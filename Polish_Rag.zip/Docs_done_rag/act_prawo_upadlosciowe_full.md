---
id: act.prawo-upadlosciowe
title: "Prawo upadłościowe (tekst jednolity)"
category: act
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 2003 nr 60 poz. 535"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["Prawo upadłościowe"]
tags: ["prawo upadłościowe","upadłość","postępowanie upadłościowe","PL"]
source_pdf: "D20030535Lj.pdf"
---

# Ustawa – Prawo upadłościowe

©Kancelaria Sejmu 
 
 
 
s. 1/224 
 
2025-09-11 
 
 
Dz. U. 2003 Nr 60 poz. 535  
 
 
U S TAWA  
z dnia 28 lutego 2003 r. 
Prawo upadłościowe1) 
CZĘŚĆ PIERWSZA 
PRZEPISY OGÓLNE O POSTĘPOWANIU UPADŁOŚCIOWYM I JEGO 
SKUTKACH 
TYTUŁ I 
Przepisy ogólne 
DZIAŁ I 
Przepisy wstępne
***
## Art. 1. {#art-1}

1. Ustawa reguluje: 
- 1) zasady wspólnego dochodzenia roszczeń wierzycieli od niewypłacalnych 
dłużników będących przedsiębiorcami; 
- 2) zasady dochodzenia roszczeń od niewypłacalnych dłużników będących osobami 
fizycznymi nieprowadzącymi działalności gospodarczej; 
- 3) skutki ogłoszenia upadłości; 
- 4) zasady umarzania zobowiązań upadłego będącego osobą fizyczną. 
- 5) (uchylony) 
- 1) Niniejsza ustawa w zakresie swojej regulacji wdraża: 
- 1) dyrektywę 2001/17/WE Parlamentu Europejskiego i Rady z dnia 19 marca 2001 r. w sprawie 
reorganizacji i likwidacji zakładów ubezpieczeń (Dz. Urz. WE L 110 z 20.04.2001); 
- 2) dyrektywę 2001/24/WE Parlamentu Europejskiego i Rady z dnia 4 kwietnia 2001 r. w sprawie 
reorganizacji i likwidacji instytucji kredytowych (Dz. Urz. WE L 125 z 05.05.2001); 
- 3) dyrektywę Parlamentu Europejskiego i Rady (UE) 2019/1023 z dnia 20 czerwca 2019 r. 
w sprawie ram restrukturyzacji zapobiegawczej, umorzenia długów i zakazów prowadzenia 
działalności oraz w sprawie środków zwiększających skuteczność postępowań dotyczących 
restrukturyzacji, niewypłacalności i umorzenia długów, a także zmieniającą dyrektywę (UE) 
2017/1132 (dyrektywa o restrukturyzacji i upadłości) (Dz. Urz. UE L 172 z 26.06.2019, str. 18 
oraz Dz. Urz. UE L 43 z 24.02.2022, str. 93). 
Opracowano na 
podstawie: 
t.j. 
Dz. U. z 2025 r. 
poz. 614, 1085, 
1170, 1172. 

©Kancelaria Sejmu 
 
 
 
s. 2/224 
 
2025-09-11 
 
2. Przepisy ustawy stosuje się również do innych podmiotów określonych 
w ustawie.

***
## Art. 2. {#art-2}

1. Postępowanie uregulowane ustawą należy prowadzić tak, aby 
roszczenia wierzycieli mogły zostać zaspokojone w jak najwyższym stopniu, a jeśli 
racjonalne względy na to pozwolą – dotychczasowe przedsiębiorstwo dłużnika zostało 
zachowane. 
1a. (uchylony) 
2. Postępowanie uregulowane ustawą wobec osób fizycznych należy prowadzić 
również tak, aby umożliwić umorzenie zobowiązań upadłego niewykonanych 
w postępowaniu upadłościowym.

***
## Art. 3. {#art-3}

Postępowanie uregulowane ustawą może być wszczęte tylko na wniosek 
złożony przez podmioty określone w ustawie.

***
## Art. 4. {#art-4}

1. Przepisy części pierwszej stosuje się odpowiednio do innych rodzajów 
postępowań unormowanych w ustawie, chyba że przepis szczególny stanowi inaczej. 
2. Przepisy części pierwszej stosuje się odpowiednio do postępowań określonych 
w art. 36 oraz rozdziale V rozporządzenia Parlamentu Europejskiego i Rady (UE) 
2015/848 z dnia 20 maja 2015 r. w sprawie postępowania upadłościowego (Dz. Urz. 
UE L 141 z 05.06.2015, str. 19), zwanego dalej „rozporządzeniem 2015/848”. 
Art. 4a. Ilekroć w ustawie jest mowa o „Rejestrze”, należy przez to rozumieć 
Krajowy Rejestr Zadłużonych. 
DZIAŁ II 
Podmiotowy zakres stosowania ustawy

***
## Art. 5. {#art-5}

1. Przepisy ustawy stosuje się do przedsiębiorców w rozumieniu ustawy 
z dnia 23 kwietnia 1964 r. – Kodeks cywilny (Dz. U. z 2024 r. poz. 1061 i 1237), jeżeli 
ustawa nie stanowi inaczej. 
2. Przepisy ustawy stosuje się także do: 
- 1) spółek z ograniczoną odpowiedzialnością, prostych spółek akcyjnych i spółek 
akcyjnych nieprowadzących działalności gospodarczej; 
- 2) wspólników osobowych spółek handlowych, ponoszących odpowiedzialność za 
zobowiązania spółki bez ograniczenia całym swoim majątkiem; 
- 3) wspólników spółki partnerskiej.

***
## Art. 6. {#art-6}

Nie można ogłosić upadłości: 

©Kancelaria Sejmu 
 
 
 
s. 3/224 
 
2025-09-11 
- 1) Skarbu Państwa; 
- 2) jednostek samorządu terytorialnego; 
- 3) publicznych samodzielnych zakładów opieki zdrowotnej; 
- 4) instytucji i osób prawnych utworzonych w drodze ustawy, chyba że ustawa ta 
stanowi inaczej, oraz utworzonych w wykonaniu obowiązku nałożonego ustawą; 
- 5) osób fizycznych prowadzących gospodarstwo rolne, które nie prowadzą innej 
działalności gospodarczej lub zawodowej; 
- 6) uczelni; 
- 7) funduszy inwestycyjnych.

***
## Art. 7. {#art-7}

W razie śmierci przedsiębiorcy można ogłosić jego upadłość, jeżeli 
wniosek o ogłoszenie upadłości został złożony w terminie roku od dnia jego śmierci, 
a w przypadku ustanowienia zarządu sukcesyjnego, o którym mowa w ustawie z dnia 
5 lipca 2018 r. o zarządzie sukcesyjnym przedsiębiorstwem osoby fizycznej i innych 
ułatwieniach związanych z sukcesją przedsiębiorstw (Dz. U. z 2021 r. poz. 170), 
zwanego dalej „zarządem sukcesyjnym” – także po upływie roku od dnia śmierci 
przedsiębiorcy, a przed dniem wygaśnięcia zarządu sukcesyjnego. Wniosek 
o ogłoszenie upadłości może złożyć wierzyciel, zarządca sukcesyjny, a także 
spadkobierca, oraz małżonek i każde z dzieci lub rodziców zmarłego, chociażby nie 
dziedziczyli po nim spadku.

***
## Art. 8. {#art-8}

1. Wierzyciel może złożyć wniosek o ogłoszenie upadłości osoby 
fizycznej, która była przedsiębiorcą, także po zaprzestaniu prowadzenia przez nią 
działalności gospodarczej, jeżeli od dnia wykreślenia z właściwego rejestru nie 
upłynął rok. Postępowanie toczy się według przepisów tytułu V części trzeciej. 
2. Przepis ust. 1 stosuje się odpowiednio do osób, które przestały być 
wspólnikami osobowych spółek handlowych.

***
## Art. 9. {#art-9}

Wierzyciel może złożyć wniosek o ogłoszenie upadłości osoby fizycznej, 
która faktycznie prowadziła działalność gospodarczą, nawet wówczas gdy nie 
dopełniła obowiązku jej zgłoszenia we właściwym rejestrze, jeżeli od dnia 
zaprzestania prowadzenia działalności nie upłynął rok. Postępowanie toczy się według 
przepisów tytułu V części trzeciej. 
Art. 9a. 1. Nie można ogłosić upadłości w okresie od dnia otwarcia 
przyspieszonego 
postępowania 
układowego, 
postępowania 
układowego 
i postępowania sanacyjnego do dnia zakończenia albo prawomocnego umorzenia tego 

©Kancelaria Sejmu 
 
 
 
s. 4/224 
 
2025-09-11 
 
postępowania. W takim przypadku rozpoznanie wniosku o ogłoszenie upadłości 
zostaje wstrzymane. 
2. Nie można ogłosić upadłości w okresie od dnia obwieszczenia o ustaleniu dnia 
układowego w postępowaniu o zatwierdzenie układu do dnia prawomocnego 
umorzenia postępowania o zatwierdzenie układu albo do dnia złożenia wniosku 
o zatwierdzenie układu do sądu. W takim przypadku rozpoznanie wniosku 
o ogłoszenie upadłości zostaje wstrzymane. 
Art. 9b. 1. W przypadku złożenia wniosku o ogłoszenie upadłości i wniosku 
restrukturyzacyjnego, 
w pierwszej 
kolejności 
rozpoznaje 
się 
wniosek 
restrukturyzacyjny. 
2. Sąd upadłościowy wstrzymuje rozpoznanie wniosku o ogłoszenie upadłości 
do 
czasu 
wydania 
prawomocnego 
orzeczenia 
w sprawie 
wniosku 
restrukturyzacyjnego. Wstrzymanie rozpoznania wniosku o ogłoszenie upadłości nie 
wyłącza możliwości zabezpieczenia majątku. 
3. Jeżeli wstrzymaniu rozpoznania wniosku o ogłoszenie upadłości sprzeciwia 
się interes ogółu wierzycieli, przepisu ust. 2 nie stosuje się. W takiej sytuacji sąd 
upadłościowy wydaje postanowienie o przejęciu wniosku o ogłoszenie upadłości 
i wniosku restrukturyzacyjnego do wspólnego rozpoznania i rozstrzygnięcia jednym 
postanowieniem. Sąd upadłościowy rozpoznaje wnioski w składzie właściwym dla 
rozpoznania wniosku o ogłoszenie upadłości. 
4. Jeżeli 
przejęcie 
wniosku 
o ogłoszenie 
upadłości 
i wniosku 
restrukturyzacyjnego do wspólnego rozpoznania prowadziłoby do znacznego 
opóźnienia wydania orzeczenia w przedmiocie ogłoszenia upadłości, ze szkodą dla 
wierzycieli, a podstawy restrukturyzacji przedstawione przez dłużnika we wniosku 
restrukturyzacyjnym są znane sądowi upadłościowemu, sąd upadłościowy nie wydaje 
postanowienia o przejęciu wniosków do wspólnego rozpoznania i rozpoznaje wniosek 
o ogłoszenie upadłości, o czym zawiadamia sąd restrukturyzacyjny. 
DZIAŁ III 
Podstawy ogłoszenia upadłości

***
## Art. 10. {#art-10}

Upadłość ogłasza się w stosunku do dłużnika, który stał się 
niewypłacalny. 

©Kancelaria Sejmu 
 
 
 
s. 5/224 
 
2025-09-11

***
## Art. 11. {#art-11}

1. Dłużnik jest niewypłacalny, jeżeli utracił zdolność do wykonywania 
swoich wymagalnych zobowiązań pieniężnych. 
1a. Domniemywa się, że dłużnik utracił zdolność do wykonywania swoich 
wymagalnych zobowiązań pieniężnych, jeżeli opóźnienie w wykonaniu zobowiązań 
pieniężnych przekracza trzy miesiące. 
2. Dłużnik będący osobą prawną albo jednostką organizacyjną nieposiadającą 
osobowości prawnej, której odrębna ustawa przyznaje zdolność prawną, jest 
niewypłacalny także wtedy, gdy jego zobowiązania pieniężne przekraczają wartość 
jego majątku, a stan ten utrzymuje się przez okres przekraczający dwadzieścia cztery 
miesiące. 
3. Do majątku, o którym mowa w ust. 2, nie wlicza się składników 
niewchodzących w skład masy upadłości. 
4. Do zobowiązań pieniężnych, o których mowa w ust. 2, nie wlicza się 
zobowiązań przyszłych, w tym zobowiązań pod warunkiem zawieszającym oraz 
zobowiązań wobec wspólnika albo akcjonariusza z tytułu pożyczki lub innej czyn-
ności prawnej o podobnych skutkach, o których mowa w art. 342 ust. 1 pkt 4. 
4a. Do zobowiązań pieniężnych, o których mowa w ust. 2, nie wlicza się 
zobowiązań wynikających z: 
- 1) instrumentów kapitałowych wyemitowanych w celu ich zakwalifikowania do 
funduszy własnych jako instrumenty: 
  - a) dodatkowe 
w Tier 
I zgodnie 
z art. 52 rozporządzenia 
Parlamentu 
Europejskiego i Rady (UE) nr 575/2013 z dnia 26 czerwca 2013 r. 
w sprawie wymogów ostrożnościowych dla instytucji kredytowych oraz 
zmieniającego rozporządzenie (UE) nr 648/2012 (Dz. Urz. UE L 176 
z 27.06.2013, str. 1, z późn. zm.2)), zwanego dalej „rozporządzeniem 
nr 575/2013”, 
  - b) w Tier II zgodnie z art. 63 rozporządzenia nr 575/2013; 
- 2) Zmiany wymienionego rozporządzenia zostały ogłoszone w Dz. Urz. UE L 208 z 02.08.2013, str. 68, 
Dz. Urz. UE L 321 z 30.11.2013, str. 6, Dz. Urz. UE L 11 z 17.01.2015, str. 37, Dz. Urz. UE L 171 
z 29.06.2016, str. 153, Dz. Urz. UE L 20 z 25.01.2017, str. 2, Dz. Urz. UE L 310 z 25.11.2017, 
str. 1, Dz. Urz. UE L 345 z 27.12.2017, str. 27, Dz. Urz. UE L 347 z 28.12.2017, str. 1, Dz. Urz. 
UE L 74 z 16.03.2018, str. 3, Dz. Urz. UE L 111 z 25.04.2019, str. 4, Dz. Urz. UE L 150 
z 07.06.2019, str. 1, Dz. Urz. UE L 314 z 05.12.2019, str. 1, Dz. Urz. UE L 328 z 18.12.2019, str. 1, 
Dz. Urz. UE L 204 z 26.06.2020, str. 4, Dz. Urz. UE L 335 z 13.10.2020, str. 20, Dz. Urz. UE L 405 
z 02.12.2020, str. 79, Dz. Urz. UE L 84 z 11.03.2021, str. 1, Dz. Urz. UE L 116 z 06.04.2021, 
str. 25 oraz Dz. Urz. UE L 275 z 25.10.2022, str. 1.  

©Kancelaria Sejmu 
 
 
 
s. 6/224 
 
2025-09-11 
- 2) pożyczek podporządkowanych zaciągniętych w celu ich zakwalifikowania do 
funduszy 
własnych 
jako 
instrumenty 
dodatkowe 
w Tier 
I zgodnie 
z art. 52 rozporządzenia nr 575/2013. 
4b. W przypadku zakładów ubezpieczeń i zakładów reasekuracji do zobowiązań 
pieniężnych, o których mowa w ust. 2, nie wlicza się zobowiązań wynikających z: 
- 1) obligacji kapitałowych wyemitowanych w celu ich zakwalifikowania do 
środków własnych jako pozycji podstawowych środków własnych kategorii 
1 zgodnie z art. 71 rozporządzenia delegowanego Komisji (UE) nr 2015/35 
z dnia 10 października 2014 r. uzupełniającego dyrektywę Parlamentu 
Europejskiego i Rady 2009/138/WE w sprawie podejmowania i prowadzenia 
działalności ubezpieczeniowej i reasekuracyjnej (Wypłacalność II) (Dz. Urz. 
UE L 12 z 17.01.2015, str. 1, z późn. zm.3)), zwanego dalej „rozporządzeniem 
delegowanym Komisji (UE) 2015/35”; 
- 2) pożyczek podporządkowanych zaciągniętych w celu zakwalifikowania ich do 
środków własnych jako pozycji środków własnych kategorii 1 zgodnie 
z rozporządzeniem delegowanym Komisji (UE) 2015/35. 
5. Domniemywa się, że zobowiązania pieniężne dłużnika przekraczają wartość 
jego majątku, jeżeli zgodnie z bilansem jego zobowiązania, z wyłączeniem rezerw na 
zobowiązania oraz zobowiązań wobec jednostek powiązanych, przekraczają wartość 
jego aktywów, a stan ten utrzymuje się przez okres przekraczający dwadzieścia cztery 
miesiące. 
6. Sąd może oddalić wniosek o ogłoszenie upadłości, jeżeli nie ma zagrożenia 
utraty przez dłużnika zdolności do wykonywania jego wymagalnych zobowiązań 
pieniężnych w niedługim czasie. 
7. Przepisy ust. 2–6 nie mają zastosowania do spółek osobowych określonych 
w ustawie z dnia 15 września 2000 r. – Kodeks spółek handlowych (Dz. U. z 2024 r. 
poz. 18 i 96), zwanej dalej „Kodeksem spółek handlowych”, w których co najmniej 
jednym wspólnikiem odpowiadającym za zobowiązania spółki bez ograniczenia 
całym swoim majątkiem jest osoba fizyczna. 
- 3) Zmiany wymienionego rozporządzenia zostały ogłoszone w Dz. Urz. UE L 85 z 01.04.2016, str. 6, 
Dz. Urz. UE L 346 z 20.12.2016, str. 111, Dz. Urz. UE L 236 z 14.09.2017, str. 14, Dz. Urz. 
UE L 227 z 10.09.2018, str. 1, Dz. Urz. UE L 161 z 18.06.2019, str. 1, Dz. Urz. UE L 289 
z 08.11.2019, str. 3, Dz. Urz. UE L 92 z 26.03.2020, str. 1, Dz. Urz. UE L 277 z 02.08.2021, str. 14 
oraz Dz. Urz. UE L 2 z 06.01.2022, str. 8.  

©Kancelaria Sejmu 
 
 
 
s. 7/224 
 
2025-09-11 
 
Art. 11a. 1. W przypadku ustanowienia zarządu sukcesyjnego można ogłosić 
upadłość zmarłego przedsiębiorcy także wtedy, gdy w zakresie czynności 
dokonywanych w ramach prowadzenia przedsiębiorstwa w spadku zarządca 
sukcesyjny utracił zdolność do wykonywania wymagalnych zobowiązań pieniężnych. 
2. Przepis art. 11 ust. 1a stosuje się odpowiednio.

***
## Art. 12. {#art-12}

(uchylony) 
Art. 12a. Sąd oddali wniosek o ogłoszenie upadłości złożony przez wierzyciela, 
jeżeli dłużnik wykaże, że wierzytelność ma w całości charakter sporny, a spór zaistniał 
między stronami przed złożeniem wniosku o ogłoszenie upadłości.

***
## Art. 13. {#art-13}

1. Sąd oddali wniosek o ogłoszenie upadłości, jeżeli majątek 
niewypłacalnego dłużnika nie wystarcza na zaspokojenie kosztów postępowania lub 
wystarcza jedynie na zaspokojenie tych kosztów. 
2. Sąd może oddalić wniosek o ogłoszenie upadłości w razie stwierdzenia, że 
majątek dłużnika jest obciążony hipoteką, zastawem, zastawem rejestrowym, 
zastawem skarbowym lub hipoteką morską w takim stopniu, że pozostały jego majątek 
nie wystarcza na zaspokojenie kosztów postępowania. 
2a. Oddalając wniosek o ogłoszenie upadłości, sąd ustala, czy materiał 
zgromadzony w sprawie daje podstawę do rozwiązania podmiotu wpisanego do 
Krajowego Rejestru Sądowego bez przeprowadzania postępowania likwidacyjnego. 
3. Jeżeli zostanie uprawdopodobnione, że obciążenia majątku dłużnika są 
bezskuteczne według przepisów ustawy albo gdy dokonane zostały w celu 
pokrzywdzenia wierzycieli, jak również jeżeli zostanie uprawdopodobnione, że 
dłużnik dokonał innych czynności prawnych bezskutecznych według przepisów 
ustawy, którymi wyzbył się majątku wystarczającego na zaspokojenie kosztów 
postępowania, a okoliczności sprawy wskazują, że zastosowanie przepisów 
o bezskuteczności i zaskarżaniu czynności upadłego doprowadzi do uzyskania 
majątku o wartości przekraczającej przewidywaną wysokość kosztów, przepisów 
ust. 1 i 2 nie stosuje się. 
4. Prawomocne postanowienie o oddaleniu wniosku o ogłoszenie upadłości na 
podstawie ust. 1 lub 2 obwieszcza się. 
5. Oddalając wniosek o ogłoszenie upadłości na podstawie ust. 1 lub 2, sąd 
wydaje postanowienie, w którym wymienia: 
- 1) imię i nazwisko dłużnika albo jego nazwę; 

©Kancelaria Sejmu 
 
 
 
s. 8/224 
 
2025-09-11 
- 2) numer PESEL albo numer w Krajowym Rejestrze Sądowym dłużnika, 
a w przypadku ich braku – inne dane umożliwiające jego jednoznaczną 
identyfikację, 
w szczególności 
numer 
paszportu 
i oznaczenie 
państwa 
wystawiającego paszport albo numer karty pobytu w Rzeczypospolitej Polskiej, 
albo numer w zagranicznym rejestrze, albo zagraniczny numer identyfikacji lub 
identyfikacji podatkowej; 
- 3) firmę, pod którą działa dłużnik; 
- 4) miejsce zamieszkania albo siedzibę oraz adres dłużnika; 
- 5) numer identyfikacji podatkowej (NIP), jeżeli dłużnik ma taki numer. 
6. W przypadku spółki osobowej w postanowieniu, o którym mowa w ust. 5, 
dodatkowo wymienia się: 
- 1) imiona i nazwiska albo nazwę wspólników odpowiadających za zobowiązania 
spółki bez ograniczenia całym swoim majątkiem; 
- 2) numery PESEL albo numery w Krajowym Rejestrze Sądowym wspólników, 
o których mowa w pkt 1, a w przypadku ich braku – inne dane umożliwiające ich 
jednoznaczną identyfikację, w szczególności numer paszportu i oznaczenie 
państwa wystawiającego paszport albo numer karty pobytu w Rzeczypospolitej 
Polskiej, albo numer w zagranicznym rejestrze, albo zagraniczny numer 
identyfikacji lub identyfikacji podatkowej; 
- 3) miejsce zamieszkania albo siedzibę wspólników, o których mowa w pkt 1. 
7. W sekretariacie sądu umożliwia się każdemu, kto dostatecznie usprawiedliwi 
potrzebę przejrzenia akt sądowych postępowania zakończonego prawomocnym 
postanowieniem o oddaleniu wniosku o ogłoszenie upadłości na podstawie ust. 1 lub 
2, dostęp do tych akt za pośrednictwem systemu teleinformatycznego obsługującego 
postępowanie sądowe.

***
## Art. 14. {#art-14}

(uchylony)

***
## Art. 15. {#art-15}

(uchylony)

***
## Art. 16. {#art-16}

(uchylony)

***
## Art. 17. {#art-17}

(uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 9/224 
 
2025-09-11 
 
TYTUŁ II 
Postępowanie w przedmiocie ogłoszenia upadłości 
DZIAŁ I 
Sąd

***
## Art. 18. {#art-18}

Sprawy o ogłoszenie upadłości rozpoznaje sąd upadłościowy w składzie 
trzech sędziów zawodowych. Sądem upadłościowym jest sąd rejonowy – sąd 
gospodarczy.

***
## Art. 19. {#art-19}

1. Sprawy o ogłoszenie upadłości rozpoznaje sąd właściwy dla 
głównego ośrodka podstawowej działalności dłużnika. 
1a. Głównym ośrodkiem podstawowej działalności jest miejsce, w którym 
dłużnik regularnie zarządza swoją działalnością o charakterze ekonomicznym i które 
jako takie jest rozpoznawalne dla osób trzecich. 
1b. W przypadku osoby prawnej oraz jednostki organizacyjnej nieposiadającej 
osobowości prawnej, której odrębna ustawa przyznaje zdolność prawną, domniemywa 
się, że głównym ośrodkiem jej podstawowej działalności jest miejsce siedziby. 
1c. W przypadku osoby fizycznej prowadzącej działalność gospodarczą lub 
zawodową domniemywa się, że głównym ośrodkiem jej podstawowej działalności jest 
główne 
miejsce 
wykonywania 
działalności 
gospodarczej 
lub 
zawodowej; 
w przypadku każdej innej osoby fizycznej domniemywa się, że głównym ośrodkiem 
podstawowej działalności jest miejsce zwykłego pobytu tej osoby. 
2. (uchylony) 
3. Jeżeli dłużnik nie ma w Rzeczypospolitej Polskiej głównego ośrodka 
podstawowej działalności, właściwy jest sąd miejsca zwykłego pobytu albo siedziby 
dłużnika, a jeżeli dłużnik nie ma w Rzeczypospolitej Polskiej miejsca zwykłego 
pobytu albo siedziby, właściwy jest sąd, w którego obszarze znajduje się majątek 
dłużnika. 
4. Jeżeli w toku postępowania o ogłoszenie upadłości okaże się, że właściwy jest 
inny sąd, sprawę przekazuje się temu sądowi. Na postanowienie o przekazaniu sprawy 
nie przysługuje zażalenie. Postanowienie to wiąże sąd, któremu sprawa została 
przekazana. Czynności dokonane w sądzie niewłaściwym pozostają w mocy. 
5. Przekazanie sprawy po ogłoszeniu upadłości jest niedopuszczalne. 

©Kancelaria Sejmu 
 
 
 
s. 10/224 
 
2025-09-11 
 
DZIAŁ II 
Wniosek o ogłoszenie upadłości

***
## Art. 20. {#art-20}

1. Wniosek o ogłoszenie upadłości może zgłosić dłużnik lub każdy 
z jego wierzycieli osobistych. 
2. Wniosek mogą zgłosić również: 
- 1) w stosunku do spółki jawnej, spółki partnerskiej, spółki komandytowej oraz 
spółki komandytowo-akcyjnej – każdy ze wspólników odpowiadających bez 
ograniczenia za zobowiązania spółki; 
- 2) w stosunku do osób prawnych oraz jednostek organizacyjnych nieposiadających 
osobowości prawnej, którym odrębna ustawa przyznaje zdolność prawną – 
każdy, kto na podstawie ustawy, umowy spółki lub statutu ma prawo do 
prowadzenia spraw dłużnika i do jego reprezentowania, samodzielnie lub łącznie 
z innymi osobami; 
- 3) w stosunku do przedsiębiorstwa państwowego – także organ założycielski; 
- 4) w stosunku do jednoosobowej spółki Skarbu Państwa – także pełnomocnik 
Rządu, państwowa osoba prawna, organ lub inna jednostka uprawniona do 
wykonywania praw z akcji lub udziałów należących do Skarbu Państwa; 
- 5) w stosunku do osoby prawnej, spółki jawnej, spółki partnerskiej oraz spółki 
komandytowej i komandytowo-akcyjnej, będących w stanie likwidacji – każdy 
z likwidatorów; 
- 6) w stosunku do osoby prawnej wpisanej do Krajowego Rejestru Sądowego – 
kurator ustanowiony na podstawie art. 42 § 1 ustawy z dnia 23 kwietnia 1964 r. 
– Kodeks cywilny; 
- 7) w stosunku do dłużnika, któremu została udzielona pomoc publiczna o wartości 
przekraczającej 100 000 euro – organ udzielający pomocy; 
- 8) w stosunku do dłużnika, wobec którego prowadzona jest egzekucja przez zarząd 
przymusowy albo przez sprzedaż przedsiębiorstwa, na podstawie Kodeksu 
postępowania cywilnego – zarządca ustanowiony w tym postępowaniu; 
- 9) w stosunku do spółki zależnej uczestniczącej w grupie spółek – spółka 
dominująca.

***
## Art. 21. {#art-21}

1. Dłużnik jest obowiązany, nie później niż w terminie trzydziestu dni 
od dnia, w którym wystąpiła podstawa do ogłoszenia upadłości, zgłosić w sądzie 
wniosek o ogłoszenie upadłości. 

©Kancelaria Sejmu 
 
 
 
s. 11/224 
 
2025-09-11 
 
2. Jeżeli dłużnikiem jest osoba prawna albo inna jednostka organizacyjna 
nieposiadająca osobowości prawnej, której odrębna ustawa przyznaje zdolność 
prawną, obowiązek, o którym mowa w ust. 1, spoczywa na każdym, kto na podstawie 
ustawy, umowy spółki lub statutu ma prawo do prowadzenia spraw dłużnika i do jego 
reprezentowania, samodzielnie lub łącznie z innymi osobami. 
2a. W przypadku ustanowienia zarządu sukcesyjnego obowiązek, o którym 
mowa w ust. 1, spoczywa na zarządcy sukcesyjnym. Jeżeli podstawa do ogłoszenia 
upadłości wystąpiła przed ustanowieniem zarządu sukcesyjnego, termin do zgłoszenia 
wniosku o ogłoszenie upadłości biegnie od dnia, w którym został ustanowiony zarząd 
sukcesyjny. Zgłoszenie wniosku o ogłoszenie upadłości przez zarządcę sukcesyjnego 
nie wymaga zgody osób, na rzecz których działa zarządca sukcesyjny. 
3. Osoby, o których mowa w ust. 1–2a, ponoszą odpowiedzialność za szkodę 
wyrządzoną wskutek niezłożenia wniosku w terminie określonym w ust. 1 lub 2a, 
chyba że nie ponoszą winy. Osoby te mogą uwolnić się od odpowiedzialności, 
w szczególności jeżeli wykażą, że w terminie określonym w ust. 1 lub 2a otwarto 
postępowanie 
restrukturyzacyjne 
albo 
zatwierdzono 
układ 
w postępowaniu 
o zatwierdzenie układu. 
3a. W przypadku 
dochodzenia 
odszkodowania 
przez 
wierzyciela 
niewypłacalnego dłużnika domniemywa się, że szkoda, o której mowa w ust. 3, 
obejmuje wysokość niezaspokojonej wierzytelności tego wierzyciela wobec dłużnika. 
4. (uchylony) 
5. Osoby, o których mowa w ust. 1–2a, nie ponoszą odpowiedzialności za 
niezłożenie wniosku o ogłoszenie upadłości w czasie, gdy prowadzona jest egzekucja 
przez zarząd przymusowy albo przez sprzedaż przedsiębiorstwa, na podstawie 
przepisów Kodeksu postępowania cywilnego, jeżeli obowiązek złożenia wniosku 
o ogłoszenie upadłości powstał w czasie prowadzenia egzekucji.

***
## Art. 22. {#art-22}

1. Wniosek o ogłoszenie upadłości powinien zawierać: 
- 1) imię i nazwisko dłużnika albo jego nazwę oraz numer PESEL albo numer 
w Krajowym Rejestrze Sądowym, a w przypadku ich braku – inne dane 
umożliwiające jego jednoznaczną identyfikację, firmę, pod którą działa dłużnik, 
miejsce zamieszkania albo siedzibę, adres, a jeżeli dłużnikiem jest spółka 
osobowa, osoba prawna albo inna jednostka organizacyjna nieposiadająca 
osobowości prawnej, której odrębna ustawa przyznaje zdolność prawną – imiona 
i nazwiska reprezentantów, w tym likwidatorów, jeżeli są ustanowieni, oraz 

©Kancelaria Sejmu 
 
 
 
s. 12/224 
 
2025-09-11 
 
numery PESEL albo numery w Krajowym Rejestrze Sądowym reprezentantów, 
a w przypadku ich braku – inne dane umożliwiające ich jednoznaczną 
identyfikację, a ponadto w przypadku spółki osobowej – imiona i nazwiska albo 
nazwę, numery PESEL albo numery w Krajowym Rejestrze Sądowym, 
a w przypadku ich braku – inne dane umożliwiające jednoznaczną identyfikację 
oraz miejsce zamieszkania albo siedzibę wspólników odpowiadających za 
zobowiązania spółki bez ograniczenia całym swoim majątkiem; 
1a) NIP, jeżeli dłużnik ma taki numer; 
- 2) wskazanie miejsca, w którym znajduje się główny ośrodek podstawowej 
działalności dłużnika; 
- 3) wskazanie okoliczności, które uzasadniają wniosek i ich uprawdopodobnienie; 
- 4) informację, czy dłużnik jest uczestnikiem podlegającego prawu polskiemu lub 
prawu innego państwa członkowskiego systemu płatności lub systemu 
rozrachunku papierów wartościowych w rozumieniu ustawy z dnia 24 sierpnia 
2001 r. o ostateczności rozrachunku w systemach płatności i systemach 
rozrachunku papierów wartościowych oraz zasadach nadzoru nad tymi 
systemami (Dz. U. z 2024 r. poz. 585) lub niebędącym uczestnikiem podmiotem 
prowadzącym system interoperacyjny w rozumieniu tej ustawy; 
- 5) informację, czy dłużnik jest spółką publiczną w rozumieniu przepisów ustawy 
z dnia 29 lipca 2005 r. o ofercie publicznej i warunkach wprowadzania 
instrumentów finansowych do zorganizowanego systemu obrotu oraz o spółkach 
publicznych (Dz. U. z 2024 r. poz. 620 i 1863 oraz z 2025 r. poz. 146). 
2. (uchylony) 
2a. (uchylony) 
3. Jeżeli wniosek zgłasza wierzyciel, przepisu ust. 1 pkt 4 nie stosuje się. 
4. Przez inne dane umożliwiające jednoznaczną identyfikację, o których mowa 
w ust. 1 pkt 1, rozumie się w szczególności numer paszportu i oznaczenie państwa 
wystawiającego paszport albo numer karty pobytu w Rzeczypospolitej Polskiej, albo 
numer w zagranicznym rejestrze, albo zagraniczny numer identyfikacji lub 
identyfikacji podatkowej. 
Art. 22a. Wnioskodawca uiszcza zaliczkę na wydatki w toku postępowania 
w przedmiocie ogłoszenia upadłości w wysokości jednokrotności przeciętnego 
miesięcznego wynagrodzenia w sektorze przedsiębiorstw bez wypłat nagród z zysku 
w trzecim kwartale roku poprzedniego, ogłoszonego przez Prezesa Głównego Urzędu 

©Kancelaria Sejmu 
 
 
 
s. 13/224 
 
2025-09-11 
 
Statystycznego i wraz z wnioskiem przedstawia dowód jej uiszczenia. W przypadku 
braku uiszczenia zaliczki przewodniczący wzywa do uiszczenia zaliczki w terminie 
tygodnia pod rygorem zwrotu wniosku.

***
## Art. 23. {#art-23}

1. Jeżeli wniosek o ogłoszenie upadłości zgłasza dłużnik, do wniosku 
powinien dołączyć: 
- 1) aktualny wykaz majątku z szacunkową wyceną jego składników; 
- 2) bilans sporządzony przez dłużnika dla celów postępowania, na dzień 
przypadający w okresie trzydziestu dni przed dniem złożenia wniosku; 
- 3) spis wierzycieli z podaniem ich adresów i wysokości wierzytelności każdego 
z nich oraz terminów zapłaty, a także listę zabezpieczeń dokonanych przez 
wierzycieli na jego majątku wraz z datami ich ustanowienia; 
- 4) oświadczenie o spłatach wierzytelności lub innych długów dokonanych 
w terminie sześciu miesięcy przed dniem złożenia wniosku; 
- 5) spis podmiotów zobowiązanych majątkowo wobec dłużnika wraz z adresami, 
z określeniem wierzytelności, daty ich powstania i terminów zapłaty; 
- 6) wykaz tytułów egzekucyjnych oraz tytułów wykonawczych przeciwko 
dłużnikowi; 
- 7) informację o postępowaniach dotyczących ustanowienia na majątku dłużnika 
hipotek, zastawów, zastawów rejestrowych, zastawów skarbowych i hipotek 
morskich oraz innych obciążeń podlegających wpisowi w księdze wieczystej lub 
w rejestrach, jak również o prowadzonych innych postępowaniach sądowych, 
administracyjnych, sądowoadministracyjnych oraz przed sądami polubownymi 
dotyczących majątku dłużnika; 
- 8) informację o miejscu zamieszkania reprezentantów spółki lub osoby prawnej 
i likwidatorów, jeżeli są ustanowieni; 
- 9) informację, czy w jednym z dwóch ostatnich lat obrotowych: 
  - a) zatrudniał średniorocznie 250 lub więcej pracowników lub 
  - b) osiągnął roczny obrót netto ze sprzedaży towarów, wyrobów i usług oraz 
operacji finansowych przekraczający równowartość w złotych 50 milionów 
euro, lub 
  - c) sumy aktywów jego bilansu sporządzonego na koniec jednego z tych lat 
przekroczyły równowartość w złotych 43 milionów euro. 
2. (uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 14/224 
 
2025-09-11 
 
3. Jeżeli dłużnik nie może dołączyć do wniosku dokumentów, o których mowa 
w ust. 1, powinien podać przyczyny ich niedołączenia oraz je uprawdopodobnić.

***
## Art. 24. {#art-24}

Jeżeli wniosek o ogłoszenie upadłości zgłasza wierzyciel, powinien we 
wniosku uprawdopodobnić swoją wierzytelność. 
Art. 24a. (uchylony)

***
## Art. 25. {#art-25}

1. Wraz z wnioskiem o ogłoszenie upadłości dłużnik jest obowiązany 
złożyć oświadczenie o prawdziwości danych zawartych we wniosku. 
2. Jeżeli oświadczenie, o którym mowa w ust. 1, nie jest zgodne z prawdą, 
dłużnik ponosi odpowiedzialność za szkodę wyrządzoną na skutek podania 
nieprawdziwych danych we wniosku o ogłoszenie upadłości. 
3. W razie niezłożenia oświadczenia, o którym mowa w ust. 1, wniosek zwraca 
się bez wzywania dłużnika do jego uzupełnienia. 
Art. 25a. Zarządzenie o wpisaniu do repertorium wniosku o ogłoszenie 
upadłości złożonego przez dłużnika, prawomocne zarządzenie o zwrocie tego wniosku 
oraz prawomocne postanowienie o odrzuceniu lub oddaleniu tego wniosku lub 
umorzeniu postępowania w przedmiocie rozpoznania tego wniosku obwieszcza się. 
DZIAŁ III 
Przepisy o postępowaniu

***
## Art. 26. {#art-26}

1. Uczestnikiem postępowania o ogłoszenie upadłości jest każdy, kto 
złożył wniosek o ogłoszenie upadłości, oraz dłużnik. 
2. O złożeniu wniosku o ogłoszenie upadłości przedsiębiorstwa państwowego 
albo jednoosobowej spółki Skarbu Państwa sąd niezwłocznie zawiadamia 
odpowiednio organ założycielski albo pełnomocnika Rządu, państwową osobę 
prawną, organ lub inną jednostkę uprawnioną do wykonywania praw z akcji lub 
udziałów należących do Skarbu Państwa, które w terminie dwóch tygodni mogą 
złożyć sądowi opinię w sprawie.

***
## Art. 261. {#art-261}

1. Jeżeli dłużnik nie ma zdolności procesowej i nie działa za niego 
przedstawiciel ustawowy, a także gdy w składzie organów dłużnika będącego osobą 
prawną lub jednostką organizacyjną nieposiadającą osobowości prawnej, której 
odrębna ustawa przyznaje zdolność prawną, zachodzą braki uniemożliwiające ich 
działanie, sąd upadłościowy ustanawia dla niego kuratora. Kuratora ustanowionego na 

©Kancelaria Sejmu 
 
 
 
s. 15/224 
 
2025-09-11 
 
podstawie art. 42 § 1 ustawy z dnia 23 kwietnia 1964 r. – Kodeks cywilny powołuje 
się na kuratora, o którym mowa w niniejszym przepisie. 
2. Ustanowienie kuratora nie stanowi przeszkody do usunięcia, na podstawie 
zasad ogólnych, braku zdolności procesowej albo braków w składzie organów 
uniemożliwiających ich działanie. 
3. Wynagrodzenie kuratora ustanowionego na podstawie ust. 1 ustala sędzia-
-komisarz w wysokości stosownej do nakładu pracy kuratora, stosując odpowiednio 
przepisy wykonawcze wydane na podstawie art. 9 pkt 3 ustawy z dnia 28 lipca 2005 r. 
o kosztach sądowych w sprawach cywilnych (Dz. U. z 2024 r. poz. 959 i 1237). 
Wynagrodzenie kuratora obowiązanego do rozliczenia podatku od towarów i usług 
podwyższa się o kwotę podatku od towarów i usług. Na postanowienie w przedmiocie 
wynagrodzenia oraz zwrotu wydatków przysługuje zażalenie. Zażalenie przysługuje 
również kuratorowi. 
4. Przepisy ust. 1 i 3 stosuje się odpowiednio w przypadku śmierci dłużnika po 
złożeniu wniosku o ogłoszenie upadłości, jeżeli nie działa zarządca sukcesyjny, oraz 
w przypadku wygaśnięcia zarządu sukcesyjnego po złożeniu wniosku o ogłoszenie 
upadłości.

***
## Art. 27. {#art-27}

1. Sąd rozpoznaje sprawę na posiedzeniu niejawnym. 
2. Sąd może na posiedzeniu niejawnym przeprowadzić postępowanie dowodowe 
w całości lub w części także wówczas, gdy wyznaczono rozprawę. 
3. Postanowienie w sprawie ogłoszenia upadłości sąd wydaje w terminie dwóch 
miesięcy od dnia złożenia wniosku. Zażalenie na postanowienie w sprawie ogłoszenia 
upadłości sąd drugiej instancji rozpoznaje w terminie miesiąca od dnia przedstawienia 
mu akt sprawy. 
4. W przypadkach przewidzianych w ustawie obwieszczenia dokonuje się 
w Rejestrze. W przypadku gdy od dnia obwieszczenia biegnie termin do wniesienia 
środka zaskarżenia, obwieszczeniu podlega także informacja o sposobie i terminie 
jego wniesienia.

***
## Art. 28. {#art-28}

(uchylony)

***
## Art. 29. {#art-29}

Jeżeli na skutek braku lub wskazania nieprawidłowego adresu dłużnika 
lub niewykonania innych zarządzeń nie można nadać sprawie dalszego biegu, wniosek 
o ogłoszenie upadłości zwraca się. 

©Kancelaria Sejmu 
 
 
 
s. 16/224 
 
2025-09-11 
 
Art. 29a. 1. Sąd może uznać cofnięcie wniosku o ogłoszenie upadłości za 
niedopuszczalne, jeżeli prowadziłoby to do pokrzywdzenia wierzycieli. 
2. Wykonanie przez dłużnika zobowiązań wobec wnioskodawcy po złożeniu 
wniosku o ogłoszenie upadłości nie ma wpływu na dalszy bieg postępowania.

***
## Art. 30. {#art-30}

1. Sąd może w razie potrzeby wysłuchać dłużnika oraz wierzyciela 
będącego wnioskodawcą, a w sprawie upadłości przedsiębiorstwa państwowego albo 
jednoosobowej spółki Skarbu Państwa także odpowiednio organ założycielski albo 
przedstawiciela pełnomocnika Rządu, państwowej osoby prawnej, organu lub innej 
jednostki uprawnionej do wykonywania praw z akcji lub udziałów należących do 
Skarbu Państwa. 
2. Sąd wysłuchuje dłużnika z zachowaniem przepisów Kodeksu postępowania 
cywilnego o przesłuchaniu stron, po odebraniu od niego przyrzeczenia. 
3. Gdyby wysłuchanie, o którym mowa w ust. 2, było niemożliwe lub 
nadmiernie utrudnione, sąd może zażądać od dłużnika złożenia wyjaśnień na piśmie 
z podpisem notarialnie poświadczonym, pod rygorem odpowiedzialności karnej za 
złożenie fałszywych zeznań. Wyjaśnienia te są dowodem w sprawie. 
4. Do wysłuchania innych osób stosuje się przepis art. 217. 
Art. 30a. W postępowaniu 
w przedmiocie 
ogłoszenia 
upadłości 
nie 
przeprowadza się dowodu z opinii biegłego, z wyjątkiem określonym w art. 56b ust. 1.

***
## Art. 31. {#art-31}

(uchylony)

***
## Art. 32. {#art-32}

1. (uchylony) 
2. Jeżeli wierzyciel cofnął wniosek o ogłoszenie upadłości po wykonaniu przez 
dłużnika zobowiązań, o których mowa w art. 11, kosztami sądowymi obciąża się 
dłużnika. 
3. Kosztami sądowymi obciąża się dłużnika w przypadku oddalenia wniosku na 
podstawie art. 13. 
4. W sprawach, o których mowa w ust. 2 i 3, dłużnik obowiązany jest również 
do zwrotu kosztów poniesionych przez wierzyciela. 
5. Od wnioskodawcy sąd może zażądać zaliczki na wydatki w postępowaniu 
w przedmiocie ogłoszenia upadłości w kwocie przewyższającej sumę określoną 
w art. 22a pod rygorem odrzucenia wniosku. Na postanowienie sądu w przedmiocie 
zaliczki zażalenie nie przysługuje. Żądanie dodatkowej zaliczki nie wstrzymuje 
rozpoznania wniosku o ogłoszenie upadłości. 

©Kancelaria Sejmu 
 
 
 
s. 17/224 
 
2025-09-11 
 
6. Wydatki pokrywane są w pierwszej kolejności z zaliczki wpłaconej przez 
wnioskodawcę.

***
## Art. 33. {#art-33}

1. Zażalenie przysługuje na postanowienie sądu kończące postępowanie 
oraz w przypadkach określonych w ustawie. 
1a. Zażalenia na postanowienia sądu rozpoznaje sąd w innym składzie 
z wyjątkiem zażaleń na postanowienia kończące postępowanie w sprawie oraz których 
przedmiotem jest: 
- 1) zatwierdzenie warunków sprzedaży, 
- 2) zabezpieczenie majątku dłużnika, 
- 3) wynagrodzenie i zwrot wydatków tymczasowego nadzorcy sądowego, 
- 4) wynagrodzenie i zwrot wydatków zarządcy przymusowego 
– które rozpoznaje sąd drugiej instancji w składzie trzech sędziów zawodowych. 
2. Od postanowienia sądu drugiej instancji skarga kasacyjna nie przysługuje. 
3. Skarga o stwierdzenie niezgodności z prawem prawomocnego orzeczenia nie 
przysługuje.

***
## Art. 34. {#art-34}

1. W przypadku złożenia przez wierzyciela wniosku w złej wierze, sąd, 
oddalając 
wniosek 
o ogłoszenie 
upadłości, 
obciąży 
wierzyciela 
kosztami 
postępowania i może nakazać wierzycielowi złożenie publicznego oświadczenia 
odpowiedniej treści i w odpowiedniej formie. 
2. W przypadku oddalenia wniosku wierzyciela o ogłoszenie upadłości 
złożonego w złej wierze, dłużnikowi, a także osobie trzeciej przysługuje przeciwko 
wierzycielowi roszczenie o naprawienie szkody.

***
## Art. 35. {#art-35}

Do postępowania w przedmiocie ogłoszenia upadłości stosuje się 
odpowiednio przepisy art. 216a–216ab, art. 219, art. 220, art. 221, art. 224, 
art. 228 ust. 1, 2 i 3 i art. 229 ust. 2 oraz przepisy części pierwszej księgi pierwszej 
Kodeksu postępowania cywilnego, z wyjątkiem art. 1302, art. 1391, art. 2051, art. 2052 
i art. 2054–20512 oraz przepisów o zawieszeniu i wznowieniu postępowania oraz 
postępowaniu w sprawach gospodarczych. 

©Kancelaria Sejmu 
 
 
 
s. 18/224 
 
2025-09-11 
 
DZIAŁ IV 
Postępowanie zabezpieczające 
## Rozdział 1. Przepisy ogólne

***
## Art. 36. {#art-36}

Po złożeniu wniosku o ogłoszenie upadłości sąd na wniosek albo 
z urzędu może dokonać zabezpieczenia majątku dłużnika. W przedmiocie 
zabezpieczenia sąd orzeka niezwłocznie.

***
## Art. 37. {#art-37}

W sprawach 
nieuregulowanych 
w ustawie 
do 
postępowania 
zabezpieczającego stosuje się odpowiednio przepisy Kodeksu postępowania 
cywilnego 
o postępowaniu 
zabezpieczającym. 
Przepisu 
art. 396 Kodeksu 
postępowania cywilnego nie stosuje się. 
## Rozdział 2. Zabezpieczenie majątku dłużnika

***
## Art. 38. {#art-38}

1. Sąd może zabezpieczyć majątek dłużnika przez ustanowienie 
tymczasowego nadzorcy sądowego. Do tymczasowego nadzorcy sądowego przepisy 
art. 156 ust. 4, art. 157, art. 157a, art. 159–161, art. 166 ust. 6, art. 167 ust. 2, 
art. 167a, art. 167b, art. 170–172 i art. 178 stosuje się odpowiednio. 
1a. Postanowienie 
o ustanowieniu 
tymczasowego 
nadzorcy 
sądowego, 
odwołaniu albo zmianie osoby tymczasowego nadzorcy sądowego i informację 
o uprawomocnieniu się postanowienia o uchyleniu zabezpieczenia przez odwołanie 
tymczasowego nadzorcy sądowego obwieszcza się. 
1b. Sąd ustala wynagrodzenie tymczasowego nadzorcy sądowego, biorąc pod 
uwagę nakład pracy, zakres czynności podejmowanych w postępowaniu, stopień ich 
trudności oraz czas pełnienia funkcji. 
1c. Wynagrodzenie tymczasowego nadzorcy sądowego ustala się w wysokości 
od 
jednej 
czwartej 
przeciętnego 
miesięcznego 
wynagrodzenia 
w sektorze 
przedsiębiorstw bez wypłat nagród z zysku w trzecim kwartale roku poprzedniego, 
ogłoszonego przez Prezesa Głównego Urzędu Statystycznego do jego dwukrotności. 
1d. W szczególnie uzasadnionych przypadkach można przyznać wyższe 
wynagrodzenie w wysokości do czterokrotności wynagrodzenia, o którym mowa 
w ust. 1c, jeżeli uzasadnia to nakład pracy tymczasowego nadzorcy sądowego, zakres 
podjętych czynności, stopień ich trudności oraz czas pełnienia funkcji. 

©Kancelaria Sejmu 
 
 
 
s. 19/224 
 
2025-09-11 
 
2. O wynagrodzeniu tymczasowego nadzorcy sądowego i zwrocie wydatków 
koniecznych poniesionych w związku z pełnieniem funkcji orzeka sąd na jego 
wniosek złożony w terminie tygodnia od dnia powiadomienia o odwołaniu lub od dnia 
wygaśnięcia funkcji. Sąd może przyznać tymczasowemu nadzorcy sądowemu zaliczkę 
na wydatki. Kwotę zaliczki wypłaca się w pierwszej kolejności z zaliczki wpłaconej 
przez wnioskodawcę. 
3. Sąd może zobowiązać tymczasowego nadzorcę sądowego do złożenia 
w wyznaczonym terminie sprawozdania obejmującego w szczególności informacje na 
temat stanu finansowego dłużnika, rodzaju i wartości jego majątku oraz 
przewidywanych kosztów postępowania upadłościowego. 
Art. 38a. Dłużnik po ustanowieniu tymczasowego nadzorcy sądowego jest 
uprawniony do dokonywania czynności zwykłego zarządu. Na dokonanie czynności 
przekraczających zakres zwykłego zarządu jest wymagana zgoda tymczasowego 
nadzorcy sądowego pod rygorem nieważności. Zgoda może zostać udzielona również 
po dokonaniu czynności w terminie trzydziestu dni od jej dokonania.

***
## Art. 39. {#art-39}

1. Sąd na wniosek wnioskodawcy, dłużnika lub tymczasowego nadzorcy 
sądowego może zawiesić postępowanie egzekucyjne oraz uchylić zajęcie rachunku 
bankowego, jeżeli jest to niezbędne do osiągnięcia celów postępowania 
upadłościowego. 
Uchylając 
zajęcie 
rachunku 
bankowego, 
sąd 
ustanawia 
tymczasowego nadzorcę sądowego, jeżeli wcześniej nie został ustanowiony. 
2. Dyspozycje dłużnika dotyczące środków na rachunku bankowym, którego 
zajęcie uchylono, wymagają zgody tymczasowego nadzorcy sądowego. 
3. Postanowienie o zawieszeniu postępowania egzekucyjnego oraz uchyleniu 
zajęcia rachunku bankowego doręcza się wierzycielowi prowadzącemu egzekucję 
oraz organowi egzekucyjnemu. Na postanowienie to dłużnikowi oraz wierzycielowi 
prowadzącemu egzekucję przysługuje zażalenie.

***
## Art. 40. {#art-40}

1. Sąd może stosować inne sposoby zabezpieczenia, w tym także 
zabezpieczenie przez ustanowienie zarządu przymusowego nad majątkiem dłużnika, 
jeżeli zachodzi obawa, że dłużnik będzie ukrywał swój majątek lub w inny sposób 
działał na szkodę wierzycieli, a także gdy dłużnik nie wykonuje poleceń 
tymczasowego nadzorcy sądowego. 
2. Ustanawiając zabezpieczenie przez zarząd przymusowy, sąd wyznacza 
zarządcę przymusowego oraz określa zakres i sposób wykonywania zarządu. 

©Kancelaria Sejmu 
 
 
 
s. 20/224 
 
2025-09-11 
 
3. Do czynności dłużnika dotyczących jego majątku objętego zarządem 
przymusowym stosuje się odpowiednio przepisy art. 77–79. 
4. Do zarządcy przymusowego przepisy art. 38 ust. 1a–3 oraz przepisy ustawy 
o syndyku stosuje się odpowiednio.

***
## Art. 41. {#art-41}

(uchylony)

***
## Art. 42. {#art-42}

(uchylony)

***
## Art. 43. {#art-43}

Zabezpieczenia zastosowane przez sąd upadają z dniem ogłoszenia 
upadłości albo uprawomocnienia się postanowienia o odrzuceniu lub oddaleniu 
wniosku o ogłoszenie upadłości albo umorzeniu postępowania w przedmiocie roz-
poznania tego wniosku. O upadku zabezpieczenia w postaci ustanowienia 
tymczasowego nadzorcy sądowego albo zarządu przymusowego obwieszcza się. 
DZIAŁ V 
(uchylony) 
DZIAŁ VI 
Orzeczenie o ogłoszeniu upadłości

***
## Art. 51. {#art-51}

1. Uwzględniając wniosek o ogłoszenie upadłości, sąd wydaje 
postanowienie o ogłoszeniu upadłości, w którym: 
- 1) wymienia imię i nazwisko dłużnika (upadłego) albo jego nazwę oraz numer 
PESEL albo numer w Krajowym Rejestrze Sądowym, a w przypadku ich braku 
– inne dane umożliwiające jego jednoznaczną identyfikację, NIP, jeżeli dłużnik 
(upadły) ma taki numer, firmę, pod którą działa dłużnik (upadły), miejsce 
zamieszkania albo siedzibę, adres, a gdy dłużnikiem (upadłym) jest spółka 
osobowa, osoba prawna albo inna jednostka organizacyjna nieposiadająca 
osobowości prawnej, której odrębna ustawa przyznaje zdolność prawną – imiona 
i nazwiska reprezentantów, w tym likwidatorów, jeżeli są ustanowieni, a ponadto 
w przypadku spółki osobowej – imiona i nazwiska albo nazwę, numery PESEL 
albo numery w Krajowym Rejestrze Sądowym, a w przypadku ich braku – inne 
dane umożliwiające jednoznaczną identyfikację oraz miejsce zamieszkania albo 
siedzibę wspólników odpowiadających za zobowiązania spółki bez ograniczenia 
całym swoim majątkiem; 
- 2) (uchylony) 
- 3) (uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 21/224 
 
2025-09-11 
- 4) wzywa wierzycieli upadłego do zgłoszenia wierzytelności syndykowi za 
pośrednictwem systemu teleinformatycznego obsługującego postępowanie 
sądowe, w terminie trzydziestu dni od dnia obwieszczenia postanowienia 
o ogłoszeniu upadłości w Rejestrze; dla wierzycieli, o których mowa 
w art. 216aa ust. 1, wskazuje adres do zgłoszenia wierzytelności syndykowi; 
- 5) wzywa osoby, którym przysługują prawa oraz prawa osobiste i roszczenia 
ciążące na nieruchomości należącej do upadłego, jeżeli nie zostały ujawnione 
przez wpis w księdze wieczystej, do ich zgłoszenia syndykowi za pośrednictwem 
systemu teleinformatycznego obsługującego postępowanie sądowe, w terminie 
trzydziestu dni od dnia obwieszczenia postanowienia o ogłoszeniu upadłości 
w Rejestrze pod rygorem utraty prawa powoływania się na nie w postępowaniu 
upadłościowym; dla wierzycieli, o których mowa w art. 216aa ust. 1, wskazuje 
adres do zgłoszenia praw oraz praw osobistych i roszczeń ciążących na 
nieruchomości syndykowi; 
- 6) określa, czy funkcję sędziego-komisarza oraz zastępcy sędziego-komisarza 
będzie pełnił sędzia czy referendarz sądowy, oraz wyznacza syndyka; 
- 7) oznacza godzinę wydania postanowienia, jeżeli upadły jest uczestnikiem 
podlegającego prawu polskiemu lub prawu innego państwa członkowskiego 
systemu płatności lub systemu rozrachunku papierów wartościowych 
w rozumieniu ustawy, o której mowa w art. 22 ust. 1 pkt 4, lub niebędącym 
uczestnikiem podmiotem prowadzącym system interoperacyjny w rozumieniu 
tej ustawy. 
2. Postanowienie o ogłoszeniu upadłości jest skuteczne i wykonalne z dniem 
jego wydania, chyba że przepis szczególny stanowi inaczej. 
2a. W postanowieniu o ogłoszeniu upadłości wskazuje się podstawę jurysdykcji 
sądów polskich. Jeżeli zastosowanie ma rozporządzenie 2015/848, w postanowieniu 
określa się również, czy postępowanie ma charakter główny czy uboczny. 
3. Przez inne dane umożliwiające jednoznaczną identyfikację, o których mowa 
w ust. 1 pkt 1, rozumie się dane, o których mowa w art. 22 ust. 4.

***
## Art. 52. {#art-52}

Data wydania postanowienia o ogłoszeniu upadłości jest datą upadłości. 
W przypadku wydania postanowienia o ogłoszeniu upadłości po ponownym 
rozpoznaniu sprawy w następstwie uchylenia postanowienia przez sąd drugiej 
instancji za datę upadłości uważa się datę wydania pierwszego postanowienia 
o ogłoszeniu upadłości. 

©Kancelaria Sejmu 
 
 
 
s. 22/224 
 
2025-09-11

***
## Art. 53. {#art-53}

1. Postanowienie o ogłoszeniu upadłości obwieszcza się. 
2. Postanowienie w przedmiocie ogłoszenia upadłości doręcza się syndykowi po 
uprzednim powiadomieniu go o ogłoszeniu upadłości, upadłemu albo jego 
spadkobiercy oraz wierzycielowi, który żądał ogłoszenia upadłości. Postanowienie 
w przedmiocie 
ogłoszenia 
upadłości 
przedsiębiorstwa 
państwowego 
albo 
jednoosobowej spółki Skarbu Państwa doręcza się także odpowiednio organowi 
założycielskiemu albo pełnomocnikowi Rządu, państwowej osobie prawnej, organowi 
lub innej jednostce uprawnionej do wykonywania praw z akcji lub udziałów 
należących do Skarbu Państwa. Powiadomienie syndyka następuje w dniu ogłoszenia 
upadłości i dokonuje się go przy zastosowaniu środków bezpośredniego 
porozumiewania się na odległość, w szczególności przez telefon, faks lub pocztę 
elektroniczną. 
3. Jeżeli upadły jest uczestnikiem podlegającego prawu polskiemu lub prawu 
innego państwa członkowskiego systemu płatności lub systemu rozrachunku papierów 
wartościowych w rozumieniu ustawy, o której mowa w art. 22 ust. 1 pkt 4, lub 
niebędącym uczestnikiem podmiotem prowadzącym system interoperacyjny 
w rozumieniu tej ustawy, postanowienie o ogłoszeniu upadłości doręcza się także 
Prezesowi Narodowego Banku Polskiego, po uprzednim powiadomieniu go 
o godzinie wydania postanowienia o ogłoszeniu upadłości. 
4. Jeżeli upadły jest spółką publiczną w rozumieniu przepisów ustawy z dnia 
29 lipca 2005 r. o ofercie publicznej i warunkach wprowadzania instrumentów 
finansowych do zorganizowanego systemu obrotu oraz o spółkach publicznych, 
postanowienie o ogłoszeniu upadłości doręcza się także Przewodniczącemu Komisji 
Nadzoru Finansowego. 
5. O ogłoszeniu upadłości powiadamia się właściwą izbę administracji 
skarbowej i właściwy oddział Zakładu Ubezpieczeń Społecznych, a także znane 
sądowi organy egzekucyjne prowadzące postępowania egzekucyjne przeciwko upad-
łemu. Powiadomienie organów egzekucyjnych następuje w dniu ogłoszenia upadłości 
i dokonuje się go przy zastosowaniu środków bezpośredniego porozumiewania się na 
odległość, w szczególności przez telefon, faks lub pocztę elektroniczną. 
6. Jeżeli upadły jest operatorem publicznej sieci telekomunikacyjnej lub 
dostawcą publicznie dostępnych usług telekomunikacyjnych w rozumieniu przepisów 
ustawy z dnia 12 lipca 2024 r. – Prawo komunikacji elektronicznej (Dz. U. poz. 1221), 
o ogłoszeniu upadłości powiadamia się Prezesa Urzędu Komunikacji Elektronicznej. 

©Kancelaria Sejmu 
 
 
 
s. 23/224 
 
2025-09-11 
 
Powiadomienie następuje w dniu ogłoszenia upadłości i dokonuje się go przy 
zastosowaniu środków bezpośredniego przekazu informacji, takich jak telefon, faks, 
poczta elektroniczna.

***
## Art. 54. {#art-54}

1. (uchylony) 
2. Sąd drugiej instancji nie może orzec o ogłoszeniu upadłości. 
3. W przypadku uchylenia postanowienia o ogłoszeniu upadłości i przekazaniu 
sprawy do ponownego rozpoznania syndyk oraz sędzia-komisarz zachowują swoje 
uprawnienia, a czynności przez nich dokonane pozostają w mocy. 
4. Jeżeli po uchyleniu postanowienia o ogłoszeniu upadłości i przekazaniu 
sprawy do ponownego rozpoznania zostanie wydane postanowienie o zatwierdzeniu 
układu 
albo 
postanowienie 
o otwarciu 
postępowania 
restrukturyzacyjnego, 
postępowanie w przedmiocie ogłoszenia upadłości umarza się. 
Art. 54a. 1. Wierzycielowi w terminie tygodnia od dnia obwieszczenia 
postanowienia o ogłoszeniu upadłości w Rejestrze, a wierzycielowi, którego siedziba 
lub miejsce zwykłego pobytu w dniu otwarcia postępowania znajdowały się za 
granicą, w terminie trzydziestu dni od dnia obwieszczenia postanowienia o ogłoszeniu 
upadłości w Rejestrze przysługuje zażalenie na postanowienie o ogłoszeniu upadłości 
wyłącznie w części dotyczącej jurysdykcji sądów polskich. 
2. O wniesieniu zażalenia obwieszcza się w Rejestrze. 
Art. 54b. Informację o prawomocności postanowienia o ogłoszeniu upadłości 
obwieszcza się.

***
## Art. 55. {#art-55}

(uchylony)

***
## Art. 56. {#art-56}

(uchylony) 
DZIAŁ VII 
Przygotowana likwidacja 
Art. 56a. 1. W postępowaniu o ogłoszenie upadłości uczestnik postępowania 
może złożyć wniosek o zatwierdzenie warunków sprzedaży przedsiębiorstwa dłużnika 
lub jego zorganizowanej części lub składników majątkowych stanowiących znaczną 
część przedsiębiorstwa na rzecz nabywcy. 
2. Niedopuszczalne jest złożenie wniosku o zatwierdzenie warunków sprzedaży 
w odniesieniu do składników majątkowych objętych zastawem rejestrowym, jeżeli 
umowa o ustanowienie zastawu rejestrowego przewiduje przejęcie przedmiotu 

©Kancelaria Sejmu 
 
 
 
s. 24/224 
 
2025-09-11 
 
zastawu albo jego sprzedaż na podstawie art. 24 ustawy z dnia 6 grudnia 1996 r. 
o zastawie rejestrowym i rejestrze zastawów (Dz. U. z 2018 r. poz. 2017), chyba że do 
wniosku zostanie dołączona pisemna zgoda zastawnika. Przepis art. 330 stosuje się 
odpowiednio. 
2a. Do wniosku o zatwierdzenie warunków sprzedaży wnioskodawca załącza 
dowód wniesienia przez nabywcę wadium w wysokości jednej dziesiątej oferowanej 
ceny. W razie niezałączenia do wniosku o zatwierdzenie warunków sprzedaży dowodu 
wniesienia wadium wniosek ten pozostawia się bez rozpoznania. 
2aa. Wadium może być wnoszone w jednej formie lub kilku następujących 
formach: 
- 1) pieniądzu; 
- 2) poręczeniach bankowych lub spółdzielczej kasy oszczędnościowo-kredytowej, 
z tym że poręczenie kasy jest zawsze poręczeniem pieniężnym; 
- 3) gwarancjach bankowych; 
- 4) gwarancjach ubezpieczeniowych. 
2ab. Wadium wnoszone w pieniądzu wpłaca się przelewem na rachunek 
depozytowy sądu właściwego do rozpoznania wniosku. 
2b. Do wniosku o zatwierdzenie warunków sprzedaży wnioskodawca załącza 
listę znanych mu zabezpieczeń dokonanych przez wierzycieli na majątku, którego 
dotyczy ten wniosek, z podaniem adresów tych wierzycieli. Sąd przesyła uzyskany 
z systemu teleinformatycznego obsługującego postępowanie sądowe odpis tego 
wniosku wraz z załącznikami wierzycielom zabezpieczonym na majątku, którego 
dotyczy ten wniosek. 
3. Do wniosku o zatwierdzenie warunków sprzedaży dołącza się opis 
i oszacowanie składnika objętego wnioskiem sporządzone przez osobę wpisaną na 
listę biegłych sądowych. 
4. Wniosek o zatwierdzenie warunków sprzedaży musi zawierać warunki 
sprzedaży przez wskazanie co najmniej ceny oraz nabywcy. Warunki sprzedaży mogą 
być określone w złożonym projekcie umowy, która ma być zawarta przez syndyka. 
We wniosku albo złożonym projekcie umowy należy wskazać adres oraz adres poczty 
elektronicznej nabywcy. 
5. Wniosek o zatwierdzenie warunków sprzedaży może przewidywać wydanie 
przedsiębiorstwa nabywcy z dniem ogłoszenia upadłości dłużnika. W takim 

©Kancelaria Sejmu 
 
 
 
s. 25/224 
 
2025-09-11 
 
przypadku do wniosku dołącza się dowód wpłaty pełnej ceny na rachunek depozytowy 
sądu. 
6. Wniosek o zatwierdzenie warunków sprzedaży może dotyczyć więcej niż 
jednego nabywcy. 
Art. 56aa. 1. W przypadku złożenia wniosku o zatwierdzenie warunków 
sprzedaży sąd ustanawia tymczasowego nadzorcę sądowego albo zarządcę 
przymusowego. 
2. Tymczasowy nadzorca sądowy albo zarządca przymusowy składa, 
w wyznaczonym terminie, sprawozdanie obejmujące w szczególności informacje na 
temat stanu finansowego dłużnika, rodzaju i wartości jego majątku oraz 
przewidywanych kosztów postępowania upadłościowego oraz innych zobowiązań 
masy upadłości, które należałoby ponieść przy likwidacji na zasadach ogólnych, 
a także inne informacje istotne dla rozpoznania wniosku o zatwierdzenie warunków 
sprzedaży. 
Art. 56ab. O złożeniu 
wniosku 
o zatwierdzenie 
warunków 
sprzedaży 
obwieszcza się. 
Art. 56b. 1. Sprzedaż, o której mowa w niniejszym dziale, na rzecz podmiotów 
wskazanych w art. 128 dopuszczalna jest wyłącznie po cenie sprzedaży nie niższej niż 
cena oszacowania. Cenę oszacowania ustala sąd na podstawie dowodu z opinii 
biegłego. 
2. Wnioskodawca i potencjalny nabywca składają oświadczenie, czy między 
nimi a dłużnikiem nie zachodzą stosunki, o których mowa w art. 128. 
Art. 56c. 1. Sąd uwzględnia wniosek o zatwierdzenie warunków sprzedaży, 
jeżeli cena jest wyższa niż kwota możliwa do uzyskania w postępowaniu 
upadłościowym przy likwidacji na zasadach ogólnych, pomniejszona o koszty 
postępowania oraz inne zobowiązania masy upadłości, które należałoby ponieść przy 
likwidacji w takim trybie. 
2. Sąd może uwzględnić wniosek o zatwierdzenie warunków sprzedaży, jeżeli 
cena jest zbliżona do kwoty możliwej do uzyskania w postępowaniu upadłościowym 
przy likwidacji na zasadach ogólnych, pomniejszonej o koszty postępowania oraz inne 
zobowiązania masy upadłości, które należałoby ponieść przy likwidacji w takim 
trybie, jeżeli przemawia za tym ważny interes publiczny lub możliwość zachowania 
przedsiębiorstwa dłużnika. 

©Kancelaria Sejmu 
 
 
 
s. 26/224 
 
2025-09-11 
 
3. Sąd rozpoznaje wniosek o zatwierdzenie warunków sprzedaży nie wcześniej 
niż trzydzieści dni od dnia obwieszczenia o złożeniu tego wniosku oraz nie wcześniej 
niż czternaście dni od dnia doręczenia wierzycielom zabezpieczonym na majątku, 
którego dotyczy ten wniosek, odpisów tego wniosku wraz z załącznikami oraz 
zobowiązaniem do zajęcia stanowiska w wyznaczonym terminie. 
Art. 56ca. 1. 
W przypadku 
złożenia 
co 
najmniej 
dwóch 
wniosków 
o zatwierdzenie warunków sprzedaży przeprowadza się aukcję pomiędzy nabywcami 
w celu wyboru najkorzystniejszych warunków sprzedaży. Do aukcji stosuje się 
odpowiednio przepisy Kodeksu cywilnego, z tym że: 
- 1) warunki aukcji zatwierdza sąd w składzie jednoosobowym; 
- 2) o aukcji należy zawiadomić nabywców oraz wnioskodawców co najmniej dwa 
tygodnie 
przed 
terminem 
posiedzenia 
wyznaczonego 
w celu 
jej 
przeprowadzenia; 
- 3) aukcję przeprowadza się na posiedzeniu jawnym; 
- 4) aukcję prowadzi tymczasowy nadzorca sądowy albo zarządca przymusowy pod 
nadzorem sądu w składzie jednoosobowym; 
- 5) wyboru najkorzystniejszej oferty dokonuje tymczasowy nadzorca sądowy albo 
zarządca przymusowy, który przedstawia wybraną ofertę w sprawozdaniu, 
o którym mowa w art. 56aa ust. 2. 
2. W przypadku złożenia kolejnego wniosku o zatwierdzenie warunków 
sprzedaży przepisu art. 56ab nie stosuje się. 
3. Kolejny wniosek o zatwierdzenie warunków sprzedaży złożony po dokonaniu 
wyboru oferenta pozostawia się bez rozpoznania, o ile jego przedmiotem jest sprzedaż 
składników majątku dłużnika objętych przeprowadzoną aukcją. 
Art. 56d. 1. Uwzględniając wniosek, sąd w postanowieniu o ogłoszeniu 
upadłości zatwierdza warunki sprzedaży, określając co najmniej cenę oraz nabywcę 
mienia będącego przedmiotem sprzedaży, o której mowa w niniejszym dziale. 
W postanowieniu sąd może także odwołać się do warunków sprzedaży określonych 
w projekcie umowy. 
2. Na postanowienie oddalające wniosek o zatwierdzenie warunków sprzedaży 
zażalenie przysługuje dłużnikowi oraz wnioskodawcy składającemu wniosek 
o zatwierdzenie warunków sprzedaży, a na postanowienie uwzględniające ten 

©Kancelaria Sejmu 
 
 
 
s. 27/224 
 
2025-09-11 
 
wniosek – dłużnikowi oraz każdemu z wierzycieli. Zażalenie można wnieść 
w terminie dwóch tygodni od dnia obwieszczenia w Rejestrze. 
3. Wadium wniesione przez nabywcę wskazanego we wniosku o zatwierdzenie 
warunków sprzedaży, który nie został uwzględniony, zwraca się w terminie dwóch 
tygodni od dnia uprawomocnienia się postanowienia o ogłoszeniu upadłości 
i zatwierdzeniu warunków sprzedaży, chyba że nabywca wcześniej złożył wniosek 
o zwrot wadium. Zwrot wadium na wniosek nabywcy skutkuje pozostawieniem bez 
rozpoznania wniosku o zatwierdzenie warunków sprzedaży na rzecz tego nabywcy. 
Wadium wniesione w pieniądzu podlega zwrotowi na rachunek bankowy wskazany 
przez nabywcę. Wadium wniesione w pieniądzu przez nabywcę wskazanego 
w uwzględnionym wniosku o zatwierdzenie warunków sprzedaży zalicza się na 
poczet ceny i niezwłocznie przekazuje z rachunku depozytowego sądu do masy 
upadłości. 
3a. Wadium wniesione w innej formie niż pieniądz zwraca się poprzez złożenie 
gwarantowi lub poręczycielowi oświadczenia o zwolnieniu wadium. 
4. Wadium 
wniesione 
przez 
nabywcę 
zwraca 
się 
również 
z dniem 
uprawomocnienia się postanowienia o ogłoszeniu upadłości i oddaleniu wniosku 
o zatwierdzenie warunków sprzedaży, uprawomocnienia się zarządzenia o zwrocie 
tego wniosku albo postanowienia o jego odrzuceniu albo umorzeniu postępowania w 
przedmiocie rozpoznania wniosku o zatwierdzenie warunków sprzedaży. 
Art. 56e. 1. Syndyk zawiera umowę sprzedaży na warunkach określonych 
w postanowieniu sądu o zatwierdzeniu warunków sprzedaży nie później niż 
w terminie trzydziestu dni od dnia stwierdzenia prawomocności tego postanowienia, 
chyba że zaakceptowane przez sąd warunki umowy przewidywały inny termin. O 
stwierdzeniu prawomocności postanowienia sądu o zatwierdzeniu warunków 
sprzedaży zawiadamia się syndyka oraz nabywcę. 
2. Zawarcie umowy sprzedaży może nastąpić wyłącznie po wpłaceniu przez 
nabywcę całej ceny do masy upadłości lub po wydaniu syndykowi ceny złożonej 
wcześniej do depozytu. 
2a. Jeżeli do zawarcia umowy sprzedaży nie dojdzie z przyczyn leżących po 
stronie nabywcy, syndyk zatrzymuje wadium wniesione w pieniądzu. Jeżeli wadium 
było wniesione w innej formie niż pieniądz, syndyk dochodzi zaspokojenia 
z przedmiotu zabezpieczenia. Wadium stanowi składnik masy upadłości. 

©Kancelaria Sejmu 
 
 
 
s. 28/224 
 
2025-09-11 
 
3. Do skutków sprzedaży według przepisów niniejszego rozdziału przepisy 
art. 313, art. 314 i art. 317 stosuje się. 
Art. 56f. 1. Jeżeli do wniosku o zatwierdzenie warunków sprzedaży był 
dołączony dowód wpłaty pełnej ceny na rachunek depozytowy sądu, wydanie 
przedmiotu sprzedaży nabywcy następuje niezwłocznie po wydaniu postanowienia 
o ogłoszeniu upadłości. 
1a. Przepis ust. 1 stosuje się odpowiednio w przypadku wpłaty pełnej ceny na 
rachunek depozytowy sądu w toku postępowania w przedmiocie ogłoszenia upadłości 
albo po wydaniu postanowienia o ogłoszeniu upadłości. 
2. Wydanie przedmiotu sprzedaży nabywcy następuje do rąk nabywcy, przy 
udziale syndyka. Przepis art. 174 stosuje się odpowiednio. 
3. Do czasu uprawomocnienia się postanowienia zatwierdzającego warunki 
sprzedaży i zawarcia umowy sprzedaży nabywca zarządza nabytym majątkiem 
w granicach zwykłego zarządu na własne ryzyko i odpowiedzialność. 
4. Uchylając postanowienie o zatwierdzeniu warunków sprzedaży, sąd 
zobowiązuje nabywcę do zwrotu przedmiotu sprzedaży do rąk syndyka lub dłużnika. 
Postanowienie jest tytułem egzekucyjnym przeciwko nabywcy. 
Art. 56g. 1. Po uprawomocnieniu się postanowienia zatwierdzającego warunki 
sprzedaży sąd z urzędu lub na wniosek syndyka postanowi o wydaniu syndykowi ceny 
złożonej do depozytu. 
2. W innych przypadkach niż określony w ust. 1 o wydaniu ceny z depozytu 
orzeka na wniosek nabywcy sąd w terminie trzydziestu dni od dnia wydania 
przedsiębiorstwa syndykowi lub dłużnikowi. Syndyk lub dłużnik może złożyć 
wniosek o zatrzymanie ceny w depozycie na kolejne dwa tygodnie potrzebne do 
złożenia wniosku o zabezpieczenie powództwa o odszkodowanie według przepisów 
ogólnych. Po upływie tego terminu sąd niezwłocznie postanowi o wydaniu ceny 
z depozytu, chyba że został złożony wniosek o zabezpieczenie. 
3. W przedmiocie postanowienia o wydaniu ceny z depozytu w sytuacjach 
wskazanych w ust. 1 i 2 orzeka sąd w składzie jednoosobowym. 
Art. 56h. W terminie przewidzianym na zawarcie umowy sprzedaży syndyk lub 
nabywca może złożyć wniosek do sądu o uchylenie lub zmianę postanowienia 
o zatwierdzeniu warunków sprzedaży, jeżeli po wydaniu tego postanowienia zmieniły 
się lub zostały ujawnione okoliczności mające istotny wpływ na wartość składnika 

©Kancelaria Sejmu 
 
 
 
s. 29/224 
 
2025-09-11 
 
majątku będącego przedmiotem sprzedaży. Na postanowienie uwzględniające ten 
wniosek zażalenie przysługuje również syndykowi oraz nabywcy. Przepisy art. 56a–
56g stosuje się odpowiednio. 
TYTUŁ III 
Skutki ogłoszenia upadłości 
DZIAŁ I 
Skutki ogłoszenia upadłości co do osoby upadłego

***
## Art. 57. {#art-57}

1. Upadły jest obowiązany wskazać i wydać syndykowi cały swój 
majątek, a także wydać dokumenty dotyczące jego działalności, majątku oraz 
rozliczeń, w szczególności księgi rachunkowe, inne ewidencje prowadzone dla celów 
podatkowych i korespondencję. Wykonanie tego obowiązku upadły potwierdza 
w formie oświadczenia na piśmie, które składa sędziemu-komisarzowi. 
2. Upadły jest obowiązany udzielać sędziemu-komisarzowi i syndykowi 
wszelkich potrzebnych wyjaśnień dotyczących swojego majątku. 
3. Sędzia-komisarz może postanowić, aby upadły będący osobą fizyczną nie 
opuszczał terytorium Rzeczypospolitej Polskiej bez jego zezwolenia. 
4. Przepis ust. 3 stosuje się odpowiednio do członków organu zarządzającego 
upadłego niebędącego osobą fizyczną. 
5. Na postanowienie sędziego-komisarza, o którym mowa w ust. 3 i 4, 
przysługuje zażalenie.

***
## Art. 58. {#art-58}

1. Jeżeli upadły ukrywa się lub ukrywa swój majątek, sędzia-komisarz 
może zastosować wobec niego środki przymusu określone w Kodeksie postępowania 
cywilnego dla egzekucji świadczeń niepieniężnych. 
2. Sędzia-komisarz może zastosować środki przymusu wobec upadłego, który 
uchybia swoim obowiązkom albo po ogłoszeniu upadłości dopuszcza się czynów 
mających na celu ukrycie majątku, obciążenie go pozornymi zobowiązaniami lub 
w jakikolwiek sposób utrudnia ustalenie składu masy upadłości. 
3. Sędzia-komisarz uchyli środki przymusu, gdy ustanie potrzeba ich stosowania. 
4. Na postanowienie w sprawie środków przymusu przysługuje zażalenie.

***
## Art. 59. {#art-59}

(uchylony)

***
## Art. 60. {#art-60}

(uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 30/224 
 
2025-09-11

***
## Art. 601. {#art-601}

Po ogłoszeniu upadłości przedsiębiorca występuje w obrocie pod 
dotychczasową firmą z dodaniem oznaczenia „w upadłości”. 
DZIAŁ II 
Skutki ogłoszenia upadłości co do majątku upadłego 
## Rozdział 1. Masa upadłości 
Oddział 1 
Przepisy ogólne

***
## Art. 61. {#art-61}

Z dniem ogłoszenia upadłości majątek upadłego staje się masą 
upadłości, która służy zaspokojeniu wierzycieli upadłego.

***
## Art. 62. {#art-62}

W skład masy upadłości wchodzi majątek należący do upadłego w dniu 
ogłoszenia 
upadłości 
oraz 
nabyty 
przez 
upadłego 
w toku 
postępowania 
upadłościowego, z wyjątkami określonymi w art. 63–67a.

***
## Art. 63. {#art-63}

1. Nie wchodzi do masy upadłości: 
- 1) mienie, które jest wyłączone od egzekucji według przepisów ustawy z dnia 
17 listopada 1964 r. – Kodeks postępowania cywilnego (Dz. U. z 2024 r. poz. 
1568 i 1841); 
- 2) wynagrodzenie za pracę upadłego w części niepodlegającej zajęciu; 
- 3) kwota uzyskana z tytułu realizacji zastawu rejestrowego lub hipoteki, jeżeli 
upadły pełnił funkcję administratora zastawu lub hipoteki, w części 
przypadającej zgodnie z umową powołującą administratora pozostałym 
wierzycielom; 
- 4) środki pieniężne znajdujące się na rachunku będącym przedmiotem blokady 
rachunku podmiotu kwalifikowanego w rozumieniu art. 119zg pkt 2 ustawy 
z dnia 29 sierpnia 1997 r. – Ordynacja podatkowa (Dz. U. z 2025 r. poz. 111). 
1a. W przypadku ogłoszenia upadłości osoby fizycznej, na której utrzymaniu nie 
pozostają inne osoby, do masy upadłości nie wchodzi także część dochodu upadłego, 
która łącznie z dochodami wyłączonymi z masy upadłości na podstawie 
ust. 1 odpowiada kwocie stanowiącej 150 % kwoty określonej w art. 8 ust. 1 pkt 1 
ustawy z dnia 12 marca 2004 r. o pomocy społecznej (Dz. U. z 2024 r. poz. 1283 i 
1572). 

©Kancelaria Sejmu 
 
 
 
s. 31/224 
 
2025-09-11 
 
1b. W przypadku ogłoszenia upadłości osoby fizycznej, na której utrzymaniu 
pozostają inne osoby, do masy upadłości nie wchodzi także część dochodu upadłego, 
która łącznie z dochodami wyłączonymi z masy upadłości na podstawie ust. 1 
odpowiada iloczynowi liczby osób pozostających na utrzymaniu upadłego oraz 
upadłego i 150 % kwoty określonej w art. 8 ust. 1 pkt 2 ustawy z dnia 12 marca 
2004 r. o pomocy społecznej. 
1c. Sędzia-komisarz na wniosek upadłego lub syndyka może w inny sposób 
określić część dochodu upadłego, która nie wchodzi do masy upadłości zgodnie 
z ust. 1a lub 1b, biorąc pod uwagę szczególne potrzeby upadłego i osób pozostających 
na jego utrzymaniu, w tym ich stan zdrowia, potrzeby mieszkaniowe oraz możliwości 
ich zaspokojenia. Na postanowienie sędziego-komisarza przysługuje zażalenie 
upadłemu i wierzycielom. 
1d. Część dochodu upadłego, która nie wchodzi do masy upadłości zgodnie 
z ust. 1a–1c, nie podlega egzekucji. 
2. Uchwała zgromadzenia wierzycieli może wyłączyć z masy upadłości inne 
składniki mienia upadłego. 
Art. 63a. Wątpliwości co do tego, które z przedmiotów należących do upadłego 
wchodzą w skład masy upadłości, rozstrzyga sędzia-komisarz na wniosek syndyka, 
upadłego lub wierzyciela. Na postanowienie sędziego-komisarza zażalenie 
przysługuje wnioskodawcy, upadłemu i wierzycielom.

***
## Art. 64. {#art-64}

1. Mienie przeznaczone na pomoc dla pracowników upadłego i ich 
rodzin, stanowiące zgromadzone na odrębnym rachunku bankowym środki pieniężne 
zakładowego funduszu świadczeń socjalnych, tworzonego na podstawie przepisów 
o zakładowym funduszu świadczeń socjalnych, wraz z przypadającymi po ogłoszeniu 
upadłości kwotami pochodzącymi ze zwrotu udzielonych pożyczek na cele 
mieszkaniowe, wpłatami odsetek bankowych od środków tego funduszu oraz opłatami 
pobieranymi od korzystających z usług i świadczeń socjalnych finansowanych z tego 
funduszu organizowanych przez upadłego, nie wchodzi w skład masy upadłości. 
Składniki tego mienia oznaczy sędzia-komisarz. 
2. Mieniem, 
o którym 
mowa 
w ust. 1, 
zarządza 
syndyk, 
wydatkując 
zgromadzone na odrębnym rachunku bankowym funduszu środki na cele i według 
zasad, które zostały określone w przepisach o zakładowym funduszu świadczeń 
socjalnych. 

©Kancelaria Sejmu 
 
 
 
s. 32/224 
 
2025-09-11 
 
3. Niewykorzystane środki, o których mowa w ust. 1, zwiększają Fundusz 
Gwarantowanych Świadczeń Pracowniczych.

***
## Art. 65. {#art-65}

(uchylony) 
Art. 65a. 1. W skład masy upadłości upadłego będącego stroną umowy 
o subpartycypację, o której mowa w art. 183 ust. 4 ustawy z dnia 27 maja 2004 r. 
o funduszach 
inwestycyjnych 
i zarządzaniu 
alternatywnymi 
funduszami 
inwestycyjnymi (Dz. U. z 2024 r. poz. 1034 i 1863 oraz z 2025 r. poz. 146), nie 
wchodzą wierzytelności będące przedmiotem tej umowy. 
2. Fundusz wierzytelności wstępuje w prawa upadłego z tytułu wierzytelności 
podlegających wyłączeniu zgodnie z ust. 1 oraz zabezpieczeń tych wierzytelności. 
3. Syndyk przekazuje funduszowi wierzytelności świadczenia otrzymane od 
dłużników z tytułu wierzytelności, o których mowa w ust. 1, oraz dłużników z tytułu 
zabezpieczeń tych wierzytelności.

***
## Art. 66. {#art-66}

1. W skład masy upadłości uczestnika systemu płatności lub systemu 
rozrachunku papierów wartościowych, o którym mowa w art. 22 ust. 1 pkt 4, nie 
wchodzi mienie upadłego wymienione w art. 80, a także inne aktywa niezbędne do 
wykonania obowiązków wynikających z uczestnictwa w systemie, które powstały 
przed ogłoszeniem upadłości, z zastrzeżeniem ust. 3. 
2. W celu wykonania obowiązków określonych w ust. 1 podmiot prowadzący 
system jest upoważniony do dysponowania tym mieniem. 
3. Mienie, o którym mowa w ust. 1, pozostałe po wykonaniu obowiązków 
wynikających z uczestnictwa w systemie, wchodzi do masy upadłości.

***
## Art. 67. {#art-67}

1. Z zastrzeżeniem przepisów art. 12 ustawy, o której mowa 
w art. 22 ust. 1 pkt 4, 
przedmiot 
zabezpieczenia 
ustanowionego 
w związku 
z uczestnictwem w systemie płatności lub systemie rozrachunku papierów 
wartościowych w rozumieniu ustawy, o której mowa w art. 22 ust. 1 pkt 4, na rzecz 
podmiotu prowadzącego ten system lub na rzecz uczestnika tego systemu, nie wchodzi 
do masy upadłości: 
- 1) uczestnika tego systemu lub uczestnika współpracującego z nim systemu 
interoperacyjnego, który ustanowił to zabezpieczenie, 
- 2) niebędącego uczestnikiem podmiotu prowadzącego system interoperacyjny 
współpracujący z tym systemem, 
- 3) jakiegokolwiek innego podmiotu, który ustanowił to zabezpieczenie 

©Kancelaria Sejmu 
 
 
 
s. 33/224 
 
2025-09-11 
 
– w razie ogłoszenia upadłości któregokolwiek z nich. 
2. Z zastrzeżeniem 
przepisów 
art. 12 
ustawy, 
o której 
mowa 
w art. 22 ust. 1 pkt 4, przedmiot zabezpieczenia ustanowionego na rzecz Narodowego 
Banku Polskiego, banku centralnego innego państwa członkowskiego w rozumieniu 
ustawy, o której mowa w art. 22 ust. 1 pkt 4, lub Europejskiego Banku Centralnego, 
przez podmiot dokonujący operacji z tymi bankami lub przez jakikolwiek inny 
podmiot, nie wchodzi do masy upadłości w razie ogłoszenia upadłości któregokolwiek 
z nich. 
3. Prawa podmiotu, na rzecz którego zostało ustanowione zabezpieczenie, 
o którym mowa w ust. 1 lub 2, do zaspokojenia się z tego zabezpieczenia nie ogranicza 
ogłoszenie upadłości podmiotu, który ustanowił to zabezpieczenie. 
4. Upadły wykonuje zobowiązania – w związku z którymi zostało ustanowione 
zabezpieczenie, o którym mowa w ust. 1 i 2 – na warunkach obowiązujących w dniu 
poprzedzającym dzień ogłoszenia upadłości. Przepisu art. 102 nie stosuje się. 
Art. 67a. 1. Mienie przeznaczone na pomoc dla uczestników systemu ochrony, 
stanowiące zgromadzone na odrębnym rachunku bankowym środki pieniężne 
funduszu pomocowego tworzonego na podstawie przepisów ustawy z dnia 7 grudnia 
2000 r. o funkcjonowaniu banków spółdzielczych, ich zrzeszaniu się i bankach 
zrzeszających (Dz. U. z 2025 r. poz. 265), wraz z przypadającymi po ogłoszeniu 
upadłości kwotami pochodzącymi ze zwrotu udzielonych pożyczek na cele 
pomocowe, wpłatami odsetek bankowych od środków tego funduszu oraz opłatami 
pobieranymi od korzystających z usług i świadczeń finansowanych z tego funduszu 
organizowanych przez upadłego, nie wchodzi w skład masy upadłości. Składniki tego 
mienia oznaczy sędzia-komisarz. Na postanowienie sędziego-komisarza przysługuje 
zażalenie upadłemu, wierzycielom oraz uczestnikom systemu ochrony. 
2. Mieniem, o którym mowa w ust. 1, zarządza upadły, chyba że został 
ustanowiony likwidator, kurator bądź przedstawiciel albo reprezentant upadłego 
ustanowiony na podstawie postanowień umowy systemu ochrony, wydatkując 
zgromadzone na odrębnym rachunku bankowym funduszu środki na cele i według 
zasad określonych w przepisach ustawy, o której mowa w ust. 1, oraz umowy systemu 
ochrony. 
3. Dotychczasowi uczestnicy systemu ochrony mogą zdecydować o przekazaniu 
mienia, o którym mowa w ust. 1, do jednego z nich albo do nowej jednostki, w celu 

©Kancelaria Sejmu 
 
 
 
s. 34/224 
 
2025-09-11 
 
utworzenia, z wykorzystaniem tego mienia, nowego systemu ochrony lub jego 
wykorzystania w istniejącym systemie ochrony. 
4. W przypadku nieutworzenia nowego systemu ochrony lub nieprzystąpienia do 
istniejącego systemu ochrony, o których mowa w ust. 3, mienie, o którym mowa 
w ust. 1, zostaje przekazane dotychczasowym uczestnikom systemu ochrony, 
stosownie do wielkości dokonanych wpłat. 
Oddział 2 
Ustalanie składu masy upadłości

***
## Art. 68. {#art-68}

(uchylony)

***
## Art. 69. {#art-69}

1. Ustalenie składu masy upadłości na dzień ogłoszenia upadłości 
następuje przez sporządzenie w systemie teleinformatycznym obsługującym 
postępowanie sądowe według wzorca udostępnionego w tym systemie spisu objętych 
przez 
syndyka 
ruchomości, 
nieruchomości, 
środków 
pieniężnych 
oraz 
przysługujących upadłemu praw majątkowych, a także przez sporządzenie spisu 
należności. 
1a. Jeżeli syndyk na podstawie ksiąg upadłego oraz dokumentów bezspornych 
ustali, że w skład masy upadłości wchodzą ruchomości, nieruchomości oraz środki 
pieniężne, których syndyk nie objął, sporządza ich spis, wskazując, których 
składników masy nie objął na skutek czynności bezskutecznych. 
1b. (uchylony) 
1c. Syndyk sporządza spisy, o których mowa w ust. 1 i 1a, na bieżąco, w miarę 
ustalania składu masy upadłości i obejmowania składników majątku wchodzących 
w skład masy upadłości. Podczas sporządzania spisów syndyk usuwa błędnie wpisane 
pozycje. 
1ca. Każdorazowy 
stan 
spisu 
objętych 
przez 
syndyka 
ruchomości, 
nieruchomości, środków pieniężnych oraz przysługujących upadłemu praw 
majątkowych jest ujawniany w Rejestrze. Zawarte w spisie należności informacje 
o przysługujących upadłemu wierzytelnościach podlegają ujawnieniu dopiero 
z chwilą obwieszczenia w Rejestrze uchwały rady wierzycieli albo postanowienia 
sędziego-komisarza o wyrażeniu zgody na sprzedaż wierzytelności. 
1d. Po zakończeniu ustalania składu masy upadłości syndyk składa spis 
inwentarza, który obejmuje raporty ze sporządzonych według stanu na dzień 
ogłoszenia upadłości spisów: 

©Kancelaria Sejmu 
 
 
 
s. 35/224 
 
2025-09-11 
- 1) objętych przez syndyka ruchomości, nieruchomości, środków pieniężnych oraz 
przysługujących upadłemu praw majątkowych; 
- 2) ruchomości, nieruchomości oraz środków pieniężnych, których syndyk nie objął; 
- 3) należności. 
1e. (uchylony) 
1f. Jeżeli syndyk na podstawie ksiąg upadłego oraz dokumentów bezspornych 
ustali, że w skład masy upadłości w dniu ogłoszenia upadłości wchodziły składniki 
majątku, których syndyk nie ujął w spisie inwentarza, sporządza uzupełnienie spisu 
inwentarza, które obejmuje składniki majątku nieujęte w spisie inwentarza. Do 
uzupełnienia spisu inwentarza przepisy ust. 1, 1a, 1c i 1d stosuje się odpowiednio. 
2. Wraz ze spisem inwentarza dokonuje się oszacowania majątku wchodzącego 
do masy upadłości. 
3. Domniemywa się, że rzeczy znajdujące się w posiadaniu upadłego w dniu 
ogłoszenia upadłości należą do majątku upadłego. 
Oddział 3 
Wyłączenia z masy upadłości

***
## Art. 70. {#art-70}

Składniki mienia nienależące do majątku upadłego podlegają 
wyłączeniu z masy upadłości.

***
## Art. 701. {#art-701}

Przepisów o wyłączeniu z masy upadłości nie stosuje się do rzeczy, 
wierzytelności i innych praw majątkowych przeniesionych przez upadłego na 
wierzyciela w celu zabezpieczenia wierzytelności. Do przedmiotów tych oraz do 
zabezpieczonych w ten sposób wierzytelności stosuje się odpowiednio przepisy 
ustawy dotyczące zastawu i wierzytelności zabezpieczonych zastawem.

***
## Art. 71. {#art-71}

1. W razie zbycia przez upadłego mienia, które podlega wyłączeniu, 
świadczenie otrzymane za zbyte mienie wydaje się osobie, do której mienie to 
należało, jeżeli świadczenie jest wyodrębnione w masie upadłości. 
2. W razie zbycia przez syndyka mienia, które podlegało wyłączeniu, osoba, do 
której prawo to należało, może żądać wydania świadczenia wzajemnego uzyskanego 
w zamian za to mienie. 
3. Jeżeli świadczenie, o którym mowa w ust. 1 i 2, nie zostało spełnione przed 
zgłoszeniem żądania wydania, prawo do świadczenia przechodzi na mającego prawo 
do wyłączonego mienia. 

©Kancelaria Sejmu 
 
 
 
s. 36/224 
 
2025-09-11

***
## Art. 72. {#art-72}

Osoba, której przysługuje prawo do mienia podlegającego wyłączeniu, 
może żądać jego wydania lub świadczenia wzajemnego za jednoczesnym zwrotem 
wydatków na utrzymanie tego mienia lub na uzyskanie świadczenia wzajemnego 
poniesionych przez upadłego lub z masy upadłości.

***
## Art. 73. {#art-73}

1. We wniosku o wyłączenie z masy upadłości należy zgłosić wszelkie 
twierdzenia, zarzuty i dowody na ich poparcie pod rygorem utraty prawa powoływania 
ich w toku dalszego postępowania, chyba że powołanie ich we wniosku było 
niemożliwe. 
2. Sędzia-komisarz rozpoznaje wniosek o wyłączenie z masy upadłości 
w terminie jednego miesiąca od dnia jego złożenia po wysłuchaniu syndyka, nadzorcy 
sądowego albo zarządcy. 
3. (uchylony) 
4. (uchylony) 
5. (uchylony) 
6. Postanowienie w przedmiocie wyłączenia z masy upadłości wymaga 
uzasadnienia. Na postanowienie o wyłączeniu z masy upadłości przysługuje zażalenie 
upadłemu i wierzycielom.

***
## Art. 74. {#art-74}

1. W razie oddalenia wniosku o wyłączenie z masy upadłości 
wnioskodawca może w drodze powództwa żądać wyłączenia mienia z masy 
upadłości. 
2. Powództwo wnosi się do sądu upadłościowego w terminie miesiąca od dnia 
doręczenia postanowienia sędziego-komisarza o odmowie wyłączenia z masy 
upadłości. 
3. Powództwo może być oparte wyłącznie na twierdzeniach i zarzutach 
zgłoszonych we wniosku o wyłączenie z masy upadłości. Inne twierdzenia i zarzuty 
mogą być zgłoszone tylko wtedy, gdy powód wykaże, że ich wcześniejsze zgłoszenie 
było niemożliwe. Niezależnie od wyniku sprawy sąd obciąży powoda kosztami 
procesu, jeżeli powołał nowe dowody istotne dla rozstrzygnięcia sprawy, których nie 
zgłosił we wniosku o wyłączenie. 
4. Sąd może zabezpieczyć powództwo przez ustanowienie zakazu zbywania lub 
obciążania mienia objętego żądaniem wyłączenia z masy upadłości. 

©Kancelaria Sejmu 
 
 
 
s. 37/224 
 
2025-09-11 
 
Oddział 4 
Czynności upadłego dotyczące mienia wchodzącego w skład masy upadłości

***
## Art. 75. {#art-75}

1. Z dniem ogłoszenia upadłości upadły traci prawo zarządu oraz 
możliwość korzystania z mienia wchodzącego do masy upadłości i rozporządzania 
nim. 
2. Sędzia-komisarz określa zakres i czas korzystania przez upadłego lub osoby 
mu bliskie, którzy w dacie ogłoszenia upadłości zamieszkiwali w mieszkaniu 
znajdującym się w lokalu lub w budynku wchodzącym do masy upadłości, z tego 
mieszkania. 
3. (uchylony)

***
## Art. 76. {#art-76}

(uchylony)

***
## Art. 77. {#art-77}

1. Czynności prawne upadłego dotyczące mienia wchodzącego do masy 
upadłości są nieważne. 
2. Na wniosek osoby trzeciej sędzia-komisarz może nakazać zwrot na jej rzecz 
z masy upadłości jej świadczenia wzajemnego, które osoba ta świadczyła w związku 
z dokonaniem przez nią z upadłym czynności prawnej, o której mowa w ust. 1. Do 
zwrotu tego świadczenia stosuje się odpowiednio przepisy o nienależnym 
świadczeniu. 
3. Zwrot świadczenia, o którym mowa w ust. 2, można nakazać, jeżeli czynność 
prawna została podjęta po ogłoszeniu upadłości i przed obwieszczeniem w Rejestrze 
postanowienia o ogłoszeniu upadłości, a osoba trzecia przy zachowaniu należytej 
staranności nie mogła wiedzieć o ogłoszeniu upadłości. Na postanowienie 
sędziego-komisarza osobie tej przysługuje zażalenie. 
4. Przepisu ust. 1 nie stosuje się do ustanowienia zabezpieczenia finansowego 
zgodnie z przepisami ustawy z dnia 2 kwietnia 2004 r. o niektórych zabezpieczeniach 
finansowych (Dz. U. z 2024 r. poz. 294), jeżeli zawarcie umowy lub ustanowienie 
zabezpieczenia finansowego nastąpiło w dniu ogłoszenia upadłości, a uprawniony 
z zabezpieczenia wykaże, że nie wiedział i przy zachowaniu należytej staranności nie 
mógł wiedzieć o wszczęciu postępowania upadłościowego. Przepisu ust. 1 nie stosuje 
się również do zabezpieczeń, o których mowa w art. 67.

***
## Art. 78. {#art-78}

Spełnienie świadczenia do rąk upadłego dokonane po obwieszczeniu 
o ogłoszeniu upadłości w Rejestrze nie zwalnia z obowiązku spełnienia świadczenia 

©Kancelaria Sejmu 
 
 
 
s. 38/224 
 
2025-09-11 
 
do masy upadłości, chyba że równowartość świadczenia została przekazana przez 
upadłego do masy upadłości.

***
## Art. 79. {#art-79}

Przepisy art. 77 i 78 stosuje się również do czynności, które podlegają 
ujawnieniu w księdze wieczystej i rejestrach, jeżeli przepisy szczególne nie stanowią 
inaczej.

***
## Art. 80. {#art-80}

1. Ogłoszenie upadłości uczestnika systemu płatności lub systemu 
rozrachunku papierów wartościowych w rozumieniu ustawy z dnia 24 sierpnia 2001 r. 
o ostateczności rozrachunku w systemach płatności i systemach rozrachunków 
papierów wartościowych oraz zasadach nadzoru nad tymi systemami nie wstrzymuje 
możliwości wykorzystania: 
- 1) środków pieniężnych i instrumentów finansowych w rozumieniu ustawy z dnia 
29 lipca 2005 r. o obrocie instrumentami finansowymi (Dz. U. z 2024 r. poz. 722 
i 1863 oraz z 2025 r. poz. 146), zgromadzonych i zapisanych na jego rachunku 
rozliczeniowym, nieobciążonych prawem rzeczowym na rzecz osób trzecich, 
- 2) instrumentów finansowych zapisanych na rachunku rozliczeniowym upadłego, 
jako przedmiot zabezpieczenia kredytu uzyskanego w ramach systemu płatności 
lub systemu rozrachunku papierów wartościowych, jeżeli kredyt taki może być 
udostępniony w ramach istniejącej umowy o kredyt 
– w celu wykonania zobowiązań upadłego wynikających ze zleceń rozrachunku 
wprowadzonych do systemu najpóźniej w dniu roboczym systemu rozpoczynającym 
się w dniu, w którym została ogłoszona upadłość. 
2. Za dzień roboczy systemu uznaje się określony przez zasady funkcjonowania 
systemu płatności lub systemu rozrachunku papierów wartościowych w rozumieniu 
ustawy, o której mowa w art. 22 ust. 1 pkt 4, cykl wykonywania zleceń, w trakcie 
którego dokonywane są rozliczenia lub rozrachunki oraz występują inne operacje 
z tym związane; dzień ten może rozpoczynać się i kończyć w następujących po sobie 
dniach kalendarzowych. 
Oddział 5 
Zakaz obciążania masy upadłości

***
## Art. 81. {#art-81}

1. Po ogłoszeniu upadłości nie można obciążyć składników masy 
upadłości hipoteką, zastawem, zastawem rejestrowym, zastawem skarbowym lub 

©Kancelaria Sejmu 
 
 
 
s. 39/224 
 
2025-09-11 
 
hipoteką morską w celu zabezpieczenia wierzytelności powstałej przed ogłoszeniem 
upadłości. 
1a. Po ogłoszeniu upadłości nie można ustanowić na składnikach masy upadłości 
hipoteki przymusowej ani zastawu skarbowego, także dla zabezpieczenia 
wierzytelności powstałej po ogłoszeniu upadłości. 
2. Przepisu ust. 1 nie stosuje się, jeżeli wniosek o wpis hipoteki został złożony 
w sądzie co najmniej na sześć miesięcy przed dniem złożenia wniosku o ogłoszenie 
upadłości.

***
## Art. 82. {#art-82}

Wpis w księdze wieczystej lub rejestrze dokonany z naruszeniem 
art. 81 podlega wykreśleniu z urzędu. Podstawą wykreślenia jest postanowienie 
sędziego-komisarza stwierdzające niedopuszczalność wpisu. Na postanowienie 
sędziego-komisarza przysługuje zażalenie. 
## Rozdział 2. Skutki ogłoszenia upadłości co do zobowiązań upadłego 
(oznaczenie i tytuł oddziału 1 – uchylone)

***
## Art. 83. {#art-83}

Postanowienia umowy zastrzegające na wypadek złożenia wniosku 
o ogłoszenie upadłości lub ogłoszenia upadłości zmianę lub rozwiązanie stosunku 
prawnego, którego stroną jest upadły, są nieważne.

***
## Art. 84. {#art-84}

1. Postanowienie umowy, której stroną jest upadły, uniemożliwiające 
albo utrudniające osiągnięcie celu postępowania upadłościowego jest bezskuteczne 
w stosunku do masy upadłości. 
2. Umowa przeniesienia własności rzeczy, wierzytelności lub innego prawa 
zawarta w celu zabezpieczenia wierzytelności jest skuteczna wobec masy upadłości, 
jeżeli została zawarta w formie pisemnej z datą pewną. 
3. Umowa ustanawiająca zabezpieczenie finansowe na podstawie ustawy z dnia 
2 kwietnia 2004 r. o niektórych zabezpieczeniach finansowych dla swojej 
skuteczności wobec masy upadłości nie wymaga zachowania formy pisemnej z datą 
pewną.

***
## Art. 85. {#art-85}

1. Jeżeli umowa ramowa, której jedną ze stron jest upadły, zastrzega, że 
poszczególne umowy szczegółowe, których przedmiotem są terminowe operacje 
finansowe, pożyczki instrumentów finansowych lub sprzedaż instrumentów 
finansowych ze zobowiązaniem do ich odkupu, będą zawierane w wykonaniu umowy 

©Kancelaria Sejmu 
 
 
 
s. 40/224 
 
2025-09-11 
 
ramowej oraz że rozwiązanie umowy ramowej powoduje rozwiązanie wszystkich 
umów szczegółowych zawartych w wykonaniu tej umowy: 
- 1) wierzytelności z tytułu poszczególnych umów szczegółowych zawartych w jej 
wykonaniu 
nie 
są 
obejmowane 
układem 
zawartym 
w postępowaniu 
upadłościowym; 
- 2) syndykowi nie przysługuje uprawnienie do odstąpienia od umowy ramowej, 
o którym mowa w art. 98. 
2. Przez terminowe operacje finansowe, o których mowa w ust. 1, rozumie się 
operacje, w których ustalono cenę, kurs, stopę procentową lub indeks – 
a w szczególności nabywanie walut, papierów wartościowych, złota lub innych metali 
szlachetnych, towarów lub praw, w tym umowy obliczone tylko na różnicę cen, opcje 
i prawa pochodne – zawarte na umówioną datę lub umówiony termin, w obrocie 
rynkowym. 
2a. Przez instrumenty finansowe, o których mowa w ust. 1, rozumie się 
instrumenty finansowe w rozumieniu przepisów ustawy z dnia 29 lipca 2005 r. 
o obrocie instrumentami finansowymi. 
3. Każda ze stron może wypowiedzieć umowę, o której mowa w ust. 1, 
z zachowaniem ustalonego w tej umowie sposobu rozliczenia stron na wypadek 
rozwiązania umowy. 
4. Dopuszczalne jest potrącenie wierzytelności wynikającej z rozliczenia stron. 
5. Do poszczególnych umów szczegółowych mających za przedmiot terminowe 
operacje finansowe, pożyczki instrumentów finansowych lub sprzedaż instrumentów 
finansowych ze zobowiązaniem do ich odkupu – nawet jeżeli nie zostały one zawarte 
w wykonaniu umowy ramowej, o której mowa w ust. 1 – nie stosuje się przepisów 
art. 98 i art. 99. 
Art. 85a. Ogłoszenie upadłości dłużnika nie narusza uprawnień wynikających 
z zamieszczonej w umowie klauzuli kompensacyjnej, o której mowa w ustawie z dnia 
2 kwietnia 2004 r. o niektórych zabezpieczeniach finansowych, jeżeli umowa została 
zawarta: 
- 1) przed dniem ogłoszenia upadłości; 
- 2) w dniu ogłoszenia upadłości, ale przed wydaniem postanowienia o ogłoszeniu 
upadłości; 

©Kancelaria Sejmu 
 
 
 
s. 41/224 
 
2025-09-11 
- 3) w dniu ogłoszenia upadłości, ale po wydaniu postanowienia o ogłoszeniu 
upadłości, jeżeli przyjmujący zabezpieczenie może potwierdzić, że nie wiedział 
i nie mógł wiedzieć o ogłoszeniu upadłości.

***
## Art. 86. {#art-86}

1. Po ogłoszeniu upadłości spółdzielni mieszkaniowej czynności 
określone 
w art. 41–43 
ustawy 
z dnia 
15 grudnia 
2000 r. 
o spółdzielniach 
mieszkaniowych (Dz. U. z 2024 r. poz. 558) wykonuje syndyk. 
2. Na syndyku ciąży obowiązek zawarcia umowy, o której mowa w art. 12, 
art. 1714, art. 1715, art. 39 i art. 48 ustawy wskazanej w ust. 1, jeżeli żądanie zostało 
złożone spółdzielni przed ogłoszeniem upadłości albo po ogłoszeniu upadłości 
na podstawie art. 541 ust. 2 tej ustawy. 
(oznaczenie i tytuł oddziału 2 – uchylone)

***
## Art. 87. {#art-87}

(uchylony)

***
## Art. 88. {#art-88}

(uchylony)

***
## Art. 89. {#art-89}

(uchylony)

***
## Art. 90. {#art-90}

(uchylony) 
(oznaczenie i tytuł oddziału 3 – uchylone)

***
## Art. 91. {#art-91}

1. Zobowiązania pieniężne upadłego, których termin płatności 
świadczenia jeszcze nie nastąpił, stają się wymagalne z dniem ogłoszenia upadłości. 
2. Zobowiązania majątkowe niepieniężne zmieniają się z dniem ogłoszenia 
upadłości na zobowiązania pieniężne i z tym dniem stają się płatne, chociażby termin 
ich wykonania jeszcze nie nastąpił.

***
## Art. 92. {#art-92}

1. Z masy upadłości mogą być zaspokojone odsetki od wierzytelności, 
należne od upadłego, za okres do dnia ogłoszenia upadłości. 
2. Przepis ust. 1 nie dotyczy odsetek od wierzytelności zabezpieczonych 
hipoteką, wpisem w rejestrze, zastawem, zastawem rejestrowym, zastawem 
skarbowym albo hipoteką morską. Odsetki te mogą być zaspokojone tylko 
z przedmiotu zabezpieczenia.

***
## Art. 93. {#art-93}

1. Potrącenie wierzytelności upadłego z wierzytelnością wierzyciela jest 
dopuszczalne, jeżeli obie wierzytelności istniały w dniu ogłoszenia upadłości, 
chociażby termin wymagalności jednej z nich jeszcze nie nastąpił. 

©Kancelaria Sejmu 
 
 
 
s. 42/224 
 
2025-09-11 
 
2. Do potrącenia przedstawia się całkowitą sumę wierzytelności upadłego, 
a wierzytelność wierzyciela tylko w wysokości wierzytelności głównej wraz 
z odsetkami naliczonymi do dnia ogłoszenia upadłości. 
3. Jeżeli termin płatności nieoprocentowanego długu upadłego w dniu ogłoszenia 
upadłości nie nastąpił, do potrącenia przyjmuje się sumę należności zmniejszoną 
o odsetki ustawowe, nie wyższe jednak niż sześć procent, za czas od dnia ogłoszenia 
upadłości do dnia płatności i nie więcej niż za okres dwóch lat.

***
## Art. 94. {#art-94}

1. Potrącenie nie jest dopuszczalne, jeżeli dłużnik upadłego nabył 
wierzytelność w drodze przelewu lub indosu po ogłoszeniu upadłości albo nabył ją 
w ciągu ostatniego roku przed dniem ogłoszenia upadłości, wiedząc o istnieniu 
podstawy do ogłoszenia upadłości. 
2. Potrącenie jest dopuszczalne, jeżeli nabywca stał się wierzycielem upadłego 
wskutek spłacenia jego długu, za który odpowiadał osobiście albo określonymi 
przedmiotami majątkowymi, i jeżeli nabywca w czasie, gdy przyjął odpowiedzialność 
za dług upadłego, nie wiedział o istnieniu podstaw do ogłoszenia upadłości. Potrącenie 
jest zawsze dopuszczalne, jeżeli przyjęcie odpowiedzialności nastąpiło na rok przed 
dniem ogłoszenia upadłości.

***
## Art. 95. {#art-95}

Potrącenie nie jest dopuszczalne, jeżeli wierzyciel stał się dłużnikiem 
upadłego po dniu ogłoszenia upadłości.

***
## Art. 96. {#art-96}

Wierzyciel, który chce skorzystać z prawa potrącenia, składa o tym 
oświadczenie nie później niż przy zgłoszeniu wierzytelności.

***
## Art. 97. {#art-97}

Roszczenie wynikające z umowy zawartej w wyniku przyjęcia oferty 
złożonej przez upadłego może być przez wierzyciela dochodzone w postępowaniu 
upadłościowym tylko wtedy, gdy oświadczenie o przyjęciu oferty zostało złożone 
upadłemu przed dniem ogłoszenia upadłości.

***
## Art. 98. {#art-98}

1. Jeżeli w dniu ogłoszenia upadłości zobowiązania z umowy 
wzajemnej nie zostały wykonane w całości lub części, syndyk może, za zgodą 
sędziego-komisarza, wykonać zobowiązanie upadłego i zażądać od drugiej strony 
spełnienia świadczenia wzajemnego lub od umowy odstąpić ze skutkiem na dzień 
ogłoszenia upadłości. 

©Kancelaria Sejmu 
 
 
 
s. 43/224 
 
2025-09-11 
 
1a. Wydając zgodę, o której mowa w ust. 1, sędzia-komisarz kieruje się celem 
postępowania upadłościowego, biorąc także pod uwagę ważny interes drugiej strony 
umowy. 
1b. Na postanowienie sędziego-komisarza zażalenie przysługuje upadłemu oraz 
drugiej stronie umowy. 
1c. Jeżeli w dniu ogłoszenia upadłości upadły był stroną umowy innej niż umowa 
wzajemna, syndyk może od umowy odstąpić, chyba że ustawa przewiduje inny skutek. 
Przepisy ust. 1–1b stosuje się odpowiednio. 
2. Na żądanie drugiej strony złożone w formie pisemnej z datą pewną, syndyk 
w terminie trzech miesięcy oświadczy na piśmie, czy od umowy odstępuje, czy też 
żąda jej wykonania. Niezłożenie w tym terminie oświadczenia przez syndyka uważa 
się za odstąpienie od umowy. 
3. Druga strona, która ma obowiązek spełnić świadczenie wcześniej, może 
wstrzymać się ze spełnieniem świadczenia, do czasu spełnienia lub zabezpieczenia 
świadczenia wzajemnego. Prawo to drugiej stronie nie przysługuje, jeżeli w czasie 
zawarcia umowy wiedziała lub wiedzieć powinna o istnieniu podstaw do ogłoszenia 
upadłości.

***
## Art. 99. {#art-99}

Jeżeli syndyk odstępuje od umowy, druga strona nie ma prawa do 
zwrotu spełnionego świadczenia, chociażby świadczenie to znajdowało się w masie 
upadłości. Strona może dochodzić w postępowaniu upadłościowym należności 
z tytułu wykonania zobowiązania i poniesionych strat, zgłaszając te wierzytelności 
syndykowi 
za 
pośrednictwem 
systemu 
teleinformatycznego 
obsługującego 
postępowanie sądowe.

***
## Art. 100. {#art-100}

1. Sprzedawca może żądać zwrotu rzeczy ruchomej – także papierów 
wartościowych – wysłanej upadłemu bez otrzymania ceny, jeżeli rzecz ta nie została 
objęta przed ogłoszeniem upadłości przez upadłego lub przez osobę upoważnioną 
przez niego do rozporządzania rzeczą. Prawo żądania zwrotu służy także komisantowi, 
który wysłał rzecz upadłemu. 
2. Sprzedawca lub komisant, któremu rzecz została zwrócona, zwraca koszty, 
które zostały poniesione lub mają być poniesione, oraz otrzymane zaliczki. 
3. Syndyk może jednak rzecz zatrzymać, jeżeli zapłaci lub zabezpieczy należną 
od upadłego cenę i koszty. Prawo to przysługuje syndykowi w terminie miesiąca od 
dnia żądania zwrotu. 

©Kancelaria Sejmu 
 
 
 
s. 44/224 
 
2025-09-11

***
## Art. 101. {#art-101}

1. Zastrzeżone w umowie sprzedaży na rzecz sprzedawcy prawo 
własności nie wygasa z powodu ogłoszenia upadłości nabywcy, jeżeli jest skuteczne 
wobec jego wierzycieli według przepisów Kodeksu cywilnego. 
2. (uchylony)

***
## Art. 102. {#art-102}

1. Zawarte przez upadłego umowy zlecenia lub komisu, w których 
upadły był dającym zlecenie lub komitentem, a także umowy o zarządzanie papierami 
wartościowymi upadłego wygasają z dniem ogłoszenia upadłości. Wierzytelność 
z tytułu poniesionej wskutek tego straty może być dochodzona w postępowaniu 
upadłościowym. 
2. Od zawartych przez upadłego umów zlecenia lub komisu, w których upadły 
był przyjmującym zlecenie lub komisantem, można odstąpić z dniem ogłoszenia 
upadłości bez odszkodowania.

***
## Art. 103. {#art-103}

1. Umowa agencyjna wygasa z dniem ogłoszenia upadłości jednej ze 
stron. 
2. W razie upadłości 
dającego zlecenie agent 
ma prawo dochodzić 
w postępowaniu upadłościowym swojej wierzytelności powstałej z tytułu straty 
poniesionej wskutek wygaśnięcia umowy.

***
## Art. 104. {#art-104}

1. W razie ogłoszenia upadłości użyczającego lub biorącego do 
używania, umowa użyczenia, jeżeli rzecz już została wydana, ulega rozwiązaniu na 
żądanie jednej ze stron. 
2. Jeżeli rzecz nie była jeszcze wydana, umowa wygasa.

***
## Art. 105. {#art-105}

W razie upadłości jednej ze stron umowy pożyczki, umowa pożyczki 
wygasa, gdy przedmiot pożyczki nie został jeszcze wydany.

***
## Art. 106. {#art-106}

Pobranie z góry przez upadłego przed ogłoszeniem upadłości czynszu 
najmu rzeczy ruchomej za czas dłuższy niż sześć miesięcy, licząc od dnia ogłoszenia 
upadłości, nie zwalnia najemcy od obowiązku zapłaty czynszu do masy upadłości.

***
## Art. 107. {#art-107}

1. Umowa najmu lub dzierżawy nieruchomości upadłego wiąże strony, 
jeżeli przedmiot umowy przed ogłoszeniem upadłości został wydany najemcy lub 
dzierżawcy. 
2. Pobranie z góry przez upadłego przed ogłoszeniem upadłości czynszu najmu 
za czas dłuższy niż trzy miesiące, a czynszu dzierżawy za czas dłuższy niż sześć 
miesięcy, licząc w obu przypadkach od dnia ogłoszenia upadłości, jak również 

©Kancelaria Sejmu 
 
 
 
s. 45/224 
 
2025-09-11 
 
rozporządzanie tym czynszem, nie zwalnia najemcy lub dzierżawcy od obowiązku 
zapłaty czynszu do masy upadłości.

***
## Art. 108. {#art-108}

Sprzedaż przez syndyka w toku postępowania upadłościowego 
nieruchomości upadłego wywołuje takie same skutki w stosunku do umowy najmu lub 
dzierżawy, jak sprzedaż w postępowaniu egzekucyjnym.

***
## Art. 109. {#art-109}

1. 
Na 
podstawie 
postanowienia 
sędziego-komisarza 
syndyk 
wypowiada umowę najmu lub dzierżawy nieruchomości upadłego z zachowaniem 
trzymiesięcznego okresu wypowiedzenia, także wtedy, gdy wypowiedzenie tej 
umowy przez upadłego nie było dopuszczalne. Sędzia-komisarz może wydać 
postanowienie, jeżeli trwanie umowy utrudnia likwidację masy upadłości albo gdy 
czynsz najmu lub dzierżawy odbiega od przeciętnych czynszów za najem lub 
dzierżawę nieruchomości tego samego rodzaju. Na postanowienie sędziego-komisarza 
przysługuje zażalenie. 
2. Druga strona rozwiązanej umowy może dochodzić w postępowaniu 
upadłościowym odszkodowania z powodu rozwiązania umowy najmu lub dzierżawy 
przed terminem przewidzianym w umowie, zgłaszając te wierzytelności syndykowi za 
pośrednictwem systemu teleinformatycznego obsługującego postępowanie sądowe. 
3. Do najmu lub dzierżawy przedsiębiorstwa lub jego zorganizowanej części 
przepisy ust. 1 i 2 stosuje się odpowiednio.

***
## Art. 110. {#art-110}

1. Jeżeli w dniu ogłoszenia upadłości przedmiot najmu lub dzierżawy 
nie był jeszcze wydany upadłemu, każda ze stron może odstąpić od umowy najmu lub 
dzierżawy nieruchomości zawartej przez upadłego jako najemcę lub dzierżawcę. 
Oświadczenie o odstąpieniu powinno być złożone w terminie dwóch miesięcy od dnia 
ogłoszenia upadłości. 
2. Odstąpienie od umowy nie pociąga za sobą obowiązku odszkodowania. 
3. Jeżeli przedmiot najmu lub dzierżawy w dniu ogłoszenia upadłości był już 
wydany upadłemu, syndyk może wypowiedzieć umowę najmu lub dzierżawy, także 
wtedy, gdy wypowiedzenie tej umowy przez upadłego nie było dopuszczalne. Jeżeli 
umowa dotyczy nieruchomości, w której prowadzone było przedsiębiorstwo 
upadłego, wypowiedzenie następuje z zachowaniem trzymiesięcznego terminu 
wypowiedzenia, a w innych przypadkach – z zachowaniem terminu ustawowego, 
chyba że terminy wypowiedzenia przewidziane w umowie są krótsze. 

©Kancelaria Sejmu 
 
 
 
s. 46/224 
 
2025-09-11 
 
4. Rozwiązanie umowy nie może nastąpić przed upływem terminu, za który 
czynsz zapłacono z góry. Na podstawie postanowienia sędziego-komisarza syndyk 
wypowiada umowę najmu lub dzierżawy przed terminem, jeżeli dalsze trwanie 
umowy utrudniałoby prowadzenie postępowania upadłościowego, w szczególności 
gdy 
prowadzi 
do 
zwiększenia 
kosztów 
upadłości. 
Na 
postanowienie 
sędziego-komisarza przysługuje zażalenie. 
5. Wynajmujący lub wydzierżawiający może dochodzić w postępowaniu 
upadłościowym odszkodowania z powodu rozwiązania najmu lub dzierżawy przed 
terminem przewidzianym w umowie, jednak za czas nie dłuższy niż dwa lata, 
pomniejszonego o rozliczenie nakładów upadłego podnoszących wartość przedmiotu 
najmu lub dzierżawy. 
6. Do najmu lub dzierżawy przedsiębiorstwa lub jego zorganizowanej części 
przepisy ust. 1–5 stosuje się odpowiednio. 
Art. 110a. 1. Syndyk może odstąpić z dniem ogłoszenia upadłości od umowy 
o zakazie konkurencji, o której mowa w art. 1012 ustawy z dnia 26 czerwca 1974 r. – 
Kodeks pracy (Dz. U. z 2025 r. poz. 277), bez prawa do odszkodowania. 
2. W przypadku 
sprzedaży 
przedsiębiorstwa 
upadłego 
w całości 
odpowiedzialność za zobowiązania upadłego z umowy o zakazie konkurencji, o której 
mowa w art. 1012 ustawy z dnia 26 czerwca 1974 r. – Kodeks pracy, przechodzi na 
nabywcę przedsiębiorstwa, chyba że syndyk wcześniej odstąpił od umowy.

***
## Art. 111. {#art-111}

1. Z dniem ogłoszenia upadłości umowa kredytu wygasa, jeżeli przed 
tym terminem kredytodawca nie przekazał środków pieniężnych do dyspozycji 
upadłego. Kredytodawca może dochodzić naprawienia szkody w postępowaniu 
upadłościowym, zgłaszając te wierzytelności syndykowi za pośrednictwem systemu 
teleinformatycznego obsługującego postępowanie sądowe. 
2. W razie oddania do dyspozycji upadłego przed dniem ogłoszenia upadłości 
części środków pieniężnych, upadły traci prawo do żądania wypłaty części 
nieprzekazanej.

***
## Art. 112. {#art-112}

Ogłoszenie upadłości nie ma wpływu na umowy rachunku bankowego, 
umowy rachunku papierów wartościowych, umowy rachunku derywatów lub konta 
rozliczeniowego, lub umowy o prowadzenie rachunku zbiorczego upadłego.

***
## Art. 113. {#art-113}

1. Z dniem ogłoszenia upadłości wygasają umowy o udostępnienie 
skrytek sejfowych oraz umowy przechowania zawarte przez upadłego z bankiem. 

©Kancelaria Sejmu 
 
 
 
s. 47/224 
 
2025-09-11 
 
Wydanie złożonych w skrytkach przedmiotów lub papierów wartościowych następuje 
w terminie uzgodnionym z syndykiem, jednak nie później niż w terminie trzech 
miesięcy od dnia ogłoszenia upadłości. 
2. Za okres korzystania ze skrytek i innych form przechowania po ogłoszeniu 
upadłości bank pobiera opłaty według stawek obowiązujących strony w ostatnim 
miesiącu przed dniem ogłoszenia upadłości. 
3. Roszczenia banku, o których mowa w ust. 2, mogą być dochodzone 
w postępowaniu upadłościowym, według zasad określonych dla dochodzenia zwrotu 
kosztów postępowania.

***
## Art. 114. {#art-114}

1. W przypadku ogłoszenia upadłości korzystającego z rzeczy na 
podstawie umowy leasingu syndyk może, za zgodą sędziego-komisarza, odstąpić 
z dniem ogłoszenia upadłości od umowy leasingu. Przepisy art. 98 ust. 2 i art. 99 
stosuje się odpowiednio. 
2. W razie ogłoszenia upadłości finansującego leasing przepisów ustawy 
o odstąpieniu od umowy przez syndyka nie stosuje się.

***
## Art. 115. {#art-115}

1. Ogłoszenie upadłości ubezpieczonego nie ma wpływu na umowy 
obowiązkowego ubezpieczenia majątkowego. 
2. Do umów ubezpieczeń majątkowych zawartych przez upadłego przed dniem 
ogłoszenia upadłości stosuje się odpowiednio przepisy art. 98 i 99.

***
## Art. 116. {#art-116}

Roszczenia małżonka upadłego wynikające z umowy majątkowej 
małżeńskiej mogą być uwzględnione tylko wówczas, gdy była ona zawarta co 
najmniej dwa lata przed dniem złożenia wniosku o ogłoszenie upadłości.

***
## Art. 117. {#art-117}

(uchylony)

***
## Art. 118. {#art-118}

(uchylony) 
## Rozdział 3. Skutki ogłoszenia upadłości co do spadków nabytych przez upadłego

***
## Art. 119. {#art-119}

1. Jeżeli do spadku otwartego po dniu ogłoszenia upadłości powołany 
zostaje upadły, spadek wchodzi do masy upadłości. Syndyk nie składa oświadczenia 
o przyjęciu spadku, a spadek uważa się za przyjęty z dobrodziejstwem inwentarza. 
2. Jeżeli otwarcie spadku nastąpiło przed ogłoszeniem upadłości, a do chwili jej 
ogłoszenia nie upłynął jeszcze termin do złożenia oświadczenia o przyjęciu lub 

©Kancelaria Sejmu 
 
 
 
s. 48/224 
 
2025-09-11 
 
odrzuceniu spadku i powołany spadkobierca oświadczenia takiego nie złożył, przepis 
ust. 1 stosuje się odpowiednio. 
3. Przepisy ust. 1 i 2 stosuje się odpowiednio w razie ustanowienia zapisów na 
rzecz upadłego.

***
## Art. 120. {#art-120}

Umowa zbycia całości lub części spadku albo całości lub części 
udziału spadkowego zawarta przez upadłego po ogłoszeniu upadłości jest nieważna. 
Nieważna jest też dokonana przez niego czynność rozporządzająca udziałem w przed-
miocie należącym do spadku, jak i jego zgoda na rozporządzenie udziałem 
w przedmiocie należącym do spadku przez innego spadkobiercę.

***
## Art. 121. {#art-121}

1. Jeżeli w skład spadku wchodzą wierzytelności i prawa wątpliwe co 
do istnienia lub możliwości ich wykonania, można wyłączyć spadek z masy upadłości. 
2. Spadek podlega wyłączeniu, jeżeli składniki majątkowe wchodzące w skład 
spadku są trudno zbywalne albo z innych przyczyn wejście spadku do masy upadłości 
nie byłoby korzystne dla postępowania upadłościowego. 
3. Postanowienie o wyłączeniu spadku z masy upadłości wydaje z urzędu 
sędzia-komisarz. Na postanowienie przysługuje zażalenie upadłemu i wierzycielom.

***
## Art. 122. {#art-122}

Jeżeli spadek zostanie wyłączony z masy upadłości, oświadczenie 
o przyjęciu lub odrzuceniu spadku składa spadkobierca. Termin do złożenia 
oświadczenia zaczyna biec od chwili uprawomocnienia się postanowienia o wy-
łączeniu.

***
## Art. 123. {#art-123}

Oświadczenie 
upadłego 
o odrzuceniu 
spadku 
lub 
zapisu 
windykacyjnego jest bezskuteczne w stosunku do masy upadłości, jeżeli zostało 
złożone po ogłoszeniu upadłości. 
## Rozdział 4. Wpływ ogłoszenia upadłości na stosunki majątkowe małżeńskie upadłego

***
## Art. 124. {#art-124}

1. Z dniem ogłoszenia upadłości jednego z małżonków powstaje 
między małżonkami rozdzielność majątkowa, o której mowa w art. 53 § 1 ustawy z 
dnia 25 lutego 1964 r. – Kodeks rodzinny i opiekuńczy (Dz. U. z 2023 r. poz. 2809). 
Jeżeli małżonkowie pozostawali w ustroju wspólności majątkowej, majątek wspólny 
małżonków wchodzi do masy upadłości, a jego podział jest niedopuszczalny. 
2. (uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 49/224 
 
2025-09-11 
 
3. Małżonek upadłego może dochodzić w postępowaniu upadłościowym 
należności z tytułu udziału w majątku wspólnym, zgłaszając tę wierzytelność 
syndykowi 
za 
pośrednictwem 
systemu 
teleinformatycznego 
obsługującego 
postępowanie sądowe. 
4. Domniemywa się, że majątek wspólny powstały w okresie prowadzenia 
przedsiębiorstwa przez upadłego został nabyty ze środków pochodzących z dochodów 
tego przedsiębiorstwa. 
5. Do masy upadłości nie wchodzą przedmioty służące wyłącznie małżonkowi 
upadłego do prowadzenia działalności gospodarczej lub zawodowej, choćby były 
objęte majątkową wspólnością małżeńską, z wyjątkiem przedmiotów majątkowych 
nabytych do majątku wspólnego w ciągu dwóch lat przed dniem złożenia wniosku 
o ogłoszenie upadłości.

***
## Art. 125. {#art-125}

1. Ustanowienie rozdzielności majątkowej na podstawie orzeczenia 
sądu w ciągu roku przed dniem złożenia wniosku o ogłoszenie upadłości jest 
bezskuteczne w stosunku do masy upadłości, chyba że pozew o ustanowienie 
rozdzielności majątkowej został złożony co najmniej na dwa lata przed dniem złożenia 
wniosku o ogłoszenie upadłości. 
2. Po ogłoszeniu upadłości nie można ustanowić rozdzielności majątkowej z datą 
wcześniejszą niż data ogłoszenia upadłości. 
3. Przepis ust. 1 stosuje się odpowiednio, gdy rozdzielność majątkowa powstała 
z mocy prawa w ciągu roku przed dniem złożenia wniosku o ogłoszenie upadłości 
w wyniku rozwodu, separacji albo ubezwłasnowolnienia jednego z małżonków, chyba 
że pozew lub wniosek w sprawie został złożony co najmniej dwa lata przed dniem 
złożenia wniosku o ogłoszenie upadłości. Rozwiedziony małżonek upadłego albo 
małżonek upadłego może w drodze powództwa lub zarzutu żądać uznania 
rozdzielności majątkowej za skuteczną w stosunku do masy upadłości, jeżeli w chwili 
powstania rozdzielności majątkowej nie wiedział o istnieniu podstawy do ogłoszenia 
upadłości, a powstanie rozdzielności majątkowej nie doprowadziło do pokrzywdzenia 
wierzycieli. Powództwo wnosi się do sądu upadłościowego. Sąd może zabezpieczyć 
powództwo przez ustanowienie zakazu zbywania lub obciążania mienia, które 
stanowiło majątek wspólny małżonków. 

©Kancelaria Sejmu 
 
 
 
s. 50/224 
 
2025-09-11

***
## Art. 126. {#art-126}

1. Ustanowienie rozdzielności majątkowej umową majątkową jest 
skuteczne w stosunku do masy upadłości tylko wtedy, gdy umowa zawarta została co 
najmniej dwa lata przed dniem złożenia wniosku o ogłoszenie upadłości. 
2. Przepis ust. 1 stosuje się odpowiednio, gdy umową majątkową ograniczono 
wspólność majątkową. 
DZIAŁ III 
Bezskuteczność i zaskarżanie czynności upadłego

***
## Art. 127. {#art-127}

1. Bezskuteczne w stosunku do masy upadłości są czynności prawne 
dokonane przez upadłego w ciągu roku przed dniem złożenia wniosku o ogłoszenie 
upadłości, którymi rozporządził on swoim majątkiem, jeżeli dokonane zostały 
nieodpłatnie albo odpłatnie, ale wartość świadczenia upadłego przewyższa w rażącym 
stopniu wartość świadczenia otrzymanego przez upadłego lub zastrzeżonego dla 
upadłego lub dla osoby trzeciej. 
2. Przepis ust. 1 stosuje się odpowiednio do ugody sądowej, uznania powództwa 
i zrzeczenia się roszczenia. 
3. Bezskuteczne są również zabezpieczenie i zapłata długu niewymagalnego 
dokonane przez upadłego w ciągu sześciu miesięcy przed dniem złożenia wniosku 
o ogłoszenie upadłości. Jednak ten, kto otrzymał zapłatę lub zabezpieczenie, może 
w drodze powództwa lub zarzutu żądać uznania tych czynności za skuteczne, jeżeli 
w czasie ich dokonania nie wiedział o istnieniu podstawy do ogłoszenia upadłości. 
4. Przepisów ust. 1–3 nie stosuje się do zabezpieczeń ustanowionych przed 
dniem ogłoszenia upadłości w związku z terminowymi operacjami finansowymi, 
pożyczkami instrumentów finansowych lub sprzedażą instrumentów finansowych ze 
zobowiązaniem do ich odkupu, o których mowa w art. 85 ust. 1.

***
## Art. 128. {#art-128}

1. Sędzia-komisarz z urzędu albo na wniosek syndyka uzna za 
bezskuteczną w stosunku do masy upadłości odpłatną czynność prawną dokonaną 
przez upadłego w terminie sześciu miesięcy przed dniem złożenia wniosku 
o ogłoszenie upadłości z małżonkiem, krewnym lub powinowatym w linii prostej, 
krewnym lub powinowatym w linii bocznej do drugiego stopnia włącznie, z osobą 
pozostającą z upadłym w faktycznym związku, prowadzącą z nim wspólnie 
gospodarstwo domowe albo z przysposobionym lub przysposabiającym, chyba że 
druga strona czynności wykaże, że nie doszło do pokrzywdzenia wierzycieli. Na 
postanowienie sędziego-komisarza przysługuje zażalenie. 

©Kancelaria Sejmu 
 
 
 
s. 51/224 
 
2025-09-11 
 
1a. Do czynności upadłego, dokonanych ze spółką, w której upadły jest 
członkiem zarządu, jedynym wspólnikiem lub akcjonariuszem, oraz ze spółkami, 
w których osoby wymienione w ust. 1 są członkami zarządu lub jedynymi 
wspólnikami lub akcjonariuszami, przepis ust. 1 stosuje się. 
2. Przepis ust. 1 stosuje się odpowiednio do czynności upadłego, będącego 
spółką lub osobą prawną, dokonanej z jej wspólnikami, ich reprezentantami lub ich 
małżonkami, 
jak 
również 
ze 
spółkami 
powiązanymi, 
ich 
wspólnikami, 
reprezentantami lub małżonkami tych osób. 
3. Do czynności upadłego będącego spółką, których dokonał z inną spółką, jeżeli 
jedna z nich była spółką dominującą, a także jeżeli ta sama spółka jest spółką 
dominującą w stosunku do upadłego i drugiej strony czynności, przepis ust. 1 stosuje 
się. 
Art. 128a. 1. Bezskuteczny w stosunku do masy upadłości jest przelew 
wierzytelności przyszłej, jeżeli wierzytelność ta powstanie po ogłoszeniu upadłości. 
2. W przypadku gdy umowa przelewu wierzytelności została zawarta nie później 
niż sześć miesięcy przed dniem złożenia wniosku o ogłoszenie upadłości w formie 
pisemnej z datą pewną, przepisu ust. 1 nie stosuje się.

***
## Art. 129. {#art-129}

1. Jeżeli wynagrodzenie za pracę reprezentanta upadłego lub 
pracownika upadłego wykonującego zadania w zakresie zarządu przedsiębiorstwem 
lub wynagrodzenie osoby świadczącej usługi związane z zarządem lub nadzorem nad 
przedsiębiorstwem upadłego określone w umowie o pracę, umowie o świadczenie 
usług lub uchwale organu upadłego zawartej lub podjętej przed dniem ogłoszenia 
upadłości jest rażąco wyższe od przeciętnego wynagrodzenia za tego rodzaju pracę lub 
usługi i nie jest uzasadnione nakładem pracy, sędzia-komisarz z urzędu albo na 
wniosek syndyka uznaje, że określona część wynagrodzenia przypadająca za okres 
przed dniem ogłoszenia upadłości, nie dłuższy jednak niż sześć miesięcy przed dniem 
złożenia wniosku o ogłoszenie upadłości, jest bezskuteczna w stosunku do masy 
upadłości, chociażby wynagrodzenie zostało już wypłacone. Sędzia-komisarz może 
uznać za bezskuteczne w całości lub części w stosunku do masy upadłości 
wynagrodzenie reprezentanta upadłego, pracownika upadłego wykonującego zadania 
w zakresie zarządu przedsiębiorstwem lub osoby świadczącej usługi związane 
z zarządem lub nadzorem nad przedsiębiorstwem upadłego przypadające za czas po 

©Kancelaria Sejmu 
 
 
 
s. 52/224 
 
2025-09-11 
 
dniu ogłoszenia upadłości, jeżeli ze względu na objęcie zarządu przez syndyka nie jest 
ono uzasadnione nakładem pracy. 
2. W przypadku, o którym mowa w ust. 1, sędzia-komisarz określa podlegające 
zaspokojeniu z masy upadłości wynagrodzenie w wysokości odpowiedniej do pracy 
wykonanej przez reprezentanta upadłego, pracownika upadłego wykonującego 
zadania w zakresie zarządu przedsiębiorstwem lub osobę wykonującą czynności 
związane 
z zarządem 
lub 
nadzorem 
nad 
przedsiębiorstwem 
upadłego. 
Sędzia-komisarz wydaje postanowienie po wysłuchaniu syndyka oraz reprezentanta, 
pracownika upadłego lub osoby wykonującej czynności związane z zarządem lub 
nadzorem nad przedsiębiorstwem upadłego. 
3. Przepis ust. 1 i 2 stosuje się odpowiednio do świadczeń przysługujących 
w związku z rozwiązaniem stosunku pracy albo umowy o usługi związane z zarządem 
przedsiębiorstwem, z tym że ograniczenie wysokości tych świadczeń następuje do 
wysokości określonych według zasad powszechnie obowiązujących. 
4. Na postanowienie sędziego-komisarza przysługuje zażalenie.

***
## Art. 130. {#art-130}

1. Sędzia-komisarz na wniosek syndyka uzna za bezskuteczne 
w stosunku do masy upadłości obciążenie majątku upadłego hipoteką, zastawem, 
zastawem rejestrowym lub hipoteką morską, jeżeli upadły nie był dłużnikiem 
osobistym zabezpieczonego wierzyciela, a obciążenie to zostało ustanowione w ciągu 
roku przed dniem złożenia wniosku o ogłoszenie upadłości i w związku z jego 
ustanowieniem upadły nie otrzymał żadnego świadczenia. 
2. Przepis ust. 1 stosuje się odpowiednio, jeżeli obciążenie rzeczowe 
ustanowione zostało w zamian za świadczenie, które jest niewspółmiernie niskie do 
wartości udzielanego zabezpieczenia. 
3. Bez względu na wysokość świadczenia otrzymanego przez upadłego 
sędzia-komisarz uzna za bezskuteczne obciążenia, o których mowa w ust. 1 i 2, jeżeli 
obciążenia te zabezpieczają długi osób, o których mowa w art. 128, chyba że druga 
strona wykaże, że nie doszło do pokrzywdzenia wierzycieli. 
4. Na postanowienie sędziego-komisarza przysługuje zażalenie. 
Art. 130a. Sędzia-komisarz na wniosek syndyka uzna za bezskuteczne 
w stosunku do masy upadłości w całości lub części kary umowne zastrzeżone na 
wypadek niewykonania lub nienależytego wykonania zobowiązania, jeżeli 
zobowiązanie zostało w znacznej części wykonane przez upadłego lub jeżeli kara 

©Kancelaria Sejmu 
 
 
 
s. 53/224 
 
2025-09-11 
 
umowna jest rażąco wygórowana. Na postanowienie sędziego-komisarza przysługuje 
zażalenie.

***
## Art. 131. {#art-131}

W sprawach 
nieuregulowanych 
przepisami 
art. 127–130a 
do 
zaskarżenia czynności 
prawnych upadłego, dokonanych 
z pokrzywdzeniem 
wierzycieli, przepisy art. 132–134 oraz przepisy Kodeksu cywilnego o ochronie 
wierzyciela w przypadku niewypłacalności dłużnika stosuje się odpowiednio. 
Art. 131a. Jeżeli 
upadłość 
ogłoszono 
w wyniku 
rozpoznania 
wniosku 
o ogłoszenie upadłości złożonego nie później niż w terminie 3 miesięcy od dnia 
zakończenia 
postępowania 
restrukturyzacyjnego 
albo 
uprawomocnienia 
się 
postanowienia o umorzeniu postępowania restrukturyzacyjnego, przez dzień złożenia 
wniosku o ogłoszenie upadłości, o którym mowa w art. 127–130, rozumie się dzień 
złożenia wniosku restrukturyzacyjnego. Jeżeli przed dniem złożenia wniosku 
restrukturyzacyjnego złożono wniosek o ogłoszenie upadłości, który został odrzucony 
zgodnie z art. 9a, to wówczas przez dzień złożenia wniosku o ogłoszenie upadłości, 
o którym mowa w art. 127–130, rozumie się dzień złożenia odrzuconego wniosku 
o ogłoszenie upadłości.

***
## Art. 132. {#art-132}

1. Powództwo może wytoczyć syndyk. 
2. Syndyk nie ponosi opłat sądowych. 
3. Nie można żądać uznania czynności za bezskuteczną po upływie dwóch lat od 
dnia ogłoszenia upadłości, chyba że na podstawie przepisów Kodeksu cywilnego 
uprawnienie to wygasło wcześniej. Termin ten nie ma zastosowania, gdy żądanie 
uznania czynności za bezskuteczną zgłoszone zostało w drodze zarzutu.

***
## Art. 133. {#art-133}

1. Syndyk może wstąpić w miejsce powoda w sprawie wszczętej przez 
wierzyciela, który zaskarżył czynności upadłego. W tym przypadku, jeżeli pozwanym 
był także upadły, postępowanie w stosunku do niego umarza się po uprawomocnieniu 
się postanowienia o ogłoszeniu upadłości. 
2. Z odzyskanej części majątku syndyk zwraca wierzycielowi poniesione przez 
niego koszty procesu. 
3. W razie 
umorzenia 
postępowania 
upadłościowego 
lub 
uchylenia 
postępowania upadłościowego przed zakończeniem sprawy, o której mowa w ust. 1, 
sąd zawiadamia o toczącym się procesie wierzyciela, który może w ciągu dwóch 
tygodni przystąpić do sprawy w charakterze powoda. Wierzyciel, który zgłosił swoje 

©Kancelaria Sejmu 
 
 
 
s. 54/224 
 
2025-09-11 
 
przystąpienie do sprawy, nie może żądać powtórzenia dotychczasowego 
postępowania. 
4. Wierzyciel, który otrzymał przed ogłoszeniem upadłości jakiekolwiek 
świadczenie na mocy wyroku uznającego czynność upadłego za bezskuteczną, nie ma 
obowiązku wydania otrzymanego świadczenia masie upadłości.

***
## Art. 134. {#art-134}

1. Jeżeli czynność upadłego jest bezskuteczna z mocy prawa lub 
została uznana za bezskuteczną, to, co wskutek tej czynności ubyło z majątku 
upadłego lub do niego nie weszło, podlega przekazaniu do masy upadłości, a jeżeli 
przekazanie w naturze jest niemożliwe, do masy upadłości wpłaca się równowartość 
w pieniądzu. Za zgodą sędziego-komisarza druga strona czynności może zwolnić się 
z obowiązku przekazania do masy upadłości tego, co wskutek tej czynności z majątku 
upadłego ubyło, przez zapłatę różnicy między wartością rynkową świadczenia 
dłużnika z dnia zawarcia umowy, a wartością świadczenia otrzymanego przez 
dłużnika. Na postanowienie, o którym mowa w zdaniu poprzednim, przysługuje 
zażalenie. 
1a. Jeżeli osoba obowiązana do przekazania składników majątkowych do masy 
upadłości nie wykona swojego obowiązku na wezwanie syndyka, a obowiązek 
przekazania składników majątkowych do masy upadłości nie został stwierdzony 
prawomocnym orzeczeniem, syndyk może w drodze powództwa żądać nakazania 
przekazania składników majątkowych do masy upadłości. Powództwo wnosi się do 
sądu upadłościowego. 
1b. Sąd może zabezpieczyć powództwo przez ustanowienie zakazu zbywania lub 
obciążania składników majątkowych objętych powództwem. 
2. W przypadkach, o których mowa w ust. 1, świadczenie wzajemne osoby 
trzeciej zwraca się tej osobie, jeżeli znajduje się w masie upadłości oddzielnie od 
innego majątku lub o ile masa upadłości jest nim wzbogacona. Jeżeli świadczenie nie 
podlega zwrotowi, osoba trzecia może dochodzić wierzytelności w postępowaniu 
upadłościowym.

***
## Art. 135. {#art-135}

1. Przepisów umożliwiających zaskarżanie czynności prawnych lub 
określających bezskuteczność czynności prawnych dokonanych przez upadłego nie 
stosuje się do kompensowania dokonanego zgodnie z art. 136 lub art. 137 i jego 
wyników. 

©Kancelaria Sejmu 
 
 
 
s. 55/224 
 
2025-09-11 
 
2. Przepisów 
umożliwiających 
zaskarżanie 
czynności 
prawnych 
lub 
określających bezskuteczność czynności prawnych dokonanych przez upadłego nie 
stosuje się także do umowy o ustanowienie zabezpieczenia finansowego, o której 
mowa w ustawie z dnia 2 kwietnia 2004 r. o niektórych 
zabezpieczeniach 
finansowych, ani do wykonania zobowiązań wynikających z takiej umowy. 
DZIAŁ IV 
Wpływ ogłoszenia upadłości na zlecenia rozrachunku w systemach płatności  
i systemach rozrachunku papierów wartościowych

***
## Art. 136. {#art-136}

W razie ogłoszenia upadłości uczestnika systemu płatności lub 
systemu rozrachunku papierów wartościowych, o którym mowa w art. 22 ust. 1 pkt 4, 
skutki prawne zlecenia rozrachunku wynikające z jego wprowadzenia do systemu oraz 
wyniki kompensowania są niepodważalne i wiążące dla osób trzecich, jeżeli zlecenie 
to zostało wprowadzone do systemu przed ogłoszeniem upadłości.

***
## Art. 137. {#art-137}

Jeżeli zlecenie rozrachunku, o którym mowa w art. 136, zostało 
wprowadzone do systemu po ogłoszeniu upadłości i jest wykonane w dniu roboczym 
systemu w rozumieniu art. 80 ust. 2, rozpoczynającym się w dniu, w którym została 
ogłoszona upadłość, skutki prawne wynikające z jego wprowadzenia do systemu są 
niepodważalne i wiążące dla osób trzecich jedynie wtedy, gdy podmiot prowadzący 
system wykaże, że w momencie, w którym zgodnie z zasadami funkcjonowania tego 
systemu zlecenie to stało się nieodwołalne, nie wiedział ani nie mógł wiedzieć 
o ogłoszeniu upadłości. 
DZIAŁ V 
Wpływ ogłoszenia upadłości na postępowania sądowe i administracyjne 
## Rozdział 1. (uchylony) 
(oznaczenie i tytuł rozdziału 2 – uchylone)

***
## Art. 144. {#art-144}

1. Po ogłoszeniu upadłości postępowania sądowe, administracyjne lub 
sądowoadministracyjne dotyczące masy upadłości mogą być wszczęte i prowadzone 
wyłącznie przez syndyka albo przeciwko niemu. 
2. Postępowania, o których mowa w ust. 1, syndyk prowadzi na rzecz upadłego, 
lecz w imieniu własnym. 

©Kancelaria Sejmu 
 
 
 
s. 56/224 
 
2025-09-11 
 
3. Przepisów ust. 1 i 2 nie stosuje się do postępowań w sprawach o należne od 
upadłego alimenty oraz renty z tytułu odpowiedzialności za uszkodzenie ciała lub 
rozstrój zdrowia albo utratę żywiciela oraz z tytułu zamiany uprawnień objętych 
treścią prawa dożywocia na dożywotnią rentę. 
4. Syndyk może żądać zmiany orzeczenia lub umowy dotyczącej obowiązku 
alimentacyjnego.

***
## Art. 145. {#art-145}

1. Postępowanie sądowe, administracyjne lub sądowoadministracyjne 
w sprawie wszczętej przeciwko upadłemu przed dniem ogłoszenia upadłości 
o wierzytelność, która podlega zgłoszeniu do masy upadłości, może być podjęte 
przeciwko syndykowi tylko w przypadku, gdy w postępowaniu upadłościowym 
wierzytelność ta po wyczerpaniu trybu określonego ustawą nie zostanie umieszczona 
na liście wierzytelności. 
2. (uchylony)

***
## Art. 146. {#art-146}

1. Postępowanie egzekucyjne skierowane do majątku wchodzącego 
w skład masy upadłości, wszczęte przed dniem ogłoszenia upadłości, ulega 
zawieszeniu z mocy prawa z dniem ogłoszenia upadłości. Postępowanie to umarza się 
z mocy prawa po uprawomocnieniu się postanowienia o ogłoszeniu upadłości. 
Zawieszenie postępowania egzekucyjnego nie stoi na przeszkodzie przysądzeniu 
własności nieruchomości, jeżeli przybicia prawomocnie udzielono przed ogłoszeniem 
upadłości, a nabywca egzekucyjny wpłaci w terminie cenę nabycia. 
2. Sumy uzyskane w zawieszonym postępowaniu egzekucyjnym, a jeszcze 
niewydane, przelewa się do masy upadłości po uprawomocnieniu się postanowienia 
o ogłoszeniu upadłości. 
2a. Sumy uzyskane ze sprzedaży w postępowaniu egzekucyjnym składników 
majątkowych obciążonych rzeczowo traktuje się w postępowaniu upadłościowym jak 
sumy uzyskane z likwidacji obciążonych rzeczowo składników masy upadłości. 
3. Po dniu ogłoszenia upadłości niedopuszczalne jest skierowanie egzekucji do 
majątku wchodzącego w skład masy upadłości oraz wykonanie postanowienia 
o zabezpieczeniu lub zarządzenia zabezpieczenia na majątku upadłego, z wyjątkiem 
zabezpieczenia 
roszczeń 
alimentacyjnych 
oraz 
roszczeń 
o rentę 
z tytułu 
odszkodowania za wywołanie choroby, niezdolności do pracy, kalectwa lub śmierci 
oraz o zamianę uprawnień objętych treścią prawa dożywocia na dożywotnią rentę. 
4. (uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 57/224 
 
2025-09-11

***
## Art. 147. {#art-147}

Do postępowań przed sądami polubownymi przepisy art. 174 § 1 pkt 4 
i 5 oraz art. 180 § 1 pkt 5 Kodeksu postępowania cywilnego, a także art. 144 
i art. 145 stosuje się odpowiednio. 
Art. 147a. 1. Jeżeli w dniu ogłoszenia upadłości postępowanie przed sądem 
polubownym nie zostało wszczęte, za zgodą sędziego-komisarza syndyk może 
odstąpić od zapisu na sąd polubowny, jeżeli dochodzenie roszczenia przed sądem 
polubownym utrudnia likwidację masy upadłości, w szczególności gdy stan masy 
uniemożliwia pokrycie kosztów wszczęcia i prowadzenia postępowania przed sądem 
polubownym. 
2. Na żądanie drugiej strony złożone w formie pisemnej syndyk w terminie 
trzydziestu dni oświadczy na piśmie, czy odstępuje od zapisu na sąd polubowny. 
Niezłożenie w tym terminie oświadczenia przez syndyka uważa się za odstąpienie od 
zapisu na sąd polubowny. 
3. Druga strona może odstąpić od zapisu na sąd polubowny, gdy syndyk mimo 
tego, że nie odstąpił od zapisu na sąd polubowny, odmówi udziału w kosztach 
postępowania przed sądem polubownym. 
4. Na skutek odstąpienia zapis na sąd polubowny traci moc.

***
## Art. 148. {#art-148}

(uchylony) 
TYTUŁ IV 
Przepisy ogólne o postępowaniu upadłościowym prowadzonym po ogłoszeniu 
upadłości 
DZIAŁ I 
Sąd i sędzia-komisarz 
## Rozdział 1. Sąd

***
## Art. 149. {#art-149}

1. Po ogłoszeniu upadłości postępowanie upadłościowe toczy się 
w sądzie upadłościowym, który ogłosił upadłość. 
2. Jeżeli postępowanie zostało wszczęte w kilku sądach właściwych, sprawa 
należy do właściwości sądu, który pierwszy wydał postanowienie o ogłoszeniu 
upadłości. 

©Kancelaria Sejmu 
 
 
 
s. 58/224 
 
2025-09-11 
 
3. Jeżeli w toku postępowania okaże się, że właściwy jest inny sąd, sprawę 
przekazuje się temu sądowi. Na postanowienie o przekazaniu nie przysługuje 
zażalenie. Postanowienie wiąże sąd, któremu sprawa została przekazana. Czynności 
dokonane w sądzie niewłaściwym pozostają w mocy.

***
## Art. 150. {#art-150}

1. 
Sąd 
upadłościowy 
orzeka 
w składzie 
jednego 
sędziego 
zawodowego, z zastrzeżeniem ust. 2. 
2. W przedmiocie wynagrodzenia syndyka, a także rozpoznając zażalenie na 
postanowienie sędziego-komisarza sąd upadłościowy orzeka w składzie trzech 
sędziów zawodowych. 
3. Sędzia-komisarz ani jego zastępca nie mogą wchodzić w skład sądu, który 
orzeka w przedmiocie wynagrodzenia lub odwołania syndyka oraz wyłączenia z masy 
upadłości. 
4. W przypadku uchylenia postanowienia sędziego-komisarza i przekazania 
sprawy do ponownego rozpoznania, sędzia-komisarz jest wyłączony od ponownego 
rozpoznawania tej sprawy. Wyłączenie to obowiązuje również w przypadku uchylenia 
postanowienia wydanego w wyniku ponownego rozpoznania sprawy. W takim 
przypadku sprawę rozpoznaje zastępca sędziego-komisarza albo wyznaczony sędzia. 
## Rozdział 2. Sędzia-komisarz i zastępca sędziego-komisarza

***
## Art. 151. {#art-151}

1. Po ogłoszeniu upadłości czynności postępowania upadłościowego 
wykonuje sędzia-komisarz, z wyjątkiem czynności, dla których właściwy jest sąd. 
1a. Funkcję sędziego-komisarza może pełnić referendarz sądowy. 
1b. Jeżeli funkcję sędziego-komisarza pełni referendarz sądowy, czynności 
wskazane w art. 57 ust. 3 i 4, art. 58 ust. 1–3, art. 63a, art. 73 ust. 2, art. 121 ust. 3, 
art. 259 ust. 1 i 1a, art. 315 i art. 350 ust. 1 i 2 wykonuje jako sędzia-komisarz 
wyznaczony do wykonania danej czynności sędzia, do którego przepisy 
o czynnościach sędziego-komisarza stosuje się odpowiednio. 
1c. Na czynności referendarza sądowego pełniącego funkcję sędziego-komisarza 
przysługuje skarga w przypadkach, w których na postanowienie sędziego-komisarza 
przysługuje zażalenie. Wniesienie skargi na postanowienie referendarza sądowego nie 
powoduje utraty mocy zaskarżonego postanowienia. Przepisy o zażaleniu na 
postanowienie sędziego-komisarza stosuje się odpowiednio. 

©Kancelaria Sejmu 
 
 
 
s. 59/224 
 
2025-09-11 
 
1d. Jeżeli wniesiono skargę na postanowienie referendarza sądowego wydane na 
podstawie art. 395 § 2 Kodeksu postępowania cywilnego, ponowne wydanie 
postanowienia na tej podstawie przez referendarza sądowego nie jest dopuszczalne. 
1e. Sąd rozpoznaje skargę w składzie jednego sędziego jako sąd drugiej instancji. 
Po rozpoznaniu skargi sąd utrzymuje w mocy albo zmienia zaskarżone postanowienie. 
2. Zastępca sędziego-komisarza wykonuje czynności sędziego-komisarza, jeżeli 
ustawa tak stanowi oraz w czasie trwania przemijającej przeszkody do wykonywania 
tych czynności przez sędziego-komisarza. 
3. W szczególnie uzasadnionych przypadkach, również po ogłoszeniu upadłości, 
sąd może wskazać, że czynności sędziego-komisarza może wykonywać więcej niż 
jeden zastępca sędziego-komisarza. Przepis art. 51 ust. 1 pkt 6 stosuje się. 
4. Do zastępcy sędziego-komisarza przepisy dotyczące sędziego-komisarza 
stosuje się odpowiednio. 
5. W czasie trwania przemijającej przeszkody do wykonywania czynności przez 
sędziego-komisarza i jego zastępcę czynności wykonuje jako sędzia-komisarz 
wyznaczony sędzia, do którego przepisy o czynnościach sędziego-komisarza stosuje 
się odpowiednio. 
6. Jeżeli do wykonania określonej czynności właściwy jest sędzia-komisarz, 
a czynność ta ma być wykonana po dniu zakończenia postępowania albo 
uprawomocnienia się postanowienia o umorzeniu postępowania, właściwy do jej 
wykonania jest sąd w składzie jednoosobowym.

***
## Art. 152. {#art-152}

1. Sędzia-komisarz kieruje tokiem postępowania upadłościowego, 
sprawuje nadzór nad czynnościami syndyka, oznacza czynności, których 
wykonywanie przez syndyka jest niedopuszczalne bez jego zezwolenia lub bez 
zezwolenia rady wierzycieli, jak również zwraca uwagę na popełnione przez syndyka 
uchybienia. 
2. Sędzia-komisarz pełni ponadto inne czynności określone w ustawie. 
3. Sędzia-komisarz i syndyk mogą porozumiewać się w sprawach dotyczących 
postępowania upadłościowego bezpośrednio oraz z użyciem środków bezpośredniego 
porozumiewania się na odległość, w szczególności przez telefon, faks lub pocztę 
elektroniczną. 
4. Jeżeli czynność, do której wykonania właściwy jest sędzia-komisarz, ma być 
wykonana po dniu uprawomocnienia się postanowienia o stwierdzeniu zakończenia 
albo umorzeniu postępowania, właściwy do jej wykonania jest sąd. 

©Kancelaria Sejmu 
 
 
 
s. 60/224 
 
2025-09-11

***
## Art. 153. {#art-153}

Skargi 
na 
czynności 
komornika 
rozpoznaje 
w postępowaniu 
upadłościowym sędzia-komisarz.

***
## Art. 154. {#art-154}

Sędzia-komisarz w zakresie swych czynności ma prawa i obowiązki 
sądu i przewodniczącego.

***
## Art. 155. {#art-155}

1. Organy administracji publicznej obowiązane są udzielać pomocy 
sędziemu-komisarzowi w wykonywaniu jego czynności. 
2. (uchylony) 
DZIAŁ II 
Syndyk i zastępca syndyka 
(oznaczenie i tytuł rozdziału 1 – uchylone)

***
## Art. 156. {#art-156}

1. W przypadku ogłoszenia upadłości powołuje się syndyka. 
2. (uchylony) 
3. (uchylony) 
4. Syndyk niezwłocznie, nie później niż wraz z podjęciem pierwszej czynności 
przed sądem lub sędzią-komisarzem, składa do akt postępowania dokument 
potwierdzający zawarcie umowy ubezpieczenia odpowiedzialności cywilnej za 
szkody wyrządzone w związku z pełnieniem funkcji. Koszty ubezpieczenia nie 
stanowią kosztów postępowania upadłościowego i nie podlegają zwrotowi z masy 
upadłości. 
5. (uchylony)

***
## Art. 1561. {#art-1561}

(uchylony)

***
## Art. 157. {#art-157}

1. Funkcję syndyka może pełnić osoba fizyczna, która posiada pełną 
zdolność do czynności prawnych i licencję doradcy restrukturyzacyjnego oraz ma 
konto doradcy restrukturyzacyjnego w systemie teleinformatycznym obsługującym 
postępowanie sądowe. 
2. Funkcję syndyka może również pełnić spółka handlowa, której wspólnicy 
ponoszący odpowiedzialność za zobowiązania spółki bez ograniczenia całym swoim 
majątkiem albo członkowie zarządu reprezentujący spółkę posiadają licencję, o której 
mowa w ust. 1, oraz która ma konto doradcy restrukturyzacyjnego w systemie tele-
informatycznym obsługującym postępowanie sądowe. 
2a. Spółka handlowa, której wspólnicy ponoszący odpowiedzialność za 
zobowiązania spółki bez ograniczenia całym swoim majątkiem albo członkowie 

©Kancelaria Sejmu 
 
 
 
s. 61/224 
 
2025-09-11 
 
zarządu reprezentujący spółkę posiadają licencję, o której mowa w ust. 1, i która 
zamierza wykonywać obowiązki w postępowaniach upadłościowych, zakłada konto 
doradcy 
restrukturyzacyjnego 
w systemie 
teleinformatycznym 
obsługującym 
postępowanie sądowe. 
3. Zasady i tryb wydawania licencji, o której mowa w ust. 1, określi odrębna 
ustawa. 
4. (uchylony) 
5. W postanowieniu, w którym wyznacza się syndyka, wskazuje się numer 
licencji doradcy restrukturyzacyjnego syndyka lub numer w Krajowym Rejestrze 
Sądowym wyznaczonej do pełnienia funkcji syndyka spółki. 
6. Jeżeli ustawa wymaga, aby osoba wyznaczona do pełnienia funkcji syndyka 
posiadała także tytuł kwalifikowanego doradcy restrukturyzacyjnego, funkcję syndyka 
może również pełnić spółka handlowa, której wspólnicy ponoszący odpowiedzialność 
za zobowiązania spółki bez ograniczenia całym swoim majątkiem albo członkowie 
zarządu reprezentujący spółkę posiadają także tytuł kwalifikowanego doradcy 
restrukturyzacyjnego.

***
## Art. 1571. {#art-1571}

1. Sąd wyznacza syndyka, biorąc pod uwagę liczbę spraw, w których 
osoba posiadająca licencję doradcy restrukturyzacyjnego pełni funkcję nadzorcy 
sądowego lub zarządcy w postępowaniach restrukturyzacyjnych lub syndyka 
w innych postępowaniach upadłościowych, a także jej doświadczenie i dodatkowe 
kwalifikacje. 
2. Przepis ust. 1 stosuje się odpowiednio w przypadku wyznaczania syndyka 
będącego spółką handlową. 
3. W przypadku: 
- 1) przedsiębiorcy, który w co najmniej jednym z dwóch ostatnich lat obrotowych: 
  - a) zatrudniał średniorocznie 250 lub więcej pracowników lub 
  - b) osiągnął roczny obrót netto ze sprzedaży towarów, wyrobów i usług oraz 
operacji finansowych przekraczający równowartość w złotych 50 milionów 
euro, lub 
  - c) osiągnął sumy aktywów bilansu sporządzonego na koniec jednego z tych 
lat, które przekroczyły równowartość w złotych 43 milionów euro, 
- 2) spółki o istotnym znaczeniu dla gospodarki państwa, umieszczonej w wykazie 
określonym w przepisach wykonawczych wydanych na podstawie art. 31 ust. 2 

©Kancelaria Sejmu 
 
 
 
s. 62/224 
 
2025-09-11 
 
ustawy z dnia 16 grudnia 2016 r. o zasadach zarządzania mieniem państwowym 
(Dz. U. z 2024 r. poz. 125, 834, 1823, 1897 i 1940), 
- 3) przedsiębiorcy realizujący zadania na rzecz Sił Zbrojnych, o których mowa 
w art. 648 ustawy z dnia 11 marca 2022 r. o obronie Ojczyzny (Dz. U. z 2024 
r. poz. 248, z późn. zm.4)) 
– sąd wyznacza do pełnienia funkcji syndyka osobę posiadającą licencję doradcy 
restrukturyzacyjnego z tytułem kwalifikowanego doradcy restrukturyzacyjnego. 
Art. 157a. 1. Syndykiem nie może być osoba fizyczna lub spółka handlowa, 
która: 
- 1) jest wierzycielem lub dłużnikiem upadłego, małżonkiem, wstępnym, zstępnym, 
rodzeństwem, powinowatym upadłego lub jego wierzyciela w tej samej linii czy 
stopniu, osobą pozostającą z nim w stosunku przysposobienia lub małżonkiem 
tej osoby albo osobą pozostającą z upadłym w faktycznym związku, prowadzącą 
z nim wspólnie gospodarstwo domowe; 
- 2) jest lub była zatrudniona przez upadłego na podstawie stosunku pracy albo 
wykonywała pracę lub świadczyła usługi na rzecz upadłego na podstawie innego 
stosunku prawnego; 
- 3) jest lub była członkiem organu, prokurentem lub pełnomocnikiem upadłego, albo 
jest lub w okresie dwóch lat przed dniem złożenia wniosku o ogłoszenie 
upadłości była wspólnikiem albo akcjonariuszem posiadającym udziały albo 
akcje w wysokości wyższej niż 5 % kapitału zakładowego dłużnika lub 
wierzyciela, a w przypadku prostej spółki akcyjnej – więcej niż 5 % akcji tej 
spółki; 
- 4) jest lub była spółką powiązaną z upadłym lub jest lub była członkiem organu, 
prokurentem lub pełnomocnikiem takiej spółki albo jest lub w okresie dwóch lat 
przed dniem złożenia wniosku o ogłoszenie upadłości była wspólnikiem albo 
akcjonariuszem posiadającym udziały albo akcje w wysokości wyższej niż 5 % 
kapitału zakładowego spółki powiązanej z dłużnikiem, a w przypadku prostej 
spółki akcyjnej – więcej niż 5 % akcji tej spółki; 
- 5) pełniła funkcję nadzorcy lub zarządcy w prowadzonym wcześniej wobec 
upadłego postępowaniu restrukturyzacyjnym. 
- 4) Zmiany tekstu jednolitego wymienionej ustawy zostały ogłoszone w Dz. U. z 2024 r. poz. 834, 1089, 
1222, 1248, 1585, 1871 i 1907 oraz z 2025 r. poz. 39. 

©Kancelaria Sejmu 
 
 
 
s. 63/224 
 
2025-09-11 
 
2. Syndyk oraz jego małżonek, wstępny, zstępny, rodzeństwo, osoba pozostająca 
z nim w stosunku przysposobienia lub małżonek takiej osoby, jak również osoba 
pozostająca z nim w faktycznym związku, prowadząca z nim wspólnie gospodarstwo 
domowe, nie mogą nabyć rzeczy ani praw pochodzących ze sprzedaży dokonanej 
w postępowaniu upadłościowym, w którym syndyk pełni albo pełnił tę funkcję. 
2a. Do innych umów zawieranych przez syndyka w toku postępowania przepis 
ust. 2 stosuje się odpowiednio, chyba że sędzia-komisarz postanowi inaczej. 
3. Przeszkoda, o której mowa w ust. 1 pkt 1, trwa mimo ustania małżeństwa lub 
przysposobienia. 
4. Syndyk niezwłocznie, nie później niż wraz z podjęciem pierwszej czynności 
przed sądem lub sędzią-komisarzem, składa do akt postępowania oświadczenie, że nie 
zachodzą przeszkody, o których mowa w ust. 1.

***
## Art. 158. {#art-158}

(uchylony)

***
## Art. 159. {#art-159}

1. Na wniosek syndyka lub z urzędu sędzia-komisarz może powołać 
zastępcę syndyka, jeżeli jest to potrzebne, zwłaszcza w przypadku wykonywania 
czynności w innym okręgu sądowym. 
2. Sędzia-komisarz określa zakres czynności zastępcy syndyka. 
3. Do zastępcy syndyka przepisy ustawy o syndyku stosuje się odpowiednio.

***
## Art. 160. {#art-160}

1. W sprawach dotyczących masy upadłości syndyk dokonuje 
czynności w imieniu własnym na rachunek upadłego. 
2. Syndyk nie odpowiada za zobowiązania zaciągnięte w sprawach dotyczących 
masy upadłości. 
3. Syndyk odpowiada za szkodę wyrządzoną na skutek nienależytego 
wykonywania obowiązków. 
Art. 160a. Syndyk na bieżąco rejestruje w systemie teleinformatycznym 
obsługującym postępowanie sądowe wpływy i wydatki masy upadłości.

***
## Art. 161. {#art-161}

1. Syndyk może udzielać pełnomocnictw do dokonywania czynności 
prawnych. Może też udzielać pełnomocnictw procesowych w postępowaniach 
sądowych, 
administracyjnych, 
sądowoadministracyjnych 
i przed 
sądami 
polubownymi. 
2. Za szkodę wyrządzoną przez pełnomocników syndyk odpowiada jak za 
działanie własne. 

©Kancelaria Sejmu 
 
 
 
s. 64/224 
 
2025-09-11

***
## Art. 162. {#art-162}

1. Wynagrodzenie syndyka ustala się jako sumę pięciu części 
składowych, w granicach od dwukrotności do dwustusześćdziesięciokrotności 
podstawy wynagrodzenia. 
2. Części składowe wynagrodzenia ustala się według następujących zasad: 
- 1) część zależna od sumy wypłaconej wierzycielom w ramach wykonania planów 
podziału powiększonej o koszty rozwiązania stosunków pracy z pracownikami 
pozostającymi w zatrudnieniu w dniu ogłoszenia upadłości: 
  - a) jedna podstawa wynagrodzenia – dla sumy do 100 000,00 zł, 
  - b) cztery podstawy wynagrodzenia – dla sumy od 100 000,01 zł do 
1 000 000,00 zł, 
  - c) dziesięć podstaw wynagrodzenia – dla sumy od 1 000 000,01 zł do 
10 000 000,00 zł, 
  - d) trzydzieści podstaw wynagrodzenia – dla sumy od 10 000 000,01 zł do 
100 000 000,00 zł, 
  - e) osiemdziesiąt podstaw wynagrodzenia – dla sumy przekraczającej 
100 000 000,00 zł; 
- 2) część zależna od liczby pracowników zatrudnionych w dniu ogłoszenia 
upadłości: 
  - a) połowa podstawy wynagrodzenia – od 1 do 10 pracowników, 
  - b) trzy podstawy wynagrodzenia – od 11 do 50 pracowników, 
  - c) dziesięć podstaw wynagrodzenia – od 51 do 200 pracowników, 
  - d) dwadzieścia podstaw wynagrodzenia – od 201 do 400 pracowników, 
  - e) trzydzieści podstaw wynagrodzenia – powyżej 400 pracowników; 
- 3) część zależna od liczby wierzycieli biorących udział w postępowaniu: 
  - a) połowa podstawy wynagrodzenia – do 10 wierzycieli, 
  - b) dwie podstawy wynagrodzenia – od 11 do 100 wierzycieli, 
  - c) cztery podstawy wynagrodzenia – od 101 do 500 wierzycieli, 
  - d) dwadzieścia podstaw wynagrodzenia – od 501 do 1000 wierzycieli, 
  - e) czterdzieści podstaw wynagrodzenia – powyżej 1000 wierzycieli; 
- 4) część zależna od czasu trwania postępowania upadłościowego od dnia ogłoszenia 
upadłości do dnia wykonania ostatecznego planu podziału: 
  - a) dla postępowań, w których suma podstaw wynagrodzenia określonych 
w pkt 1–3 nie przekracza ośmiokrotności: 

©Kancelaria Sejmu 
 
 
 
s. 65/224 
 
2025-09-11 
 
– 
cztery podstawy wynagrodzenia, jeżeli postępowanie trwało nie dłużej 
niż sześć miesięcy, 
– 
dwie podstawy wynagrodzenia, jeżeli postępowanie trwało powyżej 
sześciu miesięcy, ale nie dłużej niż dwanaście miesięcy, 
– 
jeżeli postępowanie trwało powyżej dwunastu miesięcy, wynagrodzenia 
nie podwyższa się o ten składnik, 
  - b) dla postępowań, w których suma podstaw wynagrodzenia określonych 
w pkt 1–3 przekracza 
ośmiokrotność 
i nie 
jest 
większa 
niż 
czterdziestokrotność: 
– 
osiem podstaw wynagrodzenia, jeżeli postępowanie trwało nie dłużej 
niż dwanaście miesięcy, 
– 
cztery podstawy wynagrodzenia, jeżeli postępowanie trwało powyżej 
dwunastu miesięcy, ale nie dłużej niż dwadzieścia cztery miesiące, 
– 
jeżeli postępowanie trwało powyżej dwudziestu czterech miesięcy, 
wynagrodzenia nie podwyższa się o ten składnik, 
  - c) dla postępowań, w których suma podstaw wynagrodzenia określonych 
w pkt 1–3 przekracza czterdziestokrotność: 
– 
czterdzieści podstaw wynagrodzenia, jeżeli postępowanie trwało nie 
dłużej niż osiemnaście miesięcy, 
– 
dwadzieścia podstaw wynagrodzenia, jeżeli postępowanie trwało 
powyżej osiemnastu miesięcy, ale nie dłużej niż trzydzieści sześć 
miesięcy, 
– 
jeżeli postępowanie trwało powyżej trzydziestu sześciu miesięcy, 
wynagrodzenia nie podwyższa się o ten składnik; 
- 5) część ustalana przez sąd do siedemdziesięciu podstaw wynagrodzenia 
w zależności od stopnia trudności prowadzonego postępowania i jego 
efektywności, w szczególności od skomplikowania sytuacji prawnej i faktycznej 
masy upadłości, rozproszenia majątku oraz optymalizacji kosztów postępowania. 
3. Przez podstawę wynagrodzenia należy rozumieć przeciętne miesięczne 
wynagrodzenie w sektorze przedsiębiorstw bez wypłat nagród z zysku w trzecim 
kwartale roku poprzedniego, ogłoszone przez Prezesa Głównego Urzędu 
Statystycznego. 

©Kancelaria Sejmu 
 
 
 
s. 66/224 
 
2025-09-11

***
## Art. 163. {#art-163}

1. Sąd ustala wynagrodzenie wstępne syndyka na wniosek syndyka, 
złożony po złożeniu planu likwidacyjnego, w terminie trzydziestu dni od dnia złożenia 
wniosku. 
2. We wniosku o ustalenie wynagrodzenia wstępnego podaje się aktualne, 
według stanu na dzień złożenia wniosku, informacje o: 
- 1) przewidywanej sumie zaspokojenia wierzycieli w ramach poszczególnych 
kategorii zaspokojenia; 
- 2) liczbie zatrudnionych pracowników; 
- 3) liczbie wierzycieli; 
- 4) przewidywanym zgodnie z planem likwidacyjnym czasie trwania postępowania; 
- 5) stopniu skomplikowania sytuacji prawnej i faktycznej masy upadłości, 
rozproszeniu i stanie majątku oraz innych okolicznościach mających znaczenie 
dla nakładu pracy syndyka. 
3. Ustalając wynagrodzenie wstępne, sąd stosuje zasady określone w art. 162, 
biorąc pod uwagę wskaźniki i okoliczności podane we wniosku oraz 
prawdopodobieństwo realizacji planu likwidacyjnego zgodnie z jego założeniami. 
4. Na postanowienie w przedmiocie ustalenia wynagrodzenia wstępnego 
zażalenie przysługuje wyłącznie upadłemu i syndykowi.

***
## Art. 164. {#art-164}

1. Po ustaleniu wynagrodzenia wstępnego syndyk pobiera z masy 
upadłości zaliczki w wysokości do 75 % wynagrodzenia wstępnego w czterech ratach: 
- 1) 10 % – po uprawomocnieniu się postanowienia o wynagrodzeniu wstępnym; 
- 2) 25 % – po złożeniu listy wierzytelności; 
- 3) 15 % – po złożeniu pierwszego planu podziału; 
- 4) 25 % – po przeprowadzeniu pełnej likwidacji masy upadłości. 
2. Zaliczkę na wynagrodzenie wypłaca się na podstawie rachunku wystawionego 
przez syndyka.

***
## Art. 165. {#art-165}

1. Sąd wydaje postanowienie w przedmiocie wynagrodzenia 
ostatecznego na wniosek syndyka złożony w terminie tygodnia od dnia złożenia 
ostatecznego planu podziału albo doręczenia mu postanowienia o odwołaniu lub 
zmianie syndyka albo umorzeniu postępowania. Złożenie wniosku z uchybieniem 
terminu skutkuje przyznaniem wynagrodzenia ostatecznego w wysokości dotychczas 
pobranych zaliczek, chyba że sąd postanowi o przyznaniu niższego wynagrodzenia 
i zwrocie części zaliczek. Do dnia wydania postanowienia w przedmiocie 

©Kancelaria Sejmu 
 
 
 
s. 67/224 
 
2025-09-11 
 
wynagrodzenia ostatecznego syndyk może złożyć wniosek o przywrócenie terminu, 
wykazując, że uchybienie terminu nastąpiło bez jego winy. 
2. We wniosku o przyznanie wynagrodzenia ostatecznego podaje się aktualne, 
według stanu na dzień złożenia wniosku, informacje o: 
- 1) sumie wypłaconej wierzycielom w ramach wykonania planów podziału oraz 
o poniesionych z masy upadłości kosztach rozwiązania stosunków pracy 
z pracownikami pozostającymi w zatrudnieniu na dzień ogłoszenia upadłości; 
- 2) liczbie pracowników zatrudnionych w dniu ogłoszenia upadłości; 
- 3) liczbie wierzycieli, którzy zgłosili swoje wierzytelności, oraz o liczbie 
wierzycieli umieszczonych na liście wierzytelności z urzędu; 
- 4) czasie trwania postępowania; 
- 5) trudnościach prowadzonego postępowania i jego efektywności, 
w tym 
informacje o wysokości kosztów postępowania i innych zobowiązaniach masy 
upadłości.

***
## Art. 166. {#art-166}

1. Sąd niezwłocznie doręcza odpis wniosku syndyka o przyznanie 
wynagrodzenia ostatecznego upadłemu i członkom rady wierzycieli albo informuje 
ich, że syndyk nie złożył takiego wniosku w terminie. Upadły i członkowie rady 
wierzycieli mogą w terminie tygodnia zająć stanowisko w sprawie wniosku, o czym 
należy ich pouczyć. 
2. Sąd ustala wynagrodzenie ostateczne niezwłocznie po przedstawieniu 
stanowisk, o których mowa w ust. 1, albo bezskutecznym upływie terminu na ich 
przedstawienie. 
3. Syndyk jest uprawniony do pobrania wynagrodzenia w wysokości ustalonej 
w prawomocnym 
postanowieniu 
o ustaleniu 
wynagrodzenia 
ostatecznego 
niezwłocznie po wydaniu postanowienia o zatwierdzeniu ostatecznego planu podziału. 
4. Jeżeli syndyk jest obowiązany wydać dłużnikowi jego majątek na skutek 
uprawomocnienia się postanowienia o umorzeniu lub zakończeniu postępowania, 
a postanowienie o przyznaniu wynagrodzenia ostatecznego nie jest jeszcze 
prawomocne, kwota wynagrodzenia podlega złożeniu do depozytu sądowego, 
w wysokości różnicy między wynagrodzeniem wnioskowanym a sumą pobranych 
zaliczek, chyba że sąd, mając na względzie ważny interes dłużnika, postanowi 
o ograniczeniu wysokości zabezpieczenia do kwoty ustalonej w nieprawomocnym 
postanowieniu o przyznaniu wynagrodzenia ostatecznego. Sąd postanowi o wydaniu 
syndykowi kwoty złożonej do depozytu sądowego na wniosek syndyka na podstawie 

©Kancelaria Sejmu 
 
 
 
s. 68/224 
 
2025-09-11 
 
prawomocnego 
postanowienia 
o ustaleniu 
wynagrodzenia 
ostatecznego. 
W przedmiocie złożenia i wydania z depozytu orzeka sąd w składzie jednoosobowym. 
5. Jeżeli wynagrodzenie ostateczne ustalono w wysokości niższej niż 75 % 
wynagrodzenia wstępnego, syndyk jest obowiązany zwrócić do masy upadłości 
różnicę między sumą pobranych zaliczek a wynagrodzeniem ostatecznym. W 
postanowieniu o przyznaniu wynagrodzenia ostatecznego sąd określi kwotę 
podlegającą zwrotowi. 
6. Na postanowienie sądu w przedmiocie ustalenia wynagrodzenia ostatecznego 
i zwrotu zaliczek przysługuje zażalenie. Zażalenie przysługuje również syndykowi. 
7. Prawomocne postanowienie o przyznaniu wynagrodzenia ostatecznego 
stanowi tytuł egzekucyjny przeciwko syndykowi oraz upadłemu.

***
## Art. 167. {#art-167}

1. Jeżeli syndyk został odwołany lub w przypadku zmiany syndyka 
przed dniem złożenia sprawozdania ostatecznego, zachowuje on prawo do zaliczek 
pobranych zgodnie z art. 164 do czasu ustalenia wynagrodzenia ostatecznego. 
2. Ustalając wynagrodzenie ostateczne w postępowaniu upadłościowym, 
w którym funkcję pełniło kilku syndyków, sąd rozdziela wynagrodzenie między nich 
proporcjonalnie do czasu pełnienia funkcji w postępowaniu, przy czym sąd może 
zdecydować o odstąpieniu od proporcjonalnego podziału, w szczególności jeżeli jest 
to uzasadnione zróżnicowanym wpływem poszczególnych syndyków na zaistnienie 
okoliczności, o której mowa w art. 162 ust. 2 pkt 1, oraz ich nakładem pracy. 
3. W przypadku umorzenia postępowania upadłościowego albo jego uchylenia 
sąd przyznaje syndykowi wynagrodzenie ostateczne, mając na uwadze okoliczności, 
o których mowa w art. 162, nakład pracy syndyka i czas trwania postępowania. 
4. Jeżeli przyznana syndykowi część wynagrodzenia ostatecznego przekracza 
wartość pobranych zaliczek, przepis art. 166 ust. 5 stosuje się odpowiednio. 
Art. 167a. Wynagrodzenie i zaliczki na wynagrodzenie syndyka obowiązanego 
do rozliczenia podatku od towarów i usług podwyższa się o kwotę podatku od 
towarów i usług. 
Art. 167b. 1. W przypadku śmierci syndyka roszczenie o należne mu 
wynagrodzenie należy do spadku po nim. 
2. O wynagrodzeniu syndyka w przypadku, o którym mowa w ust. 1, orzeka sąd 
z urzędu. 

©Kancelaria Sejmu 
 
 
 
s. 69/224 
 
2025-09-11

***
## Art. 168. {#art-168}

1. Syndyk składa sędziemu-komisarzowi w terminach przez niego 
wyznaczonych, przynajmniej co trzy miesiące, sprawozdanie, które obejmuje raport 
ze zmian w stanie i składzie masy upadłości w okresie sprawozdawczym, w tym stan 
środków pieniężnych na początek i koniec okresu sprawozdawczego, raport ze zmian 
stanu wierzytelności oraz niezaspokojonych przez syndyka zobowiązań masy 
upadłości w okresie sprawozdawczym, raport z wpływów i wydatków w okresie 
sprawozdawczym, informację o stanie środków pieniężnych w kasie i na rachunkach 
bankowych na początek i koniec okresu sprawozdawczego oraz opis czynności 
syndyka w okresie sprawozdawczym z uzasadnieniem. 
2. Zastępca syndyka, jeżeli został ustanowiony, składa syndykowi sprawozdanie 
w zakresie swoich czynności, obejmujące elementy wskazane w ust. 1, w terminach 
wyznaczonych przez syndyka. Syndyk składa to sprawozdanie wraz ze swoim 
sprawozdaniem sędziemu-komisarzowi. 
3. (uchylony) 
4. Po zakończeniu pełnienia funkcji syndyk i jego zastępcy składają sędziemu-
-komisarzowi sprawozdanie ostateczne, które obejmuje raport ze zmian w stanie 
i składzie masy upadłości w okresie postępowania upadłościowego ze wskazaniem 
łącznej kwoty uzyskanej z likwidacji masy upadłości, raport ze zmian stanu 
wierzytelności w okresie postępowania upadłościowego ze wskazaniem stopnia 
zaspokojenia wierzycieli w poszczególnych kategoriach oraz niezaspokojonych przez 
syndyka zobowiązań masy upadłości, raport z wpływów i wydatków w okresie 
postępowania upadłościowego oraz opis czynności syndyka w okresie postępowania 
upadłościowego z uzasadnieniem. Sprawozdanie ostateczne obejmuje również 
wskazanie 
miejsca 
zarchiwizowania 
dokumentów 
upadłego. 
O niezłożeniu 
sprawozdania ostatecznego, mimo wezwania do jego złożenia w terminie tygodnia, 
sędzia-komisarz zawiadamia Ministra Sprawiedliwości. 
5. W terminie 30 dni upadły i wierzyciele mogą wnosić zarzuty dotyczące 
wydatków poniesionych przez syndyka lub zastępcę syndyka, wskazanych 
w sprawozdaniach, o których mowa w ust. 1 i 2. Zarzuty wniesione po upływie 
terminu lub nieodpowiadające wymogom formalnym pisma procesowego pozostawia 
się bez rozpoznania. Przepisu art. 130 § 1 Kodeksu postępowania cywilnego nie 
stosuje się. 
5a. (uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 70/224 
 
2025-09-11 
 
5b. Sędzia-komisarz w wyniku rozpoznania zarzutów lub z urzędu w terminie 
dwóch miesięcy od dnia złożenia sprawozdania odmawia uznania w całości lub części 
określonego wydatku oraz orzeka o zwrocie do masy upadłości kwoty poniesionej 
z tytułu wydatku, którego uznania odmówiono. 
5c. Sędzia-komisarz zatwierdza sprawozdanie ostateczne albo odmawia jego 
zatwierdzenia w całości lub części, jeżeli syndyk dokonał czynności niezgodnych 
z prawem lub skutkujących pokrzywdzeniem wierzycieli lub upadłego albo mimo 
wezwania 
nie 
wykonał 
w zakreślonym 
terminie 
wszystkich 
obowiązków. 
Prawomocne postanowienie o odmowie zatwierdzenia sprawozdania ostatecznego 
w całości lub części doręcza się Ministrowi Sprawiedliwości. 
5d. Na postanowienie sędziego-komisarza, o którym mowa w ust. 5b i 5c, oraz 
na postanowienie o oddaleniu zarzutów przysługuje zażalenie. Zażalenie przysługuje 
również syndykowi. Prawomocne postanowienie zobowiązujące syndyka do zwrotu 
do masy upadłości kwoty poniesionej z tytułu wydatku, którego uznania odmówiono, 
stanowi tytuł egzekucyjny przeciwko syndykowi. 
6. Do sprawozdań, o których mowa w ust. 1 i 4, nie stosuje się przepisów 
o rachunkowości. 
7. (uchylony) 
8. (uchylony)

***
## Art. 169. {#art-169}

1. Syndyk wykonuje obowiązki sprawozdawcze ciążące na upadłym. 
Syndyk nie odpowiada za opóźnienia w realizacji tych obowiązków spowodowane 
nieprzekazaniem mu dokumentacji lub przekazaniem dokumentacji nierzetelnej lub 
niekompletnej. 
2. Obowiązek przekazywania informacji, o którym mowa w art. 56 ust. 1 pkt 2 i 
ust. 7 oraz art. 70 ustawy z dnia 29 lipca 2005 r. o ofercie publicznej i warunkach 
wprowadzania instrumentów finansowych do zorganizowanego systemu obrotu oraz 
o spółkach publicznych, a także art. 17 ust. 1 i 2 oraz art. 19 ust. 3 rozporządzenia 
Parlamentu Europejskiego i Rady (UE) nr 596/2014 z dnia 16 kwietnia 2014 r. 
w sprawie nadużyć na rynku (rozporządzenie w sprawie nadużyć na rynku) oraz 
uchylającego dyrektywę 2003/6/WE Parlamentu Europejskiego i Rady i dyrektywy 
Komisji 
2003/124/WE, 
2003/125/WE 
i 2004/72/WE 
(Dz. Urz. 
UE L 173 

©Kancelaria Sejmu 
 
 
 
s. 71/224 
 
2025-09-11 
 
z 12.06.2014, str. 1, z późn. zm.5)), zwanego dalej „rozporządzeniem nr 596/2014”, 
ciąży na syndyku. 
3. Upadły jest obowiązany do natychmiastowego udostępniania syndykowi 
posiadanych informacji i dokumentów pozwalających na wykonanie obowiązku, 
o którym mowa w art. 56 ust. 1 pkt 2 i ust. 7 oraz art. 70 ustawy z dnia 29 lipca 2005 r. 
o ofercie publicznej i warunkach wprowadzania instrumentów finansowych do 
zorganizowanego systemu obrotu oraz o spółkach publicznych, a także art. 17 ust. 1 
i 2 oraz art. 19 ust. 3 rozporządzenia nr 596/2014. Jeżeli dla upadłego został 
ustanowiony kurator w postępowaniu upadłościowym, obowiązek ten ciąży na 
kuratorze. 
4. Syndyk prowadzący przedsiębiorstwo upadłego może prowadzić działalność 
wymagającą koncesji, licencji albo zezwolenia, chyba że co innego wynika 
z odrębnych ustaw. 
Art. 169a. 1. Sędzia-komisarz upomina syndyka, który nie wykonuje albo 
nienależycie wykonuje swoje obowiązki. 
2. W przypadku istotnego uchybienia albo braku poprawy w wykonywaniu 
obowiązków mimo upomnienia, sędzia-komisarz nakłada na syndyka grzywnę 
w wysokości od 1000 zł do 30 000 zł, biorąc pod uwagę stopień oraz wagę uchybienia.

***
## Art. 170. {#art-170}

1. 
W przypadku 
rażącego 
uchybienia 
lub 
braku 
poprawy 
w wykonywaniu swoich obowiązków mimo nałożonej grzywny lub w przypadku 
niewykonania obowiązków, o których mowa w art. 156 ust. 4 lub art. 157a ust. 4, 
mimo wezwania do ich spełnienia w terminie tygodnia sąd odwołuje syndyka. 
1a. Wniosek o odwołanie syndyka z przyczyn, o których mowa w ust. 1, może 
złożyć prokurator. 
2. Przed odwołaniem syndyka sąd jest obowiązany do jego wysłuchania. 
W przypadku uprawdopodobnienia podstaw do odwołania syndyka sąd może do czasu 
wydania postanowienia w przedmiocie odwołania zawiesić syndyka w wykonywaniu 
jego czynności, ustanawiając tymczasowego syndyka, do którego przepisy o syndyku 
stosuje się odpowiednio. 
3. Sąd zmienia syndyka na jego wniosek albo na podstawie uchwały rady 
wierzycieli podjętej w trybie określonym w art. 207a. 
- 5) Zmiany wymienionego rozporządzenia zostały ogłoszone w Dz. Urz. UE L 171 z 29.06.2016, str. 1, 
Dz. Urz. UE L 175 z 30.06.2016, str. 1 oraz Dz. Urz. UE L 287 z 21.10.2016, str. 320. 

©Kancelaria Sejmu 
 
 
 
s. 72/224 
 
2025-09-11 
 
4. W przypadku śmierci syndyka albo utraty przez niego pełnej zdolności do 
czynności prawnych albo jeżeli w składzie organów spółki będącej syndykiem 
zachodzą braki uniemożliwiające jej działanie, sąd stwierdza wygaśnięcie funkcji 
syndyka. W postanowieniu sąd wskazuje datę śmierci syndyka. 
5. Sąd zmienia syndyka w przypadku cofnięcia albo zawieszenia syndykowi 
praw wynikających z licencji doradcy restrukturyzacyjnego, a jeżeli syndykiem jest 
spółka – w przypadku cofnięcia albo zawieszenia praw wynikających z licencji 
doradcy restrukturyzacyjnego wspólnikom ponoszącym za zobowiązania spółki 
odpowiedzialność bez ograniczenia całym swoim majątkiem albo członkom zarządu 
reprezentującym taką spółkę. 
6. Odpis prawomocnego postanowienia o odwołaniu syndyka lub stwierdzeniu 
wygaśnięcia funkcji syndyka doręcza się Ministrowi Sprawiedliwości. 
7. Postanowienie o powołaniu syndyka albo organu, do którego przepisy 
o syndyku stosuje się odpowiednio, a także prawomocne postanowienie o zmianie, 
odwołaniu, zawieszeniu albo stwierdzeniu wygaśnięcia funkcji syndyka albo organu, 
do którego przepisy o syndyku stosuje się odpowiednio, obwieszcza się.

***
## Art. 171. {#art-171}

1. W przedmiocie odwołania lub zmiany zastępcy syndyka orzeka 
sędzia-komisarz. Sędzia-komisarz odwołuje zastępcę syndyka również wówczas, 
jeżeli jego dalszy udział w postępowaniu nie jest potrzebny. 
2. (uchylony) 
3. Na postanowienie, o którym mowa w ust. 1 w zdaniu drugim, zażalenie nie 
przysługuje.

***
## Art. 172. {#art-172}

1. Na postanowienie w przedmiocie odwołania syndyka oraz na 
postanowienie sędziego-komisarza w przedmiocie upomnienia lub nałożenia grzywny 
na syndyka przysługuje zażalenie. Zażalenie przysługuje również syndykowi. 
Przepisu art. 222 ust. 1 zdanie drugie nie stosuje się. 
2. Sąd wyznacza syndyka po uprawomocnieniu się postanowienia o odwołaniu, 
o którym mowa w ust. 1. Do czasu wyznaczenia syndyka sąd wyznacza syndyka 
tymczasowego, do którego przepisy o syndyku stosuje się odpowiednio. 
(oznaczenie i tytuł rozdziału 2 – uchylone)

***
## Art. 173. {#art-173}

Syndyk niezwłocznie obejmuje majątek upadłego, zarządza nim, 
zabezpiecza go przed zniszczeniem, uszkodzeniem lub zabraniem go przez osoby 
postronne oraz przystępuje do jego likwidacji. 

©Kancelaria Sejmu 
 
 
 
s. 73/224 
 
2025-09-11

***
## Art. 174. {#art-174}

1. Jeżeli syndyk napotyka przeszkody ze strony upadłego przy 
obejmowaniu majątku upadłego, wprowadzenia syndyka w posiadanie majątku 
upadłego 
dokonuje 
komornik 
sądowy. 
Podstawę 
wprowadzenia 
stanowi 
postanowienie sądu o ogłoszeniu upadłości lub postanowienie o powołaniu syndyka 
bez potrzeby nadawania mu klauzuli wykonalności. 
2. Koszty wprowadzenia pokrywa tymczasowo Skarb Państwa. Koszty te 
stanowią koszt postępowania upadłościowego, a jeżeli upadły nie jest osobą fizyczną, 
koszty te obciążają osoby uprawnione do reprezentowania upadłego, które 
przeszkadzały w objęciu majątku. W przypadku niemożności ściągnięcia kosztów od 
osób zobowiązanych do ich zwrotu podlegają one zaspokojeniu z masy upadłości. 
Jeżeli działania utrudniające objęcie majątku przez syndyka podejmowało kilka osób 
uprawnionych do reprezentowania upadłego, koszty wprowadzenia obciążają te osoby 
solidarnie. 
3. O zwrocie kosztów, o których mowa w ust. 2, orzeka sędzia-komisarz. Na 
postanowienie sędziego-komisarza przysługuje zażalenie osobom zobowiązanym do 
zwrotu kosztów. 
4. Koszty, o których mowa w ust. 2, ściąga się od osób zobowiązanych do ich 
zwrotu w trybie egzekucji opłat sądowych.

***
## Art. 175. {#art-175}

Syndyk 
podejmuje 
niezbędne 
czynności 
celem 
ujawnienia 
postanowienia o ogłoszeniu upadłości w księdze wieczystej oraz w innych księgach 
i rejestrach, do których wpisany jest majątek upadłego.

***
## Art. 176. {#art-176}

1. Syndyk niezwłocznie zawiadamia o upadłości tych wierzycieli, 
których adresy są znane na podstawie ksiąg upadłego, a także komorników 
prowadzących postępowania egzekucyjne przeciwko upadłemu oraz małżonka 
upadłego. Do zawiadomienia syndyk załącza pouczenie o treści art. 220 ust. 2, 5 i 6. 
1a. W zawiadomieniu skierowanym do wierzycieli syndyk poucza ich o treści 
art. 54a, art. 216a–216ab, art. 235–237 i art. 239a–241, wskazuje sąd, do którego 
można zaskarżyć postanowienie o ogłoszeniu upadłości zgodnie z art. 54a ust. 1, imię 
i nazwisko albo nazwę syndyka, adres, na który należy dokonać zgłoszenia 
wierzytelności, o której mowa w art. 216aa ust. 1, termin, w którym należy dokonać 
tego zgłoszenia, albo sposób obliczenia tego terminu oraz podaje numer rachunku 
bankowego, na który należy wpłacić zryczałtowane koszty, o których mowa 
w art. 235 ust. 1. 

©Kancelaria Sejmu 
 
 
 
s. 74/224 
 
2025-09-11 
 
1b. W zawiadomieniu skierowanym do małżonka upadłego syndyk poucza go 
o treści art. 124–126. 
2. Syndyk zawiadamia placówki pocztowe w rozumieniu ustawy z dnia 
23 listopada 2012 r. – Prawo pocztowe (Dz. U. z 2023 r. poz. 1640 oraz z 2024 r. poz. 
467, 1222 i 1717) o ogłoszeniu upadłości. Placówki te doręczają syndykowi 
adresowane do upadłego przesyłki pocztowe. Syndyk, w terminie siedmiu dni od dnia 
otrzymania przesyłki, zawiadamia upadłego o otrzymaniu przesyłek pocztowych, 
które nie dotyczą masy upadłości lub których zatrzymanie nie jest potrzebne ze 
względu na zawarte w nich wiadomości, oraz umożliwia upadłemu odebranie tych 
przesyłek. Doręczenie przesyłki pocztowej dla upadłego uważa się za dokonane 
z upływem trzydziestu dni od dnia doręczenia przesyłki pocztowej syndykowi. 
2a. Syndyk zawiadamia o ogłoszeniu upadłości ministra właściwego do spraw 
informatyzacji, jeżeli upadły posiada adres do doręczeń elektronicznych, o którym 
mowa 
w art. 2 pkt 1 
ustawy 
z dnia 
18 listopada 
2020 r. 
o doręczeniach 
elektronicznych (Dz. U. z 2024 r. poz. 1045 i 1841). Operator wyznaczony oraz 
kwalifikowani dostawcy usług zaufania zapewniają, że korespondencja kierowana do 
upadłego na ten adres przesyłana jest także na adres do doręczeń elektronicznych 
syndyka. 
3. Syndyk zawiadamia o upadłości banki i instytucje, z którymi upadły zawarł 
umowę o udostępnienie skrytki sejfowej albo złożył pieniądze lub inne przedmioty. 
4. Syndyk wzywa przedsiębiorstwa przewozowe, przedsiębiorstwa spedycyjne 
i domy składowe, w których znajdują się lub mogą znajdować się towary należące do 
upadłego lub przesyłki do niego adresowane, o przekazanie syndykowi przesyłek lub 
towarów oraz aby nie wykonywały poleceń kierowanych do nich przez upadłego.

***
## Art. 177. {#art-177}

1. Syndyk niezwłocznie wykonuje obowiązki przewidziane przepisami 
o ochronie roszczeń pracowniczych w razie niewypłacalności pracodawcy. 
2. Przekazane z Funduszu Gwarantowanych Świadczeń Pracowniczych środki 
nie wchodzą do masy upadłości ani nie mogą służyć zaspokojeniu innych wierzycieli 
niż uprawnieni do ich odbioru.

***
## Art. 178. {#art-178}

1. Syndyk może żądać od organów administracji rządowej i samorządu 
terytorialnego potrzebnych informacji dotyczących majątku upadłego. 

©Kancelaria Sejmu 
 
 
 
s. 75/224 
 
2025-09-11 
 
2. Syndyk składa wniosek o poszukiwanie majątku upadłego przez komornika 
z ograniczeniem do poszukiwania w bazach danych, do których komornik ma dostęp. 
Przepisów art. 801 i art. 8011 Kodeksu postępowania cywilnego nie stosuje się. 
3. Do pism kierowanych do syndyka przez wierzycieli, o których mowa 
w art. 216aa ust. 1, oraz pism procesowych i dokumentów, o których mowa 
w art. 216ab, stosuje się odpowiednio przepisy art. 165 § 1–3 Kodeksu postępowania 
cywilnego. 
4. Do doręczeń dokonywanych przez syndyka do wierzycieli, o których mowa 
w art. 216aa ust. 1, stosuje się odpowiednio przepisy art. 131–139 i art. 140–
142 Kodeksu postępowania cywilnego. 
5. Po obwieszczeniu postanowienia o ogłoszeniu upadłości banki, w których 
upadły ma rachunki bankowe, sejfy lub skrytki, oraz spółdzielcze kasy 
oszczędnościowo-kredytowe, które prowadzą rachunki upadłego, są obowiązane 
zawiadomić o tym syndyka.

***
## Art. 179. {#art-179}

Syndyk 
jest 
obowiązany 
podejmować 
działania 
z należytą 
starannością, w sposób umożliwiający optymalne wykorzystanie majątku upadłego 
w celu zaspokojenia wierzycieli w jak najwyższym stopniu, w szczególności przez 
minimalizację kosztów postępowania. 
(Rozdział 3 – uchylony) 
(Rozdział 4 – uchylony) 
DZIAŁ III 
Uczestnicy postępowania 
## Rozdział 1. Upadły

***
## Art. 185. {#art-185}

1. Upadłym jest ten, wobec kogo wydano postanowienie o ogłoszeniu 
upadłości. 
2. Ogłoszenie upadłości nie ma wpływu na zdolność prawną oraz zdolność do 
czynności prawnych upadłego. 
3. Przekształcenia osób prawnych oraz innych jednostek organizacyjnych 
nieposiadających osobowości prawnej, którym odrębna ustawa przyznaje zdolność 
prawną, po ogłoszeniu upadłości dopuszczalne są tylko według przepisów niniejszej 
ustawy. 

©Kancelaria Sejmu 
 
 
 
s. 76/224 
 
2025-09-11 
 
4. Koszty związane z funkcjonowaniem organów upadłego oraz realizacją jego 
uprawnień organizacyjnych ustala każdorazowo sędzia-komisarz. Koszty te wchodzą 
w skład kosztów postępowania upadłościowego. Na postanowienie sędziego-
-komisarza przysługuje zażalenie.

***
## Art. 186. {#art-186}

Po ogłoszeniu upadłości wszelkie uprawnienia upadłego związane 
z uczestnictwem w spółkach lub spółdzielniach wykonuje syndyk.

***
## Art. 187. {#art-187}

1. Jeżeli upadły nie ma zdolności procesowej i nie działa za niego 
przedstawiciel ustawowy, a także gdy w składzie organów upadłego będącego osobą 
prawną lub jednostką organizacyjną nieposiadającą osobowości prawnej, której 
odrębna ustawa przyznaje zdolność prawną, zachodzą braki uniemożliwiające ich 
działanie, sędzia-komisarz ustanawia dla niego kuratora, który działa za upadłego 
w postępowaniu upadłościowym. Jeżeli dla upadłego ustanowiono kuratora na 
podstawie art. 42 § 1 ustawy z dnia 23 kwietnia 1964 r. – Kodeks cywilny, tego 
kuratora powołuje się na kuratora, o którym mowa w niniejszym przepisie. 
2. Ustanowienie kuratora na podstawie przepisu ust. 1 nie stanowi przeszkody do 
usunięcia, według zasad ogólnych, braku zdolności procesowej albo braków 
w składzie organów uniemożliwiających ich działanie. Z chwilą ich uzupełnienia 
ustanowienie kuratora według przepisów niniejszego rozdziału traci moc. 
3. Wobec kuratora nie stosuje się środków przymusu. Kurator ponosi 
odpowiedzialność za szkodę tak jak syndyk. 
4. Wynagrodzenie kuratora ustanowionego na podstawie ust. 1 ustala sędzia-
-komisarz w wysokości stosownej do nakładu pracy kuratora, stosując odpowiednio 
przepisy wykonawcze wydane na podstawie art. 9 pkt 3 ustawy z dnia 28 lipca 2005 r. 
o kosztach sądowych w sprawach cywilnych. Wynagrodzenie kuratora obowiązanego 
do rozliczenia podatku od towarów i usług podwyższa się o kwotę podatku od 
towarów i usług. Na postanowienie w przedmiocie wynagrodzenia oraz zwrotu 
wydatków przysługuje zażalenie. Zażalenie przysługuje również kuratorowi.

***
## Art. 188. {#art-188}

1. W przypadku śmierci upadłego jego spadkobierca ma prawo brać 
udział w postępowaniu upadłościowym. Jeżeli spadkobierca nie jest znany albo nie 
wstąpił do postępowania, sędzia-komisarz na wniosek syndyka albo z urzędu ustanowi 
kuratora, do którego przepis art. 187 stosuje się. 
2. Ustanowienie kuratora na podstawie ust. 1 traci moc po wstąpieniu do 
postępowania spadkobiercy upadłego, który wykazał swoje prawa prawomocnym 

©Kancelaria Sejmu 
 
 
 
s. 77/224 
 
2025-09-11 
 
postanowieniem o stwierdzeniu nabycia spadku. Przepisy o prawach i obowiązkach 
upadłego stosuje się odpowiednio do spadkobiercy. 
3. Przepis ust. 2 stosuje się odpowiednio, gdy ustanowiono kuratora spadku. 
## Rozdział 2. Wierzyciele 
Oddział 1 
Przepisy ogólne

***
## Art. 189. {#art-189}

Wierzycielem w rozumieniu ustawy jest każdy uprawniony do 
zaspokojenia z masy upadłości, choćby wierzytelność nie wymagała zgłoszenia.

***
## Art. 190. {#art-190}

1. Dla wierzyciela niemającego zdolności sądowej lub procesowej, jak 
również dla wierzyciela będącego osobą prawną albo inną jednostką organizacyjną 
nieposiadającą osobowości prawnej, której odrębna ustawa przyznaje zdolność 
prawną, która posiada braki w składzie jej organów uniemożliwiające jej działanie, 
sędzia-komisarz 
może 
ustanowić 
kuratora 
do 
działania 
w postępowaniu 
upadłościowym, jeżeli przyczyni się to do usprawnienia postępowania. 
2. Ustanowienie kuratora zgodnie z przepisem ust. 1 nie stanowi przeszkody do 
usunięcia, według przepisów ogólnych, braku zdolności sądowej lub procesowej albo 
braków w składzie organów uniemożliwiających ich działanie. Z chwilą uzupełnienia 
tych braków ustanowienie kuratora na podstawie ust. 1 traci moc. 
3. Koszty działania kuratora obciążają wierzyciela, dla którego kurator został 
ustanowiony, 
i podlegają 
zaspokojeniu 
z sum 
wypłaconych 
wierzycielowi 
w postępowaniu upadłościowym. W razie zawarcia układu oraz jeżeli wypłacona 
wierzycielowi w postępowaniu upadłościowym suma nie wystarcza na zaspokojenie 
kosztów 
ustanowienia 
kuratora, 
sędzia-komisarz 
wydaje 
postanowienie 
zobowiązujące wierzyciela do ich poniesienia. Koszty te ściąga się według przepisów 
o egzekucji opłat sądowych. Na postanowienie sędziego-komisarza przysługuje 
zażalenie. 
Oddział 2 
Zgromadzenie wierzycieli

***
## Art. 191. {#art-191}

Sędzia-komisarz zwołuje zgromadzenie wierzycieli: 
- 1) jeżeli według przepisów ustawy wymagane jest podjęcie uchwały zgromadzenia; 

©Kancelaria Sejmu 
 
 
 
s. 78/224 
 
2025-09-11 
- 2) na wniosek przynajmniej dwóch wierzycieli mających łącznie nie mniej niż 
trzecią część ogólnej sumy uznanych wierzytelności; 
- 3) w innych przypadkach, gdy uzna to za potrzebne.

***
## Art. 192. {#art-192}

1. 
Sędzia-komisarz 
zwołuje 
zgromadzenie 
wierzycieli 
przez 
obwieszczenie, w którym wskazuje termin, miejsce i przedmiot obrad oraz sposób 
głosowania. 
2. Obwieszczenia dokonuje się przynajmniej na dwa tygodnie przed terminem 
zgromadzenia wierzycieli. 
3. W przypadku odroczenia zgromadzenia wierzycieli, sędzia-komisarz podaje 
obecnym do wiadomości nowy termin i miejsce zgromadzenia; w takim przypadku nie 
dokonuje się ponownego obwieszczenia. Oddany poprzednio głos wierzyciela, który 
nie stawił się na odroczonym zgromadzeniu wierzycieli, zachowuje moc i jest 
uwzględniany przy obliczaniu wyników głosowania, jeżeli na tym zgromadzeniu 
poddane pod głosowanie są te same uchwały lub uchwały korzystniejsze dla 
wierzycieli.

***
## Art. 193. {#art-193}

1. Zgromadzeniu wierzycieli przewodniczy sędzia-komisarz. 
2. Z przebiegu zgromadzenia wierzycieli sporządza się protokół.

***
## Art. 194. {#art-194}

Syndyk, członkowie rady wierzycieli i upadły wezwany do udzielenia 
wyjaśnień 
obowiązani 
są 
stawić 
się 
na 
zgromadzeniu 
wierzycieli. 
Ich 
niestawiennictwo jednak, choćby usprawiedliwione, nie stanowi przeszkody do 
odbycia zgromadzenia wierzycieli.

***
## Art. 195. {#art-195}

1. Jeżeli ustawa nie stanowi inaczej, w zgromadzeniu wierzycieli mają 
prawo uczestniczyć z prawem głosu wierzyciele, których wierzytelności zostały 
uznane. Wierzyciele głosują z sumą wierzytelności umieszczoną na liście 
wierzytelności. 
2. Sędzia-komisarz na wniosek wierzyciela i po wysłuchaniu upadłego może 
dopuścić do udziału w zgromadzeniu wierzyciela, którego wierzytelność uzależniona 
jest od warunku zawieszającego lub jest uprawdopodobniona; stosownie do 
okoliczności sędzia-komisarz oznacza sumę, według której oblicza się głos tego 
wierzyciela.

***
## Art. 196. {#art-196}

1. Wierzyciele, którzy mają wierzytelność solidarną lub niepodzielną, 
głosują przez wspólnego pełnomocnika, któremu pełnomocnictwo powinno być 

©Kancelaria Sejmu 
 
 
 
s. 79/224 
 
2025-09-11 
 
udzielone na piśmie, z podpisem notarialnie poświadczonym. Pełnomocnictwo 
udzielone adwokatowi lub radcy prawnemu nie wymaga notarialnego poświadczenia. 
Pełnomocnikiem może być także jeden z wierzycieli. O ustanowieniu pełnomocnika 
wierzyciele ci obowiązani są powiadomić sędziego-komisarza na piśmie przed 
zgromadzeniem wierzycieli lub ustnie do protokołu na zgromadzeniu. 
2. Jeżeli wierzyciele nie dokonają wyboru pełnomocnika zgodnie z ust. 1, 
w imieniu wierzycieli głosuje zarządca ustanowiony według przepisów ustawy z dnia 
23 kwietnia 1964 r. – Kodeks cywilny o zarządzie związanym ze współwłasnością. 
3. Niedokonanie przez wierzycieli, o których mowa w ust. 1 i 2, wyboru 
pełnomocnika lub zarządcy nie stanowi przeszkody do wyznaczenia terminu 
zgromadzenia wierzycieli.

***
## Art. 197. {#art-197}

1. Wierzyciel nie ma prawa głosu na podstawie wierzytelności, którą 
nabył w drodze przelewu lub indosu po ogłoszeniu upadłości, chyba że przejście 
wierzytelności nastąpiło wskutek spłacenia przez niego długu, za który odpowiadał 
osobiście albo określonymi przedmiotami majątkowymi, ze stosunku prawnego 
powstałego przed ogłoszeniem upadłości. 
2. (uchylony) 
3. (uchylony) 
4. (uchylony)

***
## Art. 198. {#art-198}

1. Głosowanie na zgromadzeniu wierzycieli przeprowadza się ustnie 
lub pisemnie, a opis przebiegu i wynik głosowania zamieszcza się w protokole. 
W protokole podaje się imię i nazwisko głosującego, czy głosuje za, czy przeciw 
uchwale, oraz sumę wierzytelności, z jaką głosuje. Jeżeli oddano głos w cudzym 
imieniu, wskazuje się reprezentowanego oraz imię i nazwisko głosującego. 
Wierzyciela, który wstrzymał się od głosu, uważa się za nieuczestniczącego w 
głosowaniu. 
2. Uczestnik postępowania może głosować na zgromadzeniu wierzycieli także 
przez pełnomocnika.

***
## Art. 199. {#art-199}

1. Jeżeli ustawa nie stanowi inaczej, uchwały zgromadzenia 
wierzycieli zapadają bez względu na liczbę obecnych, większością głosów wierzycieli 
mających przynajmniej piątą część ogólnej sumy wierzytelności przypadających 
wierzycielom uprawnionym do uczestniczenia w tym zgromadzeniu. 

©Kancelaria Sejmu 
 
 
 
s. 80/224 
 
2025-09-11 
 
2. W sprawach o wyłączenie mienia z masy upadłości uchwały zapadają 
większością głosów wierzycieli mających przynajmniej dwie trzecie ogólnej sumy 
uznanych wierzytelności.

***
## Art. 200. {#art-200}

Sędzia-komisarz może uchylić uchwałę zgromadzenia wierzycieli, 
jeżeli jest sprzeczna z prawem lub narusza dobre obyczaje albo rażąco narusza interes 
wierzyciela, który głosował przeciw uchwale. Na postanowienie sędziego-komisarza 
przysługuje zażalenie. 
Oddział 3 
Rada wierzycieli

***
## Art. 201. {#art-201}

1. Radę wierzycieli ustanawia oraz powołuje i odwołuje jej członków 
sędzia-komisarz z urzędu, o ile uzna to za potrzebne, albo na wniosek. 
2. Sędzia-komisarz niezwłocznie, nie później niż w terminie tygodnia, ustanawia 
radę wierzycieli na wniosek upadłego, co najmniej trzech wierzycieli lub wierzyciela 
lub wierzycieli mających łącznie co najmniej piątą część sumy wierzytelności, 
z wyłączeniem wierzycieli określonych w art. 116 ustawy z dnia 15 maja 2015 r. – 
Prawo restrukturyzacyjne (Dz. U. z 2024 r. poz. 1428) oraz wierzycieli, którzy nabyli 
wierzytelność w drodze przelewu lub indosu po ogłoszeniu upadłości, chyba że 
przejście wierzytelności nastąpiło wskutek spłacenia przez wierzyciela długu, za który 
odpowiadał osobiście albo określonymi przedmiotami majątkowymi, ze stosunku 
prawnego powstałego przed ogłoszeniem upadłości. 
3. Do czasu zatwierdzenia listy wierzytelności uprawnienia wierzycieli 
w sprawach dotyczących rady wierzycieli ustala się na podstawie: 
- 1) spisu wierzycieli załączonego przez dłużnika do wniosku o ogłoszenie upadłości; 
- 2) spisu 
wierzytelności 
bezspornych 
przedstawionego 
na 
żądanie 
sędziego-komisarza 
przez 
syndyka, 
sporządzonego 
w oparciu 
o księgi 
rachunkowe i inne dokumenty upadłego; 
- 3) przedłożonych przez wierzycieli tytułów egzekucyjnych; 
- 4) spisu wierzytelności sporządzonego w postępowaniu restrukturyzacyjnym.

***
## Art. 202. {#art-202}

1. Rada wierzycieli składa się z pięciu członków oraz dwóch 
zastępców powoływanych spośród wierzycieli dłużnika będących uczestnikami 
postępowania. Rada wierzycieli może składać się z trzech członków, jeżeli liczba 
wierzycieli dłużnika będących uczestnikami postępowania jest mniejsza niż siedem. 

©Kancelaria Sejmu 
 
 
 
s. 81/224 
 
2025-09-11 
 
Sędzia-komisarz może odwołać członków rady wierzycieli, którzy nie pełnią 
należycie obowiązków, i powołać innych. Na postanowienie przysługuje zażalenie. 
Odwołany prawomocnie członek rady wierzycieli nie może być ponownie powołany. 
1a. Sędzia-komisarz odwołuje członka rady wierzycieli na jego wniosek. 
2. (uchylony) 
3. Wierzyciel może nie przyjąć obowiązków członka rady lub jego zastępcy. 
4. Do zastępcy członka rady wierzycieli przepisy dotyczące członka rady 
wierzycieli stosuje się odpowiednio. Zastępca członka rady wierzycieli może 
uczestniczyć w posiedzeniach rady wierzycieli. Głosuje on nad uchwałą w przypadku 
nieobecności któregokolwiek z członków rady wierzycieli. Zamiast nieobecnego 
członka rady wierzycieli w pierwszej kolejności głosuje zastępca wymieniony na 
pierwszym miejscu w sentencji postanowienia sędziego-komisarza o powołaniu, jeżeli 
jest obecny na posiedzeniu. 
Art. 202a. 1. Na wniosek wierzyciela lub wierzycieli mających co najmniej piątą 
część sumy wierzytelności przysługujących wierzycielom będącym uczestnikami 
postępowania, z wyłączeniem wierzycieli określonych w art. 116 ustawy z dnia 
15 maja 2015 r. – Prawo restrukturyzacyjne oraz wierzycieli, którzy nabyli 
wierzytelność w drodze przelewu lub indosu po ogłoszeniu upadłości, chyba że 
przejście wierzytelności nastąpiło wskutek spłacenia przez wierzyciela długu, za który 
odpowiadał osobiście albo określonymi przedmiotami majątkowymi, ze stosunku 
prawnego powstałego przed ogłoszeniem upadłości, sędzia-komisarz powołuje na 
członka rady wierzycieli wierzyciela wskazanego przez wnioskodawcę, chyba że 
zachodzi uzasadnione przypuszczenie, że wskazany wierzyciel nie będzie należycie 
pełnił obowiązków członka rady wierzycieli. Na postanowienie oddalające wniosek 
zażalenie przysługuje wyłącznie wnioskodawcy. 
2. W przypadku gdy wierzyciel lub wierzyciele wnioskujący o powołanie 
członka rady wierzycieli posiadają co najmniej dwie piąte sumy wierzytelności 
przysługujących wierzycielom będącym uczestnikami postępowania, z wyłączeniem 
wierzycieli określonych w art. 116 ustawy z dnia 15 maja 2015 r. – Prawo 
restrukturyzacyjne oraz wierzycieli, którzy nabyli wierzytelność w drodze przelewu 
lub indosu po ogłoszeniu upadłości, chyba że przejście wierzytelności nastąpiło 
wskutek spłacenia przez wierzyciela długu, za który odpowiadał osobiście albo 
określonymi przedmiotami majątkowymi, ze stosunku prawnego powstałego przed 

©Kancelaria Sejmu 
 
 
 
s. 82/224 
 
2025-09-11 
 
ogłoszeniem upadłości, mogą oni wskazać po jednym kandydacie na członka rady 
wierzycieli na każdą piątą część posiadanych wierzytelności. 
3. Wierzyciel lub wierzyciele, których wniosek wskazany w ust. 1 lub 2 został 
uwzględniony, nie mogą złożyć wniosku o powołanie kolejnych członków rady 
wierzycieli, chyba że członek powołany poprzednio na ich wniosek został odwołany.

***
## Art. 203. {#art-203}

1. Na wniosek wierzyciela lub wierzycieli mających co najmniej piątą 
część sumy wierzytelności przysługujących wierzycielom będącym uczestnikami 
postępowania, z wyłączeniem wierzycieli określonych w art. 116 ustawy z dnia 
15 maja 2015 r. – Prawo restrukturyzacyjne oraz wierzycieli, którzy nabyli 
wierzytelność w drodze przelewu lub indosu po ogłoszeniu upadłości, chyba że 
przejście wierzytelności nastąpiło wskutek spłacenia przez wierzyciela długu, za który 
odpowiadał osobiście albo określonymi przedmiotami majątkowymi, ze stosunku 
prawnego powstałego przed ogłoszeniem upadłości, sędzia-komisarz zmienia skład 
rady wierzycieli, powołując na członka rady wierzycieli wierzyciela wskazanego 
przez wnioskodawcę, chyba że zachodzi uzasadnione przypuszczenie, że wskazany 
wierzyciel nie będzie należycie pełnił obowiązków członka rady wierzycieli. Na 
postanowienie oddalające wniosek zażalenie przysługuje wyłącznie wnioskodawcy. 
2. Przepisy art. 202a ust. 2 i 3 stosuje się odpowiednio. 
3. Sędzia-komisarz, zmieniając skład rady wierzycieli, nie może odwołać 
członka rady wierzycieli powołanego na podstawie ust. 1 lub art. 202a, chyba że 
żądają tego wierzyciele, na których wniosek członek został powołany.

***
## Art. 204. {#art-204}

1. Członkowie rady wierzycieli pełnią swoje obowiązki osobiście albo 
przez pełnomocników. 
2. Pełnomocnictwo składa się przewodniczącemu rady, który składa je do akt 
postępowania wraz z protokołem z posiedzenia rady wierzycieli.

***
## Art. 205. {#art-205}

1. Rada wierzycieli udziela pomocy syndykowi, kontroluje jego 
czynności, bada stan funduszów masy upadłości, udziela zezwolenia na czynności, 
które mogą być dokonane tylko za zezwoleniem rady wierzycieli, oraz wyraża opinię 
w innych sprawach, jeżeli tego zażąda sędzia-komisarz lub syndyk. Przy 
wykonywaniu obowiązków rada wierzycieli kieruje się interesem ogółu wierzycieli. 
2. Rada 
wierzycieli 
lub 
jej 
członkowie 
mogą 
przedstawiać 
sędziemu-komisarzowi swoje uwagi o działalności syndyka. 

©Kancelaria Sejmu 
 
 
 
s. 83/224 
 
2025-09-11 
 
3. Rada wierzycieli może żądać od upadłego oraz syndyka wyjaśnień oraz badać 
księgi i dokumenty dotyczące upadłości w zakresie, w jakim nie narusza to tajemnicy 
przedsiębiorstwa. Sędzia-komisarz rozstrzyga wątpliwości co do zakresu uprawnienia 
członków rady do badania ksiąg i dokumentów upadłego.

***
## Art. 206. {#art-206}

1. Zezwolenia rady wierzycieli pod rygorem nieważności wymagają 
następujące czynności: 
- 1) dalsze prowadzenie przedsiębiorstwa przez syndyka, jeżeli ma trwać dłużej niż 
trzy miesiące od dnia ogłoszenia upadłości; 
- 2) odstąpienie od sprzedaży przedsiębiorstwa jako całości; 
- 3) sprzedaż z wolnej ręki mienia wchodzącego w skład masy upadłości; 
- 4) zaciąganie pożyczek lub kredytów oraz obciążenie majątku upadłego 
ograniczonymi prawami rzeczowymi; 
- 5) (uchylony) 
- 6) uznanie, zrzeczenie się i zawarcie ugody co do roszczeń spornych oraz poddanie 
sporu rozstrzygnięciu sądu polubownego. 
11. (uchylony) 
2. Jeżeli czynność, o której mowa w ust. 1 i 11, musi być dokonana niezwłocznie 
i dotyczy wartości nieprzewyższającej dziesięciu tysięcy złotych, syndyk, nadzorca 
sądowy albo zarządca może ją wykonać bez zezwolenia rady. 
3. Zezwolenie rady wierzycieli na sprzedaż ruchomości nie jest wymagane, jeżeli 
wskazana w spisie inwentarza wartość oszacowania wszystkich ruchomości 
wchodzących w skład masy upadłości nie przekracza równowartości 50 000 zł. 
4. Do zezwolenia na sprzedaż wierzytelności oraz innych praw, jeżeli wskazana 
w spisie należności wartość nominalna wszystkich wierzytelności oraz innych praw 
wchodzących w skład masy upadłości nie przekracza równowartości 50 000 zł, 
przepis ust. 3 stosuje się odpowiednio. 
5. Wpis obciążenia majątku upadłego ograniczonym prawem rzeczowym 
w księdze wieczystej lub rejestrze dokonany bez zezwolenia wymaganego zgodnie 
z ust. 1 podlega wykreśleniu z urzędu. Podstawą wykreślenia jest prawomocne 
postanowienie sędziego-komisarza stwierdzające niedopuszczalność wpisu. Na 
postanowienie sędziego-komisarza przysługuje zażalenie.

***
## Art. 207. {#art-207}

1. Rada wierzycieli wykonuje czynności przez podejmowanie uchwał 
na posiedzeniach, chyba że regulamin stanowi inaczej. Posiedzenia rady wierzycieli 

©Kancelaria Sejmu 
 
 
 
s. 84/224 
 
2025-09-11 
 
mogą odbywać się przy użyciu środków bezpośredniego porozumiewania się na 
odległość. 
1a. Jeżeli uchwała nie jest podejmowana na posiedzeniu, do jej podjęcia 
konieczne jest oddanie głosów przez wszystkich członków rady wierzycieli. W takim 
przypadku głosu nie może oddać zastępca członka rady wierzycieli. 
1b. Uchwały rady wierzycieli podejmuje się większością głosów, jeżeli ustawa 
nie stanowi inaczej, w terminie dwóch tygodni od dnia złożenia wniosku do rady. 
2. Rada wierzycieli może kontrolować czynności syndyka oraz badać stan 
funduszów masy upadłości przez członka lub członków wskazanych w uchwale. 
3. Uchwałę rady wierzycieli o zbadaniu ksiąg i dokumentów przedsiębiorstwa 
upadłego wykonują wskazani w uchwale członkowie rady wierzycieli lub, jeżeli są 
wymagane wiadomości specjalne, inne osoby. Koszty badania nie stanowią kosztów 
postępowania i nie obciążają masy upadłości. 
4. Z kontroli działalności upadłego albo syndyka oraz badania ksiąg 
i dokumentów rada wierzycieli składa sprawozdanie sędziemu-komisarzowi. Z innych 
czynności rada wierzycieli składa sprawozdanie na żądanie sędziego-komisarza. 
Art. 207a. 1. Na skutek uchwały rady wierzycieli podjętej w pełnym składzie, za 
którą głosowało co najmniej czterech członków, albo na skutek uchwały rady 
wierzycieli podjętej zgodnie z wnioskiem upadłego sąd zmienia syndyka i powołuje 
do pełnienia tej funkcji osobę spełniającą wymogi, o których mowa w art. 157 ust. 1 
lub 2, wskazaną przez radę wierzycieli, chyba że byłoby to niezgodne z prawem, 
rażąco naruszałoby interes wierzycieli lub zachodzi uzasadnione przypuszczenie, że 
wskazana osoba nie będzie należycie pełniła obowiązków. Na postanowienie sądu 
odmawiające powołania osoby wskazanej przez radę zażalenie przysługuje wyłącznie 
członkom rady wierzycieli oraz upadłemu. 
2. Jeżeli rada wierzycieli składa się z trzech członków, uchwałę, o której mowa 
w ust. 1, podejmuje się jednomyślnie.

***
## Art. 208. {#art-208}

1. Pierwsze posiedzenie rady zwołuje syndyk niezwłocznie po 
powołaniu rady wierzycieli. Rada wierzycieli na pierwszym posiedzeniu przyjmuje 
regulamin, który określa w szczególności tryb posiedzeń, sposób zbierania głosów 
i zasady współpracy rady z syndykiem, w tym sposób składania wniosków do rady. 
Rada wierzycieli na pierwszym posiedzeniu wybiera spośród swoich członków 
przewodniczącego 
rady. 
Posiedzenie 
rady 
zwołuje 
przewodniczący 
rady, 

©Kancelaria Sejmu 
 
 
 
s. 85/224 
 
2025-09-11 
 
zawiadamiając członków i zastępców o terminie, miejscu i przedmiocie posiedzenia. 
Regulamin może określać sposób zawiadamiania członków rady. Posiedzeniu rady 
wierzycieli przewodniczy przewodniczący rady, chyba że regulamin stanowi inaczej. 
2. Posiedzenie rady wierzycieli może zwołać również sędzia-komisarz, który 
przewodniczy posiedzeniu.

***
## Art. 209. {#art-209}

1. Z posiedzenia rady wierzycieli sporządza się protokół. Protokół 
podpisują obecni, a odmowę złożenia podpisu zaznacza się w protokole. Jeżeli 
posiedzenie odbywa się przy użyciu środków bezpośredniego porozumiewania się na 
odległość, protokół podpisuje wyłącznie przewodniczący rady, ze wskazaniem 
przyczyny braku pozostałych podpisów, chyba że co innego wynika z regulaminu. 
2. Przewodniczący rady niezwłocznie po posiedzeniu przekazuje odpis protokołu 
sędziemu-komisarzowi, a także syndykowi, jeżeli nie był obecny na posiedzeniu. Do 
odpisu protokołu załącza się odpisy uchwał podjętych na posiedzeniu. 
3. Po podjęciu uchwały bez zwoływania posiedzenia rady wierzycieli 
przewodniczący rady niezwłocznie przekazuje odpis uchwały sędziemu-komisarzowi. 
4. Przepisów ust. 1–3 nie stosuje się w przypadku posiedzenia rady wierzycieli, 
o którym mowa w art. 208 ust. 2.

***
## Art. 210. {#art-210}

1. (uchylony) 
2. W terminie tygodnia uczestnik postępowania oraz syndyk mogą wnieść 
zarzuty przeciwko uchwale rady wierzycieli. Zarzuty wniesione po upływie terminu 
lub nieodpowiadające wymaganiom formalnym pisma procesowego pozostawia się 
bez rozpoznania. Przepisu art. 130 § 1 Kodeksu postępowania cywilnego nie stosuje 
się. 
3. Sędzia-komisarz rozpoznaje zarzuty w terminie tygodnia od dnia przedłożenia 
mu zarzutów. 
4. Sędzia-komisarz w wyniku rozpoznania zarzutów lub z urzędu w terminie 
dwóch tygodni od dnia przekazania mu uchwały rady wierzycieli może uchylić tę 
uchwałę, jeżeli jest ona sprzeczna z prawem lub narusza interes wierzycieli. 
Na postanowienie sędziego-komisarza zażalenie przysługuje wyłącznie skarżącemu, 
upadłemu oraz członkom rady wierzycieli. 
5. Wykonanie uchwały rady wierzycieli nie może nastąpić wcześniej niż po 
upływie dwóch tygodni od dnia jej przekazania sędziemu-komisarzowi. Sędzia-
-komisarz może wstrzymać wykonanie uchwały rady wierzycieli do czasu 

©Kancelaria Sejmu 
 
 
 
s. 86/224 
 
2025-09-11 
 
uprawomocnienia się postanowienia w przedmiocie rozpoznania zarzutów lub 
postanowienia o uchyleniu uchwały rady wierzycieli.

***
## Art. 211. {#art-211}

1. Członkowi rady wierzycieli przysługuje prawo do zwrotu 
koniecznych wydatków związanych z jego udziałem w posiedzeniu rady wierzycieli. 
Za udział w posiedzeniu sędzia-komisarz może przyznać członkowi rady stosowne 
wynagrodzenie, jeżeli uzasadnione to jest rodzajem i stopniem zawiłości sprawy oraz 
zakresem wykonywanych prac. Wynagrodzenie to nie może przekraczać 3 % 
miesięcznego przeciętnego wynagrodzenia, o którym mowa w art. 162 ust. 2, za jeden 
dzień posiedzenia. Wynagrodzenie oraz zwrot wydatków wchodzi w skład kosztów 
postępowania. 
2. Postanowienie w sprawie wynagrodzenia i zwrotu wydatków wydaje 
sędzia-komisarz po wysłuchaniu członka rady wierzycieli i syndyka.

***
## Art. 212. {#art-212}

1. Członek rady wierzycieli odpowiada za szkodę wynikłą 
z nienależytego pełnienia obowiązków. 
2. Za szkodę wyrządzoną nienależytym wykonaniem obowiązków przez 
pełnomocnika działającego w radzie wierzyciel odpowiada jak za działanie własne.

***
## Art. 213. {#art-213}

1. Jeżeli rada wierzycieli nie została ustanowiona, czynności 
zastrzeżone dla rady wierzycieli podejmuje sędzia-komisarz. 
2. Sędzia-komisarz wykonuje również czynności zastrzeżone dla rady 
wierzycieli, jeżeli rada nie wykona ich w terminie wyznaczonym przez 
sędziego-komisarza lub w terminie określonym w art. 308 ust. 2. 
DZIAŁ IV 
Przepisy ogólne dotyczące postępowania po ogłoszeniu upadłości

***
## Art. 214. {#art-214}

Sąd orzeka na posiedzeniu niejawnym, jeżeli ustawa nie stanowi 
inaczej.

***
## Art. 215. {#art-215}

1. W razie ogłoszenia upadłości wszystkich wspólników spółki 
cywilnej sąd może połączyć do łącznego rozpoznania sprawy upadłościowe 
prowadzone wobec wspólników tej spółki. Jeżeli ogłoszono upadłość w różnych 
sądach, przepisy art. 149 ust. 2 i 3 stosuje się odpowiednio. 
2. W postanowieniu 
o połączeniu 
spraw 
sąd 
wyznacza 
jednego 
sędziego-komisarza do wszystkich połączonych spraw. Sąd może również wyznaczyć 

©Kancelaria Sejmu 
 
 
 
s. 87/224 
 
2025-09-11 
 
jednego syndyka do wszystkich połączonych spraw, powołać jedną radę wierzycieli 
i wyznaczyć wspólne zgromadzenie wierzycieli. 
3. Dla każdego z upadłych sporządza się osobne listy wierzytelności oraz plany 
podziału funduszów masy upadłości, w których z urzędu uwzględnia się zaspokojenie 
wierzytelności, za które upadli odpowiadają solidarnie. 
4. Wynagrodzenie syndyka oraz koszty likwidacji pokrywa się z masy upadłości 
każdego z upadłych w częściach określonych przez sąd przy odpowiednim 
uwzględnieniu zasad przyznawania wynagrodzenia. 
5. W przypadku ogłoszenia upadłości osobowej spółki handlowej oraz jej 
wspólników ponoszących odpowiedzialność za zobowiązania spółki bez ograniczenia 
całym swoim majątkiem, a także jeżeli sąd uzna za uzasadnione połączenie spraw 
upadłościowych prowadzonych wobec innych upadłych, w szczególności wobec 
podmiotów powiązanych oraz małżonków, przepisy ust. 1–4 stosuje się odpowiednio.

***
## Art. 216. {#art-216}

Do pełnomocnictwa określonego w ustawie stosuje się przepisy 
Kodeksu cywilnego, jeżeli ustawa nie stanowi inaczej. 
Art. 216a. 1. W postępowaniu 
upadłościowym 
pisma 
procesowe 
oraz 
dokumenty, z wyłączeniem pism i dokumentów, o których mowa w art. 216ab, wnosi 
się wyłącznie za pośrednictwem systemu teleinformatycznego obsługującego postę-
powanie sądowe z wykorzystaniem udostępnianych w tym systemie formularzy. 
Pisma oraz dokumenty niewniesione za pośrednictwem systemu teleinformatycznego 
obsługującego postępowanie sądowe nie wywołują skutków prawnych, jakie ustawa 
wiąże z wniesieniem pisma albo dokumentu do sądu, tymczasowego nadzorcy 
sądowego, zarządcy przymusowego, syndyka albo organu, do którego przepisy 
o syndyku stosuje się odpowiednio, o czym poucza się wnoszącego pismo albo 
dokument. Pouczenie nie jest wymagane, jeżeli wnoszącym pismo albo dokument jest 
tymczasowy nadzorca sądowy, zarządca przymusowy, syndyk albo organ, do którego 
przepisy o syndyku stosuje się odpowiednio. 
1a. Pisma procesowe oraz dokumenty wniesione za pośrednictwem systemu 
teleinformatycznego 
obsługującego 
postępowanie 
sądowe 
opatruje 
się 
kwalifikowanym podpisem elektronicznym, podpisem zaufanym, podpisem 
osobistym albo uwierzytelnia się w sposób zapewniający możliwość potwierdzenia 
pochodzenia i integralność weryfikowanych danych w postaci elektronicznej, 
dostępny w systemie teleinformatycznym obsługującym postępowanie sądowe. 

©Kancelaria Sejmu 
 
 
 
s. 88/224 
 
2025-09-11 
 
1b. Do 
pisma 
procesowego 
wnoszonego 
za 
pośrednictwem 
systemu 
teleinformatycznego obsługującego postępowanie sądowe dołącza się załączniki 
w postaci elektronicznej. 
1c. Jeżeli załączane dokumenty zostały sporządzone w postaci papierowej, do 
pisma dołącza się: 
- 1) poświadczone elektronicznie odpisy dokumentów; 
- 2) elektroniczne kopie dokumentów. 
1d. Poza podmiotami określonymi w przepisach szczególnych elektronicznego 
poświadczenia odpisu dokumentu może również dokonać występująca w sprawie 
w charakterze uczestnika lub organu postępowania albo pełnomocnika osoba posia-
dająca licencję doradcy restrukturyzacyjnego. Elektronicznego poświadczenia odpisu 
protokołu posiedzenia rady wierzycieli oraz odpisu uchwały podjętej na posiedzeniu 
rady wierzycieli może również dokonać przewodniczący rady wierzycieli. 
1e. W przypadku, o którym mowa w ust. 1c pkt 2, oryginał dokumentu albo jego 
odpis poświadczony za zgodność z oryginałem zgodnie z przepisami Kodeksu 
postępowania cywilnego składa się w sądzie upadłościowym bez wezwania 
w terminie 3 dni od dnia wniesienia pisma. Przepis art. 130 § 2 Kodeksu 
postępowania cywilnego stosuje się odpowiednio. 
2. (uchylony) 
3. W każdym piśmie procesowym należy wskazać imię i nazwisko wnoszącego 
pismo albo jego nazwę oraz numer PESEL albo numer w Krajowym Rejestrze 
Sądowym, a w przypadku ich braku – inne dane umożliwiające jego jednoznaczną 
identyfikację oraz firmę, pod którą działa wnoszący pismo będący przedsiębiorcą, 
miejsce zamieszkania albo siedzibę, adres oraz NIP, jeżeli wnoszący pismo ma taki 
numer. 
4. Przez inne dane umożliwiające jednoznaczną identyfikację, o których mowa 
w ust. 3, rozumie się dane, o których mowa w art. 22 ust. 4. 
5. W piśmie procesowym wnoszący pismo może podać numer telefonu do 
kontaktu oraz adres poczty elektronicznej. 
Art. 216aa. 1. Wierzyciele, którym przysługują należności ze stosunku pracy, 
z wyjątkiem 
roszczeń 
z tytułu 
wynagrodzenia 
reprezentanta 
upadłego 
lub 
wynagrodzenia osoby wykonującej czynności związane z zarządem lub nadzorem nad 
przedsiębiorstwem 
dłużnika, 
należności 
alimentacyjne 
oraz 
renty 
z tytułu 
odszkodowania za wywołanie choroby, niezdolności do pracy, kalectwa lub śmierci 

©Kancelaria Sejmu 
 
 
 
s. 89/224 
 
2025-09-11 
 
i renty z tytułu zamiany uprawnień objętych treścią prawa dożywocia na dożywotnią 
rentę, mogą wnosić pisma procesowe oraz dokumenty z pominięciem systemu 
teleinformatycznego obsługującego postępowanie sądowe. 
2. Osoby, o których mowa w ust. 1, mogą również wnosić wnioski lub składać 
oświadczenia i dokumenty w biurze podawczym każdego sądu rejonowego, 
przekazując ustnie treść wniosku lub oświadczenia pracownikowi biura podawczego 
oraz składając dokumenty sporządzone w postaci papierowej. 
3. Pracownik biura podawczego wprowadza treść wniosku lub oświadczenia do 
systemu teleinformatycznego obsługującego postępowanie sądowe, podając imię, 
nazwisko oraz numer PESEL osoby przekazującej ustnie treść wniosku lub 
oświadczenia ustalone na podstawie dowodu osobistego albo innego dokumentu 
potwierdzającego tożsamość, a także rodzaj i numer dokumentu potwierdzającego 
tożsamość i oznaczenie organu, który go wydał, a w przypadku ich braku – inne dane 
umożliwiające jednoznaczną identyfikację tej osoby. Wprowadzona do systemu treść 
wniosku lub oświadczenia podlega wydrukowaniu i podpisaniu przez osobę 
przekazującą ustnie treść wniosku lub oświadczenia oraz złożeniu do zbioru 
dokumentów. 
Wniosek 
lub 
oświadczenie 
wprowadzone 
do 
systemu 
teleinformatycznego obsługującego postępowanie sądowe opatruje podpisem 
pracownik biura podawczego zgodnie z art. 216a ust. 1a. 
4. Przepisy art. 216a ust. 1b, 1c, 1e i 3–5 stosuje się odpowiednio, z tym że 
elektronicznego poświadczenia odpisu dokumentu może również dokonać pracownik 
biura podawczego. 
5. Jeżeli wierzyciele, o których mowa w ust. 1, wnoszą pismo za pośrednictwem 
systemu 
teleinformatycznego 
obsługującego 
postępowanie 
sądowe, 
przepis 
art. 130 § 6 Kodeksu postępowania cywilnego stosuje się odpowiednio. 
Art. 216ab. Pisma procesowe i dokumenty zawierające informacje niejawne 
w rozumieniu ustawy z dnia 5 sierpnia 2010 r. o ochronie informacji niejawnych 
(Dz. U. z 2024 r. poz. 632 i 1222), a także oferty składane w toku przetargu lub aukcji 
wnosi się z pominięciem systemu teleinformatycznego obsługującego postępowanie 
sądowe. 
Art. 216ac. Minister Sprawiedliwości w porozumieniu z ministrem właściwym 
do spraw informatyzacji określi, w drodze rozporządzenia, sposób wnoszenia pism 
procesowych 
i składania 
dokumentów 
za 
pośrednictwem 
systemu 

©Kancelaria Sejmu 
 
 
 
s. 90/224 
 
2025-09-11 
 
teleinformatycznego obsługującego postępowanie sądowe oraz w biurze podawczym 
sądu rejonowego, mając na względzie skuteczność wnoszenia pism procesowych 
i składania dokumentów, szczególne wymagania postępowań obsługiwanych przez 
system teleinformatyczny obsługujący postępowanie sądowe oraz ochronę praw osób 
wnoszących pisma procesowe. 
Art. 216b. Organy postępowań upadłościowych obowiązane są do wzajemnej 
współpracy.

***
## Art. 217. {#art-217}

1. Jeżeli zachodzi potrzeba przeprowadzenia dowodu z przesłuchania 
upadłego, syndyka, wierzyciela, członka rady wierzycieli lub innych osób, sąd albo 
sędzia-komisarz, stosownie do okoliczności, przesłuchuje ich na posiedzeniu 
i z przesłuchania sporządza protokół, niezależnie od obecności innych osób 
zainteresowanych, albo odbiera od osób przesłuchiwanych oświadczenia na piśmie; 
oświadczenia te stanowią dowód w sprawie. 
2. Sąd albo sędzia-komisarz może zarządzić również, by oświadczenie na piśmie, 
o którym mowa w ust. 1, zawierało podpis notarialnie poświadczony. 
3. Nieobecność osoby, o której mowa w ust. 1, wezwanej na posiedzenie lub 
niezłożenie 
przez 
tę 
osobę 
oświadczenia 
na 
piśmie, 
nawet 
z przyczyn 
usprawiedliwionych, nie tamuje postępowania. 
4. Przepisy ust. 1–3 stosuje się również do przeprowadzenia dowodu z zeznań 
świadków oraz wysłuchania biegłych.

***
## Art. 218. {#art-218}

Syndyk składa sędziemu-komisarzowi wniosek o przeprowadzenie 
dowodu, jeżeli uzna za konieczne ustalenie okoliczności sprawy w drodze 
postępowania dowodowego. W przypadku uwzględnienia wniosku postępowanie 
dowodowe prowadzi sędzia-komisarz. 
Art. 218a. Wyznaczając rozprawę, poucza się uczestnika postępowania 
występującego w sprawie bez adwokata, radcy prawnego, osoby posiadającej licencję 
doradcy restrukturyzacyjnego, rzecznika patentowego lub Prokuratorii Generalnej 
Rzeczypospolitej Polskiej o: 
- 1) możliwości ustanowienia pełnomocnika procesowego oraz o tym, że zastępstwo 
adwokata, 
radcy 
prawnego, 
osoby 
posiadającej 
licencję 
doradcy 
restrukturyzacyjnego lub rzecznika patentowego nie jest obowiązkowe; 
- 2) obowiązku zwrócenia uwagi sądu na uchybienie przepisom postępowania, 
wnosząc o wpisanie zastrzeżenia do protokołu, oraz że zastrzeżenie można 

©Kancelaria Sejmu 
 
 
 
s. 91/224 
 
2025-09-11 
 
zgłosić najpóźniej na kolejnym posiedzeniu, a także o tym, że uczestnikowi 
reprezentowanemu przez adwokata, radcę prawnego, osobę posiadającą licencję 
doradcy restrukturyzacyjnego, rzecznika patentowego lub Prokuratorię 
Generalną Rzeczypospolitej Polskiej, który zastrzeżenia nie zgłosi, nie 
przysługuje prawo powoływania się na takie uchybienia w dalszym toku 
postępowania, chyba że chodzi o przepisy postępowania, których naruszenie sąd 
powinien wziąć pod rozwagę z urzędu, lub że uczestnik uprawdopodobni, iż nie 
zgłosił zastrzeżenia bez swojej winy; 
- 3) braku konieczności dowodzenia faktów, które zostały przyznane w toku 
postępowania przez przeciwnika, jeżeli przyznanie nie budzi wątpliwości; 
- 4) możliwości uznania przez sąd faktów za przyznane, gdy uczestnik postępowania 
nie wypowie się co do twierdzeń przeciwnika o faktach i wynik całej sprawy na 
to pozwala, w zakresie, który jest uzasadniony przedmiotem sprawy, która ma 
być rozpoznana na rozprawie.

***
## Art. 219. {#art-219}

1. W postępowaniu upadłościowym orzeczenia zapadają w formie 
postanowień. Postanowienie oraz zarządzenie wydane na posiedzeniu niejawnym 
uzasadnia się z urzędu, gdy przysługuje na nie środek zaskarżenia. 
1a. Orzeczenia w chwili ich wydania są wraz z uzasadnieniem utrwalane 
wyłącznie w systemie teleinformatycznym obsługującym postępowanie sądowe 
z wykorzystaniem 
wzorców 
udostępnionych 
w tym systemie 
i opatrywane 
kwalifikowanym podpisem elektronicznym. 
1b. Uczestnicy postępowania oraz osoby przez nich upoważnione mają dostęp do 
akt postępowania za pośrednictwem systemu teleinformatycznego obsługującego 
postępowanie sądowe. 
1c. Jednocześnie z utrwaleniem w systemie teleinformatycznym obsługującym 
postępowanie sądowe orzeczenia sądu, sędziego-komisarza, referendarza sądowego 
i przewodniczącego w systemie teleinformatycznym obsługującym postępowanie 
sądowe zamieszcza się informację o terminie i sposobie wniesienia środka zaskarżenia 
albo informację o tym, że środek zaskarżenia nie przysługuje. 
1d. W postanowieniu oraz dokumencie, które dotyczą składnika masy upadłości, 
podaje się numer danego składnika ujawniony w spisie inwentarza. Postanowienie 
oraz dokument, które dotyczą składnika masy upadłości, obwieszcza się. 

©Kancelaria Sejmu 
 
 
 
s. 92/224 
 
2025-09-11 
 
1e. W postanowieniu oraz dokumencie, które dotyczą wierzytelności wierzyciela 
upadłego, podaje się numer zgłoszenia wierzytelności, a jeżeli została już złożona lista 
wierzytelności – także numer na liście wierzytelności. 
2. (uchylony) 
2a. (uchylony) 
3. Do uchwał rady wierzycieli i zgromadzenia wierzycieli przepisy ust. 1d i 1e 
stosuje się odpowiednio. 
4. Ujawnienia 
informacji 
o prawomocności 
orzeczenia 
może 
dokonać 
w systemie teleinformatycznym obsługującym postępowanie sądowe pracownik 
sekretariatu. Obwieszczenia o prawomocności orzeczenia wymaganego na podstawie 
przepisów ustawy dokonuje sąd, sędzia-komisarz, referendarz sądowy albo 
przewodniczący. 
Art. 219a. 1. Na podstawie obwieszczonych postanowień oraz dokumentów, 
a także ujawnionych przez syndyka informacji o likwidacji składników masy 
upadłości, w Rejestrze tworzy się rejestr danych dotyczących aktualnego składu 
i stanu masy upadłości, obejmujący informacje o ruchomościach, nieruchomościach, 
środkach pieniężnych oraz przysługujących upadłemu prawach majątkowych 
i wierzytelnościach. Zmiany danych dotyczących składu i stanu masy upadłości 
ujawnia 
się 
w Rejestrze 
niezwłocznie. 
Do 
zmiany 
danych 
dotyczących 
przysługujących upadłemu wierzytelności przepis art. 69 ust. 1ca stosuje się 
odpowiednio. 
2. Na podstawie prawomocnych postanowień oraz dokumentów, które dotyczą 
wierzytelności wierzycieli, oraz sprawozdań syndyka w aktach tworzy się rejestr 
danych dotyczących aktualnego stanu wierzytelności oraz niezaspokojonych przez 
syndyka zobowiązań masy upadłości.

***
## Art. 220. {#art-220}

1. Postanowienie wydane na posiedzeniu niejawnym doręcza się 
upadłemu, osobom, których postanowienie dotyczy, oraz syndykowi, jeżeli ustawa nie 
stanowi inaczej. Postanowień dotyczących ogółu wierzycieli nie doręcza się 
wierzycielom. 
2. Pisma oraz postanowienia, o których mowa w ust. 1, doręcza się za 
pośrednictwem systemu teleinformatycznego obsługującego postępowanie sądowe. 
Przepis art. 1311 § 2 Kodeksu postępowania cywilnego stosuje się. 

©Kancelaria Sejmu 
 
 
 
s. 93/224 
 
2025-09-11 
 
2a. Jeżeli na postanowienie albo zarządzenie służy środek zaskarżenia, 
postanowienie albo zarządzenie doręcza się wraz z uzasadnieniem. 
3. Przepisu ust. 2 nie stosuje się do doręczeń dokonywanych osobom, o których 
mowa w art. 216aa ust. 1. 
4. Osoby, o których mowa w art. 216aa ust. 1, mogą dokonać wyboru doręczenia 
elektronicznego, jeżeli wniosły pismo za pośrednictwem systemu teleinformatycznego 
obsługującego 
postępowanie 
sądowe. 
Oświadczenie 
o rezygnacji 
z wyboru 
doręczenia elektronicznego jest skuteczne w odniesieniu do pism, które zostały 
umieszczone w systemie teleinformatycznym obsługującym postępowanie sądowe po 
złożeniu oświadczenia o rezygnacji. 
5. Przepisu ust. 2 nie stosuje się do pierwszego doręczenia dokonywanego przez 
sąd, 
sędziego-komisarza, 
tymczasowego 
nadzorcę 
sądowego, 
zarządcę 
przymusowego, syndyka albo organ, do którego przepisy o syndyku stosuje się 
odpowiednio, osobie fizycznej, osobie prawnej oraz jednostce organizacyjnej 
niebędącej osobą prawną, której ustawa przyznaje zdolność prawną, jeżeli nie wniosła 
w sprawie żadnego pisma. Nie dotyczy to doręczeń dokonywanych tymczasowemu 
nadzorcy sądowemu, zarządcy przymusowemu, syndykowi albo organowi, do którego 
przepisy o syndyku stosuje się odpowiednio. 
6. Pisma oraz postanowienia, o których mowa w ust. 1, skierowane do osoby 
albo jednostki, która nie ma założonego konta w systemie teleinformatycznym 
obsługującym postępowanie sądowe, pozostawia się w aktach sprawy ze skutkiem 
doręczenia, o czym należy pouczyć przy pierwszym doręczeniu wraz z pouczeniem 
o sposobie 
założenia 
konta 
w systemie 
teleinformatycznym 
obsługującym 
postępowanie sądowe oraz sposobie uwierzytelnienia się. 
7. Minister Sprawiedliwości w porozumieniu z ministrem właściwym do spraw 
informatyzacji określi, w drodze rozporządzenia, tryb i sposób dokonywania doręczeń 
elektronicznych, mając na względzie zapewnienie skuteczności doręczeń oraz ochronę 
praw osób, którym pisma są doręczane. 
Art. 220a. Sędzia-komisarz 
w celu 
przyspieszenia 
postępowania 
może 
dokonywać 
wezwań, 
zawiadomień 
i doręczeń 
w sposób, 
który 
uzna 
w okolicznościach konkretnej sprawy za najbardziej celowy, nawet z pominięciem 
przepisów ogólnych, jeżeli sposób wezwania, zawiadomienia lub doręczenia 
umożliwia adresatowi zapoznanie się z treścią otrzymanej informacji. 

©Kancelaria Sejmu 
 
 
 
s. 94/224 
 
2025-09-11

***
## Art. 221. {#art-221}

1. W przypadkach przewidzianych w ustawie obwieszczenia dokonuje 
się w Rejestrze. W przypadku gdy od dnia obwieszczenia biegnie termin do wniesienia 
środka zaskarżenia, obwieszczeniu podlega także informacja o sposobie i terminie 
jego wniesienia. 
2. Na wniosek syndyka lub z urzędu sędzia-komisarz może zarządzić dokonanie 
obwieszczenia także w inny sposób. 
3. Na żądanie upadłego lub wierzyciela, na ich koszt, obwieszczenie może być 
dokonane w sposób przez nich wskazany. 
4. Każdy ma dostęp do danych zawartych w obwieszczanych w Rejestrze 
postanowieniach, zarządzeniach, dokumentach i informacjach. 
5. (uchylony)

***
## Art. 222. {#art-222}

1. Na postanowienia sądu upadłościowego i sędziego-komisarza 
zażalenie przysługuje w przypadkach wskazanych w ustawie. Zażalenia na 
postanowienia sędziego-komisarza rozpoznaje sąd upadłościowy jako sąd drugiej 
instancji. 
1a. Zażalenia na postanowienia sądu upadłościowego rozpoznaje sąd 
upadłościowy w innym składzie z wyjątkiem zażaleń na postanowienia, o których 
mowa w art. 163 ust. 4, art. 166 ust. 6, art. 172 ust. 1, art. 362 ust. 1, art. 365 ust. 3, 
art. 366 ust. 3, art. 368, art. 370a ust. 10, art. 370d ust. 1–2, art. 370e ust. 1, art. 370f 
ust. 3, art. 371 ust. 3, art. 4911 ust. 2, art. 4915 ust. 2, art. 49112a ust. 8, art. 49114 ust. 7, 
art. 49119 ust. 1–3, art. 49120 ust. 1, art. 49121 ust. 1 i art. 49122 ust. 1 i 2, które 
rozpoznaje sąd drugiej instancji w składzie trzech sędziów zawodowych. 
2. Odpis zażalenia wniesionego przez wierzyciela doręcza się upadłemu, 
syndykowi oraz osobom, których dotyczy zaskarżone postanowienie. 
3. Odpis zażalenia wniesionego przez upadłego doręcza się syndykowi oraz 
osobom, których dotyczy zaskarżone postanowienie. 
3a. Jeżeli ustawa przewiduje, że zażalenie może wnieść osoba niebędąca 
uczestnikiem postępowania upadłościowego, odpis zażalenia doręcza się upadłemu, 
syndykowi oraz osobom, których dotyczy zaskarżone postanowienie. 
4. Odpisu zażalenia na postanowienia dotyczące ogółu wierzycieli nie doręcza 
się wierzycielom. 
5. Zażalenie rozpoznaje się w terminie trzydziestu dni od dnia przedstawienia akt 
sądowi drugiej instancji. 

©Kancelaria Sejmu 
 
 
 
s. 95/224 
 
2025-09-11

***
## Art. 223. {#art-223}

1. Od postanowień sądu drugiej instancji skarga kasacyjna nie 
przysługuje, chyba że ustawa przewiduje inaczej. 
2. Skarga o stwierdzenie niezgodności z prawem prawomocnego orzeczenia nie 
przysługuje.

***
## Art. 224. {#art-224}

1. Termin do wniesienia środka zaskarżenia od postanowień wydanych 
na posiedzeniu niejawnym biegnie od dnia zamieszczenia postanowienia w systemie 
teleinformatycznym obsługującym postępowanie sądowe. Zażalenie wnosi się 
w terminie tygodnia. 
2. Jeżeli 
postanowienie 
wydane 
na 
posiedzeniu 
niejawnym 
podlega 
obwieszczeniu, termin do wniesienia środka zaskarżenia biegnie od dnia 
obwieszczenia. 
3. Dla osób, którym ustawa nakazuje doręczyć postanowienie wydane na 
posiedzeniu niejawnym, termin do wniesienia środka zaskarżenia biegnie od dnia 
doręczenia postanowienia. 
4. Jeżeli postanowienie, od którego przysługuje środek zaskarżenia, zostało 
ogłoszone na posiedzeniu jawnym, osoby zawiadomione o posiedzeniu w terminie 
tygodnia od dnia posiedzenia, a osoby, które nie zostały zawiadomione o posiedzeniu 
jawnym – od dnia zamieszczenia, a jeżeli postanowienie podlega obwieszczeniu – od 
dnia obwieszczenia postanowienia w Rejestrze, mogą złożyć wniosek o sporządzenie 
uzasadnienia i doręczenie postanowienia wraz z uzasadnieniem. Termin do wniesienia 
środka zaskarżenia biegnie od dnia doręczenia postanowienia wraz z uzasadnieniem. 
5. Termin do zaskarżenia czynności rady wierzycieli oraz syndyka i innych 
organów, które zgodnie z przepisami ustawy podlegają zaskarżeniu, biegnie od dnia 
zamieszczenia w systemie teleinformatycznym obsługującym postępowanie sądowe 
pouczenia o terminie i sposobie wniesienia środka zaskarżenia.

***
## Art. 225. {#art-225}

Skargi na czynności komornika w toku postępowania upadłościowego 
wnosi się do sędziego-komisarza w terminie tygodniowym od dnia zakończenia 
czynności. 
Sędzia-komisarz 
przesyła 
komornikowi 
uzyskany 
z systemu 
teleinformatycznego obsługującego postępowanie sądowe odpis skargi wraz 
z załącznikami.

***
## Art. 226. {#art-226}

1. Zabezpieczenie w przypadkach określonych w ustawie następuje 
przez złożenie do depozytu sądowego odpowiedniej sumy pieniężnej. 

©Kancelaria Sejmu 
 
 
 
s. 96/224 
 
2025-09-11 
 
2. O wydaniu sumy złożonej do depozytu orzeka sędzia-komisarz po 
wysłuchaniu syndyka i osób zainteresowanych. 
3. (uchylony) 
4. Na 
postanowienie 
sędziego-komisarza 
w przedmiocie 
zabezpieczenia 
przysługuje zażalenie.

***
## Art. 227. {#art-227}

Sumy pieniężne wchodzące do masy upadłości oraz sumy uzyskane ze 
zbycia rzeczy i praw obciążonych rzeczowo, jeżeli nie podlegają natychmiastowemu 
wydaniu, syndyk składa na oprocentowany rachunek bankowy lub na rachunek 
depozytowy Ministra Finansów.

***
## Art. 228. {#art-228}

1. W sekretariacie sądu umożliwia się uczestnikom postępowania oraz 
każdemu, kto dostatecznie usprawiedliwi potrzebę przejrzenia akt sądowych, dostęp 
do tych akt za pośrednictwem systemu teleinformatycznego obsługującego 
postępowanie sądowe. 
1a. (uchylony) 
2. Pobrane samodzielnie wydruki komputerowe orzeczeń, pism i dokumentów 
utrwalonych w systemie teleinformatycznym obsługującym postępowanie sądowe 
mają moc urzędowo poświadczonych odpisów oraz wyciągów, jeżeli mają cechy 
umożliwiające ich weryfikację z danymi zawartymi w systemie teleinformatycznym 
obsługującym postępowanie sądowe. 
3. Od dnia obwieszczenia w Rejestrze nie można zasłaniać się nieznajomością 
treści obwieszczenia, chyba że mimo zachowania należytej staranności nie można było 
dowiedzieć się o obwieszczeniu. 
Art. 228a. 1. Syndyk zakłada i prowadzi akta do zgłoszeń wierzytelności 
w systemie teleinformatycznym obsługującym postępowanie sądowe. 
2. Treść pism procesowych oraz dokumentów, o których mowa w art. 216aa 
ust. 1, wniesionych z pominięciem systemu teleinformatycznego obsługującego 
postępowanie sądowe, syndyk wprowadza do akt do zgłoszeń wierzytelności. Pisma 
procesowe oraz dokumenty składa się do zbioru dokumentów. Przepisy art. 216aa 
ust. 2 i 3 stosuje się odpowiednio. 
3. Akta do zgłoszeń wierzytelności udostępnia się w biurze syndyka, za 
pośrednictwem systemu teleinformatycznego obsługującego postępowanie sądowe, 
uczestnikom postępowania oraz każdemu, kto potrzebę ich przejrzenia dostatecznie 

©Kancelaria Sejmu 
 
 
 
s. 97/224 
 
2025-09-11 
 
usprawiedliwi. W tym celu biuro syndyka jest czynne w dni powszednie co najmniej 
cztery następujące po sobie godziny dziennie między godziną 8.00 a 20.00. 
4. Akta 
do 
zgłoszeń 
wierzytelności 
stanowią 
część 
akt 
sądowych. 
Po prawomocnym zakończeniu postępowania zbiór dokumentów jest przekazywany 
do sądu upadłościowego, który wydał postanowienie kończące postępowanie, 
i dołączany do akt sądowych. 
5. Akta do zgłoszeń wierzytelności oraz zbiór dokumentów mogą być 
udostępniane służbie nadzoru Ministra Sprawiedliwości. 
6. W przypadku odwołania, zmiany, zawieszenia oraz wygaśnięcia funkcji 
syndyka akta do zgłoszeń wierzytelności są przejmowane przez nowo wyznaczonego 
syndyka wraz ze zbiorem dokumentów. 
7. Minister Sprawiedliwości określi, w drodze rozporządzenia, sposób i tryb 
prowadzenia akt do zgłoszeń wierzytelności oraz zbioru dokumentów, w tym 
stosowane urządzenia ewidencyjne, a także udostępniania tych akt oraz zbioru 
dokumentów, mając na względzie zapewnienie bezpieczeństwa i ochrony danych 
w nich zawartych.

***
## Art. 229. {#art-229}

1. 
W sprawach 
nieuregulowanych 
ustawą 
do 
postępowania 
upadłościowego stosuje się odpowiednio przepisy księgi pierwszej części pierwszej 
Kodeksu postępowania cywilnego, z wyjątkiem art. 1302, art. 1391, art. 2051, art. 2052 
i art. 2054–20512 oraz przepisów o zawieszeniu i wznowieniu postępowania oraz 
postępowaniu w sprawach gospodarczych, chyba że ustawa stanowi inaczej. 
2. Pouczeń na piśmie dokonuje się z wykorzystaniem udostępnionych 
w systemie teleinformatycznym obsługującym postępowanie sądowe wzorów 
pouczeń. 
DZIAŁ V 
Koszty i inne zobowiązania masy upadłości

***
## Art. 230. {#art-230}

1. Do kosztów postępowania zalicza się wydatki bezpośrednio 
związane z ustaleniem, zabezpieczeniem, zarządem i likwidacją masy upadłości oraz 
ustaleniem wierzytelności, w szczególności wynagrodzenie syndyka oraz jego 
zastępcy, wynagrodzenie osób zatrudnionych przez syndyka oraz należności z tytułu 
składek na ubezpieczenia społeczne od wynagrodzenia tych osób, wynagrodzenie 
i wydatki członków rady wierzycieli, wydatki związane ze zgromadzeniem 
wierzycieli, koszty archiwizacji dokumentów, korespondencji, ogłoszeń, eksploatacji 

©Kancelaria Sejmu 
 
 
 
s. 98/224 
 
2025-09-11 
 
koniecznych pomieszczeń, podatki i inne daniny publiczne związane z likwidacją 
masy upadłości. 
2. Do innych zobowiązań masy upadłości zalicza się wszystkie niewymienione 
w ust. 1 zobowiązania 
masy 
upadłości 
powstałe 
po 
ogłoszeniu 
upadłości, 
w szczególności należności ze stosunku pracy przypadające za czas po ogłoszeniu 
upadłości, zobowiązania z tytułu bezpodstawnego wzbogacenia masy upadłości, 
zobowiązania z zawartych przez upadłego przed ogłoszeniem upadłości umów, 
których wykonania zażądał syndyk, inne zobowiązania powstałe z czynności syndyka 
oraz przypadające za czas po ogłoszeniu upadłości renty z tytułu odszkodowania za 
wywołanie choroby, niezdolności do pracy, kalectwa lub śmierci i renty z tytułu 
zamiany uprawnień objętych treścią prawa dożywocia na dożywotnią rentę.

***
## Art. 231. {#art-231}

1. (uchylony) 
2. Niezaspokojone z masy upadłości zobowiązania, o których mowa w art. 230, 
po zakończeniu postępowania upadłościowego ponosi upadły. W przypadku uchylenia 
postępowania upadłościowego sędzia-komisarz może zwolnić upadłego od 
ponoszenia kosztów sądowych. 
3. Na postanowienie sędziego-komisarza w przedmiocie kosztów przysługuje 
zażalenie.

***
## Art. 232. {#art-232}

1. W przypadku potrzeby, w szczególności w przypadku braku 
płynnych funduszów masy upadłości, sędzia-komisarz zwoła zgromadzenie 
wierzycieli w przedmiocie podjęcia uchwały co do wpłacenia przez wierzycieli 
zaliczki na pokrycie kosztów postępowania albo zobowiąże wierzycieli mających 
największe wierzytelności, których łączna wysokość wynosi co najmniej 30 % sumy 
wierzytelności przypadających wierzycielom uprawnionym do uczestniczenia 
w zgromadzeniu, do złożenia zaliczki na koszty postępowania. 
2. W przypadku gdy lista wierzytelności nie została sporządzona, wysokość 
wierzytelności przysługujących wierzycielom ustala się na podstawie spisu 
wierzycieli złożonego w postępowaniu w przedmiocie ogłoszenia upadłości lub na 
podstawie spisu wierzytelności sporządzonego w postępowaniu restrukturyzacyjnym 
albo na podstawie spisu bezspornych wierzytelności przedstawionego na żądanie 
sędziego-komisarza przez syndyka, sporządzonego na podstawie ksiąg rachunkowych 
upadłego. 

©Kancelaria Sejmu 
 
 
 
s. 99/224 
 
2025-09-11

***
## Art. 233. {#art-233}

Wierzycielowi nie przysługuje prawo do zwrotu kosztów poniesionych 
przez niego w postępowaniu upadłościowym. Wierzycielowi zwraca się jednak 
poniesione przez niego koszty postępowania wywołanego wniesieniem sprzeciwu co 
do uznania wierzytelności innego wierzyciela, jeżeli w wyniku wniesienia tego 
sprzeciwu odmówiono uznania zaskarżonej wierzytelności, jak również zwraca się 
zaliczkę na koszty postępowania, którą złożył na żądanie sędziego-komisarza albo 
zgodnie z uchwałą zgromadzenia wierzycieli, jeżeli fundusze masy upadłości 
wystarczą na jej pokrycie.

***
## Art. 234. {#art-234}

1. Nie można żądać od wierzyciela zwrotu do masy upadłości kosztów 
wynikłych z czynności podjętych przez wierzyciela w postępowaniu upadłościowym. 
2. Po zakończeniu postępowania upadłościowego upadły nie może żądać od 
wierzyciela zwrotu kosztów postępowania, chyba że nastąpiło uchylenie postępowania 
upadłościowego, a wierzyciel zgłosił wniosek o ogłoszenie upadłości w złej wierze.

***
## Art. 235. {#art-235}

1. Wierzyciel, który zgłosił wierzytelność po upływie terminu 
wyznaczonego do zgłaszania wierzytelności, ponosi zryczałtowane koszty 
postępowania upadłościowego wynikłe z tego zgłoszenia, nawet jeżeli opóźnienie 
powstało bez jego winy, w wysokości stanowiącej równowartość 15 % przeciętnego 
miesięcznego wynagrodzenia w sektorze przedsiębiorstw bez wypłat nagród z zysku 
w trzecim kwartale roku poprzedniego, ogłoszonego przez Prezesa Głównego Urzędu 
Statystycznego, chyba że zgłoszenie wierzytelności po upływie terminu jest wynikiem 
dokonania przez syndyka korekty deklaracji lub innego tego typu dokumentu 
obejmującego rozliczenie. 
2. Syndyk zobowiązuje wierzyciela do wpłaty zryczałtowanych kosztów, 
o których mowa w ust. 1, na rachunek bankowy wskazany przez syndyka 
w wyznaczonym terminie. 

©Kancelaria Sejmu 
 
 
 
s. 100/224 
 
2025-09-11 
 
TYTUŁ V 
Zgłoszenie i ustalenie wierzytelności 
DZIAŁ I 
Zgłoszenie wierzytelności 
## Rozdział 1. Wierzytelności podlegające zgłoszeniu

***
## Art. 236. {#art-236}

1. Wierzyciel 
osobisty 
upadłego, 
który 
chce 
uczestniczyć 
w postępowaniu upadłościowym, jeżeli niezbędne jest ustalenie jego wierzytelności, 
powinien w terminie oznaczonym w postanowieniu o ogłoszeniu upadłości zgłosić 
syndykowi swoją wierzytelność za pośrednictwem systemu teleinformatycznego 
obsługującego postępowanie sądowe. 
2. Uprawnienie do zgłoszenia wierzytelności przysługuje wierzycielowi 
ponadto, gdy jego wierzytelność była zabezpieczona hipoteką, zastawem, zastawem 
rejestrowym, zastawem skarbowym, hipoteką morską lub przez inny wpis w księdze 
wieczystej lub w rejestrze okrętowym. Jeżeli wierzyciel nie zgłosi tych wierzytelności, 
będą one umieszczone na liście wierzytelności z urzędu. 
3. Przepis ust. 2 stosuje się odpowiednio do wierzytelności zabezpieczonych 
hipoteką, zastawem lub zastawem rejestrowym, zastawem skarbowym, hipoteką 
morską na rzeczach wchodzących w skład masy upadłości, jeżeli upadły nie jest 
dłużnikiem osobistym, a wierzyciel chce w postępowaniu upadłościowym dochodzić 
swoich roszczeń z przedmiotu zabezpieczenia. 
4. Postanowienia niniejszego artykułu dotyczące wierzytelności stosuje się do 
innych należności podlegających zaspokojeniu z masy upadłości.

***
## Art. 237. {#art-237}

Nie wymagają zgłoszenia należności ze stosunku pracy. Należności 
z tego tytułu umieszcza się na liście wierzytelności z urzędu.

***
## Art. 238. {#art-238}

1. Przepisy 
dotyczące 
roszczeń 
pracowniczych 
stosuje 
się 
odpowiednio do roszczeń Funduszu Gwarantowanych Świadczeń Pracowniczych 
o zwrot z masy upadłości świadczeń Funduszu wypłaconych pracownikom upadłego. 
2. Do wierzytelności Kasy Rolniczego Ubezpieczenia Społecznego przepisy 
dotyczące wierzytelności Zakładu Ubezpieczeń Społecznych stosuje się odpowiednio. 

©Kancelaria Sejmu 
 
 
 
s. 101/224 
 
2025-09-11 
## Rozdział 2. Zgłoszenie wierzytelności

***
## Art. 239. {#art-239}

(uchylony) 
Art. 239a. Zgłoszenie wierzytelności przerywa bieg terminu przedawnienia. Po 
przerwaniu biegu terminu przedawnienia biegnie on na nowo od dnia następującego 
po dniu uprawomocnienia się postanowienia o zakończeniu albo umorzeniu 
postępowania upadłościowego.

***
## Art. 240. {#art-240}

W zgłoszeniu wierzytelności należy podać: 
- 1) imię i nazwisko wierzyciela albo jego nazwę oraz numer PESEL albo numer 
w Krajowym Rejestrze Sądowym, a w przypadku ich braku – inne dane 
umożliwiające jego jednoznaczną identyfikację oraz firmę, pod którą działa 
wierzyciel będący przedsiębiorcą, miejsce zamieszkania albo siedzibę, adres oraz 
NIP, jeżeli wierzyciel ma taki numer; 
- 2) określenie wierzytelności wraz z należnościami ubocznymi oraz wartość 
wierzytelności niepieniężnej; 
- 3) dowody stwierdzające istnienie wierzytelności; jeżeli wierzytelność została 
uznana 
w spisie 
wierzytelności 
sporządzonym 
w postępowaniu 
restrukturyzacyjnym, wystarczające jest powołanie się na tę okoliczność; 
- 4) kategorię, do której wierzytelność ma być zaliczona; 
- 5) zabezpieczenia związane z wierzytelnością; 
- 6) w razie zgłoszenia wierzytelności, w stosunku do której upadły nie jest 
dłużnikiem osobistym, przedmiot zabezpieczenia, z którego wierzytelność 
podlega zaspokojeniu; 
- 7) stan sprawy, jeżeli co do wierzytelności toczy się postępowanie sądowe, 
administracyjne, sądowoadministracyjne lub przed sądem polubownym; 
- 8) (uchylony) 
- 9) numer rachunku bankowego wierzyciela, jeżeli wierzyciel posiada taki rachunek. 
Art. 240a. Przez inne dane umożliwiające jednoznaczną identyfikację, o których 
mowa w art. 240 pkt 1, rozumie się dane, o których mowa w art. 22 ust. 4. 

©Kancelaria Sejmu 
 
 
 
s. 102/224 
 
2025-09-11 
## Rozdział 3. Sprawdzanie zgłoszonych wierzytelności

***
## Art. 241. {#art-241}

Jeżeli zgłoszenie wierzytelności nie odpowiada warunkom formalnym 
pisma procesowego lub wymaganiom określonym w art. 239 i art. 240 lub wierzyciel 
w terminie wyznaczonym przez syndyka nie wpłacił zryczałtowanych kosztów, 
o których mowa w art. 235 ust. 1, stosuje się odpowiednio przepis art. 130 Kodeksu 
postępowania cywilnego.

***
## Art. 242. {#art-242}

(uchylony) 
Art. 242a. 1. Zarządzenie syndyka o zwrocie zgłoszenia wierzytelności wymaga 
uzasadnienia. 
2. Na zarządzenie syndyka o zwrocie zgłoszenia wierzytelności wierzycielowi 
przysługuje skarga do sędziego-komisarza. Syndyk poucza wierzyciela występującego 
w sprawie bez adwokata, radcy prawnego, osoby posiadającej licencję doradcy 
restrukturyzacyjnego, 
rzecznika 
patentowego 
lub 
Prokuratorii 
Generalnej 
Rzeczypospolitej Polskiej o terminie i sposobie wniesienia skargi. 
3. Skarga powinna czynić zadość wymaganiom pisma procesowego oraz 
określać zwrócone zgłoszenie wierzytelności. 
4. Skargę wnosi się w terminie tygodniowym od dnia doręczenia zarządzenia 
syndyka o zwrocie zgłoszenia wierzytelności wraz z uzasadnieniem. 
5. Skargę wnosi się do syndyka. Syndyk za pośrednictwem systemu 
teleinformatycznego obsługującego postępowanie sądowe w terminie trzech dni od 
dnia otrzymania skargi przekazuje sędziemu-komisarzowi skargę wraz ze zgłoszeniem 
wierzytelności oraz zarządzeniem o zwrocie zgłoszenia wierzytelności, chyba że 
skargę w całości uwzględnia. O uwzględnieniu skargi syndyk zawiadamia skarżącego. 
6. Sędzia-komisarz rozpoznaje skargę w terminie tygodniowym od dnia jej 
wpływu do sędziego-komisarza, a gdy skarga zawiera braki formalne, które podlegają 
uzupełnieniu lub jeżeli od skargi nie uiszczono należnej opłaty, w terminie 
tygodniowym od dnia jej uzupełnienia lub opłacenia. 
7. Sędzia-komisarz odrzuca skargę wniesioną po upływie przepisanego terminu 
lub z innych przyczyn niedopuszczalną, jak również skargę, której braków nie 
uzupełniono w terminie lub od której nie uiszczono należnej opłaty. Na postanowienie 
sędziego-komisarza o odrzuceniu skargi służy zażalenie. 

©Kancelaria Sejmu 
 
 
 
s. 103/224 
 
2025-09-11

***
## Art. 243. {#art-243}

1. Syndyk sprawdza, czy zgłoszona wierzytelność znajduje 
potwierdzenie w księgach rachunkowych lub innych dokumentach upadłego albo we 
wpisach w księdze wieczystej lub rejestrach, oraz wzywa upadłego do złożenia 
w zakreślonym terminie oświadczenia, czy wierzytelność uznaje. 
2. W przypadku gdy zgłoszona wierzytelność nie znajduje potwierdzenia 
w księgach rachunkowych lub innych dokumentach upadłego albo we wpisach 
w księdze wieczystej lub rejestrach, syndyk wzywa wierzyciela do złożenia 
w terminie tygodnia dokumentów wskazanych w zgłoszeniu wierzytelności pod 
rygorem odmowy uznania wierzytelności. Termin ten nie podlega przedłużeniu ani 
przywróceniu. Syndyk może jednak uwzględnić dokumenty złożone po upływie 
terminu, 
jeżeli 
nie 
spowoduje 
to 
opóźnienia 
w przekazaniu 
listy 
sędziemu-komisarzowi. 
3. Wezwanie wierzyciela przez syndyka do złożenia dokumentów zawiera 
pouczenie o skutkach uchybienia terminowi. 
DZIAŁ II 
Lista wierzytelności 
## Rozdział 1. Ustalenie listy wierzytelności

***
## Art. 244. {#art-244}

Po upływie terminu do zgłoszenia wierzytelności i sprawdzeniu 
zgłoszonych wierzytelności syndyk niezwłocznie sporządza listę wierzytelności, nie 
później niż w terminie dwóch miesięcy od upływu okresu przewidzianego do 
zgłaszania wierzytelności.

***
## Art. 245. {#art-245}

1. Na liście wierzytelności umieszcza się w osobnych rubrykach: 
- 1) liczbę porządkową; 
- 2) imię i nazwisko wierzyciela albo jego nazwę oraz numer PESEL albo numer 
w Krajowym Rejestrze Sądowym, a w przypadku ich braku – inne dane 
umożliwiające jego jednoznaczną identyfikację, oraz firmę, pod którą działa 
wierzyciel będący przedsiębiorcą, miejsce zamieszkania albo siedzibę, adres oraz 
NIP, jeżeli wierzyciel ma taki numer; 
- 3) sumę każdej wierzytelności podlegającej uznaniu; 
- 4) kategorię, w jakiej wierzytelność podlega zaspokojeniu; 
- 5) informację o istnieniu i rodzaju zabezpieczenia wierzytelności; 

©Kancelaria Sejmu 
 
 
 
s. 104/224 
 
2025-09-11 
- 6) informację, czy wierzytelność jest uzależniona od warunku; 
- 7) (uchylony) 
- 8) uzasadnienie odmowy uznania zgłoszonej wierzytelności. 
- 9) (uchylony) 
1a. Przez inne dane umożliwiające jednoznaczną identyfikację, o których mowa 
w ust. 1 pkt 2, rozumie się dane, o których mowa w art. 22 ust. 4. 
2. (uchylony) 
3. (uchylony) 
4. Syndyk załącza do listy wierzytelności oświadczenie upadłego i podane przez 
niego uzasadnienie, jeżeli upadły złożył takie oświadczenie, albo wzmiankę, że upadły 
oświadczenia takiego nie złożył i z jakiej przyczyny. 
5. (uchylony) 
Art. 245a. 1. Wierzytelność za okres rozliczeniowy, w trakcie którego została 
ogłoszona upadłość, w szczególności z tytułu czynszu najmu lub dzierżawy, podatków 
lub składek na ubezpieczenia społeczne, ulega z mocy prawa proporcjonalnemu 
podziałowi na część traktowaną jak wierzytelność powstała przed dniem ogłoszenia 
upadłości oraz część traktowaną jak wierzytelność powstająca po dniu ogłoszenia 
upadłości. 
2. Jeżeli przedmiot leasingu nie stanowi u korzystającego upadłego środka 
trwałego w rozumieniu ustawy z dnia 26 lipca 1991 r. o podatku dochodowym od 
osób fizycznych (Dz. U. z 2025 r. poz. 163) oraz ustawy z dnia 15 lutego 1992 r. 
o podatku dochodowym od osób prawnych (Dz. U. z 2025 r. poz. 278), do umowy 
leasingu przepis ust. 1 stosuje się. 
3. Jeżeli rozliczenie należności publicznoprawnych wymaga sporządzenia 
deklaracji lub innego tego typu dokumentu obejmujących rozliczenie, obie części 
wierzytelności, o której mowa w ust. 1, ujmowane są w odrębnych deklaracjach lub 
innych tego typu dokumentach.

***
## Art. 246. {#art-246}

Wierzytelność 
niepieniężna 
będzie 
umieszczona 
na 
liście 
wierzytelności w sumie pieniężnej według jej wartości z dnia ogłoszenia upadłości.

***
## Art. 247. {#art-247}

1. Jeżeli w dniu ogłoszenia upadłości wierzytelność bez zastrzeżenia 
odsetek nie była jeszcze wymagalna, na liście wierzytelności umieszcza się sumę 
pieniężną wierzytelności pomniejszoną o odsetki ustawowe, nie wyższe jednak niż 

©Kancelaria Sejmu 
 
 
 
s. 105/224 
 
2025-09-11 
 
6 % i za czas od dnia ogłoszenia upadłości do dnia wymagalności, najwyżej jednak za 
dwa lata. 
2. Odsetki od wierzytelności pieniężnej umieszcza się na liście wierzytelności 
w kwocie naliczonej do dnia poprzedzającego dzień ogłoszenia upadłości włącznie.

***
## Art. 248. {#art-248}

1. Wierzytelność, 
której 
upadły 
jest 
współdłużnikiem, 
oraz 
wierzytelność poręczyciela upadłego z tytułu zwrotnego roszczenia umieszcza się na 
liście w takiej wysokości, w jakiej współdłużnik lub poręczyciel zaspokoił 
wierzyciela. 
2. Współdłużnik, poręczyciel, gwarant lub bank otwierający akredytywy może 
dokonać zgłoszenia wierzytelności przed zaspokojeniem wierzyciela. Na liście 
wierzytelności umieszcza się wierzytelność współdłużnika, poręczyciela, gwaranta 
lub banku otwierającego akredytywy, który nie zaspokoił wierzyciela jako 
wierzytelność warunkową, która nie uprawnia do głosowania na zgromadzeniu 
wierzycieli.

***
## Art. 249. {#art-249}

1. Wierzytelności z tytułu powtarzających się świadczeń, których czas 
trwania jest oznaczony, umieszcza się na liście jako sumę świadczeń za cały czas ich 
trwania, pomniejszoną o odsetki ustawowe, nie wyższe jednak niż 6 % i za czas od 
dnia ogłoszenia upadłości do dnia wymagalności każdego przyszłego świadczenia. 
2. Wierzytelności z tytułu świadczeń powtarzających się, których czas trwania 
oznaczono na czas życia uprawnionego lub innej osoby, albo nieoznaczonych co do 
czasu trwania umieszcza się na liście wierzytelności jako sumę stanowiącą wartość 
prawa. 
3. Jeżeli w umowie o prawo do świadczeń powtarzających się ustalona jest suma 
wykupu, sumę tę umieszcza się na liście jako wartość prawa. 
4. Przepisów ust. 1–3 nie stosuje się do świadczeń alimentacyjnych.

***
## Art. 250. {#art-250}

Wierzytelność zabezpieczoną hipoteką lub wpisem w rejestrze na 
majątku upadłego położonym za granicą umieszcza się na liście, jeżeli złożony 
zostanie dowód wykreślenia wpisu o zabezpieczeniu. Złożenia dowodu wykreślenia 
wpisu o zabezpieczeniu nie wymaga się, jeżeli postępowanie upadłościowe zostało 
uznane w kraju, w którym znajduje się przedmiot zabezpieczenia.

***
## Art. 251. {#art-251}

Wierzytelność w walucie obcej bez względu na termin jej 
wymagalności umieszcza się na liście po przeliczeniu na walutę polską według 
średniego kursu walut obcych w Narodowym Banku Polskim z dnia ogłoszenia 

©Kancelaria Sejmu 
 
 
 
s. 106/224 
 
2025-09-11 
 
upadłości, a gdy takiego kursu nie było – według średniej ceny rynkowej z tej daty. 
Umieszczenie na liście wierzytelności w przeliczeniu na walutę polską nie powoduje 
przekształcenia zobowiązania wyrażonego w walucie obcej na zobowiązanie 
w walucie polskiej. Zaspokojenie wierzytelności w wykonaniu planu podziału 
następuje w walucie polskiej.

***
## Art. 252. {#art-252}

1. Jeżeli wierzytelność została zgłoszona przez wierzyciela po upływie 
terminu wyznaczonego do zgłaszania wierzytelności, bez względu na przyczynę 
opóźnienia, czynności już dokonane w postępowaniu upadłościowym są skuteczne 
wobec tego wierzyciela, zgłoszenie nie ma wpływu na złożone już plany podziału, 
a jego uznaną wierzytelność uwzględnia się tylko w planach podziału funduszów 
masy upadłości sporządzonych po jej uznaniu. 
2. Jeżeli postanowienie dotyczące wierzytelności zgłoszonej po upływie terminu 
wyznaczonego do zgłaszania wierzytelności nie zostało wydane albo nie stało się 
prawomocne do dnia zakończenia lub umorzenia postępowania upadłościowego, 
postępowanie w tym zakresie podlega umorzeniu. Jeżeli jednak wierzytelność 
zgłoszono po zatwierdzeniu ostatecznego planu podziału funduszów masy upadłości, 
pozostawia się ją bez rozpoznania.

***
## Art. 253. {#art-253}

1. Po upływie terminu wyznaczonego do zgłaszania wierzytelności 
syndyk uzupełnia listę wierzytelności w miarę zgłaszania wierzytelności. 
2. Jeżeli zgłoszono wierzytelności po przekazaniu listy wierzytelności 
sędziemu-komisarzowi, syndyk sporządza uzupełnienie listy wierzytelności 
obejmujące takie wierzytelności wraz z zaznaczeniem, w jaki sposób będą 
zaspokajane. 
3. O uzupełnieniu listy wierzytelności obwieszcza się.

***
## Art. 254. {#art-254}

1. Zmianę wierzyciela po zgłoszeniu wierzytelności uwzględnia się na 
liście wierzytelności tylko wtedy, gdy została stwierdzona dokumentem urzędowym 
lub niebudzącym wątpliwości dokumentem prywatnym z podpisem urzędowo 
poświadczonym i gdy zmiana wierzyciela zgłoszona została syndykowi przed 
przekazaniem listy wierzytelności sędziemu-komisarzowi. Sędzia-komisarz może 
uwzględnić zmianę wierzyciela zgłoszoną po przekazaniu mu listy wierzytelności, 
a przed jej ostatecznym zatwierdzeniem, jeżeli nie spowoduje to opóźnienia 
w postępowaniu. 

©Kancelaria Sejmu 
 
 
 
s. 107/224 
 
2025-09-11 
 
2. Nieuwzględnienie zmian, o których mowa w ust. 1, nie pozbawia nabywcy 
wierzytelności możliwości realizacji jego uprawnień na podstawie przepisów ustawy 
w toku dalszego postępowania. 
## Rozdział 2. Zaskarżenie listy wierzytelności

***
## Art. 255. {#art-255}

1. (uchylony) 
2. O dacie złożenia listy wierzytelności obwieszcza się.

***
## Art. 256. {#art-256}

1. W terminie dwóch tygodni od dnia obwieszczenia, o którym mowa 
w art. 255 ust. 2, wierzyciel może złożyć do sędziego-komisarza sprzeciw co do: 
- 1) uznania wierzytelności – w przypadku wierzyciela umieszczonego na liście 
wierzytelności; 
- 2) odmowy uznania wierzytelności – w przypadku wierzyciela, któremu 
odmówiono uznania zgłoszonej wierzytelności. 
2. W tym samym terminie sprzeciw przysługuje upadłemu, o ile lista 
wierzytelności nie jest zgodna z jego wnioskami lub oświadczeniami. Jeżeli upadły 
nie składał oświadczeń, mimo iż był do tego wezwany, może zgłosić sprzeciw tylko 
wtedy, gdy wykaże, że nie złożył oświadczeń z przyczyn od niego niezależnych.

***
## Art. 257. {#art-257}

1. Sprzeciw powinien odpowiadać wymogom formalnym pisma 
procesowego, a ponadto wskazywać zaskarżoną wierzytelność oraz zawierać wniosek 
co do uznania albo odmowy uznania wierzytelności wraz z uzasadnieniem 
i wskazaniem dowodów na jego poparcie. 
2. Jeżeli sprzeciw nie odpowiada wymaganiom wskazanym w ust. 1 lub nie 
uiszczono należnej opłaty, przepis art. 130 ustawy z dnia 17 listopada 1964 r. – 
Kodeks postępowania cywilnego stosuje się odpowiednio. Sędzia-komisarz odrzuca 
sprzeciw wniesiony po upływie terminu lub z innych przyczyn niedopuszczalny, jak 
również sprzeciw, którego braków strona nie uzupełniła, lub sprzeciw, od którego 
strona nie wniosła należnej opłaty w wyznaczonym terminie. 
3. (uchylony)

***
## Art. 258. {#art-258}

1. Sprzeciw może być oparty wyłącznie na twierdzeniach i zarzutach 
wskazanych w zgłoszeniu wierzytelności. Inne twierdzenia i zarzuty mogą być 
zgłoszone tylko wtedy, gdy wierzyciel wykaże, że ich wcześniejsze zgłoszenie było 
niemożliwe albo że potrzeba ich wskazania wynikła później. 

©Kancelaria Sejmu 
 
 
 
s. 108/224 
 
2025-09-11 
 
2. Jeżeli wierzytelność jest stwierdzona prawomocnym orzeczeniem sądu, 
sprzeciw może być oparty tylko na zdarzeniach powstałych po zamknięciu rozprawy 
w sprawie, w której orzeczenie zostało wydane. Zdarzenia potwierdza się dowodem 
na piśmie. 
Art. 258a. 1. Sędzia-komisarz doręcza uzyskany z systemu teleinformatycznego 
obsługującego postępowanie sądowe odpis sprzeciwu syndykowi oraz odpowiednio 
upadłemu i wierzycielowi, którego wierzytelności sprzeciw dotyczy, wyznaczając 
termin wniesienia odpowiedzi na sprzeciw nie krótszy niż tydzień. Syndyk wraz 
z odpowiedzią na sprzeciw przekazuje sędziemu-komisarzowi za pośrednictwem 
systemu teleinformatycznego obsługującego postępowanie sądowe zgłoszenie 
wierzytelności oraz dokumenty złożone przez wierzyciela, o których mowa w art. 243 
ust. 2. 
2. Odpowiedź na sprzeciw wniesiona po upływie terminu lub której braków 
strona nie uzupełniła w terminie podlega zwrotowi. Do odpowiedzi na sprzeciw 
przepisy art. 257 ust. 1 i 2 zdanie pierwsze stosuje się odpowiednio. 
3. Sędzia-komisarz pomija twierdzenia i dowody niezgłoszone w sprzeciwie 
i odpowiedzi na sprzeciw, chyba że strona uprawdopodobni, że nie zgłosiła ich 
w sprzeciwie albo odpowiedzi na sprzeciw bez swojej winy lub że uwzględnienie 
spóźnionych twierdzeń i dowodów nie spowoduje zwłoki w rozpoznaniu sprawy.

***
## Art. 259. {#art-259}

1. Sędzia-komisarz, zastępca sędziego-komisarza albo wyznaczony 
sędzia rozpoznaje sprzeciw na posiedzeniu niejawnym w terminie dwóch miesięcy od 
jego wniesienia. Jeżeli sędzia-komisarz, zastępca sędziego-komisarza albo 
wyznaczony sędzia uzna za potrzebne wyznaczenie rozprawy, zawiadamia o niej 
syndyka, upadłego oraz wierzyciela, który wniósł sprzeciw, i wierzyciela, którego 
wierzytelności 
sprzeciw 
dotyczy. 
Niestawiennictwo 
tych 
osób, 
nawet 
usprawiedliwione, nie wstrzymuje wydania postanowienia. 
1a. Sędzia-komisarz, zastępca sędziego-komisarza albo wyznaczony sędzia 
może odstąpić od przeprowadzenia dowodu z zeznań świadka lub opinii biegłego, 
jeżeli świadek złożył zeznania albo biegły sporządził opinię w innym postępowaniu 
toczącym się przed sądem, sądem polubownym lub organem administracji. W takim 
przypadku dowodem są dokumenty, obejmujące treść zeznań świadka lub opinii 
biegłego. 

©Kancelaria Sejmu 
 
 
 
s. 109/224 
 
2025-09-11 
 
1b. W toku postępowania wywołanego wniesieniem sprzeciwu syndyk ma prawa 
i obowiązki uczestnika postępowania. 
2. Na postanowienie w przedmiocie sprzeciwu zażalenie przysługuje upadłemu, 
syndykowi oraz każdemu z wierzycieli. 
3. Uchylenie postanowienia w przedmiocie sprzeciwu i przekazanie sprawy do 
ponownego 
rozpoznania 
jest 
możliwe 
tylko 
w przypadku 
konieczności 
przeprowadzenia postępowania dowodowego w całości albo gdy przy rozpoznawaniu 
sprzeciwu doszło do nieważności postępowania, której skutków nie dało się usunąć 
w postępowaniu zażaleniowym. 
## Rozdział 3. Zatwierdzenie, prostowanie i uzupełnienie listy wierzytelności

***
## Art. 260. {#art-260}

1. Po uprawomocnieniu się postanowienia sędziego-komisarza 
w sprawie sprzeciwu, a w razie jego zaskarżenia, po uprawomocnieniu się 
postanowienia sądu, sędzia-komisarz dokonuje zmian na liście wierzytelności na 
podstawie tych postanowień oraz zatwierdza listę wierzytelności. 
2. Jeżeli 
sprzeciwu 
nie 
wniesiono, 
sędzia-komisarz 
zatwierdza 
listę 
wierzytelności po upływie terminu do jego wniesienia. 
3. Po upływie terminu do wniesienia sprzeciwów sędzia-komisarz może 
zatwierdzić częściowo listę wierzytelności w zakresie nieobjętym sprzeciwami. 
4. Postanowienie o zatwierdzeniu listy wierzytelności obwieszcza się.

***
## Art. 261. {#art-261}

Sędzia-komisarz 
może 
z urzędu 
dokonać 
zmian 
na 
liście 
wierzytelności w razie stwierdzenia, że na liście umieszczono wierzytelności, które 
w całości lub części nie istnieją, lub nie umieszczono na liście wierzytelności, które 
podlegają umieszczeniu na liście z urzędu. O dacie postanowienia o dokonaniu 
zmiany na liście obwieszcza się. Na postanowienie to przysługuje zażalenie. 
Informację o prawomocności postanowienia o dokonaniu zmiany na liście obwieszcza 
się.

***
## Art. 262. {#art-262}

1. Jeżeli wierzytelność zgłoszono po terminie wyznaczonym do 
zgłoszenia wierzytelności lub została ujawniona po tym terminie wierzytelność, która 
nie wymaga zgłoszenia, wierzytelność taką umieszcza się na uzupełnieniu listy 
wierzytelności. 

©Kancelaria Sejmu 
 
 
 
s. 110/224 
 
2025-09-11 
 
2. Lista wierzytelności ulega sprostowaniu stosownie do prawomocnych 
orzeczeń. Zmiana wysokości wierzytelności zaistniała po ustaleniu listy 
wierzytelności jest uwzględniana przy sporządzeniu planu podziału albo przy 
głosowaniu na zgromadzeniu wierzycieli. 
2a. Do sprostowania niedokładności, błędów pisarskich albo rachunkowych lub 
innych oczywistych omyłek na zatwierdzonej liście wierzytelności przepisy art. 350 
i art. 353 Kodeksu postępowania cywilnego stosuje się odpowiednio. Sprostowania 
dokonuje sędzia-komisarz. Sprostowania może dokonać również referendarz sądowy. 
Wniesienie skargi na postanowienie referendarza sądowego nie powoduje utraty mocy 
przez zaskarżone postanowienie. Sąd rozpoznaje skargę w składzie jednego sędziego 
jako sąd drugiej instancji, stosując odpowiednio przepisy o zażaleniu. Rozpoznając 
skargę, sąd wydaje postanowienie, w którym zaskarżone postanowienie referendarza 
sądowego utrzymuje w mocy albo je zmienia. Prawomocne postanowienie 
o sprostowaniu listy wierzytelności obwieszcza się. 
3. (uchylony)

***
## Art. 263. {#art-263}

Odmowa uznania wierzytelności według przepisów niniejszego działu 
nie stanowi przeszkody do jej dochodzenia we właściwym trybie. Z uwzględnieniem 
art. 145 ust. 1 dochodzenie wierzytelności, której odmówiono uznania, jest możliwe 
dopiero po umorzeniu lub zakończeniu postępowania upadłościowego.

***
## Art. 264. {#art-264}

1. Z zastrzeżeniem art. 296, po zakończeniu lub umorzeniu 
postępowania upadłościowego wyciąg z zatwierdzonej przez sędziego-komisarza listy 
wierzytelności, zawierający oznaczenie wierzytelności oraz sumy otrzymanej na jej 
poczet przez wierzyciela, jest tytułem egzekucyjnym przeciwko upadłemu. 
2. Upadły może żądać ustalenia, że wierzytelność objęta listą wierzytelności nie 
istnieje albo istnieje w mniejszym zakresie, jeżeli nie uznał wierzytelności zgłoszonej 
w postępowaniu upadłościowym i nie zapadło co do niej jeszcze prawomocne 
orzeczenie sądowe. 
3. Po nadaniu wyciągowi z listy wierzytelności klauzuli wykonalności, zarzut, że 
wierzytelność objęta listą wierzytelności nie istnieje albo że istnieje w mniejszym 
zakresie, upadły może podnieść w drodze powództwa o pozbawienie tytułu 
wykonawczego wykonalności. 
4. Przepisu ust. 1 nie stosuje się w stosunku do wierzycieli, wobec których 
upadły nie był dłużnikiem osobistym. 

©Kancelaria Sejmu 
 
 
 
s. 111/224 
 
2025-09-11

***
## Art. 265. {#art-265}

1. Jeżeli sąd umorzył część zobowiązań upadłego, które nie zostały 
zaspokojone w postępowaniu upadłościowym, w wyciągu z listy wierzytelności, 
o którym mowa w art. 264 ust. 1, zamieszcza się wzmiankę określającą zakres 
odpowiedzialności upadłego. 
2. Jeżeli sąd umorzył całość zobowiązań upadłego, które nie zostały zaspokojone 
w postępowaniu upadłościowym, przepisu art. 264 nie stosuje się.

***
## Art. 266. {#art-266}

Wierzyciel może żądać zwrotu dokumentów złożonych w celu 
udowodnienia wierzytelności. Na zarządzenie sędziego-komisarza sekretarz sądowy 
wydaje dokumenty z zaznaczeniem na nich, w jakiej sumie wierzytelność została 
uznana. 
TYTUŁ VA 
Układ w upadłości 
Art. 266a. 1. W postępowaniu upadłościowym dopuszczalne jest zawarcie 
układu. 
2. Propozycje układowe w postępowaniu upadłościowym mogą zgłosić upadły, 
wierzyciel oraz syndyk. 
Art. 266b. 1. Podmioty uprawnione do złożenia propozycji układowych mogą 
wraz z propozycjami złożyć wniosek o całkowite lub częściowe wstrzymanie 
likwidacji masy upadłości do czasu zatwierdzenia układu. 
2. Niedopuszczalne jest wstrzymanie likwidacji masy upadłości, jeżeli 
propozycje układowe nie przewidują zaspokojenia wierzytelności nieobjętych 
układem niezwłocznie po zatwierdzeniu układu i prawomocnym zakończeniu 
postępowania na tej podstawie. 
3. Niedopuszczalne jest wstrzymanie likwidacji w zakresie przedmiotu 
obciążonego hipoteką, zastawem, zastawem rejestrowym, zastawem skarbowym lub 
hipoteką morską, jeżeli sprzeciwi się temu wierzyciel, którego wierzytelność jest w ten 
sposób zabezpieczona. Jeżeli sprzeciw wierzyciela wpłynął do sędziego-komisarza po 
wydaniu postanowienia o wstrzymaniu likwidacji, sędzia-komisarz uchyla swoje 
postanowienie w tym zakresie. 
4. Sędzia-komisarz może wstrzymać likwidację masy upadłości, jeżeli zostały 
spełnione przesłanki zwołania zgromadzenia wierzycieli w celu głosowania nad 
układem, o których mowa w art. 266c ust. 1. 

©Kancelaria Sejmu 
 
 
 
s. 112/224 
 
2025-09-11 
 
5. Sędzia-komisarz wstrzymuje likwidację masy upadłości, jeżeli zostały 
spełnione przesłanki zwołania zgromadzenia wierzycieli w celu głosowania nad 
układem, o których mowa w art. 266c ust. 2. 
6. Sędzia-komisarz wstrzymuje likwidację masy upadłości wyłącznie w zakresie, 
jaki jest niezbędny do wykonania układu. 
Art. 266c. 1. Sędzia-komisarz może zwołać zgromadzenie wierzycieli w celu 
głosowania nad układem, jeżeli zostało uprawdopodobnione, że układ zostanie 
przyjęty przez wierzycieli i wykonany. 
2. Sędzia-komisarz zwołuje zgromadzenie wierzycieli, jeżeli wniosek jest 
popierany przez wierzyciela lub wierzycieli posiadających łącznie co najmniej 50 % 
sumy wierzytelności przysługujących wierzycielom uprawnionym do głosowania nad 
układem. 
3. Zgromadzenie wierzycieli zwołuje się po zatwierdzeniu listy wierzytelności. 
Jeżeli sędzia-komisarz zatwierdził częściowo listę wierzytelności w zakresie 
nieobjętym sprzeciwami, zgromadzenie wierzycieli zwołuje się, jeżeli suma 
wierzytelności objętych sprzeciwami nie przekracza 15 % sumy wierzytelności 
objętych układem. 
Art. 266d. Po prawomocnym zatwierdzeniu układu sąd wydaje postanowienie 
o zakończeniu postępowania. Przepisy art. 362–367 stosuje się odpowiednio. 
Art. 266e. W przypadku 
zakończenia 
postępowania 
po 
prawomocnym 
zatwierdzeniu układu wynagrodzenie ostateczne syndyka może zostać ustalone na 
podstawie przepisów art. 55 oraz art. 58–61 ustawy z dnia 15 maja 2015 r. – Prawo 
restrukturyzacyjne, jeżeli będzie to korzystne dla syndyka i jest uzasadnione jego 
zaangażowaniem w skuteczne zawarcie układu. 
Art. 266f. W zakresie nieuregulowanym w niniejszym tytule do układu i jego 
skutków przepisy Prawa restrukturyzacyjnego stosuje się odpowiednio, przy czym 
czynności zastrzeżone dla nadzorcy sądowego lub zarządcy wykonuje syndyk. 
TYTUŁ VI 
(uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 113/224 
 
2025-09-11 
 
TYTUŁ VII 
Likwidacja masy upadłości 
DZIAŁ I 
Przepisy ogólne

***
## Art. 306. {#art-306}

Po ogłoszeniu upadłości syndyk niezwłocznie przystępuje do spisu 
inwentarza i oszacowania masy upadłości oraz sporządzenia planu likwidacyjnego. 
Syndyk składa sędziemu-komisarzowi spis inwentarza wraz z planem likwidacyjnym 
w terminie trzydziestu dni od dnia ogłoszenia upadłości. Plan likwidacyjny określa 
proponowane sposoby sprzedaży składników majątku upadłego, w szczególności 
sprzedaży przedsiębiorstwa, termin sprzedaży, preliminarz wydatków oraz 
ekonomiczne uzasadnienie dalszego prowadzenia działalności gospodarczej.

***
## Art. 307. {#art-307}

1. Na podstawie spisu inwentarza i innych dokumentów upadłego oraz 
oszacowania syndyk sporządza sprawozdanie finansowe na dzień poprzedzający 
ogłoszenie upadłości i niezwłocznie przedkłada je sędziemu-komisarzowi. 
2. Jeżeli z jakichkolwiek przyczyn syndyk nie może sporządzić spisu inwentarza, 
oszacowania, planu likwidacji lub sprawozdania finansowego w terminie, o którym 
mowa w art. 306, składa sędziemu-komisarzowi, w terminie miesiąca od dnia 
ogłoszenia upadłości, pisemne sprawozdanie ogólne o stanie masy upadłości 
i o możliwości zaspokojenia wierzycieli. Złożenie sprawozdania nie zwalnia syndyka 
od obowiązku sporządzenia dokumentów, o których mowa w ust. 1, gdy tylko będzie 
to możliwe.

***
## Art. 308. {#art-308}

1. Po sporządzeniu spisu inwentarza i sprawozdania finansowego albo 
po złożeniu pisemnego sprawozdania ogólnego syndyk przeprowadza likwidację masy 
upadłości. 
2. Syndyk jest obowiązany do podejmowania działań umożliwiających 
zakończenie likwidacji w ciągu sześciu miesięcy od dnia ogłoszenia upadłości. 
Sędzia-komisarz i rada wierzycieli rozpoznają wniosek o wyrażenie zgody na 
określony sposób likwidacji nie później niż w terminie dwóch tygodni od dnia 
przedstawienia im wniosku przez syndyka.

***
## Art. 309. {#art-309}

Sędzia-komisarz może wstrzymać likwidację masy upadłości do czasu 
uprawomocnienia się postanowienia o ogłoszeniu upadłości. 

©Kancelaria Sejmu 
 
 
 
s. 114/224 
 
2025-09-11

***
## Art. 310. {#art-310}

1. Przed rozpoczęciem likwidacji masy upadłości syndyk może 
sprzedać z wolnej ręki bez zezwolenia rady wierzycieli ruchomości, jeżeli jest to 
potrzebne na zaspokojenie kosztów postępowania. Ponadto syndyk może sprzedać 
ruchomości, które ulegają szybkiemu zepsuciu lub wskutek opóźnienia sprzedaży 
straciłyby znacznie na wartości albo których przechowanie pociąga za sobą koszty 
zbyt wysokie w stosunku do ich wartości. 
2. Jeżeli sędzia-komisarz wstrzyma likwidację masy upadłości, przepis 
ust. 1 stosuje się w zakresie określonym przez sędziego-komisarza.

***
## Art. 311. {#art-311}

1. Likwidacji masy upadłości dokonuje się przez sprzedaż z wolnej 
ręki lub w drodze przetargu lub aukcji przedsiębiorstwa upadłego w całości lub jego 
zorganizowanych części, nieruchomości i ruchomości, wierzytelności oraz innych 
praw majątkowych wchodzących w skład masy upadłości albo przez ściągnięcie 
wierzytelności od dłużników upadłego i wykonanie innych jego praw majątkowych. 
1a. Skarbowi Państwa reprezentowanemu przez Ministra Obrony Narodowej 
przysługuje prawo wykupu składników majątku służących do prowadzenia 
działalności w dziedzinie obronności i bezpieczeństwa państwa. 
1aa. O zamiarze sprzedaży składników majątku służących do prowadzenia 
działalności w dziedzinie obronności i bezpieczeństwa państwa syndyk zawiadamia 
Ministra Obrony Narodowej, który może przedstawić sędziemu-komisarzowi 
w terminie: 
- 1) tygodnia od dnia zawiadomienia – opinię albo 
- 2) trzydziestu dni od dnia zawiadomienia – oświadczenie o skorzystaniu z prawa 
wykupu, o którym mowa w ust. 1a. 
1ab. Wykup, o którym mowa w ust. 1a, jest dokonywany po cenie sprzedaży 
ustalonej na podstawie dowodu z opinii biegłego, przy czym cena nie może być niższa 
niż kwota możliwa do uzyskania w postępowaniu upadłościowym przy likwidacji na 
zasadach ogólnych, pomniejszona o koszty postępowania, które należałoby ponieść 
w związku z likwidacją w takim trybie. Koszty opinii biegłego ponosi Skarb Państwa. 
1ac. Na postanowienie ustalające cenę sprzedaży, po której jest dokonywany 
wykup, o którym mowa w ust. 1a, zażalenie przysługuje Ministrowi Obrony 
Narodowej, wierzycielom oraz upadłemu. 
1ad. W przypadku wykupu składników majątku obciążonych zastawem 
rejestrowym, przepisów art. 327 i art. 328 nie stosuje się. Z ceny sprzedaży 

©Kancelaria Sejmu 
 
 
 
s. 115/224 
 
2025-09-11 
 
wyodrębnia się wartość rzeczy obciążonych zastawem i przeznacza się ją na 
zaspokojenie zastawnika stosownie do przepisów art. 336 i art. 340. 
1b. (uchylony) 
1c. (uchylony) 
2. W przypadkach wskazanych w ustawie likwidacja ruchomości obciążonych 
zastawem rejestrowym oraz wierzytelności i praw obciążonych zastawem 
rejestrowym lub zastawem finansowym może nastąpić także przez przejęcie ich przez 
wierzyciela będącego zastawnikiem zastawu rejestrowego lub zastawu finansowego, 
jeżeli umowa o ustanowieniu zastawu przewiduje zaspokojenie zastawnika w drodze 
przejęcia przedmiotu zastawu. 
3. Przepisy dotyczące likwidacji w drodze sprzedaży ruchomości oraz przejęcia 
ruchomości obciążonych zastawem rejestrowym stosuje się odpowiednio do 
sprzedaży i przejęcia przez wierzyciela zwierząt, jeżeli nie jest to sprzeczne 
z przepisami dotyczącymi ochrony zwierząt.

***
## Art. 312. {#art-312}

1. Po ogłoszeniu upadłości można prowadzić dalej przedsiębiorstwo 
upadłego, jeżeli możliwe jest zawarcie układu z wierzycielami lub możliwa jest 
sprzedaż przedsiębiorstwa upadłego w całości lub jego zorganizowanych części. 
2. Jeżeli syndyk prowadzi przedsiębiorstwo upadłego, powinien podjąć wszelkie 
działania zapewniające zachowanie przedsiębiorstwa co najmniej w niepogorszonym 
stanie. 
3. Syndyk nie może prowadzić dalej przedsiębiorstwa upadłego, jeżeli na 
upadłym ciąży obowiązek zwrotu pomocy publicznej. Rada wierzycieli może 
zezwolić na zwrot pomocy publicznej udzielonej niezgodnie z prawem i dalsze 
prowadzenie przedsiębiorstwa upadłego, jeżeli zostanie uprawdopodobnione, że mimo 
zwrotu pomocy publicznej udzielonej niezgodnie z prawem pozostali wierzyciele 
zostaną zaspokojeni w większym stopniu ze względu na sprzedaż prowadzonego 
przedsiębiorstwa za większą kwotę lub w wyniku zawarcia i wykonania układu.

***
## Art. 313. {#art-313}

1. Sprzedaż dokonana w postępowaniu upadłościowym ma skutki 
sprzedaży egzekucyjnej. Nabywca składników masy upadłości nie odpowiada za 
zobowiązania podatkowe upadłego, także powstałe po ogłoszeniu upadłości. 
2. Sprzedaż nieruchomości powoduje wygaśnięcie praw oraz praw i roszczeń 
osobistych ujawnionych przez wpis do księgi wieczystej albo nieujawnionych w ten 
sposób, lecz zgłoszonych syndykowi w terminie określonym w art. 51 ust. 1 pkt 5. 

©Kancelaria Sejmu 
 
 
 
s. 116/224 
 
2025-09-11 
 
W miejsce prawa, które wygasło, uprawniony nabywa prawo do zaspokojenia 
wartości wygasłego prawa z ceny uzyskanej ze sprzedaży obciążonej nieruchomości. 
Skutek ten powstaje z chwilą zawarcia umowy sprzedaży. Podstawą do wykreślenia 
praw, które wygasły na skutek sprzedaży, jest prawomocny plan podziału sumy 
uzyskanej ze sprzedaży nieruchomości obciążonej. Podstawą wykreślenia hipoteki jest 
umowa sprzedaży nieruchomości. 
3. Pozostają w mocy bez potrącania ich wartości z ceny nabycia służebność drogi 
koniecznej, 
służebność 
przesyłu 
oraz 
służebność 
ustanowiona 
w związku 
z przekroczeniem granicy przy wznoszeniu budowli lub innego urządzenia. 
Użytkowanie oraz prawa dożywotnika pozostają w mocy, jeżeli przysługuje im 
pierwszeństwo przed wszystkimi hipotekami lub jeżeli nieruchomość nie jest 
hipotekami obciążona albo jeżeli wartość użytkowania i praw dożywotnika znajduje 
pełne pokrycie w cenie nabycia. Jednakże w tym ostatnim wypadku wartość tych praw 
będzie zaliczona na cenę nabycia. 
4. Na wniosek właściciela nieruchomości władnącej, zgłoszony najpóźniej 
w zarzutach do planu podziału sumy uzyskanej ze sprzedaży nieruchomości 
obciążonej, sędzia-komisarz może postanowić, że służebność gruntowa, która nie 
znajduje pełnego pokrycia w cenie nabycia, zostaje utrzymana w mocy, jeżeli jest dla 
nieruchomości władnącej konieczna, a nie obniża w sposób istotny wartości 
nieruchomości obciążonej. Na postanowienie sędziego-komisarza przysługuje 
zażalenie. Jeżeli wniosek o wyłączenie zgłoszony został w zarzutach, podlega 
rozpoznaniu razem z zarzutami. 
5. Przepisy ust. 2–4 stosuje się odpowiednio do sprzedaży prawa użytkowania 
wieczystego, spółdzielczego własnościowego prawa do lokalu i statku morskiego 
wpisanego do rejestru okrętowego. 
6. Do sprzedaży ułamkowej części nieruchomości odpowiednie zastosowanie 
mają przepisy art. 1004, art. 1005, art. 1007, art. 1009, art. 1012 i art. 1013 Kodeksu 
postępowania cywilnego.

***
## Art. 314. {#art-314}

1. W razie zbycia przedsiębiorstwa, w którego skład wchodzą 
przedmioty obciążone ograniczonymi prawami rzeczowymi, wartość składników 
mienia obciążonych tymi prawami podlega ujawnieniu w umowie sprzedaży, 
a uzyskana cena podlega podziałowi z uwzględnieniem art. 336 i 340. 
2. Przepis ust. 1 stosuje się odpowiednio w razie zbycia zorganizowanej części 
przedsiębiorstwa. 

©Kancelaria Sejmu 
 
 
 
s. 117/224 
 
2025-09-11

***
## Art. 315. {#art-315}

Sędzia-komisarz może wyłączyć określone składniki majątku z masy 
upadłości, w tym nieruchomość lub jej ułamkową część, jeżeli nie można ich zbyć 
z zachowaniem przepisów ustawy, a dalsze pozostawanie tych składników majątku 
w masie upadłości będzie niekorzystne dla wierzycieli z uwagi na obciążenie masy 
upadłości związanymi z tym kosztami. Na postanowienie sędziego-komisarza 
przysługuje zażalenie. 
DZIAŁ II 
Sprzedaż przedsiębiorstwa lub jego zorganizowanej części oraz nieruchomości, 
prawa użytkowania wieczystego, spółdzielczego własnościowego prawa do 
lokalu i statku morskiego wpisanego do rejestru okrętowego

***
## Art. 316. {#art-316}

1. Przedsiębiorstwo upadłego powinno być sprzedane jako całość, 
chyba że nie jest to możliwe. 
2. Sprzedaż przedsiębiorstwa upadłego może być, po wyrażeniu zgody przez 
sędziego-komisarza, poprzedzona umową dzierżawy na czas określony z prawem 
pierwokupu, jeżeli przemawiają za tym względy ekonomiczne. 
3. (uchylony) 
4. O sprzedaży przedsiębiorstwa upadłego obwieszcza się.

***
## Art. 317. {#art-317}

1. Na nabywcę przedsiębiorstwa upadłego przechodzą wszelkie 
koncesje, zezwolenia, licencje i ulgi, które zostały udzielone upadłemu, chyba że 
odrębne ustawy stanowią inaczej. 
2. Nabywca może używać oznaczenia przedsiębiorstwa upadłego, w którym 
mieści się jego nazwisko, tylko za zgodą upadłego. Nabywca przedsiębiorstwa 
upadłego nabywa je w stanie wolnym od obciążeń i nie odpowiada za zobowiązania 
upadłego. Wszelkie obciążenia na składnikach przedsiębiorstwa wygasają, 
z wyjątkiem obciążeń wymienionych w art. 313 ust. 3 i 4. 
2a. Przepis art. 231 ustawy z dnia 26 czerwca 1974 r. – Kodeks pracy stosuje się 
odpowiednio. 
3. Z chwilą zawiadomienia sądu, sądu polubownego lub organu prowadzącego 
postępowanie administracyjne o nabyciu przedsiębiorstwa upadłego, nabywca 
przedsiębiorstwa wstępuje z mocy prawa w miejsce upadłego lub syndyka do 
postępowań cywilnych, administracyjnych, sądowo-administracyjnych oraz przed 
sądami polubownymi, dotyczących przedsiębiorstwa lub jego składników, bez 
zezwolenia strony przeciwnej. 

©Kancelaria Sejmu 
 
 
 
s. 118/224 
 
2025-09-11

***
## Art. 318. {#art-318}

1. Jeżeli sprzedaż przedsiębiorstwa upadłego jako całości nie jest 
możliwa ze względów ekonomicznych lub innych przyczyn, można sprzedać 
zorganizowaną część przedsiębiorstwa. 
2. Przepis ust. 1 stosuje się odpowiednio do zbioru rzeczy lub praw obciążonych 
zastawem rejestrowym, które wchodzą w skład przedsiębiorstwa. Suma uzyskana ze 
sprzedaży takiego zbioru podlega podziałowi stosownie do przepisów art. 336 i 340.

***
## Art. 319. {#art-319}

1. Jeżeli planowana jest sprzedaż przedsiębiorstwa upadłego w całości, 
przy sporządzaniu spisu inwentarza i oszacowania masy upadłości, albo odrębnie, 
jeżeli możliwość takiej sprzedaży ujawniła się na późniejszym etapie, biegły wybrany 
przez syndyka sporządza opis i oszacowanie przedsiębiorstwa upadłego. 
2. Opis przedsiębiorstwa powinien określać w szczególności przedmiot 
działalności przedsiębiorstwa, nieruchomości wchodzące w jego skład, ich obszar oraz 
oznaczenie księgi wieczystej lub zbioru dokumentów, inne środki trwałe, stwierdzone 
prawa, a także obciążenia. 
3. W oszacowaniu należy odrębnie podać wartość przedsiębiorstwa w całości 
oraz jego zorganizowanych części, jeżeli mogą być wydzielone do sprzedaży. 
4. Jeżeli składniki przedsiębiorstwa są obciążone hipoteką, zastawem, zastawem 
rejestrowym, zastawem skarbowym, hipoteką morską lub innymi prawami i skutkami 
ujawnienia praw i roszczeń osobistych, w oszacowaniu należy oddzielnie podać, które 
z tych praw pozostają w mocy po sprzedaży, a także ich wartość oraz wartość 
składników nimi obciążonych oraz stosunek wartości poszczególnych składników 
obciążonych do wartości przedsiębiorstwa. 
5. Zarzuty na opis i oszacowanie wnosi się w terminie tygodnia od dnia 
obwieszczenia o ich przekazaniu sędziemu-komisarzowi. Zarzuty rozpoznaje 
sędzia-komisarz. W przypadku wątpliwości co do rzetelności lub poprawności opisu 
i oszacowania, sędzia-komisarz wskazuje biegłego do sporządzenia nowego opisu 
i oszacowania. 
6. Przepis ust. 4 stosuje się odpowiednio w przypadku rzeczy, wierzytelności 
i innych praw przeniesionych na wierzyciela w celu zabezpieczenia wierzytelności, 
o ile mają być one sprzedane w ramach przedsiębiorstwa.

***
## Art. 320. {#art-320}

1. Sprzedaż mienia uregulowana przepisami niniejszego działu może 
nastąpić w drodze przetargu lub aukcji, do których przepisy Kodeksu cywilnego 
stosuje się odpowiednio, z tym że: 

©Kancelaria Sejmu 
 
 
 
s. 119/224 
 
2025-09-11 
- 1) warunki przetargu lub aukcji zatwierdza sędzia-komisarz; 
- 2) o przetargu lub aukcji należy zawiadomić przez obwieszczenie co najmniej na 
dwa tygodnie, a jeżeli przetarg albo aukcja dotyczy przedsiębiorstwa spółki 
publicznej – co najmniej na sześć tygodni przed terminem posiedzenia 
wyznaczonego w celu ich przeprowadzenia; 
- 3) przetarg lub aukcję przeprowadza się na posiedzeniu jawnym; 
- 4) przetarg lub aukcję prowadzi syndyk pod nadzorem sędziego-komisarza; 
- 5) wyboru oferenta dokonuje syndyk; wybór wymaga zatwierdzenia przez 
sędziego-komisarza; 
- 6) postanowienie zatwierdzające wybór oferenta sędzia-komisarz może wydać na 
posiedzeniu niejawnym; 
- 7) sędzia-komisarz może odroczyć zatwierdzenie wyboru oferenta o tydzień; w tym 
przypadku postanowienie o zatwierdzeniu wyboru oferenta obwieszcza się. 
2. Na postanowienie sędziego-komisarza o zatwierdzeniu wyboru oferenta 
przysługuje zażalenie. 
3. Przy 
sprzedaży 
nieruchomości, 
prawa 
użytkowania 
wieczystego, 
spółdzielczego własnościowego prawa do lokalu oraz statku morskiego wpisanego do 
rejestru okrętowego przepisy art. 317 ust. 3 i art. 319 stosuje się odpowiednio.

***
## Art. 321. {#art-321}

1. Syndyk zawiera umowę sprzedaży w terminie określonym przez 
sędziego-komisarza, nie dłuższym niż cztery miesiące od dnia zatwierdzenia wyboru 
oferenta przez sędziego-komisarza. 
2. Jeżeli do zawarcia umowy nie dojdzie z winy oferenta, sędzia-komisarz 
wydaje postanowienie o ogłoszeniu nowego przetargu albo aukcji, w których nie może 
uczestniczyć oferent, który nie zawarł umowy.

***
## Art. 322. {#art-322}

(uchylony)

***
## Art. 323. {#art-323}

(uchylony)

***
## Art. 324. {#art-324}

1. Jeżeli rada wierzycieli udzieliła zezwolenia, o którym mowa 
w art. 206 ust. 1 pkt 3, spółka z udziałem ponad połowy pracowników upadłego 
będącego spółką handlową z udziałem Skarbu Państwa ma pierwszeństwo w nabyciu 
przedsiębiorstwa upadłego albo jego zorganizowanej części nadającej się do 
prowadzenia działalności gospodarczej. 
2. Syndyk w pierwszej kolejności składa ofertę sprzedaży spółce pracowniczej, 
o której mowa w ust. 1. 

©Kancelaria Sejmu 
 
 
 
s. 120/224 
 
2025-09-11 
 
DZIAŁ III 
Sprzedaż ruchomości oraz przejęcie przez zastawnika ruchomości obciążonej 
zastawem rejestrowym

***
## Art. 325. {#art-325}

Jeżeli przepisy niniejszego działu nie stanowią inaczej, do sprzedaży 
ruchomości przepisy art. 320 i art. 321 stosuje się odpowiednio.

***
## Art. 326. {#art-326}

(uchylony)

***
## Art. 327. {#art-327}

1. Zastawnik zastawu rejestrowego może zaspokoić się z przedmiotu 
zastawu przez jego przejęcie albo zbycie w trybie określonym w art. 24 ustawy z dnia 
6 grudnia 1996 r. o zastawie rejestrowym i rejestrze zastawów, jeżeli umowa 
o ustanowienie zastawu przewiduje taki sposób zaspokojenia zastawnika. 
2. Jeżeli rzecz obciążona zastawem rejestrowym znajduje się w posiadaniu 
zastawnika lub osób trzecich, zastawnik zawiadamia o zaspokojeniu się syndyka. 
Sędzia-komisarz może wyznaczyć zastawnikowi stosowny termin do zaspokojenia się 
z przedmiotu zastawu. Jeżeli zastawnik nie skorzystał z tego prawa w wyznaczonym 
terminie, osoba, u której znajduje się rzecz obciążona zastawem rejestrowym, 
obowiązana jest wydać przedmiot zastawu syndykowi. Po przekazaniu przedmiotu 
zastawu syndyk dokonuje jego sprzedaży; suma uzyskana ze sprzedaży podlega 
podziałowi, z uwzględnieniem art. 336 i 340. 
3. W sprawach, o których mowa w ust. 2, postanowienie sędziego-komisarza 
o wydaniu syndykowi przedmiotu zastawu podlega wykonaniu bez nadawania mu 
klauzuli wykonalności.

***
## Art. 328. {#art-328}

1. Jeżeli przedmiot zastawu rejestrowego, z którego wierzyciel może 
się zaspokoić, znajduje się we władaniu syndyka, a wierzycielowi przysługuje prawo 
do przejęcia przedmiotu na własność, sędzia-komisarz wyznacza wierzycielowi termin 
do wykonania tego prawa, nie krótszy niż jeden miesiąc; po upływie terminu 
przedmiot zastawu zostanie sprzedany według przepisów ustawy. 
2. Jeżeli rzecz obciążona zastawem rejestrowym znajduje się we władaniu 
syndyka, a umowa o ustanowieniu zastawu przewiduje zaspokojenie zastawnika 
w trybie określonym w art. 24 ustawy, o której mowa w art. 327 ust. 1, syndyk 
dokonuje sprzedaży rzeczy według przepisów niniejszej ustawy. 

©Kancelaria Sejmu 
 
 
 
s. 121/224 
 
2025-09-11

***
## Art. 329. {#art-329}

W przypadkach, o których mowa w art. 327 i 328, zastawnik jest 
obowiązany rozliczyć się z syndykiem stosownie do przepisów ustawy z dnia 
6 grudnia 1996 r. o zastawie rejestrowym i rejestrze zastawów.

***
## Art. 330. {#art-330}

1. Jeżeli przedmiot obciążony zastawem rejestrowym jest składnikiem 
przedsiębiorstwa upadłego i jego sprzedaż wraz z przedsiębiorstwem może być 
korzystniejsza niż oddzielna sprzedaż przedmiotu zastawu, przepisów art. 327 oraz 
art. 328 nie stosuje się. 
2. W przypadku, o którym mowa w ust. 1, przedmiot obciążony zastawem 
sprzedaje się wraz z przedsiębiorstwem. Z ceny sprzedaży przedsiębiorstwa 
wyodrębnia się wartość rzeczy obciążonej zastawem i przeznacza się na zaspokojenie 
zastawnika stosownie do art. 336 i 340. 
Art. 330a. 1. Jeżeli w skład masy upadłości wchodzą ruchomości, których nie 
można zbyć z zachowaniem przepisów ustawy, wierzyciel może przejąć na własność 
ruchomości wystawione na sprzedaż albo niektóre z nich w cenie nie niższej od 
połowy ceny oszacowania. 
2. Pierwszeństwo przejęcia ruchomości na własność przysługuje wierzycielowi, 
którego wierzytelność zabezpieczona jest zastawem, zastawem rejestrowym, 
zastawem skarbowym na tej ruchomości, a w dalszej kolejności – temu wierzycielowi, 
który oferował najwyższą cenę. 
3. Oświadczenie o przejęciu będzie uwzględnione tylko wtedy, gdy wierzyciel 
jednocześnie z wnioskiem złoży całą cenę. Własność ruchomości przechodzi na 
wierzyciela z chwilą zawiadomienia go przez syndyka o przyznaniu mu przejętej 
rzeczy. 
4. Jeżeli fundusze masy upadłości wystarczają na zaspokojenie wszystkich 
wierzycieli z wyższej i równorzędnej kategorii zaspokojenia i zobowiązań, o których 
mowa w art. 230, nabywca może zaliczyć swoją wierzytelność na cenę nabycia. 
5. Przepis art. 317 ust. 3 stosuje się odpowiednio. 
DZIAŁ IV 
Likwidacja wierzytelności i praw majątkowych

***
## Art. 331. {#art-331}

1. Likwidacja wierzytelności upadłego następuje przez ich zbycie albo 
ściągnięcie. 

©Kancelaria Sejmu 
 
 
 
s. 122/224 
 
2025-09-11 
 
2. Wybór sposobu likwidacji należy poprzedzić oceną, który z nich umożliwia 
zaspokojenie wierzycieli w jak największym stopniu przy uwzględnieniu kosztów 
i ryzyka niepowodzenia ściągnięcia wierzytelności upadłego oraz konieczności 
zaspokojenia zobowiązań, o których mowa w art. 230, związanych z przedłużeniem 
postępowania upadłościowego.

***
## Art. 332. {#art-332}

Likwidacja praw majątkowych upadłego następuje przez ich 
wykonanie albo zbycie.

***
## Art. 333. {#art-333}

1. Do likwidacji wierzytelności i praw majątkowych upadłego 
obciążonych zastawem rejestrowym stosuje się odpowiednio przepisy art. 327–330. 
2. Do likwidacji wierzytelności i praw majątkowych upadłego obciążonych 
zastawem finansowym stosuje się odpowiednio przepisy art. 327–330 oraz przepisy 
ustawy z dnia 2 kwietnia 2004 r. o niektórych zabezpieczeniach finansowych.

***
## Art. 334. {#art-334}

1. Do sprzedaży wierzytelności lub praw majątkowych upadłego 
przepisy art. 315, art. 320 i art. 321 stosuje się odpowiednio. 
2. Rada wierzycieli może wyrazić zgodę na inną formę poszukiwania nabywcy, 
z jednoczesnym określeniem warunków sprzedaży. 
3. Nie stanowi oferty publicznej papierów wartościowych w rozumieniu 
art. 2 lit. d rozporządzenia Parlamentu Europejskiego i Rady (UE) 2017/1129 z dnia 
14 czerwca 2017 r. w sprawie prospektu, który ma być publikowany w związku 
z ofertą publiczną papierów wartościowych lub dopuszczeniem ich do obrotu na rynku 
regulowanym oraz uchylenia dyrektywy 2003/71/WE (Dz. Urz. UE L 168 
z 30.06.2017, str. 12) ogłoszenie udostępniane w związku ze sprzedażą papierów 
wartościowych przez syndyka. Do takiej sprzedaży nie stosuje się przepisu 
art. 19 ust. 1 pkt 2 ustawy z dnia 29 lipca 2005 r. o obrocie instrumentami 
finansowymi. 
4. Jeżeli przedmiotem sprzedaży są instrumenty finansowe dopuszczone do 
obrotu na rynku regulowanym w rozumieniu ustawy z dnia 29 lipca 2005 r. o obrocie 
instrumentami finansowymi, sędzia-komisarz może zezwolić na ich sprzedaż przez 
firmę inwestycyjną. W takim przypadku sędzia-komisarz może wyznaczyć rynek 
regulowany lub polecić dokonanie wyboru rynku regulowanego syndykowi oraz 
wyznaczyć minimalną cenę sprzedaży. 
5. Przepis art. 317 ust. 3 stosuje się odpowiednio. 

©Kancelaria Sejmu 
 
 
 
s. 123/224 
 
2025-09-11 
 
TYTUŁ VIII 
Podział funduszów masy upadłości i sum uzyskanych ze zbycia rzeczy i praw 
obciążonych rzeczowo 
DZIAŁ I 
Przepisy ogólne

***
## Art. 335. {#art-335}

Fundusze masy upadłości obejmują sumy uzyskane z likwidacji masy 
upadłości oraz dochód uzyskany z prowadzenia lub wydzierżawienia przedsiębiorstwa 
upadłego, a także odsetki od tych sum zdeponowanych w banku, chyba że przepisy 
ustawy stanowią inaczej.

***
## Art. 336. {#art-336}

1. Sumy uzyskane z likwidacji rzeczy, wierzytelności i praw 
obciążonych hipoteką, zastawem, zastawem rejestrowym, zastawem skarbowym lub 
hipoteką morską, a także prawami oraz prawami osobistymi i roszczeniami 
ujawnionymi przez wpis do księgi wieczystej albo nieujawnionymi w ten sposób, lecz 
zgłoszonymi syndykowi w terminie określonym w art. 51 ust. 1 pkt 5, przeznacza się 
na zaspokojenie wierzycieli, których wierzytelności były zabezpieczone na tych 
rzeczach lub prawach, z zachowaniem przepisów ustawy. Kwoty pozostałe po 
zaspokojeniu tych wierzytelności wchodzą do funduszów masy upadłości. 
2. Przepisy o zaspokojeniu wierzytelności zabezpieczonej zastawem stosuje się 
odpowiednio do zaspokojenia wierzytelności zabezpieczonych przez przeniesienie na 
wierzyciela prawa własności rzeczy, wierzytelności i innego prawa. 
3. Do sum stanowiących pożytki rzeczy lub prawa obciążonego hipoteką, 
zastawem, zastawem rejestrowym, zastawem skarbowym lub hipoteką morską, a także 
prawami oraz prawami osobistymi i roszczeniami przepisu ust. 1 nie stosuje się.

***
## Art. 337. {#art-337}

1. Podziału funduszów dokonuje się jednorazowo albo kilkakrotnie 
w miarę likwidacji masy upadłości po zatwierdzeniu przez sędziego-komisarza listy 
wierzytelności w całości lub części. 
1a. W przypadku zatwierdzenia częściowego listy wierzytelności, w planie 
podziału uwzględnia się kwoty objęte nierozpoznanymi sprzeciwami, zabezpieczając 
w masie upadłości środki na ich ewentualną wypłatę po prawomocnym rozpoznaniu 
sprzeciwów. 
2. W razie kilkakrotnego podziału funduszów masy upadłości, dokonuje się 
podziału ostatecznego po całkowitym zlikwidowaniu masy upadłości. 

©Kancelaria Sejmu 
 
 
 
s. 124/224 
 
2025-09-11

***
## Art. 338. {#art-338}

Jeżeli w postępowaniu upadłościowym zaspokojeniu podlegają 
wierzytelności zabezpieczone hipoteką, zastawem, zastawem rejestrowym, zastawem 
skarbowym i hipoteką morską, podziału ostatecznego funduszów masy upadłości 
dokonuje się po podziale sumy uzyskanej ze zbycia przedmiotu obciążonego.

***
## Art. 339. {#art-339}

Do postępowania w sprawie podziału sumy uzyskanej z likwidacji 
rzeczy, wierzytelności i praw, o których mowa w art. 336, stosuje się odpowiednio 
przepisy 
o postępowaniu 
w sprawie 
podziału 
funduszów 
masy 
upadłości. 
O sporządzeniu planu podziału obwieszcza się i zawiadamia się upadłego oraz te 
osoby, których prawa podlegają zaspokojeniu z sumy uzyskanej z likwidacji. Środki 
zaskarżenia może wnosić upadły oraz osoby uprawnione do zaspokojenia z sumy 
uzyskanej z likwidacji.

***
## Art. 340. {#art-340}

1. Wierzytelności osobiste zabezpieczone hipoteką, zastawem, 
zastawem rejestrowym, zastawem skarbowym i hipoteką morską umieszcza się 
w planie podziału funduszów masy upadłości jedynie w takiej sumie, w jakiej nie 
zostały zaspokojone z przedmiotu zabezpieczenia. 
2. Przepis ust. 1 stosuje się odpowiednio do wierzytelności, które zostały 
zaspokojone przez zakład ubezpieczeń w wykonaniu umowy ubezpieczenia zawartej 
przez upadłego.

***
## Art. 341. {#art-341}

Wierzytelność wierzyciela spadku przyjętego po ogłoszeniu upadłości, 
za którą masa upadłości odpowiada, umieszcza się w planie podziału funduszów masy 
upadłości do wysokości wartości majątku spadkowego. Jeżeli w postępowaniu 
upadłościowym dochodzone są wierzytelności dwu lub więcej wierzycieli spadku, 
które łącznie przekraczają wartość majątku spadkowego, wierzytelności te umieszcza 
się w planie podziału w wysokości obniżonej stosunkowo do wysokości każdej z nich. 
DZIAŁ II 
Kolejność zaspokajania wierzycieli 
## Rozdział 1. Przepisy ogólne

***
## Art. 342. {#art-342}

1. Należności podlegające zaspokojeniu z funduszów masy upadłości 
dzieli się na następujące kategorie: 
- 1) kategoria pierwsza – przypadające za czas przed ogłoszeniem upadłości 
należności ze stosunku pracy, z wyjątkiem roszczeń z tytułu wynagrodzenia 

©Kancelaria Sejmu 
 
 
 
s. 125/224 
 
2025-09-11 
 
reprezentanta upadłego lub wynagrodzenia osoby wykonującej czynności 
związane z zarządem lub nadzorem nad przedsiębiorstwem upadłego, należności 
rolników z tytułu umów o dostarczenie produktów z własnego gospodarstwa 
rolnego, należności alimentacyjne oraz renty z tytułu odszkodowania za 
wywołanie choroby, niezdolności do pracy, kalectwa lub śmierci i renty z tytułu 
zamiany uprawnień objętych treścią prawa dożywocia na dożywotnią rentę, 
przypadające za trzy ostatnie lata przed ogłoszeniem upadłości należności 
z tytułu składek na ubezpieczenia społeczne w rozumieniu ustawy z dnia 
13 października 1998 r. o systemie ubezpieczeń społecznych (Dz. U. z 2024 r. 
poz. 497, 863, 1243 i 1615) oraz należności powstałe w postępowaniu 
restrukturyzacyjnym z czynności zarządcy albo należności powstałe z czynności 
dłużnika 
dokonanych 
po 
otwarciu 
postępowania 
restrukturyzacyjnego 
niewymagających zezwolenia rady wierzycieli albo zgody nadzorcy sądowego 
lub dokonanych za zezwoleniem rady wierzycieli albo zgodą nadzorcy 
sądowego, jeżeli upadłość ogłoszono w wyniku rozpoznania uproszczonego 
wniosku o ogłoszenie upadłości jak również należności z tytułu kredytu, 
pożyczki, obligacji, gwarancji lub akredytyw lub innego finansowania 
przewidzianego układem przyjętym w postępowaniu restrukturyzacyjnym 
i udzielonego w związku z wykonaniem takiego układu, jeżeli upadłość 
ogłoszono w wyniku rozpoznania wniosku o ogłoszenie upadłości złożonego nie 
później niż trzy miesiące po prawomocnym uchyleniu układu; 
- 2) kategoria druga – inne należności, jeżeli nie podlegają zaspokojeniu w innych 
kategoriach, w szczególności podatki i inne daniny publiczne oraz pozostałe 
należności z tytułu składek na ubezpieczenie społeczne; 
- 3) kategoria trzecia – odsetki od należności ujętych w wyższych kategoriach 
w kolejności, 
w jakiej 
podlega 
zaspokojeniu 
kapitał, 
a także 
sądowe 
i administracyjne kary grzywny oraz należności z tytułu darowizn i zapisów; 
- 4) kategoria czwarta – należności wspólników albo akcjonariuszy z tytułu pożyczki 
lub innej czynności prawnej o podobnych skutkach, w szczególności dostawy 
towaru z odroczonym terminem płatności, dokonanej na rzecz upadłego 
będącego spółką kapitałową w okresie pięciu lat przed ogłoszeniem upadłości, 
wraz z odsetkami. 
- 5) (uchylony) 
2. (uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 126/224 
 
2025-09-11 
 
3. Przepisy dotyczące zaspokojenia należności ze stosunku pracy stosuje się 
odpowiednio do roszczeń Funduszu Gwarantowanych Świadczeń Pracowniczych 
o zwrot z masy upadłości świadczeń wypłaconych przez Fundusz pracownikom 
upadłego. 
4. (uchylony) 
5. Przepisu ust. 1 pkt 4 nie stosuje się do: 
- 1) należności z tytułu pożyczek oraz innych czynności prawnych o podobnych 
skutkach dokonanych w toku postępowania restrukturyzacyjnego, jak również 
w ramach wykonania układu; 
- 2) należności z tytułu pożyczek oraz innych czynności prawnych o podobnych 
skutkach dokonanych przez wspólników albo akcjonariuszy dysponujących 
mniej niż 10 % głosów na zgromadzeniu wspólników albo na walnym 
zgromadzeniu spółki, chyba że są oni członkami organów spółki lub faktycznie 
prowadzą jej sprawy; 
- 3) należności wspólnika albo akcjonariusza, który stał się nim w wyniku konwersji 
wierzytelności na udziały lub akcje dokonanej w ramach zawartego układu, 
z tytułu pożyczek oraz innych czynności prawnych o podobnych skutkach 
dokonanych przed taką konwersją. 
6. Do pożyczek lub innych czynności prawnych o podobnych skutkach 
dokonanych przez podmiot, który dysponuje bezpośrednio większością głosów na 
zgromadzeniu wspólników albo na walnym zgromadzeniu w spółce kapitałowej lub 
dysponuje 
bezpośrednio 
większością 
głosów 
w spółce 
osobowej, 
będącej 
wspólnikiem albo akcjonariuszem upadłej spółki, która otrzymała pożyczkę lub była 
beneficjentem czynności prawnej o podobnych skutkach, przepisy ust. 1 pkt 4 i ust. 5 
stosuje się odpowiednio. 
7. W przypadku domów maklerskich, o których mowa w art. 95 ust. 1 pkt 1 i 3 
ustawy z dnia 29 lipca 2005 r. o obrocie instrumentami finansowymi, należności, 
o których mowa w ust. 1, dzieli się na kategorie, o których mowa w ust. 1 pkt 1–4, 
a ponadto na: 
- 1) kategorię piątą – należności z tytułu zobowiązań zaciągniętych w celu ich 
zakwalifikowania jako instrumenty dodatkowe w Tier I do funduszy własnych 
domu maklerskiego, o których mowa w art. 51 rozporządzenia nr 575/2013, 
wobec których Komisja Nadzoru Finansowego nie udzieliła zgody, o której 

©Kancelaria Sejmu 
 
 
 
s. 127/224 
 
2025-09-11 
 
mowa w art. 110ea ust. 1 ustawy z dnia 29 lipca 2005 r. o obrocie instrumentami 
finansowymi, wraz z odsetkami i kosztami egzekucji; 
- 2) kategorię szóstą – należności z tytułu zobowiązań zakwalifikowanych jako 
instrumenty w Tier II do funduszy własnych domu maklerskiego, o których 
mowa w art. 62 rozporządzenia nr 575/2013, wraz z odsetkami i kosztami 
egzekucji; 
- 3) kategorię siódmą – należności z tytułu zobowiązań zakwalifikowanych jako 
instrumenty dodatkowe w Tier I do funduszy własnych domu maklerskiego, 
o których mowa w art. 51 rozporządzenia nr 575/2013, wraz z odsetkami 
i kosztami egzekucji. 
Art. 342a. 1. Jeżeli upadły jest osobą fizyczną i w skład masy upadłości wchodzi 
lokal mieszkalny albo dom jednorodzinny, w którym zamieszkuje upadły, a konieczne 
jest zaspokojenie potrzeb mieszkaniowych upadłego i osób pozostających na jego 
utrzymaniu, z sumy uzyskanej z jego sprzedaży wydziela się upadłemu kwotę 
odpowiadającą przeciętnemu czynszowi najmu lokalu mieszkalnego w tej samej lub 
sąsiedniej miejscowości za okres od dwunastu do dwudziestu czterech miesięcy. 
2. Kwotę, o której mowa w ust. 1, na wniosek upadłego, określa sędzia-
-komisarz, biorąc pod uwagę potrzeby mieszkaniowe upadłego, w tym liczbę osób 
pozostających na jego utrzymaniu, zdolności zarobkowe upadłego, sumę uzyskaną ze 
sprzedaży lokalu mieszkalnego albo domu jednorodzinnego oraz opinię syndyka. Na 
postanowienie sędziego-komisarza przysługuje zażalenie. 
3. Jeżeli fundusze masy upadłości na to pozwalają, a opuszczony przez upadłego 
lokal mieszkalny albo dom jednorodzinny nie został jeszcze zbyty, sędzia-komisarz 
może przyznać upadłemu zaliczkę na poczet kwoty, o której mowa w ust. 1.

***
## Art. 343. {#art-343}

1. Z masy upadłości zaspokaja się w pierwszej kolejności koszty 
postępowania, a jeżeli fundusze masy upadłości na to pozwalają – również inne 
zobowiązania masy upadłości, o których mowa w art. 230 ust. 2, w miarę wpływu do 
masy upadłości stosownych sum. 
1a. Jeżeli inne zobowiązania masy upadłości, o których mowa w art. 230 ust. 2, 
nie zostaną zaspokojone w sposób, o którym mowa w ust. 1, zaspokaja się je 
stosunkowo do wysokości każdej z nich w drodze podziału funduszów masy 
upadłości. Przepisy art. 347–360 stosuje się odpowiednio. 

©Kancelaria Sejmu 
 
 
 
s. 128/224 
 
2025-09-11 
 
2. Zobowiązania alimentacyjne ciążące na upadłym, przypadające za czas po 
ogłoszeniu upadłości, syndyk zaspokaja zgodnie z ust. 1 w terminach ich płatności, do 
dnia sporządzenia ostatecznego planu podziału, każdorazowo dla każdego 
uprawnionego w kwocie nie wyższej niż minimalne wynagrodzenie za pracę. 
Pozostała część tych należności nie podlega zaspokojeniu z masy upadłości.

***
## Art. 344. {#art-344}

1. Należności, o których mowa w art. 342 ust. 1 i 7, zaspokaja się 
dopiero po zaspokojeniu w całości kosztów postępowania, zobowiązań masy 
upadłości i należności alimentacyjnych zgodnie z art. 343. 
2. Jeżeli suma przeznaczona do podziału nie wystarcza na zaspokojenie w całości 
wszystkich należności, należności dalszej kategorii zaspokaja się dopiero po 
zaspokojeniu w całości należności poprzedzającej kategorii, a jeżeli suma 
przeznaczona do podziału nie wystarcza na zaspokojenie w całości wszystkich 
należności tej samej kategorii, należności te zaspokaja się stosunkowo do wysokości 
każdej z nich. 
## Rozdział 2. Kolejność spłacania wierzytelności zabezpieczonych hipoteką, zastawem, 
zastawem rejestrowym, zastawem skarbowym i hipoteką morską

***
## Art. 345. {#art-345}

1. Jeżeli przepis szczególny nie stanowi inaczej, wierzytelności 
zabezpieczone hipoteką, zastawem, zastawem rejestrowym, zastawem skarbowym 
i hipoteką morską, a także wygasające według przepisów ustawy prawa oraz skutki 
ujawnienia praw i roszczeń osobistych ciążące na nieruchomości, użytkowaniu 
wieczystym, spółdzielczym własnościowym prawie do lokalu lub statku morskim 
wpisanym do rejestru okrętowego, podlegają zaspokojeniu z sumy uzyskanej 
z likwidacji obciążonego przedmiotu, pomniejszonej o koszty likwidacji tego 
przedmiotu 
oraz 
inne 
koszty 
postępowania 
upadłościowego 
w wysokości 
nieprzekraczającej dziesiątej części sumy uzyskanej z likwidacji, nie więcej jednak niż 
o taką część kosztów postępowania upadłościowego, która wynika ze stosunku 
wartości obciążonego przedmiotu do wartości całej masy upadłości. 
2. Wierzytelności i prawa, o których mowa w ust. 1, są zaspokajane w kolejności 
przysługującego im pierwszeństwa. Jeżeli z sumy uzyskanej z likwidacji obciążonego 
przedmiotu zaspokojeniu podlegają zarówno wierzytelności zabezpieczone hipoteką, 
jak i wygasające na podstawie art. 313 ust. 2 prawa oraz prawa i roszczenia osobiste, 

©Kancelaria Sejmu 
 
 
 
s. 129/224 
 
2025-09-11 
 
o pierwszeństwie rozstrzyga chwila, od której liczy się skutki wpisu hipoteki, prawa 
lub roszczenia do księgi wieczystej. 
3. W równym stopniu z wierzytelnością zaspokaja się roszczenia o świadczenia 
uboczne objęte zabezpieczeniem na mocy odrębnych przepisów. Przypadającą 
wierzycielowi sumę zalicza się przede wszystkim na należność główną, następnie na 
odsetki i pozostałe roszczenia o świadczenia uboczne, z tym że koszty postępowania 
uwzględnia się w ostatniej kolejności.

***
## Art. 346. {#art-346}

1. W razie sprzedaży nieruchomości, prawa użytkowania wieczystego, 
spółdzielczego własnościowego prawa do lokalu lub statku morskiego wpisanego do 
rejestru okrętowego, przed zaspokojeniem wierzytelności zabezpieczonych hipoteką 
albo hipoteką morską oraz innych praw, w tym praw i roszczeń osobistych, które 
ciążyły na przedmiocie sprzedaży i które w wyniku sprzedaży wygasły, zaspokaja się 
należności alimentacyjne w zakresie wskazanym w art. 343 ust. 2 oraz przypadające 
za czas po ogłoszeniu upadłości renty za wywołanie choroby, niezdolności do pracy, 
kalectwa lub śmierci i renty z tytułu zamiany uprawnień objętych treścią prawa 
dożywocia na dożywotnią rentę, jak też wynagrodzenia za pracę pracowników 
wykonujących pracę na nieruchomości, statku lub w lokalu za okres ostatnich trzech 
miesięcy przed sprzedażą, jednakże tylko do wysokości trzykrotnego minimalnego 
wynagrodzenia za pracę. 
2. Odrębnego planu podziału nie sporządza się, jeżeli suma uzyskana ze 
sprzedaży nie wystarcza na zaspokojenie wierzytelności z tytułu alimentów, rent 
i wynagrodzeń za pracę, o których mowa w ust. 1. 
DZIAŁ III 
Postępowanie w sprawie podziału funduszów masy upadłości 
## Rozdział 1. Ustalenie planu podziału

***
## Art. 347. {#art-347}

1. Syndyk sporządza i składa sędziemu-komisarzowi plan podziału 
funduszów masy upadłości, w którym: 
- 1) określa sumę podlegającą podziałowi; 
- 2) wymienia wierzytelności i prawa osób uczestniczących w podziale; 
- 3) określa sumę, jaka każdemu z uczestników przypada z podziału; 

©Kancelaria Sejmu 
 
 
 
s. 130/224 
 
2025-09-11 
- 4) wskazuje, które sumy mają być wypłacone, a które i z jakich przyczyn mają być 
pozostawione w depozycie sądowym lub pozostawione w masie upadłości na 
zaspokojenie wierzytelności objętych nierozpoznanymi sprzeciwami; 
- 5) określa, czy plan podziału jest częściowy czy ostateczny. 
1a. (uchylony) 
2. Sędzia-komisarz może wnieść do planu poprawki lub polecić syndykowi 
dokonanie wskazanych zmian w planie.

***
## Art. 348. {#art-348}

1. W sprawach, w których wierzycielom przysługują prawa na zbytych 
rzeczach lub prawach, o których mowa w art. 345 i 346, syndyk sporządza oddzielny 
plan podziału sum uzyskanych ze sprzedanych rzeczy lub praw. Do tego planu stosuje 
się odpowiednio przepis art. 347. 
2. W planie podziału sumy uzyskanej ze sprzedaży nieruchomości syndyk 
wymienia dodatkowo prawa oraz prawa i roszczenia osobiste, które wskutek 
sprzedaży nieruchomości wygasły.

***
## Art. 349. {#art-349}

1. Sędzia-komisarz zawiadamia upadłego i członków rady wierzycieli 
oraz obwieszcza, że plan podziału można przeglądać w sekretariacie sądu i w terminie 
dwóch tygodni od dnia obwieszczenia wnosić zarzuty przeciwko planowi podziału. 
2. W przypadku złożenia ostatecznego planu podziału sędzia-komisarz dokonuje 
czynności, o których mowa w ust. 1, po uprawomocnieniu się postanowienia 
o przyznaniu syndykowi wynagrodzenia ostatecznego. 
3. (uchylony)

***
## Art. 350. {#art-350}

1. Zarzuty przeciwko planowi podziału rozpoznaje sędzia-komisarz. 
2. W razie potrzeby sędzia-komisarz wysłucha osoby, których praw dotyczą 
zarzuty. 
3. Na postanowienie sędziego-komisarza przysługuje zażalenie.

***
## Art. 351. {#art-351}

1. Sędzia-komisarz zatwierdza plan podziału, jeżeli nie wniesiono 
zarzutów. 
2. W razie wniesienia zarzutów, sprostowanie i zatwierdzenie planu podziału 
następuje po uprawomocnieniu się postanowienia sędziego-komisarza w sprawie 
zarzutów, a w razie jego zaskarżenia – po wydaniu postanowienia sądu. 
3. Postanowienie 
o zatwierdzeniu 
planu 
podziału 
oraz 
prawomocne 
postanowienia o sprostowaniu planu podziału oraz jego zmianie obwieszcza się. 

©Kancelaria Sejmu 
 
 
 
s. 131/224 
 
2025-09-11 
## Rozdział 2. Wykonanie planu podziału

***
## Art. 352. {#art-352}

1. Plan podziału wykonuje się niezwłocznie po jego zatwierdzeniu. 
Wykonanie planu podziału nie może jednak nastąpić przed uprawomocnieniem się 
postanowienia o ogłoszeniu upadłości. 
2. W razie wniesienia zarzutów przeciwko planowi podziału lub zażalenia na 
postanowienie w sprawie zarzutów, plan wykonuje się w tych częściach, których nie 
dotyczą żądania zgłoszone w zarzutach lub zażaleniu. W takim przypadku zakres 
wykonania planu określa sędzia-komisarz.

***
## Art. 353. {#art-353}

1. Wykonując plan podziału, syndyk wydaje wierzycielowi należną mu 
kwotę lub przelewa ją na rachunek bankowy wierzyciela. 
2. Po wykonaniu planu podziału syndyk składa sprawozdanie z wykonania planu 
podziału. 
3. (uchylony)

***
## Art. 354. {#art-354}

1. W razie zaspokojenia wierzytelności wierzyciela osobistego 
upadłego, zabezpieczonej na mieniu upadłego hipoteką lub hipoteką morską, przed 
zbyciem 
przedmiotu 
obciążonego, 
w prawa 
wierzyciela 
wchodzi 
upadły. 
Odpowiedniego wpisu o tym dokonuje się w księdze wieczystej lub w rejestrze 
okrętowym. 
2. Podstawę wpisu stanowi wyciąg z planu podziału funduszów masy upadłości 
uwierzytelniony przez sekretarza sądowego.

***
## Art. 355. {#art-355}

Sumę wydzieloną na zaspokojenie wierzytelności, za którą osoba 
trzecia odpowiada jako poręczyciel, gwarant lub współdłużnik, wydaje się 
wierzycielowi w proporcji do wysokości kwoty należnej mu w dniu sporządzenia 
planu podziału, a poręczycielowi, gwarantowi lub współdłużnikowi – w proporcji do 
wysokości dokonanej zapłaty.

***
## Art. 356. {#art-356}

1. Sumę wydzieloną na zaspokojenie wierzytelności, której wysokość 
zależy od warunku rozwiązującego, wydaje się wierzycielowi bez zabezpieczenia, 
chyba że obowiązek zabezpieczenia ciąży na wierzycielu z mocy istniejącego między 
nim a upadłym stosunku prawnego. 
2. Sumę wydzieloną na zaspokojenie wierzytelności, której zapłata zależy od 
warunku zawieszającego, w tym wierzytelności, o których mowa w art. 248 ust. 2, 

©Kancelaria Sejmu 
 
 
 
s. 132/224 
 
2025-09-11 
 
wydaje się wierzycielowi, jeżeli udowodni, że warunek się ziścił; w przeciwnym razie 
sumę tę składa się do depozytu sądowego. 
3. Sumę wydzieloną na zaspokojenie wierzytelności niewymagalnej składa się 
do depozytu sądowego.

***
## Art. 357. {#art-357}

(uchylony)

***
## Art. 358. {#art-358}

Jeżeli wierzyciel nie odbierze swojej należności w terminie miesiąca 
lub gdy należna mu suma nie może być mu wydana z powodu podania 
nieprawidłowego adresu albo niepodania rachunku bankowego, sumy należne temu 
wierzycielowi składa się do depozytu sądowego.

***
## Art. 359. {#art-359}

1. 
W sprawach 
o złożenie 
do 
depozytu 
sądowego 
orzeka 
sędzia-komisarz. Przepisów art. 6933 § 1 i 3 Kodeksu postępowania cywilnego nie 
stosuje się. 
2. W sprawach o wydanie kwot złożonych do depozytu sądowego orzeka 
sędzia-komisarz, a po prawomocnym zakończeniu lub umorzeniu postępowania 
upadłościowego – sąd.

***
## Art. 360. {#art-360}

1. W postępowaniu o wydanie kwoty z depozytu sądowego badaniu 
podlega jedynie legitymacja czynna wnioskodawcy. Kwoty z depozytu wydaje się 
osobie, na którą przeszło uprawnienie wierzyciela do wypłaty kwoty z depozytu, jeżeli 
przejście to będzie wykazane dokumentem urzędowym lub prywatnym z podpisem 
urzędowo poświadczonym. 
2. Termin do odbioru depozytu sądowego wynosi trzy lata od dnia 
uprawomocnienia się postanowienia o zakończeniu albo umorzeniu postępowania 
upadłościowego, ale nie mniej niż trzy lata od daty ziszczenia się warunku, o którym 
mowa w art. 356 ust. 1 lub 2, albo od daty wymagalności. Po upływie terminu prawa 
do niepodjętego depozytu przechodzą na Skarb Państwa. Do likwidacji niepodjętego 
depozytu zastosowanie mają przepisy art. 69318–69322 Kodeksu postępowania 
cywilnego. 
TYTUŁ IX 
Zakończenie i umorzenie postępowania upadłościowego oraz ich skutki

***
## Art. 361. {#art-361}

1. Sąd umorzy postępowanie upadłościowe, jeżeli: 

©Kancelaria Sejmu 
 
 
 
s. 133/224 
 
2025-09-11 
- 1) majątek pozostały po wyłączeniu z niego przedmiotów majątkowych dłużnika 
obciążonych hipoteką, zastawem, zastawem rejestrowym, zastawem skarbowym 
lub hipoteką morską nie wystarcza na zaspokojenie kosztów postępowania; 
- 2) wierzyciele 
zobowiązani 
uchwałą 
zgromadzenia 
wierzycieli 
albo 
postanowieniem sędziego-komisarza nie złożyli w wyznaczonym terminie 
zaliczki na koszty postępowania, a brak jest płynnych funduszów na te koszty; 
- 3) wszyscy wierzyciele, którzy zgłosili swoje wierzytelności, żądają umorzenia 
postępowania, a upadły wyraził na to zgodę. 
2. W przypadku umorzenia postępowania upadłościowego z powodu, o którym 
mowa w ust. 1 pkt 1, sąd ustala, czy materiał zgromadzony w sprawie daje podstawę 
do rozwiązania podmiotu wpisanego do Krajowego Rejestru Sądowego bez 
przeprowadzania postępowania likwidacyjnego. 
3. Jeżeli w toku postępowania doszło do sprzedaży rzeczy lub praw, 
wymagającej 
sporządzenia 
oddzielnego 
planu 
podziału, 
o którym 
mowa 
w art. 348 ust. 1, umorzenie postępowania nie może nastąpić wcześniej niż po 
wykonaniu planu podziału sum uzyskanych ze sprzedaży tych rzeczy lub praw.

***
## Art. 362. {#art-362}

1. Postanowienie o umorzeniu postępowania upadłościowego doręcza 
się upadłemu, syndykowi oraz członkom rady wierzycieli. Na postanowienie 
przysługuje zażalenie. 
2. Postanowienie o umorzeniu postępowania, postanowienie sądu drugiej 
instancji w przedmiocie rozpoznania zażalenia na postanowienie o umorzeniu 
postępowania oraz informację o prawomocności postanowienia o umorzeniu 
postępowania obwieszcza się.

***
## Art. 363. {#art-363}

Prawomocne 
postanowienie 
o umorzeniu 
postępowania 
upadłościowego stanowi podstawę do wykreślenia wpisów dotyczących upadłości 
w księdze wieczystej i w rejestrach.

***
## Art. 364. {#art-364}

1. Z dniem uprawomocnienia się postanowienia o umorzeniu 
postępowania upadłościowego upadły odzyskuje prawo zarządzania swoim majątkiem 
i rozporządzania jego składnikami. 
2. Syndyk wyda niezwłocznie upadłemu jego majątek, księgi, korespondencję 
i dokumenty. W razie potrzeby sąd wyda postanowienie nakazujące przymusowe 
odebranie majątku. Prawomocne postanowienie ma moc tytułu wykonawczego. 

©Kancelaria Sejmu 
 
 
 
s. 134/224 
 
2025-09-11

***
## Art. 365. {#art-365}

1. Jeżeli upadły nie odbiera ksiąg, korespondencji lub dokumentów 
w terminie wyznaczonym przez syndyka, syndyk oddaje je na przechowanie na koszt 
upadłego. Syndyk może wstrzymać wydanie upadłemu majątku potrzebnego na 
pokrycie kosztów przechowania ksiąg, korespondencji lub dokumentów do czasu ich 
odebrania przez upadłego. 
2. Syndyk pokrywa koszty przechowania ksiąg, korespondencji lub dokumentów 
z funduszów masy upadłości, jeżeli posiada płynne środki pozwalające na pokrycie 
tych kosztów. W przypadku braku płynnych środków syndyk dokonuje za zgodą sądu 
likwidacji majątku w celu pokrycia kosztów ich przechowania. 
3. W przypadku braku majątku potrzebnego na pokrycie kosztów przechowania 
ksiąg, korespondencji lub dokumentów sąd zasądza od upadłego na rzecz 
przechowawcy koszty przechowania. W przypadku upadłego będącego osobą prawną 
albo spółką osobową sąd może zasądzić koszty przechowania od osób upoważnionych 
do reprezentowania upadłego, określając osobę albo osoby ponoszące koszty 
przechowania. Na postanowienie sądu zażalenie przysługuje wyłącznie upadłemu, 
osobie zobowiązanej do ponoszenia kosztów oraz przechowawcy. 
4. Jeżeli oddanie na przechowanie ksiąg, korespondencji lub dokumentów jest 
niemożliwe, podlegają one złożeniu do właściwego archiwum wraz z aktami 
postępowania upadłościowego na koszt upadłego, z wyjątkiem dokumentacji 
osobowej i płacowej, do której stosuje się przepis art. 51u ust. 3 ustawy z dnia 14 lipca 
1983 r. o narodowym zasobie archiwalnym i archiwach (Dz. U. z 2020 r. poz. 164). 
Koszty te ściąga się w trybie przepisów Kodeksu postępowania cywilnego o egzekucji 
opłat sądowych. Przepis ust. 3 stosuje się odpowiednio.

***
## Art. 366. {#art-366}

1. Sąd zarządza likwidację majątku i określa sposób likwidacji, jeżeli 
upadły nie odbierze swojego majątku w terminie wyznaczonym przez syndyka. 
2. Sąd może nakazać likwidację majątku na koszt upadłego przez przekazanie 
majątku na cele dobroczynne lub w inny sposób, jeżeli likwidacja majątku w sposób 
określony przez sąd okaże się niemożliwa lub nadmiernie utrudniona. Przepis 
art. 365 ust. 3 stosuje się odpowiednio. 
3. Na postanowienie w przedmiocie likwidacji przysługuje zażalenie.

***
## Art. 367. {#art-367}

1. Po umorzeniu postępowania upadłościowego umarza się wszczęte 
przez syndyka niezakończone procesy o uznanie za bezskuteczną czynności 

©Kancelaria Sejmu 
 
 
 
s. 135/224 
 
2025-09-11 
 
dokonanej przez upadłego ze szkodą dla wierzycieli. Wzajemne roszczenia o zwrot 
kosztów procesu wygasają. 
2. W innych postępowaniach cywilnych upadły wchodzi do postępowania 
w miejsce syndyka.

***
## Art. 368. {#art-368}

1. Sąd po wykonaniu ostatecznego planu podziału stwierdza 
zakończenie postępowania upadłościowego. 
2. Sąd stwierdza zakończenie postępowania także wtedy, gdy w toku 
postępowania wszyscy wierzyciele zostali zaspokojeni. 
3. Przepisy art. 362–367 stosuje się odpowiednio.

***
## Art. 369. {#art-369}

1. W terminie trzydziestu dni od dnia obwieszczenia postanowienia 
o zakończeniu postępowania upadłościowego upadły będący osobą fizyczną może 
złożyć wniosek o ustalenie planu spłaty wierzycieli i umorzenie pozostałej części 
zobowiązań, które nie zostały zaspokojone w postępowaniu upadłościowym. 
1a. W terminie, o którym mowa w ust. 1, upadły będący osobą fizyczną może 
również złożyć wniosek o umorzenie zobowiązań bez ustalenia planu spłaty 
wierzycieli, jeśli osobista sytuacja upadłego w oczywisty sposób wskazuje, że jest on 
trwale niezdolny do dokonywania jakichkolwiek spłat w ramach planu spłaty 
wierzycieli. Przepis art. 370f ust. 2 stosuje się. 
1b. Wnioski, o których mowa w ust. 1 i 1a, rozpoznaje się na rozprawie. 
O terminie rozprawy zawiadamia się wierzycieli przez obwieszczenie. 
2. Jeżeli niezdolność do dokonywania jakichkolwiek spłat w ramach planu spłaty 
wierzycieli wynikająca z osobistej sytuacji upadłego nie ma charakteru trwałego, sąd 
umarza zobowiązania upadłego bez ustalenia planu spłaty wierzycieli pod warunkiem, 
że w terminie pięciu lat od dnia uprawomocnienia się postanowienia o warunkowym 
umorzeniu zobowiązań upadłego bez ustalenia planu spłaty wierzycieli upadły ani 
żaden z wierzycieli nie złoży wniosku o ustalenie planu spłaty wierzycieli, na skutek 
którego sąd, uznając, że ustała niezdolność upadłego do dokonywania jakichkolwiek 
spłat w ramach planu spłaty wierzycieli, uchyli postanowienie o warunkowym 
umorzeniu zobowiązań upadłego bez ustalenia planu spłaty wierzycieli i ustali plan 
spłaty wierzycieli. Przepisy art. 370a ust. 10 i art. 370f ust. 2 stosuje się. 
2a. Na podstawie złożonego w terminie, o którym mowa w ust. 2, wniosku 
upadłego lub wierzyciela, o którym mowa w ust. 2, sąd może uchylić postanowienie 
o warunkowym umorzeniu zobowiązań upadłego bez ustalenia planu spłaty 

©Kancelaria Sejmu 
 
 
 
s. 136/224 
 
2025-09-11 
 
wierzycieli i ustalić plan spłaty wierzycieli również po upływie pięciu lat od dnia 
uprawomocnienia się postanowienia o warunkowym umorzeniu zobowiązań upadłego 
bez ustalenia planu spłaty wierzycieli. 
2b. W okresie pięciu lat od dnia uprawomocnienia się postanowienia 
o warunkowym umorzeniu zobowiązań upadłego bez ustalenia planu spłaty 
wierzycieli upadły nie może dokonywać czynności prawnych, dotyczących jego 
majątku, które mogłyby pogorszyć jego sytuację majątkową. 
2c. W szczególnie uzasadnionych przypadkach sąd, na wniosek upadłego, może 
wyrazić zgodę na dokonanie czynności prawnej, o której mowa w ust. 2b, albo 
zatwierdzić jej dokonanie. 
2d. W okresie, o którym mowa w ust. 2b, upadły jest obowiązany składać sądowi 
corocznie, do końca kwietnia, sprawozdanie ze swojej sytuacji majątkowej 
i zawodowej za poprzedni rok kalendarzowy, w którym wykazuje osiągnięte 
przychody oraz nabyte składniki majątkowe o wartości przekraczającej przeciętne 
miesięczne wynagrodzenie w sektorze przedsiębiorstw bez wypłat nagród z zysku za 
ostatni kwartał okresu sprawozdawczego, ogłoszone przez Prezesa Głównego Urzędu 
Statystycznego, jak również swoje możliwości zarobkowe, wydatki potrzebne na 
swoje utrzymanie i osób pozostających na jego utrzymaniu, w tym potrzeby 
mieszkaniowe. Do sprawozdania upadły dołącza kopię złożonego rocznego zeznania 
podatkowego. 
2e. W okresie, o którym mowa w ust. 2b, przepis art. 370c ust. 1 stosuje się 
odpowiednio. 
2f. Sąd uchyla postanowienie o warunkowym umorzeniu zobowiązań upadłego 
bez ustalenia planu spłaty wierzycieli, gdy w okresie, o którym mowa w ust. 2b, 
upadły: 
- 1) nie złożył w terminie sprawozdania, o którym mowa w ust. 2d, 
- 2) w sprawozdaniu, o którym mowa w ust. 2d, podał nieprawdziwe informacje, 
w szczególności zataił osiągnięte przychody lub nabyte składniki majątkowe, 
- 3) dokonał czynności prawnej, o której mowa w ust. 2b, bez uzyskania zgody sądu 
albo czynność ta nie została przez sąd zatwierdzona, 
- 4) ukrywał majątek lub czynność prawna upadłego została prawomocnie uznana za 
dokonaną z pokrzywdzeniem wierzycieli 
– chyba że uchybienie obowiązkom jest nieznaczne lub zaniechanie uchylenia 
postanowienia o warunkowym umorzeniu zobowiązań upadłego bez ustalenia planu 

©Kancelaria Sejmu 
 
 
 
s. 137/224 
 
2025-09-11 
 
spłaty wierzycieli jest uzasadnione względami słuszności lub względami 
humanitarnymi; przepis art. 370a ust. 10 stosuje się. 
2g. W razie uchylenia postanowienia o warunkowym umorzeniu zobowiązań 
upadłego bez ustalenia planu spłaty wierzycieli zobowiązania upadłego nie podlegają 
umorzeniu. 
2h. Jeżeli upadły ani żaden z wierzycieli nie złoży wniosku, o którym mowa 
w ust. 2, zobowiązania upadłego, o których mowa w ust. 1, ulegają umorzeniu 
z upływem pięciu lat od dnia uprawomocnienia się postanowienia o warunkowym 
umorzeniu zobowiązań upadłego bez ustalenia planu spłaty wierzycieli. Na wniosek 
upadłego lub wierzyciela sąd wydaje postanowienie stwierdzające umorzenie 
zobowiązań upadłego bez ustalenia planu spłaty wierzycieli. W postanowieniu sąd 
wskazuje datę umorzenia zobowiązań upadłego. 
3. Sąd oddala wniosek, o którym mowa w ust. 1 lub 1a, jeżeli: 
- 1) upadły doprowadził do swojej niewypłacalności lub istotnie zwiększył jej stopień 
w sposób celowy, w szczególności przez trwonienie części składowych majątku 
oraz celowe nieregulowanie wymagalnych zobowiązań, 
- 2) w okresie dziesięciu lat przed dniem zgłoszenia wniosku o ogłoszenie upadłości 
w stosunku do upadłego prowadzono postępowanie upadłościowe, w którym 
umorzono całość lub część jego zobowiązań 
– chyba że uwzględnienie wniosku, o którym mowa w ust. 1 lub 1a, jest uzasadnione 
względami słuszności lub względami humanitarnymi.

***
## Art. 370. {#art-370}

(uchylony) 
Art. 370a. 1. W postanowieniu o ustaleniu planu spłaty wierzycieli sąd ustala, 
czy upadły doprowadził do swojej niewypłacalności lub istotnie zwiększył jej stopień 
umyślnie lub wskutek rażącego niedbalstwa, oraz określa, w jakim zakresie i okresie, 
nie dłuższym niż trzydzieści sześć miesięcy, upadły jest obowiązany spłacać 
zobowiązania uznane na liście wierzytelności a niewykonane w toku postępowania 
upadłościowego na podstawie planów podziału oraz jaka część zobowiązań upadłego 
powstałych przed dniem ogłoszenia upadłości zostanie umorzona po wykonaniu planu 
spłaty wierzycieli. 
2. W przypadku ustalenia, że upadły doprowadził do swojej niewypłacalności 
lub istotnie zwiększył jej stopień umyślnie lub wskutek rażącego niedbalstwa, plan 

©Kancelaria Sejmu 
 
 
 
s. 138/224 
 
2025-09-11 
 
spłaty wierzycieli nie może być ustalony na okres krótszy niż trzydzieści sześć 
miesięcy ani dłuższy niż osiemdziesiąt cztery miesiące. 
3. W przypadku gdy w drodze wykonania planów podziału oraz planu spłaty 
wierzycieli dłużnik spłaci co najmniej 70 % zobowiązań uznanych na liście 
wierzytelności, plan spłaty wierzycieli nie może zostać ustalony na okres dłuższy niż 
rok. 
4. W przypadku gdy w drodze wykonania planów podziału oraz planu spłaty 
wierzycieli dłużnik spłaci co najmniej 50 % zobowiązań uznanych na liście 
wierzytelności, plan spłaty wierzycieli nie może zostać ustalony na okres dłuższy niż 
dwa lata. 
5. Do okresów spłaty, o których mowa w ust. 2–4, zalicza się okres od upływu 
sześciu miesięcy od dnia ogłoszenia upadłości do dnia zakończenia postępowania 
upadłościowego. Do okresu spłaty nie zalicza się okresu warunkowego umorzenia 
zobowiązań upadłego bez ustalenia planu spłaty wierzycieli. 
6. Osoba, która pełniła w postępowaniu upadłościowym funkcję syndyka, na 
żądanie sądu składa, w terminie czternastu dni, opis przyczyn powstania stanu 
niewypłacalności upadłego. 
7. Koszty postępowania upadłościowego oraz inne zobowiązania masy upadłości 
niezaspokojone w toku postępowania upadłościowego uwzględnia się w planie spłaty 
wierzycieli w pełnej wysokości, chyba że możliwości zarobkowe upadłego, 
konieczność utrzymania upadłego i osób pozostających na jego utrzymaniu oraz ich 
potrzeby mieszkaniowe nie pozwalają na zaspokojenie kosztów postępowania 
upadłościowego oraz innych zobowiązań masy upadłości w pełnej wysokości. 
8. Sąd nie jest związany stanowiskiem upadłego oraz wierzycieli co do treści 
planu spłaty wierzycieli. Ustalając plan spłaty wierzycieli, sąd bierze pod uwagę 
możliwości zarobkowe upadłego, konieczność utrzymania upadłego i osób 
pozostających na jego utrzymaniu oraz ich potrzeby mieszkaniowe, wysokość 
niezaspokojonych 
wierzytelności 
oraz 
stopień 
zaspokojenia 
wierzytelności 
w postępowaniu upadłościowym. 
9. Do planu spłaty wierzycieli stosuje się odpowiednio przepisy art. 336 
i art. 340–346. 
10. Postanowienie w przedmiocie ustalenia planu spłaty wierzycieli albo 
w przedmiocie umorzenia zobowiązań upadłego bez ustalenia planu spłaty wierzycieli 
lub w przedmiocie warunkowego umorzenia zobowiązań upadłego bez ustalenia planu 

©Kancelaria Sejmu 
 
 
 
s. 139/224 
 
2025-09-11 
 
spłaty wierzycieli oraz informację o prawomocności tych postanowień obwieszcza się. 
Na postanowienie sądu w przedmiocie ustalenia planu spłaty wierzycieli albo 
w przedmiocie umorzenia zobowiązań upadłego bez ustalenia planu spłaty wierzycieli 
lub w przedmiocie warunkowego umorzenia zobowiązań upadłego bez ustalenia planu 
spłaty wierzycieli przysługuje zażalenie. Postanowienie sądu drugiej instancji 
w przedmiocie rozpoznania zażalenia oraz informację o prawomocności tego 
postanowienia obwieszcza się. 
11. Ustalenie planu spłaty wierzycieli nie narusza praw wierzyciela wobec 
poręczyciela upadłego oraz współdłużnika upadłego ani praw wynikających 
z hipoteki, zastawu, zastawu rejestrowego, zastawu skarbowego oraz hipoteki 
morskiej, jeżeli były one ustanowione na mieniu osoby trzeciej. Ustalenie planu spłaty 
wierzycieli i umorzenie zobowiązań upadłego jest skuteczne również w stosunkach 
między upadłym, a poręczycielem, gwarantem i współdłużnikiem upadłego. 
Art. 370b. 1. Od postanowienia sądu drugiej instancji w przedmiocie ustalenia 
planu spłaty wierzycieli albo w przedmiocie umorzenia zobowiązań upadłego bez 
ustalenia planu spłaty wierzycieli lub w przedmiocie warunkowego umorzenia 
zobowiązań upadłego bez ustalenia planu spłaty wierzycieli przysługuje skarga 
kasacyjna. 
2. W przypadku wniesienia skargi kasacyjnej, sąd upadłościowy na wniosek 
skarżącego może wstrzymać wydanie postanowienia o umorzeniu zobowiązań 
upadłego, o którym mowa w art. 370f ust. 1. 
3. Jeżeli w wyniku rozpoznania skargi kasacyjnej postanowienie w przedmiocie 
ustalenia planu spłaty wierzycieli zostanie uchylone, sąd upadłościowy uchyla 
postanowienie o umorzeniu zobowiązań upadłego, o którym mowa w art. 370f ust. 1. 
4. Postanowienie Sądu Najwyższego w przedmiocie rozpoznania skargi 
kasacyjnej obwieszcza się. 
Art. 370c. 1. W okresie wykonywania planu spłaty wierzycieli niedopuszczalne 
jest 
wszczęcie 
postępowania 
egzekucyjnego 
dotyczącego 
wierzytelności 
wynikających z zobowiązań upadłego, o których mowa w art. 369 ust. 1, z wyjątkiem 
wierzytelności wynikających z zobowiązań, o których mowa w art. 370f ust. 2. 
2. W okresie wykonywania planu spłaty wierzycieli upadły nie może dokonywać 
czynności prawnych, które mogłyby pogorszyć jego zdolność do wykonania planu 
spłaty wierzycieli. 

©Kancelaria Sejmu 
 
 
 
s. 140/224 
 
2025-09-11 
 
3. W szczególnie uzasadnionych przypadkach sąd na wniosek upadłego może 
wyrazić zgodę na dokonanie albo zatwierdzić dokonanie czynności prawnej, o której 
mowa w ust. 2. 
4. Upadły jest obowiązany składać sądowi corocznie do końca kwietnia 
sprawozdanie z wykonania planu spłaty wierzycieli za poprzedni rok kalendarzowy, 
w którym wykazuje osiągnięte przychody, spłacone kwoty oraz nabyte składniki 
majątkowe o wartości przekraczającej przeciętne miesięczne wynagrodzenie 
w sektorze przedsiębiorstw bez wypłat nagród z zysku w trzecim kwartale roku 
poprzedniego, ogłoszone przez Prezesa Głównego Urzędu Statystycznego. Do 
sprawozdania upadły dołącza kopię rocznego zeznania podatkowego. 
Art. 370d. 1. Jeżeli upadły nie może wywiązać się z obowiązków określonych 
w planie spłaty wierzycieli, sąd na jego wniosek po wysłuchaniu wierzycieli może 
zmienić plan spłaty wierzycieli. Sąd może przedłużyć termin spłaty zobowiązań na 
dalszy okres nieprzekraczający osiemnastu miesięcy. Na postanowienie sądu 
przysługuje zażalenie, a na postanowienie sądu drugiej instancji – skarga kasacyjna. 
1a. Jeżeli brak możliwości wywiązania się z obowiązków określonych w planie 
spłaty wierzycieli ma charakter trwały i wynika z okoliczności niezależnych od 
upadłego, sąd na wniosek upadłego, po wysłuchaniu wierzycieli, może uchylić plan 
spłaty wierzycieli i umorzyć niewykonane zobowiązania upadłego, o których mowa 
w art. 369 ust. 1. Na postanowienie sądu przysługuje zażalenie, a od postanowienia 
sądu drugiej instancji – skarga kasacyjna. 
2. W przypadku istotnej poprawy sytuacji majątkowej upadłego w okresie 
wykonywania planu spłaty wierzycieli wynikającej z innych przyczyn niż zwiększenie 
się wynagrodzenia za pracę lub dochodów uzyskiwanych z osobiście wykonywanej 
przez upadłego działalności zarobkowej wierzyciel oraz upadły mogą wystąpić 
z wnioskiem o zmianę planu spłaty wierzycieli. O zmianie planu spłaty wierzycieli sąd 
orzeka po wysłuchaniu upadłego i wierzycieli objętych planem spłaty. Na 
postanowienie sądu przysługuje zażalenie. 
3. Do wierzycieli, których wierzytelności powstałe przed zakończeniem 
postępowania upadłościowego zostały po ustaleniu planu spłaty wierzycieli 
stwierdzone prawomocnym orzeczeniem, ugodą zawartą przed sądem lub ostateczną 
decyzją, przepis ust. 2 stosuje się odpowiednio. 
4. Postanowienie sądu o zmianie planu spłaty wierzycieli oraz o uchyleniu planu 
spłaty wierzycieli i umorzeniu niewykonanych zobowiązań, o których mowa 

©Kancelaria Sejmu 
 
 
 
s. 141/224 
 
2025-09-11 
 
w art. 369 ust. 1, obwieszcza się. Postanowienie sądu drugiej instancji w przedmiocie 
rozpoznania zażalenia na postanowienie sądu o zmianie planu spłaty wierzycieli oraz 
o uchyleniu planu spłaty wierzycieli i umorzeniu niewykonanych zobowiązań, 
o których mowa w art. 369 ust. 1, postanowienie Sądu Najwyższego w przedmiocie 
rozpoznania skargi kasacyjnej oraz informację o prawomocności postanowienia sądu 
o zmianie planu spłaty wierzycieli oraz postanowienia sądu o uchyleniu planu spłaty 
wierzycieli 
i umorzeniu 
niewykonanych 
zobowiązań, 
o których 
mowa 
w art. 369 ust. 1, obwieszcza się. 
Art. 370e. 1. W przypadku niewykonywania przez upadłego obowiązków 
ustalonych w planie spłaty wierzycieli sąd z urzędu albo na wniosek wierzyciela 
uchyla plan spłaty wierzycieli po wysłuchaniu upadłego i wierzycieli objętych planem 
spłaty, chyba że uchybienie obowiązkom jest nieznaczne lub umorzenie pozostałej 
części zobowiązań upadłego jest uzasadnione względami słuszności lub względami 
humanitarnymi. Na postanowienie sądu przysługuje zażalenie. 
2. Przepis ust. 1 stosuje się odpowiednio, jeżeli upadły: 
- 1) nie złożył w terminie sprawozdania z wykonania planu spłaty wierzycieli 
zgodnie z art. 370c ust. 4; 
- 2) w sprawozdaniu z wykonania planu spłaty wierzycieli zataił osiągnięte 
przychody lub nabyte składniki majątkowe, o których mowa w art. 370c ust. 4; 
- 3) dokonał czynności prawnej, o której mowa w art. 370c ust. 2, bez zgody sądu 
albo czynność ta nie została przez sąd zatwierdzona; 
- 4) ukrywał majątek lub czynność prawna upadłego została prawomocnie uznana za 
dokonaną z pokrzywdzeniem wierzycieli. 
3. W przypadku uchylenia planu spłaty zobowiązania upadłego nie podlegają 
umorzeniu. 
4. Przepis art. 370d ust. 4 stosuje się odpowiednio. 
Art. 370ea. W sprawach, o których mowa w art. 370d i art. 370e, sąd orzeka na 
rozprawie. O terminie rozprawy zawiadamia się wierzycieli przez obwieszczenie. 
Art. 370f. 1. Po wykonaniu przez upadłego obowiązków określonych w planie 
spłaty wierzycieli sąd wydaje postanowienie o stwierdzeniu wykonania planu spłaty 
i umorzeniu zobowiązań upadłego, o których mowa w art. 369 ust. 1, niewykonanych 
w wyniku wykonania planu spłaty wierzycieli. 

©Kancelaria Sejmu 
 
 
 
s. 142/224 
 
2025-09-11 
 
2. Nie podlegają umorzeniu zobowiązania o charakterze alimentacyjnym, 
zobowiązania wynikające z rent z tytułu odszkodowania za wywołanie choroby, 
niezdolności do pracy, kalectwa lub śmierci, zobowiązania do zapłaty kar grzywny 
orzeczonych przez sąd, a także do wykonania obowiązku naprawienia szkody oraz 
zadośćuczynienia za doznaną krzywdę, zobowiązania do zapłaty nawiązki lub 
świadczenia pieniężnego orzeczonych przez sąd jako środek karny lub środek 
związany z poddaniem sprawcy próbie, jak również zobowiązania do naprawienia 
szkody wynikającej z przestępstwa lub wykroczenia stwierdzonego prawomocnym 
orzeczeniem oraz zobowiązania, których upadły umyślnie nie ujawnił, jeżeli 
wierzyciel nie brał udziału w postępowaniu. 
3. Na postanowienie sądu przysługuje zażalenie. 
3a. Przepis art. 370d ust. 4 stosuje się odpowiednio. 
4. Po wydaniu postanowienia, o którym mowa w ust. 1, niedopuszczalne jest 
wszczęcie postępowania egzekucyjnego dotyczącego wierzytelności wynikających 
z zobowiązań upadłego, o których mowa w art. 369 ust. 1, z wyjątkiem wierzytelności 
wynikających z zobowiązań, o których mowa w ust. 2.

***
## Art. 371. {#art-371}

1. Postępowanie 
upadłościowe 
podlega 
uchyleniu 
w razie 
prawomocnego odrzucenia albo oddalenia wniosku o ogłoszenie upadłości. Przepisy 
art. 362–367 stosuje się odpowiednio. 
2. Przepis ust. 1 ma odpowiednie zastosowanie w przypadku umorzenia 
postępowania w przedmiocie ogłoszenia upadłości. 
3. Na postanowienie sądu przysługuje zażalenie.

***
## Art. 372. {#art-372}

1. Zmiany stosunków prawnych dokonane na podstawie przepisów 
ustawy obowiązują upadłego i drugą stronę również po umorzeniu lub zakończeniu 
postępowania upadłościowego, chyba że przepisy odrębnej ustawy stanowią inaczej. 
2. Przepis ust. 1 stosuje się odpowiednio w razie uchylenia postępowania 
upadłościowego, z tym że: 
- 1) upadły może cofnąć wypowiedzenie umów dokonane przez syndyka, jeżeli nie 
upłynął termin wypowiedzenia; 
- 2) upadły może w terminie trzydziestu dni od dnia ogłoszenia albo doręczenia 
postanowienia, którym uchylono postępowanie – odstąpić od umów zawartych 
przez syndyka, jeżeli umowa przez niego zawarta nie została wykonana albo 
została wykonana częściowo. 

©Kancelaria Sejmu 
 
 
 
s. 143/224 
 
2025-09-11 
 
TYTUŁ X 
Postępowanie w sprawach orzekania zakazu prowadzenia działalności 
gospodarczej

***
## Art. 373. {#art-373}

1. Sąd może orzec pozbawienie na okres od jednego do dziesięciu lat 
prawa prowadzenia działalności gospodarczej na własny rachunek lub w ramach 
spółki cywilnej oraz pełnienia funkcji zarządcy sukcesyjnego, członka rady 
nadzorczej, członka komisji rewizyjnej, reprezentanta lub pełnomocnika osoby 
fizycznej prowadzącej działalność gospodarczą w zakresie tej działalności, spółki 
handlowej, przedsiębiorstwa państwowego, spółdzielni, fundacji lub stowarzyszenia 
osoby, która ze swojej winy: 
- 1) będąc do tego zobowiązana z mocy ustawy, nie złożyła w ustawowym terminie 
wniosku o ogłoszenie upadłości albo 
1a) faktycznie zarządzając przedsiębiorstwem dłużnika, istotnie przyczyniła się do 
niezłożenia wniosku o ogłoszenie upadłości w ustawowym terminie, albo 
- 2) po ogłoszeniu upadłości nie wydała lub nie wskazała majątku, ksiąg 
rachunkowych, korespondencji lub innych dokumentów upadłego, w tym danych 
w postaci elektronicznej, do których wydania lub wskazania była obowiązana 
z mocy ustawy, albo 
- 3) jako upadły po ogłoszeniu upadłości ukrywała, niszczyła lub obciążała majątek 
wchodzący w skład masy upadłości, albo 
- 4) jako upadły w toku postępowania upadłościowego nie wykonała innych 
obowiązków ciążących na nim z mocy ustawy lub orzeczenia sądu albo 
sędziego-komisarza, albo też w inny sposób utrudniała postępowanie. 
1a. Mimo zaistnienia przesłanki, o której mowa w ust. 1 pkt 1, sąd może oddalić 
wniosek o orzeczenie zakazu prowadzenia działalności gospodarczej, jeżeli został 
złożony 
wniosek 
o otwarcie 
przyspieszonego 
postępowania 
układowego, 
postępowania układowego lub postępowania sanacyjnego, a rozmiar pokrzywdzenia 
wierzycieli jest nieznaczny. 
2. Przy orzekaniu zakazu, o którym mowa w ust. 1, sąd bierze pod uwagę stopień 
winy oraz skutki podejmowanych działań, w szczególności obniżenie wartości 
ekonomicznej przedsiębiorstwa upadłego i rozmiar pokrzywdzenia wierzycieli. 
3. Sąd może orzec pozbawienie na okres od jednego do dziesięciu lat prawa 
prowadzenia działalności gospodarczej na własny rachunek lub w ramach spółki 

©Kancelaria Sejmu 
 
 
 
s. 144/224 
 
2025-09-11 
 
cywilnej oraz pełnienia funkcji zarządcy sukcesyjnego, członka rady nadzorczej, 
członka komisji rewizyjnej, reprezentanta lub pełnomocnika osoby fizycznej 
prowadzącej działalność gospodarczą w zakresie tej działalności, spółki handlowej, 
przedsiębiorstwa państwowego, spółdzielni, fundacji lub stowarzyszenia osoby, 
wobec której: 
- 1) już co najmniej raz ogłoszono upadłość, z umorzeniem jej długów po 
zakończeniu postępowania upadłościowego; 
- 2) ogłoszono upadłość nie dawniej niż pięć lat przed ponownym ogłoszeniem 
upadłości.

***
## Art. 374. {#art-374}

1. Sąd może orzec zakaz prowadzenia działalności gospodarczej, 
o którym mowa w art. 373, wobec dłużnika będącego osobą fizyczną, także jeżeli 
niewypłacalność dłużnika jest następstwem jego celowego działania lub rażącego 
niedbalstwa. 
2. Do osób uprawnionych do reprezentowania przedsiębiorcy będącego osobą 
prawną albo spółką handlową niemającą osobowości prawnej oraz osób faktycznie 
zarządzających przedsiębiorstwem dłużnika, jeżeli niewypłacalność przedsiębiorcy 
lub pogorszenie jego sytuacji finansowej jest następstwem celowego działania lub 
rażącego niedbalstwa tych osób, przepis ust. 1 stosuje się.

***
## Art. 375. {#art-375}

1. W sprawach, o których mowa w art. 373 i 374, orzeka sąd 
upadłościowy. 
2. Jeżeli postępowania upadłościowego nie wszczęto albo oddalono wniosek 
o ogłoszenie upadłości lub umorzono postępowanie upadłościowe, orzeka sąd 
właściwy do rozpoznania sprawy o ogłoszenie upadłości.

***
## Art. 376. {#art-376}

1. Postępowanie w sprawach, o których mowa w art. 373 i art. 374, 
wszczyna się wyłącznie na wniosek wierzyciela, tymczasowego nadzorcy sądowego, 
zarządcy przymusowego, syndyka, prokuratora, a także Prezesa Urzędu Ochrony 
Konkurencji i Konsumentów oraz Komisji Nadzoru Finansowego. Wygaśnięcie 
w toku postępowania funkcji tymczasowego nadzorcy, zarządcy przymusowego lub 
syndyka oraz zaspokojenie wierzytelności wierzyciela będącego wnioskodawcą nie 
ma wpływu na dalszy bieg postępowania wszczętego na jego wniosek. W sprawach 
tych stosuje się przepisy o postępowaniu nieprocesowym. Przepisy art. 12a, art. 29–
30, art. 34, art. 216a–216ab, art. 219 ust. 1a–1c, art. 220 ust. 2–6, art. 221 i art. 228 

©Kancelaria Sejmu 
 
 
 
s. 145/224 
 
2025-09-11 
 
oraz przepisy wykonawcze wydane na podstawie art. 220 ust. 7 stosuje się 
odpowiednio. 
2. Sąd wydaje postanowienie po przeprowadzeniu rozprawy. 
3. Od postanowienia sądu drugiej instancji przysługuje skarga kasacyjna. 
4. (uchylony) 
5. Prawomocne postanowienie o orzeczeniu zakazu prowadzenia działalności 
gospodarczej obwieszcza się.

***
## Art. 377. {#art-377}

1. Nie orzeka się zakazu, o którym mowa w art. 373, z przyczyn 
wskazanych w art. 373 ust. 1 pkt 1 lub 1a i art. 374 ust. 1, jeżeli postępowanie w tej 
sprawie nie zostało wszczęte w terminie roku od dnia ogłoszenia upadłości albo 
oddalenia wniosku o ogłoszenie upadłości na podstawie art. 13, a gdy wniosek 
o ogłoszenie upadłości nie był złożony, w terminie trzech lat od dnia ustania stanu 
niewypłacalności albo wygaśnięcia obowiązku złożenia wniosku o ogłoszenie 
upadłości przez daną osobę. 
2. Nie orzeka się zakazu, o którym mowa w art. 373, z przyczyn wskazanych 
w art. 373 ust. 1 pkt 2–4, jeżeli postępowanie w tej sprawie nie zostało wszczęte 
w terminie roku od dnia zakończenia lub umorzenia postępowania upadłościowego. 
CZĘŚĆ DRUGA 
PRZEPISY Z ZAKRESU MIĘDZYNARODOWEGO POSTĘPOWANIA 
UPADŁOŚCIOWEGO 
TYTUŁ I 
Przepisy ogólne

***
## Art. 378. {#art-378}

1. Przepisów niniejszej części nie stosuje się, jeżeli umowa 
międzynarodowa, której Rzeczpospolita Polska jest stroną, albo prawo organizacji 
międzynarodowej, której Rzeczpospolita Polska jest członkiem, stanowi inaczej. 
2. (uchylony)

***
## Art. 379. {#art-379}

Ilekroć w przepisach niniejszej części jest mowa o: 
- 1) zagranicznym postępowaniu upadłościowym – należy przez to rozumieć 
wszelkie postępowania sądowe lub administracyjne lub inne postępowania 
poddane nadzorowi sądu zagranicznego, których przedmiotem jest wspólne 
dochodzenie roszczeń przeciwko dłużnikowi niewypłacalnemu lub zagrożonemu 
niewypłacalnością, prowadzone za granicą, w których mienie i sprawy dłużnika 

©Kancelaria Sejmu 
 
 
 
s. 146/224 
 
2025-09-11 
 
są poddane kontroli lub zarządowi zagranicznego sądu lub zagranicznego 
zarządcy w celu ich restrukturyzacji lub likwidacji; 
- 2) głównym zagranicznym postępowaniu upadłościowym – należy przez to 
rozumieć postępowanie, o którym mowa w pkt 1, jeżeli prowadzone jest 
w państwie, w którym znajduje się główny ośrodek podstawowej działalności 
dłużnika; 
- 3) ubocznym zagranicznym postępowaniu upadłościowym – należy przez to 
rozumieć postępowanie, o którym mowa w pkt 1, jeżeli nie ma charakteru 
głównego i jeżeli prowadzone jest w państwie miejsca prowadzenia działalności 
dłużnika albo jego miejsca zamieszkania lub siedziby albo w państwie, w którym 
znajduje się majątek dłużnika; 
- 4) zarządcy zagranicznym – należy przez to rozumieć osobę lub podmiot 
wyznaczony w zagranicznym postępowaniu upadłościowym do zarządzania 
majątkiem dłużnika, reorganizowania lub likwidacji jego majątku, jak również 
do nadzoru nad zarządzaniem majątkiem dłużnika lub jego reorganizacją; 
- 5) sądzie zagranicznym – należy przez to rozumieć sąd lub inny organ władzy 
publicznej uprawniony do prowadzenia lub nadzorowania zagranicznego 
postępowania upadłościowego; 
- 6) miejscu prowadzenia działalności – należy przez to rozumieć miejsce, w którym 
dłużnik 
podejmuje 
czynności 
w zakresie 
działalności 
o charakterze 
ekonomicznym, jeżeli nie mają charakteru jednorazowego lub krótkotrwałego; 
- 7) uznanym zagranicznym postępowaniu upadłościowym – należy przez to 
rozumieć zagraniczne postępowanie upadłościowe, co do którego zostało 
wydane przez polski sąd prawomocne postanowienie o uznaniu orzeczenia 
o wszczęciu postępowania.

***
## Art. 380. {#art-380}

1. 
Wierzyciel, 
którego 
miejsce 
zwykłego 
pobytu, 
miejsce 
zamieszkania albo siedziba znajdują się za granicą, korzysta w postępowaniu 
upadłościowym z praw, które przysługują wierzycielowi, którego miejsce zwykłego 
pobytu, miejsce zamieszkania albo siedziba znajdują się w Rzeczypospolitej Polskiej. 
2. Wierzyciel, który nie ma miejsca zamieszkania, zwykłego pobytu albo 
siedziby w Rzeczypospolitej Polskiej lub w innym państwie członkowskim Unii 
Europejskiej, jeżeli nie ustanowił w Rzeczypospolitej Polskiej pełnomocnika do pro-
wadzenia 
sprawy, 
jest 
obowiązany 
wskazać 
pełnomocnika 
do 
doręczeń 
w Rzeczypospolitej Polskiej. 

©Kancelaria Sejmu 
 
 
 
s. 147/224 
 
2025-09-11 
 
3. W przypadku niewskazania pełnomocnika do doręczeń, przeznaczone dla tego 
wierzyciela pisma sądowe pozostawia się w aktach sprawy ze skutkiem doręczenia. 
Wierzyciela należy o tym pouczyć przy pierwszym doręczeniu. Wierzyciela należy 
również pouczyć o tym, kto może być ustanowiony pełnomocnikiem. 
4. Zagraniczne wierzytelności publicznoprawne, w szczególności należności 
podatkowe oraz z tytułu ubezpieczenia społecznego, mogą być zgłoszone 
w postępowaniu upadłościowym, o ile ich dochodzenie w Rzeczypospolitej Polskiej 
jest dopuszczalne. W takim przypadku wierzytelności te podlegają zaspokojeniu 
w kategorii drugiej, z wyjątkiem kar majątkowych niemających charakteru 
cywilnoprawnego, orzeczonych przez sądy lub organy administracyjne za granicą, 
które podlegają zaspokojeniu w kategorii trzeciej.

***
## Art. 381. {#art-381}

W sprawach nieuregulowanych przepisami niniejszej części przepisy 
części I oraz Kodeksu postępowania cywilnego dotyczące międzynarodowego 
postępowania cywilnego stosuje się odpowiednio. 
TYTUŁ II 
Jurysdykcja krajowa

***
## Art. 382. {#art-382}

1. Do wyłącznej jurysdykcji sądów polskich należą sprawy 
upadłościowe, jeżeli w Rzeczypospolitej Polskiej znajduje się główny ośrodek 
podstawowej działalności dłużnika. 
2. Sądom polskim przysługuje również jurysdykcja, jeżeli dłużnik prowadzi 
w Rzeczypospolitej Polskiej działalność gospodarczą albo ma miejsce zamieszkania 
lub siedzibę albo majątek. 
3. Jeżeli jurysdykcja sądu polskiego jest wyłączna, postępowanie upadłościowe 
ma charakter głównego postępowania upadłościowego. W pozostałych przypadkach 
postępowanie upadłościowe ma charakter ubocznego postępowania upadłościowego.

***
## Art. 383. {#art-383}

W sprawach upadłościowych nie stosuje się przepisów dotyczących 
umów o jurysdykcję.

***
## Art. 384. {#art-384}

Ustanowienie przez sąd zagraniczny zarządcy zagranicznego do 
podejmowania czynności w Rzeczypospolitej Polskiej nie wyłącza jurysdykcji 
krajowej sądów polskich. 

©Kancelaria Sejmu 
 
 
 
s. 148/224 
 
2025-09-11 
 
TYTUŁ III 
Uznawanie orzeczeń o wszczęciu zagranicznego postępowania upadłościowego

***
## Art. 385. {#art-385}

(uchylony)

***
## Art. 386. {#art-386}

1. Postępowanie w przedmiocie uznania orzeczenia o wszczęciu 
zagranicznego postępowania upadłościowego wszczyna się na wniosek zarządcy 
zagranicznego albo dłużnika, któremu pozostawiono zarząd własny majątkiem. 
2. Do wniosku o uznanie należy dołączyć: 
- 1) odpis orzeczenia lub decyzji o wszczęciu zagranicznego postępowania 
upadłościowego i ustanowieniu zarządcy albo 
- 2) zaświadczenie sądu zagranicznego potwierdzające prowadzenie postępowania 
i wyznaczenie zagranicznego zarządcy; 
- 3) spis wierzycieli, których miejsce zamieszkania, siedziba lub główny ośrodek 
podstawowej działalności znajdują się na terenie Rzeczypospolitej Polskiej, 
wierzycieli, których wierzytelności wynikają z działalności ekonomicznej 
dłużnika prowadzonej w Rzeczypospolitej Polskiej, oraz wierzycieli, którym 
przysługują wobec dłużnika wierzytelności zabezpieczone na majątku dłużnika 
położonym na terenie Rzeczypospolitej Polskiej hipoteką, zastawem, zastawem 
skarbowym, zastawem rejestrowym, hipoteką morską lub przeniesieniem na 
zabezpieczenie rzeczy, wierzytelności lub innych praw majątkowych. 
3. W przypadku braku dokumentów wymienionych w ust. 2 pkt 1 i 2 do wniosku 
należy dołączyć inny wiarygodny dowód na piśmie wszczęcia zagranicznego 
postępowania i wyznaczenia zagranicznego zarządcy. 
4. Do wniosku należy ponadto dołączyć oświadczenie wnioskodawcy o innych 
postępowaniach zagranicznych prowadzonych wobec upadłego, które są znane 
wnioskodawcy, oraz oświadczenie zawierające informacje o terminie zgłaszania 
wierzytelności, adresie, pod którym wierzytelności należy zgłaszać, jak również 
o innych niezbędnych danych, które należy podać w zgłoszeniu, oraz o języku 
zgłoszenia. 
5. Do dokumentów lub dowodów na piśmie, wymienionych w ust. 2–4, należy 
ponadto dołączyć ich uwierzytelnione tłumaczenie na język polski. 
6. Wnioskodawca uiszcza zaliczkę na wydatki w toku 
postępowania 
w przedmiocie uznania orzeczenia o wszczęciu zagranicznego postępowania 
upadłościowego 
w wysokości 
jednokrotności 
przeciętnego 
miesięcznego 

©Kancelaria Sejmu 
 
 
 
s. 149/224 
 
2025-09-11 
 
wynagrodzenia w sektorze przedsiębiorstw bez wypłat nagród z zysku w trzecim 
kwartale roku poprzedniego, ogłoszonego przez Prezesa Głównego Urzędu 
Statystycznego i wraz z wnioskiem przedstawia dowód jej uiszczenia. W przypadku 
nieuiszczenia zaliczki przewodniczący wzywa do jej uiszczenia w terminie tygodnia 
pod rygorem zwrotu wniosku.

***
## Art. 387. {#art-387}

Uczestnikami postępowania w przedmiocie uznania orzeczenia 
o wszczęciu zagranicznego postępowania upadłościowego są zarządca zagraniczny 
albo dłużnik, któremu pozostawiono zarząd własny majątkiem.

***
## Art. 388. {#art-388}

Zawiadomienia uczestników postępowania o pierwszym posiedzeniu 
sądu można dokonać za pośrednictwem operatora pocztowego w rozumieniu ustawy 
z dnia 23 listopada 2012 r. – Prawo pocztowe przesyłką poleconą, odpowiednio za 
potwierdzeniem odbioru albo za zwrotnym pokwitowaniem odbioru, albo na adres do 
doręczeń elektronicznych, o którym mowa w art. 2 pkt 1 ustawy z dnia 18 listopada 
2020 r. o doręczeniach elektronicznych, wpisany do bazy adresów elektronicznych, 
o której mowa w art. 25 tej ustawy.

***
## Art. 389. {#art-389}

Po 
wniesieniu 
wniosku 
o uznanie 
orzeczenia 
o wszczęciu 
zagranicznego postępowania upadłościowego, wnioskodawca jest obowiązany 
niezwłocznie informować sąd: 
- 1) o zmianie postępowania zagranicznego, którego dotyczy wniosek o uznanie 
orzeczenia o wszczęciu zagranicznego postępowania upadłościowego, oraz 
o ustanowieniu lub zmianie zarządcy; 
- 2) o innych zagranicznych postępowaniach upadłościowych dotyczących dłużnika 
oraz 
innych 
postępowaniach 
sądowych, 
administracyjnych, 
sądowoadministracyjnych i przed sądami polubownymi dotyczących majątku 
dłużnika, które są znane wnioskodawcy.

***
## Art. 390. {#art-390}

1. Z dniem wniesienia wniosku o uznanie orzeczenia o wszczęciu 
zagranicznego postępowania upadłościowego sąd na wniosek wnioskodawcy może: 
- 1) wydać postanowienie o zabezpieczeniu; 
- 2) zabezpieczyć dowody potrzebne do dochodzenia roszczeń przeciw dłużnikowi. 
2. Sąd może odmówić wydania postanowienia o zabezpieczeniu, jeżeli 
zabezpieczenie to utrudniłoby zarządzanie majątkiem upadłego w głównym 
zagranicznym postępowaniu upadłościowym. 

©Kancelaria Sejmu 
 
 
 
s. 150/224 
 
2025-09-11

***
## Art. 391. {#art-391}

(uchylony)

***
## Art. 392. {#art-392}

Orzeczenie o wszczęciu zagranicznego postępowania upadłościowego 
podlega uznaniu, jeżeli: 
- 1) dotyczy sprawy, która nie należy do wyłącznej jurysdykcji sądów polskich; 
- 2) uznanie nie jest sprzeczne z podstawowymi zasadami porządku prawnego 
w Rzeczypospolitej Polskiej.

***
## Art. 393. {#art-393}

1. W postanowieniu o uznaniu orzeczenia o wszczęciu zagranicznego 
postępowania upadłościowego określa się: 
- 1) imię i nazwisko albo firmę upadłego oraz odpowiednio miejsce zamieszkania 
albo siedzibę upadłego, a gdy dłużnikiem (upadłym) jest spółka osobowa, osoba 
prawna albo inna jednostka organizacyjna nieposiadająca osobowości prawnej, 
której odrębna ustawa przyznaje zdolność prawną – imiona i nazwiska 
reprezentantów, w tym likwidatorów, jeżeli są ustanowieni, a ponadto 
w przypadku spółki osobowej – imiona i nazwiska albo nazwę, numery PESEL 
albo numery w Krajowym Rejestrze Sądowym, a w przypadku ich braku – inne 
dane umożliwiające jednoznaczną identyfikację oraz miejsce zamieszkania albo 
siedzibę wspólników odpowiadających za zobowiązania spółki bez ograniczenia 
całym swoim majątkiem; 
1a) numer identyfikacyjny upadłego albo nazwę rejestru, do którego jest wpisany 
upadły, i numer wpisu do rejestru, albo inne dane umożliwiające jednoznaczną 
identyfikację upadłego, a także NIP upadłego, jeżeli upadły ma taki numer; 
- 2) sąd zagraniczny, który ogłosił upadłość; 
- 3) zarządcę zagranicznego przez wskazanie jego imienia i nazwiska albo firmy oraz 
odpowiednio miejsca zamieszkania albo siedziby; 
- 4) czy uznane postępowanie jest postępowaniem głównym czy ubocznym. 
1a. Przez inne dane umożliwiające jednoznaczną identyfikację, o których mowa 
w ust. 1 pkt 1a, rozumie się dane, o których mowa w art. 22 ust. 4. 
2. W postanowieniu 
o uznaniu 
orzeczenia 
o wszczęciu 
zagranicznego 
postępowania upadłościowego wzywa się wierzycieli upadłego do zgłoszenia 
wierzytelności, wskazując termin zgłaszania wierzytelności oraz adres, pod którym 
wierzytelności należy zgłosić, jak również niezbędne dane, które należy podać 
w zgłoszeniu, i język zgłoszenia. 

©Kancelaria Sejmu 
 
 
 
s. 151/224 
 
2025-09-11 
 
3. Postanowienie o uznaniu orzeczenia o wszczęciu zagranicznego postępowania 
upadłościowego obwieszcza się. 
4. Odpis postanowienia o uznaniu orzeczenia o wszczęciu zagranicznego 
postępowania upadłościowego doręcza się wierzycielom wskazanym przez 
wnioskodawcę w spisie, o którym mowa w art. 386 ust. 2 pkt 3, oraz innym 
wierzycielom wskazanym w tym przepisie, jeżeli są znani sądowi, nawet jeżeli nie 
zostali wskazani w spisie przedłożonym przez wnioskodawcę. Wierzycieli poucza się 
o skutkach uznania orzeczenia o wszczęciu zagranicznego postępowania upadłościo-
wego oraz o możliwości złożenia wniosku o wszczęcie wtórnego postępowania 
upadłościowego i skutkach niezłożenia wniosku w terminie trzydziestu dni od dnia 
obwieszczenia. 
5. Na 
postanowienie 
w przedmiocie 
uznania 
orzeczenia 
o wszczęciu 
zagranicznego postępowania upadłościowego przysługuje zażalenie wnioskodawcy 
oraz wierzycielom, o których mowa w art. 386 ust. 2 pkt 3. Zażalenie rozpoznaje sąd 
drugiej instancji w składzie trzech sędziów zawodowych. 
Art. 393a. 1. Niezwłocznie po uznaniu orzeczenia o wszczęciu zagranicznego 
postępowania upadłościowego sąd zabezpiecza majątek dłużnika znajdujący się na 
terenie Rzeczypospolitej Polskiej przez ustanowienie tymczasowego nadzorcy 
sądowego. 
2. Czynności zagranicznego zarządcy albo dłużnika sprawującego zarząd własny 
majątkiem, dotyczące majątku znajdującego się na terenie Rzeczypospolitej Polskiej 
przekraczające zakres zwykłego zarządu wymagają zgody tymczasowego nadzorcy 
sądowego pod rygorem nieważności, chyba że wymagają zgody sądu. Zgody 
tymczasowego nadzorcy sądowego wymaga również wywiezienie składników 
majątku dłużnika poza teren Rzeczypospolitej Polskiej. 
3. Zabezpieczenie przez ustanowienie tymczasowego nadzorcy sądowego upada 
z mocy prawa z chwilą wszczęcia wtórnego postępowania upadłościowego, 
prawomocnego 
oddalenia 
lub 
odrzucenia 
wniosku 
o wszczęcie 
wtórnego 
postępowania upadłościowego lub umorzenia postępowania w przedmiocie wniosku 
albo niezłożenia wniosku o wszczęcie wtórnego postępowania upadłościowego 
w terminie trzydziestu dni od dnia obwieszczenia postanowienia o uznaniu orzeczenia 
o wszczęciu zagranicznego postępowania upadłościowego. 

©Kancelaria Sejmu 
 
 
 
s. 152/224 
 
2025-09-11 
 
4. Z dniem uznania orzeczenia o wszczęciu zagranicznego postępowania 
upadłościowego zarówno głównego, jak i ubocznego sąd na wniosek zarządcy 
zagranicznego może zabezpieczyć dowody.

***
## Art. 394. {#art-394}

1. Jeżeli przepisy ustawy nie stanowią inaczej, uznanie orzeczenia 
o wszczęciu zagranicznego postępowania upadłościowego skutkuje z mocy prawa 
uznaniem wydanych w jego toku orzeczeń dotyczących powołania, odwołania oraz 
zmiany zarządcy zagranicznego, a także orzeczeń dotyczących toku zagranicznego 
postępowania upadłościowego, jego zawieszenia i zakończenia. 
2. Egzekucja przeciwko upadłemu na podstawie zagranicznych tytułów 
egzekucyjnych wykonalnych w państwie, w którym zostały wydane w uznanym 
zagranicznym postępowaniu upadłościowym, w tym na podstawie listy wierzytelności 
lub innych podobnych dokumentów, jak również egzekucja na podstawie postanowień 
układu zawartego w uznanym zagranicznym postępowaniu upadłościowym, a także 
egzekucja na podstawie wyciągów, odpisów i innych podobnych dokumentów 
wystawionych 
na 
podstawie 
układu 
zawartego 
w uznanym 
postępowaniu 
upadłościowym, może być prowadzona po stwierdzeniu ich wykonalności przez sąd 
uznający orzeczenie o wszczęciu zagranicznego postępowania upadłościowego. 
3. Stwierdzenie wykonalności następuje przez nadanie klauzuli wykonalności na 
wniosek wierzyciela. Do stwierdzenia istnienia podstaw wykonalności przepis 
art. 392 stosuje się odpowiednio.

***
## Art. 395. {#art-395}

1. Postanowienie o uznaniu orzeczenia o wszczęciu zagranicznego 
postępowania upadłościowego może być w każdym czasie zmienione lub uchylone 
w przypadku późniejszego wykrycia, że nie było podstaw do jego uznania albo 
podstawy te przestały istnieć. 
1a. Sąd uchyla postanowienie o uznaniu orzeczenia o wszczęciu zagranicznego 
postępowania upadłościowego, jeżeli w zagranicznym postępowaniu upadłościowym 
został przyjęty układ, którego treść jest rażąco sprzeczna z polskim prawem. 
2. Postępowanie w przedmiocie uchylenia lub zmiany orzeczenia o uznaniu 
zagranicznego postępowania upadłościowego może być wszczęte na wniosek 
każdego, kogo uznanie może dotyczyć, a także z urzędu. 
3. Przepisy art. 393 ust. 3–5 stosuje się odpowiednio. 

©Kancelaria Sejmu 
 
 
 
s. 153/224 
 
2025-09-11

***
## Art. 396. {#art-396}

1. W postanowieniu o zmianie orzeczenia o uznaniu orzeczenia 
o wszczęciu zagranicznego postępowania upadłościowego sąd określa zakres zmian, 
w szczególności zakres uprawnień zarządcy zagranicznego. 
2. W przypadku pozbawienia zarządcy zagranicznego prawa do prowadzenia 
postępowań cywilnych, wszczęte przez niego postępowania podlegają umorzeniu, 
chyba że sąd prowadzący postępowanie postanowi, że do postępowań tych może 
wstąpić inny zarządca zagraniczny albo syndyk ustanowiony w postępowaniu 
upadłościowym lub dłużnik. Do interwencji ubocznych zgłoszonych przez zarządcę 
zagranicznego przepis ten stosuje się odpowiednio.

***
## Art. 397. {#art-397}

1. 
Z dniem 
uznania 
orzeczenia 
o wszczęciu 
zagranicznego 
postępowania upadłościowego do skutków wszczęcia zagranicznego postępowania 
upadłościowego dla prowadzonych w Rzeczypospolitej Polskiej postępowań 
sądowych, egzekucyjnych, administracyjnych, sądowoadministracyjnych lub przed 
sądami polubownymi stosuje się prawo polskie z uwzględnieniem, likwidacyjnego lub 
restrukturyzacyjnego charakteru zagranicznego postępowania upadłościowego, 
zakresu pozbawienia dłużnika prawa zarządu majątkiem oraz zakresu objęcia 
wierzytelności układem. Prawo polskie stosuje się również do oceny możliwości 
wszczęcia postępowania po uznaniu orzeczenia o wszczęciu zagranicznego 
postępowania upadłościowego. 
2. Przepis ust. 1 nie wyklucza jednak możliwości wnoszenia powództw 
przeciwko upadłemu, jeżeli jest to konieczne dla zachowania praw osób trzecich.

***
## Art. 398. {#art-398}

Przepis art. 397 nie ogranicza praw wierzycieli do żądania wszczęcia 
postępowania upadłościowego w Rzeczypospolitej Polskiej oraz do zgłaszania 
wierzytelności w takim postępowaniu.

***
## Art. 399. {#art-399}

(uchylony)

***
## Art. 400. {#art-400}

(uchylony) 
Art. 400a. Po uznaniu orzeczenia o wszczęciu zagranicznego postępowania 
upadłościowego postępowanie toczy się w sądzie, który uznał orzeczenie.

***
## Art. 401. {#art-401}

1. Po uznaniu orzeczenia o wszczęciu głównego zagranicznego 
postępowania upadłościowego zarządca zagraniczny lub dłużnik, któremu 
pozostawiono zarząd własny majątkiem, sporządza spis inwentarza i oszacowanie, 
które obejmują wchodzący do masy upadłości majątek upadłego znajdujący się na 

©Kancelaria Sejmu 
 
 
 
s. 154/224 
 
2025-09-11 
 
terenie Rzeczypospolitej Polskiej. Spis inwentarza wraz z oszacowaniem zarządca 
zagraniczny lub dłużnik, któremu pozostawiono zarząd własny majątkiem, składa 
sądowi uznającemu orzeczenie o wszczęciu zagranicznego postępowania w terminie 
czterech miesięcy od dnia uprawomocnienia się postanowienia o uznaniu. 
O dokonanym spisie i oszacowaniu obwieszcza się. Wnioski o wyłączenie z masy 
upadłości rozpoznaje sąd uznający. Termin do wniesienia takich wniosków wynosi 
trzydzieści dni od dnia obwieszczenia. 
2. Po sporządzeniu spisu inwentarza i oszacowania zarządca zagraniczny lub 
dłużnik, któremu pozostawiono zarząd własny majątkiem, składa sądowi uznającemu 
plan likwidacji majątku położonego w Rzeczypospolitej Polskiej oraz ogólną 
informację o przewidywanym sposobie zaspokojenia wierzycieli, w tym również 
mających miejsce zamieszkania, miejsce zwykłego pobytu albo siedzibę 
w Rzeczypospolitej Polskiej. Na tej podstawie sąd uznający postanowieniem wyda 
zezwolenie na likwidację majątku upadłego znajdującego się na terenie 
Rzeczypospolitej Polskiej. Postanowienie to sąd uznający wydaje nie wcześniej niż po 
upływie terminu, w którym można żądać wyłączenia z masy upadłości. Na 
postanowienie o odmowie wydania zezwolenia przysługuje zażalenie, które 
rozpoznaje sąd drugiej instancji w składzie trzech sędziów zawodowych. 
3. Zezwolenie, o którym mowa w ust. 2, nie obejmuje mienia, o które toczy się 
postępowanie o wyłączenie z masy upadłości. Zarządca zagraniczny jest uprawniony 
do likwidacji tego mienia dopiero po uprawomocnieniu się wyroku oddalającego 
powództwo o wyłączenie z masy upadłości lub po umorzeniu postępowania w tej 
sprawie, a gdy powództwa tego nie wniesiono, po upływie terminu, w którym 
powództwo takie skarżący mógł wnieść. 
4. Do ustalenia składu masy upadłości, spisu inwentarza i oszacowania, 
wyłączeń 
z masy 
upadłości, 
zarządu 
masą 
upadłości 
znajdującą 
się 
w Rzeczypospolitej Polskiej oraz likwidacji masy upadłości stosuje się przepisy 
niniejszej ustawy. Sąd uznający może zezwolić na likwidację masy upadłości w inny 
sposób, jeżeli nie narusza to podstawowych zasad porządku prawnego 
Rzeczypospolitej Polskiej. 
5. Po zakończeniu likwidacji majątku znajdującego się na terytorium 
Rzeczypospolitej Polskiej sąd uznający wydaje postanowienie o zakończeniu 
postępowania. 

©Kancelaria Sejmu 
 
 
 
s. 155/224 
 
2025-09-11 
 
6. Sąd uznający wydaje również postanowienie o zakończeniu postępowania 
w przypadku wszczęcia wtórnego postępowania upadłościowego oraz w przypadku 
uprawomocnienia się postanowienia o uchyleniu postanowienia o uznaniu orzeczenia 
o wszczęciu zagranicznego postępowania upadłościowego.

***
## Art. 402. {#art-402}

Po uznaniu orzeczenia o wszczęciu zagranicznego postępowania 
upadłościowego zarządca zagraniczny jest uprawniony do złożenia wniosku 
o ogłoszenie 
upadłości 
oraz 
do 
udziału 
w postępowaniu 
upadłościowym 
prowadzonym przez sądy polskie, tak jak wierzyciel.

***
## Art. 403. {#art-403}

1. W przypadku uznania orzeczenia o wszczęciu zagranicznego 
postępowania upadłościowego, skutki ogłoszenia upadłości co do majątku upadłego 
położonego w Rzeczypospolitej Polskiej oraz zobowiązań, które powstały lub mają 
być wykonywane w Rzeczypospolitej Polskiej, ocenia się według prawa polskiego. 
2. Bezskuteczność i zaskarżanie czynności upadłego, dotyczących znajdujących 
się w Rzeczypospolitej Polskiej składników mienia wchodzącego w skład masy 
upadłości, ocenia się według prawa polskiego.

***
## Art. 404. {#art-404}

1. Zaspokojenie wierzytelności zabezpieczonych ograniczonymi 
prawami rzeczowymi na rzeczach znajdujących się w Rzeczypospolitej Polskiej albo 
wpisanymi do ksiąg wieczystych i rejestrów w Rzeczypospolitej Polskiej następuje 
według prawa polskiego. Przepisu art. 313 ust. 2 zdanie piąte nie stosuje się. 
2. Hipoteka wygasa z chwilą zawarcia umowy sprzedaży, pod warunkiem że 
środki wpłyną na rachunek depozytowy Ministra Finansów. Podstawą wykreślenia 
hipoteki jest zaświadczenie sądu uznającego. 
3. Wypłata kwot z depozytu następuje bezpośrednio na rzecz wierzycieli po 
zatwierdzeniu planu podziału sporządzonego przez zagranicznego zarządcę albo na 
podstawie postanowienia sądu uznającego, jeżeli nie sporządzono planu podziału. 
TYTUŁ IV 
Wtórne postępowanie upadłościowe

***
## Art. 405. {#art-405}

1. Uznanie orzeczenia o wszczęciu zagranicznego postępowania 
upadłościowego nie stanowi przeszkody do wszczęcia przez sąd polski postępowania 
upadłościowego. Jeżeli jednak uznane zostało orzeczenie o wszczęciu głównego 
zagranicznego postępowania upadłościowego, postępowanie upadłościowe wszczęte 
w Rzeczypospolitej Polskiej jest wtórnym postępowaniem upadłościowym. 

©Kancelaria Sejmu 
 
 
 
s. 156/224 
 
2025-09-11 
 
2. Do postępowania, o którym mowa w ust. 1, stosuje się przepisy tytułu 
niniejszego. 
3. Jeżeli uznane zostało orzeczenie o wszczęciu ubocznego zagranicznego 
postępowania upadłościowego, postępowanie upadłościowe w Rzeczypospolitej 
Polskiej toczy się na zasadach ogólnych.

***
## Art. 406. {#art-406}

1. Przepisy o wtórnym postępowaniu upadłościowym stosuje się 
również do postępowań upadłościowych wszczętych przed uznaniem orzeczenia 
o wszczęciu zagranicznego postępowania upadłościowego, jeżeli sąd polski uzna 
zagraniczne postępowanie upadłościowe za główne. 
2. W przypadku, o którym mowa w ust. 1, sąd zmienia wydane wcześniej 
postanowienie o ogłoszeniu upadłości na postanowienie o wszczęciu wtórnego 
postępowania upadłościowego.

***
## Art. 407. {#art-407}

Sąd wszczyna wtórne postępowanie upadłościowe, jeżeli wnosi o to 
wierzyciel mający miejsce zamieszkania, siedzibę lub główny ośrodek podstawowej 
działalności w Rzeczypospolitej Polskiej, wierzyciel, którego wierzytelności wynikają 
z działalności ekonomicznej dłużnika prowadzonej w Rzeczypospolitej Polskiej, lub 
wierzyciel, któremu przysługują wobec dłużnika wierzytelności zabezpieczone na 
majątku dłużnika położonym na terenie Rzeczypospolitej Polskiej hipoteką, 
zastawem, zastawem skarbowym, zastawem rejestrowym, hipoteką morską lub 
przeniesieniem na zabezpieczenie rzeczy, wierzytelności lub innych praw 
majątkowych.

***
## Art. 408. {#art-408}

W przypadku 
uznania 
orzeczenia 
o wszczęciu 
głównego 
zagranicznego postępowania upadłościowego domniemywa się, że dłużnik jest 
niewypłacalny.

***
## Art. 409. {#art-409}

W przypadku wniesienia wniosku o wszczęcie wtórnego postępowania 
upadłościowego sąd może uchylić lub zmienić zabezpieczenia ustanowione na 
podstawie art. 390.

***
## Art. 410. {#art-410}

Po wszczęciu wtórnego postępowania upadłościowego: 
- 1) zarząd 
majątkiem 
upadłego 
położonym 
w Rzeczypospolitej 
Polskiej 
wykonywany dotychczas przez zarządcę zagranicznego lub dłużnika, któremu 
pozostawiono zarząd własny majątkiem, przejmuje syndyk ustanowiony we 
wtórnym postępowaniu upadłościowym; 

©Kancelaria Sejmu 
 
 
 
s. 157/224 
 
2025-09-11 
- 2) syndyk wstępuje do postępowań sądowych, egzekucyjnych, administracyjnych, 
sądowoadministracyjnych oraz przed sądami polubownymi, prowadzonych 
przez zarządcę zagranicznego lub dłużnika, któremu pozostawiono zarząd włas-
ny majątkiem. 
Art. 410a. 1. Jeżeli w uznanym głównym zagranicznym postępowaniu 
upadłościowym został zawarty układ, którego treść nie jest rażąco sprzeczna z polskim 
prawem, sąd wyznacza termin zgromadzenia wierzycieli w celu głosowania nad 
uznaniem skuteczności zagranicznego układu. 
2. W zgromadzeniu wierzycieli biorą udział z prawem głosu wierzyciele, których 
miejsce zamieszkania, siedziba lub główny ośrodek podstawowej działalności 
znajdują się na terenie Rzeczypospolitej Polskiej, wierzyciele, których wierzytelności 
wynikają z działalności ekonomicznej dłużnika prowadzonej w Rzeczypospolitej 
Polskiej, oraz wierzyciele, którym przysługują wobec dłużnika wierzytelności 
zabezpieczone na majątku dłużnika położonym na terenie Rzeczypospolitej Polskiej 
hipoteką, zastawem, zastawem skarbowym, zastawem rejestrowym, hipoteką morską 
lub przeniesieniem na zabezpieczenie rzeczy, wierzytelności lub innych praw 
majątkowych. 
3. Do zgromadzenia wierzycieli i głosowania przepisy o zgromadzeniu 
i głosowaniu nad układem w postępowaniu upadłościowym stosuje się odpowiednio. 
Art. 410b. 1. Jeżeli na zgromadzeniu wierzycieli nie podjęto uchwały o uznaniu 
skuteczności zagranicznego układu, sąd umarza wtórne postępowanie upadłościowe 
i uchyla 
postanowienie 
o uznaniu 
orzeczenia 
o wszczęciu 
zagranicznego 
postępowania upadłościowego. 
2. Przepisy art. 393 ust. 3–5 stosuje się odpowiednio.

***
## Art. 411. {#art-411}

Jeżeli we wtórnym postępowaniu upadłościowym ma zostać zawarty 
układ, a w zagranicznym głównym postępowaniu upadłościowym ma nastąpić 
likwidacja majątku upadłego, układ może mieć wyłącznie charakter likwidacyjny.

***
## Art. 412. {#art-412}

Sumy uzyskane z podziału funduszów masy upadłości pozostałe po 
zaspokojeniu wierzycieli we wtórnym postępowaniu upadłościowym przekazuje się 
do głównego zagranicznego postępowania upadłościowego. 

©Kancelaria Sejmu 
 
 
 
s. 158/224 
 
2025-09-11 
 
TYTUŁ V 
Współpraca z sądami zagranicznymi i zarządcami zagranicznymi

***
## Art. 413. {#art-413}

W sprawach uregulowanych przepisami niniejszej części sąd 
i sędzia-komisarz mogą porozumiewać się bezpośrednio z sądem zagranicznym 
i zarządcą zagranicznym, w szczególności przez telefon, faks lub pocztę 
elektroniczną.

***
## Art. 414. {#art-414}

Syndyk ustanowiony w postępowaniu upadłościowym porozumiewa 
się z sądem zagranicznym i zarządcą zagranicznym bezpośrednio lub za 
pośrednictwem sędziego-komisarza.

***
## Art. 415. {#art-415}

1. W sprawach uregulowanych przepisami niniejszej części sąd 
i sędzia-komisarz współpracują z sądem zagranicznym i zarządcą zagranicznym. 
2. Jeżeli wszczęto w Rzeczypospolitej Polskiej postępowanie upadłościowe, sąd 
prowadzący to postępowanie podejmuje działania przewidziane w niniejszym tytule.

***
## Art. 416. {#art-416}

W ramach 
współpracy 
z sądem 
zagranicznym 
i zarządcą 
zagranicznym sąd i sędzia-komisarz mogą podejmować działania, które zapewniają 
sprawne prowadzenie postępowań upadłościowych, a w szczególności przekazywać 
oraz zwracać się o informacje: 
- 1) dotyczące majątku upadłego i miejsca jego położenia, jak również informacje 
dotyczące postępowań sądowych, administracyjnych, sądowoadministracyjnych 
i przed sądami polubownymi dotyczących upadłego; 
- 2) o sposobie zabezpieczenia i likwidacji majątku upadłego; 
- 3) o zaspokojeniu poszczególnych wierzycieli.

***
## Art. 417. {#art-417}

1. Jeżeli w Rzeczypospolitej Polskiej wszczęto postępowanie 
upadłościowe i uznano orzeczenia o wszczęciu dwóch lub więcej zagranicznych 
postępowań upadłościowych przeciwko temu samemu upadłemu, sędzia-komisarz 
określa, jaki majątek dłużnika objęty zostanie poszczególnymi postępowaniami. Na 
postanowienie sędziego-komisarza przysługuje zażalenie. 
2. Jeżeli w Rzeczypospolitej Polskiej nie zostało wszczęte postępowanie 
upadłościowe obejmujące majątek należący do podmiotu, wobec którego są 
prowadzone zagraniczne postępowania upadłościowe, postanowienie, o którym mowa 
w ust. 1, wydaje sąd, który uznał orzeczenie o wszczęciu zagranicznego postępowania 
upadłościowego. Przepisy części pierwszej tytułu II stosuje się odpowiednio. 

©Kancelaria Sejmu 
 
 
 
s. 159/224 
 
2025-09-11 
 
CZĘŚĆ TRZECIA 
ODRĘBNE POSTĘPOWANIA UPADŁOŚCIOWE 
TYTUŁ I 
Postępowanie upadłościowe wszczęte po śmierci niewypłacalnego dłużnika

***
## Art. 418. {#art-418}

Jeżeli wniosek o ogłoszenie upadłości wobec przedsiębiorcy lub 
osoby, o której mowa w art. 8 lub art. 9, złożono po ich śmierci, postępowanie 
upadłościowe prowadzone jest według przepisów zawartych w tytule niniejszym.

***
## Art. 419. {#art-419}

1. Jeżeli w postępowaniu nie bierze udziału spadkobierca, którego 
prawa zostały stwierdzone prawomocnym postanowieniem o stwierdzeniu nabycia 
spadku, albo kurator spadku, sąd w postanowieniu o ogłoszeniu upadłości ustanowi 
kuratora, do którego stosuje się przepis art. 187. Po ogłoszeniu upadłości orzeczenie 
o powołaniu lub zmianie kuratora wydaje sędzia-komisarz. 
2. W razie zbycia spadku przed ogłoszeniem upadłości postępowanie prowadzi 
się z udziałem nabywcy spadku, do którego stosuje się przepisy dotyczące upadłego. 
3. W przypadku gdy został ustanowiony zarząd sukcesyjny, uczestnikiem 
postępowania o ogłoszenie upadłości zmarłego przedsiębiorcy jest również zarządca 
sukcesyjny. Zażalenie na postanowienie o ogłoszeniu upadłości przysługuje również 
osobie, która pełniła funkcję zarządcy sukcesyjnego w chwili ogłoszenia upadłości.

***
## Art. 420. {#art-420}

(uchylony)

***
## Art. 421. {#art-421}

Do masy upadłości wchodzą aktywa spadku po zmarłym dłużniku, 
a w przypadku ustanowienia zarządu sukcesyjnego także aktywa nabyte w okresie 
zarządu sukcesyjnego, które weszły w skład przedsiębiorstwa w spadku.

***
## Art. 422. {#art-422}

Ustanowienie wykonawcy testamentu oraz zapisy i polecenia są 
bezskuteczne wobec masy upadłości.

***
## Art. 423. {#art-423}

Do czynności upadłego, dokonanych na sześć miesięcy przed jego 
śmiercią, przepisy art. 127–130a stosuje się.

***
## Art. 424. {#art-424}

W razie ogłoszenia upadłości w sprawach objętych przepisami 
niniejszego tytułu skutki prawne związane z przyjęciem spadku powstają po 
zakończeniu postępowania upadłościowego.

***
## Art. 425. {#art-425}

Po zakończeniu albo umorzeniu postępowania upadłościowego wyciąg 
z zatwierdzonej listy wierzytelności, zawierający oznaczenie wierzytelności oraz 

©Kancelaria Sejmu 
 
 
 
s. 160/224 
 
2025-09-11 
 
sumy na jej poczet otrzymane przez wierzyciela, jest tytułem egzekucyjnym 
przeciwko spadkobiercy. 
TYTUŁ IA 
Postępowanie upadłościowe wobec deweloperów 
DZIAŁ I 
Przepisy ogólne 
Art. 425a. Przepisy niniejszego tytułu stosuje się w przypadku ogłoszenia 
upadłości dewelopera w rozumieniu art. 5 pkt 1 ustawy z dnia 20 maja 2021 r. 
o ochronie praw nabywcy lokalu mieszkalnego lub domu jednorodzinnego oraz 
Deweloperskim Funduszu Gwarancyjnym (Dz. U. z 2024 r. poz. 695), zwanej dalej 
„ustawą o ochronie nabywcy”. 
Art. 425b. Postępowanie określone w niniejszym tytule prowadzi się w celach, 
o których mowa w art. 2, a także aby doprowadzić do zaspokojenia nabywców 
w drodze przeniesienia na nich własności lokali, o ile racjonalne względy na to 
pozwolą. 
Art. 425c. Ilekroć w przepisach niniejszego tytułu jest mowa o: 
- 1) nabywcy – należy przez to rozumieć osobę fizyczną, osobę prawną, a także 
jednostkę organizacyjną niebędącą osobą prawną, której odrębna ustawa 
przyznaje zdolność prawną, wobec której deweloper zobowiązał się do 
przeniesienia praw wynikających z umowy deweloperskiej, o której mowa 
w art. 5 pkt 6 ustawy o ochronie nabywcy, albo jednej z umów, o których mowa 
w art. 2 ust. 1 pkt 2, 3 lub 5 lub ust. 2 tej ustawy, i która zobowiązała się do 
spełnienia świadczenia pieniężnego na rzecz dewelopera na poczet ceny nabycia 
jednego z tych praw; 
- 2) przeniesieniu własności lokalu – należy przez to rozumieć przeniesienie 
własności lokalu mieszkalnego, a także przeniesienie własności nieruchomości 
gruntowej zabudowanej domem jednorodzinnym lub użytkowania wieczystego 
nieruchomości 
gruntowej 
i własności 
domu jednorodzinnego na niej 
posadowionego stanowiącego odrębną nieruchomość lub przeniesienie 
ułamkowej części własności nieruchomości, lub przeniesienie własności lokalu 
użytkowego na podstawie umowy, o której mowa w art. 2 ust. 2 ustawy 
o ochronie nabywcy; 

©Kancelaria Sejmu 
 
 
 
s. 161/224 
 
2025-09-11 
- 3) umowie deweloperskiej – należy przez to rozumieć umowę między upadłym 
a nabywcą, której przedmiotem jest przeniesienie praw wynikających z umowy 
deweloperskiej, o której mowa w art. 5 pkt 6 ustawy o ochronie nabywcy, albo 
jednej z umów, o których mowa w art. 2 ust. 1 pkt 2, 3 lub 5 lub ust. 2 tej ustawy. 
Art. 425d. W przypadku 
gdy 
upadły 
jest 
emitentem 
obligacji, 
a dla 
zabezpieczenia praw z obligacji ustanowiono zabezpieczenie na nieruchomości, na 
której realizowane jest przedsięwzięcie deweloperskie, przepisów art. 488–490 nie 
stosuje się. 
DZIAŁ II 
Dalsze prowadzenie przedsięwzięcia deweloperskiego 
Art. 425e. 1. W postępowaniu upadłościowym syndyk może dalej prowadzić 
przedsięwzięcie 
deweloperskie 
upadłego 
za 
zgodą 
sędziego-komisarza. 
Sędzia-komisarz udziela zgody, jeżeli racjonalne względy wskazują, że dalsze 
prowadzenie przedsięwzięcia deweloperskiego jest ekonomicznie uzasadnione 
i istnieją szanse na jego ukończenie. 
2. Syndyk 
prowadzi 
dalej 
przedsięwzięcie 
deweloperskie 
upadłego, 
w odniesieniu do którego we wcześniejszym postępowaniu sanacyjnym wobec 
upadłego nabywcy podjęli uchwałę, o której mowa w art. 358 ust. 4 ustawy z dnia 
15 maja 2015 r. – Prawo restrukturyzacyjne, oraz wpłacili lub zabezpieczyli dopłaty 
w terminach, o których mowa w art. 359 ust. 1 i 2 tej ustawy, ale układ nie doszedł do 
skutku, chyba że na odstąpienie od dalszego prowadzenia przedsięwzięcia dewelo-
perskiego wyraził zgodę sędzia-komisarz. 
2a. Wydanie przez sędziego-komisarza postanowienia o odmowie dalszego 
prowadzenia przedsięwzięcia deweloperskiego albo o wyrażeniu zgody na odstąpienie 
od dalszego prowadzenia przedsięwzięcia deweloperskiego albo niewydanie przez 
sędziego-komisarza 
postanowienia 
w przedmiocie 
dalszego 
prowadzenia 
przedsięwzięcia deweloperskiego w terminie 3 miesięcy od dnia ogłoszenia upadłości 
wywołuje z mocy prawa skutek odstąpienia przez syndyka od umów deweloperskich 
na podstawie art. 98, a do roszczeń nabywców wynikających z tych umów przepis 
art. 91 stosuje się odpowiednio. 
2b. Po wydaniu przez sędziego-komisarza postanowienia o odmowie dalszego 
prowadzenia przedsięwzięcia deweloperskiego albo o wyrażeniu zgody na odstąpienie 
od dalszego prowadzenia przedsięwzięcia deweloperskiego albo w przypadku 

©Kancelaria Sejmu 
 
 
 
s. 162/224 
 
2025-09-11 
 
niewydania przez sędziego-komisarza postanowienia w przedmiocie dalszego 
prowadzenia przedsięwzięcia deweloperskiego w terminie 3 miesięcy od dnia 
ogłoszenia upadłości, syndyk informuje o tym bank lub spółdzielczą kasę 
oszczędnościowo-kredytową prowadzące mieszkaniowy rachunek powierniczy dla 
przedsięwzięcia deweloperskiego i składa dyspozycję zwrotu środków znajdujących 
się na rachunku nabywcom. 
3. Syndyk przechowuje środki pieniężne uzyskane z dopłat wpłaconych we 
wcześniejszym postępowaniu sanacyjnym, przekazane mu przez zarządcę 
ustanowionego w tym postępowaniu, na odrębnym rachunku bankowym. W przy-
padku odstąpienia od dalszego prowadzenia przedsięwzięcia deweloperskiego syndyk 
zwraca dopłaty nabywcom, a zabezpieczenia wpłacenia dopłat wygasają z mocy 
prawa. 
4. W przypadku prawomocnego oddalenia lub odrzucenia wniosku o ogłoszenie 
upadłości lub umorzenia postępowania w przedmiocie ogłoszenia upadłości przepis 
ust. 3 stosuje się odpowiednio. 
Art. 425f. 1. 
W przypadku 
dalszego 
prowadzenia 
przedsięwzięcia 
deweloperskiego zgodnie z art. 425e do umowy deweloperskiej przepisu art. 98 nie 
stosuje się w zakresie, w jakim przewiduje uprawnienie syndyka do odstąpienia od 
umowy, a do roszczenia nabywcy wynikającego z umowy deweloperskiej przepisu 
art. 91 nie stosuje się. Roszczenie nabywcy zaspokajane jest przez przeniesienie 
własności lokalu. 
2. Przeniesienie 
własności 
lokalu 
nie 
wywołuje 
skutków 
sprzedaży 
egzekucyjnej. Przepisu art. 313 nie stosuje się. 
Art. 425g. Jeżeli nieruchomość, na której jest prowadzone przedsięwzięcie 
deweloperskie lub zadanie inwestycyjne, jest obciążona hipoteką, której przysługuje 
pierwszeństwo przed roszczeniami chociażby jednego nabywcy, a wierzyciel 
hipoteczny wyraził zgodę, o której mowa w art. 25 ust. 1 pkt 1 lub 2 ustawy 
o ochronie nabywcy, lub zobowiązał się do jej udzielenia, zgodnie z art. 76 ust. 4 
zdanie drugie ustawy z dnia 6 lipca 1982 r. o księgach wieczystych i hipotece (Dz. U. 
z 2023 r. poz. 1984 oraz z 2024 r. poz. 1222), zgoda taka lub zobowiązanie do jej 
udzielenia pozostają w mocy na warunkach w nich określonych, przy czym warunek 
wykonania zobowiązania nabywcy względem upadłego uznaje się za spełniony 

©Kancelaria Sejmu 
 
 
 
s. 163/224 
 
2025-09-11 
 
w przypadku wykonania zobowiązania do rąk syndyka lub zarządcy ustanowionego 
we wcześniejszym postępowaniu sanacyjnym. 
Art. 425h. 1. Jeżeli w toku postępowania upadłościowego ujawni się podstawa 
do przyjęcia, że dalsze prowadzenie przedsięwzięcia deweloperskiego nie jest 
uzasadnione racjonalnymi względami, sędzia-komisarz na wniosek syndyka udziela 
zgody na zaprzestanie dalszego prowadzenia przedsięwzięcia deweloperskiego. Na 
postanowienie sędziego-komisarza przysługuje zażalenie. 
2. Uprawomocnienie się postanowienia sędziego-komisarza o wyrażeniu zgody 
na zaprzestanie dalszego prowadzenia przedsięwzięcia deweloperskiego wywołuje 
z mocy prawa skutek odstąpienia przez syndyka od umów deweloperskich na 
podstawie art. 98, a do roszczeń nabywców wynikających z tych umów przepis 
art. 91 stosuje się odpowiednio. 
3. Do dopłat w części niewykorzystanej przepis art. 425e ust. 3 zdanie drugie 
stosuje się. 
4. Po uprawomocnieniu się postanowienia sędziego-komisarza o wyrażeniu 
zgody na zaprzestanie dalszego prowadzenia przedsięwzięcia deweloperskiego 
syndyk informuje o tym bank lub spółdzielczą kasę oszczędnościowo-kredytową 
prowadzące 
mieszkaniowy 
rachunek 
powierniczy 
dla 
przedsięwzięcia 
deweloperskiego i składa dyspozycję zwrotu środków znajdujących się na rachunku 
nabywcom. 
DZIAŁ III 
Likwidacja nieruchomości, na której prowadzone jest przedsięwzięcie 
deweloperskie 
Art. 425i. Sumy uzyskane z likwidacji nieruchomości, na której jest prowadzone 
przedsięwzięcie deweloperskie lub zadanie inwestycyjne, podlegają podziałowi na 
zasadach ogólnych, z tym że w przypadku wyrażenia przez wierzyciela hipotecznego 
zgody, o której mowa w art. 25 ust. 1 pkt 1 lub 2 ustawy o ochronie nabywcy, lub 
zobowiązania się do jej udzielenia, zgodnie z art. 76 ust. 4 zdanie drugie ustawy z dnia 
6 lipca 1982 r. o księgach wieczystych i hipotece, uznaje się, że roszczeniu nabywcy 
lokalu, którego ta zgoda lub zobowiązanie do jej udzielenia dotyczy, przysługuje 
pierwszeństwo przed hipoteką w zakresie, w jakim dokonał wpłat na poczet umowy. 

©Kancelaria Sejmu 
 
 
 
s. 164/224 
 
2025-09-11 
 
Art. 425j. Roszczenia 
nabywcy 
wynikające 
z odstąpienia 
od 
umowy 
deweloperskiej 
podlegają 
zaspokojeniu 
z sum 
uzyskanych 
z likwidacji 
nieruchomości, na której prowadzone jest przedsięwzięcie deweloperskie, na takich 
samych zasadach jak roszczenie z umowy deweloperskiej. Nabywcy przysługuje 
pierwszeństwo wynikające z ujawnienia w księdze wieczystej przysługującego mu 
roszczenia z umowy deweloperskiej, także w przypadku gdy wpis o ujawnieniu tego 
roszczenia został wykreślony. 
Art. 425ja. Wierzytelności nabywcy wynikające z umowy deweloperskiej, która 
stanowiła podstawę wypłaty na rzecz nabywcy świadczeń z Ubezpieczeniowego 
Funduszu Gwarancyjnego, podlegają zaspokojeniu po zaspokojeniu należności tego 
funduszu powstałych w wyniku przekazania nabywcy świadczenia na podstawie 
art. 48 ust. 5 ustawy o ochronie nabywcy. 
Art. 425k. Roszczenie pieniężne nabywcy powstałe wskutek przekształcenia 
roszczenia z umowy deweloperskiej w toku postępowania restrukturyzacyjnego lub 
upadłościowego podlega zaspokojeniu w sposób określony w art. 425j. 
DZIAŁ IV 
Kontynuacja przedsięwzięcia deweloperskiego przez innego przedsiębiorcę 
Art. 425l. 1. Na wniosek syndyka sędzia-komisarz może wyrazić zgodę na 
sprzedaż nieruchomości, na której prowadzone jest przedsięwzięcie deweloperskie, 
przedsiębiorcy, który zobowiąże się do kontynuacji przedsięwzięcia deweloperskiego. 
2. Przedsiębiorca nabywający nieruchomość na podstawie ust. 1 odpowiada 
solidarnie z upadłym za jego zobowiązania z umów deweloperskich zawartych 
w związku z przedsięwzięciem deweloperskim realizowanym na nieruchomości, jak 
również za zobowiązania wobec nabywców wynikające z przekształcenia roszczeń 
z takich umów w toku postępowania restrukturyzacyjnego lub upadłościowego lub 
z odstąpienia od takich umów. Zobowiązania, o których mowa w zdaniu poprzednim, 
nie podlegają zaspokojeniu w postępowaniu upadłościowym prowadzonym wobec 
upadłego. 
3. Wraz z własnością nieruchomości przedsiębiorca nabywający nieruchomość 
na podstawie ust. 1 nabywa przysługujące upadłemu prawa wynikające z umów 
deweloperskich 
zawartych 
w związku 
z przedsięwzięciem 
deweloperskim 
realizowanym na nieruchomości. 

©Kancelaria Sejmu 
 
 
 
s. 165/224 
 
2025-09-11 
 
4. Sprzedaż nieruchomości na podstawie ust. 1 nie wywołuje skutków sprzedaży 
egzekucyjnej. Przepisu art. 313 nie stosuje się. 
5. Wyrażając zgodę na sprzedaż nieruchomości na podstawie ust. 1, 
sędzia-komisarz 
uwzględnia 
interes 
nabywców 
oraz 
prawdopodobieństwo 
dokończenia przedsięwzięcia deweloperskiego przez przedsiębiorcę nabywającego 
nieruchomość. 
6. Do 
umowy 
deweloperskiej 
zawartej 
w ramach 
przedsięwzięcia 
deweloperskiego prowadzonego na nieruchomości podlegającej sprzedaży na 
podstawie ust. 1 przepisów art. 98 nie stosuje się. Do roszczenia nabywcy 
wynikającego z umowy deweloperskiej przepisu art. 91 nie stosuje się. 
7. W przypadku sprzedaży nieruchomości na podstawie ust. 1 przepisów 
art. 336, art. 345 i art. 346 nie stosuje się. 
Art. 425m. 1. Jeżeli dla przedsięwzięcia deweloperskiego prowadzonego na 
nieruchomości nabytej na podstawie art. 425l ust. 1 jest prowadzony mieszkaniowy 
rachunek powierniczy upadłego, przedsiębiorca nabywający tę nieruchomość jest 
obowiązany do zawarcia umowy o prowadzenie mieszkaniowego rachunku 
powierniczego 
w terminie 
trzydziestu 
dni 
od 
dnia 
wyrażenia 
przez 
sędziego-komisarza zgody, o której mowa w art. 425l ust. 1. O otwarciu rachunku 
powierniczego przedsiębiorca niezwłocznie informuje syndyka. 
2. Niezwłocznie po zawarciu przez przedsiębiorcę umowy o prowadzenie 
mieszkaniowego rachunku powierniczego zgodnie z ust. 1 syndyk informuje bank lub 
spółdzielczą kasę oszczędnościowo-kredytową prowadzące mieszkaniowy rachunek 
powierniczy upadłego o przejściu praw z umów deweloperskich zgodnie z art. 425l 
ust. 3 i składa dyspozycję przekazania środków zgromadzonych na mieszkaniowym 
rachunku powierniczym upadłego na mieszkaniowy rachunek powierniczy 
przedsiębiorcy. 
3. Po przekazaniu środków, o których mowa w ust. 2, na mieszkaniowy rachunek 
powierniczy przedsiębiorcy nabywającego nieruchomość na podstawie art. 425l 
ust. 1 umowa o prowadzenie mieszkaniowego rachunku powierniczego upadłego 
wygasa. 

©Kancelaria Sejmu 
 
 
 
s. 166/224 
 
2025-09-11 
 
DZIAŁ V 
Kontynuacja przedsięwzięcia deweloperskiego w układzie 
Art. 425n. Nabywcy w liczbie stanowiącej co najmniej 20 % liczby nabywców 
w ramach przedsięwzięcia deweloperskiego prowadzonego przez upadłego mogą 
zgłosić propozycje układowe w terminie trzydziestu dni od dnia ogłoszenia upadłości. 
Art. 425o. 1. Propozycje układowe mogą także obejmować: 
- 1) wpłacenie dopłat przez wszystkich albo niektórych nabywców i zaspokojenie ich 
przez przeniesienie własności lokali, przy czym propozycje układowe mogą 
przewidywać późniejszy zwrot dopłat z przychodów z realizacji przedsięwzięcia 
deweloperskiego; 
- 2) sprzedaż 
nieruchomości, 
na 
której 
prowadzone 
jest 
przedsięwzięcie 
deweloperskie, z zachowaniem ciążących na niej ograniczonych praw 
rzeczowych, na rzecz przedsiębiorcy, który przejąłby zobowiązania wobec 
nabywców i zobowiązałby się do kontynuacji przedsięwzięcia deweloperskiego, 
przy czym propozycje układowe mogą przewidywać zmianę treści umów 
deweloperskich; 
- 3) określenie innych warunków kontynuacji przedsięwzięcia deweloperskiego 
i sposobów jego finansowania; 
- 4) zamianę lokali między wierzycielami lub zamianę lokalu na lokal niebędący 
przedmiotem umowy deweloperskiej. 
2. Przepis art. 162 ustawy z dnia 15 maja 2015 r. – Prawo restrukturyzacyjne 
stosuje się odpowiednio. 
Art. 425p. 1. Propozycje układowe mogą przewidywać różny sposób 
traktowania nabywców w zależności od tego, czy wpłacą oni dopłaty, o których mowa 
w art. 425o ust. 1 pkt 1. 
2. Do propozycji układowych przewidujących sposób restrukturyzacji, o którym 
mowa w art. 425o ust. 1 pkt 2, załącza się sporządzone w formie aktu notarialnego 
nieodwołalne oświadczenie woli przedsiębiorcy o nabyciu nieruchomości, na której 
jest prowadzone przedsięwzięcie deweloperskie, wraz z ciążącymi na niej 
obciążeniami i o przejęciu zobowiązań upadłego w stosunku do nabywców. 
W przypadku prawomocnego zatwierdzenia układu przewidującego sprzedaż nie-
ruchomości na zasadach określonych w oświadczeniu woli przedsiębiorcy, o którym 
mowa w niniejszym ustępie, oświadczenie to zastępuje jego oświadczenie woli 

©Kancelaria Sejmu 
 
 
 
s. 167/224 
 
2025-09-11 
 
konieczne do zawarcia umowy sprzedaży nieruchomości, na której jest prowadzone 
przedsięwzięcie deweloperskie, a umowę uznaje się za zawartą. 
3. Prawomocne postanowienie o zatwierdzeniu układu wraz z oświadczeniem, 
o którym mowa w ust. 2, stanowi podstawę ujawnienia prawa własności w księdze 
wieczystej. 
Jeżeli 
dla 
przedsięwzięcia 
deweloperskiego 
jest 
prowadzony 
mieszkaniowy rachunek powierniczy upadłego, przepis art. 425m stosuje się 
odpowiednio. 
Art. 425q. 1. Głosowanie nad układem przeprowadza się w grupach wierzycieli. 
2. Nabywcy stanowią odrębną grupę wierzycieli, dla której sporządza się 
odrębną listę wierzycieli uprawnionych do głosowania. Dopuszczalny jest dodatkowy 
podział nabywców na większą liczbę grup obejmujących poszczególne kategorie 
interesów, w szczególności z uwagi na stopień wykonania umowy z deweloperem. 
Art. 425r. 1. Jeżeli zostaną zgłoszone propozycje układowe przewidujące 
sposób restrukturyzacji, o którym mowa w art. 425o ust. 1 pkt 1, sędzia-komisarz 
niezwłocznie przeprowadza wstępne głosowanie nabywców nad propozycjami 
układowymi w zakresie ich dotyczącym. 
2. Sędzia-komisarz sporządza listę nabywców uprawnionych do głosowania na 
podstawie listy przedłożonej przez syndyka. 
3. Uchwała nabywców zostaje przyjęta, jeżeli wypowiedzą się za nią nabywcy 
deklarujący łącznie dopłaty wystarczające zgodnie z treścią propozycji układowych 
do sfinansowania dokończenia przedsięwzięcia deweloperskiego. 
4. Przyjęcie uchwały stwierdza sędzia-komisarz postanowieniem. 
Art. 425s. 1. W przypadku przyjęcia uchwały nabywców, o której mowa 
w art. 425r ust. 3, nabywcy zobowiązani do wpłacenia dopłat wpłacają je do masy 
upadłości lub zabezpieczają ich wpłatę w zakresie przewidzianym uchwałą w terminie 
dwóch miesięcy od dnia podjęcia uchwały. W szczególnie uzasadnionych 
przypadkach termin może zostać przedłużony postanowieniem sędziego-komisarza. 
2. Jeżeli w terminie, o którym mowa w ust. 1, nie zostaną wpłacone lub 
zabezpieczone wszystkie dopłaty, w pełnej wysokości przewidzianej uchwałą, 
nabywcy mogą uzupełnić brakujące dopłaty, wpłacając je lub zabezpieczając ich 
wpłatę w terminie trzydziestu dni od bezskutecznego upływu terminu, o którym mowa 
w ust. 1. W tym samym terminie upadły lub syndyk mogą przedstawić dowód istnienia 
innych źródeł finansowania przedsięwzięcia deweloperskiego. 

©Kancelaria Sejmu 
 
 
 
s. 168/224 
 
2025-09-11 
 
3. Wpłacenie lub zabezpieczenie dopłat lub innych środków w wysokości 
wystarczającej na sfinansowanie przedsięwzięcia deweloperskiego stwierdza 
postanowieniem sędzia-komisarz, jednocześnie wyznaczając termin zgromadzenia 
wierzycieli w celu głosowania nad układem. Treść uchwały nabywców, o której mowa 
w art. 425r ust. 3, włącza się do układu, a zgromadzenie wierzycieli nie może przyjąć 
układu o treści odbiegającej od uchwały nabywców w zakresie nią uregulowanym. 
Sędzia-komisarz zwraca uwagę wierzycieli uczestniczących w zgromadzeniu 
wierzycieli na niezgodność propozycji układowych z uchwałą nabywców. Sąd 
odmawia zatwierdzenia układu o treści odbiegającej od uchwały nabywców 
w zakresie nią uregulowanym. 
4. Jeżeli w terminach, o których mowa w ust. 1 lub 2, zostaną wpłacone lub 
zabezpieczone dopłaty w wysokości przewidzianej uchwałą nabywców, o której 
mowa w art. 425r ust. 3, przedsięwzięcie deweloperskie może być dalej prowadzone. 
5. W przypadku niedojścia układu do skutku pomimo podjęcia uchwały 
nabywców, o której mowa w art. 425r ust. 3, oraz wpłacenia lub zabezpieczenia 
w terminach, o których mowa w ust. 1 lub 2, dopłat w wysokości wystarczającej na 
sfinansowanie przedsięwzięcia deweloperskiego w dalszym toku postępowania 
upadłościowego odstąpienie przez syndyka od kontynuacji przedsięwzięcia 
deweloperskiego wymaga zgody sędziego-komisarza. 
6. Syndyk przechowuje środki pieniężne uzyskane z dopłat na odrębnym 
rachunku bankowym. W przypadku odstąpienia od dalszego prowadzenia 
przedsięwzięcia 
deweloperskiego 
syndyk 
zwraca 
dopłaty 
nabywcom, 
a zabezpieczenia wpłacenia dopłat wygasają z mocy prawa. 
7. Po uprawomocnieniu się postanowienia sędziego-komisarza o wyrażeniu 
zgody na odstąpienie przez syndyka od kontynuacji przedsięwzięcia deweloperskiego 
syndyk informuje o tym bank lub spółdzielczą kasę oszczędnościowo-kredytową 
prowadzące 
mieszkaniowy 
rachunek 
powierniczy 
dla 
przedsięwzięcia 
deweloperskiego i składa dyspozycję zwrotu środków znajdujących się na rachunku 
nabywcom. 

©Kancelaria Sejmu 
 
 
 
s. 169/224 
 
2025-09-11 
 
TYTUŁ II 
Postępowanie upadłościowe wobec banków i spółdzielczych kas 
oszczędnościowo-kredytowych 
DZIAŁ I 
Przepisy ogólne

***
## Art. 426. {#art-426}

1. Bank jest niewypłacalny również wówczas, gdy według bilansu 
sporządzonego na koniec okresu sprawozdawczego aktywa banku nie wystarczają na 
zaspokojenie jego zobowiązań. 
1a. Do zobowiązań, o których mowa w ust. 1, nie zalicza się zobowiązań, 
o których mowa w art. 11 ust. 4a. 
2. Wniosek o ogłoszenie upadłości banku może zgłosić wyłącznie Komisja 
Nadzoru Finansowego albo Bankowy Fundusz Gwarancyjny. 
2a. We wniosku, o którym mowa w ust. 2, jako syndyk może zostać wskazany 
bank. 
3. W postępowaniu upadłościowym wobec banku przepisów art. 11 ust. 3, 4 i 5–
7 oraz art. 38–43 nie stosuje się.

***
## Art. 427. {#art-427}

1. Przed ogłoszeniem upadłości banku, sąd wysłuchuje co do podstaw 
ogłoszenia upadłości oraz co do osoby syndyka: 
- 1) przedstawiciela Komisji Nadzoru Finansowego; 
1a) przedstawiciela Bankowego Funduszu Gwarancyjnego; 
1b) przedstawicieli banku, o którym mowa w art. 426 ust. 2a; 
- 2) prezesa oraz innych członków ostatniego zarządu albo zarządu komisarycznego, 
albo likwidatora banku, którego dotyczy wniosek. 
1a. W przypadku postępowania dotyczącego upadłości banku będącego 
podmiotem zależnym od Skarbu Państwa, sąd wysłuchuje również przedstawiciela 
organu lub podmiotu uprawnionego do wykonywania praw z akcji lub udziałów 
należących do Skarbu Państwa. 
2. Sąd może odstąpić od wysłuchania prezesa oraz innych członków zarządu 
banku, jeżeli ich wysłuchanie spowodowałoby zwłokę w rozpoznaniu sprawy. 
3. Syndykiem może być także bank wskazany we wniosku, o którym mowa 
w art. 426 ust. 2, po uzyskaniu pozytywnej opinii: 
- 1) Komisji Nadzoru Finansowego – w przypadku wniosku złożonego przez 
Bankowy Fundusz Gwarancyjny; 

©Kancelaria Sejmu 
 
 
 
s. 170/224 
 
2025-09-11 
- 2) Bankowego Funduszu Gwarancyjnego – w przypadku wniosku złożonego przez 
Komisję Nadzoru Finansowego. 
4. (uchylony)

***
## Art. 428. {#art-428}

(uchylony)

***
## Art. 429. {#art-429}

1. (uchylony) 
2. (uchylony) 
3. W postanowieniu o ogłoszeniu upadłości sąd ustanawia kuratora do 
reprezentowania banku w postępowaniu upadłościowym. Do kuratora stosuje się 
przepisy art. 187 ust. 3 i 4. 
4. Bankowy Fundusz Gwarancyjny jest ustanawiany kuratorem na swój wniosek.

***
## Art. 430. {#art-430}

(uchylony)

***
## Art. 431. {#art-431}

(uchylony)

***
## Art. 432. {#art-432}

Sprawozdania, o których mowa w art. 168, syndyk przekazuje do 
wiadomości Komisji Nadzoru Finansowego.

***
## Art. 433. {#art-433}

O ile skutki te nie nastąpiły wcześniej z powodu otwarcia 
postępowania układowego, z dniem ogłoszenia upadłości: 
- 1) organy zarządzające i nadzorcze banku ulegają rozwiązaniu; 
- 2) wygasają zarząd komisaryczny, powołanie likwidatora oraz uprawnienia 
kuratora ustanowionego na podstawie art. 144 ust. 1 ustawy z dnia 29 sierpnia 
1997 r. – Prawo bankowe (Dz. U. z 2024 r. poz. 1646, 1685 i 1863 oraz z 2025 
r. poz. 146 i 222); 
- 3) wygasają wszelkie uprawnienia osób wchodzących w skład organów banku do 
odpraw pieniężnych, jak też do wynagrodzenia za okres po ogłoszeniu upadłości.

***
## Art. 434. {#art-434}

O ile skutki te nie nastąpiły wcześniej z powodu otwarcia 
postępowania układowego, z dniem ogłoszenia upadłości ulegają rozwiązaniu: 
- 1) umowy rachunku bankowego; oprocentowanie rachunków bankowych jest 
naliczane do dnia ogłoszenia upadłości; 
- 2) umowy kredytu i pożyczki, jeżeli do dnia ogłoszenia upadłości nie nastąpiło 
oddanie środków pieniężnych do dyspozycji kredytobiorcy (pożyczkobiorcy); 
- 3) umowy poręczenia, gwarancji bankowych i akredytyw, jeżeli do dnia ogłoszenia 
upadłości bank nie otrzymał prowizji z tytułu tych czynności; 

©Kancelaria Sejmu 
 
 
 
s. 171/224 
 
2025-09-11 
- 4) umowy o udostępnienie skrytek sejfowych oraz umowy przechowania, z tym że 
wydanie przedmiotów i papierów wartościowych powinno nastąpić w terminie 
uzgodnionym z oddającym na przechowanie. 
Art. 434a. Jeżeli wierzytelność banku lub spółdzielczej kasy oszczędnościowo-
-kredytowej jest zabezpieczona hipoteką na nieruchomości, na której jest prowadzone 
przedsięwzięcie deweloperskie lub zadanie inwestycyjne, a bank lub spółdzielcza kasa 
oszczędnościowo-kredytowa wyraziły zgodę, o której mowa w art. 25 ust. 1 pkt 1 lub 
2 ustawy o ochronie nabywcy, lub zobowiązały się do jej udzielenia, zgodnie 
z art. 76 ust. 4 zdanie drugie ustawy z dnia 6 lipca 1982 r. o księgach wieczystych 
i hipotece, zgoda taka lub zobowiązanie do jej udzielenia pozostają w mocy na 
warunkach w nich określonych. Przepis art. 425c pkt 2 stosuje się odpowiednio.

***
## Art. 435. {#art-435}

(uchylony)

***
## Art. 436. {#art-436}

1. 
Propozycje 
układowe 
mogą 
złożyć 
także 
akcjonariusze 
(członkowie) reprezentujący dwie trzecie kapitału zakładowego banku w formie 
spółki akcyjnej lub funduszu udziałowego banku spółdzielczego, jak również bank 
zrzeszający, którego bank spółdzielczy jest akcjonariuszem. 
2. Przed zatwierdzeniem układu sąd zasięga opinii Komisji Nadzoru 
Finansowego.

***
## Art. 437. {#art-437}

1. (uchylony) 
2. Warunki nabycia przedsiębiorstwa bankowego przez inne banki oraz termin 
składania ofert określa sędzia-komisarz, po zasięgnięciu opinii Komisji Nadzoru 
Finansowego i Bankowego Funduszu Gwarancyjnego. 
3. Postanowienie zatwierdzające wybór oferty sędzia-komisarz wydaje po 
zasięgnięciu opinii Komisji Nadzoru Finansowego i Bankowego Funduszu 
Gwarancyjnego. 
4. Przepisów art. 56a–56h nie stosuje się.

***
## Art. 438. {#art-438}

1. Nabywca przedsiębiorstwa bankowego przejmuje zobowiązania 
z tytułu rachunków bankowych. 
1a. W przypadku gdy oszacowanie przedsiębiorstwa bankowego wskazuje, że 
cena nabycia przedsiębiorstwa bankowego uniemożliwiałaby pełne pokrycie 
należności, o których mowa w art. 39 ust. 1 ustawy z dnia 10 czerwca 2016 r. 
o Bankowym Funduszu Gwarancyjnym, systemie gwarantowania depozytów oraz 

©Kancelaria Sejmu 
 
 
 
s. 172/224 
 
2025-09-11 
 
przymusowej restrukturyzacji (Dz. U. z 2024 r. poz. 487 oraz z 2025 r. poz. 146), 
sprzedaż przedsiębiorstwa bankowego następuje: 
- 1) z przejęciem przez nabywcę zobowiązań upadłego z tytułu należności, o których 
mowa w art. 39 ust. 1 ustawy z dnia 10 czerwca 2016 r. o Bankowym Funduszu 
Gwarancyjnym, systemie gwarantowania depozytów oraz przymusowej 
restrukturyzacji, albo 
- 2) bez przejęcia przez nabywcę zobowiązań z tytułu rachunków bankowych. 
1b. Sędzia-komisarz dokonuje wyboru sposobu sprzedaży przedsiębiorstwa 
bankowego, o których mowa w ust. 1a, wraz z określeniem warunków nabycia 
przedsiębiorstwa bankowego przez inne banki. Na postanowienie sędziego-komisarza 
przysługuje zażalenie. 
2. Po zawarciu umowy sprzedaży przedsiębiorstwa bankowego syndyk zgłasza 
niezwłocznie sprzedaż banku do rejestru, w którym bank jest wpisany.

***
## Art. 439. {#art-439}

Jeżeli przedsiębiorstwo bankowe nie jest sprzedane w całości, syndyk 
za zezwoleniem sędziego-komisarza przystąpi do sprzedaży poszczególnych 
składników majątku upadłego banku.

***
## Art. 440. {#art-440}

1. Zaspokojenie wierzytelności i należności przypadających od 
upadłego banku następuje zgodnie z ust. 2–6. 
2. Należności podlegające zaspokojeniu z funduszów masy upadłości banku 
dzieli się na następujące kategorie: 
- 1) kategoria pierwsza – należności, o których mowa w art. 39 ust. 1 ustawy z dnia 
10 czerwca 
2016 r. 
o Bankowym 
Funduszu 
Gwarancyjnym, 
systemie 
gwarantowania depozytów oraz przymusowej restrukturyzacji, wraz z odsetkami 
i kosztami egzekucji, przypadające za czas przed ogłoszeniem upadłości 
należności ze stosunku pracy, z wyjątkiem roszczeń z tytułu wynagrodzenia 
reprezentanta upadłego lub wynagrodzenia osoby wykonującej czynności 
związane z zarządem lub nadzorem nad przedsiębiorstwem upadłego, należności 
rolników z tytułu umów o dostarczenie produktów z własnego gospodarstwa 
rolnego, należności alimentacyjne oraz renty z tytułu odszkodowania za 
wywołanie choroby, niezdolności do pracy, kalectwa lub śmierci i renty z tytułu 
zamiany uprawnień objętych treścią prawa dożywocia na dożywotnią rentę, 
przypadające za trzy ostatnie lata przed dniem ogłoszeniem upadłości należności 

©Kancelaria Sejmu 
 
 
 
s. 173/224 
 
2025-09-11 
 
z tytułu składek na ubezpieczenia społeczne w rozumieniu ustawy z dnia 
13 października 1998 r. o systemie ubezpieczeń społecznych; 
- 2) kategoria druga – należności osób fizycznych, mikroprzedsiębiorców, małych 
i średnich przedsiębiorców z tytułu środków objętych ochroną gwarancyjną 
innych niż środki gwarantowane w rozumieniu art. 2 pkt 65 ustawy z dnia 
10 czerwca 
2016 r. 
o Bankowym 
Funduszu 
Gwarancyjnym, 
systemie 
gwarantowania depozytów oraz przymusowej restrukturyzacji; 
- 3) kategoria trzecia: 
  - a) podkategoria pierwsza: pozostałe należności z tytułu środków objętych 
ochroną gwarancyjną innych niż środki gwarantowane w rozumieniu 
art. 2 pkt 65 ustawy z dnia 10 czerwca 2016 r. o Bankowym Funduszu 
Gwarancyjnym, systemie gwarantowania depozytów oraz przymusowej 
restrukturyzacji, 
  - b) podkategoria druga: pozostałe należności wynikające z umów rachunku 
bankowego, 
  - c) podkategoria trzecia: odsetki od należności ujętych w kategoriach, 
o których mowa w pkt 1 i 2, oraz podkategoriach, o których mowa 
w lit. a i b, 
  - d) podkategoria czwarta: inne należności, jeżeli nie podlegają zaspokojeniu 
w innych kategoriach, w szczególności podatki i inne daniny publiczne oraz 
pozostałe należności z tytułu składek na ubezpieczenie społeczne; 
- 4) kategoria czwarta: 
  - a) podkategoria pierwsza: odsetki od należności ujętych w pkt 3 lit. d, a także 
sądowe kary grzywny i administracyjne kary pieniężne oraz należności 
z tytułu darowizn i zapisów, 
  - b) podkategoria druga: należności jednostki zarządzającej systemem ochrony, 
o której mowa w art. 130e ust. 1 ustawy z dnia 29 sierpnia 1997 r. – Prawo 
bankowe, oraz jednostki zarządzającej systemem ochrony, o której mowa 
w art. 22d ust. 1 pkt 2 ustawy z dnia 7 grudnia 2000 r. o funkcjonowaniu 
banków spółdzielczych, ich zrzeszaniu się i bankach zrzeszających, wraz 
z odsetkami i kosztami egzekucji; 
- 5) kategoria piąta – należności wspólników albo akcjonariuszy z tytułu pożyczki 
lub innej czynności prawnej o podobnych skutkach, w szczególności dostawy 

©Kancelaria Sejmu 
 
 
 
s. 174/224 
 
2025-09-11 
 
towaru z odroczonym terminem płatności, dokonanej na rzecz upadłego będą-
cego spółką kapitałową w okresie 5 lat przed dniem ogłoszeniem upadłości, wraz 
z odsetkami, jeżeli nie podlegają zaspokojeniu w kategoriach niższych; 
- 6) kategoria szósta – należności z tytułu obligacji lub innych instrumentów 
dłużnych, które wykazują właściwości zbywalnych wierzytelności, lub z tytułu 
instrumentów 
wywołujących 
skutki 
prawne 
dłużnych 
instrumentów 
finansowych, wraz z odsetkami i kosztami egzekucji, z wyłączeniem należności 
określonych w pkt 9, jeżeli są łącznie spełnione następujące warunki: 
  - a) pierwotny umowny termin zapadalności należności wynosi co najmniej rok, 
  - b) w umowie lub załączonych do niej dokumentach i informacjach 
dotyczących emisji dłużnych instrumentów finansowych lub instrumentów 
wywołujących skutki prawne dłużnych instrumentów finansowych, 
a w stosownych przypadkach także w prospekcie emisyjnym, w sposób 
wyraźny i przystępny określono kategorię zaspokojenia należności, 
  - c) należności nie wynikają: 
– 
z instrumentów pochodnych, w szczególności takich, które odnoszą się 
do aktywów, praw, zobowiązań, indeksów oraz innych wskaźników, 
lub 
które 
wykazują 
właściwości 
pochodnych 
instrumentów 
finansowych, 
– 
ze strukturyzowanych produktów finansowych, o których mowa 
w art. 2 ust. 1 pkt 28 rozporządzenia Parlamentu Europejskiego i Rady 
(UE) nr 600/2014 z dnia 15 maja 2014 r. w sprawie rynków 
instrumentów finansowych oraz zmieniającego rozporządzenie (UE) 
nr 648/2012 (Dz. Urz. UE L 173 z 12.06.2014, str. 84, z późn. zm.6)), 
  - d) wartość nominalna jednej obligacji lub jednego instrumentu dłużnego nie 
jest niższa niż 400 000 zł lub równowartość tej kwoty wyrażona w innej 
walucie, ustalona przy zastosowaniu średniego kursu tej waluty ogłaszanego 
przez Narodowy Bank Polski w dniu podjęcia przez emitenta decyzji 
o emisji; 
- 7) kategoria siódma – należności z tytułu zobowiązań podporządkowanych 
niezaliczanych do funduszy własnych banku, wraz z odsetkami i kosztami 
egzekucji; 
- 6) Zmiany wymienionego rozporządzenia zostały ogłoszone w Dz. Urz. UE L 270 z 15.10.2015, str. 4 oraz 
Dz. Urz. UE L 175 z 30.06.2016, str. 1. 

©Kancelaria Sejmu 
 
 
 
s. 175/224 
 
2025-09-11 
- 8) kategoria ósma – należności z tytułu zobowiązań zaliczanych do funduszy 
własnych banku, o których mowa w art. 62 rozporządzenia nr 575/2013, wraz 
z odsetkami i kosztami egzekucji; 
- 9) kategoria dziewiąta – należności z tytułu zobowiązań zaliczanych do funduszy 
własnych banku, o których mowa w art. 51 rozporządzenia nr 575/2013, wraz 
z odsetkami i kosztami egzekucji; 
- 10) kategoria dziesiąta – należności z tytułu zobowiązań zaliczanych do funduszy 
własnych banku, o których mowa w art. 26 rozporządzenia nr 575/2013, wraz 
z odsetkami i kosztami egzekucji. 
2a. Do kategorii szóstej zalicza się instrumenty dłużne, o zmiennym 
oprocentowaniu, wynikającym z powszechnie stosowanej stopy procentowej 
wyrażonej za pomocą wskaźnika o charakterze referencyjnym, o którym mowa 
w art. 3 ust. 1 pkt 3 rozporządzenia Parlamentu Europejskiego i Rady (UE) 2016/1011 
z dnia 8 czerwca 2016 r. w sprawie indeksów stosowanych jako wskaźniki 
referencyjne w instrumentach finansowych i umowach finansowych lub do pomiaru 
wyników funduszy inwestycyjnych i zmieniającego dyrektywy 2008/48/WE 
i 2014/17/UE 
oraz 
rozporządzenie 
(UE) 
nr 596/2014 
(Dz. Urz. 
UE L 171 
z 29.06.2016, str. 1), oraz instrumenty dłużne, które są denominowane w walucie innej 
niż waluta polska, o ile świadczenia główne lub uboczne są denominowane w tej samej 
walucie. 
2b. W przypadku gdy instrumenty, których dotyczą należności wskazane 
w ust. 2 pkt 8–10, są jedynie częściowo uznawane za pozycję funduszy własnych 
banku, należności z tytułu całego instrumentu są traktowane jako należności 
wynikające z kategorii, do której został zaliczony ten instrument. 
3. Z masy upadłości zaspokaja się w pierwszej kolejności koszty postępowania 
upadłościowego, a następnie koszty przymusowej restrukturyzacji niepokryte 
z przychodów z przymusowej restrukturyzacji, a jeżeli fundusze masy upadłości na to 
pozwalają – również inne zobowiązania masy upadłości, o których mowa 
w art. 230 ust. 2, w miarę wpływu do masy upadłości stosownych sum. Przepisy 
art. 343 ust. 1a i 2 oraz art. 344 stosuje się. 
4. Należności Bankowego Funduszu Gwarancyjnego z tytułu wypłaty środków 
gwarantowanych lub zapewnienia możliwości ich podjęcia nie wymagają zgłoszenia. 
Należności z tego tytułu umieszcza się na liście wierzytelności z urzędu. 

©Kancelaria Sejmu 
 
 
 
s. 176/224 
 
2025-09-11 
 
5. W przypadku, o którym mowa w ust. 2 pkt 5, przepis art. 342 ust. 5 pkt 2–3 
oraz ust. 6 stosuje się. 
6. Przepisy dotyczące zaspokojenia należności ze stosunku pracy stosuje się 
odpowiednio do roszczeń Funduszu Gwarantowanych Świadczeń Pracowniczych 
o zwrot z masy upadłości świadczeń wypłaconych przez Fundusz pracownikom 
upadłego.

***
## Art. 441. {#art-441}

Jeżeli wierzytelności i należności od upadłego były zabezpieczone 
ograniczonymi prawami rzeczowymi, ich zaspokojenie następuje zgodnie z art. 345 
i 346. 
Art. 441a. 1. Wniosek 
o ogłoszenie 
upadłości 
spółdzielczej 
kasy 
oszczędnościowo-kredytowej może zgłosić wyłącznie Komisja Nadzoru Finansowego 
albo Bankowy Fundusz Gwarancyjny. 
1a. We wniosku, o którym mowa w ust. 1, jako syndyk mogą zostać wskazane 
bank albo spółdzielcza kasa oszczędnościowo-kredytowa. 
2. W postępowaniu upadłościowym wobec spółdzielczej kasy oszczędnościowo-
-kredytowej syndykiem może być także spółdzielcza kasa oszczędnościowo-
-kredytowa albo bank wskazane we wniosku, o którym mowa w ust. 1, po uzyskaniu 
pozytywnej opinii: 
- 1) Komisji Nadzoru Finansowego – w przypadku wniosku złożonego przez 
Bankowy Fundusz Gwarancyjny; 
- 2) Bankowego Funduszu Gwarancyjnego – w przypadku wniosku złożonego przez 
Komisję Nadzoru Finansowego. 
3. Propozycje układowe mogą złożyć także członkowie spółdzielczej kasy 
oszczędnościowo-kredytowej reprezentujący dwie trzecie funduszu udziałowego 
kasy. 
4. W pozostałym zakresie przepisy art. 426–441 stosuje się odpowiednio. 
DZIAŁ II 
Postępowanie upadłościowe wobec banków hipotecznych

***
## Art. 442. {#art-442}

1. W razie ogłoszenia upadłości banku hipotecznego osobną masę 
upadłości, która służy zaspokojeniu roszczeń wierzycieli z listów zastawnych oraz 
roszczeń z tytułu umów o instrument pochodny, wpisanych do rejestru zabezpieczenia 
listów zastawnych, tworzą: 

©Kancelaria Sejmu 
 
 
 
s. 177/224 
 
2025-09-11 
- 1) wierzytelności banku hipotecznego oraz prawa i środki, o których mowa 
w art. 18 ust. 3, 3a i 4 ustawy z dnia 29 sierpnia 1997 r. o listach zastawnych 
i bankach hipotecznych (Dz. U. z 2023 r. poz. 110), zwanej dalej „ustawą o lis-
tach zastawnych”, wpisane do rejestru zabezpieczenia listów zastawnych; 
- 2) środki uzyskane w wyniku spłaty wierzytelności wpisanych do rejestru 
zabezpieczenia listów zastawnych; 
- 3) składniki majątkowe uzyskane w zamian za aktywa wpisane do rejestru 
zabezpieczenia listów zastawnych. 
2. W razie wątpliwości, czy składniki, o których mowa w ust. 1, należą do 
osobnej masy upadłości, uważa się, że należą one do tej masy do wysokości 
ujawnionej w rejestrze zabezpieczenia listów zastawnych wartości: 
- 1) wierzytelności banku hipotecznego oraz praw i środków, o których mowa 
w art. 18 ust. 3, 3a i 4 ustawy o listach zastawnych; 
- 2) odpowiednio wierzytelności i aktywów – w przypadku składników, o których 
mowa w ust. 1 pkt 2 i 3. 
3. Po zaspokojeniu roszczeń wierzycieli z listów zastawnych nadwyżkę środków 
z osobnej masy upadłości zalicza się do masy upadłości. 
Art. 442a. 1. 
Potrącenie 
wierzytelności 
wierzyciela 
upadłego 
banku 
hipotecznego z wierzytelnościami upadłego banku hipotecznego należącymi do 
osobnej masy upadłości nie jest dopuszczalne. 
2. Przepisu ust. 1 nie stosuje się do potrącenia wierzytelności z tytułu 
instrumentów pochodnych, w przypadku których zostały spełnione warunki określone 
w art. 18a ust. 1 ustawy o listach zastawnych, wpisanych do rejestru zabezpieczenia 
listów zastawnych. Do zaspokojenia roszczeń wierzycieli z tych instrumentów 
przepisy niniejszego działu dotyczące zaspokajania roszczeń wierzycieli z listów 
zastawnych stosuje się odpowiednio. 
3. Przepisu ust. 1 nie stosuje się również do rozliczeń dokonywanych w ramach 
systemu płatności i systemu rozrachunku papierów wartościowych, których 
uczestnikiem jest upadły bank hipoteczny, oraz rozliczeń zabezpieczeń finansowych 
ustanowionych zgodnie z przepisami ustawy z dnia 2 kwietnia 2004 r. o niektórych 
zabezpieczeniach finansowych.

***
## Art. 443. {#art-443}

1. W postanowieniu o ogłoszeniu upadłości sąd ustanowi kuratora dla 
reprezentowania w postępowaniu praw posiadaczy listów zastawnych. Przed 

©Kancelaria Sejmu 
 
 
 
s. 178/224 
 
2025-09-11 
 
ustanowieniem kuratora sąd zasięga opinii Komisji Nadzoru Finansowego co do osoby 
kuratora. 
2. Do kuratora, o którym mowa w ust. 1, stosuje się odpowiednio przepisy 
art. 187 ust. 3 i 4 oraz przepisy o sprawozdaniach syndyka. 
3. Posiadacze listów zastawnych mogą działać w postępowaniu również 
osobiście lub przez pełnomocnika, jeżeli zostali dopuszczeni do udziału 
w postępowaniu przez sędziego-komisarza. Sędzia-komisarz dopuszcza posiadaczy 
listów zastawnych do udziału w postępowaniu po wykazaniu, że przysługują im prawa 
z listów zastawnych.

***
## Art. 444. {#art-444}

Kurator w terminie 21 dni od dnia ogłoszenia upadłości zgłasza do 
masy upadłości: 
- 1) ogólną sumę nominalną nieumorzonych do dnia ogłoszenia upadłości listów 
zastawnych, których termin płatności przypada przed tym dniem, oraz ogólną 
sumę niezapłaconych odsetek; 
- 2) ogólną sumę nominalną listów zastawnych oraz odsetek płatnych po dniu 
ogłoszenia upadłości, oraz premii przewidzianych w planie.

***
## Art. 445. {#art-445}

1. Syndyk udziela kuratorowi wszelkich potrzebnych mu informacji. 
Kurator ma prawo przeglądać księgi i dokumenty upadłego banku. 
2. Na zgromadzeniu wierzycieli kurator ma prawo głosu tylko w sprawach, które 
mogą mieć wpływ na prawa posiadaczy listów zastawnych. 
Art. 445a. 1. Sędzia-komisarz zwołuje zgromadzenie wierzycieli z listów 
zastawnych na wniosek wierzycieli z listów zastawnych reprezentujących co najmniej 
10 % wierzytelności z tytułu nominalnej wartości listów zastawnych pozostających 
w obrocie. Przepisy o zgromadzeniu wierzycieli stosuje się odpowiednio. 
2. Jeżeli przepisy niniejszego działu nie stanowią inaczej, uchwały zgromadzenia 
wierzycieli z listów zastawnych zapadają bez względu na liczbę obecnych, 
większością głosów wierzycieli reprezentujących ponad 50 % wierzytelności z tytułu 
nominalnej wartości listów zastawnych pozostających w obrocie. 
3. Zgody zgromadzenia wierzycieli z listów zastawnych wymaga sprzedaż 
składników majątkowych wpisanych do rejestru zabezpieczenia listów zastawnych: 
- 1) w całości, jeżeli środki uzyskane ze sprzedaży nie wystarczą na całkowite 
zaspokojenie kosztów likwidacji osobnej masy upadłości oraz roszczeń 
wierzycieli z listów zastawnych; 

©Kancelaria Sejmu 
 
 
 
s. 179/224 
 
2025-09-11 
- 2) w części, jeżeli planowana jest ich sprzedaż poniżej wartości godziwej. 
Art. 445b. 1. Likwidację osobnej masy upadłości syndyk przeprowadza 
z udziałem kuratora. 
2. W przypadku wyrażenia zgody przez radę wierzycieli lub sędziego-komisarza 
na sprzedaż z wolnej ręki mienia wchodzącego w skład osobnej masy upadłości 
sprzedaż wymaga zgody kuratora. 
3. Jeżeli przepisy niniejszego działu nie stanowią inaczej, składniki majątkowe 
wpisane do rejestru zabezpieczenia listów zastawnych sprzedaje się innemu bankowi 
hipotecznemu, a sprzedaż tych składników powoduje przejście na nabywcę 
zobowiązań upadłego banku wobec wierzycieli z listów zastawnych. Na przejście 
zobowiązań zgoda wierzycieli z listów zastawnych nie jest wymagana. O dokonanej 
sprzedaży obwieszcza się. 
4. Umowa sprzedaży wierzytelności zabezpieczonej hipoteką stanowi podstawę 
wpisu w księdze wieczystej. 
5. Do sprzedaży części przedsiębiorstwa bankowego upadłego banku 
hipotecznego, obejmującej w szczególności składniki osobnej masy upadłości, 
wymagana jest uchwała zgromadzenia wierzycieli z listów zastawnych podjęta 
większością dwóch trzecich głosów wierzycieli z tytułu nominalnej wartości listów 
zastawnych pozostających w obrocie. W takim przypadku listy zastawne nie są objęte 
sprzedażą, przy czym syndyk określa udział w cenie ze sprzedaży części 
przedsiębiorstwa bankowego upadłego banku hipotecznego, który zostanie 
przeznaczony na zaspokojenie roszczeń wierzycieli z listów zastawnych.

***
## Art. 446. {#art-446}

1. Z dniem ogłoszenia upadłości banku hipotecznego terminy 
wymagalności jego zobowiązań wobec wierzycieli z listów zastawnych ulegają 
przedłużeniu o 12 miesięcy. 
2. Zobowiązania 
wobec 
wierzycieli 
z listów 
zastawnych 
wymagalne, 
a niezapłacone przed dniem ogłoszenia upadłości banku hipotecznego, zaspokaja się 
w terminie 12 miesięcy od dnia ogłoszenia upadłości, nie wcześniej jednak niż po 
pierwszym obwieszczeniu o wynikach testów, o którym mowa w art. 446a 
ust. 8 pkt 1, z zastrzeżeniem art. 446c ust. 1 pkt 1. 
3. Odsetki od wierzytelności z listów zastawnych należne od upadłego wypłaca 
się w sposób i terminach określonych w warunkach emisji. 

©Kancelaria Sejmu 
 
 
 
s. 180/224 
 
2025-09-11 
 
Art. 446a. 1. Syndyk niezwłocznie, nie później niż w terminie 3 miesięcy od 
dnia ogłoszenia upadłości banku hipotecznego, przeprowadza w odniesieniu do 
osobnej masy upadłości test równowagi pokrycia, o którym mowa w art. 25 ust. 2 
pkt 1 ustawy o listach zastawnych, a jeżeli wynik testu równowagi pokrycia jest 
pozytywny – test płynności, o którym mowa w art. 25 ust. 2 pkt 2 tej ustawy. 
2. Kolejne testy płynności przeprowadza się nie rzadziej niż co 3 miesiące, 
a kolejne testy równowagi pokrycia – nie rzadziej niż co 6 miesięcy. Jeżeli wynik testu 
równowagi pokrycia nie jest pozytywny, dalszych testów nie przeprowadza się. 
3. Przeprowadzając test równowagi pokrycia i test płynności, syndyk uwzględnia 
dodatkowo zobowiązania z listów zastawnych, o których mowa w art. 446 ust. 2. 
4. Test równowagi pokrycia i test płynności są przeprowadzane pod nadzorem 
kuratora, odrębnie dla hipotecznych listów zastawnych i dla publicznych listów 
zastawnych. 
5. Wyniki testu równowagi pokrycia i testu płynności uznaje się za pozytywne, 
jeżeli po ich przeprowadzeniu ustalono, że osobna masa upadłości wystarcza na pełne 
zaspokojenie posiadaczy listów zastawnych. 
6. Wyniki pierwszego po ogłoszeniu upadłości testu równowagi pokrycia albo 
testu równowagi pokrycia i testu płynności, wraz z dokumentami, na podstawie 
których przeprowadzono te testy, syndyk przekazuje niezwłocznie do wiadomości 
Komisji Nadzoru Finansowego. Wyniki kolejnych testów syndyk przekazuje 
niezwłocznie do wiadomości Komisji, wraz z dokumentami, na podstawie których 
przeprowadzono te testy, jeżeli przeprowadzone zostały w inny sposób niż testy, 
o których mowa w zdaniu pierwszym. Komisja może zgłosić uwagi, w szczególności 
do sposobu przeprowadzenia testów, w terminie 2 tygodni od dnia otrzymania ich 
wyników. 
7. Syndyk po rozpatrzeniu uwag Komisji Nadzoru Finansowego niezwłocznie 
przekazuje wyniki testu równowagi pokrycia i testu płynności sędziemu-komisarzowi. 
Wyniki pierwszego po ogłoszeniu upadłości testu równowagi pokrycia albo testu 
równowagi pokrycia i testu płynności przekazuje się sędziemu-komisarzowi nie 
później niż w terminie 4 miesięcy od dnia ogłoszenia upadłości banku hipotecznego. 
8. Sędzia-komisarz: 
- 1) obwieszcza o wynikach testu równowagi pokrycia albo testu równowagi 
pokrycia i testu płynności; 

©Kancelaria Sejmu 
 
 
 
s. 181/224 
 
2025-09-11 
- 2) wydaje i obwieszcza postanowienie o sposobie prowadzenia postępowania 
upadłościowego wobec banku hipotecznego, o którym mowa w art. 446b ust. 1 
albo art. 446c ust. 1, oraz o sposobie prowadzenia postępowania, w przypadku 
gdy zgromadzenie wierzycieli z listów zastawnych podjęło uchwałę, o której 
mowa w art. 446b ust. 2, art. 446c ust. 3 albo art. 446d ust. 1. 
Art. 446b. 1. W przypadku pozytywnego wyniku testu równowagi pokrycia 
i pozytywnego wyniku testu płynności: 
- 1) roszczenia wierzycieli z listów zastawnych zaspokajane są zgodnie z warunkami 
emisji, z uwzględnieniem art. 446 ust. 1; 
- 2) syndyk może zawierać umowy dotyczące instrumentów pochodnych, o których 
mowa w art. 442a ust. 2. 
2. Zgromadzenie wierzycieli z listów zastawnych, nie później niż w terminie 
2 miesięcy od dnia obwieszczenia o wynikach testów, może podjąć większością 
dwóch trzecich głosów wierzycieli z tytułu nominalnej wartości listów zastawnych 
pozostających w obrocie uchwałę o zobowiązaniu syndyka do podjęcia działań w celu 
sprzedaży wszystkich wierzytelności i praw upadłego banku hipotecznego należących 
do osobnej masy upadłości: 
- 1) na rzecz banku hipotecznego wraz z przejściem całości zobowiązań upadłego 
banku wobec wierzycieli z listów zastawnych albo 
- 2) na rzecz banku hipotecznego albo innego banku bez przejścia zobowiązań 
upadłego banku wobec wierzycieli z listów zastawnych. 
3. Zgromadzenie wierzycieli z listów zastawnych, o którym mowa w ust. 2, 
zwołuje się na wniosek złożony nie później niż w terminie miesiąca od dnia 
obwieszczenia o wynikach testów. 
4. W przypadku podjęcia uchwały, o której mowa w ust. 2 pkt 2, z osobnej masy 
upadłości zaspokajane są roszczenia o odsetki za okres do dnia sprzedaży 
wierzytelności i praw upadłego banku hipotecznego. 
5. Jeżeli wpływy z tytułu sprzedaży składników osobnej masy upadłości 
pomniejszone o łączną kwotę nominalnych wartości odsetek od znajdujących się 
w obrocie listów zastawnych, przypadających do wypłaty w okresie kolejnych 
6 miesięcy, oraz kwoty, o których mowa w art. 446 ust. 2, wyniosą co najmniej 5 % 
łącznej kwoty nominalnych wartości znajdujących się w obrocie listów zastawnych, 
roszczenia wierzycieli z listów zastawnych mogą być zaspokojone proporcjonalnie do 
wysokości tych roszczeń, w terminach wcześniejszych niż w przedłużonych 

©Kancelaria Sejmu 
 
 
 
s. 182/224 
 
2025-09-11 
 
terminach 
wymagalności, 
o których 
mowa 
w art. 446 ust. 1. 
Przepisu 
art. 356 ust. 3 nie stosuje się. 
6. Listy zastawne w części zaspokojonej zgodnie z ust. 5 umarza się. 
7. Środki, o których mowa w ust. 5, są przekazywane wierzycielom z listów 
zastawnych w najbliższym terminie płatności odsetek określonym w warunkach 
emisji, jednak nie wcześniej niż po upływie dwóch miesięcy od dnia złożenia sprawo-
zdania syndyka. Jeżeli sędzia-komisarz wydał postanowienie, o którym mowa 
w art. 168 ust. 5b, środki, o których mowa w ust. 5, są przekazywane nie wcześniej niż 
po upływie 14 dni od dnia uprawomocnienia się tego postanowienia. 
Art. 446c. 1. W przypadku pozytywnego wyniku testu równowagi pokrycia 
i braku pozytywnego wyniku testu płynności: 
- 1) terminy wymagalności zobowiązań banku hipotecznego wobec wierzycieli 
z listów zastawnych z tytułu nominalnej wartości tych listów, w tym zobowiązań 
wymagalnych, a niezapłaconych przed dniem ogłoszenia upadłości banku 
hipotecznego, ulegają przedłużeniu o 3 lata od najpóźniejszego terminu 
wymagalności wierzytelności wpisanej do rejestru zabezpieczenia listów 
zastawnych; 
- 2) roszczenia wierzycieli z listów zastawnych z tytułu nominalnej wartości tych 
listów zaspokajane są, proporcjonalnie do wysokości tych roszczeń, w terminach 
wcześniejszych niż w przedłużonych terminach wymagalności, o których mowa 
w pkt 1, ze środków tworzących osobną masę upadłości – o ile środki te, po 
pomniejszeniu o wysokość: 
  - a) łącznej kwoty nominalnych wartości odsetek od znajdujących się w obrocie 
listów zastawnych, przypadających do wypłaty w okresie kolejnych 
6 miesięcy, 
  - b) kosztów postępowania upadłościowego w zakresie osobnej masy upadłości 
wynikających ze sprawozdania syndyka 
– wyniosą co najmniej 5 % łącznej kwoty nominalnych wartości znajdujących 
się w obrocie listów zastawnych; przy czym listy zastawne w zaspokojonej 
części podlegają umorzeniu. 
2. Do przekazywania środków, o których mowa w ust. 1 pkt 2, stosuje się 
odpowiednio przepis art. 446b ust. 7. 
3. Zgromadzenie wierzycieli z listów zastawnych, nie później niż w terminie 
3 miesięcy od dnia obwieszczenia o wynikach testów, może podjąć większością 

©Kancelaria Sejmu 
 
 
 
s. 183/224 
 
2025-09-11 
 
dwóch trzecich głosów wierzycieli z tytułu nominalnej wartości listów zastawnych 
pozostających w obrocie uchwałę o niestosowaniu ust. 1, albo o zastosowaniu 
procedury, o której mowa w art. 446d. Przepis art. 446b ust. 3 stosuje się. 
Art. 446d. 1. W przypadku gdy wynik testu równowagi pokrycia nie jest 
pozytywny, stosuje się odpowiednio przepisy art. 446b ust. 7 i art. 446c ust. 1, chyba 
że zgromadzenie wierzycieli z listów zastawnych większością dwóch trzecich głosów 
wierzycieli z tytułu nominalnej wartości listów zastawnych pozostających w obrocie 
podejmie uchwałę o wyrażeniu zgody na likwidację osobnej masy upadłości 
i sprzedaży składników majątkowych wpisanych do rejestru zabezpieczenia listów 
zastawnych. 
2. Zobowiązania banku hipotecznego wobec wierzycieli z listów zastawnych 
stają się wymagalne z dniem podjęcia uchwały, o której mowa w ust. 1. 
3. W przypadku podjęcia uchwały, o której mowa w ust. 1, możliwa jest 
sprzedaż składników majątkowych wpisanych do rejestru zabezpieczenia listów 
zastawnych: 
- 1) na rzecz banku innego niż bank hipoteczny bez przejścia na nabywcę zobowiązań 
upadłego banku wobec wierzycieli z listów zastawnych; 
- 2) na rzecz podmiotu innego niż bank – w przypadku składników, których 
posiadanie nie jest zastrzeżone dla banków. 
4. W przypadku sprzedaży składnika majątkowego wpisanego do rejestru 
zabezpieczenia listów zastawnych bez przejścia na nabywcę zobowiązań upadłego 
banku wobec wierzycieli z listów zastawnych, ze środków uzyskanych ze sprzedaży 
zaspokajane są roszczenia o odsetki z listów zastawnych zabezpieczonych tym 
składnikiem za okres do dnia sprzedaży.

***
## Art. 447. {#art-447}

(uchylony)

***
## Art. 448. {#art-448}

Z osobnej masy upadłości zaspokaja się kolejno: 
- 1) koszty likwidacji osobnej masy upadłości, które obejmują także wynagrodzenie 
kuratora, oraz odsetki i inne należności uboczne z listów zastawnych oraz 
z tytułu 
okresowych 
płatności 
odsetkowych 
dokonywanych 
w ramach 
instrumentów pochodnych; 
- 2) roszczenia z listów zastawnych według ich wartości nominalnej oraz roszczenia 
z tytułu instrumentów pochodnych. 

©Kancelaria Sejmu 
 
 
 
s. 184/224 
 
2025-09-11

***
## Art. 449. {#art-449}

Jeżeli osobna masa upadłości nie wystarcza na pełne zaspokojenie 
posiadaczy listów zastawnych, pozostała suma podlega zaspokojeniu w podziale 
funduszów masy upadłości. Sumę na zaspokojenie posiadaczy listów zastawnych 
z funduszu masy upadłości przekazuje się do funduszu osobnej masy upadłości.

***
## Art. 450. {#art-450}

Nie można wprowadzać do obiegu listów zastawnych emitowanych 
przez upadłego, które są jego własnością. Listy takie podlegają umorzeniu. 
Art. 450a. Do postępowania upadłościowego wobec banków hipotecznych 
przepisów tytułu Va części I nie stosuje się. 
DZIAŁ III 
Postępowanie upadłościowe wobec instytucji kredytowych, firm inwestycyjnych, 
banków zagranicznych oraz banków krajowych prowadzących działalność za 
granicą 
## Rozdział 1. Przepisy ogólne

***
## Art. 451. {#art-451}

Przepisy niniejszego działu stosuje się w przypadku: 
- 1) ogłoszenia upadłości banku krajowego, jeżeli prowadzi on działalność także za 
granicą Rzeczypospolitej Polskiej w co najmniej jednym innym państwie 
członkowskim Unii Europejskiej lub państwie członkowskim Europejskiego 
Porozumienia o Wolnym Handlu (EFTA) – stronie umowy o Europejskim 
Obszarze Gospodarczym; 
- 2) ogłoszenia upadłości, otwarcia postępowania układowego lub innego podobnego 
postępowania wobec instytucji kredytowej, jeżeli prowadzi ona działalność także 
w Rzeczypospolitej Polskiej; 
- 3) ogłoszenia upadłości, otwarcia postępowania układowego lub innego podobnego 
postępowania wobec banku zagranicznego, jeżeli bank zagraniczny prowadzi 
działalność w Rzeczypospolitej Polskiej oraz w co najmniej jednym innym 
państwie członkowskim Unii Europejskiej lub państwie członkowskim 
Europejskiego Porozumienia o Wolnym Handlu (EFTA) – stronie umowy 
o Europejskim Obszarze Gospodarczym; 
- 4) ogłoszenia upadłości domu maklerskiego, jeżeli prowadzi on działalność 
maklerską w Rzeczypospolitej Polskiej oraz w co najmniej jednym innym 
państwie członkowskim Unii Europejskiej lub państwie członkowskim 

©Kancelaria Sejmu 
 
 
 
s. 185/224 
 
2025-09-11 
 
Europejskiego Porozumienia o Wolnym Handlu (EFTA) – stronie umowy 
o Europejskim Obszarze Gospodarczym; 
- 5) ogłoszenia upadłości, otwarcia postępowania układowego lub innego podobnego 
postępowania wobec zagranicznej firmy inwestycyjnej, jeżeli prowadzi ona 
działalność maklerską także w Rzeczypospolitej Polskiej.

***
## Art. 452. {#art-452}

1. Ilekroć w ustawie jest mowa o „banku krajowym”, „banku 
zagranicznym”, „instytucji kredytowej”, „oddziale banku krajowego za granicą”, 
„oddziale banku zagranicznego” i „oddziale instytucji kredytowej” – rozumie się 
przez to instytucje określone w przepisach prawa bankowego. 
1a. Ilekroć w ustawie jest mowa o „firmie inwestycyjnej”, „zagranicznej firmie 
inwestycyjnej” oraz „domu maklerskim” – rozumie się przez to instytucje określone 
w ustawie z dnia 29 lipca 2005 r. o obrocie instrumentami finansowymi. 
2. Użyte w niniejszym dziale określenia oznaczają: 
- 1) „sąd zagraniczny” – sąd lub inny organ uprawniony do prowadzenia lub 
nadzorowania 
postępowania 
upadłościowego, 
układowego 
lub 
innego 
podobnego postępowania w innym państwie członkowskim Unii Europejskiej 
lub państwie członkowskim Europejskiego Porozumienia o Wolnym Handlu 
(EFTA) – stronie umowy o Europejskim Obszarze Gospodarczym; 
- 2) „zarządca zagraniczny” – osobę lub podmiot wyznaczony w zagranicznym 
postępowaniu upadłościowym, układowym lub innym podobnym postępowaniu 
do zarządzania, reorganizowania lub likwidacji majątku dłużnika, ustanowiony 
zgodnie z prawem obowiązującym w innym państwie członkowskim Unii 
Europejskiej lub państwie członkowskim Europejskiego Porozumienia 
o Wolnym Handlu (EFTA) – stronie umowy o Europejskim Obszarze 
Gospodarczym.

***
## Art. 453. {#art-453}

Sądom 
polskim 
nie 
przysługuje 
jurysdykcja 
w sprawach 
upadłościowych dotyczących instytucji kredytowych lub zagranicznych firm 
inwestycyjnych prowadzących działalność gospodarczą albo mających majątek 
w Rzeczypospolitej Polskiej. Przepisu art. 405 ust. 1 nie stosuje się.

***
## Art. 454. {#art-454}

Orzeczenie o wszczęciu zagranicznego postępowania upadłościowego, 
postępowania układowego lub innego podobnego postępowania prowadzonego wobec 
instytucji kredytowych lub zagranicznych firm inwestycyjnych podlega uznaniu 
z mocy prawa, jeżeli postępowanie wszczął właściwy sąd zagraniczny w państwie 

©Kancelaria Sejmu 
 
 
 
s. 186/224 
 
2025-09-11 
 
członkowskim Unii Europejskiej lub państwie członkowskim Europejskiego 
Porozumienia o Wolnym Handlu (EFTA) – stronie umowy o Europejskim Obszarze 
Gospodarczym, w którym instytucja kredytowa lub zagraniczna firma inwestycyjna 
ma siedzibę.

***
## Art. 455. {#art-455}

W skład masy upadłości banku krajowego oraz domu maklerskiego 
wchodzi także mienie upadłego znajdujące się na terytorium państw członkowskich 
Unii Europejskiej lub państw członkowskich Europejskiego Porozumienia o Wolnym 
Handlu (EFTA) – stron umowy o Europejskim Obszarze Gospodarczym. 
## Rozdział 2. Postępowanie

***
## Art. 456. {#art-456}

1. Sąd, który ogłosił upadłość banku krajowego, banku zagranicznego, 
domu maklerskiego lub zagranicznej firmy inwestycyjnej, powiadamia o tym 
niezwłocznie właściwe organy państwa członkowskiego Unii Europejskiej lub 
państwa członkowskiego Europejskiego Porozumienia o Wolnym Handlu (EFTA) – 
strony umowy o Europejskim Obszarze Gospodarczym, w którym znajduje się oddział 
banku krajowego za granicą, inny oddział banku zagranicznego, oddział domu 
maklerskiego albo oddział zagranicznej firmy inwestycyjnej, informując o skutkach 
ogłoszenia upadłości. 
2. Jeżeli wszczęcie postępowania, o którym mowa w ust. 1, może wpływać na 
prawa osób trzecich w państwie będącym członkiem Unii Europejskiej lub członkiem 
Europejskiego Porozumienia o Wolnym Handlu (EFTA) – stroną umowy 
o Europejskim Obszarze Gospodarczym albo gdy takim osobom przysługuje zażalenie 
na postanowienie o ogłoszeniu upadłości, postanowienie to podlega obwieszczeniu 
w Dzienniku Urzędowym Wspólnot Europejskich oraz w dwóch czasopismach 
o zasięgu ogólnokrajowym w każdym państwie, w którym znajduje się oddział banku 
albo oddział firmy inwestycyjnej. Termin do wniesienia zażalenia liczy się od dnia 
obwieszczenia w Dzienniku Urzędowym Wspólnot Europejskich. 
3. Obwieszczenie, o którym mowa w ust. 2, jest dokonywane w języku lub 
jednym 
z języków 
urzędowych 
państwa, 
w którym 
jest 
zamieszczane. 
W obwieszczeniu należy określić cel i podstawy prawne ogłoszenia upadłości, termin 
wniesienia zażalenia oraz adres sądu właściwego do jego rozpoznania wraz z adresem 
sądu, za pośrednictwem którego wnosi się zażalenie. 

©Kancelaria Sejmu 
 
 
 
s. 187/224 
 
2025-09-11

***
## Art. 457. {#art-457}

1. Wezwanie do zgłaszania wierzytelności przez wierzycieli mających 
miejsce zamieszkania, miejsce zwykłego pobytu albo siedzibę w państwie 
członkowskim Unii Europejskiej lub państwie członkowskim Europejskiego Poro-
zumienia o Wolnym Handlu (EFTA) – stronie umowy o Europejskim Obszarze 
Gospodarczym zawiera nagłówek o treści: „Wezwanie do zgłaszania wierzytelności. 
Termin zgłoszenia”, sporządzony we wszystkich językach urzędowych Unii Euro-
pejskiej oraz języku norweskim i języku islandzkim. Wezwanie wskazuje termin 
zgłoszenia wierzytelności, skutki jego uchybienia, zawiera informację, czy 
wierzyciele posiadający wierzytelności uprzywilejowane lub zabezpieczone rzeczowo 
muszą dokonać zgłoszenia wierzytelności, a także określa obowiązek załączenia 
dowodów stwierdzających istnienie wierzytelności. 
1a. Do wezwania do zgłaszania wierzytelności, o którym mowa w ust. 1, 
przepisy art. 176 ust. 1 i 1a stosuje się odpowiednio. 
2. Wierzyciel mający miejsce zamieszkania, miejsce zwykłego pobytu albo 
siedzibę w państwie członkowskim Unii Europejskiej lub państwie członkowskim 
Europejskiego Porozumienia o Wolnym Handlu (EFTA) – stronie umowy 
o Europejskim Obszarze Gospodarczym może zgłosić wierzytelność w języku 
urzędowym lub jednym z języków urzędowych państwa, w którym ma miejsce 
zamieszkania, miejsce zwykłego pobytu albo siedzibę, jednakże co najmniej nagłówek 
„Zgłoszenie wierzytelności” wyraża się w języku polskim. Sąd może zażądać 
uwierzytelnionego tłumaczenia zgłoszenia na język polski.

***
## Art. 458. {#art-458}

1. Wierzyciele upadłościowi banku krajowego, banku zagranicznego, 
domu maklerskiego lub zagranicznej firmy inwestycyjnej, mający miejsce 
zamieszkania, miejsce zwykłego pobytu albo siedzibę w państwie członkowskim Unii 
Europejskiej lub państwie członkowskim Europejskiego Porozumienia o Wolnym 
Handlu (EFTA) – stronie umowy o Europejskim Obszarze Gospodarczym, mają 
w postępowaniu takie same prawa jak wierzyciele krajowi. 
2. Zagraniczne należności publicznoprawne zaspokaja się w kategorii trzeciej 
podkategorii czwartej.

***
## Art. 459. {#art-459}

1. W przypadku 
ogłoszenia 
upadłości, 
otwarcia 
postępowania 
układowego lub innego podobnego postępowania w stosunku do instytucji 
kredytowej, mającej oddział na terytorium Rzeczypospolitej Polskiej lub zagranicznej 
firmy inwestycyjnej, zarządca zagraniczny zamierzający wykonywać swe czynności 

©Kancelaria Sejmu 
 
 
 
s. 188/224 
 
2025-09-11 
 
w Rzeczypospolitej Polskiej obowiązany jest wykazać swe uprawnienia urzędowo 
poświadczonym odpisem orzeczenia lub decyzji o jego ustanowieniu wraz 
z uwierzytelnionym tłumaczeniem na język polski. 
2. Zarządca zagraniczny, o którym mowa w ust. 1, korzysta w zakresie swych 
czynności urzędowych w Rzeczypospolitej Polskiej z takich samych uprawnień, jakie 
przysługują mu w państwie, w którym został powołany. 
3. Zarządca zagraniczny obowiązany jest wystąpić z wnioskiem o ujawnienie 
ogłoszenia upadłości, otwarcia postępowania układowego lub innego podobnego 
postępowania w księgach wieczystych, Krajowym Rejestrze Sądowym i innych 
rejestrach prowadzonych w Rzeczypospolitej Polskiej. Z żądaniem takim wystąpić 
mogą właściwe organy sądowe lub administracyjne państwa, w którym ogłoszono 
upadłość, otwarto postępowanie układowe lub wszczęto inne podobne postępowanie. 
Koszty poniesione w związku z tym ujawnieniem wchodzą w skład kosztów 
postępowania.

***
## Art. 4591. {#art-4591}

Syndyk obowiązany jest regularnie, nie rzadziej niż co sześć miesięcy, 
informować wierzycieli, których miejsce zwykłego pobytu, miejsce zamieszkania lub 
siedziba znajdują się w innych państwach członkowskich Unii Europejskiej lub 
w państwach członkowskich Europejskiego Porozumienia o Wolnym Handlu (EFTA) 
– stronach umowy o Europejskim Obszarze Gospodarczym o czynnościach podjętych 
w postępowaniu upadłościowym w okresie objętym informacją. 
## Rozdział 3. Prawo właściwe oraz skutki ogłoszenia upadłości

***
## Art. 460. {#art-460}

W postępowaniu upadłościowym wszczętym w Rzeczypospolitej 
Polskiej stosuje się prawo polskie, o ile przepisy niniejszego rozdziału nie stanowią 
inaczej.

***
## Art. 461. {#art-461}

1. Stosunki pracy pracowników zatrudnionych na terytorium innego 
państwa 
członkowskiego 
Unii 
Europejskiej 
lub 
państwa 
członkowskiego 
Europejskiego Porozumienia o Wolnym Handlu (EFTA) – strony umowy o Euro-
pejskim Obszarze Gospodarczym podlegają prawu właściwemu dla umowy o pracę. 
2. Uznanie danej rzeczy za nieruchomość ocenia się według prawa miejsca 
położenia rzeczy. 

©Kancelaria Sejmu 
 
 
 
s. 189/224 
 
2025-09-11 
 
3. Do umów mających za przedmiot korzystanie albo nabycie nieruchomości 
położonej na terytorium innego państwa członkowskiego Unii Europejskiej lub 
państwa członkowskiego Europejskiego Porozumienia o Wolnym Handlu (EFTA) – 
strony umowy o Europejskim Obszarze Gospodarczym stosuje się prawo państwa, 
w którym nieruchomość jest położona. 
4. Prawa dotyczące nieruchomości położonej na terytorium innego państwa 
członkowskiego Unii Europejskiej lub państwa członkowskiego Europejskiego 
Porozumienia o Wolnym Handlu (EFTA) – strony umowy o Europejskim Obszarze 
Gospodarczym oraz statku morskiego lub powietrznego, wpisanych do rejestru, 
podlegają prawu państwa, w którym prowadzony jest rejestr.

***
## Art. 462. {#art-462}

1. Ogłoszenie upadłości nie narusza praw wierzycieli i osób trzecich 
ciążących na rzeczy i innym mieniu upadłego położonym na terytorium innego 
państwa członkowskiego Unii Europejskiej lub państwa członkowskiego Euro-
pejskiego Porozumienia o Wolnym Handlu (EFTA) – strony umowy o Europejskim 
Obszarze Gospodarczym, nie wyłączając zorganizowanych części tego mienia, 
w szczególności prawa do rozporządzania mieniem w celu zaspokojenia należności 
lub prawa do zaspokojenia należności z pożytków, które mienie przynosi, prawa 
zastawu i hipoteki, prawa do żądania wydania mienia od osób, we władaniu których 
się ono znajduje wbrew woli uprawnionego, prawa do powierniczego korzystania 
z mienia. 
2. Przepis ust. 1 stosuje się do praw i roszczeń osobistych, wpisanych do ksiąg 
wieczystych i innych rejestrów publicznych, których realizacja prowadzi do powstania 
praw wymienionych w ust. 1. 
3. Przepisy ust. 1 i 2 nie wyłączają możliwości żądania w drodze powództwa 
stwierdzenia nieważności czynności prawnej lub uznania za bezskuteczną czynności 
prawnej dokonanej z pokrzywdzeniem wierzycieli.

***
## Art. 463. {#art-463}

1. Zastrzeżenie w umowie sprzedaży prawa własności na rzecz 
sprzedawcy nie wygasa wskutek ogłoszenia upadłości banku krajowego będącego 
nabywcą przedmiotu umowy, jeżeli w chwili ogłoszenia upadłości przedmiot umowy 
znajdował się na terytorium innego państwa członkowskiego Unii Europejskiej lub 
państwa członkowskiego Europejskiego Porozumienia o Wolnym Handlu (EFTA) – 
strony umowy o Europejskim Obszarze Gospodarczym. 

©Kancelaria Sejmu 
 
 
 
s. 190/224 
 
2025-09-11 
 
2. Ogłoszenie upadłości banku krajowego będącego zbywcą składnika mienia nie 
może być podstawą do odstąpienia od umowy sprzedaży, jeżeli wydanie przedmiotu 
sprzedaży nastąpiło przed ogłoszeniem upadłości, a w chwili ogłoszenia upadłości 
przedmiot sprzedaży znajdował się za granicą. 
3. Przepisy ust. 1 i 2 nie wyłączają możliwości żądania w drodze powództwa 
stwierdzenia nieważności czynności prawnej lub uznania za bezskuteczną czynności 
prawnej dokonanej z pokrzywdzeniem wierzycieli.

***
## Art. 464. {#art-464}

Wykonywanie praw, których powstanie, istnienie lub zbycie wymaga 
dokonania wpisu do ksiąg lub rejestrów, ujawnienia na rachunku albo złożenia do 
centralnego depozytu, podlega prawu państwa, w którym księgi lub rejestry, rachunki 
albo depozyty są prowadzone.

***
## Art. 465. {#art-465}

Z zastrzeżeniem art. 464, prawo odkupu podlega prawu właściwemu 
dla zobowiązań umownych, mającemu zastosowanie do umowy, z której prawo to 
wynika.

***
## Art. 466. {#art-466}

Z zastrzeżeniem art. 464, do umów zawieranych w ramach transakcji 
na rynku regulowanym w rozumieniu przepisów ustawy z dnia 29 lipca 2005 r. 
o obrocie instrumentami finansowymi stosuje się prawo właściwe dla zobowiązań 
umownych, mające zastosowanie do transakcji zawieranych na tym rynku.

***
## Art. 467. {#art-467}

Czynność 
kompensowania 
podlega 
prawu 
właściwemu 
dla 
zobowiązań umownych, mającemu zastosowanie do umowy o kompensowanie.

***
## Art. 4671. {#art-4671}

Ogłoszenie upadłości nie narusza prawa wierzyciela do potrącenia 
swej wierzytelności z wierzytelnością upadłego, jeżeli takie potrącenie jest 
dopuszczalne według prawa właściwego dla wierzytelności upadłego.

***
## Art. 468. {#art-468}

Skuteczność 
i ważność 
czynności 
prawnej 
rozporządzającej 
w stosunku do nieruchomości, statku morskiego lub powietrznego, podlegającego 
wpisowi do rejestru, albo w stosunku do praw, których powstanie, istnienie lub zbycie 
wymaga dokonania wpisu do ksiąg lub rejestrów, ujawnienia na rachunku albo 
złożenia do centralnego depozytu, dokonanej przez upadłego po ogłoszeniu upadłości 
podlega prawu państwa, w którym nieruchomość jest położona lub w którym 
prowadzone są księgi, rejestry, rachunki albo depozyty.

***
## Art. 469. {#art-469}

Przepisów o nieważności i bezskuteczności czynności prawnej 
dokonanej z pokrzywdzeniem wierzycieli nie stosuje się, gdy prawo właściwe dla tej 

©Kancelaria Sejmu 
 
 
 
s. 191/224 
 
2025-09-11 
 
czynności nie przewiduje bezskuteczności czynności dokonanych z pokrzywdzeniem 
wierzycieli.

***
## Art. 470. {#art-470}

Wpływ ogłoszenia upadłości na postępowanie sądowe toczące się 
przed sądem państwa członkowskiego Unii Europejskiej lub państwa członkowskiego 
Europejskiego Porozumienia o Wolnym Handlu (EFTA) – strony umowy 
o Europejskim Obszarze Gospodarczym ocenia się według prawa państwa, w którym 
postępowanie się toczy. 
TYTUŁ III 
Postępowanie upadłościowe wobec zakładów ubezpieczeń i zakładów 
reasekuracji 
DZIAŁ I 
Przepisy ogólne

***
## Art. 471. {#art-471}

1. Wniosek o ogłoszenie upadłości zakładu ubezpieczeń lub zakładu 
reasekuracji może zgłosić tylko dłużnik lub Komisja Nadzoru Finansowego, zwana 
dalej „Komisją”. 
2. Komisja jest uczestnikiem postępowania.

***
## Art. 472. {#art-472}

1. Przed ogłoszeniem upadłości zakładu ubezpieczeń lub zakładu 
reasekuracji sąd zasięga opinii Komisji co do osoby syndyka. Syndyk powinien 
posiadać znajomość organizacji i zasad działania zakładów ubezpieczeń i zakładów 
reasekuracji. Syndykiem może być inny zakład ubezpieczeń lub inny zakład 
reasekuracji. 
2. Syndyk przedkłada Komisji przynajmniej co trzy miesiące sprawozdanie, 
które obejmuje raport ze zmian w stanie i składzie masy upadłości w okresie 
sprawozdawczym, raport ze zmian stanu wierzytelności w okresie sprawozdawczym, 
raport z wpływów i wydatków syndyka w okresie sprawozdawczym oraz opis 
czynności syndyka w okresie sprawozdawczym z uzasadnieniem. Po zakończeniu 
pełnienia funkcji syndyk przedkłada Komisji sprawozdanie ostateczne. 
3. Syndyk o ogłoszeniu upadłości zawiadamia znanych mu wierzycieli, którzy 
udzielili upadłemu kredytu.

***
## Art. 473. {#art-473}

1. W postanowieniu o ogłoszeniu upadłości zakładu ubezpieczeń sąd 
po 
zasięgnięciu 
opinii 
Komisji 
ustanawia 
kuratora 
do 
reprezentowania 

©Kancelaria Sejmu 
 
 
 
s. 192/224 
 
2025-09-11 
 
w postępowaniu upadłościowym interesów osób ubezpieczających, ubezpieczonych, 
uposażonych lub uprawnionych z umów ubezpieczenia. 
2. Do kuratora, o którym mowa w niniejszym dziale, stosuje się odpowiednio 
przepisy art. 187 ust. 3 i 4 oraz przepisy o sprawozdaniach syndyka. 
3. Kuratorowi przysługuje wynagrodzenie w wysokości ustalonej przez 
sędziego-komisarza na wniosek Komisji. Wynagrodzenie wypłaca się z funduszów 
masy upadłości i zalicza się do kosztów postępowania upadłościowego.

***
## Art. 474. {#art-474}

1. Syndyk udziela kuratorowi potrzebnych informacji. Kurator ma 
prawo przeglądać księgi i dokumenty upadłego. Na zgromadzeniu wierzycieli kurator 
ma prawo głosu tylko w sprawach, które mogą mieć wpływ na prawa ubezpieczonych. 
2. Kurator ma prawo wnoszenia środków zaskarżenia w imieniu własnym na 
rzecz osób ubezpieczonych, upoważnionych i uprawnionych z umów ubezpieczenia, 
oraz jest uprawniony do zawarcia umowy o przeniesienie portfela ubezpieczeń do 
innego zakładu z możliwością obniżenia sum ubezpieczenia lub wysokości 
wypłacanych odszkodowań lub świadczeń. W przypadku zatwierdzenia przez 
Komisję umowy o przeniesienie portfela, kurator ogłasza niezwłocznie jej treść 
trzykrotnie w dzienniku o zasięgu ogólnopolskim. 
3. (uchylony) 
4. Do umowy o przeniesienie portfela ubezpieczeń zawartej przez kuratora 
stosuje się przepisy odrębne o przeniesieniu portfela ubezpieczeń.

***
## Art. 475. {#art-475}

Do ubezpieczonych, uposażonych lub uprawnionych z umów 
ubezpieczenia przepisu art. 232 nie stosuje się.

***
## Art. 476. {#art-476}

Umowy ubezpieczenia zawarte przez upadły zakład ubezpieczeń 
wygasają, jeżeli kurator nie zawarł umowy o przeniesienie portfela: 
- 1) z umów obowiązkowych oraz umów ubezpieczenia na życie, w terminie trzech 
miesięcy od ogłoszenia upadłości; 
- 2) z innych umów w terminie miesiąca od dnia ogłoszenia upadłości.

***
## Art. 477. {#art-477}

1. Z dniem ogłoszenia upadłości aktywa stanowiące pokrycie rezerw 
techniczno-ubezpieczeniowych 
dla 
celów 
wypłacalności 
upadłego 
zakładu 
ubezpieczeń tworzą osobną masę upadłości przeznaczoną na zaspokojenie roszczeń 
z tytułu umów ubezpieczenia, umów reasekuracji oraz kosztów likwidacji tej masy. 
2. Likwidację osobnej masy upadłości przeprowadza syndyk z udziałem 
kuratora. 

©Kancelaria Sejmu 
 
 
 
s. 193/224 
 
2025-09-11 
 
3. W razie wyrażenia zgody przez radę wierzycieli lub sędziego-komisarza na 
sprzedaż z wolnej ręki mienia wchodzącego w skład osobnej masy upadłości sprzedaż 
wymaga zgody kuratora.

***
## Art. 4771. {#art-4771}

1. Z dniem ogłoszenia upadłości aktywa stanowiące pokrycie rezerw 
techniczno-ubezpieczeniowych 
dla 
celów 
wypłacalności 
upadłego 
zakładu 
reasekuracji tworzą osobną masę upadłości przeznaczoną na zaspokojenie roszczeń 
z tytułu umów reasekuracji oraz kosztów likwidacji tej masy. 
2. Likwidację osobnej masy upadłości przeprowadza syndyk.

***
## Art. 478. {#art-478}

1. Z osobnej masy upadłości zakładu ubezpieczeń zaspokaja się 
kolejno: 
- 1) koszty likwidacji osobnej masy upadłości; 
- 2) wierzytelności z umów ubezpieczenia, z zastrzeżeniem ust. 3; 
- 3) wierzytelności z umów reasekuracji. 
2. Niezaspokojone 
z osobnej 
masy 
upadłości 
wierzytelności 
z umów 
ubezpieczenia umieszcza się w planie podziału funduszów masy upadłości w kategorii 
pierwszej. 
3. Wierzytelności osób poszkodowanych i uprawnionych z tytułu ubezpieczeń 
obowiązkowych oraz wierzytelności ubezpieczonych, uprawnionych i uposażonych 
z umów ubezpieczeń na życie, zaspokaja Ubezpieczeniowy Fundusz Gwarancyjny 
i Polskie Biuro Ubezpieczycieli Komunikacyjnych według odrębnych przepisów, 
w granicach określonych w tych przepisach.

***
## Art. 4781. {#art-4781}

Z osobnej masy upadłości zakładu reasekuracji zaspokaja się kolejno: 
- 1) koszty likwidacji osobnej masy upadłości; 
- 2) wierzytelności z umów reasekuracji.

***
## Art. 479. {#art-479}

W razie 
oddalenia 
wniosku 
o ogłoszenie 
upadłości 
zakładu 
ubezpieczeń z przyczyny, o której mowa w art. 13 ust. 1, jak również w razie 
umorzenia postępowania upadłościowego, Ubezpieczeniowy Fundusz Gwarancyjny 
zaspokaja roszczenia osób poszkodowanych i uprawnionych, w trybie i na zasadach 
określonych w odrębnych przepisach.

***
## Art. 480. {#art-480}

Przy zawieraniu układu kurator głosuje sumą wierzytelności 
ubezpieczonych niezaspokojonych z osobnej masy upadłości, przy czym przysługuje 
mu jeden głos od każdej sumy, która wynika z podziału sumy wszystkich innych 

©Kancelaria Sejmu 
 
 
 
s. 194/224 
 
2025-09-11 
 
wierzytelności uprawniających do głosowania przez liczbę wierzycieli, którzy 
reprezentują te wierzytelności. 
DZIAŁ II 
Postępowanie upadłościowe wobec mających siedzibę w państwach 
członkowskich Unii Europejskiej lub państwach członkowskich Europejskiego 
Porozumienia o Wolnym Handlu (EFTA) – stronach umowy o Europejskim 
Obszarze Gospodarczym zakładów ubezpieczeń i ich oddziałów oraz zakładów 
reasekuracji i ich oddziałów

***
## Art. 481. {#art-481}

Przepisy art. 452 ust. 2, art. 453–466 i art. 4671–470 stosuje się 
odpowiednio w przypadku: 
- 1) ogłoszenia upadłości krajowego zakładu ubezpieczeń lub krajowego zakładu 
reasekuracji, jeżeli prowadzi on działalność także za granicą Rzeczypospolitej 
Polskiej w co najmniej jednym innym państwie członkowskim Unii Europejskiej 
lub państwie członkowskim Europejskiego Porozumienia o Wolnym Handlu 
(EFTA) – stronie umowy o Europejskim Obszarze Gospodarczym; 
- 2) ogłoszenia upadłości, otwarcia postępowania układowego lub innego podobnego 
postępowania wobec: 
  - a) zagranicznego zakładu ubezpieczeń, 
  - b) zagranicznego zakładu reasekuracji 
– mającego siedzibę w państwie członkowskim Unii Europejskiej lub państwie 
członkowskim Europejskiego Porozumienia o Wolnym Handlu (EFTA) – stronie 
umowy o Europejskim Obszarze Gospodarczym, jeżeli prowadzi on działalność 
w Rzeczypospolitej Polskiej; 
- 3) ogłoszenia upadłości, otwarcia postępowania układowego lub innego podobnego 
postępowania wobec: 
  - a) zagranicznego zakładu ubezpieczeń, 
  - b) zagranicznego zakładu reasekuracji 
– mającego siedzibę w państwie niebędącym członkiem Unii Europejskiej lub 
członkiem Europejskiego Porozumienia o Wolnym Handlu (EFTA) – stroną 
umowy o Europejskim Obszarze Gospodarczym, jeżeli prowadzi on działalność 
w Rzeczypospolitej Polskiej oraz w co najmniej jednym innym państwie 
członkowskim Unii Europejskiej lub państwie członkowskim Europejskiego 

©Kancelaria Sejmu 
 
 
 
s. 195/224 
 
2025-09-11 
 
Porozumienia o Wolnym Handlu (EFTA) – stronie umowy o Europejskim 
Obszarze Gospodarczym.

***
## Art. 482. {#art-482}

Użyte w art. 481 określenia oznaczają: 
- 1) „krajowy zakład ubezpieczeń” – przedsiębiorcę mającego siedzibę na terenie 
Rzeczypospolitej Polskiej, który uzyskał zezwolenie na wykonywanie 
działalności ubezpieczeniowej w rozumieniu odrębnych przepisów; 
1a) „krajowy zakład reasekuracji” – przedsiębiorcę mającego siedzibę na terenie 
Rzeczypospolitej Polskiej, który uzyskał zezwolenie na wykonywanie 
działalności reasekuracyjnej w rozumieniu odrębnych przepisów; 
- 2) „oddział krajowego zakładu ubezpieczeń” – jednostkę organizacyjną krajowego 
zakładu ubezpieczeń, wykonującą w jego imieniu i na jego rzecz wszystkie lub 
niektóre czynności wynikające z zezwolenia udzielonego krajowemu zakładowi 
ubezpieczeń; 
2a) „oddział krajowego zakładu reasekuracji” – jednostkę organizacyjną krajowego 
zakładu reasekuracji, wykonującą w jego imieniu i na jego rzecz wszystkie lub 
niektóre czynności wynikające z zezwolenia udzielonego krajowemu zakładowi 
reasekuracji; 
- 3) „zagraniczny zakład ubezpieczeń” – przedsiębiorcę mającego siedzibę za granicą 
Rzeczypospolitej 
Polskiej, 
wykonującego 
działalność 
ubezpieczeniową 
w rozumieniu odrębnych przepisów; 
3a) „zagraniczny zakład reasekuracji” – przedsiębiorcę mającego siedzibę za granicą 
Rzeczypospolitej 
Polskiej, 
wykonującego 
działalność 
reasekuracyjną 
w rozumieniu odrębnych przepisów; 
- 4) „oddział zagranicznego zakładu ubezpieczeń” – jednostkę organizacyjną 
zagranicznego zakładu ubezpieczeń, wykonującą w jego imieniu i na jego rzecz 
działalność ubezpieczeniową; 
- 5) „oddział zagranicznego zakładu reasekuracji” – jednostkę organizacyjną 
zagranicznego zakładu reasekuracji, wykonującą w jego imieniu i na jego rzecz 
działalność reasekuracyjną. 

©Kancelaria Sejmu 
 
 
 
s. 196/224 
 
2025-09-11 
 
TYTUŁ IV 
Postępowanie upadłościowe wobec emitentów obligacji

***
## Art. 483. {#art-483}

1. Przepisy niniejszego tytułu stosuje się w razie ogłoszenia upadłości 
podmiotu emitującego obligacje, jeżeli dla zabezpieczenia praw z obligacji 
ustanowiono zabezpieczenie na majątku emitenta. 
2. Przepisów niniejszego tytułu nie stosuje się w razie ogłoszenia upadłości 
emitenta obligacji przychodowych, jeżeli emitent w treści obligacji ograniczył swoją 
odpowiedzialność do kwoty przychodów lub wartości majątku przedsięwzięcia. 
Środki przeznaczone na zaspokojenie praw obligatariuszy z takich obligacji nie 
wchodzą do masy upadłości, a roszczenia obligatariuszy nie podlegają zaspokojeniu 
w postępowaniu upadłościowym.

***
## Art. 484. {#art-484}

1. Dla reprezentowania praw obligatariuszy sąd ustanawia kuratora. 
Kuratorem może być także bank, z którym upadły zawarł umowę o reprezentowanie 
obligatariuszy wobec emitenta. Obligatariusze mogą działać w postępowaniu również 
osobiście lub przez pełnomocnika, jeżeli zostali dopuszczeni do udziału w 
postępowaniu przez sędziego-komisarza. Sędzia-komisarz dopuszcza obligatariuszy 
do udziału w postępowaniu po wykazaniu, że przysługują im prawa z obligacji. 
2. Nie ustanawia się kuratora, o którym mowa w ust. 1, w przypadku gdy dla 
zabezpieczenia praw z obligacji ustanowiono hipotekę na majątku emitenta. W takiej 
sytuacji prawa i obowiązki obligatariuszy w postępowaniu upadłościowym wykonuje 
administrator hipoteki, o którym mowa w art. 31 ust. 4 ustawy z dnia 15 stycznia 
2015 r. o obligacjach (Dz. U. z 2024 r. poz. 708).

***
## Art. 485. {#art-485}

Do kuratora, o którym mowa w niniejszym tytule, stosuje się 
odpowiednio przepisy art. 187 ust. 3 i 4 oraz przepisy o sprawozdaniach syndyka.

***
## Art. 486. {#art-486}

Syndyk udziela kuratorowi potrzebnych informacji. Kurator ma prawo 
przeglądać księgi i dokumenty upadłego. Na zgromadzeniu wierzycieli kurator ma 
prawo głosu tylko w sprawach, które mogą mieć wpływ na prawa obligatariuszy.

***
## Art. 487. {#art-487}

1. Kurator zgłasza do masy upadłości: 
- 1) ogólną sumę nominalną nieumorzonych do dnia ogłoszenia upadłości obligacji, 
których termin płatności przypada przed tym dniem, oraz ogólną sumę 
niezapłaconych odsetek od tych obligacji; 
- 2) ogólną sumę obligacji oraz odsetek płatnych po dniu ogłoszenia upadłości. 

©Kancelaria Sejmu 
 
 
 
s. 197/224 
 
2025-09-11 
 
2. W zgłoszeniu należy wymienić składniki majątku emitenta, na których 
ustanowiono zabezpieczenie praw obligatariuszy.

***
## Art. 488. {#art-488}

1. Przedmiot zabezpieczenia praw z obligacji tworzy osobną masę 
upadłości przeznaczoną na zaspokojenie praw obligatariuszy. 
2. Likwidację osobnej masy upadłości przeprowadza syndyk z udziałem 
kuratora. 
3. W razie wyrażenia zgody przez radę wierzycieli lub sędziego-komisarza na 
sprzedaż z wolnej ręki mienia wchodzącego w skład osobnej masy upadłości sprzedaż 
wymaga zgody kuratora.

***
## Art. 489. {#art-489}

Z osobnej masy upadłości zaspokaja się kolejno: 
- 1) koszty likwidacji tej masy, które obejmują także wynagrodzenie kuratora; 
- 2) należności obligatariuszy w nominalnej ich cenie; 
- 3) odsetki (kupony).

***
## Art. 490. {#art-490}

Jeżeli osobna masa upadłości nie wystarczy na pełne zaspokojenie 
należności obligatariuszy, należności niezaspokojone podlegają zaspokojeniu 
z funduszu masy upadłości.

***
## Art. 491. {#art-491}

Nie można wprowadzać do obiegu obligacji emitowanych przez 
upadłego, które są jego własnością. Obligacje takie podlegają umorzeniu. 
TYTUŁ V 
Postępowanie upadłościowe wobec osób fizycznych nieprowadzących 
działalności gospodarczej

***
## Art. 4911. {#art-4911}

1. Przepisy niniejszego tytułu stosuje się wobec osób fizycznych, 
których upadłości nie można ogłosić zgodnie z przepisami działu II tytułu I części 
pierwszej. 
2. W postanowieniu o ogłoszeniu upadłości sąd może postanowić, że 
postępowanie upadłościowe wobec osób, o których mowa w ust. 1, będzie 
prowadzone zgodnie z przepisami części pierwszej, jeżeli jest to uzasadnione 
znacznym rozmiarem majątku dłużnika, znaczną liczbą wierzycieli lub innymi 
uzasadnionymi przewidywaniami co do zwiększonego stopnia skomplikowania 
postępowania. Na postanowienie o prowadzeniu postępowania upadłościowego 
zgodnie z przepisami części pierwszej przysługuje zażalenie. 

©Kancelaria Sejmu 
 
 
 
s. 198/224 
 
2025-09-11 
 
3. W postępowaniu, o którym mowa w ust. 2, stosuje się przepisy art. 4917, 
art. 4918 i art. 49110. 
4. W postępowaniu, o którym mowa w ust. 2, przepis art. 361 stosuje się 
odpowiednio jedynie wówczas, gdy upadłość została ogłoszona wyłącznie na skutek 
uwzględnienia wniosku wierzyciela. Jeżeli upadłość nie została ogłoszona wyłącznie 
na skutek uwzględnienia wniosku wierzyciela, sąd stwierdza zakończenie 
postępowania upadłościowego również w przypadku braku masy upadłości lub gdy po 
całkowitym zlikwidowaniu masy upadłości z uwagi na brak funduszów masy 
upadłości, które mogłyby podlegać podziałowi, nie został sporządzony ostateczny plan 
podziału.

***
## Art. 4912. {#art-4912}

1. W sprawach nieuregulowanych w niniejszym tytule przepisy 
o postępowaniu upadłościowym stosuje się odpowiednio, z tym że przepisów art. 21, 
art. 25, art. 145, art. 151–155, art. 163, art. 164, art. 168 ust. 1–3 i 5, art. 176 ust. 2, 
art. 244, art. 245, art. 253–264, art. 307 ust. 1, art. 337–339, art. 343 ust. 1a, 
art. 346 ust. 2 i art. 347–356 oraz art. 358–366 nie stosuje się. Przepisy art. 13, 
art. 22a, art. 32 ust. 5, art. 36–40 i art. 43 stosuje się odpowiednio jedynie wówczas, 
gdy wniosek o ogłoszenie upadłości złożył wyłącznie wierzyciel. Przepis 
art. 361 stosuje się odpowiednio jedynie wówczas, gdy upadłość została ogłoszona 
wyłącznie na skutek uwzględnienia wniosku wierzyciela. 
1a. W postępowaniu o ogłoszenie upadłości uczestnik postępowania może 
złożyć wniosek o zatwierdzenie warunków sprzedaży składników majątku o znacznej 
wartości. Przepisy art. 56a–56h stosuje się odpowiednio. 
2. Postępowanie upadłościowe w sprawach objętych przepisami niniejszego 
tytułu prowadzi się także wtedy, gdy dłużnik ma tylko jednego wierzyciela. 
3. Wniosek o ogłoszenie upadłości może zgłosić dłużnik, z uwzględnieniem 
przepisów art. 8 i art. 9. Do wniosku o ogłoszenie upadłości i innych pism 
procesowych oraz dokumentów składanych przez dłużnika stosuje się odpowiednio 
przepis art. 216aa. W przypadku, o którym mowa w art. 216aa ust. 1, wniosek 
o ogłoszenie upadłości składa się na formularzu. 
3a. Do doręczeń dokonywanych dłużnikowi przepisy art. 220 ust. 3, 4 i 6 stosuje 
się odpowiednio. 
4. Wniosek o ogłoszenie upadłości powinien zawierać: 

©Kancelaria Sejmu 
 
 
 
s. 199/224 
 
2025-09-11 
- 1) imię i nazwisko, miejsce zamieszkania, adres oraz numer PESEL dłużnika, 
a jeżeli dłużnik nie posiada numeru PESEL – inne dane umożliwiające jego 
jednoznaczną identyfikację; 
1a) NIP dłużnika, jeżeli dłużnik miał taki numer w ciągu ostatnich dziesięciu lat 
przed dniem złożenia wniosku; 
- 2) wskazanie miejsc, w których znajduje się majątek dłużnika; 
- 3) wskazanie okoliczności, które uzasadniają wniosek i ich uprawdopodobnienie; 
- 4) aktualny i zupełny wykaz majątku z szacunkową wyceną jego składników; 
- 5) spis wierzycieli z podaniem ich adresów i wysokości wierzytelności każdego 
z nich oraz terminów zapłaty; 
- 6) spis wierzytelności spornych z zaznaczeniem zakresu w jakim dłużnik 
kwestionuje istnienie wierzytelności; wskazanie wierzytelności w spisie 
wierzytelności spornych nie stanowi jej uznania; 
- 7) listę zabezpieczeń ustanowionych na majątku dłużnika wraz z datami ich 
ustanowienia, w szczególności hipotek, zastawów i zastawów rejestrowych; 
- 8) informację o osiągniętych przychodach oraz o kosztach poniesionych na swoje 
utrzymanie oraz osób pozostających na utrzymaniu dłużnika, w ostatnich sześciu 
miesiącach przed dniem złożenia wniosku; 
- 9) informację o czynnościach prawnych dokonanych przez dłużnika w ostatnich 
dwunastu miesiącach przed dniem złożenia wniosku, których przedmiotem były 
nieruchomości, akcje lub udziały w spółkach; 
- 10) informację o czynnościach prawnych dokonanych przez dłużnika w ostatnich 
dwunastu miesiącach przed dniem złożenia wniosku, których przedmiotem były 
ruchomości, wierzytelności lub inne prawa, których wartość przekracza 
10 000 zł; 
- 11) oświadczenie o prawdziwości danych zawartych we wniosku. 
5. Jeżeli wniosek o ogłoszenie upadłości zgłasza wierzyciel, przepisów 
ust. 4 pkt 2 i 4–11 nie stosuje się. Przed wydaniem orzeczenia w przedmiocie 
ogłoszenia upadłości sąd może zobowiązać dłużnika do przedstawienia informacji, 
o których mowa w ust. 4, w terminie dwóch tygodni. 
5a. Wartość, o której mowa w ust. 4 pkt 10, ustala się dla wszystkich czynności 
dotyczących tego samego prawa lub wierzytelności, dokonanych przez dłużnika 
w ostatnich dwunastu miesiącach przed dniem złożenia wniosku. 

©Kancelaria Sejmu 
 
 
 
s. 200/224 
 
2025-09-11 
 
5b. Jeżeli oświadczenie, o którym mowa w ust. 4 pkt 11, nie jest zgodne 
z prawdą, dłużnik ponosi odpowiedzialność za szkodę wyrządzoną na skutek podania 
nieprawdziwych danych we wniosku o ogłoszenie upadłości. 
5c. Przez inne dane umożliwiające jednoznaczną identyfikację, o których mowa 
w ust. 4 pkt 1, rozumie się w szczególności numer paszportu i oznaczenie państwa 
wystawiającego paszport albo numer karty pobytu w Rzeczypospolitej Polskiej, albo 
numer w zagranicznym rejestrze, albo zagraniczny numer identyfikacji lub 
identyfikacji podatkowej. 
6. Minister 
Sprawiedliwości 
określi, 
w drodze 
rozporządzenia, 
wzory 
formularzy wniosku o ogłoszenie upadłości, mając na uwadze podmiot, który składa 
wniosek, oraz zakres informacji, których umieszczenie we wniosku jest niezbędne.

***
## Art. 4913. {#art-4913}

Sprawy o ogłoszenie upadłości objęte przepisami niniejszego tytułu 
rozpoznaje sąd upadłościowy w składzie jednego sędziego zawodowego.

***
## Art. 4914. {#art-4914}

(uchylony)

***
## Art. 4915. {#art-4915}

1. Uwzględniając wniosek o ogłoszenie upadłości, sąd wydaje 
postanowienie o ogłoszeniu upadłości, w którym: 
- 1) wymienia imię i nazwisko, miejsce zamieszkania, adres oraz numer PESEL 
dłużnika (upadłego), a jeżeli upadły nie posiada numeru PESEL – inne dane 
umożliwiające jego jednoznaczną identyfikację; 
1a) wymienia NIP, jeżeli upadły miał taki numer w ciągu ostatnich dziesięciu lat 
przed dniem złożenia wniosku; 
- 2) określa, że upadły jest osobą nieprowadzącą działalności gospodarczej; 
- 3) wzywa wierzycieli upadłego do zgłoszenia wierzytelności syndykowi za 
pośrednictwem systemu teleinformatycznego obsługującego postępowanie 
sądowe, w terminie trzydziestu dni od dnia obwieszczenia postanowienia 
o ogłoszeniu upadłości w Rejestrze; dla wierzycieli, o których mowa 
w art. 216aa ust. 1, wskazuje adres do zgłoszenia wierzytelności syndykowi; 
- 4) wzywa osoby, którym przysługują prawa oraz prawa i roszczenia osobiste 
ciążące na nieruchomości należącej do upadłego, jeżeli nie zostały ujawnione 
przez wpis w księdze wieczystej, do ich zgłaszania syndykowi za pośrednictwem 
systemu teleinformatycznego obsługującego postępowanie sądowe w terminie 
trzydziestu dni od dnia obwieszczenia postanowienia o ogłoszeniu upadłości 
w Rejestrze pod rygorem utraty prawa powoływania się na nie w postępowaniu 

©Kancelaria Sejmu 
 
 
 
s. 201/224 
 
2025-09-11 
 
upadłościowym; dla wierzycieli, o których mowa w art. 216aa ust. 1, wskazuje 
adres do zgłoszenia praw oraz praw osobistych i roszczeń ciążących na 
nieruchomości syndykowi; 
- 5) wyznacza syndyka; 
- 6) określa, czy postępowanie upadłościowe będzie prowadzone w trybie 
określonym w art. 4911 ust. 1 czy 2; 
- 7) jeżeli postępowanie upadłościowe będzie prowadzone w trybie określonym 
w art. 4911 ust. 2, w postanowieniu o ogłoszeniu upadłości sąd określa również, 
czy funkcje sędziego-komisarza oraz zastępcy sędziego-komisarza będzie pełnił 
sędzia czy referendarz sądowy. 
2. O prowadzeniu 
postępowania 
upadłościowego 
w trybie 
określonym 
w art. 4911 ust. 2 sąd może postanowić również po ogłoszeniu upadłości. Na 
postanowienie o prowadzeniu postępowania upadłościowego w trybie określonym 
w art. 4911 ust. 2 przysługuje zażalenie. Postanowienie w przedmiocie trybu 
prowadzenia postępowania upadłościowego obwieszcza się. 
3. Jeżeli postępowanie jest prowadzone w trybie określonym w art. 4911 ust. 1, 
a do wykonania określonej czynności właściwy jest sędzia-komisarz, to czynność tę 
wykonuje jako sędzia-komisarz wyznaczony sędzia, do którego przepisy 
o czynnościach sędziego-komisarza stosuje się odpowiednio. 
4. Przez inne dane umożliwiające jednoznaczną identyfikację, o których mowa 
w ust. 1 pkt 1, rozumie się dane, o których mowa w art. 4912 ust. 5c.

***
## Art. 4916. {#art-4916}

1. Postanowienie o ogłoszeniu upadłości doręcza się również 
syndykowi. 
2. O ogłoszeniu upadłości powiadamia się właściwą izbę administracji 
skarbowej oraz właściwy oddział Zakładu Ubezpieczeń Społecznych lub Kasy 
Rolniczego Ubezpieczenia Społecznego. 
Art. 4916a. 1. W zawiadomieniu skierowanym do wierzycieli syndyk poucza ich 
o treści 
art. 54a, 
art. 216a–216ab, 
art. 235–237, 
art. 239a–241, 
art. 49112a, 
art. 49114 ust. 5, 6 i 8, art. 49114a i art. 49116, wskazuje sąd, do którego można 
zaskarżyć postanowienie o ogłoszeniu upadłości zgodnie z art. 54a ust. 1, imię 
i nazwisko albo nazwę syndyka, adres, na który należy dokonać zgłoszenia 
wierzytelności, o której mowa w art. 216aa ust. 1, termin, w którym należy dokonać 
zgłoszenia wierzytelności, albo sposób obliczenia tego terminu oraz podaje numer 

©Kancelaria Sejmu 
 
 
 
s. 202/224 
 
2025-09-11 
 
rachunku bankowego, na który należy wpłacić zryczałtowane koszty, o których mowa 
w art. 235 ust. 1. 
2. W zawiadomieniu skierowanym do małżonka dłużnika syndyk poucza go 
o treści art. 124–126, art. 49114 ust. 5, 6 i 8, art. 49114a i art. 49116.

***
## Art. 4917. {#art-4917}

1. W przypadku, gdy majątek niewypłacalnego dłużnika nie 
wystarcza na pokrycie kosztów postępowania albo w masie upadłości brak jest 
płynnych funduszów na ich pokrycie, koszty te pokrywa tymczasowo Skarb Państwa. 
2. (uchylony) 
3. Jednocześnie z ogłoszeniem upadłości sąd przyznaje syndykowi zaliczkę na 
pokrycie kosztów postępowania oraz zarządza jej niezwłoczną wypłatę tymczasowo 
ze środków Skarbu Państwa, chyba że majątek upadłego pozwala na bieżące 
pokrywanie kosztów postępowania. W dalszym toku postępowania, w razie potrzeby, 
sąd przyznaje syndykowi zaliczkę na pokrycie kosztów postępowania oraz zarządza 
jej niezwłoczną wypłatę tymczasowo ze środków Skarbu Państwa. 
4. Syndyk zwraca Skarbowi Państwa wypłacone kwoty niezwłocznie po wpływie 
do masy upadłości funduszów wystarczających na pokrycie kosztów postępowania. 
5. W przypadku postępowania wszczętego wyłącznie na wniosek wierzyciela 
przepisów ust. 1 i 3 nie stosuje się, jeżeli dłużnik nie sprzeciwia się umorzeniu 
postępowania. Przed umorzeniem postępowania sąd wysłuchuje dłużnika.

***
## Art. 4918. {#art-4918}

1. Po ogłoszeniu upadłości syndyk zwraca się do naczelnika urzędu 
skarbowego właściwego dla upadłego z wnioskiem o udzielenie informacji 
dotyczących upadłego, mających wpływ na ocenę jego sytuacji majątkowej, w szcze-
gólności dotyczących okoliczności powodujących powstanie po stronie upadłego 
obowiązku podatkowego w okresie pięciu lat przed dniem zgłoszenia wniosku 
o ogłoszenie upadłości, oraz zasięga informacji w Krajowym Rejestrze Sądowym, czy 
upadły jest wspólnikiem spółek handlowych, jak również czy w okresie dziesięciu lat 
przed dniem zgłoszenia wniosku o ogłoszenie upadłości sprawował funkcję członka 
organu spółek handlowych i czy w stosunku do tych spółek ogłoszono upadłość. 
2. Syndyk informuje sędziego-komisarza o niezgodności informacji uzyskanych 
w sposób, o którym mowa w ust. 1, z danymi podanymi przez upadłego we wniosku 
o ogłoszenie upadłości.

***
## Art. 4919. {#art-4919}

1. Sąd ustala wynagrodzenie syndyka w postępowaniu prowadzonym 
według przepisów niniejszego tytułu biorąc pod uwagę wysokość funduszów masy 

©Kancelaria Sejmu 
 
 
 
s. 203/224 
 
2025-09-11 
 
upadłości, stopień zaspokojenia wierzycieli, nakład pracy, zakres czynności 
podejmowanych w postępowaniu, stopień ich trudności oraz czas trwania 
postępowania. 
2. Wynagrodzenie syndyka ustala się w wysokości od jednej czwartej 
przeciętnego miesięcznego wynagrodzenia w sektorze przedsiębiorstw bez wypłat 
nagród z zysku w czwartym kwartale roku poprzedniego, ogłoszonego przez Prezesa 
Głównego Urzędu Statystycznego do jego dwukrotności. 
3. W szczególnie uzasadnionych przypadkach sąd może ustalić wynagrodzenie 
syndyka w wysokości do czterokrotności przeciętnego miesięcznego wynagrodzenia, 
o którym mowa w ust. 2, jeżeli jest to uzasadnione zwiększonym nakładem pracy 
syndyka wynikającym w szczególności ze stopnia skomplikowania postępowania oraz 
liczby wierzycieli. 
4. W przedmiocie wynagrodzenia syndyka oraz zwrotu jego wydatków orzeka 
sąd upadłościowy w składzie jednego sędziego zawodowego.

***
## Art. 49110. {#art-49110}

1. Sąd umarza postępowanie na wniosek upadłego. 
2. Jeżeli upadły nie wskaże lub nie wyda syndykowi całego majątku, 
niezbędnych dokumentów lub w inny sposób nie wykonuje ciążących na nim 
obowiązków, sąd, z urzędu albo na wniosek syndyka lub wierzyciela, po wysłuchaniu 
upadłego, syndyka, a w razie potrzeby także wierzycieli, umarza postępowanie, chyba 
że uchybienie przez upadłego ciążącym na nim obowiązkom nie jest istotne lub 
przeprowadzenie postępowania jest uzasadnione względami słuszności lub względami 
humanitarnymi. 
2a. Sąd umarza postępowanie, jeżeli zostanie ujawnione, że dane podane przez 
dłużnika we wniosku o ogłoszenie upadłości są niezgodne z prawdą lub niezupełne, 
chyba że niezgodność lub niezupełność nie są istotne lub przeprowadzenie 
postępowania jest uzasadnione względami słuszności lub względami humanitarnymi. 
3. Sąd nie umarza postępowania, jeżeli umorzenie postępowania mogłoby 
skutkować pokrzywdzeniem wierzycieli. 
4. Na postanowienie w przedmiocie umorzenia postępowania przysługuje 
zażalenie. 
5. Do postępowania wszczętego na wniosek wierzyciela przepisów ust. 1 i 2 nie 
stosuje się.

***
## Art. 49111. {#art-49111}

(uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 204/224 
 
2025-09-11 
 
Art. 49111a. 1. Wyboru sposobu likwidacji masy upadłości dokonuje 
samodzielnie syndyk w sposób, który umożliwia zaspokojenie wierzycieli w jak 
największym stopniu, z uwzględnieniem kosztów likwidacji. 
2. O wyborze sposobu likwidacji nieruchomości oraz wyborze sposobu 
likwidacji składników masy upadłości, których wartość oszacowania wskazana 
w spisie 
inwentarza 
przekracza 
pięciokrotność 
przeciętnego 
miesięcznego 
wynagrodzenia w sektorze przedsiębiorstw bez wypłat nagród z zysku w trzecim 
kwartale roku poprzedzającego złożenie spisu inwentarza, ogłoszonego przez Prezesa 
Głównego Urzędu Statystycznego, syndyk zawiadamia wierzycieli oraz sąd za 
pośrednictwem systemu teleinformatycznego obsługującego postępowanie sądowe 
z wykorzystaniem udostępnianych w tym systemie formularzy. W zawiadomieniu 
syndyk wskazuje sposób likwidacji oraz minimalną cenę. 
3. Na skutek skargi na czynności syndyka, o której mowa w art. 49112a, lub 
z urzędu sąd, w drodze postanowienia, zakazuje syndykowi dokonania likwidacji 
składnika masy upadłości w wybrany przez syndyka sposób lub za wskazaną 
minimalną cenę, jeżeli likwidacja byłaby niezgodna z prawem albo prowadziłaby do 
pokrzywdzenia upadłego lub wierzycieli. 
4. Przed wydaniem postanowienia, o którym mowa w ust. 3, sąd może 
wstrzymać dokonanie likwidacji składnika masy upadłości. O wstrzymaniu likwidacji 
składnika masy upadłości sąd zawiadamia syndyka w dniu wydania postanowienia 
o wstrzymaniu likwidacji. 
5. W przypadku braku wstrzymania lub zakazu likwidacji składnika masy 
upadłości likwidacja może nastąpić po upływie czternastu dni od dnia zawiadomienia, 
o którym mowa w ust. 2.

***
## Art. 49112. {#art-49112}

Syndyk może pisemnie upoważnić upadłego do sprzedaży 
ruchomości należących do masy upadłości. Do upoważnienia stosuje się odpowiednio 
przepisy o pełnomocnictwie. 
Art. 49112a. 1. 
Na 
czynności 
syndyka 
przysługuje 
skarga 
do 
sądu 
upadłościowego. Dotyczy to także zaniechania przez syndyka dokonania czynności. 
2. Skargę może złożyć upadły, wierzyciel lub inna osoba, której prawo zostało 
przez czynności lub zaniechanie syndyka naruszone albo zagrożone. 

©Kancelaria Sejmu 
 
 
 
s. 205/224 
 
2025-09-11 
 
3. Skarga powinna czynić zadość wymaganiom pisma procesowego oraz 
określać zaskarżoną czynność lub czynność, której zaniechano, jak również wniosek 
o zmianę, uchylenie lub dokonanie czynności, wraz z uzasadnieniem. 
4. Skargę wnosi się w terminie siedmiu dni od dnia dokonania czynności, gdy 
upadły, wierzyciel lub osoba, której prawo zostało przez czynność syndyka naruszone 
albo zagrożone, była przy czynności obecna lub była o jej terminie zawiadomiona; 
w innych przypadkach – od dnia zawiadomienia o dokonaniu czynności upadłego, 
wierzyciela lub osoby, której prawo zostało przez czynność syndyka naruszone albo 
zagrożone, a w braku zawiadomienia – od dnia powzięcia wiadomości przez 
skarżącego o dokonanej czynności. Skargę na zaniechanie przez syndyka dokonania 
czynności wnosi się w terminie siedmiu dni od dnia, w którym skarżący dowiedział 
się, że czynność miała być dokonana. 
5. Skargę wnosi się do syndyka, który dokonał zaskarżonej czynności lub 
zaniechał jej dokonania. Syndyk w terminie trzech dni od dnia otrzymania skargi 
sporządza uzasadnienie zaskarżonej czynności, o ile nie zostało ono sporządzone 
wcześniej, albo przyczyn jej zaniechania i przekazuje je wraz ze skargą do właściwego 
sądu upadłościowego, chyba że skargę w całości uwzględnia. O uwzględnieniu skargi 
syndyk zawiadamia skarżącego oraz zainteresowanych, których uwzględnienie skargi 
dotyczy, 
za 
pośrednictwem 
systemu 
teleinformatycznego 
obsługującego 
postępowanie sądowe z wykorzystaniem udostępnianych w tym systemie formularzy. 
6. Sąd rozpoznaje skargę w terminie siedmiu dni od dnia jej wpływu do sądu, 
a gdy skarga zawiera braki formalne, które podlegają uzupełnieniu – od dnia jej 
uzupełnienia. 
7. Wniesienie skargi nie wstrzymuje postępowania upadłościowego ani 
dokonania zaskarżonej czynności, chyba że sąd wstrzyma dokonanie czynności. 
8. Sąd odrzuca skargę wniesioną po upływie przepisanego terminu, nieopłaconą 
lub z innych przyczyn niedopuszczalną, jak również skargę, której braków nie 
uzupełniono w terminie. Na postanowienie sądu o odrzuceniu skargi służy zażalenie. 
9. W razie odrzucenia skargi sąd z urzędu bierze pod uwagę okoliczności 
wskazane w skardze i w razie potrzeby wydaje syndykowi polecenie dokonania 
odpowiednich czynności lub zakazuje syndykowi dokonania określonych czynności.

***
## Art. 49113. {#art-49113}

(uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 206/224 
 
2025-09-11

***
## Art. 49114. {#art-49114}

1. 
Po 
upływie 
terminu 
do 
zgłaszania 
wierzytelności 
i przeprowadzeniu likwidacji majątku wchodzącego w skład masy upadłości syndyk 
składa sądowi projekt planu spłaty wierzycieli z uzasadnieniem albo informację, że 
zachodzą przesłanki, o których mowa w art. 49114a ust. 1 lub art. 49116 ust. 1 lub 2a. 
2. W przypadku postępowania wszczętego wyłącznie na wniosek wierzyciela 
syndyk składa sądowi projekt planu spłaty wierzycieli z uzasadnieniem albo 
informację, że zachodzą przesłanki, o których mowa w art. 49114a ust. 1 lub art. 49116 
ust. 1 lub 2a, chyba że dłużnik na wezwanie syndyka oświadczy, że nie wnosi 
o sporządzenie planu spłaty wierzycieli ani o umorzenie zobowiązań bez ustalenia 
planu spłaty wierzycieli lub o warunkowe umorzenie zobowiązań upadłego bez 
ustalenia planu spłaty wierzycieli. Jeżeli dłużnik na wezwanie syndyka oświadczy, że 
nie wnosi o sporządzenie planu spłaty wierzycieli ani o umorzenie zobowiązań bez 
ustalenia planu spłaty wierzycieli lub o warunkowe umorzenie zobowiązań upadłego 
bez ustalenia planu spłaty wierzycieli, sąd wydaje postanowienie o zakończeniu 
postępowania. 
3. Do projektu planu spłaty wierzycieli z uzasadnieniem albo informacji, że 
zachodzą przesłanki, o których mowa w art. 49114a ust. 1 lub art. 49116 ust. 1 lub 2a, 
syndyk załącza: 
- 1) dowody doręczenia upadłemu oraz wierzycielom projektu planu spłaty 
wierzycieli z uzasadnieniem albo informacji, że zachodzą przesłanki, o których 
mowa w art. 49114a ust. 1 lub art. 49116 ust. 1 lub 2a, wraz z pouczeniem o treści 
ust. 4 i zobowiązaniem do złożenia stanowiska, o którym mowa w pkt 2, 
w terminie czternastu dni; 
- 2) stanowiska upadłego oraz wierzycieli albo informację, że upadły lub wierzyciele 
nie złożyli stanowiska wraz z podaniem przyczyny jego niezłożenia. 
4. Sąd ustala plan spłaty wierzycieli albo w przypadku, o którym mowa 
w art. 49116 ust. 1 lub 2a, umarza zobowiązania upadłego bez ustalenia planu spłaty 
wierzycieli lub warunkowo umarza zobowiązania upadłego bez ustalenia planu spłaty 
wierzycieli albo wydaje postanowienie, o którym mowa w art. 49114a ust. 1, po 
przeprowadzeniu rozprawy, jeżeli upadły, syndyk lub wierzyciel złożył wniosek 
o przeprowadzenie rozprawy. O terminie rozprawy zawiadamia się upadłego 
i syndyka oraz wierzyciela, który złożył wniosek o przeprowadzenie rozprawy. 
5. W przypadku braku zgłoszeń wierzytelności i braku wierzytelności, które 
w postępowaniu upadłościowym prowadzonym zgodnie z przepisami części pierwszej 

©Kancelaria Sejmu 
 
 
 
s. 207/224 
 
2025-09-11 
 
podlegałyby z urzędu umieszczeniu na liście wierzytelności, sąd, po upływie terminu 
do zgłoszenia wierzytelności, wydaje postanowienie o umorzeniu zobowiązań 
upadłego bez ustalenia planu spłaty wierzycieli, chyba że w toku postępowania nie 
zostały zaspokojone koszty tego postępowania tymczasowo pokryte przez Skarb 
Państwa lub inne zobowiązania masy upadłości. 
6. Zgłoszenie wierzytelności dokonane po złożeniu przez syndyka projektu planu 
spłaty wierzycieli z uzasadnieniem albo informacji, że zachodzą przesłanki, o których 
mowa w art. 49114a ust. 1 lub art. 49116 ust. 1 lub 2a, pozostawia się bez rozpoznania. 
7. Postanowienie w przedmiocie ustalenia planu spłaty wierzycieli albo 
w przedmiocie umorzenia zobowiązań upadłego bez ustalenia planu spłaty wierzycieli 
lub w przedmiocie warunkowego umorzenia zobowiązań upadłego bez ustalenia planu 
spłaty wierzycieli oraz informację o prawomocności tych postanowień obwieszcza się. 
Na postanowienie sądu w przedmiocie ustalenia planu spłaty wierzycieli albo 
w przedmiocie umorzenia zobowiązań upadłego bez ustalenia planu spłaty wierzycieli 
lub w przedmiocie warunkowego umorzenia zobowiązań upadłego bez ustalenia planu 
spłaty wierzycieli przysługuje zażalenie. Postanowienie sądu drugiej instancji 
w przedmiocie rozpoznania zażalenia oraz informację o prawomocności tego 
postanowienia obwieszcza się. 
8. Wydanie postanowienia o ustaleniu planu spłaty wierzycieli albo umorzeniu 
zobowiązań upadłego bez ustalenia planu spłaty wierzycieli lub warunkowym 
umorzeniu zobowiązań upadłego bez ustalenia planu spłaty wierzycieli oznacza 
zakończenie postępowania. 
Art. 49114a. 1. Sąd wydaje postanowienie o odmowie ustalenia planu spłaty 
wierzycieli albo umorzenia zobowiązań upadłego bez ustalenia planu spłaty 
wierzycieli lub warunkowego umorzenia zobowiązań upadłego bez ustalenia planu 
spłaty wierzycieli, jeżeli: 
- 1) upadły doprowadził do swojej niewypłacalności lub istotnie zwiększył jej stopień 
w sposób celowy, w szczególności przez trwonienie części składowych majątku 
oraz celowe nieregulowanie wymagalnych zobowiązań, 
- 2) w okresie dziesięciu lat przed dniem zgłoszenia wniosku o ogłoszenie upadłości 
w stosunku do upadłego prowadzono postępowanie upadłościowe, w którym 
umorzono całość lub część jego zobowiązań 
– chyba że ustalenie planu spłaty wierzycieli lub umorzenie zobowiązań upadłego bez 
ustalenia planu spłaty wierzycieli lub warunkowe umorzenie zobowiązań upadłego 

©Kancelaria Sejmu 
 
 
 
s. 208/224 
 
2025-09-11 
 
bez ustalenia planu spłaty wierzycieli jest uzasadnione względami słuszności lub 
względami humanitarnymi. 
2. Jeżeli w przypadku, o którym mowa w ust. 1, w postępowaniu zgromadzono 
fundusze masy upadłości, sąd wydaje postanowienie o ustaleniu planu spłaty 
wierzycieli, w którym wymienia wierzycieli uczestniczących w planie spłaty, oraz 
dokonuje podziału funduszy masy upadłości między wierzycieli uczestniczących 
w planie spłaty. Przepisu art. 49121 nie stosuje się. 
3. Wydanie postanowienia o odmowie ustalenia planu spłaty wierzycieli oznacza 
zakończenie postępowania.

***
## Art. 49115. {#art-49115}

1. W postanowieniu o ustaleniu planu spłaty wierzycieli sąd: 
- 1) wymienia wierzycieli uczestniczących w planie spłaty; 
- 2) dokonuje 
podziału 
funduszy 
masy 
upadłości 
pomiędzy 
wierzycieli 
uczestniczących w planie spłaty, jeżeli w postępowaniu zgromadzono fundusze 
masy upadłości; 
- 3) ustala, czy upadły doprowadził do swojej niewypłacalności lub istotnie 
zwiększył jej stopień umyślnie lub wskutek rażącego niedbalstwa; 
- 4) określa, w jakim zakresie i okresie, nie dłuższym niż trzydzieści sześć miesięcy, 
upadły jest obowiązany spłacać zobowiązania, które w postępowaniu 
upadłościowym prowadzonym zgodnie z przepisami części pierwszej zostałyby 
uznane na liście wierzytelności, oraz jaka część zobowiązań upadłego 
powstałych przed dniem ogłoszenia upadłości zostanie umorzona po wykonaniu 
planu spłaty wierzycieli. 
1a. W przypadku ustalenia, że upadły doprowadził do swojej niewypłacalności 
lub istotnie zwiększył jej stopień umyślnie lub wskutek rażącego niedbalstwa, plan 
spłaty wierzycieli nie może być ustalony na okres krótszy niż trzydzieści sześć 
miesięcy ani dłuższy niż osiemdziesiąt cztery miesiące. 
1b. W przypadku gdy w drodze wykonania planu spłaty wierzycieli dłużnik 
spłaci co najmniej 70 % zobowiązań objętych planem spłaty wierzycieli, które 
w postępowaniu upadłościowym prowadzonym zgodnie z przepisami części pierwszej 
zostałyby uznane na liście wierzytelności, plan spłaty wierzycieli nie może zostać 
ustalony na okres dłuższy niż rok. 
1c. W przypadku gdy w drodze wykonania planu spłaty wierzycieli dłużnik 
spłaci co najmniej 50 % zobowiązań objętych planem spłaty wierzycieli, które 
w postępowaniu upadłościowym prowadzonym zgodnie z przepisami części pierwszej 

©Kancelaria Sejmu 
 
 
 
s. 209/224 
 
2025-09-11 
 
zostałyby uznane na liście wierzytelności, plan spłaty wierzycieli nie może zostać 
ustalony na okres dłuższy niż dwa lata. 
1d. Do okresów spłaty, o których mowa w ust. 1 pkt 4 oraz ust. 1a–1c, zalicza się 
okres od upływu sześciu miesięcy od dnia ogłoszenia upadłości do dnia ustalenia planu 
spłaty wierzycieli, chyba że dłużnik nie pokryłby w całości kosztów postępowania 
tymczasowo poniesionych przez Skarb Państwa. Do okresu spłaty nie zalicza się 
okresu warunkowego umorzenia zobowiązań upadłego bez ustalenia planu spłaty 
wierzycieli. 
2. Koszty postępowania tymczasowo pokryte przez Skarb Państwa oraz inne 
zobowiązania masy upadłości niezaspokojone w toku postępowania uwzględnia się 
w planie spłaty wierzycieli w pełnej wysokości, chyba że możliwości zarobkowe 
upadłego, konieczność utrzymania upadłego i osób pozostających na jego utrzymaniu 
oraz ich potrzeby mieszkaniowe nie pozwalają na zaspokojenie kosztów postępowania 
tymczasowo pokrytych przez Skarb Państwa oraz innych zobowiązań masy upadłości 
w pełnej wysokości. W przypadku braku zgłoszeń wierzytelności i braku wierzytel-
ności, które w postępowaniu upadłościowym prowadzonym zgodnie z przepisami 
części pierwszej podlegałyby z urzędu umieszczeniu na liście wierzytelności, w planie 
spłaty wierzycieli uwzględnia się wyłącznie zobowiązania, o których mowa w zdaniu 
poprzednim, a w przypadku braku takich zobowiązań umarza się zobowiązania 
upadłego bez ustalenia planu spłaty wierzycieli. 
3. Koszty 
postępowania 
tymczasowo 
pokryte 
przez 
Skarb 
Państwa 
nieuwzględnione w planie spłaty wierzycieli albo niezaspokojone w ramach 
wykonania planu spłaty wierzycieli ponosi Skarb Państwa. 
4. Sąd nie jest związany stanowiskiem upadłego oraz wierzycieli co do treści 
planu spłaty wierzycieli. Ustalając plan spłaty wierzycieli, sąd bierze pod uwagę 
możliwości zarobkowe upadłego, konieczność utrzymania upadłego i osób 
pozostających na jego utrzymaniu oraz ich potrzeby mieszkaniowe, wysokość 
niezaspokojonych 
wierzytelności 
oraz 
stopień 
zaspokojenia 
wierzytelności 
w postępowaniu upadłościowym. 
5. Ustalenie planu spłaty wierzycieli nie narusza praw wierzyciela wobec 
poręczyciela upadłego oraz współdłużnika upadłego ani praw wynikających 
z hipoteki, zastawu, zastawu rejestrowego, zastawu skarbowego oraz hipoteki 
morskiej, jeśli były one ustanowione na mieniu osoby trzeciej. Ustalenie planu spłaty 

©Kancelaria Sejmu 
 
 
 
s. 210/224 
 
2025-09-11 
 
wierzycieli i umorzenie zobowiązań upadłego jest skuteczne również w stosunkach 
pomiędzy upadłym, a poręczycielem, gwarantem i współdłużnikiem upadłego. 
6. W okresie wykonywania planu spłaty wierzycieli niedopuszczalne jest 
wszczęcie postępowania egzekucyjnego dotyczącego wierzytelności powstałych 
przed ustaleniem planu spłaty wierzycieli, z wyjątkiem wierzytelności wynikających 
z zobowiązań, o których mowa w art. 49121 ust. 2. 
7. Do planu spłaty wierzycieli oraz wykonania określonego w planie spłaty 
wierzycieli podziału funduszy masy upadłości stosuje się odpowiednio przepisy 
art. 313 ust. 2, art. 335, art. 336, art. 340–348 i art. 352–356 oraz art. 358–360. W 
zakresie, w jakim plan spłaty wierzycieli obejmuje podział funduszy masy upadłości 
zgromadzonych w postępowaniu upadłościowym, plan spłaty wierzycieli wykonuje 
syndyk niezwłocznie po uprawomocnieniu się postanowienia o ustaleniu planu spłaty 
wierzycieli.

***
## Art. 49116. {#art-49116}

1. Sąd umarza zobowiązania upadłego bez ustalenia planu spłaty 
wierzycieli, jeśli osobista sytuacja upadłego w oczywisty sposób wskazuje, że jest on 
trwale niezdolny do dokonywania jakichkolwiek spłat w ramach planu spłaty 
wierzycieli. 
1a. Jeżeli w przypadku, o którym mowa w ust. 1, w postępowaniu zgromadzono 
fundusze masy upadłości, sąd wydaje postanowienie o ustaleniu planu spłaty 
wierzycieli, w którym wymienia wierzycieli uczestniczących w planie spłaty, oraz 
dokonuje podziału funduszy masy upadłości między wierzycieli uczestniczących 
w planie spłaty i umarza zobowiązania upadłego niewykonane w wyniku wykonania 
planu spłaty wierzycieli. Plan spłaty wierzycieli obejmujący podział funduszy masy 
upadłości wykonuje syndyk. 
2. Umarzając zobowiązania upadłego bez ustalenia planu spłaty wierzycieli sąd 
obciąża Skarb Państwa tymczasowo pokrytymi kosztami postępowania. 
2a. Jeżeli niezdolność do dokonywania jakichkolwiek spłat w ramach planu 
spłaty wierzycieli wynikająca z osobistej sytuacji upadłego nie ma charakteru 
trwałego, sąd umarza zobowiązania upadłego bez ustalenia planu spłaty wierzycieli 
pod warunkiem, że w terminie pięciu lat od dnia uprawomocnienia się postanowienia 
o warunkowym umorzeniu zobowiązań upadłego bez ustalenia planu spłaty 
wierzycieli upadły ani żaden z wierzycieli nie złoży wniosku o ustalenie planu spłaty 
wierzycieli, na skutek którego sąd, uznając, że ustała niezdolność upadłego do 
dokonywania jakichkolwiek spłat w ramach planu spłaty wierzycieli, uchyli 

©Kancelaria Sejmu 
 
 
 
s. 211/224 
 
2025-09-11 
 
postanowienie o warunkowym umorzeniu zobowiązań upadłego bez ustalenia planu 
spłaty wierzycieli i ustali plan spłaty wierzycieli. Przepisy art. 49114 ust. 7 
i art. 49121 ust. 2 stosuje się. Przepis ust. 1a stosuje się odpowiednio. 
2b. Na podstawie złożonego w terminie, o którym mowa w ust. 2a, wniosku 
upadłego lub wierzyciela, o którym mowa w ust. 2a, sąd może uchylić postanowienie 
o warunkowym umorzeniu zobowiązań upadłego bez ustalenia planu spłaty 
wierzycieli i ustalić plan spłaty wierzycieli również po upływie pięciu lat od dnia 
uprawomocnienia się postanowienia o warunkowym umorzeniu zobowiązań upadłego 
bez ustalenia planu spłaty wierzycieli. 
2c. W okresie pięciu lat od dnia uprawomocnienia się postanowienia 
o warunkowym umorzeniu zobowiązań upadłego bez ustalenia planu spłaty 
wierzycieli upadły nie może dokonywać czynności prawnych, dotyczących jego 
majątku, które mogłyby pogorszyć jego sytuację majątkową. 
2d. W szczególnie uzasadnionych przypadkach sąd, na wniosek upadłego, może 
wyrazić zgodę na dokonanie czynności prawnej, o której mowa w ust. 2c, albo 
zatwierdzić jej dokonanie. 
2e. W okresie, o którym mowa w ust. 2c, upadły jest obowiązany składać sądowi 
corocznie, do końca kwietnia, sprawozdanie ze swojej sytuacji majątkowej 
i zawodowej za poprzedni rok kalendarzowy, w którym wykazuje osiągnięte 
przychody oraz nabyte składniki majątkowe o wartości przekraczającej przeciętne 
miesięczne wynagrodzenie w sektorze przedsiębiorstw bez wypłat nagród z zysku za 
ostatni kwartał okresu sprawozdawczego, ogłoszone przez Prezesa Głównego Urzędu 
Statystycznego, jak również swoje możliwości zarobkowe, wydatki potrzebne na 
swoje utrzymanie i osób pozostających na jego utrzymaniu, w tym potrzeby 
mieszkaniowe. Do sprawozdania upadły dołącza kopię złożonego rocznego zeznania 
podatkowego. 
2f. W okresie, o którym mowa w ust. 2c, przepis art. 49115 ust. 6 stosuje się 
odpowiednio. 
2g. Sąd uchyla postanowienie o warunkowym umorzeniu zobowiązań upadłego 
bez ustalenia planu spłaty wierzycieli, gdy w okresie, o którym mowa w ust. 2c, 
upadły: 
- 1) nie złożył w terminie sprawozdania, o którym mowa w ust. 2e, 
- 2) w sprawozdaniu, o którym mowa w ust. 2e, podał nieprawdziwe informacje, 
w szczególności zataił osiągnięte przychody lub nabyte składniki majątkowe, 

©Kancelaria Sejmu 
 
 
 
s. 212/224 
 
2025-09-11 
- 3) dokonał czynności prawnej, o której mowa w ust. 2c, bez uzyskania zgody sądu 
albo czynność ta nie została przez sąd zatwierdzona, 
- 4) ukrywał majątek lub czynność prawna upadłego została prawomocnie uznana za 
dokonaną z pokrzywdzeniem wierzycieli 
– chyba że uchybienie obowiązkom jest nieznaczne lub zaniechanie uchylenia 
postanowienia o warunkowym umorzeniu zobowiązań upadłego bez ustalenia planu 
spłaty wierzycieli jest uzasadnione względami słuszności lub względami 
humanitarnymi; przepis art. 49114 ust. 7 stosuje się. 
2h. W razie uchylenia postanowienia o warunkowym umorzeniu zobowiązań 
upadłego bez ustalenia planu spłaty wierzycieli zobowiązania upadłego nie podlegają 
umorzeniu. 
2i. Jeżeli upadły ani żaden z wierzycieli nie złoży wniosku, o którym mowa 
w ust. 2a, zobowiązania upadłego ulegają umorzeniu z upływem pięciu lat od dnia 
uprawomocnienia się postanowienia o warunkowym umorzeniu zobowiązań upadłego 
bez ustalenia planu spłaty wierzycieli. Na wniosek upadłego lub wierzyciela sąd 
wydaje postanowienie stwierdzające umorzenie zobowiązań upadłego bez ustalenia 
planu spłaty wierzycieli. W postanowieniu sąd wskazuje datę umorzenia zobowiązań 
upadłego. 
3. Przepisy art. 49121 ust. 2 i 3 stosuje się odpowiednio.

***
## Art. 49117. {#art-49117}

1. Od postanowienia sądu drugiej instancji w przedmiocie ustalenia 
planu spłaty wierzycieli albo w przedmiocie umorzenia zobowiązań upadłego bez 
ustalenia planu spłaty wierzycieli lub w przedmiocie warunkowego umorzenia 
zobowiązań upadłego bez ustalenia planu spłaty wierzycieli przysługuje skarga 
kasacyjna. 
2. W przypadku wniesienia skargi kasacyjnej, na wniosek skarżącego sąd może 
wstrzymać wydanie postanowienia, o którym mowa w art. 49121 ust. 1. 
3. Jeżeli w wyniku rozpoznania skargi kasacyjnej postanowienie o ustaleniu 
planu spłaty wierzycieli zostanie uchylone, sąd uchyla postanowienie, o którym mowa 
w art. 49121 ust. 1. 
4. Postanowienie Sądu Najwyższego w przedmiocie rozpoznania skargi 
kasacyjnej obwieszcza się. 

©Kancelaria Sejmu 
 
 
 
s. 213/224 
 
2025-09-11

***
## Art. 49118. {#art-49118}

1. W okresie wykonywania planu spłaty wierzycieli upadły nie może 
dokonywać czynności prawnych, dotyczących jego majątku, które mogłyby pogorszyć 
jego zdolność do wykonania planu spłaty wierzycieli. 
2. W szczególnie uzasadnionych przypadkach sąd, na wniosek upadłego, może 
wyrazić zgodę na dokonanie albo zatwierdzić dokonanie czynności prawnej, o której 
mowa w ust. 1. 
3. Upadły jest obowiązany składać sądowi corocznie, do końca kwietnia, 
sprawozdanie z wykonania planu spłaty wierzycieli za poprzedni rok kalendarzowy, 
w którym wykazuje osiągnięte przychody, spłacone kwoty oraz nabyte składniki 
majątkowe o wartości przekraczającej przeciętne miesięczne wynagrodzenie 
w sektorze przedsiębiorstw bez wypłat nagród z zysku za ostatni kwartał okresu 
sprawozdawczego, ogłoszone przez Prezesa Głównego Urzędu Statystycznego. Do 
sprawozdania upadły dołącza kopię złożonego rocznego zeznania podatkowego.

***
## Art. 49119. {#art-49119}

1. Jeżeli upadły nie może wywiązać się z obowiązków określonych 
w planie spłaty wierzycieli, sąd na jego wniosek, po wysłuchaniu wierzycieli, może 
zmienić plan spłaty wierzycieli. Sąd może przedłużyć termin spłaty wierzytelności na 
dalszy okres nieprzekraczający osiemnastu miesięcy. Na postanowienie sądu 
przysługuje zażalenie, a od postanowienia sądu drugiej instancji skarga kasacyjna. 
2. Jeżeli brak możliwości wywiązania się z obowiązków określonych w planie 
spłaty wierzycieli ma charakter trwały i wynika z okoliczności niezależnych od 
upadłego, sąd na wniosek upadłego, po wysłuchaniu wierzycieli, może uchylić plan 
spłaty wierzycieli i umorzyć niewykonane zobowiązania upadłego, o których mowa 
w art. 49115 ust. 1–3. 
Na 
postanowienie 
sądu 
przysługuje 
zażalenie, 
a od 
postanowienia sądu drugiej instancji skarga kasacyjna. 
3. W razie istotnej poprawy sytuacji majątkowej upadłego w okresie 
wykonywania planu spłaty wierzycieli, wynikającej z innych przyczyn niż 
zwiększenie się wynagrodzenia za pracę lub dochodów uzyskiwanych z osobiście 
wykonywanej przez upadłego działalności zarobkowej, każdy z wierzycieli oraz 
upadły może wystąpić z wnioskiem o zmianę planu spłaty wierzycieli. O zmianie 
planu spłaty wierzycieli sąd orzeka po wysłuchaniu upadłego i wierzycieli objętych 
planem spłaty wierzycieli. Na postanowienie przysługuje zażalenie. 
4. Przepis ust. 3 stosuje się odpowiednio do wierzycieli, których wierzytelności 
powstałe przed ustaleniem planu spłaty wierzycieli zostały po jego ustaleniu 

©Kancelaria Sejmu 
 
 
 
s. 214/224 
 
2025-09-11 
 
stwierdzone prawomocnym orzeczeniem, ugodą zawartą przed sądem lub ostateczną 
decyzją. 
5. Postanowienie 
o zmianie 
planu 
spłaty 
wierzycieli 
obwieszcza 
się. 
Postanowienie sądu drugiej instancji w przedmiocie rozpoznania zażalenia na 
postanowienie o zmianie planu spłaty wierzycieli, postanowienie Sądu Najwyższego 
w przedmiocie rozpoznania skargi kasacyjnej oraz informację o prawomocności 
postanowienia o zmianie planu spłaty wierzycieli obwieszcza się.

***
## Art. 49120. {#art-49120}

1. 
W razie 
niewykonywania 
przez 
upadłego 
obowiązków 
określonych w planie spłaty wierzycieli sąd z urzędu albo na wniosek wierzyciela, po 
wysłuchaniu upadłego i wierzycieli objętych planem spłaty wierzycieli, uchyla plan 
spłaty wierzycieli, chyba że uchybienie obowiązkom jest nieznaczne lub dalsze 
wykonywanie planu spłaty wierzycieli jest uzasadnione względami słuszności lub 
względami humanitarnymi. Na postanowienie przysługuje zażalenie. 
2. Przepis ust. 1 stosuje się odpowiednio, gdy upadły: 
- 1) nie złożył w terminie sprawozdania z wykonania planu spłaty wierzycieli 
zgodnie z art. 49118 ust. 3; 
- 2) w sprawozdaniu z wykonania planu spłaty wierzycieli zataił osiągnięte 
przychody lub nabyte składniki majątkowe, o których mowa w art. 49118 ust. 3; 
- 3) dokonał czynności prawnej, o której mowa w art. 49118 ust. 1, bez uzyskania 
zgody sądu albo czynność ta nie została przez sąd zatwierdzona; 
- 4) ukrywał majątek lub czynność prawna upadłego została prawomocnie uznana za 
dokonaną z pokrzywdzeniem wierzycieli. 
3. W razie uchylenia planu spłaty wierzycieli zobowiązania upadłego nie 
podlegają umorzeniu. 
4. Przepis art. 49119 ust. 5 stosuje się odpowiednio. 
Art. 49120a. W sprawach, o których mowa w art. 49119 i art. 49120, sąd orzeka na 
rozprawie. O terminie rozprawy zawiadamia się wierzycieli przez obwieszczenie.

***
## Art. 49121. {#art-49121}

1. Po wykonaniu przez upadłego obowiązków określonych w planie 
spłaty wierzycieli sąd wydaje postanowienie o stwierdzeniu wykonania planu spłaty 
wierzycieli i umorzeniu zobowiązań upadłego powstałych przed dniem ogłoszenia 
upadłości i niewykonanych w wyniku wykonania planu spłaty wierzycieli. Na 
postanowienie przysługuje zażalenie. 

©Kancelaria Sejmu 
 
 
 
s. 215/224 
 
2025-09-11 
 
2. Nie podlegają umorzeniu zobowiązania o charakterze alimentacyjnym, 
zobowiązania wynikające z rent z tytułu odszkodowania za wywołanie choroby, 
niezdolności do pracy, kalectwa lub śmierci, zobowiązania do zapłaty orzeczonych 
przez sąd kar grzywny, a także do wykonania obowiązku naprawienia szkody oraz 
zadośćuczynienia za doznaną krzywdę, zobowiązania do zapłaty nawiązki lub 
świadczenia pieniężnego orzeczonych przez sąd jako środek karny lub środek 
związany z poddaniem sprawcy próbie, jak również zobowiązania do naprawienia 
szkody wynikającej z przestępstwa lub wykroczenia stwierdzonego prawomocnym 
orzeczeniem oraz zobowiązania, których upadły umyślnie nie ujawnił, jeżeli 
wierzyciel nie brał udziału w postępowaniu. 
2a. Przepis art. 49119 ust. 5 stosuje się odpowiednio. 
3. Po wydaniu postanowienia, o którym mowa w ust. 1, niedopuszczalne jest 
wszczęcie postępowania egzekucyjnego dotyczącego wierzytelności powstałej przed 
dniem ustalenia planu spłaty wierzycieli z wyjątkiem wierzytelności wynikających 
z zobowiązań, o których mowa w ust. 2.

***
## Art. 49122. {#art-49122}

1. Jeżeli zostanie uprawdopodobnione, że w drodze układu zostaną 
osiągnięte cele postępowania, sędzia-komisarz, na wniosek upadłego, postanowieniem 
zwołuje zgromadzenie wierzycieli w celu zawarcia układu. Na postanowienie 
o odmowie zwołania zgromadzenia wierzycieli przysługuje zażalenie. 
2. Zwołując zgromadzenie wierzycieli sędzia-komisarz może wstrzymać 
likwidację majątku upadłego, w szczególności lokalu mieszkalnego albo domu 
jednorodzinnego, w którym zamieszkuje upadły. Na postanowienie w przedmiocie 
wstrzymania likwidacji przysługuje zażalenie. 
3. Wniosek o zwołanie zgromadzenia wierzycieli złożony po zakończeniu 
likwidacji masy upadłości pozostawia się bez rozpoznania. 
4. Układ może zostać przyjęty wyłącznie za zgodą upadłego. 
5. W przypadku postępowania wszczętego na wniosek wierzyciela wniosek, 
o którym mowa w ust. 1, może złożyć również każdy z wierzycieli. Przepisu ust. 4 nie 
stosuje się.

***
## Art. 49123. {#art-49123}

Do zawarcia układu w postępowaniu prowadzonym na podstawie 
przepisów niniejszego tytułu, do jego skutków, zmiany oraz uchylenia przepisy 
o układzie w postępowaniu upadłościowym prowadzonym wobec przedsiębiorców 
stosuje się odpowiednio, z wyjątkiem przepisów art. 192 ust. 1 i 2. 

©Kancelaria Sejmu 
 
 
 
s. 216/224 
 
2025-09-11

***
## Art. 49124. {#art-49124}

1. Po ogłoszeniu upadłości syndyk zakłada i prowadzi akta, w tym 
akta do zgłoszeń wierzytelności, w systemie teleinformatycznym obsługującym 
postępowanie sądowe. 
2. Treść pism procesowych oraz dokumentów, o których mowa w art. 216aa 
ust. 1, wniesionych z pominięciem systemu teleinformatycznego obsługującego 
postępowanie sądowe, syndyk wprowadza do akt. Pisma procesowe oraz dokumenty 
składa się do zbioru dokumentów. Przepisy art. 216aa ust. 2 i 3 stosuje się 
odpowiednio. 
3. Akta udostępnia się w biurze syndyka, za pośrednictwem systemu 
teleinformatycznego obsługującego postępowanie sądowe, uczestnikom postępowania 
oraz każdemu, kto potrzebę ich przejrzenia dostatecznie usprawiedliwi. W tym celu 
biuro syndyka jest czynne w dni powszednie co najmniej cztery następujące po sobie 
godziny dziennie między godziną 8.00 a 20.00. 
4. Akta stanowią część akt sądowych. Po prawomocnym zakończeniu 
postępowania zbiór dokumentów jest przekazywany do sądu upadłościowego, który 
wydał postanowienie kończące postępowanie, i dołączany do akt sądowych. 
5. Akta oraz zbiór dokumentów mogą być udostępniane służbie nadzoru Ministra 
Sprawiedliwości. 
6. W przypadku odwołania, zmiany, zawieszenia oraz wygaśnięcia funkcji 
syndyka akta są przejmowane przez nowo wyznaczonego syndyka wraz ze zbiorem 
dokumentów. 
7. Minister Sprawiedliwości określi, w drodze rozporządzenia, sposób i tryb 
prowadzenia akt oraz zbioru dokumentów, w tym stosowane urządzenia ewidencyjne, 
a także udostępniania tych akt oraz zbioru dokumentów, mając na względzie 
zapewnienie bezpieczeństwa i ochrony danych w nich zawartych. 
TYTUŁ VI 
Postępowanie o zawarcie układu na zgromadzeniu wierzycieli przez osobę 
fizyczną nieprowadzącą działalności gospodarczej

***
## Art. 49125. {#art-49125}

1. Dłużnik będący osobą fizyczną nieprowadzącą działalności 
gospodarczej, który stał się niewypłacalny, może wystąpić do sądu upadłościowego 
o otwarcie postępowania o zawarcie układu na zgromadzeniu wierzycieli. 
2. Sąd może skierować dłużnika, który złożył wniosek o ogłoszenie upadłości, 
do postępowania o zawarcie układu na zgromadzeniu wierzycieli, chyba że dłużnik 

©Kancelaria Sejmu 
 
 
 
s. 217/224 
 
2025-09-11 
 
we wniosku o ogłoszenie upadłości złożył oświadczenie, że nie wyraża zgody na 
udział w postępowaniu o zawarcie układu na zgromadzeniu wierzycieli. 
3. Sąd uwzględnia wniosek dłużnika o otwarcie postępowania o zawarcie układu 
na zgromadzeniu wierzycieli albo może skierować go do tego postępowania, jeżeli 
możliwości zarobkowe dłużnika oraz jego sytuacja zawodowa wskazują na zdolność 
do pokrycia kosztów postępowania o zawarcie układu oraz możliwość zawarcia 
i wykonania układu z wierzycielami. 
4. Do wniosku o otwarcie postępowania o zawarcie układu na zgromadzeniu 
wierzycieli stosuje się odpowiednio przepis art. 216aa. W przypadku, o którym mowa 
w art. 216aa ust. 1, wniosek o otwarcie postępowania o zawarcie układu na 
zgromadzeniu wierzycieli składa się na formularzu. 
5. Wniosek, o którym mowa w ust. 4, powinien odpowiadać warunkom 
formalnym, o których mowa w art. 4912 ust. 4, oraz zawierać wstępne propozycje 
układowe. 
6. Minister Sprawiedliwości określi, w drodze rozporządzenia, wzór formularza 
wniosku dłużnika o otwarcie postępowania o zawarcie układu na zgromadzeniu 
wierzycieli, mając na uwadze zakres informacji, których umieszczenie we wniosku 
jest niezbędne.

***
## Art. 49126. {#art-49126}

1. Dłużnik wraz z wnioskiem o otwarcie postępowania o zawarcie 
układu na zgromadzeniu wierzycieli uiszcza zaliczkę na wydatki postępowania 
w wysokości przeciętnego miesięcznego wynagrodzenia w sektorze przedsiębiorstw 
bez wypłat nagród z zysku w trzecim kwartale roku poprzedniego, ogłoszonego przez 
Prezesa Głównego Urzędu Statystycznego, pod rygorem zwrotu wniosku. 
2. W przypadku, o którym mowa w art. 49125 ust. 2, dłużnik uiszcza zaliczkę na 
wydatki, o której mowa w ust. 1, nadzorcy sądowemu w terminie trzydziestu dni od 
dnia otwarcia postępowania o zawarcie układu na zgromadzeniu wierzycieli pod 
rygorem umorzenia postępowania i rozpoznania wniosku o ogłoszenie upadłości.

***
## Art. 49127. {#art-49127}

1. Uwzględniając wniosek o otwarcie postępowania o zawarcie 
układu na zgromadzeniu wierzycieli lub kierując dłużnika do tego postępowania, sąd 
wydaje postanowienie o otwarciu postępowania o zawarcie układu na zgromadzeniu 
wierzycieli, w którym: 

©Kancelaria Sejmu 
 
 
 
s. 218/224 
 
2025-09-11 
- 1) wymienia imię i nazwisko, miejsce zamieszkania, adres oraz numer PESEL 
dłużnika, a jeżeli dłużnik nie posiada numeru PESEL – inne dane umożliwiające 
jego jednoznaczną identyfikację; 
- 2) wyznacza nadzorcę sądowego. 
2. Przez inne dane umożliwiające jednoznaczną identyfikację, o których mowa 
w ust. 1 pkt 1, rozumie się dane, o których mowa w art. 4912 ust. 5c.

***
## Art. 49128. {#art-49128}

1. Postanowienie o otwarciu postępowania o zawarcie układu na 
zgromadzeniu wierzycieli obwieszcza się. 
2. Postanowienie w przedmiocie otwarcia postępowania o zawarcie układu na 
zgromadzeniu wierzycieli doręcza się dłużnikowi, a postanowienie o otwarciu 
postępowania o zawarcie układu na zgromadzeniu wierzycieli doręcza się także 
nadzorcy sądowemu. 
3. O otwarciu postępowania o zawarcie układu na zgromadzeniu wierzycieli 
zawiadamia się właściwą izbę administracji skarbowej oraz właściwy oddział Zakładu 
Ubezpieczeń Społecznych lub Kasy Rolniczego Ubezpieczenia Społecznego.

***
## Art. 49129. {#art-49129}

Jednocześnie z otwarciem postępowania o zawarcie układu na 
zgromadzeniu wierzycieli sąd przyznaje nadzorcy sądowemu zaliczkę na pokrycie 
kosztów postępowania o zawarcie układu oraz zarządza jej niezwłoczną wypłatę 
z zaliczki uiszczonej przez dłużnika.

***
## Art. 49130. {#art-49130}

Nadzorca sądowy w terminie trzydziestu dni od dnia doręczenia 
postanowienia o otwarciu postępowania o zawarcie układu na zgromadzeniu 
wierzycieli: 
- 1) sporządza w porozumieniu z dłużnikiem propozycje układowe; 
- 2) sporządza spis wierzytelności; 
- 3) sporządza spis wierzytelności spornych; 
- 4) zwołuje zgromadzenie wierzycieli w celu głosowania nad układem.

***
## Art. 49131. {#art-49131}

1. Termin zgromadzenia wierzycieli ustala nadzorca sądowy 
w porozumieniu z dłużnikiem. 
2. Zgromadzenie wierzycieli nie może odbyć się później niż trzy miesiące od 
dnia otwarcia postępowania o zawarcie układu na zgromadzeniu wierzycieli, 
a w przypadku, o którym mowa w art. 49125 ust. 2 – cztery miesiące od dnia otwarcia 
tego postępowania pod rygorem jego umorzenia. 

©Kancelaria Sejmu 
 
 
 
s. 219/224 
 
2025-09-11 
 
3. Nadzorca sądowy zawiadamia wierzycieli o terminie i miejscu zgromadzenia 
za pośrednictwem operatora pocztowego w rozumieniu ustawy z dnia 23 listopada 
2012 r. – Prawo pocztowe przesyłką poleconą, odpowiednio za potwierdzeniem 
odbioru albo za zwrotnym pokwitowaniem odbioru co najmniej dwa tygodnie przed 
dniem zgromadzenia. Wraz z zawiadomieniem należy doręczyć wierzycielowi 
propozycje układowe.

***
## Art. 49132. {#art-49132}

1. Zgromadzeniu wierzycieli przewodniczy nadzorca sądowy. 
2. Z przebiegu zgromadzenia wierzycieli sporządza się protokół, który powinien 
zawierać treść układu oraz wymieniać wierzycieli głosujących za układem i przeciwko 
układowi. 
3. Nadzorca sądowy przedstawia sądowi wniosek o zatwierdzenie układu albo 
o umorzenie postępowania w terminie dwudziestu jeden dni od dnia zgromadzenia 
wierzycieli.

***
## Art. 49133. {#art-49133}

1. Układ jest zawierany na okres nieprzekraczający pięciu lat. 
2. W przypadku, gdy układ obejmuje wierzytelności, o których mowa 
w art. 151 ust. 2 ustawy z dnia 15 maja 2015 r. – Prawo restrukturyzacyjne, układ, 
w części dotyczącej tych wierzytelności, może być zawarty na okres przekraczający 
pięć lat. 
3. W przypadku gdy w skład masy upadłości wchodzi nieruchomość służąca 
zaspokojeniu potrzeb mieszkaniowych dłużnika lub osób znajdujących się na jego 
utrzymaniu, układ może być zawarty na okres przekraczający pięć lat, jeżeli 
przewiduje zachowanie nieruchomości przez dłużnika.

***
## Art. 49134. {#art-49134}

Dłużnik wykonuje układ za pośrednictwem nadzorcy wykonania 
układu.

***
## Art. 49135. {#art-49135}

1. Wynagrodzenie nadzorcy sądowego wynosi równowartość 15 % 
poziomu zaspokojenia wierzycieli zgodnie z postanowieniami układu i składa się 
z opłaty wstępnej, wynoszącej połowę przeciętnego miesięcznego wynagrodzenia 
w sektorze przedsiębiorstw bez wypłat nagród z zysku w trzecim kwartale roku 
poprzedniego, ogłoszonego przez Prezesa Głównego Urzędu Statystycznego, oraz 
kwot wypłacanych nadzorcy sądowemu wraz z przekazaniem wynikających z układu 
świadczeń dla wierzycieli, w wysokości nieprzekraczającej równowartości 15 % 
każdorazowego świadczenia dla wierzycieli. 

©Kancelaria Sejmu 
 
 
 
s. 220/224 
 
2025-09-11 
 
2. W przypadku 
gdy 
poziom 
zaspokojenia 
wierzycieli 
zgodnie 
z postanowieniami układu przekracza 100 000 złotych, wynagrodzenie od poziomu 
przewyższającego 100 000 złotych wynosi równowartość 3 % zaspokojenia 
wierzycieli. 
3. W przypadku 
gdy 
poziom 
zaspokojenia 
wierzycieli 
zgodnie 
z postanowieniami układu przekracza 500 000 złotych, wynagrodzenie od poziomu 
przewyższającego 500 000 złotych wynosi równowartość 1 % zaspokojenia 
wierzycieli. 
4. Opłatę wstępną nadzorca sądowy pobiera po doręczeniu postanowienia 
o otwarciu postępowania o zawarcie układu na zgromadzeniu wierzycieli, a pozostałą 
część wynagrodzenia – równocześnie z dokonaniem wypłat dla wierzycieli 
w wykonaniu układu zatwierdzonego przez sąd. 
5. Wynagrodzenie nadzorcy sądowego nie może być niższe od opłaty wstępnej, 
o której mowa w ust. 1.

***
## Art. 49136. {#art-49136}

1. Sąd umarza postępowanie o zawarcie układu na zgromadzeniu 
wierzycieli, jeżeli: 
- 1) dłużnik nie realizuje ciążących na nim obowiązków; 
- 2) aktualne możliwości zarobkowe dłużnika oraz jego sytuacja zawodowa nie 
uprawdopodobniają zdolności do pokrycia kosztów postępowania o zawarcie 
układu na zgromadzeniu wierzycieli oraz możliwości zawarcia i wykonania 
układu z wierzycielami; 
- 3) w terminie sześciu miesięcy od dnia wydania postanowienia o otwarciu 
postępowania o zawarcie układu na zgromadzeniu wierzycieli nadzorca sądowy 
nie przedstawi wniosku o zatwierdzenie układu. 
2. W przypadku, o którym mowa w art. 49125 ust. 2, po prawomocnym 
umorzeniu postępowania sąd rozpoznaje wniosek dłużnika o ogłoszenie upadłości.

***
## Art. 49137. {#art-49137}

1. Po wydaniu postanowienia, o którym mowa w art. 49127 ust. 1, 
nadzorca sądowy zakłada i prowadzi akta w systemie teleinformatycznym 
obsługującym postępowanie sądowe. 
2. Treść pism procesowych oraz dokumentów, o których mowa w art. 216aa 
ust. 1, wniesionych z pominięciem systemu teleinformatycznego obsługującego 
postępowanie sądowe, nadzorca sądowy wprowadza do akt. Pisma procesowe oraz 

©Kancelaria Sejmu 
 
 
 
s. 221/224 
 
2025-09-11 
 
dokumenty składa się do zbioru dokumentów. Przepisy art. 216aa ust. 2 i 3 stosuje się 
odpowiednio. 
3. Akta udostępnia się w biurze nadzorcy sądowego, za pośrednictwem systemu 
teleinformatycznego obsługującego postępowanie sądowe, uczestnikom postępowania 
oraz każdemu, kto potrzebę ich przejrzenia dostatecznie usprawiedliwi. W tym celu 
biuro nadzorcy sądowego jest czynne w dni powszednie co najmniej cztery 
następujące po sobie godziny dziennie między godziną 8.00 a 20.00. 
4. Akta stanowią część akt sądowych. Po prawomocnym zakończeniu 
postępowania zbiór dokumentów jest przekazywany do sądu upadłościowego, który 
wydał postanowienie kończące postępowanie, i dołączany do akt sądowych. 
5. Akta oraz zbiór dokumentów mogą być udostępniane służbie nadzoru Ministra 
Sprawiedliwości. 
6. W przypadku odwołania, zmiany, zawieszenia oraz wygaśnięcia funkcji 
nadzorcy sądowego akta są przejmowane przez nowo wyznaczonego nadzorcę 
sądowego wraz ze zbiorem dokumentów. 
7. Minister Sprawiedliwości określi, w drodze rozporządzenia, sposób i tryb 
prowadzenia akt oraz zbioru dokumentów, w tym stosowane urządzenia ewidencyjne, 
a także udostępniania tych akt oraz zbioru dokumentów, mając na względzie 
zapewnienie bezpieczeństwa i ochrony danych w nich zawartych.

***
## Art. 49138. {#art-49138}

W zakresie nieuregulowanym w niniejszym tytule do postępowania 
o zawarcie układu na zgromadzeniu wierzycieli stosuje się odpowiednio przepisy 
ustawy z dnia 15 maja 2015 r. – Prawo restrukturyzacyjne dotyczące przyspieszonego 
postępowania układowego, z tym że nie wyznacza się sędziego-komisarza i nie stosuje 
się przepisów o czynnościach sędziego-komisarza. 
CZĘŚĆ CZWARTA 
(uchylona) 
CZĘŚĆ PIĄTA 
PRZEPISY KARNE

***
## Art. 522. {#art-522}

1. Kto będąc dłużnikiem albo osobą uprawnioną do reprezentowania 
dłużnika, który jest osobą prawną lub spółką handlową niemającą osobowości 
prawnej, podaje we wniosku o ogłoszenie upadłości nieprawdziwe dane 
– podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 

©Kancelaria Sejmu 
 
 
 
s. 222/224 
 
2025-09-11 
 
2. Tej samej karze podlega, kto będąc dłużnikiem lub osobą uprawnioną do 
reprezentowania dłużnika, który jest osobą prawną lub spółką handlową niemającą 
osobowości prawnej, w postępowaniu w przedmiocie ogłoszenia upadłości podaje 
sądowi nieprawdziwe informacje co do stanu majątku dłużnika.

***
## Art. 523. {#art-523}

1. Kto będąc upadłym albo osobą uprawnioną do reprezentowania 
upadłego, który jest osobą prawną lub spółką handlową niemającą osobowości 
prawnej, nie wydaje syndykowi całego majątku wchodzącego do masy upadłości, 
ksiąg rachunkowych lub innych dokumentów dotyczących jego majątku 
– podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
2. Tej samej karze podlega, kto będąc upadłym albo osobą uprawnioną do 
reprezentowania upadłego, który jest osobą prawną lub spółką handlową niemającą 
osobowości prawnej, nie udziela syndykowi lub sędziemu-komisarzowi informacji 
dotyczących majątku upadłego lub nie udostępnia syndykowi posiadanych przez 
siebie danych lub dokumentów pozwalających na wykonanie obowiązku, o którym 
mowa w art. 56 ust. 1 pkt 2 i ust. 7 oraz art. 70 ustawy z dnia 29 lipca 2005 r. o ofercie 
publicznej 
i warunkach 
wprowadzania 
instrumentów 
finansowych 
do 
zorganizowanego systemu obrotu oraz o spółkach publicznych, oraz obowiązku, 
o którym mowa w art. 17 ust. 1 lub 2 i art. 19 ust. 3 rozporządzenia nr 596/2014. 
CZĘŚĆ SZÓSTA 
ZMIANY W PRZEPISACH OBOWIĄZUJĄCYCH, PRZEPISY 
PRZEJŚCIOWE I PRZEPISY KOŃCOWE 
DZIAŁ I 
Zmiany w przepisach obowiązujących 
Art. 524–535. (pominięte) 
DZIAŁ II 
Przepisy przejściowe

***
## Art. 536. {#art-536}

W sprawach, w których ogłoszono upadłość przed dniem wejścia 
w życie ustawy, stosuje się przepisy dotychczasowe.

***
## Art. 537. {#art-537}

W sprawach, w których przed dniem wejścia w życie ustawy wpłynął 
wniosek o ogłoszenie upadłości, lecz jeszcze nie wydano postanowienia o ogłoszeniu 

©Kancelaria Sejmu 
 
 
 
s. 223/224 
 
2025-09-11 
 
upadłości, postępowanie w przedmiocie ogłoszenia upadłości prowadzi się według 
przepisów ustawy.

***
## Art. 538. {#art-538}

1. Jeżeli podanie o otwarcie postępowania układowego złożone zostało 
przed dniem wejścia w życie ustawy, lecz jeszcze nie orzeczono o otwarciu 
postępowania układowego, postępowanie prowadzi się według przepisów ustawy. Sąd 
może zobowiązać dłużnika do złożenia wniosku o ogłoszenie upadłości z możliwością 
zawarcia układu zgodnie z przepisami ustawy. 
2. W sprawach, w których postanowienie o otwarciu układu zostało wydane 
przed dniem wejścia w życie ustawy, stosuje się przepisy rozporządzenia Prezydenta 
Rzeczypospolitej z dnia 24 października 1934 r. – Prawo o postępowaniu układowym 
(Dz. U. poz. 836, z późn. zm.7)), z wyjątkiem art. 31 § 5 zdanie drugie.

***
## Art. 539. {#art-539}

W sprawach, o których mowa w art. 536 i 538 ust. 2, wpisu do 
Krajowego Rejestru Sądowego dokonuje się według przepisów dotychczasowych.

***
## Art. 540. {#art-540}

Do postępowań wszczętych przed dniem wejścia w życie ustawy, na 
podstawie art. 172 rozporządzenia, o którym mowa w art. 545 pkt 1, stosuje się 
przepisy dotychczasowe.

***
## Art. 541. {#art-541}

(pominięty)

***
## Art. 542. {#art-542}

(pominięty)

***
## Art. 543. {#art-543}

Ilekroć 
w przepisach odrębnych jest 
mowa o „postępowaniu 
upadłościowym”, rozumie się przez to postępowanie upadłościowe obejmujące 
likwidację majątku upadłego.

***
## Art. 544. {#art-544}

Ilekroć w przepisach odrębnych jest 
mowa o „postępowaniu 
układowym”, rozumie się przez to także postępowanie upadłościowe z możliwością 
zawarcia układu. 
DZIAŁ III 
Przepisy końcowe

***
## Art. 545. {#art-545}

Tracą moc: 
- 7) Zmiany wymienionego rozporządzenia zostały ogłoszone w Dz. U. z 1950 r. poz. 349, z 1990 r. 
poz. 320, z 1996 r. poz. 43 i 189 oraz z 1997 r. poz. 592, 770 i 885. 

©Kancelaria Sejmu 
 
 
 
s. 224/224 
 
2025-09-11 
- 1) rozporządzenie Prezydenta Rzeczypospolitej z dnia 24 października 1934 r. – 
Prawo upadłościowe (Dz. U. z 1991 r. poz. 512, z późn. zm.8)); 
- 2) rozporządzenie Prezydenta Rzeczypospolitej z dnia 24 października 1934 r. – 
Przepisy wprowadzające prawo upadłościowe (Dz. U. poz. 835 oraz z 1946 r. 
poz. 197, 321 i 329); 
- 3) rozporządzenie Prezydenta Rzeczypospolitej z dnia 24 października 1934 r. – 
Prawo o postępowaniu układowym (Dz. U. poz. 836, z późn. zm.7)).

***
## Art. 546. {#art-546}

Ustawa wchodzi w życie z dniem 1 października 2003 r., z tym że: 
- 1) w przypadku przedsiębiorców, którzy złożyli wnioski, o których mowa 
w art. 12 ust. 1 ustawy z dnia 30 października 2002 r. o pomocy publicznej dla 
przedsiębiorców o szczególnym znaczeniu dla rynku pracy (Dz. U. poz. 1800, 
z późn. 
zm.9)), 
oraz 
dłużników 
odpowiadających 
solidarnie 
wraz 
z przedsiębiorcami, będących stroną postępowania restrukturyzacyjnego 
prowadzonego na podstawie tej ustawy, przepisy niniejszej ustawy 
o postępowaniu naprawczym wchodzą w życie po upływie 14 dni od dnia 
ogłoszenia10), z tym że postępowanie naprawcze nie obejmuje zobowiązań 
cywilnoprawnych i publicznoprawnych objętych postępowaniem toczącym się 
na 
podstawie 
przepisów 
o pomocy 
publicznej 
dla 
przedsiębiorców 
o szczególnym znaczeniu dla rynku pracy, jeżeli przedsiębiorca jest stroną 
takiego 
postępowania 
w chwili 
ogłoszenia 
oświadczenia 
o wszczęciu 
postępowania naprawczego w Monitorze Sądowym i Gospodarczym; 
- 2) przepisy art. 451, art. 454–470, art. 481 i art. 482 stosuje się z dniem 
przystąpienia Rzeczypospolitej Polskiej do Unii Europejskiej11). 
- 8) Zmiany wymienionego rozporządzenia zostały ogłoszone w Dz. U. z 1994 r. poz. 1, z 1995 r. poz. 426, 
z 1996 r. poz. 43, 189, 496 i 703, z 1997 r. poz. 153, 349, 751, 770 i 940, z 1998 r. poz. 756, z 2000 r. 
poz. 306, 948, 1037 i 1193 oraz z 2001 r. poz. 18. 
- 9) Zmiany wymienionej ustawy zostały ogłoszone w Dz. U. z 2003 r. poz. 844 i 2271, z 2004 r. poz. 1291, 
z 2006 r. poz. 1121 oraz z 2009 r. poz. 1664 i 1707. 
- 10) Ustawa została ogłoszona w dniu 9 kwietnia 2003 r. 
- 11) Rzeczpospolita Polska uzyskała członkostwo w Unii Europejskiej z dniem 1 maja 2004 r.

