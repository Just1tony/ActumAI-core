---
id: code.kpc.czesc.0.ksiega.all
title: "Kodeks postępowania cywilnego — TYTUŁ WSTĘPNY — KSIĘGA — (—)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1964 Nr 43 poz. 296"
consolidated_citation: "t.j. Dz.U. 2024 poz. 1568, 1841; Dz.U. 2025 poz. 620, 1172"
status: "obowiązujący"
last_consolidated: "2025-09-08"
aliases: ["KPC — TYTUŁ WSTĘPNY — Księga —"]
tags: ["KPC","Kodeks postępowania cywilnego","TYTUŁ WSTĘPNY","Księga —","PL"]
source_pdf: "D19640296Lj.pdf"
articles: "Art. 1–14"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpc-0--art-{n}}"
  separators: "***"
  hierarchy: ["CZĘŚĆ","KSIĘGA","TYTUŁ","DZIAŁ","Rozdział"]
---

# Kodeks postępowania cywilnego — TYTUŁ WSTĘPNY — KSIĘGA —: —

# TYTUŁ WSTĘPNY
Przepisy ogólne
***
## Art. 1. {#kpc-0--art-1}

- 2) 3) Kodeks postępowania cywilnego normuje postępowanie sądowe 
w sprawach ze stosunków z zakresu prawa cywilnego, rodzinnego i opiekuńczego 
oraz prawa pracy, jak również w sprawach z zakresu ubezpieczeń społecznych oraz 
w innych sprawach, do których przepisy tego Kodeksu stosuje się z mocy ustaw 
szczególnych (sprawy cywilne).

***
## Art. 2. {#kpc-0--art-2}

**§ 1.** Do rozpoznawania spraw cywilnych powołane są sądy 
powszechne, o ile sprawy te nie należą do właściwości sądów szczególnych, oraz 
Sąd Najwyższy. 
- 1) Niniejsza ustawa w zakresie swojej regulacji wdraża dyrektywę Parlamentu Europejskiego 
i Rady (UE) 2020/1828 z dnia 25 listopada 2020 r. w sprawie powództw przedstawicielskich 
wytaczanych w celu ochrony zbiorowych interesów konsumentów i uchylającą dyrektywę 
2009/22/WE (Dz. Urz. UE L 409 z 04.12.2020, str. 1, Dz. Urz. UE L 265 z 12.10.2022, str. 1, 
Dz. Urz. UE L 277 z 27.10.2022, str. 1, Dz. Urz. UE L 135 z 23.05.2023, str. 1 oraz Dz. Urz. 
UE L 2023/2854 z 22.12.2023). 
- 2) Utracił moc z dniem 17 lipca 2000 r., rozumiany w ten sposób, iż w zakresie pojęcia „sprawy 
cywilnej” nie mogą się mieścić roszczenia dotyczące zobowiązań pieniężnych, których źródło 
stanowi decyzja administracyjna, na podstawie wyroku Trybunału Konstytucyjnego z dnia 
10 lipca 2000 r. sygn. akt SK. 12/99 (Dz. U. poz. 665).  
- 3) Utracił moc z dniem 11 września 2017 r.: 
– w zakresie, w jakim dotyczy zagadnienia oceny prawidłowości procedury wyboru sędziego 
Trybunału Konstytucyjnego, 
– w zakresie, w jakim dotyczy zagadnienia oceny prawidłowości procedury przedstawienia 
kandydatów na stanowisko Prezesa oraz Wiceprezesa Trybunału Konstytucyjnego przez 
Zgromadzenie Ogólne Sędziów Trybunału Konstytucyjnego i powołania ich przez 
Prezydenta Rzeczypospolitej Polskiej 
na podstawie wyroku Trybunału Konstytucyjnego z dnia 11 września 2017 r. sygn. akt K 10/17 
(Dz. U. poz. 1727). 

podstawie: 
t.j. 
Dz. U. z 2024 r. 
poz. 1568, 1841, z 
2025 r. poz. 620, 
1172. 

 
 
 
s. 2/580 
 
2025-09-08 
**§ 1a.** (uchylony) 
**§ 2.** (uchylony) 
**§ 3.** Nie są rozpoznawane w postępowaniu sądowym sprawy cywilne, jeżeli 
przepisy szczególne przekazują je do właściwości innych organów.

***
## Art. 3. {#kpc-0--art-3}

Strony i uczestnicy postępowania obowiązani są dokonywać 
czynności procesowych zgodnie z dobrymi obyczajami, dawać wyjaśnienia co do 
okoliczności sprawy zgodnie z prawdą i bez zatajania czegokolwiek oraz 
przedstawiać dowody.

***
## Art. 4. {#kpc-0--art-4}

(uchylony)

***
## Art. 41. {#kpc-0--art-41}

Z uprawnienia przewidzianego w przepisach postępowania stronom 
i uczestnikom postępowania nie wolno czynić użytku niezgodnego z celem, dla 
którego je ustanowiono (nadużycie prawa procesowego).

***
## Art. 5. {#kpc-0--art-5}

W razie uzasadnionej potrzeby sąd może udzielić stronom 
i uczestnikom postępowania występującym w sprawie bez adwokata, radcy 
prawnego, 
rzecznika 
patentowego 
lub 
radcy 
Prokuratorii 
Generalnej 
Rzeczypospolitej Polskiej niezbędnych pouczeń co do czynności procesowych.

***
## Art. 6. {#kpc-0--art-6}

**§ 1.** Sąd powinien przeciwdziałać przewlekaniu postępowania i dążyć 
do tego, aby rozstrzygnięcie nastąpiło na pierwszym posiedzeniu, jeżeli jest to 
możliwe bez szkody dla wyjaśnienia sprawy. 
**§ 2.** Strony i uczestnicy postępowania obowiązani są przytaczać wszystkie 
fakty i dowody bez zwłoki, aby postępowanie mogło być przeprowadzone sprawnie 
i szybko.

***
## Art. 7. {#kpc-0--art-7}

Prokurator może żądać wszczęcia postępowania w każdej sprawie, jak 
również wziąć udział w każdym toczącym się już postępowaniu, jeżeli według jego 
oceny wymaga tego ochrona praworządności, praw obywateli lub interesu 
społecznego. W sprawach niemajątkowych z zakresu prawa rodzinnego prokurator 
może wytaczać powództwa tylko w wypadkach wskazanych w ustawie.

***
## Art. 8. {#kpc-0--art-8}

Organizacje pozarządowe, których zadanie statutowe nie polega na 
prowadzeniu działalności gospodarczej, mogą dla ochrony praw obywateli, 
w wypadkach przewidzianych w ustawie, wszcząć postępowanie oraz wziąć udział 
w toczącym się postępowaniu. 

 
 
 
s. 3/580 
 
2025-09-08

***
## Art. 9. {#kpc-0--art-9}

**§ 1.** Rozpoznawanie spraw odbywa się jawnie, chyba że przepis 
szczególny stanowi inaczej. Strony i uczestnicy postępowania mają prawo 
przeglądać akta sprawy i otrzymywać odpisy, kopie lub wyciągi z tych akt. 
**§ 11.** Przeglądanie akt sprawy oraz udostępnianie stronom i uczestnikom 
postępowania odpisów, kopii lub wyciągów z akt sprawy może się odbywać za 
pośrednictwem 
systemu 
teleinformatycznego obsługującego postępowanie 
sądowe, zwanego dalej „systemem teleinformatycznym”, albo systemu 
teleinformatycznego, o którym mowa w art. 53e § 1 ustawy z dnia 27 lipca 2001 r. 
– Prawo o ustroju sądów powszechnych (Dz. U. z 2024 r. poz. 334), zwanego dalej 
„portalem informacyjnym”. 
**§ 2.** Strony i uczestnicy postępowania mają prawo do otrzymania z akt sprawy 
zapisu dźwięku albo obrazu i dźwięku, chyba że protokół został sporządzony 
wyłącznie pisemnie. Przewodniczący wydaje z akt sprawy zapis dźwięku, jeżeli 
wydaniu zapisu obrazu i dźwięku sprzeciwia się ważny interes publiczny lub 
prywatny. 
**§ 3.** Jeżeli posiedzenie odbyło się przy drzwiach zamkniętych strony 
i uczestnicy postępowania mają prawo do otrzymania z akt sprawy jedynie zapisu 
dźwięku.

***
## Art. 91. {#kpc-0--art-91}

**§ 1.** Nie jest wymagane zezwolenie sądu na utrwalanie przez strony 
lub uczestników postępowania przebiegu posiedzeń i innych czynności sądowych, 
przy których są obecni, za pomocą urządzenia rejestrującego dźwięk. 
**§ 2.** Strony i uczestnicy postępowania uprzedzają sąd o zamiarze utrwalenia 
przebiegu posiedzenia lub innej czynności sądowej za pomocą urządzenia 
rejestrującego dźwięk. 
**§ 3.** Sąd zakazuje stronie lub uczestnikowi postępowania utrwalenia 
przebiegu posiedzenia lub innej czynności sądowej za pomocą urządzenia 
rejestrującego dźwięk, jeżeli posiedzenie lub jego część odbywa się przy drzwiach 
zamkniętych lub sprzeciwia się temu wzgląd na prawidłowość postępowania.

***
## Art. 10. {#kpc-0--art-10}

W sprawach, w których zawarcie ugody jest dopuszczalne, sąd dąży 
w każdym stanie postępowania do ich ugodowego załatwienia, w szczególności 
przez nakłanianie stron do mediacji. 

 
 
 
s. 4/580 
 
2025-09-08

***
## Art. 11. {#kpc-0--art-11}

Ustalenia wydanego w postępowaniu karnym prawomocnego 
wyroku skazującego co do popełnienia przestępstwa wiążą sąd w postępowaniu 
cywilnym. Jednakże osoba, która nie była oskarżona, może powoływać się w 
postępowaniu cywilnym na wszelkie okoliczności wyłączające lub ograniczające 
jej odpowiedzialność cywilną.

***
## Art. 12. {#kpc-0--art-12}

Roszczenia majątkowe wynikające z przestępstwa mogą być 
dochodzone 
w postępowaniu 
cywilnym 
albo 
w wypadkach 
w ustawie 
przewidzianych w postępowaniu karnym.

***
## Art. 13. {#kpc-0--art-13}

**§ 1.** Sąd rozpoznaje sprawy w procesie, chyba że ustawa stanowi 
inaczej. W wypadkach przewidzianych w ustawie sąd rozpoznaje sprawy według 
przepisów o postępowaniach odrębnych. 
**§ 2.** Przepisy o procesie stosuje się odpowiednio do innych rodzajów 
postępowań unormowanych w niniejszym kodeksie, chyba że przepisy szczególne 
stanowią inaczej.

***
## Art. 14. {#kpc-0--art-14}

(uchylony)

