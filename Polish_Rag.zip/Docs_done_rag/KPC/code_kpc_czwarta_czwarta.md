---
id: code.kpc.czesc.czwarta.ksiega.czwarta
title: "Kodeks postępowania cywilnego — CZĘŚĆ CZWARTA — KSIĘGA CZWARTA (UZNANIE I WYKONANIE NIEKTÓRYCH ORZECZEŃ SĄDÓW)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1964 Nr 43 poz. 296"
consolidated_citation: "t.j. Dz.U. 2024 poz. 1568, 1841; Dz.U. 2025 poz. 620, 1172"
status: "obowiązujący"
last_consolidated: "2025-09-08"
aliases: ["KPC — CZĘŚĆ CZWARTA — Księga CZWARTA"]
tags: ["KPC","Kodeks postępowania cywilnego","CZĘŚĆ CZWARTA","Księga CZWARTA","PL"]
source_pdf: "D19640296Lj.pdf"
articles: "Art. 115313–115325"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpc-czwarta-czwarta-art-{n}}"
  separators: "***"
  hierarchy: ["CZĘŚĆ","KSIĘGA","TYTUŁ","DZIAŁ","Rozdział"]
---

# Kodeks postępowania cywilnego — CZĘŚĆ CZWARTA — KSIĘGA CZWARTA: UZNANIE I WYKONANIE NIEKTÓRYCH ORZECZEŃ SĄDÓW

UZNANIE I WYKONANIE NIEKTÓRYCH ORZECZEŃ SĄDÓW 
PAŃSTW CZŁONKOWSKICH UNII EUROPEJSKIEJ ORAZ 
POCHODZĄCYCH Z TYCH PAŃSTW UGÓD, 
DOKUMENTÓW URZĘDOWYCH I POROZUMIEŃ 
### TYTUŁ I
Przepisy ogólne
***
## Art. 115313. {#kpc-czwarta-czwarta-art-115313}

**§ 1.** Przepisy niniejszej księgi stosuje się do orzeczeń sądów 
państw członkowskich Unii Europejskiej oraz pochodzących z tych państw ugód, 
dokumentów urzędowych i porozumień objętych zakresem zastosowania 
rozporządzenia nr 1215/2012, rozporządzenia nr 805/2004, rozporządzenia 
nr 1896/2006, 
rozporządzenia 
nr 861/2007, 
rozporządzenia 
nr 4/2009, 
rozporządzenia nr 606/2013 i rozporządzenia nr 2019/1111. 
**§ 2.** Przepisy niniejszej księgi stosuje się ponadto do europejskich nakazów 
zabezpieczenia na rachunku bankowym wydanych w państwach członkowskich 
Unii Europejskiej na podstawie rozporządzenia nr 655/2014.

***
## Art. 115314. {#kpc-czwarta-czwarta-art-115314}

Tytułami wykonawczymi w Rzeczypospolitej Polskiej są: 
- 1) orzeczenia sądów państw członkowskich Unii Europejskiej oraz pochodzące 
z tych państw ugody i dokumenty urzędowe, objęte zakresem zastosowania 
rozporządzenia nr 1215/2012, jeżeli nadają się do wykonania w drodze 
egzekucji; 
- 2) orzeczenia sądów państw członkowskich Unii Europejskiej oraz pochodzące 
z tych państw ugody i dokumenty urzędowe, opatrzone w tych państwach 
zaświadczeniem europejskiego tytułu egzekucyjnego; 
- 3) europejskie nakazy zapłaty wydane przez sądy państw członkowskich Unii 
Europejskiej, których wykonalność została stwierdzona w tych państwach na 
podstawie przepisów rozporządzenia nr 1896/2006; 
- 4) orzeczenia sądów państw członkowskich Unii Europejskiej wydane 
w europejskim postępowaniu w sprawie drobnych roszczeń, opatrzone w tych 
państwach zaświadczeniem na podstawie przepisów rozporządzenia 
nr 861/2007; 

 
 
 
s. 553/580 
 
2025-09-08 
- 5) orzeczenia w sprawach alimentacyjnych wydane w państwach członkowskich 
Unii Europejskiej będących stronami Protokołu haskiego z dnia 23 listopada 
2007 r. o prawie właściwym dla zobowiązań alimentacyjnych (Dz. Urz. 
UE L 331 z 16.12.2009, str. 17) oraz pochodzące z tych państw ugody 
i dokumenty urzędowe w sprawach alimentacyjnych, objęte zakresem 
zastosowania rozporządzenia nr 4/2009; 
- 6) orzeczenia 
wydane 
w państwach 
członkowskich 
Unii 
Europejskiej 
obejmujące środki ochrony wchodzące w zakres zastosowania rozporządzenia 
nr 606/2013, jeżeli nadają się do wykonania w drodze egzekucji; 
- 7) orzeczenia sądów państw członkowskich Unii Europejskiej objęte zakresem 
zastosowania rozporządzenia nr 2019/1111, w zakresie, w jakim nadają się do 
wykonania w drodze egzekucji.

***
## Art. 115315. {#kpc-czwarta-czwarta-art-115315}

Orzeczenia 
wydane 
w państwach 
członkowskich 
Unii 
Europejskiej obejmujące środki ochrony wchodzące w zakres zastosowania 
rozporządzenia nr 606/2013, które podlegają wykonaniu w inny sposób niż 
w drodze egzekucji stanowią podstawę wszczęcia postępowania wykonawczego.

***
## Art. 115315a. {#kpc-czwarta-czwarta-art-115315a}

Europejskie nakazy zabezpieczenia na rachunku bankowym 
wydane w państwach członkowskich Unii Europejskiej na podstawie 
rozporządzenia nr 655/2014 są tytułami zabezpieczenia w Rzeczypospolitej 
Polskiej stanowiącymi podstawę wszczęcia postępowania wykonawczego.

***
## Art. 115315b. {#kpc-czwarta-czwarta-art-115315b}

Orzeczenia 
wydane 
w państwach 
członkowskich 
Unii 
Europejskiej, a także dokumenty urzędowe i porozumienia pochodzące z tych 
państw, objęte zakresem zastosowania rozporządzenia nr 2019/1111, które 
podlegają wykonaniu w inny sposób niż w drodze egzekucji, stanowią podstawę 
wszczęcia postępowania wykonawczego. 
### TYTUŁ II
Wykonanie

***
## Art. 115316. {#kpc-czwarta-czwarta-art-115316}

**§ 1.** Jeżeli tytuły wykonawcze, o których mowa w art. 115314 
pkt 1 albo 6, wymagają dostosowania zgodnie z przepisami, odpowiednio, 
rozporządzenia nr 1215/2012 albo rozporządzenia nr 606/2013, organ egzekucyjny 
wydaje postanowienie w przedmiocie dostosowania. W razie potrzeby komornik 

 
 
 
s. 554/580 
 
2025-09-08 
 
może zwrócić się do sądu o wydanie postanowienia, o którym mowa w zdaniu 
pierwszym. 
**§ 2.** Na postanowienie sądu przysługuje zażalenie.

***
## Art. 115316a. {#kpc-czwarta-czwarta-art-115316a}

O wszczęciu postępowania wykonawczego na podstawie 
orzeczeń wydanych w państwach członkowskich Unii Europejskiej, a także 
dokumentów urzędowych i porozumień, o którym mowa w art. 115315b, sąd właś-
ciwy do prowadzenia postępowania wykonawczego zawiadamia właściwego 
prokuratora okręgowego.

***
## Art. 115316b. {#kpc-czwarta-czwarta-art-115316b}

**§ 1.** W sytuacji gdy zgodnie z przepisami rozporządzenia 
nr 2019/1111: 
- 1) strona wniosła o częściowe wykonanie orzeczenia lub 
- 2) stwierdzono podstawy do odmowy wykonania orzeczenia co do jego części 
albo 
- 3) zachodzą podstawy do określenia warunków wykonywania kontaktów 
z dzieckiem 
– sąd właściwy do wykonania orzeczenia wydaje postanowienie odpowiednio 
w przedmiocie częściowego wykonania orzeczenia albo w przedmiocie określenia 
warunków wykonywania kontaktów. 
**§ 2.** Na postanowienie sądu przysługuje zażalenie.

***
## Art. 115317. {#kpc-czwarta-czwarta-art-115317}

**§ 1.** W postępowaniu egzekucyjnym wszczętym na podstawie 
tytułu wykonawczego, o którym mowa w art. 115314 pkt 1, wraz z zawiadomieniem 
o wszczęciu egzekucji organ egzekucyjny doręcza dłużnikowi także określone 
w przepisach rozporządzenia nr 1215/2012 zaświadczenie wystawione w państwie 
członkowskim Unii Europejskiej, z którego pochodzi tytuł wykonawczy. 
**§ 2.** Jeżeli dłużnik zażądał tłumaczenia tytułu wykonawczego zgodnie 
z przepisami rozporządzenia nr 1215/2012, organ egzekucyjny ogranicza 
egzekucję do środków zabezpieczających, stosując odpowiednio przepisy 
o sposobach zabezpieczenia roszczeń w postępowaniu zabezpieczającym. Dalsze 
czynności egzekucyjne są dopuszczalne po doręczeniu tłumaczenia dłużnikowi. Na 
postanowienie sądu przysługuje zażalenie.

***
## Art. 115318. {#kpc-czwarta-czwarta-art-115318}

**§ 1.** Na wniosek dłużnika sąd zawiesza postępowanie 
egzekucyjne prowadzone na podstawie tytułu wykonawczego, o którym mowa 

 
 
 
s. 555/580 
 
2025-09-08 
 
w art. 115314 pkt 2, jeżeli dłużnik przedstawił przewidziane w przepisach 
rozporządzenia 
nr 805/2004 zaświadczenie 
o utracie 
lub 
ograniczeniu 
wykonalności, z którego wynika, że wykonanie tytułu zostało tymczasowo 
zawieszone lub uzależnione od złożenia przez wierzyciela zabezpieczenia, które 
dotychczas nie zostało wpłacone. 
**§ 2.** Jeżeli z zaświadczenia o utracie lub ograniczeniu wykonalności wynika, 
że 
wykonanie 
tytułu 
zostało 
tymczasowo 
ograniczone 
do 
środków 
zabezpieczających, sąd na wniosek dłużnika orzeka o ograniczeniu egzekucji do 
takich 
środków. 
Orzekając 
o ograniczeniu 
egzekucji 
do 
środków 
zabezpieczających, sąd określa sposób zabezpieczenia, stosując odpowiednio 
przepisy o sposobach zabezpieczenia roszczeń w postępowaniu zabezpieczającym. 
Na postanowienie sądu przysługuje zażalenie. 
**§ 3.** Na wniosek dłużnika sąd zawiesza postępowanie egzekucyjne 
prowadzone na podstawie tytułu wykonawczego, o którym mowa w art. 115314 
pkt 1 albo 5, jeżeli wykonalność tytułu została zawieszona w państwie 
członkowskim Unii Europejskiej, z którego tytuł pochodzi.

***
## Art. 115319. {#kpc-czwarta-czwarta-art-115319}

Na wniosek strony sąd zawiesza lub umarza postępowanie 
egzekucyjne prowadzone na podstawie tytułu wykonawczego, o którym mowa 
w art. 115314 pkt 6, jeżeli wnioskodawca przedstawił określone w przepisach 
rozporządzenia 
nr 606/2013 zaświadczenie 
potwierdzające 
zawieszenie, 
ograniczenie lub uchylenie środka ochrony.

***
## Art. 115319a. {#kpc-czwarta-czwarta-art-115319a}

**§ 1.** Jeżeli w ocenie sądu lub organu zachodzą: 
- 1) przesłanka odmowy uznania lub wykonania orzeczenia, o której mowa 
w art. 38, art. 39 lub art. 41 rozporządzenia nr 2019/1111 lub 
- 2) podstawa odmowy uznania i wykonania orzeczenia, o której mowa 
w art. 50 rozporządzenia nr 2019/1111, lub 
- 3) podstawa odmowy uznania lub wykonania dokumentu urzędowego lub 
porozumienia, o której mowa w art. 68 rozporządzenia nr 2019/1111 
– sąd lub organ odmawia prowadzenia postępowania na podstawie przedłożonego 
im orzeczenia, dokumentu urzędowego lub porozumienia objętych zakresem 
zastosowania tego rozporządzenia, pouczając jednocześnie wnioskodawcę 

 
 
 
s. 556/580 
 
2025-09-08 
 
o prawie do wystąpienia w trybie art. 115323 do sądu okręgowego z wnioskiem, 
o którym mowa w art. 115325 § 2 pkt 2. 
**§ 2.** Jeżeli w trakcie postępowania wykonawczego wystąpiono do sądu 
okręgowego z wnioskiem o odmowę uznania lub wykonania orzeczenia, 
dokumentu urzędowego lub porozumienia objętych zakresem zastosowania 
rozporządzenia nr 2019/1111, sąd lub organ może zawiesić postępowanie 
prowadzone na ich podstawie do czasu prawomocnego zakończenia postępowania 
przed sądem okręgowym. W razie oddalenia wniosku o odmowę uznania lub 
wykonania orzeczenia, dokumentu urzędowego lub porozumienia objętych 
zakresem zastosowania rozporządzenia nr 2019/1111 postępowanie prowadzone 
na ich podstawie umarza się.

***
## Art. 115320. {#kpc-czwarta-czwarta-art-115320}

**§ 1.** Na wniosek dłużnika sąd może zawiesić postępowanie 
egzekucyjne prowadzone na podstawie tytułu wykonawczego, o którym mowa 
w art. 115314 pkt 1–5, także wówczas, gdy możliwość taka wynika z przepisów, 
odpowiednio, 
rozporządzenia 
nr 1215/2012, 
rozporządzenia 
nr 805/2004, 
rozporządzenia nr 1896/2006, rozporządzenia nr 861/2007 lub rozporządzenia 
nr 4/2009. 
**§ 2.** Sąd może również, na wniosek dłużnika, ograniczyć egzekucję do 
środków zabezpieczających lub uzależnić wykonanie tytułu od złożenia przez 
wierzyciela stosownego zabezpieczenia, jeżeli taką możliwość przewidują przepisy 
rozporządzenia nr 1215/2012, rozporządzenia nr 805/2004, rozporządzenia 
nr 1896/2006, rozporządzenia nr 861/2007 lub rozporządzenia nr 4/2009. 
Orzekając o ograniczeniu egzekucji do środków zabezpieczających, sąd określa 
sposób zabezpieczenia, stosując odpowiednio przepisy o sposobach zabezpieczenia 
roszczeń w postępowaniu zabezpieczającym. Na postanowienie sądu przysługuje 
zażalenie.

***
## Art. 115321. {#kpc-czwarta-czwarta-art-115321}

Organ egzekucyjny umarza postępowanie egzekucyjne w całości 
lub w części na wniosek także wtedy, gdy: 
- 1) postępowanie jest prowadzone na podstawie tytułu wykonawczego, o którym 
mowa w art. 115314 pkt 2, a dłużnik przedstawi przewidziane w przepisach 
rozporządzenia nr 805/2004 zaświadczenie o utracie lub ograniczeniu 
wykonalności, z którego wynika, że tytuł nie jest już wykonalny; 

 
 
 
s. 557/580 
 
2025-09-08 
- 2) prawomocnym orzeczeniem odmówiono uznania lub wykonania tytułu 
wykonawczego, o którym mowa w art. 115314.

***
## Art. 115322. {#kpc-czwarta-czwarta-art-115322}

Przepisy art. 115316, art. 115319 i art. 115321 pkt 2 stosuje się 
odpowiednio do orzeczeń obejmujących środki ochrony wchodzące w zakres 
zastosowania rozporządzenia nr 606/2013, które podlegają wykonaniu w inny 
sposób niż w drodze egzekucji.

***
## Art. 115322a. {#kpc-czwarta-czwarta-art-115322a}

**§ 1.** Przepisy art. 11443, art. 11449, art. 114412 i art. 114413 
stosuje się odpowiednio do postępowania wykonawczego dotyczącego tytułu 
zabezpieczenia, o którym mowa w art. 115315a. 
**§ 2.** Właściwym organem w rozumieniu art. 4 pkt 14 rozporządzenia nr 
655/2014 w zakresie czynności, o których mowa w art. 10 ust. 2, art. 23 ust. 3, 5 i 
6, art. 25 ust. 3, art. 27 ust. 2, art. 28 ust. 3 oraz art. 36 ust. 5 akapit drugi roz-
porządzenia nr 655/2014, jest komornik. W przypadku czynności, która była 
poprzedzona wystąpieniem do banku o wykonanie europejskiego nakazu 
zabezpieczenia na rachunku bankowym, właściwy jest komornik, który skierował 
do banku takie wystąpienie. 
**§ 3.** Właściwym sądem, o którym mowa w art. 34, art. 35 ust. 4 i art. 38 ust. 1 
lit. b rozporządzenia nr 655/2014, jest sąd rejonowy, w którego okręgu znajduje się 
siedziba banku wskazanego w europejskim nakazie zabezpieczenia na rachunku 
bankowym. Sąd orzeka na posiedzeniu niejawnym.

***
## Art. 115322b. {#kpc-czwarta-czwarta-art-115322b}

Czynności, o których mowa w art. 28, art. 52, art. 55 ust. 1 
i art. 56 rozporządzenia nr 2019/1111, oraz czynności dotyczące zawieszenia 
postępowania w sprawie wykonania orzeczenia oraz odmowy wykonania 
orzeczenia na podstawie art. 57 tego rozporządzenia wykonuje sąd właściwy do 
wykonania orzeczenia. 
### TYTUŁ III
Odmowa uznania lub wykonania

***
## Art. 115323. {#kpc-czwarta-czwarta-art-115323}

**§ 1.** Wniosek 
o odmowę 
wykonania, 
o którym 
mowa 
w przepisach 
rozporządzenia 
nr 1215/2012, 
rozporządzenia 
nr 805/2004, 
rozporządzenia nr 1896/2006, rozporządzenia nr 861/2007, rozporządzenia 
nr 4/2009 lub rozporządzenia nr 606/2013, wnosi się do sądu okręgowego miejsca 

 
 
 
s. 558/580 
 
2025-09-08 
 
zamieszkania albo siedziby dłużnika, a w braku takiego sądu – do sądu 
okręgowego, w którego okręgu ma być lub jest prowadzona egzekucja. 
**§ 2.** Wniosek o odmowę uznania i wniosek o stwierdzenie braku podstaw do 
odmowy uznania, przewidziane w przepisach rozporządzenia nr 1215/2012, oraz 
wniosek 
o odmowę 
uznania, 
przewidziany 
w przepisach 
rozporządzenia 
nr 606/2013, wnosi się do sądu okręgowego, który byłby miejscowo właściwy do 
rozpoznania sprawy rozstrzygniętej orzeczeniem lub w którego okręgu znajduje się 
miejscowo właściwy sąd rejonowy, a w braku tej podstawy – do Sądu Okręgowego 
w Warszawie. 
**§ 3.** W terminie wyznaczonym przez sąd przeciwnik może przedstawić swoje 
stanowisko w sprawie. 
**§ 4.** Sąd rozpoznaje wniosek na posiedzeniu niejawnym.

***
## Art. 115324. {#kpc-czwarta-czwarta-art-115324}

Na postanowienie w przedmiocie odmowy wykonania, odmowy 
uznania albo stwierdzenia braku podstaw do odmowy uznania przysługuje 
zażalenie, a od postanowienia sądu apelacyjnego – skarga kasacyjna; można także 
żądać wznowienia postępowania, które zostało zakończone prawomocnym 
postanowieniem w przedmiocie odmowy wykonania, odmowy uznania albo 
stwierdzenia braku podstaw do odmowy uznania, oraz stwierdzenia niezgodności 
z prawem prawomocnego postanowienia wydanego w tym przedmiocie.

***
## Art. 115325. {#kpc-czwarta-czwarta-art-115325}

**§ 1.** Przepisy art. 115323 i art. 115324 stosuje się odpowiednio do 
orzeczeń obejmujących środki ochrony wchodzące w zakres zastosowania 
rozporządzenia nr 606/2013, które podlegają wykonaniu w inny sposób niż 
w drodze egzekucji. 
**§ 2.** Przepisy art. 115323 i art. 115324 stosuje się odpowiednio do: 
- 1) wniosku o odmowę uznania lub wykonania orzeczenia, dokumentu 
urzędowego i porozumienia objętych zakresem zastosowania rozporządzenia 
nr 2019/1111 na podstawie przesłanki lub podstawy, o których mowa 
w art. 38, art. 39, art. 41, art. 50 lub art. 68 tego rozporządzenia; 
- 2) wniosku o stwierdzenie braku podstaw do odmowy uznania orzeczenia, 
dokumentu urzędowego i porozumienia objętych zakresem zastosowania 
rozporządzenia nr 2019/1111 na podstawie przesłanki lub podstawy, 

 
 
 
s. 559/580 
 
2025-09-08 
 
o których mowa w art. 38, art. 39, art. 41, art. 50 lub art. 68 tego 
rozporządzenia.

