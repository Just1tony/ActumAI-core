---
id: code.kpc.czesc.czwarta.ksiega.trzecia
title: "Kodeks postępowania cywilnego — CZĘŚĆ CZWARTA — KSIĘGA TRZECIA (UZNANIE I STWIERDZENIE WYKONALNOŚCI)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1964 Nr 43 poz. 296"
consolidated_citation: "t.j. Dz.U. 2024 poz. 1568, 1841; Dz.U. 2025 poz. 620, 1172"
status: "obowiązujący"
last_consolidated: "2025-09-08"
aliases: ["KPC — CZĘŚĆ CZWARTA — Księga TRZECIA"]
tags: ["KPC","Kodeks postępowania cywilnego","CZĘŚĆ CZWARTA","Księga TRZECIA","PL"]
source_pdf: "D19640296Lj.pdf"
articles: "Art. 1145–1153"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpc-czwarta-trzecia-art-{n}}"
  separators: "***"
  hierarchy: ["CZĘŚĆ","KSIĘGA","TYTUŁ","DZIAŁ","Rozdział"]
---

# Kodeks postępowania cywilnego — CZĘŚĆ CZWARTA — KSIĘGA TRZECIA: UZNANIE I STWIERDZENIE WYKONALNOŚCI

UZNANIE I STWIERDZENIE WYKONALNOŚCI 
### TYTUŁ I
Uznanie orzeczeń sądów państw obcych lub rozstrzygnięć innych organów 
państw obcych
***
## Art. 1145. {#kpc-czwarta-trzecia-art-1145}

Orzeczenia sądów państw obcych wydane w sprawach cywilnych 
podlegają uznaniu z mocy prawa, chyba że istnieją przeszkody określone 
w art. 1146.

***
## Art. 1146. {#kpc-czwarta-trzecia-art-1146}

**§ 1.** Orzeczenie nie podlega uznaniu, jeżeli: 
- 1) nie jest prawomocne w państwie, w którym zostało wydane; 
- 2) zapadło w sprawie należącej do wyłącznej jurysdykcji sądów polskich; 
- 3) pozwanemu, który nie wdał się w spór co do istoty sprawy, nie doręczono 
należycie i w czasie umożliwiającym podjęcie obrony pisma wszczynającego 
postępowanie; 
- 4) strona w toku postępowania była pozbawiona możności obrony; 

 
 
 
s. 548/580 
 
2025-09-08 
- 5) sprawa o to samo roszczenie między tymi samymi stronami zawisła 
w Rzeczypospolitej Polskiej wcześniej niż przed sądem państwa obcego; 
- 6) jest sprzeczne z wcześniej wydanym prawomocnym orzeczeniem sądu 
polskiego albo wcześniej wydanym prawomocnym orzeczeniem sądu 
państwa obcego, spełniającym przesłanki jego uznania w Rzeczypospolitej 
Polskiej, zapadłymi w sprawie o to samo roszczenie między tymi samymi 
stronami; 
- 7) uznanie byłoby sprzeczne z podstawowymi zasadami porządku prawnego 
Rzeczypospolitej Polskiej (klauzula porządku publicznego). 
**§ 2.** Przeszkody określone w § 1 pkt 5 i 6 stosuje się odpowiednio do sprawy 
zawisłej przed innym niż sąd organem polskim lub organem państwa obcego oraz 
do rozstrzygnięcia wydanego przez inny niż sąd organ polski lub organ państwa 
obcego. 
**§ 3.** Przepisów § 1 pkt 5 i 6 nie stosuje się, gdy orzeczenie sądu państwa 
obcego stwierdza, zgodnie z przepisami tego państwa o jurysdykcji krajowej, 
nabycie przez osobę mieszkającą albo mającą siedzibę w Rzeczypospolitej Polskiej 
mienia spadkowego znajdującego się w chwili śmierci spadkodawcy na obszarze 
państwa obcego.

***
## Art. 1147. {#kpc-czwarta-trzecia-art-1147}

**§ 1.** Osoba powołująca się na uznanie orzeczenia sądu państwa 
obcego jest zobowiązana przedstawić: 
- 1) urzędowy odpis orzeczenia; 
- 2) dokument stwierdzający, że orzeczenie jest prawomocne, chyba że 
prawomocność orzeczenia wynika z jego treści; 
- 3) uwierzytelniony przekład na język polski dokumentów wymienionych 
w pkt 1 i 2 oraz w § 2. 
**§ 2.** Jeżeli orzeczenie zostało wydane w postępowaniu, w którym pozwany 
nie wdał się w spór co do istoty sprawy, należy przedstawić dokument 
stwierdzający, że pismo wszczynające postępowanie zostało mu doręczone.

***
## Art. 1148. {#kpc-czwarta-trzecia-art-1148}

**§ 1.** Każdy, kto ma w tym interes prawny, może wystąpić do sądu 
z wnioskiem o ustalenie, że orzeczenie sądu państwa obcego podlega albo nie 
podlega uznaniu. 

 
 
 
s. 549/580 
 
2025-09-08 
**§ 2.** Do wniosku o ustalenie, że orzeczenie sądu państwa obcego podlega 
uznaniu, należy dołączyć dokumenty wymienione w art. 1147, a do wniosku 
o ustalenie, że orzeczenie nie podlega uznaniu, urzędowy odpis orzeczenia wraz 
z jego uwierzytelnionym przekładem na język polski.

***
## Art. 11481. {#kpc-czwarta-trzecia-art-11481}

**§ 1.** Wniosek, o którym mowa w art. 1148, rozpoznaje sąd 
okręgowy, który byłby miejscowo właściwy do rozpoznania sprawy rozstrzygniętej 
orzeczeniem sądu państwa obcego lub w którego okręgu znajduje się miejscowo 
właściwy sąd rejonowy, a w braku tej podstawy – Sąd Okręgowy w Warszawie. 
**§ 2.** W terminie dwóch tygodni od doręczenia wniosku strona może 
przedstawić sądowi stanowisko w sprawie. Sąd może rozpoznać wniosek na 
posiedzeniu niejawnym. 
**§ 3.** Na postanowienie sądu okręgowego w przedmiocie ustalenia przysługuje 
zażalenie, a od postanowienia sądu apelacyjnego – skarga kasacyjna; można także 
żądać wznowienia postępowania, które zostało zakończone prawomocnym 
postanowieniem w przedmiocie ustalenia, oraz stwierdzenia niezgodności 
z prawem prawomocnego postanowienia wydanego w tym przedmiocie.

***
## Art. 1149. {#kpc-czwarta-trzecia-art-1149}

Przepisy 
art. 170 
i art. 400 stosuje 
się 
odpowiednio 
do 
prawomocnych postanowień sądu polskiego ustalających, że orzeczenia sądu 
państwa obcego orzekające rozwód lub unieważnienie małżeństwa albo ustalające 
nieistnienie małżeństwa podlegają uznaniu.

***
## Art. 11491. {#kpc-czwarta-trzecia-art-11491}

Przepisy tytułu niniejszego stosuje się odpowiednio do 
rozstrzygnięć innych organów państw obcych wydanych w sprawach cywilnych. 
### TYTUŁ II
Wykonalność orzeczeń sądów państw obcych lub rozstrzygnięć innych 
organów państw obcych oraz ugód zawartych przed takimi sądami 
i organami lub przez nie zatwierdzonych

***
## Art. 1150. {#kpc-czwarta-trzecia-art-1150}

Orzeczenia sądów państw obcych w sprawach cywilnych, 
nadające się do wykonania w drodze egzekucji, stają się tytułami wykonawczymi 
po stwierdzeniu ich wykonalności przez sąd polski. Stwierdzenie wykonalności 
następuje, jeżeli orzeczenie jest wykonalne w państwie, z którego pochodzi, oraz 
nie istnieją przeszkody określone w art. 1146 § 1 i 2. 

 
 
 
s. 550/580 
 
2025-09-08

***
## Art. 1151. {#kpc-czwarta-trzecia-art-1151}

**§ 1.** Stwierdzenie wykonalności następuje na wniosek wierzyciela 
przez nadanie orzeczeniu sądu państwa obcego klauzuli wykonalności. 
**§ 2.** Do wniosku o nadanie klauzuli wykonalności należy dołączyć 
dokumenty wymienione w art. 1147, a ponadto dokument stwierdzający, że 
orzeczenie jest wykonalne w państwie, z którego pochodzi, chyba że wykonalność 
wynika z treści orzeczenia lub prawa tego państwa.

***
## Art. 11511. {#kpc-czwarta-trzecia-art-11511}

**§ 1.** O nadaniu klauzuli wykonalności orzeka sąd okręgowy 
miejsca zamieszkania albo siedziby dłużnika, a w braku takiego sądu – sąd 
okręgowy, w którego okręgu ma być prowadzona egzekucja. 
**§ 2.** W terminie dwóch tygodni od dnia doręczenia odpisu wniosku dłużnik 
może przedstawić stanowisko w sprawie. Sąd rozpoznaje wniosek na posiedzeniu 
niejawnym. 
**§ 3.** Na postanowienie sądu okręgowego w przedmiocie nadania klauzuli 
wykonalności służy zażalenie, a od postanowienia sądu apelacyjnego – skarga 
kasacyjna; można także żądać wznowienia postępowania, które zostało zakończone 
prawomocnym postanowieniem w przedmiocie nadania klauzuli wykonalności, 
oraz stwierdzenia niezgodności z prawem prawomocnego postanowienia 
wydanego w tym przedmiocie. Przepisu art. 795 § 2 nie stosuje się.

***
## Art. 11512. {#kpc-czwarta-trzecia-art-11512}

**§ 1.** Egzekucja na podstawie orzeczenia sądu państwa obcego 
może być wszczęta po uprawomocnieniu się postanowienia o nadaniu klauzuli 
wykonalności. Do czasu upływu terminu do wniesienia zażalenia na postanowienie 
sądu okręgowego o nadaniu klauzuli wykonalności, a w razie wniesienia zażalenia 
– do czasu jego rozpoznania przez sąd apelacyjny, postanowienie to stanowi tytuł 
zabezpieczenia. Sposób zabezpieczenia określa wierzyciel we wniosku o 
dokonanie zabezpieczenia. Dla orzeczeń obejmujących roszczenia pieniężne 
dopuszczalne są wyłącznie rodzaje zabezpieczeń wymienione w art. 747. W razie 
potrzeby rodzaj zabezpieczenia może określić na wniosek wierzyciela także sąd 
okręgowy w postanowieniu o nadaniu klauzuli wykonalności. Do zabezpieczenia 
tego art. 750–7526, art. 7541, art. 755 i art. 757 stosuje się odpowiednio. 
**§ 2.** Wykonanie zabezpieczenia, o którym mowa w § 1, sąd okręgowy może 
uzależnić od złożenia przez wierzyciela kaucji. Dłużnikowi przysługuje 

 
 
 
s. 551/580 
 
2025-09-08 
 
pierwszeństwo zaspokojenia z kaucji złożonej przez wierzyciela przed wszystkimi 
innymi wierzycielami wierzyciela. 
**§ 3.** W razie oddalenia zażalenia na postanowienie o nadaniu klauzuli 
wykonalności albo wydania postanowienia o nadaniu klauzuli wykonalności sąd 
apelacyjny może uzależnić wykonanie orzeczenia sądu państwa obcego od złożenia 
stosownego zabezpieczenia przez wierzyciela. Sąd może, jeżeli na skutek 
wykonania orzeczenia mogłaby wyniknąć dla dłużnika niepowetowana szkoda, 
wstrzymać wykonanie orzeczenia do czasu upływu terminu do wniesienia skargi 
kasacyjnej, a w razie jej wniesienia – do czasu jej rozpoznania przez Sąd 
Najwyższy.

***
## Art. 11513. {#kpc-czwarta-trzecia-art-11513}

W przypadkach, o których mowa w art. 840 § 1, podstawy 
powództwa o pozbawienie wykonalności orzeczenia sądu państwa obcego 
zaopatrzonego w klauzulę wykonalności nie mogą stanowić zarzuty co do 
przeszkód określonych w art. 1146 § 1 i 2.

***
## Art. 11514. {#kpc-czwarta-trzecia-art-11514}

Przepisy 
art. 1150–11513 stosuje 
się 
odpowiednio 
do 
rozstrzygnięć innych organów państw obcych wydanych w sprawach cywilnych.

***
## Art. 1152. {#kpc-czwarta-trzecia-art-1152}

Ugody w sprawach cywilnych zawarte przed sądami i innymi 
organami państw obcych lub przez nie zatwierdzone stają się tytułami 
wykonawczymi po stwierdzeniu ich wykonalności, jeżeli są one wykonalne 
w państwie pochodzenia i nie są sprzeczne z podstawowymi zasadami porządku 
prawnego w Rzeczypospolitej Polskiej (klauzula porządku publicznego). Przepisy 
art. 1151–11513 stosuje się odpowiednio.

***
## Art. 1153. {#kpc-czwarta-trzecia-art-1153}

(uchylony) 
### TYTUŁ III
(zawierający art. 11531–11533 – uchylony) 
### TYTUŁ IV
(zawierający art. 11534–11536 – uchylony)  
### TYTUŁ V
(zawierający art. 11537–11539 – uchylony)  
### TYTUŁ VI
(zawierający art. 115310–115312 – uchylony)  

 
 
 
s. 552/580 
 
2025-09-08

