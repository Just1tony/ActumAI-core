---
id: code.kpc.czesc.piata.ksiega.all
title: "Kodeks postępowania cywilnego — CZĘŚĆ PIĄTA — KSIĘGA — (—)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1964 Nr 43 poz. 296"
consolidated_citation: "t.j. Dz.U. 2024 poz. 1568, 1841; Dz.U. 2025 poz. 620, 1172"
status: "obowiązujący"
last_consolidated: "2025-09-08"
aliases: ["KPC — CZĘŚĆ PIĄTA — Księga —"]
tags: ["KPC","Kodeks postępowania cywilnego","CZĘŚĆ PIĄTA","Księga —","PL"]
source_pdf: "D19640296Lj.pdf"
articles: "Art. 1154–1217"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpc-piata--art-{n}}"
  separators: "***"
  hierarchy: ["CZĘŚĆ","KSIĘGA","TYTUŁ","DZIAŁ","Rozdział"]
---

# Kodeks postępowania cywilnego — CZĘŚĆ PIĄTA — KSIĘGA —: —

# CZĘŚĆ PIĄTA 
SĄD POLUBOWNY (ARBITRAŻOWY) 
### TYTUŁ I
Przepisy ogólne
***
## Art. 1154. {#kpc-piata--art-1154}

Przepisy części niniejszej stosuje się, jeżeli miejsce postępowania 
przed sądem polubownym znajduje się na terytorium Rzeczypospolitej Polskiej, 
a w wypadkach w części tej określonych – także wtedy, gdy miejsce postępowania 
przed sądem polubownym znajduje się poza granicami Rzeczypospolitej Polskiej 
lub nie jest oznaczone.

***
## Art. 1155. {#kpc-piata--art-1155}

**§ 1.** Miejsce postępowania przed sądem polubownym wskazują 
strony, a w razie braku takiego wskazania określa je sąd polubowny, biorąc pod 
uwagę przedmiot postępowania, okoliczności sprawy i dogodność dla stron. 
**§ 2.** Jeżeli miejsce postępowania przed sądem polubownym nie zostało 
określone przez strony ani przez sąd polubowny, uważa się, że miejsce tego 
postępowania znajdowało się na terytorium Rzeczypospolitej Polskiej, gdy na tym 
terytorium wydane zostało orzeczenie kończące postępowanie w sprawie.

***
## Art. 1156. {#kpc-piata--art-1156}

Sądom polskim przysługuje jurysdykcja krajowa w sprawach 
uregulowanych przepisami niniejszej części, jeżeli miejsce postępowania przed 
sądem polubownym znajduje się na terytorium Rzeczypospolitej Polskiej. Sądom 
polskim przysługuje jurysdykcja krajowa także wtedy, gdy przepisy niniejszej 
części przewidują czynności sądu w związku z postępowaniem przed sądem 
polubownym, którego miejsce znajduje się poza granicami Rzeczypospolitej 
Polskiej albo nie jest oznaczone.

***
## Art. 1157. {#kpc-piata--art-1157}

Jeżeli przepis szczególny nie stanowi inaczej, strony mogą poddać 
pod rozstrzygnięcie sądu polubownego: 
- 1) spory o prawa majątkowe, z wyjątkiem spraw o alimenty; 
- 2) spory o prawa niemajątkowe, jeżeli mogą one być przedmiotem ugody 
sądowej. 

 
 
 
s. 560/580 
 
2025-09-08

***
## Art. 1158. {#kpc-piata--art-1158}

**§ 1.** Ilekroć w części niniejszej mowa jest o sądzie, rozumie się 
przez to sąd, który byłby właściwy do rozpoznania sprawy, gdyby strony nie 
dokonały zapisu na sąd polubowny. 
**§ 2.** Przepisy części niniejszej stosuje się zarówno do sądu polubownego 
powołanego do rozstrzygnięcia poszczególnego sporu, jak i składu orzekającego 
powołanego w ramach stałego sądu polubownego.

***
## Art. 1159. {#kpc-piata--art-1159}

**§ 1.** W zakresie uregulowanym przepisami niniejszej części sąd 
może podejmować czynności jedynie wtedy, gdy ustawa tak stanowi. 
**§ 2.** Na postanowienie sądu przysługuje zażalenie w wypadkach wskazanych 
w ustawie. 
**§ 3.** W wypadkach, o których mowa w art. 1171, 1172, 1177, 1178 i 1179, sąd 
może orzec na posiedzeniu niejawnym. Przed rozstrzygnięciem sąd może 
wysłuchać strony, wysłuchanie może odbyć się także przez odebranie oświadczenia 
na piśmie. W miarę potrzeby sąd może zażądać, aby oświadczenie na piśmie 
zawierało podpis notarialnie poświadczony.

***
## Art. 1160. {#kpc-piata--art-1160}

**§ 1.** Jeżeli strony nie postanowiły inaczej, zawiadomienie pisemne 
uważa się za doręczone, gdy zostało wręczone osobiście adresatowi albo 
dostarczono je do jego siedziby albo miejsca jego zwykłego pobytu lub na 
wskazany przez niego adres pocztowy. 
**§ 2.** Jeżeli adresat jest przedsiębiorcą wpisanym do właściwego rejestru 
sądowego albo innego publicznego rejestru, zawiadomienie uważa się za 
doręczone, gdy doszło na adres wskazany w rejestrze, chyba że strona podała inny 
adres do doręczeń. 
**§ 3.** Jeżeli żadnego z miejsc wymienionych w paragrafach poprzedzających 
nie można ustalić pomimo dołożenia należytej staranności, zawiadomienie pisemne 
uważa się za doręczone, gdy zostało wysłane do ostatniego znanego miejsca 
siedziby albo ostatniego znanego miejsca zwykłego pobytu adresata. W takim 
wypadku zawiadomienie uważa się za doręczone w ostatnim dniu okresu, w którym 
przesyłka mogła zostać odebrana przez adresata. 
**§ 4.** Przepisów paragrafów poprzedzających nie stosuje się do doręczeń 
sądowych. 

 
 
 
s. 561/580 
 
2025-09-08 
### TYTUŁ II
Zapis na sąd polubowny

***
## Art. 1161. {#kpc-piata--art-1161}

**§ 1.** Poddanie sporu pod rozstrzygnięcie sądu polubownego 
wymaga umowy stron, w której należy wskazać przedmiot sporu lub stosunek 
prawny, z którego spór wyniknął lub może wyniknąć (zapis na sąd polubowny). 
**§ 2.** Bezskuteczne są postanowienia zapisu na sąd polubowny naruszające 
zasadę równości stron, w szczególności uprawniające tylko jedną stronę do 
wytoczenia powództwa przed sądem polubownym przewidzianym w zapisie albo 
przed sądem. 
**§ 3.** Zapis na sąd polubowny może wskazywać stały sąd polubowny jako 
właściwy do rozstrzygnięcia sporu. Jeżeli strony nie postanowiły inaczej, wiąże je 
regulamin stałego sądu polubownego obowiązujący w dacie wniesienia pozwu.

***
## Art. 11611. {#kpc-piata--art-11611}

**§ 1.** W sprawie zawisłej przed sądem strony mogą poddać spór 
pod rozstrzygnięcie sądu polubownego aż do momentu prawomocnego 
rozstrzygnięcia sprawy przez sąd. 
**§ 2.** Sąd umorzy postępowanie na zgodny wniosek stron, złożony po zawarciu 
przez strony zapisu na sąd polubowny, chyba że z treści tego zapisu i okoliczności 
sprawy wynika, że byłoby to sprzeczne z prawem, zasadami współżycia 
społecznego lub zmierzałoby do obejścia prawa albo zapis na sąd polubowny jest 
nieważny lub bezskuteczny. Termin przedawnienia objętych zapisem na sąd 
polubowny roszczeń zaczyna biec od nowa od dnia uprawomocnienia się 
postanowienia o umorzeniu postępowania.

***
## Art. 1162. {#kpc-piata--art-1162}

**§ 1.** Zapis na sąd polubowny powinien być sporządzony na piśmie. 
**§ 2.** Wymaganie dotyczące formy zapisu na sąd polubowny jest spełnione 
także wtedy, gdy zapis zamieszczony został w wymienionych między stronami 
pismach lub oświadczeniach złożonych za pomocą środków porozumiewania się 
na odległość, które pozwalają utrwalić ich treść. Powołanie się w umowie na 
dokument zawierający postanowienie o poddaniu sporu pod rozstrzygnięcie sądu 
polubownego spełnia wymagania dotyczące formy zapisu na sąd polubowny, jeżeli 
umowa ta jest sporządzona na piśmie, a to powołanie się jest tego rodzaju, że czyni 
zapis częścią składową umowy. 

 
 
 
s. 562/580 
 
2025-09-08

***
## Art. 1163. {#kpc-piata--art-1163}

**§ 1.** Zamieszczony w umowie (statucie) spółki handlowej zapis na 
sąd polubowny dotyczący sporów ze stosunku spółki wiąże spółkę, jej wspólników 
oraz organy spółki i ich członków. 
**§ 2.** W sprawach o uchylenie lub stwierdzenie nieważności uchwały 
zgromadzenia wspólników spółki z ograniczoną odpowiedzialnością albo walnego 
zgromadzenia spółki akcyjnej zapis na sąd polubowny jest skuteczny, jeżeli 
przewiduje obowiązek ogłoszenia o wszczęciu postępowania w sposób wymagany 
dla ogłoszeń spółki najpóźniej w terminie miesiąca od dnia jego wszczęcia; 
ogłoszenie może zamieścić również powód. W sprawach tych każdy wspólnik albo 
akcjonariusz może przystąpić do postępowania po jednej ze stron w terminie 
miesiąca od dnia ogłoszenia. Skład sądu polubownego wyznaczony w sprawie 
najwcześniej wszczętej rozpoznaje wszystkie pozostałe sprawy o uchylenie lub 
stwierdzenie nieważności tej samej uchwały zgromadzenia wspólników spółki 
z ograniczoną odpowiedzialnością albo walnego zgromadzenia spółki akcyjnej. 
**§ 3.** Przepisy § 1 i 2 stosuje się odpowiednio do zapisów na sąd polubowny 
zawartych w statucie fundacji rodzinnej, spółdzielni lub stowarzyszenia.

***
## Art. 1164. {#kpc-piata--art-1164}

Zapis na sąd polubowny obejmujący spory z zakresu prawa pracy 
może być sporządzony tylko po powstaniu sporu i wymaga zachowania formy 
pisemnej. Przepisu art. 1162 § 2 nie stosuje się.

***
## Art. 11641. {#kpc-piata--art-11641}

**§ 1.** Zapis na sąd polubowny obejmujący spory wynikające z 
umów, których stroną jest konsument, może być sporządzony tylko po powstaniu 
sporu i wymaga zachowania formy pisemnej. Przepisu art. 1162 § 2 nie stosuje się. 
**§ 2.** W zapisie na sąd polubowny, o którym mowa w § 1, należy także wskazać 
pod rygorem nieważności, że stronom znane są skutki zapisu na sąd polubowny, w 
szczególności co do mocy prawnej wyroku sądu polubownego lub ugody przed nim 
zawartej na równi z wyrokiem sądu lub ugodą zawartą przed sądem po ich uznaniu 
przez sąd lub po stwierdzeniu przez sąd ich wykonalności.

***
## Art. 1165. {#kpc-piata--art-1165}

**§ 1.** W razie wniesienia do sądu sprawy dotyczącej sporu objętego 
zapisem na sąd polubowny, sąd odrzuca pozew lub wniosek o wszczęcie 
postępowania nieprocesowego, jeżeli pozwany albo uczestnik postępowania 
nieprocesowego podniósł zarzut zapisu na sąd polubowny przed wdaniem się 
w spór co do istoty sprawy. 

 
 
 
s. 563/580 
 
2025-09-08 
**§ 11.** Sąd z urzędu odrzuca pozew lub wniosek o wszczęcie postępowania 
nieprocesowego, jeżeli dotyczy on sporu, który był przedmiotem sprawy 
umorzonej na podstawie art. 11611 § 2. 
**§ 2.** Przepisu § 1 nie stosuje się, gdy zapis na sąd polubowny jest nieważny, 
bezskuteczny, niewykonalny albo utracił moc, jak również wtedy, gdy sąd 
polubowny orzekł o swej niewłaściwości. 
**§ 3.** Wniesienie sprawy do sądu nie stanowi przeszkody do rozpoznania 
sprawy przez sąd polubowny. 
**§ 4.** Przepisy paragrafów poprzedzających stosuje się także, gdy miejsce 
postępowania przed sądem polubownym znajduje się poza granicami 
Rzeczypospolitej Polskiej lub nie jest oznaczone.

***
## Art. 1166. {#kpc-piata--art-1166}

**§ 1.** Poddanie sporu pod rozstrzygnięcie sądu polubownego nie 
wyłącza możliwości zabezpieczenia przez sąd roszczeń dochodzonych przed sądem 
polubownym. 
**§ 2.** Przepis § 1 stosuje się także, gdy miejsce postępowania przed sądem 
polubownym znajduje się poza granicami Rzeczypospolitej Polskiej lub nie jest 
oznaczone.

***
## Art. 1167. {#kpc-piata--art-1167}

Pełnomocnictwo do dokonania czynności prawnej udzielone przez 
przedsiębiorcę obejmuje również umocowanie do sporządzenia zapisu na sąd 
polubowny w zakresie sporów wynikających z tej czynności prawnej, chyba że 
z pełnomocnictwa wynika co innego.

***
## Art. 1168. {#kpc-piata--art-1168}

**§ 1.** Jeżeli osoba wyznaczona w zapisie na sąd polubowny jako 
arbiter lub arbiter przewodniczący odmawia pełnienia tej funkcji lub gdy pełnienie 
przez nią tej funkcji okaże się z innych przyczyn niemożliwe, zapis na sąd 
polubowny traci moc, chyba że strony postanowiły inaczej. 
**§ 2.** W braku odmiennej umowy stron, zapis na sąd polubowny traci moc, 
w przypadku gdy sąd polubowny wskazany w tym zapisie nie przyjął sprawy do 
rozpoznania lub gdy rozpoznanie sprawy w ramach tego sądu okazało się z innych 
przyczyn niemożliwe. 

 
 
 
s. 564/580 
 
2025-09-08 
### TYTUŁ III
Skład sądu polubownego

***
## Art. 1169. {#kpc-piata--art-1169}

**§ 1.** Strony mogą w umowie określić liczbę sędziów sądu 
polubownego (arbitrów). 
**§ 2.** W braku takiego określenia powołuje się sąd polubowny w składzie 
trzech arbitrów. 
**§ 21.** Jeżeli z powództwem występują albo pozwano dwie lub więcej osób, 
powołują one arbitra jednomyślnie, chyba że zapis na sąd polubowny stanowi 
inaczej. 
**§ 3.** Postanowienia umowy przyznające jednej ze stron więcej uprawnień przy 
powołaniu sądu polubownego są bezskuteczne.

***
## Art. 1170. {#kpc-piata--art-1170}

**§ 1.** Arbitrem może być osoba fizyczna bez względu na 
obywatelstwo, mająca pełną zdolność do czynności prawnych. 
**§ 2.** Arbitrem nie może być sędzia państwowy. Nie dotyczy to sędziów 
w stanie spoczynku.

***
## Art. 1171. {#kpc-piata--art-1171}

**§ 1.** Strony mogą uzgodnić sposób powołania arbitrów. 
**§ 2.** W braku takiego uzgodnienia arbitrów powołuje się w sposób 
następujący: 
- 1) jeżeli sprawa ma być rozpoznawana przez sąd polubowny składający się 
z nieparzystej liczby arbitrów, każda ze stron powołuje równą liczbę arbitrów, 
a następnie arbitrzy powołują arbitra przewodniczącego; jeżeli strona nie 
powoła arbitra lub arbitrów w terminie miesiąca od dnia otrzymania żądania 
drugiej strony, aby to uczyniła, lub jeżeli arbitrzy powołani przez strony nie 
powołali arbitra przewodniczącego w terminie miesiąca od dnia ich powoła-
nia, arbitra lub arbitrów lub arbitra przewodniczącego powołuje sąd na 
wniosek którejkolwiek ze stron; 
- 2) jeżeli sprawa ma być rozpoznawana przez jedynego arbitra, a w terminie 
miesiąca od dnia, w którym jedna ze stron zwróciła się o wspólne powołanie 
arbitra, strony tego nie uczyniły, arbitra powołuje sąd na wniosek 
którejkolwiek ze stron; 
- 3) jeżeli sprawa ma być rozpoznawana przez sąd polubowny składający się 
z parzystej liczby arbitrów, każda ze stron powołuje równą liczbę arbitrów, 

 
 
 
s. 565/580 
 
2025-09-08 
 
a arbitrzy wybierają ze swego grona przewodniczącego; jeżeli strona nie 
powoła arbitra lub arbitrów w terminie miesiąca od dnia otrzymania żądania 
drugiej strony, aby to uczyniła, lub jeżeli arbitrzy powołani przez strony nie 
wybrali arbitra przewodniczącego w terminie miesiąca od dnia ich powołania, 
arbitra lub arbitrów lub arbitra przewodniczącego powołuje sąd na wniosek 
którejkolwiek ze stron. 
**§ 3.** Strona lub strony mogą powołać także arbitra zastępczego na wypadek 
śmierci, ustąpienia, odwołania (wygaśnięcia powołania) arbitra przez nie 
wyznaczonego.

***
## Art. 1172. {#kpc-piata--art-1172}

Jeżeli według umowy stron arbitra lub arbitra przewodniczącego 
ma powołać osoba trzecia, która nie dokonała tego w terminie przez strony 
określonym, a gdy strony tego terminu nie określiły, w terminie miesiąca od dnia 
wezwania jej, aby to uczyniła, każda ze stron może wystąpić do sądu z wnioskiem 
o powołanie arbitra lub arbitra przewodniczącego, chyba że strony postanowiły 
inaczej.

***
## Art. 1173. {#kpc-piata--art-1173}

**§ 1.** Powołując arbitra, sąd bierze pod uwagę kwalifikacje, jakie 
arbiter powinien mieć stosownie do porozumienia stron, oraz inne okoliczności, 
które zapewniają powołanie na arbitra osoby niezależnej i bezstronnej. 
**§ 2.** Powołując jedynego arbitra albo arbitra przewodniczącego w sporze 
między stronami mającymi miejsce zamieszkania lub siedzibę w różnych 
państwach, sąd powinien rozważyć potrzebę powołania osoby niezwiązanej 
z żadnym z tych państw.

***
## Art. 1174. {#kpc-piata--art-1174}

**§ 1.** Osoba powołana na arbitra składa na piśmie każdej ze stron 
i pozostałym arbitrom oświadczenie o swojej bezstronności i niezależności. Osoba 
powołana na arbitra niezwłocznie ujawnia stronom wszystkie okoliczności, które 
mogłyby wzbudzić wątpliwości co do jej bezstronności lub niezależności. 
**§ 2.** Arbiter może być wyłączony tylko wtedy, gdy zachodzą okoliczności, 
które budzą uzasadnione wątpliwości co do jego bezstronności lub niezależności, 
a także wtedy, gdy nie ma kwalifikacji określonych w umowie stron. Wyłączenia 
arbitra, którego strona sama powołała lub w powołaniu którego uczestniczyła, 
może ona żądać tylko z przyczyn, o których się dowiedziała po jego powołaniu. 

 
 
 
s. 566/580 
 
2025-09-08

***
## Art. 1175. {#kpc-piata--art-1175}

Arbiter może ustąpić w każdym czasie. Jeżeli ustąpienie nastąpiło 
bez ważnych powodów, arbiter ponosi odpowiedzialność za wynikłą stąd szkodę.

***
## Art. 1176. {#kpc-piata--art-1176}

**§ 1.** Strony mogą określić tryb postępowania o wyłączenie arbitra. 
**§ 2.** Jeżeli w terminie miesiąca od dnia, w którym strona zgłosiła do sądu 
polubownego żądanie wyłączenia arbitra w trybie określonym przez strony, arbiter 
nie zostanie wyłączony, strona żądająca wyłączenia może w terminie następnych 
dwóch tygodni wystąpić do sądu z wnioskiem o wyłączenie arbitra. Odmienne 
postanowienia umowy stron są bezskuteczne. 
**§ 3.** Jeżeli strony nie postanowiły inaczej, strona żądająca wyłączenia arbitra 
powinna w terminie dwóch tygodni od dnia, w którym dowiedziała się o jego 
powołaniu, 
lub 
od dnia, w którym 
dowiedziała się o okolicznościach 
wymienionych w art. 1174 § 2, zawiadomić o tym na piśmie wszystkich arbitrów 
powołanych do rozstrzygnięcia sprawy oraz stronę przeciwną. W zawiadomieniu, 
które powinno być jednocześnie wysłane do wszystkich tych osób, należy wskazać 
okoliczności uzasadniające żądanie wyłączenia. 
**§ 4.** Jeżeli w terminie dwóch tygodni od dnia, w którym zgodnie z przepisem 
§ 3 doręczono arbitrowi zawiadomienie o żądaniu jego wyłączenia, arbiter ten sam 
nie ustąpi lub nie zostanie odwołany na mocy zgodnych oświadczeń stron 
złożonych na piśmie, strona żądająca wyłączenia może w terminie następnych 
dwóch tygodni wystąpić do sądu z wnioskiem o wyłączenie arbitra. 
**§ 5.** Jeżeli arbiter ustępuje lub zostaje odwołany przez strony w związku 
z żądaniem jego wyłączenia, nie oznacza to samo przez się, że żądanie to było 
uzasadnione. 
**§ 6.** Wniesienie do sądu wniosku, o którym mowa w § 2 i 4, nie ma wpływu 
na bieg postępowania przed sądem polubownym, chyba że sąd polubowny 
postanowi zawiesić to postępowanie do czasu rozstrzygnięcia takiego wniosku 
przez sąd.

***
## Art. 1177. {#kpc-piata--art-1177}

**§ 1.** Strony mogą w każdym czasie złożyć zgodne oświadczenie na 
piśmie o odwołaniu każdego z arbitrów. 
**§ 2.** Na wniosek którejkolwiek ze stron sąd może odwołać arbitra, jeżeli jest 
oczywiste, że arbiter nie wykona swych czynności w odpowiednim terminie, lub 
jeżeli opóźnia się z ich wykonywaniem bez uzasadnionej przyczyny. 

 
 
 
s. 567/580 
 
2025-09-08

***
## Art. 1178. {#kpc-piata--art-1178}

**§ 1.** W razie wygaśnięcia powołania arbitra nowy (zastępczy) 
arbiter jest powoływany w sposób, który jest przewidziany dla powołania arbitra. 
**§ 2.** Jeżeli ustąpienie lub odwołanie przez strony lub sąd arbitra powołanego 
przez jedną ze stron miało miejsce dwukrotnie, druga strona może zażądać, aby sąd 
wyznaczył nowego (zastępczego) arbitra za stronę przeciwną. Z wnioskiem takim 
strona może wystąpić w terminie tygodnia od dnia, w którym dowiedziała się, że 
nowy (zastępczy) arbiter powołany przez stronę przeciwną ustąpił lub został 
odwołany.

***
## Art. 1179. {#kpc-piata--art-1179}

**§ 1.** Arbiter ma prawo do wynagrodzenia za swoje czynności oraz 
do zwrotu wydatków poniesionych w związku z wykonywaniem tych czynności. 
Odpowiedzialność stron z tego tytułu jest solidarna. 
**§ 2.** Jeżeli co do wysokości wynagrodzenia i zwracanych wydatków nie 
nastąpiło porozumienie arbitra ze stronami, arbiter może żądać, aby sąd ustalił jego 
wynagrodzenie stosownie do nakładu pracy oraz wartości przedmiotu sporu, 
a także wydatki podlegające zwrotowi. 
**§ 3.** Na postanowienie sądu przysługuje zażalenie. 
### TYTUŁ IV
Właściwość sądu polubownego

***
## Art. 1180. {#kpc-piata--art-1180}

**§ 1.** Sąd polubowny może orzekać o swej właściwości, w tym 
o istnieniu, ważności albo skuteczności zapisu na sąd polubowny. Nieważność albo 
wygaśnięcie umowy podstawowej, w której zamieszczono zapis na sąd polubowny, 
samo przez się nie oznacza nieważności lub wygaśnięcia zapisu. 
**§ 2.** Zarzut braku właściwości sądu polubownego może być podniesiony nie 
później niż w odpowiedzi na pozew lub w innym terminie określonym przez strony, 
chyba że przed upływem terminu strona nie znała i przy dołożeniu należytej 
staranności nie mogła poznać podstawy takiego zarzutu albo jego podstawa 
powstała dopiero po upływie tego terminu. W obu wypadkach sąd polubowny może 
rozpoznać zarzut podniesiony po terminie, jeżeli uzna opóźnienie za 
usprawiedliwione. Wyznaczenie arbitra przez stronę lub uczestniczenie strony 
w jego wyznaczeniu nie pozbawia jej prawa do podniesienia tego zarzutu. Zarzut, 
że zgłoszone w toku postępowania żądanie strony przeciwnej wykracza poza zakres 
zapisu na sąd polubowny, powinien być podniesiony niezwłocznie po zgłoszeniu 

 
 
 
s. 568/580 
 
2025-09-08 
 
takiego żądania. Sąd polubowny może rozpoznać zarzut podniesiony po tym 
terminie, jeżeli uzna opóźnienie za usprawiedliwione. 
**§ 3.** O zarzucie, o którym mowa w § 2, sąd polubowny może orzec 
w odrębnym postanowieniu. Jeżeli sąd polubowny takim postanowieniem oddali 
zarzut, każda ze stron może w terminie dwóch tygodni od dnia doręczenia jej tego 
postanowienia wystąpić do sądu o rozstrzygnięcie. Wszczęcie postępowania przed 
sądem nie wstrzymuje rozpoznania sprawy przez sąd polubowny. Do postępowania 
przed sądem przepisy art. 1207 stosuje się odpowiednio. Na postanowienie sądu 
przysługuje zażalenie.

***
## Art. 1181. {#kpc-piata--art-1181}

**§ 1.** Jeżeli strony nie uzgodniły inaczej, sąd polubowny na wniosek 
strony, która uprawdopodobniła dochodzone roszczenie, może postanowić 
o zastosowaniu takiego sposobu zabezpieczenia, który uzna za właściwy ze 
względu na przedmiot sporu. Wydając takie postanowienie, sąd polubowny może 
uzależnić jego wykonanie od złożenia stosownego zabezpieczenia. 
**§ 2.** Na wniosek strony sąd polubowny może zmienić lub uchylić 
postanowienie wydane na podstawie § 1. 
**§ 3.** Postanowienie sądu polubownego o zastosowaniu tymczasowego środka 
zabezpieczającego podlega wykonaniu po nadaniu mu klauzuli wykonalności przez 
sąd. Przepisy art. 1214 § 2 i 3 oraz art. 1215 stosuje się odpowiednio.

***
## Art. 1182. {#kpc-piata--art-1182}

Jeżeli 
zastosowanie 
zarządzonego 
przez 
sąd 
polubowny 
tymczasowego środka zabezpieczającego było oczywiście nieuzasadnione, strona, 
na rzecz której środek ten został zastosowany, odpowiada za wynikłą stąd szkodę. 
Roszczenie o naprawienie szkody może być dochodzone także w toczącym się 
postępowaniu przed sądem polubownym. 
### TYTUŁ V
Postępowanie przed sądem polubownym

***
## Art. 1183. {#kpc-piata--art-1183}

W postępowaniu przed sądem polubownym strony powinny być 
traktowane równoprawnie. Każda ze stron ma prawo do wysłuchania 
i przedstawienia swoich twierdzeń oraz dowodów na ich poparcie.

***
## Art. 1184. {#kpc-piata--art-1184}

**§ 1.** Jeżeli przepis ustawy nie stanowi inaczej, strony mogą 
uzgodnić zasady i sposób postępowania przed sądem polubownym. 

 
 
 
s. 569/580 
 
2025-09-08 
**§ 2.** W braku odmiennego uzgodnienia stron, sąd polubowny może, 
z zastrzeżeniem przepisów ustawy, prowadzić postępowanie w taki sposób, jaki 
uzna za właściwy. Sąd polubowny nie jest związany przepisami o postępowaniu 
przed sądem.

***
## Art. 1185. {#kpc-piata--art-1185}

Jeżeli strony nie uzgodniły inaczej, sąd polubowny niezależnie od 
ustalonego miejsca postępowania może wyznaczyć posiedzenie w każdym miejscu, 
jakie uzna za stosowne dla odbycia narady arbitrów albo dla przeprowadzenia 
dowodów.

***
## Art. 1186. {#kpc-piata--art-1186}

W braku odmiennego uzgodnienia stron, postępowanie przed 
sądem polubownym rozpoczyna się w dniu, w którym pozwanemu doręczono 
pismo zawierające żądanie rozpoznania sprawy w postępowaniu przed sądem 
polubownym (wezwanie na arbitraż). Wezwanie na arbitraż powinno dokładnie 
określić strony i przedmiot sporu oraz wskazywać zapis na sąd polubowny, na 
podstawie którego postępowanie ma być prowadzone, a także zawierać 
wyznaczenie arbitra, jeżeli należy to do strony, która dokonuje wezwania na 
arbitraż.

***
## Art. 1187. {#kpc-piata--art-1187}

**§ 1.** Strony mogą uzgodnić język lub języki, w których będzie 
prowadzone postępowanie. W braku takiego uzgodnienia, o języku lub językach 
postępowania decyduje sąd polubowny. Uzgodnienie stron lub decyzja sądu 
polubownego, jeżeli nie postanowiono w nich inaczej, mają zastosowanie do 
wszystkich oświadczeń pisemnych stron, rozprawy oraz orzeczeń i zawiadomień 
sądu polubownego. 
**§ 2.** Sąd polubowny może zarządzić, aby do każdego dokumentu było 
dołączone jego tłumaczenie na język lub języki uzgodnione przez strony lub 
określone przez ten sąd.

***
## Art. 1188. {#kpc-piata--art-1188}

**§ 1.** W terminie uzgodnionym przez strony lub, jeżeli strony nie 
postanowiły inaczej, w terminie wyznaczonym przez sąd polubowny powód 
powinien wnieść pozew, a pozwany może złożyć odpowiedź na pozew. Do pozwu 
i odpowiedzi na pozew strony mogą dołączyć dokumenty, jakie uznają za stosowne. 
**§ 2.** W braku odmiennego uzgodnienia stron pozew lub odpowiedź na pozew 
mogą być uzupełnione lub zmienione w toku postępowania przed sądem 

 
 
 
s. 570/580 
 
2025-09-08 
 
polubownym, chyba że sąd polubowny nie dopuści do takiego uzupełnienia lub 
takiej zmiany ze względu na zbyt późne ich dokonanie. 
**§ 3.** Przepisy § 1 i 2 stosuje się także do powództwa wzajemnego.

***
## Art. 1189. {#kpc-piata--art-1189}

**§ 1.** W braku odmiennego uzgodnienia stron, sąd polubowny 
decyduje o tym, czy przeprowadzić rozprawę w celu przedstawienia przez strony 
twierdzeń lub dowodów na ich poparcie, czy też postępowanie będzie prowadzone 
na podstawie dokumentów i innych pism, bez wyznaczania rozprawy. Jeżeli strony 
nie uzgodniły, że postępowanie będzie prowadzone bez wyznaczania rozprawy, sąd 
polubowny jest obowiązany rozpoznać sprawę na rozprawie, gdy jedna ze stron 
tego zażąda. 
**§ 2.** Strony powinny być odpowiednio wcześnie zawiadomione o rozprawie 
oraz posiedzeniach sądu polubownego odbywanych w celu przeprowadzenia 
dowodów. 
**§ 3.** Wszelkie pisma składane przez stronę sądowi polubownemu powinny 
być doręczone drugiej stronie. Obu stronom powinny być doręczone opinie 
biegłych oraz inne dowody na piśmie, które sąd polubowny może wziąć pod uwagę 
przy rozstrzyganiu sporu.

***
## Art. 1190. {#kpc-piata--art-1190}

**§ 1.** Sąd polubowny umarza postępowanie, jeżeli powód nie 
wniesie pozwu zgodnie z art. 1188. 
**§ 2.** Jeżeli pozwany nie wniesie odpowiedzi na pozew zgodnie z art. 1188, sąd 
polubowny prowadzi postępowanie. Brak odpowiedzi na pozew nie może być 
uznany za przyznanie faktów przytoczonych w pozwie. 
**§ 3.** Jeżeli strona nie stawi się na rozprawę lub nie przedstawi dokumentów, 
które strona obowiązana była przedłożyć, sąd polubowny może prowadzić 
postępowanie i wydać wyrok na podstawie zebranego materiału dowodowego. 
**§ 4.** Przepisów § 1–3 nie stosuje się, jeżeli strona usprawiedliwi swą 
bezczynność lub niestawiennictwo, chyba że strony postanowiły inaczej.

***
## Art. 1191. {#kpc-piata--art-1191}

**§ 1.** Sąd polubowny może przeprowadzić dowód z przesłuchania 
świadków, z dokumentów, oględzin, a także inne konieczne dowody, nie może 
jednak stosować środków przymusu. 
**§ 2.** W braku odmiennego uzgodnienia stron, sąd polubowny może także: 
- 1) wyznaczyć biegłego lub biegłych w celu zasięgnięcia ich opinii; 

 
 
 
s. 571/580 
 
2025-09-08 
- 2) zażądać od strony dostarczenia biegłemu odpowiednich informacji lub 
przedstawienia mu albo udostępnienia do zbadania dokumentów lub innych 
przedmiotów. 
**§ 3.** W braku odmiennego uzgodnienia stron, na żądanie strony lub jeżeli sąd 
polubowny uzna to za konieczne, biegły po przedstawieniu swojej pisemnej lub 
ustnej opinii uczestniczy w rozprawie, w toku której strony mogą zadawać mu 
pytania oraz żądać wyjaśnień.

***
## Art. 1192. {#kpc-piata--art-1192}

**§ 1.** Sąd polubowny może zwrócić się o przeprowadzenie dowodu 
lub wykonanie innej czynności, której sąd polubowny nie może wykonać, do sądu 
rejonowego, w którego okręgu dowód lub czynność powinna być przeprowadzona. 
W postępowaniu dowodowym przed sądem rejonowym mogą wziąć udział strony 
i arbitrzy z prawem zadawania pytań. 
**§ 2.** Przepis § 1 stosuje się także, gdy miejsce postępowania przed sądem 
polubownym znajduje się poza granicami Rzeczypospolitej Polskiej lub nie jest 
oznaczone.

***
## Art. 1193. {#kpc-piata--art-1193}

Jeżeli uchybiono przepisom niniejszej części, od których strony 
mogą odstąpić, albo uchybiono określonym przez strony zasadom postępowania 
przed sądem polubownym, strona, która o powyższym uchybieniu wiedziała, nie 
może podnieść zarzutu takiego uchybienia przed sądem polubownym ani też 
powołać się na takie uchybienie w skardze o uchylenie wyroku sądu polubownego, 
jeżeli nie podniosła zarzutu niezwłocznie lub w terminie określonym przez strony 
bądź przepisy niniejszej części. 
### TYTUŁ VI
Wyrok sądu polubownego i zakończenie postępowania

***
## Art. 1194. {#kpc-piata--art-1194}

**§ 1.** Sąd polubowny rozstrzyga spór według prawa właściwego dla 
danego stosunku, a gdy strony go do tego wyraźnie upoważniły – według ogólnych 
zasad prawa lub zasad słuszności. 
**§ 2.** W każdym jednak przypadku sąd polubowny bierze pod uwagę 
postanowienia umowy oraz ustalone zwyczaje mające zastosowanie do danego 
stosunku prawnego. 
**§ 3.** W przypadku sporów wynikających z umów, których stroną jest 
konsument, rozstrzyganie sporu według ogólnych zasad prawa lub zasad słuszności 

 
 
 
s. 572/580 
 
2025-09-08 
 
nie może prowadzić do pozbawienia konsumenta ochrony przyznanej mu 
bezwzględnie wiążącymi przepisami prawa właściwego dla danego stosunku.

***
## Art. 1195. {#kpc-piata--art-1195}

**§ 1.** Jeżeli sąd polubowny rozpoznaje sprawę w składzie więcej niż 
jednego arbitra, jego orzeczenia zapadają większością głosów, chyba że strony 
uzgodniły inaczej. Orzeczenia w kwestiach proceduralnych może wydawać 
samodzielnie arbiter przewodniczący, jeżeli zostanie upoważniony do tego przez 
strony lub przez pozostałych arbitrów. 
**§ 2.** Arbiter, który głosował przeciwko stanowisku większości, może na 
wyroku przy swoim podpisie zaznaczyć, że zgłosił zdanie odrębne. 
**§ 3.** Uzasadnienie zdania odrębnego należy sporządzić w terminie dwóch 
tygodni od dnia sporządzenia motywów rozstrzygnięcia i dołączyć do akt sprawy. 
**§ 4.** Jeżeli przy wydawaniu wyroku nie można osiągnąć wymaganej 
jednomyślności lub większości głosów co do rozstrzygnięcia o całości lub o części 
przedmiotu sporu, zapis na sąd polubowny w tym zakresie traci moc.

***
## Art. 1196. {#kpc-piata--art-1196}

**§ 1.** Jeżeli strony zawarły ugodę przed sądem polubownym, sąd 
polubowny umarza postępowanie. Osnowę ugody wciąga się do protokołu albo 
zamieszcza w odrębnym dokumencie stanowiącym część protokołu i stwierdza 
podpisami stron. 
**§ 2.** Na wniosek stron sąd polubowny może nadać ugodzie formę wyroku. 
Wyrok sądu polubownego wydany na podstawie ugody stron powinien odpowiadać 
wymaganiom art. 1197 i zawierać stwierdzenie, że jest wyrokiem sądu 
polubownego. Wyrok taki ma takie same skutki jak każdy inny wyrok sądu 
polubownego.

***
## Art. 1197. {#kpc-piata--art-1197}

**§ 1.** Wyrok sądu polubownego powinien być sporządzony na 
piśmie i podpisany przez arbitrów, którzy go wydali. Jeżeli wyrok jest wydany 
przez sąd polubowny rozpoznający sprawę w składzie trzech lub więcej arbitrów, 
wystarczą podpisy większości arbitrów z podaniem przyczyny braku pozostałych 
podpisów. 
**§ 2.** Wyrok sądu polubownego powinien zawierać motywy rozstrzygnięcia. 
**§ 3.** Wyrok sądu polubownego powinien wskazywać zapis na sąd polubowny, 
na podstawie którego wydano wyrok, zawierać oznaczenie stron i arbitrów, a także 
określać datę i miejsce jego wydania. Gdy każdy z arbitrów podpisuje wyrok 

 
 
 
s. 573/580 
 
2025-09-08 
 
w innym państwie, a strony nie określiły miejsca wydania wyroku, miejsce to 
określa sąd polubowny. 
**§ 4.** Wyrok sądu polubownego doręcza się stronom.

***
## Art. 1198. {#kpc-piata--art-1198}

Poza wypadkami, o których mowa w art. 1190 § 1 i art. 1196 § 1, 
sąd polubowny wydaje postanowienie o umorzeniu postępowania, gdy: 
- 1) powód cofnął pozew, chyba że pozwany się temu sprzeciwił, a sąd polubowny 
uznał, że ma on uzasadniony interes w ostatecznym rozstrzygnięciu sporu; 
- 2) stwierdził, że dalsze prowadzenie postępowania stało się z innej przyczyny 
zbędne lub niemożliwe.

***
## Art. 1199. {#kpc-piata--art-1199}

Po 
wydaniu 
wyroku 
albo 
postanowienia 
o umorzeniu 
postępowania lub innego postanowienia kończącego postępowanie w sprawie, 
kończą się obowiązki arbitrów z wyjątkiem obowiązków określonych w art. 1200–
1203 i art. 1204 § 1.

***
## Art. 1200. {#kpc-piata--art-1200}

**§ 1.** W terminie 2 tygodni od dnia otrzymania wyroku, jeżeli 
strony nie uzgodniły innego terminu: 
- 1) każda ze stron może, po zawiadomieniu drugiej strony, zwrócić się do sądu 
polubownego o sprostowanie w tekście wyroku niedokładności, błędów 
pisarskich albo rachunkowych lub innych oczywistych omyłek; 
- 2) każda ze stron może, po zawiadomieniu drugiej strony, zwrócić się do sądu 
polubownego o rozstrzygnięcie wątpliwości co do treści wyroku. 
**§ 2.** Jeżeli sąd polubowny uzna wniosek za uzasadniony, dokonuje 
sprostowania lub wykładni wyroku w terminie 2 tygodni od dnia otrzymania 
wniosku. Wykładnia stanowi integralną część wyroku.

***
## Art. 1201. {#kpc-piata--art-1201}

W terminie miesiąca od dnia wydania wyroku sąd polubowny 
może z urzędu sprostować błędy pisarskie albo rachunkowe lub inne oczywiste 
omyłki. O dokonanym sprostowaniu sąd polubowny zawiadamia strony.

***
## Art. 1202. {#kpc-piata--art-1202}

Jeżeli strony nie postanowiły inaczej, każda z nich może, po 
zawiadomieniu drugiej strony, zwrócić się do sądu polubownego w terminie 
miesiąca od dnia otrzymania wyroku z wnioskiem o jego uzupełnienie co do żądań 
zgłoszonych w postępowaniu, o których sąd polubowny nie orzekł w wyroku. Po 
rozpoznaniu wniosku sąd polubowny wydaje wyrok uzupełniający w terminie do 
dwóch miesięcy od dnia złożenia wniosku. 

 
 
 
s. 574/580 
 
2025-09-08

***
## Art. 1203. {#kpc-piata--art-1203}

**§ 1.** Sąd polubowny może przedłużyć termin do złożenia wniosku 
o sprostowanie, wykładnię lub wydanie wyroku uzupełniającego, jeżeli uzna to za 
niezbędne. 
**§ 2.** Do sprostowania lub wykładni wyroku oraz do wyroku uzupełniającego 
stosuje się art. 1195 i 1197.

***
## Art. 1204. {#kpc-piata--art-1204}

**§ 1.** Akta sprawy wraz z oryginałem wyroku sąd polubowny 
składa w sądzie. 
**§ 2.** Stałe sądy polubowne mogą przechowywać akta we własnych archiwach 
i wówczas powinny udostępniać je sądowi oraz innym uprawnionym organom na 
ich żądanie. 
**§ 3.** W razie ponownego rozpoznania sprawy przez sąd polubowny sąd ten 
jest uprawniony do wglądu w złożone akta. 
### TYTUŁ VII
Skarga o uchylenie wyroku sądu polubownego

***
## Art. 1205. {#kpc-piata--art-1205}

**§ 1.** Wyrok sądu polubownego wydany w Rzeczypospolitej 
Polskiej może zostać uchylony przez sąd wyłącznie w postępowaniu wszczętym na 
skutek wniesienia skargi o jego uchylenie, zgodnie z poniższymi przepisami. 
**§ 2.** Jeżeli strony ustaliły, że postępowanie przed sądem polubownym będzie 
obejmowało więcej niż jedną instancję, przepis § 1 dotyczy ostatecznego wyroku 
sądu polubownego rozstrzygającego o żądaniach stron.

***
## Art. 1206. {#kpc-piata--art-1206}

**§ 1.** Strona może w drodze skargi żądać uchylenia wyroku sądu 
polubownego, jeżeli: 
- 1) brak było zapisu na sąd polubowny, zapis na sąd polubowny jest nieważny, 
bezskuteczny albo utracił moc według prawa dla niego właściwego; 
- 2) strona 
nie 
była 
należycie 
zawiadomiona 
o wyznaczeniu 
arbitra, 
o postępowaniu przed sądem polubownym lub w inny sposób była 
pozbawiona możności obrony swoich praw przed sądem polubownym; 
- 3) wyrok sądu polubownego dotyczy sporu nieobjętego zapisem na sąd 
polubowny lub wykracza poza zakres takiego zapisu, jeżeli jednak 
rozstrzygnięcie w sprawach objętych zapisem na sąd polubowny daje się 
oddzielić od rozstrzygnięcia w sprawach nieobjętych tym zapisem lub 
wykraczających poza jego zakres, wyrok może być uchylony jedynie 

 
 
 
s. 575/580 
 
2025-09-08 
 
w zakresie spraw nieobjętych zapisem lub wykraczających poza jego zakres; 
przekroczenie zakresu zapisu na sąd polubowny nie może stanowić podstawy 
uchylenia wyroku, jeżeli strona, która brała udział w postępowaniu, nie 
zgłaszała zarzutów co do rozpoznania roszczeń wykraczających poza zakres 
zapisu; 
- 4) nie zachowano wymagań co do składu sądu polubownego lub podstawowych 
zasad postępowania przed tym sądem, wynikających z ustawy lub 
określonych przez strony; 
- 5) wyrok uzyskano za pomocą przestępstwa albo podstawą wydania wyroku był 
dokument podrobiony lub przerobiony; 
- 6) w tej samej sprawie między tymi samymi stronami zapadł prawomocny wyrok 
sądu. 
**§ 2.** Uchylenie wyroku sądu polubownego następuje także wtedy, gdy sąd 
stwierdził, że: 
- 1) według ustawy spór nie może być rozstrzygnięty przez sąd polubowny; 
- 2) wyrok sądu polubownego jest sprzeczny z podstawowymi zasadami porządku 
prawnego Rzeczypospolitej Polskiej (klauzula porządku publicznego); 
- 3) wyrok sądu polubownego pozbawia konsumenta ochrony przyznanej mu 
bezwzględnie wiążącymi przepisami prawa właściwego dla umowy, której 
stroną jest konsument, a gdy prawem właściwym dla tej umowy jest prawo 
wybrane przez strony – ochrony przyznanej konsumentowi bezwzględnie 
wiążącymi przepisami prawa, które byłoby właściwe w braku wyboru prawa.

***
## Art. 1207. {#kpc-piata--art-1207}

**§ 1.** Do skargi o uchylenie wyroku sądu polubownego przepis 
art. 368 stosuje się odpowiednio. 
**§ 2.** Jeśli przepisy poniższe nie stanowią inaczej, do postępowania ze skargi 
o uchylenie wyroku sądu polubownego przepisy o apelacji stosuje się 
odpowiednio.

***
## Art. 1208. {#kpc-piata--art-1208}

**§ 1.** Skargę o uchylenie wyroku sądu polubownego wnosi się do 
sądu apelacyjnego, na obszarze którego znajduje się sąd, który byłby właściwy do 
rozpoznania sprawy, gdyby strony nie dokonały zapisu na sąd polubowny, 
a w braku tej podstawy – do Sądu Apelacyjnego w Warszawie, w terminie dwóch 
miesięcy od dnia doręczenia wyroku lub jeżeli strona wniosła o uzupełnienie, 

 
 
 
s. 576/580 
 
2025-09-08 
 
sprostowanie lub wykładnię wyroku – w terminie dwóch miesięcy od dnia 
doręczenia przez sąd polubowny orzeczenia rozstrzygającego o tym wniosku. 
**§ 2.** Jeżeli skargę o uchylenie wyroku sądu polubownego oparto na podstawie 
określonej w art. 1206 § 1 pkt 5 lub 6, termin do wniesienia skargi liczy się od dnia, 
w którym strona dowiedziała się o tej podstawie. Strona nie może jednak żądać 
uchylenia wyroku sądu polubownego po upływie pięciu lat od dnia doręczenia jej 
wyroku sądu polubownego. 
**§ 3.** Od wyroku wydanego w postępowaniu ze skargi o uchylenie wyroku 
sądu polubownego przysługuje skarga kasacyjna. Można także żądać wznowienia 
postępowania zakończonego prawomocnym wyrokiem w przedmiocie uchylenia 
wyroku 
sądu 
polubownego 
oraz 
stwierdzenia 
niezgodności 
z prawem 
prawomocnego wyroku wydanego w tym przedmiocie.

***
## Art. 1209. {#kpc-piata--art-1209}

**§ 1.** Sąd, do którego wniesiono skargę o uchylenie wyroku sądu 
polubownego, może – na wniosek jednej ze stron – zawiesić postępowanie na czas 
określony, aby umożliwić sądowi polubownemu ponowne podjęcie postępowania 
w celu usunięcia podstaw do uchylenia wyroku sądu polubownego. 
**§ 2.** W podjętym postępowaniu sąd polubowny wykonuje czynności 
wskazane przez sąd. Przepis art. 1202 stosuje się odpowiednio. Stronom nie 
przysługuje jednak odrębna skarga o uchylenie wydanego w tym trybie wyroku 
sądu polubownego. Zarzuty do czynności sądu polubownego oraz przeciwko 
wydanemu wyrokowi sądu polubownego rozpoznaje sąd po podjęciu 
postępowania.

***
## Art. 1210. {#kpc-piata--art-1210}

Sąd na posiedzeniu niejawnym może wstrzymać wykonanie 
wyroku sądu polubownego, może jednak uzależnić wstrzymanie od złożenia 
zabezpieczenia. Na postanowienie sądu przysługuje zażalenie do innego składu 
tego sądu.

***
## Art. 1211. {#kpc-piata--art-1211}

Uchylenie wyroku sądu polubownego nie powoduje wygaśnięcia 
zapisu na sąd polubowny, chyba że strony postanowiły inaczej. 

 
 
 
s. 577/580 
 
2025-09-08 
### TYTUŁ VIII
Uznanie i stwierdzenie wykonalności wyroku sądu polubownego lub ugody 
przed nim zawartej

***
## Art. 1212. {#kpc-piata--art-1212}

**§ 1.** Wyrok sądu polubownego lub ugoda przed nim zawarta mają 
moc prawną na równi z wyrokiem sądu lub ugodą zawartą przed sądem po ich 
uznaniu przez sąd albo po stwierdzeniu przez sąd ich wykonalności. 
**§ 2.** Wyrok sądu polubownego lub ugoda przed nim zawarta niezależnie od 
tego, w jakim państwie zostały wydane, podlegają uznaniu albo stwierdzeniu 
wykonalności na zasadach określonych w niniejszym tytule.

***
## Art. 1213. {#kpc-piata--art-1213}

**§ 1.** O uznaniu albo stwierdzeniu wykonalności wyroku sądu 
polubownego lub ugody przed tym sądem zawartej sąd orzeka na wniosek strony. 
Do wniosku strona jest obowiązana załączyć oryginał lub poświadczony przez sąd 
polubowny odpis jego wyroku lub ugody przed nim zawartej, jak również oryginał 
zapisu na sąd polubowny lub urzędowo poświadczony jego odpis. Jeżeli wyrok 
sądu polubownego lub ugoda przed nim zawarta albo zapis na sąd polubowny nie 
są 
sporządzone 
w języku 
polskim, 
strona 
jest 
obowiązana 
dołączyć 
uwierzytelniony ich przekład na język polski. 
**§ 2.** W terminie dwóch tygodni od dnia doręczenia wniosku strona może 
przedstawić sądowi stanowisko w sprawie.

***
## Art. 12131. {#kpc-piata--art-12131}

**§ 1.** O uznaniu albo stwierdzeniu wykonalności wyroku sądu 
polubownego lub ugody przed nim zawartej orzeka sąd apelacyjny, na obszarze 
którego znajduje się sąd, który byłby właściwy do rozpoznania sprawy, gdyby 
strony nie dokonały zapisu na sąd polubowny, a w braku tej podstawy – Sąd 
Apelacyjny w Warszawie. 
**§ 2.** Do postępowania o uznanie albo stwierdzenie wykonalności wyroku sądu 
polubownego lub ugody przed nim zawartej stosuje się odpowiednio przepisy 
o apelacji.

***
## Art. 1214. {#kpc-piata--art-1214}

**§ 1.** O uznaniu wyroku sądu polubownego lub ugody przed nim 
zawartej, nienadających się do wykonania w drodze egzekucji, sąd orzeka 
postanowieniem. 
**§ 2.** Sąd stwierdza wykonalność wyroku sądu polubownego lub ugody przed 
nim zawartej, nadających się do wykonania w drodze egzekucji, nadając im 

 
 
 
s. 578/580 
 
2025-09-08 
 
klauzulę wykonalności. Wyrok sądu polubownego lub ugoda przed nim zawarta, 
których wykonalność została stwierdzona, są tytułami wykonawczymi. 
**§ 3.** Sąd odmawia uznania albo stwierdzenia wykonalności wyroku sądu 
polubownego lub ugody przed nim zawartej, jeżeli: 
- 1) według przepisów ustawy spór nie może być poddany pod rozstrzygnięcie 
sądu polubownego; 
- 2) uznanie lub wykonanie wyroku sądu polubownego lub ugody przed nim 
zawartej byłoby sprzeczne z podstawowymi zasadami porządku prawnego 
Rzeczypospolitej Polskiej (klauzula porządku publicznego); 
- 3) wyrok sądu polubownego lub ugoda przed nim zawarta pozbawia konsumenta 
ochrony przyznanej mu bezwzględnie wiążącymi przepisami prawa 
właściwego dla umowy, której stroną jest konsument, a gdy prawem 
właściwym dla tej umowy jest prawo wybrane przez strony – ochrony 
przyznanej konsumentowi bezwzględnie wiążącymi przepisami prawa, które 
byłoby właściwe w braku wyboru prawa. 
**§ 4.** Na postanowienie sądu apelacyjnego w przedmiocie uznania albo 
stwierdzenia 
wykonalności 
wyroku 
sądu 
polubownego 
wydanego 
w Rzeczypospolitej Polskiej lub ugody przed nim zawartej przysługuje zażalenie 
do innego składu tego sądu.

***
## Art. 1215. {#kpc-piata--art-1215}

**§ 1.** O uznaniu albo stwierdzeniu wykonalności wyroku sądu 
polubownego wydanego za granicą lub ugody zawartej przed sądem polubownym 
za granicą, sąd orzeka po przeprowadzeniu rozprawy. 
**§ 2.** Niezależnie od przyczyn wymienionych w art. 1214, sąd na wniosek 
strony odmawia uznania albo stwierdzenia wykonalności wyroku sądu 
polubownego wydanego za granicą lub ugody zawartej przed sądem polubownym 
za granicą, jeżeli strona wykaże, że: 
- 1) nie było zapisu na sąd polubowny, zapis na sąd polubowny jest nieważny, 
bezskuteczny albo utracił moc według prawa dla niego właściwego; 
- 2) nie była należycie zawiadomiona o wyznaczeniu arbitra, o postępowaniu 
przed sądem polubownym lub w inny sposób była pozbawiona możliwości 
obrony swoich praw przed sądem polubownym; 
- 3) wyrok sądu polubownego dotyczy sporu nieobjętego zapisem na sąd 
polubowny lub wykracza poza zakres takiego zapisu, jeżeli jednak 

 
 
 
s. 579/580 
 
2025-09-08 
 
rozstrzygnięcie w sprawach objętych zapisem na sąd polubowny daje się 
oddzielić od rozstrzygnięcia w sprawach nieobjętych tym zapisem lub 
wykraczających poza jego zakres, odmowa uznania albo stwierdzenia 
wykonalności wyroku sądu polubownego może dotyczyć jedynie spraw 
nieobjętych zapisem lub wykraczających poza jego zakres; 
- 4) skład sądu polubownego lub postępowanie przed tym sądem nie były zgodne 
z umową stron lub – w braku w tym przedmiocie umowy – nie były zgodne 
z prawem państwa, w którym przeprowadzono postępowanie przed sądem 
polubownym; 
- 5) wyrok sądu polubownego nie stał się jeszcze dla stron wiążący lub został 
uchylony albo jego wykonanie zostało wstrzymane przez sąd państwa, 
w którym lub według prawa którego wyrok ten został wydany. 
**§ 3.** Od prawomocnego postanowienia sądu w przedmiocie uznania albo 
stwierdzenia wykonalności wyroku sądu polubownego wydanego za granicą lub 
ugody zawartej przed sądem polubownym za granicą przysługuje skarga kasacyjna. 
Można także żądać wznowienia postępowania zakończonego prawomocnym 
postanowieniem w przedmiocie uznania albo stwierdzenia wykonalności oraz 
stwierdzenia niezgodności z prawem prawomocnego postanowienia wydanego 
w tym przedmiocie.

***
## Art. 1216. {#kpc-piata--art-1216}

**§ 1.** Jeżeli 
wniesiono 
skargę 
o uchylenie 
wyroku 
sądu 
polubownego zgodnie z przepisami tytułu VII, sąd, do którego skierowano wniosek 
o uznanie albo stwierdzenie wykonalności tego wyroku, może odroczyć 
rozpoznanie sprawy. Sąd ten może również, na wniosek strony żądającej uznania 
albo stwierdzenia wykonalności wyroku sądu polubownego, nakazać drugiej 
stronie złożenie stosownego zabezpieczenia. 
**§ 2.** Przepis § 1 stosuje się odpowiednio, jeżeli skargę o uchylenie wyroku 
sądu polubownego wydanego za granicą wniesiono w państwie, w którym lub 
według prawa którego wyrok został wydany. 
**§ 3.** Przepisy § 1 i 2 stosuje się odpowiednio do ugody zawartej przed sądem 
polubownym.

***
## Art. 1217. {#kpc-piata--art-1217}

W postępowaniu o uznanie albo stwierdzenie wykonalności 
wyroku sądu polubownego wydanego w Rzeczypospolitej Polskiej lub ugody 

 
 
 
s. 580/580 
 
2025-09-08 
 
zawartej przed sądem polubownym w Rzeczypospolitej Polskiej, sąd nie bada 
okoliczności, o których mowa w art. 1214 § 3, jeżeli skarga o uchylenie wyroku 
sądu polubownego została prawomocnie oddalona.

