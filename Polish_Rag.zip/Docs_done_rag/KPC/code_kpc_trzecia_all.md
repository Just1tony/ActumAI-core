---
id: code.kpc.czesc.trzecia.ksiega.all
title: "Kodeks postępowania cywilnego — CZĘŚĆ TRZECIA — KSIĘGA — (—)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1964 Nr 43 poz. 296"
consolidated_citation: "t.j. Dz.U. 2024 poz. 1568, 1841; Dz.U. 2025 poz. 620, 1172"
status: "obowiązujący"
last_consolidated: "2025-09-08"
aliases: ["KPC — CZĘŚĆ TRZECIA — Księga —"]
tags: ["KPC","Kodeks postępowania cywilnego","CZĘŚĆ TRZECIA","Księga —","PL"]
source_pdf: "D19640296Lj.pdf"
articles: "Art. 758–1088"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpc-trzecia--art-{n}}"
  separators: "***"
  hierarchy: ["CZĘŚĆ","KSIĘGA","TYTUŁ","DZIAŁ","Rozdział"]
---

# Kodeks postępowania cywilnego — CZĘŚĆ TRZECIA — KSIĘGA —: —

# CZĘŚĆ TRZECIA 
POSTĘPOWANIE EGZEKUCYJNE 
### TYTUŁ I
Przepisy ogólne 
#### DZIAŁ I
Organy egzekucyjne, ich właściwość i postępowanie w ogólności
***
## Art. 758. {#kpc-trzecia--art-758}

Sprawy egzekucyjne należą do właściwości sądów rejonowych 
i działających przy tych sądach komorników.

***
## Art. 7581. {#kpc-trzecia--art-7581}

Jeżeli stroną lub uczestnikiem postępowania egzekucyjnego jest 
sąd właściwy do podjęcia czynności, przepisu art. 442 nie stosuje się.

***
## Art. 759. {#kpc-trzecia--art-759}

**§ 1.** Czynności egzekucyjne są wykonywane przez komorników 
z wyjątkiem czynności zastrzeżonych dla sądów. 
**§ 11.** Czynności zastrzeżone dla sądu mogą być wykonywane przez 
referendarza sądowego, z wyłączeniem: 
- 1) stosowania środków przymusu; 
- 2) orzekania o ściągnięciu należności w trybie art. 873; 
- 3) stwierdzenia wygaśnięcia skutków przybicia i utraty rękojmi; 
- 4) spraw o egzekucję świadczeń niepieniężnych z wyjątkiem wydania rzeczy 
ruchomej; 
- 5) spraw o egzekucję przez zarząd przymusowy; 
- 6) spraw o egzekucję przez sprzedaż przedsiębiorstwa lub gospodarstwa 
rolnego. 

 
 
 
s. 349/580 
 
2025-09-08 
**§ 2.** Sąd wydaje z urzędu komornikowi zarządzenia zmierzające do 
zapewnienia należytego wykonania egzekucji oraz usuwa spostrzeżone uchybienia. 
Ocena prawna wyrażona przez sąd w ramach wydanych zarządzeń jest wiążąca dla 
komornika. 
**§ 3.** Sąd może zobowiązać komornika do składania sprawozdań z czynności 
podjętych w wyniku zarządzeń, o których mowa w § 2.

***
## Art. 7591. {#kpc-trzecia--art-7591}

Przepisy niniejszego Kodeksu dotyczące właściwości miejscowej 
komorników nie uchybiają prawu wyboru komornika określonemu w odrębnych 
przepisach.

***
## Art. 7592. {#kpc-trzecia--art-7592}

**§ 1.** Komornik dokonuje doręczeń administracyjnym organom 
egzekucyjnym, organom podatkowym oraz wierzycielom należności pieniężnych, 
których egzekucja została przejęta przez sądowy organ egzekucyjny w wyniku 
zbiegu egzekucji administracyjnej i sądowej, będącym podmiotami publicznymi 
obowiązanymi do udostępniania i obsługi elektronicznej skrzynki podawczej na 
podstawie art. 16 ust. 1a ustawy z dnia 17 lutego 2005 r. o informatyzacji działal-
ności podmiotów realizujących zadania publiczne (Dz. U. z 2024 r. poz. 307 i 
1222), wyłącznie za pośrednictwem systemu teleinformatycznego albo z użyciem 
środków komunikacji elektronicznej, w sposób określony w przepisach wydanych 
na podstawie art. 63a § 2 ustawy z dnia 17 czerwca 1966 r. o postępowaniu 
egzekucyjnym w administracji (Dz. U. z 2023 r. poz. 2505 i 2760 oraz z 2024 r. 
poz. 858, 859, 1222 i 1473). 
**§ 11.** Doręczenia pomiędzy komornikiem a naczelnikiem urzędu skarbowego 
w przypadku zbiegu egzekucji sądowej i administracyjnej są dokonywane za 
pośrednictwem konta w e-Urzędzie Skarbowym. W tym przypadku przepisu § 1 
nie stosuje się. 
**§ 2.** Do pism wysyłanych przez komornika w postępowaniu egzekucyjnym 
przepisu art. 1391 nie stosuje się. 
**§ 3.** Komornik może, na wniosek strony, doręczać jej odpisy pism za 
pośrednictwem Elektronicznej Platformy Usług Administracji Publicznej 
(ePUAP). Odpisy pism doręczanych w ten sposób nie wymagają dodatkowego 
uwierzytelnienia przez komornika. W przypadku nieodebrania pisma przez 

 
 
 
s. 350/580 
 
2025-09-08 
 
adresata, doręczenie uważa się za dokonane po upływie 14 dni, licząc od dnia 
wysłania pisma za pośrednictwem ePUAP.

***
## Art. 760. {#kpc-trzecia--art-760}

**§ 1.** Wnioski i oświadczenia w postępowaniu egzekucyjnym składa 
się, według wyboru składającego, na piśmie albo ustnie do protokołu, chyba że 
przepis szczególny stanowi inaczej. Jeżeli przepis szczególny tak stanowi albo 
dokonano 
wyboru 
wnoszenia 
pism 
za 
pośrednictwem 
systemu 
teleinformatycznego, wnioski i oświadczenia składa się wyłącznie za 
pośrednictwem systemu teleinformatycznego. 
**§ 11.** Komornik niezwłocznie, nie później jednak niż w terminie 7 dni od dnia 
otrzymania wniosku, podejmuje niezbędne czynności. 
**§ 2.** W przypadku gdy według przepisów niniejszego kodeksu zachodzi 
potrzeba wysłuchania strony, wysłuchanie odbywa się, stosownie do okoliczności, 
przez spisanie protokołu w obecności lub nieobecności drugiej strony albo przez 
oświadczenie strony złożone na piśmie lub za pośrednictwem systemu 
teleinformatycznego.

***
## Art. 7601. {#kpc-trzecia--art-7601}

Na żądanie wierzyciela, którego roszczenie stwierdzone jest 
tytułem wykonawczym lub tytułem egzekucyjnym, organ egzekucyjny, który 
prowadzi egzekucję lub który jest właściwy do jej prowadzenia według przepisów 
kodeksu, udzieli mu informacji, czy przeciwko dłużnikowi prowadzone jest przez 
ten organ egzekucyjny postępowanie egzekucyjne, a jeżeli tak, powiadomi go 
o stosowanych sposobach egzekucji oraz o wysokości egzekwowanych roszczeń, 
a także o aktualnym stanie sprawy.

***
## Art. 7602. {#kpc-trzecia--art-7602}

Organ egzekucyjny, dokonując zajęcia majątku dłużnika albo 
żądając udzielenia informacji, o których mowa w art. 761 § 11, jest obowiązany 
podać numer PESEL, NIP lub REGON dłużnika, którego ta czynność dotyczy, 
jeżeli numery te zostały dłużnikowi nadane, a w razie konieczności także inne dane 
niezbędne do identyfikacji jego tożsamości.

***
## Art. 761. {#kpc-trzecia--art-761}

**§ 1.** Organ egzekucyjny może żądać od uczestników postępowania 
złożenia wyjaśnień. 
**§ 11.** Organ egzekucyjny może żądać od: 
- 1) organów administracji publicznej, 
- 2) podmiotów wykonujących zadania z zakresu administracji publicznej, 

 
 
 
s. 351/580 
 
2025-09-08 
- 3) organów podatkowych, 
- 4) organów rentowych, 
- 5) banków, 
- 6) spółdzielczych kas oszczędnościowo-kredytowych, 
- 7) zakładów ubezpieczeń lub zakładów reasekuracji, 
- 8) podmiotów prowadzących rachunki papierów wartościowych, wymienionych 
w art. 4 ust. 1 ustawy z dnia 29 lipca 2005 r. o obrocie instrumentami 
finansowymi, 
- 9) spółdzielni mieszkaniowych, 
- 10) wspólnot mieszkaniowych, 
- 11) innych podmiotów zarządzających lokalami, 
- 12) biur informacji gospodarczej, 
- 13) innych instytucji i osób nieuczestniczących w postępowaniu 
– informacji dotyczących stanu majątkowego dłużnika lub umożliwiających 
identyfikację składników jego majątku oraz danych adresowych jedynie w zakresie 
niezbędnym do zapewnienia prawidłowego toku postępowania. 
**§ 2.** Od wykonania takiego żądania można uchylić się w takim zakresie, 
w jakim według przepisów części pierwszej Kodeksu można odmówić 
przedstawienia dokumentu lub złożenia zeznań w charakterze świadka albo 
odpowiedzi na zadane pytanie. 
**§ 21.** Informacji, o których mowa w § 11, udziela się w oparciu o dane 
przekazane przez organ egzekucyjny, w terminie przez niego wyznaczonym, o ile 
przepisy szczególne nie przewidują innego terminu. 
**§ 22.** Jeżeli pozyskanie informacji, o których mowa w § 11, jest możliwe za 
pośrednictwem systemów teleinformatycznych funkcjonujących na podstawie 
przepisów odrębnych, komornik korzysta z tych systemów z wyłączeniem innych 
form komunikacji – na zasadach określonych w tych przepisach. 
**§ 3.** Dłużnik, który został zawiadomiony o wszczęciu egzekucji, obowiązany 
jest do powiadomienia w terminie 7 dni organu egzekucyjnego o każdej zmianie 
miejsca swego pobytu, trwającej dłużej niż jeden miesiąc. O obowiązku tym oraz 
o skutkach jego zaniedbania poucza się dłużnika przy zawiadomieniu go 
o wszczęciu egzekucji. 

 
 
 
s. 352/580 
 
2025-09-08

***
## Art. 762. {#kpc-trzecia--art-762}

**§ 1.** Za 
nieuzasadnioną 
odmowę 
udzielenia 
organowi 
egzekucyjnemu wyjaśnień lub informacji przewidzianych w art. 761 albo za 
udzielanie informacji lub wyjaśnień świadomie fałszywych osoba odpowiedzialna 
może być na wniosek wierzyciela lub z urzędu ukarana przez organ egzekucyjny 
grzywną do dwóch tysięcy złotych. Grzywną taką może być również ukarany 
dłużnik, który zaniedba obowiązku powiadomienia o zmianie miejsca swojego 
pobytu. 
**§ 2.** Jeżeli żądanie udzielenia wyjaśnień lub informacji skierowane było do 
osoby prawnej lub innej organizacji, ukaraniu grzywną podlega jej pracownik 
odpowiedzialny za udzielenie wyjaśnień lub informacji, a gdyby ustalenie takiego 
pracownika było utrudnione, ukaraniu podlega jej kierownik. Przed wydaniem 
postanowienia organ egzekucyjny wysłucha kierownika. 
**§ 3.** Wypis postanowienia o ukaraniu grzywną organ egzekucyjny doręcza 
osobie ukaranej, stronom oraz prokuratorowi. 
**§ 4.** (uchylony) 
**§ 5.** Ukaranie przez organ egzekucyjny grzywną nie zwalnia osób ukaranych 
od odpowiedzialności karnej za niedopełnienie lub przekroczenie obowiązków 
służbowych.

***
## Art. 7621. {#kpc-trzecia--art-7621}

W razie uchybienia przez żołnierza w czynnej służbie wojskowej, 
z wyjątkiem terytorialnej służby wojskowej pełnionej dyspozycyjnie, obowiązkom, 
o których mowa w art. 762 § 1 i 2, komornik, zamiast ukarać żołnierza grzywną, 
występuje do dowódcy jednostki wojskowej, w której żołnierz ten pełni służbę, z 
wnioskiem o pociągnięcie go do odpowiedzialności dyscyplinarnej.

***
## Art. 763. {#kpc-trzecia--art-763}

**§ 1.** Komornik zawiadamia stronę o każdej dokonanej czynności, 
o której terminie nie była zawiadomiona i przy której nie była obecna, i na jej 
żądanie udziela wyjaśnień o stanie sprawy. 
**§ 2.** Przepis § 1 stosuje się także do uczestnika postępowania, którego dotyczy 
czynność komornika. 
**§ 3.** W każdym piśmie kierowanym do strony komornik informuje o aktualnej 
wysokości należności będących przedmiotem egzekucji.

***
## Art. 7631. {#kpc-trzecia--art-7631}

Komornik 
poucza 
strony 
i uczestników postępowania 
niezastępowanych przez adwokata, radcę prawnego, rzecznika patentowego lub 

 
 
 
s. 353/580 
 
2025-09-08 
 
Prokuratorię 
Generalną 
Rzeczypospolitej 
Polskiej 
o sposobie 
i terminie 
zaskarżenia czynności. Jeżeli osoby te nie są obecne, pouczenie następuje wraz 
z zawiadomieniem o dokonaniu czynności.

***
## Art. 7632. {#kpc-trzecia--art-7632}

**§ 1.** Wniosek o wyłączenie komornika zgłasza się na piśmie do 
komornika 
prowadzącego 
postępowanie, 
uprawdopodobniając 
przyczyny 
wyłączenia. Komornik w terminie 3 dni od dnia złożenia wniosku o wyłączenie 
przekazuje wniosek do sądu rejonowego właściwego ze względu na siedzibę 
kancelarii komornika, wraz z pisemnymi wyjaśnieniami. 
**§ 2.** Sąd rejonowy właściwy ze względu na siedzibę kancelarii komornika 
rozpoznaje wniosek o wyłączenie komornika w terminie 7 dni od dnia przekazania 
wniosku. 
**§ 3.** Postanowienie w przedmiocie wyłączenia komornika sąd wydaje na 
posiedzeniu niejawnym w składzie jednego sędziego. Na postanowienie zażalenie 
nie przysługuje. 
**§ 4.** Przepisy § 1–3 stosuje się odpowiednio do zastępcy komornika oraz 
asesorów komorniczych, jeżeli osoby te prowadzą postępowanie lub dokonują 
określonych czynności w sprawie. 
**§ 5.** Do czasu rozpoznania wniosku o wyłączenie komornik, którego dotyczy 
wniosek, może podejmować dalsze czynności, z wyjątkiem czynności, które 
pociągałyby za sobą nieodwracalne skutki, chyba że wniosek w sposób oczywisty 
zmierza jedynie do przedłużenia postępowania. 
**§ 6.** W przypadku uwzględnienia wniosku o wyłączenie komornika, sąd 
wyznaczy innego komornika do dalszego prowadzenia postępowania, w miarę 
możliwości powierzając je komornikowi z tego samego rewiru, w którym ma 
siedzibę komornik wyłączony. W takim przypadku sąd może z urzędu uchylić 
w niezbędnym zakresie czynności dokonane po złożeniu wniosku. 
**§ 7.** W zakresie nieuregulowanym w § 1–6 do wyłączenia komornika stosuje 
się odpowiednio przepisy o wyłączeniu sędziego.

***
## Art. 7633. {#kpc-trzecia--art-7633}

**§ 1.** Komornik właściwy do prowadzenia egzekucji, zgodnie 
z przepisami niniejszego kodeksu, w chwili wszczęcia postępowania pozostaje 
właściwy do czasu jego zakończenia, choćby podstawy właściwości zmieniły się 
w toku sprawy. 

 
 
 
s. 354/580 
 
2025-09-08 
**§ 2.** Jeżeli w toku egzekucji świadczeń alimentacyjnych dłużnik zmienił 
miejsce zamieszkania, przeprowadzając się na obszar właściwości innego sądu 
apelacyjnego, a dalsze prowadzenie egzekucji wiązałoby się z nadmiernymi 
kosztami, komornik może przekazać sprawę do komornika właściwości ogólnej 
dłużnika. Jeżeli w rewirze, do którego sprawa zostaje przekazana, działa więcej niż 
jeden komornik, komornik doręczając odpis postanowienia jednocześnie wzywa 
wierzyciela, aby w terminie 7 dni od dnia doręczenia wezwania wskazał 
komornika, któremu sprawa ma zostać przekazana. Jeżeli wierzyciel w powyższym 
terminie nie dokona wyboru komornika lub wskaże komornika, który nie jest 
właściwy, komornik przekazuje sprawę według własnego wyboru. Na wybór 
komornika z właściwego rewiru dłużnikowi skarga nie przysługuje.

***
## Art. 7634. {#kpc-trzecia--art-7634}

Komornik, który stwierdzi swoją niewłaściwość, w postanowieniu 
o przekazaniu sprawy zgodnie z właściwością wskazuje komornika rewiru, do 
którego sprawa zostaje przekazana. Jeżeli w rewirze, do którego sprawa zostaje 
przekazana, działa więcej niż jeden komornik, doręczając odpis postanowienia 
stwierdzającego niewłaściwość, komornik jednocześnie wzywa wierzyciela, aby 
w terminie 7 dni od doręczenia wezwania wskazał komornika, któremu sprawa ma 
zostać przekazana. Jeżeli wierzyciel w powyższym terminie nie dokona wyboru lub 
wskaże komornika, który nie jest właściwy, komornik przekazuje sprawę według 
własnego wyboru. Na wybór komornika z właściwego rewiru dłużnikowi skarga 
nie przysługuje.

***
## Art. 764. {#kpc-trzecia--art-764}

Komornik może upomnieć, a po bezskutecznym upomnieniu 
wydalić osobę, która zachowuje się niewłaściwie lub przeszkadza jego 
czynnościom. W przypadku niezastosowania się do wezwania do wydalenia 
z miejsca czynności komornik może ukarać taką osobę grzywną w wysokości do 
tysiąca złotych.

***
## Art. 765. {#kpc-trzecia--art-765}

**§ 1.** W razie oporu komornik może wezwać pomocy organów 
Policji. Jeżeli opór stawia osoba wojskowa, z wyjątkiem żołnierza pełniącego 
terytorialną służbę wojskową dyspozycyjnie, należy wezwać pomocy właściwego 
organu wojskowego, chyba że zwłoka grozi udaremnieniem egzekucji, a na miejscu 
nie ma organu wojskowego. 

 
 
 
s. 355/580 
 
2025-09-08 
**§ 11.** Policja udziela komornikowi, na jego wezwanie, pomocy przy 
czynnościach 
egzekucyjnych. 
W 
przypadku 
stwierdzenia 
okoliczności 
uzasadniających podejrzenie popełnienia przestępstwa, Policja niezwłocznie 
powiadamia prezesa właściwego sądu rejonowego i żąda od komornika wpisania 
zastrzeżeń do protokołu czynności. 
**§ 12.** Otwarcia lub przeszukania mieszkania dłużnika komornik dokonuje 
wyłącznie w asyście Policji. 
**§ 2.** Sposób udzielania pomocy komornikowi przy wykonywaniu czynności 
egzekucyjnych, przypadki, w których należy udzielić komornikowi pomocy, 
sposób postępowania, tryb występowania o udzielenie pomocy, sposób jej 
realizacji, a także sposób dokumentowania wykonywanych czynności i rozliczania 
ich kosztów, określa, w drodze rozporządzenia: 
- 1) minister właściwy do spraw wewnętrznych w porozumieniu z Ministrem 
Sprawiedliwości – w przypadku udzielania pomocy przez Policję lub Straż 
Graniczną; 
- 2) Minister Obrony Narodowej w porozumieniu z Ministrem Sprawiedliwości – 
w przypadku udzielania pomocy przez Służbę Kontrwywiadu Wojskowego, 
Służbę Wywiadu Wojskowego, Żandarmerię Wojskową lub wojskowe 
organy porządkowe; 
- 3) Prezes Rady Ministrów w przypadku udzielania pomocy przez Agencję 
Bezpieczeństwa Wewnętrznego lub Agencję Wywiadu. 
**§ 3.** W rozporządzeniu, o którym mowa w § 2, należy uwzględnić gwarancję 
bezpieczeństwa komornika i uczestników postępowania, poszanowania godności 
osób biorących udział w czynnościach egzekucyjnych, odpowiednie terminy 
wyznaczania 
czynności 
i występowania 
o udzielenie 
pomocy, 
objęcie 
dokumentacją przebiegu czynności i udziału w nich funkcjonariuszy udzielających 
pomocy oraz wskazanie organów, na których rachunek przekazywane są należności 
zaliczane do kosztów egzekucji.

***
## Art. 766. {#kpc-trzecia--art-766}

Sąd rozpoznaje sprawy egzekucyjne na posiedzeniu niejawnym, 
chyba że zachodzi potrzeba wyznaczenia rozprawy albo wysłuchania na 
posiedzeniu stron lub innych osób. W sprawach tych sąd wydaje orzeczenia 
w formie postanowień. 

 
 
 
s. 356/580 
 
2025-09-08

***
## Art. 7661. {#kpc-trzecia--art-7661}

**§ 1.** Postanowienie wydane na posiedzeniu niejawnym sąd 
z urzędu uzasadnia i doręcza wraz z uzasadnieniem, gdy stronie przysługuje środek 
zaskarżenia, chyba że przepis szczególny stanowi inaczej. 
**§ 2.** Komornik uzasadnia postanowienie z urzędu, chyba że postanowienie 
wydano bez spisywania odrębnej sentencji.

***
## Art. 767. {#kpc-trzecia--art-767}

**§ 1.** Na czynności komornika przysługuje skarga do sądu 
rejonowego, jeżeli ustawa nie stanowi inaczej. Dotyczy to także zaniechania przez 
komornika dokonania czynności. Skargę rozpoznaje sąd właściwy ze względu na 
siedzibę kancelarii komornika. 
**§ 11.** Skarga nie przysługuje na zarządzenie komornika o wezwaniu do 
usunięcia braków pisma, na zawiadomienie o terminie czynności oraz na uiszczenie 
przez komornika podatku od towarów i usług. 
**§ 2.** Skargę może złożyć strona lub inna osoba, której prawa zostały przez 
czynności lub zaniechanie komornika naruszone bądź zagrożone. 
**§ 3.** Skarga na czynność komornika powinna czynić zadość wymaganiom 
pisma procesowego oraz określać zaskarżoną czynność lub czynność, której 
zaniechano, jak również wniosek o zmianę, uchylenie lub dokonanie czynności 
wraz z uzasadnieniem. 
**§ 31.** Skarga może być wniesiona na urzędowym formularzu. 
**§ 32.** O możliwości wniesienia skargi na urzędowym formularzu oraz 
o sposobie, w jaki jest on udostępniany, komornik poucza dłużnika przy pierwszej 
czynności egzekucyjnej, a także strony i uczestników obecnych podczas czynności 
dokonywanej poza kancelarią, chyba że czynność ta podlega zaskarżeniu skargą 
w formie ustnej. Komornik doręcza urzędowy formularz skargi na żądanie strony 
lub uczestnika, jeżeli urzędowego formularza skargi im nie doręczono. 
**§ 33.** Minister Sprawiedliwości określi, w drodze rozporządzenia, wzór 
i sposób udostępniania urzędowego formularza skargi, mając na względzie 
ustawowe wymagania przewidziane dla tego pisma, potrzebę zamieszczenia 
niezbędnych pouczeń co do sposobu wypełniania formularza, wnoszenia pisma 
i skutków niedostosowania go do ustawowych wymagań, a także konieczność 
bezpłatnego udostępniania formularzy w kancelariach komorniczych, siedzibach 
sądów oraz sieci Internet w formie pozwalającej na dogodną edycję treści 
formularza. 

 
 
 
s. 357/580 
 
2025-09-08 
**§ 4.** Skargę wnosi się w terminie tygodniowym od dnia dokonania czynności, 
gdy strona lub osoba, której prawo zostało przez czynność komornika naruszone 
bądź zagrożone, była przy czynności obecna lub była o jej terminie zawiadomiona; 
w innych przypadkach – od dnia zawiadomienia o dokonaniu czynności strony lub 
osoby, której prawo zostało przez czynność komornika naruszone bądź zagrożone, 
a w braku zawiadomienia – od dnia powzięcia wiadomości przez skarżącego 
o dokonanej czynności. Skargę na zaniechanie przez komornika dokonania 
czynności wnosi się w terminie tygodniowym od dnia, w którym skarżący 
dowiedział się, że czynność miała być dokonana. 
**§ 5.** Skargę wnosi się do komornika, który dokonał zaskarżonej czynności lub 
zaniechał jej dokonania. Komornik w terminie trzech dni od dnia otrzymania skargi 
sporządza uzasadnienie zaskarżonej czynności, o ile nie zostało ono sporządzone 
wcześniej, albo przyczyn jej zaniechania i przekazuje je wraz ze skargą i aktami 
sprawy do właściwego sądu, chyba że skargę w całości uwzględnia. 
O uwzględnieniu skargi komornik zawiadamia skarżącego oraz zainteresowanych, 
których uwzględnienie skargi dotyczy. 
<§ 51. Do skargi na czynność komornika przepisów art. 132 § 1, 14 i 15 nie 
stosuje się.> 
**§ 6.** W przypadku stwierdzenia oczywistego naruszenia prawa przez 
komornika, sąd uwzględniając skargę, stosownie do okoliczności, może go 
obciążyć kosztami postępowania wywołanego skargą. Na postanowienie sądu 
przysługuje zażalenie stronom oraz komornikowi.

***
## Art. 7671. {#kpc-trzecia--art-7671}

(uchylony)

***
## Art. 7672. {#kpc-trzecia--art-7672}

**§ 1.** Sąd rozpoznaje skargę w terminie tygodniowym od dnia jej 
wpływu do sądu, a gdy skarga zawiera braki formalne, które podlegają 
uzupełnieniu, w terminie tygodniowym od jej uzupełnienia. 
**§ 2.** Wniesienie skargi nie wstrzymuje postępowania egzekucyjnego ani 
wykonania zaskarżonej czynności, chyba że sąd zawiesi postępowanie lub 
wstrzyma dokonanie czynności.

***
## Art. 7673. {#kpc-trzecia--art-7673}

**§ 1.** Sąd odrzuca skargę wniesioną po upływie przepisanego 
terminu, nieopłaconą lub z innych przyczyn niedopuszczalną, jak również skargę, 
Dodany § 51 w 
art. 767 wejdzie 
w życie z dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 
 

 
 
 
s. 358/580 
 
2025-09-08 
 
której braków nie uzupełniono w terminie. Na postanowienie sądu o odrzuceniu 
skargi służy zażalenie. 
**§ 2.** Przepis art. 759 § 2 stosuje się.

***
## Art. 7673a. {#kpc-trzecia--art-7673a}

**§ 1.** Wniesienie skargi na postanowienie referendarza sądowego 
nie powoduje utraty mocy zaskarżonego postanowienia. 
**§ 2.** Jeżeli wniesiono skargę na postanowienie referendarza sądowego wydane 
na podstawie art. 39822 § 4, ponowne wydanie postanowienia na tej podstawie 
przez referendarza sądowego nie jest dopuszczalne. 
**§ 3.** Sąd rozpoznaje skargę w składzie jednego sędziego jako sąd drugiej 
instancji. Po rozpoznaniu skargi sąd utrzymuje w mocy lub zmienia zaskarżone 
postanowienie, stosując odpowiednio przepisy o zażaleniu.

***
## Art. 7674. {#kpc-trzecia--art-7674}

**§ 1.** Zażalenie na postanowienie sądu przysługuje w wypadkach 
wskazanych w ustawie. 
**§ 11.** Zażalenie rozpoznaje sąd, który wydał zaskarżone postanowienie, 
w składzie trzech sędziów, orzekając jako sąd drugiej instancji. Przepis art. 3941a 
§ 3 stosuje się. 
**§ 12.** Zażalenie na postanowienie: 
- 1) którego 
przedmiotem 
są 
czynności 
w sprawach 
wymienionych 
w art. 759 § 11 pkt 4–6, 
- 2) wydane w wyniku rozpoznania zarzutów przeciwko planowi podziału sumy 
uzyskanej z egzekucji z nieruchomości, 
- 3) wydane na podstawie art. 1037 § 1 
– rozpoznaje sąd drugiej instancji. 
**§ 13.** Sąd, o którym mowa w § 11 zdanie pierwsze, może przekazać zażalenie 
do rozpoznania sądowi drugiej instancji, jeżeli przemawia za tym waga 
zaskarżonego orzeczenia lub jego precedensowy charakter. Sąd drugiej instancji 
w razie stwierdzenia braku podstaw do rozpoznania zażalenia zwraca sprawę 
sądowi właściwemu. 
**§ 14.** Sąd drugiej instancji rozpoznaje zażalenie w składzie jednego sędziego. 
**§ 2.** Na postanowienie sądu drugiej instancji wydane po rozpoznaniu 
zażalenia skarga kasacyjna nie przysługuje. 

 
 
 
s. 359/580 
 
2025-09-08 
**§ 3.** W sprawach 
egzekucyjnych 
skarga 
o stwierdzenie 
niezgodności 
z prawem prawomocnego orzeczenia nie przysługuje.

***
## Art. 768. {#kpc-trzecia--art-768}

Na postanowienie sądu w przedmiocie ukarania grzywną przez 
komornika przysługuje zażalenie.

***
## Art. 7681. {#kpc-trzecia--art-7681}

Prawomocne postanowienie komornika o ukaraniu grzywną 
podlega wykonaniu w drodze egzekucji sądowej bez zaopatrywania go w klauzulę 
wykonalności.

***
## Art. 769. {#kpc-trzecia--art-769}

(utracił moc)19)

***
## Art. 770. {#kpc-trzecia--art-770}

**§ 1.** Dłużnik zwraca wierzycielowi koszty niezbędne do celowego 
przeprowadzenia egzekucji. Koszty te ściąga się wraz z egzekwowanym 
świadczeniem. Przepisów art. 98 § 11 i 12 nie stosuje się. 
**§ 2.** Koszty postępowania egzekucyjnego ustala postanowieniem komornik 
wraz z ukończeniem postępowania egzekucyjnego, jeżeli przeprowadzenie 
egzekucji należy do niego. 
**§ 3.** Jeżeli w sprawie zachodzi konieczność sporządzenia planu podziału 
sumy uzyskanej z egzekucji, komornik ustala koszty egzekucji przed 
przystąpieniem do sporządzenia planu podziału, z wyjątkiem planu podziału, do 
którego stosuje się przepis art. 1029. Kosztów egzekucji nie ustala się także przed 
dokonaniem podziału bieżąco uzyskiwanych w toku egzekucji sum, jeżeli 
wysokość sumy nie przekracza jednorazowo dwóch tysięcy złotych. Postanowienie 
w przedmiocie kosztów egzekucji jest wydawane łącznie we wszystkich sprawach, 
których dotyczy plan podziału. 
**§ 4.** Wynagrodzenie 
z tytułu 
zastępstwa 
prawnego 
w postępowaniu 
egzekucyjnym nie może być wyższe niż stawka minimalna opłaty za czynności 
adwokackie albo radcowskie, określona w odrębnych przepisach. 
**§ 5.** Na postanowienie sądu zażalenie przysługuje stronom, komornikowi oraz 
innej osobie, której to postanowienie dotyczy. 
- 19) Z dniem 27 stycznia 2004 r. na podstawie wyroku Trybunału Konstytucyjnego z dnia 20 stycznia 
2004 r. sygn. akt SK 26/03 (Dz. U. poz. 101). 

 
 
 
s. 360/580 
 
2025-09-08

***
## Art. 7701. {#kpc-trzecia--art-7701}

Prawomocne 
postanowienie 
komornika 
przyznające 
zwrot 
kosztów postępowania egzekucyjnego podlega wykonaniu bez zaopatrywania go 
w klauzulę wykonalności.

***
## Art. 771. {#kpc-trzecia--art-771}

Zwolnienie od kosztów sądowych, przyznane stronie przez sąd 
w postępowaniu rozpoznawczym lub z którego strona korzysta z mocy ustawy, 
rozciąga się także na postępowanie egzekucyjne.

***
## Art. 772. {#kpc-trzecia--art-772}

(uchylony)

***
## Art. 773. {#kpc-trzecia--art-773}

**§ 1.** W przypadku zbiegu egzekucji sądowej i administracyjnej do 
tej samej rzeczy albo prawa majątkowego egzekucje do tej rzeczy albo prawa 
majątkowego prowadzi łącznie ten sądowy albo administracyjny organ 
egzekucyjny, który jako pierwszy dokonał zajęcia, a w razie niemożności ustalenia 
tego pierwszeństwa – organ egzekucyjny, który dokonał zajęcia na poczet 
należności w wyższej kwocie. 
**§ 2.** W przypadku zbiegu egzekucji administracyjnej prowadzonej na 
podstawie jednolitego tytułu wykonawczego państwa członkowskiego Unii 
Europejskiej albo zagranicznego tytułu wykonawczego określonych w ustawie 
z dnia 11 października 2013 r. o wzajemnej pomocy przy dochodzeniu podatków, 
należności celnych i innych należności pieniężnych (Dz. U. z 2023 r. poz. 2009) 
i egzekucji sądowej do tej samej rzeczy albo prawa majątkowego – egzekucje do 
tej rzeczy albo prawa majątkowego prowadzi łącznie administracyjny organ 
egzekucyjny. 
**§ 21.** W przypadku zbiegu egzekucji sądowej i administracyjnej do tej samej 
rzeczy albo prawa majątkowego, gdy egzekucja sądowa dotyczy: 
- 1) świadczeń alimentacyjnych, rentowych lub innych świadczeń powtarzających 
się, 
- 2) świadczenia pieniężnego w walucie obcej 
– egzekucje do tej rzeczy albo prawa majątkowego prowadzi łącznie sądowy organ 
egzekucyjny. 
**§ 22.** W przypadku zbiegu egzekucji administracyjnej, o której mowa w § 2, 
i egzekucji sądowej, o której mowa w § 21, do tej samej rzeczy albo prawa 
majątkowego egzekucje do tej rzeczy albo prawa majątkowego prowadzi łącznie 
sądowy organ egzekucyjny. 

 
 
 
s. 361/580 
 
2025-09-08 
**§ 23.** Prawa i obowiązki wierzyciela należności dochodzonej na podstawie 
jednolitego tytułu wykonawczego państwa członkowskiego Unii Europejskiej albo 
zagranicznego tytułu wykonawczego określonych w ustawie z dnia 11 paździer-
nika 2013 r. o wzajemnej pomocy przy dochodzeniu podatków, należności celnych 
i innych należności pieniężnych wykonuje administracyjny organ egzekucyjny. 
**§ 3.** Zbieg egzekucji nie wstrzymuje czynności egzekucyjnych. 
**§ 4.** Strona lub uczestnik postępowania zawiadamiają sądowy organ 
egzekucyjny o zbiegu egzekucji do tej samej rzeczy albo prawa majątkowego, 
wskazując datę dokonania każdego zajęcia i wysokość należności, na poczet 
których każde zajęcie zostało dokonane. 
**§ 5.** Sądowy organ egzekucyjny prowadzi łącznie egzekucje w trybie dla 
niego właściwym. 
**§ 51.** Sądowy organ egzekucyjny, któremu przekazano adnotację, o której 
mowa w art. 62b § 1 pkt 1 ustawy z dnia 17 czerwca 1966 r. o postępowaniu 
egzekucyjnym w administracji, zwaną dalej „adnotacją w sprawie zbiegu”, 
zawiadamia administracyjny organ egzekucyjny o przekazaniu sprawy innemu 
sądowemu organowi egzekucyjnemu. 
**§ 6.** W razie kolejnego zbiegu egzekucji sądowej i administracyjnej do tej 
samej rzeczy albo prawa majątkowego egzekucję administracyjną przejmuje 
sądowy organ egzekucyjny, który prowadzi łącznie egzekucje w wyniku 
pierwszego zbiegu egzekucji. 
**§ 7.** Jeżeli zbieg egzekucji dotyczy egzekucji administracyjnej, o której mowa 
w § 2, prowadzenie łącznie egzekucji przejmuje administracyjny organ 
egzekucyjny, z wyjątkiem przypadku określonego w § 22. 
**§ 8.** Jeżeli w wyniku kolejnego zbiegu egzekucji nastąpiła zmiana organu 
egzekucyjnego prowadzącego łącznie egzekucję do rzeczy lub prawa majątkowego, 
organ egzekucyjny, który przejął prowadzenie łącznie egzekucji w wyniku pierw-
szego zbiegu: 
- 1) przekazuje adnotację w sprawie zbiegu organowi, który przejął prowadzenie 
łącznie egzekucji w wyniku kolejnego zbiegu; 
- 2) zawiadamia o przekazaniu prowadzenia łącznie egzekucji organ egzekucyjny, 
który przekazał mu adnotację w sprawie zbiegu. 

 
 
 
s. 362/580 
 
2025-09-08

***
## Art. 7731. {#kpc-trzecia--art-7731}

**§ 1.** W wypadku zbiegu egzekucji do tych samych rzeczy, 
wierzytelności lub praw, dalszą egzekucję prowadzi komornik właściwy według 
przepisów niniejszego kodeksu. 
**§ 2.** Jeżeli żaden z komorników nie jest właściwy według przepisów 
niniejszego kodeksu lub właściwych jest kilku komorników, komornik, który 
później wszczął egzekucję, niezwłocznie przekazuje sprawę komornikowi, który 
pierwszy wszczął egzekucję, o czym zawiadamia wierzyciela. 
**§ 3.** Przekazując sprawę, komornik obowiązany jest rozliczyć koszty 
egzekucji. 
**§ 31.** Przepisy § 1 i 2 stosuje się odpowiednio do zbiegu zabezpieczeń 
sądowych. 
**§ 32.** W przypadku zbiegu egzekucji i zabezpieczenia sądowego sprawę 
o zabezpieczenie przejmuje komornik, który prowadził dotąd egzekucję. 
**§ 4.** (uchylony)

***
## Art. 7732. {#kpc-trzecia--art-7732}

**§ 1.** Komornik zawiadamia strony, uczestników postępowania, 
z wyjątkiem dłużnika zajętej wierzytelności z tytułu nadpłaty lub zwrotu podatku, 
i administracyjny organ egzekucyjny o zachodzącej podstawie przekazania 
egzekucji sądowej administracyjnemu organowi egzekucyjnemu. 
**§ 2.** Sądowy organ egzekucyjny niezwłocznie sporządza i przekazuje 
administracyjnemu organowi egzekucyjnemu adnotację w sprawie zbiegu. 
**§ 3.** (uchylony) 
**§ 4.** W przypadku, o którym mowa w § 2, komornik: 
- 1) zwraca wierzycielowi niewykorzystaną zaliczkę; 
- 2) przekazuje administracyjnemu organowi egzekucyjnemu wyegzekwowane 
kwoty uzyskane wskutek zajęcia rzeczy albo prawa majątkowego, do których 
nastąpił zbieg, które nie zostały wypłacone wierzycielowi przed 
sporządzeniem zawiadomienia, o którym mowa w § 1. 
**§ 5.** Skarga na czynności komornika oraz na zaniechanie przez komornika 
dokonania 
czynności 
przysługuje 
również 
administracyjnemu 
organowi 
egzekucyjnemu.

***
## Art. 7733. {#kpc-trzecia--art-7733}

(uchylony) 

 
 
 
s. 363/580 
 
2025-09-08

***
## Art. 774. {#kpc-trzecia--art-774}

**§ 1.** Sądowy organ egzekucyjny, który przejął prowadzenie łącznie 
egzekucji sądowej i administracyjnej, postanowi w trybie dla niego właściwym 
również o kosztach powstałych w egzekucji, której dotyczył zbieg. 
**§ 2.** Sądowy organ egzekucyjny, który przejął prowadzenie łącznie egzekucji 
sądowej i administracyjnej, na żądanie administracyjnego organu egzekucyjnego, 
informuje ten organ o przebiegu egzekucji. 
**§ 3.** Sądowy organ egzekucyjny, który przejął prowadzenie łącznie egzekucji 
sądowej i administracyjnej, dokonuje podziału sumy uzyskanej z egzekucji objętej 
zbiegiem dopiero po otrzymaniu od organów biorących udział w zbiegu adnotacji 
w sprawie zbiegu. 
**§ 4.** Sądowy organ egzekucyjny, który przejął prowadzenie łącznie egzekucji 
sądowej i administracyjnej, zawiadamia dłużnika o wysokości dochodzonych 
należności oraz sposobie egzekucji. Przepisów art. 805 § 1 zdanie pierwsze i § 2 
nie stosuje się.

***
## Art. 775. {#kpc-trzecia--art-775}

**§ 1.** W przypadku 
zbiegu 
egzekucji 
administracyjnej 
i zabezpieczenia sądowego, jak również zbiegu zabezpieczenia administracyjnego 
i egzekucji sądowej do tej samej rzeczy albo prawa majątkowego sprawę 
o zabezpieczenie przejmuje organ, który prowadził dotąd egzekucję do tej rzeczy 
albo prawa majątkowego. Jeżeli jednak egzekucja lub zabezpieczenie dotyczą 
tytułów wykonawczych lub świadczeń wymienionych odpowiednio w art. 773 § 2 
i 21, egzekucję i zabezpieczenie do objętej zbiegiem rzeczy albo prawa 
majątkowego prowadzi łącznie organ wskazany w tych przepisach jako właściwy. 
**§ 2.** Do zbiegu egzekucji administracyjnej i zabezpieczenia sądowego, jak 
również zbiegu zabezpieczenia administracyjnego i egzekucji sądowej do tej samej 
rzeczy albo prawa majątkowego przepisy art. 773 § 22 i 3–8, art. 7732 
i art. 774 stosuje się odpowiednio.

***
## Art. 7751. {#kpc-trzecia--art-7751}

Komornik, który przyjął wniosek o wszczęcie egzekucji, do 
prowadzenia której nie jest właściwy według przepisów niniejszego kodeksu, nie 
może odmówić przyjęcia innych wniosków o wszczęcie egzekucji przeciwko temu 
samemu dłużnikowi, jeżeli następni wierzyciele wnoszą o przeprowadzenie 
egzekucji według tych samych sposobów co wcześniejsi wierzyciele. 

 
 
 
s. 364/580 
 
2025-09-08 
#### DZIAŁ II
Tytuły egzekucyjne i klauzula wykonalności

***
## Art. 776. {#kpc-trzecia--art-776}

Podstawą egzekucji jest tytuł wykonawczy. Tytułem wykonawczym 
jest tytuł egzekucyjny zaopatrzony w klauzulę wykonalności, chyba że ustawa 
stanowi inaczej.

***
## Art. 7761. {#kpc-trzecia--art-7761}

**§ 1.** Tytuł wykonawczy wystawiony przeciwko dłużnikowi 
pozostającemu w związku małżeńskim jest podstawą do prowadzenia egzekucji nie 
tylko z majątku osobistego dłużnika, lecz także z pobranego przez niego wynagro-
dzenia za pracę lub dochodów uzyskanych z prowadzenia przez niego innej 
działalności zarobkowej oraz z korzyści uzyskanych z jego praw autorskich i praw 
pokrewnych, praw własności przemysłowej oraz innych praw twórcy. 
**§ 2.** Zawarcie umowy majątkowej małżeńskiej, mocą której rozszerzono 
wspólność majątkową, nie wyłącza prowadzenia egzekucji z tych składników 
majątku, które należałyby do majątku osobistego dłużnika, gdyby umowy takiej nie 
zawarto. 
**§ 3.** Przepis § 2 nie wyłącza obrony dłużnika i jego małżonka w drodze 
powództw przeciwegzekucyjnych, jeżeli umowa majątkowa małżeńska była 
skuteczna wobec wierzyciela. 
**§ 4.** Przepisy § 1–3 stosuje się odpowiednio, gdy egzekucja jest prowadzona 
na podstawie samego tytułu egzekucyjnego.

***
## Art. 777. {#kpc-trzecia--art-777}

**§ 1.** Tytułami egzekucyjnymi są: 
- 1) orzeczenie sądu prawomocne lub podlegające natychmiastowemu wykonaniu, 
jak również ugoda zawarta przed sądem; 
- 11) orzeczenie 
referendarza 
sądowego 
prawomocne 
lub 
podlegające 
natychmiastowemu wykonaniu; 
- 2) (uchylony) 
- 21) (uchylony) 
- 3) inne orzeczenia, ugody i akty, które z mocy ustawy podlegają wykonaniu 
w drodze egzekucji sądowej; 
- 4) akt notarialny, w którym dłużnik poddał się egzekucji i który obejmuje 
obowiązek zapłaty sumy pieniężnej lub wydania rzeczy oznaczonych co do 
gatunku, ilościowo w akcie określonych, albo też wydania rzeczy 

 
 
 
s. 365/580 
 
2025-09-08 
 
indywidualnie oznaczonej, gdy w akcie wskazano termin wykonania 
obowiązku lub zdarzenie, od którego uzależnione jest wykonanie; 
- 5) akt notarialny, w którym dłużnik poddał się egzekucji i który obejmuje 
obowiązek zapłaty sumy pieniężnej do wysokości w akcie wprost określonej 
albo oznaczonej za pomocą klauzuli waloryzacyjnej, gdy w akcie wskazano 
zdarzenie, od którego uzależnione jest wykonanie obowiązku, jak również 
termin, do którego wierzyciel może wystąpić o nadanie temu aktowi klauzuli 
wykonalności; 
- 6) akt notarialny określony w pkt 4 lub 5, w którym niebędąca dłużnikiem 
osobistym osoba, której rzecz, wierzytelność lub prawo obciążone jest 
hipoteką lub zastawem, poddała się egzekucji z obciążonego przedmiotu 
w celu 
zaspokojenia 
wierzytelności 
pieniężnej 
przysługującej 
zabezpieczonemu wierzycielowi. 
**§ 2.** Oświadczenie dłużnika o poddaniu się egzekucji może być złożone także 
w odrębnym akcie notarialnym. W takim przypadku w akcie notarialnym wskazuje 
się stosunek prawny, w związku z którym dłużnik poddaje się egzekucji, datę 
powstania zobowiązania dłużnika, jego treść, a w przypadku zobowiązań z umów 
wzajemnych – dodatkowo świadczenie wierzyciela z terminem jego wykonania. 
**§ 21.** Jeśli oświadczenie o poddaniu się egzekucji jest składane w celu 
zabezpieczenia roszczeń wynikających z zawarcia przez osobę fizyczną umowy 
pożyczki niezwiązanej bezpośrednio z działalnością gospodarczą lub zawodową 
prowadzoną przez tę osobę albo z zawarcia przez tę osobę innej umowy, do której 
przepisy o pożyczce stosuje się odpowiednio, wysokość sumy pieniężnej, do której 
dłużnik poddaje się egzekucji, nie może przekraczać sumy kwoty pożyczki 
powiększonej o wysokość odsetek maksymalnych obliczonych bezpośrednio od tej 
kwoty za okres, na który została udzielona pożyczka, wysokości odsetek 
maksymalnych za opóźnienie obliczonych od kwoty pożyczki za okres do 
6 miesięcy oraz maksymalnej wysokości pozaodsetkowych kosztów, o których 
mowa w art. 7201 ustawy z dnia 23 kwietnia 1964 r. – Kodeks cywilny. 
**§ 3.** (uchylony)

***
## Art. 778. {#kpc-trzecia--art-778}

Do egzekucji ze wspólnego majątku wspólników spółki prawa 
cywilnego konieczny jest tytuł egzekucyjny wydany przeciwko wszystkim 
wspólnikom. 

 
 
 
s. 366/580 
 
2025-09-08

***
## Art. 7781. {#kpc-trzecia--art-7781}

Tytułowi egzekucyjnemu wydanemu przeciwko spółce jawnej, 
spółce partnerskiej, spółce komandytowej lub spółce komandytowo-akcyjnej sąd 
nadaje 
klauzulę 
wykonalności 
przeciwko 
wspólnikowi 
ponoszącemu 
odpowiedzialność bez ograniczenia całym swoim majątkiem za zobowiązania 
spółki, jeżeli egzekucja przeciwko spółce okaże się bezskuteczna, jak również 
wtedy, gdy jest oczywiste, że egzekucja ta będzie bezskuteczna. Nie dotyczy to 
osoby, która w chwili wszczęcia postępowania w sprawie, w której został wydany 
tytuł egzekucyjny przeciwko spółce, nie była już jej wspólnikiem.

***
## Art. 7782. {#kpc-trzecia--art-7782}

Tytułowi egzekucyjnemu wydanemu przeciwko spółce, o której 
mowa w art. 7a ust. 1 ustawy z dnia 19 grudnia 2008 r. o partnerstwie publiczno-
-prywatnym (Dz. U. z 2023 r. poz. 1637), obejmującemu obowiązek zapłaty 
wynagrodzenia należnego podwykonawcy, sąd nadaje klauzulę wykonalności 
przeciwko partnerowi prywatnemu, jeżeli egzekucja przeciwko spółce okaże się 
bezskuteczna, jak również wtedy, gdy jest oczywiste, że egzekucja ta będzie 
bezskuteczna.

***
## Art. 7783. {#kpc-trzecia--art-7783}

Tytułowi egzekucyjnemu wydanemu przeciwko fundatorowi 
fundacji rodzinnej sąd nadaje klauzulę wykonalności przeciwko fundacji rodzinnej 
ponoszącej odpowiedzialność za zobowiązania fundatora, jeżeli egzekucja 
przeciwko fundatorowi okaże się bezskuteczna, jak również wtedy, gdy jest 
oczywiste, że egzekucja ta będzie bezskuteczna.

***
## Art. 779. {#kpc-trzecia--art-779}

**§ 1.** Do egzekucji ze spadku konieczny jest – aż do działu spadku – 
tytuł egzekucyjny przeciwko wszystkim spadkobiercom. 
**§ 2.** Jeżeli tytuł był wydany przeciwko spadkodawcy, przejście obowiązków 
na spadkobierców następuje stosownie do art. 788.

***
## Art. 780. {#kpc-trzecia--art-780}

Jeżeli ustanowiono zarządcę masy majątkowej, kuratora spadku lub 
zarząd sukcesyjny albo gdy powołano wykonawcę testamentu, do egzekucji 
z mienia poddanego ich pieczy konieczny jest tytuł egzekucyjny wydany przeciwko 
zarządcy masy majątkowej, kuratorowi spadku, zarządcy sukcesyjnemu lub 
wykonawcy testamentu. Przepis § 2 artykułu poprzedzającego stosuje się 
odpowiednio.

***
## Art. 781. {#kpc-trzecia--art-781}

**§ 1.** Tytułowi egzekucyjnemu pochodzącemu od sądu klauzulę 
wykonalności nadaje sąd pierwszej instancji, w którym sprawa się toczyła lub 
Zmiany (dodanie 
wyrazów) w § 1 i 
12 w art. 781 
wejdą w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 

 
 
 
s. 367/580 
 
2025-09-08 
 
toczy. Sąd drugiej instancji nadaje klauzulę wykonalności, dopóki akta sprawy 
znajdują się w tym sądzie, nie dotyczy to jednak Sądu Najwyższego oraz 
przypadków, o których mowa w art. 7781, art. 7782, <art. 7783,> art. 786, art. 787, 
art. 7871, art. 788 i art. 789. 
**§ 11.** Czynności w sprawach o nadanie klauzuli wykonalności tytułom 
egzekucyjnym, o których mowa w art. 777 § 1, może wykonywać referendarz 
sądowy. 
**§ 12.** Tytułowi egzekucyjnemu, o którym mowa w art. 783 § 4, klauzulę 
wykonalności, w przypadkach określonych w art. 7781, art. 7782, <art. 7783,> 787, 
7871, 788 oraz 789, nadaje sąd rejonowy właściwości ogólnej dłużnika. 
**§ 13.** Do wniosku o nadanie klauzuli wykonalności, o którym mowa w § 12, 
należy 
dołączyć 
dokument 
uzyskany 
z systemu 
teleinformatycznego 
umożliwiający sądowi weryfikację istnienia i treści tytułu wykonawczego. Przed 
rozpoznaniem wniosku istnienie i treść tytułu wykonawczego podlegają 
zweryfikowaniu przez sędziego lub referendarza sądowego w systemie 
teleinformatycznym. 
**§ 14.** Do wniosku o nadanie klauzuli wykonalności tytułowi egzekucyjnemu, 
o którym mowa w art. 777 § 1 pkt 4–6 lub § 2, w związku z udzieleniem pożyczki 
pieniężnej zawieranej z osobą fizyczną i niezwiązanej bezpośrednio z działalnością 
gospodarczą lub zawodową tej osoby należy dołączyć dokument potwierdzający 
wydanie przedmiotu pożyczki biorącemu pożyczkę lub wskazanej przez niego 
osobie. 
**§ 2.** Tytułom egzekucyjnym pochodzącym od sądu administracyjnego oraz 
innym tytułom klauzulę wykonalności nadaje sąd rejonowy właściwości ogólnej 
dłużnika. Jeżeli tej właściwości nie można ustalić, klauzulę nadaje sąd rejonowy, 
w którego okręgu ma być wszczęta egzekucja, a gdy wierzyciel zamierza wszcząć 
egzekucję za granicą – sąd rejonowy, w którego okręgu tytuł został sporządzony. 
**§ 3.** (uchylony) 
**§ 31.** (uchylony) 
**§ 4.** (uchylony)

***
## Art. 7811. {#kpc-trzecia--art-7811}

Wniosek o nadanie klauzuli wykonalności sąd rozpoznaje 
niezwłocznie, nie później jednak niż w terminie 3 dni od dnia jego złożenia. 

 
 
 
s. 368/580 
 
2025-09-08

***
## Art. 782. {#kpc-trzecia--art-782}

**§ 1.** Klauzulę wykonalności nadaje sąd w składzie jednego 
sędziego, na wniosek wierzyciela. Sąd z urzędu nadaje klauzulę wykonalności 
tytułowi egzekucyjnemu wydanemu w postępowaniu, które zostało lub mogło być 
wszczęte z urzędu, a także innemu tytułowi egzekucyjnemu w części, w jakiej 
obejmuje grzywnę lub karę pieniężną orzeczoną w postępowaniu cywilnym lub 
koszty sądowe w sprawach cywilnych przysługujące Skarbowi Państwa. 
**§ 11.** Tytułowi egzekucyjnemu nakazującemu osobie stosującej przemoc 
domową opuszczenie wspólnie zajmowanego mieszkania i jego bezpośredniego 
otoczenia sąd nadaje klauzulę wykonalności z urzędu. Tytuł wykonawczy doręcza 
się wierzycielowi z urzędu. 
**§ 2.** Nakazowi 
zapłaty 
wydanemu 
w elektronicznym 
postępowaniu 
upominawczym nadaje się klauzulę wykonalności z urzędu niezwłocznie po jego 
uprawomocnieniu się.

***
## Art. 7821. {#kpc-trzecia--art-7821}

**§ 1.** Sąd odmawia nadania klauzuli wykonalności, jeżeli: 
- 1) w świetle okoliczności sprawy jest oczywiste, że wniosek jest sprzeczny 
z prawem albo zmierza do obejścia prawa; 
- 2) z okoliczności sprawy i treści tytułu egzekucyjnego wynika, że objęte tytułem 
egzekucyjnym roszczenie uległo przedawnieniu, chyba że wierzyciel 
przedstawi dokument, z którego wynika, że doszło do przerwania biegu 
terminu przedawnienia; sąd nie bada przedawnienia odsetek wymagalnych po 
powstaniu tytułu egzekucyjnego. 
**§ 2.** Prawomocne oddalenie wniosku o nadanie klauzuli wykonalności na 
podstawie 
§ 1 pkt 2 nie 
pozbawia 
wierzyciela 
prawa 
do 
wystąpienia 
z powództwem o ustalenie, że objęta tytułem egzekucyjnym wierzytelność nie 
uległa przedawnieniu. Nie dotyczy to sytuacji, gdy wierzycielowi przysługuje dalej 
idące roszczenie.

***
## Art. 783. {#kpc-trzecia--art-783}

**§ 1.** Postanowienie o nadaniu klauzuli wykonalności wymienia 
także tytuł egzekucyjny, a w razie potrzeby oznacza świadczenie podlegające 
egzekucji i zakres egzekucji oraz wskazuje czy orzeczenie podlega wykonaniu jako 
prawomocne, czy jako natychmiast wykonalne. Jeżeli przepis szczególny nie 
stanowi inaczej, tytułowi egzekucyjnemu opiewającemu na świadczenie pieniężne 
w walucie obcej sąd nada klauzulę wykonalności ze zobowiązaniem komornika do 

 
 
 
s. 369/580 
 
2025-09-08 
 
przeliczenia tej kwoty na walutę polską według średniego kursu waluty obcej 
ogłoszonego przez Narodowy Bank Polski na dzień sporządzenia planu podziału, 
a jeżeli planu podziału nie sporządza się – na dzień wypłaty kwoty wierzycielowi. 
**§ 11.** Niezwłocznie po ogłoszeniu postanowienia o nadaniu klauzuli 
wykonalności, a gdy ogłoszenia nie było niezwłocznie po jego wydaniu, klauzulę 
wykonalności umieszcza się na tytule egzekucyjnym, a w przypadkach, o których 
mowa w art. 781 § 12, na zweryfikowanym przez sąd dokumencie uzyskanym 
z systemu 
teleinformatycznego 
potwierdzającym 
istnienie 
i treść 
tytułu 
egzekucyjnego. Klauzula wykonalności zawiera stwierdzenie, że tytuł egzekucyjny 
uprawnia do egzekucji, a w razie potrzeby – także informacje wskazane w § 1. 
Klauzulę wykonalności podpisuje sędzia albo referendarz sądowy. 
**§ 2.** Minister Sprawiedliwości określi, w drodze rozporządzenia, brzmienie 
klauzuli wykonalności, mając na względzie treść § 1 i 11 oraz sprawne prowadzenie 
egzekucji i zapewnienie możliwości obrony praw jej uczestników. 
**§ 3.** Postanowienie o nadaniu klauzuli wykonalności tytułom egzekucyjnym, 
o których mowa w art. 777 § 1 pkt 1 i 11, jest wydawane bez spisywania odrębnej 
sentencji, przez umieszczenie na tytule egzekucyjnym klauzuli wykonalności 
i opatrzenie jej podpisem sędziego albo referendarza sądowego, który wydaje 
postanowienie. Na oryginale orzeczenia umieszcza się wzmiankę o nadaniu 
klauzuli wykonalności. 
**§ 31.** Postanowienie o nadaniu klauzuli wykonalności tytułom egzekucyjnym, 
o których mowa w art. 777 § 1 pkt 1 i 11, wydanym w postaci elektronicznej, jest 
wydawane bez spisywania odrębnej sentencji, poprzez umieszczenie klauzuli 
wykonalności w systemie teleinformatycznym i opatrzenie jej kwalifikowanym 
podpisem elektronicznym, sędziego albo referendarza sądowego, który wydaje 
postanowienie. 
**§ 32.** Przepisów § 3 i 31 nie stosuje się w przypadkach, o których mowa 
w art. 7781, art. 7782, <art. 7783,> art. 787, art. 7871, art. 788 oraz art. 789. 
**§ 4.** Postanowienie o nadaniu klauzuli wykonalności tytułom egzekucyjnym, 
o których mowa w art. 777 § 1 pkt 1 i 11, wydanym w postaci elektronicznej 
pozostawia 
się 
wyłącznie 
w systemie 
teleinformatycznym, 
z wyjątkiem 
przypadków, o których mowa w art. 7781, art. 7782, <art. 7783,>  art. 787, art. 7871, 
art. 788 oraz art. 789. 
Zmiany (dodanie 
wyrazów) w § 32 i 

w 
art. 

wejdą w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 
 

 
 
 
s. 370/580 
 
2025-09-08 
**§ 41.** (uchylony) 
**§ 5.** Minister Sprawiedliwości w porozumieniu z ministrem właściwym do 
spraw informatyzacji określi, w drodze rozporządzenia, czynności sądu związane 
z nadawaniem klauzuli wykonalności, o której mowa w § 31, oraz sposób 
przechowywania 
tytułów 
wykonawczych 
i posługiwania 
się 
tytułami 
wykonawczymi, 
o których 
mowa 
w § 4, 
przy 
uwzględnieniu 
potrzeby 
usprawnienia postępowania oraz zapewnienia bezpieczeństwa korzystania 
z elektronicznych tytułów wykonawczych.

***
## Art. 784. {#kpc-trzecia--art-784}

Celem uzyskania klauzuli wykonalności tytułu pochodzącego od 
organu administracji publicznej lub sądu szczególnego, który sam nie nadaje 
klauzuli, wierzyciel złoży sądowi w razie potrzeby oprócz tytułu także ich 
zaświadczenie, że tytuł podlega wykonaniu.

***
## Art. 785. {#kpc-trzecia--art-785}

Jeżeli do uzyskania klauzuli wykonalności potrzebne jest 
zaświadczenie lub dokument, które według ustawy organy administracji publicznej 
są obowiązane wydać dłużnikowi, wierzyciel może również żądać ich wydania. 
Gdy wierzyciel nie może uzyskać zaświadczenia lub dokumentu albo gdy chodzi 
o nadanie klauzuli z urzędu, wydanie ich zarządza sąd.

***
## Art. 786. {#kpc-trzecia--art-786}

**§ 1.** Jeżeli wykonanie tytułu egzekucyjnego jest uzależnione od 
zdarzenia, które udowodnić powinien wierzyciel, sąd nada klauzulę wykonalności 
po dostarczeniu dowodu tego zdarzenia w formie dokumentu urzędowego lub 
prywatnego z podpisem urzędowo poświadczonym. Nie dotyczy to wypadku, gdy 
wykonanie jest uzależnione od równoczesnego świadczenia wzajemnego, chyba że 
świadczenie dłużnika polega na oświadczeniu woli. 
**§ 2.** Jeżeli obowiązek wypłaty wynagrodzenia zasądzonego w orzeczeniu 
przywracającym do pracy lub ustalonego w ugodzie jest uzależniony od podjęcia 
przez pracownika pracy, klauzulę wykonalności w części dotyczącej tego 
wynagrodzenia nadaje się po stwierdzeniu, że pracownik podjął pracę.

***
## Art. 7861. {#kpc-trzecia--art-7861}

(uchylony)

***
## Art. 7862. {#kpc-trzecia--art-7862}

(uchylony)

***
## Art. 787. {#kpc-trzecia--art-787}

Tytułowi 
egzekucyjnemu 
wydanemu 
przeciwko 
osobie 
pozostającej w związku małżeńskim sąd nada klauzulę wykonalności także 

 
 
 
s. 371/580 
 
2025-09-08 
 
przeciwko jej małżonkowi z ograniczeniem jego odpowiedzialności do majątku 
objętego wspólnością majątkową, jeżeli wierzyciel wykaże dokumentem 
urzędowym lub prywatnym, że stwierdzona tytułem egzekucyjnym wierzytelność 
powstała z czynności prawnej dokonanej za zgodą małżonka dłużnika.

***
## Art. 7871. {#kpc-trzecia--art-7871}

Tytułowi 
egzekucyjnemu 
wydanemu 
przeciwko 
osobie 
pozostającej w związku małżeńskim sąd nada klauzulę wykonalności przeciwko 
małżonkowi 
dłużnika 
z ograniczeniem 
jego 
odpowiedzialności 
do 
przedsiębiorstwa wchodzącego w skład majątku wspólnego małżonków, jeżeli 
wierzyciel wykaże dokumentem urzędowym lub prywatnym, że stwierdzona 
tytułem egzekucyjnym wierzytelność powstała w związku z prowadzeniem 
przedsiębiorstwa.

***
## Art. 7872. {#kpc-trzecia--art-7872}

Zawarcie umowy majątkowej małżeńskiej nie stanowi przeszkody 
do nadania klauzuli wykonalności według przepisów art. 787 i art. 7871 oraz 
prowadzenia na podstawie tak powstałego tytułu wykonawczego egzekucji do tych 
składników, które należałyby do majątku wspólnego, gdyby umowy majątkowej 
nie zawarto. Przepis niniejszy nie wyłącza obrony małżonków w drodze powództw 
przeciwegzekucyjnych, jeżeli umowa majątkowa małżeńska była skuteczna wobec 
wierzyciela.

***
## Art. 788. {#kpc-trzecia--art-788}

**§ 1.** Jeżeli uprawnienie lub obowiązek po powstaniu tytułu 
egzekucyjnego lub w toku sprawy przed wydaniem tytułu przeszły na inną osobę, 
sąd nada klauzulę wykonalności na rzecz lub przeciwko tej osobie, gdy przejście to 
będzie wykazane dokumentem urzędowym lub prywatnym z podpisem urzędowo 
poświadczonym. 
**§ 2.** Za przejście uprawnień lub obowiązków, o których mowa w paragrafie 
poprzedzającym, uważa się również zmiany w prawie rozporządzania mieniem 
wywołane ustanowieniem zarządcy masy majątkowej, kuratora spadku lub zarządu 
sukcesyjnego albo powołaniem wykonawcy testamentu lub tymczasowego 
przedstawiciela, jak również wygaśnięciem funkcji zarządcy masy majątkowej, 
kuratora spadku, zarządcy sukcesyjnego, wykonawcy testamentu lub tym-
czasowego przedstawiciela. 
**§ 3.** Sąd odmawia nadania klauzuli wykonalności, jeżeli wszczęcie lub dalsze 
prowadzenie egzekucji możliwe jest na zasadach przewidzianych w art. 8041 

 
 
 
s. 372/580 
 
2025-09-08 
 
i art. 8042. Przepisu tego nie stosuje się, jeżeli wnioskodawca wykaże, że organ 
egzekucyjny prawomocnym postanowieniem nie dopuścił go do udziału 
w postępowaniu lub odmówił wszczęcia egzekucji.

***
## Art. 789. {#kpc-trzecia--art-789}

Przepis § 1 artykułu poprzedzającego stosuje się odpowiednio do 
nabywcy przedsiębiorstwa lub gospodarstwa rolnego, jeżeli tytuł egzekucyjny stał 
się prawomocny przed nabyciem.

***
## Art. 7891. {#kpc-trzecia--art-7891}

Jeżeli wierzyciel nie może uzyskać dokumentu stwierdzającego 
zbycie przedsiębiorstwa lub gospodarstwa rolnego albo gdyby uzyskanie takiego 
dokumentu było nadmiernie utrudnione, sąd przed nadaniem klauzuli 
wykonalności wysłucha nabywcę stosownie do art. 760 § 2. Jeżeli nabywca 
zaprzecza istnieniu podstaw do nadania przeciwko niemu klauzuli wykonalności, 
sąd na wniosek wierzyciela, a w sprawach o alimenty lub o roszczenia z zakresu 
prawa pracy, także z urzędu, wzywa nabywcę do okazania dokumentów 
stwierdzających nabycie. Przepisy o wyjawieniu majątku stosuje się odpowiednio. 
W razie przyznania okoliczności nabycia przedsiębiorstwa lub gospodarstwa 
rolnego sąd nada klauzulę wykonalności bez okazywania dokumentu 
stwierdzającego nabycie.

***
## Art. 7892. {#kpc-trzecia--art-7892}

**§ 1.** Tytuł 
wykonawczy 
wystawiony 
przeciwko 
zbywcy 
przedsiębiorstwa lub gospodarstwa rolnego jest także podstawą egzekucji 
przeciwko nabywcy przedsiębiorstwa lub gospodarstwa rolnego, jeżeli wierzyciel 
złożył wniosek o wszczęcie egzekucji w ciągu miesiąca od dnia nabycia 
przedsiębiorstwa lub gospodarstwa rolnego. 
**§ 2.** Przepis § 1 stosuje się odpowiednio, gdy przejęcie obowiązków nastąpiło 
w wyniku podziału, połączenia lub innego przekształcenia przedsiębiorstwa lub 
gospodarstwa rolnego albo w wyniku wniesienia do spółki przedsiębiorstwa lub 
jego zorganizowanej części dokonanego w trybie komercjalizacji i prywatyzacji 
przedsiębiorstw państwowych. 
**§ 3.** Przepisy 
§ 1 
i § 2 nie 
uchybiają 
przepisom 
o ograniczeniu 
odpowiedzialności nabywcy przedsiębiorstwa lub gospodarstwa rolnego za 
zobowiązania zbywcy.

***
## Art. 790. {#kpc-trzecia--art-790}

(uchylony) 

 
 
 
s. 373/580 
 
2025-09-08

***
## Art. 791. {#kpc-trzecia--art-791}

**§ 1.** Tytuł wykonawczy zobowiązujący do wydania nieruchomości, 
statku lub do opróżnienia pomieszczenia upoważnia do prowadzenia egzekucji 
także przeciwko każdemu, kto uzyskał władanie nad tym przedmiotem po 
wszczęciu postępowania, w którym wydano tytuł egzekucyjny. 
**§ 2.** Tytuł wykonawczy zobowiązujący do wydania nieruchomości, statku lub 
do opróżnienia pomieszczenia upoważnia do prowadzenia egzekucji nie tylko 
przeciw dłużnikowi, lecz także przeciwko jego domownikom, krewnym i innym 
osobom reprezentującym jego prawa. 
**§ 3.** Przepisy § 1 i 2 nie wyłączają praw określonych przepisami o ochronie 
lokatorów oraz praw, które są skuteczne wobec wierzyciela. Jeżeli dłużnik twierdzi, 
że przysługuje mu prawo skuteczne wobec wierzyciela, komornik wstrzyma się 
względem niego z czynnościami egzekucyjnymi, pouczając, że w terminie 
tygodnia może wytoczyć powództwo o pozbawienie w stosunku do niego tytułu 
wykonawczego wykonalności. 
**§ 4.** (uchylony) 
**§ 5.** Po upływie miesiąca od daty wstrzymania czynności komornik podejmie 
dalsze czynności egzekucyjne w stosunku do dłużnika, chyba że postępowanie 
egzekucyjne 
zostało 
zawieszone 
postanowieniem 
sądu 
o udzieleniu 
zabezpieczenia.

***
## Art. 792. {#kpc-trzecia--art-792}

Jeżeli następca ponosi odpowiedzialność tylko z określonych 
przedmiotów albo do wysokości ich wartości, należy w klauzuli wykonalności 
zastrzec mu prawo powoływania się w toku postępowania egzekucyjnego na 
ograniczoną odpowiedzialność, o ile prawo to nie jest zastrzeżone już w tytule 
egzekucyjnym.

***
## Art. 793. {#kpc-trzecia--art-793}

W razie potrzeby prowadzenia egzekucji na rzecz kilku osób lub 
przeciwko kilku osobom albo z kilku składowych części majątku tego samego 
dłużnika, sąd oprócz pierwszego tytułu wykonawczego może wydawać dalsze 
tytuły, oznaczając cel, do którego mają służyć, i ich liczbę porządkową.

***
## Art. 794. {#kpc-trzecia--art-794}

Ponowne wydanie tytułu wykonawczego zamiast utraconego może 
nastąpić jedynie na mocy postanowienia sądu wydanego po przeprowadzeniu 
rozprawy. Na ponownie wydanym tytule wykonawczym czyni się wzmiankę 

 
 
 
s. 374/580 
 
2025-09-08 
 
o wydaniu go zamiast tytułu pierwotnego. W postępowaniu tym sąd ogranicza 
badanie do faktu utraty tytułu wykonawczego.

***
## Art. 7941. {#kpc-trzecia--art-7941}

**§ 1.** Postanowienie o nadaniu klauzuli wykonalności w części, 
w jakiej przyznano w nim wierzycielowi zwrot kosztów postępowania, podlega 
wykonaniu bez potrzeby zaopatrywania go w klauzulę wykonalności. 
**§ 2.** W razie wydania postanowienia o nadaniu klauzuli wykonalności 
w sposób określony w art. 783 § 3 albo 31 rozstrzygnięcie o przyznaniu 
wierzycielowi 
zwrotu kosztów postępowania umieszcza się w klauzuli 
wykonalności.

***
## Art. 7942. {#kpc-trzecia--art-7942}

**§ 1.** Postanowienia 
wydane 
na 
posiedzeniach 
niejawnych 
w postępowaniach przewidzianych w niniejszym dziale sąd doręcza tylko 
wierzycielowi. Postanowienie co do nadania klauzuli wykonalności, o której mowa 
w art. 783 § 4, doręcza się w sposób przewidziany w art. 1311. 
**§ 2.** W razie wydania postanowienia o nadaniu klauzuli wykonalności 
w sposób określony w art. 783 § 3 albo 31 uzasadnienie postanowienia sporządza 
się i doręcza wierzycielowi na jego wniosek zgłoszony w terminie tygodniowym 
od dnia wydania mu tytułu wykonawczego albo doręczenia zawiadomienia 
o utworzeniu tytułu wykonawczego w systemie teleinformatycznym. 
**§ 3.** Dłużnik może żądać sporządzenia uzasadnienia postanowienia o nadaniu 
klauzuli wykonalności i doręczenia postanowienia z uzasadnieniem w terminie 
tygodniowym od dnia doręczenia mu zawiadomienia o wszczęciu egzekucji. Jeżeli 
postanowienie o nadaniu klauzuli wykonalności zostało wydane bez spisywania 
odrębnej sentencji, dłużnikowi doręcza się wyłącznie uzasadnienie postanowienia.

***
## Art. 795. {#kpc-trzecia--art-795}

**§ 1.** Na postanowienie sądu co do nadania klauzuli wykonalności 
przysługuje zażalenie. 
**§ 2.** Termin do wniesienia zażalenia biegnie dla wierzyciela od dnia wydania 
mu 
tytułu wykonawczego lub 
zawiadomienia go o utworzeniu 
tytułu 
wykonawczego w systemie teleinformatycznym albo od dnia ogłoszenia 
postanowienia odmownego, a gdy ogłoszenia nie było – od dnia doręczenia tego 
postanowienia. Dla dłużnika termin ten biegnie od dnia doręczenia mu 
zawiadomienia o wszczęciu egzekucji. W razie zgłoszenia wniosku, o którym 

 
 
 
s. 375/580 
 
2025-09-08 
 
mowa w art. 7942 § 2 albo 3, termin ten biegnie od dnia doręczenia stronie 
uzasadnienia postanowienia albo postanowienia z uzasadnieniem. 
**§ 21.** W przypadkach, o których mowa w art. 7781, art. 7782, <art. 7783,> 
art. 786, art. 787, art. 7871, art. 788 i art. 789, lub gdy tytułem egzekucyjnym nie 
jest orzeczenie sądu albo referendarza sądowego, sąd drugiej instancji, 
uwzględniając zażalenie wierzyciela na postanowienie o odmowie nadania klauzuli 
wykonalności, uchyla zaskarżone postanowienie i przekazuje wniosek do 
ponownego rozpoznania, jeżeli zachodzą podstawy do nadania klauzuli 
wykonalności. 
**§ 3.** Przepisy § 2 i 21 stosuje się odpowiednio do skargi na postanowienie 
referendarza sądowego. 
DZIAŁ IIa 
Zaświadczenie europejskiego tytułu egzekucyjnego

***
## Art. 7951. {#kpc-trzecia--art-7951}

**§ 1.** Jeżeli tytuł egzekucyjny w postaci orzeczenia sądu lub ugody 
zawartej przed sądem lub zatwierdzonej przez sąd spełnia warunki określone 
w przepisach rozporządzenia (WE) nr 805/2004 Parlamentu Europejskiego i Rady 
z dnia 21 kwietnia 2004 r. w sprawie utworzenia Europejskiego Tytułu 
Egzekucyjnego dla roszczeń bezspornych (Dz. Urz. UE L 143 z 30.04.2004, 
str. 15, z późn. zm.; Dz. Urz. UE Polskie wydanie specjalne, rozdz. 19, t. 7, str. 38), 
zwanego dalej „rozporządzeniem nr 805/2004”, sąd, który wydał orzeczenie albo 
przed którym została zawarta ugoda lub który zatwierdził ugodę, na wniosek 
wierzyciela wydaje zaświadczenie, że stanowią one europejski tytuł egzekucyjny, 
zwane dalej „zaświadczeniem europejskiego tytułu egzekucyjnego”. 
**§ 2.** Jeżeli 
wniosek 
o wydanie 
zaświadczenia 
europejskiego 
tytułu 
egzekucyjnego dotyczy innego tytułu egzekucyjnego niż wskazany w § 1, 
w przedmiocie wniosku rozstrzyga sąd rejonowy, w którego okręgu tytuł został 
sporządzony.

***
## Art. 7952. {#kpc-trzecia--art-7952}

Postanowienie 
w przedmiocie 
wydania 
zaświadczenia 
europejskiego tytułu egzekucyjnego sąd wydaje w składzie jednego sędziego.

***
## Art. 7952a. {#kpc-trzecia--art-7952a}

W przypadku 
tytułu 
egzekucyjnego, 
o którym 
mowa 
w art. 783 § 4, zaświadczenie europejskiego tytułu egzekucyjnego doręcza się wraz 
Zmiana (dodanie 
wyrazów) w § 21 
w 
art. 

wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 

 
 
 
s. 376/580 
 
2025-09-08 
 
ze 
zweryfikowanym 
przez 
sąd 
dokumentem 
uzyskanym 
z systemu 
teleinformatycznego, potwierdzającym istnienie i treść tytułu egzekucyjnego.

***
## Art. 7953. {#kpc-trzecia--art-7953}

**§ 1.** Postanowienie 
o odmowie 
wydania 
zaświadczenia 
europejskiego tytułu egzekucyjnego doręcza się wyłącznie wierzycielowi. 
**§ 2.** Na postanowienie o odmowie wydania zaświadczenia europejskiego 
tytułu egzekucyjnego wierzycielowi przysługuje zażalenie. Odpisu zażalenia nie 
doręcza się dłużnikowi.

***
## Art. 7954. {#kpc-trzecia--art-7954}

**§ 1.** W razie stwierdzenia, że istnieje określona w przepisach 
rozporządzenia nr 805/2004 podstawa do uchylenia zaświadczenia europejskiego 
tytułu egzekucyjnego, sąd, który je wydał, na wniosek dłużnika uchyla to 
zaświadczenie. 
**§ 2.** Wniosek zgłasza się w terminie miesięcznym od dnia doręczenia 
dłużnikowi postanowienia o wydaniu zaświadczenia. 
**§ 3.** Jeżeli wniosek nie jest sporządzony na formularzu określonym 
w przepisach rozporządzenia nr 805/2004, powinien czynić zadość warunkom 
pisma procesowego oraz wskazywać okoliczności uzasadniające wniosek. 
**§ 4.** Przed uchyleniem zaświadczenia sąd wysłucha wierzyciela. 
**§ 5.** Na postanowienie w przedmiocie uchylenia zaświadczenia europejskiego 
tytułu egzekucyjnego przysługuje zażalenie.

***
## Art. 7955. {#kpc-trzecia--art-7955}

**§ 1.** Przepisy art. 7951–7952a stosuje się odpowiednio do 
wydawania 
przewidzianych 
w przepisach 
rozporządzenia 
nr 805/2004 zaświadczeń o utracie lub ograniczeniu wykonalności tytułu 
egzekucyjnego opatrzonego zaświadczeniem europejskiego tytułu egzekucyjnego. 
Wniosek o wydanie takiego zaświadczenia może złożyć także dłużnik. 
**§ 2.** Na postanowienie w przedmiocie wydania zaświadczenia, o którym 
mowa w § 1, przysługuje zażalenie. 
DZIAŁ IIb 
Stwierdzenie wykonalności europejskiego nakazu zapłaty

***
## Art. 7956. {#kpc-trzecia--art-7956}

**§ 1.** Sąd, który wydał europejski nakaz zapłaty, stwierdza z urzędu 
jego wykonalność, jeżeli zostały spełnione warunki określone w przepisach 
rozporządzenia nr 1896/2006. 

 
 
 
s. 377/580 
 
2025-09-08 
**§ 2.** Postanowienie może wydać także referendarz sądowy.

***
## Art. 7957. {#kpc-trzecia--art-7957}

Na postanowienie w przedmiocie stwierdzenia wykonalności 
przysługuje zażalenie. 
#### DZIAŁ IIc
Zaświadczenie dotyczące orzeczenia wydanego w europejskim postępowaniu 
w sprawie drobnych roszczeń

***
## Art. 7958. {#kpc-trzecia--art-7958}

**§ 1.** Sąd, który wydał orzeczenie w europejskim postępowaniu 
w sprawie drobnych roszczeń, wydaje na wniosek zaświadczenie dotyczące tego 
orzeczenia, określone w przepisach rozporządzenia nr 861/2007, jeżeli spełnione są 
warunki określone w tym rozporządzeniu. 
**§ 2.** Postanowienie może wydać także referendarz sądowy.

***
## Art. 7959. {#kpc-trzecia--art-7959}

Na 
postanowienie 
w przedmiocie 
wydania 
zaświadczenia 
przysługuje zażalenie. 
DZIAŁ IId 
Zaświadczenia dotyczące orzeczeń, ugód i innych tytułów egzekucyjnych 
w sprawach cywilnych i handlowych

***
## Art. 79510. {#kpc-trzecia--art-79510}

**§ 1.** Jeżeli 
orzeczenie 
objęte 
zakresem 
zastosowania 
rozporządzenia Parlamentu Europejskiego i Rady (UE) nr 1215/2012 z dnia 
12 grudnia 2012 r. w sprawie jurysdykcji i uznawania orzeczeń sądowych oraz ich 
wykonywania w sprawach cywilnych i handlowych (wersja przekształcona) 
(Dz. Urz. UE L 351 z 20.12.2012, str. 1, z późn. zm.), zwanego dalej 
„rozporządzeniem 
nr 1215/2012”, 
spełnia 
warunki 
określone 
w tym 
rozporządzeniu, sąd, który je wydał, wydaje na wniosek zaświadczenie na potrzeby 
uznania lub wykonania tego orzeczenia w innym państwie członkowskim Unii 
Europejskiej, określone w rozporządzeniu. 
**§ 2.** Jeżeli 
ugoda 
objęta 
zakresem 
zastosowania 
rozporządzenia 
nr 1215/2012 spełnia warunki określone w tym rozporządzeniu, sąd, przed którym 
zawarto ugodę albo który ją zatwierdził, wydaje na wniosek zaświadczenie na 
potrzeby wykonania tej ugody w innym państwie członkowskim Unii Europejskiej, 
określone w rozporządzeniu. 

 
 
 
s. 378/580 
 
2025-09-08 
**§ 3.** Jeżeli inny tytuł egzekucyjny niż określony w § 1 lub 2 objęty zakresem 
zastosowania rozporządzenia nr 1215/2012 spełnia warunki określone w tym 
rozporządzeniu, sąd rejonowy, w którego okręgu sporządzono tytuł, wydaje na 
wniosek zaświadczenie na potrzeby wykonania tego tytułu w innym państwie 
członkowskim Unii Europejskiej, określone w rozporządzeniu. 
**§ 4.** Postanowienie może wydać także referendarz sądowy.

***
## Art. 79511. {#kpc-trzecia--art-79511}

Na 
postanowienie 
w przedmiocie 
wydania 
zaświadczenia 
przysługuje zażalenie. 
Dział IIda 
Zaświadczenia dotyczące orzeczeń w sprawach małżeńskich oraz w sprawach 
dotyczących odpowiedzialności rodzicielskiej

***
## Art. 79511a. {#kpc-trzecia--art-79511a}

**§ 1.** Jeżeli 
orzeczenie 
objęte 
zakresem 
zastosowania 
rozporządzenia nr 2019/1111 spełnia warunki określone w tym rozporządzeniu, 
sąd, który wydał to orzeczenie, na wniosek strony, wydaje odpowiednie 
zaświadczenie na potrzeby uznania lub wykonania tego orzeczenia w innym 
państwie członkowskim Unii Europejskiej. 
**§ 2.** Na postanowienie w przedmiocie odmowy wydania zaświadczenia, 
o którym mowa w § 1, przysługuje zażalenie.

***
## Art. 79511b. {#kpc-trzecia--art-79511b}

**§ 1.** W razie stwierdzenia, że zachodzi przewidziana w art. 37 lub 
art. 48 rozporządzenia nr 2019/1111 podstawa do sprostowania lub cofnięcia 
zaświadczenia, sąd, który wydał zaświadczenie, na wniosek strony albo z urzędu, 
dokonuje sprostowania zaświadczenia albo je cofa. 
**§ 2.** W razie stwierdzenia, że zachodzi przewidziana w art. 49 rozporządzenia 
nr 2019/1111 podstawa do wydania zaświadczenia wskazującego na brak albo 
ograniczenie albo zawieszenie wykonalności orzeczenia, sąd, który wydał 
orzeczenie, na wniosek strony wydaje zaświadczenie wskazujące na brak albo 
ograniczenie albo zawieszenie wykonalności orzeczenia. 
**§ 3.** Na postanowienie w przedmiocie zaświadczenia, o którym mowa w § 1 
i 2, przysługuje zażalenie.

***
## Art. 79511c. {#kpc-trzecia--art-79511c}

Postanowienia, o których mowa w art. 79511a i art. 79511b, sąd 
wydaje na posiedzeniu niejawnym. 

 
 
 
s. 379/580 
 
2025-09-08 
 
DZIAŁ IIe 
Wyciągi z orzeczeń, ugód i innych tytułów egzekucyjnych w sprawach 
alimentacyjnych

***
## Art. 79512. {#kpc-trzecia--art-79512}

**§ 1.** Jeżeli 
orzeczenie 
objęte 
zakresem 
zastosowania 
rozporządzenia Rady (WE) nr 4/2009 z dnia 18 grudnia 2008 r. w sprawie 
jurysdykcji, prawa właściwego, uznawania i wykonywania orzeczeń oraz 
współpracy 
w zakresie 
zobowiązań 
alimentacyjnych 
(Dz. Urz. 
UE L 7 
z 10.01.2009, str. 1, z późn. zm.), zwanego dalej „rozporządzeniem nr 4/2009”, 
spełnia warunki określone w tym rozporządzeniu, sąd, który je wydał, wydaje na 
wniosek wyciąg z tego orzeczenia określony w rozporządzeniu na potrzeby uznania 
lub wykonania orzeczenia w innym państwie członkowskim Unii Europejskiej. 
**§ 2.** Jeżeli 
ugoda 
objęta 
zakresem 
zastosowania 
rozporządzenia 
nr 4/2009 spełnia warunki określone w tym rozporządzeniu, sąd, przed którym 
zawarto ugodę albo który ją zatwierdził, wydaje na wniosek wyciąg z ugody 
określony w rozporządzeniu na potrzeby wykonania ugody w innym państwie 
członkowskim Unii Europejskiej. 
**§ 3.** Jeżeli inny tytuł egzekucyjny niż określony w § 1 lub 2 objęty zakresem 
zastosowania rozporządzenia nr 4/2009 spełnia warunki określone w tym 
rozporządzeniu, sąd rejonowy, w którego okręgu sporządzono tytuł, wydaje na 
wniosek wyciąg z tego tytułu określony w rozporządzeniu na potrzeby wykonania 
tytułu w innym państwie członkowskim Unii Europejskiej. 
**§ 4.** Postanowienie może wydać także referendarz sądowy.

***
## Art. 79513. {#kpc-trzecia--art-79513}

Na postanowienie o odmowie wydania wyciągu wnioskodawcy 
przysługuje zażalenie. Odpisu zażalenia nie doręcza się przeciwnikowi. 
DZIAŁ IIf  
Zaświadczenia dotyczące orzeczeń obejmujących środki ochrony w sprawach 
cywilnych

***
## Art. 79514. {#kpc-trzecia--art-79514}

Jeżeli orzeczenie obejmujące środek ochrony wchodzący w zakres 
zastosowania rozporządzenia Parlamentu Europejskiego i Rady (UE) nr 606/2013 
z dnia 12 czerwca 2013 r. w sprawie wzajemnego uznawania środków ochrony 
w sprawach cywilnych (Dz. Urz. UE L 181 z 29.06.2013, str. 4), zwanego dalej 

 
 
 
s. 380/580 
 
2025-09-08 
 
„rozporządzeniem nr 606/2013”, spełnia warunki określone w tym rozporządzeniu, 
sąd, który wydał to orzeczenie, wydaje na wniosek osoby objętej ochroną określone 
w rozporządzeniu zaświadczenie na potrzeby uznania lub wykonania tego 
orzeczenia w innym państwie członkowskim Unii Europejskiej.

***
## Art. 79515. {#kpc-trzecia--art-79515}

Na 
postanowienie 
o odmowie 
wydania 
zaświadczenia 
wnioskodawcy przysługuje zażalenie. Odpisu zażalenia nie doręcza się 
przeciwnikowi.

***
## Art. 79516. {#kpc-trzecia--art-79516}

**§ 1.** W razie stwierdzenia, że istnieje określona w rozporządzeniu 
nr 606/2013 podstawa do uchylenia zaświadczenia, sąd, który je wydał, na wniosek 
strony albo z urzędu uchyla to zaświadczenie. 
**§ 2.** Wniosek składa się w terminie miesięcznym od dnia doręczenia 
postanowienia o wydaniu zaświadczenia. 
**§ 3.** Wniosek powinien odpowiadać warunkom pisma procesowego oraz 
wskazywać okoliczności uzasadniające uchylenie zaświadczenia. 
**§ 4.** Przed uchyleniem zaświadczenia sąd wysłuchuje osobę objętą ochroną, 
chyba że jest ona wnioskodawcą. 
**§ 5.** Na postanowienie w przedmiocie uchylenia zaświadczenia przysługuje 
zażalenie.

***
## Art. 79517. {#kpc-trzecia--art-79517}

**§ 1.** Przepis art. 79514 stosuje się odpowiednio do wydawania 
określonych w rozporządzeniu nr 606/2013 zaświadczeń potwierdzających 
zawieszenie, ograniczenie lub uchylenie środka ochrony. 
**§ 2.** Na postanowienie w przedmiocie wydania zaświadczenia, o którym 
mowa w § 1, przysługuje zażalenie. 
#### DZIAŁ III
Wszczęcie egzekucji i dalsze czynności egzekucyjne

***
## Art. 796. {#kpc-trzecia--art-796}

**§ 1.** Wniosek o wszczęcie egzekucji składa się stosownie do 
właściwości sądowi lub komornikowi. Wniosek składany komornikowi może być 
złożony na urzędowym formularzu. 
**§ 2.** W sprawach, które mogą być wszczęte z urzędu, egzekucja może być 
wszczęta z urzędu na żądanie sądu pierwszej instancji, który sprawę rozpoznawał, 
skierowane do właściwego sądu lub komornika. 

 
 
 
s. 381/580 
 
2025-09-08 
**§ 3.** Egzekucja może być również wszczęta na żądanie uprawnionego organu. 
**§ 4.** Minister Sprawiedliwości określi, w drodze rozporządzenia, wzór 
i sposób udostępniania urzędowego formularza wniosku o wszczęcie egzekucji, 
mając na względzie ustawowe wymagania przewidziane dla tego pisma, potrzebę 
zamieszczenia niezbędnych pouczeń co do sposobu wypełniania formularza, 
wnoszenia pisma i skutków niedostosowania go do ustawowych wymagań, a także 
konieczność bezpłatnego udostępniania formularzy w kancelariach komorniczych, 
siedzibach sądów oraz sieci Internet w formie pozwalającej na dogodną edycję 
treści formularza.

***
## Art. 797. {#kpc-trzecia--art-797}

**§ 1.** We 
wniosku 
o wszczęcie 
egzekucji 
lub 
żądaniu 
przeprowadzenia egzekucji z urzędu wskazuje się świadczenie, które ma być 
spełnione. Do wniosku lub żądania dołącza się tytuł wykonawczy.  
**§ 11.** Jeżeli z treści tytułu wykonawczego wynika, że termin przedawnienia 
dochodzonego roszczenia upłynął, do wniosku należy dołączyć również dokument, 
z którego wynika, że doszło do przerwania biegu przedawnienia. 
**§ 2.** Wniosek o wszczęcie egzekucji na podstawie tytułu wykonawczego, 
o którym mowa w art. 783 § 4, może być złożony do komornika także za 
pośrednictwem systemu teleinformatycznego. 
**§ 3.** Jeżeli podstawą egzekucji jest tytuł wykonawczy, o którym mowa 
w art. 783 § 4, do wniosku o wszczęcie egzekucji lub żądania przeprowadzenia 
egzekucji z urzędu dołącza się dokument uzyskany z systemu teleinformatycznego, 
umożliwiający organowi egzekucyjnemu weryfikację istnienia i treści tego tytułu, 
a w przypadku złożenia wniosku o wszczęcie egzekucji za pośrednictwem systemu 
teleinformatycznego wskazuje się tytuł wykonawczy. 
**§ 4.** Wszczynając egzekucję na podstawie tytułu wykonawczego, o którym 
mowa w art. 783 § 4, komornik jest zobowiązany do zweryfikowania treści 
przedstawionego mu dokumentu uzyskanego z systemu teleinformatycznego oraz 
zaznaczenia w tym systemie faktu prowadzenia egzekucji na podstawie tego tytułu. 
**§ 5.** Ilekroć w ustawie jest mowa o przedstawieniu (okazaniu, dołączeniu, 
doręczeniu albo złożeniu) tytułu wykonawczego, a tytułem tym jest tytuł 
wykonawczy, o którym mowa w art. 783 § 4, należy przedstawić zweryfikowany 
przez komornika dokument, o którym mowa w § 3. Jeżeli tytuł wykonawczy ma 
być złożony w postępowaniu prowadzonym przez sąd lub komornika wystarcza 

 
 
 
s. 382/580 
 
2025-09-08 
 
złożenie dokumentu uzyskanego z systemu teleinformatycznego. Przepis 
§ 4 stosuje się odpowiednio.

***
## Art. 7971. {#kpc-trzecia--art-7971}

(uchylony)

***
## Art. 798. {#kpc-trzecia--art-798}

Jeżeli dłużnikowi przysługuje wybór między świadczeniami, które 
ma spełnić, a wyboru jeszcze nie dokonał, komornik, wszczynając egzekucję celem 
spełnienia tych świadczeń, na wniosek wierzyciela wyznaczy dłużnikowi 
odpowiedni termin do dokonania wyboru. Po bezskutecznym upływie tego terminu 
wierzyciel wybierze świadczenie, które ma być spełnione.

***
## Art. 7981. {#kpc-trzecia--art-7981}

**§ 1.** Jeżeli tytuł wykonawczy obejmuje świadczenie pieniężne 
w walucie obcej, organ egzekucyjny przelicza zasądzoną kwotę na walutę polską 
według kursu średniego ogłaszanego przez Narodowy Bank Polski na dzień 
sporządzenia planu podziału, a jeżeli planu nie sporządzono – na dzień wypłaty 
kwoty wierzycielowi. 
**§ 2.** Przepisu § 1 nie stosuje się, jeżeli z tytułu wykonawczego wynika, że 
świadczenie pieniężne podlega spełnieniu wyłącznie w walucie obcej. W takim 
przypadku organ egzekucyjny nabywa tę walutę w banku. Wszczynając egzekucję, 
organ egzekucyjny wyznacza dłużnikowi tygodniowy termin do wskazania banku. 
Po bezskutecznym upływie wyznaczonego terminu organ egzekucyjny wzywa 
wierzyciela do wskazania banku w terminie tygodniowym. Jeżeli dłużnik albo 
wierzyciel nie wskażą banku, wskazanie banku należy do organu egzekucyjnego. 
Bankiem wskazanym przez wierzyciela albo organ egzekucyjny nie może być 
wierzyciel.

***
## Art. 799. {#kpc-trzecia--art-799}

**§ 1.** Wniosek o wszczęcie egzekucji lub żądanie przeprowadzenia 
egzekucji z urzędu umożliwia prowadzenie egzekucji według wszystkich 
dopuszczalnych sposobów, z wyjątkiem egzekucji z nieruchomości. Skierowanie 
egzekucji do nieruchomości dłużnika oraz składników jego majątku, do których 
przepisy o egzekucji z nieruchomości stosuje się odpowiednio, jest możliwe tylko 
na wniosek wierzyciela. Wierzyciel może wskazać wybrane przez siebie sposób 
albo sposoby egzekucji. Organ egzekucyjny stosuje sposób egzekucji najmniej 
uciążliwy dla dłużnika. 

 
 
 
s. 383/580 
 
2025-09-08 
**§ 2.** Jeżeli egzekucja z jednej części majątku dłużnika oczywiście wystarcza 
na zaspokojenie wierzyciela, dłużnik może żądać zawieszenia egzekucji 
z pozostałej części majątku.

***
## Art. 800. {#kpc-trzecia--art-800}

**§ 1.** Wniosków skierowanych do sądu nie można łączyć 
z wnioskami skierowanymi do komornika. Nie można również łączyć wniosków, 
które skierowane są do różnych sądów. 
**§ 2.** W razie niedopuszczalnego połączenia wniosków sąd lub komornik 
rozpoznaje wniosek w zakresie swej właściwości, w pozostałej zaś części wniosek 
przekaże właściwemu organowi egzekucyjnemu, jeżeli wierzyciel w wyznaczonym 
terminie przedstawi odpis wniosku.

***
## Art. 8001. {#kpc-trzecia--art-8001}

**§ 1.** Organ egzekucyjny odmawia wszczęcia egzekucji, jeżeli: 
- 1) zachodzą okoliczności, o których mowa w art. 199 § 1, albo 
- 2) przepis szczególny tak stanowi, albo 
- 3) wniosek o wszczęcie egzekucji z innych przyczyn jest niedopuszczalny. 
**§ 2.** W razie odmowy wszczęcia egzekucji organ egzekucyjny wstrzymuje się 
z dalszymi czynnościami, a wniosek o wszczęcie egzekucji nie wywołuje żadnych 
skutków, jakie ustawa wiąże z jego złożeniem.

***
## Art. 801. {#kpc-trzecia--art-801}

**§ 1.** Jeżeli 
wierzyciel 
albo 
sąd 
zarządzający 
z urzędu 
przeprowadzenie egzekucji albo uprawniony organ żądający przeprowadzenia 
egzekucji nie wskaże majątku pozwalającego na zaspokojenie świadczenia, 
komornik z urzędu: 
- 1) ustala majątek dłużnika w zakresie znanym mu z innych prowadzonych 
postępowań albo na podstawie publicznie dostępnych źródeł informacji, albo 
rejestrów, do których ma dostęp drogą elektroniczną; 
- 2) wzywa dłużnika do złożenia wykazu majątku. 
**§ 2.** Jeżeli zachodzą wątpliwości, czy wniosek o podjęcie określonych 
czynności egzekucyjnych lub żądanie złożenia wyjaśnień lub udzielenia informacji 
w trybie art. 761 są niezbędne do zapewnienia prawidłowego toku egzekucji, lub 
zachodzą uzasadnione podstawy do przyjęcia, że zostały złożone wyłącznie w celu 
szykanowania dłużnika, komornik może zobowiązać wierzyciela do uzasadnienia 
wniosku pod rygorem obciążenia wierzyciela kosztem bezskutecznych czynności 
podjętych na jego skutek – niezależnie od wyniku sprawy. 

 
 
 
s. 384/580 
 
2025-09-08 
**§ 3.** Komornik oddali wniosek, o którym mowa w § 2, jeżeli w świetle 
okoliczności sprawy lub innych prowadzonych przeciwko temu samemu 
dłużnikowi postępowań egzekucyjnych jest wysoce prawdopodobne, że wniosek 
nie przyczyni się do zapewnienia prawidłowego toku egzekucji lub zachodzą 
uzasadnione podstawy do przyjęcia, że został on złożony wyłącznie w celu 
szykanowania dłużnika. 
**§ 4.** Jeżeli pomimo skierowania egzekucji do oznaczonych przez wierzyciela 
składników majątku dłużnika lub podjęcia czynności przewidzianych w § 1 pkt 1 
oraz odebrania od dłużnika wykazu majątku nie zdołano ustalić majątku dłużnika 
pozwalającego nawet na zaspokojenie kosztów egzekucyjnych, komornik może 
wysłuchać wierzyciela w sposób przewidziany w art. 827 § 1. W takim przypadku 
warunkiem żądania przez wierzyciela dalszego prowadzenia egzekucji jest zlecenie 
komornikowi poszukiwania majątku dłużnika.

***
## Art. 8011. {#kpc-trzecia--art-8011}

**§ 1.** Dłużnik składa komornikowi, na piśmie lub ustnie do 
protokołu, wykaz majątku wraz z oświadczeniem o jego prawdziwości i zupełności 
pod rygorem odpowiedzialności karnej za złożenie fałszywego oświadczenia. 
Wzywając dłużnika do złożenia wykazu majątku, komornik uprzedza go 
o odpowiedzialności karnej za złożenie fałszywego oświadczenia oraz poucza, że 
w razie niezłożenia wykazu majątku wierzyciel może zlecić komornikowi 
poszukiwanie majątku dłużnika. 
**§ 2.** Jeżeli dłużnik bez usprawiedliwionej przyczyny nie złoży wykazu 
majątku wraz z oświadczeniem o jego prawdziwości i zupełności albo nie udzieli 
odpowiedzi na zadane mu pytanie, komornik może ukarać go grzywną. 
**§ 3.** Jeżeli dłużnik mimo ukarania go grzywną nie złożył wykazu majątku 
wraz z oświadczeniem o jego prawdziwości i zupełności, komornik właściwości 
ogólnej dłużnika na wniosek wierzyciela zwróci się do sądu o nakazanie 
przymusowego doprowadzenia dłużnika celem złożenia wykazu majątku wraz 
z oświadczeniem o jego prawdziwości i zupełności. 
**§ 4.** Jeżeli postępowanie egzekucyjne prowadzone jest przez komornika 
niebędącego komornikiem właściwości ogólnej dłużnika, złożenie przez 
wierzyciela wniosku, o którym mowa w § 3, uważa się za żądanie przekazania 
sprawy komornikowi właściwości ogólnej. Wierzyciel może we wniosku wskazać 
komornika, któremu ma zostać przekazana sprawa. W przypadku braku wskazania 

 
 
 
s. 385/580 
 
2025-09-08 
 
przez wierzyciela komornika właściwego, komornik przekaże sprawę według 
własnego wyboru. 
**§ 5.** Przepisy art. 916 § 3 oraz art. 919 stosuje się odpowiednio.

***
## Art. 8012. {#kpc-trzecia--art-8012}

Wierzyciel może zlecić komornikowi poszukiwanie majątku 
dłużnika, jeżeli w drodze czynności przewidzianych w art. 801 § 1 pkt 1 nie 
zdołano ustalić majątku pozwalającego na zaspokojenie dochodzonego 
świadczenia. Poszukiwaniem majątku nie jest realizacja wniosków wierzyciela 
o zwrócenie się z żądaniem udzielenia informacji do podmiotów wymienionych 
w art. 761 § 11 pkt 1–6.

***
## Art. 802. {#kpc-trzecia--art-802}

Jeżeli miejsce pobytu dłużnika nie jest znane, sąd ustanowi dla 
niego kuratora z urzędu, gdy egzekucja ma być wszczęta z urzędu, w innych zaś 
sprawach – na wniosek wierzyciela.

***
## Art. 803. {#kpc-trzecia--art-803}

Tytuł wykonawczy stanowi podstawę do prowadzenia egzekucji 
o całe objęte nim roszczenie i ze wszystkich części majątku dłużnika, chyba że 
z treści tytułu wynika co innego.

***
## Art. 804. {#kpc-trzecia--art-804}

**§ 1.** Organ egzekucyjny nie jest uprawniony do badania zasadności 
i wymagalności obowiązku objętego tytułem wykonawczym. 
**§ 2.** Jeżeli z treści tytułu wykonawczego wynika, że termin przedawnienia 
dochodzonego roszczenia upłynął, a wierzyciel nie przedłożył dokumentu, 
o którym mowa w art. 797 § 11, organ egzekucyjny odmawia wszczęcia egzekucji 
bez wzywania wierzyciela do uzupełnienia braków wniosku. Nie dotyczy to 
przedawnienia odsetek wymagalnych po powstaniu tytułu wykonawczego. Na 
postanowienie sądu przysługuje zażalenie.

***
## Art. 8041. {#kpc-trzecia--art-8041}

W razie przejścia egzekwowanego uprawnienia na inną osobę po 
wszczęciu postępowania egzekucyjnego osoba ta może wstąpić do postępowania 
na miejsce wierzyciela za jego zgodą, o ile przejście będzie wykazane dokumentem 
urzędowym lub dokumentem prywatnym z podpisem urzędowo poświadczonym.

***
## Art. 8042. {#kpc-trzecia--art-8042}

**§ 1.** Jeżeli po powstaniu tytułu wykonawczego uprawnienie 
przeszło na inną osobę, osoba ta może wszcząć egzekucję przeciwko dłużnikowi na 
podstawie tego tytułu, jeżeli wykaże przejście uprawnienia dokumentem 
urzędowym lub prywatnym z podpisem urzędowo poświadczonym. 

 
 
 
s. 386/580 
 
2025-09-08 
**§ 2.** W przypadku niezłożenia przez wnioskodawcę dokumentów, o których 
mowa w § 1, organ egzekucyjny odmawia wszczęcia egzekucji bez wzywania 
wnioskodawcy do uzupełnienia braków wniosku. 
**§ 3.** W przypadku, o którym mowa w § 2, odpis postanowienia doręcza się 
tylko wnioskodawcy. Na postanowienie sądu przysługuje zażalenie.

***
## Art. 8043. {#kpc-trzecia--art-8043}

Przepisy art. 8041 oraz art. 8042 § 1 nie mają zastosowania, jeżeli 
z przedłożonych dokumentów wynika, że przeniesienie uprawnienia: 
- 1) ma charakter warunkowy, chyba że chodzi o warunek zawieszający, który 
spełnił się przed złożeniem wniosku o wszczęcie egzekucji albo wstąpieniem 
do postępowania, a wierzyciel lub osoba wstępująca do postępowania na 
miejsce wierzyciela przedłożyli dokument potwierdzający spełnienie 
warunku, albo 
- 2) nastąpiło na rzecz podmiotu mającego miejsce zamieszkania lub siedzibę poza 
granicami Rzeczypospolitej Polskiej.

***
## Art. 805. {#kpc-trzecia--art-805}

**§ 1.** Przy pierwszej czynności egzekucyjnej doręcza się dłużnikowi 
zawiadomienie o wszczęciu egzekucji, z podaniem treści tytułu wykonawczego 
i wymienieniem sposobu egzekucji oraz z pouczeniem o możliwości, terminie 
i sposobie wniesienia środka zaskarżenia na postanowienie o nadaniu klauzuli 
wykonalności, a także sporządzony przez organ egzekucyjny odpis tytułu 
wykonawczego albo zweryfikowanego przez komornika dokumentu, o którym 
mowa w art. 797 § 3. Komornik poucza dłużnika również o treści przepisów działu 
V tytułu I części trzeciej oraz prawie i sposobie złożenia wniosku o ograniczenie 
egzekucji, a także o treści art. 52a i art. 54 ustawy z dnia 29 sierpnia 1997 r. – 
Prawo bankowe (Dz. U. z 2023 r. poz. 2488 oraz z 2024 r. poz. 879) oraz art. 13g 
ustawy z dnia 5 listopada 2009 r. o spółdzielczych kasach oszczędnościowo-
-kredytowych (Dz. U. z 2024 r. poz. 512 i 879) i sposobie realizacji uprawnień 
wynikających z tych przepisów. 
**§ 11.** Jeżeli podstawę egzekucji stanowi tytuł wykonawczy w postaci 
zaopatrzonego w klauzulę wykonalności wyroku zaocznego lub nakazu zapłaty 
wydanego w postępowaniu nakazowym, upominawczym albo elektronicznym 
postępowaniu upominawczym, komornik poucza dłużnika również o treści 
art. 139 § 1 i 5, art. 168, art. 172, art. 8203 § 1 i 2 i art. 824 § 1 pkt 5, a także 

 
 
 
s. 387/580 
 
2025-09-08 
 
stosownie do orzeczenia stanowiącego tytuł egzekucyjny o treści art. 344, art. 346, 
art. 4803, art. 492 § 3, art. 493 i art. 505 albo art. 50535. 
**§ 12.** Pouczeń, o których mowa w § 1 zdanie drugie oraz w § 11, dokonuje się 
przez wskazanie stronie adresu strony internetowej Krajowej Rady Komorniczej, 
na której jest przytoczona treść wymienionych przepisów oraz zawarte pouczenie 
o prawie i sposobie złożenia wniosku o ograniczenie egzekucji. Na żądanie 
dłużnika komornik przesyła pouczenia w postaci papierowej. 
**§ 2.** Na żądanie dłużnika komornik powinien okazać mu tytuł wykonawczy 
w oryginale. 
**§ 3.** W przypadku 
prowadzenia 
egzekucji 
na 
podstawie 
tytułu 
wykonawczego, o którym mowa w art. 783 § 4, obowiązek okazania oryginału 
tytułu wykonawczego, o którym mowa w § 2, polega na okazaniu dłużnikowi 
zweryfikowanego przez komornika dokumentu, o którym mowa w art. 797 § 3.

***
## Art. 8051. {#kpc-trzecia--art-8051}

**§ 1.** Jeżeli w toku egzekucji zostanie ujawnione, że na zajętym 
przedmiocie, wierzytelności lub prawie ustanowiony został zastaw rejestrowy, 
komornik zawiadomi niezwłocznie o zajęciu zastawnika zastawu rejestrowego. 
**§ 2.** Prowadząc egzekucję o świadczenie przekraczające dwadzieścia tysięcy 
złotych, komornik obowiązany jest uzyskać z centralnej informacji o zastawach 
rejestrowych dane o tym, czy dłużnik jest zastawcą zastawu rejestrowego oraz kto 
jest zastawnikiem. O wszczęciu egzekucji komornik niezwłocznie zawiadamia 
zastawnika zastawu rejestrowego. 
**§ 3.** Jeżeli skierowano egzekucję do pojazdu mechanicznego, a dłużnik nie 
wydał dowodu rejestracyjnego zajętego pojazdu, komornik jest obowiązany 
uzyskać informację w centralnej informacji o zastawach rejestrowych, czy zajęty 
pojazd nie jest obciążony zastawem rejestrowym. W razie stwierdzenia, że zajęty 
pojazd 
mechaniczny 
jest 
obciążony 
zastawem 
rejestrowym, 
komornik 
niezwłocznie zawiadomi zastawnika zastawu rejestrowego o wszczęciu egzekucji. 
**§ 4.** Sprzedaż ruchomości, wierzytelności i praw obciążonych zastawem 
rejestrowym może nastąpić nie wcześniej niż po upływie tygodnia od dnia 
zawiadomienia zastawnika.

***
## Art. 806. {#kpc-trzecia--art-806}

Komornik powinien na żądanie wierzyciela przyjąć od niego 
pieniądze lub inne rzeczy przypadające dłużnikowi w związku z egzekucją. 

 
 
 
s. 388/580 
 
2025-09-08

***
## Art. 807. {#kpc-trzecia--art-807}

**§ 1.** Zabezpieczenie 
w wypadkach 
w części 
niniejszej 
przewidzianych powinno być złożone w gotówce do rąk komornika lub wpłacone 
na rachunek depozytowy Ministra Finansów albo złożone w książeczkach 
oszczędnościowych lub w papierach wartościowych. O wydaniu zabezpieczenia 
sąd rozstrzyga po wysłuchaniu osób zainteresowanych. Na postanowienie sądu 
przysługuje zażalenie. 
**§ 2.** Minister Sprawiedliwości w porozumieniu z ministrem właściwym do 
spraw finansów publicznych określi, w drodze rozporządzenia, sposób składania 
zabezpieczenia w papierach wartościowych, biorąc pod uwagę bezpieczeństwo 
papierów wartościowych i sprawność postępowania egzekucyjnego.

***
## Art. 808. {#kpc-trzecia--art-808}

**§ 1.** Jeżeli złożona w postępowaniu egzekucyjnym kwota pieniężna 
nie podlega natychmiastowemu wydaniu, powinna być złożona na rachunek 
depozytowy Ministra Finansów. 
**§ 2.** Odsetki od sum złożonych na rachunek depozytowy Ministra Finansów 
tytułem nabycia przedmiotu egzekucji wchodzą w skład sumy uzyskanej 
w egzekucji. Odsetki należne za okres od dnia sporządzenia planu podziału sumy 
uzyskanej w egzekucji do dnia wykonania planu zwraca się osobie uprawnionej.

***
## Art. 809. {#kpc-trzecia--art-809}

Komornik stwierdza każdą czynność egzekucyjną protokołem, 
który powinien zawierać: 
- 1) oznaczenie miejsca i czasu czynności; 
- 2) imiona i nazwiska stron oraz innych osób uczestniczących w czynności; 
- 3) sprawozdanie z przebiegu czynności; 
- 4) wnioski i oświadczenia obecnych; 
- 5) wzmiankę o odczytaniu protokołu; 
- 6) podpisy obecnych lub wzmiankę o przyczynie braku podpisu; 
- 7) podpis komornika.

***
## Art. 8091. {#kpc-trzecia--art-8091}

**§ 1.** Utrwalaniu za pomocą urządzenia rejestrującego obraz 
i dźwięk podlega przebieg następujących czynności egzekucyjnych dokonywanych 
przez komornika poza kancelarią: 
- 1) z udziałem dłużnika zmierzające do ustalenia jego stanu majątkowego; 
- 2) zajęcie ruchomości; 

 
 
 
s. 389/580 
 
2025-09-08 
- 3) wykonanie postanowienia o oddaniu ruchomości pod dozór innej osobie niż 
dłużnik; 
- 4) licytacja ruchomości z wyłączeniem licytacji elektronicznej; 
- 5) licytacja nieruchomości, chyba że jej przebieg jest utrwalany w sposób 
określony w art. 972 § 2; 
- 6) oględziny nieruchomości; 
- 7) wprowadzenie w zarząd nieruchomości w trybie art. 933; 
- 8) opróżnienie pomieszczeń z osób lub rzeczy; 
- 9) wydanie ruchomości i nieruchomości; 
- 10) wprowadzenie w posiadanie; 
- 11) przymusowe otwarcie pomieszczenia; 
- 12) przeszukanie mieszkania lub pomieszczenia gospodarczego dłużnika. 
**§ 2.** Komornik utrwala przebieg czynności w trybie określonym w § 1, 
również gdy wniosek taki złoży co najmniej jedna ze stron postępowania. 
**§ 3.** Komornik uprzedza osoby uczestniczące w czynności o utrwalaniu 
przebiegu czynności, o których mowa w § 1 i 2. Komornik przerywa utrwalanie 
przebiegu czynności w miejscu zamieszkania dłużnika lub osoby trzeciej, jeżeli 
dłużnik lub ta osoba sprzeciwiają się temu, o czym należy te osoby pouczyć. Na 
żądanie osoby, która sprzeciwiła się utrwalaniu czynności, komornik podejmuje 
utrwalanie czynności na nowo, o czym należy te osoby pouczyć. 
**§ 4.** W przypadku utrwalania za pomocą urządzenia rejestrującego obraz 
i dźwięk przebiegu czynności, w protokole zamieszcza się poza elementami 
wymienionymi w art. 809 pkt 1, 2 i 4–7 jedynie zwięzłe sprawozdanie z przebiegu 
czynności. Powyższe nie zwalnia z obowiązku sporządzenia pełnego protokołu 
zajęcia. 
**§ 5.** Komornik umożliwia stronom i uczestnikom postępowania zapoznanie 
się z zapisem obrazu i dźwięku w siedzibie kancelarii komorniczej. Stronom ani 
uczestnikom postępowania nie wydaje się zapisu obrazu i dźwięku. 
**§ 6.** Minister Sprawiedliwości określi, w drodze rozporządzenia, rodzaje 
urządzeń i środków technicznych służących do utrwalania obrazu i dźwięku, 
sposób przechowywania, odtwarzania i kopiowania zapisów oraz sposób 
zapoznania się z zapisem obrazu i dźwięku, mając na uwadze konieczność 
właściwego zabezpieczenia utrwalonego obrazu i dźwięku przed utratą, 

 
 
 
s. 390/580 
 
2025-09-08 
 
zniekształceniem lub nieuprawnionym ujawnieniem oraz zapewnienie ochrony 
praw osób uczestniczących w postępowaniu oraz osób trzecich, których wizerunek 
został utrwalony.

***
## Art. 810. {#kpc-trzecia--art-810}

**§ 1.** Komornik może wykonywać czynności poza kancelarią 
komorniczą w dni robocze, w godzinach od siódmej do dwudziestej pierwszej. Na 
wykonanie czynności w dni ustawowo wolne od pracy lub godzinach nocnych jest 
wymagana zgoda prezesa właściwego sądu rejonowego. 
**§ 2.** Czynności komornika rozpoczęte przed godziną dwudziestą pierwszą 
mogą być prowadzone w dalszym ciągu bez zgody, o której mowa w § 1, jeżeli ich 
przerwanie może znacznie utrudnić egzekucję. Przepisu zdania pierwszego nie 
stosuje się do czynności prowadzonych w miejscu zamieszkania dłużnika, chyba że 
jest to również miejsce prowadzenia przez niego działalności gospodarczej.

***
## Art. 811. {#kpc-trzecia--art-811}

**§ 1.** W obrębie budynków wojskowych i zajmowanych przez 
Policję, Straż Graniczną, Służbę Ochrony Państwa, Agencję Bezpieczeństwa 
Wewnętrznego, Agencję Wywiadu, Służbę Kontrwywiadu Wojskowego, Służbę 
Wywiadu Wojskowego, Centralne Biuro Antykorupcyjne lub Straż Marszałkowską 
oraz na okrętach wojennych można dokonywać czynności egzekucyjnych tylko po 
uprzednim zawiadomieniu odpowiednio właściwego komendanta lub kierownika 
jednostki i w asyście wyznaczonego organu wojskowego, organu Policji lub 
przedstawiciela Agencji Bezpieczeństwa Wewnętrznego, Agencji Wywiadu, 
Służby Kontrwywiadu Wojskowego, Służby Wywiadu Wojskowego, Służby 
Ochrony 
Państwa, 
Centralnego 
Biura 
Antykorupcyjnego 
lub 
Straży 
Marszałkowskiej. 
**§ 2.** Sposób asystowania przy wykonywaniu czynności egzekucyjnych, 
uwzględniając w szczególności przypadki i miejsca, w których wymagana jest 
asysta organów, sposób postępowania przy wykonywaniu asysty, tryb 
powiadamiania 
właściwych 
organów, 
wymagane 
dokumenty, 
sposób 
dokumentowania wykonywanych czynności i rozliczania ich kosztów określa, 
w drodze rozporządzenia: 
- 1) Minister Obrony Narodowej w porozumieniu z Ministrem Sprawiedliwości – 
w przypadku wykonywania asysty przez Służbę Kontrwywiadu Wojskowego, 

 
 
 
s. 391/580 
 
2025-09-08 
 
Służbę Wywiadu Wojskowego, Żandarmerię Wojskową lub wojskowe 
organy porządkowe; 
- 2) minister właściwy do spraw wewnętrznych w porozumieniu z Ministrem 
Sprawiedliwości – w przypadku wykonywania asysty przez Policję, Straż 
Graniczną lub Służbę Ochrony Państwa; 
- 3) Prezes Rady Ministrów w przypadku wykonywania asysty przez Agencję 
Bezpieczeństwa Wewnętrznego, Agencję Wywiadu, Centralne Biuro 
Antykorupcyjne lub Straż Marszałkowską. 
**§ 3.** Do wydania rozporządzenia, o którym mowa w § 2, stosuje się 
art. 765 § 3.

***
## Art. 812. {#kpc-trzecia--art-812}

**§ 1.** Wierzyciel i dłużnik mogą być obecni przy czynnościach 
egzekucyjnych. Na żądanie stron albo według uznania komornika mogą być obecni 
także świadkowie, chyba że zachodzi obawa, że wskutek straty czasu na 
przywołanie świadków egzekucja będzie udaremniona. Świadków przywołuje się 
w liczbie nie większej niż po dwóch z każdej strony. 
**§ 2.** Komornik powinien przywołać jednego lub dwóch świadków, jeżeli 
dłużnik nie jest obecny lub komornik go wydalił, chyba że zachodzi obawa, iż 
wskutek straty czasu na przywołanie świadków egzekucja będzie udaremniona. 
**§ 3.** Świadkami mogą być także członkowie rodziny i domownicy dłużnika. 
**§ 4.** Świadkowie nie otrzymują wynagrodzenia.

***
## Art. 813. {#kpc-trzecia--art-813}

**§ 1.** W wypadkach wymagających zasięgnięcia opinii biegłego, 
komornik zwróci się o wydanie opinii do jednego lub kilku stałych biegłych 
sądowych. Jeżeli wśród stałych biegłych sądowych nie ma biegłego wymaganej 
specjalności, komornik zwróci się do sądu o wyznaczenie biegłego i odebranie od 
niego przyrzeczenia. 
**§ 2.** Przepis § 1 stosuje się odpowiednio, gdy wezwany przez komornika stały 
biegły sądowy został wyłączony lub nie przyjął nałożonego na niego obowiązku 
z przyczyn wskazanych w art. 280 § 1, a nie ma innego biegłego tej specjalności 
wśród stałych biegłych sądowych.

***
## Art. 814. {#kpc-trzecia--art-814}

**§ 1.** Jeżeli cel egzekucji tego wymaga, komornik zarządzi 
otworzenie mieszkania oraz innych pomieszczeń i schowków dłużnika, jak również 
przeszuka jego rzeczy, mieszkanie i schowki. Gdyby to nie wystarczyło, komornik 

 
 
 
s. 392/580 
 
2025-09-08 
 
może ponadto przeszukać odzież, którą dłużnik ma na sobie. Komornik może to 
uczynić także wówczas, gdy dłużnik chce się wydalić lub gdy zachodzi podejrzenie, 
że chce usunąć od egzekucji przedmioty, które ma przy sobie. 
**§ 2.** Jeżeli w czasie dokonywania czynności egzekucyjnych w mieszkaniu 
dłużnika komornik zauważy, że dłużnik oddał poszukiwane przedmioty swemu 
domownikowi lub innej osobie do ukrycia, komornik może przeszukać odzież tej 
osoby oraz przedmioty, jakie ma ona przy sobie. 
**§ 3.** Przeszukanie odzieży na osobie dłużnika oraz przedmiotów, które dłużnik 
ma przy sobie, poza miejscem zamieszkania, przedsiębiorstwem, zakładem oraz 
gospodarstwem dłużnika może nastąpić na podstawie pisemnego zezwolenia właś-
ciwego prezesa sądu rejonowego. W wypadkach niecierpiących zwłoki 
przeszukanie może być dokonane bez zezwolenia, jednakże czynność taka musi 
być niezwłocznie po dokonaniu przedstawiona do zatwierdzenia prezesowi sądu 
rejonowego. 
**§ 4.** Przeszukanie odzieży może być dokonane tylko przez osobę tej samej 
płci, co dłużnik. Przeszukania odzieży na żołnierzu w czynnej służbie wojskowej, 
z wyjątkiem terytorialnej służby wojskowej pełnionej dyspozycyjnie, albo 
funkcjonariuszu Policji, Służby Ochrony Państwa, Agencji Bezpieczeństwa 
Wewnętrznego, Agencji Wywiadu, Służby Kontrwywiadu Wojskowego, Służby 
Wywiadu 
Wojskowego, 
Centralnego 
Biura 
Antykorupcyjnego, 
Straży 
Marszałkowskiej lub Straży Granicznej przeprowadza w obecności komornika 
odpowiednio żołnierz Żandarmerii Wojskowej lub wojskowego organu 
porządkowego albo osoba wyznaczona przez przełożonego funkcjonariusza.

***
## Art. 815. {#kpc-trzecia--art-815}

**§ 1.** Jeżeli ustawa nie stanowi inaczej, wszelkich wpłat 
komornikowi można dokonać gotówką lub poleceniem przelewu na rachunek 
komornika, a za zgodą komornika także w inny sposób. 
**§ 2.** Pokwitowanie komornika ma taki sam skutek jak pokwitowanie 
wierzyciela sporządzone w formie dokumentu urzędowego.

***
## Art. 816. {#kpc-trzecia--art-816}

**§ 1.** Po ukończeniu postępowania egzekucyjnego należy na tytule 
wykonawczym zaznaczyć wynik egzekucji i tytuł zatrzymać w aktach, a jeżeli 
świadczenie objęte tytułem nie zostało zaspokojone całkowicie, tytuł zwrócić 
wierzycielowi. 

 
 
 
s. 393/580 
 
2025-09-08 
**§ 2.** Jeżeli egzekucja była prowadzona na podstawie tytułu wykonawczego, 
o którym mowa w art. 783 § 4, wynik egzekucji odnotowuje się w systemie 
teleinformatycznym. 
**§ 3.** Ukończenie postępowania egzekucyjnego w inny sposób niż przez 
umorzenie komornik stwierdza postanowieniem, rozstrzygając o kosztach.

***
## Art. 8161. {#kpc-trzecia--art-8161}

Dane w postaci elektronicznej wytworzone w wyniku czynności 
komornika 
wymienionych 
w art. 797 § 4 
i art. 816 § 2 opatrywane 
są 
kwalifikowanym podpisem elektronicznym.

***
## Art. 817. {#kpc-trzecia--art-817}

W sprawach o naruszenie posiadania ukończona egzekucja może 
być podjęta na nowo na podstawie tego samego tytułu wykonawczego, jeżeli 
dłużnik ponownie dokonał zmiany sprzecznej z treścią tego tytułu, a żądanie w tym 
przedmiocie zostanie zgłoszone przed upływem sześciu miesięcy od ukończenia 
egzekucji. 
#### DZIAŁ IV
Zawieszenie i umorzenie postępowania

***
## Art. 818. {#kpc-trzecia--art-818}

**§ 1.** Organ egzekucyjny zawiesza postępowanie z urzędu jeżeli się 
okaże, że wierzyciel lub dłużnik nie ma zdolności procesowej ani przedstawiciela 
ustawowego. Na wniosek wierzyciela, a w wypadku gdy egzekucja została 
wszczęta z urzędu bez takiego wniosku, sąd ustanowi dla dłużnika niemającego 
zdolności procesowej kuratora na czas do ustanowienia przedstawiciela 
ustawowego. 
**§ 2.** Przedstawiciel ustawowy wierzyciela lub dłużnika, jako też kurator 
dłużnika, mogą zaskarżyć postanowienia sądu oraz czynności komornika dokonane 
w czasie, kiedy strona nie miała należytej reprezentacji. Termin zaskarżenia biegnie 
od daty, w której przedstawiciel ustawowy lub kurator otrzymał zawiadomienie 
o toczącym się postępowaniu, a jeżeli wcześniej zgłosił swoje uczestnictwo 
w postępowaniu – od daty tego zgłoszenia. Powtórzenia czynności już dokonanych 
można żądać tylko wtedy, gdy przy wykonywaniu czynności nastąpiło naruszenie 
praw strony, która nie posiadając zdolności procesowej nie miała przedstawiciela 
ustawowego. 

 
 
 
s. 394/580 
 
2025-09-08

***
## Art. 8181. {#kpc-trzecia--art-8181}

**§ 1.** Braki w składzie organów jednostki organizacyjnej będącej 
dłużnikiem nie stanowią podstawy do zawieszenia postępowania egzekucyjnego. 
**§ 2.** Informację o brakach uniemożliwiających działanie dłużnika komornik 
przekazuje wraz z aktami sprawy sądowi, który z urzędu ustanowi kuratora, jeżeli 
jest to konieczne dla ochrony interesów dłużnika, a majątek dłużnika wystarcza na 
pokrycie kosztów z tym związanych. W razie potrzeby komornik wstrzymuje się 
z czynnościami do momentu wydania postanowienia w przedmiocie ustanowienia 
kuratora. 
**§ 3.** Doręczenie pisma kuratorowi dokonane w ciągu dwóch tygodni od dnia 
otrzymania przez komornika informacji o uzupełnieniu braków w składzie 
organów jednostki organizacyjnej będącej dłużnikiem jest skuteczne wobec 
dłużnika. 
**§ 4.** W razie wystąpienia potrzeby ponownego ustanowienia kuratora w tej 
samej sprawie z przyczyn, o których mowa w § 1, sąd w miarę możliwości 
wyznaczy na kuratora tę samą osobę co poprzednio. Nie stoi to na przeszkodzie 
ponownemu przyznaniu wynagrodzenia kuratorowi. 
**§ 5.** Koszty ustanowienia kuratora obciążają dłużnika i zwraca się je sądowi 
po 
ich 
wyegzekwowaniu, 
z pierwszeństwem 
przed 
wszystkimi 
innymi 
należnościami.

***
## Art. 819. {#kpc-trzecia--art-819}

**§ 1.** Organ egzekucyjny zawiesza postępowanie z urzędu również 
w razie śmierci wierzyciela lub dłużnika. Postępowanie podejmuje się z udziałem 
spadkobierców zmarłego albo – w zakresie w jakim dotyczy ono praw i 
obowiązków wynikających z działalności gospodarczej – zarządcy sukcesyjnego, 
jeżeli został ustanowiony zarząd sukcesyjny. 
**§ 2.** Jeżeli spadkobiercy dłużnika nie objęli spadku albo nie są znani, a nie ma 
kuratora spadku, sąd na wniosek wierzyciela ustanowi dla nich kuratora, chyba że 
egzekucja dotyczy roszczeń wynikających z działalności gospodarczej, a został 
ustanowiony zarząd sukcesyjny.

***
## Art. 8191. {#kpc-trzecia--art-8191}

**§ 1.** Zbycie przedsiębiorstwa lub gospodarstwa rolnego po 
wszczęciu postępowania egzekucyjnego nie ma wpływu na bieg tego 
postępowania. 

 
 
 
s. 395/580 
 
2025-09-08 
**§ 2.** Przepis 
§ 1 stosuje 
się 
odpowiednio 
w razie 
przekształcenia 
organizacyjnego dłużnika będącego osobą prawną, a także spółką handlową 
niemającą osobowości prawnej, jak również przekształcenia spółki cywilnej 
w spółkę handlową.

***
## Art. 820. {#kpc-trzecia--art-820}

**§ 1.** Organ egzekucyjny zawiesza postępowanie na wniosek 
wierzyciela, chyba że wniosek ten zmierza jedynie do przedłużenia postępowania. 
Zawieszenie postępowania nie stoi na przeszkodzie jego umorzeniu, jeżeli w tym 
czasie ujawnią się okoliczności, o których mowa w art. 824 § 1. 
**§ 2.** Na wniosek dłużnika postępowanie ulega zawieszeniu, jeżeli sąd zawiesił 
natychmiastową wykonalność tytułu lub wstrzymał jego wykonanie albo dłużnik 
złożył zabezpieczenie konieczne według orzeczenia sądowego do zwolnienia go od 
egzekucji.

***
## Art. 8201. {#kpc-trzecia--art-8201}

(uchylony)

***
## Art. 8202. {#kpc-trzecia--art-8202}

**§ 1.** W przypadku egzekucji prowadzonej na podstawie tytułu 
wykonawczego w postaci zaopatrzonego w klauzulę wykonalności orzeczenia sądu 
wydanego w europejskim postępowaniu w sprawie drobnych roszczeń, sąd może 
na wniosek dłużnika zawiesić postępowanie egzekucyjne także wówczas, gdy 
możliwość taka wynika z przepisów rozporządzenia nr 861/2007. 
**§ 2.** Sąd może również, na wniosek dłużnika, ograniczyć egzekucję do 
środków zabezpieczających lub uzależnić wykonanie tytułu od złożenia przez 
wierzyciela stosownego zabezpieczenia, jeżeli taką możliwość przewidują przepisy 
rozporządzenia nr 861/2007. Orzekając o ograniczeniu egzekucji do środków 
zabezpieczających, sąd określa sposób zabezpieczenia, stosując odpowiednio 
przepisy o sposobach zabezpieczenia roszczeń w postępowaniu zabezpieczającym. 
Na postanowienie sądu przysługuje zażalenie.

***
## Art. 8203. {#kpc-trzecia--art-8203}

**§ 1.** Komornik zawiesza na wniosek dłużnika postępowanie 
prowadzone na podstawie tytułu wykonawczego w postaci zaopatrzonego 
w klauzulę wykonalności wyroku zaocznego, nakazu zapłaty wydanego 
w postępowaniu nakazowym, upominawczym albo elektronicznym postępowaniu 
upominawczym, jeżeli dłużnik przedstawi zaświadczenie określone w art. 139 § 5, 
z którego wynika, że wyrok zaoczny lub nakaz zapłaty został doręczony na inny 
adres 
aniżeli 
miejsce 
zamieszkania 
dłużnika 
ustalone 
w postępowaniu 

 
 
 
s. 396/580 
 
2025-09-08 
 
egzekucyjnym. Dłużnik nie ma obowiązku przedstawienia zaświadczenia, 
określonego w art. 139 § 5, jeżeli okoliczności, które mają być nim stwierdzone 
wynikają z dokumentu, o którym mowa w art. 797 § 3. 
**§ 2.** Komornik podejmie na wniosek wierzyciela postępowanie zawieszone na 
podstawie § 1, jeżeli sąd lub referendarz sądowy, przed którym sprawa się toczyła 
albo się toczy, stwierdzi, że doręczenie wyroku zaocznego lub nakazu zapłaty było 
prawidłowe albo – w przypadku ponownego doręczenia – że upłynął termin do 
wniesienia środka zaskarżenia, chyba że zachodzi inna podstawa zawieszenia 
postępowania albo postępowanie podlega umorzeniu. W tym celu sąd albo 
referendarz sądowy postanowi wydać na wniosek wierzyciela odpowiednie 
zaświadczenie. 
**§ 3.** Zawieszenie postępowania egzekucyjnego w przypadku, o którym mowa 
w § 1, nie wyłącza możliwości podejmowania przez komornika czynności 
mających na celu wykonanie w przyszłości tytułu wykonawczego, nie wyłączając 
zajęcia majątku dłużnika.

***
## Art. 821. {#kpc-trzecia--art-821}

**§ 1.** Sąd może na wniosek zawiesić w całości lub części 
postępowanie egzekucyjne, jeżeli złożono skargę na czynności komornika lub 
zażalenie na postanowienie sądu. Zawieszenie postępowania sąd może uzależnić 
od złożenia przez dłużnika zabezpieczenia. 
**§ 2.** Jeżeli dłużnik zabezpieczy spełnienie swego obowiązku, sąd może 
uchylić dokonane czynności egzekucyjne, z wyjątkiem zajęcia. 
**§ 3.** Sąd może odmówić zawieszenia postępowania albo już zawieszone 
postępowanie podjąć na nowo, jeżeli wierzyciel zabezpieczy naprawienie szkody, 
jaka wskutek dalszego postępowania może wyniknąć dla dłużnika.

***
## Art. 8211. {#kpc-trzecia--art-8211}

Jeżeli egzekucja została skierowana do rachunku bankowego, 
wynagrodzenia za pracę lub innych praw majątkowych, z którymi związane jest 
prawo dłużnika do świadczeń okresowych, sąd na wniosek dłużnika może określić 
kwotę, jaką dłużnik może pobierać w okresie zawieszenia postępowania w celu 
zaspokajania bieżących potrzeb. Na postanowienie sądu określające kwotę, którą 
dłużnik może pobierać w celu zaspokajania bieżących potrzeb, wierzycielowi służy 
zażalenie. 

 
 
 
s. 397/580 
 
2025-09-08

***
## Art. 822. {#kpc-trzecia--art-822}

Komornik wstrzyma się z dokonaniem czynności, jeżeli przed jej 
rozpoczęciem dłużnik złoży niebudzący wątpliwości dowód na piśmie, że 
obowiązku swojego dopełnił albo że wierzyciel udzielił mu zwłoki. Komornik 
wstrzyma się również z dokonaniem czynności, jeżeli przed jej rozpoczęciem 
dłużnik albo jego małżonek podniesie zarzut wynikający z umowy małżeńskiej 
przeciwko dokonaniu czynności i okaże umowę majątkową małżeńską oraz 
przedłoży niebudzący wątpliwości dowód na piśmie, że zawarcie umowy 
majątkowej małżeńskiej oraz jej rodzaj były wierzycielowi wiadome. Wstrzymując 
się z dokonaniem czynności, komornik stosownie do okoliczności podejmie 
działania, które umożliwiają dokonanie czynności w przyszłości. O wstrzymaniu 
czynności i jego przyczynach komornik niezwłocznie zawiadomi wierzyciela. Na 
polecenie wierzyciela komornik niezwłocznie dokona czynności, która uległa 
wstrzymaniu.

***
## Art. 823. {#kpc-trzecia--art-823}

(uchylony)

***
## Art. 824. {#kpc-trzecia--art-824}

**§ 1.** Postępowanie umarza się w całości lub części z urzędu: 
- 1) jeżeli okaże się, że egzekucja nie należy do organów sądowych; 
- 2) jeżeli wierzyciel lub dłużnik nie ma zdolności sądowej albo gdy egzekucja ze 
względu na jej przedmiot lub na osobę dłużnika jest niedopuszczalna; 
- 3) jeżeli jest oczywiste, że z egzekucji nie uzyska się sumy wyższej od kosztów 
egzekucyjnych; 
- 4) jeżeli wierzyciel w ciągu sześciu miesięcy nie dokonał czynności potrzebnej 
do dalszego prowadzenia postępowania lub nie zażądał podjęcia 
zawieszonego postępowania; 
- 5) jeżeli prawomocnym orzeczeniem tytuł wykonawczy został pozbawiony 
wykonalności albo orzeczenie, na którym oparto klauzulę wykonalności, 
zostało uchylone lub utraciło moc; 
- 6) jeżeli egzekucję skierowano przeciwko osobie, która według klauzuli 
wykonalności nie jest dłużnikiem, i która sprzeciwiła się prowadzeniu 
egzekucji, albo jeżeli prowadzenie egzekucji pozostaje z innych powodów w 
oczywistej sprzeczności z treścią tytułu wykonawczego. 
**§ 11.** Termin, o którym mowa w § 1 pkt 4, biegnie od dnia dokonania ostatniej 
czynności egzekucyjnej, a w razie zawieszenia postępowania – od dnia ustania 

 
 
 
s. 398/580 
 
2025-09-08 
 
przyczyny zawieszenia. Jeżeli jednak postępowanie zawieszono z uwagi na śmierć 
dłużnika albo utratę przez niego zdolności procesowej, termin, o którym mowa 
w § 1 pkt 4, biegnie od daty wydania postanowienia o zawieszeniu postępowania. 
**§ 2.** Umorzenie wskutek braku zdolności sądowej nastąpić może dopiero 
wówczas, gdy w terminie wyznaczonym przez organ egzekucyjny brak ten nie 
zostanie usunięty. W razie usunięcia braku stosuje się odpowiednio przepis art. 818 
**§ 2.** **§ 3.** Z chwilą uprawomocnienia się orzeczenia o zniesieniu separacji nie jest 
dopuszczalne wszczęcie postępowania egzekucyjnego na podstawie tytułu 
egzekucyjnego wydanego w sprawach, o których mowa w art. 5675, oraz 
rozstrzygającego 
o zaspokojeniu 
potrzeb 
rodziny, 
o świadczeniach 
alimentacyjnych małżonka pozostającego w separacji względem drugiego 
małżonka lub względem wspólnego małoletniego dziecka małżonków co do 
świadczeń za okres po zniesieniu separacji. Wszczęte w tych sprawach 
postępowanie egzekucyjne umarza się z urzędu.

***
## Art. 825. {#kpc-trzecia--art-825}

Organ egzekucyjny umorzy postępowanie w całości lub części na 
wniosek: 
- 1) jeżeli tego zażąda wierzyciel; jednakże w sprawach, w których egzekucję 
wszczęto z urzędu lub na żądanie uprawnionego organu, wniosek wierzyciela 
o umorzenie postępowania wymaga zgody sądu lub uprawnionego organu, 
który zażądał wszczęcia egzekucji; 
- 11) gdy zażąda tego dłużnik, jeżeli przed dniem złożenia wniosku o wszczęcie 
egzekucji roszczenie objęte tytułem wykonawczym uległo przedawnieniu, 
a wierzyciel nie wykaże dokumentem urzędowym lub prywatnym, że przed 
tym dniem nastąpiło zdarzenie, wskutek którego bieg terminu przedawnienia 
został przerwany; 
- 2) (uchylony) 
- 3) (uchylony) 
- 4) jeżeli wierzyciel jest w posiadaniu zastawu zabezpieczającego pełne 
zaspokojenie egzekwowanego roszczenia, chyba że egzekucja skierowana jest 
do przedmiotu zastawu. 
- 5) (uchylony) 

 
 
 
s. 399/580 
 
2025-09-08

***
## Art. 826. {#kpc-trzecia--art-826}

**§ 1.** Umorzenie postępowania egzekucyjnego powoduje uchylenie 
dokonanych czynności egzekucyjnych, lecz nie pozbawia wierzyciela możności 
wszczęcia ponownej egzekucji, chyba że z innych przyczyn egzekucja jest nie-
dopuszczalna. Umorzenie postępowania egzekucyjnego nie może naruszać praw 
osób trzecich. 
**§ 2.** Niezwłocznie po uprawomocnieniu się postanowienia o umorzeniu 
postępowania egzekucyjnego komornik zawiadamia o uchyleniu dokonanego 
zajęcia osoby trzecie, na których prawa i obowiązki zajęcie miało wpływ, w 
szczególności dozorcę zajętej ruchomości, pracodawcę, bank, dłużnika zajętej 
wierzytelności lub inną osobę, która z zajętego prawa jest obciążona obowiązkiem 
względem dłużnika. Zdanie pierwsze stosuje się także w razie ukończenia 
postępowania egzekucyjnego w inny sposób.

***
## Art. 827. {#kpc-trzecia--art-827}

**§ 1.** Przed zawieszeniem albo umorzeniem postępowania można 
wysłuchać wierzyciela i dłużnika. 
**§ 2.** Na wniosek wierzyciela lub dłużnika organ egzekucyjny wyda 
zaświadczenie o umorzeniu postępowania.

***
## Art. 828. {#kpc-trzecia--art-828}

Na postanowienie sądu co do zawieszenia lub umorzenia 
postępowania przysługuje zażalenie. 
#### DZIAŁ V
Ograniczenia egzekucji

***
## Art. 829. {#kpc-trzecia--art-829}

Nie podlegają egzekucji: 
- 1) przedmioty 
urządzenia 
domowego 
niezbędne 
dla 
dłużnika 
i jego 
domowników, w szczególności lodówka, pralka, odkurzacz, piekarnik lub 
kuchenka 
mikrofalowa, 
płyta 
grzewcza 
służąca 
podgrzewaniu 
i 
przygotowywaniu posiłków, łóżka, stół i krzesła w liczbie niezbędnej dla 
dłużnika i jego domowników oraz po jednym źródle oświetlenia na izbę, 
chyba że są to przedmioty, których wartość znacznie przekracza przeciętną 
wartość nowych przedmiotów danego rodzaju; 
- 11) pościel, bielizna i ubranie codzienne, w liczbie niezbędnej dla dłużnika i jego 
domowników, a także ubranie niezbędne do pełnienia służby lub 
wykonywania zawodu; 

 
 
 
s. 400/580 
 
2025-09-08 
- 2) zapasy żywności i opału niezbędne dla dłużnika i będących na jego 
utrzymaniu członków jego rodziny na okres jednego miesiąca; 
- 3) jedna krowa lub dwie kozy albo trzy owce potrzebne do wyżywienia dłużnika 
i będących na jego utrzymaniu członków jego rodziny wraz z zapasem paszy 
i ściółki do najbliższych zbiorów; 
- 4) narzędzia i inne przedmioty niezbędne do osobistej pracy zarobkowej 
dłużnika oraz surowce niezbędne dla niego do produkcji na okres jednego 
tygodnia, z wyłączeniem jednak pojazdów mechanicznych; 
- 5) u dłużnika pobierającego periodyczną stałą płacę – pieniądze w kwocie, która 
odpowiada niepodlegającej egzekucji części płacy za czas do najbliższego 
terminu wypłaty, a u dłużnika nieotrzymującego stałej płacy lub u dłużnika, 
będącego osobą fizyczną wykonującą działalność gospodarczą – pieniądze 
niezbędne dla niego i jego rodziny na utrzymanie przez dwa tygodnie; 
- 6) przedmioty niezbędne do nauki, papiery osobiste, odznaczenia i przedmioty 
służące do wykonywania praktyk religijnych oraz przedmioty codziennego 
użytku, które mogą być sprzedane tylko znacznie poniżej ich wartości, a dla 
dłużnika mają znaczną wartość użytkową; 
- 7) (uchylony) 
- 8) produkty lecznicze w rozumieniu przepisów ustawy z dnia 6 września 2001 r. 
– Prawo farmaceutyczne (Dz. U. z 2024 r. poz. 686) niezbędne do 
funkcjonowania 
podmiotu 
leczniczego 
w rozumieniu 
przepisów 
o działalności leczniczej przez okres trzech miesięcy; 
- 81) niezbędne do funkcjonowania podmiotu leczniczego w rozumieniu przepisów 
o działalności leczniczej wyroby medyczne, wyposażenie wyrobów 
medycznych, systemy i zestawy zabiegowe, w rozumieniu przepisów 
rozporządzenia Parlamentu Europejskiego i Rady (UE) 2017/745 z dnia 
5 kwietnia 2017 r. w sprawie wyrobów medycznych, zmiany dyrektywy 
2001/83/WE, rozporządzenia (WE) nr 178/2002 i rozporządzenia (WE) 
nr 1223/2009 oraz uchylenia dyrektyw Rady 90/385/EWG i 93/42/EWG 
(Dz. Urz. UE L 117 z 05.05.2017, str. 1, z późn. zm.20)), oraz wyroby 
- 20) Zmiany wymienionego rozporządzenia zostały ogłoszone w Dz. Urz. UE L 117 z 03.05.2019, 
str. 9, Dz. Urz. UE L 334 z 27.12.2019, str. 165, Dz. Urz. UE L 130 z 24.04.2020, str. 18 i Dz. 
Urz. UE L 241 z 08.07.2021, str. 7. 

 
 
 
s. 401/580 
 
2025-09-08 
 
medyczne do diagnostyki in vitro i wyposażenie wyrobów medycznych do 
diagnostyki in vitro, w rozumieniu przepisów rozporządzenia Parlamentu 
Europejskiego i Rady (UE) 2017/746 z dnia 5 kwietnia 2017 r. w sprawie 
wyrobów medycznych do diagnostyki in vitro oraz uchylenia dyrektywy 
98/79/WE i decyzji Komisji 2010/227/UE (Dz. Urz. UE L 117 z 05.05.2017, 
str. 176, z późn. zm.21)); 
- 9) przedmioty niezbędne ze względu na niepełnosprawność dłużnika lub 
członków jego rodziny.

***
## Art. 8291. {#kpc-trzecia--art-8291}

Jeżeli dłużnikiem jest rolnik prowadzący gospodarstwo rolne, 
egzekucji nie podlegają również: 
- 1) stado podstawowe zwierząt gospodarskich: 
  - a) bydła mlecznego, 
  - b) bydła mięsnego, 
  - c) koni, 
  - d) kóz, 
  - e) owiec, 
  - f) świń, 
  - g) drobiu, 
  - h) zwierząt futerkowych, 
  - i) innych gatunków, stanowiących podstawę produkcji zwierzęcej 
w gospodarstwie rolnym dłużnika; 
- 2) zwierzęta gospodarskie, poza stadem podstawowym, w drugiej połowie 
okresu ciąży i w okresie odchowu potomstwa oraz źrebięta do 6 miesięcy, 
cielęta do 4 miesięcy, jagnięta do 3 miesięcy, prosięta do 2 miesięcy i koźlęta 
do 5 miesięcy; 
- 3) stado użytkowe drobiu, co do którego zawarto umowę na dostawę ptaków 
z tego stada lub produktów pochodzących od tych ptaków; 
- 4) zwierzęta futerkowe, co do których hodowca zawarł umowę na dostawę skór 
tych zwierząt; 
- 21) Zmiany wymienionego rozporządzenia zostały ogłoszone w Dz. Urz. UE L 117 z 03.05.2019, 
str. 11, Dz. Urz. UE L 334 z 27.12.2019, str. 167 i Dz. Urz. UE L 233 z 01.07.2021, str. 9. 

 
 
 
s. 402/580 
 
2025-09-08 
- 5) rodziny pszczele pszczoły miodnej (Apis mellifera) wraz z zasiedlonymi 
przez te rodziny ulami; 
- 6) podstawowe maszyny, narzędzia i urządzenia rolnicze, w liczbie niezbędnej 
do pracy w gospodarstwie rolnym dłużnika, w tym ciągniki rolnicze 
z maszynami i sprzętem współpracującym, samobieżne maszyny rolnicze 
niezbędne do uprawy, pielęgnacji, zbioru i transportu ziemiopłodów; 
- 7) silosy na zboża i pasze; 
- 8) zapasy paliwa i części zamienne, niezbędne do normalnej pracy ciągnika 
i maszyn 
rolniczych, 
na 
okres 
niezbędny 
do 
zakończenia 
cyklu 
produkcyjnego; 
- 9) materiał siewny, zboże i inne ziemiopłody niezbędne do siewów lub sadzenia 
w gospodarstwie rolnym dłużnika, w ilości niezbędnej w danym roku 
gospodarczym; 
- 10) zapasy opału na okres 6 miesięcy; 
- 11) nawozy, środki ochrony roślin oraz środki wspomagające uprawę roślin, 
w ilości niezbędnej na dany rok gospodarczy dla gospodarstwa rolnego 
dłużnika; 
- 12) zapasy paszy i ściółki dla inwentarza wymienionego w pkt 1–4, do 
najbliższych zbiorów; 
- 13) podstawowy sprzęt techniczny, niezbędny do zakończenia cyklu danej 
technologii produkcji w przypadku gospodarstwa specjalistycznego; 
- 14) zaliczki na poczet dostaw produktów rolnych; 
- 15) budynki gospodarcze i grunty rolne, niezbędne do hodowli zwierząt 
w proporcji uzależnionej od wielkości stada podstawowego i niezbędnej 
nadwyżki inwentarza; 
- 16) budynki gospodarcze magazynowe, składowe, przechowalnie oraz szklarnie, 
tunele foliowe i inspekty do prowadzenia produkcji roślinnej w gospodarstwie 
rolnym dłużnika wraz z wyposażeniem.

***
## Art. 8292. {#kpc-trzecia--art-8292}

**§ 1.** Niezależnie od wyłączeń, o których mowa w art. 8291, 
egzekucji nie podlegają nadwyżka inwentarza żywego ponad stado podstawowe 
oraz przedmioty, o których mowa w art. 8291 pkt 6, 8, 9, 11–13 i 15, ponad ilości 
wymienione w tych przepisach, jeżeli komornik, po zasięgnięciu opinii izby 

 
 
 
s. 403/580 
 
2025-09-08 
 
rolniczej właściwej ze względu na położenie gospodarstwa rolnego dłużnika, uzna 
je za niezbędne do prowadzenia tego gospodarstwa. 
**§ 2.** Komornik, w terminie 3 dni od dokonania zajęcia, występuje do izby 
rolniczej, właściwej ze względu na położenie gospodarstwa rolnego dłużnika, 
z wnioskiem o wydanie, w terminie 21 dni od dnia doręczenia tego wniosku, opinii, 
o której mowa w § 1. Do wniosku komornik załącza odpis protokołu zajęcia 
składników majątku dłużnika oraz informację o łącznej wysokości dochodzonych 
od dłużnika należności. Do czasu wydania opinii komornik wstrzymuje się 
z dokonaniem czynności egzekucyjnych dotyczących nadwyżki inwentarza 
żywego ponad stado podstawowe oraz przedmiotów, o których mowa 
w art. 8291 pkt 6, 8, 9, 11–13 i 15. 
**§ 3.** Opinia, o której mowa w § 1, nie stanowi informacji w rozumieniu 
art. 761 § 11. Przepisu art. 762 nie stosuje się. 
**§ 4.** W uzasadnionych przypadkach, gdy zaistnieją wątpliwości co do treści 
opinii, o której mowa w § 1, komornik może powołać biegłego na okoliczność 
ustalenia dopuszczalnego zakresu zajęcia. 
**§ 5.** W razie rozbieżności między opinią izby rolniczej a opinią biegłego 
komornik związany jest opinią biegłego. 
**§ 6.** W razie uznania nadwyżki inwentarza żywego ponad stado podstawowe 
oraz przedmiotów, o których mowa w art. 8291 pkt 6, 8, 9, 11–13 i 15, za niezbędne 
do prowadzenia gospodarstwa rolnego dłużnika komornik umarza postępowanie 
egzekucyjne w tym zakresie.

***
## Art. 8293. {#kpc-trzecia--art-8293}

Zajęte zwierzęta hodowlane w rozumieniu ustawy z dnia 
10 grudnia 2020 r. o organizacji hodowli i rozrodzie zwierząt gospodarskich 
(Dz. U. z 2021 r. poz. 36) wyłącza się spod egzekucji, jeżeli nie mogą być 
sprzedane osobie, która wykaże, że posiada gospodarstwo rolne, w którym istnieją 
warunki do dalszej hodowli tych zwierząt.

***
## Art. 8294. {#kpc-trzecia--art-8294}

W sprawach o egzekucję alimentów lub renty mającej charakter 
alimentów, jak również w sprawach o egzekucję należności powstałych w związku 
z pracą zarobkową, wykonywaną w gospodarstwie rolnym dłużnika, nie stosuje się 
przepisów art. 8291 pkt 1, 3–5 i 14 oraz art. 8292, chyba że egzekucja dotyczy 
świadczeń zaległych za okres dłuższy niż 6 miesięcy. Jeżeli w toku egzekucji 

 
 
 
s. 404/580 
 
2025-09-08 
 
doszło do sprzedaży rzeczy ruchomej albo przejęcia jej na własność przez 
wierzyciela, a cena nabycia przekracza wysokość zaległości za okres, o którym 
mowa w zdaniu poprzedzającym, nadwyżkę zalicza się na poczet pozostałych 
wymagalnych świadczeń.

***
## Art. 8295. {#kpc-trzecia--art-8295}

Przepisów art. 8291–8294 nie stosuje się w razie równoczesnego 
skierowania egzekucji do wszystkich nieruchomości wchodzących w skład 
gospodarstwa rolnego prowadzonego przez dłużnika.

***
## Art. 830. {#kpc-trzecia--art-830}

(uchylony)

***
## Art. 831. {#kpc-trzecia--art-831}

**§ 1.** Nie podlegają egzekucji: 
- 1) sumy i świadczenia w naturze wyasygnowane na pokrycie wydatków lub 
wyjazdów w sprawach służbowych; 
1a) 50 % kwot diet przysługujących z tytułu podróży służbowych – jeżeli 
egzekucja ma na celu zaspokojenie roszczeń z tytułu alimentów, w tym 
należności budżetu państwa z tytułu świadczeń wypłacanych w przypadku 
bezskuteczności egzekucji alimentów; 
- 2) sumy przyznane przez Skarb Państwa na specjalne cele (w szczególności 
stypendia, wsparcia), chyba że wierzytelność egzekwowana powstała 
w związku z urzeczywistnieniem tych celów albo z tytułu obowiązku 
alimentacyjnego; 
2a) środki pochodzące z programów finansowanych z udziałem środków, o 
których mowa w art. 5 ust. 1 pkt 2 i 3 ustawy z dnia 27 sierpnia 2009 r. o 
finansach publicznych (Dz. U. z 2023 r. poz. 1270, z późn. zm.22)), wypłacone 
w formie zaliczki, chyba że wierzytelność egzekwowana powstała w związku 
z realizacją projektu, na który środki te były przeznaczone; 
- 3) prawa niezbywalne, chyba że możność ich zbycia wyłączono umową, 
a przedmiot świadczenia nadaje się do egzekucji albo wykonanie prawa może 
być powierzone komu innemu; 
- 4) (utracił moc)23) 
- 22) Zmiany tekstu jednolitego wymienionej ustawy zostały ogłoszone w Dz. U. z 2023 r. poz. 1273, 
1407, 1429, 1641, 1693 i 1872 oraz z 2024 r. poz. 858 i 1089. 
- 23) Z dniem 17 stycznia 2007 r. na podstawie wyroku Trybunału Konstytucyjnego z dnia 9 stycznia 
2007 r. sygn. akt P 5/05 (Dz. U. poz. 58). 

 
 
 
s. 405/580 
 
2025-09-08 
- 5) świadczenia z ubezpieczeń osobowych oraz odszkodowania z ubezpieczeń 
majątkowych, w granicach określonych w drodze rozporządzenia przez 
Ministrów Finansów24) i Sprawiedliwości; nie dotyczy to egzekucji mającej 
na celu zaspokojenie roszczeń z tytułu alimentów; 
- 6) świadczenia z pomocy społecznej w rozumieniu przepisów ustawy z dnia 
12 marca 2004 r. o pomocy społecznej (Dz. U. z 2024 r. poz. 1283); 
6a) jednorazowa lub okresowa pomoc pieniężna przyznawana przez Szefa Urzędu 
do Spraw Kombatantów i Osób Represjonowanych; 
- 7) wierzytelności przypadające dłużnikowi z budżetu państwa lub od 
Narodowego Funduszu Zdrowia z tytułu udzielania świadczeń opieki 
zdrowotnej w rozumieniu przepisów ustawy z dnia 27 sierpnia 2004 r. 
o świadczeniach opieki zdrowotnej finansowanych ze środków publicznych 
(Dz. U. z 2024 r. poz. 146, 858 i 1222) przed ukończeniem udzielania tych 
świadczeń, w wysokości 75 % każdorazowej wypłaty, chyba że chodzi 
o wierzytelności pracowników dłużnika lub świadczeniodawców, o których 
mowa w art. 5 pkt 41 lit. a i b ustawy z dnia 27 sierpnia 2004 r. o świad-
czeniach opieki zdrowotnej finansowanych ze środków publicznych; 
- 8) sumy przyznane orzeczeniem Europejskiego Trybunału Praw Człowieka, 
jeżeli egzekwowana wierzytelność przysługuje Skarbowi Państwa; 
- 9) świadczenie integracyjne w rozumieniu ustawy z dnia 13 czerwca 2003 r. 
o zatrudnieniu socjalnym (Dz. U. z 2022 r. poz. 2241); 
- 10) wierzytelności przysługujące spółdzielni mieszkaniowej wobec członków 
spółdzielni i osób niebędących członkami spółdzielni, którym przysługuje 
spółdzielcze prawo do lokalu albo własność lokalu, z tytułu opłat, o których 
mowa w art. 4 ustawy z dnia 15 grudnia 2000 r. o spółdzielniach 
mieszkaniowych (Dz. U. z 2024 r. poz. 558), jak również środki, będące w 
dyspozycji spółdzielni w związku z wnoszeniem tych opłat, chyba że 
wierzytelność egzekwowana powstała w związku z wykonaniem przez 
wierzyciela zobowiązań, które miały być zaspokojone z opłat, o których 
mowa w art. 4 tej ustawy. 
- 24) Obecnie minister właściwy do spraw finansów publicznych, na podstawie art. 4 ust. 1, art. 5 pkt 
3 i art. 8 ustawy z dnia 4 września 1997 r. o działach administracji rządowej (Dz. U. z 2024 r. 
poz. 1370), która weszła w życie z dniem 1 kwietnia 1999 r. 

 
 
 
s. 406/580 
 
2025-09-08 
**§ 2.** W przypadkach, o których mowa w § 1 pkt 1–2a i 7, nie podlegają 
egzekucji również sumy i świadczenia w naturze już wypłacone lub wydane, a w 
przypadku, o którym mowa w § 1 pkt 2a, nie podlegają egzekucji również środki 
trwałe oraz wartości niematerialne i prawne powstałe w ramach realizacji projektu, 
na który były przeznaczone środki pochodzące z programów finansowanych z 
udziałem środków, o których mowa w art. 5 ust. 1 pkt 2 i 3 ustawy z dnia 27 sierpnia 
2009 r. o finansach publicznych, przez okres jego realizacji wskazany w umowie o 
dofinansowanie projektu. 
**§ 3.** (uchylony) 
**§ 4.** Przepis § 1 pkt 10 stosuje się odpowiednio do wierzytelności 
przysługujących spółdzielni mieszkaniowej wobec najemców spółdzielczych lokali 
mieszkalnych, które przed przejęciem przez spółdzielnię mieszkaniową były 
mieszkaniami przedsiębiorstwa państwowego, państwowej osoby prawnej, spółki 
Skarbu Państwa lub innej państwowej jednostki organizacyjnej.

***
## Art. 832. {#kpc-trzecia--art-832}

Należności wypłacone w związku ze śmiercią tytułem zapomogi lub 
jednorazowego zaopatrzenia pod jakąkolwiek nazwą albo z tytułu ubezpieczenia na 
pokrycie kosztów pogrzebu podlegają egzekucji tylko na zaspokojenie tych 
kosztów.

***
## Art. 833. {#kpc-trzecia--art-833}

**§ 1.** Wynagrodzenie ze stosunku pracy podlega egzekucji 
w zakresie określonym w przepisach Kodeksu pracy. 
**§ 11.** Przepisy art. 87 i art. 871 Kodeksu pracy stosuje się odpowiednio do 
zasiłków dla bezrobotnych, dodatków aktywizacyjnych oraz stypendiów, 
wypłacanych na podstawie ustawy z dnia 20 marca 2025 r. o rynku pracy 
i służbach zatrudnienia (Dz. U. poz. 620). 
**§ 2.** Przepisy art. 87 i art. 871 Kodeksu pracy stosuje się odpowiednio do 
uposażeń posłów i senatorów, należności członków rolniczych spółdzielni 
produkcyjnych i ich domowników z tytułu pracy w spółdzielni, wynagrodzeń 
członków spółdzielni pracy. 
**§ 21.** Przepisy art. 87 i art. 871 Kodeksu pracy stosuje się odpowiednio do 
wszystkich świadczeń powtarzających się, których celem jest zapewnienie 
utrzymania albo stanowiących jedyne źródło dochodu dłużnika będącego osobą 
fizyczną. 

 
 
 
s. 407/580 
 
2025-09-08 
**§ 3.** Ograniczeń przewidzianych w § 2 i 21 nie stosuje się do wierzytelności 
członków rolniczych spółdzielni produkcyjnych z tytułu udziału w dochodach 
spółdzielni przypadających im od wniesionych do spółdzielni wkładów. 
**§ 4.** Świadczenia pieniężne przewidziane w przepisach o zaopatrzeniu 
emerytalnym podlegają egzekucji w zakresie określonym w tych przepisach. 
**§ 5.** Do egzekucji z rent przysługujących z tytułu wypadku przy pracy lub 
choroby zawodowej i z rent zasądzonych przez sąd lub ustalonych umową za utratę 
zdolności do pracy albo za śmierć żywiciela lub wypłacanych z dobrowolnego 
ubezpieczenia rentowego oraz do egzekucji ze świadczeń pieniężnych 
przysługujących z ubezpieczenia społecznego w razie choroby i macierzyństwa 
stosuje się przepisy o egzekucji ze świadczeń przewidzianych w przepisach o 
zaopatrzeniu emerytalnym pracowników i ich rodzin. 
**§ 6.** Nie podlegają egzekucji świadczenia alimentacyjne, świadczenia 
pieniężne wypłacane w przypadku bezskuteczności egzekucji alimentów, 
świadczenia rodzinne, dodatki rodzinne, pielęgnacyjne, porodowe, dla sierot zupeł-
nych, zasiłki dla opiekunów, świadczenia z pomocy społecznej, świadczenia 
integracyjne, świadczenie wychowawcze, świadczenie dobry start, jednorazowe 
świadczenie, o którym mowa w art. 10 ustawy z dnia 4 listopada 2016 r. o wsparciu 
kobiet w ciąży i rodzin „Za życiem” (Dz. U. z 2023 r. poz. 1923), dodatek 
osłonowy, o którym mowa w ustawie z dnia 17 grudnia 2021 r. o dodatku osło-
nowym (Dz. U. z 2024 r. poz. 953), dodatek węglowy, o którym mowa w ustawie 
z dnia 5 sierpnia 2022 r. o dodatku węglowym (Dz. U. z 2024 r. poz. 1207), 
dodatek dla gospodarstw domowych z tytułu wykorzystywania niektórych źródeł 
ciepła i dodatek dla niektórych podmiotów niebędących gospodarstwami 
domowymi z tytułu wykorzystania niektórych źródeł ciepła, o których mowa 
w ustawie z dnia 15 września 2022 r. o szczególnych rozwiązaniach w zakresie 
niektórych źródeł ciepła w związku z sytuacją na rynku paliw (Dz. U. z 2023 r. poz. 
1772, 1693 i 2760 oraz z 2024 r. poz. 859), dodatek elektryczny, o którym mowa 
w ustawie z dnia 7 października 2022 r. o szczególnych rozwiązaniach służących 
ochronie odbiorców energii elektrycznej w 2023 roku oraz w 2024 roku w związku 
z sytuacją na rynku energii elektrycznej (Dz. U. z 2024 r. poz. 1288), refundacja 
podatku VAT, o której mowa w art. 18 ustawy z dnia 15 grudnia 2022 r. 
o szczególnej ochronie niektórych odbiorców paliw gazowych w 2023 r. oraz w 

 
 
 
s. 408/580 
 
2025-09-08 
 
2024 r. w związku z sytuacją na rynku gazu (Dz. U. z 2024 r. poz. 303, 834 i 859), 
bon energetyczny, o którym mowa w ustawie z dnia 23 maja 2024 r. o bonie 
energetycznym oraz o zmianie niektórych ustaw w celu ograniczenia cen energii 
elektrycznej, gazu ziemnego i ciepła systemowego (Dz. U. poz. 859), świadczenie 
wspierające, o którym mowa w ustawie z dnia 7 lipca 2023 r. o świadczeniu 
wspierającym (Dz. U. poz. 1429 i 2760), a także świadczenia „aktywny rodzic”, o 
których mowa w ustawie z dnia 15 maja 2024 r. o wspieraniu rodziców w 
aktywności zawodowej oraz w wychowaniu dziecka – „Aktywny rodzic” (Dz. U. 
poz. 858). 
**§ 7.** Nie podlegają egzekucji świadczenia, dodatki i inne kwoty, o których 
mowa w art. 31 ust. 1, art. 80 ust. 1, art. 81, art. 83 ust. 1 i 4, art. 84 pkt 2 i 3 
i art. 140 ust. 1 pkt 1 ustawy z dnia 9 czerwca 2011 r. o wspieraniu rodziny 
i systemie pieczy zastępczej, oraz środki finansowe na utrzymanie lokalu 
mieszkalnego w budynku wielorodzinnym lub domu jednorodzinnego, o których 
mowa w art. 83 ust. 2 i art. 84 pkt 1 ustawy z dnia 9 czerwca 2011 r. o wspieraniu 
rodziny i systemie pieczy zastępczej, w części przysługującej na umieszczone 
w rodzinie zastępczej lub rodzinnym domu dziecka dzieci i osoby, które osiągnęły 
pełnoletność przebywając w pieczy zastępczej. 
**§ 8.** Nie podlegają egzekucji dodatki mieszkaniowe wypłacone na podstawie 
ustawy z dnia 21 czerwca 2001 r. o dodatkach mieszkaniowych (Dz. U. z 2023 r. 
poz. 1335) oraz dodatki energetyczne wypłacone na podstawie ustawy z dnia 
10 kwietnia 1997 r. – Prawo energetyczne. 
**§ 9.** Nie podlegają egzekucji zapomogi udzielone na podstawie ustawy z dnia 
11 sierpnia 2021 r. o kasach zapomogowo-pożyczkowych (Dz. U. poz. 1666).

***
## Art. 834. {#kpc-trzecia--art-834}

Dochody wymienione w artykule poprzedzającym oblicza się wraz 
ze wszystkimi dodatkami i wartością świadczeń w naturze, lecz po potrąceniu 
podatków i opłat należnych z mocy ustawy.

***
## Art. 835. {#kpc-trzecia--art-835}

Jeżeli dłużnik otrzymuje dochody z kilku źródeł, podstawę 
obliczenia stanowi suma wszystkich dochodów.

***
## Art. 8351. {#kpc-trzecia--art-8351}

Jeżeli zachodzą uzasadnione wątpliwości, że uzyskane na skutek 
egzekucji środki pieniężne pochodzą z sum lub ze świadczeń niepodlegających 

 
 
 
s. 409/580 
 
2025-09-08 
 
egzekucji, komornik wstrzymuje się z ich przekazaniem wierzycielowi do czasu 
wyjaśnienia tych wątpliwości.

***
## Art. 836. {#kpc-trzecia--art-836}

Do czasu przyjęcia spadku egzekucja na zaspokojenie długu 
spadkodawcy dopuszczalna jest tylko ze spadku. Przed przyjęciem spadku nie może 
być z niego prowadzona egzekucja na zaspokojenie osobistego długu spadkobiercy.

***
## Art. 837. {#kpc-trzecia--art-837}

Dłużnik może powoływać się na ograniczenie odpowiedzialności 
tylko wówczas, gdy ograniczenie to zostało zastrzeżone w tytule wykonawczym. 
Zastrzeżenie nie jest konieczne, jeżeli świadczenie zostało zasądzone od nabywcy 
majątku, zarządcy ustanowionego przez sąd, kuratora spadku, wykonawcy 
testamentu lub zarządcy sukcesyjnego z powierzonego im majątku albo Skarbu 
Państwa lub gminy jako spadkobiercy.

***
## Art. 838. {#kpc-trzecia--art-838}

Gdy 
w wypadku 
zbiegu 
egzekucji 
sądowej 
i egzekucji 
administracyjnej organ egzekucyjny sądowy prowadzi obie egzekucje, przepisy 
kodeksu w przedmiocie ograniczenia egzekucji stosuje się również do należności 
podlegających egzekucji administracyjnej, chyba że określone w przepisach 
ustawy o egzekucji administracyjnej ograniczenia egzekucyjne są mniejsze.

***
## Art. 839. {#kpc-trzecia--art-839}

**§ 1.** Postanowienie sądu w przedmiocie ograniczenia egzekucji 
powinno zapaść po wysłuchaniu stron. 
**§ 2.** Na postanowienie sądu przysługuje zażalenie. 
#### DZIAŁ VI
Powództwa przeciwegzekucyjne

***
## Art. 840. {#kpc-trzecia--art-840}

**§ 1.** Dłużnik może w drodze powództwa żądać pozbawienia tytułu 
wykonawczego wykonalności w całości lub części albo ograniczenia, jeżeli: 
- 1) przeczy zdarzeniom, na których oparto wydanie klauzuli wykonalności, 
a w szczególności gdy kwestionuje istnienie obowiązku stwierdzonego 
tytułem egzekucyjnym niebędącym orzeczeniem sądu albo gdy kwestionuje 
przejście obowiązku mimo istnienia formalnego dokumentu stwierdzającego 
to przejście; 
- 2) po powstaniu tytułu egzekucyjnego nastąpiło zdarzenie, wskutek którego 
zobowiązanie wygasło albo nie może być egzekwowane; gdy tytułem jest 
orzeczenie sądowe, dłużnik może oprzeć powództwo także na zdarzeniach, 

 
 
 
s. 410/580 
 
2025-09-08 
 
które nastąpiły po zamknięciu rozprawy, na zarzucie spełnienia świadczenia, 
jeżeli 
zgłoszenie 
tego 
zarzutu 
w sprawie 
było 
z mocy 
ustawy 
niedopuszczalne, a także na zarzucie potrącenia; 
- 3) małżonek, przeciwko któremu sąd nadał klauzulę wykonalności na podstawie 
art. 787, wykaże, że egzekwowane świadczenie wierzycielowi nie należy się, 
przy czym małżonkowi temu przysługują zarzuty nie tylko z własnego prawa, 
lecz także zarzuty, których jego małżonek wcześniej nie mógł podnieść. 
**§ 2.** Jeżeli 
podstawą 
egzekucji 
jest 
tytuł 
pochodzący 
od 
organu 
administracyjnego, do stwierdzenia, że zobowiązanie wygasło lub nie może być 
egzekwowane, powołany jest organ, od którego tytuł pochodzi.

***
## Art. 8401. {#kpc-trzecia--art-8401}

Jeżeli dłużnik albo jego małżonek, przeciwko któremu sąd nadał 
klauzulę wykonalności na podstawie art. 787 lub art. 7871, podnosi wynikający 
z umowy majątkowej małżeńskiej zarzut wyłączenia lub ograniczenia jego 
odpowiedzialności całością lub częścią majątku, przepis art. 840 § 1 i § 2 stosuje 
się odpowiednio.

***
## Art. 8402. {#kpc-trzecia--art-8402}

Jeżeli 
egzekucja 
prowadzona 
jest 
na 
podstawie 
tytułu 
egzekucyjnego lub innego dokumentu, któremu nie nadaje się klauzuli 
wykonalności, do ochrony praw dłużnika stosuje się odpowiednio przepisy art. 840 
i art. 843.

***
## Art. 8403. {#kpc-trzecia--art-8403}

(uchylony)

***
## Art. 841. {#kpc-trzecia--art-841}

**§ 1.** Osoba trzecia może w drodze powództwa żądać zwolnienia 
zajętego przedmiotu od egzekucji, jeżeli skierowanie do niego egzekucji narusza 
jej prawa. 
**§ 2.** Jeżeli dłużnik zaprzecza prawu powoda, należy oprócz wierzyciela 
pozwać również dłużnika. 
**§ 3.** Powództwo można wnieść w terminie miesiąca od dnia dowiedzenia się 
o naruszeniu prawa, chyba że inny termin jest przewidziany w przepisach 
odrębnych.

***
## Art. 842. {#kpc-trzecia--art-842}

**§ 1.** Dopuszczalne jest również powództwo o zwolnienie zajętego 
przedmiotu od egzekucji administracyjnej. Do pozwu należy dołączyć 
postanowienie administracyjnego organu egzekucyjnego odmawiające żądaniu 
wyłączenia przedmiotu spod egzekucji. Niezależnie od wyniku sprawy sąd nałoży 

 
 
 
s. 411/580 
 
2025-09-08 
 
koszty procesu na osobę trzecią, powołującą w powództwie o zwolnienie 
przedmiotu od egzekucji administracyjnej nowe dowody istotne dla rozstrzygnięcia 
sprawy, których nie przedstawiła w postępowaniu administracyjnym, mimo że 
mogła je powołać w tym postępowaniu. 
**§ 2.** Powództwo można wnieść w ciągu dni czternastu od doręczenia 
postanowienia administracyjnego organu egzekucyjnego, a jeżeli zainteresowany 
wniósł zażalenie na to postanowienie – w ciągu dni czternastu od doręczenia 
postanowienia wydanego na skutek zażalenia.

***
## Art. 843. {#kpc-trzecia--art-843}

**§ 1.** Powództwa przewidziane w niniejszym dziale wytacza się 
przed sąd rzeczowo właściwy, w którego okręgu prowadzi się egzekucję. Miejsce 
prowadzenia egzekucji określa się na podstawie przepisów niniejszego kodeksu 
regulujących właściwość miejscową organu egzekucyjnego także wtedy, gdy do 
prowadzenia egzekucji został wybrany komornik poza właściwością ogólną. 
**§ 2.** Jeżeli egzekucji jeszcze nie wszczęto, powództwo o pozbawienie tytułu 
wykonawczego wykonalności wytacza się według przepisów o właściwości 
ogólnej. 
**§ 3.** W pozwie powód powinien przytoczyć wszystkie zarzuty, jakie w tym 
czasie mógł zgłosić, pod rygorem utraty prawa korzystania z nich w dalszym 
postępowaniu. 
**§ 4.** (uchylony) 
### TYTUŁ II
Egzekucja świadczeń pieniężnych 
#### DZIAŁ I
Egzekucja z ruchomości 
Rozdział 1 
Zajęcie

***
## Art. 844. {#kpc-trzecia--art-844}

**§ 1.** Egzekucja z ruchomości należy do komornika ogólnej 
właściwości dłużnika. Jeżeli dłużnik nie ma miejsca zamieszkania, siedziby lub 
oddziału na terytorium Rzeczypospolitej Polskiej, do przeprowadzenia egzekucji 
właściwy jest komornik tego sądu, w którego okręgu znajdują się ruchomości. 

 
 
 
s. 412/580 
 
2025-09-08 
**§ 2.** Komornik, który wszczął egzekucję z niektórych ruchomości dłużnika, 
jest właściwy do przeprowadzenia egzekucji z pozostałych ruchomości dłużnika, 
chociażby znajdowały się w okręgu innego sądu. 
**§ 3.** Komornik wybrany przez wierzyciela oraz komornik, o którym mowa 
w § 2, po dokonaniu zajęcia ruchomości zawiadamia o zajęciu komornika 
działającego przy sądzie rejonowym, w którego okręgu znajdują się ruchomości, 
w chwili zajęcia, przesyłając odpis protokołu zajęcia ruchomości.

***
## Art. 8441. {#kpc-trzecia--art-8441}

Przepisy 
dotyczące 
egzekucji 
z ruchomości 
stosuje 
się 
odpowiednio do egzekucji ze zwierząt, jeżeli nie jest to sprzeczne z przepisami 
dotyczącymi ochrony zwierząt.

***
## Art. 845. {#kpc-trzecia--art-845}

**§ 1.** Do egzekucji z ruchomości komornik przystępuje przez ich 
zajęcie. 
**§ 2.** Zająć można ruchomości dłużnika będące w jego władaniu albo we 
władaniu samego wierzyciela, który do nich skierował egzekucję. Nie podlegają 
jednak zajęciu ruchomości, jeżeli z ujawnionych w sprawie okoliczności wynika, 
że nie stanowią one własności dłużnika. Ruchomości dłużnika będące we władaniu 
osoby trzeciej można zająć tylko wówczas, gdy osoba ta zgadza się na ich zajęcie 
albo przyznaje, że stanowią one własność dłużnika, oraz w przypadkach 
wskazanych 
w ustawie. 
Jednakże 
w razie 
zbiegu 
egzekucji 
sądowej 
i administracyjnej 
dopuszczalne 
jest 
zajęcie 
ruchomości 
na 
zasadach 
przewidzianych w przepisach o egzekucji administracyjnej. 
**§ 21.** W przypadku egzekucji świadczeń alimentacyjnych komornik może 
zająć także ruchomości będące we władaniu osoby zamieszkującej wspólnie 
z dłużnikiem bez zgody tej osoby, chyba że przedstawi ona dowód, że ruchomości 
są jej własnością. 
**§ 22.** Komornik umarza postępowanie w niezbędnym zakresie, jeżeli 
przedstawiono niebudzący wątpliwości dowód na piśmie, że zajęte ruchomości nie 
stanowią własności dłużnika. Nie dotyczy to sytuacji, w której sam dłużnik dokonał 
zbycia ruchomości na rzecz osoby trzeciej. 
**§ 23.** W przypadku złożenia przez osobę trzecią skargi na zajęcie, miesięczny 
termin do wniesienia powództwa, o którym mowa w art. 841 § 1, zaczyna biec dla 
tej osoby od dnia doręczenia jej postanowienia oddalającego skargę. 

 
 
 
s. 413/580 
 
2025-09-08 
**§ 24.** Tytuł wykonawczy wystawiony przeciwko osobie pozostającej 
w związku małżeńskim stanowi podstawę do zajęcia ruchomości wchodzącej 
w skład majątku wspólnego. Jeżeli zajęta ruchomość wchodzi w skład majątku 
wspólnego, dalsze czynności egzekucyjne dopuszczalne są na podstawie tytułu 
wykonawczego wystawionego przeciwko obojgu małżonkom. 
**§ 3.** Nie należy zajmować więcej ruchomości ponad te, które są potrzebne do 
zaspokojenia należności i kosztów egzekucyjnych.

***
## Art. 846. {#kpc-trzecia--art-846}

**§ 1.** Egzekucja z ułamkowej części rzeczy ruchomej będącej 
wspólną własnością kilku osób odbywa się w sposób przewidziany dla egzekucji 
z ruchomości, z zastrzeżeniem, że sprzedaży podlega tylko udział dłużnika. 
**§ 2.** Innym współwłaścicielom przysługuje łącznie prawo żądania, aby cała 
rzecz została sprzedana.

***
## Art. 847. {#kpc-trzecia--art-847}

**§ 1.** Komornik dokonuje zajęcia przez wpisanie ruchomości do 
protokołu zajęcia. Odpis protokołu zajęcia należy doręczyć dłużnikowi 
i współwłaścicielom zajętej ruchomości, którzy nie są dłużnikami, jak również 
wierzycielowi, który nie był obecny przy zajęciu. 
**§ 2.** Dłużnik, pod rygorem odpowiedzialności za szkodę, przy zajęciu, a jeżeli 
jest nieobecny – niezwłocznie po otrzymaniu odpisu protokołu zajęcia, wskazuje 
komornikowi ruchomości znajdujące się w jego władaniu, do których osobom 
trzecim przysługuje prawo żądania zwolnienia ich od egzekucji, z podaniem 
adresów tych osób, oraz powiadamia komornika o wcześniejszych zajęciach tej 
samej rzeczy dokonanych przez organy egzekucyjne, z podaniem daty tych zajęć 
i wysokości należności, na poczet których te zajęcia zostały dokonane. Komornik 
zawiadamia o zajęciu ruchomości osoby wskazane przez dłużnika.

***
## Art. 848. {#kpc-trzecia--art-848}

Zajęcie ma ten skutek, że rozporządzenie ruchomością dokonane po 
zajęciu nie ma wpływu na dalszy bieg postępowania, a postępowanie egzekucyjne 
z zajętej ruchomości może być prowadzone również przeciwko nabywcy. Przepis 
ten nie narusza przepisów o ochronie nabywcy w dobrej wierze.

***
## Art. 849. {#kpc-trzecia--art-849}

Jeżeli komornik przerywa zajęcie, powinien stosownie do 
okoliczności poczynić kroki zapobiegające usunięciu ruchomości jeszcze 
niezajętych. 

 
 
 
s. 414/580 
 
2025-09-08

***
## Art. 850. {#kpc-trzecia--art-850}

Wierzyciel może żądać, aby zajęcie nastąpiło w jego obecności. 
W tym wypadku komornik zawiadomi go o terminie, w którym zajęcie ma być 
dokonane. Jeżeli wierzyciel nie stawi się w wyznaczonym terminie, komornik 
dokona zajęcia w jego nieobecności. Jeżeli komornik bez zawiadomienia 
wierzyciela dokonał zajęcia w jego nieobecności, wierzyciel może żądać 
sprawdzenia zajęcia z jego udziałem.

***
## Art. 851. {#kpc-trzecia--art-851}

Jeżeli zajęte już ruchomości mają być zajęte na zaspokojenie innej 
jeszcze wierzytelności, komornik dokona nowego zajęcia przez zaznaczenie go 
w protokole pierwszego zajęcia. Wierzyciel może żądać, aby komornik sprawdził 
ruchomości, zajęte na podstawie protokołu; sprawdzenie to komornik stwierdzi 
w tym protokole.

***
## Art. 852. {#kpc-trzecia--art-852}

**§ 1.** Z zajętych pieniędzy komornik zaspokoi wierzycieli, a jeżeli 
nie wystarczają na zaspokojenie wszystkich wierzycieli, złoży je na rachunek 
depozytowy Ministra Finansów w celu podziału. 
**§ 2.** Złożenie na rachunek depozytowy Ministra Finansów nastąpi również 
wówczas, gdy zgłoszono zarzut, że osobie trzeciej przysługuje do zajętych 
pieniędzy prawo stanowiące przeszkodę do wydania ich wierzycielowi. Sąd 
postanowi wydać pieniądze wierzycielowi, jeżeli w ciągu miesiąca od złożenia ich 
na rachunek depozytowy Ministra Finansów nie będzie złożone orzeczenie 
właściwego sądu zwalniające od zajęcia lub wstrzymujące wydanie pieniędzy. 
**§ 3.** Na postanowienie sądu co do wydania pieniędzy przysługuje zażalenie. 
Postanowienie staje się wykonalne dopiero z chwilą uprawomocnienia się.

***
## Art. 853. {#kpc-trzecia--art-853}

**§ 1.** Jeżeli przepis szczególny nie stanowi inaczej, komornik, 
dokonując zajęcia, szacuje wartość zajętych ruchomości i oznacza ją w protokole 
zajęcia. 
**§ 2.** Zastrzeżenia do oszacowania wartości dokonanego przez komornika 
wnosi się komornikowi do protokołu przy zajęciu ruchomości, a gdyby nie było to 
możliwe – w terminie trzech dni od dnia doręczenia odpisu protokołu zajęcia. 
W razie wniesienia zastrzeżeń komornik zamieszcza w protokole zajęcia wzmiankę 
o ich treści i wyznacza biegłego. 

 
 
 
s. 415/580 
 
2025-09-08 
**§ 3.** O sposobie i terminie wniesienia zastrzeżeń do oszacowania wartości 
komornik poucza strony, dokonując zajęcia, a jeżeli zajęcia dokonano pod 
nieobecność strony – przy doręczeniu protokołu zajęcia. 
**§ 4.** Jeżeli komornik uzna, że w celu oszacowania wartości należy wezwać 
biegłego, albo wierzyciel lub dłużnik wniósł zastrzeżenia, oszacowania wartości 
dokonuje komornik na podstawie opinii biegłego przy samym zajęciu, a gdyby to 
nie było możliwe, w terminie późniejszym. Jeżeli wartość zajętej ruchomości 
według oceny komornika przekracza dwadzieścia pięć tysięcy złotych, komornik 
wzywa do oszacowania wartości biegłego. 
**§ 5.** Jeżeli oszacowanie wartości zajętych ruchomości następuje po 
sporządzeniu protokołu zajęcia, komornik dokonuje tego oszacowania w drodze 
postanowienia.

***
## Art. 854. {#kpc-trzecia--art-854}

Na każdej zajętej ruchomości komornik umieści znak ujawniający 
na zewnątrz jej zajęcie, a jeżeli to nie jest możliwe, ujawni je w inny sposób.

***
## Art. 855. {#kpc-trzecia--art-855}

**§ 1.** Zajęte ruchomości komornik pozostawia pod dozorem osoby, 
u której je zajął. Jedynie z ważnych przyczyn komornik może, w każdym stanie 
postępowania, oddać zajęte ruchomości pod dozór innej osobie, nie wyłączając 
wierzyciela, choćby to było połączone z koniecznością ich przeniesienia. Osoba ta 
pełni obowiązki dozorcy. Komornik doręcza jej protokół zajęcia. Dozorcą nie może 
być komornik ani osoba przez niego zatrudniona, ich małżonkowie, dzieci, rodzice 
ani rodzeństwo. Komornik nie może nawet z ważnych przyczyn odebrać dozoru, 
jeżeli koszty przeniesienia lub przechowywania rzeczy byłyby niewspółmiernie 
wysokie w stosunku do jej wartości. 
**§ 11.** Odebranie 
dozoru 
następuje 
w drodze 
postanowienia, 
którego 
uzasadnienie zawiera w szczególności wskazanie przyczyn odebrania dozoru. 
**§ 12.** O odebraniu dozoru komornik niezwłocznie zawiadamia sąd właściwy 
ze względu na siedzibę kancelarii komornika, przesyłając odpis postanowienia, 
o którym mowa w § 11, oraz nośnik zawierający nagranie z przebiegu czynności. 
**§ 13.** W razie uchylenia postanowienia, o którym mowa w § 11, sąd może 
obciążyć komornika kosztami związanymi z nieuzasadnionym odebraniem dozoru. 
W takim przypadku sumę wydatków i wysokość wynagrodzenia ustala 
postanowieniem sąd. 

 
 
 
s. 416/580 
 
2025-09-08 
**§ 14.** W przypadkach uzasadniających odebranie dozoru, komornik może 
przejąć pod osobisty dozór drobne ruchomości należące do dłużnika. W takim 
przypadku przepisu art. 858 nie stosuje się. Zajęte przedmioty przechowywane są 
w kancelarii komornika. Na polecenie sądu albo zgodne wezwanie obu stron 
komornik obowiązany jest wydać ruchomości uprawnionemu. 
**§ 2.** Jeżeli właściwości zajętych ruchomości za tym przemawiają, komornik 
składa je do depozytu sądowego albo oddaje na przechowanie właściwej instytucji. 
**§ 3.** Minister Sprawiedliwości określi, w drodze rozporządzenia, właściwe 
instytucje oraz szczegółowy sposób składania ruchomości do depozytu sądowego 
albo oddawania na przechowanie właściwym instytucjom, mając na względzie 
właściwości tych ruchomości, ochronę praw stron, sprawność postępowania 
i skuteczność egzekucji.

***
## Art. 856. {#kpc-trzecia--art-856}

**§ 1.** Dozorca lub dłużnik, któremu powierzono dozór, obowiązani 
są przechowywać oddane im pod dozór ruchomości z taką starannością, aby nie 
straciły na wartości, i oddać je na wezwanie komornika lub stosownie do orzeczenia 
sądu albo na zgodne wezwanie obu stron. Jeżeli dozorca lub dłużnik zobowiązany 
do wydania ruchomości ich nie oddaje, komornik mu je odbiera. 
**§ 2.** Dozorca obowiązany jest zawiadomić komornika o zamierzonej zmianie 
miejsca przechowania ruchomości.

***
## Art. 857. {#kpc-trzecia--art-857}

**§ 1.** Dozorca nie odpowiada za pogorszenie, uszkodzenie, 
zniszczenie lub zaginięcie zajętych ruchomości, jeżeli zachował staranność, do 
jakiej był obowiązany w myśl przepisu artykułu poprzedzającego. 
**§ 2.** Dłużnikowi nie przysługuje roszczenie do wierzyciela z powodu 
uszkodzenia lub zaginięcia zajętych ruchomości podczas ich przewożenia, 
przesyłki lub przechowywania u dozorcy.

***
## Art. 858. {#kpc-trzecia--art-858}

**§ 1.** Dozorca może żądać zwrotu wydatków związanych 
z przechowywaniem oraz wynagrodzenia za dozór odpowiednio do poniesionych 
trudów. Nie dotyczy to dłużnika, członków jego rodziny wspólnie z nim 
mieszkających oraz osoby trzeciej, u której rzecz zajęto. 
**§ 2.** Sumę wydatków i wysokość wynagrodzenia ustala komornik, o czym 
zawiadamia strony i dozorcę. 

 
 
 
s. 417/580 
 
2025-09-08

***
## Art. 859. {#kpc-trzecia--art-859}

Na postanowienie sądu co do zwrotu wydatków i wynagrodzenia 
dozorcy przysługuje zażalenie.

***
## Art. 860. {#kpc-trzecia--art-860}

Komornik może z ważnych przyczyn zwolnić dozorcę i ustanowić 
innego. Zmianę dozorcy komornik zarządzi po wysłuchaniu stron, chyba że 
natychmiastowa zmiana jest konieczna.

***
## Art. 861. {#kpc-trzecia--art-861}

Jeżeli 
zajęte 
ruchomości 
pozostawiono 
w pomieszczeniu 
należącym do dłużnika i dozór powierzono jemu samemu lub członkowi jego 
rodziny razem z nim mieszkającemu, mają oni prawo zwykłego używania rzeczy, 
byleby przez to rzecz nie straciła na wartości. Również osoba trzecia, pod której 
dozorem komornik pozostawił zajęte u niej ruchomości dłużnika, może ich używać, 
jeżeli jest do tego uprawniona.

***
## Art. 862. {#kpc-trzecia--art-862}

**§ 1.** Jeżeli rzecz oddana pod dozór osobie nieuprawnionej do 
korzystania z niej przynosi dochód, dozorca obowiązany jest po ustaniu dozoru 
złożyć komornikowi rachunek z dochodów. Czysty dochód po potrąceniu 
wydatków zostanie złożony na rachunek depozytowy Ministra Finansów. 
**§ 2.** Z uzyskanego w ten sposób dochodu pokrywa się przede wszystkim 
wynagrodzenie dozorcy, resztę zaś dołącza się do sumy uzyskanej z egzekucji, 
a w razie umorzenia egzekucji, wypłaca się dłużnikowi.

***
## Art. 863. {#kpc-trzecia--art-863}

Minister 
Sprawiedliwości 
może, 
w drodze 
rozporządzenia, 
zarządzić 
utrzymywanie 
osobnych 
pomieszczeń 
do 
przechowywania 
i dozorowania zajętych ruchomości, mając na względzie sprawne prowadzenie 
egzekucji oraz właściwe zabezpieczenie zajętych ruchomości. 
Rozdział 2 
Sprzedaż

***
## Art. 864. {#kpc-trzecia--art-864}

**§ 1.** Sprzedaż zajętych ruchomości nie może nastąpić wcześniej niż 
po upływie dwóch tygodni od dnia uprawomocnienia się zajęcia. 
**§ 2.** Sprzedaż zajętych ruchomości może nastąpić bezpośrednio po zajęciu, 
jeżeli: 
- 1) ruchomości ulegają łatwo zepsuciu albo sprawowanie nad nimi dozoru lub ich 
przechowywanie powodowałoby nadmierne koszty; 
- 2) zajęto inwentarz żywy, a dłużnik odmówił zgody na przyjęcie go pod dozór. 

 
 
 
s. 418/580 
 
2025-09-08

***
## Art. 8641. {#kpc-trzecia--art-8641}

Komornik może sprzedać ruchomości z wolnej ręki, jeżeli dłużnik 
wyraził na to zgodę i określił minimalną cenę zbycia. Sprzedaż może nastąpić, 
jeżeli żaden z wierzycieli prowadzących egzekucję nie sprzeciwił się jej w terminie 
tygodnia, a w przypadku ruchomości wymienionych w art. 864 § 2 – w terminie 
trzech dni, od dnia zawiadomienia go przez komornika o zamiarze jej 
przeprowadzenia i minimalnej cenie zbycia określonej przez dłużnika.

***
## Art. 865. {#kpc-trzecia--art-865}

**§ 1.** Zajęte ruchomości nieużywane, stanowiące przedmiot obrotu 
handlowego, komornik na wniosek strony może sprzedać przedsiębiorcy 
prowadzącemu obrót takimi ruchomościami po cenach hurtowych, a gdy takie ceny 
nie zostaną udokumentowane, po cenach o 25 % niższych od wartości szacunkowej 
ruchomości. 
**§ 2.** (uchylony) 
**§ 3.** (uchylony)

***
## Art. 866. {#kpc-trzecia--art-866}

(uchylony)

***
## Art. 8661. {#kpc-trzecia--art-8661}

Zajęte ruchomości, których sprzedaż wymaga zezwolenia, 
komornik sprzeda za pośrednictwem przedsiębiorstwa posiadającego takie 
zezwolenie albo sprzeda je temu przedsiębiorstwu. Do wyceny ruchomości przepis 
art. 865 stosuje się odpowiednio.

***
## Art. 8662. {#kpc-trzecia--art-8662}

**§ 1.** Do oszacowania zajętych przedmiotów o wartości historycznej 
lub artystycznej komornik wzywa biegłego. Przedmioty te mogą być sprzedane za 
pośrednictwem przedsiębiorstwa zajmującego się ich obrotem albo państwowemu 
muzeum, bibliotece, archiwum lub ośrodkowi badań i dokumentacji. Przepis 
art. 8641 stosuje się odpowiednio. 
**§ 2.** Do oszacowania wyrobów ze złota i platyny komornik powołuje 
biegłego. Wyroby ze złota i platyny, z wyjątkiem przedmiotów użytkowych, oraz 
przedmioty ze złota lub platyny niezdatne do użytku komornik sprzedaje 
przedsiębiorstwu jubilerskiemu lub innemu zajmującemu się obrotem lub 
przerobem metali szlachetnych. Przepis art. 865 stosuje się odpowiednio. 
**§ 3.** Zajęte waluty obce komornik sprzedaje bankowi. Komornik wyznacza 
dłużnikowi tygodniowy termin do wskazania banku. Po bezskutecznym upływie 
wyznaczonego terminu komornik wzywa wierzyciela do wskazania banku 
w terminie tygodniowym. Jeżeli dłużnik albo wierzyciel nie wskażą banku, 

 
 
 
s. 419/580 
 
2025-09-08 
 
wskazanie banku należy do komornika. Bankiem wskazanym przez wierzyciela 
albo komornika nie może być wierzyciel. 
**§ 4.** Przepisu § 3 nie stosuje się, jeżeli tytuł wykonawczy obejmuje 
świadczenie pieniężne podlegające spełnieniu wyłącznie w walucie obcej, która 
została zajęta.

***
## Art. 867. {#kpc-trzecia--art-867}

**§ 1.** Zajęte 
ruchomości, 
niesprzedane 
według 
przepisów 
poprzedzających, z wyłączeniem przypadku, o którym mowa w art. 8661, 
komornik sprzedaje w drodze licytacji publicznej. 
**§ 11.** Obwieszczenie o licytacji zamieszcza się na tablicy ogłoszeń w budynku 
sądu rejonowego właściwego dla miejsca licytacji oraz na stronie internetowej 
Krajowej Rady Komorniczej. Jeżeli wartość ruchomości, objętych jednym 
obwieszczeniem o licytacji, została oszacowana na kwotę wyższą niż pięć tysięcy 
złotych, komornik może zamieścić obwieszczenie o licytacji także w dzienniku lub 
czasopiśmie poczytnym w danej miejscowości. Obwieszczenie o licytacji doręcza 
się stronom i dozorcy zajętych ruchomości. 
**§ 12.** W obwieszczeniu o licytacji komornik określa czas, miejsce, przedmiot 
oraz warunki licytacji, sumę oszacowania i cenę wywołania oraz miejsce i czas, 
w których można oglądać ruchomości. Ponadto w obwieszczeniu o licytacji 
zamieszcza się wzmiankę, że prawa osób trzecich nie będą przeszkodą do 
przeprowadzenia licytacji i przybicia na rzecz nabywcy bez zastrzeżeń, jeżeli osoby 
te przed rozpoczęciem przetargu nie złożą dowodu, że wniosły powództwo o 
zwolnienie ruchomości od egzekucji i uzyskały w tym zakresie orzeczenie 
wstrzymujące egzekucję. 
**§ 13.** Jeżeli na licytację została wystawiona znaczna liczba ruchomości, 
w obwieszczeniu o licytacji wystarczy ogólnie podać ich rodzaj, liczbę i łączną 
sumę oszacowania, a ponadto wskazać rodzaj, sumę oszacowania i cenę wywołania 
przedmiotów o większej wartości. 
**§ 14.** W razie możliwości ogłasza się jedno obwieszczenie o licytacjach 
ruchomości, choćby należały one do różnych dłużników i różne były terminy 
licytacji. Koszty ogłoszenia rozkłada się pomiędzy poszczególne sprawy 
proporcjonalnie do sum oszacowania ruchomości. 
**§ 15.** Podmiot obowiązany do udostępnienia obwieszczenia usuwa je 
niezwłocznie po upływie wskazanego w obwieszczeniu terminu licytacji. 

 
 
 
s. 420/580 
 
2025-09-08 
**§ 2.** Cena wywołania w pierwszym terminie licytacji publicznej wynosi trzy 
czwarte wartości szacunkowej. Jeżeli licytacja w pierwszym terminie nie dojdzie 
do skutku, zajęte ruchomości mogą być sprzedane w drugim terminie licytacyjnym. 
Cena wywołania w drugim terminie licytacyjnym wynosi połowę wartości 
szacunkowej. Sprzedaż licytacyjna nie może nastąpić za cenę niższą od ceny 
wywołania. 
**§ 3.** Obwieszczenie o licytacji komornik doręcza dłużnikowi najpóźniej na 
tydzień 
przed 
rozpoczęciem 
licytacji. 
W przypadkach 
określonych 
w art. 864 § 2 obwieszczenie to doręcza się dłużnikowi przed rozpoczęciem 
licytacji. 
**§ 4.** (uchylony) 
**§ 5.** (uchylony)

***
## Art. 8671. {#kpc-trzecia--art-8671}

**§ 1.** Przystępujący do przetargu jest obowiązany złożyć rękojmię 
w wysokości 
jednej 
dziesiątej 
sumy 
oszacowania, 
najpóźniej 
w dniu 
poprzedzającym przetarg. Rękojmi nie składa się, jeżeli suma oszacowania jest 
niższa niż pięć tysięcy złotych. 
**§ 2.** Rękojmię złożoną przez licytanta, któremu udzielono przybicia, 
zatrzymuje się; pozostałym licytantom rękojmię zwraca się niezwłocznie. 
**§ 3.** Jeżeli nabywca nie wykonał w terminie warunków licytacji co do zapłaty 
ceny, traci rękojmię, a skutki przybicia wygasają. Z utraconej rękojmi pokrywa się 
koszty egzekucji związanej ze sprzedażą, a reszta wchodzi w skład sumy uzyskanej 
w egzekucji albo jeżeli egzekucja została umorzona jest przelewana na dochód 
Skarbu Państwa. 
**§ 4.** Rękojmi nie składa wierzyciel przystępujący do przetargu, któremu 
przysługuje wierzytelność o wartości nie niższej od wysokości rękojmi i jeżeli do 
tej wysokości jego wierzytelność oraz prawa korzystające z pierwszeństwa przed 
tą wierzytelnością znajdują pokrycie w cenie wywołania. Jeżeli wartość 
wierzytelności jest niższa od wysokości rękojmi albo znajduje tylko częściowe 
pokrycie w cenie wywołania, wysokość rękojmi obniża się – w pierwszym 
przypadku do różnicy między pełną rękojmią a wartością wierzytelności, w drugim 
przypadku – do części wartości wierzytelności niepokrytej w cenie wywołania.

***
## Art. 8672. {#kpc-trzecia--art-8672}

**§ 1.** Licytacja odbywa się publicznie. 

 
 
 
s. 421/580 
 
2025-09-08 
**§ 2.** W przetargu 
nie 
mogą 
uczestniczyć: 
dłużnik, 
komornik, 
ich 
małżonkowie, dzieci, rodzice i rodzeństwo, osoby obecne na licytacji 
w charakterze urzędowym oraz licytant, który nie wykonał warunków poprzedniej 
licytacji. 
**§ 3.** Stawienie się jednego licytanta wystarcza do odbycia przetargu. 
**§ 4.** Pełnomocnictwo do udziału w przetargu powinno być stwierdzone 
dokumentem 
z podpisem 
urzędowo 
poświadczonym, 
chyba 
że 
chodzi 
o pełnomocnictwo udzielone adwokatowi lub radcy prawnemu.

***
## Art. 8673. {#kpc-trzecia--art-8673}

**§ 1.** Postąpienie nie może wynosić mniej niż pięć procent ceny 
wywołania, a jeżeli wartość szacunkowa ruchomości przekracza sto tysięcy złotych 
mniej niż jeden procent ceny wywołania, z zaokrągleniem wzwyż do pełnych 
złotych. 
**§ 2.** Zaofiarowana cena przestaje wiązać, gdy inny licytant zaofiarował cenę 
wyższą.

***
## Art. 868. {#kpc-trzecia--art-868}

Minister Sprawiedliwości określi, w drodze rozporządzenia, sposób 
przeprowadzenia licytacji, mając na względzie ochronę praw osób uczestniczących 
w licytacji, sprawność postępowania oraz skuteczność egzekucji.

***
## Art. 869. {#kpc-trzecia--art-869}

**§ 1.** Komornik udzieli przybicia osobie ofiarującej najwyższą cenę, 
jeżeli po trzykrotnym wezwaniu do dalszych postąpień nikt więcej nie zaofiarował. 
**§ 2.** Z chwilą przybicia dochodzi do skutku sprzedaż ruchomości na rzecz 
nabywcy. Od tego czasu należą do niego pożytki ruchomości.

***
## Art. 870. {#kpc-trzecia--art-870}

**§ 1.** Wierzyciel lub dłużnik mogą zaskarżyć udzielenie przybicia 
w razie naruszenia przepisów o publicznym charakterze licytacji, o najniższej cenie 
nabycia i o wyłączeniu od udziału w przetargu. Skarga powinna być zgłoszona do 
protokołu licytacji. Nie ma skargi na udzielenie przybicia ruchomości ulegających 
szybkiemu zepsuciu. 
**§ 2.** Na postanowienie sądu przysługuje zażalenie. 
**§ 3.** Jeżeli w ciągu dwóch tygodni skarga nie zostanie rozstrzygnięta, 
nabywca może w ciągu dalszego tygodnia zrzec się nabycia ruchomości i odebrać 
zapłaconą sumę. 

 
 
 
s. 422/580 
 
2025-09-08 
**§ 4.** Gdy nabywca skorzysta z uprawnienia przewidzianego w paragrafie 
poprzedzającym albo gdy sąd odmówi przybicia, licytacja będzie uznana za 
niedoszłą do skutku.

***
## Art. 871. {#kpc-trzecia--art-871}

Nabywca jest obowiązany zapłacić cenę nabycia natychmiast po 
udzieleniu mu przybicia. Gdy jednak cena nabycia przewyższa pięćset złotych, 
obowiązek nabywcy ogranicza się do złożenia natychmiast jednej piątej ceny, nie 
mniej jednak niż pięćset złotych, przy czym resztę ceny, na którą zalicza się złożoną 
rękojmię, uiszcza się w dniu następnym w godzinach urzędowania kancelarii 
komorniczej lub na rachunek bankowy komornika do godziny osiemnastej dnia 
następnego. Jeżeli ten dzień przypada w sobotę lub dzień ustawowo wolny od 
pracy, cenę uiszcza się w następnym dniu po dniu albo dniach wolnych od pracy.

***
## Art. 872. {#kpc-trzecia--art-872}

**§ 1.** Nabywca, który w przepisanym terminie nie uiści ceny 
w całości lub części, traci prawa wynikające z przybicia. 
**§ 2.** Jeżeli nabywca nie uiści w terminie sumy przypadającej do zapłaty 
natychmiast przy udzieleniu przybicia, komornik wznowi niezwłocznie przetarg 
tych samych ruchomości, rozpoczynając od ceny wywołania, przy czym opieszały 
nabywca nie może nadal uczestniczyć w licytacji. W razie niezapłacenia w terminie 
reszty ceny płatnej dnia następnego po licytacji, będzie wyznaczona ponowna 
licytacja na warunkach pierwszej. 
**§ 3.** Od nabywcy zwolnionego z obowiązku wpłacenia rękojmi, który nie 
dopełnił obowiązku zapłaty ceny lub jej części w przepisanym terminie, komornik 
ściąga sumę odpowiadającą jednej dziesiątej sumy oszacowania. Na sumę ściąganą 
przez komornika zalicza się kwoty wpłacone przez nabywcę. 
**§ 4.** Z sumy ściągniętej od nabywcy pokrywa się koszty związane z licytacją. 
Nadwyżkę należy wpłacić do kasy sądowej na rzecz Skarbu Państwa.

***
## Art. 873. {#kpc-trzecia--art-873}

O ściągnięciu 
od 
nabywcy 
należności 
według 
artykułu 
poprzedzającego orzeka sąd. Na postanowienie sądu przysługuje zażalenie.

***
## Art. 874. {#kpc-trzecia--art-874}

Nabywca po uprawomocnieniu się przybicia i zapłaceniu całej ceny 
staje się właścicielem nabytych ruchomości. Gdy sąd odmówi przybicia, wypłacona 
cena nabycia ulega zwrotowi.

***
## Art. 875. {#kpc-trzecia--art-875}

**§ 1.** Jeżeli licytacja nie doszła do skutku, wierzyciel może w ciągu 
dwóch tygodni od otrzymania zawiadomienia komornika żądać wyznaczenia 

 
 
 
s. 423/580 
 
2025-09-08 
 
drugiej licytacji lub przejąć na własność ruchomości wystawione na sprzedaż albo 
niektóre z nich w cenie nie niższej od ceny wywołania. 
**§ 2.** Jeżeli egzekucję prowadzi kilku wierzycieli, pierwszeństwo przejęcia 
ruchomości na własność przysługuje temu z nich, który ofiarował najwyższą cenę, 
przy równej zaś cenie – temu, na którego żądanie wcześniej dokonano zajęcia. 
**§ 3.** Oświadczenie o przejęciu będzie uwzględnione tylko wtedy, gdy 
wierzyciel jednocześnie z wnioskiem złoży całą cenę. Własność ruchomości 
przechodzi na wierzyciela z chwilą zawiadomienia go o przyznaniu mu przejętej 
rzeczy. 
**§ 4.** W razie niezgłoszenia w przepisanym terminie wniosku o wyznaczenie 
drugiej licytacji lub oświadczenia o przejęciu ruchomości na własność, komornik 
umorzy postępowanie co do niesprzedanych ruchomości. Jeżeli spomiędzy kilku 
wierzycieli jedni żądają licytacji, a inni przejęcia ruchomości na własność, 
wyznaczona będzie druga licytacja.

***
## Art. 876. {#kpc-trzecia--art-876}

Jeżeli nabywca jest jedynym wierzycielem egzekwującym albo 
jeżeli cena nabycia wystarcza na zaspokojenie wszystkich wierzycieli 
egzekwujących i kosztów egzekucji, nabywca może zaliczyć swoją egzekwowaną 
wierzytelność na cenę nabycia.

***
## Art. 877. {#kpc-trzecia--art-877}

Jeżeli druga licytacja nie doszła do skutku, wierzycielowi w ciągu 
dwóch tygodni od otrzymania zawiadomienia komornika przysługuje prawo 
przejęcia ruchomości na własność za cenę nie niższą od ceny wywołania. W tym 
wypadku stosuje się odpowiednio przepis art. 875 § 2. Jeżeli wierzyciel nie 
skorzystał z prawa przejęcia ruchomości na własność, komornik umorzy 
postępowanie co do rzeczy niesprzedanej lub nieprzejętej na własność.

***
## Art. 878. {#kpc-trzecia--art-878}

Jeżeli dłużnik lub dozorca odmawia wydania rzeczy nabywcy, 
komornik na wniosek nabywcy postąpi jak przy egzekucji roszczeń niepieniężnych.

***
## Art. 879. {#kpc-trzecia--art-879}

Kto nabywa rzecz na podstawie przepisów niniejszego rozdziału, 
staje się jej właścicielem bez żadnych obciążeń i powinien ją natychmiast odebrać. 
Nabywcy nie przysługują roszczenia z tytułu rękojmi za wady rzeczy; przeciwko 
nabywcy nie można podnosić zarzutów co do ważności nabycia. 

 
 
 
s. 424/580 
 
2025-09-08 
 
Rozdział 3 
Sprzedaż w drodze licytacji elektronicznej

***
## Art. 8791. {#kpc-trzecia--art-8791}

Do sprzedaży w drodze licytacji elektronicznej stosuje się przepisy 
rozdziału 2 z odrębnościami wynikającymi z niniejszego rozdziału.

***
## Art. 8792. {#kpc-trzecia--art-8792}

**§ 1.** Komornik 
dokonuje 
sprzedaży 
w drodze 
licytacji 
elektronicznej na wniosek wierzyciela złożony po dokonaniu zajęcia. Jeżeli 
ruchomość została zajęta na zaspokojenie kilku wierzytelności dochodzonych 
w różnych 
postępowaniach, 
sprzedaży 
ruchomości 
w drodze 
licytacji 
elektronicznej dokonuje się, jeżeli zażądał tego którykolwiek z wierzycieli. 
**§ 2.** W razie złożenia wniosku komornik oddaje zajęte ruchomości, co do 
których zajęcie uprawomocniło się, pod dozór innej osobie niż dłużnik, chyba że 
dłużnik daje rękojmię należytego sprawowania dozoru albo dozór taki został już 
ustanowiony, albo ruchomość została złożona do depozytu sądowego lub oddana 
na przechowanie właściwej instytucji. Przepisu art. 855 § 12 nie stosuje się. 
W przypadku odebrania dozoru, początek licytacji nie może przypadać wcześniej 
niż po upływie dwóch tygodni od dnia odebrania dozoru.

***
## Art. 8793. {#kpc-trzecia--art-8793}

Wniosek o dokonanie sprzedaży w drodze licytacji elektronicznej 
składa się przed wyznaczeniem terminu licytacji lub wraz z wnioskiem 
o wyznaczenie drugiej licytacji.

***
## Art. 8794. {#kpc-trzecia--art-8794}

**§ 1.** Sprzedaż w drodze licytacji elektronicznej jest dokonywana za 
pośrednictwem systemu teleinformatycznego. 
**§ 2.** Obwieszczenie o sprzedaży ruchomości w drodze licytacji elektronicznej 
zamieszcza się na stronie internetowej Krajowej Rady Komorniczej co najmniej 
tydzień przed terminem licytacji, a w przypadku rzeczy określonych w art. 864 § 2 
w terminie 3 dni przed terminem licytacji. Przepisów art. 867 § 11 i 12 nie stosuje 
się. 
**§ 3.** W obwieszczeniu 
o sprzedaży 
ruchomości 
w drodze 
licytacji 
elektronicznej wskazuje się przedmiot oraz warunki licytacji, sumę oszacowania 
i cenę wywołania oraz miejsce i czas, w których można oglądać ruchomość, 
a ponadto zdjęcie lub zdjęcia ruchomości podlegającej sprzedaży, informację 
o chwili rozpoczęcia i o chwili zakończenia licytacji oraz informację o tym, że 
warunkiem udziału w licytacji jest złożenie rękojmi. W obwieszczeniu o licytacji 

 
 
 
s. 425/580 
 
2025-09-08 
 
elektronicznej zamieszcza się wzmiankę, że prawa osób trzecich nie będą 
przeszkodą do przeprowadzenia licytacji i przybicia na rzecz nabywcy bez 
zastrzeżeń, jeżeli osoby te przed rozpoczęciem przetargu nie złożą dowodu, że 
wniosły powództwo o zwolnienie ruchomości od egzekucji i uzyskały w tym 
zakresie orzeczenie wstrzymujące egzekucję. W obwieszczeniu o licytacji 
elektronicznej komornik poucza o treści art. 8795, art. 8796 § 1 i 21, art. 8797 § 3 
i art. 8799. 
**§ 4.** (uchylony) 
**§ 5.** Krajowa 
Rada 
Komornicza 
usuwa 
obwieszczenie 
o sprzedaży 
ruchomości w drodze licytacji elektronicznej z upływem dnia zakończenia 
przetargu. 
**§ 6.** Doręczając dłużnikowi i wierzycielowi 
obwieszczenie o licytacji 
komornik poucza o treści art. 8797 § 1 i 3.

***
## Art. 8795. {#kpc-trzecia--art-8795}

**§ 1.** Rękojmię należy złożyć na rachunek bankowy komornika 
najpóźniej na 2 dni robocze przed rozpoczęciem przetargu. Za datę złożenia 
rękojmi przyjmuje się dzień uznania rachunku bankowego komornika. Przepisu 
art. 8671 § 4 nie stosuje się. 
**§ 2.** Przed przystąpieniem do licytacji licytant obowiązany jest do podania 
w systemie teleinformatycznym danych niezbędnych do wydania postanowienia 
o przybiciu: numeru PESEL, numeru dokumentu stwierdzającego tożsamość 
i oświadczenia, czy pozostaje w związku małżeńskim, a jeżeli tak, czy ruchomość 
zamierza nabyć do majątku wspólnego czy osobistego, oraz do wskazania, czy 
licytuje we własnym imieniu czy jako pełnomocnik innej osoby, a także innych 
danych, jeżeli potrzeba ich podania wynika z przepisów odrębnych ustaw. Jeżeli 
licytant bierze udział w licytacji jako pełnomocnik innej osoby, powinien zgłosić 
ten fakt najpóźniej na 5 dni przed terminem licytacji. 
**§ 3.** W razie potrzeby komornik niezwłocznie wzywa licytanta, pod rygorem 
niedopuszczenia do udziału w przetargu, do uzupełnienia danych, o których mowa 
w § 2, lub do złożenia rękojmi. Jeżeli licytant występuje w imieniu innej osoby 
wzywa się go, pod rygorem niedopuszczenia do udziału w przetargu, do 
przedłożenia utrwalonej w postaci elektronicznej kopii pełnomocnictwa w terminie 
3 dni, nie później niż dzień przed terminem licytacji. Wezwania dokonuje się za 
pośrednictwem systemu teleinformatycznego. 

 
 
 
s. 426/580 
 
2025-09-08 
**§ 4.** Licytant, który licytuje we własnym imieniu i nie ma obowiązku złożenia 
rękojmi, może przystąpić do przetargu aż do momentu jego zakończenia. 
**§ 5.** Komornik potwierdza fakt złożenia rękojmi, podania danych lub złożenia 
dokumentów, o których mowa w § 2 i 3, niezwłocznie po ich otrzymaniu, poprzez 
dopuszczenie licytanta do udziału w przetargu. O odmowie dopuszczenia do 
przetargu zawiadamia się zainteresowanego za pośrednictwem systemu 
teleinformatycznego.

***
## Art. 8796. {#kpc-trzecia--art-8796}

**§ 1.** Przetarg w drodze elektronicznej rozpoczyna się z chwilą 
określoną w obwieszczeniu o licytacji elektronicznej i kończy się w chwili 
wyznaczonej przez komornika. 
**§ 2.** Komornik wyznacza licytację elektroniczną w taki sposób, aby zarówno 
termin rozpoczęcia, jak i zakończenia przetargu przypadał pomiędzy godziną 9.00 
a 14.00 w dni robocze. Czas trwania przetargu wynosi 7 dni. W przypadku 
ruchomości wymienionych w art. 864 § 2 czas trwania przetargu można skrócić do 
co najmniej dwóch dni, z zachowaniem warunków, o których mowa w zdaniu 
pierwszym. 
**§ 21.** Jeżeli w ciągu 5 minut przed planowanym terminem zakończenia 
przetargu zgłoszono postąpienie, termin ten ulega odroczeniu o 5 minut. Jeżeli 
w dodatkowym czasie zgłoszono dalsze postąpienie, termin zakończenia przetargu 
podlega każdorazowo odroczeniu o kolejne 5 minut, aż do momentu gdy ustaną 
postąpienia. 
**§ 3.** Komornik natychmiast po zakończeniu licytacji elektronicznej udziela 
przybicia osobie ofiarującej najwyższą cenę w chwili zakończenia licytacji 
elektronicznej. Jeżeli jednak do udzielenia przybicia niezbędne jest przedłożenie 
oryginału pełnomocnictwa do udziału w przetargu, przybicie następuje 
niezwłocznie po jego złożeniu, o czym należy poinformować uczestników 
przetargu przez obwieszczenie w systemie teleinformatycznym. Przybicie jest 
udzielane w systemie teleinformatycznym. 
**§ 4.** Komornik wstrzyma się z udzieleniem przybicia do czasu przedłożenia 
oryginału pełnomocnictwa do udziału w przetargu. W takim przypadku komornik 
obwieszcza o tym fakcie w systemie teleinformatycznym niezwłocznie po 
zakończeniu licytacji, wzywając jednocześnie licytanta za pośrednictwem systemu 

 
 
 
s. 427/580 
 
2025-09-08 
 
teleinformatycznego do przedłożenia oryginału pełnomocnictwa w terminie 3 dni, 
pod rygorem odmowy udzielenia przybicia.

***
## Art. 8797. {#kpc-trzecia--art-8797}

**§ 1.** O fakcie udzielenia przybicia obwieszcza się w systemie 
teleinformatycznym niezwłocznie po jego udzieleniu, przy czym dane nabywcy nie 
podlegają ujawnieniu. Zawiadomienie o przybiciu doręcza się nabywcy za 
pośrednictwem systemu teleinformatycznego. 
**§ 2.** Osoby, których nie dopuszczono do przetargu, mogą złożyć skargę 
w terminie 3 dni od dnia odmowy dopuszczenia do przetargu, a licytanci mogą 
złożyć skargę na przebieg przetargu w terminie 3 dni od dnia jego zakończenia. 
Skargę składa się wyłącznie za pośrednictwem systemu teleinformatycznego. 
**§ 3.** Wierzyciel lub dłużnik mogą złożyć skargę na udzielenie przybicia 
w razie naruszenia przepisów o najniższej cenie nabycia, o przebiegu przetargu lub 
o wyłączeniu od udziału w przetargu – w terminie 3 dni od dnia obwieszczenia 
o udzieleniu przybicia w systemie teleinformatycznym. Skargę można złożyć za 
pośrednictwem systemu teleinformatycznego, o ile skarżący posiada w tym 
systemie konto. 
**§ 4.** W razie nieuwzględnienia skargi komornik niezwłocznie po jej 
wniesieniu przekazuje sądowi poświadczony przez siebie odpis skargi, wraz 
z protokołem z przebiegu przetargu lub innymi dokumentami niezbędnymi do jej 
rozpoznania.

***
## Art. 8798. {#kpc-trzecia--art-8798}

W razie wniesienia skargi, o której mowa w art. 8797 § 2 lub 3, 
termin dla nabywcy do zrzeczenia się nabycia ruchomości wynosi miesiąc od dnia 
zakończenia przetargu. Zrzeczenie dokonywane jest wyłącznie za pośrednictwem 
systemu teleinformatycznego.

***
## Art. 8799. {#kpc-trzecia--art-8799}

Nabywca jest obowiązany zapłacić cenę nabycia w dniu następnym 
po doręczeniu zawiadomienia o przybiciu w godzinach urzędowania kancelarii 
komorniczej lub na rachunek bankowy komornika do godziny osiemnastej dnia 
następnego. Jeżeli ten dzień przypada w sobotę lub dzień ustawowo wolny od 
pracy, cenę uiszcza się w następnym dniu po dniu albo dniach wolnych od pracy. 
Za datę zapłaty ceny nabycia przyjmuje się dzień uznania rachunku bankowego 
komornika. 

 
 
 
s. 428/580 
 
2025-09-08

***
## Art. 87910. {#kpc-trzecia--art-87910}

**§ 1.** W przypadkach, o których mowa w art. 865 § 1, art. 8661 
oraz art. 8662 § 1 i 2, wybór przedsiębiorcy lub przedsiębiorstwa może być 
dokonany na wniosek wierzyciela złożony za pośrednictwem systemu 
teleinformatycznego. 
**§ 2.** Komornik może sprzedać ruchomości, o których mowa w art. 864 § 2, 
oraz dokonać wyboru osoby, której sprzeda ruchomość, w trybie określonym 
w art. 8641, za pośrednictwem systemu teleinformatycznego.

***
## Art. 87911. {#kpc-trzecia--art-87911}

Minister Sprawiedliwości określi, w drodze rozporządzenia, 
sposób przeprowadzenia licytacji elektronicznej oraz sposób wykorzystania 
systemu teleinformatycznego obsługującego licytację elektroniczną do czynności, 
o których mowa w art. 87910, mając na względzie zapewnienie ochrony praw osób 
uczestniczących w licytacji, sprawność postępowania, skuteczność egzekucji, 
zapewnienie 
bezpieczeństwa 
posługiwania 
się 
dokumentami 
w postaci 
elektronicznej oraz dostępność systemu teleinformatycznego. 
#### DZIAŁ II
Egzekucja z wynagrodzenia za pracę

***
## Art. 880. {#kpc-trzecia--art-880}

Egzekucja z wynagrodzenia za pracę należy do komornika przy 
sądzie rejonowym ogólnej właściwości dłużnika.

***
## Art. 881. {#kpc-trzecia--art-881}

**§ 1.** Do egzekucji z wynagrodzenia za pracę komornik przystępuje 
przez jego zajęcie. 
**§ 2.** Komornik zawiadamia dłużnika, że do wysokości egzekwowanego 
świadczenia i aż do pełnego pokrycia długu nie wolno mu odbierać wynagrodzenia 
poza częścią wolną od zajęcia ani rozporządzać nim w żaden inny sposób. Dotyczy 
to w szczególności periodycznego wynagrodzenia za pracę i wynagrodzenia za 
prace zlecone oraz nagród i premii przysługujących dłużnikowi za okres jego 
zatrudnienia, jak również związanego ze stosunkiem pracy zysku lub udziału 
w funduszu zakładowym oraz wszelkich innych funduszach, pozostających 
w związku ze stosunkiem pracy. 
**§ 21.** Jeżeli egzekucja dotyczy świadczeń, o których mowa w art. 773 § 21, 
komornik zawiadamia pracodawcę o charakterze egzekwowanych świadczeń. 

 
 
 
s. 429/580 
 
2025-09-08 
**§ 3.** Komornik 
wzywa 
pracodawcę, 
aby 
w granicach 
określonych 
w paragrafie drugim nie wypłacał dłużnikowi poza częścią wolną od zajęcia 
żadnego wynagrodzenia, lecz: 
- 1) przekazywał 
zajęte 
wynagrodzenie 
bezpośrednio 
wierzycielowi 
egzekwującemu, zawiadamiając komornika o pierwszej wypłacie, albo 
- 2) przekazywał zajęte wynagrodzenie komornikowi w wypadku, gdy do 
wynagrodzenia 
jest 
lub 
zostanie 
w dalszym 
toku 
postępowania 
egzekucyjnego skierowana jeszcze inna egzekucja, a wynagrodzenie w części 
wymagalnej nie wystarcza na pokrycie wszystkich egzekwowanych 
świadczeń wymagalnych. 
Komornik poucza zarazem pracodawcę o skutkach niezastosowania się do 
wezwania. 
**§ 4.** Stosownie do okoliczności komornik może wezwać pracodawcę do 
przekazywania mu zajętego wynagrodzenia bezpośrednio.

***
## Art. 882. {#kpc-trzecia--art-882}

**§ 1.** Dokonując zajęcia wynagrodzenia za pracę, komornik wzywa 
ponadto pracodawcę, aby w ciągu tygodnia: 
- 1) przedstawił za okres trzech miesięcy poprzedzających zajęcie, za każdy 
miesiąc oddzielnie, zestawienie periodycznego wynagrodzenia dłużnika za 
pracę oraz oddzielnie jego dochodu z wszelkich innych tytułów; 
- 2) podał, w jakiej kwocie i w jakich terminach zajęte wynagrodzenie będzie 
przekazywane wierzycielowi; 
- 3) w razie istnienia przeszkód do wypłacenia wynagrodzenia za pracę złożył 
oświadczenie o rodzaju tych przeszkód, a w szczególności podał, czy inne 
osoby roszczą sobie prawa, czy i w jakim sądzie toczy się sprawa o zajęte 
wynagrodzenie i czy oraz o jakie roszczenia została skierowana do zajętego 
wynagrodzenia egzekucja przez innych wierzycieli. 
**§ 2.** Pracodawca obowiązany jest do niezwłocznego zawiadomienia 
komornika oraz wierzyciela o każdej zmianie okoliczności wymienionych w § 1.

***
## Art. 8821. {#kpc-trzecia--art-8821}

**§ 1.** W razie zbiegu egzekucji sądowej i administracyjnej, 
w przypadku gdy wynagrodzenie nie wystarcza na pokrycie wszystkich 
egzekwowanych należności, pracodawca dokonuje wypłat na rzecz sądowego albo 
administracyjnego organu egzekucyjnego, który pierwszy dokonał zajęcia, 

 
 
 
s. 430/580 
 
2025-09-08 
 
a w razie niemożności ustalenia tego pierwszeństwa – na rzecz organu, który 
dokonał zajęcia na poczet należności w wyższej kwocie, oraz niezwłocznie 
zawiadamia o zbiegu egzekucji właściwe organy egzekucyjne, wskazując datę 
doręczenia zawiadomień o zajęciach dokonanych przez te organy i wysokość 
należności, na poczet których zostały dokonane zajęcia, o czym komornik poucza 
pracodawcę, dokonując zajęcia. 
**§ 2.** W razie zbiegu egzekucji administracyjnej i sądowej świadczeń, 
o których mowa w art. 773 § 21, w przypadku gdy wynagrodzenie nie wystarcza na 
pokrycie wszystkich egzekwowanych należności, pracodawca dokonuje wypłat na 
rzecz sądowego organu egzekucyjnego, a zawiadamiając o zbiegu egzekucji 
właściwe organy egzekucyjne, wskazuje na charakter egzekwowanych świadczeń.

***
## Art. 883. {#kpc-trzecia--art-883}

**§ 1.** Zajęcie jest dokonane z chwilą doręczenia wezwania 
dłużnikowi zajętej wierzytelności. 
**§ 2.** Jednakże dłużnik może żądać umorzenia egzekucji co do świadczeń 
wymagalnych w przyszłości, jeżeli uiści wszystkie świadczenia wymagalne i złoży 
na rachunek depozytowy Ministra Finansów sumę równającą się sumie świadczeń 
periodycznych za sześć miesięcy, z równoczesnym umocowaniem komornika do 
podejmowania tej sumy. Komornik skorzysta z tego umocowania, gdy stwierdzi, 
że dłużnik popadł w zwłokę z uiszczeniem świadczeń wymagalnych; równocześnie 
wszczyna z urzędu egzekucję.

***
## Art. 884. {#kpc-trzecia--art-884}

**§ 1.** Zajęcie obowiązuje nadal, choćby po zajęciu nawiązano 
z dłużnikiem nowy stosunek pracy lub zlecenia albo choćby zakład pracy przeszedł 
na inną osobę, jeżeli osoba ta o zajęciu wiedziała. 
**§ 2.** W razie rozwiązania stosunku pracy z dłużnikiem dotychczasowy 
pracodawca czyni wzmiankę o zajęciu należności w wydanym dłużnikowi 
świadectwie pracy, a jeżeli nowy pracodawca dłużnika jest mu znany, przesyła 
temu pracodawcy zawiadomienie komornika i dokumenty dotyczące zajęcia 
wynagrodzenia oraz powiadamia o tym komornika i dłużnika, przeciwko któremu 
toczy się postępowanie egzekucyjne. Wzmianka w świadectwie pracy powinna 
zawierać oznaczenie komornika, który zajął należność, oraz numer sprawy 
egzekucyjnej, jak również wskazać wysokość potrąconych już kwot. Przesłanie 

 
 
 
s. 431/580 
 
2025-09-08 
 
zawiadomienia komornika ma skutki zajęcia należności dłużnika u nowego 
pracodawcy od chwili dojścia zawiadomienia do tego pracodawcy. 
**§ 3.** Nowy pracodawca, któremu pracownik przedstawi świadectwo pracy ze 
wzmianką 
o zajęciu 
należności, 
zawiadamia 
o zatrudnieniu 
pracownika 
pracodawcę, który wydał świadectwo, oraz wskazanego we wzmiance komornika. 
Jeżeli nowy pracodawca, któremu pracownik nie okazał świadectwa pracy, dowie 
się, gdzie pracownik był przedtem zatrudniony, obowiązany jest zawiadomić 
poprzedniego pracodawcę o jego zatrudnieniu, chyba że pracownik przedstawi 
zaświadczenie tego pracodawcy stwierdzające, że jego należności nie były zajęte. 
**§ 4.** Obowiązek powiadomienia komornika o zmianie pracodawcy obciąża 
również dłużnika. O obowiązku tym oraz o skutkach jego zaniedbania dłużnik 
powinien być pouczony przy zawiadomieniu go o zajęciu wynagrodzenia za pracę.

***
## Art. 885. {#kpc-trzecia--art-885}

Zajęcie ma ten skutek, że w stosunku do wierzyciela egzekwującego 
nieważne są rozporządzenia wynagrodzeniem przekraczające część wolną od 
zajęcia, dokonane po jego zajęciu, a także przed zajęciem, jeżeli wymagalność 
wynagrodzenia następuje po zajęciu.

***
## Art. 886. {#kpc-trzecia--art-886}

**§ 1.** Pracodawcy, który nie wykonał obowiązków określonych 
w art. 881 § 3 i 4, nie złożył w przepisanym terminie oświadczenia przewidzianego 
w art. 882 albo zaniedbał przesłania dokumentów zajęcia wynagrodzenia nowemu 
pracodawcy dłużnika, stosownie do art. 884 § 2 i 3, komornik wymierza grzywnę 
w wysokości do pięciu tysięcy złotych. Grzywna jest powtarzana, jeżeli 
pracodawca nadal uchyla się od wykonania tych czynności w dodatkowo 
wyznaczonym terminie. 
**§ 2.** Jeżeli pracodawcą nie jest osoba fizyczna, grzywnie podlega pracownik 
lub wspólnik odpowiedzialny za wykonanie takiej czynności, a w razie 
niewyznaczenia takiego pracownika lub niemożności jego ustalenia – osoby 
uprawnione do reprezentowania pracodawcy. Jeżeli pracodawcą jest spółka 
cywilna, grzywnie podlega którykolwiek ze wspólników. 
**§ 3.** Pracodawca, który nie zastosował się do wezwania z art. 881 i 882 lub 
w inny sposób naruszył obowiązki wynikające z zajęcia bądź złożył oświadczenie 
przewidziane w art. 882 niezgodne z prawdą albo dokonał wypłaty zajętej części 

 
 
 
s. 432/580 
 
2025-09-08 
 
wynagrodzenia dłużnikowi, odpowiada za wyrządzoną przez to wierzycielowi 
szkodę. 
**§ 4.** Grzywnę określoną w § 1 komornik wymierzy również dłużnikowi, który 
nie powiadomił go o zmianie pracodawcy.

***
## Art. 887. {#kpc-trzecia--art-887}

**§ 1.** Z mocy samego zajęcia wierzyciel może wykonywać wszelkie 
prawa i roszczenia dłużnika. Na żądanie wierzyciela komornik wydaje mu 
odpowiednie zaświadczenie. 
**§ 2.** Wierzyciel wnoszący powództwo przeciwko pracodawcy powinien 
przypozwać dłużnika, przeciwko któremu toczy się postępowanie egzekucyjne. 
Pozwany pracodawca obowiązany jest podać sądowi wszystkich innych 
wierzycieli, na rzecz których dochodzona wierzytelność również została zajęta. Sąd 
zawiadomi tych wierzycieli stosownie do art. 195. Wyrok wydany w sprawie jest 
skuteczny w stosunku do innych wierzycieli. Jednakże w stosunku do wierzyciela, 
o którym sąd nie został powiadomiony, pracodawca nie może powoływać się na 
wyrok, który zapadł na jego korzyść.

***
## Art. 888. {#kpc-trzecia--art-888}

**§ 1.** Na wniosek wierzyciela komornik odbierze dłużnikowi 
dokumenty stanowiące dowód wierzytelności i złoży je do depozytu sądowego. 
**§ 2.** Jeżeli wierzyciel zgłasza wniosek, aby odebranie odbyło się w jego 
obecności, komornik zawiadamia go o terminie czynności. W razie niestawienia się 
wierzyciela czynności nie dokonuje się. 
**§ 3.** Dłużnik obowiązany jest pod rygorem odpowiedzialności za szkodę 
udzielić wierzycielowi wszystkich wyjaśnień potrzebnych do dochodzenia praw 
przeciwko dłużnikowi zajętej wierzytelności. 
#### DZIAŁ III
Egzekucja z rachunków bankowych

***
## Art. 889. {#kpc-trzecia--art-889}

**§ 1.** W celu dokonania egzekucji z wierzytelności z rachunku 
bankowego komornik ogólnej właściwości dłużnika: 
- 1) przesyła do banku, w którym dłużnik posiada rachunek, zawiadomienie 
o zajęciu wierzytelności pieniężnej dłużnika pochodzącej z rachunku 
bankowego do wysokości należności będącej przedmiotem egzekucji wraz 
z kosztami egzekucyjnymi i wzywa bank, aby nie dokonywał wypłat 
z rachunku bez zgody komornika do wysokości zajętej wierzytelności albo 

 
 
 
s. 433/580 
 
2025-09-08 
 
zawiadomił komornika w terminie siedmiu dni o przeszkodzie do przekazania 
zajętej kwoty; zawiadomienie jest skuteczne także w przypadku niewskazania 
rachunku bankowego; 
- 2) zawiadamia dłużnika o zajęciu jego wierzytelności z rachunku bankowego, 
doręczając mu odpis zawiadomienia skierowanego do banku, o zakazie 
wypłat z rachunku bankowego. 
**§ 11.** Jeżeli egzekucja dotyczy świadczeń, o których mowa w art. 773 § 21, 
komornik zawiadamia bank o charakterze egzekwowanych świadczeń. 
**§ 2.** Równocześnie komornik przesyła wierzycielowi odpis zawiadomienia 
przesłanego do banku. 
**§ 3.** Jeżeli wierzytelność z rachunku bankowego zajęta została w dwu lub 
więcej postępowaniach egzekucyjnych, a znajdująca się na rachunku kwota nie 
wystarcza na zaspokojenie wszystkich wierzycieli, bank wstrzymuje się z wypłatą 
zajętych kwot, powiadamiając o tym komorników prowadzących egzekucję. Zajęte 
wierzytelności bank wypłaca, po przekazaniu wszystkich spraw w trybie art. 7731, 
komornikowi, który prowadzi dalszą egzekucję.

***
## Art. 8891. {#kpc-trzecia--art-8891}

**§ 1.** Jeżeli zajęto rachunek bankowy prowadzony w walucie obcej, 
bank przekazuje komornikowi należność w walucie polskiej przeliczonej według 
kursu kupna waluty obcej, w której prowadzony jest rachunek, ogłoszonego przez 
Narodowy Bank Polski w dniu przekazania należności komornikowi. 
**§ 2.** Przepisu § 1 nie stosuje się, jeżeli tytuł wykonawczy obejmuje 
świadczenie pieniężne podlegające spełnieniu wyłącznie w walucie obcej, w której 
jest prowadzony rachunek bankowy.

***
## Art. 8892. {#kpc-trzecia--art-8892}

Bank niezwłocznie przekazuje środki pieniężne z zajętego 
rachunku na rachunek bankowy komornika.

***
## Art. 890. {#kpc-trzecia--art-890}

**§ 1.** Zajęcie wierzytelności z rachunku bankowego dłużnika jest 
dokonane z chwilą doręczenia bankowi zawiadomienia o zakazie wypłat z tego 
rachunku i obejmuje również kwoty: 
- 1) których nie było na rachunku bankowym w chwili jego zajęcia, a zostały 
wpłacone na ten rachunek po dokonaniu zajęcia; 
- 2) które zostały wpłacone na inny rachunek, otwarty po dokonaniu zajęcia. 

 
 
 
s. 434/580 
 
2025-09-08 
**§ 11.** Zajęcie wierzytelności z rachunku bankowego nie obejmuje kwot 
pochodzących ze świadczeń, dodatków i zasiłków, o których mowa w art. 833 § 6, 
oraz świadczeń, dodatków i innych kwot, o których mowa w art. 31 ust. 1, art. 80 
ust. 1 i 1a, art. 81, art. 83 ust. 1 i 4, art. 84 pkt 2 i 3 i art. 140 ust. 1 pkt 1 ustawy 
z dnia 9 czerwca 2011 r. o wspieraniu rodziny i systemie pieczy zastępczej, a także 
świadczenia dobry start oraz środków finansowych na utrzymanie lokalu 
mieszkalnego w budynku wielorodzinnym lub domu jednorodzinnego, o których 
mowa w art. 83 ust. 2 i art. 84 pkt 1 ustawy z dnia 9 czerwca 2011 r. o wspieraniu 
rodziny i systemie pieczy zastępczej, a także świadczenia dobry start w części 
przysługującej na umieszczone w rodzinie zastępczej lub rodzinnym domu dziecka 
dzieci i osoby, które osiągnęły pełnoletność, przebywając w pieczy zastępczej. 
**§ 12.** (uchylony) 
**§ 13.** (uchylony) 
**§ 2.** Wynikający z zajęcia wierzytelności z rachunku bankowego zakaz 
wypłat z tego rachunku nie dotyczy bieżących wypłat na wynagrodzenie za pracę 
wraz z podatkami i innymi ciężarami ustawowymi oraz na zasądzone alimenty 
i renty o charakterze alimentacyjnym zasądzone tytułem odszkodowania – do 
wysokości przeciętnego wynagrodzenia z poprzedniego kwartału ogłaszanego 
przez Prezesa Głównego Urzędu Statystycznego w Dzienniku Urzędowym 
Rzeczypospolitej Polskiej „Monitor Polski” na podstawie art. 20 pkt 2 ustawy 
z dnia 17 grudnia 1998 r. o emeryturach i rentach z Funduszu Ubezpieczeń 
Społecznych. Wypłata na wynagrodzenie za pracę następuje po złożeniu 
komornikowi odpisu listy płac lub innego wiarygodnego dowodu, a wypłata na 
alimenty i renty alimentacyjne – tytułu wykonawczego stwierdzającego obowiązek 
dłużnika do płacenia alimentów lub renty. 
**§ 21.** Bank dokonuje wypłat, o których mowa w § 2, na podstawie zezwolenia 
komornika. Wypłaty na alimenty i renty alimentacyjne następują do rąk 
uprawnionego do tych świadczeń. 
**§ 22.** (uchylony) 
**§ 3.** (uchylony)

***
## Art. 8901. {#kpc-trzecia--art-8901}

Jeżeli zajęcie obejmuje wierzytelność wynikającą z rachunku 
bankowego zajętego uprzednio na podstawie postanowienia o zabezpieczeniu 
ustanowionym w postępowaniu zabezpieczającym, uprawnienia obowiązanego do 

 
 
 
s. 435/580 
 
2025-09-08 
 
dokonania wypłat z rachunku bankowego ustają z dniem dokonania zajęcia 
w postępowaniu egzekucyjnym.

***
## Art. 8902. {#kpc-trzecia--art-8902}

**§ 1.** Wykonanie zajęcia wierzytelności z rachunku bankowego 
podlega wstrzymaniu w okresie blokady rachunku podmiotu kwalifikowanego 
w rozumieniu art. 119zg pkt 2 ustawy z dnia 29 sierpnia 1997 r. – Ordynacja podat-
kowa (Dz. U. z 2023 r. poz. 2383 i 2760 oraz z 2024 r. poz. 879). 
**§ 2.** Wstrzymanie wykonania zajęcia, o którym mowa w § 1, nie dotyczy 
zajęcia na poczet zasądzonych alimentów, renty o charakterze alimentacyjnym 
tytułem odszkodowania oraz wynagrodzenia ze stosunku pracy wraz z zaliczką na 
podatek dochodowy od osób fizycznych oraz składkami na ubezpieczenie 
społeczne należnymi od dokonywanych wypłat na bieżące wynagrodzenia. Bank 
wykonuje to zajęcie do wysokości nieprzekraczającej kwoty minimalnego 
wynagrodzenia za pracę, o którym mowa w przepisach ustawy z dnia 
10 października 2002 r. o minimalnym wynagrodzeniu za pracę (Dz. U. z 2020 r. 
poz. 2207 oraz z 2023 r. poz. 1667). 
**§ 3.** W przypadku, o którym mowa w § 1, bank informuje komornika 
o przyczynie 
wstrzymania 
wykonania 
zajęcia 
wierzytelności 
z rachunku 
bankowego w przypadku blokady rachunku, o której mowa w art. 119zw § 1 
ustawy z dnia 29 sierpnia 1997 r. – Ordynacja podatkowa.

***
## Art. 891. {#kpc-trzecia--art-891}

**§ 1.** W razie zbiegu egzekucji sądowej 
i administracyjnej, 
w przypadku gdy kwoty znajdujące się na rachunku bankowym nie wystarczają na 
pokrycie wszystkich egzekwowanych należności, bank dokonuje wypłat z tego 
rachunku na rzecz sądowego albo administracyjnego organu egzekucyjnego, który 
pierwszy dokonał zajęcia, a w razie niemożności ustalenia tego pierwszeństwa – na 
rzecz organu, który dokonał zajęcia na poczet należności w wyższej kwocie, oraz 
niezwłocznie zawiadamia o zbiegu egzekucji właściwe organy egzekucyjne, 
wskazując datę doręczenia zawiadomień o zajęciach dokonanych przez te organy 
i wysokość należności, na poczet których zostały dokonane zajęcia, o czym komor-
nik poucza bank, dokonując zajęcia. 
**§ 2.** W razie zbiegu egzekucji administracyjnej i sądowej świadczeń, 
o których mowa w art. 773 § 21, w przypadku gdy kwoty znajdujące się na 
rachunku bankowym nie wystarczają na pokrycie wszystkich egzekwowanych 

 
 
 
s. 436/580 
 
2025-09-08 
 
należności, bank dokonuje wypłat z tego rachunku na rzecz sądowego organu 
egzekucyjnego, a zawiadamiając o zbiegu egzekucji właściwe organy egzekucyjne, 
wskazuje na charakter egzekwowanych świadczeń.

***
## Art. 8911. {#kpc-trzecia--art-8911}

**§ 1.** Na podstawie tytułu wykonawczego wystawionego przeciwko 
dłużnikowi można zająć wierzytelność z rachunku wspólnego prowadzonego dla 
dłużnika i osób trzecich. Dalsze czynności egzekucyjne będą prowadzone do 
udziału przypadającego dłużnikowi w rachunku wspólnym stosownie do treści 
umowy rachunku bankowego, którą dłużnik jest obowiązany przedłożyć 
komornikowi w terminie tygodnia od daty zajęcia. Przepisy o wyjawieniu majątku 
stosuje się odpowiednio. Jeżeli umowa nie określa udziału w rachunku wspólnym 
albo gdy dłużnik nie przedłoży umowy, domniemywa się, że udziały są równe. Po 
ustaleniu udziału dłużnika zwalnia się pozostałe udziały od egzekucji. 
**§ 2.** W razie zajęcia rachunku wspólnego dla wspólników spółki cywilnej, 
komornik zawiadamia pozostałych wspólników.

***
## Art. 8912. {#kpc-trzecia--art-8912}

**§ 1.** Na podstawie tytułu wykonawczego wystawionego przeciwko 
dłużnikowi pozostającemu w związku małżeńskim można prowadzić egzekucję 
z rachunku wspólnego dłużnika i jego małżonka. 
**§ 2.** Przepis § 1 nie wyłącza możliwości obrony małżonka dłużnika w drodze 
powództwa o zwolnienie od egzekucji, jeżeli na rachunku wspólnym małżonków 
zgromadzono środki, które nie wchodzą do majątku osobistego dłużnika, albo też 
środki, które nie pochodzą z pobranego przez dłużnika wynagrodzenia za pracę, 
dochodów uzyskanych przez dłużnika z innej działalności zarobkowej, jak również 
z korzyści uzyskanych z jego praw autorskich i praw pokrewnych, praw własności 
przemysłowej oraz innych praw twórcy.

***
## Art. 892. {#kpc-trzecia--art-892}

**§ 1.** Bank, który naruszył przepisy dotyczące obowiązków banku 
w zakresie egzekucji z rachunków bankowych odpowiada za wyrządzoną przez to 
wierzycielowi szkodę. 
**§ 2.** Przepisy art. 886 stosuje się odpowiednio do pracowników banku 
winnych niezgodnego z prawem dokonania wypłaty z zajętego rachunku 
bankowego.

***
## Art. 893. {#kpc-trzecia--art-893}

Do skutków zajęcia stosuje się odpowiednio art. 885, 887 i 888. 

 
 
 
s. 437/580 
 
2025-09-08

***
## Art. 8931. {#kpc-trzecia--art-8931}

**§ 1.** Jeżeli egzekucja z rachunku bankowego, na który wystawiono 
dowód imienny, nie może być przeprowadzona w trybie art. 901 z powodu 
niemożności odebrania tego dokumentu, komornik stwierdza ten fakt protokołem 
i dokonuje zajęcia rachunku bankowego, na który wystawiono dowód imienny, 
przez skierowanie do właściwego banku zawiadomienia o zajęciu. Zajęcie jest 
dokonane z chwilą doręczenia tego zawiadomienia. Na skutek zajęcia dokonanego 
w powyższy sposób bank wstrzymuje wszelkie wypłaty z zajętego rachunku 
bankowego, na który wystawiono dowód imienny, i zawiadamia o tym placówki 
banku, placówki pocztowe w rozumieniu ustawy z dnia 23 listopada 2012 r. – 
Prawo pocztowe oraz inne placówki wykonujące czynności w powyższym 
zakresie. 
**§ 2.** Komornik doręcza niezwłocznie zawiadomienie o zajęciu rachunku 
bankowego, na który wystawiono dowód imienny, dłużnikowi z pouczeniem 
o odpowiedzialności przewidzianej w § 3, w razie dokonania wypłaty z zajętego 
rachunku bankowego, na który wystawiono dowód imienny. 
**§ 3.** Dłużnik, który po dokonaniu zajęcia rachunku bankowego, na który 
wystawiono dowód imienny, dokona wypłaty całości lub części środków 
pieniężnych znajdujących się na tym rachunku, podlega odpowiedzialności karnej 
jak za usunięcie mienia spod egzekucji. 
**§ 4.** Komornik doręcza niezwłocznie zawiadomienie o zajęciu rachunku 
bankowego, na który wystawiono dowód imienny, wierzycielowi. 
**§ 41.** W terminie dwóch tygodni od daty doręczenia zawiadomienia o zajęciu 
rachunku bankowego, na który wystawiono dowód imienny, wierzyciel występuje 
do sądu z wnioskiem o umorzenie książeczki oszczędnościowej dłużnika 
i zawiadamia o tym niezwłocznie właściwy oddział banku, doręczając mu odpis 
złożonego do sądu wniosku o umorzenie książeczki oszczędnościowej. W razie 
niedoręczenia odpisu, o którym mowa w zdaniu poprzedzającym, w terminie 
miesiąca od daty zajęcia rachunku bankowego, na który wystawiono dowód 
imienny, właściwy oddział banku odwołuje wstrzymanie wypłat z tego rachunku, 
o czym zawiadamia właściciela książeczki oszczędnościowej. 
**§ 42.** W zawiadomieniu, o którym mowa w § 4, poucza się wierzyciela 
o treści § 41. 

 
 
 
s. 438/580 
 
2025-09-08 
**§ 5.** Minister właściwy do spraw finansów publicznych w porozumieniu 
z ministrem właściwym do spraw łączności oraz Ministrem Sprawiedliwości 
określi, w drodze rozporządzenia, tryb zawiadamiania placówek banków, placówek 
pocztowych w rozumieniu ustawy z dnia 23 listopada 2012 r. – Prawo pocztowe 
i innych placówek, uwzględniając dane zawarte w zawiadomieniu, mając na 
względzie sprawne prowadzenie egzekucji.

***
## Art. 8932. {#kpc-trzecia--art-8932}

**§ 1.** Sąd 
rozpatrzy 
wniosek 
o umorzenie 
książeczki 
oszczędnościowej 
na 
zasadach 
i w trybie 
przewidzianych 
w przepisach 
o umarzaniu utraconych dokumentów. W postępowaniu o umorzenie książeczki 
oszczędnościowej nie mogą być zgłoszone zarzuty dotyczące zasadności 
roszczenia wierzyciela. Koszty postępowania obciążają właściciela książeczki. Sąd 
przesyła właściwemu oddziałowi banku wypis prawomocnego postanowienia 
w sprawie umorzenia książeczki oszczędnościowej. 
**§ 2.** W razie umorzenia książeczki oszczędnościowej właściwy oddział banku 
wystawia na jej miejsce nową książeczkę oszczędnościową, którą po odpisaniu 
środków pieniężnych do wysokości należności wskazanej w tytule wykonawczym 
łącznie 
z kosztami 
egzekucyjnymi 
wydaje 
właścicielowi. 
W przypadku 
nieuwzględnienia wniosku o umorzenie książeczki oszczędnościowej właściwy 
oddział banku niezwłocznie odwoła wstrzymanie wypłat z rachunku bankowego, 
na który wystawiono dowód imienny, i zawiadomi o tym właściciela.

***
## Art. 8932a. {#kpc-trzecia--art-8932a}

Komornik doręcza pisma bankowi za pośrednictwem systemu 
teleinformatycznego obsługującego zajęcie wierzytelności z rachunku bankowego, 
a bank wnosi pisma do komornika wyłącznie za pośrednictwem tego systemu.

***
## Art. 8933. {#kpc-trzecia--art-8933}

Przepisy art. 8931 i 8932 stosuje się odpowiednio w wypadku 
niemożności odebrania innego dokumentu, z którego posiadaniem jest związana 
wierzytelność na rachunku bankowym.

***
## Art. 8934. {#kpc-trzecia--art-8934}

Przepisy niniejszego działu stosuje się odpowiednio do egzekucji 
z rachunków prowadzonych przez spółdzielcze kasy oszczędnościowo-kredytowe.

***
## Art. 894. {#kpc-trzecia--art-894}

(uchylony) 

 
 
 
s. 439/580 
 
2025-09-08 
#### DZIAŁ IV
Egzekucja z innych wierzytelności

***
## Art. 895. {#kpc-trzecia--art-895}

**§ 1.** Egzekucja prowadzona według przepisów działu niniejszego 
należy do komornika sądu właściwości ogólnej dłużnika, przeciwko któremu toczy 
się postępowanie egzekucyjne, a w braku podstaw do jej oznaczenia – do 
komornika sądu właściwości ogólnej osoby zobowiązanej względem dłużnika. Gdy 
osoby takiej nie ma, egzekucja należy do komornika tego sądu, w którego okręgu 
znajduje się przedmiot świadczenia lub prawa. 
**§ 2.** Jeżeli wykonanie prawa związane jest z posiadaniem dokumentu, 
właściwy jest komornik tego sądu, w którego okręgu dokument się znajduje. 
**§ 3.** Na podstawie wniosku o wszczęcie egzekucji z ruchomości komornik 
dokona również zajęcia wierzytelności lub innych praw majątkowych, związanych 
z posiadaniem dokumentu, jeżeli dokument taki znajduje się w posiadaniu 
dłużnika.

***
## Art. 896. {#kpc-trzecia--art-896}

**§ 1.** Do egzekucji z wierzytelności komornik przystępuje przez jej 
zajęcie. W celu zajęcia komornik: 
- 1) zawiadomi dłużnika, że nie wolno mu odbierać żadnego świadczenia ani 
rozporządzać 
zajętą 
wierzytelnością 
i ustanowionym 
dla 
niej 
zabezpieczeniem; 
- 11) zawiadomi 
dłużnika 
wierzytelności 
o charakterze 
egzekwowanych 
świadczeń, 
jeżeli 
egzekucja 
dotyczy 
świadczeń, 
o których 
mowa 
w art. 773 § 21; 
- 2) wezwie dłużnika wierzytelności, aby należnego od niego świadczenia nie 
uiszczał dłużnikowi, lecz złożył je komornikowi lub na rachunek depozytowy 
Ministra Finansów; 
- 3) wezwie dłużnika wierzytelności, aby w razie zbiegu egzekucji sądowej 
i administracyjnej, w przypadku gdy świadczenie nie wystarcza na pokrycie 
wszystkich egzekwowanych należności, uiszczał je na rzecz: 
  - a) sądowego albo administracyjnego organu egzekucyjnego, który 
pierwszy dokonał zajęcia, a w razie niemożności ustalenia tego 
pierwszeństwa – na rzecz organu, który dokonał zajęcia na poczet należ-
ności w wyższej kwocie, albo 

 
 
 
s. 440/580 
 
2025-09-08 
  - b) sądowego organu egzekucyjnego – jeżeli egzekucja dotyczy świadczeń, 
o których mowa w art. 773 § 21 
– oraz niezwłocznie zawiadomił o zbiegu egzekucji właściwe organy 
egzekucyjne, 
wskazując 
datę 
doręczenia 
zawiadomień 
o zajęciach 
dokonanych przez te organy i wysokość należności, na poczet których zostały 
dokonane zajęcia, a w przypadku, o którym mowa w art. 773 § 21 – także na 
charakter egzekwowanych świadczeń. 
**§ 2.** Jednocześnie z zajęciem wierzytelności komornik wezwie jej dłużnika, 
aby w ciągu tygodnia złożył oświadczenie: 
- 1) czy i w jakiej wysokości przysługuje dłużnikowi zajęta wierzytelność, czy też 
odmawia zapłaty i z jakiej przyczyny; 
- 2) czy inne osoby roszczą sobie prawa do wierzytelności, czy i w jakim sądzie 
lub przed jakim organem toczy się lub toczyła się sprawa o zajętą 
wierzytelność oraz czy i o jakie roszczenie została skierowana do zajętej 
wierzytelności egzekucja przez innych wierzycieli.

***
## Art. 897. {#kpc-trzecia--art-897}

**§ 1.** W celu zajęcia wierzytelności, której zabezpieczenie jest 
ujawnione przez wpis w księdze wieczystej lub przez złożenie dokumentu do 
zbioru, komornik jednocześnie z zawiadomieniem i wezwaniem dłużników 
zgodnie z art. 896, składa do sądu właściwego do prowadzenia księgi wieczystej 
wniosek o wpis o zajęciu lub o złożenie tego wniosku do zbioru dokumentów. 
**§ 2.** Jeżeli w księdze wieczystej znajdują się wpisy lub w zbiorze 
dokumentów dokumenty stanowiące przeszkodę do uwzględnienia wniosku, sąd 
właściwy do prowadzenia księgi wieczystej zawiadomi o tym wierzyciela 
i komornika, wyznaczając termin do usunięcia przeszkody. Usunięcie przeszkody 
należy do wierzyciela. W tym celu wierzyciel może wykonywać prawa 
przysługujące dłużnikowi. Na wniosek wierzyciela komornik odbierze dłużnikowi 
potrzebne do tego dokumenty. 
**§ 3.** Po bezskutecznym upływie wyznaczonego terminu sąd oddali wniosek 
komornika, a komornik umorzy egzekucję. Jeżeli jednak wierzyciel w terminie 
wyznaczonym przez sąd wytoczy powództwo w celu usunięcia przeszkody, 
oddalenie wniosku i umorzenie egzekucji nie może nastąpić przed prawomocnym 
oddaleniem powództwa. 
**§ 4.** (uchylony) 

 
 
 
s. 441/580 
 
2025-09-08

***
## Art. 898. {#kpc-trzecia--art-898}

Jeżeli do zabezpieczenia zajętej wierzytelności wymagany jest wpis 
w księdze wieczystej, komornik odbierze dłużnikowi dokumenty potrzebne do 
dokonania tego wpisu i złoży wniosek o wpis na rzecz dłużnika oraz o jednoczesne 
ujawnienie zajęcia.

***
## Art. 899. {#kpc-trzecia--art-899}

Dokonując zajęcia wierzytelności zabezpieczonej poręczeniem, 
zastawem lub zastawem rejestrowym, komornik na wniosek wierzyciela 
zawiadamia także poręczyciela albo właściciela przedmiotu obciążonego prawem 
zastawu, iż świadczenia z wierzytelności zabezpieczonej nie wolno uiścić 
dłużnikowi. Przepis art. 882 § 1 pkt 2 stosuje się odpowiednio.

***
## Art. 900. {#kpc-trzecia--art-900}

**§ 1.** Zajęcie jest dokonane z chwilą doręczenia wezwania 
dłużnikowi zajętej wierzytelności. Jeżeli konieczny jest wpis zajęcia w księdze 
wieczystej, wierzytelność jest zajęta z chwilą dokonania wpisu lub złożenia do 
zbioru dokumentów wniosku komornika. Jednakże i w tym wypadku zajęcie jest 
skuteczne już z chwilą doręczenia wezwania dłużnikowi zajętej wierzytelności, 
jeżeli takie doręczenie nastąpiło wcześniej. 
**§ 2.** Zajęcie sum płatnych periodycznie obejmuje także wypłaty przyszłe. Art. 
883 § 2 stosuje się odpowiednio.

***
## Art. 901. {#kpc-trzecia--art-901}

**§ 1.** Zajęcia wierzytelności związanej z posiadaniem dokumentu 
dokonuje się przez odebranie dokumentu dłużnikowi lub osobie trzeciej. Przepis 
art. 845 § 2 stosuje się odpowiednio. Następnych zajęć takiej wierzytelności 
dokonuje się przez zaznaczenie w protokole pierwszego zajęcia. 
**§ 2.** O dokonaniu zajęcia komornik powiadomi wierzyciela dłużnika, 
przeciwko któremu toczy się postępowanie egzekucyjne, i dłużnika zajętej 
wierzytelności, a przy dalszych zajęciach także poprzednich wierzycieli. 
**§ 3.** Od dłużnika zajętej wierzytelności związanej z posiadaniem dokumentu 
komornik zażąda zapłaty poszukiwanej sumy, a jeżeli wierzytelność wymagalna 
jest po wypowiedzeniu, dokona jej wypowiedzenia. Na wniosek wierzyciela, 
dłużnika albo z urzędu, komornik dokona również czynności zachowawczych, 
jeżeli zajdzie tego potrzeba. 
**§ 4.** Zajęte papiery wartościowe niezapisane na rachunku papierów 
wartościowych komornik może sprzedać za pośrednictwem firmy inwestycyjnej 
w rozumieniu przepisów, o których mowa w art. 7521. Sprzedaż w tym trybie może 

 
 
 
s. 442/580 
 
2025-09-08 
 
nastąpić w okresie miesiąca od dnia zajęcia. Za zgodą dłużnika sprzedaż może 
nastąpić także po tym terminie. Do ustalenia ceny sprzedaży należy powołać 
biegłego. Na wniosek dłużnika sprzedaż może nastąpić po cenie przez niego 
wskazanej. 
**§ 5.** Jeżeli zobowiązany z weksla nie zapłaci poszukiwanej sumy, komornik 
sprzeda weksel. Dokonany przez komornika indos wywiera skutki indosu 
wpisanego przez zobowiązanego. Jeżeli na wekslu zostały umieszczone wyrazy 
„nie na zlecenie” lub inne zastrzeżone równoważnie, komornik może przenieść 
weksel na nabywcę tylko w formie i ze skutkiem przewidzianym w przepisach 
o przelewie wierzytelności. 
**§ 6.** Do zbycia weksli przepisy art. 9041 stosuje się odpowiednio.

***
## Art. 902. {#kpc-trzecia--art-902}

Do skutków zajęcia stosuje się odpowiednio art. 885, 887 i 888, 
a do skutków niezastosowania się do wezwań komornika oraz do obowiązków 
wynikających z zajęcia – art. 886.

***
## Art. 9021. {#kpc-trzecia--art-9021}

Zajęcie wierzytelności nie narusza uprawnień wynikających 
z zamieszczonej w umowie klauzuli kompensacyjnej, o której mowa w ustawie 
z dnia 2 kwietnia 2004 r. o niektórych zabezpieczeniach finansowych (Dz. U. 
z 2024 r. poz. 294).

***
## Art. 9022. {#kpc-trzecia--art-9022}

**§ 1.** Zajęcie nadpłaty i zwrotu podatku obejmuje wszelkie 
wierzytelności z tytułu nadpłaty lub zwrotu podatku istniejące w chwili zajęcia oraz 
powstałe po zajęciu. Przepisu art. 896 § 2 nie stosuje się. 
**§ 11.** Zajęcie nadpłaty i zwrotu podatku skierowane do naczelnika urzędu 
skarbowego nie wywołuje skutku, jeżeli dotyczy dłużnika, który nie jest 
zaewidencjonowany w Centralnym Rejestrze Podmiotów – Krajowej Ewidencji 
Podatników. 
**§ 12.** Zajęcie nadpłaty i zwrotu podatku skierowane do naczelnika urzędu 
skarbowego jest skuteczne wobec pozostałych naczelników urzędów skarbowych. 
**§ 2.** Dłużnik wierzytelności z tytułu nadpłaty lub zwrotu podatku zawiadamia 
sądowy organ egzekucyjny o braku swojej właściwości, jeżeli nie jest dłużnikiem 
wierzytelności. Zdania pierwszego nie stosuje się do naczelnika urzędu 
skarbowego. 

 
 
 
s. 443/580 
 
2025-09-08 
**§ 21.** Do zbiegu egzekucji do wierzytelności z tytułu zajęcia nadpłaty lub 
zwrotu podatku dochodzi z chwilą zaistnienia podstaw do zwrotu nadpłaty lub 
zwrotu podatku. W takim przypadku dłużnik zajętej wierzytelności zawiadamia 
organy egzekucyjne o zbiegu egzekucji i o dacie dokonania uczestniczących 
w zbiegu 
zajęć, 
z jednoczesnym 
przekazaniem 
właściwemu 
organowi 
egzekucyjnemu środków pieniężnych. W przypadku zbiegu egzekucji przepisów 
art. 773 § 6 i 8 nie stosuje się. 
**§ 22.** Przepisów art. 773–7732 i art. 774 nie stosuje się, jeżeli dokonane zajęcie 
dotyczy wierzytelności z tytułu nadpłaty lub zwrotu podatku w wysokości nie 
wyższej niż 100 zł. Dłużnik wierzytelności przekazuje środki pieniężne organowi 
egzekucyjnemu, który jako pierwszy dokonał zajęcia, a w razie niemożności 
ustalenia tego pierwszeństwa – organowi egzekucyjnemu, który dokonał zajęcia na 
poczet należności w wyższej kwocie. 
**§ 23.** Jeżeli po przekazaniu, o którym mowa w § 22, pozostały środki 
pieniężne, dłużnik wierzytelności przekazuje je, aż do całkowitego rozliczenia 
wierzytelności z tytułu nadpłaty lub zwrotu podatku, organowi egzekucyjnemu, 
który jako kolejny dokonał zajęcia nadpłaty i zwrotu podatku, a w razie 
niemożności ustalenia kolejności – organowi, który dokonał zajęcia na poczet 
należności w wyższej kwocie. 
**§ 3.** Zawiadomienie o zajęciu nadpłaty i zwrotu podatku oraz inne związane 
z dokonanym zajęciem dokumenty doręcza się dłużnikowi zajętej wierzytelności 
przy wykorzystaniu systemu teleinformatycznego albo z użyciem środków komu-
nikacji elektronicznej, w sposób określony w przepisach wydanych na podstawie 
art. 67 § 2c ustawy z dnia 17 czerwca 1966 r. o postępowaniu egzekucyjnym 
w administracji. Doręczenia pomiędzy komornikiem a naczelnikiem urzędu 
skarbowego dokonywane są za pośrednictwem konta w e-Urzędzie Skarbowym. 
**§ 4.** Nadwyżkę środków pieniężnych uzyskanych z tytułu zajęcia nadpłaty lub 
zwrotu podatku komornik zwraca bezpośrednio dłużnikowi.

***
## Art. 903. {#kpc-trzecia--art-903}

Jeżeli zajęto wierzytelność, której przedmiotem jest świadczenie 
z zobowiązania przemiennego z prawem wyboru zastrzeżonym dla dłużnika, 
przeciwko któremu toczy się postępowanie egzekucyjne, prawo to przechodzi na 
wierzyciela, jeżeli dłużnik, wezwany przez komornika do dokonania wyboru, 
w ciągu tygodnia z prawa tego nie skorzysta. 

 
 
 
s. 444/580 
 
2025-09-08

***
## Art. 904. {#kpc-trzecia--art-904}

Jeżeli obowiązek dłużnika zajętej wierzytelności zależy od 
wzajemnego świadczenia dłużnika, przeciwko któremu toczy się postępowanie 
egzekucyjne, które polega na wydaniu rzeczy znajdującej się w jego władaniu, a 
obowiązek wydania tej rzeczy został już orzeczony prawomocnym wyrokiem lub 
stwierdzony innym tytułem egzekucyjnym, komornik odbierze dłużnikowi zajętej 
wierzytelności tytuł egzekucyjny i po uzyskaniu na nim klauzuli wykonalności 
odbierze rzecz dłużnikowi, przeciwko któremu toczy się postępowanie 
egzekucyjne, jeżeli to jest konieczne do uzyskania świadczenia od dłużnika zajętej 
wierzytelności.

***
## Art. 9041. {#kpc-trzecia--art-9041}

**§ 1.** Na wniosek wierzyciela jego zaspokojenie nastąpi przez 
sprzedaż wierzytelności w drodze licytacji lub z wolnej ręki, o ile nie sprzeciwia 
się temu charakter zajętej wierzytelności. 
**§ 2.** Sprzedaży zajętej wierzytelności dokonuje się w drodze licytacji 
prowadzonej według przepisów o egzekucji z ruchomości. Cena wywołania wynosi 
trzy czwarte sumy, na którą składa się należność główna oraz odsetki naliczone do 
dnia licytacji. Nabycie nie może nastąpić poniżej ceny wywołania. 
**§ 3.** Za zgodą dłużnika zajęta wierzytelność może zostać sprzedana z wolnej 
ręki po cenie przez niego wskazanej, jeżeli sprzedaż nie narusza interesów 
wierzycieli. Dłużnik może też wskazać nabywcę oraz określić inne warunki 
sprzedaży. Zgoda dłużnika na sprzedaż z wolnej ręki nie jest potrzebna, gdy 
wierzytelność była wymagalna przed dniem zajęcia. W takim wypadku cena 
sprzedaży nie może być jednak niższa niż cztery piąte sumy, na którą składa się 
należność główna oraz odsetki naliczone do dnia sprzedaży.

***
## Art. 905. {#kpc-trzecia--art-905}

**§ 1.** Jeżeli zajęta została wierzytelność, z mocy której mają być 
wydane dłużnikowi na własność ruchomości, będą one wydane komornikowi 
w miejscu, w którym miały być wydane dłużnikowi. Zajęcie ruchomości dokonane 
jest przez samo zajęcie wierzytelności o ich wydanie. 
**§ 2.** Dalsza egzekucja z tych ruchomości będzie prowadzona według 
przepisów o egzekucji z ruchomości.

***
## Art. 906. {#kpc-trzecia--art-906}

**§ 1.** Jeżeli została zajęta wierzytelność, z mocy której dłużnikowi, 
przeciwko któremu toczy się postępowanie egzekucyjne, jako właścicielowi ma 

 
 
 
s. 445/580 
 
2025-09-08 
 
być wydana nieruchomość, komornik odda wydaną nieruchomość w zarząd 
dłużnikowi. Na wniosek wierzyciela komornik ustanowi zarządcą inną osobę. 
**§ 2.** Egzekucja z tej nieruchomości i zarząd prowadzone będą według 
przepisów o egzekucji z nieruchomości.

***
## Art. 907. {#kpc-trzecia--art-907}

Przepis artykułu poprzedzającego stosuje się odpowiednio 
w wypadku, gdy przedmiotem zajętej wierzytelności jest statek morski wpisany do 
rejestru okrętowego.

***
## Art. 908. {#kpc-trzecia--art-908}

**§ 1.** Jeżeli po zajęciu wierzytelności należyte wykonanie praw 
dłużnika lub wierzyciela tego wymaga, sąd na wniosek wierzyciela lub dłużnika, 
stosownie do okoliczności, ustanowi kuratora lub zarządcę. Na postanowienie sądu 
przysługuje zażalenie. 
**§ 2.** Do zarządu stosuje się odpowiednio przepisy o zarządzie w toku 
egzekucji z nieruchomości.

***
## Art. 9081. {#kpc-trzecia--art-9081}

**§ 1.** Przepisy niniejszego działu stosuje się odpowiednio w razie 
zajęcia stanowiącej własność dłużnika sumy złożonej na rachunku depozytowym 
Ministra Finansów, dopóki suma ta nie zostanie objęta, choćby nieprawomocnie, 
planem podziału sumy uzyskanej z egzekucji. Zajęcie kieruje się do organu 
będącego dysponentem sumy. 
**§ 2.** Jeżeli na skutek zajęcia, o którym mowa w § 1, doszło do zbiegu 
egzekucji albo egzekucji i zabezpieczenia, przyjmuje się, że organ będący 
dysponentem sumy jako pierwszy dokonał zajęcia. Do organu tego stosuje się 
odpowiednio przepis art. 896 § 2 dotyczący obowiązków dłużnika zajętej 
wierzytelności. 
**§ 3.** W razie zbiegu, o którym mowa w § 2, podziału sumy uzyskanej 
z egzekucji dokonuje się z uwzględnieniem przepisów właściwych dla sposobu 
egzekucji zastosowanego do uzyskania zdeponowanej sumy. 
**§ 4.** Nie jest dopuszczalne zajęcie sumy uzyskanej w toku egzekucji 
z nieruchomości albo egzekucji, do której przepisy o egzekucji z nieruchomości 
stosuje się odpowiednio. Przepis powyższy nie stoi na przeszkodzie zajęciu 
wierzytelności dłużnika o zwrot kwoty, która może mu przypadać zgodnie 
z planem podziału sumy uzyskanej z egzekucji. 

 
 
 
s. 446/580 
 
2025-09-08 
 
DZIAŁ IVa 
Egzekucja z innych praw majątkowych

***
## Art. 909. {#kpc-trzecia--art-909}

Przepisy o egzekucji z wierzytelności stosuje się odpowiednio do 
egzekucji z innych praw majątkowych, jeżeli przepisy poniższe nie stanowią 
inaczej.

***
## Art. 910. {#kpc-trzecia--art-910}

**§ 1.** Do egzekucji z praw majątkowych komornik przystąpi przez 
zajęcie prawa. W tym celu komornik: 
- 1) zawiadomi dłużnika, że nie wolno mu rozporządzać, obciążać ani realizować 
zajętego prawa, jak również nie wolno mu pobierać żadnego świadczenia 
przysługującego z zajętego prawa; 
- 11) zawiadomi osobę, która z zajętego prawa jest obciążona obowiązkiem 
względem dłużnika, o charakterze egzekwowanych świadczeń, jeżeli 
egzekucja dotyczy świadczeń, o których mowa w art. 773 § 21; 
- 2) zawiadomi osobę, która z zajętego prawa jest obciążona obowiązkiem 
względem dłużnika, by obowiązku tego wobec dłużnika nie realizowała, 
a wynikające z prawa świadczenia pieniężne uiszczała komornikowi lub na 
rachunek depozytowy Ministra Finansów, oraz wzywa tę osobę, by w terminie 
tygodnia złożyła oświadczenie, czy inne osoby roszczą sobie pretensje do 
zajęcia prawa, czy i w jakim sądzie lub przed jakim organem toczy się lub 
toczyła się sprawa o zajęte prawo, jak również czy oraz o jakie roszczenie 
skierowana jest egzekucja do zajętego prawa; 
- 3) wezwie osobę, która z zajętego prawa jest obciążona obowiązkiem względem 
dłużnika, aby w razie zbiegu egzekucji sądowej i administracyjnej, 
w przypadku gdy świadczenie nie wystarcza na pokrycie wszystkich 
egzekwowanych należności, uiszczała je na rzecz: 
  - a) sądowego albo administracyjnego organu egzekucyjnego, który 
pierwszy dokonał zajęcia, a w razie niemożności ustalenia tego 
pierwszeństwa – na rzecz organu, który dokonał zajęcia na poczet 
należności w wyższej kwocie, albo 
  - b) sądowego organu egzekucyjnego – jeżeli egzekucja dotyczy świadczeń, 
o których mowa w art. 773 § 21 

 
 
 
s. 447/580 
 
2025-09-08 
 
– oraz niezwłocznie zawiadomiła o zbiegu egzekucji właściwe organy 
egzekucyjne, 
wskazując 
datę 
doręczenia 
zawiadomień 
o zajęciach 
dokonanych przez te organy i wysokość należności, na poczet których zostały 
dokonane zajęcia, a w przypadku, o którym mowa w art. 773 § 21 – także na 
charakter egzekwowanych świadczeń. 
**§ 2.** Prawo jest zajęte z chwilą doręczenia zawiadomienia osobie, która 
z mocy zajętego prawa jest obciążona obowiązkiem wobec dłużnika. Jednakże 
jeżeli zawiadomienie o zajęciu zostało doręczone dłużnikowi wcześniej, skutki 
zajęcia powstają wobec dłużnika z chwilą doręczenia mu zawiadomienia o zajęciu. 
**§ 3.** Jeżeli prawo majątkowe, które ma być zajęte, jest tego rodzaju, że nie ma 
oznaczonej osoby obciążonej obowiązkiem względem dłużnika, zajęcie jest 
dokonane z chwilą doręczenia zawiadomienia dłużnikowi. 
**§ 4.** W stosunku do każdego, kto wiedział o wszczęciu egzekucji, skutki 
zajęcia powstają z chwilą, gdy o wszczęciu egzekucji powziął wiadomość, choćby 
zawiadomienie, o którym mowa w § 1, nie zostało jeszcze doręczone.

***
## Art. 9101. {#kpc-trzecia--art-9101}

Dokonując zajęcia patentu, dodatkowego prawa ochronnego, 
prawa ochronnego lub prawa z rejestracji komornik przesyła do Urzędu 
Patentowego Rzeczypospolitej Polskiej wniosek o wpis informacji o zajęciu prawa 
do właściwego rejestru.

***
## Art. 9102. {#kpc-trzecia--art-9102}

**§ 1.** Z mocy zajęcia wierzyciel może wykonywać wszelkie 
uprawnienia majątkowe dłużnika wynikające z zajętego prawa, które są niezbędne 
do zaspokojenia wierzyciela w drodze egzekucji, może również podejmować 
wszelkie działania, które są niezbędne do zachowania prawa. 
**§ 2.** Jeżeli zachodzi potrzeba realizacji innych uprawnień wynikających 
z zajętego prawa niż wymienione w § 1, sąd na wniosek dłużnika lub wierzyciela 
albo z urzędu ustanowi zarządcę. Do zarządcy stosuje się odpowiednio przepisy 
o zarządzie w egzekucji z nieruchomości.

***
## Art. 9103. {#kpc-trzecia--art-9103}

Do egzekucji z prawa majątkowego wchodzącego w skład majątku 
wspólnego małżonków stosuje się odpowiednio przepisy art. 9231.

***
## Art. 9104. {#kpc-trzecia--art-9104}

**§ 1.** Do oszacowania zajętego prawa komornik powołuje biegłego. 
**§ 2.** Wycena biegłego nie jest potrzebna, jeżeli strony zgodnie ustaliły wartość 
zajętego prawa albo jeżeli w okresie trzech miesięcy przed dokonaniem zajęcia 

 
 
 
s. 448/580 
 
2025-09-08 
 
zajęte prawo było oszacowane dla celów obrotu rynkowego lub w drodze umowy 
ustalono jego wartość dla potrzeb takiego obrotu. 
**§ 3.** W przypadkach wskazanych w § 2 za wartość prawa przyjmuje się 
wartość prawa ustaloną zgodnie przez strony albo we wcześniejszej umowie lub 
oszacowaniu.

***
## Art. 911. {#kpc-trzecia--art-911}

Na żądanie wierzyciela komornik sporządzi opis zajętego prawa 
majątkowego.

***
## Art. 9111. {#kpc-trzecia--art-9111}

W opisie komornik zamieści w szczególności: 
- 1) rodzaj zajętego prawa; 
- 2) oznaczenie osób uprawnionych oraz rodzaj przysługujących im uprawnień 
albo stwierdzenie o braku informacji o ich istnieniu; 
- 3) oznaczenie osób zobowiązanych, jeżeli są, i rodzaj ciążących na nich 
obowiązków; 
- 4) w razie istnienia sporu co do treści prawa lub rodzaju przysługujących 
uprawnień, rodzaj sporu, osoby dochodzące tych roszczeń oraz oznaczenie 
sądu lub innego organu, przed którym spór się toczy.

***
## Art. 9112. {#kpc-trzecia--art-9112}

**§ 1.** Zajęcie praw dłużnika przysługujących mu na wypadek 
wystąpienia ze spółki cywilnej lub jej rozwiązania dokonane jest z chwilą 
powiadomienia dłużnika o zajęciu. O zajęciu komornik powiadomi pozostałych 
wspólników, jeżeli ich adresy zostaną komornikowi podane przez którąkolwiek ze 
stron. 
**§ 2.** Pozostali wspólnicy w terminie dwóch tygodni od dnia zajęcia są 
obowiązani przedstawić komornikowi wykaz przedmiotów, wierzytelności i praw, 
które przypadną dłużnikowi na wypadek wystąpienia ze spółki lub jej rozwiązania. 
Przepisy art. 886 stosuje się odpowiednio.

***
## Art. 9113. {#kpc-trzecia--art-9113}

**§ 1.** Zajmując udział wspólnika w spółce handlowej albo prawa 
wspólnika z tytułu udziału w takiej spółce, którymi wspólnikowi wolno 
rozporządzać, jak również prawa majątkowe akcjonariusza, komornik powiadomi 
o zajęciu spółkę oraz zgłosi ten fakt sądowi rejestrowemu. 
**§ 2.** W razie zajęcia praw majątkowych zarejestrowanych w rejestrze 
akcjonariuszy, o którym mowa w art. 30030 § 1 i art. 3281 § 1 ustawy z dnia 
15 września 2000 r. – Kodeks spółek handlowych, komornik występuje także 

 
 
 
s. 449/580 
 
2025-09-08 
 
z żądaniem ujawnienia zajęcia tych praw do podmiotu prowadzącego ten rejestr, 
wzywając go do zawiadomienia, w terminie 7 dni od dnia doręczenia żądania, o: 
- 1) dacie wpisania zajęcia praw majątkowych w rejestrze akcjonariuszy albo 
przeszkodzie do jego dokonania; 
- 2) liczbie lub wartości oraz rodzaju, seriach i numerach albo odrębnych 
oznaczeniach, o których mowa w art. 55 ustawy z dnia 29 lipca 2005 r. 
o obrocie instrumentami finansowymi, zajętych praw majątkowych, jeżeli 
rejestr akcjonariuszy zawiera takie dane.

***
## Art. 9114. {#kpc-trzecia--art-9114}

Zajęcie prawa obejmuje również wszelkie wierzytelności 
i roszczenia przysługujące dłużnikowi z tytułu zajętego prawa, nawet jeżeli 
powstały po zajęciu.

***
## Art. 9115. {#kpc-trzecia--art-9115}

Jeżeli z zajętego prawa wynika wymagalne roszczenie, komornik 
wezwie dłużnika zajętej wierzytelności, aby spełnił świadczenie wierzycielowi lub 
komornikowi. Przepisy art. 887 stosuje się odpowiednio.

***
## Art. 9116. {#kpc-trzecia--art-9116}

**§ 1.** Zaspokojenie wierzyciela z zajętego prawa następuje 
z dochodu, jeżeli zajęte prawo przynosi dochód, albo z realizacji lub sprzedaży 
prawa. 
**§ 2.** Zaspokojenie z dochodu lub realizacji prawa, jeżeli nie nastąpi w trybie 
art. 9115, następuje w drodze egzekucji przez zarząd przymusowy. Przepisy 
art. 10641–106411 stosuje się odpowiednio. 
**§ 3.** (uchylony) 
**§ 4.** (uchylony)

***
## Art. 9117. {#kpc-trzecia--art-9117}

**§ 1.** Jeżeli przepis szczególny nie stanowi inaczej, komornik może 
sprzedać zajęte prawo z wolnej ręki po cenie nie niższej niż 75 % ceny 
oszacowania. Sprzedaż ta nie może nastąpić wcześniej niż czternastego dnia od 
oszacowania. 
**§ 2.** Na wniosek dłużnika, za zgodą wierzyciela, sprzedaż może nastąpić bez 
oszacowania prawa. Sprzedaż za wskazaną przez dłużnika cenę może nastąpić, gdy 
nie naruszyło to interesów wierzycieli. Dłużnik winien wówczas wskazać cenę 
minimalną, poniżej której sprzedaż nie może być dokonana. Dłużnik może wskazać 
osobę nabywcy albo też wskazać kilka osób uprawnionych do nabycia oraz 
kolejność, w jakiej prawo nabycia będzie im przysługiwało. 

 
 
 
s. 450/580 
 
2025-09-08 
**§ 3.** Jeżeli sprzedaż nie dojdzie do skutku w terminie tygodnia od dnia, 
w którym wierzyciel wyraził zgodę na sprzedaż, komornik sprzedaje zajęte prawo 
w drodze licytacji, chyba że wierzyciel wyrazi zgodę na ponowną sprzedaż 
z wolnej ręki. 
**§ 4.** Do sprzedaży prawa w drodze licytacji stosuje się odpowiednio przepisy 
o sprzedaży licytacyjnej w egzekucji z ruchomości. Ogłoszenia udostępniane 
w związku ze sprzedażą w drodze licytacji papierów wartościowych w rozumieniu 
ustawy z dnia 29 lipca 2005 r. o ofercie publicznej i warunkach wprowadzania 
instrumentów finansowych do zorganizowanego systemu obrotu oraz o spółkach 
publicznych (Dz. U. z 2024 r. poz. 620) nie stanowią oferty publicznej papierów 
wartościowych 
w rozumieniu 
art. 2 lit. d 
rozporządzenia 
Parlamentu 
Europejskiego i Rady (UE) 2017/1129 z dnia 14 czerwca 2017 r. w sprawie 
prospektu, który ma być publikowany w związku z ofertą publiczną papierów 
wartościowych lub dopuszczeniem ich do obrotu na rynku regulowanym oraz 
uchylenia dyrektywy 2003/71/WE (Dz. Urz. UE L 168 z 30.06.2017, str. 12). Do 
tej sprzedaży nie stosuje się przepisu art. 19 ust. 1 pkt 2 ustawy z dnia 29 lipca 
2005 r. o obrocie instrumentami finansowymi.

***
## Art. 9118. {#kpc-trzecia--art-9118}

**§ 1.** Do egzekucji z instrumentów finansowych zapisanych na 
rachunku papierów wartościowych lub innym rachunku, komornik przystąpi przez 
ich zajęcie. W tym celu komornik: 
- 1) zawiadamia dłużnika, że nie wolno mu odbierać żadnego świadczenia, jak 
również rozporządzać, z wyjątkiem zleceń, o których mowa w § 2, zajętymi 
instrumentami finansowymi czy wartościami zebranymi na rachunku; 
- 11) zawiadamia podmiot prowadzący działalność maklerską, w którym dłużnik 
ma rachunek, o charakterze egzekwowanych świadczeń, jeżeli egzekucja 
dotyczy świadczeń, o których mowa w art. 773 § 21; 
- 2) wezwie podmiot prowadzący działalność maklerską, w którym dłużnik ma 
rachunek, by nie wykonywał dyspozycji dłużnika, z wyjątkiem zleceń, 
o których mowa w § 2, ani też nie wypłacał dłużnikowi pieniędzy 
ulokowanych na jego rachunku, lecz zajęte sumy pieniężne do wysokości 
egzekwowanej należności wydał komornikowi lub złożył na rachunek 
depozytowy Ministra Finansów. 

 
 
 
s. 451/580 
 
2025-09-08 
**§ 11.** Komornik może doręczać pisma podmiotowi prowadzącemu działalność 
maklerską za pośrednictwem systemu teleinformatycznego obsługującego zajęcie 
wierzytelności z rachunku bankowego, a podmiot prowadzący działalność makler-
ską wnosi pisma do komornika za pośrednictwem tego systemu, jeżeli podmiot 
prowadzący działalność maklerską korzysta z tego systemu. 
**§ 2.** Jeżeli znajdujące się na rachunku dłużnika sumy pieniężne nie 
wystarczają na pokrycie egzekwowanego roszczenia, podmiot prowadzący 
działalność maklerską, w którym dłużnik ma rachunek, niezwłocznie wzywa 
dłużnika, aby w terminie trzech dni złożył zlecenie sprzedaży celem zaspokojenia 
wierzyciela przez okres miesiąca, wskazując, które ze zdeponowanych 
instrumentów finansowych mają być przedmiotem zlecenia sprzedaży. Jeżeli zajęto 
instrumenty finansowe, które wcześniej były zajęte na podstawie postanowienia 
o zabezpieczeniu, dyspozycja dłużnika dotycząca zlecenia ich sprzedaży będzie 
wykonana po zajęciu dokonanym w egzekucji, jeżeli samo zlecenie sprzedaży 
dłużnik złożył w terminie określonym w art. 7521. 
**§ 3.** Jeżeli dłużnik nie dokona czynności, o której mowa w § 2, albo pomimo 
wykonania czynności nie dojdzie do sprzedaży instrumentów finansowych, 
prowadzący rachunek w terminie trzech dni powiadamia wierzyciela, za 
pośrednictwem komornika, jakie instrumenty finansowe umieszczone są na 
rachunku. Wierzyciel 
składa zlecenie dokonania sprzedaży wybranych 
instrumentów finansowych. 
**§ 4.** W razie niezłożenia przez wierzyciela w terminie dwóch tygodni 
zlecenia, o którym mowa w § 3, albo gdy sprzedaż na zlecenie wierzyciela nie 
doszła do skutku przez okres roku, egzekucję umarza się. 
**§ 5.** Jeżeli zajęcia dokonano na rzecz dwu lub więcej wierzycieli, zlecenie, 
o którym mowa w § 3, składa kurator ustanowiony w trybie art. 908, chyba że 
wierzyciele złożą zgodny wniosek o sprzedaży instrumentów finansowych. W razie 
ustanowienia kuratora termin dwutygodniowy liczy się od dnia powołania kuratora. 
**§ 51.** W razie zbiegu egzekucji sądowej i administracyjnej, w przypadku gdy 
kwoty znajdujące się na rachunku nie wystarczają na pokrycie wszystkich 
egzekwowanych należności, podmiot prowadzący działalność maklerską, 
w którym dłużnik ma rachunek, dokonuje wypłat z tego rachunku na rzecz 
sądowego albo administracyjnego organu egzekucyjnego, który pierwszy dokonał 

 
 
 
s. 452/580 
 
2025-09-08 
 
zajęcia, a w razie niemożności ustalenia tego pierwszeństwa – na rzecz organu, 
który dokonał zajęcia na poczet należności w wyższej kwocie, oraz niezwłocznie 
zawiadamia o zbiegu egzekucji właściwe organy egzekucyjne, wskazując datę 
doręczenia zawiadomień o zajęciach dokonanych przez te organy i wysokość 
należności, na poczet których zostały dokonane zajęcia, o czym komornik poucza 
podmiot prowadzący działalność maklerską, w którym dłużnik ma rachunek, 
dokonując zajęcia. 
**§ 52.** W razie zbiegu egzekucji sądowej i administracyjnej, w przypadku gdy 
kwoty znajdujące się na rachunku nie wystarczają na pokrycie wszystkich 
egzekwowanych należności, jeżeli egzekucja dotyczy świadczeń, o których mowa 
w art. 773 § 21, podmiot prowadzący działalność maklerską, w którym dłużnik ma 
rachunek, dokonuje wypłat z tego rachunku na rzecz sądowego organu 
egzekucyjnego, a zawiadamiając o zbiegu egzekucji właściwe organy egzekucyjne, 
wskazuje na charakter egzekwowanych świadczeń. 
**§ 6.** Przepisów § 1–52 nie stosuje się do rachunku zbiorczego, o którym mowa 
w art. 8a ust. 1 ustawy z dnia 29 lipca 2005 r. o obrocie instrumentami 
finansowymi.

***
## Art. 912. {#kpc-trzecia--art-912}

**§ 1.** Jeżeli zajęte zostało prawo, z mocy którego dłużnik może żądać 
działu majątku, zajęcie obejmuje wszystko to, co dłużnikowi z działu przypadnie. 
Gdy dłużnik otrzyma z działu nieruchomość lub ułamkową jej część, sąd 
przeprowadziwszy dział zawiadomi o zajęciu sąd właściwy do prowadzenia księgi 
wieczystej w celu ujawnienia zajęcia przez wpis w księdze wieczystej lub złożenie 
zawiadomienia do zbioru dokumentów. Jeżeli wierzyciel w ciągu miesiąca po 
ukończeniu działu nie zażądał przeprowadzenia egzekucji z mienia przypadłego 
dłużnikowi, przedmioty majątkowe, z których egzekucji nie żądał, będą wolne od 
zajęcia. 
**§ 2.** O zajęciu prawa, z mocy którego dłużnik może żądać działu, komornik 
zawiadomi wskazane przez wierzyciela osoby, przeciwko którym dłużnikowi 
przysługuje prawo żądania działu. 

 
 
 
s. 453/580 
 
2025-09-08 
#### DZIAŁ V
Wyjawienie majątku

***
## Art. 913. {#kpc-trzecia--art-913}

**§ 1.** Jeżeli zajęty w egzekucji majątek dłużnika nie rokuje 
zaspokojenia egzekwowanych należności lub jeżeli wierzyciel wykaże, że na 
skutek prowadzonej egzekucji nie uzyskał w pełni zaspokojenia swej należności, 
może on żądać zobowiązania dłużnika do złożenia wykazu majątku z 
wymienieniem rzeczy i miejsca, gdzie się znajdują, przypadających mu 
wierzytelności i innych praw majątkowych lub informacji o odpłatnych i 
nieodpłatnych czynnościach prawnych, których przedmiotem jest rzecz lub prawo 
o wartości przekraczającej w dniu dokonania tych czynności wysokość 
minimalnego wynagrodzenia za pracę ustalonego na podstawie przepisów ustawy 
z dnia 10 października 2002 r. o minimalnym wynagrodzeniu za pracę, dokonanych 
na rzecz osób trzecich, w pięcioletnim okresie poprzedzającym wszczęcie 
egzekucji, w wyniku których stał się niewypłacalny albo stał się niewypłacalny w 
wyższym stopniu niż był przed dokonaniem czynności, oraz do złożenia 
przyrzeczenia według roty: „Świadomy znaczenia mych słów i odpowiedzialności 
przed prawem zapewniam, że złożony przeze mnie wykaz majątku jest prawdziwy 
i zupełny.”. 
**§ 11.** Dłużnik składa wykaz, o którym mowa w § 1, pod rygorem 
odpowiedzialności karnej za złożenie fałszywego oświadczenia, o czym sąd poucza 
go przed odebraniem wykazu. 
**§ 2.** Wierzyciel może żądać wyjawienia majątku także przed wszczęciem 
egzekucji, jeżeli: 
- 1) uprawdopodobni, że nie uzyska zaspokojenia w pełni swojej należności ze 
znanego mu majątku albo z przypadających dłużnikowi bieżących świadczeń 
periodycznych za okres sześciu miesięcy; 
- 2) po uzyskaniu tytułu wykonawczego wezwał dłużnika do zapłaty stwierdzonej 
nim należności listem poleconym za potwierdzeniem odbioru, a dłużnik nie 
spełnił świadczenia w terminie 14 dni od dnia doręczenia wezwania do 
zapłaty. 
**§ 3.** Komornik poucza wierzyciela występującego w sprawie bez adwokata, 
radcy prawnego, rzecznika patentowego lub radcy Prokuratorii Generalnej 

 
 
 
s. 454/580 
 
2025-09-08 
 
Rzeczypospolitej Polskiej o prawie i sposobie złożenia wniosku o wyjawienie 
majątku dłużnika, o którym mowa w § 1. Równocześnie z pouczeniem wierzyciela 
komornik poucza dłużnika występującego w sprawie bez adwokata, radcy 
prawnego, 
rzecznika 
patentowego 
lub 
radcy 
Prokuratorii 
Generalnej 
Rzeczypospolitej Polskiej o skutkach wyjawienia majątku, w szczególności o treści 
art. 55 pkt 3 ustawy z dnia 20 sierpnia 1997 r. o Krajowym Rejestrze Sądowym.

***
## Art. 914. {#kpc-trzecia--art-914}

**§ 1.** Wniosek o nakazanie dłużnikowi wyjawienia majątku składa 
się w sądzie właściwości ogólnej dłużnika. 
**§ 2.** Do wniosku należy dołączyć odpis protokołu zajęcia lub inne dokumenty 
uzasadniające obowiązek wyjawienia majątku, a jeżeli wniosek złożono przed 
wszczęciem egzekucji, także tytuł wykonawczy.

***
## Art. 915. {#kpc-trzecia--art-915}

**§ 1.** Sąd rozpoznaje wniosek po wezwaniu i wysłuchaniu stron, 
jeżeli się stawią. 
**§ 2.** Wykaz i przyrzeczenie sąd odbierze niezwłocznie. W uzasadnionych 
wypadkach sąd może wyznaczyć dłużnikowi termin nie dłuższy niż tydzień. 
**§ 3.** Na postanowienie sądu w przedmiocie wyjawienia majątku przysługuje 
zażalenie. Wniesienie zażalenia nie tamuje wykonania postanowienia o wyjawieniu 
majątku. Sąd może postąpić stosownie do art. 396.

***
## Art. 916. {#kpc-trzecia--art-916}

**§ 1.** Jeżeli dłużnik bez usprawiedliwionej przyczyny nie stawi się 
do sądu w celu złożenia wykazu lub przyrzeczenia albo stawiwszy się wykazu nie 
złoży lub odmówi odpowiedzi na zadane mu pytanie albo odmówi złożenia 
przyrzeczenia, sąd może skazać go na grzywnę lub nakazać przymusowe 
doprowadzenie oraz może zastosować areszt nieprzekraczający miesiąca, 
z uwzględnieniem art. 276 § 2. O skutkach tych dłużnik powinien być pouczony 
w wezwaniu na posiedzenie. W razie wykonania czynności przez dłużnika lub 
umorzenia postępowania grzywny niezapłacone do tego czasu ulegają umorzeniu. 
**§ 2.** Na postanowienie sądu w przedmiocie skazania na grzywnę oraz 
orzeczenie aresztu przysługuje zażalenie. 
**§ 3.** Jeżeli dłużnikiem jest osoba prawna lub jednostka organizacyjna, o której 
mowa w art. 64 § 11, środkom przymusu podlegają osoby uprawnione do działania 
w jej imieniu. 

 
 
 
s. 455/580 
 
2025-09-08

***
## Art. 917. {#kpc-trzecia--art-917}

**§ 1.** W razie zastosowania środków przymusu dłużnik może 
w każdej chwili złożyć wykaz i przyrzeczenie. W wypadku gdy zastosowano 
wobec niego areszt, dłużnik może domagać się stawienia go przed sąd w celu 
złożenia wykazu i przyrzeczenia. W wypadku tym sąd nie wzywając wierzyciela 
niezwłocznie przyjmie wykaz i odbierze przyrzeczenie, po czym zwolni dłużnika. 
**§ 2.** Wierzyciel, który nie był obecny przy tych czynnościach, może żądać 
ponownego wezwania dłużnika w celu zadania mu pytań zmierzających do 
wykrycia przedmiotów, do których mogłaby być skierowana egzekucja. 
Niestawiennictwo dłużnika lub odmowa odpowiedzi albo dodatkowego złożenia 
przyrzeczenia pociąga za sobą skutki wymienione w artykule poprzedzającym. 
O skutkach tych dłużnik powinien być pouczony w wezwaniu na posiedzenie.

***
## Art. 918. {#kpc-trzecia--art-918}

(uchylony)

***
## Art. 9181. {#kpc-trzecia--art-9181}

Dłużnik, który złożył przyrzeczenie lub do którego zastosowano 
środki przymusu, obowiązany jest do złożenia nowego wykazu i przyrzeczenia na 
żądanie tego samego lub innego wierzyciela, gdy od złożenia przyrzeczenia lub 
wyczerpania środków przymusu upłynął okres jednego roku.

***
## Art. 919. {#kpc-trzecia--art-919}

Za 
osobę, 
która 
nie 
ma 
zdolności 
procesowej, 
wykaz 
i przyrzeczenie obowiązany jest złożyć jej przedstawiciel ustawowy.

***
## Art. 920. {#kpc-trzecia--art-920}

**§ 1.** Przepisy niniejszego działu stosuje się odpowiednio do 
egzekucji prowadzonej z urzędu, a także egzekucji alimentów. 
**§ 2.** W razie egzekucji alimentów sąd prowadzi postępowanie o wyjawienie 
majątku także na wniosek komornika.

***
## Art. 9201. {#kpc-trzecia--art-9201}

**§ 1.** Przepisy art. 913–917, 919 i 920 stosuje się odpowiednio do 
wyjawienia przez dłużnika stanu oszczędności na rachunkach bankowych 
w związku z żądaniem wydania książeczki oszczędnościowej lub innego dowodu 
posiadania wkładu. W wykazie majątku dłużnik jest obowiązany podać, czy i jakie 
oszczędności ma na rachunku bankowym, w jakim banku zostały zgromadzone, 
jeżeli zaś nie posiada dowodu bankowego, jest obowiązany wskazać osobę, u której 
znajduje się ten dowód. 
**§ 2.** Uchylenie się dłużnika od wydania książeczki oszczędnościowej lub 
innego odpowiedniego dowodu albo wskazania osoby, u której się one znajdują, 

 
 
 
s. 456/580 
 
2025-09-08 
 
powoduje takie skutki, jak odmowa złożenia wykazu albo udzielenia odpowiedzi 
na pytanie (art. 916).

***
## Art. 9202. {#kpc-trzecia--art-9202}

(uchylony) 
#### DZIAŁ VI
Egzekucja z nieruchomości 
Rozdział 1 
Przepisy wstępne

***
## Art. 921. {#kpc-trzecia--art-921}

**§ 1.** Egzekucja z nieruchomości należy do komornika działającego 
przy sądzie, w którego okręgu nieruchomość jest położona. 
**§ 2.** Jeżeli nieruchomość jest położona w okręgu kilku sądów, wybór należy 
do wierzyciela. Jednakże z postępowaniem wszczętym na wniosek jednego 
wierzyciela połączone będą postępowania wszczęte na wniosek innych wierzycieli. 
W tym celu komornik, który rozpoczął egzekucję, o wszczęciu, a następnie 
o ukończeniu egzekucji zawiadomi komornika, do którego, stosownie do paragrafu 
poprzedzającego, mogłaby należeć egzekucja.

***
## Art. 9211. {#kpc-trzecia--art-9211}

O wszczęciu i ukończeniu egzekucji komornik zawiadamia sąd 
właściwy ze względu na miejsce położenia nieruchomości.

***
## Art. 922. {#kpc-trzecia--art-922}

Uczestnikami postępowania oprócz wierzyciela i dłużnika są 
również osoby, którym przysługują prawa rzeczowe ograniczone lub roszczenia 
albo prawa osobiste zabezpieczone na nieruchomości, a gdy przedmiotem 
egzekucji jest użytkowanie wieczyste, także organ, który zawarł umowę 
o użytkowanie wieczyste. 
Rozdział 2 
Zajęcie

***
## Art. 923. {#kpc-trzecia--art-923}

Wskutek 
wniosku 
wierzyciela 
o wszczęcie 
egzekucji 
z nieruchomości wymienionej we wniosku komornik wzywa dłużnika, aby zapłacił 
dług w ciągu dwóch tygodni pod rygorem przystąpienia do opisu i oszacowania.

***
## Art. 9231. {#kpc-trzecia--art-9231}

**§ 1.** Tytuł 
wykonawczy 
wystawiony 
przeciwko 
osobie 
pozostającej w związku małżeńskim stanowi podstawę do zajęcia nieruchomości 

 
 
 
s. 457/580 
 
2025-09-08 
 
wchodzącej w skład majątku wspólnego. Dalsze czynności egzekucyjne 
dopuszczalne są na podstawie tytułu wykonawczego wystawionego przeciwko 
obojgu małżonkom. 
**§ 2.** Jeżeli małżonek dłużnika sprzeciwi się zajęciu, o sprzeciwie komornik 
niezwłocznie zawiadamia wierzyciela, który w terminie tygodniowym powinien 
wystąpić o nadanie przeciwko małżonkowi dłużnika klauzuli wykonalności pod 
rygorem umorzenia egzekucji z zajętej nieruchomości.

***
## Art. 924. {#kpc-trzecia--art-924}

**§ 1.** Jednocześnie z wysłaniem dłużnikowi wezwania komornik 
składa do sądu właściwego do prowadzenia księgi wieczystej wniosek o wpis 
o wszczęciu egzekucji lub o złożenie wniosku do zbioru dokumentów, wraz z od-
pisem wezwania do zapłaty. 
**§ 2.** W przypadku umorzenia postępowania egzekucyjnego lub ukończenia 
egzekucji w inny sposób niż przez umorzenie komornik składa wniosek 
o wykreślenie w księdze wieczystej wpisu o wszczęciu egzekucji lub o usunięcie 
wniosku o wszczęcie egzekucji ze zbioru dokumentów. Obowiązek poprawienia 
lub uzupełnienia wniosku spoczywa na komorniku.

***
## Art. 925. {#kpc-trzecia--art-925}

**§ 1.** W stosunku do dłużnika nieruchomość jest zajęta z chwilą 
doręczenia mu wezwania. W stosunku do dłużnika, któremu nie doręczono 
wezwania, jako też w stosunku do osób trzecich, nieruchomość jest zajęta z chwilą 
dokonania wpisu w księdze wieczystej lub złożenia wniosku komornika do zbioru 
dokumentów. 
**§ 2.** Jednakże w stosunku do każdego, kto wiedział o wszczęciu egzekucji, 
skutki zajęcia powstają z chwilą, gdy o wszczęciu egzekucji powziął wiadomość, 
chociażby wezwanie nie zostało jeszcze dłużnikowi wysłane ani wpis w księdze 
wieczystej nie był jeszcze dokonany. 
**§ 3.** O dokonanym zajęciu komornik zawiadamia wierzyciela.

***
## Art. 926. {#kpc-trzecia--art-926}

**§ 1.** Postępowania egzekucyjne toczące się co do kilku 
nieruchomości tego samego dłużnika lub co do kilku części tej samej 
nieruchomości, jak również postępowania egzekucyjne dotyczące części 
nieruchomości i jej całości, mogą być połączone w jedno postępowanie, jeżeli 
odpowiada to celowi egzekucji, a nie ma przeszkód natury prawnej lub 
gospodarczej. Połączenie zarządza na wniosek jednej ze stron komornik, a gdy 

 
 
 
s. 458/580 
 
2025-09-08 
 
nieruchomości są położone w okręgach różnych sądów rejonowych, sąd okręgowy 
przełożony nad sądem rejonowym, w którego okręgu wszczęto pierwszą egzekucję. 
**§ 2.** Postępowanie można rozdzielić, jeżeli w dalszym jego toku odpadną 
przyczyny, które spowodowały połączenie.

***
## Art. 927. {#kpc-trzecia--art-927}

**§ 1.** Wierzyciel, który skierował egzekucję do nieruchomości po jej 
zajęciu przez innego wierzyciela, przyłącza się do postępowania wszczętego 
wcześniej i nie może żądać powtórzenia czynności już dokonanych; poza tym ma 
te same prawa co pierwszy wierzyciel. 
**§ 2.** W przypadku, o którym mowa w § 1, komornik składa do sądu 
właściwego do prowadzenia księgi wieczystej wniosek o wpis o przyłączeniu się 
wierzyciela do egzekucji lub o złożenie wniosku do zbioru dokumentów.

***
## Art. 928. {#kpc-trzecia--art-928}

W celu dopilnowania praw osoby, której miejsce pobytu nie jest 
znane i której z powodu nieobecności nie można dokonywać doręczeń, sąd na 
wniosek komornika ustanowi kuratora do zastępowania osoby nieobecnej. Kurator 
będzie wykonywał swe czynności także w interesie innych osób, którym w dalszym 
toku postępowania doręczenia nie będą mogły być dokonane. Kurator może jednak 
reprezentować równocześnie tylko osoby, których interesy nie są sprzeczne.

***
## Art. 929. {#kpc-trzecia--art-929}

**§ 1.** Zajęcie obejmuje nieruchomość i to wszystko, co według 
przepisów prawa rzeczowego stanowi przedmiot obciążenia hipoteką. 
**§ 11.** Pobranie z góry przez dłużnika przed zajęciem czynszu najmu za czas 
dłuższy niż trzy miesiące, a czynszu dzierżawy za czas dłuższy niż sześć miesięcy, 
licząc w obu przypadkach od dnia zajęcia, nie zwalnia najemcy lub dzierżawcy 
od obowiązku zapłaty czynszu do rąk komornika. 
**§ 2.** Zajęcie obejmuje także prawa wynikające z umów ubezpieczenia 
przedmiotów 
wymienionych 
w § 1. 
Do odszkodowania 
z ubezpieczeń 
majątkowych przepisu art. 831 § 1 pkt 5 nie stosuje się, a uzyskane w toku 
egzekucji świadczenia wchodzą w skład sumy uzyskanej w egzekucji. 
**§ 3.** Komornik z urzędu zbada, czy ruchomości, wierzytelności lub prawa 
zajęte według przepisów § 1 i § 2 nie są obciążone zastawem rejestrowym. 
Przepisy art. 8051 § 1 i § 4 stosuje się odpowiednio.

***
## Art. 930. {#kpc-trzecia--art-930}

**§ 1.** Rozporządzenie nieruchomością po jej zajęciu nie ma wpływu 
na dalsze postępowanie, a kolejni wierzyciele dłużnika mogą przyłączyć się do 

 
 
 
s. 459/580 
 
2025-09-08 
 
prowadzonej 
egzekucji. 
Nabywca 
może 
uczestniczyć 
w postępowaniu 
w charakterze dłużnika. W każdym razie czynności egzekucyjne są ważne tak w 
stosunku do dłużnika, jak i w stosunku do nabywcy. 
**§ 11.** Zajęcie nieruchomości, o której mowa w § 1, przez wierzycieli nabywcy 
jest dopuszczalne. Postępowanie prowadzone przez wierzyciela nabywcy podlega 
jednak zawieszeniu na czas trwania postępowania egzekucyjnego wszczętego 
wcześniej przeciwko dłużnikowi będącemu zbywcą nieruchomości. W razie 
uprawomocnienia się postanowienia o przysądzeniu własności nieruchomości 
wydanego w postępowaniu prowadzonym przeciwko dłużnikowi będącemu 
zbywcą nieruchomości, postępowanie prowadzone co do tej samej nieruchomości 
celem zaspokojenia wierzycieli nabywcy, o którym mowa w § 1, podlega 
umorzeniu. 
**§ 2.** Rozporządzenia 
przedmiotami 
podlegającymi 
zajęciu 
razem 
z nieruchomością po ich zajęciu są nieważne. Nie dotyczy to rozporządzeń 
zarządcy nieruchomości w zakresie jego ustawowych uprawnień. 
**§ 3.** Obciążenie nieruchomości przez dłużnika po jej zajęciu oraz 
rozporządzenie opróżnionym miejscem hipotecznym jest nieważne. W razie 
wpisania hipoteki przymusowej po zajęciu nieruchomości zabezpieczona nią 
wierzytelność nie korzysta z pierwszeństwa zaspokojenia przewidzianego dla 
należności zabezpieczonych hipotecznie. 
**§ 4.** Oddanie zajętej nieruchomości w użyczenie, leasing, najem lub 
dzierżawę jest bezskuteczne wobec nabywcy nieruchomości w egzekucji.

***
## Art. 931. {#kpc-trzecia--art-931}

**§ 1.** Zajętą nieruchomość pozostawia się w zarządzie dłużnika, do 
którego stosuje się wówczas przepisy o zarządcy. 
**§ 2.** Jeżeli prawidłowe sprawowanie zarządu tego wymaga, sąd odejmie 
dłużnikowi zarząd i ustanowi innego zarządcę; to samo dotyczy ustanowionego 
zarządcy. 
**§ 3.** Sąd oddali wniosek o ustanowienie innego zarządcy, jeżeli sprawowanie 
zarządu wymaga kosztów, na których pokrycie nie wystarczają na razie dochody 
bieżące, a wnioskodawca nie złoży w ciągu tygodnia kwoty wyznaczonej przez sąd. 
**§ 4.** Jeżeli dłużnik, któremu odjęto zarząd, w chwili zajęcia korzystał 
z pomieszczeń w zajętej nieruchomości, należy mu je pozostawić. Sąd może jednak 
na wniosek wierzyciela zarządzić odebranie pomieszczeń, jeżeli dłużnik lub jego 

 
 
 
s. 460/580 
 
2025-09-08 
 
domownik przeszkadza zarządcy w wykonywaniu zarządu. Zarządca może 
zatrudniać dłużnika i jego rodzinę za wynagrodzeniem, które ustali sąd.

***
## Art. 932. {#kpc-trzecia--art-932}

(uchylony)

***
## Art. 933. {#kpc-trzecia--art-933}

Jeżeli zarządca przy obejmowaniu zarządu napotyka przeszkody, 
komornik na polecenie sądu wprowadza go w zarząd nieruchomości.

***
## Art. 934. {#kpc-trzecia--art-934}

Po ustanowieniu zarządcy komornik wzywa wskazane przez 
wierzyciela osoby, aby przypadające od nich tak zaległe, jak i przyszłe 
świadczenia, które stanowią dochód z nieruchomości, uiszczały do rąk zarządcy. 
W wezwaniu należy uprzedzić, że uiszczenie do rąk dłużnika będzie bezskuteczne 
w stosunku do wierzyciela.

***
## Art. 935. {#kpc-trzecia--art-935}

**§ 1.** Zarządca zajętej nieruchomości obowiązany jest wykonywać 
czynności potrzebne do prowadzenia prawidłowej gospodarki. Ma on prawo 
pobierać zamiast dłużnika wszelkie pożytki z nieruchomości, spieniężać je w gra-
nicach zwykłego zarządu oraz prowadzić sprawy, które przy wykonywaniu takiego 
zarządu okażą się potrzebne. W sprawach wynikających z zarządu nieruchomością 
zarządca może pozywać i być pozywany. 
**§ 2.** Zarządcy wolno zaciągać tylko takie zobowiązania, które mogą być 
zaspokojone z dochodów z nieruchomości i są gospodarczo uzasadnione. 
**§ 3.** Czynności przekraczające zakres zwykłego zarządu zarządca może 
wykonywać tylko za zgodą stron, a w jej braku – za zezwoleniem sądu, który przed 
wydaniem postanowienia wysłucha wierzyciela, dłużnika i zarządcę, chyba że 
zwłoka groziłaby szkodą.

***
## Art. 936. {#kpc-trzecia--art-936}

Zarząd nie ma wpływu na umowy najmu lub dzierżawy 
obowiązujące w chwili jego ustanowienia. Zarządcy wolno jednak wypowiadać 
tego rodzaju umowy z zachowaniem obowiązujących przepisów oraz zawierać 
umowy na czas przyjęty przez zwyczaj miejscowy. Do wydzierżawiania 
nieruchomości wymagana jest zgoda stron, a w jej braku – zezwolenie sądu.

***
## Art. 937. {#kpc-trzecia--art-937}

**§ 1.** Zarządca składa sądowi w wyznaczonych terminach co 
najmniej raz w roku oraz po ukończeniu zarządu sprawozdania ze swych czynności, 
jak również udokumentowane sprawozdania rachunkowe. 

 
 
 
s. 461/580 
 
2025-09-08 
**§ 2.** Sąd po wysłuchaniu wierzycieli, dłużnika i zarządcy oraz po rozpatrzeniu 
sprawozdań, a zwłaszcza przedstawionych w nich pozycji rachunkowych, 
zatwierdza sprawozdania zarządcy albo odmawia ich zatwierdzenia w całości lub 
w części. 
**§ 3.** Na postanowienie sądu w przedmiocie zatwierdzenia sprawozdania 
przysługuje zażalenie.

***
## Art. 938. {#kpc-trzecia--art-938}

**§ 1.** Zarządca odpowiada za szkodę wyrządzoną na skutek 
nienależytego wykonywania obowiązków. 
**§ 2.** Zarządca, 
który 
bez 
usprawiedliwionej 
przyczyny 
nie 
złożył 
w oznaczonym terminie przepisanego sprawozdania lub nie wykonał innych przez 
sąd wydanych poleceń, może być skazany na grzywnę.

***
## Art. 939. {#kpc-trzecia--art-939}

**§ 1.** Zarządca może żądać wynagrodzenia oraz zwrotu wydatków, 
które w związku z zarządem poniósł z własnych funduszów. Wysokość 
wynagrodzenia sąd określi odpowiednio do nakładu pracy i dochodowości 
nieruchomości. 
**§ 2.** Jednakże zarządcy, który jest dłużnikiem, nie należy się wynagrodzenie; 
może on tylko pokrywać z pożytków z nieruchomości najkonieczniejsze potrzeby 
własne i rodziny w rozmiarze, jaki oznaczy sąd, oraz swoje wydatki związane 
z zarządem. 
**§ 3.** (uchylony) 
**§ 4.** Roszczeń 
o wynagrodzenie 
za 
sprawowanie 
zarządu 
i o zwrot 
poniesionych 
w związku 
z zarządem 
wydatków 
nie 
można 
dochodzić 
powództwem. Zarządca traci roszczenia, jeżeli ich nie zgłosił w ciągu miesiąca po 
ustąpieniu z zarządu lub po jego ustaniu.

***
## Art. 940. {#kpc-trzecia--art-940}

**§ 1.** Z dochodów z nieruchomości zarządca pokrywa bezpośrednio 
konieczne wydatki, połączone z zarządem, w następującej kolejności: 
- 1) koszty egzekucji w postaci wynagrodzenia w ustalonej przez sąd wysokości 
oraz zwrot własnych wydatków; 
- 2) bieżące należności pracowników zatrudnionych w nieruchomości lub 
w przedsiębiorstwach znajdujących się na niej i należących do dłużnika; 
- 3) bieżące należności podatkowe z nieruchomości oraz bieżące należności 
z tytułu ubezpieczenia społecznego pracowników wymienionych w pkt 2; 

 
 
 
s. 462/580 
 
2025-09-08 
- 4) zobowiązania związane z wykonywaniem zarządu; 
- 5) należności z tytułu ubezpieczenia nieruchomości, jej przynależności 
i pożytków. 
**§ 2.** Nadwyżki dochodów uzyskane po pokryciu wydatków, o których mowa 
w § 1, zarządca przekazuje nie rzadziej niż raz w roku komornikowi, który pokrywa 
z nich przypadające w toku zarządu należności wierzycieli alimentacyjnych.

***
## Art. 941. {#kpc-trzecia--art-941}

Nadwyżkę dochodów pozostałą po zaspokojeniu należności, 
o których mowa w art. 940 § 2, za czas do dnia przejścia własności nieruchomości 
na nabywcę, komornik składa na rachunek depozytowy Ministra Finansów. 
Nadwyżka ta wchodzi w skład sumy uzyskanej w egzekucji. Jeżeli egzekucja ulega 
umorzeniu, nadwyżkę tę otrzymuje dłużnik, z uwzględnieniem art. 985 § 11. 
Rozdział 3 
Opis i oszacowanie

***
## Art. 942. {#kpc-trzecia--art-942}

Po upływie terminu określonego w wezwaniu dłużnika do zapłaty 
długu komornik na wniosek wierzyciela dokonuje opisu i oszacowania zajętej 
nieruchomości.

***
## Art. 943. {#kpc-trzecia--art-943}

**§ 1.** Przy wniosku o dokonanie opisu i oszacowania wierzyciel 
powinien: 
- 1) złożyć wyciąg – a w razie potrzeby odpis księgi wieczystej albo 
zaświadczenie sądu wystawione na podstawie zbioru dokumentów 
prowadzonego dla nieruchomości, zawierające wskazanie jej właściciela 
i wykaz ujawnionych w tym zbiorze obciążeń, jeżeli zaś nieruchomość jest 
objęta katastrem nieruchomości – także odpowiedni wyciąg; 
- 2) wskazać miejsce zamieszkania uczestników postępowania. 
**§ 2.** Jeżeli nieruchomość nie ma księgi wieczystej, wierzyciel powinien złożyć 
inny dokument stwierdzający własność dłużnika. 
**§ 3.** Dokumentów wskazanych w paragrafie poprzedzającym może żądać od 
właściwych organów także komornik.

***
## Art. 944. {#kpc-trzecia--art-944}

(uchylony)

***
## Art. 945. {#kpc-trzecia--art-945}

**§ 1.** O terminie opisu i oszacowania komornik zawiadamia znanych 
mu uczestników. 

 
 
 
s. 463/580 
 
2025-09-08 
**§ 2.** Komornik wzywa ponadto przez obwieszczenie publiczne w budynku 
sądowym oraz na stronie internetowej Krajowej Rady Komorniczej uczestników, 
o których nie ma wiadomości, oraz inne osoby, które roszczą sobie prawa do 
nieruchomości i przedmiotów razem z nią zajętych, aby przed ukończeniem opisu 
i oszacowania zgłosiły swoje prawa. 
**§ 21.** Poza informacjami, o których mowa w § 2, w obwieszczeniu wymienia 
się nadto: 
- 1) nieruchomość, która ma być przedmiotem opisu i oszacowania, ze 
wskazaniem miejsca jej położenia i przeznaczenia gospodarczego, wraz 
z podaniem numeru księgi wieczystej lub z oznaczeniem zbioru dokumentów 
i sądu, w którym zbiór jest prowadzony, a także imienia i nazwiska dłużnika, 
z wyłączeniem innych danych osobowych pozwalających go zidentyfikować; 
- 2) termin i miejsce opisu i oszacowania. 
**§ 3.** Zawiadomienia i obwieszczenia powinny być dokonane nie później niż 
na dwa tygodnie przed rozpoczęciem opisu. 
**§ 31.** Niezwłocznie po upływie wskazanego w obwieszczeniu terminu opisu 
i oszacowania podmiot obowiązany do jego udostępnienia usuwa obwieszczenie. 
**§ 4.** Jeżeli opis i oszacowanie nie zostały ukończone w terminie podanym 
w zawiadomieniu, komornik o fakcie ukończenia opisu i oszacowania zawiadomi 
znanych mu uczestników.

***
## Art. 946. {#kpc-trzecia--art-946}

**§ 1.** Na wniosek wierzyciela lub dłużnika, zgłoszony nie później niż 
podczas opisu i oszacowania, jak również z urzędu może być wystawiona na 
licytację wydzielona część zajętej nieruchomości, której cena wywołania wystarcza 
na zaspokojenie wierzyciela egzekwującego. O wydzieleniu rozstrzyga komornik 
po oszacowaniu nieruchomości. 
**§ 2.** Na postanowienie sądu przysługuje zażalenie. 
**§ 3.** W razie wydzielenia części, dalsze postępowanie co do reszty 
nieruchomości będzie zawieszone do czasu ukończenia licytacji wydzielonej 
części.

***
## Art. 947. {#kpc-trzecia--art-947}

**§ 1.** W protokole opisu i oszacowania komornik wymieni: 
- 1) oznaczenie nieruchomości, jej granice, a w miarę możności jej obszar oraz 
oznaczenie księgi wieczystej lub zbioru dokumentów; 

 
 
 
s. 464/580 
 
2025-09-08 
- 2) budowle i inne urządzenia ze wskazaniem ich przeznaczenia gospodarczego 
oraz przynależności nieruchomości, jak również zapasy objęte zajęciem; 
- 3) stwierdzone prawa i obciążenia; 
- 4) umowy ubezpieczenia; 
- 5) osoby, w których posiadaniu znajduje się nieruchomość, jej przynależności 
i pożytki; 
- 6) sposób korzystania z nieruchomości przez dłużnika; 
- 7) oszacowanie z podaniem jego podstaw; 
- 8) zgłoszone prawa do nieruchomości; 
- 9) inne szczegóły istotne dla oznaczenia lub oszacowania nieruchomości. 
**§ 11.** Jeżeli na ruchomościach, wierzytelnościach lub prawach zajętych 
wspólnie z nieruchomością ustanowiony został zastaw rejestrowy, w opisie należy 
wymienić przedmiot obciążony zastawem rejestrowym oraz wierzytelność, którą 
zastaw ten zabezpiecza. 
**§ 2.** Minister Sprawiedliwości określi, w drodze rozporządzenia, szczegółowy 
sposób przeprowadzenia opisu i oszacowania nieruchomości, mając na względzie 
zapewnienie prawidłowej wyceny nieruchomości oraz sprawność postępowania 
i skuteczność egzekucji.

***
## Art. 948. {#kpc-trzecia--art-948}

**§ 1.** Podstawą oszacowania nieruchomości jest operat szacunkowy 
sporządzony przez biegłego uprawnionego do określania wartości nieruchomości 
zgodnie z ustawą z dnia 21 sierpnia 1997 r. o gospodarce nieruchomościami 
(Dz. U. z 2024 r. poz. 1145 i 1222). Celem sporządzenia operatu szacunkowego, 
w rozumieniu 
art. 156 ust. 3 tej 
ustawy, 
jest 
dokonanie 
oszacowania 
nieruchomości. Oszacowania nieruchomości można również dokonać na podstawie 
operatu szacunkowego sporządzonego na potrzeby obrotu rynkowego w okresie 
roku przed terminem opisu i oszacowania nieruchomości, jeżeli jego treść 
odpowiada wymogom oszacowania nieruchomości w egzekucji z nieruchomości. 
**§ 11.** Jeżeli wniosek o wszczęcie nowej egzekucji złożono do tego samego 
komornika w terminie trzech lat od daty umorzenia egzekucji, w toku której 
dokonano opisu i oszacowania nieruchomości, nowego oszacowania dokonuje się 
tylko na wniosek wierzyciela lub dłużnika. Dłużnik może złożyć taki wniosek 
w terminie dwóch tygodni od daty doręczenia mu wezwania do zapłaty, o czym 
należy go pouczyć przy doręczeniu wezwania. W toku nowej egzekucji od 

 
 
 
s. 465/580 
 
2025-09-08 
 
sporządzenia protokołu opisu i oszacowania nieruchomości można odstąpić 
wyłącznie w przypadku, jeżeli od dnia przeprowadzenia poprzedniego opisu 
i oszacowania minął mniej niż rok, a w okresie tym nie zaszły zmiany w stanie 
nieruchomości. 
**§ 2.** W oszacowaniu poza wartością całej nieruchomości należy podać osobno 
wartość przynależności i pożytków, a także części nieruchomości, która zgodnie 
z art. 946 może zostać wydzielona celem wystawienia oddzielnie na licytację. 
Wartości powyższe należy podać zarówno z uwzględnieniem, jak i bez 
uwzględnienia praw, które pozostają w mocy bez zaliczenia na cenę nabycia, oraz 
wartości praw nieokreślonych sumą pieniężną obciążających nieruchomość, 
w szczególności świadczeń z tytułu takich praw. 
**§ 3.** Opisem i oszacowaniem należy objąć z osobna każdą nieruchomość 
stanowiącą przedmiot egzekucji, jeżeli jest ona wpisana do odrębnej księgi 
wieczystej lub prowadzony jest dla niej odrębny zbiór dokumentów. Jeżeli jednak 
postępowania egzekucyjne toczące się co do kilku nieruchomości tego samego 
dłużnika, wpisanych do oddzielnych ksiąg wieczystych lub dla których prowadzone 
są odrębne zbiory dokumentów, połączone zostały w jedno postępowanie, to 
w przypadku gdy nieruchomości te stanowią całość gospodarczą, należy opisać 
i oszacować tę całość i każdą z nieruchomości z osobna.

***
## Art. 949. {#kpc-trzecia--art-949}

Jeżeli zostały zgłoszone prawa osób trzecich do nieruchomości, 
budowli lub innych urządzeń, przynależności lub pożytków albo gdy rzeczy takie 
znajdują się we władaniu osób trzecich, oznacza się osobno wartość rzeczy spornej, 
osobno wartość całości po wyłączeniu tej rzeczy, wreszcie osobno wartość całości 
tak z uwzględnieniem, jak i bez uwzględnienia praw, które pozostają w mocy bez 
zaliczenia na cenę nabycia, oraz wartości praw nieokreślonych sumą pieniężną, 
obciążających nieruchomość, w szczególności świadczeń z tytułu takich praw.

***
## Art. 950. {#kpc-trzecia--art-950}

Termin zaskarżenia opisu i oszacowania wynosi dwa tygodnie 
i liczy się od dnia jego ukończenia. Jeżeli opis i oszacowanie nie zostały ukończone 
w terminie podanym w zawiadomieniu, termin do zaskarżenia liczy się od dnia 
doręczenia uczestnikowi zawiadomienia, o którym mowa w art. 945 § 4. Na 
postanowienie sądu przysługuje zażalenie. 

 
 
 
s. 466/580 
 
2025-09-08

***
## Art. 951. {#kpc-trzecia--art-951}

Jeżeli w stanie nieruchomości pomiędzy sporządzeniem opisu 
i oszacowania a terminem licytacyjnym zajdą istotne zmiany, na wniosek 
wierzyciela lub dłużnika może nastąpić dodatkowy opis i oszacowanie. 
Rozdział 4 
Obwieszczenie o licytacji

***
## Art. 952. {#kpc-trzecia--art-952}

Zajęta nieruchomość ulega sprzedaży przez licytację publiczną. 
Termin licytacji nie może być wyznaczony wcześniej niż po upływie dwóch 
tygodni po uprawomocnieniu się opisu i oszacowania ani też przed 
uprawomocnieniem się wyroku, na podstawie którego wszczęto egzekucję.

***
## Art. 9521. {#kpc-trzecia--art-9521}

**§ 1.** Termin licytacji lokalu mieszkalnego lub nieruchomości 
gruntowej zabudowanej budynkiem mieszkalnym, które służą zaspokojeniu 
potrzeb mieszkaniowych dłużnika, wyznacza się na wniosek wierzyciela. 
**§ 2.** Wierzyciel jest uprawniony do złożenia wniosku, o którym mowa w § 1, 
jeżeli wysokość egzekwowanej należności głównej stanowi co najmniej 
równowartość jednej dwudziestej części sumy oszacowania. 
**§ 3.** Jeżeli egzekucję z nieruchomości prowadzi kilku wierzycieli, termin 
licytacji nieruchomości, o której mowa w § 1, wyznacza się również w przypadku, 
gdy wnioski w tym przedmiocie złożyli wierzyciele, których łączna wysokość 
egzekwowanych należności głównych stanowi co najmniej równowartość jednej 
dwudziestej części sumy oszacowania. 
**§ 4.** Przepisów § 2 i 3 nie stosuje się, jeżeli należność przysługuje Skarbowi 
Państwa, wynika z wyroku wydanego w postępowaniu karnym lub mimo 
niespełnienia warunków przewidzianych w tych przepisach zgodę na wyznaczenie 
terminu licytacji wyraził dłużnik, do którego nieruchomość należy, albo sąd. Sąd 
wyraża zgodę na wyznaczenie terminu licytacji na wniosek wierzyciela, jeżeli 
przemawia za tym wysokość i charakter dochodzonej należności lub brak 
możliwości zaspokojenia wierzyciela z innych składników majątku dłużnika. Na 
postanowienie sądu oddalające wniosek wierzyciela przysługuje zażalenie. 
**§ 5.** (uchylony)

***
## Art. 953. {#kpc-trzecia--art-953}

**§ 1.** Komornik ogłosi o licytacji przez publiczne obwieszczenie, 
w którym wymienia: 

 
 
 
s. 467/580 
 
2025-09-08 
- 1) nieruchomość, która ma być sprzedana, ze wskazaniem miejsca jej położenia 
i przeznaczenia gospodarczego, wraz z podaniem numeru księgi wieczystej 
lub z oznaczeniem zbioru dokumentów i sądu, w którym zbiór jest 
prowadzony, a także imienia i nazwiska dłużnika, z wyłączeniem innych 
danych osobowych pozwalających go zidentyfikować; 
- 2) czas i miejsce licytacji; 
- 3) sumę oszacowania i cenę wywołania; 
- 4) wysokość rękojmi, którą licytant przystępujący do przetargu powinien złożyć, 
z zaznaczeniem, że rękojmia może być również złożona w książeczce 
oszczędnościowej zaopatrzonej w upoważnienie właściciela książeczki do 
wypłaty całego wkładu stosownie do prawomocnego postanowienia sądu 
o utracie rękojmi albo w inny wskazany przez komornika sposób; 
- 5) czas, w którym w ciągu dwóch tygodni przed licytacją wolno będzie oglądać 
nieruchomość oraz przeglądać w sądzie protokół opisu i oszacowania; 
ponadto w obwieszczeniu należy podać: 
- 6) wzmiankę, że prawa osób trzecich nie będą przeszkodą do licytacji 
i przysądzenia własności na rzecz nabywcy bez zastrzeżeń, jeżeli osoby te 
przed rozpoczęciem przetargu nie złożą dowodu, iż wniosły powództwo 
o zwolnienie nieruchomości lub przedmiotów razem z nią zajętych od 
egzekucji i uzyskały w tym zakresie orzeczenie wstrzymujące egzekucję; 
- 7) wyjaśnienie, że użytkowanie, służebności i prawa dożywotnika, jeżeli nie są 
ujawnione w księdze wieczystej lub przez złożenie dokumentu do zbioru 
dokumentów i nie zostaną zgłoszone najpóźniej na trzy dni przed 
rozpoczęciem licytacji, nie będą uwzględnione w dalszym toku egzekucji 
i wygasną z chwilą uprawomocnienia się postanowienia o przysądzeniu 
własności. 
**§ 2.** (uchylony) 
**§ 3.** (uchylony)

***
## Art. 954. {#kpc-trzecia--art-954}

Obwieszczenie o licytacji doręcza się: 
- 1) uczestnikom postępowania; 
- 2) organowi gminy, urzędowi skarbowemu miejsca położenia nieruchomości 
oraz organom ubezpieczeń społecznych z wezwaniem, aby najpóźniej 

 
 
 
s. 468/580 
 
2025-09-08 
 
w terminie licytacji zgłosiły zestawienie podatków i innych danin 
publicznych, należnych do dnia licytacji.

***
## Art. 955. {#kpc-trzecia--art-955}

**§ 1.** Obwieszczenie o licytacji należy co najmniej dwa tygodnie 
przed jej terminem ogłosić publicznie na stronie internetowej oraz tablicy ogłoszeń 
sądu sprawującego nadzór nad egzekucją z nieruchomości, w lokalu organu gminy 
właściwego ze względu na miejsce położenia nieruchomości oraz na stronie 
internetowej Krajowej Rady Komorniczej. 
**§ 11.** Podmiot obowiązany do udostępnienia obwieszczenia usuwa je 
niezwłocznie po upływie wskazanego w obwieszczeniu terminu licytacji. 
**§ 2.** Na wniosek i koszt strony komornik może zarządzić ogłoszenie również 
w inny wskazany przez nią sposób, w szczególności w dzienniku lub czasopiśmie 
poczytnym w danej miejscowości. 
**§ 3.** W ogłoszeniu, o którym mowa w § 2, podaje się oznaczenie 
nieruchomości, czas i miejsce licytacji, sumę oszacowania i cenę wywołania oraz 
wysokość rękojmi, jaką licytant powinien złożyć.

***
## Art. 956. {#kpc-trzecia--art-956}

Jeżeli egzekucja dotyczy jednej lub kilku nieruchomości 
położonych w różnych okręgach sądowych, obwieszczenie ogłasza się publicznie 
we wszystkich właściwych sądach.

***
## Art. 957. {#kpc-trzecia--art-957}

(uchylony)

***
## Art. 958. {#kpc-trzecia--art-958}

**§ 1.** Z chwilą obwieszczenia o licytacji nieruchomości wchodzącej 
w skład gospodarstwa rolnego współwłaścicielowi tej nieruchomości, który nie jest 
dłużnikiem osobistym, przysługuje aż do trzeciego dnia przed licytacją prawo 
przejęcia nieruchomości na własność w cenie nie niższej od sumy oszacowania. 
Przy wniosku o przejęcie wnioskodawca powinien złożyć rękojmię, chyba że 
ustawa go od niej zwalnia. 
**§ 2.** Jeżeli kilku współwłaścicieli zgłosi wniosek o przejęcie, pierwszeństwo 
przysługuje temu z nich, który prowadzi gospodarstwo rolne lub pracuje w nim. 
Jeżeli warunek ten spełnia kilku współwłaścicieli albo nie spełnia go żaden z nich, 
sąd przyzna pierwszeństwo temu współwłaścicielowi, który daje najlepszą 
gwarancję należytego prowadzenia gospodarstwa rolnego.

***
## Art. 959. {#kpc-trzecia--art-959}

O pierwszeństwie 
przejęcia 
nieruchomości 
w myśl 
dwóch 
artykułów poprzedzających rozstrzyga sąd, wydając postanowienie o przybiciu. 

 
 
 
s. 469/580 
 
2025-09-08

***
## Art. 960. {#kpc-trzecia--art-960}

Jeżeli nikt z prawa przejęcia nieruchomości na podstawie trzech 
artykułów poprzedzających wcześniej nie skorzysta albo jeżeli przedmiotem 
egzekucji nie jest nieruchomość rolna, komornik po dokonaniu obwieszczeń 
przedstawia akta sądowi. W razie spostrzeżenia niedokładności lub wadliwości 
postępowania sąd poleci komornikowi ich usunięcie.

***
## Art. 961. {#kpc-trzecia--art-961}

(uchylony) 
Rozdział 5 
Warunki licytacyjne

***
## Art. 962. {#kpc-trzecia--art-962}

**§ 1.** Przystępujący do przetargu obowiązany jest złożyć rękojmię 
w wysokości jednej dziesiątej części sumy oszacowania, najpóźniej w dniu 
poprzedzającym przetarg. 
**§ 2.** (uchylony)

***
## Art. 963. {#kpc-trzecia--art-963}

Rękojmię złożoną przez licytanta, któremu udzielono przybicia, 
zatrzymuje się; pozostałym licytantom zwraca się ją niezwłocznie.

***
## Art. 964. {#kpc-trzecia--art-964}

**§ 1.** Nie składa rękojmi osoba, której przysługuje ujawnione 
w opisie i oszacowaniu prawo, jeżeli jego wartość nie jest niższa od wysokości 
rękojmi i jeżeli do tej wysokości znajduje ono pokrycie w cenie wywołania wraz 
z prawami stwierdzonymi w opisie i oszacowaniu, korzystającymi z pierwszeństwa 
przed jej prawem. 
**§ 2.** Jeżeli w warunkach przewidzianych w paragrafie poprzedzającym 
wartość prawa jest niższa od wysokości rękojmi albo też prawo znajduje tylko 
częściowe pokrycie w cenie wywołania, wysokość rękojmi obniża się w pierwszym 
wypadku do różnicy między pełną rękojmią a wartością prawa, w drugim zaś 
wypadku do części wartości prawa niepokrytej w cenie wywołania.

***
## Art. 965. {#kpc-trzecia--art-965}

Najniższa suma, za którą nieruchomość można nabyć na pierwszej 
licytacji (cena wywołania), wynosi trzy czwarte sumy oszacowania.

***
## Art. 966. {#kpc-trzecia--art-966}

(uchylony)

***
## Art. 967. {#kpc-trzecia--art-967}

Po uprawomocnieniu się postanowienia o przybiciu komornik 
wzywa licytanta, który uzyskał przybicie (nabywcę), aby w ciągu dwóch tygodni 
od dnia otrzymania wezwania złożył na rachunek depozytowy Ministra Finansów 

 
 
 
s. 470/580 
 
2025-09-08 
 
cenę nabycia z potrąceniem rękojmi złożonej w gotówce. Na wniosek nabywcy 
komornik 
może 
oznaczyć 
dłuższy 
termin 
uiszczenia 
ceny 
nabycia, 
nieprzekraczający jednak miesiąca.

***
## Art. 968. {#kpc-trzecia--art-968}

**§ 1.** Nabywca może zaliczyć na poczet ceny własną wierzytelność 
lub jej część, jeżeli znajduje ona pokrycie w cenie nabycia. 
**§ 2.** (uchylony)

***
## Art. 969. {#kpc-trzecia--art-969}

**§ 1.** Jeżeli 
nabywca 
nie 
wykonał 
w terminie 
warunków 
licytacyjnych co do zapłaty ceny, traci rękojmię, a skutki przybicia wygasają. 
Uiszczoną część ceny zwraca się. Następstwa te sąd stwierdza postanowieniem, na 
które przysługuje zażalenie. 
**§ 2.** Od nabywcy nieskładającego rękojmi, który nie wykonał warunków 
licytacyjnych, ściąga się rękojmię w trybie egzekucji należności sądowych. 
**§ 3.** Z rękojmi utraconej przez nabywcę lub od niego ściągniętej pokrywa się 
koszty egzekucji związane ze sprzedażą, a reszta wchodzi w skład sumy uzyskanej 
w egzekucji albo jeżeli egzekucja została umorzona, jest przelewana na dochód 
Skarbu Państwa.

***
## Art. 970. {#kpc-trzecia--art-970}

Po 
uprawomocnieniu 
się 
postanowienia 
stwierdzającego 
wygaśnięcie przybicia wierzyciel może żądać wyznaczenia ponownej licytacji.

***
## Art. 971. {#kpc-trzecia--art-971}

Nabywca nie może żądać unieważnienia nabycia ani zmniejszenia 
ceny z powodu wad nieruchomości lub przedmiotów razem z nią nabytych. 
Rozdział 6 
Licytacja

***
## Art. 972. {#kpc-trzecia--art-972}

**§ 1.** Licytacja odbywa się publicznie w obecności i pod nadzorem 
sędziego albo referendarza sądowego. 
**§ 2.** Przebieg licytacji sąd utrwala również za pomocą urządzenia 
rejestrującego dźwięk albo obraz i dźwięk.

***
## Art. 973. {#kpc-trzecia--art-973}

Po wywołaniu licytacji komornik podaje do wiadomości obecnych: 
- 1) przedmiot przetargu; 
- 2) cenę wywołania; 
- 3) sumę rękojmi; 
- 4) termin uiszczenia ceny nabycia; 

 
 
 
s. 471/580 
 
2025-09-08 
- 5) (uchylony) 
- 6) prawa 
obciążające 
nieruchomość, 
które 
będą 
utrzymane 
w mocy 
z zaliczeniem i bez zaliczenia na cenę nabycia; 
- 7) wynikające z akt zmiany w stanie faktycznym i prawnym nieruchomości, 
jeżeli zaszły po jej opisie i oszacowaniu.

***
## Art. 974. {#kpc-trzecia--art-974}

Przedmiotem przetargu jest nieruchomość według stanu objętego 
opisem i oszacowaniem z uwzględnieniem zmian podanych do wiadomości przez 
komornika na terminie licytacyjnym.

***
## Art. 975. {#kpc-trzecia--art-975}

Jeżeli ma być sprzedanych kilka nieruchomości lub kilka części 
jednej nieruchomości, dłużnik ma prawo wskazać kolejność, w jakiej ma być 
przeprowadzony przetarg poszczególnych nieruchomości lub części.

***
## Art. 976. {#kpc-trzecia--art-976}

**§ 1.** W przetargu nie mogą uczestniczyć: dłużnik, komornik, ich 
małżonkowie, dzieci, rodzice i rodzeństwo oraz osoby obecne na licytacji 
w charakterze urzędowym, licytant, który nie wykonał warunków poprzedniej 
licytacji, osoby, które mogą nabyć nieruchomość tylko za zezwoleniem organu 
państwowego, a zezwolenia tego nie przedstawiły. 
**§ 2.** Stawienie się jednego licytanta wystarcza do odbycia przetargu.

***
## Art. 977. {#kpc-trzecia--art-977}

Pełnomocnictwo do udziału w przetargu powinno być stwierdzone 
dokumentem 
z podpisem 
urzędowo 
poświadczonym. 
Podpisy 
na 
pełnomocnictwach udzielonych przez państwowe jednostki organizacyjne lub 
jednostki organizacyjne samorządu terytorialnego oraz na pełnomocnictwach 
udzielonych adwokatom lub radcom prawnym nie wymagają poświadczenia.

***
## Art. 978. {#kpc-trzecia--art-978}

**§ 1.** Przetarg odbywa się ustnie. 
**§ 2.** Postąpienie nie może wynosić mniej niż jeden procent ceny wywołania, 
z zaokrągleniem wzwyż do pełnych złotych. 
**§ 3.** Zaofiarowana cena przestaje wiązać, gdy inny licytant zaofiarował cenę 
wyższą.

***
## Art. 979. {#kpc-trzecia--art-979}

**§ 1.** Jeżeli w tym samym postępowaniu ma być sprzedanych kilka 
nieruchomości lub kilka części jednej nieruchomości i jeżeli za te, które już zostały 
sprzedane, osiągnięto cenę wystarczającą na zaspokojenie należności wierzyciela 

 
 
 
s. 472/580 
 
2025-09-08 
 
egzekwującego 
i kosztów 
egzekucyjnych, 
komornik 
wstrzyma 
przetarg 
pozostałych nieruchomości lub ich części. 
**§ 2.** Jeżeli przy podziale sumy uzyskanej za sprzedane niektóre tylko 
nieruchomości lub niektóre części nieruchomości okaże się, że należność 
wierzyciela i koszty egzekucji istotnie znajdują w tej sumie pełne pokrycie, 
egzekucję co do pozostałych nieruchomości lub części nieruchomości należy 
umorzyć.

***
## Art. 980. {#kpc-trzecia--art-980}

Po ustaniu postąpień komornik, uprzedzając obecnych, że po 
trzecim obwieszczeniu dalsze postąpienia nie będą przyjęte, obwieści trzykrotnie 
ostatnio zaofiarowaną cenę, zamknie przetarg i wymieni licytanta, który 
zaofiarował najwyższą cenę.

***
## Art. 981. {#kpc-trzecia--art-981}

Jeżeli należność wierzyciela będzie uiszczona wraz z kosztami 
przed zamknięciem przetargu, komornik umorzy egzekucję.

***
## Art. 982. {#kpc-trzecia--art-982}

**§ 1.** Jeżeli na licytacji nikt nie przystąpił do przetargu, 
a przedmiotem egzekucji jest nieruchomość rolna, współwłaściciel nieruchomości 
wystawionej na licytację, niebędący dłużnikiem osobistym, ma prawo przejęcia 
nieruchomości na własność w cenie nie niższej od trzech czwartych sumy 
oszacowania. Art. 958 § 2 stosuje się odpowiednio. 
**§ 2.** Wniosek o przejęcie nieruchomości należy zgłosić w ciągu tygodnia od 
licytacji, składając równocześnie rękojmię, chyba że ustawa wnioskodawcę od niej 
zwalnia. 
**§ 3.** Jeżeli na licytacji nikt nie przystąpił do przetargu, a przedmiotem 
egzekucji jest spółdzielcze własnościowe prawo do lokalu, wierzyciel hipoteczny 
może przejąć to prawo za cenę nie niższą od trzech czwartych sumy oszacowania; 
wniosek o przejęcie należy zgłosić w ciągu tygodnia od licytacji. Wierzyciel 
hipoteczny nie składa rękojmi.

***
## Art. 983. {#kpc-trzecia--art-983}

Jeżeli nikt nie zgłosił wniosku o przejęcie nieruchomości w myśl 
artykułu poprzedzającego albo przedmiot egzekucji nie jest nieruchomością rolną, 
komornik na wniosek wierzyciela wyznacza drugą licytację, na której cena 
wywołania stanowi dwie trzecie sumy oszacowania. Cena ta jest najniższa, za którą 
można nabyć nieruchomość. 

 
 
 
s. 473/580 
 
2025-09-08

***
## Art. 984. {#kpc-trzecia--art-984}

**§ 1.** Jeżeli również na drugiej licytacji nikt nie przystąpi do 
przetargu, przejęcie nieruchomości na własność może nastąpić w cenie nie niższej 
od dwóch trzecich części sumy oszacowania, przy czym prawo przejęcia 
przysługuje 
wierzycielowi 
egzekwującemu 
i hipotecznemu 
oraz 
współwłaścicielowi. Jeżeli przedmiotem egzekucji jest nieruchomość rolna, stosuje 
się art. 982 z wynikającą z niniejszego przepisu zmianą co do ceny przejęcia. 
W wypadku gdy osoby określone w art. 982 nie skorzystają z prawa przejęcia 
nieruchomości rolnej, prawo to przysługuje także wierzycielowi egzekwującemu 
i hipotecznemu. 
**§ 2.** Wniosek o przejęcie nieruchomości wierzyciel powinien złożyć sądowi 
w ciągu tygodnia po licytacji, składając jednocześnie rękojmię, chyba że ustawa go 
od niej zwalnia. 
**§ 3.** Jeżeli kilku wierzycieli składa wniosek o przejęcie, pierwszeństwo 
przysługuje temu, kto zaofiarował cenę wyższą, a przy równych cenach – temu, 
czyja należność jest większa.

***
## Art. 985. {#kpc-trzecia--art-985}

**§ 1.** Jeżeli po drugiej licytacji żaden z wierzycieli nie przejął 
nieruchomości na własność, postępowanie egzekucyjne umarza się i nowa 
egzekucja z tej nieruchomości może być wszczęta dopiero po upływie 6 miesięcy 
od daty drugiej licytacji. 
**§ 11.** Jeżeli w toku egzekucji uzyskano sumy, o których mowa w art. 929 § 2 
lub art. 941, przed umorzeniem postępowania egzekucyjnego sporządza się plan 
podziału tych sum, z uwzględnieniem pierwszeństwa przysługującego należ-
nościom zabezpieczonym hipoteką lub zastawem rejestrowym. Przepis 
art. 10361 stosuje się. 
**§ 2.** (uchylony)

***
## Art. 986. {#kpc-trzecia--art-986}

Skargę na czynności komornika w toku licytacji aż do zamknięcia 
przetargu zgłasza się ustnie sędziemu albo referendarzowi sądowemu 
nadzorującemu licytację, który natychmiast ją rozstrzyga. 

 
 
 
s. 474/580 
 
2025-09-08 
 
Rozdział 6a 
Sprzedaż nieruchomości w drodze licytacji elektronicznej

***
## Art. 9861. {#kpc-trzecia--art-9861}

**§ 1.** Do sprzedaży nieruchomości w drodze licytacji elektronicznej 
stosuje się przepisy rozdziałów 4–6 i 7 z odrębnościami 
wynikającymi 
z niniejszego rozdziału. 
**§ 2.** Do sprzedaży nieruchomości w drodze licytacji elektronicznej przepisów 
art. 8091 § 1 pkt 5 oraz art. 972 § 2 nie stosuje się.

***
## Art. 9862. {#kpc-trzecia--art-9862}

**§ 1.** Sprzedaż nieruchomości w drodze licytacji elektronicznej 
przeprowadza się na wniosek wierzyciela. Wniosek o dokonanie sprzedaży 
w drodze licytacji elektronicznej może zostać złożony także w razie złożenia 
wniosku o wyznaczenie ponownej lub drugiej licytacji. 
**§ 2.** Jeżeli nieruchomość została zajęta na zaspokojenie kilku wierzytelności 
dochodzonych przez różnych wierzycieli, sprzedaży nieruchomości w drodze 
licytacji elektronicznej dokonuje się, jeżeli zażądał tego którykolwiek 
z wierzycieli.

***
## Art. 9863. {#kpc-trzecia--art-9863}

**§ 1.** Komornik w terminie tygodnia od dnia otrzymania od 
wierzyciela wniosku o przeprowadzenie sprzedaży nieruchomości w drodze 
licytacji elektronicznej zawiadamia o tym fakcie dłużnika. W zawiadomieniu 
wskazuje się nieruchomość lub część nieruchomości, których wniosek dotyczy, 
oraz poucza dłużnika o treści art. 975. 
**§ 2.** Uprawnienie wynikające z art. 975 dłużnik może zrealizować w terminie 
tygodnia od dnia doręczenia mu zawiadomienia, o którym mowa w § 1. Po upływie 
wskazanego terminu kolejność przeprowadzenia przetargu poszczególnych 
nieruchomości lub ich części określa komornik. 
**§ 3.** Przetargi dotyczące różnych nieruchomości lub ich części, zajętych 
w tym samym postępowaniu należy zaplanować tak, aby nie toczyły się 
równocześnie. Przepisu zdania pierwszego nie stosuje się, jeżeli łączna wysokość 
sumy oszacowania tych nieruchomości nie przekracza łącznej wysokości 
należności wierzycieli egzekwujących i kosztów egzekucyjnych. 
**§ 4.** Licytacja nie może rozpocząć się wcześniej niż dwa tygodnie od dnia 
upływu terminu, o którym mowa w § 2 zdanie pierwsze. 

 
 
 
s. 475/580 
 
2025-09-08

***
## Art. 9864. {#kpc-trzecia--art-9864}

**§ 1.** Sprzedaż nieruchomości w drodze licytacji elektronicznej jest 
przeprowadzana za pośrednictwem systemu teleinformatycznego. 
**§ 2.** Warunkiem udziału w przetargu jest utworzenie indywidualnego konta 
w systemie teleinformatycznym. 
**§ 3.** Obwieszczenie 
o sprzedaży 
nieruchomości 
w drodze 
licytacji 
elektronicznej zamieszcza się na stronie internetowej Krajowej Rady Komorniczej 
co najmniej dwa tygodnie przed terminem licytacji. Przepisów art. 955 
i art. 956 nie stosuje się. 
**§ 4.** W obwieszczeniu, 
o którym 
mowa 
w § 3, 
komornik 
wymienia 
informacje, o których mowa w art. 953 § 1 pkt 3, 6 i 7, a ponadto: 
- 1) nieruchomość, która ma być sprzedana, ze wskazaniem miejsca jej położenia 
i przeznaczenia gospodarczego wraz z podaniem księgi wieczystej i miejsca 
jej przechowania lub z oznaczeniem zbioru dokumentów i sądu, w którym 
zbiór ten jest prowadzony; 
- 2) informację o tym, że przetarg odbywa się w drodze elektronicznej, oraz 
o chwili rozpoczęcia i zakończenia przetargu; 
- 3) informację o obowiązku uiszczenia rękojmi i jej wysokości; 
- 4) czas, w którym w ciągu dwóch tygodni przed licytacją wolno będzie oglądać 
nieruchomość. 
**§ 5.** W systemie teleinformatycznym wraz z obwieszczeniem o licytacji 
nieruchomości udostępnia się protokół opisu i oszacowania nieruchomości. Nie 
podlegają ujawnieniu zawarte w protokole opisu i oszacowania nieruchomości 
dane osobowe stron i innych uczestników postępowania. 
**§ 6.** Krajowa 
Rada 
Komornicza 
usuwa 
obwieszczenie 
o sprzedaży 
nieruchomości w drodze licytacji elektronicznej z upływem dnia wskazanego jako 
termin zakończenia przetargu.

***
## Art. 9865. {#kpc-trzecia--art-9865}

**§ 1.** Rękojmię należy złożyć na rachunek bankowy najpóźniej na 
2 dni robocze przed rozpoczęciem przetargu. Za datę złożenia rękojmi przyjmuje 
się dzień uznania rachunku bankowego komornika. Przepisu art. 964 nie 
stosuje się. 
**§ 2.** Wraz z rękojmią licytant zobowiązany jest do podania w systemie 
teleinformatycznym danych niezbędnych do wydania postanowienia o przybiciu: 
numeru PESEL, numeru dokumentu stwierdzającego tożsamość i oświadczenia, 

 
 
 
s. 476/580 
 
2025-09-08 
 
czy pozostaje w związku małżeńskim, a jeżeli tak, czy nieruchomość zamierza 
nabyć do majątku wspólnego czy osobistego, oraz do wskazania, czy licytuje we 
własnym imieniu czy jako pełnomocnik innej osoby, a także innych danych, jeżeli 
potrzeba ich podania wynika z przepisów odrębnych ustaw. 
**§ 3.** W razie potrzeby komornik niezwłocznie wzywa licytanta, pod rygorem 
niedopuszczenia 
do 
udziału 
w przetargu, 
za 
pośrednictwem 
systemu 
teleinformatycznego do uzupełnienia danych, a jeżeli udział w przetargu wymaga 
zezwolenia organu władzy publicznej lub wykazania umocowania do 
występowania w imieniu innej osoby – do przedłożenia utrwalonych w postaci 
elektronicznej kopii wymaganych dokumentów w terminie 3 dni, nie później niż 
dzień przed terminem licytacji. 
**§ 4.** Komornik potwierdza fakt złożenia rękojmi i podania danych, o których 
mowa w § 2, niezwłocznie po ich otrzymaniu, poprzez dopuszczenie licytanta do 
udziału w przetargu. O odmowie dopuszczenia do przetargu zawiadamia się 
zainteresowanego za pośrednictwem systemu teleinformatycznego.

***
## Art. 9866. {#kpc-trzecia--art-9866}

Na 
dzień 
przed 
rozpoczęciem 
przetargu 
w systemie 
teleinformatycznym udostępnia się informacje, o których mowa w art. 973, oraz 
pouczenia o treści przepisów art. 967, art. 969, art. 971, art. 976, art. 978 § 2, 
art. 981, art. 9867 § 31 i 5 oraz art. 9868.

***
## Art. 9867. {#kpc-trzecia--art-9867}

**§ 1.** Przetarg rozpoczyna się i kończy z chwilą wskazaną 
w obwieszczeniu o licytacji nieruchomości. 
**§ 2.** Komornik wyznacza licytację elektroniczną w taki sposób, aby zarówno 
termin rozpoczęcia, jak i zakończenia przetargu przypadał pomiędzy godziną 9.00 
a 14.00 w dni robocze. Czas trwania przetargu wynosi 7 dni. 
**§ 3.** W toku przetargu licytanci ofiarują cenę nabycia za pośrednictwem 
systemu teleinformatycznego. Przepisu art. 980 nie stosuje się. 
**§ 31.** Jeżeli w ciągu 5 minut przed planowanym terminem zakończenia 
przetargu zgłoszono postąpienie, termin ten ulega odroczeniu o 5 minut. Jeżeli 
w dodatkowym czasie zgłoszono dalsze postąpienie, termin zakończenia przetargu 
podlega każdorazowo odroczeniu o kolejne 5 minut, aż do momentu gdy ustaną 
postąpienia. 

 
 
 
s. 477/580 
 
2025-09-08 
**§ 4.** W razie 
umorzenia 
egzekucji 
na 
podstawie 
art. 981 komornik 
niezwłocznie 
anuluje 
przetarg. 
Jeżeli 
w jednym 
z kilku 
prowadzonych 
równocześnie na podstawie art. 9863 § 3 zdanie drugie przetargów zaofiarowano 
cenę przekraczającą łączną wysokość należności wierzycieli egzekwujących 
i kosztów egzekucyjnych, komornik może anulować pozostałe przetargi. Z chwilą 
anulowania przetargu zaofiarowane przez licytantów ceny przestają wiązać. 
**§ 5.** Przetarg wygrywa licytant, którego oferta była w chwili zakończenia 
przetargu najwyższa. 
**§ 6.** Po zakończeniu przetargu komornik za pośrednictwem systemu 
teleinformatycznego informuje licytantów o wyłonieniu licytanta ofiarującego 
najwyższą cenę w chwili zakończenia przetargu.

***
## Art. 9868. {#kpc-trzecia--art-9868}

**§ 1.** Skargę na odmowę dopuszczenia do przetargu można złożyć 
w terminie 3 dni od dnia odmowy dopuszczenia do przetargu, a na przebieg 
przetargu – w terminie 3 dni od dnia jego zakończenia. 
**§ 2.** Licytanci i osoby, których nie dopuszczono do przetargu, mogą złożyć 
skargę wyłącznie za pośrednictwem systemu teleinformatycznego. 
**§ 3.** Skargę za pośrednictwem systemu teleinformatycznego mogą złożyć 
także osoby niewymienione w § 2, o ile posiadają w tym systemie konto.

***
## Art. 9869. {#kpc-trzecia--art-9869}

Niezwłocznie po zamknięciu przetargu, nie później niż w terminie 
tygodnia, komornik przesyła sądowi protokół z przebiegu przetargu, wszystkie 
nierozpoznane skargi oraz dokumenty niezbędne do udzielenia przybicia.

***
## Art. 98610. {#kpc-trzecia--art-98610}

**§ 1.** Sąd albo referendarz sądowy wydaje postanowienie co do 
przybicia na posiedzeniu niejawnym w terminie tygodnia od dnia otrzymania 
protokołu z przebiegu przetargu oraz dokumentów niezbędnych do udzielenia 
przybicia. Przepis art. 988 § 2 stosuje się. 
**§ 2.** Wysłuchania licytanta, który zaofiarował najwyższą cenę, oraz 
uczestników przetargu dokonuje się jedynie wtedy, gdy jest to konieczne dla 
wydania postanowienia co do przybicia.

***
## Art. 98611. {#kpc-trzecia--art-98611}

Minister Sprawiedliwości określi, w drodze rozporządzenia, 
sposób 
przeprowadzenia 
sprzedaży 
nieruchomości 
w drodze 
licytacji 
elektronicznej 
oraz 
sposób 
uwierzytelniania 
użytkowników 
systemu 
teleinformatycznego obsługującego licytację elektroniczną, mając na względzie 

 
 
 
s. 478/580 
 
2025-09-08 
 
zapewnienie ochrony praw osób uczestniczących w licytacji, sprawność 
postępowania, 
skuteczność 
egzekucji, 
bezpieczeństwo 
posługiwania 
się 
dokumentami 
w postaci 
elektronicznej 
oraz 
dostępność 
systemu 
teleinformatycznego. 
Rozdział 7 
Przybicie

***
## Art. 987. {#kpc-trzecia--art-987}

Po zamknięciu przetargu sąd w osobie sędziego albo referendarz 
sądowy, pod którego nadzorem odbywa się licytacja, wydaje na posiedzeniu 
jawnym postanowienie co do przybicia na rzecz licytanta, który zaofiarował 
najwyższą cenę, po wysłuchaniu tak jego, jak i obecnych uczestników.

***
## Art. 988. {#kpc-trzecia--art-988}

**§ 1.** Postanowienie o przybiciu ogłasza się niezwłocznie po 
ukończeniu przetargu; ogłoszenie można jednak odroczyć najdalej na tydzień, 
jeżeli zgłoszono skargę, której natychmiastowe rozstrzygnięcie nie jest możliwe, 
jak również z innych ważnych przyczyn. 
**§ 2.** Jeżeli 
skargi 
lub 
zażalenia 
wniesione 
w toku 
postępowania 
egzekucyjnego nie są jeszcze prawomocnie rozstrzygnięte, sąd może wstrzymać 
wydanie postanowienia co do udzielenia przybicia.

***
## Art. 989. {#kpc-trzecia--art-989}

Gdy przejęcie nieruchomości na własność ma nastąpić po niedojściu 
do skutku drugiej licytacji, sąd udzieli przybicia na rzecz przejmującego 
nieruchomość po wysłuchaniu wnioskodawcy oraz uczestników, jeżeli stawią się 
na posiedzenie.

***
## Art. 990. {#kpc-trzecia--art-990}

W postanowieniu o przybiciu wymienia się imię i nazwisko 
nabywcy, oznaczenie nieruchomości, datę przetargu i cenę nabycia.

***
## Art. 991. {#kpc-trzecia--art-991}

**§ 1.** Sąd odmówi przybicia z powodu naruszenia przepisów 
postępowania w toku licytacji, jeżeli uchybienia te mogły mieć istotny wpływ na 
wynik przetargu. 
**§ 2.** Sąd odmówi również przybicia, jeżeli postępowanie podlegało umorzeniu 
lub zawieszeniu albo jeżeli uczestnik nie otrzymał zawiadomienia o licytacji, chyba 
że z tego powodu nie nastąpiło naruszenie jego praw albo że będąc na licytacji nie 
wystąpił ze skargą na to uchybienie. 

 
 
 
s. 479/580 
 
2025-09-08

***
## Art. 992. {#kpc-trzecia--art-992}

Jeżeli sąd odmówi przybicia, komornik na wniosek wierzyciela 
wyznaczy ponowną licytację.

***
## Art. 993. {#kpc-trzecia--art-993}

**§ 1.** Jeżeli przybicie nie następuje niezwłocznie po ukończeniu 
przetargu, sąd na wniosek licytanta, który zaofiarował najwyższą cenę, może, 
w wypadku gdy zarządcą jest dłużnik, odjąć mu zarząd i ustanowić innego 
zarządcę. 
**§ 2.** Po przybiciu sąd wyda zarządzenie, o którym mowa w paragrafie 
poprzedzającym, na wniosek nabywcy lub uczestnika postępowania. Nabywca 
może być na własne żądanie ustanowiony zarządcą, jeżeli oprócz rękojmi złożył 
w gotówce nie mniej niż piątą część ceny nabycia albo jeżeli do tej wysokości 
przysługuje mu prawo zaliczenia swej wierzytelności na poczet ceny nabycia. 
**§ 3.** W razie wygaśnięcia skutków przybicia bez równoczesnego umorzenia 
egzekucji sąd wyda postanowienie co do osoby zarządcy, jeżeli dotychczasowym 
zarządcą był nabywca.

***
## Art. 994. {#kpc-trzecia--art-994}

Jeżeli nabywca nie uzyska przysądzenia własności, należność 
przypadająca na niego z tytułu zarządu będzie pokryta z pierwszeństwem przed 
innymi jego zobowiązaniami z kwot pieniężnych złożonych na poczet ceny poza 
rękojmią.

***
## Art. 995. {#kpc-trzecia--art-995}

Osoba, na rzecz której udzielono przybicia, uzyskuje, jeżeli wykona 
warunki licytacyjne, prawo do przysądzenia jej własności nieruchomości.

***
## Art. 996. {#kpc-trzecia--art-996}

Postanowienie 
o przybiciu, 
które 
zapadło 
na 
posiedzeniu 
niejawnym, doręcza się wierzycielowi, dłużnikowi, nabywcy i osobom, które 
w toku licytacji zaskarżyły czynności związane z udzielaniem przybicia, jako też 
zarządcy, który nie jest dłużnikiem, postanowienie zaś o odmowie przybicia – 
wierzycielowi, dłużnikowi i licytantowi, który zaofiarował najwyższą cenę.

***
## Art. 997. {#kpc-trzecia--art-997}

Na postanowienie sądu co do przybicia przysługuje zażalenie. 
Podstawą zażalenia nie mogą być takie uchybienia przepisów postępowania, które 
nie naruszają praw skarżącego. 

 
 
 
s. 480/580 
 
2025-09-08 
 
Rozdział 8 
Przysądzenie własności

***
## Art. 998. {#kpc-trzecia--art-998}

**§ 1.** Po uprawomocnieniu się przybicia i wykonaniu przez nabywcę 
warunków licytacyjnych lub postanowienia o ustaleniu ceny nabycia i wpłaceniu 
całej ceny przez Skarb Państwa sąd wydaje postanowienie o przysądzeniu 
własności. 
**§ 2.** Na postanowienie co do przysądzenia własności przysługuje zażalenie. 
Podstawą zażalenia nie mogą być uchybienia sprzed uprawomocnienia się 
przybicia.

***
## Art. 999. {#kpc-trzecia--art-999}

**§ 1.** Prawomocne postanowienie o przysądzeniu własności przenosi 
własność na nabywcę i jest tytułem do ujawnienia na rzecz nabywcy prawa 
własności w katastrze nieruchomości oraz przez wpis w księdze wieczystej lub 
przez złożenie dokumentu do zbioru dokumentów. Prawomocne postanowienie 
o przysądzeniu własności jest tytułem wykonawczym do wprowadzenia nabywcy 
w posiadanie nieruchomości i opróżnienia znajdujących się na tej nieruchomości 
pomieszczeń bez potrzeby nadania mu klauzuli wykonalności. Przepis 
art. 791 stosuje się odpowiednio. 
**§ 2.** Od chwili uprawomocnienia się postanowienia o przysądzeniu własności 
na rzecz nabywcy należą do niego pożytki z nieruchomości. Powtarzające się 
daniny publiczne przypadające z nieruchomości od dnia prawomocności 
postanowienia 
o przysądzeniu 
własności 
ponosi 
nabywca. 
Świadczenia 
publicznoprawne niepowtarzające się nabywca ponosi tylko wtedy, gdy ich 
płatność przypada w dniu uprawomocnienia się postanowienia o przysądzeniu 
własności lub po tym dniu. 
**§ 3.** (uchylony)

***
## Art. 1000. {#kpc-trzecia--art-1000}

**§ 1.** Z chwilą uprawomocnienia się postanowienia o przysądzeniu 
własności wygasają wszelkie prawa i skutki ujawnienia praw i roszczeń osobistych 
ciążące na nieruchomości. Na miejsce tych praw powstaje prawo do zaspokojenia 
z ceny nabycia z pierwszeństwem przewidzianym w przepisach o podziale ceny 
uzyskanej z egzekucji. 
**§ 2.** Pozostają w mocy bez potrącenia ich wartości z ceny nabycia: 
- 1) prawa ciążące na nieruchomości z mocy ustawy; 

 
 
 
s. 481/580 
 
2025-09-08 
- 2) (uchylony) 
- 3) służebność drogi koniecznej oraz służebność ustanowiona w związku 
z przekroczeniem granicy przy wznoszeniu budowli lub innego urządzenia; 
- 4) służebność przesyłu. 
**§ 3.** Pozostają również w mocy ujawnione przez wpis w księdze wieczystej 
lub złożenie dokumentu do zbioru albo nieujawnione w ten sposób, lecz zgłoszone 
najpóźniej na trzy dni przed terminem licytacji, użytkowanie, służebności i prawa 
dożywotnika, jeżeli przysługuje im pierwszeństwo przed wszystkimi hipotekami 
lub jeżeli nieruchomość nie jest hipotekami obciążona albo jeżeli wartość 
użytkowania, służebności i praw dożywotnika znajduje pełne pokrycie w cenie 
nabycia. Jednakże w wypadku ostatnim wartość tych praw będzie zaliczona na cenę 
nabycia. 
**§ 4.** Przepisu § 1 nie stosuje się w odniesieniu do ciążących na nieruchomości 
spółdzielczych lokatorskich i własnościowych praw do lokalu. Prawa te, z chwilą 
uprawomocnienia się postanowienia o przysądzeniu własności, przekształcają się 
odpowiednio w prawo najmu, w prawo odrębnej własności do lokalu albo we 
własność domu jednorodzinnego.

***
## Art. 1001. {#kpc-trzecia--art-1001}

Na wniosek właściciela nieruchomości władnącej, zgłoszony 
najpóźniej na trzy dni przed terminem licytacji, sąd może zarządzić, że służebność 
gruntowa, która nie znajduje pełnego pokrycia w cenie nabycia, będzie utrzymana 
w mocy, jeżeli jest dla nieruchomości władnącej konieczna, a nie obciąża w sposób 
istotny wartości nieruchomości obciążonej.

***
## Art. 1002. {#kpc-trzecia--art-1002}

Z chwilą uprawomocnienia się postanowienia o przysądzeniu 
własności nabywca wstępuje w prawa i obowiązki dłużnika wynikające ze 
stosunku najmu i dzierżawy stosownie do przepisów prawa normujących te 
stosunki w wypadku zbycia rzeczy wynajętej lub wydzierżawionej. W przypadku 
gdy umowa najmu lub dzierżawy nieruchomości zawarta była na czas oznaczony 
dłuższy niż dwa lata, nabywca może wypowiedzieć tę umowę, w ciągu miesiąca od 
uprawomocnienia się postanowienia o przysądzeniu własności, z zachowaniem 
rocznego terminu wypowiedzenia, o ile umowa nie przewiduje terminu krótszego, 
chociażby umowa została zawarta z zachowaniem formy pisemnej i z datą pewną, 
a rzecz została najemcy lub dzierżawcy wydana. 

 
 
 
s. 482/580 
 
2025-09-08

***
## Art. 1003. {#kpc-trzecia--art-1003}

**§ 1.** Prawomocne postanowienie o przysądzeniu własności wraz 
z planem podziału sumy uzyskanej z egzekucji jest tytułem do wykreślenia 
w księdze wieczystej lub w zbiorze dokumentów wszelkich praw, które według 
planu podziału wygasły. 
**§ 2.** Na podstawie samego postanowienia o przysądzeniu własności wykreśla 
się wszystkie hipoteki obciążające nieruchomość, jeżeli w postanowieniu 
stwierdzono złożenie całej ceny nabycia na rachunek depozytowy Ministra 
Finansów. 
Rozdział 9 
Egzekucja z ułamkowej części nieruchomości oraz użytkowania wieczystego

***
## Art. 1004. {#kpc-trzecia--art-1004}

Do egzekucji z ułamkowej części nieruchomości, jak również do 
egzekucji z użytkowania wieczystego, stosuje się odpowiednio przepisy 
o egzekucji z nieruchomości z zachowaniem przepisów poniższych.

***
## Art. 1005. {#kpc-trzecia--art-1005}

O zajęciu ułamkowej części nieruchomości komornik zawiadamia 
także pozostałych współwłaścicieli, a o zajęciu użytkowania wieczystego także 
właściciela nieruchomości oraz właściwy organ administracji rządowej lub właś-
ciwą gminę.

***
## Art. 1006. {#kpc-trzecia--art-1006}

**§ 1.** Jeżeli przedmiotem egzekucji jest użytkowanie wieczyste, 
zajęcie obejmuje użytkowanie wieczyste terenu oraz znajdujący się na nim budynek 
stanowiący własność wieczystego użytkownika wraz z przynależnościami, 
a mianowicie: 
- 1) ruchomościami, 
będącymi 
własnością 
wieczystego 
użytkownika, 
a potrzebnymi do korzystania z przedmiotu wieczystego użytkowania 
zgodnie z jego przeznaczeniem, jeżeli pozostają z tym przedmiotem 
w faktycznym 
związku, 
odpowiadającym 
temu 
celowi, 
oraz 
przynależnościami 
budynku 
stanowiącego 
własność 
wieczystego 
użytkownika; 
- 2) prawami wynikającymi z umów ubezpieczenia przedmiotów podlegających 
zajęciu, tudzież należnościami z tych umów już przypadającymi. 
**§ 2.** Zajęcie obejmuje także przedmioty wymienione w pkt 1 paragrafu 
poprzedzającego wprowadzone później oraz później wzniesione budowle 
i posadzone rośliny, jak również prawa z umów ubezpieczenia później zawartych. 

 
 
 
s. 483/580 
 
2025-09-08

***
## Art. 1007. {#kpc-trzecia--art-1007}

Gdy przedmiotem zarządu jest ułamkowa część nieruchomości, 
zarządca działa tylko w granicach uprawnień dłużnika jako współwłaściciela.

***
## Art. 1008. {#kpc-trzecia--art-1008}

Jeżeli egzekucja jest prowadzona z użytkowania wieczystego, 
postępowanie ulega zawieszeniu, jeżeli właściwy organ wystąpił z żądaniem 
rozwiązania umowy użytkowania wieczystego. Egzekucja może być podjęta na 
wniosek wierzyciela, jeżeli sąd orzeknie, że brak jest podstaw do rozwiązania 
umowy użytkowania wieczystego. W przypadku rozwiązania umowy użytkowania 
wieczystego, komornik umarza postępowanie egzekucyjne.

***
## Art. 1009. {#kpc-trzecia--art-1009}

W razie 
skierowania 
egzekucji 
do 
ułamkowej 
części 
nieruchomości opisowi i oszacowaniu podlega cała nieruchomość. Sumą 
oszacowania takiej części jest odpowiednia część sumy oszacowania całej 
nieruchomości.

***
## Art. 1010. {#kpc-trzecia--art-1010}

Jeżeli przedmiotem egzekucji jest użytkowanie wieczyste, 
w protokole wymienia się końcową datę użytkowania wieczystego oraz ujawniony 
w księdze wieczystej sposób korzystania z terenu przez wieczystego użytkownika.

***
## Art. 1011. {#kpc-trzecia--art-1011}

Jeżeli przedmiotem egzekucji jest użytkowanie wieczyste, 
postanowienie o przysądzeniu tego prawa nie narusza ograniczonych praw 
rzeczowych na nieruchomości powstałych przed jej oddaniem w użytkowanie 
wieczyste.

***
## Art. 1012. {#kpc-trzecia--art-1012}

Jeżeli 
przedmiotem 
sprzedaży 
jest 
ułamkowa 
część 
nieruchomości, pozostają w mocy bez potrącenia ich wartości z ceny nabycia 
obciążenia tej części ułamkowej nieruchomości ujawnione przez wpis w księdze 
wieczystej lub złożenie dokumentu do zbioru oraz nieujawnione w ten sposób, lecz 
zgłoszone najpóźniej na trzy dni przed terminem licytacji, jeżeli zostały 
ustanowione przed powstaniem współwłasności.

***
## Art. 1013. {#kpc-trzecia--art-1013}

Postanowienie o przysądzeniu własności ułamkowej części 
nieruchomości nie narusza obciążających ją hipotek wpisanych przed powstaniem 
współwłasności. 

 
 
 
s. 484/580 
 
2025-09-08 
 
DZIAŁ VIa 
Uproszczona egzekucja z nieruchomości

***
## Art. 10131. {#kpc-trzecia--art-10131}

**§ 1.** Przepisy niniejszego działu stosuje się do egzekucji 
z niezabudowanej nieruchomości gruntowej oraz nieruchomości zabudowanej 
budynkiem mieszkalnym lub użytkowym, jeżeli w chwili złożenia wniosku 
o wszczęcie egzekucji nie dokonano zawiadomienia o zakończeniu budowy albo 
nie 
wystąpiono 
z wnioskiem 
o udzielenie 
zezwolenia 
na 
użytkowanie 
w rozumieniu przepisów prawa budowlanego. 
**§ 2.** Przepisy działu niniejszego stosuje się także do części nieruchomości 
wydzielonych do sprzedaży w trybie art. 946, jeżeli część wydzielona jest 
nieruchomością wymienioną w § 1. 
**§ 3.** W sprawach nieuregulowanych w niniejszym dziale stosuje się 
odpowiednio przepisy działu poprzedzającego.

***
## Art. 10132. {#kpc-trzecia--art-10132}

**§ 1.** Komornik na wniosek wierzyciela niezwłocznie po zajęciu 
dokona opisu i oszacowania nieruchomości na podstawie wartości określonej przez 
biegłego. Przepis art. 948 § 1 stosuje się odpowiednio. 
**§ 2.** Dokonując zajęcia, komornik, w miarę możności, zabezpieczy budynek 
lub lokal przed możliwością objęcia go we władanie przez dłużnika lub osoby 
trzecie. W razie potrzeby komornik ustanowi dozór nad budynkiem lub lokalem. 
Dozorcą może być także wierzyciel. Do dozoru stosuje się odpowiednio przepisy 
o dozorze ruchomości. 
**§ 3.** Jeżeli w toku opisu okaże się, że nieruchomość nie odpowiada wymogom 
określonym w art. 10131, dalsze postępowanie egzekucyjne toczy się w trybie 
przepisów działu poprzedzającego.

***
## Art. 10133. {#kpc-trzecia--art-10133}

**§ 1.** Jeżeli zajęto niezabudowaną nieruchomość gruntową, która 
nie jest obciążona na rzecz osób trzecich, komornik zaoferuje ją do sprzedaży 
z wolnej ręki po cenie nie niższej niż wartość oszacowania. Jeżeli strony nie 
określiły trybu wyszukania nabywcy, tryb ten ustala sąd. 
**§ 2.** Sprzedaż nastąpi po upływie dwóch tygodni od dnia opisu i oszacowania. 
O sprzedaży komornik zawiadamia uczestników stosownie do art. 954. 

 
 
 
s. 485/580 
 
2025-09-08 
**§ 3.** Jeżeli sprzedaż z wolnej ręki nie nastąpi w terminie miesiąca od dnia 
zakończenia opisu i oszacowania, sprzedaż nieruchomości następuje w trybie 
art. 10136.

***
## Art. 10134. {#kpc-trzecia--art-10134}

Przepis art. 10133 stosuje się odpowiednio do zbycia innych 
nieruchomości, do których stosuje się przepisy niniejszego działu, jeżeli 
oszacowanie nieruchomości nie zostało zaskarżone przez dłużnika. Za zgodą 
dłużnika sprzedaż z wolnej ręki może nastąpić także w pozostałych przypadkach; 
wtedy jednak dłużnik może określić cenę minimalną i wyznaczyć nabywcę.

***
## Art. 10135. {#kpc-trzecia--art-10135}

**§ 1.** Podejmując czynności związane ze sprzedażą, określone 
w przepisach poprzedzających, komornik sporządzi protokół, w którym wymieni 
nazwisko osoby przyjmującej ofertę nabycia nieruchomości, a także wpłaconą 
przez nią całą cenę nabycia; po czym niezwłocznie przedłoży protokół wraz 
z aktami sądowi. 
**§ 2.** Na podstawie protokołu komornika, o którym mowa w § 1, a także na 
podstawie akt sprawy sąd wydaje postanowienie o przysądzeniu własności, które 
przenosi własność na nabywcę. Na postanowienie o przysądzeniu służy zażalenie 
jedynie dłużnikowi i tylko wtedy, gdy naruszone zostały przepisy o cenie 
minimalnej. 
**§ 3.** W razie stwierdzenia naruszenia przepisów o oszacowaniu i cenie 
minimalnej sprzedaży, sąd odmawia przysądzenia własności i zwraca akta 
komornikowi, który ponownie przeprowadza postępowanie według przepisów 
niniejszego działu. 
**§ 4.** W razie stwierdzenia, że nieruchomość nie podlega sprzedaży według 
przepisów niniejszego działu, sąd poleca komornikowi prowadzenie dalszej 
egzekucji według przepisów o egzekucji z nieruchomości. 
**§ 5.** W razie wydania przez sąd postanowienia nakazującego ponowne 
przeprowadzenie sprzedaży lub podjęcie dalszych czynności według przepisów 
o egzekucji z nieruchomości, komornik niezwłocznie zwraca oferentowi kwotę 
wpłaconą przez niego na cenę nabycia.

***
## Art. 10136. {#kpc-trzecia--art-10136}

**§ 1.** Jeżeli sprzedaż nieruchomości nie nastąpi w trybie sprzedaży 
z wolnej ręki, nieruchomość podlega sprzedaży w drodze licytacji, do której stosuje 
się przepisy o licytacji w egzekucji z ruchomości. O terminie licytacji komornik 

 
 
 
s. 486/580 
 
2025-09-08 
 
zawiadamia uczestników postępowania stosownie do art. 954. W obwieszczeniu 
o licytacji podaje się także informacje, o których mowa w art. 953 § 1 pkt 1, 3, 6 
i 7. 
**§ 2.** Po zapłaceniu przez nabywcę sumy sąd niezwłocznie wydaje 
postanowienie o przysądzeniu własności. Po uprawomocnieniu się tego 
postanowienia komornik sporządza plan podziału sumy uzyskanej z egzekucji. 
#### DZIAŁ VII
Egzekucja ze statków morskich

***
## Art. 1014. {#kpc-trzecia--art-1014}

Do egzekucji ze statków morskich wpisanych do rejestru 
okrętowego stosuje się odpowiednio przepisy o egzekucji z nieruchomości ze 
zmianami wskazanymi w artykułach poniższych.

***
## Art. 1015. {#kpc-trzecia--art-1015}

Egzekucja należy do komornika sądu, w którego okręgu statek 
znajduje się w chwili wszczęcia egzekucji.

***
## Art. 1016. {#kpc-trzecia--art-1016}

Do wniosku o wszczęcie egzekucji wierzyciel powinien dołączyć 
dowód, że statek jest wpisany do rejestru.

***
## Art. 1017. {#kpc-trzecia--art-1017}

**§ 1.** Jednocześnie z wysłaniem dłużnikowi wezwania do zapłaty 
komornik zarządzi przytrzymanie statku i ustanowi dozór. 
**§ 2.** Statek jest zajęty z chwilą przytrzymania. O zajęciu należy zawiadomić 
także dłużnika oraz właściciela, który nie jest dłużnikiem. 
**§ 3.** Do dozorcy stosuje się odpowiednio przepisy o egzekucji z ruchomości 
dotyczące dozorcy.

***
## Art. 1018. {#kpc-trzecia--art-1018}

Ogłoszenie o wszczęciu egzekucji komornik zamieszcza na tablicy 
ogłoszeń w budynku sądu oraz na stronie internetowej Krajowej Rady 
Komorniczej. Komornik może zamieścić ogłoszenie także w dzienniku lub 
czasopiśmie poczytnym w danej miejscowości.

***
## Art. 1019. {#kpc-trzecia--art-1019}

Obwieszczenie o licytacji należy co najmniej dwa tygodnie przed 
jej terminem ogłosić publicznie na stronie internetowej sądu oraz tablicy ogłoszeń 
w budynku sądu, a także na stronie internetowej Krajowej Rady Komorniczej, jak 
również przesłać terenowym organom administracji morskiej właściwym dla portu, 
w którym statek się znajduje, oraz dla portu macierzystego statku w celu 

 
 
 
s. 487/580 
 
2025-09-08 
 
wywieszenia w tych portach. Komornik może zamieścić obwieszczenie o licytacji 
także w dzienniku lub czasopiśmie poczytnym w danej miejscowości.

***
## Art. 1020. {#kpc-trzecia--art-1020}

Egzekucja z udziału w statku należy do komornika sądu, 
w którego okręgu znajduje się port macierzysty statku.

***
## Art. 1021. {#kpc-trzecia--art-1021}

Egzekucja ze statków niewpisanych do rejestru okrętowego 
odbywa się według przepisów o egzekucji z ruchomości.

***
## Art. 1022. {#kpc-trzecia--art-1022}

**§ 1.** Egzekucja ze statku zagranicznego znajdującego się na 
terytorium Rzeczypospolitej Polskiej odbywa się według przepisów działu 
niniejszego, jeśli przepisy poniższe nie stanowią inaczej. 
**§ 2.** We wniosku o wszczęcie egzekucji wierzyciel wskazuje rejestr, do 
którego statek jest wpisany, chyba że jest to niemożliwe lub nadmiernie utrudnione.

***
## Art. 10221. {#kpc-trzecia--art-10221}

O dokonanym zajęciu statku komornik zawiadamia także 
zagraniczną władzę rejestrową.

***
## Art. 10222. {#kpc-trzecia--art-10222}

Jeżeli wezwanie do zapłaty nie może być doręczone dłużnikowi, 
gdyż nie zamieszkuje on lub nie posiada siedziby pod adresem wskazanym 
w dokumentach statku zagranicznego, przepis art. 802 stosuje się odpowiednio.

***
## Art. 10223. {#kpc-trzecia--art-10223}

W razie śmierci albo likwidacji dłużnika po wszczęciu 
postępowania egzekucyjnego sąd na wniosek wierzyciela ustanawia dla niego 
kuratora. Przepisu art. 819 nie stosuje się.

***
## Art. 10224. {#kpc-trzecia--art-10224}

Opisu i oszacowania zajętego statku zagranicznego komornik bez 
wniosku wierzyciela dokonuje niezwłocznie po upływie terminu wyznaczonego 
dłużnikowi do zapłaty długu. 
#### DZIAŁ VIII
Podział sumy uzyskanej z egzekucji 
Rozdział 1 
Przepisy ogólne

***
## Art. 1023. {#kpc-trzecia--art-1023}

**§ 1.** Organ egzekucyjny sporządza plan podziału pomiędzy 
wierzycieli sumy uzyskanej z egzekucji z nieruchomości. 

 
 
 
s. 488/580 
 
2025-09-08 
**§ 2.** Plan podziału powinien być sporządzony także wtedy, gdy suma 
uzyskana przez egzekucję z ruchomości, wynagrodzenia za pracę lub 
wierzytelności i innych praw majątkowych nie wystarcza na zaspokojenie 
wszystkich wierzycieli.

***
## Art. 1024. {#kpc-trzecia--art-1024}

**§ 1.** W planie podziału należy wymienić: 
- 1) sumę ulegającą podziałowi; 
- 2) wierzytelności i prawa osób uczestniczących w podziale; 
- 3) sumę, jaka przypada każdemu z uczestników podziału; 
- 4) sumy, które mają być wypłacone, jak również sumy, które pozostawia się na 
rachunku depozytowym Ministra Finansów, ze wskazaniem przyczyn 
uzasadniających wstrzymanie ich wypłaty; 
- 5) prawa ujawnione przez wpis w księdze wieczystej lub złożenie dokumentów 
do zbioru, które wygasły wskutek przysądzenia własności. 
**§ 2.** Przy świadczeniach powtarzających się bieżące raty wierzytelności 
uwzględnia się w planie podziału, jeżeli stały się wymagalne przed datą 
sporządzenia planu. Odsetki i inne świadczenia bieżące uwzględnia się 
w wysokości, do jakiej narosły do powyższego terminu. Nie dotyczy to danin 
publicznych przypadających z nieruchomości. 
**§ 3.** Świadczenie pieniężne w walucie obcej jest uwzględniane w planie 
podziału według waluty obcej przeliczonej na walutę polską według kursu 
średniego ogłaszanego przez Narodowy Bank Polski z dnia sporządzenia planu 
podziału.

***
## Art. 1025. {#kpc-trzecia--art-1025}

**§ 1.** Z kwoty uzyskanej z egzekucji zaspokaja się w następującej 
kolejności: 
- 1) koszty egzekucyjne z wyjątkiem kosztów zastępstwa prawnego przyznanych 
przez komornika w postępowaniu egzekucyjnym; 
- 2) należności alimentacyjne wymagalne; 
- 21) należności alimentacyjne przyszłe – w wysokości stanowiącej równowartość 
minimalnego wynagrodzenia za pracę za okres roku – na każdego wierzyciela 
prowadzącego egzekucję; 
- 3) należności za pracę za okres 3 miesięcy do wysokości minimalnego 
wynagrodzenia za pracę, renty z tytułu odszkodowania za wywołanie 

 
 
 
s. 489/580 
 
2025-09-08 
 
choroby, niezdolności do pracy, kalectwa albo śmierci, należności zasądzone 
na rzecz pokrzywdzonego lub osób wykonujących prawa pokrzywdzonego 
w postępowaniu karnym i koszty zwykłego pogrzebu dłużnika; 
- 4) należności zabezpieczone hipoteką morską lub przywilejem na statku 
morskim; 
- 5) należności zabezpieczone hipoteką, zastawem, zastawem rejestrowym 
i zastawem skarbowym albo korzystające z ustawowego pierwszeństwa oraz 
prawa, które ciążyły na nieruchomości przed dokonaniem w księdze 
wieczystej wpisu o wszczęciu egzekucji lub przed złożeniem do zbioru 
dokumentów wniosku o dokonanie takiego wpisu; 
- 6) należności za pracę niezaspokojone w kolejności trzeciej; 
- 7) należności, do których stosuje się przepisy działu III ustawy z dnia 29 sierpnia 
1997 r. – Ordynacja podatkowa, o ile nie zostały zaspokojone w kolejności 
piątej; 
- 8) (uchylony) 
- 9) należności wierzycieli, którzy prowadzili egzekucję; 
- 10) inne należności. 
**§ 2.** Po zaspokojeniu wszystkich należności ulegają zaspokojeniu kary 
pieniężne oraz grzywny sądowe i administracyjne. 
**§ 3.** W równym stopniu z należnością ulegają zaspokojeniu odsetki i koszty 
postępowania oraz przyznane przez komornika koszty zastępstwa prawnego 
w postępowaniu egzekucyjnym. Z pierwszeństwa równego należnościom kategorii 
czwartej i piątej korzystają wszystkie roszczenia o świadczenia uboczne objęte 
zabezpieczeniem na mocy odrębnych przepisów. Roszczenia o świadczenia 
uboczne nieobjęte zabezpieczeniem zaspokaja się w kategorii dziesiątej, chyba że 
należność podlegałaby zaspokojeniu w kategorii wcześniejszej. To samo dotyczy 
roszczeń o świadczenia należne dożywotnikowi. 
**§ 31.** Z pierwszeństwa równego należnościom kategorii siódmej korzystają 
należności celne, o których mowa w rozporządzeniu Parlamentu Europejskiego 
i Rady (UE) nr 952/2013 z dnia 9 października 2013 r. ustanawiającym unijny 
kodeks celny (Dz. Urz. UE L 269 z 10.10.2013, str. 1, z późn. zm.25)), dochodzone 
- 25) Zmiany wymienionego rozporządzenia zostały ogłoszone w Dz. Urz. UE L 287 z 29.10.2013, 
str. 90, Dz. Urz. UE L 267 z 30.09.2016, str. 2, Dz. Urz. UE L 354 z 23.12.2016, str. 32, Dz. Urz. 

 
 
 
s. 490/580 
 
2025-09-08 
 
na podstawie tytułu wykonawczego innego niż jednolity tytuł wykonawczy 
państwa członkowskiego Unii Europejskiej albo zagraniczny tytuł wykonawczy 
określone w ustawie z dnia 11 października 2013 r. o wzajemnej pomocy przy 
dochodzeniu podatków, należności celnych i innych należności pieniężnych. Po 
zaspokojeniu należności celnych ulegają zaspokojeniu koszty egzekucyjne i koszty 
upomnienia powstałe w egzekucji tych należności, a następnie odsetki od 
należności celnych. 
**§ 32.** Sumy 
przypadające 
na 
poczet 
należności 
alimentacyjnych 
niewymagalnych w dniu sporządzenia planu podziału pozostawia się na rachunku 
depozytowym Ministra Finansów. Komornik podejmuje zdeponowane środki, 
jeżeli zaspokojenie bieżących należności alimentacyjnych nie jest możliwe w inny 
sposób. 
**§ 4.** Jeżeli przedmiotem egzekucji jest spółdzielcze własnościowe prawo do 
lokalu, wierzytelność spółdzielni mieszkaniowej z tytułu niewniesionego wkładu 
budowlanego związana z tym prawem ulega zaspokojeniu przed należnością 
zabezpieczoną na tym prawie hipotecznie. 
**§ 5.** Roszczenia nabywcy wynikające z: 
- 1) odstąpienia od umowy deweloperskiej, o której mowa w art. 5 pkt 6 ustawy 
z dnia 20 maja 2021 r. o ochronie praw nabywcy lokalu mieszkalnego lub 
domu jednorodzinnego oraz Deweloperskim Funduszu Gwarancyjnym 
(Dz. U. z 2024 r. poz. 695), albo jednej z umów, o których mowa 
w art. 2 ust. 1 pkt 2, 3 lub 5 tej ustawy, lub 
- 2) przekształcenia roszczenia z umowy deweloperskiej, o której mowa 
w art. 5 pkt 6 ustawy z dnia 20 maja 2021 r. o ochronie praw nabywcy lokalu 
mieszkalnego lub domu jednorodzinnego oraz Deweloperskim Funduszu 
Gwarancyjnym, albo jednej z umów, o których mowa w art. 2 ust. 1 pkt 2, 3 
lub 5 lub ust. 2 tej ustawy, w toku postępowania restrukturyzacyjnego lub 
upadłościowego 
– podlegają zaspokojeniu z kwoty uzyskanej z egzekucji z nieruchomości, na której 
jest prowadzone przedsięwzięcie deweloperskie lub zadanie inwestycyjne, 
o których mowa w art. 5 pkt 7 i 8 ustawy z dnia 20 maja 2021 r. o ochronie praw 
 
UE L 42 z 18.02.2017, str. 43, Dz. Urz. UE L 83 z 25.03.2019, str. 38 oraz Dz. Urz. UE L 111 
z 25.04.2019, str. 54. 

 
 
 
s. 491/580 
 
2025-09-08 
 
nabywcy lokalu mieszkalnego lub domu jednorodzinnego oraz Deweloperskim 
Funduszu Gwarancyjnym, na takich samych zasadach, jak roszczenie z umowy 
deweloperskiej albo jednej z umów, o których mowa w art. 2 ust. 1 pkt 2, 3 lub 5 
tej ustawy, z pierwszeństwem wynikającym z ujawnienia w księdze wieczystej 
przysługującego nabywcy roszczenia wynikającego z tych umów także 
w przypadku, gdy wpis o ujawnieniu tego roszczenia został wykreślony. 
**§ 6.** Roszczenie Ubezpieczeniowego Funduszu Gwarancyjnego wynikające 
z art. 48 ust. 8 ustawy z dnia 20 maja 2021 r. o ochronie praw nabywcy lokalu 
mieszkalnego lub domu jednorodzinnego oraz Deweloperskim Funduszu 
Gwarancyjnym 
podlega 
zaspokojeniu 
z kwoty 
uzyskanej 
z egzekucji 
z nieruchomości, na której jest prowadzone przedsięwzięcie deweloperskie lub 
zadanie inwestycyjne, o których mowa w art. 5 pkt 7 i 8 tej ustawy, z 
pierwszeństwem wynikającym z ujawnienia w księdze wieczystej przysługującego 
Ubezpieczeniowemu Funduszowi Gwarancyjnemu roszczenia także w przypadku, 
gdy wpis o ujawnieniu roszczenia z umowy deweloperskiej, o której mowa 
w art. 5 pkt 6 tej ustawy, albo jednej z umów, o których mowa w art. 2 ust. 1 pkt 2, 
3 lub 5 lub ust. 2 tej ustawy, został wykreślony. 
**§ 7.** Z kwoty przypadającej dłużnikowi po zaspokojeniu wszystkich 
wierzytelności, o których mowa w § 1–6, pozostawia się na rachunku 
depozytowym Ministra Finansów sumę stanowiącą równowartość minimalnego 
wynagrodzenia za pracę za okres roku – na każdego wierzyciela prowadzącego 
egzekucję należności alimentacyjnych, o ile zachodzą podstawy do przyjęcia, że 
należności zabezpieczone zgodnie z § 1 pkt 21 nie wystarczą na pełne zaspokojenie 
przyszłych należności tych wierzycieli. Przepis § 32 zdanie drugie stosuje się 
odpowiednio. 
**§ 8.** Przepisów § 1 pkt 21 oraz § 7 nie stosuje się w przypadku, jeżeli 
w wyniku prowadzonych wcześniej egzekucji przeciwko dłużnikowi pozostawiono 
na rachunku depozytowym Ministra Finansów sumę stanowiącą równowartość 
minimalnego wynagrodzenia za pracę za okres dwóch lat – na każdego wierzyciela 
prowadzącego 
egzekucję 
należności 
alimentacyjnych. 
W razie 
potrzeby 
zdeponowana kwota podlega jednak uzupełnieniu do wysokości określonej 
w zdaniu pierwszym. 

 
 
 
s. 492/580 
 
2025-09-08

***
## Art. 1026. {#kpc-trzecia--art-1026}

**§ 1.** Jeżeli suma objęta podziałem nie wystarcza na zaspokojenie 
w całości wszystkich należności i praw tej samej kategorii, należności zaliczone 
w artykule poprzedzającym do kategorii czwartej i piątej będą zaspokojone 
w kolejności odpowiadającej przysługującemu im pierwszeństwu, inne zaś 
należności – stosunkowo do wysokości każdej z nich. 
**§ 11.** Jeżeli z kwoty uzyskanej z egzekucji zaspokojeniu podlegają zarówno 
wierzytelności zabezpieczone hipoteką, jak i prawa lub roszczenia ciążące na 
nieruchomości, 
o pierwszeństwie między hipoteką a tymi 
prawami 
lub 
roszczeniami rozstrzyga chwila, od której liczy się skutki wpisu hipoteki, prawa lub 
roszczenia do księgi wieczystej. 
**§ 2.** Wydzieloną wierzycielowi sumę zalicza się przede wszystkim na koszty 
postępowania, następnie na odsetki, a w końcu na sumę dłużną. 
**§ 3.** W przypadku połączenia postępowań egzekucyjnych toczących się co do 
kilku nieruchomości tego samego dłużnika, suma przypadająca po zaspokojeniu 
należności zaliczonych do wyższej kategorii na zaspokojenie ciążących na nie-
ruchomościach hipotek oraz praw i roszczeń, które wygasły wskutek przysądzenia 
własności, ulega podziałowi na tyle części, ile nieruchomości było przedmiotem 
połączonych postępowań, w takim stosunku, w jakim wartość poszczególnych nie-
ruchomości pozostawała do wartości całości gospodarczej, którą tworzyły te 
nieruchomości. Hipoteki, roszczenia i prawa ciążące na nieruchomości zaspokaja 
się tylko w tej części sumy, która odpowiada wartości obciążonej nimi nie-
ruchomości. Pozostałą część sumy dzieli się stosownie do § 1.

***
## Art. 1027. {#kpc-trzecia--art-1027}

**§ 1.** Odpis planu podziału doręcza się dłużnikowi, osobom 
uczestniczącym w podziale oraz innym osobom, które zgłosiły swój udział, a ich 
należności nie zostały uwzględnione w podziale. 
**§ 2.** Zarzuty przeciwko planowi podziału wnosi się do organu egzekucyjnego, 
który go sporządził, w terminie dwóch tygodni od dnia doręczenia tego planu. 
<Przepisów art. 132 § 1, 14 i 15 nie stosuje się.> 
**§ 3.** O zarzutach wniesionych do komornika rozstrzyga sąd.

***
## Art. 1028. {#kpc-trzecia--art-1028}

**§ 1.** Jeżeli zarzutów nie wniesiono w terminie przepisanym, organ 
egzekucyjny przystąpi do wykonania planu. Wniesienie zarzutów wstrzymuje 
wykonanie planu tylko w części, której zarzuty dotyczą. 
Dodane 
zdanie 
drugie w § 2 w 
art. 1027 wejdzie 
w życie z dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 

 
 
 
s. 493/580 
 
2025-09-08 
**§ 2.** Na 
skutek 
wniesienia 
zarzutów 
sąd 
po 
wysłuchaniu 
osób 
zainteresowanych zatwierdzi albo odpowiednio zmieni plan. W postępowaniu tym 
sąd nie rozpoznaje sporu co do istnienia prawa objętego planem podziału. 
**§ 3.** Na postanowienie sądu przysługuje zażalenie. 
**§ 4.** Wykonanie 
planu 
w części 
dotkniętej 
zarzutami 
nastąpi 
po 
uprawomocnieniu się postanowienia sądu, chyba że zostało wstrzymane przez 
zabezpieczenie powództwa w sporze o ustalenie nieistnienia prawa. Powództwo 
o ustalenie nieistnienia prawa, na zaspokojenie którego pozostawiono sumy na 
rachunku depozytowym Ministra Finansów, może po uprawomocnieniu się planu 
podziału wytoczyć ten uczestnik podziału, któremu przypadają niezaspokojone 
należności o pierwszeństwie równym lub niższym od kwestionowanego prawa. 
**§ 5.** Plan podziału w zakresie podlegających wypłacie sum, które przypadają 
poszczególnym uczestnikom podziału, w razie uprawomocnienia się wywiera 
skutek na dzień jego sporządzenia. Nie dotyczy to planu podziału, do którego 
stosuje się przepis art. 1029.

***
## Art. 10281. {#kpc-trzecia--art-10281}

**§ 1.** Jeżeli po uprawomocnieniu się planu podziału okaże się, że 
nie istnieją wierzytelności lub prawa, na poczet których miały przypaść sumy 
pozostawione na rachunku depozytowym Ministra Finansów ze wstrzymaniem ich 
wypłaty, organ egzekucyjny na wniosek wierzyciela sporządza uzupełniający plan 
podziału. 
**§ 2.** W uzupełniającym planie podziału uwzględnia się niezaspokojone 
wierzytelności osób uczestniczących w prawomocnym planie podziału. Organ 
egzekucyjny wzywa te osoby do złożenia tytułów wykonawczych wraz 
z aktualnym zestawieniem objętych nimi należności. Kwoty przypadające zgodnie 
z uzupełniającym planem podziału uczestnikom, którzy nie przedłożyli po 
wezwaniu tytułu wykonawczego wraz z aktualnym zestawieniem objętych nim 
należności, pozostawia się na rachunku depozytowym Ministra Finansów. 
**§ 3.** Po zaspokojeniu wszystkich wierzycieli część zdeponowanej sumy 
nieobjętej uzupełniającym planem podziału zwraca się dłużnikowi. 

 
 
 
s. 494/580 
 
2025-09-08 
 
Rozdział 2 
Podział sumy uzyskanej przez egzekucję z wynagrodzenia za pracę

***
## Art. 1029. {#kpc-trzecia--art-1029}

**§ 1.** Na podstawie oświadczenia pracodawcy o wynagrodzeniu 
dłużnika oraz spisu wierzytelności i praw osób uczestniczących w podziale 
komornik sporządza plan podziału, ustalając, w jakim procencie przypada na 
każdego wierzyciela udział w sumach potrąconych każdorazowo przez pracodawcę 
z wynagrodzenia dłużnika i wpłaconych komornikowi. Jeżeli zaś komornik nie 
może sporządzić planu podziału na podstawie samego oświadczenia pracodawcy, 
sporządzi go niezwłocznie po złożeniu na rachunek depozytowy Ministra Finansów 
sumy podlegającej podziałowi. 
**§ 11.** Wierzyciel może zrzec się doręczenia planu podziału, o którym mowa 
w § 1, podając jednocześnie adres poczty elektronicznej. W takim przypadku 
termin do wniesienia zarzutów przeciwko planowi podziału zaczyna biec od dnia 
wysłania wierzycielowi, na podany adres poczty elektronicznej, informacji o treści 
planu podziału. 
**§ 2.** Razem z planem podziału należy doręczyć odpis oświadczenia 
pracodawcy o wynagrodzeniu dłużnika. 
**§ 3.** Przy podziale sum, o których mowa w § 1, przepisów art. 1025 § 1 pkt 21 
oraz § 7 i 8 nie stosuje się.

***
## Art. 1030. {#kpc-trzecia--art-1030}

W podziale 
sum 
uzyskanych 
w sposób 
przewidziany 
w art. 1029 oprócz wierzyciela egzekwującego uczestniczą: wierzyciele składający 
tytuł wykonawczy z dowodem doręczenia dłużnikowi wezwania do zapłaty, 
wierzyciele, którzy uzyskali zabezpieczenie powództwa, oraz wierzyciele, którym 
przysługuje umowne prawo zastawu i którzy udowodnili je dokumentem 
urzędowym lub prywatnym z podpisem urzędowo poświadczonym, jak również 
wierzyciele, którym przysługuje ustawowe prawo zastawu i którzy udowodnili je 
dokumentem, jeżeli zgłosili swe wierzytelności najpóźniej w dniu złożenia na 
rachunek depozytowy Ministra Finansów sumy ulegającej podziałowi.

***
## Art. 1031. {#kpc-trzecia--art-1031}

Kwoty wyegzekwowane i złożone na rachunek depozytowy 
Ministra Finansów komornik dzieli niezwłocznie w ustalonym poprzednio 
stosunku procentowym pomiędzy wierzycieli uczestniczących w podziale, chyba 
że wskutek zmiany podstaw podziału należy ustalić nowy procent. Sumy 

 
 
 
s. 495/580 
 
2025-09-08 
 
przypadające do wypłaty komornik wypłaca, jeżeli nie są niższe niż sto złotych, 
chyba że wierzytelność nie przekracza tej kwoty.

***
## Art. 1032. {#kpc-trzecia--art-1032}

**§ 1.** Należność przypadającą wierzycielowi niemającemu jeszcze 
tytułu wykonawczego pozostawia się na rachunku depozytowym Ministra 
Finansów. 
**§ 2.** Jeżeli w ciągu miesiąca po uprawomocnieniu się planu podziału 
wierzyciel niemający tytułu wykonawczego nie przedstawi dowodu wytoczenia 
powództwa o zasądzenie mu roszczenia, traci prawo do sumy pozostającej 
w depozycie. 
Rozdział 3 
Podział sumy uzyskanej przez egzekucję z ruchomości, wierzytelności 
i innych praw majątkowych

***
## Art. 1033. {#kpc-trzecia--art-1033}

**§ 1.** Plan podziału sporządza komornik niezwłocznie po złożeniu 
na rachunek depozytowy Ministra Finansów sumy ulegającej podziałowi oraz po 
uprawomocnieniu się postanowienia w przedmiocie kosztów. 
**§ 2.** Jeżeli egzekucja jest prowadzona z wierzytelności mających za przedmiot 
świadczenia bieżące, stosuje się odpowiednio przepisy art. 1029 § 1 i 3 oraz 
art. 1031.

***
## Art. 1034. {#kpc-trzecia--art-1034}

Przepisy art. 1030 i art. 1032 stosuje się także w postępowaniu 
unormowanym w rozdziale niniejszym. W podziale sumy uzyskanej z egzekucji 
umieszcza się także wierzytelności zabezpieczone zastawem rejestrowym, jeżeli 
zastawnikowi przysługuje prawo zaspokojenia się z przedmiotu egzekucji oraz 
jeżeli prawa swe udowodnił dokumentem urzędowym najpóźniej w dniu złożenia 
na rachunek depozytowy Ministra Finansów sumy ulegającej podziałowi. 
Rozdział 4 
Podział sumy uzyskanej przez egzekucję z nieruchomości

***
## Art. 1035. {#kpc-trzecia--art-1035}

Niezwłocznie 
po 
uprawomocnieniu 
się 
postanowienia 
o przysądzeniu własności oraz postanowienia w przedmiocie kosztów komornik 
sporządza plan podziału.

***
## Art. 1036. {#kpc-trzecia--art-1036}

**§ 1.** W podziale oprócz wierzyciela egzekwującego uczestniczą: 

 
 
 
s. 496/580 
 
2025-09-08 
- 1) wierzyciele składający tytuł wykonawczy z dowodem doręczenia dłużnikowi 
wezwania do zapłaty, jeżeli zgłosili się najpóźniej w dniu uprawomocnienia 
się postanowienia o przysądzeniu własności nieruchomości; 
- 2) wierzyciele, którzy uzyskali zabezpieczenie powództwa, jeżeli zgłosili się 
najpóźniej w dniu uprawomocnienia się postanowienia o przysądzeniu 
własności nieruchomości; 
- 3) osoby, które przed zajęciem nieruchomości nabyły na niej prawa stwierdzone 
w opisie i oszacowaniu lub zgłoszone i udowodnione najpóźniej w dniu 
uprawomocnienia się postanowienia o przybiciu; 
- 4) pracownicy co do stwierdzonych dokumentem należności za pracę, jeżeli 
zgłosili swoje roszczenia przed sporządzeniem planu podziału. 
**§ 2.** Jeżeli 
wierzytelność 
hipoteczna 
nie 
jest 
stwierdzona 
tytułem 
wykonawczym, należność przypadającą wierzycielowi hipotecznemu pozostawia 
się na rachunku depozytowym Ministra Finansów.

***
## Art. 10361. {#kpc-trzecia--art-10361}

Jeżeli 
egzekucja 
objęła 
również 
należności 
z umów 
ubezpieczenia lub przedmiotów, wierzytelności i praw, które według przepisów 
prawa stanowią przedmiot obciążenia hipoteką, w podziale uczestniczy również 
wierzyciel, 
którego 
wierzytelność 
została 
na 
tych 
ruchomościach, 
wierzytelnościach lub prawach zabezpieczona zastawem rejestrowym.

***
## Art. 1037. {#kpc-trzecia--art-1037}

**§ 1.** Jeżeli przy sporządzaniu planu podziału okaże się, że 
nabywca, uiszczając cenę, potrącił wierzytelność, która się w niej nie mieści, sąd, 
na wniosek komornika, zobowiąże nabywcę do uzupełnienia ceny w ciągu 
tygodnia. Na postanowienie sądu przysługuje zażalenie. 
**§ 2.** W planie podziału komornik wymienia osoby, dla których jest 
przeznaczona suma przypadająca od nabywcy. W tej części plan podziału stanowi 
tytuł egzekucyjny przeciwko nabywcy. 
**§ 3.** Wierzyciel, któremu przydzielono roszczenie przeciwko nabywcy, 
nabywa z mocy samego prawa hipotekę na sprzedanej nieruchomości. Ujawnienie 
hipoteki w księdze wieczystej lub zbiorze dokumentów następuje na wniosek 
wierzyciela.

***
## Art. 1038. {#kpc-trzecia--art-1038}

**§ 1.** Jeżeli hipoteka nie jest wyczerpana i może jeszcze służyć 
zabezpieczeniu wierzyciela, reszta sumy pozostanie na rachunku depozytowym 

 
 
 
s. 497/580 
 
2025-09-08 
 
Ministra Finansów aż do ustania stosunku prawnego, uzasadniającego korzystanie 
z hipoteki. 
**§ 2.** W przypadku hipoteki zabezpieczającej kilka wierzytelności, gdy łączna 
kwota wierzytelności przewyższa sumę wymienioną we wpisie hipoteki, 
a wierzyciel nie wskazał do dnia uprawomocnienia się postanowienia 
o przysądzeniu własności, które z wierzytelności i w jakiej wysokości mają zostać 
zaspokojone, zaspokaja się wszystkie wierzytelności proporcjonalnie do ich 
wysokości.

***
## Art. 1039. {#kpc-trzecia--art-1039}

Jeżeli 
wierzytelność 
jest 
zabezpieczona 
na 
kilku 
nieruchomościach łącznie, wierzyciel powinien przed uprawomocnieniem się 
postanowienia o przysądzeniu własności złożyć oświadczenie, czy i w jakiej 
wysokości żąda zaspokojenia z każdej ze sprzedanych nieruchomości. Jeżeli 
w powyższym terminie tego nie uczyni, a podzielona ma być suma uzyskana tylko 
z jednej nieruchomości, jego wierzytelność będzie przyjęta do rozrachunku 
w całości; jeżeli natomiast podziałowi podlegają sumy uzyskane ze sprzedaży kilku 
łącznie obciążonych nieruchomości, na wierzytelność łącznie zabezpieczoną 
przypadnie z każdej z sum podlegających podziałowi taka część, jaka odpowiada 
stosunkowi 
kwoty 
pozostałej 
po 
zaspokojeniu 
należności 
z wyższym 
pierwszeństwem do ogólnej sumy tych kwot.

***
## Art. 1040. {#kpc-trzecia--art-1040}

**§ 1.** Sumę wydzieloną na zaspokojenie wierzytelności, której 
uiszczenie zależne jest od warunku zawieszającego albo od wyniku sporu, 
w którym wierzyciel uzyskał zabezpieczenie powództwa, pozostawia się na 
rachunku depozytowym Ministra Finansów. 
**§ 2.** Suma wydzielona na zaspokojenie wierzytelności zależnych od warunku 
rozwiązującego będzie wydana wierzycielowi bez zabezpieczenia. Jeżeli jednak 
obowiązek zabezpieczenia zwrotu ciąży na wierzycielu z mocy istniejącego między 
nim a dłużnikiem stosunku prawnego, komornik zarządzi złożenie wydzielonej 
sumy na rachunek depozytowy Ministra Finansów.

***
## Art. 10401. {#kpc-trzecia--art-10401}

Plan podziału wykonuje komornik. 

 
 
 
s. 498/580 
 
2025-09-08 
### TYTUŁ III
Przepisy szczególne o egzekucji 
#### DZIAŁ I
Egzekucja świadczeń niepieniężnych

***
## Art. 1041. {#kpc-trzecia--art-1041}

**§ 1.** Jeżeli dłużnik ma wydać wierzycielowi rzecz ruchomą, 
komornik sądu, w którego okręgu rzecz się znajduje, odbierze ją dłużnikowi i wyda 
wierzycielowi. 
**§ 2.** Jeżeli ze względu na rodzaj rzeczy niezwłoczne fizyczne jej przejęcie nie 
jest możliwe, komornik wprowadzi wierzyciela w posiadanie rzeczy zgodnie 
z przepisami prawa cywilnego.

***
## Art. 1042. {#kpc-trzecia--art-1042}

Jeżeli rzeczy odebranej dłużnikowi nie można niezwłocznie wydać 
wierzycielowi, komornik złoży ją do depozytu sądowego albo odda na 
przechowanie na koszt i niebezpieczeństwo wierzyciela.

***
## Art. 1043. {#kpc-trzecia--art-1043}

Jeżeli rzecz należąca do dłużnika znajduje się we władaniu osoby 
trzeciej, która nie zgadza się na jej wydanie, komornik zajmie roszczenie dłużnika 
o wydanie rzeczy.

***
## Art. 1044. {#kpc-trzecia--art-1044}

Jeżeli wierzyciel żąda, aby odebranie rzeczy odbyło się w jego 
obecności, 
komornik 
zawiadomi 
go 
o 
terminie 
odebrania, 
a w razie 
niestawiennictwa wierzyciela nie przystąpi do wykonania.

***
## Art. 1045. {#kpc-trzecia--art-1045}

Jeżeli komornik nie znalazł u dłużnika rzeczy lub dokumentu, 
które mają być odebrane, sąd na wniosek wierzyciela nakaże dłużnikowi, aby 
wyjawił, gdzie one się znajdują, i aby złożył przyrzeczenie, że jego oświadczenia 
są zgodne z prawdą. Przepisy dotyczące przyrzeczenia przy wyjawieniu majątku 
stosuje się odpowiednio.

***
## Art. 1046. {#kpc-trzecia--art-1046}

**§ 1.** Jeżeli dłużnik ma wydać nieruchomość lub statek albo 
opróżnić pomieszczenie, komornik sądu, w którego okręgu rzeczy te się znajdują, 
wezwie dłużnika do dobrowolnego wykonania tego obowiązku w wyznaczonym 
stosownie do okoliczności terminie, po którego bezskutecznym upływie dokona 
czynności potrzebnych do wprowadzenia wierzyciela w posiadanie. 
**§ 2.** (uchylony) 

 
 
 
s. 499/580 
 
2025-09-08 
**§ 3.** (uchylony) 
**§ 4.** Wykonując obowiązek opróżnienia lokalu służącego zaspokojeniu 
potrzeb mieszkaniowych dłużnika na podstawie tytułu wykonawczego, z którego 
nie wynika uprawnienie dłużnika do zawarcia umowy najmu socjalnego lokalu lub 
prawo do lokalu zamiennego, komornik usunie dłużnika do innego lokalu lub 
pomieszczenia, do którego dłużnikowi przysługuje tytuł prawny i w którym może 
on zamieszkać. Jeżeli dłużnikowi nie przysługuje tytuł prawny do innego lokalu lub 
pomieszczenia, w którym może zamieszkać, komornik wstrzyma się z dokonaniem 
czynności do czasu, gdy gmina właściwa ze względu na miejsce położenia lokalu 
podlegającego opróżnieniu, na wniosek komornika, wskaże dłużnikowi 
tymczasowe pomieszczenie. 
**§ 41.** (uchylony) 
**§ 5.** Komornik nie może wstrzymać się z dokonaniem czynności, jeżeli 
wierzyciel lub dłużnik albo osoba trzecia wskaże pomieszczenie odpowiadające 
wymogom tymczasowego pomieszczenia. 
**§ 51.** Jeżeli 
dłużnikowi 
nie 
przysługuje 
prawo 
do 
tymczasowego 
pomieszczenia, komornik usunie dłużnika do noclegowni, schroniska lub innej 
placówki zapewniającej miejsca noclegowe, wskazanej na wniosek komornika 
przez gminę właściwą ze względu na miejsce położenia lokalu podlegającego 
opróżnieniu. 
**§ 6.** (uchylony) 
**§ 7.** (uchylony) 
**§ 8.** (uchylony) 
**§ 9.** Przeprowadzając egzekucję, komornik usunie ruchomości niebędące 
przedmiotem egzekucji i odda je dłużnikowi, a w razie jego nieobecności 
pozostawi osobie dorosłej spośród jego domowników, gdyby zaś i to nie było 
możliwe, ustanowi dozorcę, pouczając go o obowiązkach i prawach dozorcy 
ustanowionego przy zajęciu ruchomości, i odda mu usunięte ruchomości na 
przechowanie na koszt dłużnika. 
**§ 10.** Jeżeli na wezwanie dozorcy dłużnik w wyznaczonym terminie, nie 
krótszym niż 30 dni, nie odbierze ruchomości, sąd na wniosek dozorcy i po 
wysłuchaniu dłużnika nakaże ich sprzedaż, a jeżeli ruchomości nie przedstawiają 

 
 
 
s. 500/580 
 
2025-09-08 
 
wartości handlowej lub sprzedaż okaże się bezskuteczna, sąd wskaże inny sposób 
rozporządzenia rzeczą, nie wyłączając ich zniszczenia. 
**§ 11.** Minister 
Sprawiedliwości 
określi, 
w drodze 
rozporządzenia, 
szczegółowy 
tryb 
postępowania 
w sprawach 
o opróżnienie 
lokalu, 
lub 
pomieszczenia albo o wydanie nieruchomości, mając na względzie ochronę przed 
bezdomnością osób eksmitowanych oraz sprawne prowadzenie egzekucji. 
**§ 12.** Minister 
Sprawiedliwości 
określi, 
w drodze 
rozporządzenia, 
szczegółowy tryb postępowania w sprawach o wykonanie postanowienia 
zobowiązującego osobę stosującą przemoc domową do opuszczenia wspólnie 
zajmowanego mieszkania i jego bezpośredniego otoczenia, mając na względzie 
sprawne, szybkie i skuteczne prowadzenie egzekucji.

***
## Art. 1047. {#kpc-trzecia--art-1047}

**§ 1.** Jeżeli dłużnik jest obowiązany do złożenia oznaczonego 
oświadczenia woli, prawomocne orzeczenie sądu zobowiązujące do złożenia 
oświadczenia zastępuje oświadczenie dłużnika. 
**§ 2.** Jeżeli złożenie oświadczenia woli jest uzależnione od świadczenia 
wzajemnego wierzyciela, skutek wymieniony w paragrafie poprzedzającym 
powstaje dopiero z chwilą prawomocnego nadania orzeczeniu klauzuli 
wykonalności.

***
## Art. 1048. {#kpc-trzecia--art-1048}

Jeżeli ujawnienie na podstawie orzeczenia sądowego prawa 
wierzyciela przez wpis w księdze wieczystej lub w rejestrze albo przez złożenie 
dokumentu do zbioru wymaga poprzedniego ujawnienia prawa dłużnika, komornik 
na żądanie wierzyciela odbierze dłużnikowi dokumenty potrzebne do dokonania 
wpisu na rzecz dłużnika lub do złożenia do zbioru i złoży je w sądzie właściwym 
do prowadzenia księgi wieczystej, rejestru lub zbioru dokumentów.

***
## Art. 1049. {#kpc-trzecia--art-1049}

**§ 1.** Jeżeli w samym tytule egzekucyjnym nie postanowiono, że 
w razie niewykonania przez dłużnika w wyznaczonym terminie czynności, którą 
może wykonać także inna osoba, wierzyciel będzie umocowany do wykonania tej 
czynności na koszt dłużnika – sąd, w którego okręgu czynność ma być wykonana, 
na wniosek wierzyciela wezwie dłużnika do jej wykonania w wyznaczonym 
terminie. 

 
 
 
s. 501/580 
 
2025-09-08 
**§ 11.** W postępowaniu prowadzonym na podstawie niniejszego artykułu sąd 
bada fakt wykonania przez dłużnika czynności nakazanej tytułem wykonawczym, 
stosując odpowiednio przepisy o postępowaniu nieprocesowym. 
**§ 12.** W razie stwierdzenia, że w wyznaczonym terminie dłużnik nie wykonał 
czynności, sąd udzieli wierzycielowi umocowania do wykonania czynności na 
koszt dłużnika, wyznaczając odpowiedni termin do jej wykonania. Termin 
wykonania czynności może być na uzasadniony wniosek wierzyciela przedłużony. 
**§ 13.** Dłużnik może wykonać czynność nakazaną tytułem wykonawczym do 
chwili rozpoczęcia wykonania czynności przez wierzyciela. W razie wykonania 
czynności po tej chwili, dłużnik jest obowiązany zwrócić wierzycielowi, na jego 
wniosek, poniesione koszty. 
**§ 14.** Udzielając wierzycielowi umocowania, sąd może oznaczyć, na wniosek 
którejkolwiek 
ze 
stron, 
maksymalną 
wysokość 
kosztów 
czynności, 
z uwzględnieniem średnich cen obowiązujących na danym rynku. Postanowienie 
w tym przedmiocie zapada po przeprowadzeniu rozprawy. Z wnioskiem 
o oznaczenie maksymalnej wysokości kosztów czynności może wystąpić także 
wierzyciel, którego w tytule egzekucyjnym umocowano do wykonania czynności 
na koszt dłużnika. 
**§ 15.** Po wykonaniu czynności wierzyciel może wystąpić do sądu o przyznanie 
mu od dłużnika zwrotu udokumentowanych i celowych kosztów czynności, przy 
czym ich suma nie może przekraczać maksymalnej wysokości kosztów oznaczonej 
przez sąd zgodnie z § 14. 
**§ 16.** Prawomocne postanowienie sądu przyznające wierzycielowi od dłużnika 
zwrot kosztów czynności podlega wykonaniu bez zaopatrywania go w klauzulę 
wykonalności. Powyższe nie wyłącza dochodzenia przez wierzyciela zwrotu 
pozostałych poniesionych kosztów na zasadach ogólnych. 
**§ 17.** Jeżeli wierzyciel w terminie sześciu miesięcy od daty upływu 
wyznaczonego mu terminu nie zgłosił faktu dokonania czynności, sąd umarza 
postępowanie. Powyższe nie wyłącza dochodzenia przez wierzyciela zwrotu 
poniesionych kosztów na zasadach ogólnych. 
**§ 2.** Przepisów niniejszego artykułu nie stosuje się do czynności polegających 
na świadczeniu rzeczy oznaczonych co do tożsamości lub na złożeniu oświadczenia 

 
 
 
s. 502/580 
 
2025-09-08 
 
odpowiedniej treści i w odpowiedniej formie w związku z naruszeniem dóbr 
osobistych.

***
## Art. 1050. {#kpc-trzecia--art-1050}

**§ 1.** Jeżeli dłużnik ma wykonać czynność, której inna osoba 
wykonać za niego nie może, a której wykonanie zależy wyłącznie od jego woli, sąd, 
w którego okręgu czynność ma być wykonana, na wniosek wierzyciela po 
wysłuchaniu stron wyznaczy dłużnikowi termin do wykonania i zagrozi mu 
grzywną na wypadek, gdyby w wyznaczonym terminie czynności nie wykonał. 
**§ 11.** W sprawach z zakresu prawa pracy wierzyciel może złożyć wniosek, 
o którym mowa w § 1, do sądu właściwości ogólnej dłużnika albo do sądu, 
w którego okręgu praca jest, była lub miała być wykonywana, albo do sądu, 
w okręgu którego znajduje się zakład pracy. 
**§ 2.** Jeżeli wykonanie czynności wymaga wydatków pieniężnych lub 
dostarczenia materiałów, a obowiązek dostarczenia ich ciąży na wierzycielu, sąd 
przystąpi do egzekucji w myśl paragrafu poprzedzającego dopiero po wykazaniu 
przez wierzyciela, że dokonał czynności, od których zależy obowiązek dłużnika, 
chyba że tytuł egzekucyjny zawiera w tym względzie inne zarządzenie. 
**§ 3.** Po bezskutecznym upływie terminu wyznaczonego dłużnikowi do 
wykonania czynności, sąd na wniosek wierzyciela nałoży na dłużnika grzywnę 
i jednocześnie wyznaczy nowy termin do wykonania czynności, z zagrożeniem 
surowszą grzywną. 
**§ 4.** Jeżeli w sprawach o naruszenie dóbr osobistych dłużnik nie składa 
oświadczenia odpowiedniej treści i w odpowiedniej formie, pomimo wyznaczenia 
terminu do jego złożenia i zagrożenia mu grzywną, sąd wymierzy dłużnikowi 
grzywnę do piętnastu tysięcy złotych i nakaże zamieszczenie w Monitorze 
Sądowym i Gospodarczym na koszt dłużnika ogłoszenia odpowiadającego treści 
wymaganego oświadczenia i we właściwej dla niego formie. Przepisów art. 1052 
i art. 1053 nie stosuje się. Zamieszczenie w Monitorze Sądowym i Gospodarczym 
ogłoszenia, o którym mowa w zdaniu pierwszym, skutkuje – w objętym 
ogłoszeniem zakresie – wygaśnięciem roszczenia stwierdzonego tytułem 
wykonawczym.

***
## Art. 10501. {#kpc-trzecia--art-10501}

**§ 1.** W sytuacji, o której mowa w art. 1050 § 1, sąd, na wniosek 
wierzyciela, może zamiast zagrożenia grzywną, po wysłuchaniu stron, zagrozić 

 
 
 
s. 503/580 
 
2025-09-08 
 
dłużnikowi nakazaniem zapłaty na rzecz wierzyciela określonej sumy pieniężnej za 
każdy dzień zwłoki w wykonaniu czynności, niezależnie od roszczeń 
przysługujących wierzycielowi na zasadach ogólnych. Przepis art. 1050 § 2 stosuje 
się odpowiednio. 
**§ 2.** Po bezskutecznym upływie terminu wyznaczonego dłużnikowi do 
wykonania czynności, sąd na wniosek wierzyciela nakazuje dłużnikowi zapłatę 
wierzycielowi sumy pieniężnej. Tak samo sąd postąpi w razie dalszego wniosku 
wierzyciela. Prawomocne postanowienie sądu jest tytułem wykonawczym na rzecz 
wierzyciela bez potrzeby nadawania mu klauzuli wykonalności. Sąd może również, 
na wniosek wierzyciela, podwyższyć wysokość należnej mu od dłużnika sumy 
pieniężnej. 
**§ 3.** W razie wykonania czynności przez dłużnika po upływie wyznaczonego 
przez sąd terminu, wierzyciel może złożyć wniosek o nakazanie dłużnikowi zapłaty 
sumy pieniężnej na jego rzecz w terminie miesiąca od dnia dokonania czynności. 
**§ 4.** Określając wysokość sumy pieniężnej, o której mowa w § 1, sąd 
uwzględni interesy stron w takiej mierze, aby zapewnić wykonalność obowiązku 
określonego w tytule wykonawczym a dłużnika nie obciążać ponad potrzebę.

***
## Art. 1051. {#kpc-trzecia--art-1051}

**§ 1.** Jeżeli dłużnik ma obowiązek zaniechać pewnej czynności lub 
nie przeszkadzać czynności wierzyciela, sąd, w którego okręgu dłużnik działał 
wbrew swemu obowiązkowi, na wniosek wierzyciela po wysłuchaniu stron 
i stwierdzeniu, że dłużnik działał wbrew obowiązkowi, nałoży na niego grzywnę. 
Tak samo sąd postąpi w razie dalszego wniosku wierzyciela. 
**§ 2.** Ponadto sąd może na wniosek wierzyciela zobowiązać dłużnika do 
zabezpieczenia szkody, grożącej wierzycielowi wskutek dalszego działania 
dłużnika wbrew obowiązkowi. W postanowieniu sąd może wskazać wysokość 
i czas trwania zabezpieczenia. 
**§ 3.** Jeżeli w samym tytule egzekucyjnym nie postanowiono, że w razie 
dokonania zmiany sprzecznej z obowiązkiem dłużnika wierzyciel będzie 
uprawniony do usunięcia tej zmiany na koszt dłużnika, sąd na wniosek wierzyciela 
po wysłuchaniu stron upoważni wierzyciela do usunięcia tej zmiany na koszt 
dłużnika. Na żądanie wierzyciela sąd przyzna mu sumę na ten cel potrzebną. 
W razie oporu dłużnika sąd na wniosek wierzyciela poleci komornikowi usunięcie 
oporu. 

 
 
 
s. 504/580 
 
2025-09-08

***
## Art. 10511. {#kpc-trzecia--art-10511}

**§ 1.** W sytuacji, o której mowa w art. 1051 § 1, sąd, na wniosek 
wierzyciela, po wysłuchaniu stron i stwierdzeniu, że dłużnik działał wbrew 
obowiązkowi, może zamiast nałożenia grzywny nakazać dłużnikowi zapłatę na 
rzecz wierzyciela określonej sumy pieniężnej za dokonane naruszenie oraz zagrozić 
nakazaniem zapłaty określonej sumy pieniężnej za każde kolejne naruszenie 
obowiązku, stosownie do jego treści, niezależnie od roszczeń przysługujących 
wierzycielowi na zasadach ogólnych. 
**§ 2.** Po stwierdzeniu, że dłużnik w dalszym ciągu działał wbrew 
obowiązkowi, sąd, na wniosek wierzyciela, po wysłuchaniu stron, nakazuje 
dłużnikowi zapłatę wierzycielowi sumy pieniężnej. Tak samo sąd postąpi w razie 
dalszego wniosku wierzyciela. 
**§ 3.** Przepisy art. 10501 § 2 zdanie trzecie i czwarte, art. 10501 § 4 oraz 
art. 1051 § 2 i 3 stosuje się odpowiednio.

***
## Art. 1052. {#kpc-trzecia--art-1052}

W jednym postanowieniu sąd może wymierzyć grzywnę nie 
wyższą niż piętnaście tysięcy złotych, chyba że dwukrotne wymierzenie grzywny 
okazało się nieskuteczne. Ogólna suma grzywien w tej samej sprawie nie może 
przewyższać miliona złotych. W razie wykonania czynności przez dłużnika lub 
umorzenia postępowania grzywny niezapłacone do tego czasu ulegają umorzeniu.

***
## Art. 1053. {#kpc-trzecia--art-1053}

**§ 1.** Wymierzając grzywnę, sąd orzeknie jednocześnie – na 
wypadek niezapłacenia – zamianę grzywny na areszt, licząc jeden dzień aresztu od 
pięćdziesięciu do tysiąca pięciuset złotych grzywny. Ogólny czas trwania aresztu 
nie może w tej samej sprawie przekroczyć 6 miesięcy. 
**§ 2.** Jeżeli dłużnikiem, do którego skierowane było wezwanie sądu, jest osoba 
prawna lub inna organizacja, środkom przymusu podlega jej pracownik 
odpowiedzialny za niezastosowanie się do wezwania, a gdyby ustalenie takiego 
pracownika było utrudnione, środkom przymusu podlegają osoby uprawnione do 
jej reprezentowania.

***
## Art. 1054. {#kpc-trzecia--art-1054}

**§ 1.** Jeżeli postępowanie egzekucyjne zostanie umorzone albo 
dłużnik na skutek aresztu zgłosi gotowość wykonania czynności, sąd postanowi 
zwolnić go niezwłocznie i zawiadomi o tym wierzyciela. Dłużnikowi, który zgłosił 
gotowość wykonania czynności, sąd stosownie do okoliczności wyznaczy termin 
do jej wykonania. 

 
 
 
s. 505/580 
 
2025-09-08 
**§ 2.** Gdyby dłużnik po zwolnieniu zwlekał z wykonaniem czynności, sąd na 
wniosek wierzyciela po wysłuchaniu stron zarządzi wykonanie aresztu do końca 
wyznaczonego poprzednio terminu. 
**§ 3.** Jeżeli dłużnik zgłosił się ponownie do wykonania czynności, sąd może 
odmówić zwolnienia go z aresztu przed upływem oznaczonego czasu.

***
## Art. 1055. {#kpc-trzecia--art-1055}

Na postanowienie sądu co do wezwania dłużnika do wykonania 
czynności, zagrożenia grzywną i jej zamiany na areszt, co do zabezpieczenia 
szkody wierzyciela oraz na postanowienia, o których mowa w art. 10501 § 1–3 oraz 
art. 10511 § 1 i 2, przysługuje zażalenie.

***
## Art. 1056. {#kpc-trzecia--art-1056}

**§ 1.** Areszt 
wykonywa 
się 
przez 
osadzenie 
dłużnika 
w pomieszczeniu na ten cel przeznaczonym, oddzielnie od osób pozbawionych 
wolności w trybie postępowania karnego i administracyjnego. Dłużnik powinien 
jednak podczas przebywania w areszcie być według możności zatrudniony 
zarobkowo w granicach jego zdolności. Z zarobku jego pokrywa się przede 
wszystkim koszty wykonania aresztu. 
**§ 2.** Polecenie osadzenia dłużnika w areszcie sąd kieruje do komornika 
miejsca pobytu dłużnika. Jeżeli dłużnik nie przebywa w okręgu sądu, który 
wymierzył grzywnę z zamianą na areszt, sąd może zwrócić się o wykonanie aresztu 
do sądu rejonowego, w którego okręgu dłużnik przebywa. 
**§ 3.** Koszty wykonania aresztu powinny być pokryte z zarobków dłużnika. 
Wierzyciel obowiązany jest złożyć z góry komornikowi sumę potrzebną na 
sprowadzenie dłużnika do miejsca osadzenia i na wyżywienie go przez czas trwania 
przymusu; nie dotyczy to wypadku, gdy wierzyciel korzysta ze zwolnienia od 
kosztów sądowych.

***
## Art. 1057. {#kpc-trzecia--art-1057}

**§ 1.** Zarządzając wykonanie aresztu, sąd wydaje komornikowi 
nakaz na piśmie z odpowiednim uzasadnieniem. Wraz z przystąpieniem do 
wykonania nakazu komornik doręcza go dłużnikowi. 
**§ 2.** O wykonanie aresztu w stosunku do dłużnika będącego żołnierzem w 
czynnej służbie wojskowej, z wyjątkiem terytorialnej służby wojskowej pełnionej 
dyspozycyjnie, albo funkcjonariuszem Policji, Służby Ochrony Państwa, Agencji 
Bezpieczeństwa 
Wewnętrznego, 
Agencji 
Wywiadu, 
Centralnego 
Biura 
Antykorupcyjnego lub Straży Granicznej sąd zwraca się do dowódcy jednostki 

 
 
 
s. 506/580 
 
2025-09-08 
 
wojskowej albo odpowiednio do właściwego komendanta lub kierownika jednostki 
organizacyjnej Policji, Służby Ochrony Państwa, Agencji Bezpieczeństwa 
Wewnętrznego, Agencji Wywiadu, Centralnego Biura Antykorupcyjnego lub 
Straży Granicznej, w której pełni on służbę, przesyłając w tym celu nakaz. O 
wykonanie aresztu w stosunku do dłużnika będącego żołnierzem zawodowym 
wyznaczonym na stanowisko służbowe w Służbie Kontrwywiadu Wojskowego 
albo Służbie Wywiadu Wojskowego albo będącego funkcjonariuszem Służby 
Kontrwywiadu Wojskowego albo Służby Wywiadu Wojskowego sąd zwraca się 
odpowiednio do Szefa Służby Kontrwywiadu Wojskowego albo Szefa Służby 
Wywiadu Wojskowego, przesyłając w tym celu nakaz.

***
## Art. 1058. {#kpc-trzecia--art-1058}

**§ 1.** W stosunku do osób, których zdrowie może być narażone na 
niebezpieczeństwo, aresztu nie wykonuje się aż do ich wyzdrowienia. 
**§ 2.** Na wniosek jednej ze stron i na jej koszt zarządza się zbadanie stanu 
zdrowia dłużnika przez lekarza sądowego.

***
## Art. 1059. {#kpc-trzecia--art-1059}

Z ważnej przyczyny sąd może zwolnić dłużnika z aresztu na czas 
nie dłuższy niż tydzień. 
#### DZIAŁ II
Przepisy szczególne o egzekucji z udziałem Skarbu Państwa oraz 
przedsiębiorców 
Rozdział 1 
Przepisy ogólne

***
## Art. 1060. {#kpc-trzecia--art-1060}

**§ 1.** Jeżeli dłużnikiem jest Skarb Państwa, wierzyciel – wskazując 
na tytuł egzekucyjny – wzywa do spełnienia świadczenia bezpośrednio państwową 
jednostkę organizacyjną, z której działalnością wiąże się to świadczenie; jednostka 
ta jest obowiązana spełnić niezwłocznie świadczenie stwierdzone tytułem 
egzekucyjnym. 
**§ 11.** W sprawach o naprawienie szkody wyrządzonej przez wydanie ustawy, 
rozporządzenia Rady Ministrów lub rozporządzenia innego organu konstytucyjnie 
do tego powołanego, niezgodnych z Konstytucją, ratyfikowaną umową 
międzynarodową lub ustawą, a także w sprawie o naprawienie szkody wyrządzonej 
przez niewydanie takiego aktu normatywnego, którego obowiązek wydania 

 
 
 
s. 507/580 
 
2025-09-08 
 
przewiduje przepis prawa, wierzyciel – wskazując na tytuł egzekucyjny – wzywa 
do spełnienia świadczenia bezpośrednio ministra właściwego do spraw finansów 
publicznych, który jest obowiązany spełnić niezwłocznie świadczenie stwierdzone 
tytułem egzekucyjnym ze środków utworzonej w ramach budżetu państwa rezerwy 
celowej. 
**§ 2.** W wypadku gdy tytuł egzekucyjny, obejmujący należność pieniężną, nie 
zostanie wykonany w ciągu dwóch tygodni od dnia doręczenia wezwania, o którym 
mowa w § 1, wierzyciel może wystąpić do sądu o nadanie tytułowi egzekucyjnemu 
klauzuli wykonalności w celu przeprowadzenia egzekucji z rachunku bankowego 
właściwej państwowej jednostki organizacyjnej dłużnika. W przypadku, o którym 
mowa w § 11, egzekucję prowadzi się z rachunków bankowych służących do 
obsługi centralnego rachunku bieżącego budżetu państwa. 
**§ 3.** W wypadku 
gdy 
w terminie, 
o którym 
mowa 
w paragrafie 
poprzedzającym, nie zostanie wykonany tytuł egzekucyjny obejmujący 
świadczenie niepieniężne, sąd, na wniosek wierzyciela, wyznacza termin do 
spełnienia 
świadczenia 
kierownikowi 
właściwej 
państwowej 
jednostki 
organizacyjnej i temu kierownikowi wymierza grzywnę w razie niespełnienia 
świadczenia w wyznaczonym terminie.

***
## Art. 1061. {#kpc-trzecia--art-1061}

**§ 1.** Dłużnik prowadzący działalność gospodarczą w formie 
przedsiębiorstwa lub gospodarstwa rolnego, w razie gdy egzekucja zostanie 
skierowana do rzeczy niezbędnej do prowadzenia tej działalności, może wystąpić 
do sądu o wyłączenie tej rzeczy spod zajęcia, wskazując we wniosku składniki 
swego mienia, z których jest możliwe zaspokojenie roszczenia wierzyciela 
w zamian za rzecz zwolnioną. O wyłączeniu spod zajęcia sąd orzeka po 
wysłuchaniu stron, biorąc pod uwagę obok interesów wierzyciela i dłużnika 
również społeczno-gospodarcze znaczenie działalności gospodarczej dłużnika. 
Z chwilą wydania postanowienia zwalniającego spod zajęcia, w stosunku do 
mienia zastępczego określonego w postanowieniu następują skutki zajęcia. 
Komornik dokona niezwłocznie czynności związanych z zajęciem. Wniosek 
o zwolnienie spod zajęcia może być zgłoszony również w skardze na czynności 
komornika. 
**§ 2.** Na postanowienie sądu w sprawie wyłączenia służy zażalenie. 

 
 
 
s. 508/580 
 
2025-09-08

***
## Art. 1062. {#kpc-trzecia--art-1062}

(uchylony)

***
## Art. 1063. {#kpc-trzecia--art-1063}

W toku egzekucji świadczeń pieniężnych z nieruchomości Skarb 
Państwa nie składa rękojmi.

***
## Art. 10631. {#kpc-trzecia--art-10631}

W sprawach, których przedmiotem jest egzekucja grzywien i kar 
pieniężnych orzeczonych w postępowaniu cywilnym, a także kosztów sądowych 
w sprawach cywilnych, przysługujących Skarbowi Państwa, korespondencja 
między wierzycielem a komornikiem może być doręczana za pośrednictwem 
środków komunikacji elektronicznej, jeżeli zapewniają one możliwość ustalenia 
daty, z jaką adresat zapoznał się z treścią pisma, a charakter pisma lub dołączonych 
do niego załączników nie sprzeciwia się takiej formie doręczeń.

***
## Art. 1064. {#kpc-trzecia--art-1064}

Minister Sprawiedliwości określi, w drodze rozporządzenia, 
sposób prowadzenia egzekucji grzywien i kar pieniężnych orzeczonych 
w postępowaniu cywilnym, a także kosztów sądowych w sprawach cywilnych, 
przysługujących Skarbowi Państwa, mając na uwadze sprawność i skuteczność 
postępowania egzekucyjnego. 
Rozdział 2 
Egzekucja przez zarząd przymusowy

***
## Art. 10641. {#kpc-trzecia--art-10641}

**§ 1.** Przeciwko 
dłużnikowi 
prowadzącemu 
działalność 
gospodarczą 
w formie 
przedsiębiorstwa 
lub 
gospodarstwa 
rolnego 
jest 
dopuszczalna egzekucja z dochodów uzyskiwanych z tej działalności przez 
ustanowienie zarządu przymusowego nad przedsiębiorstwem lub gospodarstwem 
rolnym. 
**§ 2.** Do zarządu ustanowionego na podstawie § 1 stosuje się odpowiednio 
przepisy o zarządzie w toku egzekucji z nieruchomości, z uwzględnieniem 
artykułów poniższych.

***
## Art. 10642. {#kpc-trzecia--art-10642}

**§ 1.** We 
wniosku 
o wszczęcie 
egzekucji 
przez 
zarząd 
przymusowy należy dokładnie określić przedsiębiorstwo lub gospodarstwo rolne 
albo ich część. 
**§ 2.** Do 
wniosku 
dołącza 
się 
informację 
komornika 
o wszystkich 
postępowaniach egzekucyjnych prowadzonych przeciwko dłużnikowi z mienia 
wchodzącego w skład przedsiębiorstwa lub gospodarstwa rolnego. 

 
 
 
s. 509/580 
 
2025-09-08

***
## Art. 10643. {#kpc-trzecia--art-10643}

**§ 1.** (uchylony) 
**§ 2.** Postanowienie w przedmiocie wniosku doręcza się również wskazanym 
we wniosku wierzycielom prowadzącym egzekucję z mienia wchodzącego w skład 
przedsiębiorstwa lub gospodarstwa rolnego. 
**§ 3.** Na postanowienie sądu przysługuje zażalenie stronom oraz wierzycielom, 
którzy prowadzą egzekucję z mienia wchodzącego w skład przedsiębiorstwa lub 
gospodarstwa rolnego. 
**§ 4.** Termin do wniesienia zażalenia przez wierzycieli, o których mowa w § 3, 
niewskazanych we wniosku, liczy się od dnia powzięcia przez nich wiadomości 
o wszczęciu egzekucji.

***
## Art. 10644. {#kpc-trzecia--art-10644}

Do prowadzenia egzekucji przez zarząd przymusowy właściwy 
jest sąd, w którego okręgu znajduje się siedziba przedsiębiorstwa lub w którego 
okręgu jest położone gospodarstwo rolne. Jeżeli gospodarstwo rolne położone jest 
w okręgu kilku sądów, wybór należy do wierzyciela. Jeżeli egzekucja ograniczona 
jest do części przedsiębiorstwa lub gospodarstwa rolnego, właściwy jest sąd, 
w którego okręgu część ta się znajduje.

***
## Art. 10645. {#kpc-trzecia--art-10645}

Egzekucję przez zarząd przymusowy można ograniczyć do części 
przedsiębiorstwa lub gospodarstwa rolnego, jeżeli część ta jest gospodarczo 
wyodrębniona, a dochód uzyskany z przymusowego zarządu tej części majątku 
dłużnika wystarczy na zaspokojenie egzekwowanych roszczeń.

***
## Art. 10646. {#kpc-trzecia--art-10646}

**§ 1.** Prowadzenie egzekucji świadczeń pieniężnych, w tym 
również egzekucji administracyjnych ze składników mienia wchodzącego w skład 
przedsiębiorstwa lub gospodarstwa rolnego dłużnika, nie stanowi przeszkody do 
wszczęcia egzekucji przez zarząd przymusowy, jeżeli o to wnosi wierzyciel 
dotychczas prowadzący egzekucję albo, gdy w chwili wszczęcia egzekucji przez 
zarząd przymusowy jest oczywiste, że wierzyciel prowadzący egzekucję zostanie 
w toku egzekucji przez zarząd przymusowy zaspokojony w okresie sześciu 
miesięcy od daty jej wszczęcia. 
**§ 2.** W razie wszczęcia egzekucji przez zarząd przymusowy w sprawach 
określonych w § 1, wcześniej wszczęte egzekucje umarza się z dniem 
uprawomocnienia się postanowienia sądu o wszczęciu egzekucji przez zarząd 

 
 
 
s. 510/580 
 
2025-09-08 
 
przymusowy, a dotychczasowi wierzyciele z mocy prawa wstępują do egzekucji 
prowadzonej według przepisów niniejszego działu.

***
## Art. 10647. {#kpc-trzecia--art-10647}

Jeżeli przed wszczęciem egzekucji ustanowiono zarząd nad 
przedsiębiorstwem lub gospodarstwem rolnym dłużnika w ramach postępowania 
zabezpieczającego, po wszczęciu egzekucji zarząd będzie prowadzony według 
niniejszych przepisów.

***
## Art. 10648. {#kpc-trzecia--art-10648}

Wydając postanowienie o wszczęciu egzekucji przez zarząd 
przymusowy, sąd przesyła do sądu właściwego do prowadzenia księgi wieczystej 
dla nieruchomości wchodzącej w skład przedsiębiorstwa lub gospodarstwa rolnego 
wniosek o dokonanie wpisu o ustanowienie zarządu przymusowego we właściwej 
księdze wieczystej lub o złożenie wniosku do zbioru dokumentów.

***
## Art. 10649. {#kpc-trzecia--art-10649}

Czynności prawne dłużnika dotyczące mienia objętego zarządem 
dokonane po wszczęciu egzekucji są nieważne. Dla określenia daty powstania 
skutków prawnych wszczęcia egzekucji prowadzonej według niniejszego rozdziału 
przepisy art. 910 stosuje się odpowiednio.

***
## Art. 106410. {#kpc-trzecia--art-106410}

**§ 1.** Sąd powołuje na zarządcę osobę fizyczną lub prawną 
wskazaną 
przez 
strony 
spośród 
osób 
posiadających 
licencję 
doradcy 
restrukturyzacyjnego. 
**§ 2.** W wypadku braku porozumienia stron zarządcę wyznacza sąd spośród 
osób wskazanych w § 1. 
**§ 3.** Przepisy § 1 i § 2 stosuje się odpowiednio do odwołania lub zmiany 
zarządcy.

***
## Art. 106411. {#kpc-trzecia--art-106411}

**§ 1.** W szczególnie uzasadnionych wypadkach zarządca może 
sprzedać nieruchomości, ruchomości lub prawa wchodzące w skład zarządzanego 
przedsiębiorstwa lub gospodarstwa rolnego w części przekraczającej zakres zwyk-
łego zarządu oraz oddać je w najem lub dzierżawę wyłącznie za zgodą sądu. 
W razie zarządzenia sprzedaży sąd określa warunki sprzedaży. Do wyceny 
sprzedawanych składników majątkowych sąd może powołać biegłego. Przepis ten 
stosuje się również do rozwiązania umowy najmu lub dzierżawy oraz do obciążenia 
zarządzanego majątku hipoteką, zastawem, zastawem rejestrowym oraz 
przewłaszczeniem. 

 
 
 
s. 511/580 
 
2025-09-08 
**§ 2.** Na postanowienie sądu w przedmiocie czynności, o których mowa w § 1, 
stronom, zarządcy oraz osobom, których praw czynność dotyczy lub miała 
dotyczyć, przysługuje zażalenie. 
**§ 3.** Nadwyżkę dochodów, po pokryciu wydatków wskazanych w art. 940, 
zarządca wypłaca wierzycielowi. W razie wielości wierzycieli wypłata następuje 
z zachowaniem stosowanych odpowiednio przepisów ogólnych o podziale sumy 
uzyskanej z egzekucji oraz przepisów o podziale sumy uzyskanej z egzekucji 
z nieruchomości. Kwoty niewypłacone zarządca umieszcza na rachunku 
depozytowym Ministra Finansów.

***
## Art. 106412. {#kpc-trzecia--art-106412}

**§ 1.** Po wszczęciu egzekucji przez zarząd przymusowy 
prowadzenie egzekucji świadczeń pieniężnych innymi sposobami z majątku 
dłużnika wchodzącego w skład przedsiębiorstwa lub gospodarstwa rolnego jest 
niedopuszczalne. Inni wierzyciele mogą przyłączyć się do egzekucji przez zarząd 
przymusowy. Przepis niniejszy stosuje się odpowiednio w razie późniejszego 
skierowania przeciwko dłużnikowi egzekucji administracyjnej. W takim wypadku 
art. 773 nie ma zastosowania. 
**§ 2.** Jeżeli dochody uzyskane z egzekucji przez zarząd przymusowy wskazują, 
że niemożliwe jest zaspokojenie wszystkich wierzycieli w okresie sześciu 
miesięcy, licząc od dnia przyłączenia się do egzekucji ostatniego wierzyciela, 
wierzyciel, który w tym okresie nie będzie zaspokojony, może żądać wszczęcia 
egzekucji ze składników mienia wchodzącego w skład przedsiębiorstwa lub 
gospodarstwa rolnego objętego zarządem przymusowym. W żądaniu należy 
oznaczyć mienie, z którego egzekucja ma być prowadzona. Na postanowienie sądu 
o dopuszczeniu egzekucji przysługuje zażalenie. 
**§ 3.** Prowadzenie egzekucji przez zarząd przymusowy nie stanowi przeszkody 
do prowadzenia przeciwko dłużnikowi egzekucji świadczeń niepieniężnych oraz 
egzekucji w celu zniesienia współwłasności nieruchomości w drodze sprzedaży 
publicznej. Jeżeli w toku tych egzekucji dłużnik obowiązany jest do wydania 
ruchomości, statku lub nieruchomości albo do opróżnienia pomieszczeń, które 
znajdują się we władaniu zarządcy, obowiązki te ciążą na zarządcy. 
**§ 4.** Wyłączenie mienia do osobnych egzekucji według przepisów § 1–3 nie 
tamuje dalszego prowadzenia egzekucji przez zarząd przymusowy, chyba że 
z uwagi na zakres wyłączeń dalsze jej prowadzenie jest bezcelowe. W takim 

 
 
 
s. 512/580 
 
2025-09-08 
 
wypadku sąd umarza egzekucję przez zarząd przymusowy. Wierzyciele, którzy 
prowadzili egzekucję przez zarząd przymusowy, mogą w terminie dwóch tygodni 
od dnia uprawomocnienia się postanowienia o umorzeniu tej egzekucji żądać 
skierowania egzekucji do mienia, które objęte było tą egzekucją, a które nie zostało 
wcześniej z niej wyłączone. Do tego czasu mienie to podlega z mocy prawa zajęciu.

***
## Art. 106413. {#kpc-trzecia--art-106413}

**§ 1.** Zarządca sporządza plan podziału sumy uzyskanej 
z egzekucji. 
**§ 2.** Na plan podziału sumy uzyskanej z egzekucji przysługuje skarga, do 
której stosuje się odpowiednio przepisy o skardze na czynności komornika. 
**§ 3.** Przepisy ogólne o podziale sumy uzyskanej z egzekucji oraz przepisy 
o podziale sumy uzyskanej z egzekucji z nieruchomości stosuje się odpowiednio. 
Rozdział 3 
Egzekucja przez sprzedaż przedsiębiorstwa lub gospodarstwa rolnego

***
## Art. 106414. {#kpc-trzecia--art-106414}

**§ 1.** Egzekucja 
przez 
sprzedaż 
przedsiębiorstwa 
lub 
gospodarstwa rolnego należy do sądu, w którego okręgu znajduje się siedziba 
przedsiębiorstwa dłużnika lub w którym dłużnik ma gospodarstwo rolne. 
**§ 2.** Do egzekucji przez sprzedaż przedsiębiorstwa lub gospodarstwa rolnego 
dłużnika stosuje się odpowiednio przepisy o egzekucji z nieruchomości, jeżeli 
przepisy niniejszego rozdziału nie stanowią inaczej.

***
## Art. 106415. {#kpc-trzecia--art-106415}

**§ 1.** Wydając postanowienie o wszczęciu egzekucji, sąd 
ustanawia zarząd przymusowy nad przedsiębiorstwem lub gospodarstwem rolnym 
podlegającym sprzedaży. Do zarządu tego stosuje się odpowiednio przepisy 
art. 10641–106411. 
**§ 2.** Postanowienie o wszczęciu egzekucji sąd przesyła do sądu właściwego 
do prowadzenia księgi wieczystej dla nieruchomości wchodzącej w skład 
przedsiębiorstwa lub gospodarstwa rolnego. Sąd właściwy do prowadzenia księgi 
wieczystej z urzędu dokonuje wpisu o wszczęciu egzekucji albo składa 
postanowienie do zbioru dokumentów. W razie wszczęcia egzekucji przeciwko 
przedsiębiorcy podlegającemu wpisowi do właściwego rejestru, sąd przesyła 
postanowienie o wszczęciu egzekucji w celu złożenia do akt rejestrowych. Ponadto 
sąd zarządza zamieszczenie ogłoszenia o wszczęciu egzekucji w Monitorze 
Sądowym i Gospodarczym oraz na stronie internetowej Krajowej Rady 

 
 
 
s. 513/580 
 
2025-09-08 
 
Komorniczej. Sąd może również zarządzić zamieszczenie ogłoszenia w dzienniku 
lub czasopiśmie poczytnym w danej miejscowości właściwej ze względu na 
miejsce położenia nieruchomości wchodzącej w skład przedsiębiorstwa lub 
gospodarstwa rolnego.

***
## Art. 106416. {#kpc-trzecia--art-106416}

**§ 1.** Prowadzenie egzekucji ze składników przedsiębiorstwa lub 
gospodarstwa rolnego, w tym egzekucji administracyjnej, nie stanowi przeszkody 
do wszczęcia egzekucji przez sprzedaż przedsiębiorstwa lub gospodarstwa rolnego, 
jeżeli o to wnosi dłużnik lub wierzyciel prowadzący egzekucję, a także gdy jest 
oczywiste, że egzekucja przez sprzedaż doprowadzi do zaspokojenia wierzycieli, 
którzy wcześniej wszczęli egzekucję. Na postanowienie sądu służy zażalenie. 
**§ 2.** Z chwilą uprawomocnienia się postanowienia sądu wszczynającego 
egzekucję w trybie wskazanym w § 1, egzekucje wszczęte wcześniej umarza się, 
a dotychczasowi wierzyciele z mocy prawa przystępują do egzekucji prowadzonej 
według przepisów niniejszego rozdziału.

***
## Art. 106417. {#kpc-trzecia--art-106417}

**§ 1.** Zarządca niezwłocznie sporządzi bilans przedsiębiorstwa 
lub gospodarstwa rolnego dłużnika. 
**§ 2.** Jeżeli dłużnik i wszyscy wierzyciele nie ustalili ceny sprzedaży 
przedsiębiorstwa lub gospodarstwa rolnego, wyceny przedsiębiorstwa lub 
gospodarstwa rolnego dokonuje co najmniej dwóch biegłych. W razie rozbieżności 
w wycenie dokonanej przez biegłych, wartość przedsiębiorstwa lub gospodarstwa 
rolnego ustala sąd.

***
## Art. 106418. {#kpc-trzecia--art-106418}

**§ 1.** Na wniosek wierzyciela lub dłużnika sąd może postanowić, 
że sprzedaż przedsiębiorstwa lub gospodarstwa rolnego nastąpi z wolnej ręki przez 
zarządcę. Sprzedaż nie może nastąpić poniżej wartości szacunkowej, chyba że 
dłużnik i wszyscy wierzyciele wyrażą na to zgodę. 
**§ 2.** Wydając postanowienie o sprzedaży z wolnej ręki, sąd wyznaczy termin, 
w którym sprzedaż ma być dokonana, oraz określi tryb wyszukania nabywcy, jeżeli 
strony tego nie uzgodniły. Termin dokonania sprzedaży nie może być krótszy niż 
miesiąc i dłuższy niż dwa miesiące. Bieg terminu rozpoczyna się od dnia 
zamieszczenia ogłoszenia w Monitorze Sądowym i Gospodarczym.

***
## Art. 106419. {#kpc-trzecia--art-106419}

**§ 1.** Sąd zarządzi zamieszczenie ogłoszenia postanowienia, 
o którym mowa w art. 106416 § 1, w Monitorze Sądowym i Gospodarczym oraz na 

 
 
 
s. 514/580 
 
2025-09-08 
 
stronie internetowej Krajowej Rady Komorniczej. Sąd może również zarządzić 
zamieszczenie tego ogłoszenia w dzienniku lub czasopiśmie poczytnym w danej 
miejscowości właściwej ze względu na miejsce położenia nieruchomości 
wchodzącej w skład przedsiębiorstwa lub gospodarstwa rolnego. 
**§ 2.** O wydaniu postanowienia nakazującego sprzedaż zarządca zawiadomi 
uczestników stosownie do art. 954.

***
## Art. 106420. {#kpc-trzecia--art-106420}

**§ 1.** Jeżeli pierwsza sprzedaż z wolnej ręki nie dojdzie do skutku, 
sąd wyda postanowienie nakazujące sprzedaż w drodze licytacji, chyba że 
wierzyciele zgodzą się na ponowną sprzedaż z wolnej ręki. 
**§ 2.** Licytację 
prowadzi 
zarządca 
pod 
nadzorem 
sędziego. 
Sędzia 
niezwłocznie udziela przybicia osobie, która zaoferowała najwyższą cenę. 
**§ 3.** Po zapłacie ceny zarządca w terminie nie dłuższym niż miesiąc zawiera 
z nabywcą umowę sprzedaży przedsiębiorstwa lub gospodarstwa rolnego. 
W wypadku niezawarcia umowy z winy zarządcy, nabywca może żądać zwrotu 
wpłaconej ceny i uważa się, że licytacja nie doszła do skutku. 
**§ 4.** Do licytacji stosuje się odpowiednio przepisy o licytacji z nieruchomości.

***
## Art. 106421. {#kpc-trzecia--art-106421}

**§ 1.** Sprzedaż dokonana w myśl przepisów niniejszego rozdziału 
nie narusza praw wynikających z hipotek, zastawów rejestrowych, zastawów 
i innych obciążeń rzeczowych ciążących na nieruchomościach, wierzytelnościach 
lub prawach wchodzących w skład przedsiębiorstwa lub gospodarstwa rolnego 
dłużnika. Ich wartość podlega zaliczeniu na poczet ceny nabycia. 
**§ 2.** Sprzedaż dokonana według przepisów niniejszego rozdziału nie narusza 
również uprawnień zastawnika zastawu rejestrowego, jeżeli umowa zastawnicza 
przewiduje zakaz zbycia przedmiotu zastawu.

***
## Art. 106422. {#kpc-trzecia--art-106422}

**§ 1.** Nabywca przedsiębiorstwa lub gospodarstwa rolnego 
w egzekucji 
prowadzonej 
według 
przepisów 
niniejszego 
rozdziału 
jest 
odpowiedzialny solidarnie z dłużnikiem za ujawnione w toku egzekucji 
zobowiązania związane z prowadzeniem przedsiębiorstwa lub gospodarstwa 
rolnego według zasad określonych w art. 554 Kodeksu cywilnego. 
**§ 2.** Jeżeli przed zawarciem umowy sprzedaży przedsiębiorstwa lub 
gospodarstwa rolnego nabywca spłacił lub przejął zobowiązania, o których mowa 
w § 1, wartość przejętych należności zalicza się na poczet ceny kupna. Jeżeli 

 
 
 
s. 515/580 
 
2025-09-08 
 
nabywca wcześniej wpłacił cenę niepomniejszoną o tę wartość, zarządca zwraca 
mu nadwyżkę w terminie tygodniowym od daty zawarcia umowy sprzedaży. 
Zaliczenie lub zwrot nadwyżki nastąpi na podstawie dokumentów urzędowych lub 
prywatnych z podpisem urzędowo poświadczonym, stwierdzających spłatę lub 
przejęcie zobowiązań wymienionych w § 1.

***
## Art. 106423. {#kpc-trzecia--art-106423}

Do podziału sumy uzyskanej ze sprzedaży przedsiębiorstwa lub 
gospodarstwa rolnego stosuje się odpowiednio przepisy ogólne o podziale sumy 
uzyskanej z egzekucji oraz przepisy o podziale sumy uzyskanej z egzekucji 
z nieruchomości.

***
## Art. 1065. {#kpc-trzecia--art-1065}

(uchylony) 
#### DZIAŁ III
Egzekucja w celu zniesienia współwłasności nieruchomości w drodze 
sprzedaży publicznej

***
## Art. 1066. {#kpc-trzecia--art-1066}

W postępowaniu egzekucyjnym wszczętym na podstawie tytułu 
wykonawczego, a mającym na celu zniesienie współwłasności nieruchomości 
w drodze sprzedaży publicznej, stosuje się odpowiednio przepisy o egzekucji z nie-
ruchomości ze zmianami wskazanymi w artykułach poniższych.

***
## Art. 1067. {#kpc-trzecia--art-1067}

Postępowanie może być wszczęte z urzędu lub na wniosek 
każdego ze współwłaścicieli na podstawie tytułu wykonawczego, który postanawia, 
że zniesienie współwłasności ma być przeprowadzone w drodze sprzedaży 
nieruchomości.

***
## Art. 1068. {#kpc-trzecia--art-1068}

**§ 1.** Na podstawie wniosku o wszczęcie egzekucji komornik 
przesyła do właściwego sądu wniosek o ujawnienie wszczęcia egzekucji w księdze 
wieczystej lub o złożenie wniosku do zbioru dokumentów. 
**§ 2.** We wpisie w księdze wieczystej lub zarządzeniu złożenia wniosku do 
zbioru dokumentów oraz w obwieszczeniu o licytacji należy podać, że egzekucja 
ma na celu zniesienie współwłasności.

***
## Art. 1069. {#kpc-trzecia--art-1069}

**§ 1.** W wypadku gdy według przepisów szczególnych przysługuje 
współwłaścicielowi lub osobie trzeciej prawo pierwokupu nieruchomości rolnej 
wchodzącej w skład gospodarstwa rolnego, postanowienie o przybiciu po jego 
uprawomocnieniu się sąd doręcza uprawnionemu do wykonania prawa 

 
 
 
s. 516/580 
 
2025-09-08 
 
pierwokupu. W tym wypadku bieg terminu do wykonania przez nabywcę 
warunków licytacyjnych rozpoczyna się z chwilą bezskutecznego upływu terminu 
do wykonania prawa pierwokupu. 
**§ 2.** Jeżeli uprawniony wykona prawo pierwokupu, sąd uchyli postanowienie 
o przybiciu i udzieli przybicia na rzecz uprawnionego do wykonania prawa 
pierwokupu.

***
## Art. 1070. {#kpc-trzecia--art-1070}

Egzekucja 
w celu 
zniesienia 
współwłasności 
i egzekucja 
z nieruchomości mogą toczyć się jednocześnie. W razie sprzedaży nieruchomości 
w toku jednej z tych egzekucji – drugą zawiesza się, a po uprawomocnieniu się 
postanowienia o przysądzeniu własności – umarza się.

***
## Art. 1071. {#kpc-trzecia--art-1071}

Przepisy niniejszego działu stosuje się odpowiednio do 
zarządzonej przez sąd w toku postępowania o dział spadku sprzedaży gospodarstwa 
rolnego albo wkładu gruntowego w rolniczej spółdzielni produkcyjnej wraz 
z działką przyzagrodową i siedliskową. 
#### DZIAŁ IV
(zawierający art. 1072–1080 – uchylony) 
#### DZIAŁ V
Egzekucja świadczeń alimentacyjnych

***
## Art. 1081. {#kpc-trzecia--art-1081}

**§ 1.** Jeżeli egzekucja dotyczy alimentów lub renty mającej 
charakter alimentów, wniosek o wszczęcie egzekucji można zgłosić również do 
komornika sądu właściwego ze względu na miejsce zamieszkania wierzyciela. 
**§ 2.** Komornik ten jest obowiązany zawiadomić o wszczęciu egzekucji 
komornika sądu ogólnej właściwości dłużnika. Komornik zawiadomiony zażąda 
przekazania mu sprawy wraz ze ściągniętymi kwotami, jeżeli wskutek dalszych 
zajęć suma uzyskana ze wszystkich egzekucji nie wystarcza na zaspokojenie 
wszystkich wierzycieli. Jeżeli dokonane zostało zajęcie wynagrodzenia za pracę lub 
wierzytelności, równocześnie z przekazaniem sprawy komornik zawiadamia 
pracodawcę, dłużnika, względnie wierzyciela zajętej wierzytelności, że dalszych 
wpłat należy dokonywać komornikowi, któremu sprawę przekazano. 
**§ 3.** Jeżeli dłużnik odbywa karę pozbawienia wolności, wierzyciel może 
złożyć tytuł wykonawczy bezpośrednio dyrektorowi zakładu karnego, który 

 
 
 
s. 517/580 
 
2025-09-08 
 
obowiązany jest wypłacać wierzycielowi należności za pracę dłużnika lub jego 
pieniądze znajdujące się w depozycie zakładu karnego, w granicach określonych 
w art. 125 Kodeksu karnego wykonawczego. 
**§ 4.** Przewidziana w § 3 wypłata nie może być dokonywana, jeżeli wnioski 
złożyło kilku wierzycieli, a należności za pracę dłużnika lub jego pieniądze 
znajdujące się w depozycie zakładu karnego nie wystarczają na zaspokojenie 
wszystkich należności tych wierzycieli lub jeżeli są zajęte przez organ egzekucyjny. 
W takim wypadku dyrektor zakładu karnego przekazuje wnioski do właściwego 
komornika.

***
## Art. 1082. {#kpc-trzecia--art-1082}

Tytułowi egzekucyjnemu, zasądzającemu alimenty, sąd nadaje 
klauzulę wykonalności z urzędu. Tytuł wykonawczy doręcza się wówczas 
wierzycielowi z urzędu.

***
## Art. 1083. {#kpc-trzecia--art-1083}

**§ 1.** Dochody 
wymienione 
w art. 831 § 1 
pkt 2 podlegają 
egzekucji na zaspokojenie alimentów do trzech piątych części. 
**§ 2.** Wierzytelności 
z rachunku 
bankowego 
podlegają 
egzekucji 
na 
zaspokojenie alimentów w pełnej wysokości. 
**§ 3.** (uchylony) 
**§ 4.** Dłużnik może żądać zawieszenia postępowania egzekucyjnego co do 
świadczeń alimentacyjnych wymagalnych w przyszłości, jeżeli uiści wszystkie 
świadczenia wymagalne i złoży na rachunek depozytowy Ministra Finansów sumę 
równą sumie świadczeń alimentacyjnych za sześć miesięcy, z równoczesnym 
umocowaniem komornika do podejmowania tej sumy. Komornik skorzysta z tego 
umocowania, gdy stwierdzi, że dłużnik popadł w zwłokę z uiszczeniem świadczeń 
wymagalnych, równocześnie z urzędu podejmując postępowanie. 
**§ 5.** Zawieszenie postępowania egzekucyjnego w przypadku, o którym mowa 
w § 4, nie wyłącza możliwości podejmowania przez komornika czynności 
mających na celu wykonanie w przyszłości tytułu wykonawczego, w tym zajęcia 
majątku dłużnika. Sąd na wniosek dłużnika może, po wysłuchaniu stron, uchylić 
dokonane zajęcia. Na postanowienie sądu przysługuje zażalenie.

***
## Art. 1084. {#kpc-trzecia--art-1084}

(uchylony) 

 
 
 
s. 518/580 
 
2025-09-08

***
## Art. 1085. {#kpc-trzecia--art-1085}

W sprawach, w których zasądzono alimenty, egzekucja może być 
wszczęta z urzędu na żądanie sądu pierwszej instancji, który sprawę rozpoznawał. 
Żądanie takie kieruje się do właściwego organu egzekucyjnego.

***
## Art. 1086. {#kpc-trzecia--art-1086}

**§ 1.** Komornik 
obowiązany 
jest 
z urzędu 
przeprowadzić 
dochodzenie w celu ustalenia zarobków i stanu majątkowego dłużnika oraz jego 
miejsca zamieszkania. Jeżeli środki te okażą się bezskuteczne, organy Policji 
przeprowadzą na wniosek komornika czynności w celu ustalenia miejsca 
zamieszkania i miejsca pracy dłużnika. 
**§ 2.** Dochodzenie, o którym mowa w § 1, powinno być przeprowadzone 
okresowo w odstępach nie dłuższych niż 6 miesięcy. 
**§ 3.** (uchylony) 
**§ 4.** (uchylony) 
**§ 5.** Bezskuteczność 
egzekucji 
nie 
stanowi 
podstawy 
umorzenia 
postępowania. Jeżeli wierzyciel w terminie roku od daty wezwania nie dokonał 
czynności potrzebnej do dalszego prowadzenia postępowania albo w terminie 3 lat 
od dnia zawieszenia postępowania nie zażądał jego podjęcia, postępowanie umarza 
się w całości lub w części z urzędu.

***
## Art. 1087. {#kpc-trzecia--art-1087}

Jeżeli dłużnik zatrudniony jest u osoby bliskiej, osoba ta w razie 
zajęcia wynagrodzenia za pracę w poszukiwaniu świadczeń alimentacyjnych nie 
może zasłaniać się zarzutem, że wypłaciła dłużnikowi wynagrodzenie z góry, ani 
zarzutami, że dłużnik pracuje bez wynagrodzenia lub za wynagrodzeniem niższym 
od przeciętnego, albo że przysługuje jej wierzytelność do dłużnika nadająca się do 
potrącenia z jego roszczenia o wynagrodzenie.

***
## Art. 1088. {#kpc-trzecia--art-1088}

Do egzekucji świadczeń alimentacyjnych stosuje się również 
przepisy tytułu drugiego. 
#### DZIAŁ VI
(zawierający art. 1089–10951 – uchylony)

