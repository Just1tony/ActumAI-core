---
id: code.kpc.czesc.czwarta.ksiega.pierwsza
title: "Kodeks postępowania cywilnego — CZĘŚĆ CZWARTA — KSIĘGA PIERWSZA (IMMUNITET SĄDOWY I EGZEKUCYJNY)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1964 Nr 43 poz. 296"
consolidated_citation: "t.j. Dz.U. 2024 poz. 1568, 1841; Dz.U. 2025 poz. 620, 1172"
status: "obowiązujący"
last_consolidated: "2025-09-08"
aliases: ["KPC — CZĘŚĆ CZWARTA — Księga PIERWSZA"]
tags: ["KPC","Kodeks postępowania cywilnego","CZĘŚĆ CZWARTA","Księga PIERWSZA","PL"]
source_pdf: "D19640296Lj.pdf"
articles: "Art. 1111–1116"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpc-czwarta-pierwsza-art-{n}}"
  separators: "***"
  hierarchy: ["CZĘŚĆ","KSIĘGA","TYTUŁ","DZIAŁ","Rozdział"]
---

# Kodeks postępowania cywilnego — CZĘŚĆ CZWARTA — KSIĘGA PIERWSZA: IMMUNITET SĄDOWY I EGZEKUCYJNY

## KSIĘGA PIERWSZA a 
IMMUNITET SĄDOWY I EGZEKUCYJNY
***
## Art. 1111. {#kpc-czwarta-pierwsza-art-1111}

**§ 1.** Nie mogą być pozywane przed sądy polskie następujące 
osoby: 
- 1) uwierzytelnieni w Rzeczypospolitej Polskiej szefowie przedstawicielstw 
dyplomatycznych państw obcych; 
- 2) członkowie personelu dyplomatycznego przedstawicielstw państw obcych 
w Rzeczypospolitej Polskiej; 
- 3) inne osoby korzystające z immunitetów dyplomatycznych na mocy ustaw, 
umów lub powszechnie ustalonych zwyczajów międzynarodowych; 
- 4) członkowie rodzin osób wymienionych w pkt 1–3, jeżeli pozostają z nimi we 
wspólnocie domowej i nie mają obywatelstwa polskiego. 
**§ 2.** Przepisy § 1 nie mają zastosowania do osób w nim wymienionych 
w odniesieniu do: 
- 1) spraw z zakresu prawa rzeczowego dotyczących prywatnego mienia 
nieruchomego położonego w Rzeczypospolitej Polskiej, chyba że mienie to 
jest w posiadaniu tych osób w imieniu państwa wysyłającego dla celów 
przedstawicielstwa 
dyplomatycznego 
lub 
odpowiedniej 
organizacji 
międzynarodowej dla celów organizacji; 
- 2) spraw dotyczących spadków, w których osoby te występują jako 
spadkobiercy, zapisobiercy, wykonawcy testamentów, zarządcy lub kuratorzy 
spadku w charakterze osób prywatnych, nie zaś w imieniu państwa 
wysyłającego lub odpowiedniej organizacji międzynarodowej; 
- 3) spraw dotyczących zawodowej lub gospodarczej działalności tych osób, 
wykonywanej przez nie w Rzeczypospolitej Polskiej poza funkcjami 
urzędowymi.

***
## Art. 1112. {#kpc-czwarta-pierwsza-art-1112}

**§ 1.** Nie mogą być pozywane przed sądy polskie w sprawach 
wchodzących w zakres czynności dokonanych w toku pełnienia ich funkcji 
urzędowych następujące osoby: 
- 1) urzędnicy pełniący funkcje konsularne w imieniu państw obcych niezależnie 
od posiadanego obywatelstwa; 

 
 
 
s. 532/580 
 
2025-09-08 
- 2) cudzoziemcy będący pracownikami administracyjnymi i technicznymi 
przedstawicielstw dyplomatycznych i urzędów konsularnych państw obcych 
w Rzeczypospolitej 
Polskiej 
lub 
członkami 
personelu 
służby 
przedstawicielstw dyplomatycznych oraz inne osoby zrównane z nimi na 
mocy ustaw, umów lub powszechnie ustalonych zwyczajów między-
narodowych. 
**§ 2.** Przepis § 1 nie ma zastosowania w stosunku do urzędników pełniących 
funkcje konsularne oraz pracowników administracyjnych i technicznych urzędów 
konsularnych w przypadku wytoczenia przeciwko tym osobom powództw: 
- 1) wynikłych z zawarcia przez nie umowy, w której nie występowały wyraźnie 
lub w sposób dorozumiany jako przedstawiciele państwa wysyłającego; 
- 2) o wynagrodzenie szkody powstałej w wyniku wypadku spowodowanego 
w Rzeczypospolitej Polskiej przez pojazd, statek morski, statek żeglugi 
śródlądowej lub statek powietrzny.

***
## Art. 1113. {#kpc-czwarta-pierwsza-art-1113}

Immunitet sądowy sąd bierze pod rozwagę z urzędu w każdym 
stanie sprawy. W razie stwierdzenia istnienia immunitetu sąd odrzuca pozew albo 
wniosek. Rozpoznanie sprawy z naruszeniem immunitetu sądowego powoduje nie-
ważność postępowania. Jeżeli osoba, przeciwko której albo z udziałem której 
wszczęto sprawę, uzyska immunitet sądowy w toku postępowania, sąd umarza 
postępowanie.

***
## Art. 11131. {#kpc-czwarta-pierwsza-art-11131}

**§ 1.** Osoby wymienione w art. 1111 § 1, jak również osoby 
wymienione w art. 1112 § 1 pkt 2, z wyjątkiem pracowników administracyjnych 
i technicznych urzędów konsularnych państw obcych w Rzeczypospolitej Polskiej, 
nie mają obowiązku składania zeznań w charakterze świadków lub występowania 
w charakterze biegłego lub tłumacza, jak również obowiązku przedstawienia 
dokumentu lub przedmiotu oględzin, chyba że uprawniona do tego osoba wyrazi 
zgodę. 
**§ 2.** Urzędnicy pełniący funkcje konsularne, pracownicy administracyjni 
i techniczni urzędów konsularnych państw obcych w Rzeczypospolitej Polskiej, 
o których mowa w art. 1112 § 1, jak również członkowie personelu służby tych 
urzędów będący cudzoziemcami, nie mają obowiązku – co do faktów związanych 
z wykonywaniem ich funkcji – składania zeznań w charakterze świadków lub 

 
 
 
s. 533/580 
 
2025-09-08 
 
występowania w charakterze biegłych co do treści prawa państwa wysyłającego, 
jak również obowiązku przedstawienia dokumentu lub przedmiotu oględzin, chyba 
że uprawniona do tego osoba wyrazi zgodę. 
**§ 3.** W razie wyrażenia zgody, o której mowa w § 1 lub 2, nie można stosować 
środków przymusu, ani grozić ich zastosowaniem.

***
## Art. 1114. {#kpc-czwarta-pierwsza-art-1114}

**§ 1.** Przepisy art. 1111 § 1 i art. 1112 § 1 nie mają zastosowania 
w przypadku, jeżeli państwo wysyłające w sposób wyraźny zrzeknie się 
immunitetu sądowego w stosunku do osób wymienionych w tych przepisach. 
**§ 2.** W stosunku 
do 
urzędników 
międzynarodowych, 
korzystających 
z immunitetu sądowego, zrzeczenie się immunitetu przewidziane w § 1 musi być 
dokonane przez odpowiednią organizację międzynarodową. 
**§ 3.** Niezależnie 
od 
postanowień 
§ 1 
i 2 osobom 
wymienionym 
w art. 1111 § 1 i art. 1112 § 1 nie przysługuje immunitet sądowy w sprawach: 
- 1) w których osoby te wszczynają postępowanie przed sądem polskim; 
- 2) z powództw wzajemnych przeciwko tym osobom; 
- 3) z powództw przeciwegzekucyjnych wytoczonych przeciwko nim.

***
## Art. 1115. {#kpc-czwarta-pierwsza-art-1115}

**§ 1.** Przeciwko osobom, które na podstawie art. 1111 § 1 
i art. 1112 § 1 korzystają z immunitetu sądowego w zakresie przewidzianym 
w tych przepisach, nie może być także prowadzona egzekucja, chyba że chodzi 
o sprawę, w której osobom tym nie przysługuje immunitet sądowy. 
**§ 2.** Przeciwko osobom określonym w § 1, w stosunku do których państwo 
wysyłające lub odpowiednia organizacja międzynarodowa zrzekły się immunitetu 
sądowego, może być prowadzona egzekucja jedynie w przypadku wyraźnego 
zrzeczenia się immunitetu przez państwo wysyłające lub odpowiednią organizację 
międzynarodową także w odniesieniu do postępowania egzekucyjnego. 
**§ 3.** Jeżeli prowadzenie egzekucji jest dozwolone, niedopuszczalna jest 
egzekucja z mienia służącego do użytku urzędowego oraz przez stosowanie 
przymusu wobec osoby dłużnika. 
**§ 4.** Egzekucja jest niedopuszczalna w pomieszczeniach zajmowanych przez 
przedstawicielstwa dyplomatyczne, misje zagraniczne lub urzędy konsularne 
państw obcych w Rzeczypospolitej Polskiej oraz w mieszkaniach osób 

 
 
 
s. 534/580 
 
2025-09-08 
 
wymienionych 
w art. 1111 § 1, 
chyba 
że 
szef 
przedstawicielstwa 
dyplomatycznego, misji zagranicznej lub urzędu konsularnego wyrazi na to zgodę.

***
## Art. 11151. {#kpc-czwarta-pierwsza-art-11151}

Przepisy 
art. 1111–1115 stosuje 
się 
odpowiednio 
w postępowaniu zabezpieczającym.

***
## Art. 1116. {#kpc-czwarta-pierwsza-art-1116}

(uchylony)

