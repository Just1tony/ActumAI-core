---
id: code.kpc.czesc.pierwsza.ksiega.druga
title: "Kodeks postępowania cywilnego — CZĘŚĆ PIERWSZA — KSIĘGA DRUGA (POSTĘPOWANIE NIEPROCESOWE)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1964 Nr 43 poz. 296"
consolidated_citation: "t.j. Dz.U. 2024 poz. 1568, 1841; Dz.U. 2025 poz. 620, 1172"
status: "obowiązujący"
last_consolidated: "2025-09-08"
aliases: ["KPC — CZĘŚĆ PIERWSZA — Księga DRUGA"]
tags: ["KPC","Kodeks postępowania cywilnego","CZĘŚĆ PIERWSZA","Księga DRUGA","PL"]
source_pdf: "D19640296Lj.pdf"
articles: "Art. 506–6948"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpc-pierwsza-druga-art-{n}}"
  separators: "***"
  hierarchy: ["CZĘŚĆ","KSIĘGA","TYTUŁ","DZIAŁ","Rozdział"]
---

# Kodeks postępowania cywilnego — CZĘŚĆ PIERWSZA — KSIĘGA DRUGA: POSTĘPOWANIE NIEPROCESOWE

POSTĘPOWANIE NIEPROCESOWE 
### TYTUŁ I
Przepisy ogólne
***
## Art. 506. {#kpc-pierwsza-druga-art-506}

Sąd 
wszczyna 
postępowanie 
nieprocesowe 
na 
wniosek; 
w wypadkach wskazanych w ustawie sąd może wszcząć postępowanie także 
z urzędu.

***
## Art. 507. {#kpc-pierwsza-druga-art-507}

Sprawy należące do postępowania nieprocesowego rozpoznają sądy 
rejonowe, z wyjątkiem spraw, dla których zastrzeżona jest właściwość sądów 
okręgowych.

***
## Art. 508. {#kpc-pierwsza-druga-art-508}

**§ 1.** Jeżeli właściwość miejscowa nie jest oznaczona w przepisie 
szczególnym, wyłącznie właściwy jest sąd miejsca zamieszkania wnioskodawcy, 
a w braku miejsca zamieszkania – sąd miejsca jego pobytu. Do postępowania 
z urzędu właściwy jest sąd miejsca, w którego okręgu nastąpiło zdarzenie będące 
podstawą wszczęcia postępowania. W braku wskazanych wyżej podstaw właściwy 
będzie sąd dla m.st. Warszawy. 
**§ 2.** W wypadku gdy sąd właściwy nie może z powodu przeszkody rozpoznać 
sprawy lub podjąć innej czynności albo gdy wymagają tego względy celowości, sąd 
nad nim przełożony wyznaczy na posiedzeniu niejawnym inny sąd do rozpoznania 
sprawy w całości lub w części. 
**§ 3.** Wyznaczenie następuje z urzędu albo na przedstawienie sądu 
właściwego, albo też na wniosek właściwego organu lub osoby zainteresowanej, po 
wysłuchaniu w razie potrzeby innych osób zainteresowanych. 
**§ 4.** Przepisu 
art. 481 nie 
stosuje 
się 
w sprawach 
rozpoznawanych 
w postępowaniu wieczystoksięgowym i postępowaniu rejestrowym, a także 

 
 
 
s. 236/580 
 
2025-09-08 
 
w sprawach z zakresu prawa spadkowego, z wyjątkiem spraw o stwierdzenie 
nabycia spadku i przedmiotu zapisu windykacyjnego oraz o dział spadku.

***
## Art. 509. {#kpc-pierwsza-druga-art-509}

Sprawy o przysposobienie w pierwszej instancji sąd rozpoznaje 
w składzie jednego sędziego i dwóch ławników.

***
## Art. 5091. {#kpc-pierwsza-druga-art-5091}

**§ 1.** Czynności w postępowaniu wieczystoksięgowym może 
wykonywać referendarz sądowy. 
**§ 2.** Czynności 
w postępowaniach 
dotyczących 
rejestrów 
i ewidencji 
prowadzonych przez sądy może wykonywać referendarz sądowy, z wyjątkiem 
przygotowania i prowadzenia rozprawy, odmowy wpisu partii politycznej do 
ewidencji, wykreślenia wpisu partii politycznej z ewidencji oraz zawieszenia 
wydawania dziennika lub czasopisma. 
**§ 3.** Czynności w sprawach z zakresu prawa spadkowego może wykonywać 
referendarz sądowy, z wyłączeniem prowadzenia rozprawy, zabezpieczenia spadku 
oraz przesłuchania świadków testamentu ustnego. 
**§ 4.** Czynności w sprawach depozytowych może wykonywać referendarz 
sądowy, z wyłączeniem spraw o stwierdzenie likwidacji niepodjętego depozytu. 
**§ 5.** Przepisu art. 39822 § 4 nie stosuje się do orzeczeń co do istoty sprawy 
wydawanych przez referendarza sądowego.

***
## Art. 510. {#kpc-pierwsza-druga-art-510}

**§ 1.** Zainteresowanym w sprawie jest każdy, czyich praw dotyczy 
wynik postępowania, może on wziąć udział w każdym stanie sprawy aż do 
zakończenia postępowania w drugiej instancji. Jeżeli weźmie udział, staje się 
uczestnikiem. Na odmowę dopuszczenia do wzięcia udziału w sprawie przysługuje 
zażalenie. 
**§ 2.** Jeżeli okaże się, że zainteresowany nie jest uczestnikiem, sąd wezwie go 
do udziału w sprawie. Przez wezwanie do wzięcia udziału w sprawie wezwany staje 
się uczestnikiem. W razie potrzeby wyznaczenia kuratora do zastępowania 
zainteresowanego, którego miejsce pobytu jest nieznane, jego wyznaczenie 
następuje z urzędu.

***
## Art. 511. {#kpc-pierwsza-druga-art-511}

**§ 1.** Wniosek o wszczęcie postępowania powinien czynić zadość 
przepisom o pozwie, z tą zmianą, że zamiast pozwanego należy wymienić 
zainteresowanych w sprawie. 

 
 
 
s. 237/580 
 
2025-09-08 
**§ 2.** Do wniosków prokuratora o wszczęcie postępowania nie stosuje się 
przepisów art. 55 i 56.

***
## Art. 5111. {#kpc-pierwsza-druga-art-5111}

**§ 1.** W postępowaniu 
wieczystoksięgowym 
oraz 
w postępowaniach rejestrowych wniosek podlegający opłacie stałej, który nie 
został należycie opłacony, przewodniczący zwraca bez wezwania o uiszczenie tej 
opłaty. W zarządzeniu o zwrocie pisma należy wskazać wysokość należnej opłaty 
stałej. 
**§ 2.** W terminie tygodniowym od dnia doręczenia zarządzenia o zwrocie 
pisma z przyczyn określonych w § 1 wnioskodawca może uiścić brakującą opłatę. 
Jeżeli opłata została wniesiona we właściwej wysokości, wniosek wywołuje skutek 
od daty pierwotnego wniesienia. Skutek taki nie następuje w razie kolejnego 
zwrotu wniosku z tej samej przyczyny.

***
## Art. 5111a. {#kpc-pierwsza-druga-art-5111a}

Przepis art. 1391 stosuje się, jeżeli w razie nieodebrania przesyłki 
przez uczestnika postępowania przewodniczący uzna doręczenie pisma za 
pośrednictwem komornika za konieczne. 
<Art. 5111b. Przepisu art. 1251 § 1 nie stosuje się do pism procesowych 
wnoszonych w postępowaniu wieczystoksięgowym oraz postępowaniach 
rejestrowych.>

***
## Art. 5112. {#kpc-pierwsza-druga-art-5112}

**§ 1.** Wniesienie odpowiedzi na wniosek o wszczęcie postępowania 
jest obowiązkowe, tylko gdy przewodniczący tak zarządzi. 
**§ 2.** Posiedzenie przygotowawcze można wyznaczyć niezależnie od 
wniesienia odpowiedzi na wniosek.

***
## Art. 512. {#kpc-pierwsza-druga-art-512}

**§ 1.** Po rozpoczęciu 
posiedzenia albo po złożeniu 
przez 
któregokolwiek z uczestników oświadczenia na piśmie cofnięcie wniosku jest 
skuteczne tylko wtedy, gdy inni uczestnicy nie sprzeciwili się temu w terminie 
wyznaczonym. 
**§ 2.** Cofnięcie wniosku o wszczęcie postępowania jest bezskuteczne 
w sprawie, której wszczęcie mogło nastąpić z urzędu.

***
## Art. 513. {#kpc-pierwsza-druga-art-513}

Niestawiennictwo uczestników nie tamuje rozpoznania sprawy. 
Przepisów o wyroku zaocznym nie stosuje się. 
Dodany art. 5111b 
wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 

 
 
 
s. 238/580 
 
2025-09-08

***
## Art. 514. {#kpc-pierwsza-druga-art-514}

**§ 1.** Rozprawa odbywa się w wypadkach wskazanych w ustawie. 
W innych wypadkach wyznaczenie rozprawy zależy od uznania sądu. Mimo 
niewyznaczenia rozprawy sąd przed rozstrzygnięciem sprawy może wysłuchać 
uczestników na posiedzeniu sądowym lub zażądać od nich oświadczeń na piśmie. 
**§ 2.** Jednakże nawet w wypadkach, gdy ustawa wymaga przeprowadzenia 
rozprawy, sąd może, bez wzywania zainteresowanych do udziału w sprawie, 
oddalić wniosek na posiedzeniu niejawnym, jeżeli z treści wniosku wynika 
oczywisty brak uprawnienia wnioskodawcy.

***
## Art. 515. {#kpc-pierwsza-druga-art-515}

Sąd może, stosownie do okoliczności, przesłuchać świadków 
i biegłych bez przyrzeczenia oraz w nieobecności uczestników, może również 
zażądać od osób, które nie są uczestnikami, złożenia wyjaśnień na piśmie.

***
## Art. 516. {#kpc-pierwsza-druga-art-516}

Orzeczenia 
sądu 
w postępowaniu 
nieprocesowym 
zapadają 
w formie postanowień, chyba że przepis szczególny stanowi inaczej.

***
## Art. 517. {#kpc-pierwsza-druga-art-517}

(uchylony)

***
## Art. 518. {#kpc-pierwsza-druga-art-518}

Od postanowień sądu pierwszej instancji orzekających co do istoty 
sprawy przysługuje apelacja. Na inne postanowienia sądu pierwszej instancji, 
w wypadkach wskazanych w ustawie, przysługuje zażalenie.

***
## Art. 5181. {#kpc-pierwsza-druga-art-5181}

**§ 1.** (uchylony) 
**§ 11.** Na 
orzeczenie 
referendarza 
sądowego 
służy 
skarga 
także 
w przypadkach, w których na postanowienie sądu służyłaby apelacja. 
**§ 2.** (uchylony) 
**§ 3.** W razie wniesienia skargi na wpis w księdze wieczystej wpis nie traci 
mocy. Rozpoznając sprawę, sąd zmienia zaskarżony wpis przez jego wykreślenie 
i dokonanie nowego wpisu lub wydaje postanowienie, którym zaskarżony wpis 
utrzymuje w mocy albo uchyla go w całości lub w części i w tym zakresie wniosek 
oddala bądź odrzuca, względnie postępowanie umarza. 
**§ 31.** W postępowaniu rejestrowym o wpis do Krajowego Rejestru Sądowego 
oraz rejestru zastawów w razie wniesienia skargi na orzeczenie referendarza 
sądowego zarządzające wpis, pozostaje ono w mocy do chwili rozpatrzenia skargi 
przez sąd rejonowy rozpoznający sprawę jako sąd pierwszej instancji. Rozpoznając 
sprawę, sąd wydaje postanowienie, w którym zaskarżone orzeczenie i dokonany na 
jego podstawie wpis zmienia albo utrzymuje w mocy, albo uchyla w całości lub 

 
 
 
s. 239/580 
 
2025-09-08 
 
w części i w tym zakresie wniosek oddala bądź odrzuca, względnie postępowanie 
umarza. 
**§ 32.** O ile przepis szczególny nie stanowi inaczej, orzeczenie co do istoty 
sprawy wydawane przez referendarza sądowego doręcza się wraz z uzasadnieniem. 
Uzasadnienie może ograniczać się do wyjaśnienia podstawy prawnej rozstrzyg-
nięcia wraz z przytoczeniem przepisów prawa. 
**§ 4.** Skargę wnosi się do sądu w terminie tygodniowym: 
- 1) od dnia czynności, gdy uczestnik był przy niej obecny lub był o jej terminie 
zawiadomiony; 
- 2) w innych przypadkach niż wymienione w pkt 1 – od dnia doręczenia 
zawiadomienia uczestnika o dokonaniu czynności lub postanowienia 
oddalającego wniosek o dokonanie czynności; 
- 3) w przypadku braku zawiadomienia – od dnia dowiedzenia się o dokonaniu 
czynności, z tym że w postępowaniu o wpis do Krajowego Rejestru 
Sądowego dla uczestników postępowania, którym postanowienia co do istoty 
sprawy nie doręcza się, termin do wniesienia skargi biegnie od daty wpisu 
w Rejestrze. 
**§ 5.** (uchylony) 
**§ 6.** (uchylony)

***
## Art. 5182. {#kpc-pierwsza-druga-art-5182}

**§ 1.** Sądem drugiej instancji w sprawach o odebranie osoby 
podlegającej władzy rodzicielskiej lub pozostającej pod opieką prowadzonych na 
podstawie konwencji haskiej z 1980 r. oraz rozpoznawanych łącznie z nimi spraw 
określonych w art. 5691 § 11 jest Sąd Apelacyjny w Warszawie. 
**§ 2.** Sąd Apelacyjny w Warszawie orzeka w sprawach określonych w § 1 
w terminie sześciu tygodni od dnia przedstawienia przez sąd pierwszej instancji akt 
sprawy wraz z apelacją.

***
## Art. 519. {#kpc-pierwsza-druga-art-519}

(uchylony)

***
## Art. 5191. {#kpc-pierwsza-druga-art-5191}

**§ 1.** Od wydanego przez sąd drugiej instancji postanowienia co do 
istoty sprawy oraz od postanowienia w przedmiocie odrzucenia wniosku 
i umorzenia postępowania kończących postępowanie w sprawie – w sprawach 
z zakresu prawa osobowego, rzeczowego i spadkowego – przysługuje skarga 
kasacyjna do Sądu Najwyższego, chyba że przepis szczególny stanowi inaczej. 

 
 
 
s. 240/580 
 
2025-09-08 
**§ 2.** W sprawach z zakresu prawa rodzinnego, opiekuńczego i kurateli skarga 
kasacyjna przysługuje tylko w sprawach o przysposobienie oraz o podział majątku 
wspólnego po ustaniu wspólności majątkowej między małżonkami, chyba że 
wartość przedmiotu zaskarżenia jest niższa niż sto pięćdziesiąt tysięcy złotych. 
**§ 21.** Skarga kasacyjna przysługuje także w sprawach o odebranie osoby 
podlegającej władzy rodzicielskiej lub pozostającej pod opieką prowadzonych na 
podstawie konwencji haskiej z 1980 r. 
**§ 22.** Skargę kasacyjną w sprawach, o których mowa w § 21, mogą wnieść 
Prokurator Generalny, Rzecznik Praw Dziecka lub Rzecznik Praw Obywatelskich 
w terminie czterech miesięcy od dnia uprawomocnienia się postanowienia. 
**§ 3.** W postępowaniu rejestrowym skarga kasacyjna przysługuje jedynie od 
postanowień sądu drugiej instancji w przedmiocie wpisu lub wykreślenia z rejestru 
podmiotu podlegającego rejestracji. 
**§ 4.** Skarga kasacyjna nie przysługuje w sprawach dotyczących: 
- 1) przepadku rzeczy; 
- 2) zarządu związanego ze współwłasnością lub użytkowaniem; 
- 3) zabezpieczenia spadku i spisu inwentarza, wyjawienia przedmiotów 
spadkowych, zarządu spadku nieobjętego oraz zwolnienia wykonawcy 
testamentu; 
- 4) zniesienia współwłasności i działu spadku, jeżeli wartość przedmiotu 
zaskarżenia jest niższa niż sto pięćdziesiąt tysięcy złotych; 
- 5) likwidacji niepodjętych depozytów.

***
## Art. 5192. {#kpc-pierwsza-druga-art-5192}

**§ 1.** Można 
żądać 
stwierdzenia 
niezgodności 
z prawem 
prawomocnego postanowienia co do istoty sprawy sądu drugiej instancji 
kończącego postępowanie w sprawie, jeżeli przez jego wydanie stronie została 
wyrządzona szkoda, a zmiana lub uchylenie tego postanowienia w drodze 
przysługujących stronie środków prawnych nie było i nie jest możliwe. 
**§ 2.** W wyjątkowych wypadkach, gdy niezgodność z prawem wynika 
z naruszenia podstawowych zasad porządku prawnego lub konstytucyjnych 
wolności albo praw człowieka i obywatela, można także żądać stwierdzenia 
niezgodności z prawem prawomocnego postanowienia co do istoty sprawy sądu 
pierwszej lub drugiej instancji kończącego postępowanie w sprawie, jeżeli strona 
nie skorzystała z przysługujących jej środków prawnych, chyba że jest możliwa 

 
 
 
s. 241/580 
 
2025-09-08 
 
zmiana lub uchylenie postanowienia w drodze innych przysługujących stronie 
środków prawnych.

***
## Art. 520. {#kpc-pierwsza-druga-art-520}

**§ 1.** Każdy uczestnik ponosi koszty postępowania związane ze 
swym udziałem w sprawie. 
**§ 2.** Jeżeli jednak uczestnicy są w różnym stopniu zainteresowani w wyniku 
postępowania lub interesy ich są sprzeczne, sąd może stosunkowo rozdzielić 
obowiązek zwrotu kosztów lub włożyć go na jednego z uczestników w całości. To 
samo dotyczy zwrotu kosztów postępowania wyłożonych przez uczestników. 
**§ 3.** Jeżeli interesy uczestników są sprzeczne, sąd może włożyć na uczestnika, 
którego wnioski zostały oddalone lub odrzucone, obowiązek zwrotu kosztów 
postępowania poniesionych przez innego uczestnika. Przepis powyższy stosuje się 
odpowiednio, jeżeli uczestnik postępował niesumiennie lub oczywiście 
niewłaściwie.

***
## Art. 521. {#kpc-pierwsza-druga-art-521}

**§ 1.** Jeżeli przepis szczególny inaczej nie stanowi, postanowienie 
orzekające co do istoty sprawy staje się skuteczne, a jeżeli wymaga wykonania – 
także wykonalne, po uprawomocnieniu się. 
**§ 2.** Jeżeli postanowienie takie ulega z mocy ustawy wykonaniu przed 
uprawomocnieniem się, sąd, który wydał postanowienie, może stosownie do 
okoliczności wstrzymać jego wykonanie.

***
## Art. 522. {#kpc-pierwsza-druga-art-522}

Postanowienia wydane w sprawie, która może być wszczęta 
z urzędu, podlegają wykonaniu z urzędu.

***
## Art. 523. {#kpc-pierwsza-druga-art-523}

Prawomocne postanowienie orzekające co do istoty sprawy nie 
może być zmienione ani uchylone, chyba że przepis szczególny stanowi inaczej. 
Jednakże prawomocne postanowienie oddalające wniosek sąd może zmienić 
w razie zmiany okoliczności sprawy.

***
## Art. 524. {#kpc-pierwsza-druga-art-524}

**§ 1.** Uczestnik postępowania może żądać wznowienia postępowania 
zakończonego prawomocnym postanowieniem orzekającym co do istoty sprawy, 
jednakże wznowienie postępowania nie jest dopuszczalne, jeżeli postanowienie 
kończące postępowanie może być zmienione lub uchylone. 
**§ 2.** Zainteresowany, który nie był uczestnikiem postępowania zakończonego 
prawomocnym postanowieniem orzekającym co do istoty sprawy, może żądać 
wznowienia postępowania, jeżeli postanowienie to narusza jego prawa. W takim 

 
 
 
s. 242/580 
 
2025-09-08 
 
wypadku stosuje się przepisy o wznowieniu postępowania z powodu pozbawienia 
możności działania.

***
## Art. 525. {#kpc-pierwsza-druga-art-525}

Akta sprawy dostępne są dla uczestników postępowania oraz za 
zezwoleniem przewodniczącego dla każdego, kto potrzebę przejrzenia dostatecznie 
usprawiedliwi. Na tych samych zasadach dopuszczalne jest: 
- 1) sporządzanie i otrzymywanie odpisów i wyciągów z akt sprawy; 
- 2) otrzymywanie zapisu dźwięku albo obrazu i dźwięku z akt sprawy. 
### TYTUŁ II
Przepisy dla poszczególnych rodzajów spraw 
#### DZIAŁ I
Sprawy z zakresu prawa osobowego 
Rozdział 1 
Uznanie za zmarłego i stwierdzenie zgonu 
Oddział 1 
Postępowanie o uznanie za zmarłego

***
## Art. 526. {#kpc-pierwsza-druga-art-526}

**§ 1.** W sprawach o uznanie za zmarłego właściwy jest sąd 
ostatniego miejsca zamieszkania zaginionego, a w braku tej podstawy – sąd 
wskazany w art. 508 § 1. 
**§ 2.** Jeżeli wskutek tego samego zdarzenia zaginęła większa liczba osób, Sąd 
Najwyższy na wniosek Ministra Sprawiedliwości może wyznaczyć jeden sąd jako 
wyłącznie właściwy do rozpoznania spraw będących w związku z tym zdarzeniem. 
Postanowienie Sądu Najwyższego podlega ogłoszeniu w Dzienniku Urzędowym 
Rzeczypospolitej Polskiej „Monitor Polski”.

***
## Art. 527. {#kpc-pierwsza-druga-art-527}

Do zgłoszenia wniosku o uznanie za zmarłego uprawniony jest 
każdy zainteresowany.

***
## Art. 528. {#kpc-pierwsza-druga-art-528}

Wniosek o uznanie za zmarłego można zgłosić nie wcześniej niż na 
rok przed końcem terminu, po upływie którego zaginiony może być uznany za 
zmarłego. Gdy jednak uznanie za zmarłego może nastąpić po upływie roku lub 
krótszego niż rok terminu od zdarzenia, które uzasadnia prawdopodobieństwo 

 
 
 
s. 243/580 
 
2025-09-08 
 
śmierci zaginionego, wniosek o uznanie za zmarłego zgłosić można dopiero po 
upływie tego terminu.

***
## Art. 529. {#kpc-pierwsza-druga-art-529}

**§ 1.** Wniosek o uznanie za zmarłego, oprócz danych koniecznych 
dla wniosku o wszczęcie postępowania, powinien zawierać: 
- 1) imię, nazwisko i wiek zaginionego, imiona jego rodziców oraz nazwisko 
rodowe matki; 
- 2) ostatnie znane miejsce zamieszkania i pobytu zaginionego. 
**§ 2.** Okoliczności uzasadniające wniosek należy uprawdopodobnić.

***
## Art. 530. {#kpc-pierwsza-druga-art-530}

**§ 1.** Jeżeli według treści wniosku istnieją przesłanki do uznania 
zaginionego za zmarłego, sąd zarządzi ogłoszenie o wszczęciu postępowania. 
**§ 2.** Ogłoszenie o wszczęciu postępowania powinno zawierać: 
- 1) imię i nazwisko oraz adres wnioskodawcy; 
- 2) dane dotyczące osoby zaginionego oraz istotne okoliczności znane z akt 
sprawy, które mogą przyczynić się do wykrycia zaginionego; 
- 3) wezwanie skierowane do zaginionego, aby w oznaczonym terminie, nie 
krótszym niż trzy, a nie dłuższym niż sześć miesięcy, zgłosił się, gdyż 
w przeciwnym razie może być uznany za zmarłego; 
- 4) wezwanie skierowane do wszystkich osób, które mogą udzielić wiadomości 
o zaginionym, aby w powyższym terminie przekazały je sądowi.

***
## Art. 531. {#kpc-pierwsza-druga-art-531}

**§ 1.** Ogłoszenie o wszczęciu postępowania zamieszcza się 
w Monitorze Sądowym i Gospodarczym oraz podaje publicznie do wiadomości 
w miejscu ostatniego zamieszkania zaginionego, w sposób w tym miejscu przyjęty. 
**§ 2.** Sąd może dodatkowo zarządzić podanie ogłoszenia publicznie do 
wiadomości w inny sposób, jaki uzna za odpowiedni.

***
## Art. 532. {#kpc-pierwsza-druga-art-532}

Dalsze postępowanie może toczyć się przed upływem terminu 
podanego w ogłoszeniu, nie może jednak być zakończone wcześniej niż po 
upływie: 
- 1) terminów przewidzianych w kodeksie cywilnym; 
- 2) trzech miesięcy od ukazania się ogłoszenia; 
- 3) miesiąca od końca terminu wyznaczonego w ogłoszeniu.

***
## Art. 533. {#kpc-pierwsza-druga-art-533}

Przed wydaniem postanowienia uznającego zaginionego za 
zmarłego sąd powinien wysłuchać w miarę możności osoby bliskie zaginionego. 

 
 
 
s. 244/580 
 
2025-09-08

***
## Art. 534. {#kpc-pierwsza-druga-art-534}

Jeżeli w toku postępowania o uznanie za zmarłego okaże się, że 
śmierć zaginionego jest niewątpliwa, sąd przeprowadzi dalsze postępowanie 
z urzędu według przepisów oddziału następnego. 
Oddział 2 
Postępowanie o stwierdzenie zgonu

***
## Art. 535. {#kpc-pierwsza-druga-art-535}

Do postępowania o stwierdzenie zgonu osoby, której śmierć mimo 
niesporządzenia aktu zgonu jest niewątpliwa, stosuje się odpowiednio przepisy 
oddziału poprzedzającego ze zmianami przewidzianymi w oddziale niniejszym.

***
## Art. 536. {#kpc-pierwsza-druga-art-536}

Wniosek o stwierdzenie zgonu może być zgłoszony w każdym 
czasie.

***
## Art. 537. {#kpc-pierwsza-druga-art-537}

**§ 1.** Zarządzenie ogłoszenia o wszczęciu postępowania nie jest 
obowiązkowe. 
**§ 2.** Sąd może jednak, jeżeli uzna to za celowe, zarządzić dokonanie 
ogłoszenia w określony przez siebie sposób. Do ogłoszenia stosuje się wówczas 
odpowiednio przepis art. 530 § 2; termin wyznaczony w ogłoszeniu nie może być 
krótszy niż miesiąc ani dłuższy niż trzy miesiące. 
**§ 3.** W wypadku przewidzianym w paragrafie poprzedzającym postępowanie 
nie może być zakończone wcześniej niż po upływie miesiąca od ukazania się 
ogłoszenia i dwóch tygodni od końca terminu wyznaczonego w ogłoszeniu.

***
## Art. 538. {#kpc-pierwsza-druga-art-538}

**§ 1.** W postanowieniu stwierdzającym zgon należy chwilę śmierci 
ściśle oznaczyć, stosownie do wyników postępowania. 
**§ 2.** Jeżeli dokładne ustalenie chwili śmierci nie jest możliwe, przyjmuje się 
chwilę najbardziej prawdopodobną. 
Oddział 3 
Uchylenie postanowień orzekających uznanie za zmarłego lub stwierdzenie 
zgonu

***
## Art. 539. {#kpc-pierwsza-druga-art-539}

Dowód, że osoba uznana za zmarłą albo której zgon został 
stwierdzony pozostaje przy życiu lub że śmierć jej nastąpiła w innej chwili niż 
chwila oznaczona w orzeczeniu, może być przeprowadzony tylko w postępowaniu 
unormowanym w niniejszym oddziale. 

 
 
 
s. 245/580 
 
2025-09-08

***
## Art. 540. {#kpc-pierwsza-druga-art-540}

Właściwy jest sąd, który w pierwszej instancji orzekł uznanie za 
zmarłego lub stwierdzenie zgonu.

***
## Art. 541. {#kpc-pierwsza-druga-art-541}

**§ 1.** Wniosek o uchylenie postanowienia orzekającego uznanie za 
zmarłego albo stwierdzającego zgon może zgłosić każdy zainteresowany. Sąd może 
także uchylić je z urzędu. 
**§ 2.** Sąd wzywa do udziału w sprawie uczestników postępowania, w którym 
zapadło postanowienie o uznaniu za zmarłego lub o stwierdzeniu zgonu.

***
## Art. 542. {#kpc-pierwsza-druga-art-542}

W razie przeprowadzenia dowodu, że osoba uznana za zmarłą albo 
której zgon został stwierdzony pozostaje przy życiu, sąd postanowienie uchyli. 
W wypadku udowodnienia innej chwili śmierci niż oznaczona w postanowieniu 
o uznaniu za zmarłego, sąd uchyla postanowienie o uznaniu za zmarłego tylko 
wówczas, gdy równocześnie stwierdza zgon.

***
## Art. 543. {#kpc-pierwsza-druga-art-543}

Jeżeli osoba, którą uznano za zmarłą lub której zgon stwierdzono, 
zjawi się osobiście w sądzie i wykaże swoją tożsamość, sąd niezwłocznie i bez 
dalszego postępowania uchyli postanowienie orzekające uznanie za zmarłego lub 
stwierdzenie zgonu. 
Rozdział 2 
Ubezwłasnowolnienie 
Oddział 1 
Przepisy ogólne

***
## Art. 544. {#kpc-pierwsza-druga-art-544}

**§ 1.** Sprawy o ubezwłasnowolnienie należą do właściwości sądów 
okręgowych. 
**§ 2.** W sprawach tych właściwy jest sąd miejsca zamieszkania osoby, której 
dotyczy wniosek o ubezwłasnowolnienie, a w braku miejsca zamieszkania – sąd 
miejsca jej pobytu.

***
## Art. 545. {#kpc-pierwsza-druga-art-545}

**§ 1.** Wniosek o ubezwłasnowolnienie może zgłosić: 
- 1) małżonek osoby, której dotyczy wniosek o ubezwłasnowolnienie; 
- 2) jej krewni w linii prostej oraz rodzeństwo; 
- 3) jej przedstawiciel ustawowy. 

 
 
 
s. 246/580 
 
2025-09-08 
**§ 2.** Krewni osoby, której dotyczy wniosek o ubezwłasnowolnienie, nie mogą 
zgłaszać tego wniosku, jeżeli osoba ta ma przedstawiciela ustawowego. 
**§ 3.** Wniosek o ubezwłasnowolnienie częściowe można zgłosić już na rok 
przed 
dojściem 
do 
pełnoletności 
osoby, 
której 
dotyczy 
wniosek 
o ubezwłasnowolnienie. 
**§ 4.** Kto zgłosił wniosek o ubezwłasnowolnienie w złej wierze lub 
lekkomyślnie, podlega karze grzywny.

***
## Art. 546. {#kpc-pierwsza-druga-art-546}

**§ 1.** Uczestnikami postępowania o ubezwłasnowolnienie są z mocy 
samego prawa prócz wnioskodawcy: 
- 1) osoba, której dotyczy wniosek; 
- 2) jej przedstawiciel ustawowy; 
- 3) małżonek osoby, której dotyczy wniosek o ubezwłasnowolnienie. 
**§ 2.** Postępowanie toczy się z udziałem prokuratora. 
**§ 3.** Organizacje pozarządowe, do których zadań statutowych należy ochrona 
praw osób niepełnosprawnych, udzielanie pomocy takim osobom lub ochrona praw 
człowieka, mogą wstąpić do postępowania w każdym jego stadium.

***
## Art. 547. {#kpc-pierwsza-druga-art-547}

**§ 1.** Osobę, której dotyczy wniosek o ubezwłasnowolnienie, należy 
wysłuchać niezwłocznie po wszczęciu postępowania; wysłuchanie powinno odbyć 
się w obecności biegłego psychologa oraz – w zależności od stanu zdrowia osoby, 
która ma być wysłuchana – biegłego lekarza psychiatry lub neurologa. 
**§ 2.** W celu 
wysłuchania 
osoby, 
której 
dotyczy 
wniosek 
o ubezwłasnowolnienie, sąd może zarządzić przymusowe sprowadzenie tej osoby 
na rozprawę albo wysłuchać ją przez sędziego wyznaczonego. Na postanowienie 
sądu o przymusowym sprowadzeniu osoby na rozprawę przysługuje zażalenie. 
**§ 3.** Niemożność porozumienia się z osobą, której dotyczy wniosek 
o ubezwłasnowolnienie, stwierdza się w protokole po wysłuchaniu biegłego lekarza 
i psychologa uczestniczących w posiedzeniu. 
**§ 4.** Przepisów o posiedzeniu zdalnym nie stosuje się do osoby, której dotyczy 
wniosek o ubezwłasnowolnienie, o ile ma być wysłuchana, ani do udziału biegłych 
w tej czynności. 

 
 
 
s. 247/580 
 
2025-09-08 
 
Oddział 2 
Doradca tymczasowy

***
## Art. 548. {#kpc-pierwsza-druga-art-548}

**§ 1.** Jeżeli 
wniosek 
o ubezwłasnowolnienie 
dotyczy 
osoby 
pełnoletniej, sąd może na wniosek uczestnika postępowania lub z urzędu, przy 
wszczęciu lub w toku postępowania, ustanowić dla niej doradcę tymczasowego, 
gdy uzna to za konieczne dla ochrony jej osoby lub mienia. 
**§ 2.** Przed ustanowieniem doradcy tymczasowego należy wysłuchać osobę, 
której dotyczy wniosek o ubezwłasnowolnienie. 
**§ 3.** Doradcą tymczasowym należy ustanowić przede wszystkim małżonka, 
krewnego lub inną osobę bliską, jeżeli nie stoi temu na przeszkodzie wzgląd na 
dobro osoby, której dotyczy wniosek o ubezwłasnowolnienie. 
**§ 4.** Sąd może zwrócić się do organizacji pozarządowej wymienionej 
w art. 546 § 3 o wskazanie osoby, która mogłaby być ustanowiona doradcą 
tymczasowym. 
**§ 5.** Postanowienie o ustanowieniu doradcy tymczasowego staje się skuteczne 
z chwilą doręczenia go osobie, której dotyczy wniosek. W wypadkach określonych 
w art. 556 postanowienie staje się skuteczne z chwilą wydania.

***
## Art. 549. {#kpc-pierwsza-druga-art-549}

**§ 1.** Osoba, dla której ustanowiono doradcę tymczasowego, ma 
ograniczoną 
zdolność 
do 
czynności 
prawnych 
na 
równi 
z osobą 
ubezwłasnowolnioną częściowo. 
**§ 2.** Do doradcy tymczasowego stosuje się przepisy o kuratorze osoby 
częściowo ubezwłasnowolnionej.

***
## Art. 550. {#kpc-pierwsza-druga-art-550}

**§ 1.** Postanowienie o ustanowieniu doradcy tymczasowego traci 
moc z chwilą, gdy: 
- 1) wniosek o ubezwłasnowolnienie został prawomocnie oddalony lub odrzucony 
albo postępowanie umorzono; 
- 2) na skutek orzeczenia o ubezwłasnowolnieniu ustanowiony został opiekun lub 
kurator. 
**§ 2.** Sąd odwołuje doradcę tymczasowego, jeżeli ustała potrzeba dalszej 
ochrony osoby, której dotyczy wniosek o ubezwłasnowolnienie, lub jej mienia.

***
## Art. 551. {#kpc-pierwsza-druga-art-551}

**§ 1.** O ustanowieniu lub odwołaniu doradcy tymczasowego należy 
z urzędu zawiadomić sąd opiekuńczy. 

 
 
 
s. 248/580 
 
2025-09-08 
**§ 2.** Na postanowienie w przedmiocie ustanowienia lub odwołania doradcy 
tymczasowego przysługuje zażalenie. 
Oddział 3 
Postępowanie

***
## Art. 552. {#kpc-pierwsza-druga-art-552}

**§ 1.** Jeżeli według wniosku ubezwłasnowolnienie ma być orzeczone 
z powodu choroby psychicznej lub niedorozwoju umysłowego, sąd przed 
zarządzeniem 
doręczenia 
wniosku 
zażąda, 
w wyznaczonym 
terminie, 
przedstawienia świadectwa lekarskiego wydanego przez lekarza psychiatrę o stanie 
psychicznym osoby, której dotyczy wniosek o ubezwłasnowolnienie, lub opinii 
psychologa o stopniu niepełnosprawności umysłowej tej osoby. Jeżeli ubezwłasno-
wolnienie ma nastąpić z powodu pijaństwa, sąd żąda także przedstawienia 
zaświadczenia poradni przeciwalkoholowej, a jeżeli ubezwłasnowolnienie ma 
nastąpić z powodu narkomanii – zaświadczenia z poradni leczenia uzależnień. 
**§ 2.** Sąd odrzuca wniosek o ubezwłasnowolnienie, jeżeli treść wniosku lub 
dołączone do wniosku dokumenty nie uprawdopodobniają istnienia choroby 
psychicznej, niedorozwoju umysłowego lub występowania innego rodzaju 
zaburzeń psychicznych osoby, której dotyczy wniosek o ubezwłasnowolnienie albo 
w razie niezłożenia żądanego świadectwa, opinii lub zaświadczenia, chyba że 
złożenie takich dokumentów nie jest możliwe.

***
## Art. 553. {#kpc-pierwsza-druga-art-553}

**§ 1.** Osoba, której dotyczy wniosek o ubezwłasnowolnienie, musi 
być zbadana przez biegłego lekarza psychiatrę lub neurologa, a także psychologa. 
**§ 2.** Opinia biegłego oprócz oceny stanu zdrowia psychicznego lub zaburzeń 
psychicznych albo rozwoju umysłowego osoby, której dotyczy wniosek 
o ubezwłasnowolnienie, powinna zawierać umotywowaną ocenę zakresu jej 
zdolności do samodzielnego kierowania swoim postępowaniem i prowadzenia 
swoich spraw, uwzględniającą postępowanie i zachowanie się tej osoby.

***
## Art. 554. {#kpc-pierwsza-druga-art-554}

**§ 1.** Sąd może, jeżeli na podstawie opinii dwóch biegłych lekarzy 
uzna to za niezbędne, zarządzić oddanie osoby, której dotyczy wniosek 
o ubezwłasnowolnienie, pod obserwację w zakładzie leczniczym na czas nie 
dłuższy niż sześć tygodni. W wyjątkowych wypadkach sąd może termin ten 
przedłużyć do trzech miesięcy. 

 
 
 
s. 249/580 
 
2025-09-08 
**§ 2.** Przed 
wydaniem 
postanowienia 
sąd 
wysłucha 
uczestników 
postępowania. 
**§ 3.** Na postanowienie zarządzające oddanie do zakładu przysługuje 
zażalenie.

***
## Art. 5541. {#kpc-pierwsza-druga-art-5541}

**§ 1.** Postępowanie dowodowe powinno ustalić przede wszystkim 
stan zdrowia, sytuację osobistą, zawodową i majątkową osoby, której dotyczy 
wniosek o ubezwłasnowolnienie, rodzaj spraw wymagających prowadzenia przez 
tę osobę oraz sposób zaspokajania jej potrzeb życiowych. 
**§ 2.** Sąd może zobowiązać osoby pozostające we wspólnocie domowej 
z osobą, której dotyczy wniosek o ubezwłasnowolnienie, do złożenia wykazu 
majątku należącego do tej osoby oraz do złożenia przyrzeczenia. Przepisy art. 913, 
915–917 stosuje się odpowiednio.

***
## Art. 555. {#kpc-pierwsza-druga-art-555}

Orzeczenie w przedmiocie ubezwłasnowolnienia może zapaść tylko 
po przeprowadzeniu rozprawy.

***
## Art. 556. {#kpc-pierwsza-druga-art-556}

**§ 1.** Sąd może zaniechać doręczenia pism sądowych, wezwania lub 
wysłuchania osoby, której dotyczy wniosek o ubezwłasnowolnienie, jeżeli uzna to 
za niecelowe ze względu na stan zdrowia tej osoby, określony w opiniach biegłego 
lekarza psychiatry lub neurologa oraz psychologa wydanych po przeprowadzeniu 
badania. Nie dotyczy to wysłuchania, o którym mowa w art. 547. Na postanowienie 
sądu przysługuje zażalenie. 
**§ 2.** W wypadkach wskazanych w § 1 sąd orzekający, w celu ochrony w toku 
postępowania praw osoby, której dotyczy wniosek o ubezwłasnowolnienie, 
ustanowi kuratora, chyba że ma ona przedstawiciela ustawowego, który nie jest 
wnioskodawcą. 
Przepisy 
art. 548 § 3 
i 4 stosuje 
się 
odpowiednio. 
Na 
postanowienie sądu przysługuje zażalenie.

***
## Art. 557. {#kpc-pierwsza-druga-art-557}

W postanowieniu 
o ubezwłasnowolnieniu 
sąd 
orzeka, 
czy 
ubezwłasnowolnienie jest całkowite, czy też częściowe i z jakiego powodu zostaje 
orzeczone.

***
## Art. 558. {#kpc-pierwsza-druga-art-558}

**§ 1.** Sąd, który orzekł ubezwłasnowolnienie, zarządza z urzędu 
przesłanie sądowi opiekuńczemu odpisu prawomocnego postanowienia, którym 
orzekł ubezwłasnowolnienie. 

 
 
 
s. 250/580 
 
2025-09-08 
**§ 2.** W razie oddalenia wniosku o ubezwłasnowolnienie sąd zawiadamia sąd 
opiekuńczy o potrzebie ustanowienia kuratora dla osoby niepełnosprawnej.

***
## Art. 559. {#kpc-pierwsza-druga-art-559}

**§ 1.** Sąd uchyli ubezwłasnowolnienie, gdy ustaną przyczyny, dla 
których je orzeczono; uchylenie może nastąpić także z urzędu. 
**§ 2.** Sąd może w razie poprawy stanu psychicznego ubezwłasnowolnionego 
zmienić ubezwłasnowolnienie całkowite na częściowe, a w razie pogorszenia się 
tego stanu – zmienić ubezwłasnowolnienie częściowe na całkowite. 
**§ 3.** Z wnioskiem o uchylenie albo zmianę ubezwłasnowolnienia może 
wystąpić także ubezwłasnowolniony.

***
## Art. 560. {#kpc-pierwsza-druga-art-560}

**§ 1.** Do 
zaskarżania 
postanowień 
uprawniony 
jest 
sam 
ubezwłasnowolniony nawet wówczas, gdy ustanowiony został doradca 
tymczasowy albo kurator. 
**§ 2.** Do środków odwoławczych wnoszonych przez osobę, której dotyczy 
wniosek o ubezwłasnowolnienie, nie stosuje się art. 368. Środka odwoławczego 
wniesionego przez osobę, której dotyczy wniosek o ubezwłasnowolnienie, nie 
odrzuca się z powodu nieusunięcia braków formalnych. 
**§ 3.** Sąd drugiej instancji rozpoznaje sprawę w składzie jednego sędziego.

***
## Art. 5601. {#kpc-pierwsza-druga-art-5601}

W sprawach o ubezwłasnowolnienie, o uchylenie oraz zmianę 
ubezwłasnowolnienia sąd może ustanowić dla osoby, której dotyczy wniosek 
o ubezwłasnowolnienie lub dla osoby ubezwłasnowolnionej, adwokata lub radcę 
prawnego z urzędu, nawet bez jej wniosku, jeżeli osoba ta ze względu na stan 
zdrowia psychicznego nie jest zdolna do złożenia wniosku, a sąd uzna udział 
adwokata lub radcy prawnego w sprawie za potrzebny. 
DZIAŁ Ia 
Sprawy z zakresu przeciwdziałania przemocy domowej

***
## Art. 5602. {#kpc-pierwsza-druga-art-5602}

Przepisy zawarte w niniejszym dziale stosuje się w sprawach, 
o których mowa w art. 11a–11ab ustawy z dnia 29 lipca 2005 r. o przeciwdziałaniu 
przemocy domowej (Dz. U. z 2024 r. poz. 424 i 834).

***
## Art. 5603. {#kpc-pierwsza-druga-art-5603}

**§ 1.** Wniosek o zobowiązanie osoby stosującej przemoc domową 
do opuszczenia wspólnie zajmowanego mieszkania i jego bezpośredniego 
otoczenia lub o wydanie zakazu zbliżania się do wspólnie zajmowanego 

 
 
 
s. 251/580 
 
2025-09-08 
 
mieszkania i jego bezpośredniego otoczenia, lub zakazu zbliżania się do osoby 
doznającej przemocy domowej, lub zakazu kontaktowania się z osobą doznającą 
przemocy domowej, lub zakazu wstępu na teren szkoły, placówki oświatowej, 
opiekuńczej lub artystycznej, lub obiektu sportowego, do których uczęszcza osoba 
doznająca przemocy domowej, miejsca pracy lub innego miejsca, w którym zwykle 
lub regularnie przebywa osoba doznająca przemocy domowej, i przebywania na 
tym terenie, może być złożony na urzędowym formularzu. 
**§ 11.** Wniosek, o którym mowa w § 1, może zawierać wskazanie numeru 
telefonu lub adresu poczty elektronicznej wnioskodawcy. 
**§ 2.** Minister Sprawiedliwości określi, w drodze rozporządzenia, wzór 
i sposób udostępniania urzędowego formularza wniosku, o którym mowa w § 1, 
mając na względzie ustawowe wymagania przewidziane dla tego pisma, potrzebę 
zamieszczenia niezbędnych pouczeń co do sposobu wypełniania formularza, 
wnoszenia pisma i skutków niedostosowania go do ustawowych wymagań, a także 
konieczność bezpłatnego udostępniania formularzy w siedzibach sądów oraz sieci 
Internet w formie pozwalającej na dogodną edycję treści formularza.

***
## Art. 5603a. {#kpc-pierwsza-druga-art-5603a}

**§ 1.** W trakcie postępowania uczestnik, który został zobowiązany 
do opuszczenia wspólnie zajmowanego mieszkania i jego bezpośredniego 
otoczenia lub któremu zakazano zbliżania się do wspólnie zajmowanego 
mieszkania i jego bezpośredniego otoczenia, może złożyć wniosek o zezwolenie na 
zabranie ze wspólnie zajmowanego mieszkania i jego bezpośredniego otoczenia 
przedmiotów osobistego użytku i przedmiotów niezbędnych do wykonywania 
osobistej pracy zarobkowej lub zwierząt domowych będących jego własnością 
niezbędnych do codziennego funkcjonowania lub pracy zarobkowej, na których 
wydanie nie wyraża zgody wnioskodawca. 
**§ 2.** We wniosku, o którym mowa w § 1, uczestnik określa przedmiot lub 
zwierzę domowe, które mają być zabrane, uprawdopodobnia korzystanie ze 
wskazanego przedmiotu lub uprawdopodobnia własność zwierzęcia domowego 
i jego niezbędność do codziennego funkcjonowania lub pracy zarobkowej. 
**§ 3.** Sąd rozpoznaje wniosek, o którym mowa w § 1, niezwłocznie po jego 
wpływie, na posiedzeniu niejawnym lub rozprawie, po odebraniu wyjaśnień od 
wnioskodawcy. Sąd może telefonicznie lub za pośrednictwem poczty 
elektronicznej zawiadomić wnioskodawcę o złożeniu wniosku, o którym mowa 

 
 
 
s. 252/580 
 
2025-09-08 
 
w § 1, oraz dopuszczalnych sposobach złożenia wyjaśnień, o ile numer telefonu lub 
adres poczty elektronicznej został wskazany przez wnioskodawcę. 
**§ 4.** Jeżeli wnioskodawca w wyznaczonym terminie nie złoży wyjaśnień na 
piśmie lub nie stawi się na rozprawę, sąd rozstrzyga na podstawie twierdzeń 
zawartych we wniosku, o którym mowa w § 1, o czym należy wnioskodawcę 
pouczyć, zawiadamiając go o dopuszczalnych sposobach złożenia wyjaśnień. 
**§ 5.** Do wniosku, o którym mowa w § 1, stosuje się przepis art. 5604 § 2. 
**§ 6.** Postanowienie jest 
skuteczne i wykonalne z chwilą ogłoszenia. 
Prawomocne postanowienie i ustalenia faktyczne sądu stanowiące podstawę 
rozstrzygnięcia nie wiążą sądu w postępowaniach, których przedmiotem jest 
żądanie co do własności rzeczy. 
**§ 7.** Na postanowienie przysługuje zażalenie do innego składu sądu pierwszej 
instancji. 
**§ 8.** Przedmioty lub zwierzęta domowe wskazane w postanowieniu uczestnik 
może zabrać ze wspólnie zajmowanego mieszkania i z jego bezpośredniego 
otoczenia, w obecności policjanta lub żołnierza Żandarmerii Wojskowej, po 
wcześniejszym uzgodnieniu terminu z osobą doznającą przemocy domowej. 
Przepisy art. 15ae ust. 1–3 ustawy z dnia 6 kwietnia 1990 r. o Policji (Dz. U. z 2024 
r. poz. 145, 1006, 1089, 1222, 1248 i 1473) albo art. 18e ust. 1–3 ustawy z dnia 
24 sierpnia 
2001 r. 
o Żandarmerii 
Wojskowej 
i wojskowych 
organach 
porządkowych (Dz. U. z 2023 r. poz. 1266 i 1860 oraz z 2024 r. poz. 1222 i 1248) 
stosuje się odpowiednio. 
**§ 9.** Jeżeli postanowienie nie może być wykonane zgodnie z § 8, podlega 
wykonaniu w drodze egzekucji świadczeń niepieniężnych o wydaniu rzeczy 
ruchomej.

***
## Art. 5604. {#kpc-pierwsza-druga-art-5604}

**§ 1.** Sąd orzeka po przeprowadzeniu rozprawy. 
**§ 2.** W wypadku gdy do wniosku lub innych pism nie dołączono odpisów, sąd 
sporządza i doręcza ich odpisy. Odpis wniosku lub innych pism sąd doręcza 
również prokuratorowi i zawiadamia go o terminach rozprawy.

***
## Art. 5605. {#kpc-pierwsza-druga-art-5605}

Sąd orzeka w terminie jednego miesiąca od dnia wniesienia 
wniosku. 

 
 
 
s. 253/580 
 
2025-09-08

***
## Art. 5606. {#kpc-pierwsza-druga-art-5606}

**§ 1.** Jeżeli jest to niezbędne dla zapewnienia szybkości 
postępowania, sąd może dokonywać doręczeń przez Policję lub Żandarmerię 
Wojskową. 
**§ 2.** Doręczeń, o których mowa w § 1, Policja lub Żandarmeria Wojskowa 
dokonuje nie później niż w terminie 7 dni od dnia otrzymania zlecenia, za 
potwierdzeniem odbioru i oznaczeniem daty, na formularzu określonym w prze-
pisach wydanych na podstawie art. 131 § 2. 
**§ 3.** Jeżeli adresata nie zastano przy próbie doręczenia, Policja lub 
Żandarmeria Wojskowa ustala, czy adresat zamieszkuje pod wskazanym adresem. 
Z dokonanych ustaleń Policja lub Żandarmeria Wojskowa sporządza notatkę, którą 
przekazuje sądowi zlecającemu doręczenie. 
**§ 4.** Jeżeli próba doręczenia okaże się bezskuteczna, a zgodnie z ustaleniami 
Policji lub Żandarmerii Wojskowej adresat zamieszkuje pod wskazanym adresem, 
w oddawczej skrzynce pocztowej adresata umieszcza się zawiadomienie o podjętej 
próbie doręczenia wraz z informacją o możliwości odbioru pisma lub odpisu 
postanowienia sądu w budynku sądu zlecającego doręczenie, do którego Policja lub 
Żandarmeria Wojskowa je zwraca. Do zawiadomienia Policja lub Żandarmeria 
Wojskowa dołącza pouczenie, że pismo lub odpis postanowienia należy odebrać 
z sądu w terminie 7 dni od dnia umieszczenia zawiadomienia. Jeżeli pod 
wskazanym adresem zastano dorosłego domownika niebędącego osobą doznającą 
przemocy domowej, o możliwości odbioru poucza się dodatkowo tego domownika. 
W przypadku bezskutecznego upływu terminu do odbioru pisma lub odpisu 
postanowienia doręczenie uważa się za dokonane w ostatnim dniu tego terminu. 
**§ 5.** Jeżeli próba doręczenia okaże się bezskuteczna, a zgodnie z ustaleniami 
Policji lub Żandarmerii Wojskowej adresat nie zamieszkuje pod wskazanym 
adresem, Policja lub Żandarmeria Wojskowa zwraca pisma lub odpisy postanowień 
sądowi, informując go o dokonanych ustaleniach. To samo dotyczy przypadku, gdy 
Policji lub Żandarmerii Wojskowej mimo podjęcia wymaganych czynności nie 
udało się ustalić, czy adresat zamieszkuje pod wskazanym adresem. 
**§ 6.** Policja lub Żandarmeria Wojskowa w toku postępowania udzielają 
sądowi innej pomocy niezbędnej do jego szybkiego zakończenia.

***
## Art. 5607. {#kpc-pierwsza-druga-art-5607}

**§ 1.** Sąd, uwzględniając wniosek o zobowiązanie osoby stosującej 
przemoc domową do opuszczenia wspólnie zajmowanego mieszkania i jego 

 
 
 
s. 254/580 
 
2025-09-08 
 
bezpośredniego otoczenia lub o wydanie zakazu zbliżania się do wspólnie 
zajmowanego 
mieszkania 
i jego 
bezpośredniego 
otoczenia, 
wskazuje 
w postanowieniu obszar, który osoba stosująca przemoc domową ma opuścić i na 
którym nie może przebywać, lub odległość od wspólnie zajmowanego mieszkania, 
którą osoba stosująca przemoc domową jest obowiązana zachować. 
**§ 2.** W postanowieniu, o którym mowa w § 1, sąd na wniosek wnioskodawcy 
lub uczestnika postępowania może im tymczasowo przyznać prawo do korzystania 
z rzeczy znajdujących się we wspólnie zajmowanym mieszkaniu lub w jego 
bezpośrednim otoczeniu oraz określić sposób korzystania z nich, jeżeli nie 
spowoduje to nadmiernej zwłoki w postępowaniu. W postanowieniu sąd określa 
termin i sposób wydania rzeczy przyznanych do korzystania, a w uzasadnionych 
przypadkach okres korzystania z tych rzeczy. Do wykonania postanowienia 
o przyznaniu prawa do korzystania z rzeczy stosuje się odpowiednio przepisy 
art. 5603a § 8 i 9. Prawomocne postanowienie i ustalenia faktyczne sądu stanowiące 
podstawę rozstrzygnięcia nie wiążą sądu w postępowaniach, których przedmiotem 
jest żądanie co do własności rzeczy. 
**§ 3.** Sąd, uwzględniając wniosek o wydanie zakazu zbliżania się do osoby 
doznającej przemocy domowej, wskazuje w postanowieniu wyrażoną w metrach 
odległość, na którą osoba stosująca przemoc domową nie może zbliżyć się do osoby 
doznającej tej przemocy. 
**§ 4.** Sąd, uwzględniając wniosek o wydanie zakazu kontaktowania się 
z pełnoletnią osobą doznającą przemocy domowej, na wniosek wnioskodawcy lub 
uczestnika postępowania, gdy przemawiają za tym szczególne okoliczności, może 
w postanowieniu określić dopuszczalne sposoby kontaktowania się oraz ich zakres, 
mając na uwadze bezpieczeństwo osoby doznającej przemocy domowej. 
**§ 5.** Postanowienia, o których mowa w § 1, 3 i 4, oraz postanowienie 
uwzględniające wniosek o wydanie zakazu wstępu na teren szkoły, placówki 
oświatowej, opiekuńczej lub artystycznej, lub obiektu sportowego, do których 
uczęszcza osoba doznająca przemocy domowej, miejsca pracy lub innego miejsca, 
w którym zwykle lub regularnie przebywa osoba doznająca przemocy domowej, 
i przebywania na tym terenie, są skuteczne i wykonalne z chwilą ogłoszenia. 
Postanowienia te mogą być uchylane lub zmieniane wskutek zmiany okoliczności 
sprawy, chociażby były zaskarżone, a nawet prawomocne. 

 
 
 
s. 255/580 
 
2025-09-08

***
## Art. 5608. {#kpc-pierwsza-druga-art-5608}

Sąd 
w postanowieniu 
w przedmiocie 
zobowiązania 
osoby 
stosującej przemoc domową do opuszczenia wspólnie zajmowanego mieszkania 
i jego bezpośredniego otoczenia lub wydania zakazu zbliżania się do wspólnie 
zajmowanego mieszkania i jego bezpośredniego otoczenia, lub zakazu zbliżania się 
do osoby doznającej przemocy domowej, lub zakazu kontaktowania się z osobą 
doznającą przemocy domowej, lub zakazu wstępu na teren szkoły, placówki 
oświatowej, opiekuńczej lub artystycznej, lub obiektu sportowego, do których 
uczęszcza osoba doznająca przemocy domowej, miejsca pracy lub innego miejsca, 
w którym zwykle lub regularnie przebywa osoba doznająca przemocy domowej, 
i przebywania na tym terenie, rozstrzyga również o zabezpieczeniu, jeżeli było 
udzielone.

***
## Art. 5609. {#kpc-pierwsza-druga-art-5609}

**§ 1.** Sąd z urzędu doręcza odpis postanowienia uczestnikom 
postępowania, prokuratorowi, Policji lub Żandarmerii Wojskowej oraz zawiadamia 
właściwy miejscowo zespół interdyscyplinarny, o którym mowa w przepisach 
ustawy z dnia 29 lipca 2005 r. o przeciwdziałaniu przemocy domowej, a gdy 
w mieszkaniu zamieszkują osoby małoletnie – także właściwy miejscowo sąd 
opiekuńczy. Sąd, uwzględniając wniosek o wydanie zakazu wstępu na teren szkoły, 
placówki oświatowej, opiekuńczej lub artystycznej, lub obiektu sportowego, do 
których uczęszcza osoba doznająca przemocy domowej, miejsca pracy lub innego 
miejsca, w którym zwykle lub regularnie przebywa osoba doznająca przemocy 
domowej, i przebywania na tym terenie, zawiadamia o treści postanowienia 
dyrektora szkoły, placówki oświatowej, opiekuńczej lub artystycznej, do której 
uczęszcza osoba doznająca przemocy domowej, osobę zarządzającą obiektem 
sportowym, do którego uczęszcza osoba doznająca przemocy domowej, lub 
pracodawcę osoby doznającej przemocy domowej. Sąd może także zawiadomić 
inne osoby odpowiedzialne za miejsce, w którym zwykle lub regularnie przebywa 
osoba doznająca przemocy domowej, jeżeli jest to niezbędne do prawidłowego 
wykonania postanowienia. 
**§ 11.** Sąd opiekuńczy po otrzymaniu zawiadomienia, o którym mowa w § 1, 
bezzwłocznie podejmuje czynności w celu ustalenia sytuacji małoletniego. Po 
ustaleniu sytuacji małoletniego sąd opiekuńczy wszczyna z urzędu postępowanie 
dotyczące władzy rodzicielskiej, chyba że nie zachodzi konieczność jego 
wszczęcia, w szczególności gdy takie postępowanie się toczy. 

 
 
 
s. 256/580 
 
2025-09-08 
**§ 2.** Termin do złożenia wniosku o uzasadnienie biegnie od dnia ogłoszenia 
postanowienia.

***
## Art. 56010. {#kpc-pierwsza-druga-art-56010}

Jeżeli do apelacji nie dołączono jej odpisów, sąd sporządza 
i doręcza odpis apelacji.

***
## Art. 56011. {#kpc-pierwsza-druga-art-56011}

Termin do wniesienia odpowiedzi na apelację jest tygodniowy.

***
## Art. 56012. {#kpc-pierwsza-druga-art-56012}

Sąd drugiej instancji orzeka w terminie jednego miesiąca od 
przedstawienia akt sprawy przez sąd pierwszej instancji wraz z apelacją. 
#### DZIAŁ II
Sprawy z zakresu prawa rodzinnego, opiekuńczego i kurateli 
Rozdział 1 
Sprawy małżeńskie

***
## Art. 561. {#kpc-pierwsza-druga-art-561}

**§ 1.** Zezwolenia na zawarcie małżeństwa kobiecie niemającej 
ukończonych lat osiemnastu udziela sąd opiekuńczy na jej wniosek. Postanowienie 
o udzieleniu zezwolenia staje się skuteczne z chwilą uprawomocnienia się i nie 
może być zmienione ani uchylone. 
**§ 2.** Zezwolenia na zawarcie małżeństwa osobie dotkniętej chorobą 
psychiczną albo niedorozwojem umysłowym oraz osobom powinowatym w linii 
prostej udziela sąd na wniosek tych osób. 
**§ 3.** W postanowieniu o udzieleniu zezwolenia wymienia się osobę, z którą 
małżeństwo ma być zawarte. Przed wydaniem postanowienia rozstrzygającego taki 
wniosek sąd wysłucha wnioskodawcę, osobę, z którą małżeństwo ma być zawarte, 
oraz w razie potrzeby osoby bliskie przyszłych małżonków. Gdy chodzi 
o udzielenie zezwolenia osobie dotkniętej chorobą psychiczną lub niedorozwojem 
umysłowym, sąd zasięgnie opinii biegłego lekarza, w miarę możności psychiatry.

***
## Art. 5611. {#kpc-pierwsza-druga-art-5611}

W sprawach, o których mowa w art. 561, sąd może zarządzić 
przeprowadzenie przez kuratora sądowego wywiadu środowiskowego w celu 
ustalenia warunków, w jakich żyją osoby ubiegające się o udzielenie zezwolenia.

***
## Art. 562. {#kpc-pierwsza-druga-art-562}

Zwolnienia od obowiązku złożenia urzędowi stanu cywilnego 
dokumentu potrzebnego do zawarcia małżeństwa udziela sąd na wniosek osoby 
obowiązanej do złożenia dokumentu. 

 
 
 
s. 257/580 
 
2025-09-08

***
## Art. 563. {#kpc-pierwsza-druga-art-563}

Do 
zgłoszenia 
wniosku 
o zezwolenie 
na 
złożenie 
przez 
pełnomocnika oświadczenia o wstąpieniu w związek małżeński uprawniona jest 
osoba, która zamierza udzielić pełnomocnictwa.

***
## Art. 564. {#kpc-pierwsza-druga-art-564}

Postanowienie 
rozstrzygające 
o tym, 
czy 
okoliczność 
przedstawiona przez kierownika urzędu stanu cywilnego wyłącza zawarcie 
małżeństwa, a także o tym, czy okoliczności przedstawione przez kierownika 
urzędu stanu cywilnego uzasadniają odmowę: 
- 1) przyjęcia oświadczeń o wstąpieniu w związek małżeński, 
- 2) wydania zaświadczenia o braku okoliczności wyłączających zawarcie 
małżeństwa, o których mowa w art. 41 Kodeksu rodzinnego i opiekuńczego, 
- 3) wydania zezwolenia na zawarcie małżeństwa przed upływem terminu, 
o którym mowa w art. 4 Kodeksu rodzinnego i opiekuńczego, 
- 4) sporządzenia aktu małżeństwa zawartego zgodnie z art. 1 § 2 Kodeksu 
rodzinnego i opiekuńczego, 
- 5) wydania zaświadczenia stwierdzającego, że zgodnie z prawem polskim 
można zawrzeć małżeństwo, 
sąd wydaje po przeprowadzeniu rozprawy.

***
## Art. 565. {#kpc-pierwsza-druga-art-565}

**§ 1.** Rozstrzygnięcie o istotnych sprawach rodziny w braku 
porozumienia małżonków, jak również udzielenie zezwolenia na dokonanie 
czynności, do której jest potrzebna zgoda drugiego małżonka lub której drugi 
małżonek sprzeciwił się, może nastąpić dopiero po umożliwieniu złożenia 
wyjaśnień małżonkowi wnioskodawcy, chyba że jego wysłuchanie nie jest możliwe 
lub celowe. 
**§ 2.** To samo dotyczy nakazu sądu, aby wynagrodzenie za pracę albo inne 
należności przypadające jednemu małżonkowi były w całości lub w części 
wypłacane do rąk drugiego małżonka. 
**§ 3.** Przepis 
§ 1 stosuje 
się 
także 
do 
rozstrzygnięcia 
o wyłączeniu 
odpowiedzialności małżonka za zobowiązania zaciągnięte przez drugiego 
z małżonków w sprawach wynikających z zaspokajania zwykłych potrzeb rodziny, 
jak również do uchylenia postanowienia w tym przedmiocie. 

 
 
 
s. 258/580 
 
2025-09-08

***
## Art. 5651. {#kpc-pierwsza-druga-art-5651}

W sprawach, o których mowa w art. 565, sąd może zarządzić 
przeprowadzenie przez kuratora sądowego wywiadu środowiskowego w celu 
ustalenia warunków, w jakich żyją małżonkowie.

***
## Art. 566. {#kpc-pierwsza-druga-art-566}

W sprawie o podział majątku wspólnego po ustaniu wspólności 
majątkowej między małżonkami właściwy jest sąd miejsca położenia majątku, 
a jeżeli wspólność ustała przez śmierć jednego z małżonków – sąd spadku.

***
## Art. 567. {#kpc-pierwsza-druga-art-567}

**§ 1.** W postępowaniu o podział majątku wspólnego po ustaniu 
wspólności majątkowej między małżonkami sąd rozstrzyga także o żądaniu 
ustalenia nierównych udziałów małżonków w majątku wspólnym oraz o tym, jakie 
wydatki, nakłady i inne świadczenia z majątku wspólnego na rzecz majątku 
osobistego lub odwrotnie podlegają zwrotowi. 
**§ 2.** W razie sporu co do ustalenia nierównych udziałów w majątku wspólnym 
sąd może w tym przedmiocie orzec postanowieniem wstępnym. 
**§ 3.** Do postępowania o podział majątku wspólnego po ustaniu wspólności 
majątkowej między małżonkami, a zwłaszcza do odrębnego postępowania 
w sprawach wymienionych w paragrafie pierwszym stosuje się odpowiednio 
przepisy o dziale spadku.

***
## Art. 5671. {#kpc-pierwsza-druga-art-5671}

W sprawach o separację na zgodny wniosek małżonków, a także 
w sprawach o zniesienie separacji właściwe rzeczowo są sądy okręgowe. 
W sprawach tych miejscowo właściwym jest sąd, w którego okręgu małżonkowie 
mają wspólne zamieszkanie, a w braku takiej podstawy – sąd miejsca ich 
wspólnego pobytu. Jeżeli małżonkowie nie mają wspólnego miejsca zamieszkania 
ani pobytu, wniosek należy zgłosić w sądzie właściwym dla jednego z małżonków, 
zgodnie z art. 508 § 1–3.

***
## Art. 5672. {#kpc-pierwsza-druga-art-5672}

**§ 1.** W sprawie o separację na zgodny wniosek małżonków oraz 
w sprawie o zniesienie separacji w razie cofnięcia wniosku albo wyrażenia w inny 
sposób braku zgody na orzeczenie separacji lub na zniesienie separacji przez 
któregokolwiek z małżonków postępowanie umarza się. Przepisu art. 512 § 1 nie 
stosuje się. 
**§ 2.** W razie śmierci jednego z małżonków postępowanie umarza się.

***
## Art. 5673. {#kpc-pierwsza-druga-art-5673}

**§ 1.** Postanowienie o separacji sąd wydaje po przeprowadzeniu 
rozprawy. 

 
 
 
s. 259/580 
 
2025-09-08 
**§ 2.** W toku postępowania sąd nakłania małżonków do pojednania. Jeżeli 
pojednanie nie nastąpi, a odroczenie rozprawy nie byłoby celowe, sąd przystępuje 
do rozpoznania sprawy.

***
## Art. 5674. {#kpc-pierwsza-druga-art-5674}

Postanowienie 
o zniesieniu 
separacji 
sąd 
wydaje 
po 
przeprowadzeniu rozprawy.

***
## Art. 5675. {#kpc-pierwsza-druga-art-5675}

Z chwilą wszczęcia postępowania o zniesienie separacji zawiesza 
się z urzędu postępowanie w sprawie o eksmisję jednego z małżonków 
pozostających w separacji ze wspólnego mieszkania, jak również postępowanie w 
sprawie o korzystanie przez małżonków pozostających w separacji ze wspólnego 
mieszkania. Z chwilą uprawomocnienia się orzeczenia o zniesieniu separacji 
postępowanie umarza się z urzędu. 
Rozdział 2 
Inne sprawy rodzinne oraz sprawy opiekuńcze 
Oddział 1 
Przepisy ogólne

***
## Art. 568. {#kpc-pierwsza-druga-art-568}

Sądem opiekuńczym jest sąd rodzinny.

***
## Art. 569. {#kpc-pierwsza-druga-art-569}

**§ 1.** Właściwy wyłącznie jest sąd opiekuńczy miejsca zamieszkania 
osoby, której postępowanie ma dotyczyć, a w braku miejsca zamieszkania – sąd 
opiekuńczy miejsca jej pobytu. Jeżeli brak tej podstawy, właściwy jest sąd 
opiekuńczy ostatniego miejsca zamieszkania osoby, której postępowanie ma 
dotyczyć, a w braku miejsca zamieszkania – sąd opiekuńczy ostatniego miejsca jej 
pobytu. Jeżeli brak i tej podstawy właściwy jest sąd rejonowy dla m.st. Warszawy. 
**§ 2.** W wypadkach nagłych sąd opiekuńczy wydaje z urzędu wszelkie 
potrzebne zarządzenia nawet w stosunku do osób, które nie podlegają jego 
właściwości miejscowej, zawiadamiając o tym sąd opiekuńczy miejscowo 
właściwy.

***
## Art. 5691. {#kpc-pierwsza-druga-art-5691}

**§ 1.** Do właściwości sądu okręgowego z siedzibą w miejscowości 
będącej siedzibą sądu apelacyjnego należą sprawy o odebranie osoby podlegającej 
władzy rodzicielskiej lub pozostającej pod opieką prowadzone na podstawie 

 
 
 
s. 260/580 
 
2025-09-08 
 
konwencji haskiej z 1980 r., jeżeli na tym obszarze osoba podlegająca władzy 
rodzicielskiej lub pozostająca pod opieką ma miejsce zamieszkania lub pobytu. 
**§ 11.** W przypadku określonym w art. 11063 § 2, jeżeli w toku postępowania 
w sprawach o odebranie osoby podlegającej władzy rodzicielskiej lub pozostającej 
pod opieką prowadzonych na podstawie konwencji haskiej z 1980 r., mającej 
miejsce zwykłego pobytu w państwie członkowskim Unii Europejskiej stosującym 
rozporządzenie Rady (UE) 2019/1111 z dnia 25 czerwca 2019 r. w sprawie 
jurysdykcji, uznawania i wykonywania orzeczeń w sprawach małżeńskich 
i w sprawach dotyczących odpowiedzialności rodzicielskiej oraz w sprawie 
uprowadzenia dziecka za granicę (wersja przekształcona) (Dz. Urz. UE L 178 
z 02.07.2019, str. 1), zwane dalej „rozporządzeniem nr 2019/1111”, uczestnicy 
postępowania osiągnęli porozumienie co do powrotu albo odstąpienia od powrotu 
tej osoby do państwa, w którym bezpośrednio przed naruszeniem prawa 
wynikającego z władzy rodzicielskiej lub opieki miała ona miejsce zwykłego 
pobytu, a także co do wykonywania władzy rodzicielskiej lub sprawowania opieki 
nad tą osobą, utrzymywania z nią kontaktów lub alimentów na jej rzecz, sąd, 
o którym mowa w § 1, jest właściwy również w sprawach dotyczących tej osoby 
w przedmiocie władzy rodzicielskiej lub opieki, a także kontaktów lub alimentów. 
**§ 12.** Porozumienie, o którym mowa w § 11, jest zawierane na piśmie lub 
ustnie do protokołu i opatrywane datą oraz podpisem uczestników postępowania. 
**§ 2.** Sąd okręgowy orzeka w terminie sześciu tygodni od dnia wniesienia 
wniosku w sprawach, o których mowa w § 1. 
**§ 3.** Dla spraw, o których mowa w § 1, z obszaru właściwości Sądu 
Apelacyjnego w Warszawie właściwy jest Sąd Okręgowy w Warszawie. 
**§ 4.** Jeżeli wniosek w sprawach, o których mowa w § 1, wniesiony został bez 
pośrednictwa polskiego organu centralnego, o którym mowa w art. 3 ust. 1 ustawy 
z dnia 26 stycznia 2018 r. o wykonywaniu niektórych czynności organu 
centralnego w sprawach rodzinnych z zakresu obrotu prawnego na podstawie 
prawa Unii Europejskiej i umów międzynarodowych (Dz. U. z 2023 r. poz. 1236), 
sąd okręgowy zawiadamia niezwłocznie sąd, o którym mowa w art. 569 § 1, 
o wniesieniu wniosku oraz o zakończeniu postępowania w tej sprawie.

***
## Art. 570. {#kpc-pierwsza-druga-art-570}

Sąd opiekuńczy może wszcząć postępowanie z urzędu. 

 
 
 
s. 261/580 
 
2025-09-08

***
## Art. 5701. {#kpc-pierwsza-druga-art-5701}

**§ 1.** Sąd opiekuńczy może zarządzić przeprowadzenie przez 
kuratora sądowego wywiadu środowiskowego w celu zebrania informacji 
dotyczących małoletniego i jego środowiska, a w szczególności jego zachowania 
się, warunków wychowawczych i życiowych, w tym sytuacji bytowej rodziny, 
przebiegu nauki małoletniego i sposobu spędzania czasu wolnego, jego kontaktów 
środowiskowych, stosunku do niego rodziców lub opiekunów, podejmowanych 
oddziaływań wychowawczych, stanu zdrowia i znanych w środowisku uzależnień 
małoletniego. 
**§ 11.** Przepis § 1 stosuje się także wtedy, gdy sąd opiekuńczy powziął 
wiadomość o zdarzeniu uzasadniającym wszczęcie postępowania z urzędu, oraz w 
toku postępowania wykonawczego. 
**§ 2.** W przypadku gdy z rodziną małoletniego asystent rodziny prowadzi 
pracę określoną w przepisach o wspieraniu rodziny i systemie pieczy zastępczej, 
sąd opiekuńczy zwraca się o informacje, o których mowa w § 1, do właściwej 
jednostki organizacyjnej wspierania rodziny i systemu pieczy zastępczej. 
**§ 3.** O informacje, o których mowa w § 1, a także informację mającą na celu 
wskazanie osób właściwych do zapewnienia dziecku rodzinnej pieczy zastępczej, 
sąd opiekuńczy może zwrócić się do właściwej jednostki organizacyjnej wspierania 
rodziny i systemu pieczy zastępczej.

***
## Art. 5701a. {#kpc-pierwsza-druga-art-5701a}

Sąd opiekuńczy może zarządzić przeprowadzenie przez kuratora 
sądowego wywiadu środowiskowego w toku postępowania prowadzonego w 
sprawach dotyczących ustanowienia opieki lub kurateli i prowadzonego w tych 
sprawach postępowania wykonawczego w celu ustalenia możliwości lub sposobu 
sprawowania opieki lub kurateli oraz warunków życiowych osoby, której 
postępowanie dotyczy.

***
## Art. 5702. {#kpc-pierwsza-druga-art-5702}

W sprawie, w której zawarcie ugody jest dopuszczalne, sąd może 
skierować uczestników do mediacji. Przedmiotem mediacji może być także 
określenie sposobu wykonywania władzy rodzicielskiej. Jeżeli uczestnicy 
postępowania nie uzgodnili osoby mediatora, sąd kieruje ich do mediacji 
prowadzonej przez stałego mediatora, o którym mowa w art. 436 § 4.

***
## Art. 571. {#kpc-pierwsza-druga-art-571}

(uchylony) 

 
 
 
s. 262/580 
 
2025-09-08

***
## Art. 572. {#kpc-pierwsza-druga-art-572}

**§ 1.** Każdy, komu znane jest zdarzenie uzasadniające wszczęcie 
postępowania z urzędu, obowiązany jest zawiadomić o nim sąd opiekuńczy. 
**§ 2.** Obowiązek wymieniony w § 1 ciąży przede wszystkim na urzędach stanu 
cywilnego, 
sądach, 
prokuratorach, 
notariuszach, 
komornikach, 
organach 
samorządu i administracji rządowej, organach Policji, placówkach oświatowych, 
opiekunach społecznych oraz organizacjach i zakładach zajmujących się opieką 
nad dziećmi lub osobami psychicznie chorymi. 
**§ 3.** Na wniosek osoby lub instytucji, o której mowa w § 1 lub 2, sąd 
opiekuńczy informuje o wszczęciu postępowania z urzędu lub braku podstaw do 
jego wszczęcia z urzędu.

***
## Art. 573. {#kpc-pierwsza-druga-art-573}

**§ 1.** Osoba pozostająca pod władzą rodzicielską, opieką albo 
kuratelą ma zdolność do podejmowania czynności w postępowaniu dotyczącym jej 
osoby, chyba że nie ma zdolności do czynności prawnych. 
**§ 2.** Sąd może ograniczyć lub wyłączyć osobisty udział małoletniego 
w postępowaniu, jeżeli przemawiają za tym względy wychowawcze.

***
## Art. 574. {#kpc-pierwsza-druga-art-574}

**§ 1.** Sąd opiekuńczy może nakazać osobiste stawiennictwo osoby 
pozostającej pod władzą rodzicielską lub opieką, jak również zarządzić 
przymusowe sprowadzenie takiej osoby. 
**§ 2.** Jeżeli osoba pozostająca pod władzą rodzicielską lub opieką nie ma 
zdolności do podejmowania czynności w postępowaniu, sąd opiekuńczy może 
nakazać jej sprowadzenie do sądu pod rygorem grzywny każdemu, u kogo osoba 
taka przebywa.

***
## Art. 575. {#kpc-pierwsza-druga-art-575}

Do osobistego stawiennictwa innych uczestników postępowania 
stosuje się w sprawach, które mogą być wszczęte z urzędu, przepisy o skutkach 
niestawiennictwa świadków, a w innych sprawach – przepis art. 429.

***
## Art. 5751. {#kpc-pierwsza-druga-art-5751}

W sprawach opiekuńczych osób małoletnich sąd z urzędu zarządza 
odbycie całego posiedzenia lub jego części przy drzwiach zamkniętych, jeżeli 
przeciwko publicznemu rozpoznaniu sprawy przemawia dobro małoletniego.

***
## Art. 576. {#kpc-pierwsza-druga-art-576}

**§ 1.** Przed wydaniem orzeczenia co do istoty sprawy sąd opiekuńczy 
wysłucha przedstawiciela ustawowego osoby, której postępowanie dotyczy. 
W wypadkach ważniejszych powinien ponadto w miarę możności wysłuchać 
osoby bliskie tej osoby. 

 
 
 
s. 263/580 
 
2025-09-08 
**§ 2.** Sąd w sprawach dotyczących osoby lub majątku dziecka wysłucha je, 
jeżeli jego rozwój umysłowy, stan zdrowia i stopień dojrzałości na to pozwala, 
uwzględniając w miarę możliwości jego rozsądne życzenia. Wysłuchanie odbywa 
się poza salą posiedzeń sądowych. 
**§ 3.** Do wysłuchania, o którym mowa w § 2, stosuje się odpowiednio przepisy 
art. 2161 § 3 i 4 oraz art. 2162.

***
## Art. 577. {#kpc-pierwsza-druga-art-577}

Sąd opiekuńczy może zmienić swe postanowienie nawet 
prawomocne, jeżeli wymaga tego dobro osoby, której postępowanie dotyczy.

***
## Art. 578. {#kpc-pierwsza-druga-art-578}

**§ 1.** Postanowienia sądu opiekuńczego są skuteczne i wykonalne 
z chwilą ich ogłoszenia, a gdy ogłoszenia nie było, z chwilą ich wydania. 
**§ 2.** Sąd w terminie 7 dni od dnia uprawomocnienia się postanowienia 
o pozbawieniu władzy rodzicielskiej przesyła to postanowienie do właściwego 
ośrodka adopcyjnego, prowadzącego wojewódzki bank danych o dzieciach 
oczekujących na przysposobienie.

***
## Art. 5781. {#kpc-pierwsza-druga-art-5781}

**§ 1.** Podstawą wszczęcia postępowania wykonawczego jest 
orzeczenie sądu albo ugoda zawarta przed sądem, których wykonalność została 
stwierdzona przez sąd, albo ugoda zawarta przed mediatorem, po jej zatwierdzeniu 
przez sąd. 
**§ 2.** Do stwierdzenia wykonalności, o którym mowa w § 1, art. 364 stosuje się 
odpowiednio. 
**§ 3.** Wykonalność orzeczenia sąd stwierdza z urzędu.

***
## Art. 5782. {#kpc-pierwsza-druga-art-5782}

**§ 1.** W postępowaniu w sprawach o odebranie osoby podlegającej 
władzy rodzicielskiej lub pozostającej pod opieką prowadzonych na podstawie 
konwencji haskiej z 1980 r. obowiązuje zastępstwo uczestników postępowania 
przez adwokatów lub radców prawnych. 
**§ 2.** Przepisu § 1 nie stosuje się do wniosku o wszczęcie postępowania 
w sprawach o odebranie osoby podlegającej władzy rodzicielskiej lub pozostającej 
pod opieką prowadzonych na podstawie konwencji haskiej z 1980 r., w 
postępowaniu o zwolnienie od kosztów sądowych oraz o ustanowienie adwokata 
lub radcy prawnego, a także gdy uczestnikiem postępowania, jego organem, jego 
przedstawicielem ustawowym lub pełnomocnikiem jest: 
- 1) sędzia; 

 
 
 
s. 264/580 
 
2025-09-08 
- 2) prokurator; 
- 3) notariusz; 
- 4) profesor lub doktor habilitowany nauk prawnych; 
- 5) adwokat; 
- 6) radca prawny; 
- 7) radca Prokuratorii Generalnej Rzeczypospolitej Polskiej. 
Oddział 2 
Sprawy z zakresu stosunków między rodzicami a dziećmi

***
## Art. 579. {#kpc-pierwsza-druga-art-579}

Postanowienia 
w sprawach 
o powierzenie 
wykonywania, 
ograniczenie, zawieszenie, pozbawienie i przywrócenie władzy rodzicielskiej, 
ustalenie, ograniczenie albo zakazanie kontaktów z dzieckiem mogą być wydane 
tylko po przeprowadzeniu rozprawy. Dotyczy to także zmiany rozstrzygnięć w tym 
przedmiocie, zawartych w wyroku orzekającym rozwód, separację, unieważnienie 
małżeństwa albo ustalającym pochodzenie dziecka. Postanowienia takie stają się 
skuteczne i wykonalne po uprawomocnieniu się.

***
## Art. 5791. {#kpc-pierwsza-druga-art-5791}

**§ 1.** Po powzięciu wiadomości o umieszczeniu dziecka w pieczy 
zastępczej bez orzeczenia sądu opiekuńczego, sąd ten niezwłocznie wszczyna 
postępowanie opiekuńcze. 
**§ 2.** Jeżeli umieszczenie dziecka w pieczy zastępczej nastąpiło w trybie 
art. 12a ustawy z dnia 29 lipca 2005 r. o przeciwdziałaniu przemocy domowej sąd 
opiekuńczy niezwłocznie, po wysłuchaniu pracownika socjalnego, który zapewnił 
ochronę dziecku, nie później jednak niż w ciągu 24 godzin od wysłuchania, wydaje 
orzeczenie o umieszczeniu dziecka w pieczy zastępczej albo orzeczenie o powrocie 
dziecka do rodziców, opiekunów prawnych lub faktycznych dziecka. 
**§ 3.** Sąd opiekuńczy okresowo, nie rzadziej niż raz na sześć miesięcy, 
dokonuje oceny sytuacji dziecka umieszczonego w pieczy zastępczej w celu 
ustalenia możliwości powrotu dziecka do rodziny. Jeżeli wymaga tego dobro 
dziecka, sąd wszczyna postępowanie o pozbawienie władzy rodzicielskiej jego 
rodziców.

***
## Art. 5792. {#kpc-pierwsza-druga-art-5792}

**§ 1.** Przed 
umieszczeniem 
dziecka 
u kandydata 
zakwalifikowanego do pełnienia funkcji rodziny zastępczej, kandydata 
zakwalifikowanego do prowadzenia rodzinnego domu dziecka, w rodzinie 

 
 
 
s. 265/580 
 
2025-09-08 
 
zastępczej lub rodzinnym domu dziecka sąd zasięga informacji z rejestru, o którym 
mowa w art. 38d ust. 1 ustawy z dnia 9 czerwca 2011 r. o wspieraniu rodziny 
i systemie pieczy zastępczej (Dz. U. z 2024 r. poz. 177, 742, 743 i 858). 
**§ 2.** W przypadku konieczności uzyskania przez sąd informacji o kandydacie 
zakwalifikowanym do pełnienia funkcji rodziny zastępczej, kandydacie 
zakwalifikowanym do prowadzenia rodzinnego domu dziecka, rodzinie zastępczej 
lub prowadzącym rodzinny dom dziecka innych niż zawarte w rejestrze, o którym 
mowa w art. 38d ust. 1 ustawy z dnia 9 czerwca 2011 r. o wspieraniu rodziny 
i systemie pieczy zastępczej, sąd może wystąpić o informacje odpowiednio do 
właściwego: 
- 1) ośrodka pomocy społecznej; 
- 2) organizatora rodzinnej pieczy zastępczej. 
**§ 3.** Przed umieszczeniem dziecka w rodzinnej pieczy zastępczej na terenie 
powiatu innego niż powiat obowiązany do ponoszenia wydatków, o których mowa 
w art. 191 ust. 1 pkt 1 ustawy z dnia 9 czerwca 2011 r. o wspieraniu rodziny 
i systemie pieczy zastępczej, sąd zasięga odpowiednio od: 
- 1) starosty powiatu, na terenie którego funkcjonuje mogąca przyjąć dziecko 
rodzina zastępcza, 
- 2) starosty, który zawarł z mogącą przyjąć dziecko rodziną zastępczą 
niezawodową umowę o pełnienie funkcji rodziny zastępczej zawodowej, 
chyba że porozumienie, o którym mowa w art. 54 ust. 3b ustawy z dnia 
9 czerwca 2011 r. o wspieraniu rodziny i systemie pieczy zastępczej, stanowi 
inaczej, 
- 3) starosty powiatu, który organizuje rodzinny dom dziecka mogący przyjąć 
dziecko, chyba że porozumienie, o którym mowa w art. 60 ust. 3, stanowi 
inaczej 
– informacji o liczbie umieszczonych w rodzinnej pieczy zastępczej dzieci, 
w stosunku do których powiat ten nie jest powiatem obowiązanym do ponoszenia 
wydatków, o których mowa w art. 191 ust. 1 pkt 1 ustawy z dnia 9 czerwca 2011 r. 
o wspieraniu rodziny i systemie pieczy zastępczej, oraz o ogólnej liczbie miejsc 
w rodzinnej pieczy zastępczej zapewnianej przez ten powiat. 
**§ 4.** W przypadku gdy z informacji, o której mowa w § 3, wynika, że liczba 
umieszczonych w rodzinnej pieczy zastępczej dzieci, na które powiat nie jest 

 
 
 
s. 266/580 
 
2025-09-08 
 
powiatem 
obowiązanym 
do 
ponoszenia 
wydatków, 
o których 
mowa 
w art. 191 ust. 1 pkt 1 ustawy z dnia 9 czerwca 2011 r. o wspieraniu rodziny 
i systemie pieczy zastępczej, przekroczyła 25 % ogólnej liczby miejsc w rodzinnej 
pieczy zastępczej zapewnianych przez ten powiat, sąd może umieścić dziecko 
w rodzinnej pieczy zastępczej zapewnianej przez ten powiat tylko za jego zgodą 
oraz jeżeli przemawia za tym dobro dziecka.

***
## Art. 5793. {#kpc-pierwsza-druga-art-5793}

W sprawach, o których mowa w art. 5792 § 1 i § 2, sąd może 
zarządzić przeprowadzenie przez kuratora sądowego wywiadu środowiskowego 
w miejscu zamieszkania kandydata do pełnienia funkcji rodziny zastępczej lub 
prowadzenia rodzinnego domu dziecka, w szczególności w zakresie jego: 
- 1) danych osobowych; 
- 2) stopnia pokrewieństwa z dzieckiem; 
- 3) karalności oraz prowadzonych z jego udziałem postępowań dotyczących 
władzy rodzicielskiej; 
- 4) stanu zdrowia; 
- 5) statusu zawodowego; 
- 6) uzależnień; 
- 7) sytuacji bytowej i rodzinnej; 
- 8) stosunku do dziecka; 
- 9) prezentowanego modelu wychowawczego; 
- 10) sposobu funkcjonowania w środowisku.

***
## Art. 5794. {#kpc-pierwsza-druga-art-5794}

**§ 1.** Postępowanie w sprawie o udzielenie zgody na umieszczenie 
dziecka w pieczy zastępczej na podstawie orzeczenia sądu lub innego organu 
państwa obcego sąd opiekuńczy wszczyna z urzędu na podstawie wystąpienia sądu 
lub innego organu państwa obcego. 
**§ 2.** Jeżeli sąd lub inny organ państwa obcego wskazał kandydatów do 
pełnienia funkcji rodziny zastępczej albo prowadzenia rodzinnego domu dziecka 
albo określoną placówkę opiekuńczo-wychowawczą, albo regionalną placówkę 
opiekuńczo-terapeutyczną, albo interwencyjny ośrodek preadopcyjny, w których 
dziecko ma być umieszczone, w przedmiocie zgody orzeka sąd opiekuńczy 
właściwy ze względu na miejsce przyszłego sprawowania pieczy zastępczej. 
W pozostałych przypadkach właściwy jest sąd rejonowy dla m.st. Warszawy. Przed 

 
 
 
s. 267/580 
 
2025-09-08 
 
wydaniem zgody sąd zasięga opinii, o której mowa w przepisach o wspieraniu 
rodziny i systemie pieczy zastępczej. 
**§ 3.** Sąd opiekuńczy może zwrócić się do sądu lub innego organu państwa 
obcego o wszelkie niezbędne dokumenty, opinie i informacje dotyczące dziecka, 
w szczególności dotyczące jego sytuacji rodzinnej, stanu zdrowia i szczególnych 
potrzeb. Jeżeli wystąpienie sądu lub innego organu państwa obcego nie wskazuje 
sposobu sprowadzenia dziecka do Rzeczypospolitej Polskiej i zasad pokrycia 
kosztów jego sprowadzenia, a gdy umieszczenie ma nastąpić na czas określony – 
także sposobu powrotu i zasad pokrycia kosztów powrotu dziecka, sąd opiekuńczy 
zwraca się o udzielenie takich informacji. Sąd oceni, jakie znaczenie nadać 
nieudzieleniu informacji. 
**§ 4.** Sąd opiekuńczy orzeka na posiedzeniu niejawnym. Rozpoznanie wniosku 
następuje w terminie miesiąca od dnia jego wpływu do sądu. 
**§ 5.** Postanowienie w przedmiocie udzielenia zgody doręcza się sądowi lub 
innemu organowi państwa obcego, a także organowi, który wydał opinię, o której 
mowa w § 2. Postanowienie to nie podlega zaskarżeniu. 
**§ 6.** Przepisów art. 573, art. 576 oraz art. 577 nie stosuje się. 
**§ 7.** Wniosek o stwierdzenie wykonalności orzeczenia sądu lub innego organu 
państwa obcego o umieszczeniu dziecka w pieczy zastępczej może złożyć także 
organ centralny tego państwa wyznaczony na podstawie przepisów Konwencji 
o jurysdykcji, prawie właściwym, uznawaniu, wykonywaniu i współpracy 
w zakresie odpowiedzialności rodzicielskiej oraz środków ochrony dzieci, 
sporządzonej w Hadze dnia 19 października 1996 r. (Dz. U. z 2010 r. poz. 1158), 
zwanej dalej „konwencją haską z 1996 r.”.

***
## Art. 580. {#kpc-pierwsza-druga-art-580}

(uchylony)

***
## Art. 581. {#kpc-pierwsza-druga-art-581}

**§ 1.** Uznanie ojcostwa może nastąpić także przed sądem 
opiekuńczym niewłaściwym według przepisów ogólnych. W takim wypadku 
o uznaniu zawiadamia się właściwy sąd opiekuńczy. 
**§ 2.** Jeżeli kierownik urzędu stanu cywilnego odmówił przyjęcia oświadczeń 
koniecznych do uznania ojcostwa, uznanie ojcostwa może nastąpić wyłącznie przed 
sądem opiekuńczym, właściwym ze względu na siedzibę urzędu stanu cywilnego, 
którego kierownik odmówił przyjęcia tych oświadczeń. 

 
 
 
s. 268/580 
 
2025-09-08 
**§ 21.** Jeżeli konsul odmówił przyjęcia oświadczeń koniecznych do uznania 
ojcostwa, uznanie ojcostwa może nastąpić wyłącznie przed sądem rejonowym dla 
m.st. Warszawy. 
**§ 3.** Sąd opiekuńczy odmawia przyjęcia oświadczeń koniecznych do uznania 
ojcostwa, jeżeli uznanie jest niedopuszczalne albo poweźmie wątpliwość co do 
pochodzenia dziecka.

***
## Art. 582. {#kpc-pierwsza-druga-art-582}

Rozstrzygnięcie o istotnych sprawach dziecka, co do których brak 
porozumienia pomiędzy rodzicami, może nastąpić dopiero po umożliwieniu 
rodzicom złożenia oświadczeń, chyba że wysłuchanie ich byłoby połączone z 
nadmiernymi trudnościami.

***
## Art. 5821. {#kpc-pierwsza-druga-art-5821}

**§ 1.** W sprawach o kontakty z dzieckiem przepis art. 582 stosuje 
się odpowiednio. 
**§ 2.** Sąd opiekuńczy w celu zapewnienia wykonywania kontaktów może 
w szczególności: 
- 1) zobowiązać osobę uprawnioną do kontaktu z dzieckiem lub osobę, pod której 
pieczą dziecko pozostaje, do pokrycia kosztów podróży i pobytu dziecka lub 
także osoby towarzyszącej dziecku, w tym kosztów powrotu do miejsca 
stałego pobytu; 
- 2) zobowiązać osobę, pod której pieczą dziecko pozostaje, do złożenia na 
rachunek depozytowy Ministra Finansów odpowiedniej kwoty pieniężnej 
w celu pokrycia wydatków uprawnionego związanych z wykonywaniem 
kontaktu na wypadek niewykonania lub niewłaściwego wykonania przez 
osobę 
zobowiązaną 
obowiązków 
wynikających 
z postanowienia 
o kontaktach; nie dotyczy to rodzin zastępczych, rodzinnych domów dziecka, 
rodzin pomocowych, placówek opiekuńczo-wychowawczych, regionalnych 
placówek opiekuńczo-terapeutycznych oraz interwencyjnych ośrodków 
preadopcyjnych; 
- 3) odebrać od osoby uprawnionej do kontaktu z dzieckiem lub osoby, pod której 
pieczą dziecko pozostaje, przyrzeczenie określonego zachowania. 
**§ 3.** W razie uzasadnionej obawy naruszenia obowiązków wynikających 
z postanowienia o kontaktach przez osobę, pod której pieczą dziecko pozostaje, lub 
osobę uprawnioną do kontaktu z dzieckiem albo osobę, której tego kontaktu 

 
 
 
s. 269/580 
 
2025-09-08 
 
zakazano, sąd opiekuńczy może zagrozić nakazaniem zapłaty oznaczonej sumy 
pieniężnej, stosownie do zasad określonych w art. 59815: 
- 1) osobie, pod której pieczą dziecko pozostaje – na rzecz osoby uprawnionej do 
kontaktu z dzieckiem lub 
- 2) osobie uprawnionej do kontaktu z dzieckiem albo osobie, której tego kontaktu 
zakazano – na rzecz osoby, pod której pieczą dziecko pozostaje. 
**§ 4.** Przepis § 3 stosuje się odpowiednio do orzeczenia, w którym sąd określił, 
że dziecko będzie mieszkać z każdym z rodziców w powtarzających się okresach.

***
## Art. 583. {#kpc-pierwsza-druga-art-583}

Zezwolenia 
na 
dokonanie 
przez 
rodziców 
czynności 
przekraczającej zakres zwykłego zarządu majątkiem dziecka lub na wyrażenie 
przez rodziców zgody na dokonanie takiej czynności przez dziecko sąd opiekuńczy 
udziela na wniosek jednego z rodziców po wysłuchaniu drugiego. Postanowienie 
sądu opiekuńczego w tym przedmiocie staje się skuteczne dopiero z chwilą 
uprawomocnienia się i nie może być zmienione ani uchylone, jeżeli na podstawie 
zezwolenia powstały skutki prawne względem osób trzecich.

***
## Art. 5831. {#kpc-pierwsza-druga-art-5831}

**§ 1.** Wniosek o wyznaczenie reprezentanta dziecka, o którym 
mowa w art. 99 § 1 Kodeksu rodzinnego i opiekuńczego, sąd opiekuńczy 
rozpoznaje niezwłocznie, nie później niż w terminie 7 dni od dnia wpływu tego 
wniosku. 
**§ 2.** Adwokat lub radca prawny, o którym mowa w art. 991 § 1 Kodeksu 
rodzinnego i opiekuńczego, jest wyznaczany z listy reprezentantów dziecka. 
**§ 3.** Minister Sprawiedliwości określi, w drodze rozporządzenia, sposób 
zapewnienia reprezentacji dziecka przez reprezentanta dziecka, w tym sposób 
ustalania listy reprezentantów dziecka, sposób wyznaczania reprezentanta dziecka 
oraz system szkoleniowy reprezentantów dziecka, mając na uwadze konieczność 
zapewnienia prawidłowego toku postępowania oraz prawidłowej realizacji prawa 
do ochrony interesów dziecka.

***
## Art. 584. {#kpc-pierwsza-druga-art-584}

Postanowienie o nadaniu dziecku nazwiska staje się skuteczne 
dopiero po uprawomocnieniu się. Postanowienia takiego sąd opiekuńczy nie może 
zmienić ani uchylić. 

 
 
 
s. 270/580 
 
2025-09-08 
 
Oddział 3 
Sprawy o przysposobienie

***
## Art. 585. {#kpc-pierwsza-druga-art-585}

**§ 1.** Sąd 
opiekuńczy 
wszczyna 
postępowanie 
na 
wniosek 
przysposabiającego. 
**§ 2.** Wniosek ten należy zgłosić w sądzie opiekuńczym właściwym dla osoby 
przysposabiającego lub osoby mającej być przysposobioną. 
**§ 21.** We wniosku, o którym mowa w § 1, przysposabiający wskazuje również 
ośrodek adopcyjny, w którym objęty był postępowaniem adopcyjnym, o którym 
mowa w ustawie z dnia 9 czerwca 2011 r. o wspieraniu rodziny i systemie pieczy 
zastępczej. 
**§ 22.** Sąd zwraca się do ośrodka adopcyjnego wskazanego we wniosku, 
o którym mowa w § 1, o: 
- 1) świadectwo ukończenia przez przysposabiającego szkolenia dla kandydatów 
do przysposobienia dziecka, z uwzględnieniem art. 172 ust. 2 ustawy z dnia 
9 czerwca 2011 r. o wspieraniu rodziny i systemie pieczy zastępczej; 
- 2) opinię kwalifikacyjną o kandydatach do przysposobienia dziecka. 
**§ 3.** Art. 87 § 3 stosuje się odpowiednio.

***
## Art. 5851. {#kpc-pierwsza-druga-art-5851}

**§ 1.** Wskazanie osoby przysposabiającego przez rodziców, 
o którym mowa w art. 1191a Kodeksu rodzinnego i opiekuńczego, następuje przed 
sądem opiekuńczym właściwym dla osoby przysposabiającego lub osoby mającej 
być przysposobioną. 
**§ 2.** W przypadku wskazania, o którym mowa w § 1, przed wszczęciem 
postępowania w sprawie o przysposobienie, sąd opiekuńczy wyznacza termin, 
w którym wskazany przez rodziców przysposabiający powinien zgłosić do sądu 
opiekuńczego wniosek o przysposobienie pod rygorem nieuwzględnienia 
wskazania. Termin ten nie może przekraczać dwóch tygodni.

***
## Art. 5852. {#kpc-pierwsza-druga-art-5852}

O toczącym się postępowaniu w sprawach, w których wniosek 
o przysposobienie dotyczy dziecka niezgłoszonego do ośrodka adopcyjnego, sąd 
opiekuńczy zawiadamia prokuratora.

***
## Art. 586. {#kpc-pierwsza-druga-art-586}

**§ 1.** Sąd opiekuńczy orzeka o przysposobieniu po przeprowadzeniu 
rozprawy. 

 
 
 
s. 271/580 
 
2025-09-08 
**§ 2.** Na rozprawę wzywa się przysposabiającego oraz osoby, których zgoda 
na przysposobienie jest potrzebna. Równocześnie z wezwaniem na rozprawę 
poucza się uczestnika o treści przepisów art. 211a § 2 pkt 1 oraz § 3 Kodeksu 
karnego oraz o tym, że w razie działania uczestnika w celu osiągnięcia korzyści 
majątkowej lub osobistej oświadczenie o działaniu w tym celu powinno zostać 
złożone niezwłocznie, nie później jednak niż przed wydaniem postanowienia 
kończącego postępowanie w sprawie o przysposobienie. 
**§ 3.** Nie wzywa się na rozprawę rodziców, którzy wyrazili zgodę na 
przysposobienie 
ich 
dziecka 
w przyszłości 
bez 
wskazania 
osoby 
przysposabiającego. W wypadku takim rodzice nie mogą brać udziału 
w postępowaniu. 
**§ 4.** Przed wydaniem orzeczenia sąd opiekuńczy występuje o opinię do 
ośrodka adopcyjnego, a w razie potrzeby uzasadnionej dobrem dziecka może także 
zasięgnąć opinii innej specjalistycznej placówki. 
**§ 5.** Opinia 
ośrodka 
adopcyjnego, 
o której 
mowa 
w § 4, 
zawiera 
w szczególności: 
- 1) imię i nazwisko przysposabianego oraz miejsce jego zamieszkania lub 
pobytu; 
1a) imię i nazwisko przysposabiającego oraz miejsce jego zamieszkania 
i zwykłego pobytu; 
- 2) opinię kwalifikacyjną o kandydatach do przysposobienia dziecka; 
- 3) ustalenie relacji między przysposabianym a przysposabiającym; 
- 4) ustalenie relacji między rodzicami przysposabianego a przysposabiającym; 
- 5) inne istotne dla sądu informacje o przysposabianym lub przysposabiającym.

***
## Art. 5861. {#kpc-pierwsza-druga-art-5861}

Na postanowienie w przedmiocie określenia sposobu i okresu 
osobistej styczności przysposabiającego z przysposabianym przysługuje zażalenie.

***
## Art. 587. {#kpc-pierwsza-druga-art-587}

**§ 1.** W razie śmierci przysposabiającego lub osoby mającej być 
przysposobioną, sąd opiekuńczy postępowanie umarza. 
**§ 2.** Jednakże postępowanie zawiesza się w razie śmierci przysposabiającego, 
który złożył wniosek o przysposobienie wspólnie z małżonkiem, do czasu 
ustanowienia przez sąd opiekuńczy kuratora. 

 
 
 
s. 272/580 
 
2025-09-08

***
## Art. 588. {#kpc-pierwsza-druga-art-588}

**§ 1.** Postanowienie orzekające przysposobienie staje się skuteczne 
po uprawomocnieniu się. Postanowienia takiego sąd opiekuńczy nie może zmienić 
ani uchylić. 
**§ 2.** Sąd w terminie 7 dni od dnia uprawomocnienia się postanowienia 
orzekającego przysposobienie przesyła odpis tego postanowienia do ośrodka 
adopcyjnego, który dokonał kwalifikacji dziecka do przysposobienia krajowego. 
**§ 3.** W przypadku gdy przez przysposobienie przysposabiany zmienia 
dotychczasowe miejsce zamieszkania w Rzeczypospolitej Polskiej na miejsce 
zamieszkania w innym państwie, będącym stroną Konwencji o ochronie dzieci 
i współpracy w dziedzinie przysposobienia międzynarodowego, sporządzonej 
w Hadze dnia 29 maja 1993 r. (Dz. U. z 2000 r. poz. 448 oraz z 2002 r. poz. 17), 
sąd w terminie 7 dni od dnia uprawomocnienia się postanowienia orzekającego 
przysposobienie przesyła odpis tego postanowienia do organu centralnego, 
o którym mowa w art. 187 ust. 1 pkt 9 ustawy z dnia 9 czerwca 2011 r. 
o wspieraniu rodziny i systemie pieczy zastępczej.

***
## Art. 589. {#kpc-pierwsza-druga-art-589}

**§ 1.** Zgodę na przysposobienie dziecka w przyszłości bez wskazania 
osoby przysposabiającego rodzice mogą wyrazić także w sądzie opiekuńczym 
swego miejsca zamieszkania lub pobytu. Dotyczy to również oświadczenia 
o odwołaniu takiej zgody. 
**§ 2.** Oświadczenia, o których mowa w paragrafie poprzedzającym, powinny 
zawierać: 
- 1) imię i nazwisko dziecka oraz miejsce jego zamieszkania lub pobytu; 
- 2) treść wyrażonej zgody lub jej odwołanie. 
**§ 3.** Z przyjęcia oświadczenia o wyrażeniu zgody na przysposobienie dziecka 
w przyszłości lub o odwołaniu takiej zgody sąd opiekuńczy sporządza protokół. 
O odwołaniu zgody należy nadto uczynić wzmiankę w protokole, w którym 
wyrażono zgodę na przysposobienie. 
**§ 4.** Przyjmując oświadczenie o wyrażeniu zgody na przysposobienie dziecka 
w przyszłości, sąd opiekuńczy poucza o treści przepisu art. 211a § 2 Kodeksu 
karnego oraz przyjmuje oświadczenie, że wyrażając zgodę na przysposobienie, 
rodzic nie działa w celu osiągnięcia korzyści majątkowej lub osobistej. Fakt 
udzielenia pouczenia i przyjęcia oświadczenia odnotowuje się w protokole. 

 
 
 
s. 273/580 
 
2025-09-08 
 
Oddział 4 
Sprawy z zakresu opieki

***
## Art. 590. {#kpc-pierwsza-druga-art-590}

Obejmując opiekę opiekun składa następujące przyrzeczenie: 
„Przyrzekam, że powierzone mi obowiązki opiekuna wykonam z całą 
sumiennością i zgodnie z interesem społecznym, mając zawsze na względzie dobro 
osoby podlegającej mojej pieczy”.

***
## Art. 591. {#kpc-pierwsza-druga-art-591}

**§ 1.** Po złożeniu przyrzeczenia przez opiekuna sąd opiekuńczy 
wydaje mu zaświadczenie. 
**§ 2.** Po zwolnieniu opiekuna lub ustaniu opieki opiekun obowiązany jest 
zwrócić sądowi opiekuńczemu otrzymane zaświadczenie.

***
## Art. 592. {#kpc-pierwsza-druga-art-592}

O zwolnieniu od obowiązku objęcia opieki sąd opiekuńczy 
rozstrzyga na wniosek osoby ustanowionej opiekunem, zgłoszony w ciągu tygodnia 
od doręczenia jej postanowienia w tym przedmiocie.

***
## Art. 593. {#kpc-pierwsza-druga-art-593}

Zezwolenia we wszelkich ważniejszych sprawach, które dotyczą 
osoby lub majątku osoby pozostającej pod opieką, udziela sąd opiekuńczy na 
wniosek opiekuna. Postanowienie staje się skuteczne z chwilą uprawomocnienia 
się i nie może być zmienione ani uchylone, jeżeli na podstawie zezwolenia 
powstały skutki prawne względem osób trzecich.

***
## Art. 594. {#kpc-pierwsza-druga-art-594}

Minister właściwy do spraw finansów publicznych w porozumieniu 
z Ministrem Sprawiedliwości określi, w drodze rozporządzenia, zasady i tryb 
składania przez opiekunów gotówki w instytucji bankowej, uwzględniając 
zabezpieczenie interesów osób pozostających pod opieką oraz kompetencje sądu 
opiekuńczego określone w art. 593.

***
## Art. 595. {#kpc-pierwsza-druga-art-595}

Opiekun składa sądowi opiekuńczemu ustnie lub na piśmie 
sprawozdanie dotyczące osoby pozostającej pod opieką. Sprawozdanie z zarządu 
majątkiem tej osoby składa na piśmie, chyba że sąd zezwoli mu na złożenie sprawo-
zdania do protokołu.

***
## Art. 596. {#kpc-pierwsza-druga-art-596}

Do wzięcia udziału w badaniu rachunku końcowego z opieki sąd 
opiekuńczy wezwie osobę, która pozostawała pod opieką, jeżeli ma ona pełną 
zdolność do czynności prawnych, w innych zaś wypadkach – przedstawiciela 
ustawowego tej osoby lub jej spadkobierców, jeżeli są sądowi opiekuńczemu znani. 

 
 
 
s. 274/580 
 
2025-09-08

***
## Art. 597. {#kpc-pierwsza-druga-art-597}

**§ 1.** W postanowieniu o przyznaniu opiekunowi wynagrodzenia sąd 
upoważnia opiekuna do pobrania wynagrodzenia z dochodów lub majątku osoby 
pozostającej pod opieką, bądź ustala, że wynagrodzenie ma być wypłacone ze 
środków publicznych. 
**§ 2.** Postanowienie, o którym mowa w § 1, staje się wykonalne dopiero po 
jego uprawomocnieniu się.

***
## Art. 598. {#kpc-pierwsza-druga-art-598}

**§ 1.** Sąd opiekuńczy może wymierzyć grzywnę osobie, która uchyla 
się od objęcia opieki. 
**§ 2.** Sąd opiekuńczy może wymierzyć grzywnę opiekunowi, który nie 
wykonuje zarządzeń sądu opiekuńczego. Jeżeli zarządzenie zostanie wykonane, 
grzywna jeszcze nieuiszczona może być umorzona. 
Oddział 5 
Sprawy o odebranie osoby podlegającej władzy rodzicielskiej lub 
pozostającej pod opieką

***
## Art. 5981. {#kpc-pierwsza-druga-art-5981}

**§ 1.** W sprawach o odebranie osoby podlegającej władzy 
rodzicielskiej lub pozostającej pod opieką prokuratorowi doręcza się odpis wniosku 
i zawiadamia się go o terminach rozprawy. 
**§ 2.** (uchylony) 
**§ 3.** W sprawach, o których mowa w § 1, art. 570 nie stosuje się.

***
## Art. 5982. {#kpc-pierwsza-druga-art-5982}

**§ 1.** W czasie 
trwania 
postępowania 
o odebranie 
osoby 
podlegającej władzy rodzicielskiej lub pozostającej pod opieką toczącego się na 
podstawie konwencji haskiej z 1980 r. przed sądem, o którym mowa w art. 5182 § 
1 lub art. 5691 § 1 lub 3, nie można rozstrzygać w przedmiocie władzy 
rodzicielskiej lub opieki nad tą osobą. Postępowanie w tych sprawach sąd zawiesza 
z urzędu z chwilą otrzymania informacji przesłanej przez polski organ centralny, 
o którym mowa w art. 3 ust. 1 ustawy z dnia 26 stycznia 2018 r. o wykonywaniu 
niektórych czynności organu centralnego w sprawach rodzinnych z zakresu obrotu 
prawnego na podstawie prawa Unii Europejskiej i umów międzynarodowych, lub 
sąd, o którym mowa w art. 5691 § 1 lub 3, o wniesieniu wniosku w przedmiocie 
odebrania osoby podlegającej władzy rodzicielskiej lub pozostającej pod opieką. 
**§ 2.** Po zakończeniu postępowania o odebranie osoby podlegającej władzy 
rodzicielskiej lub pozostającej pod opieką sąd podejmie zawieszone postępowanie. 

 
 
 
s. 275/580 
 
2025-09-08 
**§ 3.** W przypadku innym niż określony w § 1, jeżeli do rozstrzygnięcia 
wniosku o odebranie osoby podlegającej władzy rodzicielskiej lub pozostającej pod 
opieką niezbędne jest jego łączne rozpoznanie ze sprawą dotyczącą władzy 
rodzicielskiej, postępowanie toczy się z zachowaniem przepisu art. 579. 
**§ 4.** Przepisu § 1 nie stosuje się w przypadku, o którym mowa w art. 5691 § 11 
i art. 5182 w związku z art. 5691, ani w przypadku toczącego się przed sądem innego 
państwa postępowania w sprawie o odebranie osoby podlegającej władzy 
rodzicielskiej lub pozostającej pod opieką prowadzonej na podstawie konwencji 
haskiej z 1980 r.

***
## Art. 5983. {#kpc-pierwsza-druga-art-5983}

Jeżeli miejsce pobytu osoby podlegającej władzy rodzicielskiej lub 
pozostającej pod opieką nie jest znane, sąd przeprowadzi stosowne dochodzenie 
w celu ustalenia jej miejsca pobytu. W szczególności sąd może zażądać ustalenia 
miejsca jej pobytu przez Policję.

***
## Art. 5984. {#kpc-pierwsza-druga-art-5984}

Orzeczenie co do istoty sprawy może być wydane tylko po 
przeprowadzeniu rozprawy.

***
## Art. 5985. {#kpc-pierwsza-druga-art-5985}

**§ 1.** W postanowieniu o odebranie osoby podlegającej władzy 
rodzicielskiej lub pozostającej pod opieką sąd określa termin, w jakim zobowiązany 
powinien oddać uprawnionemu osobę podlegającą władzy rodzicielskiej lub 
pozostającą pod opieką. 
**§ 2.** W postanowieniu o odebraniu osoby podlegającej władzy rodzicielskiej 
lub pozostającej pod opieką w sprawie prowadzonej na podstawie konwencji 
haskiej z 1980 r. sąd nakazuje zobowiązanemu zapewnić powrót tej osoby do 
państwa, w którym bezpośrednio przed naruszeniem prawa wynikającego z władzy 
rodzicielskiej 
lub 
opieki 
miała 
miejsce 
stałego 
pobytu, 
w terminie 
nieprzekraczającym dwóch tygodni od dnia uprawomocnienia się postanowienia. 
**§ 3.** Postanowienie w przedmiocie odebrania osoby podlegającej władzy 
rodzicielskiej lub pozostającej pod opieką w sprawie prowadzonej na podstawie 
konwencji haskiej z 1980 r. wymaga uzasadnienia, które sporządza się w terminie 
dwóch tygodni od dnia ogłoszenia. Postanowienie wraz z uzasadnieniem doręcza 
się z urzędu uczestnikom postępowania oraz prokuratorowi. Przepisu art. 328 § 
11 nie stosuje się. 

 
 
 
s. 276/580 
 
2025-09-08 
**§ 4.** Postanowienie, o którym mowa w § 2, staje się skuteczne i wykonalne po 
uprawomocnieniu się, z zastrzeżeniem art. 3881 i art. 3883, o czym sąd poucza 
strony. 
**§ 5.** W sprawach, o których mowa w § 2, przepisu art. 577 nie stosuje się.

***
## Art. 5985a. {#kpc-pierwsza-druga-art-5985a}

Sąd, o którym mowa w art. 5182 § 1, zawiadamia uczestników 
postępowania, prokuratora, podmioty wymienione w art. 5191 § 22 oraz sąd 
okręgowy, który wydał orzeczenie w sprawie w pierwszej instancji, o wstrzymaniu 
wykonania postanowienia w przedmiocie odebrania osoby podlegającej władzy 
rodzicielskiej lub pozostającej pod opieką oraz uzyskaniu wykonalności tego 
postanowienia.

***
## Art. 5986. {#kpc-pierwsza-druga-art-5986}

Jeżeli zobowiązany nie zastosuje się do postanowienia, o którym 
mowa w art. 5985 § 1 lub 2, sąd, na wniosek uprawnionego, zleca kuratorowi 
sądowemu przymusowe odebranie osoby podlegającej władzy rodzicielskiej lub 
pozostającej pod opieką.

***
## Art. 5987. {#kpc-pierwsza-druga-art-5987}

W razie potrzeby sąd zwraca się o przymusowe odebranie osoby 
podlegającej władzy rodzicielskiej lub pozostającej pod opieką przez kuratora 
sądowego działającego w sądzie, w którego okręgu osoba ta faktycznie przebywa.

***
## Art. 5988. {#kpc-pierwsza-druga-art-5988}

Kurator sądowy jest uprawniony do odebrania osoby podlegającej 
władzy rodzicielskiej lub pozostającej pod opieką od każdej osoby, u której ona się 
znajduje.

***
## Art. 5989. {#kpc-pierwsza-druga-art-5989}

Przymusowe odebranie osoby podlegającej władzy rodzicielskiej 
lub pozostającej pod opieką i oddanie jej uprawnionemu może nastąpić tylko 
w obecności uprawnionego albo osoby przez niego upoważnionej lub 
przedstawiciela instytucji przez niego upoważnionej. Jeżeli żadna z tych osób nie 
stawi się w terminie wyznaczonym przez kuratora sądowego, czynność nie będzie 
dokonana. O terminie odebrania nie zawiadamia się zobowiązanego. Kurator 
sądowy dokonuje przekazania odebranej osoby uprawnionemu albo osobie przez 
niego upoważnionej lub przedstawicielowi instytucji przez niego upoważnionej, po 
czym zawiadamia zobowiązanego o dokonaniu tej czynności. 

 
 
 
s. 277/580 
 
2025-09-08

***
## Art. 59810. {#kpc-pierwsza-druga-art-59810}

Na żądanie kuratora sądowego Policja jest zobowiązana do 
udzielenia mu pomocy przy czynnościach związanych z przymusowym 
odebraniem osoby podlegającej władzy rodzicielskiej lub pozostającej pod opieką.

***
## Art. 59811. {#kpc-pierwsza-druga-art-59811}

**§ 1.** Jeżeli przymusowe odebranie osoby podlegającej władzy 
rodzicielskiej lub pozostającej pod opieką napotyka przeszkody na skutek ukrycia 
tej osoby lub na skutek innej czynności przedsięwziętej w celu udaremnienia 
wykonania orzeczenia, kurator sądowy zawiadomi prokuratora. 
**§ 2.** Jeżeli zobowiązany nie ujawnia miejsca pobytu osoby podlegającej 
władzy rodzicielskiej lub pozostającej pod opieką, która ma być odebrana, sąd na 
wniosek kuratora sądowego zarządzi jego przymusowe sprowadzenie celem 
złożenia oświadczenia o miejscu pobytu tej osoby. Pod względem skutków karnych 
oświadczenie jest równoznaczne ze złożeniem zeznań pod przyrzeczeniem, o czym 
sędzia powinien uprzedzić składającego oświadczenie. 
**§ 3.** Jeżeli zobowiązany lub inne osoby przeszkadzają w wykonaniu 
orzeczenia w miejscu pobytu osoby podlegającej władzy rodzicielskiej lub 
pozostającej pod opieką, na żądanie kuratora sądowego Policja usunie te osoby 
z miejsca wykonywania orzeczenia.

***
## Art. 59811a. {#kpc-pierwsza-druga-art-59811a}

**§ 1.** W celu ustalenia miejsca pobytu osoby podlegającej 
przymusowemu odebraniu sąd, na wniosek kuratora sądowego, może postanowić 
o dokonaniu przeszukania pomieszczeń i innych miejsc, jeżeli istnieją uzasadnione 
podstawy do przypuszczenia, że osoba ta się tam znajduje. 
**§ 2.** Przeszukania dokonuje Policja na podstawie postanowienia sądu. 
**§ 3.** Postanowienie sądu doręcza się osobie, u której przeszukanie ma być 
dokonane, w chwili przystąpienia do tej czynności. 
**§ 4.** Podczas przeszukania może być obecna osoba, o której mowa w § 3, 
kurator sądowy, który wykonuje postanowienie o przymusowym odebraniu, oraz 
uprawniony, o którym mowa w art. 5989. Podczas przeszukania może być także 
obecna osoba wskazana przez tego, u kogo dokonuje się przeszukania, o ile nie 
uniemożliwia to przeszukania albo nie utrudnia go w istotny sposób. 
**§ 5.** Jeżeli przy przeszukaniu nie ma osoby, o której mowa w § 3, należy do 
przeszukania przywołać przynajmniej jednego domownika lub inną osobę. 

 
 
 
s. 278/580 
 
2025-09-08 
**§ 6.** Przeszukanie powinno być dokonane zgodnie z celem tej czynności, 
z zachowaniem umiaru i poszanowania godności osób, których ta czynność 
dotyczy, oraz bez wyrządzania niepotrzebnych szkód i dolegliwości. 
**§ 7.** Protokół przeszukania sporządza Policja, a jego odpis niezwłocznie 
przesyła sądowi. 
**§ 8.** Protokół przeszukania zawiera: wskazanie postanowienia sądu, 
oznaczenie czynności, jej czasu i miejsca oraz osób w niej uczestniczących, 
przebieg czynności oraz oświadczenia i wnioski osób w niej uczestniczących, 
a także w miarę potrzeby stwierdzenie innych okoliczności dotyczących przebiegu 
czynności. 
**§ 9.** Na postanowienie o dokonaniu przeszukania przysługuje zażalenie 
osobom, których prawa zostały naruszone.

***
## Art. 59812. {#kpc-pierwsza-druga-art-59812}

**§ 1.** Przy odbieraniu osoby podlegającej władzy rodzicielskiej lub 
pozostającej pod opieką kurator sądowy powinien zachować szczególną ostrożność 
i uczynić wszystko, aby dobro tej osoby nie zostało naruszone, a zwłaszcza aby nie 
doznała ona krzywdy fizycznej lub moralnej. W razie potrzeby kurator sądowy 
może zażądać pomocy organu opieki społecznej lub innej powołanej do tego 
instytucji. 
**§ 2.** Jeżeli wskutek wykonania orzeczenia miałoby doznać poważnego 
uszczerbku dobro osoby podlegającej władzy rodzicielskiej lub pozostającej pod 
opieką, kurator sądowy wstrzyma się z wykonaniem orzeczenia do czasu ustania 
zagrożenia, chyba że wstrzymanie wykonania orzeczenia stwarza poważniejsze 
zagrożenie dla tej osoby.

***
## Art. 59812a. {#kpc-pierwsza-druga-art-59812a}

Postępowanie określone w art. 5986–59812 może być podjęte na 
nowo na podstawie tego samego postanowienia, o którym mowa w art. 5985 § 1 lub 
2, jeżeli zobowiązany w okresie trzech miesięcy od wydania lub uprawomocnienia 
się postanowienia, o którym mowa odpowiednio w art. 5985 § 1 lub 2, postąpił 
sprzecznie z treścią postanowienia dotyczącego władzy rodzicielskiej, miejsca 
zamieszkania, opieki lub kontaktów z dzieckiem, a okoliczności uzasadniające jego 
wydanie nie uległy zmianie.

***
## Art. 59813. {#kpc-pierwsza-druga-art-59813}

Przepisy art. 5986–59812 stosuje się odpowiednio do wykonania 
orzeczeń wydanych na zasadzie art. 569 § 2, dotyczących odebrania osoby 

 
 
 
s. 279/580 
 
2025-09-08 
 
podlegającej władzy rodzicielskiej lub pozostającej pod opieką, a także orzeczeń 
o umieszczeniu 
małoletniego 
w placówce 
opiekuńczo-wychowawczej 
lub 
w rodzinie zastępczej.

***
## Art. 59814. {#kpc-pierwsza-druga-art-59814}

**§ 1.** Dla przymusowego odebrania, zgodnie z art. 5986–59812, 
osoby podlegającej władzy rodzicielskiej lub pozostającej pod opieką, na podstawie 
orzeczenia sądu albo innego organu państwa obcego, niezbędne jest stwierdzenie 
wykonalności tego orzeczenia. Przepisy art. 1150–11512 i 11514 stosuje się 
odpowiednio. 
**§ 2.** Wniosek, o którym mowa w art. 5986, uprawniony składa do sądu, który 
byłby właściwy w sprawie o odebranie osoby podlegającej władzy rodzicielskiej 
lub pozostającej pod opieką. 
Oddział 6 
Sprawy dotyczące wykonywania kontaktów z dzieckiem

***
## Art. 59815. {#kpc-pierwsza-druga-art-59815}

**§ 1.** 17) Jeżeli osoba, pod której pieczą dziecko pozostaje, nie 
wykonuje albo niewłaściwie wykonuje obowiązki wynikające z orzeczenia albo 
z ugody zawartej przed sądem lub przed mediatorem w przedmiocie kontaktów 
z dzieckiem, sąd opiekuńczy, uwzględniając sytuację majątkową tej osoby, zagrozi 
jej nakazaniem zapłaty na rzecz osoby uprawnionej do kontaktu z dzieckiem 
oznaczonej sumy pieniężnej za każde naruszenie obowiązku. 
**§ 2.** Jeżeli osoba uprawniona do kontaktu z dzieckiem albo osoba, której tego 
kontaktu zakazano, narusza obowiązki wynikające z orzeczenia albo z ugody 
zawartej przed sądem lub przed mediatorem w przedmiocie kontaktów 
z dzieckiem, sąd opiekuńczy zagrozi tej osobie nakazaniem zapłaty oznaczonej 
sumy pieniężnej na rzecz osoby, pod której pieczą dziecko pozostaje, stosując 
odpowiednio przepis § 1. 
**§ 3.** Na postanowienia sądu, o których mowa w § 1 i 2, przysługuje zażalenie. 
- 17) Art. 59816 § 1 w związku z art. 59815 § 1 w zakresie, w jakim obejmują sytuacje, w których 
niewłaściwe wykonywanie lub niewykonywanie obowiązków związane jest z zachowaniem 
dziecka, niewywołanym przez osobę, pod której pieczą dziecko to się znajduje, są niezgodne z 
art. 48 ust. 1 zdanie drugie oraz art. 72 ust. 3 Konstytucji Rzeczypospolitej Polskiej, na podstawie 
wyroku Trybunału Konstytucyjnego z dnia 22 czerwca 2022 r. sygn. akt SK 3/20 (Dz. U. poz. 
1371). 

 
 
 
s. 280/580 
 
2025-09-08

***
## Art. 59816. {#kpc-pierwsza-druga-art-59816}

**§ 1.** 17) Jeżeli osoba, której sąd opiekuńczy zagroził nakazaniem 
zapłaty oznaczonej sumy pieniężnej, nie wypełnia nadal swego obowiązku, sąd 
opiekuńczy nakazuje jej zapłatę należnej sumy pieniężnej, ustalając jej wysokość 
stosownie do liczby naruszeń. Sąd może w wyjątkowych wypadkach zmienić 
wysokość sumy pieniężnej, o której mowa w art. 59815, ze względu na zmianę 
okoliczności. 
**§ 2.** Przepis § 1 stosuje się odpowiednio, jeżeli osoba, której sąd zagroził 
nakazaniem zapłaty oznaczonej sumy pieniężnej zgodnie z art. 5821 § 3, dopuściła 
się naruszenia obowiązku wynikającego z orzeczenia o kontaktach. 
**§ 3.** Na postanowienie sądu przysługuje zażalenie. 
**§ 4.** Prawomocne postanowienie sądu, w którym nakazano zapłatę należnej 
sumy pieniężnej, jest tytułem wykonawczym bez potrzeby nadawania mu klauzuli 
wykonalności.

***
## Art. 59817. {#kpc-pierwsza-druga-art-59817}

**§ 1.** Jeżeli do kontaktu nie doszło wskutek niewykonania lub 
niewłaściwego wykonania przez osobę, pod której pieczą dziecko pozostaje, 
obowiązków wynikających z orzeczenia albo z ugody zawartej przed sądem lub 
przed mediatorem w przedmiocie kontaktów z dzieckiem, sąd opiekuńczy przyzna 
od tej osoby uprawnionemu do kontaktu zwrot jego uzasadnionych wydatków 
poniesionych w związku z przygotowaniem kontaktu, w tym kosztów, o których 
mowa w art. 5821 § 2 pkt 1. 
**§ 2.** Przepis § 1 stosuje się odpowiednio, jeżeli uprawniony do kontaktu 
z dzieckiem narusza obowiązki dotyczące kontaktu wynikające z orzeczenia albo 
z ugody zawartej przed sądem lub przed mediatorem. 
**§ 3.** Na postanowienie sądu przysługuje zażalenie. 
**§ 4.** Prawomocne postanowienie sądu jest tytułem wykonawczym bez 
potrzeby nadawania mu klauzuli wykonalności.

***
## Art. 59818. {#kpc-pierwsza-druga-art-59818}

**§ 1.** W sprawach 
wykonywania 
kontaktów 
z dzieckiem 
art. 570 nie stosuje się. Wniosku wymaga także wydanie każdego kolejnego 
postanowienia, o którym mowa w poprzedzających przepisach niniejszego 
oddziału. 
**§ 2.** Przed wydaniem postanowień, o których mowa w oddziale niniejszym, 
sąd wysłucha uczestników postępowania. 

 
 
 
s. 281/580 
 
2025-09-08

***
## Art. 59819. {#kpc-pierwsza-druga-art-59819}

**§ 1.** Do wniosku o wszczęcie postępowania uregulowanego 
w niniejszym oddziale należy dołączyć odpis wykonalnego orzeczenia albo 
wykonalnej ugody zawartej przed sądem lub przed mediatorem w przedmiocie 
kontaktów z dzieckiem. 
**§ 2.** Jeżeli postępowanie ma się toczyć na podstawie orzeczenia sądu albo 
innego organu państwa obcego albo ugody zawartej przed sądem lub innym 
organem państwa obcego lub przez niego zatwierdzonej, niezbędne jest 
stwierdzenie wykonalności tego orzeczenia albo ugody. Przepisy art. 1150–11512, 
11514 i 1152 stosuje się odpowiednio.

***
## Art. 59820. {#kpc-pierwsza-druga-art-59820}

Sąd umarza postępowanie, jeżeli w ciągu sześciu miesięcy od 
uprawomocnienia ostatniego postanowienia nie wpłynął kolejny wniosek 
w sprawach wykonywania kontaktów z dzieckiem.

***
## Art. 59821. {#kpc-pierwsza-druga-art-59821}

Do spraw uregulowanych w niniejszym oddziale art. 577 nie 
stosuje się.

***
## Art. 59822. {#kpc-pierwsza-druga-art-59822}

Przepisy niniejszego oddziału stosuje się odpowiednio do 
orzeczenia, w którym sąd określił, że dziecko będzie mieszkać z każdym 
z rodziców w powtarzających się okresach. 
Rozdział 3 
Sprawy z zakresu kurateli

***
## Art. 599. {#kpc-pierwsza-druga-art-599}

Sądem opiekuńczym właściwym do ustanowienia kuratora dla 
dziecka poczętego, lecz jeszcze nieurodzonego, jest sąd właściwy według miejsca 
zamieszkania lub pobytu matki.

***
## Art. 600. {#kpc-pierwsza-druga-art-600}

**§ 1.** Kuratora dla osoby niepełnosprawnej sąd opiekuńczy 
ustanawia na wniosek tej osoby, a za zgodą osoby niepełnosprawnej – także na 
wniosek organizacji pozarządowej, wymienionej w art. 546 § 3. 
**§ 2.** W przypadku gdy stan osoby niepełnosprawnej wyłącza możliwość 
złożenia wniosku lub wyrażenia zgody, o których mowa w § 1, sąd może ustanowić 
kuratora z urzędu. Sąd może ustanowić kuratora z urzędu także w przypadku, 
o którym mowa w art. 558 § 2. 
**§ 3.** W toku postępowania o ustanowienie kuratora sąd wysłuchuje osobę 
niepełnosprawną. W przypadku osoby niepełnosprawnej o złożonych potrzebach 

 
 
 
s. 282/580 
 
2025-09-08 
 
w komunikowaniu się, wysłuchanie przeprowadza się przy uwzględnieniu tych 
potrzeb. 
**§ 4.** Sąd może odstąpić od wysłuchania tylko wówczas, gdy brak możliwości 
jakiegokolwiek porozumienia się z osobą niepełnosprawną jest potwierdzony przez 
lekarza. 
**§ 5.** Przed wydaniem postanowienia sąd może zlecić kuratorowi sądowemu 
przeprowadzenie wywiadu w celu ustalenia sposobu funkcjonowania osoby 
niepełnosprawnej, chyba że wystarczające dla dokonania tych ustaleń jest 
wysłuchanie osoby niepełnosprawnej lub dokumentacja będąca w posiadaniu sądu 
dotycząca tej osoby. 
**§ 6.** W razie potrzeby, o ile sąd uzna to za konieczne, zasięga opinii biegłego 
psychologa lub biegłego innej specjalności. 
**§ 7.** Minister Sprawiedliwości określi, w drodze rozporządzenia, sposób 
przygotowania wysłuchania osoby niepełnosprawnej oraz warunki, w jakich 
powinno odbywać się wysłuchanie, mając na względzie konieczność zapewnienia 
swobody wypowiedzi i wsparcia potrzeb w komunikowaniu się wysłuchiwanych 
osób niepełnosprawnych.

***
## Art. 601. {#kpc-pierwsza-druga-art-601}

Dla osoby, która z powodu nieobecności nie może prowadzić 
swoich spraw, a nie ma pełnomocnika, ustanawia kuratora na wniosek osoby 
zainteresowanej sąd opiekuńczy miejsca ostatniego zamieszkania lub pobytu osoby 
nieobecnej.

***
## Art. 602. {#kpc-pierwsza-druga-art-602}

Właściwość miejscową sądu opiekuńczego do ustanowienia 
kuratora dla dochodzenia ojcostwa w razie śmierci domniemanego ojca określa się 
według miejsca zamieszkania lub pobytu dziecka, chociażby dziecko nie podlegało 
już ani władzy rodzicielskiej, ani opiece.

***
## Art. 603. {#kpc-pierwsza-druga-art-603}

**§ 1.** Kuratora dla osoby prawnej ustanawia sąd rejestrowy, 
w którego okręgu osoba ta ma lub miała ostatnią siedzibę. 
**§ 2.** Wszczęcie postępowania z urzędu może nastąpić, gdy jest to uzasadnione 
ważnym interesem społecznym lub bezpieczeństwem obrotu i brak jest możliwości 
powołania organu uprawnionego do reprezentacji osoby prawnej. 
**§ 3.** Postanowienie jest skuteczne i wykonalne z chwilą jego ogłoszenia, 
a gdy ogłoszenia nie było, z chwilą jego wydania. 

 
 
 
s. 283/580 
 
2025-09-08 
**§ 4.** Sąd może zmienić zakres umocowania kuratora. 
**§ 5.** Jeżeli dla osoby prawnej ustanowiono wcześniej kuratora, o którym 
mowa w art. 69 § 1, sąd rejestrowy zawiadamia właściwy sąd o ustanowieniu 
kuratora na podstawie art. 42 § 1 Kodeksu cywilnego.

***
## Art. 6031. {#kpc-pierwsza-druga-art-6031}

Kuratora, o którym mowa w art. 26 ust. 1 ustawy z dnia 
23 października 2014 r. o odwróconym kredycie hipotecznym (Dz. U. z 2023 r. 
poz. 152), ustanawia sąd właściwy dla miejsca położenia nieruchomości.

***
## Art. 6032. {#kpc-pierwsza-druga-art-6032}

**§ 1.** Wnioskodawca we wniosku o ustanowienie kuratora wskazuje 
zakres spraw, w jakich kurator powinien podjąć czynności. Sąd nie jest związany 
zakresem żądania. 
**§ 2.** Przewodniczący wzywa wnioskodawcę do uiszczenia zaliczki na 
pokrycie kosztów działania kuratora w wyznaczonej wysokości i wyznaczonym 
terminie. Jeżeli o ustanowienie kuratora wnosi więcej niż jeden wnioskodawca, 
przewodniczący wzywa każdego z nich do uiszczenia zaliczki w równych 
częściach lub w innym stosunku według swego uznania. W razie nieuiszczenia 
zaliczki przewodniczący zwraca wniosek.

***
## Art. 6033. {#kpc-pierwsza-druga-art-6033}

Ustanawiając kuratora dla osoby prawnej wpisanej do Krajowego 
Rejestru Sądowego, sąd rejestrowy zarządza jego wpis do tego rejestru.

***
## Art. 6034. {#kpc-pierwsza-druga-art-6034}

**§ 1.** Kurator ma prawo do wynagrodzenia za swoją działalność oraz 
do zwrotu uzasadnionych wydatków, które poniósł w związku ze swoimi 
czynnościami. 
**§ 2.** Koszty działania kuratora, o których mowa w § 1, obciążają tymczasowo: 
- 1) wnioskodawcę – odpowiednio do zakresu spraw wskazanych we wniosku; 
- 2) Skarb Państwa – w pozostałym zakresie. 
**§ 3.** Wynagrodzenie kuratora obowiązanego do rozliczenia podatku od 
towarów i usług podwyższa się o kwotę podatku od towarów i usług, określoną 
zgodnie z obowiązującą stawką tego podatku. 
**§ 4.** Przyznając postanowieniem koszty kuratorowi, sąd rejestrowy orzeka 
jednocześnie o obowiązku zwrotu kosztów poniesionych tymczasowo przez 
wnioskodawcę lub Skarb Państwa solidarnie od osoby prawnej, dla której kurator 
został ustanowiony, oraz osób obowiązanych do powołania organu uprawnionego 
do reprezentacji. Osoby te nie ponoszą jednak kosztów działania kuratora, jeżeli 

 
 
 
s. 284/580 
 
2025-09-08 
 
podjęły, z zachowaniem należytej staranności, czynności zmierzające do powołania 
lub wyboru organu uprawnionego do reprezentowania podmiotu. 
**§ 5.** Sąd rejestrowy może postanowieniem przyznawać kuratorowi zaliczki na 
wydatki w miarę dokonywanych czynności.

***
## Art. 604. {#kpc-pierwsza-druga-art-604}

W zaświadczeniu dla kuratora sąd określa zakres jego uprawnień.

***
## Art. 605. {#kpc-pierwsza-druga-art-605}

W przedmiotach nieunormowanych w rozdziale niniejszym stosuje 
się odpowiednio przepisy o postępowaniu w sprawach z zakresu opieki. 
#### DZIAŁ III
Sprawy z zakresu prawa rzeczowego 
Rozdział 1 
Przepisy ogólne

***
## Art. 606. {#kpc-pierwsza-druga-art-606}

W sprawach z zakresu prawa rzeczowego właściwy jest sąd 
położenia rzeczy.

***
## Art. 607. {#kpc-pierwsza-druga-art-607}

Do wniosków dotyczących nieruchomości, dla których prowadzony 
jest zbiór dokumentów, należy dołączyć zaświadczenie o stanie prawnym, jaki 
wynika ze zbioru dokumentów.

***
## Art. 608. {#kpc-pierwsza-druga-art-608}

Sprawy z zakresu prawa rzeczowego rozpoznawane są na 
rozprawie, chyba że przepis szczególny stanowi inaczej. 
Rozdział 2 
Stwierdzenie zasiedzenia

***
## Art. 609. {#kpc-pierwsza-druga-art-609}

**§ 1.** Do zgłoszenia wniosku o stwierdzenie zasiedzenia własności 
uprawniony jest każdy zainteresowany. 
**§ 2.** Jeżeli wnioskodawca nie wskazuje innych zainteresowanych, orzeczenie 
może zapaść dopiero po wezwaniu innych zainteresowanych przez ogłoszenie. Sąd 
może zarządzić ogłoszenie również w innych wypadkach, jeżeli uzna to za 
wskazane. 
**§ 3.** Ogłoszenie powinno zawierać dokładne określenie rzeczy, imię 
i nazwisko posiadacza rzeczy, a jeżeli chodzi o rzeczy ruchome – również jego 
miejsce zamieszkania. 

 
 
 
s. 285/580 
 
2025-09-08

***
## Art. 610. {#kpc-pierwsza-druga-art-610}

**§ 1.** W zakresie nieuregulowanym w niniejszym rozdziale do 
ogłoszenia i orzeczenia stosuje się odpowiednio przepisy o stwierdzeniu nabycia 
spadku i przedmiotu zapisu windykacyjnego. 
**§ 2.** Jeżeli w terminie wskazanym w ogłoszeniu nikt się nie zgłosi albo 
zgłaszający się nie wykaże własności, sąd stwierdzi zasiedzenie, jeżeli zostało ono 
udowodnione. 
Rozdział 2a 
Przepadek rzeczy 
Oddział 1 
Przepadek rzeczy na podstawie prawa celnego

***
## Art. 6101. {#kpc-pierwsza-druga-art-6101}

**§ 1.** Przepisy niniejszego oddziału stosuje się w sprawach 
o przepadek rzeczy będących towarami, które na podstawie przepisów prawa 
celnego podlegają przepadkowi. 
**§ 2.** W sprawach, o których mowa w § 1, właściwy jest sąd miejsca zajęcia 
lub zatrzymania rzeczy będących towarami przez organ celny.

***
## Art. 6102. {#kpc-pierwsza-druga-art-6102}

**§ 1.** Postępowanie wszczyna się na wniosek organu celnego. Do 
wniosku dołącza się protokół z pouczenia o obowiązku wskazania w Polsce 
pełnomocnika do doręczeń oraz o skutkach niedopełnienia tego obowiązku, jeżeli 
protokół taki został sporządzony. 
**§ 2.** Organ celny może domagać się w jednym wniosku orzeczenia przepadku 
rzeczy będących towarami zajętymi lub zatrzymanymi w tych samych 
okolicznościach faktycznych, jeżeli ponadto sąd jest właściwy dla każdej sprawy.

***
## Art. 6103. {#kpc-pierwsza-druga-art-6103}

Uczestnikowi zamieszkałemu w państwie niebędącym członkiem 
Unii Europejskiej, który w postępowaniu w sprawach celnych nie ustanowił 
pełnomocnika do prowadzenia sprawy zamieszkałego w Rzeczypospolitej Polskiej 
ani nie wskazał w Rzeczypospolitej Polskiej pełnomocnika do doręczeń, 
przeznaczone dla niego pisma sądowe pozostawia się w aktach sprawy ze skutkiem 
doręczenia. W razie ustanowienia pełnomocnika do prowadzenia sprawy 
zamieszkałego w Rzeczypospolitej Polskiej, który nie może być pełnomocnikiem 
procesowym, jego ustanowienie uważa się za wskazanie pełnomocnika do 
doręczeń. 

 
 
 
s. 286/580 
 
2025-09-08

***
## Art. 6104. {#kpc-pierwsza-druga-art-6104}

Wyznaczenie rozprawy zależy od uznania sądu.

***
## Art. 6105. {#kpc-pierwsza-druga-art-6105}

Do wykonania orzeczenia o przepadku towaru jest obowiązany 
właściwy organ celny. Wykonanie orzeczenia następuje w trybie i na zasadach 
określonych w przepisach o postępowaniu egzekucyjnym w administracji, z 
uwzględnieniem przepisów prawa celnego. 
Oddział 2 
Przepadek pojazdów

***
## Art. 6106. {#kpc-pierwsza-druga-art-6106}

**§ 1.** Przepisy niniejszego oddziału stosuje się w sprawach 
o przepadek pojazdów, które na podstawie przepisów prawa o ruchu drogowym 
podlegają przepadkowi na rzecz powiatu. 
**§ 2.** W sprawach, o których mowa w § 1, właściwy jest sąd miejsca, z którego 
usunięto pojazd. 
**§ 3.** Sprawy, o których mowa w § 1, są rozpoznawane na posiedzeniu 
niejawnym, chyba że sąd postanowi inaczej.

***
## Art. 6107. {#kpc-pierwsza-druga-art-6107}

**§ 1.** Postępowanie wszczyna się na wniosek starosty. 
**§ 2.** Starosta może domagać się w jednym wniosku orzeczenia przepadku 
pojazdów usuniętych w tych samych okolicznościach faktycznych, jeżeli ponadto 
sąd jest właściwy dla każdej sprawy. 
Rozdział 3 
Zarząd związany ze współwłasnością i użytkowaniem

***
## Art. 611. {#kpc-pierwsza-druga-art-611}

Zarządca nieruchomości ustanowiony na podstawie art. 203 
i 269 § 1 Kodeksu cywilnego obowiązany jest niezwłocznie zgłosić wniosek 
o ujawnienie zarządu w księdze wieczystej lub w zbiorze dokumentów.

***
## Art. 612. {#kpc-pierwsza-druga-art-612}

**§ 1.** Od chwili ustanowienia zarządcy współwłaściciele lub 
użytkownik mogą używać rzeczy tylko o tyle, o ile nie przeszkadza to 
wykonywaniu zarządu. Na wniosek innego współwłaściciela lub zarządcy 
współwłaściciel lub użytkownik może być pozbawiony używania rzeczy, jeżeli 
przeszkadza zarządcy w wykonywaniu czynności. 
**§ 2.** Na postanowienie sądu przysługuje zażalenie. 

 
 
 
s. 287/580 
 
2025-09-08

***
## Art. 613. {#kpc-pierwsza-druga-art-613}

**§ 1.** Nadwyżkę dochodów po pokryciu wydatków wypłaca się 
współwłaścicielom lub użytkownikom w terminach przez sąd określonych. 
**§ 2.** Sąd może postanowić, aby zarządca wydawał współwłaścicielom 
nadwyżkę dochodów w naturze.

***
## Art. 614. {#kpc-pierwsza-druga-art-614}

Sąd uchyli zarząd, gdy odpadnie podstawa dalszego jego trwania.

***
## Art. 615. {#kpc-pierwsza-druga-art-615}

Jeżeli powyższe przepisy nie stanowią inaczej, do wyznaczenia 
zarządcy i sprawowania zarządu stosuje się odpowiednio przepisy o zarządzie 
w toku egzekucji z nieruchomości.

***
## Art. 616. {#kpc-pierwsza-druga-art-616}

Z wyjątkiem spraw przewidzianych w art. 199, 201 i 202 Kodeksu 
cywilnego, jak również spraw dotyczących powołania i odwołania zarządcy, 
wyznaczenie rozprawy zależy od uznania sądu. 
Rozdział 4 
Zniesienie współwłasności

***
## Art. 617. {#kpc-pierwsza-druga-art-617}

We wniosku o zniesienie współwłasności należy dokładnie określić 
rzecz mającą ulec podziałowi oraz przedstawić dowody prawa własności.

***
## Art. 618. {#kpc-pierwsza-druga-art-618}

**§ 1.** W postępowaniu o zniesienie współwłasności sąd rozstrzyga 
także spory o prawo żądania zniesienia współwłasności i o prawo własności, jak 
również wzajemne roszczenia współwłaścicieli z tytułu posiadania rzeczy. 
Rozstrzygając spór o prawo żądania zniesienia współwłasności lub o prawo 
własności, sąd może wydać w tym przedmiocie postanowienie wstępne. 
**§ 2.** Z chwilą wszczęcia postępowania o zniesienie współwłasności odrębne 
postępowanie w sprawach wymienionych w paragrafie poprzedzającym jest 
niedopuszczalne. Sprawy będące w toku przekazuje się do dalszego rozpoznania 
sądowi prowadzącemu postępowanie o zniesienie współwłasności. Jeżeli jednak 
postępowanie o zniesienie współwłasności zostało wszczęte po wydaniu wyroku, 
przekazanie następuje tylko wówczas, gdy sąd drugiej instancji uchyli wyrok 
i sprawę przekaże do ponownego rozpoznania. Postępowanie w sprawach, które nie 
zostały przekazane, sąd umarza z chwilą zakończenia postępowania o zniesienie 
współwłasności. 
**§ 3.** Po 
zapadnięciu 
prawomocnego 
postanowienia 
o zniesieniu 
współwłasności uczestnik nie może dochodzić roszczeń przewidzianych 

 
 
 
s. 288/580 
 
2025-09-08 
 
w paragrafie pierwszym, chociażby nie były one zgłoszone w postępowaniu 
o zniesienie współwłasności.

***
## Art. 619. {#kpc-pierwsza-druga-art-619}

**§ 1.** W postępowaniu o zniesienie współwłasności gospodarstwa 
rolnego sąd ustala jego skład i wartość, w szczególności obszar i rodzaj 
nieruchomości wchodzących w skład tego gospodarstwa oraz obszar i rodzaj 
nieruchomości stanowiących już własność współwłaścicieli i ich małżonków, 
a w miarę potrzeby także okoliczności przewidziane w art. 216 Kodeksu 
cywilnego. 
**§ 2.** Podział w naturze nastąpi po zasięgnięciu opinii biegłych co do sposobu 
podziału.

***
## Art. 620. {#kpc-pierwsza-druga-art-620}

(uchylony)

***
## Art. 621. {#kpc-pierwsza-druga-art-621}

Projektowany sposób podziału nieruchomości na części powinien 
być zaznaczony na planie sporządzonym według zasad obowiązujących przy 
oznaczaniu nieruchomości w księgach wieczystych.

***
## Art. 622. {#kpc-pierwsza-druga-art-622}

**§ 1.** W toku postępowania o zniesienie współwłasności sąd 
powinien nakłaniać współwłaścicieli do zgodnego przeprowadzenia podziału, 
wskazując im sposoby mogące do tego doprowadzić. 
**§ 2.** Gdy wszyscy współwłaściciele złożą zgodny wniosek co do sposobu 
zniesienia współwłasności, sąd wyda postanowienie odpowiadające treści wniosku, 
jeżeli spełnione zostanie wymaganie, o którym mowa w art. 621, a projekt podziału 
nie sprzeciwia się prawu ani zasadom współżycia społecznego, ani też nie narusza 
w sposób rażący interesu osób uprawnionych.

***
## Art. 623. {#kpc-pierwsza-druga-art-623}

Jeżeli brak podstaw do wydania postanowienia w myśl artykułu 
poprzedzającego, a zachodzą warunki do dokonania podziału w naturze, sąd 
dokonuje tego podziału na części odpowiadające wartością udziałom 
współwłaścicieli z uwzględnieniem wszelkich okoliczności zgodnie z interesem 
społeczno-gospodarczym. Różnice wartości wyrównuje się przez dopłaty 
pieniężne.

***
## Art. 624. {#kpc-pierwsza-druga-art-624}

Z chwilą uprawomocnienia się postanowienia przyznającego 
dotychczasowym współwłaścicielom części lub jednemu z nich całość rzeczy 
własność przechodzi na uczestników wskazanych w postanowieniu. Jeżeli 

 
 
 
s. 289/580 
 
2025-09-08 
 
w wyniku podziału całość rzeczy albo jej część przypadnie współwłaścicielowi, 
który nie włada tą rzeczą lub jej częścią, sąd w postanowieniu o zniesieniu 
współwłasności orzeknie również co do jej wydania lub opróżnienia przez 
pozostałych współwłaścicieli pomieszczeń znajdujących się na nieruchomości, 
określając stosownie do okoliczności termin wydania rzeczy lub opróżnienia 
pomieszczeń. Określenie terminu wydania nieruchomości wchodzącej w skład 
gospodarstwa rolnego lub jej części bądź opróżnienia znajdujących się na niej 
pomieszczeń następuje z uwzględnieniem interesu społeczno-gospodarczego.

***
## Art. 625. {#kpc-pierwsza-druga-art-625}

W postanowieniu zarządzającym sprzedaż rzeczy należących do 
współwłaścicieli 
sąd 
bądź 
rozstrzygnie 
o wzajemnych 
roszczeniach 
współwłaścicieli, bądź też tylko zarządzi sprzedaż, odkładając rozstrzygnięcie 
o wzajemnych roszczeniach współwłaścicieli oraz o podziale sumy uzyskanej ze 
sprzedaży do czasu jej przeprowadzenia. 
Rozdział 5 
Ustanowienie drogi koniecznej i służebności przesyłu

***
## Art. 626. {#kpc-pierwsza-druga-art-626}

**§ 1.** We wniosku o ustanowienie drogi koniecznej należy wskazać 
właścicieli wszystkich nieruchomości, przez które mogłaby prowadzić droga, aby 
nieruchomość wnioskodawcy miała odpowiedni dostęp do drogi publicznej. 
**§ 2.** Przed wydaniem postanowienia o ustanowieniu drogi koniecznej sąd 
powinien przeprowadzić dowód z oględzin nieruchomości, chyba że okoliczności 
istotne dla wytyczenia drogi koniecznej są niesporne i niewątpliwe albo że 
przeprowadzenie dowodu z innych przyczyn nie jest potrzebne. 
**§ 3.** Przepisy § 1 i 2 stosuje się odpowiednio w sprawach o ustanowienie 
służebności przesyłu. 
Rozdział 6 
Postępowanie wieczystoksięgowe

***
## Art. 6261. {#kpc-pierwsza-druga-art-6261}

**§ 1.** Sprawy w postępowaniu wieczystoksięgowym rozpoznawane 
są na posiedzeniu niejawnym. 
**§ 2.** Uczestnikami postępowania oprócz wnioskodawcy są tylko te osoby, 
których prawa zostały wykreślone lub obciążone bądź na rzecz których wpis ma 
nastąpić. 

 
 
 
s. 290/580 
 
2025-09-08 
**§ 3.** Nie stanowi przeszkody do wpisu okoliczność, że po złożeniu wniosku 
wnioskodawca bądź inny uczestnik postępowania zmarł lub został pozbawiony 
albo ograniczony w możliwości rozporządzania prawem albo w zdolności do 
czynności prawnych. 
**§ 4.** (utracił moc)18) 
**§ 5.** (uchylony)

***
## Art. 6262. {#kpc-pierwsza-druga-art-6262}

**§ 1.** Wniosek o wpis składa się na urzędowym formularzu. 
**§ 2.** (uchylony) 
**§ 3.** Do wniosku o wpis należy dołączyć dokumenty, stanowiące podstawę 
wpisu w księdze wieczystej. 
**§ 31.** Do wniosku o wpis w księdze wieczystej na podstawie tytułu 
wykonawczego, o którym mowa w art. 783 § 4, należy dołączyć dokument 
uzyskany z systemu teleinformatycznego umożliwiający sądowi weryfikację 
istnienia i treści tytułu wykonawczego. 
**§ 4.** Jeżeli z dokumentów załączonych do wniosku wynika, że nastąpiła 
zmiana w prawie własności, sąd, zwracając wniosek, stosuje art. 62613 § 1. 
**§ 5.** Wniosek o wpis może złożyć właściciel nieruchomości, użytkownik 
wieczysty, osoba, na rzecz której wpis ma nastąpić, albo wierzyciel, jeżeli 
przysługuje mu prawo, które może być wpisane w księdze wieczystej. W sprawach 
dotyczących obciążeń powstałych z mocy ustawy wniosek może złożyć 
uprawniony organ.

***
## Art. 6263. {#kpc-pierwsza-druga-art-6263}

W postępowaniu wieczystoksięgowym nie stosuje się przepisów 
o wznowieniu postępowania.

***
## Art. 6264. {#kpc-pierwsza-druga-art-6264}

**§ 1.** Notariusz oraz komornik składa wniosek o wpis wyłącznie za 
pośrednictwem systemu teleinformatycznego. 
**§ 11.** Naczelnik urzędu skarbowego składa wniosek o wpis w dziale III i IV 
księgi wieczystej wyłącznie za pośrednictwem systemu teleinformatycznego. 
**§ 12.** Wniosek, o którym mowa w § 1 i § 11, opatruje się kwalifikowanym 
podpisem elektronicznym. 
- 18) Z dniem 17 września 2004 r. na podstawie wyroku Trybunału Konstytucyjnego z dnia 
7 września 2004 r. sygn. akt P 4/04 (Dz. U. poz. 2091). 

 
 
 
s. 291/580 
 
2025-09-08 
**§ 2.** Do wniosku, o którym mowa w § 1 i § 11, dołącza się dokumenty 
stanowiące podstawę wpisu w księdze wieczystej, jeżeli zostały one sporządzone 
w postaci elektronicznej. 
**§ 3.** Dokumenty stanowiące podstawę wpisu w księdze wieczystej 
niesporządzone w postaci elektronicznej notariusz, komornik oraz naczelnik urzędu 
skarbowego przesyła sądowi właściwemu do prowadzenia księgi wieczystej 
w terminie trzech dni od dnia złożenia wniosku o wpis. 
**§ 31.** W przypadku gdy wniosek o wpis w księdze wieczystej składany przez 
naczelnika urzędu skarbowego podlega opłacie, przepisów art. 130 § 6 i 7 nie 
stosuje się. Naczelnik urzędu skarbowego przesyła sądowi właściwemu do 
prowadzenia księgi wieczystej wraz z dokumentami, stanowiącymi podstawę 
wpisu, dowód uiszczenia opłaty. 
**§ 32.** Jeżeli wierzyciel został zwolniony od kosztów sądowych od wniosku 
o wpis w księdze wieczystej, naczelnik urzędu skarbowego przesyła sądowi 
właściwemu do prowadzenia księgi wieczystej wraz z dokumentami, stanowiącymi 
podstawę wpisu, prawomocne postanowienie sądu w przedmiocie zwolnienia od 
kosztów sądowych. 
**§ 4.** W przypadku wniosków składanych przez notariuszy i komorników 
obowiązek poprawienia lub uzupełnienia wniosku spoczywa odpowiednio na 
stronie czynności notarialnej lub wierzycielu. O zobowiązaniu wierzyciela do 
poprawienia lub uzupełnienia wniosku sąd jednocześnie zawiadamia za 
pośrednictwem systemu teleinformatycznego komornika, wskazując rodzaj braków 
formalnych, które uniemożliwiają nadanie wnioskowi prawidłowego biegu.

***
## Art. 6265. {#kpc-pierwsza-druga-art-6265}

Jeżeli z treści wniosku i dołączonych dokumentów wynika, że 
nastąpiła zmiana prawa własności, cofnięcie wniosku o wpis tego prawa jest 
niedopuszczalne.

***
## Art. 6266. {#kpc-pierwsza-druga-art-6266}

**§ 1.** O kolejności wniosku o wpis rozstrzyga chwila wpływu 
wniosku do właściwego sądu. Za chwilę wpływu wniosku uważa się godzinę 
i minutę, w której w danym dniu wniosek wpłynął do sądu. 
**§ 11.** Za chwilę wpływu wniosku o wpis złożonego za pośrednictwem systemu 
teleinformatycznego uważa się godzinę, minutę i sekundę umieszczenia wniosku 
w systemie. 

 
 
 
s. 292/580 
 
2025-09-08 
**§ 2.** Wnioski, które wpłynęły w tej samej chwili, będą uważane za złożone 
równocześnie.

***
## Art. 6267. {#kpc-pierwsza-druga-art-6267}

**§ 1.** Wniosek o wpis powinien być w dniu wpływu do sądu 
zarejestrowany niezwłocznie w dzienniku ksiąg wieczystych i opatrzony kolejnym 
numerem. 
**§ 2.** Niezwłocznie 
po 
zarejestrowaniu 
wniosku 
w dzienniku 
ksiąg 
wieczystych zamieszcza się w odpowiednim dziale księgi wieczystej informację 
o wniosku jako wzmiankę o wniosku. Wzmianka o wniosku złożonym za 
pośrednictwem systemu teleinformatycznego umieszczana jest automatycznie 
z chwilą umieszczenia wniosku w systemie. 
**§ 3.** Wzmiankę o wniosku wykreśla się z urzędu, niezwłocznie po dokonaniu 
wpisu, po uprawomocnieniu się postanowienia o odmowie dokonania wpisu lub 
o odrzuceniu wniosku albo o umorzeniu postępowania albo po uprawomocnieniu 
się zarządzenia o zwrocie wniosku. 
**§ 4.** W razie wniesienia skargi na wpis w księdze wieczystej dokonany przez 
referendarza stosuje się odpowiednio przepisy § 1 i § 2. Wzmiankę o skardze 
wykreśla się z urzędu po rozpoznaniu skargi.

***
## Art. 6268. {#kpc-pierwsza-druga-art-6268}

**§ 1.** Wpis dokonywany jest jedynie na wniosek i w jego granicach, 
chyba że przepis szczególny przewiduje dokonanie wpisu z urzędu. 
**§ 2.** Rozpoznając wniosek o wpis, sąd bada jedynie treść i formę wniosku, 
dołączonych do wniosku dokumentów oraz treść księgi wieczystej. 
**§ 21.** Przed 
rozpoznaniem 
wniosku 
o wpis 
na 
podstawie 
tytułu 
wykonawczego, o którym mowa w art. 783 § 4, istnienie i treść tego tytułu 
podlegają zweryfikowaniu przez sędziego lub referendarza sądowego w systemie 
teleinformatycznym. 
**§ 3.** Rozpoznając wniosek o wpis w księdze wieczystej, sąd z urzędu bada 
zgodność danych wskazanych we wniosku z danymi wynikającymi z systemów 
prowadzących ewidencje powszechnych numerów identyfikacyjnych, chyba że 
istnieją przeszkody faktyczne uniemożliwiające dokonanie takiego sprawdzenia. 
**§ 4.** Rozpoznając wniosek o zmianę oznaczenia nieruchomości w księdze 
wieczystej, sąd ponadto dokonuje z urzędu sprawdzenia danych wskazanych we 
wniosku i ujawnionego w księdze wieczystej oznaczenia nieruchomości z danymi 

 
 
 
s. 293/580 
 
2025-09-08 
 
katastru nieruchomości, chyba że istnieją przeszkody faktyczne uniemożliwiające 
dokonanie takiego sprawdzenia. 
**§ 5.** Niezgodność danych, o których mowa w § 3 i § 4, stanowi przeszkodę do 
dokonania wpisu. 
**§ 6.** W postępowaniu wieczystoksięgowym wpis w księdze wieczystej jest 
orzeczeniem. Uzasadnienia wpisu nie sporządza się. 
**§ 7.** Wpisem w księdze wieczystej jest również wykreślenie. 
**§ 8.** Wpis w księdze wieczystej podpisany przez sędziego lub referendarza 
sądowego uważa się za dokonany z chwilą jego zapisania w centralnej bazie 
danych ksiąg wieczystych. 
**§ 9.** (uchylony) 
**§ 10.** Założenie księgi wieczystej następuje z chwilą dokonania pierwszego 
wpisu. 
**§ 11.** Czynności związane z zakładaniem i prowadzeniem ksiąg wieczystych 
dokonywane są w centralnej bazie danych ksiąg wieczystych.

***
## Art. 6269. {#kpc-pierwsza-druga-art-6269}

Sąd oddala wniosek o wpis, jeżeli brak jest podstaw albo istnieją 
przeszkody do jego dokonania.

***
## Art. 62610. {#kpc-pierwsza-druga-art-62610}

**§ 1.** O dokonanym 
wpisie 
sąd 
zawiadamia 
uczestników 
postępowania. Nie zawiadamia się uczestnika, który na piśmie zrzekł się 
zawiadomienia. 
**§ 11.** Zrzeczenia się zawiadomienia można dokonać w akcie notarialnym 
dotyczącym czynności, z którą wiąże się wpis. 
**§ 12.** Na wniosek uczestnika postępowania, zawarty w akcie notarialnym albo 
w odrębnym piśmie, zawiadomienie o wpisie doręcza się za pośrednictwem 
systemu teleinformatycznego, na konto wskazane w tym systemie. W przypadku 
wskazania 
danych 
o koncie 
uniemożliwiających 
skuteczne 
doręczenie, 
zawiadomienie o wpisie doręcza się w sposób określony w art. 131 § 1. 
**§ 2.** Zawiadomienie zawiera istotną treść wpisu. 
**§ 3.** Apelację od wpisu wnosi się w terminie dwóch tygodni od doręczenia 
zawiadomienia o wpisie. Dla uczestnika, który zrzekł się zawiadomienia, termin 
ten biegnie od dnia dokonania wpisu. 

 
 
 
s. 294/580 
 
2025-09-08

***
## Art. 62611. {#kpc-pierwsza-druga-art-62611}

**§ 1.** Niezwłocznie po wniesieniu apelacji sąd z urzędu wpisuje 
wzmiankę o apelacji. 
**§ 2.** W razie wniesienia skargi kasacyjnej lub skargi nadzwyczajnej, o której 
mowa w art. 89 ustawy z dnia 8 grudnia 2017 r. o Sądzie Najwyższym, wpisu 
wzmianki o skardze kasacyjnej lub skardze nadzwyczajnej dokonuje się z urzędu 
niezwłocznie 
po 
przedstawieniu 
przez 
zainteresowanego 
zawiadomienia 
o wniesieniu skargi kasacyjnej lub skargi nadzwyczajnej. 
**§ 3.** Do wzmianki o apelacji, skardze kasacyjnej i skardze nadzwyczajnej, 
o której mowa w art. 89 ustawy z dnia 8 grudnia 2017 r. o Sądzie Najwyższym 
odpowiednio stosuje się art. 6267.

***
## Art. 62612. {#kpc-pierwsza-druga-art-62612}

**§ 1.** Osoba, na rzecz której w księdze wieczystej jest wpisane 
prawo lub roszczenie, jej przedstawiciel albo pełnomocnik do doręczeń ma 
obowiązek niezwłocznego zawiadomienia sądu prowadzącego księgę wieczystą 
o każdej zmianie adresu lub wskazania adresu do doręczeń. Osoba zamieszkała lub 
mająca siedzibę w państwie niebędącym członkiem Unii Europejskiej jest 
obowiązana wskazać pełnomocnika do doręczeń w Rzeczypospolitej Polskiej. 
**§ 2.** Przepis § 1 stosuje się odpowiednio do spadkobierców lub innych 
następców prawnych osoby, na rzecz której jest wpisane prawo w księdze 
wieczystej. 
**§ 3.** W razie zaniedbania obowiązku, o którym mowa w § 1 i 2, pismo sądowe 
pozostawia się w aktach sprawy ze skutkiem doręczenia, chyba że nowy adres jest 
sądowi znany.

***
## Art. 62613. {#kpc-pierwsza-druga-art-62613}

**§ 1.** Sąd z urzędu dokona wpisu ostrzeżenia, jeżeli dostrzeże 
niezgodność stanu prawnego ujawnionego w księdze wieczystej z rzeczywistym 
stanem prawnym. W razie stwierdzenia, że dla tej samej nieruchomości albo dla 
tego samego ograniczonego prawa rzeczowego prowadzi się dwie lub więcej ksiąg 
wieczystych, ujawniających odmienny stan prawny, wpisu ostrzeżenia dokonuje się 
we wszystkich księgach wieczystych założonych dla tej nieruchomości. 
**§ 2.** Sprostowania usterek wpisu, które nie mogą wywołać niezgodności treści 
księgi wieczystej z rzeczywistym stanem prawnym, dokonuje się z urzędu. 

 
 
 
s. 295/580 
 
2025-09-08 
#### DZIAŁ IV
Sprawy z zakresu prawa spadkowego 
Przepisy wstępne

***
## Art. 627. {#kpc-pierwsza-druga-art-627}

Postępowanie spadkowe należy do zakresu działalności sądów, 
chyba że przepis szczególny stanowi inaczej.

***
## Art. 628. {#kpc-pierwsza-druga-art-628}

Do czynności w postępowaniu spadkowym, które należą do zakresu 
działania sądów, wyłącznie właściwy jest sąd ostatniego miejsca zwykłego pobytu 
spadkodawcy, a jeżeli jego miejsca zwykłego pobytu w Polsce nie da się ustalić, 
sąd miejsca, w którym znajduje się majątek spadkowy lub jego część (sąd spadku). 
W braku powyższych podstaw sądem spadku jest sąd rejonowy dla m.st. 
Warszawy.

***
## Art. 629. {#kpc-pierwsza-druga-art-629}

(uchylony) 
(oznaczenie rozdziału 1 i tytuł oraz oznaczenie oddziału 1 i tytuł – uchylone)

***
## Art. 630. {#kpc-pierwsza-druga-art-630}

(uchylony)

***
## Art. 631. {#kpc-pierwsza-druga-art-631}

(uchylony)

***
## Art. 632. {#kpc-pierwsza-druga-art-632}

(uchylony) 
Rozdział 1 
Zabezpieczenie spadku, wykaz inwentarza i spis inwentarza

***
## Art. 633. {#kpc-pierwsza-druga-art-633}

**§ 1.** Do zabezpieczenia spadku właściwy jest sąd, w którego okręgu 
znajdują się rzeczy będące w chwili otwarcia spadku we władaniu spadkodawcy. 
Jeżeli przedmiotem zabezpieczenia mają być prawa majątkowe należące do 
spadkodawcy w chwili otwarcia spadku, sądem właściwym jest sąd właściwości 
ogólnej osoby zobowiązanej z tytułu tego prawa, a gdy takiej osoby nie ma – sąd, 
w którego okręgu znajduje się przedmiot świadczenia lub prawa. Jeżeli wykonanie 
prawa majątkowego jest związane z posiadaniem dokumentu, właściwy jest sąd, 
w którego okręgu znajduje się ten dokument. 
**§ 2.** Sąd, który nie jest sądem spadku, zawiadamia sąd spadku o dokonaniu 
zabezpieczenia, jego uchyleniu oraz zmianie środka zabezpieczenia, przesyłając 
odpisy postanowień wydanych w tym przedmiocie. 

 
 
 
s. 296/580 
 
2025-09-08

***
## Art. 634. {#kpc-pierwsza-druga-art-634}

Spadek zabezpiecza się, gdy zostanie uprawdopodobnione, że 
z jakiejkolwiek przyczyny grozi naruszenie rzeczy lub praw majątkowych, które 
w chwili otwarcia spadku były we władaniu lub należały do spadkodawcy, 
zwłaszcza przez usunięcie, uszkodzenie, zniszczenie lub nieusprawiedliwione 
rozporządzenie.

***
## Art. 635. {#kpc-pierwsza-druga-art-635}

**§ 1.** Sąd dokonuje zabezpieczenia spadku na wniosek lub z urzędu. 
**§ 2.** Wniosek może zgłosić każdy, kto uprawdopodobni, że jest spadkobiercą, 
uprawnionym do zachowku lub zapisobiercą, a ponadto wykonawca testamentu, 
zarządca sukcesyjny, tymczasowy przedstawiciel, współwłaściciel rzeczy, 
współuprawniony co do praw pozostałych po spadkodawcy, wierzyciel mający 
pisemny dowód należności przeciwko spadkodawcy oraz Skarb Państwa 
reprezentowany przez naczelnika właściwego urzędu skarbowego. 
**§ 21.** Wniosek powinien zawierać uprawdopodobnienie okoliczności go 
uzasadniających. 
**§ 3.** Zabezpieczenia spadku dokonuje się z urzędu, jeżeli sąd poweźmie 
wiadomość, że: 
- 1) spadkobierca jest nieznany, nieobecny lub nie ma pełnej zdolności do 
czynności prawnych i nie ma ustawowego przedstawiciela; 
- 2) organ administracji rządowej albo organ jednostki samorządu terytorialnego 
zastosował niezbędne środki tymczasowe ze względu na grożące 
niebezpieczeństwo naruszenia rzeczy, które w chwili otwarcia spadku były we 
władaniu spadkodawcy. 
**§ 4.** (uchylony) 
**§ 5.** Postanowienie 
o zabezpieczeniu 
spadku 
oraz 
zmianie 
środka 
zabezpieczenia podlega wykonaniu z chwilą jego wydania. 
**§ 6.** Na postanowienie w przedmiocie zabezpieczenia spadku przysługuje 
zażalenie. Sąd pierwszej instancji może wstrzymać wykonanie zaskarżonego 
postanowienia do czasu rozstrzygnięcia zażalenia.

***
## Art. 636. {#kpc-pierwsza-druga-art-636}

**§ 1.** Sąd stosuje taki środek zabezpieczenia, jaki stosownie do 
okoliczności uzna za odpowiedni. Jeżeli nie jest możliwe określenie środka 
zabezpieczenia w postanowieniu o zabezpieczeniu spadku, wybór środka 
zabezpieczenia należy do komornika. 

 
 
 
s. 297/580 
 
2025-09-08 
**§ 2.** Środkami 
zabezpieczenia 
są 
w szczególności 
spisanie 
majątku 
ruchomego i oddanie go pod dozór, złożenie do depozytu sądowego, ustanowienie 
zarządu tymczasowego, ustanowienie dozoru nad nieruchomością. Zastosowanie 
jednego środka zabezpieczenia nie wyłącza zastosowania innych, równocześnie lub 
kolejno. 
**§ 3.** Ustanowienie zarządu tymczasowego może nastąpić tylko wtedy, gdy 
zabezpieczeniu podlega przedsiębiorstwo, gospodarstwo rolne albo prawo 
majątkowe 
wymagające 
zabezpieczenia 
przez 
ustanowienie 
zarządu 
tymczasowego. 
**§ 4.** Do 
zarządcy 
tymczasowego 
i dozorcy 
ustanowionych 
w toku 
postępowania o zabezpieczenie spadku stosuje się odpowiednio przepisy art. 855–
862, art. 931 i art. 933–941. 
**§ 5.** Do depozytu sądowego składa się podlegające zabezpieczeniu pieniądze, 
papiery wartościowe, imienne książeczki oszczędnościowe lub inne dokumenty 
potwierdzające zawarcie umowy rachunku oszczędnościowego, rachunku 
oszczędnościowo-rozliczeniowego 
albo 
rachunku 
terminowej 
lokaty 
oszczędnościowej, a także kosztowności, w tym złote monety oraz kruszce 
szlachetne i wyroby z tych kruszców. Kosztowności mogą być również oddane na 
przechowanie dozorcy. 
**§ 6.** Jeżeli w skład spadku wchodzą ruchomości ulegające szybkiemu 
zepsuciu, sąd zarządza ich sprzedaż przez komornika, oznaczając przy tym sposób 
sprzedaży. Uzyskane ze sprzedaży pieniądze składa się do depozytu sądowego. 
**§ 7.** Jeżeli przemawiają za tym właściwości przedmiotu podlegającego 
zabezpieczeniu, sąd zawiadamia właściwą instytucję o zastosowanym środku 
zabezpieczenia.

***
## Art. 6361. {#kpc-pierwsza-druga-art-6361}

**§ 1.** W razie potrzeby, sąd z urzędu zmieni środek zabezpieczenia, 
w szczególności jeżeli dotychczas zastosowany środek nie jest wystarczający do 
zabezpieczenia spadku. 
**§ 2.** Sąd 
z 
urzędu 
uchyli 
zabezpieczenie, 
jeżeli 
ustała 
potrzeba 
zabezpieczenia, a w szczególności gdy zgłosi się spadkobierca legitymujący się 
prawomocnym 
postanowieniem 
o stwierdzeniu 
nabycia 
spadku 
albo 
zarejestrowanym aktem poświadczenia dziedziczenia w celu objęcia spadku albo 

 
 
 
s. 298/580 
 
2025-09-08 
 
wykonawca testamentu albo tymczasowy przedstawiciel lub kurator spadku w celu 
przejęcia zarządu majątkiem spadkowym.

***
## Art. 6362. {#kpc-pierwsza-druga-art-6362}

Przepisy o zabezpieczeniu spadku stosuje się odpowiednio do 
zabezpieczenia przedmiotu zapisu windykacyjnego.

***
## Art. 6363. {#kpc-pierwsza-druga-art-6363}

**§ 1.** Wykaz inwentarza może być złożony w sądzie spadku lub 
w sądzie, w którego okręgu znajduje się miejsce zamieszkania składającego wykaz. 
Sąd niebędący sądem spadku niezwłocznie przesyła wykaz inwentarza do sądu 
spadku. 
**§ 2.** Na żądanie spadkobiercy, zapisobiercy windykacyjnego, wykonawcy 
testamentu lub tymczasowego przedstawiciela notariusz sporządza protokół 
obejmujący wykaz inwentarza. Notariusz, przed którym złożono wykaz 
inwentarza, niezwłocznie przesyła wypis protokołu do sądu spadku. 
**§ 3.** Sąd spadku niezwłocznie zarządza ogłoszenie o złożeniu wykazu 
inwentarza.

***
## Art. 637. {#kpc-pierwsza-druga-art-637}

**§ 1.** Na wniosek tego, kto uprawdopodobni, że jest spadkobiercą, 
uprawnionym do zachowku lub zapisobiercą, albo wykonawcy testamentu, 
tymczasowego przedstawiciela lub wierzyciela mającego pisemny dowód należ-
ności przeciwko spadkodawcy sąd spadku wydaje postanowienie o sporządzeniu 
spisu inwentarza. 
**§ 2.** Jeżeli sporządzenia spisu inwentarza żąda wierzyciel, sąd spadku wydaje 
postanowienie w przedmiocie wniosku po wysłuchaniu spadkobiercy, chyba że 
wysłuchanie nie jest możliwe. 
**§ 3.** Sąd spadku niezwłocznie zarządza ogłoszenie o wydaniu postanowienia 
o sporządzeniu spisu inwentarza. 
**§ 4.** Na postanowienie w przedmiocie sporządzenia spisu inwentarza 
przysługuje zażalenie.

***
## Art. 6371. {#kpc-pierwsza-druga-art-6371}

**§ 1.** Wniosek o sporządzenie spisu inwentarza może być także 
zgłoszony bezpośrednio komornikowi, który byłby właściwy do wykonania 
postanowienia sądu spadku o sporządzeniu spisu inwentarza. 
**§ 2.** Komornik przystępuje niezwłocznie do sporządzenia spisu inwentarza 
i zawiadamia o tym sąd spadku, który wydaje postanowienie w przedmiocie 
sporządzenia spisu inwentarza. Jeżeli sąd oddali albo odrzuci wniosek, o którym 

 
 
 
s. 299/580 
 
2025-09-08 
 
mowa w § 1, albo umorzy postępowanie, spis sporządzony przez komornika rodzi 
takie same skutki jak złożenie wykazu inwentarza.

***
## Art. 638. {#kpc-pierwsza-druga-art-638}

(uchylony)

***
## Art. 6381. {#kpc-pierwsza-druga-art-6381}

**§ 1.** Ogłoszenia, o których mowa w art. 6363 § 3 i art. 637 § 3, 
zamieszcza się na stronie internetowej oraz na tablicy ogłoszeń sądu spadku. 
**§ 2.** Ogłoszenie zawiera: 
- 1) imię i nazwisko, numer PESEL, jeżeli został nadany, oraz ostatni adres 
spadkodawcy; 
- 2) datę śmierci spadkodawcy. 
**§ 3.** Ogłoszenie, o którym mowa w art. 6363 § 3, poza danymi, o których 
mowa w § 2, zawiera również pouczenie, że: 
- 1) ze złożonym wykazem inwentarza może się zapoznać każdy, kto taką 
potrzebę dostatecznie uzasadni; 
- 2) osoby wskazane w art. 637 § 1 mogą złożyć wniosek o sporządzenie spisu 
inwentarza. 
**§ 4.** Ogłoszenie, o którym mowa w art. 637 § 3, poza danymi, o których 
mowa w § 2, zawiera również pouczenie, że osoby wskazane w art. 637 § 1 mogą 
uczestniczyć w sporządzaniu spisu inwentarza, w szczególności zgłaszać 
przedmioty należące do spadku, przedmioty zapisów windykacyjnych lub długi 
spadkowe, które podlegają zamieszczeniu w spisie inwentarza.

***
## Art. 6382. {#kpc-pierwsza-druga-art-6382}

**§ 1.** W sprawach, w których postanowienie o zabezpieczeniu 
spadku, zmianie środka zabezpieczenia lub sporządzeniu spisu inwentarza zostało 
wydane z urzędu, sąd, który wydał to postanowienie, kieruje do komornika 
polecenie dokonania zabezpieczenia spadku, zmiany środka zabezpieczenia lub 
sporządzenia spisu inwentarza. 
**§ 2.** Podstawą postępowania mającego na celu wykonanie postanowienia 
o zabezpieczeniu spadku, zmianie środka zabezpieczenia lub sporządzeniu spisu 
inwentarza jest postanowienie zaopatrzone z urzędu we wzmiankę o wykonalności. 
**§ 3.** Nadzór nad czynnościami komornika sprawuje sąd, który wydał 
postanowienie o zabezpieczeniu spadku lub sporządzeniu spisu inwentarza. 

 
 
 
s. 300/580 
 
2025-09-08 
**§ 4.** W postępowaniu o zabezpieczenie spadku, zmianę środka zabezpieczenia 
lub sporządzenie spisu inwentarza w sprawach nieuregulowanych w niniejszym 
rozdziale stosuje się odpowiednio przepisy art. 759–774.

***
## Art. 6383. {#kpc-pierwsza-druga-art-6383}

**§ 1.** Jeżeli postanowienie o zabezpieczeniu spadku nie określa 
środka zabezpieczenia, komornik niezwłocznie zawiadamia sąd, który wydał 
postanowienie o zabezpieczeniu spadku, o zastosowanym środku zabezpieczenia. 
**§ 2.** W razie potrzeby złożenia przedmiotów podlegających zabezpieczeniu 
do depozytu sądowego komornik występuje z wnioskiem do sądu, który wydał 
postanowienie o zabezpieczeniu spadku. 
**§ 3.** Sąd, który wydał postanowienie o zabezpieczeniu spadku, zawiadamia 
sąd spadku o środkach zabezpieczenia zastosowanych przez komornika.

***
## Art. 6384. {#kpc-pierwsza-druga-art-6384}

**§ 1.** Spis majątku ruchomego w ramach zabezpieczenia spadku 
sporządza się w obecności dwóch świadków powołanych przez komornika. 
**§ 2.** Przy sporządzaniu spisu majątku ruchomego mogą być obecne osoby, 
które mają prawo zgłosić wniosek o zabezpieczenie spadku. Niestawiennictwo tych 
osób nie wstrzymuje wykonania czynności. 
**§ 3.** Z dokonanej czynności komornik sporządza protokół, który podpisują 
wszyscy obecni. Odmowę lub niemożność podpisania stwierdza się w protokole 
z podaniem przyczyny.

***
## Art. 6385. {#kpc-pierwsza-druga-art-6385}

Komornik wykonujący postanowienie o zabezpieczeniu spadku 
w razie potrzeby stosuje niezbędne środki tymczasowe zapobiegające naruszeniu 
ruchomości przed ich spisaniem.

***
## Art. 6386. {#kpc-pierwsza-druga-art-6386}

**§ 1.** Z pieniędzy wchodzących w skład spadku komornik 
wykonujący postanowienie o zabezpieczeniu spadku wyda w razie potrzeby 
członkowi rodziny spadkodawcy, a gdyby to nie było możliwe, domownikowi 
spadkodawcy albo innej osobie ponoszącej koszty pogrzebu, sumę potrzebną na 
koszty pogrzebu spadkodawcy. W przypadku braku pieniędzy na pogrzeb 
spadkodawcy, sąd może zarządzić sprzedaż przez komornika odpowiedniego 
przedmiotu należącego do spadku, oznaczając przy tym sposób sprzedaży. 
**§ 2.** Komornik wykonujący postanowienie o zabezpieczeniu spadku może 
z pieniędzy wchodzących w skład spadku pozostawić członkom rodziny 
spadkodawcy, którzy do chwili jego śmierci wspólnie z nim zamieszkiwali i byli 

 
 
 
s. 301/580 
 
2025-09-08 
 
na jego utrzymaniu, niezbędne kwoty na ich utrzymanie przez czas nie dłuższy niż 
miesiąc.

***
## Art. 6387. {#kpc-pierwsza-druga-art-6387}

O terminie sporządzenia spisu inwentarza komornik zawiadamia 
wnioskodawcę oraz uczestników postępowania o sporządzenie spisu inwentarza, 
a także spadkobiercę i zapisobiercę windykacyjnego, których miejsce pobytu jest 
znane, jak również wykonawcę testamentu, tymczasowego przedstawiciela, 
kuratora spadku, dozorcę i zarządcę tymczasowego, jeżeli byli ustanowieni. 
Niestawiennictwo tych osób nie wstrzymuje czynności.

***
## Art. 6388. {#kpc-pierwsza-druga-art-6388}

**§ 1.** W spisie inwentarza komornik zamieszcza przedmioty 
należące do spadku i przedmioty zapisów windykacyjnych, z zaznaczeniem 
wartości każdego z tych przedmiotów, oraz długi spadkowe ze wskazaniem 
wysokości każdego z nich. 
**§ 2.** Wartość przedmiotów należących do spadku i przedmiotów zapisów 
windykacyjnych komornik ustala według stanu i cen z chwili otwarcia spadku, 
a wysokość długów spadkowych – według stanu z chwili otwarcia spadku. 
**§ 3.** Komornik z urzędu ustala i zamieszcza w spisie inwentarza przedmioty 
należące do spadku, przedmioty zapisów windykacyjnych oraz długi spadkowe. 
**§ 4.** W spisie inwentarza komornik wykazuje też wartość stanu czynnego 
spadku z uwzględnieniem wartości rzeczy i praw spornych. 
**§ 5.** Przy sporządzaniu spisu inwentarza stosuje się odpowiednio przepisy 
art. 6384 § 1 i 3 oraz art. 947–949.

***
## Art. 6389. {#kpc-pierwsza-druga-art-6389}

W razie potrzeby zamieszczenia w spisie inwentarza rzeczy 
znajdujących się w okręgu innego sądu sąd spadku może zwrócić się do tego sądu 
o wykonanie potrzebnych czynności. Po ich wykonaniu sąd wezwany przekazuje 
akta sprawy sądowi spadku.

***
## Art. 63810. {#kpc-pierwsza-druga-art-63810}

**§ 1.** Ruchomości 
i nieruchomości 
zamieszczone 
w spisie 
inwentarza pozostawia się w posiadaniu osób, które nimi władają. Nie dotyczy to 
ruchomości złożonych do depozytu sądowego. 
**§ 2.** Jeżeli zachodzą podstawy do dokonania zabezpieczenia spadku z urzędu, 
komornik zawiadamia o tym sąd właściwy do zabezpieczenia spadku.

***
## Art. 63811. {#kpc-pierwsza-druga-art-63811}

W razie 
ujawnienia 
przedmiotu 
należącego 
do 
spadku, 
przedmiotu zapisu windykacyjnego lub długu spadkowego niezamieszczonego 

 
 
 
s. 302/580 
 
2025-09-08 
 
w spisie 
inwentarza 
sąd 
spadku 
wydaje 
postanowienie 
o sporządzeniu 
uzupełniającego spisu inwentarza. W przypadkach, w których postanowienie 
o sporządzeniu 
spisu 
inwentarza 
wydaje 
się 
z urzędu, 
postanowienie 
o sporządzeniu uzupełniającego spisu inwentarza wydaje się również z urzędu.

***
## Art. 63812. {#kpc-pierwsza-druga-art-63812}

Po wykonaniu postanowienia o sporządzeniu spisu inwentarza 
komornik przesyła akta sądowi spadku, a w przypadku, o którym mowa 
w art. 6389, sądowi wezwanemu.

***
## Art. 639. {#kpc-pierwsza-druga-art-639}

Minister Sprawiedliwości określi, w drodze rozporządzenia: 
- 1) szczegółowy sposób zawiadamiania właściwych instytucji o zastosowanym 
środku zabezpieczenia, mając na względzie właściwość przedmiotu 
podlegającego zabezpieczeniu oraz właściwość poszczególnych instytucji; 
- 2) zawartość protokołu ze spisu majątku ruchomego, w tym zakres danych 
osobowych zamieszczanych w protokole, mając na względzie niezbędność 
i adekwatność informacji oraz niezbędność i adekwatność danych osobowych 
w stosunku do celu ich przetwarzania; 
- 3) szczegółowy 
tryb 
i sposób 
zastosowania 
niezbędnych 
środków 
tymczasowych zapobiegających naruszeniu ruchomości przed ich spisaniem, 
mając na względzie przedmiot zabezpieczenia, szybkość postępowania, 
a także skuteczność niezbędnych środków tymczasowych. 
Rozdział 2 
Przyjęcie lub odrzucenie spadku

***
## Art. 640. {#kpc-pierwsza-druga-art-640}

**§ 1.** Oświadczenie 
o prostym 
przyjęciu 
spadku 
lub 
z dobrodziejstwem inwentarza albo o odrzuceniu spadku może być złożone przed 
notariuszem lub w sądzie rejonowym, w którego okręgu znajduje się miejsce 
zamieszkania lub pobytu składającego oświadczenie. Notariusz lub sąd prześle 
niezwłocznie oświadczenie, wraz z załącznikami, do sądu spadku. Notariusz nie 
przesyła oświadczenia, jeżeli zarejestrował akt poświadczenia dziedziczenia. 
**§ 2.** Oświadczenia, o których mowa w paragrafie pierwszym, mogą być 
również składane w sądzie spadku w toku postępowania o stwierdzenie praw do 
spadku. 

 
 
 
s. 303/580 
 
2025-09-08

***
## Art. 6401. {#kpc-pierwsza-druga-art-6401}

**§ 1.** Zezwolenie na dokonanie czynności przekraczającej zakres 
zwykłego zarządu majątkiem dziecka lub osoby pozostającej pod opieką w postaci 
prostego przyjęcia lub odrzucenia spadku, w toku postępowania o stwierdzenie 
nabycia spadku, wydaje sąd spadku. 
**§ 2.** Z chwilą wszczęcia postępowania o stwierdzenie nabycia spadku 
wniosek o zezwolenie na dokonanie czynności, o której mowa w § 1, złożony do 
sądu opiekuńczego, przekazuje się do dalszego rozpoznania sądowi spadku.

***
## Art. 641. {#kpc-pierwsza-druga-art-641}

**§ 1.** Oświadczenie o przyjęciu lub odrzuceniu spadku powinno 
zawierać: 
- 1) imię i nazwisko spadkodawcy, datę i miejsce jego śmierci oraz ostatnie 
miejsce jego zwykłego pobytu; 
- 2) tytuł powołania do spadku; 
- 3) treść złożonego oświadczenia. 
**§ 2.** Oświadczenie powinno również zawierać wymienienie wszelkich 
wiadomych składającemu oświadczenie osób należących do kręgu spadkobierców 
ustawowych, jak również wszelkich testamentów, chociażby składający oświad-
czenie uważał je za nieważne, oraz danych dotyczących treści i miejsca 
przechowania testamentów. 
**§ 3.** (uchylony) 
**§ 31.** Rodzic, składając w imieniu dziecka oświadczenie o odrzuceniu spadku, 
oświadcza o: 
- 1) przysługiwaniu mu władzy rodzicielskiej i jej zakresie, 
- 2) wyrażeniu przez drugiego z rodziców zgody na odrzucenie spadku, chyba że 
oświadczenie to jest składane wspólnie, 
- 3) uprzednim odrzuceniu spadku przez któregokolwiek z rodziców, 
- 4) odrzuceniu spadku przez innych zstępnych rodziców tego dziecka 
– chyba że przed złożeniem oświadczenia zostało wydane zezwolenie sądu na 
dokonanie czynności przekraczającej zakres zwykłego zarządu majątkiem dziecka 
w postaci odrzucenia spadku. 
**§ 32.** Oświadczenie w zakresie treści wskazanej w § 31 pkt 1–4 składane jest 
pod rygorem odpowiedzialności karnej za złożenie fałszywego oświadczenia. 

 
 
 
s. 304/580 
 
2025-09-08 
**§ 33.** Jeżeli oświadczenie jest składane przed sądem albo notariuszem, przed 
jego odebraniem sędzia albo notariusz uprzedza składającego oświadczenie 
o odpowiedzialności karnej za złożenie fałszywego oświadczenia. 
**§ 34.** Jeżeli oświadczenie o treści wskazanej w § 31 jest składane na piśmie 
z podpisem urzędowo poświadczonym, składający oświadczenie jest obowiązany 
do zawarcia w jego treści klauzuli o następującej treści: „Jestem świadomy 
odpowiedzialności karnej za złożenie fałszywego oświadczenia.”. Klauzula ta 
zastępuje pouczenie organu o odpowiedzialności karnej za złożenie fałszywego 
oświadczenia. 
**§ 35.** Oświadczenie, o którym mowa w § 31, może dotyczyć więcej niż 
jednego dziecka. 
**§ 4.** Jeżeli oświadczenie złożono ustnie, z oświadczenia sporządza się 
protokół.

***
## Art. 642. {#kpc-pierwsza-druga-art-642}

(uchylony)

***
## Art. 643. {#kpc-pierwsza-druga-art-643}

O odrzuceniu spadku zawiadamia się wszystkie znane sądowi 
spadku 
osoby, 
które 
zgodnie 
z treścią 
oświadczenia 
i przedstawionych 
dokumentów są powołane do dziedziczenia.

***
## Art. 644. {#kpc-pierwsza-druga-art-644}

(uchylony)

***
## Art. 645. {#kpc-pierwsza-druga-art-645}

(uchylony) 
Rozdział 3 
Ogłoszenie testamentu

***
## Art. 646. {#kpc-pierwsza-druga-art-646}

**§ 1.** Osoba, u której znajduje się testament, jest obowiązana złożyć 
go w sądzie spadku, gdy dowie się o śmierci spadkodawcy, chyba że złożyła go 
u notariusza. 
**§ 2.** Kto bezzasadnie uchyla się od wykonania powyższego obowiązku, 
ponosi odpowiedzialność za wynikłą stąd szkodę. Ponadto sąd spadku może 
nałożyć na uchylającego się grzywnę.

***
## Art. 647. {#kpc-pierwsza-druga-art-647}

W celu stwierdzenia, czy istnieje testament i gdzie się znajduje, sąd 
spadku może nakazać złożenie oświadczenia w tym przedmiocie, stosując 
odpowiednio tryb przewidziany do wyjawienia przedmiotów spadkowych. 

 
 
 
s. 305/580 
 
2025-09-08

***
## Art. 648. {#kpc-pierwsza-druga-art-648}

**§ 1.** Sąd po wysłuchaniu osoby, u której według uzyskanych 
wiadomości testament się znajduje, wyda z urzędu postanowienie nakazujące jej 
złożenie testamentu w wyznaczonym terminie. 
**§ 2.** Na postanowienie sądu w przedmiocie złożenia testamentu przysługuje 
zażalenie.

***
## Art. 649. {#kpc-pierwsza-druga-art-649}

**§ 1.** Sąd albo notariusz otwiera i ogłasza testament, gdy ma dowód 
śmierci spadkodawcy. 
**§ 2.** O terminie 
otwarcia 
i ogłoszenia 
nie 
zawiadamia 
się 
osób 
zainteresowanych, jednakże mogą one być obecne przy tej czynności.

***
## Art. 650. {#kpc-pierwsza-druga-art-650}

Gdy złożono kilka testamentów jednego spadkodawcy, otwiera się 
i ogłasza wszystkie, a na każdym z nich czyni się wzmiankę o innych.

***
## Art. 651. {#kpc-pierwsza-druga-art-651}

W protokole otwarcia i ogłoszenia testamentu opisuje się jego stan 
zewnętrzny oraz wymienia się jego datę, datę złożenia i osobę, która testament 
złożyła. Na testamencie zamieszcza się datę otwarcia i ogłoszenia.

***
## Art. 652. {#kpc-pierwsza-druga-art-652}

O dokonanym otwarciu i ogłoszeniu testamentu sąd spadku albo 
notariusz 
zawiadamia 
w miarę 
możności 
osoby, 
których 
rozrządzenia 
testamentowe 
dotyczą, 
oraz 
wykonawcę 
testamentu, 
tymczasowego 
przedstawiciela i kuratora spadku. Notariusz niezwłocznie zawiadamia o tym sąd 
spadku, przesyłając odpis sporządzonego protokołu, chyba że zarejestrował akt 
poświadczenia dziedziczenia.

***
## Art. 653. {#kpc-pierwsza-druga-art-653}

Testament wraz z protokołem otwarcia i ogłoszenia przechowuje 
się w sądzie spadku, chyba że został złożony u notariusza. Jednakże na żądanie 
sądu spadku notariusz przesyła złożony testament temu sądowi.

***
## Art. 654. {#kpc-pierwsza-druga-art-654}

Przepisy niniejszego rozdziału stosuje się odpowiednio do pisma 
stwierdzającego treść testamentu ustnego. 
(oznaczenie rozdziału 2 i tytuł tego rozdziału – uchylone) 
Rozdział 4 
Wyjawienie przedmiotów spadkowych

***
## Art. 655. {#kpc-pierwsza-druga-art-655}

**§ 1.** Jeżeli po sporządzeniu spisu inwentarza zachodzi wątpliwość, 
czy zostały w nim zamieszczone wszystkie przedmioty należące do spadku 
i przedmioty zapisów windykacyjnych lub czy zamieszczone w spisie inwentarza 

 
 
 
s. 306/580 
 
2025-09-08 
 
długi spadkowe istnieją, sąd spadku z urzędu lub na wniosek spadkobiercy, 
zapisobiercy 
windykacyjnego, 
wykonawcy 
testamentu, 
tymczasowego 
przedstawiciela lub wierzyciela spadku może nakazać spadkobiercy złożenie: 
- 1) oświadczenia, że żadnego przedmiotu spadkowego nie zataił ani nie usunął 
oraz że nie podał do spisu inwentarza nieistniejących długów; 
- 2) wykazu przedmiotów spadkowych nieujawnionych w spisie inwentarza, 
jeżeli mu są wiadome, z podaniem miejsca przechowania ruchomości 
i dokumentów dotyczących praw majątkowych, jak również z wyjaśnieniem 
podstawy prawnej tych praw; 
- 3) zapewnienia, że złożone oświadczenie lub wykaz są prawidłowe i zupełne. 
**§ 2.** Wierzyciel spadku może zgłosić powyższe wnioski tylko wówczas, gdy 
uprawdopodobni, że ujawniony w spisie inwentarza stan czynny spadku nie 
wystarcza na zaspokojenie długów spadkowych.

***
## Art. 656. {#kpc-pierwsza-druga-art-656}

Sprawy o wyjawienie przedmiotów spadkowych sąd rozpoznaje na 
rozprawie, wzywając oprócz wnioskodawcy tych, którzy są uprawnieni do 
wystąpienia z wnioskiem o wyjawienie przedmiotów spadkowych, jeżeli są mu 
znani.

***
## Art. 657. {#kpc-pierwsza-druga-art-657}

Jeżeli wniosek o wyjawienie skierowany jest przeciwko innemu 
współspadkobiercy, ten ostatni może nie później niż na rozprawie żądać włożenia 
na wnioskodawcę obowiązków wymienionych w art. 655.

***
## Art. 658. {#kpc-pierwsza-druga-art-658}

Po 
uprawomocnieniu 
się 
postanowienia 
uwzględniającego 
w całości lub części wniosek o wyjawienie przedmiotów spadkowych, sąd na 
wniosek każdego, kto był uprawniony do wystąpienia z tym wnioskiem, wezwie 
spadkobiercę do wykonania w wyznaczonym terminie włożonego na niego 
obowiązku, z pouczeniem, że oświadczenie swe może spadkobierca złożyć do 
protokołu sądowego. Równocześnie sąd wyznaczy na dzień przypadający co 
najmniej na dwa tygodnie po upływie wyznaczonego terminu posiedzenie, na które 
wezwie wszystkich uczestników sprawy. Jeżeli przed tym posiedzeniem 
spadkobierca złoży oświadczenie lub wykaz, sąd zawiadomi o tym uczestników.

***
## Art. 659. {#kpc-pierwsza-druga-art-659}

Spadkobierca, który swym obowiązkom nie uczynił zadość, może 
spełnić je jeszcze na posiedzeniu. W związku z materiałem przedstawionym przez 
spadkobiercę sąd oraz uczestnicy mogą zadawać spadkobiercy pytania. 

 
 
 
s. 307/580 
 
2025-09-08

***
## Art. 660. {#kpc-pierwsza-druga-art-660}

**§ 1.** W razie niedopełnienia przez spadkobiercę jego obowiązków 
lub odmowy odpowiedzi na stawiane mu pytania, sąd stosuje środki przymusu 
według przepisów o egzekucji świadczeń niepieniężnych. 
**§ 2.** O skutkach tych należy spadkobiercę uprzedzić w wezwaniu do 
spełnienia obowiązków objętych postanowieniem o wyjawieniu przedmiotów 
spadkowych. 
Rozdział 5 
Przesłuchanie świadków testamentu ustnego

***
## Art. 661. {#kpc-pierwsza-druga-art-661}

**§ 1.** Kto dowie się o śmierci spadkodawcy oraz o tym, że treść 
testamentu ustnego nie została spisana, obowiązany jest niezwłocznie zawiadomić 
o tym sąd spadku oraz podać imiona, nazwiska i adresy świadków testamentu, 
jeżeli okoliczności te są mu znane. 
**§ 2.** Kto 
nie 
dopełnia 
obowiązku 
przewidzianego 
w paragrafie 
poprzedzającym, odpowiada za wynikłą stąd szkodę, nadto sąd spadku może 
wymierzyć mu grzywnę.

***
## Art. 662. {#kpc-pierwsza-druga-art-662}

Świadków, którzy treści testamentu ustnego nie stwierdzili na 
piśmie, sąd wzywa do złożenia na wyznaczonym posiedzeniu sądowym zeznań 
stwierdzających treść testamentu. Do postępowania w sprawie przesłuchania 
świadków testamentu ustnego stosuje się odpowiednio przepisy o dowodzie ze 
świadków w procesie, z tą zmianą, że świadkowie testamentu nie mogą odmówić 
zeznań ani odpowiedzi na pytanie, ani też nie mogą być zwolnieni od złożenia 
przyrzeczenia.

***
## Art. 663. {#kpc-pierwsza-druga-art-663}

(uchylony) 
Rozdział 6 
Sprawy dotyczące wykonawcy testamentu

***
## Art. 664. {#kpc-pierwsza-druga-art-664}

Osoba powołana na wykonawcę testamentu, która odmawia 
przyjęcia tego obowiązku, oświadcza o tym w sądzie spadku ustnie do protokołu 
albo na piśmie z podpisem urzędowo poświadczonym albo przed notariuszem. 
Pełnomocnictwa do złożenia takiego oświadczenia udziela się na piśmie 
z podpisem urzędowo poświadczonym. 

 
 
 
s. 308/580 
 
2025-09-08

***
## Art. 665. {#kpc-pierwsza-druga-art-665}

**§ 1.** Sąd spadku albo notariusz wyda osobie powołanej na 
wykonawcę testamentu, na jej wniosek, zaświadczenie, w którym wymieni imię, 
nazwisko, miejsce ostatniego zamieszkania oraz datę i miejsce śmierci 
spadkodawcy, imię, nazwisko i miejsce zamieszkania wykonawcy testamentu, jak 
również zamieści stwierdzenie, że dana osoba została powołana na wykonawcę 
testamentu. W zaświadczeniu wskazuje się też prawa i obowiązki wykonawcy 
testamentu, jeżeli zostały one określone przez spadkodawcę. 
**§ 2.** Notariusz 
niezwłocznie 
zawiadamia 
sąd 
spadku 
o wydanym 
zaświadczeniu, przesyłając jego odpis. 
Rozdział 6a 
Sprawy dotyczące zarządu sukcesyjnego

***
## Art. 6651. {#kpc-pierwsza-druga-art-6651}

W sprawach dotyczących zarządu sukcesyjnego właściwy jest sąd 
spadku, z wyjątkiem art. 6655.

***
## Art. 6652. {#kpc-pierwsza-druga-art-6652}

Wniosek 
o wydanie 
zezwolenia 
na 
dokonanie 
czynności 
przekraczającej zakres zwykłego zarządu składa zarządca sukcesyjny.

***
## Art. 6653. {#kpc-pierwsza-druga-art-6653}

**§ 1.** Wniosek o odwołanie zarządcy sukcesyjnego z powodu 
rażącego naruszenia jego obowiązków może zgłosić każdy, kto ma w tym interes 
prawny. 
**§ 2.** W postępowaniu wszczętym na wniosek, o którym mowa w § 1, osoba 
uprawniona do powołania zarządcy sukcesyjnego, nawet jeżeli nie jest 
wnioskodawcą, może złożyć wniosek o powołanie wskazanej osoby na zarządcę 
sukcesyjnego w miejsce odwołanego zarządcy sukcesyjnego.

***
## Art. 6654. {#kpc-pierwsza-druga-art-6654}

Wniosek 
o przedłużenie 
zarządu 
sukcesyjnego 
z ważnych 
przyczyn może złożyć każda osoba, na rzecz której działa zarządca sukcesyjny.

***
## Art. 6655. {#kpc-pierwsza-druga-art-6655}

**§ 1.** W sprawach ograniczenia zarządu sukcesyjnego majątkiem 
osoby, która nie ma zdolności do czynności prawnych albo której zdolność do 
czynności prawnych jest ograniczona, właściwy jest sąd opiekuńczy. 
**§ 2.** W sprawach, o których mowa w § 1, przepisy art. 568, art. 569, art. 570, 
art. 5701 § 1–2, art. 572–577, art. 578 § 1, art. 5781, art. 579 oraz art. 582 stosuje się 
odpowiednio. 

 
 
 
s. 309/580 
 
2025-09-08 
 
Rozdział 7 
Zarząd spadku nieobjętego

***
## Art. 666. {#kpc-pierwsza-druga-art-666}

**§ 1.** Do czasu objęcia spadku przez spadkobiercę sąd czuwa nad 
całością spadku, a w razie potrzeby ustanawia kuratora spadku. 
**§ 2.** Jeżeli inwentarz nie był przedtem spisany, sąd wyda postanowienie 
o sporządzeniu spisu inwentarza.

***
## Art. 667. {#kpc-pierwsza-druga-art-667}

**§ 1.** Kurator spadku powinien starać się o wyjaśnienie, kto jest 
spadkobiercą, i zawiadomić spadkobierców o otwarciu spadku. 
**§ 2.** Kurator spadku zarządza majątkiem spadkowym pod nadzorem sądu 
spadku. Do sprawowania zarządu stosuje się odpowiednio przepisy o zarządzie 
w toku egzekucji z nieruchomości. 
**§ 3.** W przypadku 
gdy 
w skład 
spadku 
wchodzi 
przedsiębiorstwo 
i ustanowiono zarząd sukcesyjny tym przedsiębiorstwem, jest ono wyłączone 
z zarządu majątkiem spadkowym sprawowanego przez kuratora spadku.

***
## Art. 668. {#kpc-pierwsza-druga-art-668}

Sąd spadku może nakazać sprzedaż należących do spadku rzeczy 
ruchomych, które są narażone na zepsucie albo których przechowanie pociąga za 
sobą nadmierne koszty. Sprzedaż nastąpi w sposób przewidziany dla sprzedaży 
ruchomości w toku egzekucji, chyba że sąd określi inny sposób sprzedaży.

***
## Art. 6681. {#kpc-pierwsza-druga-art-6681}

Sąd spadku, na wniosek banku w rozumieniu ustawy z dnia 
23 października 2014 r. o odwróconym kredycie hipotecznym, może upoważnić 
kuratora spadku do przeniesienia na bank własności nieruchomości lub prawa, 
o którym mowa w art. 4 ust. 2 tej ustawy, stanowiących zabezpieczenie 
odwróconego 
kredytu 
hipotecznego, 
i rozliczenia 
odwróconego 
kredytu 
hipotecznego. Wniosek może być złożony przez bank nie wcześniej niż po upływie 
roku od daty śmierci kredytobiorcy. W sprawach wynikających z rozliczenia 
odwróconego kredytu hipotecznego kurator spadku może pozywać lub być 
pozywany. 
Rozdział 8 
Stwierdzenie nabycia spadku i przedmiotu zapisu windykacyjnego

***
## Art. 669. {#kpc-pierwsza-druga-art-669}

Sąd spadku wydaje postanowienie o stwierdzeniu nabycia spadku 
po przeprowadzeniu rozprawy, na którą wzywa wnioskodawcę oraz osoby mogące 

 
 
 
s. 310/580 
 
2025-09-08 
 
wchodzić w rachubę jako spadkobiercy testamentowi i jako spadkobiercy 
ustawowi 
zgodnie 
z kolejnością 
dziedziczenia. 
Spośród 
spadkobierców 
ustawowych wzywa się małżonka, zstępnych, osoby pozostające w stosunku 
przysposobienia, rodziców i rodzeństwo. Pozostałych spadkobierców ustawowych 
wzywa się, jeżeli są sądowi znani.

***
## Art. 6691. {#kpc-pierwsza-druga-art-6691}

**§ 1.** Sąd spadku uchyla zarejestrowany akt poświadczenia 
dziedziczenia, jeżeli w odniesieniu do tego samego spadku zostało wydane 
postanowienie o stwierdzeniu nabycia spadku. 
**§ 2.** W przypadku zarejestrowania dwóch lub więcej aktów poświadczenia 
dziedziczenia w odniesieniu do tego samego spadku, sąd spadku na wniosek 
zainteresowanego uchyla wszystkie akty poświadczenia dziedziczenia i wydaje 
postanowienie o stwierdzeniu nabycia spadku. 
**§ 3.** Poza okolicznościami wskazanymi w § 1 i 2, uchylenie zarejestrowanego 
aktu poświadczenia dziedziczenia jest dopuszczalne jedynie w przypadkach 
wskazanych w ustawie. 
**§ 4.** (uchylony)

***
## Art. 670. {#kpc-pierwsza-druga-art-670}

**§ 1.** Sąd 
spadku 
bada 
z urzędu, 
kto 
jest 
spadkobiercą 
testamentowym oraz spadkobiercą ustawowym, o którym mowa w art. 669 zdanie 
drugie. W szczególności bada, czy spadkodawca pozostawił testament, oraz wzywa 
do złożenia testamentu osobę, co do której będzie uprawdopodobnione, że 
testament u niej się znajduje. Jeżeli testament zostanie złożony, sąd dokona jego 
otwarcia i ogłoszenia. 
**§ 2.** Sąd spadku ustala, czy w skład spadku wchodzi przedsiębiorstwo 
w spadku objęte zarządem sukcesyjnym.

***
## Art. 671. {#kpc-pierwsza-druga-art-671}

**§ 1.** Za dowód, że nie ma innych spadkobierców, może być przyjęte 
zapewnienie złożone przez zgłaszającego się spadkobiercę. 
**§ 2.** W zapewnieniu zgłaszający się powinien złożyć oświadczenie co do 
wszystkiego, co mu jest wiadome: 
- 1) o istnieniu lub nieistnieniu osób, które wyłączałyby znanych spadkobierców 
od dziedziczenia lub dziedziczyłyby wraz z nimi; 
- 2) o testamentach spadkodawcy. 

 
 
 
s. 311/580 
 
2025-09-08 
**§ 3.** Pod względem skutków karnych zapewnienie jest równoznaczne ze 
złożeniem zeznań pod przyrzeczeniem, o czym sędzia powinien uprzedzić 
składającego zapewnienie.

***
## Art. 672. {#kpc-pierwsza-druga-art-672}

Jeżeli zapewnienie nie było złożone albo jeżeli zapewnienie lub 
inne dowody nie będą uznane przez sąd za wystarczające, w szczególności gdy nie 
udało się ustalić spadkobierców, o których mowa w art. 669 zdanie drugie, 
postanowienie w sprawie stwierdzenia nabycia spadku może zapaść dopiero po 
wezwaniu spadkobierców przez ogłoszenie.

***
## Art. 673. {#kpc-pierwsza-druga-art-673}

Ogłoszenie powinno zawierać: 
- 1) imię, nazwisko, zawód oraz ostatnie miejsce zwykłego pobytu spadkodawcy; 
- 2) datę śmierci spadkodawcy; 
- 3) wskazanie majątku pozostałego po spadkodawcy; 
- 4) wezwanie, aby spadkobiercy w ciągu trzech miesięcy od dnia wskazanego 
w ogłoszeniu zgłosili i udowodnili nabycie spadku, gdyż w przeciwnym razie 
mogą być pominięci w postanowieniu o stwierdzeniu nabycia spadku.

***
## Art. 674. {#kpc-pierwsza-druga-art-674}

**§ 1.** Ogłoszenie 
zamieszcza 
się 
w Monitorze 
Sądowym 
i Gospodarczym oraz podaje publicznie do wiadomości w ostatnim miejscu 
zwykłego pobytu spadkodawcy, w sposób w tym miejscu przyjęty. 
**§ 2.** (uchylony)

***
## Art. 675. {#kpc-pierwsza-druga-art-675}

Po upływie trzech miesięcy od dnia ogłoszenia sąd wyznaczy w celu 
rozpoznania zgłoszonych żądań rozprawę, na którą wezwie także osoby, które 
zgłosiły żądanie i podały miejsce zamieszkania.

***
## Art. 676. {#kpc-pierwsza-druga-art-676}

Jeżeli w ciągu trzech miesięcy od dnia ogłoszenia o wezwaniu 
spadkobierców nikt nie zgłosił nabycia spadku albo zgłaszający się nie udowodnił 
go na rozprawie, sąd wyda postanowienie stwierdzające nabycie spadku przez 
spadkobierców, których prawa zostały ustalone.

***
## Art. 677. {#kpc-pierwsza-druga-art-677}

**§ 1.** Sąd stwierdzi nabycie spadku przez spadkobierców, choćby 
były nimi inne osoby niż te, które wskazali uczestnicy. 
**§ 11.** Postanowienie o stwierdzeniu nabycia spadku zawiera: 

 
 
 
s. 312/580 
 
2025-09-08 
- 1) imię i nazwisko spadkodawcy, imiona jego rodziców oraz jego numer PESEL, 
jeżeli został nadany, datę i miejsce zgonu albo znalezienia zwłok 
spadkodawcy oraz ostatnie miejsce jego zwykłego pobytu; 
- 2) wszystkich spadkobierców, którym spadek przypadł – ich imię albo imiona, 
nazwisko, imiona rodziców oraz datę i miejsce urodzenia osób fizycznych, 
a w przypadku osób prawnych – nazwę i siedzibę; 
- 3) tytuł powołania do spadku i wysokość udziałów w spadku, a w razie 
dziedziczenia testamentowego – określenie formy testamentu oraz powołanie 
protokołu otwarcia i ogłoszenia testamentu; 
- 4) sposób przyjęcia spadku; 
- 5) spadkobierców 
dziedziczących 
gospodarstwo 
rolne 
podlegające 
dziedziczeniu z ustawy oraz ich udziały w nim. 
**§ 2.** W postanowieniu o stwierdzeniu nabycia spadku sąd stwierdza także 
nabycie przedmiotu zapisu windykacyjnego, wymieniając osobę, dla której 
spadkodawca uczynił zapis windykacyjny, oraz przedmiot tego zapisu. Przepis § 
11 pkt 2 stosuje się odpowiednio. 
**§ 3.** Stwierdzenie nabycia przedmiotu zapisu windykacyjnego może nastąpić 
również przez wydanie przez sąd postanowienia częściowego.

***
## Art. 678. {#kpc-pierwsza-druga-art-678}

Jeżeli stwierdzone zostało nabycie spadku albo zarejestrowany 
został akt poświadczenia dziedziczenia po osobie uznanej za zmarłą lub której zgon 
został stwierdzony postanowieniem sądu, a postanowienie o uznaniu tej osoby za 
zmarłą lub o stwierdzeniu jej zgonu zostało uchylone, sąd spadku z urzędu uchyli 
postanowienie 
o stwierdzeniu 
nabycia 
spadku 
albo 
akt 
poświadczenia 
dziedziczenia.

***
## Art. 679. {#kpc-pierwsza-druga-art-679}

**§ 1.** Dowód, że osoba, która uzyskała stwierdzenie nabycia spadku, 
nie jest spadkobiercą lub że jej udział w spadku jest inny niż stwierdzony, może 
być przeprowadzony tylko w postępowaniu o uchylenie lub zmianę stwierdzenia 
nabycia spadku, z zastosowaniem przepisów niniejszego rozdziału. Jednakże ten, 
kto był uczestnikiem postępowania o stwierdzenie nabycia spadku, może tylko 
wówczas żądać zmiany postanowienia stwierdzającego nabycie spadku, gdy 
żądanie opiera na podstawie, której nie mógł powołać w tym postępowaniu, 

 
 
 
s. 313/580 
 
2025-09-08 
 
a wniosek o zmianę składa przed upływem roku od dnia, w którym uzyskał tę 
możność. 
**§ 2.** Wniosek o wszczęcie takiego postępowania może zgłosić każdy 
zainteresowany. 
**§ 3.** W razie przeprowadzenia dowodu, że spadek w całości lub w części 
nabyła inna osoba niż wskazana w prawomocnym postanowieniu o stwierdzeniu 
nabycia spadku, sąd spadku, zmieniając to postanowienie, stwierdzi nabycie spadku 
zgodnie z rzeczywistym stanem prawnym. 
**§ 4.** Przepisy § 1–3 stosuje się odpowiednio do zarejestrowanego aktu 
poświadczenia dziedziczenia oraz do stwierdzenia nabycia przedmiotu zapisu 
windykacyjnego.

***
## Art. 6791. {#kpc-pierwsza-druga-art-6791}

Prawomocne postanowienie o stwierdzeniu nabycia spadku, 
prawomocne 
postanowienie 
uchylające 
lub 
zmieniające 
postanowienie 
o stwierdzeniu nabycia spadku sąd niezwłocznie wpisuje, za pośrednictwem 
systemu teleinformatycznego, o którym mowa w art. 95i § 1 ustawy z dnia 
14 lutego 1991 r. – Prawo o notariacie (Dz. U. z 2024 r. poz. 1001), do Rejestru 
Spadkowego.

***
## Art. 6792. {#kpc-pierwsza-druga-art-6792}

Sąd niezwłocznie zawiadamia Krajową Radę Notarialną o wydaniu 
prawomocnego postanowienia uchylającego zarejestrowany akt poświadczenia 
dziedziczenia. Do zawiadomienia dołącza się odpis postanowienia. 
Rozdział 9 
Dział spadku

***
## Art. 680. {#kpc-pierwsza-druga-art-680}

**§ 1.** We wniosku o dział spadku należy powołać postanowienie 
o stwierdzeniu 
nabycia 
spadku 
albo 
zarejestrowany 
akt 
poświadczenia 
dziedziczenia oraz spis inwentarza, jak również podać, jakie spadkodawca 
sporządził testamenty, gdzie zostały złożone i gdzie się znajdują. Jeżeli spis 
inwentarza nie został sporządzony, należy we wniosku wskazać majątek, który ma 
być przedmiotem działu. 
**§ 2.** W wypadku gdy w skład spadku wchodzi nieruchomość, należy 
przedstawić dowody stwierdzające, że nieruchomość stanowiła własność 
spadkodawcy. 

 
 
 
s. 314/580 
 
2025-09-08

***
## Art. 681. {#kpc-pierwsza-druga-art-681}

Jeżeli stwierdzenie nabycia spadku jeszcze nie nastąpiło i nie został 
sporządzony zarejestrowany akt poświadczenia dziedziczenia, postanowienie 
o stwierdzeniu nabycia spadku wydaje sąd w toku postępowania działowego, 
stosując przepisy rozdziału 8.

***
## Art. 682. {#kpc-pierwsza-druga-art-682}

Współspadkobiercy powinni podać sądowi swój wiek, zawód, stan 
rodzinny oraz dane co do swych zarobków i majątku, a także zarobków i majątku 
małżonka, wyjaśnić, w jaki sposób korzystali ze spadku dotychczas, jak również 
podać inne okoliczności, które mogą mieć wpływ na rozstrzygnięcie, co każdy ze 
współspadkobierców ma otrzymać ze spadku. Jeżeli przedmiotem działu jest 
gospodarstwo rolne, współspadkobiercy powinni w szczególności podać dane 
dotyczące okoliczności przewidzianych w art. 214 kodeksu cywilnego.

***
## Art. 683. {#kpc-pierwsza-druga-art-683}

Na żądanie uczestnika działu, zgłoszone nie później niż na 
pierwszej rozprawie, sąd spadku może przekazać sprawę sądowi rejonowemu, 
w którego okręgu znajduje się spadek lub jego znaczna część, albo sądowi 
rejonowemu, w którego okręgu mieszkają wszyscy współspadkobiercy.

***
## Art. 684. {#kpc-pierwsza-druga-art-684}

Skład i wartość spadku ulegającego podziałowi ustala sąd.

***
## Art. 685. {#kpc-pierwsza-druga-art-685}

W razie sporu o istnienie uprawnienia do żądania działu spadku, jak 
również w razie sporu między współspadkobiercami o to, czy pewien przedmiot 
należy do spadku, sąd spadku może wydać postanowienie wstępne.

***
## Art. 686. {#kpc-pierwsza-druga-art-686}

W postępowaniu działowym sąd rozstrzyga także o istnieniu 
zapisów zwykłych, których przedmiotem są rzeczy lub prawa należące do spadku, 
jak również o wzajemnych roszczeniach pomiędzy współspadkobiercami z tytułu 
posiadania poszczególnych przedmiotów spadkowych, pobranych pożytków 
i innych przychodów, poczynionych na spadek nakładów i spłaconych długów 
spadkowych.

***
## Art. 687. {#kpc-pierwsza-druga-art-687}

W braku podstaw do wydania postanowienia działowego na 
podstawie zgodnego wniosku uczestników, dział spadku będzie rozpoznany 
według przepisów poniższych.

***
## Art. 688. {#kpc-pierwsza-druga-art-688}

Do działu spadku stosuje się odpowiednio przepisy dotyczące 
zniesienia współwłasności, a w szczególności art. 618 § 2 i 3. 

 
 
 
s. 315/580 
 
2025-09-08

***
## Art. 689. {#kpc-pierwsza-druga-art-689}

Jeżeli cały majątek spadkowy lub poszczególne rzeczy wchodzące 
w jego skład stanowią współwłasność z innego tytułu niż dziedziczenie, dział 
spadku i zniesienie współwłasności mogą być połączone w jednym postępowaniu. 
Rozdział 10 
Inne sprawy spadkowe

***
## Art. 690. {#kpc-pierwsza-druga-art-690}

**§ 1.** W razie uchylenia się od skutków prawnych oświadczenia 
o przyjęciu lub odrzuceniu spadku sąd przeprowadza rozprawę. 
**§ 2.** Jeżeli wskutek prawomocnego zatwierdzenia przez sąd uchylenia się, 
o którym mowa w § 1, ulega zmianie krąg osób, co do których nabycie spadku 
zostało już stwierdzone albo zarejestrowany został akt poświadczenia 
dziedziczenia, sąd po przeprowadzeniu rozprawy zmienia z urzędu postanowienie 
o stwierdzeniu nabycia spadku albo uchyla zarejestrowany akt poświadczenia 
dziedziczenia i orzeka w tym przedmiocie.

***
## Art. 691. {#kpc-pierwsza-druga-art-691}

**§ 1.** Do wniosku o zwolnienie wykonawcy testamentu uprawniona 
jest osoba zainteresowana. Rozstrzygnięcie wniosku nastąpi po wysłuchaniu 
wykonawcy testamentu. 
**§ 2.** Wykonawca testamentu zwolniony z obowiązków powinien zwrócić 
zaświadczenie o swych uprawnieniach. 
DZIAŁ IVa 
Sprawy z zakresu przepisów o przedsiębiorstwach państwowych 
i o samorządzie załogi przedsiębiorstwa państwowego

***
## Art. 6911. {#kpc-pierwsza-druga-art-6911}

**§ 1.** Przepisy niniejszego działu stosuje się w sprawach 
o rozstrzygnięcie sporu między: 
- 1) radą pracowniczą przedsiębiorstwa a dyrektorem przedsiębiorstwa; 
- 2) organami przedsiębiorstwa a organem założycielskim przedsiębiorstwa; 
- 3) organami 
przedsiębiorstwa 
a organem 
sprawującym 
nadzór 
nad 
przedsiębiorstwem. 
**§ 2.** Sprawy wymienione w § 1 rozpoznają sądy okręgowe.

***
## Art. 6912. {#kpc-pierwsza-druga-art-6912}

Właściwy jest sąd miejsca siedziby przedsiębiorstwa, z którego 
działalnością wiąże się przedmiot sporu. 

 
 
 
s. 316/580 
 
2025-09-08

***
## Art. 6913. {#kpc-pierwsza-druga-art-6913}

W sprawach, o których mowa w art. 6911, zdolność sądową mają 
ponadto dyrektor przedsiębiorstwa, działający w tym charakterze, oraz rada 
pracownicza przedsiębiorstwa.

***
## Art. 6914. {#kpc-pierwsza-druga-art-6914}

W imieniu rady pracowniczej przedsiębiorstwa może występować 
każdy wyznaczony przez radę jej członek.

***
## Art. 6915. {#kpc-pierwsza-druga-art-6915}

**§ 1.** Pełnomocnikiem rady pracowniczej może być również każdy 
pracownik przedsiębiorstwa, któremu przysługuje bierne prawo wyborcze do 
organów samorządu załogi przedsiębiorstwa, lub radca prawny niezatrudniony 
w tym przedsiębiorstwie. 
**§ 2.** Pełnomocnikiem dyrektora przedsiębiorstwa może być również radca 
prawny lub inny pracownik przedsiębiorstwa. 
**§ 3.** Pełnomocnikiem dyrektora przedsiębiorstwa i rady pracowniczej 
w sprawach między nimi a organem założycielskim lub organem sprawującym 
nadzór nad przedsiębiorstwem może być również radca prawny przedsiębiorstwa, 
chyba że między dyrektorem a radą zachodzi sprzeczność interesów.

***
## Art. 6916. {#kpc-pierwsza-druga-art-6916}

(uchylony)

***
## Art. 6917. {#kpc-pierwsza-druga-art-6917}

Orzeczenie 
rozstrzygające 
spór 
może 
zapaść 
tylko 
po 
przeprowadzeniu rozprawy.

***
## Art. 6918. {#kpc-pierwsza-druga-art-6918}

Koszty postępowania obciążające zarówno radę pracowniczą, jak 
i dyrektora przedsiębiorstwa ponosi przedsiębiorstwo.

***
## Art. 6919. {#kpc-pierwsza-druga-art-6919}

Przepisów niniejszego działu nie stosuje się w sprawach 
o odszkodowanie. 
DZIAŁ IVb 
Sprawy z zakresu prawa pracy

***
## Art. 69110. {#kpc-pierwsza-druga-art-69110}

**§ 1.** We wniosku zawierającym żądanie ustalenia uprawnienia do 
otrzymania świadectwa pracy wskazuje się: 
- 1) okres i rodzaj wykonywanej pracy, wymiar czasu pracy, zajmowane 
stanowiska oraz miejsce wykonywania pracy; 
- 2) tryb rozwiązania albo okoliczności wygaśnięcia stosunku pracy – jeżeli 
pracownik posiada te informacje, a w przypadku ich nieposiadania – 
okoliczności zaprzestania świadczenia pracy przez pracownika; 

 
 
 
s. 317/580 
 
2025-09-08 
- 3) pracodawcę, który był obowiązany do wydania świadectwa pracy, oraz 
przyczynę, z powodu której wystąpienie przeciwko niemu z żądaniem 
zobowiązania pracodawcy do wydania świadectwa pracy jest niemożliwe. 
**§ 2.** Jeżeli wytoczenie powództwa o zobowiązanie pracodawcy do wydania 
świadectwa pracy jest możliwe, sąd rozpozna żądanie w procesie jako żądanie 
zobowiązania pracodawcy do wydania świadectwa pracy. 
**§ 3.** W postanowieniu uwzględniającym żądanie ustalenia uprawnienia do 
otrzymania świadectwa pracy sąd określa treść świadectwa pracy zgodnie 
z art. 97 § 2 ustawy z dnia 26 czerwca 1974 r. – Kodeks pracy i przepisami 
wydanymi na podstawie art. 97 § 4 tej ustawy. Jeżeli określenie wszystkich faktów 
wymienionych w tych przepisach jest niemożliwe, w postanowieniu określa się co 
najmniej okres i rodzaj wykonywanej pracy, wymiar czasu pracy, zajmowane 
stanowiska oraz tryb rozwiązania albo okoliczności wygaśnięcia stosunku pracy, 
a w sytuacji gdy określenie trybu rozwiązania albo okoliczności wygaśnięcia 
stosunku pracy również jest niemożliwe – wskazuje się, że rozwiązanie stosunku 
pracy nastąpiło za wypowiedzeniem dokonanym przez pracodawcę. 
**§ 4.** Prawomocne postanowienie ustalające uprawnienie do otrzymania 
świadectwa pracy zastępuje to świadectwo.

***
## Art. 69111. {#kpc-pierwsza-druga-art-69111}

Przepis 
art. 69110 stosuje 
się 
odpowiednio 
do 
żądania 
sprostowania świadectwa pracy. 
#### DZIAŁ V
Sprawy depozytowe 
Rozdział 1 
Złożenie przedmiotu świadczenia do depozytu sądowego

***
## Art. 692. {#kpc-pierwsza-druga-art-692}

W sprawach o złożenie przedmiotu świadczenia do depozytu 
sądowego właściwy jest sąd miejsca wykonania zobowiązania. Jeżeli miejsca tego 
nie da się ustalić, właściwy jest sąd miejsca zamieszkania wierzyciela, a gdy 
wierzyciel jest nieznany lub gdy nie jest znane miejsce jego zamieszkania – sąd 
miejsca zamieszkania dłużnika. Jeżeli zobowiązanie jest zabezpieczone wpisem 
w księdze wieczystej, właściwy jest sąd miejsca położenia nieruchomości. 

 
 
 
s. 318/580 
 
2025-09-08

***
## Art. 693. {#kpc-pierwsza-druga-art-693}

We wniosku o złożenie przedmiotu świadczenia do depozytu 
sądowego należy: 
- 1) określić zobowiązanie, przy wykonaniu którego składa się przedmiot; 
- 2) przytoczyć okoliczności uzasadniające złożenie; 
- 3) dokładnie oznaczyć przedmiot, który ma być złożony; 
- 4) wskazać osobę, której przedmiot ma być wydany, oraz warunki, pod którymi 
wydanie ma nastąpić.

***
## Art. 6931. {#kpc-pierwsza-druga-art-6931}

W postępowaniu o złożenie przedmiotu świadczenia do depozytu 
sądowego sąd nie bada prawdziwości twierdzeń zawartych we wniosku, 
ograniczając się do oceny, czy według przytoczonych okoliczności złożenie do 
depozytu jest prawnie uzasadnione.

***
## Art. 6932. {#kpc-pierwsza-druga-art-6932}

**§ 1.** Złożenie przedmiotu świadczenia do depozytu sądowego może 
być dokonane dopiero po uzyskaniu zezwolenia sądu. 
**§ 2.** Jeżeli jednak przedmiotem świadczenia są pieniądze polskie, złożenie do 
depozytu może być dokonane również przed uzyskaniem zezwolenia sądu. 
W takim wypadku dłużnik powinien równocześnie ze złożeniem pieniędzy zgłosić 
wniosek o zezwolenie na złożenie do depozytu. W razie uwzględnienia tego 
wniosku złożenie do depozytu uważa się za dokonane w chwili, w której 
rzeczywiście nastąpiło. 
**§ 3.** Jeżeli przedmiotem świadczenia są pieniądze, złożenie do depozytu 
sądowego następuje przez wpłatę na rachunek depozytowy Ministra Finansów.

***
## Art. 6933. {#kpc-pierwsza-druga-art-6933}

**§ 1.** Jeżeli wierzyciel lub jego miejsce zamieszkania nie są znane, 
sąd zarządza zamieszczenie ogłoszenia o zezwoleniu na złożenie przedmiotu 
świadczenia do depozytu sądowego na stronie internetowej sądu oraz tablicy 
ogłoszeń w budynku sądu, a także na tablicach ogłoszeń i stronach internetowych 
urzędów obsługujących organy wykonawcze gminy i powiatu ostatniego miejsca 
zamieszkania tego wierzyciela, o ile jest ono znane. Jeżeli wartość przedmiotu 
świadczenia składanego do depozytu sądowego przekracza pięć tysięcy złotych sąd 
zarządza 
zamieszczenie 
ogłoszenia 
również 
w Monitorze 
Sądowym 
i Gospodarczym. 
**§ 2.** Ogłoszenie powinno zawierać dane określone w art. 693 pkt 1, 3 i 4 oraz 
wezwanie wierzyciela do odbioru depozytu. 

 
 
 
s. 319/580 
 
2025-09-08 
**§ 3.** Jeżeli wierzyciel lub jego miejsce zamieszkania nie są znane, sąd 
ustanawia kuratora. Przepis art. 510 § 2 stosuje się odpowiednio.

***
## Art. 6934. {#kpc-pierwsza-druga-art-6934}

**§ 1.** Sąd 
może 
zażądać, 
aby 
depozyt 
został 
złożony 
w odpowiednim opakowaniu. 
**§ 2.** Przed przyjęciem kosztowności do depozytu sądowego poddaje się je 
opisowi i oszacowaniu przez biegłego w obecności dłużnika lub wyznaczonej przez 
niego osoby.

***
## Art. 6935. {#kpc-pierwsza-druga-art-6935}

**§ 1.** Jeżeli dłużnik jest zobowiązany do świadczeń powtarzających 
się, a zachodzą warunki do złożenia do depozytu sądowego świadczeń już 
wymagalnych, sąd może zezwolić dłużnikowi na składanie w przyszłości do 
depozytu dalszych świadczeń w chwili, gdy staną się wymagalne. O złożeniu 
każdego świadczenia sąd zawiadamia wierzyciela. 
**§ 2.** Na wniosek wierzyciela sąd uchyli postanowienie o zezwoleniu 
dłużnikowi na składanie do depozytu świadczeń na zasadach określonych w § 1, 
jeżeli wierzyciel wyrazi gotowość przyjmowania i pokwitowania odbioru dalszych 
świadczeń wymagalnych.

***
## Art. 6936. {#kpc-pierwsza-druga-art-6936}

**§ 1.** Przyjmowane do depozytu sądowego: 
- 1) pieniądze – przechowuje się na rachunku depozytowym Ministra Finansów; 
- 2) kosztowności, książeczki oszczędnościowe, papiery wartościowe i inne 
dokumenty oraz przedmioty, które mają być przyjęte do depozytu sądowego 
na podstawie przepisów szczególnych – przechowuje się w sądzie lub 
w banku; 
- 3) inne przedmioty – przechowuje się w miejscu wyznaczonym przez sąd. 
**§ 2.** Jeżeli przedmiotem świadczenia jest książeczka oszczędnościowa, 
a przechowanie 
nie 
następuje 
u jej 
wystawcy, 
o przyjęciu 
książeczki 
oszczędnościowej do depozytu sąd zawiadomi tego wystawcę.

***
## Art. 6937. {#kpc-pierwsza-druga-art-6937}

**§ 1.** W celu 
sprawowania 
dozoru 
nad 
przedmiotami 
przechowywanymi w wyznaczonym miejscu sąd ustanowi dozorcę. Przed 
wydaniem postanowienia sąd wysłucha wniosku dłużnika co do osoby dozorcy. Na 
postanowienie sądu przysługuje zażalenie. 
**§ 2.** Do dozorcy stosuje się odpowiednio przepisy dotyczące dozorcy w toku 
egzekucji sądowej. 

 
 
 
s. 320/580 
 
2025-09-08

***
## Art. 6938. {#kpc-pierwsza-druga-art-6938}

Dokumenty i inne depozyty rzeczowe przechowuje się w stanie 
niezmienionym.

***
## Art. 6939. {#kpc-pierwsza-druga-art-6939}

**§ 1.** Jeżeli przedmiotem świadczenia, które ma być złożone do 
depozytu sądowego, jest rzecz ruchoma ulegająca łatwemu zepsuciu, jak również 
rzecz 
ruchoma, 
której 
przechowywanie 
byłoby 
związane 
z kosztami 
niewspółmiernie wysokimi w stosunku do jej wartości lub nadmiernymi 
trudnościami albo powodowałoby znaczne obniżenie jej wartości, sąd na wniosek 
dłużnika zarządzi postanowieniem sprzedaż rzeczy według przepisów o egzekucji 
z ruchomości. 
**§ 2.** Uzyskaną ze sprzedaży kwotę komornik składa na rachunek depozytowy 
Ministra Finansów.

***
## Art. 69310. {#kpc-pierwsza-druga-art-69310}

Po przyjęciu depozytu sąd wyda dłużnikowi pokwitowanie. 
Rozdział 2 
Zwrot depozytu sądowego składającemu i wydanie depozytu sądowego 
uprawnionemu

***
## Art. 69311. {#kpc-pierwsza-druga-art-69311}

**§ 1.** Na żądanie dłużnika sąd zwróci mu depozyt, jeżeli wierzyciel 
nie zażądał wydania depozytu. 
**§ 2.** Jeżeli wniosek dłużnika o zwrot depozytu i wniosek wierzyciela 
o wydanie zostały zgłoszone równocześnie, sąd postanowi wydać depozyt 
wierzycielowi.

***
## Art. 69312. {#kpc-pierwsza-druga-art-69312}

W razie złożenia depozytu na skutek orzeczenia sądu lub innego 
organu, depozyt nie może być zwrócony dłużnikowi bez zezwolenia sądu lub 
innego organu, który wydał to orzeczenie, chyba że z orzeczenia wynika co innego.

***
## Art. 69313. {#kpc-pierwsza-druga-art-69313}

Jeżeli złożenie przedmiotu do depozytu nastąpiło w celu nadania 
klauzuli wykonalności tytułowi egzekucyjnemu, depozyt nie może być zwrócony 
dłużnikowi bez zgody wierzyciela, chyba że wniosek o nadanie klauzuli 
wykonalności został cofnięty.

***
## Art. 69314. {#kpc-pierwsza-druga-art-69314}

Na żądanie wierzyciela sąd postanowi wydać mu depozyt, jeżeli 
zachodzą warunki określone we wniosku o złożenie do depozytu. 

 
 
 
s. 321/580 
 
2025-09-08

***
## Art. 69315. {#kpc-pierwsza-druga-art-69315}

Jeżeli zobowiązanie było zabezpieczone wpisem w księdze 
wieczystej, a na skutek złożenia przedmiotu świadczenia do depozytu nastąpiło 
wykreślenie tego wpisu, dłużnik może żądać wydania mu depozytu tylko za zgodą 
wierzyciela, chyba że przepis szczególny stanowi inaczej.

***
## Art. 69316. {#kpc-pierwsza-druga-art-69316}

Na żądanie dłużnika, zgłoszone przed wydaniem przez sąd 
postanowienia o wydaniu depozytu, sąd przyzna mu od wierzyciela zwrot kosztów 
postępowania.

***
## Art. 69317. {#kpc-pierwsza-druga-art-69317}

Jeżeli złożenie do depozytu sądowego nastąpiło na żądanie 
właściwego organu, depozyt wydaje się osobie uprawnionej dopiero po wykazaniu 
przez nią, że warunki, pod którymi wydanie depozytu mogło nastąpić, zostały 
spełnione. 
Rozdział 3 
Postępowanie w sprawach o stwierdzenie likwidacji niepodjętego depozytu

***
## Art. 69318. {#kpc-pierwsza-druga-art-69318}

**§ 1.** Przepisy niniejszego rozdziału stosuje się w sprawach 
o stwierdzenie likwidacji niepodjętych depozytów, o ile przepisy innych ustaw nie 
stanowią inaczej. 
**§ 2.** W sprawach, o których mowa w § 1, właściwy jest sąd miejsca złożenia 
depozytu.

***
## Art. 69319. {#kpc-pierwsza-druga-art-69319}

**§ 1.** We wniosku o stwierdzenie likwidacji niepodjętego depozytu 
należy: 
- 1) wskazać okoliczności, w których nastąpiło złożenie depozytu; 
- 2) dokładnie określić depozyt podlegający likwidacji; 
- 3) wskazać osobę, która jest uprawniona do odbioru depozytu. 
**§ 2.** W przypadku gdy nie jest znana osoba uprawniona do odbioru depozytu 
lub nie jest znane jej miejsce zamieszkania lub siedziba, wnioskodawca jest 
obowiązany przedstawić dowody potwierdzające dokonanie czynności mających 
na celu wyjaśnienie tych okoliczności.

***
## Art. 69320. {#kpc-pierwsza-druga-art-69320}

W sprawie o stwierdzenie likwidacji niepodjętego depozytu sąd 
może wszcząć postępowanie z urzędu. 

 
 
 
s. 322/580 
 
2025-09-08

***
## Art. 69321. {#kpc-pierwsza-druga-art-69321}

Uczestników, którzy nie są znani lub których miejsce 
zamieszkania lub siedziba nie jest znane, sąd wzywa do udziału w postępowaniu 
przez obwieszczenie publiczne w budynku sądowym.

***
## Art. 69322. {#kpc-pierwsza-druga-art-69322}

Do wykonania orzeczenia o stwierdzeniu likwidacji niepodjętego 
depozytu jest obowiązany naczelnik właściwego urzędu skarbowego w trybie i na 
zasadach określonych w przepisach o postępowaniu egzekucyjnym w admini-
stracji. 
#### DZIAŁ VI
Postępowanie rejestrowe

***
## Art. 6941. {#kpc-pierwsza-druga-art-6941}

**§ 1.** Przepisy zawarte w niniejszym dziale stosuje się do 
postępowań w sprawach, w których właściwy jest sąd rejonowy (sąd gospodarczy) 
prowadzący Krajowy Rejestr Sądowy (sprawy rejestrowe). 
**§ 2.** Przepisy niniejszego działu stosuje się odpowiednio do postępowań 
rejestrowych prowadzonych przez inne sądy, jeżeli przepisy szczególne nie 
stanowią inaczej.

***
## Art. 6942. {#kpc-pierwsza-druga-art-6942}

W sprawach rejestrowych wyłącznie właściwy jest sąd rejonowy 
(sąd gospodarczy) właściwy ze względu na miejsce zamieszkania lub wpisaną 
w rejestrze siedzibę podmiotu, którego sprawa dotyczy (sąd rejestrowy). Przepisu 
art. 508 § 1 zdanie pierwsze nie stosuje się.

***
## Art. 6942a. {#kpc-pierwsza-druga-art-6942a}

Jeżeli postępowanie przed sądem rejestrowym odbywa się za 
pośrednictwem systemu teleinformatycznego, czynności sądu, referendarza 
sądowego i przewodniczącego są utrwalane wyłącznie w tym systemie, 
a wytworzone w ich wyniku dane w postaci elektronicznej opatrywane są 
kwalifikowanym podpisem elektronicznym.

***
## Art. 6943. {#kpc-pierwsza-druga-art-6943}

**§ 1.** Wniosek do sądu rejestrowego prowadzącego Krajowy Rejestr 
Sądowy składa podmiot podlegający wpisowi do tego rejestru, jeżeli przepisy 
szczególne nie stanowią inaczej. 
**§ 2.** Podmiot podlegający wpisowi do Krajowego Rejestru Sądowego jest 
uczestnikiem postępowania, chociażby nie był wnioskodawcą. Przepisu 
art. 510 § 2 nie stosuje się. 

 
 
 
s. 323/580 
 
2025-09-08 
**§ 21.** Brak organu lub brak w składzie organu powołanego do reprezentacji 
podmiotu podlegającego wpisowi do Krajowego Rejestru Sądowego nie stanowi 
przeszkody do dokonania wpisu z urzędu. 
**§ 3.** (uchylony) 
**§ 31.** (uchylony) 
**§ 32.** Do wniosku złożonego przez pełnomocnika za pośrednictwem systemu 
teleinformatycznego pełnomocnik dołącza pełnomocnictwo lub jego odpis. 
[Przepisu art. 89 § 11 nie stosuje się.] 
**§ 4.** W postępowaniu przed sądem drugiej instancji przepisu art. 1311 § 1 nie 
stosuje się. 
**§ 5.** (uchylony) 
**§ 6.** Jeżeli postępowanie przed sądem rejestrowym odbywa się za 
pośrednictwem systemu teleinformatycznego, przepisu art. 1311 § 21 nie stosuje 
się.

***
## Art. 6943a. {#kpc-pierwsza-druga-art-6943a}

**§ 1.** Jeżeli wniosek w postępowaniu przed sądem rejestrowym 
został złożony za pośrednictwem systemu teleinformatycznego, wszelkie pisma 
w tej sprawie wnosi się wyłącznie za pośrednictwem systemu teleinformatycznego, 
z wyłączeniem środków zaskarżenia, do których rozpoznania właściwy jest Sąd 
Najwyższy. Przepisów art. 125 § 24 i art. 1311 § 21 nie stosuje się. 
**§ 2.** Sąd rejestrowy przy pierwszym doręczeniu w sprawie poucza o treści 
art. 125 § 21 zdanie drugie. 
**§ 3.** Jeżeli pismo dotyczące podmiotu podlegającego wpisowi do rejestru 
przedsiębiorców lub w sprawie, w której wniosek został złożony w sposób, 
o którym mowa w § 1, zostało wniesione w postaci papierowej, a wnoszący pismo 
nie był pouczony o treści art. 125 § 21 zdanie drugie, przewodniczący wzywa do 
jego wniesienia za pośrednictwem systemu teleinformatycznego w terminie 
tygodniowym od dnia doręczenia wezwania, pouczając o treści tego przepisu. 
Przepis art. 130 § 3 stosuje się. Przepis art. 125 § 21 zdanie drugie nie stanowi 
przeszkody do podjęcia przez sąd rejestrowy czynności z urzędu. 
**§ 4.** Sąd odrzuca apelację, zażalenie albo skargę na orzeczenie referendarza 
sądowego złożone z naruszeniem § 1, jeżeli strona nie uczyniła zadość wezwaniu, 
o którym mowa w § 3, albo będąc pouczoną o treści art. 125 § 21 zdanie drugie, nie 
złożyła środka zaskarżenia za pośrednictwem systemu teleinformatycznego. 
Zmiana 
(skreślenie 
zdania drugiego) 
w § 32 w art. 6943 
wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 
 

 
 
 
s. 324/580 
 
2025-09-08

***
## Art. 6943b. {#kpc-pierwsza-druga-art-6943b}

Do 
pisma 
wnoszonego 
za 
pośrednictwem 
systemu 
teleinformatycznego dołącza się załączniki w postaci elektronicznej.

***
## Art. 6944. {#kpc-pierwsza-druga-art-6944}

**§ 1.** Dokumenty stanowiące podstawę wpisu do Krajowego 
Rejestru Sądowego albo podlegające złożeniu do akt rejestrowych składa się 
w oryginałach albo poświadczonych urzędowo odpisach lub wyciągach. 
**§ 11.** Ilekroć konieczne jest badanie tytułu wykonawczego, o którym mowa 
w art. 783 § 4, do wniosku o dokonanie wpisu należy dołączyć dokument uzyskany 
z systemu teleinformatycznego umożliwiający sądowi weryfikację istnienia i treści 
tytułu wykonawczego. Przed rozpoznaniem tego wniosku istnienie i treść tytułu 
wykonawczego podlegają zweryfikowaniu przez sędziego lub referendarza 
sądowego w systemie teleinformatycznym. 
**§ 2.** Dokumenty, o których mowa w § 1, stanowiące załączniki do wniosku 
złożonego za pośrednictwem systemu teleinformatycznego, sporządzone w postaci 
elektronicznej, opatruje się kwalifikowanym podpisem elektronicznym, podpisem 
zaufanym albo podpisem osobistym. 
**§ 21.** (uchylony) 
**§ 22.** Jeżeli dokumenty, o których mowa w § 1, zostały sporządzone w postaci 
papierowej, do wniosku dołącza się: 
[1) odpisy elektronicznie poświadczone przez notariusza albo występującego 
w sprawie pełnomocnika, będącego adwokatem, radcą prawnym lub radcą 
Prokuratorii Generalnej Rzeczypospolitej Polskiej, albo] 
<1) odpisy elektronicznie poświadczone przez notariusza albo występującego 
w sprawie pełnomocnika będącego adwokatem lub radcą prawnym, albo 
radcę lub referendarza Prokuratorii Generalnej Rzeczypospolitej 
Polskiej, albo> 
- 2) elektroniczne kopie dokumentów. 
**§ 23.** W przypadku, o którym mowa w § 22 pkt 2, oryginał dokumentu albo 
jego odpis lub wyciąg poświadczony urzędowo przesyła się do sądu rejestrowego 
w terminie 3 dni od daty złożenia pisma. Przepisy art. 130 § 1–4 stosuje się 
odpowiednio. 
**§ 24.** Podmioty dokonujące zgłoszenia okoliczności, o których mowa 
w art. 41 pkt 1 i 2 ustawy z dnia 20 sierpnia 1997 r. o Krajowym Rejestrze 
Nowe brzmienie 
pkt 1 w § 22 w art. 
6944 wejdzie w 
życie 
z 
dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 
 

 
 
 
s. 325/580 
 
2025-09-08 
 
Sądowym, mogą także dokonać samodzielnie elektronicznego poświadczenia 
dokumentów.  
**§ 3.** (uchylony)

***
## Art. 6944a. {#kpc-pierwsza-druga-art-6944a}

[§ 1. Elektroniczne poświadczenie odpisu dokumentu przez 
występującego w sprawie pełnomocnika będącego adwokatem, radcą prawnym lub 
radcą Prokuratorii Generalnej Rzeczypospolitej Polskiej lub elektroniczne uwie-
rzytelnienie odpisu udzielonego mu pełnomocnictwa następuje z chwilą 
wprowadzenia przez tego pełnomocnika odpisu dokumentu lub odpisu 
pełnomocnictwa do systemu teleinformatycznego.] 
<§ 1. Elektroniczne 
poświadczenie 
odpisu 
dokumentu 
przez 
występującego w sprawie pełnomocnika będącego adwokatem lub radcą 
prawnym 
albo 
radcę 
lub 
referendarza 
Prokuratorii 
Generalnej 
Rzeczypospolitej 
Polskiej, 
lub 
elektroniczne 
uwierzytelnienie 
odpisu 
udzielonego mu pełnomocnictwa następuje z chwilą wprowadzenia przez tego 
pełnomocnika odpisu dokumentu lub odpisu pełnomocnictwa do systemu 
teleinformatycznego.> 
**§ 2.** Przepis § 1 stosuje się odpowiednio do elektronicznego poświadczenia 
odpisu dokumentu lub elektronicznego uwierzytelnienia odpisu udzielonego 
pełnomocnictwa przez podmiot dokonujący zgłoszenia okoliczności, o których 
mowa w art. 41 pkt 1 i 2 ustawy z dnia 20 sierpnia 1997 r. o Krajowym Rejestrze 
Sądowym.

***
## Art. 6945. {#kpc-pierwsza-druga-art-6945}

**§ 1.** Wpis do Krajowego Rejestru Sądowego następuje na 
podstawie postanowienia, jeżeli przepis szczególny nie stanowi inaczej. 
**§ 2.** Postanowienia o wpisie są skuteczne i wykonalne z chwilą ich wydania, 
z wyjątkiem postanowień dotyczących wykreślenia podmiotu z Krajowego 
Rejestru Sądowego. 
**§ 3.** Postanowieniom dotyczącym stosowania środków przymusu sąd 
rejestrowy może nadać rygor natychmiastowej wykonalności, jeżeli wymaga tego 
interes wierzyciela lub innych osób.

***
## Art. 6946. {#kpc-pierwsza-druga-art-6946}

**§ 1.** Postanowienie 
w przedmiocie 
wpisu 
oraz 
złożenia 
dokumentów do akt rejestrowych wydane zgodnie z wnioskiem nie wymaga 
uzasadnienia. 
Nowe brzmienie 
§ 1 w art. 6944a 
wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 
 

 
 
 
s. 326/580 
 
2025-09-08 
**§ 11.** W sprawie innej niż sprawa o wpis do rejestru, w której wnioskodawca 
jest jedynym uczestnikiem postępowania, przepis § 1 stosuje się odpowiednio. 
**§ 2.** Sąd rejestrowy z urzędu sporządza uzasadnienie postanowienia co do 
istoty sprawy, które zostało wydane z urzędu. 
**§ 3.** Sąd rejestrowy przy doręczeniu postanowienia o wpisie do rejestru 
spółki, o której mowa w art. 38 pkt 8 lit. f ustawy z dnia 20 sierpnia 1997 r. 
o Krajowym Rejestrze Sądowym, poucza o treści art. 45 ust. 1b tej ustawy.

***
## Art. 6946a. {#kpc-pierwsza-druga-art-6946a}

Po przedstawieniu lub udostępnieniu akt sprawy sądowi drugiej 
instancji na skutek wniesionego środka odwoławczego pisma oraz dokumenty 
mogą być składane w postaci papierowej do czasu zakończenia postępowania przed 
tym sądem.

***
## Art. 6947. {#kpc-pierwsza-druga-art-6947}

W razie uwzględnienia środka odwoławczego od orzeczenia 
wydanego w postępowaniu rejestrowym, dotyczącego wpisu do Krajowego 
Rejestru Sądowego, sąd drugiej instancji uchyla zaskarżone orzeczenie i przekazuje 
sprawę do ponownego rozpoznania sądowi rejestrowemu. Rozpoznając ponownie 
sprawę, sąd rejestrowy uwzględnia wskazania sądu drugiej instancji oraz aktualny 
stan rejestru.

***
## Art. 6948. {#kpc-pierwsza-druga-art-6948}

**§ 1.** Koszty 
postępowania 
rejestrowego 
ponosi 
podmiot 
podlegający obowiązkowi wpisu do Krajowego Rejestru Sądowego. 
**§ 2.** Koszty postępowania wszczętego przez osobę, która nie jest upoważniona 
do działania w imieniu podmiotu podlegającego obowiązkowi wpisu do Krajowego 
Rejestru Sądowego, ponosi wnioskodawca, chyba że wniosek jego został 
uwzględniony w całości lub w istotnej części. 
**§ 3.** (uchylony)

