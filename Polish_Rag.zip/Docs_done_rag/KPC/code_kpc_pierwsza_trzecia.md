---
id: code.kpc.czesc.pierwsza.ksiega.trzecia
title: "Kodeks postępowania cywilnego — CZĘŚĆ PIERWSZA — KSIĘGA TRZECIA ((zawierająca art. 695–715 – uchylona))"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1964 Nr 43 poz. 296"
consolidated_citation: "t.j. Dz.U. 2024 poz. 1568, 1841; Dz.U. 2025 poz. 620, 1172"
status: "obowiązujący"
last_consolidated: "2025-09-08"
aliases: ["KPC — CZĘŚĆ PIERWSZA — Księga TRZECIA"]
tags: ["KPC","Kodeks postępowania cywilnego","CZĘŚĆ PIERWSZA","Księga TRZECIA","PL"]
source_pdf: "D19640296Lj.pdf"
articles: ""
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpc-pierwsza-trzecia-art-{n}}"
  separators: "***"
  hierarchy: ["CZĘŚĆ","KSIĘGA","TYTUŁ","DZIAŁ","Rozdział"]
---

# Kodeks postępowania cywilnego — CZĘŚĆ PIERWSZA — KSIĘGA TRZECIA: (zawierająca art. 695–715 – uchylona)

(zawierająca art. 695–715 – uchylona)
