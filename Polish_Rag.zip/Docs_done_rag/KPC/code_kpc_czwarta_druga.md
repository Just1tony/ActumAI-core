---
id: code.kpc.czesc.czwarta.ksiega.druga
title: "Kodeks postępowania cywilnego — CZĘŚĆ CZWARTA — KSIĘGA DRUGA (POSTĘPOWANIE)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1964 Nr 43 poz. 296"
consolidated_citation: "t.j. Dz.U. 2024 poz. 1568, 1841; Dz.U. 2025 poz. 620, 1172"
status: "obowiązujący"
last_consolidated: "2025-09-08"
aliases: ["KPC — CZĘŚĆ CZWARTA — Księga DRUGA"]
tags: ["KPC","Kodeks postępowania cywilnego","CZĘŚĆ CZWARTA","Księga DRUGA","PL"]
source_pdf: "D19640296Lj.pdf"
articles: "Art. 1117–114413"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpc-czwarta-druga-art-{n}}"
  separators: "***"
  hierarchy: ["CZĘŚĆ","KSIĘGA","TYTUŁ","DZIAŁ","Rozdział"]
---

# Kodeks postępowania cywilnego — CZĘŚĆ CZWARTA — KSIĘGA DRUGA: POSTĘPOWANIE

POSTĘPOWANIE 
### TYTUŁ I
Zdolność sądowa i procesowa
***
## Art. 1117. {#kpc-czwarta-druga-art-1117}

**§ 1.** Zdolność sądową cudzoziemców, zagranicznych osób 
prawnych i jednostek organizacyjnych niebędących osobami prawnymi określa się 
według prawa właściwego dla ich zdolności prawnej. 
**§ 2.** Zdolność procesową podmiotów wymienionych w § 1 określa się według 
prawa właściwego dla ich zdolności do czynności prawnych. 
**§ 3.** Cudzoziemiec 
niemający 
zdolności 
procesowej 
według 
prawa 
wskazanego w § 2 może dokonywać czynności procesowych przed sądem polskim, 
jeżeli miałby zdolność procesową według prawa polskiego.

***
## Art. 1118. {#kpc-czwarta-druga-art-1118}

(uchylony) 
### TYTUŁ II
Zabezpieczenie kosztów procesu

***
## Art. 1119. {#kpc-czwarta-druga-art-1119}

Powód, który nie ma miejsca zamieszkania lub zwykłego pobytu 
albo siedziby w Rzeczypospolitej Polskiej lub w innym państwie członkowskim 
Unii Europejskiej, jest obowiązany na żądanie pozwanego złożyć kaucję na 
zabezpieczenie kosztów procesu.

***
## Art. 1120. {#kpc-czwarta-druga-art-1120}

Powód nie ma obowiązku określonego w art. 1119: 
- 1) jeżeli ma w Rzeczypospolitej Polskiej majątek wystarczający na zapłatę 
kosztów; 
- 2) jeżeli przysługuje mu lub uzyskał zwolnienie od kosztów sądowych; 

 
 
 
s. 535/580 
 
2025-09-08 
- 3) w sprawach małżeńskich niemajątkowych, w sprawach z powództwa 
wzajemnego 
oraz 
w postępowaniu 
nakazowym, 
upominawczym 
i uproszczonym; 
- 4) w sprawach, które strony zgodnie poddały jurysdykcji sądów polskich; 
- 5) jeżeli orzeczenie sądu polskiego zasądzające koszty procesu od powoda na 
rzecz pozwanego byłoby wykonalne w państwie, w którym powód ma 
miejsce zamieszkania lub zwykłego pobytu albo siedzibę.

***
## Art. 1121. {#kpc-czwarta-druga-art-1121}

**§ 1.** Pozwany może zgłosić żądanie zabezpieczenia kosztów przed 
wdaniem się w spór co do istoty sprawy. 
**§ 2.** Późniejsze zgłoszenie żądania jest dopuszczalne, jeżeli dopiero w toku 
sprawy: 
- 1) pozwany dowiedział się, że powód nie ma miejsca zamieszkania lub zwykłego 
pobytu albo siedziby w Rzeczypospolitej Polskiej lub w innym państwie 
członkowskim Unii Europejskiej; 
- 2) ustała podstawa prawna do zwolnienia powoda od obowiązku złożenia kaucji.

***
## Art. 1122. {#kpc-czwarta-druga-art-1122}

Pozwany nie ma prawa domagać się złożenia kaucji, jeżeli uznana 
przez niego część roszczenia powoda wystarcza na zabezpieczenie kosztów.

***
## Art. 1123. {#kpc-czwarta-druga-art-1123}

**§ 1.** Sąd oznaczy wysokość kaucji, mając na względzie 
prawdopodobną sumę kosztów, które poniesie pozwany, jednak bez włączenia 
kosztów powództwa wzajemnego. 
**§ 2.** Jeżeli w toku sprawy okaże się, że kaucja nie wystarcza, pozwany może 
żądać dodatkowego zabezpieczenia. 
**§ 3.** Kaucję składa się na rachunek depozytowy Ministra Finansów, chyba że 
sąd określi inny sposób jej złożenia.

***
## Art. 1124. {#kpc-czwarta-druga-art-1124}

**§ 1.** Zgłaszając w przepisanym czasie wniosek o zabezpieczenie 
kosztów, pozwany nie ma obowiązku składać wyjaśnień co do istoty sprawy przed 
rozstrzygnięciem tego wniosku. 
**§ 2.** Sąd wyznaczy powodowi termin do złożenia kaucji. 
**§ 3.** Po bezskutecznym upływie terminu sąd odrzuca pozew lub środek 
odwoławczy, orzekając o kosztach jak w przypadku cofnięcia pozwu. 

 
 
 
s. 536/580 
 
2025-09-08

***
## Art. 1125. {#kpc-czwarta-druga-art-1125}

Jeżeli w toku postępowania ustanie przyczyna zabezpieczenia, sąd 
na wniosek powoda, po wysłuchaniu pozwanego, zwolni powoda od obowiązku 
zabezpieczenia kosztów i zarządzi zwrot złożonej kaucji.

***
## Art. 1126. {#kpc-czwarta-druga-art-1126}

**§ 1.** Sąd na wniosek pozwanego zarządzi zaspokojenie z kaucji 
przyznanych mu kosztów. 
**§ 2.** Wniosek taki powinien być zgłoszony w ciągu miesiąca od 
uprawomocnienia się orzeczenia. Jeżeli wniosku nie zgłoszono, sąd po upływie 
tego terminu zarządzi wydanie kaucji powodowi na jego żądanie. 
**§ 3.** Sąd 
zarządzi 
wydanie 
powodowi 
kaucji 
natychmiast 
po 
uprawomocnieniu się orzeczenia, jeżeli pozwanemu kosztów nie przyznano.

***
## Art. 1127. {#kpc-czwarta-druga-art-1127}

Pierwszeństwo zaspokojenia z kaucji złożonej przez powoda 
przysługuje pozwanemu przed wszystkimi innymi wierzycielami powoda.

***
## Art. 1128. {#kpc-czwarta-druga-art-1128}

Przepisy 
tytułu 
niniejszego 
stosuje 
się 
odpowiednio 
w postępowaniu nieprocesowym. 
### TYTUŁ III
Zwolnienie cudzoziemców od kosztów sądowych

***
## Art. 1129. {#kpc-czwarta-druga-art-1129}

Cudzoziemcy, 
zagraniczne 
osoby 
prawne 
i jednostki 
organizacyjne niebędące osobami prawnymi korzystają ze zwolnienia od kosztów 
sądowych na zasadach przewidzianych w przepisach odrębnych. 
### TYTUŁ IV
Pomoc prawna

***
## Art. 1130. {#kpc-czwarta-druga-art-1130}

**§ 1.** W sprawach przeprowadzania dowodów i dokonywania 
innych czynności oraz doręczania pism sądowych sądy porozumiewają się z sądami 
lub innymi organami państw obcych oraz z polskimi przedstawicielstwami dyplo-
matycznymi i urzędami konsularnymi, chyba że przepis szczególny stanowi 
inaczej. 
**§ 2.** Czynności, o których mowa w § 1, może wykonywać referendarz 
sądowy, z wyjątkiem przeprowadzania dowodu.

***
## Art. 1131. {#kpc-czwarta-druga-art-1131}

**§ 1.** Sądy występują o przeprowadzenie dowodów za granicą do 
sądów lub innych organów państw obcych. 

 
 
 
s. 537/580 
 
2025-09-08 
**§ 2.** Wnioski są przesyłane bezpośrednio, jeżeli taki sposób dopuszcza prawo 
państwa wezwanego, lub za pośrednictwem polskiego przedstawicielstwa 
dyplomatycznego lub urzędu konsularnego. Nie wyłącza to innych sposobów 
przesyłania wniosków. 
**§ 3.** Sąd może wnosić o bezpośrednie zawiadomienie go, stron i ich 
przedstawicieli, w tym pełnomocników, o miejscu i czasie przeprowadzenia 
dowodu w celu umożliwienia obecności przy przeprowadzeniu dowodu lub udziału 
w tej czynności. 
**§ 4.** Jeżeli nie sprzeciwia się temu prawo państwa wezwanego, sąd może 
wyznaczyć jednego ze swych członków (sędzia wyznaczony), aby był obecny przy 
przeprowadzaniu za granicą dowodu przez sąd lub inny organ państwa wezwanego, 
jak również, aby brał udział w tej czynności. Sąd może w tym celu wyznaczyć 
również biegłego. 
**§ 5.** Za zgodą państwa wezwanego sąd lub sędzia wyznaczony może 
przeprowadzić dowód bezpośrednio w państwie wezwanym. Przepisów kodeksu 
o środkach przymusu nie stosuje się. 
**§ 6.** W przypadkach 
wskazanych 
w § 1–5 sąd 
może 
postanowić, 
w porozumieniu z sądem lub innym organem państwa wezwanego, że 
przeprowadzenie dowodu, którego charakter się temu nie sprzeciwia, nastąpi przy 
użyciu urządzeń technicznych umożliwiających obecność lub udział w dokonaniu 
tej czynności albo jej dokonanie na odległość.

***
## Art. 11311. {#kpc-czwarta-druga-art-11311}

Przepis art. 1131 stosuje się odpowiednio, jeżeli sądy występują 
do sądów lub innych organów państw obcych o dokonanie innych czynności niż 
przeprowadzenie dowodów.

***
## Art. 1132. {#kpc-czwarta-druga-art-1132}

**§ 1.** Sądy występują o doręczenie pism sądowych osobie mającej 
miejsce zamieszkania lub zwykłego pobytu albo siedzibę za granicą do sądów lub 
innych organów państw obcych. 
**§ 2.** Wnioski są przesyłane bezpośrednio, jeżeli taki sposób dopuszcza prawo 
państwa wezwanego, lub za pośrednictwem polskiego przedstawicielstwa 
dyplomatycznego lub urzędu konsularnego. Nie wyłącza to innych sposobów prze-
syłania wniosków. 

 
 
 
s. 538/580 
 
2025-09-08

***
## Art. 1133. {#kpc-czwarta-druga-art-1133}

**§ 1.** Sąd może doręczyć pisma sądowe osobie przebywającej lub 
mającej siedzibę za granicą pocztą listem poleconym za potwierdzeniem odbioru, 
jeżeli taki sposób dopuszcza prawo państwa, w którym ma nastąpić doręczenie. 
**§ 2.** Jeżeli nie jest możliwe doręczenie z powodu odmowy wykonania 
wniosku przez sąd lub inny organ państwa wezwanego lub długotrwałego 
niewykonywania wniosku, sąd może doręczyć pisma w sposób określony w § 1, 
także wówczas, gdy takiego sposobu nie dopuszcza prawo państwa, w którym ma 
nastąpić doręczenie.

***
## Art. 11331. {#kpc-czwarta-druga-art-11331}

Przepisy art. 1132 i 1133 stosuje się odpowiednio do doręczania 
pism pozasądowych.

***
## Art. 1134. {#kpc-czwarta-druga-art-1134}

Sądy mogą występować do polskiego przedstawicielstwa 
dyplomatycznego lub urzędu konsularnego o przeprowadzenie dowodu lub 
o doręczenie pisma, jeżeli osoba mająca być przesłuchana lub odbiorca pisma jest 
obywatelem polskim przebywającym za granicą.

***
## Art. 11341. {#kpc-czwarta-druga-art-11341}

W razie 
stwierdzenia, 
że 
zachodzą 
podstawy 
określone 
w rozporządzeniu nr 2019/1111 do wystąpienia do sądu lub organu innego państwa 
członkowskiego Unii Europejskiej z wnioskiem o udzielenie pomocy w wykonaniu 
orzeczenia w sprawie dotyczącej odpowiedzialności rodzicielskiej lub kontaktów 
z dzieckiem, 
sąd, 
który 
wykonuje 
orzeczenie, 
wydaje 
postanowienie 
w przedmiocie tego wystąpienia.

***
## Art. 1135. {#kpc-czwarta-druga-art-1135}

**§ 1.** Sądy polskie przeprowadzają dowody i doręczają pisma na 
wniosek sądów i innych organów państw obcych. W przypadkach takich właściwy 
jest sąd rejonowy, w którego okręgu ma być przeprowadzony dowód lub ma 
nastąpić doręczenie pisma. 
**§ 2.** Sąd polski odmawia wykonania czynności wymienionych w § 1, jeżeli: 
- 1) ich wykonanie byłoby sprzeczne z podstawowymi zasadami porządku 
prawnego Rzeczypospolitej Polskiej (klauzula porządku publicznego); 
- 2) ich wykonanie nie należy do zakresu działania sądów polskich; 
- 3) państwo, 
z którego 
pochodzi 
wniosek, 
odmawia 
sądom 
polskim 
wykonywania takich czynności; 
- 4) nie została złożona w terminie zaliczka, o której mowa w art. 11351 § 3. 

 
 
 
s. 539/580 
 
2025-09-08

***
## Art. 11351. {#kpc-czwarta-druga-art-11351}

**§ 1.** Wykonanie wniosku sądu lub innego organu państwa obcego 
o przeprowadzenie dowodu lub doręczenie pism sądowych przez sąd polski 
odbywa się według prawa polskiego. Sąd wezwany może jednak na wniosek sądu 
lub innego organu państwa obcego zastosować przy wykonaniu wniosku inny 
sposób od przewidzianego przez prawo polskie, jeżeli ten sposób wykonania 
wniosku nie jest zakazany przez prawo polskie i nie jest sprzeczny 
z podstawowymi zasadami porządku prawnego Rzeczypospolitej Polskiej 
(klauzula porządku publicznego). 
**§ 2.** Jeżeli sąd lub inny organ państwa obcego zwróci się do sądu o doręczenie 
pisma sądowego osobie przebywającej w Rzeczypospolitej Polskiej, nie dołączając 
tłumaczenia tego pisma na język polski, doręcza się je odbiorcy, o ile zechce je 
przyjąć. Odbiorcę, który odmawia przyjęcia pisma, należy pouczyć o możliwości 
wystąpienia w związku z tym niekorzystnych skutków prawnych za granicą. 
**§ 3.** Jeżeli w wykonaniu wniosku sądu lub innego organu państwa obcego 
mogą powstać koszty związane z udziałem biegłych, tłumaczy, świadków i innych 
osób, sąd wykonuje wniosek dopiero po złożeniu w wyznaczonym terminie 
stosownej zaliczki przez sąd lub inny organ państwa obcego. To samo dotyczy 
kosztów mogących powstać w wyniku zastosowania innego sposobu niż 
przewidziany przez prawo polskie.

***
## Art. 11352. {#kpc-czwarta-druga-art-11352}

**§ 1.** Jeżeli przepis szczególny nie stanowi inaczej, sądy 
zawiadamiają bezpośrednio sąd lub inny organ państwa wzywającego, jak również 
strony 
i ich 
przedstawicieli, 
w tym 
pełnomocników, 
o miejscu 
i czasie 
przeprowadzenia dowodu w celu umożliwienia obecności przy przeprowadzeniu 
dowodu lub udziału w tej czynności tylko na ich wniosek. 
**§ 2.** Jeżeli przepis szczególny nie stanowi inaczej, sędzia lub inna osoba 
wyznaczona przez sąd lub inny organ państwa wzywającego mogą być obecni przy 
przeprowadzaniu dowodu lub brać udział w tej czynności tylko za zgodą sądu. 
**§ 3.** Na wniosek sądu lub innego organu państwa wzywającego sąd może 
wyrazić zgodę na bezpośrednie przeprowadzenie dowodu w Rzeczypospolitej 
Polskiej przez sąd lub inny organ państwa wzywającego lub wyznaczone przez nich 
osoby, jeżeli przeprowadzenie dowodu nie będzie sprzeczne z podstawowymi 
zasadami porządku prawnego Rzeczypospolitej Polskiej (klauzula porządku 
publicznego). W takim przypadku sąd na wniosek sądu lub innego organu państwa 

 
 
 
s. 540/580 
 
2025-09-08 
 
wzywającego stosuje przepisy kodeksu o środkach przymusu. Przeprowadzenie 
dowodu następuje w obecności sądu lub sędziego wyznaczonego. 
**§ 4.** W przypadkach wskazanych w § 1–3 sąd może wyrazić zgodę na 
przeprowadzenie dowodu, którego charakter się temu nie sprzeciwia, przy użyciu 
urządzeń technicznych umożliwiających obecność lub udział w dokonaniu tej 
czynności albo jej dokonanie na odległość.

***
## Art. 11353. {#kpc-czwarta-druga-art-11353}

**§ 1.** Doręczenie pism sądowych osobom przebywającym 
w Rzeczypospolitej Polskiej, którym przysługuje immunitet sądowy lub 
egzekucyjny, 
oraz 
innym 
osobom 
przebywającym 
w budynkach 
lub 
pomieszczeniach korzystających z nietykalności na podstawie ustaw, umów lub 
powszechnie ustalonych zwyczajów międzynarodowych, dokonuje się za 
pośrednictwem Ministerstwa Spraw Zagranicznych. 
**§ 2.** Przepis § 1 stosuje się odpowiednio do doręczania pism sądowych 
obywatelom polskim przebywającym za granicą, którzy korzystają z immunitetu 
dyplomatycznego lub konsularnego.

***
## Art. 11354. {#kpc-czwarta-druga-art-11354}

Przepisy 
art. 1135–11353 stosuje 
się 
odpowiednio 
do 
wykonywania przez sądy polskie innych czynności niż przeprowadzanie dowodu 
oraz do doręczania pism pozasądowych.

***
## Art. 11355. {#kpc-czwarta-druga-art-11355}

**§ 1.** Strona, która nie ma miejsca zamieszkania lub zwykłego 
pobytu albo siedziby w Rzeczypospolitej Polskiej lub w innym państwie 
członkowskim Unii Europejskiej, jeżeli nie ustanowiła pełnomocnika do 
prowadzenia sprawy zamieszkałego w Rzeczypospolitej Polskiej, jest obowiązana 
wskazać pełnomocnika do doręczeń w Rzeczypospolitej Polskiej. 
**§ 2.** W razie niewskazania pełnomocnika do doręczeń, przeznaczone dla tej 
strony pisma sądowe pozostawia się w aktach sprawy ze skutkiem doręczenia. 
Stronę należy o tym pouczyć przy pierwszym doręczeniu. Strona powinna być 
również pouczona o możliwości złożenia odpowiedzi na pismo wszczynające 
postępowanie i wyjaśnień na piśmie oraz o tym, kto może być ustanowiony 
pełnomocnikiem.

***
## Art. 1136. {#kpc-czwarta-druga-art-1136}

(uchylony) 

 
 
 
s. 541/580 
 
2025-09-08 
### TYTUŁ V
Zabezpieczenie dowodów

***
## Art. 1137. {#kpc-czwarta-druga-art-1137}

Sąd może zabezpieczyć dowód znajdujący się w Rzeczypospolitej 
Polskiej, jeżeli jest to potrzebne do dochodzenia roszczenia za granicą. Wniosek 
o zabezpieczenie dowodu składa się w sądzie rejonowym, w którego okręgu dowód 
ma być przeprowadzony. O terminie wyznaczonym do przeprowadzenia dowodu 
zawiadamia się wnioskodawcę, chyba że zachodzi wypadek niecierpiący zwłoki. 
Poza tym stosuje się odpowiednio art. 310 oraz art. 312–314. 
### TYTUŁ VI
Zagraniczne dokumenty urzędowe

***
## Art. 1138. {#kpc-czwarta-druga-art-1138}

Zagraniczne dokumenty urzędowe mają moc dowodową na równi 
z polskimi dokumentami urzędowymi. Dokument dotyczący przeniesienia 
własności nieruchomości położonej w Rzeczypospolitej Polskiej powinien być 
uwierzytelniony przez polskie przedstawicielstwo dyplomatyczne lub urząd 
konsularny. To samo dotyczy dokumentu, którego autentyczności strona 
zaprzeczyła. 
### TYTUŁ VII
Czynności dotyczące spadku po cudzoziemcach

***
## Art. 1139. {#kpc-czwarta-druga-art-1139}

**§ 1.** W sprawach 
spadkowych 
z zakresu 
postępowania 
nieprocesowego, w których sądom polskim nie przysługuje jurysdykcja, dokonują 
one z urzędu zabezpieczenia spadku oraz otwarcia i ogłoszenia testamentu. 
Zawiadamia się o tym właściwego konsula, który może uczestniczyć 
w postępowaniu. 
**§ 2.** Organom państwa, którego obywatelem był spadkodawca, wydaje się na 
żądanie wypis testamentu oraz protokołu otwarcia i ogłoszenia testamentu. 
Oryginał testamentu może być wydany, jeżeli nie przewiduje się dalszych 
czynności urzędowych w Rzeczypospolitej Polskiej.

***
## Art. 1140. {#kpc-czwarta-druga-art-1140}

**§ 1.** Sąd z urzędu postanowi o wezwaniu przez ogłoszenie osób 
roszczących sobie prawa do spadku, spadkobierców i wierzycieli spadkodawcy, 
aby w ciągu trzech miesięcy zgłosili i uprawdopodobnili swoje prawa. 

 
 
 
s. 542/580 
 
2025-09-08 
 
W ogłoszeniu należy wskazać obywatelstwo, miejsce zamieszkania i miejsce 
zwykłego pobytu spadkodawcy. 
**§ 2.** Ogłoszenie doręcza się właściwemu urzędowi skarbowemu i konsulowi.

***
## Art. 1141. {#kpc-czwarta-druga-art-1141}

**§ 1.** Jeżeli nikt nie zgłosił się w powyższym terminie, sąd spadku 
postanowi wydać majątek ruchomy właściwemu konsulowi. 
**§ 2.** W przeciwnym razie wyznacza się rozprawę, na którą wzywa się osoby 
zainteresowane. 
Po 
wysłuchaniu 
stawających 
sąd 
wyda 
postanowienie 
o zabezpieczeniu zgłoszonych i uprawdopodobnionych praw osób zamieszkałych 
w Rzeczypospolitej Polskiej oraz obywateli polskich zamieszkałych za granicą, jak 
również o zabezpieczeniu należnych podatków. Na postanowienie sądu 
przysługuje zażalenie. 
**§ 3.** Niewydany 
majątek 
ruchomy 
będzie 
służył 
na 
zaspokojenie 
zabezpieczonych praw. Resztę majątku ruchomego sąd postanowi wydać 
właściwemu konsulowi. 
**§ 4.** Wydanie może nastąpić tylko pod warunkiem wzajemności.

***
## Art. 1142. {#kpc-czwarta-druga-art-1142}

**§ 1.** Jeżeli cudzoziemiec zmarł w Rzeczypospolitej Polskiej 
w czasie podróży, a nie miał w Rzeczypospolitej Polskiej miejsca zamieszkania lub 
miejsca zwykłego pobytu ani majątku oprócz rzeczy przy nim znalezionych, rzeczy 
te będą zabezpieczone z urzędu przez sąd, który zawiadamia o tym właściwego 
konsula. 
**§ 2.** Część ich sprzedaje się według przepisów o sprzedaży zabezpieczonych 
ruchomości, a z osiągniętej ceny zaspokaja się koszty pobytu w Polsce i pogrzebu 
spadkodawcy. Reszta ceny oraz rzeczy niesprzedanych będzie wydana właściwemu 
konsulowi. 
TYTUŁ VIIA 
Europejskie poświadczenie spadkowe

***
## Art. 11421. {#kpc-czwarta-druga-art-11421}

W zakresie nieuregulowanym w rozporządzeniu Parlamentu 
Europejskiego i Rady (UE) nr 650/2012 z dnia 4 lipca 2012 r. w sprawie 
jurysdykcji, 
prawa 
właściwego, 
uznawania 
i wykonywania 
orzeczeń, 
przyjmowania 
i wykonywania 
dokumentów 
urzędowych 
dotyczących 
dziedziczenia oraz w sprawie ustanowienia europejskiego poświadczenia 
spadkowego (Dz. Urz. UE L 201 z 27.07.2012, str. 107, z późn. zm.) do 

 
 
 
s. 543/580 
 
2025-09-08 
 
postępowań dotyczących europejskiego poświadczenia spadkowego stosuje się 
odpowiednio przepisy o stwierdzeniu nabycia spadku i przedmiotu zapisu 
windykacyjnego, chyba że przepisy niniejszego tytułu stanowią inaczej.

***
## Art. 11422. {#kpc-czwarta-druga-art-11422}

W postępowaniach dotyczących europejskiego poświadczenia 
spadkowego 
sąd 
może 
orzekać 
na 
posiedzeniu 
niejawnym. 
Przepisu 
art. 5091 § 3 nie stosuje się.

***
## Art. 11423. {#kpc-czwarta-druga-art-11423}

**§ 1.** Sąd z urzędu doręcza postanowienie w przedmiocie wydania 
europejskiego poświadczenia spadkowego wraz z pouczeniem o przysługującym 
środku odwoławczym. Uzasadnienie postanowienia sporządza się tylko na żądanie 
uczestnika postępowania zgłoszone w terminie tygodnia od dnia jego doręczenia 
albo gdy uczestnik, który takiego żądania nie zgłosił, wniósł środek odwoławczy 
w ustawowym terminie. 
**§ 2.** Wnioskodawcy doręcza się postanowienie o wydaniu europejskiego 
poświadczenia spadkowego wraz z poświadczonym odpisem tego poświadczenia.

***
## Art. 11424. {#kpc-czwarta-druga-art-11424}

W razie stwierdzenia, że istnieje określona w rozporządzeniu, 
o którym mowa w art. 11421, podstawa do zmiany lub uchylenia europejskiego 
poświadczenia spadkowego, sąd może je zmienić lub uchylić także z urzędu.

***
## Art. 11425. {#kpc-czwarta-druga-art-11425}

Sąd z urzędu doręcza postanowienie o sprostowaniu, zmianie lub 
uchyleniu europejskiego poświadczenia spadkowego albo zawieszeniu jego 
skutków wraz z pouczeniem o przysługującym środku odwoławczym. Przepis 
art. 11423 § 1 zdanie drugie stosuje się odpowiednio. Postanowienia w tym 
przedmiocie sąd doręcza z urzędu także wszystkim osobom, którym wydano 
poświadczone odpisy europejskiego poświadczenia spadkowego.

***
## Art. 11426. {#kpc-czwarta-druga-art-11426}

**§ 1.** Na postanowienie sądu pierwszej instancji w przedmiocie 
wydania, sprostowania, zmiany lub uchylenia albo zawieszenia skutków 
europejskiego poświadczenia spadkowego przysługuje zażalenie. 
**§ 2.** Na postanowienie sądu drugiej instancji wydane w wyniku rozpoznania 
zażalenia skarga kasacyjna nie przysługuje. 
**§ 3.** W postępowaniach 
dotyczących 
europejskiego 
poświadczenia 
spadkowego skarga o stwierdzenie niezgodności z prawem prawomocnego 
orzeczenia nie przysługuje. 

 
 
 
s. 544/580 
 
2025-09-08

***
## Art. 11427. {#kpc-czwarta-druga-art-11427}

Postanowienie o wydaniu, sprostowaniu, zmianie lub uchyleniu 
europejskiego poświadczenia spadkowego albo o zawieszeniu jego skutków oraz 
postanowienie o zmianie albo uchyleniu tych postanowień sąd niezwłocznie 
wpisuje, za pośrednictwem systemu teleinformatycznego, o którym mowa 
w art. 95i § 1 ustawy z dnia 14 lutego 1991 r. – Prawo o notariacie, do Rejestru 
Spadkowego. 
### TYTUŁ VIII
Stwierdzenie obcego prawa i wzajemności

***
## Art. 1143. {#kpc-czwarta-druga-art-1143}

(uchylony) 
### TYTUŁ IX
Uzasadnienie prawomocnych orzeczeń i wydawanie zaświadczeń

***
## Art. 1144. {#kpc-czwarta-druga-art-1144}

Jeżeli do uznania albo wykonania prawomocnego orzeczenia sądu 
polskiego 
za 
granicą 
konieczne 
jest 
przedstawienie 
orzeczenia 
wraz 
z uzasadnieniem, a orzeczenie nie zawiera uzasadnienia, sąd, który wydał 
orzeczenie, sporządzi uzasadnienie na wniosek strony, uczestnika postępowania lub 
osoby ubiegającej się o uznanie lub wykonanie orzeczenia.

***
## Art. 11441. {#kpc-czwarta-druga-art-11441}

Jeżeli 
przepisy 
prawa 
Unii 
Europejskiej 
lub 
wiążącej 
Rzeczpospolitą 
Polską 
umowy 
międzynarodowej 
przewidują 
wydanie 
zaświadczenia lub wyciągu na potrzeby uznania lub stwierdzenia wykonalności 
orzeczenia, ugody lub innego tytułu egzekucyjnego za granicą, zaświadczenie takie 
lub wyciąg taki wystawia, stosując formularz określony w tych przepisach, na 
wniosek zainteresowanego, przewodniczący w sądzie, który wydał orzeczenie albo 
zatwierdził ugodę lub przed którym ugoda została zawarta, a w przypadku innych 
tytułów egzekucyjnych – przewodniczący w sądzie rejonowym, w którego okręgu 
tytuł został sporządzony, chyba że przepis szczególny stanowi inaczej. 
### TYTUŁ X
Wniosek o uchylenie wyroku wydanego w sprawie alimentacyjnej

***
## Art. 11442. {#kpc-czwarta-druga-art-11442}

**§ 1.** W razie stwierdzenia, że istnieje określona w przepisach 
rozporządzenia nr 4/2009 podstawa do uchylenia wyroku wydanego w sprawie 
alimentacyjnej, na wniosek pozwanego sąd, który go wydał, uchyla wyrok. 

 
 
 
s. 545/580 
 
2025-09-08 
**§ 2.** Wniosek powinien czynić zadość warunkom pisma procesowego 
i wskazywać okoliczności uzasadniające uchylenie wyroku. 
**§ 3.** Sąd może rozpoznać wniosek na posiedzeniu niejawnym. Przed 
uchyleniem wyroku sąd wysłucha powoda na posiedzeniu lub zażąda od niego 
oświadczenia na piśmie. 
**§ 4.** Na postanowienie sądu w przedmiocie uchylenia wyroku przysługuje 
zażalenie. 
### TYTUŁ XI
Europejski nakaz zabezpieczenia na rachunku bankowym

***
## Art. 11443. {#kpc-czwarta-druga-art-11443}

**§ 1.** W zakresie nieuregulowanym w rozporządzeniu Parlamentu 
Europejskiego i Rady (UE) nr 655/2014 z dnia 15 maja 2014 r. ustanawiającym 
procedurę europejskiego nakazu zabezpieczenia na rachunku bankowym w celu 
ułatwienia transgranicznego dochodzenia wierzytelności w sprawach cywilnych i 
handlowych (Dz. Urz. UE L 189 z 27.06.2014, str. 59), zwanym dalej 
„rozporządzeniem nr 655/2014”, do postępowań dotyczących europejskiego 
nakazu zabezpieczenia na rachunku bankowym stosuje się odpowiednio przepisy o 
postępowaniu zabezpieczającym, chyba że przepisy niniejszego tytułu stanowią 
inaczej. 
**§ 2.** Ilekroć w przepisach niniejszego tytułu jest mowa o rachunku bankowym 
lub banku, oznacza to rachunek bankowy lub bank w rozumieniu rozporządzenia 
nr 655/2014.

***
## Art. 11444. {#kpc-czwarta-druga-art-11444}

**§ 1.** W postępowaniu o wydanie europejskiego nakazu 
zabezpieczenia na rachunku bankowym właściwy jest sąd, który byłby właściwy 
do rozpoznania sprawy w pierwszej instancji. Jeżeli nie można ustalić takiego sądu, 
właściwy jest sąd, w którego okręgu ma być wykonany europejski nakaz 
zabezpieczenia na rachunku bankowym, a z braku tej podstawy lub w przypadku, 
w którym europejski nakaz zabezpieczenia na rachunku bankowym miałby być 
wykonany w okręgach różnych sądów – sąd rejonowy dla m.st. Warszawy. 
Wniosek o wydanie europejskiego nakazu zabezpieczenia na rachunku bankowym 
zgłoszony w toku postępowania lub po jego zakończeniu rozpoznaje sąd pierwszej 
instancji. 

 
 
 
s. 546/580 
 
2025-09-08 
**§ 2.** W razie zawarcia ugody przed sądem albo zatwierdzenia ugody przez sąd 
właściwy jest sąd, który rozpoznawał sprawę w pierwszej instancji, a jeżeli sprawa 
nie była rozpoznawana przez sąd – sąd, który był właściwy do zatwierdzenia ugody 
w pierwszej instancji. 
**§ 3.** W pozostałych wypadkach właściwy jest sąd rejonowy, w którego okręgu 
tytuł egzekucyjny został sporządzony.

***
## Art. 11445. {#kpc-czwarta-druga-art-11445}

W wypadkach, o których mowa w art. 10 ust. 2 zdanie drugie 
rozporządzenia nr 655/2014, sąd, który wydał europejski nakaz zabezpieczenia na 
rachunku bankowym, z urzędu stwierdza upadek zabezpieczenia.

***
## Art. 11446. {#kpc-czwarta-druga-art-11446}

**§ 1.** Organem do spraw informacji w rozumieniu rozporządzenia 
nr 655/2014 jest Minister Sprawiedliwości. 
**§ 2.** Minister Sprawiedliwości uzyskuje informacje o rachunkach bankowych 
niezbędne do wykonywania zadań organu do spraw informacji z centralnej 
informacji o rachunkach, o której mowa w art. 92bb ustawy z dnia 29 sierpnia 1997 
r. – Prawo bankowe. 
**§ 3.** Za udzielenie informacji Minister Sprawiedliwości pobiera opłatę 
ryczałtową. Minister Sprawiedliwości uzależnia podjęcie czynności w celu 
pozyskania informacji od uprzedniego uiszczenia opłaty. 
**§ 4.** Przepisy § 1–3 stosuje się również w sprawach, w których postępowanie 
o wydanie europejskiego nakazu zabezpieczenia na rachunku bankowym toczy się 
w innym państwie członkowskim Unii Europejskiej. 
**§ 5.** Minister Sprawiedliwości określi, w drodze rozporządzenia, sposób 
uiszczania i wysokość opłaty za udzielenie informacji, o której mowa w § 3, mając 
na względzie potrzebę zapewnienia efektywnego wykonywania wniosków 
o udzielenie informacji, wysokość kosztów związanych z pozyskaniem i 
przekazaniem informacji oraz ryczałtowy charakter opłaty.

***
## Art. 11447. {#kpc-czwarta-druga-art-11447}

Europejski nakaz zabezpieczenia na rachunku bankowym sąd 
doręcza z urzędu wierzycielowi. W razie odmowy wydania europejskiego nakazu 
zabezpieczenia na rachunku bankowym w całości lub części sąd doręcza z urzędu 
wierzycielowi postanowienie w tym przedmiocie.

***
## Art. 11448. {#kpc-czwarta-druga-art-11448}

Środkiem odwoławczym, o którym mowa w art. 21 
rozporządzenia nr 655/2014, jest zażalenie. 

 
 
 
s. 547/580 
 
2025-09-08

***
## Art. 11449. {#kpc-czwarta-druga-art-11449}

Oświadczenie, o którym mowa w art. 25 ust. 1 rozporządzenia nr 
655/2014, sporządza bank i przekazuje je komornikowi, który wystąpił do banku o 
wykonanie europejskiego nakazu zabezpieczenia na rachunku bankowym.

***
## Art. 114410. {#kpc-czwarta-druga-art-114410}

Właściwym organem w rozumieniu art. 4 pkt 14 rozporządzenia 
nr 655/2014, w zakresie czynności, o których mowa w art. 27 ust. 2 tego 
rozporządzenia, jest komornik, który wystąpił do banku o wykonanie europejskiego 
nakazu zabezpieczenia na rachunku bankowym.

***
## Art. 114411. {#kpc-czwarta-druga-art-114411}

**§ 1.** Właściwym sądem, o którym mowa w art. 33, art. 34, art. 35 
ust. 4 i art. 38 ust. 1 lit. b rozporządzenia nr 655/2014, jest sąd, który wydał 
europejski nakaz zabezpieczenia na rachunku bankowym. 
**§ 2.** Sąd orzeka na posiedzeniu niejawnym.

***
## Art. 114412. {#kpc-czwarta-druga-art-114412}

Na postanowienie sądu wydane w wypadkach określonych w art. 
33, art. 34, art. 35 i art. 38 ust. 1 rozporządzenia nr 655/2014 przysługuje zażalenie.

***
## Art. 114413. {#kpc-czwarta-druga-art-114413}

W sprawach, o których mowa w art. 39 ust. 2 rozporządzenia nr 
655/2014, przepisy art. 841 i art. 843 § 1 i 3 stosuje się odpowiednio.

