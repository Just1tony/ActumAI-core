---
id: code.kpc.czesc.druga.ksiega.all
title: "Kodeks postępowania cywilnego — CZĘŚĆ DRUGA — KSIĘGA — (—)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1964 Nr 43 poz. 296"
consolidated_citation: "t.j. Dz.U. 2024 poz. 1568, 1841; Dz.U. 2025 poz. 620, 1172"
status: "obowiązujący"
last_consolidated: "2025-09-08"
aliases: ["KPC — CZĘŚĆ DRUGA — Księga —"]
tags: ["KPC","Kodeks postępowania cywilnego","CZĘŚĆ DRUGA","Księga —","PL"]
source_pdf: "D19640296Lj.pdf"
articles: "Art. 730–757"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpc-druga--art-{n}}"
  separators: "***"
  hierarchy: ["CZĘŚĆ","KSIĘGA","TYTUŁ","DZIAŁ","Rozdział"]
---

# Kodeks postępowania cywilnego — CZĘŚĆ DRUGA — KSIĘGA —: —

# CZĘŚĆ DRUGA 
POSTĘPOWANIE ZABEZPIECZAJĄCE 
(oznaczenie oraz tytuł księgi pierwszej – uchylone) 
### TYTUŁ I
Przepisy ogólne
***
## Art. 730. {#kpc-druga--art-730}

**§ 1.** W każdej sprawie cywilnej podlegającej rozpoznaniu przez sąd 
lub sąd polubowny można żądać udzielenia zabezpieczenia. 
**§ 2.** Sąd może udzielić zabezpieczenia przed wszczęciem postępowania lub 
w jego toku. Po uzyskaniu przez uprawnionego tytułu wykonawczego 
dopuszczalne jest udzielenie zabezpieczenia tylko wtedy, jeżeli ma ono na celu 
zabezpieczenie roszczenia o świadczenie, którego termin spełnienia jeszcze nie 
nastąpił.

***
## Art. 7301. {#kpc-druga--art-7301}

**§ 1.** Udzielenia zabezpieczenia może żądać każda strona lub 
uczestnik postępowania, jeżeli uprawdopodobni roszczenie oraz interes prawny 
w udzieleniu zabezpieczenia. 
**§ 11.** W sprawach wymienionych w art. 47989 sąd w ramach oceny, czy 
uprawdopodobniono roszczenie, bierze pod uwagę prawdopodobieństwo 
unieważnienia prawa wyłącznego w innym toczącym się postępowaniu. 
Okoliczność tę ustala się w oparciu o informacje pochodzące od stron, chyba że jest 
ona znana sądowi z urzędu. 

 
 
 
s. 330/580 
 
2025-09-08 
**§ 2.** Interes prawny w udzieleniu zabezpieczenia istnieje wtedy, gdy brak 
zabezpieczenia uniemożliwi lub poważnie utrudni wykonanie zapadłego w sprawie 
orzeczenia lub w inny sposób uniemożliwi lub poważnie utrudni osiągnięcie celu 
postępowania w sprawie. 
**§ 21.** Interes 
prawny 
w udzieleniu 
zabezpieczenia 
uważa 
się 
za 
uprawdopodobniony, gdy żądającym zabezpieczenia jest powód dochodzący 
należności zapłaty z tytułu transakcji handlowej w rozumieniu ustawy z dnia 
8 marca 2013 r. o przeciwdziałaniu nadmiernym opóźnieniom w transakcjach 
handlowych, 
w przypadku 
gdy 
wartość 
tej 
transakcji 
nie 
przekracza 
siedemdziesięciu pięciu tysięcy złotych, a dochodzona należność nie została 
uregulowana i od dnia upływu terminu jej płatności upłynęły co najmniej trzy 
miesiące. 
**§ 3.** Przy wyborze sposobu zabezpieczenia sąd uwzględni interesy stron lub 
uczestników postępowania w takiej mierze, aby uprawnionemu zapewnić należytą 
ochronę prawną, a obowiązanego nie obciążać ponad potrzebę.

***
## Art. 731. {#kpc-druga--art-731}

Zabezpieczenie nie może zmierzać do zaspokojenia roszczenia, 
chyba że ustawa stanowi inaczej.

***
## Art. 732. {#kpc-druga--art-732}

Zabezpieczenie udzielane jest na wniosek, a w wypadkach, 
w których postępowanie może być wszczęte z urzędu – także z urzędu.

***
## Art. 733. {#kpc-druga--art-733}

**§ 1.** Udzielając zabezpieczenia przed wszczęciem postępowania 
w sprawie, sąd wyznacza termin, w którym pismo wszczynające postępowanie 
powinno być wniesione pod rygorem upadku zabezpieczenia. Termin ten nie może 
przekraczać dwóch tygodni. 
**§ 2.** W przypadku zabezpieczenia w formie miesięcznego świadczenia na 
zapewnienie środków utrzymania, o którym mowa w art. 7533 § 1, termin upadku 
zabezpieczenia wyznaczany przez sąd, o którym mowa w § 1, wynosi sześć 
miesięcy. Sąd na uzasadniony wniosek pełnomocnika może wskazać dłuższy 
termin, wynoszący nie więcej jednak niż rok.

***
## Art. 734. {#kpc-druga--art-734}

Do udzielenia zabezpieczenia właściwy jest sąd, do którego 
właściwości należy rozpoznanie sprawy w pierwszej instancji. Jeżeli nie można 
ustalić takiego sądu, właściwy jest sąd, w którego okręgu ma być wykonane 
postanowienie o udzieleniu 
zabezpieczenia, 
a z braku tej 
podstawy lub 

 
 
 
s. 331/580 
 
2025-09-08 
 
w przypadku, w którym postanowienie o udzieleniu zabezpieczenia miałoby być 
wykonane w okręgach różnych sądów – sąd rejonowy dla m.st. Warszawy. 
Wniosek o udzielenie zabezpieczenia zgłoszony w toku postępowania rozpoznaje 
sąd tej instancji, w której toczy się postępowanie, z wyjątkiem przypadku, gdy 
sądem tym jest Sąd Najwyższy. Wtedy o zabezpieczeniu orzeka sąd pierwszej 
instancji.

***
## Art. 735. {#kpc-druga--art-735}

**§ 1.** (uchylony) 
**§ 2.** W sprawie, którą rozpoznaje sąd w składzie trzech sędziów, w przypadku 
niecierpiącym zwłoki postanowienie w przedmiocie udzielenia zabezpieczenia 
może być wydane przez sąd w składzie jednego sędziego.

***
## Art. 7351. {#kpc-druga--art-7351}

**§ 1.** W sprawach 
o udzielenie 
zabezpieczenia 
roszczeń 
pieniężnych, w których żądającym zabezpieczenia jest powód dochodzący 
należności zapłaty z tytułu transakcji handlowej w rozumieniu ustawy z dnia 
8 marca 2013 r. o przeciwdziałaniu nadmiernym opóźnieniom w transakcjach 
handlowych, o których mowa w art. 7301 § 21, postanowienie w przedmiocie 
udzielenia zabezpieczenia może wydać także referendarz sądowy. Referendarz 
sądowy nie może podejmować czynności zastrzeżonych dla sądu, o których mowa 
w art. 751. 
**§ 2.** Przepisu § 1 zdanie pierwsze nie stosuje się do zabezpieczenia, o którym 
mowa w art. 747 pkt 6. 
**§ 3.** Do skargi na postanowienie referendarza sądowego stosuje się 
odpowiednio przepis art. 7673a. Skarga podlega rozpoznaniu w terminie tygodnia 
od dnia jej wpływu do sądu.

***
## Art. 736. {#kpc-druga--art-736}

**§ 1.** Wniosek o udzielenie zabezpieczenia powinien odpowiadać 
wymaganiom przepisanym dla pisma procesowego, a nadto zawierać: 
- 1) wskazanie sposobu zabezpieczenia, a w sprawach o roszczenie pieniężne 
także wskazanie sumy zabezpieczenia; 
- 2) uprawdopodobnienie okoliczności uzasadniających wniosek. 
**§ 2.** Jeżeli wniosek o udzielenie zabezpieczenia złożono przed wszczęciem 
postępowania, należy nadto zwięźle przedstawić przedmiot sprawy. 
**§ 3.** Wskazana w § 1 suma zabezpieczenia nie może być wyższa od 
dochodzonego roszczenia liczonego wraz z odsetkami do dnia wydania 

 
 
 
s. 332/580 
 
2025-09-08 
 
postanowienia 
o udzieleniu 
zabezpieczenia 
oraz 
z kosztami 
wykonania 
zabezpieczenia. Suma ta może obejmować także przewidywane koszty 
postępowania. 
**§ 4.** Jeżeli w ramach zabezpieczenia obowiązany składa sumę zabezpieczenia, 
sumę tę umieszcza na rachunku depozytowym Ministra Finansów, chyba że przepis 
szczególny stanowi inaczej. 
**§ 5.** W sprawach wymienionych w art. 47989 wniosek powinien zawierać 
ponadto informację, czy toczy lub toczyło się postępowanie w przedmiocie 
unieważnienia prawa wyłącznego albo oświadczenie strony lub uczestnika 
postępowania o braku wiedzy o takim postępowaniu.

***
## Art. 737. {#kpc-druga--art-737}

Wniosek 
o udzielenie 
zabezpieczenia 
podlega 
rozpoznaniu 
bezzwłocznie, nie później jednak niż w terminie tygodnia od dnia jego wpływu do 
sądu, chyba że przepis szczególny stanowi inaczej. Jeżeli ustawa przewiduje roz-
poznanie wniosku na rozprawie, należy ją wyznaczyć tak, aby rozprawa mogła 
odbyć się w terminie miesięcznym od dnia wpływu wniosku.

***
## Art. 738. {#kpc-druga--art-738}

Sąd rozpoznaje wniosek o udzielenie zabezpieczenia w jego 
granicach, biorąc za podstawę orzeczenia materiał zebrany w sprawie.

***
## Art. 739. {#kpc-druga--art-739}

**§ 1.** Wykonanie postanowienia o udzieleniu zabezpieczenia sąd 
może uzależnić od złożenia przez uprawnionego kaucji na zabezpieczenie roszczeń 
obowiązanego lub, stosownie do okoliczności, innych osób, powstałych w wyniku 
wykonania postanowienia o zabezpieczeniu. Z kaucji tej będzie przysługiwało 
obowiązanemu lub, stosownie do okoliczności, innym osobom dotkniętym 
wykonaniem postanowienia o zabezpieczeniu pierwszeństwo zaspokojenia przed 
innymi należnościami zaraz po kosztach egzekucyjnych. 
**§ 2.** Przepisu § 1 nie stosuje się, gdy uprawnionym jest Skarb Państwa oraz 
w wypadku zabezpieczenia roszczeń alimentacyjnych, o rentę, a także należności 
pracownika w sprawach z zakresu prawa pracy, w części nieprzekraczającej 
pełnego jednomiesięcznego wynagrodzenia pracownika.

***
## Art. 740. {#kpc-druga--art-740}

**§ 1.** Wydane na posiedzeniu niejawnym postanowienie o odmowie 
udzielenia zabezpieczenia, jak również postanowienie o udzieleniu zabezpieczenia, 
które podlega wykonaniu przez organ egzekucyjny, oraz dalsze postanowienia 
dotyczące tego zabezpieczenia sąd doręcza tylko uprawnionemu, chyba że przepis 

 
 
 
s. 333/580 
 
2025-09-08 
 
szczególny stanowi inaczej. Doręczenia obowiązanemu postanowienia o udzieleniu 
zabezpieczenia, które podlega wykonaniu przez organ egzekucyjny dokonuje ten 
organ równocześnie z przystąpieniem do wykonania tego postanowienia. 
**§ 2.** W wypadkach objętych § 1 obowiązanemu nie doręcza się również 
zażalenia uprawnionego ani postanowienia sądu drugiej instancji rozstrzygającego 
o tym zażaleniu. 
**§ 3.** Jeżeli ustanowiono jako zabezpieczenie zarząd nad przedsiębiorstwem 
lub gospodarstwem rolnym obowiązanego albo zakładem wchodzącym w skład 
przedsiębiorstwa lub jego częścią albo częścią gospodarstwa rolnego 
obowiązanego, 
doręczenia 
obowiązanemu 
postanowienia 
o udzieleniu 
zabezpieczenia dokonuje zarządca ustanowiony przez sąd. Jeżeli obowiązany 
odmawia przyjęcia postanowienia albo gdy zarządca jest wprowadzony w zarząd 
przez komornika, doręczenia postanowienia o zabezpieczeniu dokonuje komornik. 
**§ 4.** Przepisy § 1 i 2 stosuje się także do postanowień w przedmiocie 
zabezpieczenia przez obciążenie nieruchomości hipoteką przymusową. Doręczenia 
obowiązanemu postanowienia o udzieleniu zabezpieczenia dokonuje sąd 
prowadzący 
księgę 
wieczystą 
równocześnie 
z doręczeniem 
orzeczenia 
w przedmiocie wniosku o wpis hipoteki.

***
## Art. 741. {#kpc-druga--art-741}

**§ 1.** Na postanowienie sądu pierwszej instancji w przedmiocie 
zabezpieczenia 
przysługuje 
zażalenie. 
Zażalenie 
przysługuje 
także 
na 
postanowienie sądu drugiej instancji o udzieleniu zabezpieczenia, z wyjątkiem 
postanowienia wydanego w wyniku rozpoznania zażalenia na postanowienie sądu 
pierwszej instancji. 
**§ 2.** Zażalenie na postanowienie sądu pierwszej instancji rozpoznaje sąd 
drugiej instancji. Na postanowienie sądu drugiej instancji przysługuje zażalenie do 
innego składu tego sądu. 
**§ 3.** Sąd może uchylić zaskarżone postanowienie tylko gdy zachodzi 
nieważność postępowania.

***
## Art. 742. {#kpc-druga--art-742}

**§ 1.** Obowiązany może w każdym czasie żądać uchylenia lub 
zmiany prawomocnego postanowienia, którym udzielono zabezpieczenia, gdy 
odpadnie lub zmieni się przyczyna zabezpieczenia. Jeżeli obowiązany złoży na 
rachunek depozytowy Ministra Finansów sumę zabezpieczenia żądaną przez 

 
 
 
s. 334/580 
 
2025-09-08 
 
uprawnionego we wniosku o udzielenie zabezpieczenia, zabezpieczenie upada. 
Przepis art. 7541 § 3 stosuje się odpowiednio. 
**§ 2.** Przed 
wydaniem 
postanowienia 
w przedmiocie 
uchylenia 
lub 
ograniczenia zabezpieczenia sąd wysłucha uprawnionego. 
**§ 3.** Wniesienie zażalenia na postanowienie uchylające lub zmieniające 
postanowienie o udzieleniu zabezpieczenia wstrzymuje wykonanie postanowienia. 
**§ 4.** Przepisów § 2 i § 3 nie stosuje się, gdy uchylenie postanowienia 
o udzieleniu zabezpieczenia nastąpiło na skutek złożenia przez obowiązanego na 
rachunek depozytowy Ministra Finansów sumy wystarczającej do zabezpieczenia. 
**§ 5.** (uchylony)

***
## Art. 743. {#kpc-druga--art-743}

**§ 1.** Jeżeli postanowienie o udzieleniu zabezpieczenia podlega 
wykonaniu w drodze egzekucji, do wykonania tego postanowienia stosuje się 
odpowiednio przepisy o postępowaniu egzekucyjnym, z tym jednak, że sąd nadaje 
postanowieniu o udzieleniu zabezpieczenia klauzulę wykonalności z urzędu. 
W razie zbiegu zabezpieczenia udzielonego przez sąd i organ administracyjny 
przepisy art. 773 i art. 774 nie mają zastosowania, z wyjątkiem wypadków 
przewidzianych w art. 751. 
**§ 2.** Jeżeli z uwagi na swą treść postanowienie podlega wykonaniu w inny 
sposób, stosuje się odpowiednio przepisy dotyczące tego sposobu. Podstawą 
przeprowadzenia postępowania jest wtedy postanowienie zaopatrzone z urzędu 
przez przewodniczącego we wzmiankę o wykonalności. 
**§ 3.** Jeżeli wykonanie postanowienia o zabezpieczeniu zostało uzależnione od 
złożenia przez uprawnionego kaucji na zabezpieczenie roszczeń obowiązanego, 
powstałych w wyniku wykonania postanowienia o zabezpieczeniu, sąd nadaje mu 
klauzulę wykonalności albo przewodniczący zaopatruje je we wzmiankę 
o wykonalności, po złożeniu kaucji.

***
## Art. 7431. {#kpc-druga--art-7431}

**§ 1.** Postanowienie o udzieleniu zabezpieczenia wydane przeciwko 
osobie pozostającej w związku małżeńskim stanowi podstawę do podjęcia 
czynności związanych z wykonaniem zabezpieczenia na mieniu wchodzącym 
w skład majątku wspólnego. 
**§ 2.** W terminie tygodnia od dnia dokonania pierwszej czynności związanej 
z wykonaniem zabezpieczenia małżonek obowiązanego może sprzeciwić się 

 
 
 
s. 335/580 
 
2025-09-08 
 
wykonaniu postanowienia o udzieleniu zabezpieczenia, o czym organ wykonujący 
zabezpieczenie niezwłocznie zawiadamia uprawnionego. 
**§ 3.** Sprzeciw małżonka obowiązanego, o którym mowa w § 2, nie 
wstrzymuje wykonania zabezpieczenia. Jeżeli jednak zabezpieczenie prowadzi do 
zaspokojenia uprawnionego, wstrzymuje się wypłatę pieniędzy uzyskanych w 
postępowaniu zabezpieczającym. 
**§ 4.** W razie sprzeciwu, o którym mowa w § 2, uprawniony może w terminie 
dwóch tygodni od dnia zawiadomienia, pod rygorem upadku zabezpieczenia 
w zakresie wykonania na mieniu wchodzącym w skład majątku wspólnego, 
wystąpić do sądu o nadanie temu postanowieniu klauzuli wykonalności przeciwko 
małżonkowi obowiązanego. Przepisy art. 787 stosuje się odpowiednio. Upadek, 
o którym mowa w zdaniu pierwszym, następuje również w razie oddalenia wniosku 
o nadanie klauzuli wykonalności. Przepis art. 7541 § 3 stosuje się odpowiednio.

***
## Art. 744. {#kpc-druga--art-744}

**§ 1.** W razie prawomocnego zwrotu albo odrzucenia pozwu lub 
wniosku, oddalenia powództwa lub wniosku albo umorzenia postępowania, 
zabezpieczenie upada. 
**§ 2.** Zabezpieczenie upada również, gdy zostało udzielone przed wszczęciem 
postępowania, jeżeli uprawniony nie wystąpił we wszczętym postępowaniu 
w sprawie o całość roszczenia lub też wystąpił o roszczenia inne niż to, które 
zostało zabezpieczone. 
**§ 3.** W sprawach wymienionych w § 1 i § 2 przepis art. 7541 § 3 stosuje się 
odpowiednio.

***
## Art. 745. {#kpc-druga--art-745}

**§ 1.** O kosztach postępowania zabezpieczającego sąd rozstrzyga 
w orzeczeniu kończącym postępowanie w sprawie, a o kosztach postępowania 
zabezpieczającego później powstałych rozstrzyga na wniosek strony sąd, który 
udzielił zabezpieczenia. 
**§ 2.** Jeżeli postanowienie, w którym udzielono zabezpieczenia, zostało 
wydane przed wszczęciem postępowania w sprawie, a uprawniony nie zachował 
wyznaczonego mu terminu do jej wszczęcia, obowiązany może w terminie dwóch 
tygodni od upływu tego terminu złożyć wniosek o przyznanie mu kosztów. W tym 
terminie wniosek taki może zgłosić uprawniony, jeżeli nie wytoczył sprawy 
dlatego, że obowiązany zaspokoił jego roszczenie. 

 
 
 
s. 336/580 
 
2025-09-08

***
## Art. 746. {#kpc-druga--art-746}

**§ 1.** Jeżeli uprawniony nie wniósł pisma wszczynającego 
postępowanie w wyznaczonym terminie albo cofnął pozew lub wniosek, jak 
również gdy pozew lub wniosek zwrócono albo odrzucono albo powództwo bądź 
wniosek oddalono lub postępowanie umorzono, a także w przypadkach 
wskazanych w art. 744 § 2, obowiązanemu przysługuje przeciwko uprawnionemu 
roszczenie o naprawienie szkody wyrządzonej wykonaniem zabezpieczenia. 
Roszczenie wygasa, jeżeli nie będzie dochodzone w ciągu roku od dnia jego 
powstania. 
**§ 11.** W przypadku wniesienia skargi kasacyjnej termin, o którym mowa 
w § 1, rozpoczyna bieg w dniu prawomocnego zakończenia postępowania 
wywołanego jej wniesieniem. 
**§ 2.** Uprawnieni, którzy łącznie uzyskali zabezpieczenie, ponoszą solidarną 
odpowiedzialność za wyrządzoną szkodę. 
**§ 3.** Jeżeli w terminie miesiąca od rozpoczęcia biegu terminu, o którym mowa 
w § 1 lub 11, obowiązany nie wytoczył powództwa, sąd zwraca uprawnionemu, na 
jego wniosek, kaucję złożoną na zabezpieczenie roszczenia. 
### TYTUŁ II
Zabezpieczenie roszczeń pieniężnych

***
## Art. 747. {#kpc-druga--art-747}

Zabezpieczenie roszczeń pieniężnych następuje przez: 
- 1) zajęcie ruchomości, wynagrodzenia za pracę, wierzytelności z rachunku 
bankowego albo innej wierzytelności lub innego prawa majątkowego; 
- 2) obciążenie nieruchomości obowiązanego hipoteką przymusową; 
- 3) ustanowienie zakazu zbywania lub obciążania nieruchomości, która nie ma 
urządzonej księgi wieczystej lub której księga wieczysta zaginęła lub uległa 
zniszczeniu; 
- 4) obciążenie statku albo statku w budowie hipoteką morską; 
- 5) ustanowienie zakazu zbywania spółdzielczego własnościowego prawa do 
lokalu; 
- 6) ustanowienie 
zarządu 
przymusowego 
nad 
przedsiębiorstwem 
lub 
gospodarstwem rolnym obowiązanego albo zakładem wchodzącym w skład 
przedsiębiorstwa lub jego częścią albo częścią gospodarstwa rolnego 
obowiązanego. 

 
 
 
s. 337/580 
 
2025-09-08

***
## Art. 748. {#kpc-druga--art-748}

(uchylony)

***
## Art. 749. {#kpc-druga--art-749}

Zabezpieczenie roszczeń pieniężnych przeciwko Skarbowi Państwa 
jest niedopuszczalne.

***
## Art. 750. {#kpc-druga--art-750}

Zabezpieczenie nie może obejmować rzeczy, wierzytelności i praw, 
z których egzekucja jest wyłączona.

***
## Art. 751. {#kpc-druga--art-751}

**§ 1.** Rzeczy ulegające szybkiemu zepsuciu mogą stanowić 
przedmiot zabezpieczenia, gdy obowiązany nie ma innego mienia, które mogłoby 
zabezpieczyć roszczenia uprawnionego, istnieje zaś możliwość sprzedaży tych 
rzeczy niezwłocznie. 
**§ 2.** Sprzedaż rzeczy wymienionych w § 1 powinna nastąpić niezwłocznie, 
według przepisów o sprzedaży w trybie egzekucji z ruchomości. 
**§ 3.** Na wniosek obowiązanego sąd rejonowy może po wysłuchaniu 
uprawnionego polecić komornikowi sprzedaż każdej zajętej ruchomości, 
wierzytelności lub prawa. 
**§ 4.** Cenę uzyskaną ze sprzedaży składa się na rachunek depozytowy Ministra 
Finansów na zabezpieczenie roszczeń uprawnionego.

***
## Art. 752. {#kpc-druga--art-752}

**§ 1.** Zajęte ruchomości nie mogą być oddane pod dozór 
uprawnionemu. Zajęte pieniądze składa się na rachunek depozytowy Ministra 
Finansów, a zajęte papiery wartościowe sąd składa w banku. 
**§ 2.** (uchylony) 
**§ 3.** (uchylony)

***
## Art. 7521. {#kpc-druga--art-7521}

**§ 1.** W razie udzielenia zabezpieczenia przez zajęcie praw 
z instrumentów finansowych zapisanych na rachunku papierów wartościowych lub 
innym rachunku w rozumieniu przepisów o obrocie instrumentami finansowymi 
obowiązany w terminie trzech miesięcy od dnia zajęcia może zlecić ich sprzedaż. 
Sumę uzyskaną ze sprzedaży umieszcza się na rachunku depozytowym Ministra 
Finansów. Obowiązany może także zlecić, by znajdujące się na rachunku sumy 
pieniężne zostały wpłacone na rachunek depozytowy Ministra Finansów. 
**§ 2.** Przepisu § 1 nie stosuje się do rachunku zbiorczego w rozumieniu 
przepisów ustawy z dnia 29 lipca 2005 r. o obrocie instrumentami finansowymi 
(Dz. U. z 2024 r. poz. 722). 

 
 
 
s. 338/580 
 
2025-09-08

***
## Art. 7522. {#kpc-druga--art-7522}

**§ 1.** W razie zajęcia na zabezpieczenie rachunku bankowego 
przedsiębiorcy lub właściciela gospodarstwa rolnego sąd na wniosek obowiązanego 
złożony w terminie tygodniowym od dnia doręczenia mu postanowienia o 
zabezpieczeniu określa, jakie kwoty można pobierać na bieżące wypłaty 
wynagrodzeń za pracę wraz z podatkiem od wynagrodzenia i innymi ustawowymi 
ciężarami, a także na bieżące koszty prowadzonej działalności gospodarczej. 
**§ 2.** Udzielając zabezpieczenia, sąd może określić korzystanie z zajętego 
rachunku bankowego w inny sposób. 
**§ 3.** Sumę uzyskaną z zajętego rachunku bankowego umieszcza się na 
rachunku depozytowym Ministra Finansów, chyba że zabezpieczenie polega na 
zobowiązaniu obowiązanego do zapłaty uprawnionemu określonej sumy 
pieniężnej. 
**§ 4.** Przepis § 3 stosuje się odpowiednio, gdy w ramach zabezpieczenia zajęto 
inne wierzytelności i prawa majątkowe.

***
## Art. 7523. {#kpc-druga--art-7523}

**§ 1.** Postanowienie o udzieleniu zabezpieczenia ustanawiające 
zakaz zbywania spółdzielczego własnościowego prawa do lokalu stanowi podstawę 
wpisu w księdze wieczystej ostrzeżenia o zakazie zbywania tego prawa. 
**§ 2.** Sąd, który wydał postanowienie, o którym mowa w § 1, przekazuje to 
postanowienie sądowi dokonującemu wpisu ostrzeżenia w księdze wieczystej. 
Wpisu dokonuje się z urzędu. 
**§ 3.** Sąd, który dokonał wpisu ostrzeżenia w księdze wieczystej, doręcza 
postanowienie, o którym mowa w § 1, obowiązanemu i spółdzielni mieszkaniowej. 
**§ 4.** Spółdzielnia mieszkaniowa ponosi odpowiedzialność za szkodę 
spowodowaną 
czynnościami 
zmierzającymi 
do 
zbycia 
spółdzielczego 
własnościowego prawa do lokalu mimo ustanowionego zakazu.

***
## Art. 7523a. {#kpc-druga--art-7523a}

**§ 1.** Czynność prawna obowiązanego dokonana wbrew zakazowi 
zbywania lub obciążania nieruchomości, która nie ma urządzonej księgi wieczystej 
lub której księga wieczysta zaginęła lub uległa zniszczeniu, jest nieważna. 
**§ 2.** Czynność prawna dokonana wbrew zakazowi zbywania spółdzielczego 
własnościowego prawa do lokalu jest nieważna, jeżeli dokonano wpisu w księdze 
wieczystej ostrzeżenia o zakazie zbywania tego prawa. 

 
 
 
s. 339/580 
 
2025-09-08

***
## Art. 7524. {#kpc-druga--art-7524}

**§ 1.** Zarząd przymusowy ustanowiony nad przedsiębiorstwem lub 
gospodarstwem rolnym obowiązanego lub nad zakładem wchodzącym w skład 
przedsiębiorstwa lub jego częścią albo nad częścią gospodarstwa rolnego wykonuje 
się według przepisów o zarządzie w toku egzekucji z nieruchomości. 
**§ 11.** Zarządcę 
ustanawia 
sąd 
wydający 
postanowienie 
o udzieleniu 
zabezpieczenia. Postanowienie o ustanowieniu zarządcy jest jednocześnie 
podstawą do wprowadzenia go w zarząd bez potrzeby nadania mu klauzuli 
wykonalności. Zarządcą nie może być obowiązany. 
**§ 2.** W toku sprawowania zarządu sąd może, za zgodą uprawnionego 
i obowiązanego, zezwolić na wykonywanie zarządu w inny sposób. 
**§ 3.** Za zgodą obowiązanego sąd postanowi, że dochód uzyskiwany z zarządu 
przeznaczony będzie na zaspokojenie uprawnionego. Zgoda taka nie jest potrzebna 
w sprawach wymienionych w art. 753, art. 7531 i art. 754. Wydając postanowienie 
o przekazywaniu dochodu na zaspokojenie uprawnionego, sąd określi wysokość 
kwoty, do której wierzyciel winien być zaspokojony, jeżeli kwota ta nie została 
określona w postanowieniu o zabezpieczeniu. 
**§ 4.** W razie wyrażenia zgody na zaspokojenie uprawnionego z dochodu 
uzyskanego przez zarząd, przepisy art. 7532 stosuje się odpowiednio. 
**§ 5.** W sprawach, 
o których 
mowa 
w § 2–4, 
orzeka 
sąd 
wydający 
postanowienie o zabezpieczeniu.

***
## Art. 7525. {#kpc-druga--art-7525}

Czynności prawne obowiązanego dotyczące majątku objętego 
zarządem przymusowym podjęte po ustanowieniu zarządu są nieważne. Dla 
określenia czasu powstania skutków ustanowienia zarządu przepisy art. 910 stosuje 
się odpowiednio.

***
## Art. 7526. {#kpc-druga--art-7526}

**§ 1.** W razie skierowania egzekucji do składników mienia objętego 
zarządem przymusowym dalsze postępowanie prowadzone będzie według 
przepisów o egzekucji przez zarząd przymusowy. Przepisy art. 10644 i art. 106410 
stosuje się odpowiednio. 
**§ 2.** Jeżeli do przedsiębiorstwa lub gospodarstwa rolnego objętego zarządem 
ustanowionym w postępowaniu zabezpieczającym skierowano egzekucję przez 
sprzedaż przedsiębiorstwa lub gospodarstwa rolnego, przepis art. 106414 stosuje się 
odpowiednio. 

 
 
 
s. 340/580 
 
2025-09-08

***
## Art. 753. {#kpc-druga--art-753}

**§ 1.** W sprawach o alimenty zabezpieczenie może polegać na 
zobowiązaniu obowiązanego do zapłaty uprawnionemu jednorazowo albo 
okresowo określonej sumy pieniężnej. W sprawach tych podstawą zabezpieczenia 
jest jedynie uprawdopodobnienie istnienia roszczenia. 
**§ 2.** W wypadkach wymienionych w § 1 sąd z urzędu doręcza stronom odpis 
postanowienia o zabezpieczeniu.

***
## Art. 7531. {#kpc-druga--art-7531}

**§ 1.** Przepis art. 753 stosuje się odpowiednio do zabezpieczenia 
roszczeń o: 
- 1) rentę, sumę potrzebną na koszty leczenia, z tytułu odpowiedzialności za 
uszkodzenie ciała lub utratę życia żywiciela albo rozstrój zdrowia oraz 
o zmianę uprawnień objętych treścią dożywocia na dożywotnią rentę; 
- 2) wynagrodzenie za pracę; 
- 3) należności z tytułu rękojmi lub gwarancji jakości albo kary umownej, jak 
również należności z tytułu niezgodności towaru konsumpcyjnego z umową 
sprzedaży 
konsumenckiej, 
przeciwko 
przedsiębiorcy 
do 
wysokości 
dwudziestu tysięcy złotych; 
- 4) należności z tytułu najmu lub dzierżawy, a także należności z tytułu opłat 
obciążających najemcę lub dzierżawcę oraz opłat z tytułu korzystania z lokalu 
mieszkalnego lub użytkowego – do wysokości, o której mowa w pkt 3; 
- 5) naprawienie szkody wynikającej z naruszenia przepisów o ochronie 
środowiska; 
- 6) (uchylony) 
- 7) (uchylony) 
- 8) wynagrodzenie przysługujące twórcy projektu wynalazczego; 
- 9) przyznanie państwowej kompensaty przysługującej ofiarom niektórych 
czynów zabronionych, w części na pokrycie niezbędnych kosztów leczenia, 
rehabilitacji lub pogrzebu. 
**§ 2.** W sprawach wymienionych w § 1, z wyjątkiem spraw, o których mowa 
w pkt 9, sąd udziela zabezpieczenia po przeprowadzeniu rozprawy. Oddalenie 
wniosku o udzielenie zabezpieczenia może nastąpić na posiedzeniu niejawnym. 
Przepisu art. 749 nie stosuje się. 
**§ 3.** W sprawach wymienionych w § 1 w pkt 1, 2 i 9 do udzielenia 
zabezpieczenia nie jest wymagane uprawdopodobnienie interesu prawnego. 

 
 
 
s. 341/580 
 
2025-09-08

***
## Art. 7532. {#kpc-druga--art-7532}

W sprawach, o których mowa w art. 753 i art. 7531, jeżeli osoba 
obowiązana do świadczeń uzna roszczenie, wyrok zasądzający świadczenie 
w zakresie niezaspokojonym może być wydany na posiedzeniu niejawnym.

***
## Art. 7533. {#kpc-druga--art-7533}

**§ 1.** W przypadku żądania zabezpieczenia roszczeń opartych na 
podstawie art. 444 § 2 lub art. 446 § 2 Kodeksu cywilnego, w formie miesięcznego 
świadczenia na zapewnienie środków utrzymania, w związku ze szkodą poniesioną 
wskutek czynu niedozwolonego wyczerpującego znamiona: 
- 1) jednego z przestępstw przeciwko bezpieczeństwu w komunikacji w ruchu 
lądowym, o których mowa w rozdziale XXI Kodeksu karnego, lub 
- 2) zabójstwa z użyciem pojazdu mechanicznego w ruchu lądowym, lub 
- 3) umyślnego spowodowania ciężkiego uszczerbku na zdrowiu z użyciem 
pojazdu mechanicznego w ruchu lądowym 
– sąd udziela tego zabezpieczenia na rzecz każdego uprawnionego w wysokości nie 
niższej niż kwota najniższej emerytury określonej w art. 85 ust. 2 ustawy z dnia 
17 grudnia 1998 r. o emeryturach i rentach z Funduszu Ubezpieczeń Społecznych 
(Dz. U. z 2023 r. poz. 1251, 1429 i 1672 oraz z 2024 r. poz. 834, 858 i 1243), chyba 
że uzyskanie świadczeń rentowych z innych źródeł przemawia za udzieleniem 
zabezpieczenia w wysokości kwoty niższej. 
**§ 2.** Łączna kwota zabezpieczenia na rzecz wszystkich uprawnionych 
w formie miesięcznego świadczenia na zapewnienie środków utrzymania na 
podstawie art. 444 § 2 oraz art. 446 § 2 Kodeksu cywilnego nie może przekraczać 
wysokości uzyskiwanego przez poszkodowanego miesięcznego wynagrodzenia 
netto lub dochodu w okresie poprzedzającym zdarzenie i pięciokrotnej wysokości 
kwoty najniższej emerytury określonej w art. 85 ust. 2 ustawy z dnia 17 grudnia 
1998 r. o emeryturach i rentach z Funduszu Ubezpieczeń Społecznych.

***
## Art. 754. {#kpc-druga--art-754}

Sąd może jeszcze przed urodzeniem się dziecka zabezpieczyć 
przyszłe roszczenia alimentacyjne związane z ustaleniem ojcostwa, o których 
mowa 
w art. 141 
i art. 142 Kodeksu 
rodzinnego 
i opiekuńczego, 
przez 
zobowiązanie obowiązanego do wyłożenia odpowiedniej sumy na koszty 
utrzymania matki przez trzy miesiące w okresie porodu oraz na utrzymanie dziecka 
przez pierwsze trzy miesiące po urodzeniu. W sprawach tych termin do wytoczenia 
powództwa wynosi trzy miesiące od dnia urodzenia się dziecka. Postanowienie sąd 

 
 
 
s. 342/580 
 
2025-09-08 
 
wydaje po przeprowadzeniu rozprawy. Przepisy art. 733 § 1 i art. 7532 stosuje się 
odpowiednio.

***
## Art. 7541. {#kpc-druga--art-7541}

**§ 1.** Jeżeli przepis szczególny nie stanowi inaczej albo jeżeli sąd 
inaczej nie postanowi, zabezpieczenie udzielone według przepisów niniejszego 
tytułu upada po upływie dwóch miesięcy od uprawomocnienia się orzeczenia 
uwzględniającego roszczenie, które podlegało 
zabezpieczeniu, 
albo od 
uprawomocnienia się postanowienia o odrzuceniu apelacji lub innego środka 
zaskarżenia wniesionego przez obowiązanego od orzeczenia uwzględniającego 
roszczenie, które podlegało zabezpieczeniu, chyba że uprawniony wniósł 
o dokonanie czynności egzekucyjnych. 
**§ 2.** W sprawach, w których udzielono zabezpieczenia przy zastosowaniu art. 
747 pkt 1 lub 6, zabezpieczenie upada, jeżeli uprawniony w terminie miesiąca od 
uprawomocnienia się orzeczenia uwzględniającego roszczenie albo od uprawo-
mocnienia się postanowienia o odrzuceniu apelacji lub innego środka zaskarżenia 
wniesionego przez obowiązanego od orzeczenia uwzględniającego roszczenie, 
które podlegało zabezpieczeniu, nie wniósł o dokonanie dalszych czynności egze-
kucyjnych. 
**§ 3.** Na wniosek obowiązanego sąd wydaje postanowienie stwierdzające 
upadek zabezpieczenia w całości albo w części. 
### TYTUŁ III
Inne wypadki zabezpieczenia

***
## Art. 755. {#kpc-druga--art-755}

**§ 1.** Jeżeli przedmiotem zabezpieczenia nie jest roszczenie 
pieniężne, sąd udziela zabezpieczenia w taki sposób, jaki stosownie do 
okoliczności uzna za odpowiedni, nie wyłączając sposobów przewidzianych dla 
zabezpieczenia roszczeń pieniężnych. W szczególności sąd może: 
- 1) unormować prawa i obowiązki stron lub uczestników postępowania na czas 
trwania postępowania; 
- 2) ustanowić zakaz zbywania przedmiotów lub praw objętych postępowaniem; 
- 3) zawiesić postępowanie egzekucyjne lub inne postępowanie zmierzające do 
wykonania orzeczenia; 
- 4) uregulować sposób roztoczenia pieczy nad małoletnimi dziećmi i kontaktów 
z dzieckiem; 

 
 
 
s. 343/580 
 
2025-09-08 
- 5) nakazać wpisanie stosownego ostrzeżenia w księdze wieczystej lub we 
właściwym rejestrze. 
**§ 2.** W sprawach o ochronę dóbr osobistych zabezpieczenie polegające na 
zakazie publikacji może być udzielone tylko wtedy, gdy nie sprzeciwia się temu 
ważny interes publiczny. Udzielając zabezpieczenia, sąd określa czas trwania 
zakazu, który nie może być dłuższy niż rok. Jeżeli postępowanie w sprawie jest 
w toku, uprawniony może przed upływem okresu, na który orzeczono zakaz 
publikacji, żądać dalszego zabezpieczenia; przepisy zdania pierwszego i drugiego 
stosuje się. Jeżeli uprawniony zażądał dalszego zabezpieczenia, zakaz publikacji 
pozostaje w mocy do czasu prawomocnego rozstrzygnięcia wniosku. 
**§ 21.** Przepisu art. 731 nie stosuje się, jeżeli zabezpieczenie jest konieczne dla 
odwrócenia grożącej szkody lub innych niekorzystnych dla uprawnionego 
skutków. 
**§ 22.** W sprawach wymienionych w art. 47989 sąd udziela zabezpieczenia po 
wysłuchaniu 
obowiązanego, 
chyba 
że 
konieczne 
jest 
natychmiastowe 
rozstrzygnięcie wniosku. Nie dotyczy to sposobów zabezpieczenia w całości 
podlegających wykonaniu przez komornika albo polegających na ustanowieniu 
zarządu przymusowego nad przedsiębiorstwem lub gospodarstwem rolnym albo 
zakładem wchodzącym w skład przedsiębiorstwa lub jego częścią albo częścią 
gospodarstwa rolnego. 
**§ 23.** W sprawach 
wymienionych 
w art. 47989 sąd 
oddala 
wniosek 
o udzielenie zabezpieczenia, jeżeli został on złożony po upływie 6 miesięcy od 
dnia, w którym strona lub uczestnik postępowania powziął wiadomość 
o naruszeniu przysługującego mu prawa wyłącznego. 
**§ 3.** Sąd doręcza obowiązanemu postanowienie wydane na posiedzeniu 
niejawnym, w którym nakazuje mu wykonanie lub zaniechanie czynności albo 
nieprzeszkadzanie czynnościom uprawnionego. Nie dotyczy to postanowień 
nakazujących wydanie rzeczy będących we władaniu obowiązanego.

***
## Art. 7551. {#kpc-druga--art-7551}

W sprawach dotyczących roszczeń z tytułu czynów nieuczciwej 
konkurencji polegających na naruszeniu tajemnicy przedsiębiorstwa, w których 
udzielono zabezpieczenia polegającego na ustanowieniu zakazów, nakazów lub 
zajęciu rzeczy ruchomych, mającego na celu zaprzestanie wykorzystywania 
tajemnicy przedsiębiorstwa, sąd może, na wniosek obowiązanego, zamiast tych 

 
 
 
s. 344/580 
 
2025-09-08 
 
środków nakazać obowiązanemu złożenie na rachunek depozytowy Ministra 
Finansów 
odpowiedniej 
sumy 
pieniężnej 
dla 
zabezpieczenia 
roszczeń 
uprawnionego z tytułu dalszego wykorzystywania tajemnicy przedsiębiorstwa. 
Postanowienie może zapaść tylko po przeprowadzeniu rozprawy.

***
## Art. 7552. {#kpc-druga--art-7552}

**§ 1.** W sprawach z zakresu przeciwdziałania przemocy domowej 
sąd może udzielić zabezpieczenia również przez przedłużenie obowiązywania 
nakazu i zakazu, o którym mowa w art. 15aa ust. 1 ustawy z dnia 6 kwietnia 1990 r. 
o Policji albo art. 18a ust. 1 ustawy z dnia 24 sierpnia 2001 r. o Żandarmerii 
Wojskowej i wojskowych organach porządkowych, lub zakazów, o których mowa 
w art. 15aaa ustawy z dnia 6 kwietnia 1990 r. o Policji albo art. 18aa ustawy z dnia 
24 sierpnia 
2001 r. 
o Żandarmerii 
Wojskowej 
i wojskowych 
organach 
porządkowych. Sąd może zmienić wskazane w nakazie i zakazie obszar lub 
odległość od wspólnie zajmowanego mieszkania lub wskazaną w zakazie zbliżania 
się do osoby doznającej przemocy domowej odległość określoną w metrach, na 
którą osoba stosująca przemoc domową nie może zbliżyć się do osoby doznającej 
tej przemocy. 
**§ 2.** Sąd, udzielając zabezpieczenia, określa częstotliwość sprawdzania przez 
Policję albo Żandarmerię Wojskową, czy orzeczone nakaz i zakaz, o którym mowa 
w art. 15aa ust. 1 ustawy z dnia 6 kwietnia 1990 r. o Policji albo art. 18a ust. 1 
ustawy z dnia 24 sierpnia 2001 r. o Żandarmerii Wojskowej i wojskowych 
organach porządkowych, lub zakazy, o których mowa w art. 15aaa ustawy z dnia 
6 kwietnia 1990 r. o Policji albo art. 18aa ustawy z dnia 24 sierpnia 2001 r. 
o Żandarmerii Wojskowej i wojskowych organach porządkowych, nie są 
naruszane, z uwzględnieniem art. 15ai ust. 1 ustawy z dnia 6 kwietnia 1990 r. 
o Policji albo art. 18i ust. 1 ustawy z dnia 24 sierpnia 2001 r. o Żandarmerii 
Wojskowej i wojskowych organach porządkowych. 
**§ 3.** Przepisy art. 5604 § 2 i art. 5606 stosuje się odpowiednio. 
**§ 4.** Wniosek 
o udzielenie 
zabezpieczenia 
podlega 
rozpoznaniu 
bezzwłocznie, nie później jednak niż w terminie trzech dni od dnia jego wpływu do 
sądu. 
**§ 5.** Sąd 
doręcza 
niezwłocznie 
odpis 
postanowienia 
o udzieleniu 
zabezpieczenia uczestnikom postępowania, wraz z pouczeniem o zażaleniu, 
i prokuratorowi oraz Policji albo Żandarmerii Wojskowej, a ponadto zawiadamia 

 
 
 
s. 345/580 
 
2025-09-08 
 
właściwy miejscowo zespół interdyscyplinarny, o którym mowa w przepisach 
ustawy z dnia 29 lipca 2005 r. o przeciwdziałaniu przemocy domowej, a gdy 
w mieszkaniu zamieszkują osoby małoletnie lub osobą doznającą przemocy 
domowej jest osoba małoletnia – także właściwy miejscowo sąd opiekuńczy, chyba 
że zabezpieczenie następuje przez przedłużenie obowiązywania nakazu i zakazu 
lub zakazów, a właściwy miejscowo zespół interdyscyplinarny oraz sąd opiekuńczy 
zostały powiadomione o ich wydaniu przez Policję lub Żandarmerię Wojskową. 
**§ 6.** Sąd, udzielając zabezpieczenia przez wydanie zakazu wstępu na teren 
szkoły, placówki oświatowej, opiekuńczej lub artystycznej, lub obiektu 
sportowego, do których uczęszcza osoba doznająca przemocy domowej, miejsca 
pracy lub innego miejsca, w którym zwykle lub regularnie przebywa osoba 
doznająca przemocy domowej, i przebywania na tym terenie, zawiadamia o treści 
postanowienia dyrektora szkoły, placówki oświatowej, opiekuńczej lub 
artystycznej, do której uczęszcza osoba doznająca przemocy domowej, osobę 
zarządzającą obiektem sportowym, do którego uczęszcza osoba doznająca 
przemocy domowej, lub pracodawcę osoby doznającej przemocy domowej. Sąd 
może także zawiadomić inne osoby odpowiedzialne za miejsce, w którym zwykle 
lub regularnie przebywa osoba doznająca przemocy domowej, jeżeli jest to 
niezbędne do prawidłowego wykonania postanowienia.

***
## Art. 7553. {#kpc-druga--art-7553}

**§ 1.** W sprawach z zakresu przeciwdziałania przemocy domowej 
sąd, udzielając zabezpieczenia, wskazuje w postanowieniu czas jego trwania. 
**§ 2.** Sąd, udzielając zabezpieczenia przez wydanie zakazu kontaktowania się 
z osobą doznającą przemocy domowej, na wniosek wnioskodawcy, gdy 
przemawiają za tym szczególne okoliczności, może w postanowieniu określić 
dopuszczalne sposoby kontaktowania się oraz ich zakres, mając na względzie 
bezpieczeństwo osoby doznającej przemocy domowej.

***
## Art. 7554. {#kpc-druga--art-7554}

Sąd opiekuńczy po otrzymaniu zawiadomienia, o którym mowa 
w art. 15a ust. 4 lub art. 15ad ust. 4 ustawy z dnia 6 kwietnia 1990 r. o Policji albo 
art. 18 ust. 6 lub art. 18d ust. 4 ustawy z dnia 24 sierpnia 2001 r. o Żandarmerii 
Wojskowej 
i wojskowych 
organach 
porządkowych, 
albo 
art. 7552 § 5, 
bezzwłocznie podejmuje czynności w celu ustalenia sytuacji małoletniego i orzeka 
w przedmiocie zabezpieczenia. Po ustaleniu sytuacji małoletniego sąd opiekuńczy 

 
 
 
s. 346/580 
 
2025-09-08 
 
wszczyna z urzędu postępowanie dotyczące władzy rodzicielskiej, chyba że nie 
zachodzi konieczność jego wszczęcia, w szczególności gdy takie postępowanie się 
toczy.

***
## Art. 7555. {#kpc-druga--art-7555}

**§ 1.** W sprawach z zakresu prawa pracy, w których pracownik 
podlegający szczególnej ochronie przed rozwiązaniem stosunku pracy za 
wypowiedzeniem lub bez wypowiedzenia dochodzi roszczenia o uznanie 
wypowiedzenia stosunku pracy za bezskuteczne lub o przywrócenie do pracy, sąd 
na wniosek uprawnionego na każdym etapie postępowania udzieli zabezpieczenia 
przez nakazanie dalszego zatrudnienia go przez pracodawcę do czasu 
prawomocnego zakończenia postępowania. Podstawą udzielenia zabezpieczenia 
jest jedynie uprawdopodobnienie istnienia roszczenia. Sąd może odmówić 
udzielenia zabezpieczenia wyłącznie w sytuacji, gdy roszczenie jest oczywiście 
bezzasadne. 
**§ 2.** Postanowienie o udzieleniu zabezpieczenia podlega wykonaniu w drodze 
egzekucji. Przepis art. 7562 stosuje się. 
**§ 3.** Obowiązany może żądać uchylenia prawomocnego postanowienia 
o udzieleniu zabezpieczenia wyłącznie jeżeli wykaże, że po udzieleniu 
zabezpieczenia zaistniały przesłanki, o których mowa w art. 52 § 1 ustawy z dnia 
26 czerwca 1974 r. – Kodeks pracy. Zmiana postanowienia o udzieleniu 
zabezpieczenia jest niedopuszczalna. 
**§ 4.** Na postanowienie w przedmiocie udzielenia zabezpieczenia przysługuje 
zażalenie do sądu drugiej instancji.

***
## Art. 756. {#kpc-druga--art-756}

W sprawach 
o rozwód, 
o separację 
oraz 
o unieważnienie 
małżeństwa, sąd może również orzec o wydaniu małżonkowi, opuszczającemu 
mieszkanie zajmowane wspólnie przez małżonków, potrzebnych mu przedmiotów.

***
## Art. 7561. {#kpc-druga--art-7561}

W sprawach dotyczących pieczy nad małoletnimi dziećmi 
i kontaktów z dzieckiem sąd orzeka w przedmiocie zabezpieczenia po 
przeprowadzeniu rozprawy, chyba że chodzi o wypadek niecierpiący zwłoki.

***
## Art. 7562. {#kpc-druga--art-7562}

**§ 1.** Uwzględniając wniosek o zabezpieczenie przez uregulowanie: 
- 1) stosunków na czas trwania postępowania, 
- 2) sposobów kontaktów z dzieckiem, 

 
 
 
s. 347/580 
 
2025-09-08 
- 3) sposobu roztoczenia pieczy nad małoletnim dzieckiem w ten sposób, że 
dziecko będzie mieszkać z każdym z rodziców w powtarzających się okresach 
– sąd, 
na 
wniosek 
uprawnionego, 
może 
w postanowieniu 
o udzieleniu 
zabezpieczenia zagrozić obowiązanemu nakazaniem zapłaty określonej sumy 
pieniężnej na rzecz uprawnionego na wypadek naruszenia obowiązków 
określonych w tym postanowieniu. 
**§ 2.** Przepisy art. 10501 i art. 10511, a jeżeli zabezpieczenie polega na 
uregulowaniu sposobu kontaktów z dzieckiem albo ustaleniu, że dziecko będzie 
mieszkać z każdym z rodziców w powtarzających się okresach – przepis 
art. 5821 § 3, stosuje się odpowiednio.

***
## Art. 7563. {#kpc-druga--art-7563}

**§ 1.** Postanowienie o udzieleniu zabezpieczenia ustanawiające 
zakaz 
zbywania 
lub 
obciążania 
nieruchomości 
albo 
spółdzielczego 
własnościowego prawa do lokalu stanowi podstawę wpisu w księdze wieczystej 
ostrzeżenia o zakazie zbywania lub obciążania tych praw. 
**§ 2.** Sąd, który wydał postanowienie, o którym mowa w § 1, przekazuje to 
postanowienie sądowi dokonującemu wpisu ostrzeżenia w księdze wieczystej. 
Wpisu dokonuje się z urzędu. 
**§ 3.** Sąd, który dokonał wpisu ostrzeżenia w księdze wieczystej, doręcza 
postanowienie, o którym mowa w § 1, obowiązanemu. Postanowienie, o którym 
mowa w § 1, dotyczące spółdzielczego własnościowego prawa do lokalu doręcza 
się także spółdzielni mieszkaniowej. 
**§ 4.** Spółdzielnia mieszkaniowa ponosi odpowiedzialność za szkodę 
spowodowaną 
czynnościami 
zmierzającymi 
do 
zbycia 
spółdzielczego 
własnościowego prawa do lokalu mimo ustanowionego zakazu.

***
## Art. 7564. {#kpc-druga--art-7564}

**§ 1.** Czynność prawna dokonana wbrew zakazowi zbywania lub 
obciążania nieruchomości, która nie ma urządzonej księgi wieczystej lub której 
księga wieczysta zaginęła lub uległa zniszczeniu, jest nieważna. 
**§ 2.** Czynność prawna dokonana wbrew zakazowi zbywania lub obciążania 
nieruchomości, która ma urządzoną księgę wieczystą, albo spółdzielczego 
własnościowego prawa do lokalu jest nieważna, jeżeli dokonano wpisu w księdze 
wieczystej ostrzeżenia o zakazie zbywania lub obciążania tych praw. 

 
 
 
s. 348/580 
 
2025-09-08

***
## Art. 757. {#kpc-druga--art-757}

Jeżeli przepis szczególny nie stanowi inaczej albo sąd inaczej nie 
postanowi, zabezpieczenie udzielone według przepisów niniejszego tytułu upada 
po upływie dwóch miesięcy od uprawomocnienia się orzeczenia uwzględniającego 
roszczenie, które podlegało zabezpieczeniu, albo od uprawomocnienia się 
postanowienia o odrzuceniu apelacji lub innego środka zaskarżenia wniesionego 
przez obowiązanego od orzeczenia uwzględniającego roszczenie, które podlegało 
zabezpieczeniu. 
Na 
wniosek 
obowiązanego 
sąd 
wydaje 
postanowienie 
stwierdzające upadek zabezpieczenia w całości albo w części.

