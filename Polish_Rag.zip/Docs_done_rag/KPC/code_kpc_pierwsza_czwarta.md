---
id: code.kpc.czesc.pierwsza.ksiega.czwarta
title: "Kodeks postępowania cywilnego — CZĘŚĆ PIERWSZA — KSIĘGA CZWARTA (POSTĘPOWANIE W RAZIE ZAGINIĘCIA LUB ZNISZCZENIA AKT)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1964 Nr 43 poz. 296"
consolidated_citation: "t.j. Dz.U. 2024 poz. 1568, 1841; Dz.U. 2025 poz. 620, 1172"
status: "obowiązujący"
last_consolidated: "2025-09-08"
aliases: ["KPC — CZĘŚĆ PIERWSZA — Księga CZWARTA"]
tags: ["KPC","Kodeks postępowania cywilnego","CZĘŚĆ PIERWSZA","Księga CZWARTA","PL"]
source_pdf: "D19640296Lj.pdf"
articles: "Art. 716–729"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpc-pierwsza-czwarta-art-{n}}"
  separators: "***"
  hierarchy: ["CZĘŚĆ","KSIĘGA","TYTUŁ","DZIAŁ","Rozdział"]
---

# Kodeks postępowania cywilnego — CZĘŚĆ PIERWSZA — KSIĘGA CZWARTA: POSTĘPOWANIE W RAZIE ZAGINIĘCIA LUB ZNISZCZENIA AKT

POSTĘPOWANIE W RAZIE ZAGINIĘCIA LUB ZNISZCZENIA AKT
***
## Art. 716. {#kpc-pierwsza-czwarta-art-716}

Odtworzeniu ulegają akta zaginione lub zniszczone w całości lub 
części. W sprawie prawomocnie zakończonej odtworzeniu podlega orzeczenie 

 
 
 
s. 327/580 
 
2025-09-08 
 
kończące postępowanie w sprawie oraz ta część akt, która jest niezbędna do 
ustalenia jego treści i do wznowienia postępowania.

***
## Art. 717. {#kpc-pierwsza-czwarta-art-717}

**§ 1.** Sąd wszczyna postępowanie z urzędu lub na wniosek. 
**§ 2.** Sąd wszczyna postępowanie tylko na wniosek, jeżeli zaginięcie lub 
zniszczenie akt nastąpiło wskutek siły wyższej. Również w tym wypadku sąd może 
jednak wszcząć postępowanie z urzędu, jeżeli sprawa, której akta zaginęły lub 
uległy zniszczeniu, była lub mogła być wszczęta z urzędu.

***
## Art. 718. {#kpc-pierwsza-czwarta-art-718}

**§ 1.** Do zgłoszenia wniosku o odtworzenie akt uprawniona jest 
strona, uczestnik postępowania lub interwenient. 
**§ 2.** Wniosek o odtworzenie akt sprawy będącej w toku zgłosić można 
w ciągu lat trzech od zaginięcia lub zniszczenia akt, a wniosek o odtworzenie akt 
sprawy prawomocnie zakończonej – w ciągu lat dziesięciu od tej chwili. 
**§ 3.** Ograniczenia powyższe nie dotyczą wniosku o odtworzenie akt sprawy 
o prawa stanu.

***
## Art. 719. {#kpc-pierwsza-czwarta-art-719}

**§ 1.** Do odtworzenia akt sprawy będącej w toku właściwy jest sąd, 
w którym sprawa ostatnio się toczyła. 
**§ 2.** Jeżeli właściwy byłby sąd drugiej instancji lub Sąd Najwyższy, sąd ten 
przekaże sprawę sądowi pierwszej instancji, chyba że chodzi o odtworzenie tylko 
akt sądu drugiej instancji lub akt Sądu Najwyższego. 
**§ 3.** Postępowanie w razie zaginięcia lub zniszczenia akt w sprawie 
prawomocnie zakończonej przeprowadza sąd, w którym sprawa toczyła się 
w pierwszej instancji.

***
## Art. 720. {#kpc-pierwsza-czwarta-art-720}

Do odtworzenia akt sprawy zakończonej w państwowym biurze 
notarialnym właściwy jest sąd rejonowy, w którego okręgu znajdowało się to biuro.

***
## Art. 721. {#kpc-pierwsza-czwarta-art-721}

We wniosku o odtworzenie akt należy określić dokładnie sprawę, 
dołączyć wszelkie urzędowo poświadczone odpisy znajdujące się w posiadaniu 
zgłaszającego wniosek oraz wskazać znane mu miejsca, w których dokumenty lub 
ich odpisy się znajdują.

***
## Art. 722. {#kpc-pierwsza-czwarta-art-722}

**§ 1.** Przewodniczący wzywa osoby, organy administracji publicznej 
lub instytucje wskazane we wniosku oraz znane sądowi urzędowo do złożenia 

 
 
 
s. 328/580 
 
2025-09-08 
 
w określonym terminie poświadczonych urzędowo odpisów dokumentów 
będących w ich posiadaniu albo do oświadczenia, że ich nie posiadają. 
**§ 2.** Jeżeli osoba wezwana nie posiada dokumentu lub odpisu, a przed 
wezwaniem była w jego posiadaniu, powinna wyjaśnić, gdzie dokument lub odpis 
się znajduje.

***
## Art. 723. {#kpc-pierwsza-czwarta-art-723}

**§ 1.** Sąd może skazać na grzywnę każdego, kto nie uczyni zadość 
wezwaniu dokonanemu w myśl artykułu poprzedzającego. 
**§ 2.** Jeżeli wezwana była osoba prawna lub inna organizacja, ukaraniu 
podlega jej kierownik lub pracownik, którego obowiązkiem było uczynić zadość 
wezwaniu.

***
## Art. 724. {#kpc-pierwsza-czwarta-art-724}

Jeżeli 
poświadczone 
urzędowo 
odpisy 
zostaną 
złożone, 
przewodniczący zarządza dołączenie ich do akt. Odpis zarządzenia doręcza się 
stronom.

***
## Art. 725. {#kpc-pierwsza-czwarta-art-725}

Jeżeli odtworzenia akt nie można przeprowadzić w trybie 
przewidzianym w artykułach poprzedzających, przewodniczący wzywa strony do 
złożenia dokładnych oświadczeń co do treści zaginionych lub zniszczonych pism 
oraz dowodów na zawarte w nich twierdzenia, nie wyłączając prywatnych odpisów 
oraz innych pism i notatek, które mogą być pomocne przy odtworzeniu akt.

***
## Art. 726. {#kpc-pierwsza-czwarta-art-726}

Niezależnie od oświadczeń i wniosków stron sąd przeprowadza 
z urzędu dochodzenia, nie pomijając żadnej okoliczności, która może mieć 
znaczenie dla ustalenia treści zaginionych lub zniszczonych akt. Sąd bierze 
zwłaszcza pod uwagę wpisy do repertoriów i innych ksiąg biurowych. Sąd może 
też przesłuchać w charakterze świadków sędziów, prokuratorów, protokolantów, 
pełnomocników stron i inne osoby, które uczestniczyły w postępowaniu lub które 
mogą wypowiedzieć się co do treści akt, jak również może zarządzić przesłuchanie 
stron.

***
## Art. 727. {#kpc-pierwsza-czwarta-art-727}

Po przeprowadzeniu postępowania w myśl dwóch artykułów 
poprzedzających sąd orzeka postanowieniem, w jaki sposób i w jakim zakresie 
zaginione akta mają być odtworzone lub że odtworzenie akt jest niemożliwe. Na 
postanowienie przysługuje zażalenie. 

 
 
 
s. 329/580 
 
2025-09-08

***
## Art. 728. {#kpc-pierwsza-czwarta-art-728}

Jeżeli akta nie mogą być odtworzone lub odtworzone zostały 
w części niewystarczającej do podjęcia dalszego postępowania, sprawa może być 
wszczęta ponownie. We wszystkich innych wypadkach sąd podejmuje 
postępowanie w takim stanie, w jakim okaże się to możliwe przy uwzględnieniu 
akt pozostałych i odtworzonych. Na postanowienie co do podjęcia dalszego 
postępowania przysługuje zażalenie.

***
## Art. 729. {#kpc-pierwsza-czwarta-art-729}

Bieg przedawnienia przerwany przez pierwotne wszczęcie sprawy 
rozpoczyna się na nowo od daty uprawomocnienia się postanowienia 
stwierdzającego niemożliwość odtworzenia akt lub odmawiającego podjęcia 
dalszego postępowania.

