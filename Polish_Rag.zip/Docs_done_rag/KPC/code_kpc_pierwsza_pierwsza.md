---
id: code.kpc.czesc.pierwsza.ksiega.pierwsza
title: "Kodeks postępowania cywilnego — CZĘŚĆ PIERWSZA — KSIĘGA PIERWSZA (PROCES)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1964 Nr 43 poz. 296"
consolidated_citation: "t.j. Dz.U. 2024 poz. 1568, 1841; Dz.U. 2025 poz. 620, 1172"
status: "obowiązujący"
last_consolidated: "2025-09-08"
aliases: ["KPC — CZĘŚĆ PIERWSZA — Księga PIERWSZA"]
tags: ["KPC","Kodeks postępowania cywilnego","CZĘŚĆ PIERWSZA","Księga PIERWSZA","PL"]
source_pdf: "D19640296Lj.pdf"
articles: "Art. 15–50539"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpc-pierwsza-pierwsza-art-{n}}"
  separators: "***"
  hierarchy: ["CZĘŚĆ","KSIĘGA","TYTUŁ","DZIAŁ","Rozdział"]
---

# Kodeks postępowania cywilnego — CZĘŚĆ PIERWSZA — KSIĘGA PIERWSZA: PROCES

PROCES 
### TYTUŁ I
Sąd 
#### DZIAŁ I
Właściwość sądu 
Przepis wstępny
***
## Art. 15. {#kpc-pierwsza-pierwsza-art-15}

**§ 1.** Sąd właściwy w chwili wniesienia pozwu pozostaje właściwy aż 
do ukończenia postępowania, choćby podstawy właściwości zmieniły się w toku 
sprawy. 
**§ 2.** Sąd nie może uznać, że jest niewłaściwy, jeżeli w toku postępowania stał 
się właściwy. 

 
 
 
s. 5/580 
 
2025-09-08 
 
Rozdział 1 
Właściwość rzeczowa 
Oddział 1 
Podstawy właściwości

***
## Art. 16. {#kpc-pierwsza-pierwsza-art-16}

Sądy rejonowe rozpoznają wszystkie sprawy z wyjątkiem spraw, dla 
których zastrzeżona jest właściwość sądów okręgowych. 
**§ 2.** (uchylony)

***
## Art. 17. {#kpc-pierwsza-pierwsza-art-17}

Do właściwości sądów okręgowych należą sprawy: 
- 1) o prawa niemajątkowe i łącznie z nimi dochodzone roszczenia majątkowe 
oprócz spraw o ustalenie lub zaprzeczenie pochodzenia dziecka, o ustalenie 
bezskuteczności uznania ojcostwa oraz o rozwiązanie przysposobienia; 
- 2) (uchylony) 
- 3) o roszczenia wynikające z Prawa prasowego; 
- 4) o prawa majątkowe, w których wartość przedmiotu sporu przewyższa sto 
tysięcy złotych, oprócz spraw o alimenty, o naruszenie posiadania, 
o ustanowienie rozdzielności majątkowej między małżonkami oraz spraw 
rozpoznawanych w elektronicznym postępowaniu upominawczym; 
- 41) o wydanie orzeczenia zastępującego uchwałę o podziale spółdzielni; 
- 42) o uchylenie, stwierdzenie nieważności albo o ustalenie istnienia lub 
nieistnienia uchwał organów osób prawnych lub jednostek organizacyjnych 
niebędących osobami prawnymi, którym ustawa przyznaje zdolność prawną; 
- 43) (uchylony) 
- 44) o odszkodowanie z tytułu szkody wyrządzonej przez wydanie prawomocnego 
orzeczenia niezgodnego z prawem; 
- 45) o roszczenia wynikające z naruszenia praw przysługujących na mocy 
przepisów o ochronie danych osobowych. 
- 5) (uchylony) 
- 6) (uchylony)

***
## Art. 18. {#kpc-pierwsza-pierwsza-art-18}

**§ 1.** Jeżeli przy rozpoznawaniu sprawy w sądzie rejonowym 
powstanie zagadnienie prawne budzące poważne wątpliwości, sąd ten może 

 
 
 
s. 6/580 
 
2025-09-08 
 
przekazać sprawę do rozpoznania sądowi okręgowemu. Postanowienie 
o przekazaniu sprawy wymaga uzasadnienia. 
**§ 2.** Przed pierwszym posiedzeniem wyznaczonym na rozprawę sąd 
okręgowy może odmówić przyjęcia sprawy do rozpoznania i zwrócić ją sądowi 
rejonowemu, jeżeli uzna, że poważne wątpliwości nie zachodzą. Postanowienie 
zapada w składzie trzech sędziów i wymaga uzasadnienia. Ponowne przekazanie 
tej samej sprawy przez sąd rejonowy nie jest dopuszczalne. 
Oddział 2 
Wartość przedmiotu sporu

***
## Art. 19. {#kpc-pierwsza-pierwsza-art-19}

**§ 1.** W sprawach 
o roszczenia 
pieniężne, 
zgłoszone 
choćby 
w zamian innego przedmiotu, podana kwota pieniężna stanowi wartość przedmiotu 
sporu. 
**§ 2.** W innych sprawach majątkowych powód obowiązany jest oznaczyć 
w pozwie 
kwotą 
pieniężną 
wartość 
przedmiotu 
sporu, 
uwzględniając 
postanowienia zawarte w artykułach poniższych.

***
## Art. 20. {#kpc-pierwsza-pierwsza-art-20}

Do wartości przedmiotu sporu nie wlicza się odsetek, pożytków 
i kosztów, żądanych obok roszczenia głównego.

***
## Art. 21. {#kpc-pierwsza-pierwsza-art-21}

Jeżeli powód dochodzi pozwem kilku roszczeń, zlicza się ich 
wartość.

***
## Art. 22. {#kpc-pierwsza-pierwsza-art-22}

W sprawach o prawo do świadczeń powtarzających się wartość 
przedmiotu sporu stanowi suma świadczeń za jeden rok, a jeżeli świadczenia trwają 
krócej niż rok – za cały czas ich trwania.

***
## Art. 23. {#kpc-pierwsza-pierwsza-art-23}

W sprawach o istnienie, unieważnienie albo rozwiązanie umowy 
najmu lub dzierżawy, o wydanie albo odebranie przedmiotu najmu lub dzierżawy, 
wartość przedmiotu sporu stanowi przy umowach zawartych na czas oznaczony – 
suma czynszu za czas sporny, lecz nie więcej niż za rok; przy umowach zawartych 
na czas nieoznaczony – suma czynszu za okres trzech miesięcy.

***
## Art. 231. {#kpc-pierwsza-pierwsza-art-231}

W sprawach o roszczenia pracowników dotyczące nawiązania, 
istnienia lub rozwiązania stosunku pracy wartość przedmiotu sporu stanowi, przy 
umowach na czas określony – suma wynagrodzenia za pracę za okres sporny, lecz 

 
 
 
s. 7/580 
 
2025-09-08 
 
nie więcej niż za rok, a przy umowach na czas nieokreślony – za okres jednego 
roku.

***
## Art. 232. {#kpc-pierwsza-pierwsza-art-232}

W sprawach o wydanie nieruchomości posiadanej bez tytułu 
prawnego lub na podstawie tytułu innego niż najem lub dzierżawa wartość 
przedmiotu sporu oblicza się przyjmując, stosownie do rodzaju nieruchomości 
i sposobu korzystania z niej, podaną przez powoda sumę odpowiadającą 
trzymiesięcznemu czynszowi najmu lub dzierżawy należnemu od danego rodzaju 
nieruchomości.

***
## Art. 24. {#kpc-pierwsza-pierwsza-art-24}

W sprawach o zabezpieczenie, zastaw lub hipotekę wartość 
przedmiotu sporu stanowi suma wierzytelności. Jeżeli jednak przedmiot 
zabezpieczenia lub zastawu ma mniejszą wartość niż wierzytelność, rozstrzyga 
wartość mniejsza.

***
## Art. 25. {#kpc-pierwsza-pierwsza-art-25}

**§ 1.** Sąd może sprawdzić wartość przedmiotu sporu oznaczoną przez 
powoda i zarządzić w tym celu dochodzenie. 
**§ 2.** Po doręczeniu pozwu sprawdzenie nastąpić może jedynie na zarzut 
pozwanego, zgłoszony przed wdaniem się w spór co do istoty sprawy. 
**§ 3.** Jeżeli sąd w wyniku sprawdzenia wartości przedmiotu sporu uzna się za 
niewłaściwy, przekaże sprawę sądowi właściwemu; jeżeli jest kilka sądów 
właściwych – przekaże temu z nich, który wskaże powód.

***
## Art. 26. {#kpc-pierwsza-pierwsza-art-26}

Po ustaleniu w myśl artykułu poprzedzającego, wartość przedmiotu 
sporu nie podlega ponownemu badaniu w dalszym toku postępowania. 
Rozdział 2 
Właściwość miejscowa 
Oddział 1 
Właściwość ogólna

***
## Art. 27. {#kpc-pierwsza-pierwsza-art-27}

**§ 1.** Powództwo wytacza się przed sąd pierwszej instancji, w którego 
okręgu pozwany ma miejsce zamieszkania. 
**§ 2.** Miejsce zamieszkania określa się według przepisów kodeksu cywilnego.

***
## Art. 28. {#kpc-pierwsza-pierwsza-art-28}

Jeżeli pozwany nie ma miejsca zamieszkania w Polsce, ogólną 
właściwość oznacza się według miejsca jego pobytu w Polsce, a gdy nie jest ono 

 
 
 
s. 8/580 
 
2025-09-08 
 
znane lub nie leży w Polsce – według ostatniego miejsca zamieszkania pozwanego 
w Polsce.

***
## Art. 29. {#kpc-pierwsza-pierwsza-art-29}

Powództwo przeciwko Skarbowi Państwa wytacza się według 
siedziby państwowej jednostki organizacyjnej, z której działalnością wiąże się 
dochodzone roszczenie.

***
## Art. 30. {#kpc-pierwsza-pierwsza-art-30}

Powództwo przeciwko osobie prawnej lub innemu podmiotowi 
niebędącemu osobą fizyczną wytacza się według miejsca ich siedziby. 
Oddział 2 
Właściwość przemienna

***
## Art. 31. {#kpc-pierwsza-pierwsza-art-31}

**§ 1.** Powództwo w sprawach objętych przepisami oddziału 
niniejszego wytoczyć można bądź według przepisów o właściwości ogólnej, bądź 
przed sąd oznaczony w przepisach poniższych. 
**§ 2.** Przepisów niniejszego oddziału nie stosuje się w sprawach przeciwko 
konsumentom.

***
## Art. 32. {#kpc-pierwsza-pierwsza-art-32}

Powództwo o roszczenie alimentacyjne oraz o ustalenie pochodzenia 
dziecka i związane z tym roszczenia wytoczyć można według miejsca 
zamieszkania osoby uprawnionej.

***
## Art. 33. {#kpc-pierwsza-pierwsza-art-33}

Powództwo o roszczenie majątkowe przeciwko przedsiębiorcy 
można wytoczyć przed sąd, w którego okręgu znajduje się zakład główny lub 
oddział, jeżeli roszczenie pozostaje w związku z działalnością tego zakładu lub 
oddziału.

***
## Art. 34. {#kpc-pierwsza-pierwsza-art-34}

**§ 1.** Powództwo o zawarcie umowy, ustalenie jej treści, o zmianę 
umowy oraz o ustalenie istnienia umowy, o jej wykonanie, rozwiązanie lub 
unieważnienie, 
a także 
o odszkodowanie 
z powodu 
niewykonania 
lub 
nienależytego wykonania umowy można wytoczyć przed sąd miejsca jej 
wykonania. 
**§ 2.** Za miejsce wykonania umowy uważa się miejsce spełnienia świadczenia 
charakterystycznego dla umów danego rodzaju, w szczególności w przypadku: 
- 1) sprzedaży rzeczy ruchomych – miejsce, do którego rzeczy te zgodnie 
z umową zostały lub miały zostać dostarczone; 

 
 
 
s. 9/580 
 
2025-09-08 
- 2) świadczenia usług – miejsce, w którym usługi zgodnie z umową były lub 
miały być świadczone. 
**§ 3.** W przypadku wątpliwości miejsce wykonania umowy powinno być 
stwierdzone dokumentem.

***
## Art. 35. {#kpc-pierwsza-pierwsza-art-35}

Powództwo o roszczenie z czynu niedozwolonego wytoczyć można 
przed sąd, w którego okręgu nastąpiło zdarzenie wywołujące szkodę.

***
## Art. 351. {#kpc-pierwsza-pierwsza-art-351}

Powództwo 
o ochronę 
dóbr 
osobistych 
naruszonych 
przy 
wykorzystaniu środków masowego przekazu można wytoczyć przed sąd właściwy 
dla miejsca zamieszkania albo siedziby powoda.

***
## Art. 36. {#kpc-pierwsza-pierwsza-art-36}

Powództwo o zapłatę należności za prowadzenie sprawy wytoczyć 
można przed sąd miejsca, gdzie pełnomocnik procesowy sprawę prowadził.

***
## Art. 37. {#kpc-pierwsza-pierwsza-art-37}

Powództwo o roszczenie ze stosunku najmu lub dzierżawy 
nieruchomości wytoczyć można przed sąd miejsca położenia nieruchomości.

***
## Art. 371. {#kpc-pierwsza-pierwsza-art-371}

**§ 1.** Powództwo przeciwko zobowiązanemu z weksla lub czeku 
można wytoczyć przed sąd miejsca płatności. 
**§ 2.** Kilku zobowiązanych z weksla lub czeku można łącznie pozwać przed 
sąd miejsca płatności lub sąd właściwości ogólnej dla akceptanta albo wystawcy 
weksla własnego lub czeku.

***
## Art. 372. {#kpc-pierwsza-pierwsza-art-372}

**§ 1.** Powództwo o roszczenie wynikające z czynności bankowej 
przeciwko bankowi, innej jednostce organizacyjnej uprawnionej do wykonywania 
czynności bankowych lub ich następcom prawnym można wytoczyć przed sąd 
właściwy dla miejsca zamieszkania albo siedziby powoda. 
**§ 2.** Przepis § 1 stosuje się także do powództwa przeciwko bankowi 
hipotecznemu lub jego następcy prawnemu o roszczenie wynikające z czynności 
banku hipotecznego. 
Oddział 3 
Właściwość wyłączna

***
## Art. 38. {#kpc-pierwsza-pierwsza-art-38}

**§ 1.** Powództwo o: 
- 1) własność lub inne prawa rzeczowe na nieruchomości, 
- 2) posiadanie nieruchomości, 
- 3) roszczenia wynikające z art. 231 Kodeksu cywilnego, 

 
 
 
s. 10/580 
 
2025-09-08 
- 4) roszczenia wynikające z art. 224–228 i art. 230 Kodeksu cywilnego, o ile są 
związane z nieruchomością 
– wytacza się wyłącznie przed sąd miejsca położenia nieruchomości, przy czym 
jeżeli przedmiotem sporu jest służebność gruntowa, właściwość oznacza się według 
położenia nieruchomości obciążonej. 
**§ 2.** Właściwość powyższa rozciąga się na roszczenia osobiste związane 
z prawami rzeczowymi i dochodzone łącznie z nimi przeciwko temu samemu 
pozwanemu. 
**§ 3.** Sąd właściwy może na zgodny wniosek stron przekazać sprawę innemu 
sądowi równorzędnemu, jeżeli przemawiają za tym względy celowości.

***
## Art. 39. {#kpc-pierwsza-pierwsza-art-39}

Powództwo z tytułu dziedziczenia, zachowku, jak również z tytułu 
zapisu, polecenia oraz innych rozrządzeń testamentowych wytacza się wyłącznie 
przed sąd ostatniego miejsca zwykłego pobytu spadkodawcy, a jeżeli miejsca jego 
zwykłego pobytu w Polsce nie da się ustalić, przed sąd miejsca, w którym znajduje 
się majątek spadkowy lub jego część.

***
## Art. 40. {#kpc-pierwsza-pierwsza-art-40}

Powództwo ze stosunku członkostwa spółdzielni, spółki lub 
stowarzyszenia wytacza się wyłącznie według miejsca ich siedziby.

***
## Art. 41. {#kpc-pierwsza-pierwsza-art-41}

Powództwo ze stosunku małżeństwa wytacza się wyłącznie przed 
sąd, w którego okręgu małżonkowie mieli ostatnie miejsce zamieszkania, jeżeli 
choć jedno z nich w okręgu tym jeszcze ma miejsce zamieszkania lub zwykłego 
pobytu. Z braku takiej podstawy wyłącznie właściwy jest sąd miejsca zamieszkania 
strony pozwanej, a jeżeli i tej podstawy nie ma – sąd miejsca zamieszkania powoda.

***
## Art. 42. {#kpc-pierwsza-pierwsza-art-42}

Powództwo ze stosunku między rodzicami a dziećmi oraz między 
przysposabiającym a przysposobionym wytacza się wyłącznie przed sąd miejsca 
zamieszkania powoda, jeżeli brak jest podstaw do wytoczenia powództwa według 
przepisów o właściwości ogólnej. 
Oddział 4 
Przepisy szczególne

***
## Art. 43. {#kpc-pierwsza-pierwsza-art-43}

**§ 1.** Jeżeli uzasadniona jest właściwość kilku sądów albo jeżeli 
powództwo wytacza się przeciwko kilku osobom, dla których według przepisów 

 
 
 
s. 11/580 
 
2025-09-08 
 
o właściwości ogólnej właściwe są różne sądy, wybór między tymi sądami należy 
do powoda. 
**§ 2.** To samo dotyczy wypadku, gdy nieruchomość, której położenie jest 
podstawą oznaczenia właściwości sądu, jest położona w kilku okręgach sądowych.

***
## Art. 44. {#kpc-pierwsza-pierwsza-art-44}

**§ 1.** Jeżeli sąd właściwy nie może z powodu przeszkody rozpoznać 
sprawy lub podjąć innej czynności, sąd nad nim przełożony wyznaczy inny sąd 
równorzędny. 
**§ 2.** O wyznaczenie innego sądu równorzędnego występuje sąd właściwy.

***
## Art. 441. {#kpc-pierwsza-pierwsza-art-441}

**§ 1.** Sąd Najwyższy może przekazać sprawę do rozpoznania innemu 
sądowi równorzędnemu z sądem występującym, jeżeli wymaga tego dobro 
wymiaru sprawiedliwości, w szczególności wzgląd na społeczne postrzeganie sądu 
jako organu bezstronnego. 
**§ 2.** O przekazanie sprawy może wystąpić sąd właściwy.

***
## Art. 442. {#kpc-pierwsza-pierwsza-art-442}

Jeżeli stroną jest Skarb Państwa, a państwową jednostką 
organizacyjną, z której działalnością wiąże się dochodzone roszczenie, jest sąd: 
- 1) właściwy do rozpoznania sprawy – sąd ten z urzędu przedstawia akta sprawy 
sądowi nad nim przełożonemu, który przekazuje sprawę innemu sądowi 
równorzędnemu z sądem przedstawiającym; 
- 2) przełożony nad sądem właściwym do rozpoznania sprawy – sąd właściwy do 
rozpoznania sprawy z urzędu przedstawia akta sprawy temu sądowi 
przełożonemu, który przekazuje sprawę innemu sądowi równorzędnemu 
z sądem przedstawiającym, mającemu siedzibę poza obszarem właściwości 
sądu przekazującego.

***
## Art. 45. {#kpc-pierwsza-pierwsza-art-45}

**§ 1.** Jeżeli na podstawie przepisów kodeksu nie można w świetle 
okoliczności sprawy ustalić właściwości miejscowej, Sąd Najwyższy oznaczy sąd, 
przed który należy wytoczyć powództwo. 
**§ 2.** O oznaczenie sądu, przed który należy wytoczyć powództwo, występuje 
sąd, do którego wpłynął pozew.

***
## Art. 46. {#kpc-pierwsza-pierwsza-art-46}

**§ 1.** Strony mogą umówić się na piśmie o poddanie sądowi pierwszej 
instancji, który według ustawy nie jest miejscowo właściwy, sporu już wynikłego 
lub sporów mogących w przyszłości wyniknąć z oznaczonego stosunku prawnego. 
Sąd ten będzie wówczas wyłącznie właściwy, jeżeli strony nie postanowiły inaczej 

 
 
 
s. 12/580 
 
2025-09-08 
 
lub 
jeżeli 
powód 
nie 
złożył 
pozwu 
w elektronicznym 
postępowaniu 
upominawczym. Strony mogą również ograniczyć umową pisemną prawo wyboru 
powoda pomiędzy kilku sądami właściwymi dla takich sporów. 
**§ 2.** Strony nie mogą jednak zmieniać właściwości wyłącznej. 
#### DZIAŁ II
Skład sądu

***
## Art. 47. {#kpc-pierwsza-pierwsza-art-47}

**§ 1.** W pierwszej instancji sąd rozpoznaje sprawy w składzie jednego 
sędziego, chyba że przepis szczególny stanowi inaczej. 
**§ 2.** W pierwszej 
instancji 
sąd 
w składzie 
jednego 
sędziego 
jako 
przewodniczącego i dwóch ławników rozpoznaje sprawy: 
- 1) z zakresu prawa pracy o: 
  - a) ustalenie istnienia, nawiązanie lub wygaśnięcie stosunku pracy, 
o uznanie 
bezskuteczności 
wypowiedzenia 
stosunku 
pracy, 
o przywrócenie do pracy i przywrócenie poprzednich warunków pracy 
lub płacy oraz łącznie z nimi dochodzone roszczenia i o odszkodowanie 
w przypadku 
nieuzasadnionego 
lub 
naruszającego 
przepisy 
wypowiedzenia oraz rozwiązania stosunku pracy, 
  - b) naruszenia zasady równego traktowania w zatrudnieniu i o roszczenia 
z tym związane, 
  - c) odszkodowanie lub zadośćuczynienie w wyniku stosowania mobbingu; 
- 2) ze stosunków rodzinnych o: 
  - a) rozwód, 
  - b) separację, 
  - c) ustalenie bezskuteczności uznania ojcostwa, 
  - d) rozwiązanie przysposobienia. 
**§ 3.** Postanowienia poza rozprawą wydaje sąd w składzie jednego sędziego. 
**§ 31.** Zarządzenia wydaje przewodniczący. 
**§ 32.** W sprawach rozpoznawanych w składzie jednego sędziego sędzia ten 
ma prawa i obowiązki przewodniczącego. 
**§ 4.** Prezes sądu może zarządzić rozpoznanie sprawy w składzie trzech 
sędziów, jeżeli uzna to za wskazane ze względu na szczególną zawiłość lub 
precedensowy charakter sprawy. 

 
 
 
s. 13/580 
 
2025-09-08

***
## Art. 471. {#kpc-pierwsza-pierwsza-art-471}

Referendarz sądowy może wykonywać czynności w postępowaniu 
cywilnym w przypadkach wskazanych w ustawie. W zakresie powierzonych mu 
czynności referendarz sądowy ma, zależnie od rodzaju podejmowanej czynności, 
prawa i obowiązki sądu albo przewodniczącego.

***
## Art. 472. {#kpc-pierwsza-pierwsza-art-472}

**§ 1.** W zakresie czynności przewodniczącego zarządzenia może 
również wydawać asystent sędziego, z wyjątkiem zarządzenia o zwrocie pisma 
procesowego, w tym pozwu. W każdym przypadku przewodniczący może uchylić 
lub zmienić zarządzenie asystenta. 
**§ 2.** W terminie tygodnia od dnia doręczenia stronie zarządzenia asystenta 
sędziego o wezwaniu do uiszczenia opłaty, z pouczeniem o terminie i sposobie 
wniesienia zastrzeżenia, strona może wnieść zastrzeżenie do zarządzenia asystenta 
sędziego o wezwaniu do uiszczenia opłaty. Zastrzeżenie powinno zawierać 
wskazanie zaskarżonego zarządzenia. Zastrzeżenie nie wymaga uzasadnienia. 
**§ 3.** W razie wniesienia zastrzeżenia zarządzenie asystenta sędziego 
o wezwaniu do uiszczenia opłaty traci moc. Zastrzeżenie wniesione po upływie 
terminu lub niespełniające warunków formalnych pisma procesowego nie 
wywołuje skutków i pozostawia się je bez rozpoznania, bez wzywania do jego 
poprawienia lub uzupełnienia. W takim przypadku przewodniczący z urzędu bada 
prawidłowość zarządzenia asystenta sędziego. 
#### DZIAŁ III
Wyłączenie sędziego

***
## Art. 48. {#kpc-pierwsza-pierwsza-art-48}

**§ 1.** Sędzia jest wyłączony z mocy samej ustawy: 
- 1) w sprawach, w których jest stroną lub pozostaje z jedną ze stron w takim 
stosunku prawnym, że wynik sprawy oddziaływa na jego prawa lub 
obowiązki; 
- 2) w sprawach swego małżonka, krewnych lub powinowatych w linii prostej, 
krewnych bocznych do czwartego stopnia i powinowatych bocznych do 
drugiego stopnia; 
- 3) w sprawach osób związanych z nim z tytułu przysposobienia, opieki lub 
kurateli; 
- 4) w sprawach, w których był lub jest jeszcze pełnomocnikiem albo był radcą 
prawnym jednej ze stron; 

 
 
 
s. 14/580 
 
2025-09-08 
 
5)4) w sprawach, w których w instancji niższej brał udział w wydaniu 
zaskarżonego orzeczenia, jako też w sprawach o ważność aktu prawnego 
z jego udziałem sporządzonego lub przez niego rozpoznanego oraz 
w sprawach, w których występował jako prokurator; 
- 6) w sprawach o odszkodowanie z tytułu szkody wyrządzonej przez wydanie 
prawomocnego orzeczenia niezgodnego z prawem, jeżeli brał udział 
w wydaniu tego orzeczenia. 
**§ 2.** Powody wyłączenia trwają także po ustaniu uzasadniającego je 
małżeństwa, przysposobienia, opieki lub kurateli. 
**§ 3.** Sędzia, który brał udział w wydaniu orzeczenia objętego skargą 
o wznowienie lub skargą nadzwyczajną, nie może orzekać co do tej skargi.

***
## Art. 481. {#kpc-pierwsza-pierwsza-art-481}

W przypadku wyłączenia sędziego na podstawie art. 48 § 1 pkt 1–
4 sąd występuje do sądu nad nim przełożonego o wyznaczenie innego sądu do 
rozpoznania sprawy, a sąd przełożony wyznacza inny równorzędny sąd.

***
## Art. 49. {#kpc-pierwsza-pierwsza-art-49}

**§ 1.** 5) 6) Niezależnie od przyczyn wymienionych w art. 48, sąd 
wyłącza sędziego na jego żądanie lub na wniosek strony, jeżeli istnieje okoliczność 
tego rodzaju, że mogłaby wywołać uzasadnioną wątpliwość co do bezstronności 
sędziego w danej sprawie. 
**§ 2.** Za okoliczność, o której mowa w § 1, nie uważa się wyrażenia przez 
sędziego poglądu co do prawa i faktów przy wyjaśnianiu stronom czynności sądu, 
nakłanianiu do ugody lub udzielaniu pouczeń. 
- 4) Utracił moc z dniem 30 lipca 2004 r. w związku z art. 401 pkt 1 i art. 379 pkt 4, w zakresie, 
w jakim ogranicza wyłączenie sędziego z mocy samej ustawy tylko do spraw, w których 
rozstrzyganiu brał udział w instancji bezpośrednio niższej, na podstawie wyroku Trybunału 
Konstytucyjnego z dnia 20 lipca 2004 r. sygn. akt SK 19/02 (Dz. U. poz. 1783). 
- 5) Utracił moc z dniem 9 czerwca 2020 r. w zakresie, w jakim dopuszcza rozpoznanie wniosku o 
wyłączenie sędziego z powodu podniesienia okoliczności wadliwości powołania sędziego przez 
Prezydenta Rzeczypospolitej Polskiej na wniosek Krajowej Rady Sądownictwa, na podstawie 
wyroku Trybunału Konstytucyjnego z dnia 2 czerwca 2020 r. sygn. akt P 13/19 (Dz. U. poz. 
1017). 
- 6) Utracił moc z dniem 28 lutego 2022 r. w zakresie, w jakim za przesłankę mogącą wywołać 
uzasadnioną wątpliwość co do bezstronności sędziego w danej sprawie uznaje jakąkolwiek 
okoliczność odnoszącą się do procedury powoływania tego sędziego przez Prezydenta 
Rzeczypospolitej Polskiej na wniosek Krajowej Rady Sądownictwa do pełnienia urzędu, na 
podstawie wyroku Trybunału Konstytucyjnego z dnia 23 lutego 2022 r. sygn. akt P 10/19 (Dz. 
U. poz. 480). 

 
 
 
s. 15/580 
 
2025-09-08

***
## Art. 50. {#kpc-pierwsza-pierwsza-art-50}

**§ 1.** Wniosek o wyłączenie sędziego strona zgłasza na piśmie lub 
ustnie do protokołu w sądzie, w którym sprawa się toczy, uprawdopodabniając 
przyczyny wyłączenia. 
**§ 2.** Strona, która przystąpiła do rozprawy, powinna uprawdopodobnić 
ponadto, że przyczyna wyłączenia dopiero później powstała lub stała się jej znana. 
**§ 3.** Do czasu rozstrzygnięcia wniosku o wyłączenie sędziego: 
- 1) sędzia, którego dotyczy wniosek, może podejmować dalsze czynności; 
- 2) nie może zostać wydane orzeczenie lub zarządzenie kończące postępowanie 
w sprawie.

***
## Art. 51. {#kpc-pierwsza-pierwsza-art-51}

Sędzia 
zawiadamia 
sąd 
o zachodzącej 
podstawie 
swojego 
wyłączenia.

***
## Art. 52. {#kpc-pierwsza-pierwsza-art-52}

**§ 1.** O wyłączeniu sędziego rozstrzyga sąd, w którym sprawa się 
toczy, a gdyby sąd ten nie mógł wydać postanowienia z powodu braku dostatecznej 
liczby sędziów – sąd nad nim przełożony. 
**§ 2.** Postanowienie wydaje się po złożeniu wyjaśnienia przez sędziego, 
którego wniosek dotyczy. W przypadku niezłożenia wyjaśnienia w terminie dwóch 
tygodni od dnia wpływu wniosku do sądu właściwego, a jeśli był dotknięty bra-
kami – od dnia ich usunięcia, wniosek podlega rozpoznaniu bez wyjaśnienia, chyba 
że sąd uzna złożenie wyjaśnienia za konieczne. 
**§ 3.** Uwzględniając wniosek o wyłączenie sędziego, sąd znosi postępowanie 
w zakresie obejmującym udział tego sędziego w sprawie po złożeniu wniosku, 
chyba że czynności przez niego podejmowane były czynnościami niecierpiącymi 
zwłoki.

***
## Art. 53. {#kpc-pierwsza-pierwsza-art-53}

(utracił moc)7)

***
## Art. 531. {#kpc-pierwsza-pierwsza-art-531}

**§ 1.** Niedopuszczalny jest wniosek o wyłączenie sędziego: 
- 1) oparty wyłącznie na okolicznościach związanych z rozstrzygnięciem przez 
sąd o dowodach; 
- 2) złożony po raz kolejny co do tego samego sędziego z powołaniem tych 
samych okoliczności; 
- 3) niebędącego członkiem składu orzekającego. 
- 7) Z dniem 18 grudnia 2002 r. na podstawie wyroku Trybunału Konstytucyjnego z dnia 11 grudnia 
2002 r. sygn. akt SK. 27/01 (Dz. U. poz. 1849). 

 
 
 
s. 16/580 
 
2025-09-08 
**§ 2.** Wniosek, o którym mowa w § 1, pozostawia się w aktach sprawy bez 
żadnych dalszych czynności. To samo dotyczy pism związanych z jego 
wniesieniem. O pozostawieniu wniosku i pism związanych z jego wniesieniem 
zawiadamia się stronę wnoszącą tylko raz – przy złożeniu pierwszego pisma. 
**§ 3.** W przypadku złożenia ustnie wniosku, o którym mowa w § 1, 
przewodniczący zawiadamia stronę o jego bezskuteczności.

***
## Art. 54. {#kpc-pierwsza-pierwsza-art-54}

Przepisy niniejszego działu, z wyłączeniem przepisu art. 481, stosuje 
się odpowiednio do wyłączenia referendarza sądowego, ławnika, jak również 
innych organów sądowych oraz prokuratora. Wniosek o wyłączenie referendarza 
sądowego oraz ławnika sąd rozstrzyga zgodnie z przepisami niniejszego działu, 
a w pozostałych przypadkach przekazuje odpowiedniemu organowi nadrzędnemu. 
### TYTUŁ II
Prokurator

***
## Art. 55. {#kpc-pierwsza-pierwsza-art-55}

Prokurator, wytaczając powództwo na rzecz oznaczonej osoby, 
powinien ją wskazać w pozwie. Nie dotyczy to spraw niemajątkowych z zakresu 
prawa rodzinnego, chyba że przepis szczególny stanowi inaczej.

***
## Art. 56. {#kpc-pierwsza-pierwsza-art-56}

**§ 1.** Osobę, na rzecz której prokurator wytoczył powództwo, sąd 
zawiadamia o tym, doręczając jej odpis pozwu. Osoba ta może wstąpić do sprawy 
w każdym jej stanie w charakterze powoda; w tym wypadku do udziału prokuratora 
w sprawie stosuje się odpowiednio przepisy o współuczestnictwie jednolitym. 
**§ 2.** Prokurator nie może samodzielnie rozporządzać przedmiotem sporu.

***
## Art. 57. {#kpc-pierwsza-pierwsza-art-57}

Jeżeli prokurator, wytaczając powództwo, nie działa na rzecz 
oznaczonej osoby, wnosi on pozew przeciwko wszystkim osobom będącym 
stronami stosunku prawnego, którego dotyczy powództwo.

***
## Art. 58. {#kpc-pierwsza-pierwsza-art-58}

Wyrok 
prawomocny 
zapadły 
w sprawie 
wytoczonej 
przez 
prokuratora ma powagę rzeczy osądzonej pomiędzy stroną, na rzecz której 
prokurator wytoczył powództwo, a stroną przeciwną. Jednakże w sprawach 
o roszczenia majątkowe prawomocne rozstrzygnięcie sprawy nie pozbawia strony 
zainteresowanej, która nie brała udziału w sporze, możności dochodzenia swoich 
roszczeń w całości lub w tej części, w której nie zostały zasądzone. 

 
 
 
s. 17/580 
 
2025-09-08

***
## Art. 59. {#kpc-pierwsza-pierwsza-art-59}

Sąd zawiadamia prokuratora o każdej sprawie, w której udział jego 
uważa za potrzebny.

***
## Art. 60. {#kpc-pierwsza-pierwsza-art-60}

**§ 1.** Prokurator może wstąpić do postępowania w każdym jego 
stadium. Prokurator nie jest związany z żadną ze stron. Może on składać 
oświadczenia i zgłaszać wnioski, jakie uzna za celowe, oraz przytaczać fakty 
i dowody na ich potwierdzenie. Od chwili, kiedy prokurator zgłosił udział 
w postępowaniu, należy mu doręczać pisma procesowe, zawiadomienia 
o terminach i posiedzeniach oraz orzeczenia sądowe. 
**§ 2.** Prokurator może zaskarżyć każde orzeczenie sądowe, od którego służy 
środek odwoławczy. Terminy do zaskarżenia orzeczeń sądowych, ustanowione dla 
stron, wiążą również prokuratora. 
### TYTUŁ III
Organizacje pozarządowe

***
## Art. 61. {#kpc-pierwsza-pierwsza-art-61}

**§ 1.** Organizacje pozarządowe w zakresie swoich zadań statutowych 
mogą, za zgodą osoby fizycznej wyrażoną na piśmie, wytaczać powództwa na jej 
rzecz w sprawach o: 
- 1) alimenty; 
- 2) ochronę środowiska; 
- 3) ochronę konsumentów; 
- 4) ochronę praw własności przemysłowej; 
- 5) ochronę równości oraz niedyskryminacji przez bezpodstawne bezpośrednie 
lub pośrednie zróżnicowanie praw i obowiązków obywateli. 
**§ 2.** W sprawach wymienionych w § 1 organizacje pozarządowe w zakresie 
swoich zadań statutowych mogą, za zgodą osoby fizycznej wyrażoną na piśmie, 
przystąpić do niej w toczącym się postępowaniu. 
**§ 3.** Za zgodą przedsiębiorcy, wyrażoną na piśmie, organizacja pozarządowa, 
której jest członkiem, może na jego rzecz wytoczyć powództwo lub przystąpić do 
niego w toczącym się postępowaniu związanym z prowadzoną przez niego 
działalnością gospodarczą. 
**§ 4.** Do pozwu lub pisma obejmującego przystąpienie organizacja 
pozarządowa dołącza wyrażoną na piśmie zgodę osoby fizycznej. 

 
 
 
s. 18/580 
 
2025-09-08

***
## Art. 62. {#kpc-pierwsza-pierwsza-art-62}

**§ 1.** Do organizacji pozarządowych wytaczających powództwa na 
rzecz osób fizycznych lub przedsiębiorców stosuje się odpowiednio przepisy 
o prokuratorze wytaczającym powództwo na rzecz oznaczonej osoby, z wyjątkiem 
art. 58 zdanie drugie. 
**§ 2.** Do przystąpienia organizacji pozarządowych do strony w toczącym się 
postępowaniu stosuje się odpowiednio przepisy o interwencji ubocznej, do której 
nie mają odpowiedniego zastosowania przepisy o współuczestnictwie jednolitym.

***
## Art. 63. {#kpc-pierwsza-pierwsza-art-63}

Organizacje 
pozarządowe 
wymienione 
w artykułach 
poprzedzających, które nie uczestniczą w sprawie, mogą przedstawiać sądowi 
istotny dla sprawy pogląd wyrażony w uchwale lub w oświadczeniu ich należycie 
umocowanych organów. 
TYTUŁ IIIa 
Państwowa Inspekcja Pracy

***
## Art. 631. {#kpc-pierwsza-pierwsza-art-631}

W sprawach o ustalenie istnienia stosunku pracy inspektorzy pracy 
mogą wytaczać powództwa na rzecz obywateli, a także wstępować, za zgodą 
powoda, do postępowania w tych sprawach w każdym jego stadium.

***
## Art. 632. {#kpc-pierwsza-pierwsza-art-632}

W sprawach 
wymienionych 
w artykule 
poprzedzającym 
do 
inspektorów pracy stosuje się odpowiednio przepisy o prokuratorze. 
TYTUŁ IIIb 
Powiatowy (miejski) rzecznik konsumentów

***
## Art. 633. {#kpc-pierwsza-pierwsza-art-633}

W sprawach o ochronę konsumentów powiatowy (miejski) rzecznik 
konsumentów może wytaczać powództwa na rzecz konsumentów, a także 
wstępować, za ich zgodą, do postępowań w tych sprawach w każdym ich stadium.

***
## Art. 634. {#kpc-pierwsza-pierwsza-art-634}

W sprawach, o których mowa w art. 633, do powiatowego 
(miejskiego) rzecznika konsumentów stosuje się odpowiednio przepisy 
o prokuratorze. 

 
 
 
s. 19/580 
 
2025-09-08 
### TYTUŁ IIIc
Podmioty uprawnione do udziału w postępowaniu na podstawie odrębnych 
przepisów

***
## Art. 635. {#kpc-pierwsza-pierwsza-art-635}

**§ 1.** Jeżeli przepisy odrębne przyznają określonym podmiotom, 
które nie uczestniczą w sprawie, uprawnienie do przedstawiania sądowi istotnego 
dla sprawy poglądu, do podmiotów tych stosuje się odpowiednio przepis art. 63. 
Jednak na wniosek podmiotu uprawnionego sąd może zezwolić, aby pogląd został 
przedstawiony także ustnie na rozprawie. 
**§ 2.** Na wniosek podmiotu uprawnionego sąd udostępnia akta sprawy 
w zakresie niezbędnym do przedstawienia poglądu. 
### TYTUŁ IV
Strony 
#### DZIAŁ I
Zdolność sądowa i procesowa

***
## Art. 64. {#kpc-pierwsza-pierwsza-art-64}

**§ 1.** Każda osoba fizyczna i prawna ma zdolność występowania 
w procesie jako strona (zdolność sądowa). 
**§ 11.** Zdolność sądową mają także jednostki organizacyjne niebędące osobami 
prawnymi, którym ustawa przyznaje zdolność prawną. 
**§ 2.** (uchylony)

***
## Art. 65. {#kpc-pierwsza-pierwsza-art-65}

**§ 1.** Zdolność do czynności procesowych (zdolność procesową) mają 
osoby fizyczne posiadające pełną zdolność do czynności prawnych, osoby prawne 
oraz jednostki organizacyjne, o których mowa w art. 64 § 11. 
**§ 2.** Osoba fizyczna ograniczona w zdolności do czynności prawnych ma 
zdolność procesową w sprawach wynikających z czynności prawnych, których 
może dokonywać samodzielnie.

***
## Art. 66. {#kpc-pierwsza-pierwsza-art-66}

Osoba fizyczna niemająca zdolności procesowej może podejmować 
czynności procesowe tylko przez swego przedstawiciela ustawowego.

***
## Art. 67. {#kpc-pierwsza-pierwsza-art-67}

**§ 1.** Osoby prawne oraz jednostki organizacyjne, o których mowa 
w art. 64 § 11, dokonują czynności procesowych przez swoje organy albo przez 
osoby uprawnione do działania w ich imieniu. 

 
 
 
s. 20/580 
 
2025-09-08 
**§ 11.** W zakresie określonym odrębną ustawą za inne niż Skarb Państwa 
państwowe osoby prawne, osoby z udziałem Skarbu Państwa i osoby prawne z 
udziałem państwowych osób prawnych czynności procesowe może podejmować 
Prokuratoria Generalna Rzeczypospolitej Polskiej. 
**§ 2.** Za Skarb Państwa podejmuje czynności procesowe organ państwowej 
jednostki organizacyjnej, z której działalnością wiąże się dochodzone roszczenie, 
lub organ jednostki nadrzędnej. W zakresie określonym odrębną ustawą za Skarb 
Państwa czynności procesowe podejmuje Prokuratoria Generalna Rzeczypospolitej 
Polskiej. 
**§ 3.** (uchylony)

***
## Art. 68. {#kpc-pierwsza-pierwsza-art-68}

**§ 1.** 8) Przedstawiciel ustawowy, organy oraz osoby wymienione 
w art. 67 mają obowiązek wykazać swoje umocowanie dokumentem przy 
pierwszej czynności procesowej. 
**§ 2.** Przepisu § 1 nie stosuje się, gdy stwierdzenie umocowania przez sąd jest 
możliwe na podstawie wykazu lub innego rejestru, do którego sąd ma dostęp drogą 
elektroniczną, a także gdy czynność procesowa jest dokonywana za pośrednictwem 
systemu teleinformatycznego, w przypadku gdy przepis szczególny przewiduje, że 
czynności można dokonać wyłącznie za pośrednictwem tego systemu. 
Przedstawiciel ustawowy, organy oraz osoby wymienione w art. 67 mają jednak 
obowiązek wskazać podstawę swojego umocowania. 
**§ 3.** Jeżeli czynności procesowe za stronę podejmuje organ państwowej lub 
samorządowej jednostki organizacyjnej, przedłożenie aktu powołania lub innego 
aktu równorzędnego potwierdzającego powierzenie określonej osobie pełnienia 
funkcji tego organu nie jest wymagane, o ile stwierdzenie tego faktu jest możliwe 
na 
podstawie 
informacji 
powszechnie 
dostępnych, 
w szczególności 
udostępnionych w Biuletynie Informacji Publicznej. W takim przypadku 
w pierwszym piśmie procesowym tej strony wskazuje się źródło informacji, 
z których wynika umocowanie określonej osoby do działania w imieniu organu. 
- 8) Utracił moc z dniem 11 września 2017 r. w związku z art. 67 w zakresie, w jakim dopuszcza 
ocenę prawidłowości procedury przedstawienia kandydatów na stanowisko Prezesa oraz 
Wiceprezesa Trybunału Konstytucyjnego przez Zgromadzenie Ogólne Sędziów Trybunału 
Konstytucyjnego i powołania ich przez Prezydenta Rzeczypospolitej Polskiej, który prowadzi 
do wystawienia dokumentu, o którym stanowi ten przepis, na podstawie wyroku Trybunału 
Konstytucyjnego, o którym mowa w odnośniku 3. 

 
 
 
s. 21/580 
 
2025-09-08

***
## Art. 69. {#kpc-pierwsza-pierwsza-art-69}

**§ 1.** Sąd orzekający, na wniosek strony przeciwnej, ustanawia 
kuratora dla strony niemającej zdolności procesowej, która nie ma przedstawiciela 
ustawowego, dla strony będącej osobą prawną, gdy w jej organie zachodzą braki 
uniemożliwiające jej reprezentację, albo dla strony będącej jednostką 
organizacyjną, o której mowa w art. 64 § 11, gdy brak jest osób uprawnionych do 
jej reprezentowania. W toku postępowania sąd orzekający w uzasadnionych 
przypadkach może z urzędu ustanowić kuratora dla osoby prawnej lub jednostki 
organizacyjnej, o której mowa w art. 64 § 11. 
**§ 2.** Sąd niezwłocznie zawiadamia właściwy sąd rejestrowy o ustanowieniu 
kuratora dla strony wpisanej do Krajowego Rejestru Sądowego. 
**§ 3.** Kurator ustanowiony na podstawie § 1 jest umocowany do dokonywania 
wszystkich czynności łączących się ze sprawą. 
**§ 4.** Po otrzymaniu zawiadomienia, o którym mowa w art. 603 § 5, sąd 
orzekający odwołuje kuratora ustanowionego na podstawie § 1. W miejsce 
odwołanego 
kuratora 
wstępuje 
kurator 
ustanowiony 
na 
podstawie 
art. 42 § 1 Kodeksu cywilnego. Czynności odwołanego kuratora pozostają w mocy. 
**§ 5.** Czynności, o których mowa w § 1 i 4, mogą być wykonywane przez 
referendarza sądowego.

***
## Art. 70. {#kpc-pierwsza-pierwsza-art-70}

**§ 1.** Jeżeli braki w zakresie zdolności sądowej lub procesowej albo 
w składzie właściwych organów dają się uzupełnić, sąd wyznaczy w tym celu 
odpowiedni termin. W wypadkach, w których ustanowienie przedstawiciela 
ustawowego powinno nastąpić z urzędu, sąd zwraca się o to do właściwego sądu 
opiekuńczego. 
**§ 2.** Sąd może dopuścić tymczasowo do czynności stronę niemającą zdolności 
sądowej lub procesowej albo osobę niemającą należytego ustawowego 
umocowania, z zastrzeżeniem, że przed upływem wyznaczonego terminu braki 
będą uzupełnione, a czynności zatwierdzone przez powołaną do tego osobę.

***
## Art. 71. {#kpc-pierwsza-pierwsza-art-71}

Jeżeli braków powyższych nie można uzupełnić albo nie zostały one 
w wyznaczonym terminie uzupełnione, sąd zniesie postępowanie w zakresie, 
w jakim jest ono dotknięte brakami, i w miarę potrzeby wyda odpowiednie 
postanowienie. 

 
 
 
s. 22/580 
 
2025-09-08 
#### DZIAŁ II
Współuczestnictwo w sporze

***
## Art. 72. {#kpc-pierwsza-pierwsza-art-72}

**§ 1.** Kilka osób może w jednej sprawie występować w roli powodów 
lub pozwanych, jeżeli przedmiot sporu stanowią: 
- 1) prawa lub obowiązki im wspólne lub oparte na tej samej podstawie faktycznej 
i prawnej (współuczestnictwo materialne); 
- 2) roszczenia lub zobowiązania jednego rodzaju, oparte na jednakowej 
podstawie faktycznej i prawnej, jeżeli ponadto właściwość sądu jest 
uzasadniona dla każdego z roszczeń lub zobowiązań z osobna, jako też dla 
wszystkich wspólnie (współuczestnictwo formalne). 
**§ 2.** Jeżeli przeciwko kilku osobom sprawa może toczyć się tylko łącznie 
(współuczestnictwo konieczne), przepis paragrafu poprzedzającego stosuje się 
także do osób, których udział w sprawie uzasadniałby jej rozpoznanie 
w postępowaniu odrębnym. 
**§ 3.** Przepis § 2 stosuje się odpowiednio w wypadku współuczestnictwa 
materialnego, innego niż współuczestnictwo konieczne.

***
## Art. 73. {#kpc-pierwsza-pierwsza-art-73}

**§ 1.** Każdy współuczestnik działa w imieniu własnym. 
**§ 2.** W wypadku jednak, gdy z istoty spornego stosunku prawnego lub 
z przepisu ustawy wynika, że wyrok dotyczyć ma niepodzielnie wszystkich 
współuczestników 
(współuczestnictwo 
jednolite), 
czynności 
procesowe 
współuczestników działających są skuteczne wobec niedziałających. Do zawarcia 
ugody, zrzeczenia się roszczenia albo uznania powództwa potrzeba zgody 
wszystkich współuczestników.

***
## Art. 74. {#kpc-pierwsza-pierwsza-art-74}

Każdy ze współuczestników sporu ma prawo samodzielnie popierać 
sprawę. Na posiedzenie sądowe wzywa się wszystkich tych współuczestników, co 
do których sprawa nie jest zakończona. 
#### DZIAŁ III
Interwencja główna i uboczna

***
## Art. 75. {#kpc-pierwsza-pierwsza-art-75}

Kto występuje z roszczeniem o rzecz lub prawo, o które sprawa toczy 
się pomiędzy innymi osobami, może aż do zamknięcia rozprawy w pierwszej 

 
 
 
s. 23/580 
 
2025-09-08 
 
instancji wytoczyć powództwo o tę rzecz lub prawo przeciwko obu stronom przed 
sąd, w którym toczy się sprawa (interwencja główna).

***
## Art. 76. {#kpc-pierwsza-pierwsza-art-76}

Kto ma interes prawny w tym, aby sprawa została rozstrzygnięta na 
korzyść jednej ze stron, może w każdym stanie sprawy aż do zamknięcia rozprawy 
w drugiej instancji przystąpić do tej strony (interwencja uboczna).

***
## Art. 77. {#kpc-pierwsza-pierwsza-art-77}

**§ 1.** Interwenient uboczny składa oświadczenie o wstąpieniu do 
sprawy w piśmie procesowym, w którym wskazuje, jaki ma interes prawny we 
wstąpieniu i do której ze stron przystępuje. Pismo to doręcza się stronom. 
**§ 11.** Do pisma procesowego niespełniającego wymogów, o których mowa 
w § 1, przepis art. 130 stosuje się odpowiednio. 
**§ 2.** Interwenient uboczny może ze wstąpieniem do sprawy połączyć 
dokonanie innej czynności procesowej.

***
## Art. 78. {#kpc-pierwsza-pierwsza-art-78}

**§ 1.** Każda ze stron może zgłosić opozycję przeciwko wstąpieniu 
interwenienta ubocznego w terminie dwóch tygodni od dnia doręczenia jej pisma 
zawierającego oświadczenie o wstąpieniu, jednak nie później niż przy rozpoczęciu 
najbliższego posiedzenia z jej udziałem. 
**§ 2.** Sąd oddali opozycję, jeżeli interwenient uboczny uprawdopodobni, że ma 
interes prawny we wstąpieniu do sprawy. 
**§ 3.** Mimo wniesienia opozycji interwenient uboczny bierze udział w sprawie, 
dopóki orzeczenie uwzględniające opozycję nie stanie się prawomocne. W razie 
prawomocnego uwzględnienia opozycji czynności interwenienta ubocznego 
uważane będą za niebyłe.

***
## Art. 79. {#kpc-pierwsza-pierwsza-art-79}

Interwenient uboczny jest uprawniony do wszelkich czynności 
procesowych dopuszczalnych według stanu sprawy. Nie mogą one jednak 
pozostawać w sprzeczności z czynnościami i oświadczeniami strony, do której 
przystąpił.

***
## Art. 80. {#kpc-pierwsza-pierwsza-art-80}

Interwenientowi ubocznemu należy od chwili jego wstąpienia do 
sprawy doręczać, tak jak stronie, zawiadomienia o terminach i posiedzeniach 
sądowych, jako też orzeczenia sądu.

***
## Art. 81. {#kpc-pierwsza-pierwsza-art-81}

Jeżeli z istoty spornego stosunku prawnego lub z przepisu ustawy 
wynika, że wyrok w sprawie ma odnieść bezpośredni skutek prawny w stosunku 
między interwenientem a przeciwnikiem strony, do której interwenient przystąpił, 

 
 
 
s. 24/580 
 
2025-09-08 
 
do stanowiska interwenienta w procesie stosuje się odpowiednio przepisy 
o współuczestnictwie jednolitym.

***
## Art. 82. {#kpc-pierwsza-pierwsza-art-82}

Interwenient uboczny nie może w stosunku do strony, do której 
przystąpił, podnieść zarzutu, że sprawa została rozstrzygnięta błędnie albo że strona 
ta prowadziła proces wadliwie, chyba że stan sprawy w chwili przystąpienia 
interwenienta uniemożliwił mu korzystanie ze środków obrony albo że strona 
umyślnie lub przez niedbalstwo nie skorzystała ze środków, które nie były 
interwenientowi znane.

***
## Art. 83. {#kpc-pierwsza-pierwsza-art-83}

Za zgodą stron interwenient uboczny może wejść na miejsce strony, 
do której przystąpił. 
#### DZIAŁ IV
Przypozwanie

***
## Art. 84. {#kpc-pierwsza-pierwsza-art-84}

**§ 1.** Strona, której w razie niekorzystnego dla niej rozstrzygnięcia 
przysługiwałoby roszczenie względem osoby trzeciej albo przeciwko której osoba 
trzecia mogłaby wystąpić z roszczeniem, może zawiadomić taką osobę o toczącym 
się procesie i wezwać ją do wzięcia w nim udziału. 
**§ 2.** W tym celu strona wnosi do sądu pismo procesowe wskazujące 
przyczynę wezwania i stan sprawy. Pismo to doręcza się niezwłocznie osobie 
trzeciej, która może zgłosić swe przystąpienie do strony jako interwenient uboczny.

***
## Art. 85. {#kpc-pierwsza-pierwsza-art-85}

Skutki związane z interwencją uboczną określone w art. 82 powstają 
w stosunku do wezwanego, który nie zgłosił przystąpienia, z chwilą, w której 
przystąpienie było możliwe. 
#### DZIAŁ V
Pełnomocnicy procesowi

***
## Art. 86. {#kpc-pierwsza-pierwsza-art-86}

Strony i ich organy lub przedstawiciele ustawowi mogą działać przed 
sądem osobiście lub przez pełnomocników.

***
## Art. 87. {#kpc-pierwsza-pierwsza-art-87}

**§ 1.** Pełnomocnikiem może być adwokat lub radca prawny, 
w sprawach własności intelektualnej także rzecznik patentowy, a w sprawach 
restrukturyzacji 
i upadłości 
także 
osoba 
posiadająca 
licencję 
doradcy 
restrukturyzacyjnego, a ponadto osoba sprawująca zarząd majątkiem lub interesami 

 
 
 
s. 25/580 
 
2025-09-08 
 
strony oraz osoba pozostająca ze stroną w stałym stosunku zlecenia, jeżeli 
przedmiot sprawy wchodzi w zakres tego zlecenia, współuczestnik sporu, jak 
również małżonek, rodzeństwo, zstępni lub wstępni strony oraz osoby pozostające 
ze stroną w stosunku przysposobienia. 
**§ 2.** Pełnomocnikiem 
osoby 
prawnej 
lub 
przedsiębiorcy, 
w tym 
nieposiadającego osobowości prawnej, może być również pracownik tej jednostki 
albo jej organu nadrzędnego. Osoba prawna prowadząca, na podstawie odrębnych 
przepisów, obsługę prawną przedsiębiorcy, osoby prawnej lub innej jednostki 
organizacyjnej może udzielić pełnomocnictwa procesowego – w imieniu podmiotu, 
którego obsługę prawną prowadzi – adwokatowi lub radcy prawnemu, jeżeli została 
do tego upoważniona przez ten podmiot. 
**§ 3.** W sprawach 
o ustalenie 
i zaprzeczenie 
pochodzenia 
dziecka 
i o roszczenia alimentacyjne pełnomocnikiem może być również przedstawiciel 
właściwego w sprawach z zakresu pomocy społecznej organu jednostki samorządu 
terytorialnego oraz organizacji pozarządowej, mającej na celu udzielanie pomocy 
rodzinie. 
**§ 4.** W sprawach 
związanych 
z prowadzeniem 
gospodarstwa 
rolnego 
pełnomocnikiem rolnika może być również przedstawiciel organizacji zrzeszającej 
rolników indywidualnych, której rolnik jest członkiem. 
**§ 5.** W sprawach związanych z ochroną praw konsumentów pełnomocnikiem 
może być przedstawiciel organizacji, do której zadań statutowych należy ochrona 
konsumentów. 
**§ 6.** (uchylony)

***
## Art. 871. {#kpc-pierwsza-pierwsza-art-871}

**§ 1.** W postępowaniu przed Sądem Najwyższym obowiązuje 
zastępstwo stron przez adwokatów lub radców prawnych, a w sprawach własności 
intelektualnej także przez rzeczników patentowych. Zastępstwo to dotyczy także 
czynności procesowych związanych z postępowaniem przed Sądem Najwyższym, 
podejmowanych przed sądem niższej instancji. 
**§ 2.** Przepisu § 1 nie stosuje się w postępowaniu o zwolnienie od kosztów 
sądowych oraz o ustanowienie adwokata, radcy prawnego lub rzecznika 
patentowego oraz gdy stroną, jej organem, jej przedstawicielem ustawowym lub 
pełnomocnikiem jest sędzia, prokurator, notariusz albo profesor lub doktor 
habilitowany nauk prawnych, a także gdy stroną, jej organem lub jej 

 
 
 
s. 26/580 
 
2025-09-08 
 
przedstawicielem ustawowym jest adwokat, radca prawny lub radca Prokuratorii 
Generalnej Rzeczypospolitej Polskiej, a w sprawach własności intelektualnej 
rzecznik patentowy. 
**§ 3.** Przepisu § 1 nie stosuje się także wtedy, gdy zastępstwo procesowe 
Skarbu Państwa albo państwowej osoby prawnej jest wykonywane przez 
Prokuratorię Generalną Rzeczypospolitej Polskiej.

***
## Art. 872. {#kpc-pierwsza-pierwsza-art-872}

**§ 1.** W postępowaniu 
w sprawach 
własności 
intelektualnej 
obowiązuje zastępstwo stron przez adwokatów, radców prawnych lub rzeczników 
patentowych. Przepisy art. 871 § 2 i 3 stosuje się odpowiednio. 
**§ 2.** Przepisu § 1 nie stosuje się w postępowaniu, w którym wartość 
przedmiotu sporu nie przekracza dwudziestu tysięcy złotych. 
**§ 3.** Sąd może zwolnić stronę, na wniosek lub z urzędu, z obowiązkowego 
zastępstwa przez adwokata, radcę prawnego lub rzecznika patentowego, jeżeli 
okoliczności, w tym stopień zawiłości sprawy, nie uzasadniają obowiązkowego 
zastępstwa. Zwolnienie może nastąpić w każdym stanie sprawy, w tym także na 
wniosek strony złożony w piśmie procesowym. 
**§ 4.** W sprawach związanych z ochroną praw własności przemysłowej 
pełnomocnikiem twórcy projektu wynalazczego może być również przedstawiciel 
organizacji, do której zadań statutowych należą sprawy popierania własności 
przemysłowej i udzielania pomocy twórcom projektów wynalazczych.

***
## Art. 88. {#kpc-pierwsza-pierwsza-art-88}

**§ 1.** Pełnomocnictwo może być albo procesowe – bądź to ogólne, 
bądź do prowadzenia poszczególnych spraw – albo do niektórych tylko czynności 
procesowych. 
**§ 2.** Pełnomocnictwo do niektórych tylko czynności procesowych może 
obejmować wyłącznie upoważnienie do odbioru pism sądowych. Pełnomocnictwa 
takiego można udzielić każdej osobie fizycznej (pełnomocnik do doręczeń).

***
## Art. 89. {#kpc-pierwsza-pierwsza-art-89}

**§ 1.** Pełnomocnik jest obowiązany przy pierwszej czynności 
procesowej dołączyć do akt sprawy pełnomocnictwo z podpisem mocodawcy lub 
wierzytelny odpis pełnomocnictwa wraz z odpisem dla strony przeciwnej. 
Adwokat, radca prawny, rzecznik patentowy, a także radca Prokuratorii Generalnej 
Rzeczypospolitej Polskiej mogą sami uwierzytelnić odpis udzielonego im 
pełnomocnictwa oraz odpisy innych dokumentów wykazujących ich umocowanie. 

 
 
 
s. 27/580 
 
2025-09-08 
 
Złożenie dokumentu wykazującego umocowanie lub jego uwierzytelnionego 
odpisu nie jest wymagane, jeżeli stwierdzenie przez sąd umocowania jest możliwe 
na podstawie wykazu lub innego rejestru, do którego sąd ma dostęp drogą 
elektroniczną. 
[§ 11. Przepisu § 1 nie stosuje się do czynności procesowej dokonanej za 
pośrednictwem systemu teleinformatycznego, w przypadku gdy przepis szczególny 
przewiduje, że czynności można dokonać wyłącznie za pośrednictwem tego 
systemu. W takim przypadku pełnomocnik powołuje się na pełnomocnictwo, 
wskazując jego zakres oraz okoliczności wymienione w art. 87.] 
<§ 12. Pełnomocnictwo udzielone w postaci elektronicznej opatruje się 
kwalifikowanym podpisem elektronicznym, podpisem zaufanym albo 
podpisem osobistym.> 
**§ 2.** W toku sprawy pełnomocnictwo może być udzielone ustnie na 
posiedzeniu sądu przez oświadczenie złożone przez stronę i wciągnięte do 
protokołu. 
**§ 3.** (uchylony)

***
## Art. 90. {#kpc-pierwsza-pierwsza-art-90}

Za stronę, która nie może się podpisać, podpisuje pełnomocnictwo 
osoba przez nią upoważniona, z wymienieniem przyczyny, dla której strona sama 
się nie podpisała.

***
## Art. 91. {#kpc-pierwsza-pierwsza-art-91}

Pełnomocnictwo procesowe obejmuje z samego prawa umocowanie 
do: 
- 1) wszystkich łączących się ze sprawą czynności procesowych, nie wyłączając 
powództwa 
wzajemnego, 
skargi 
kasacyjnej, 
skargi 
o wznowienie 
postępowania i postępowania wywołanego ich wniesieniem, jak też 
wniesieniem interwencji głównej przeciwko mocodawcy; 
- 2) wszelkich czynności dotyczących zabezpieczenia i egzekucji; 
- 3) udzielenia dalszego pełnomocnictwa procesowego adwokatowi lub radcy 
prawnemu; 
- 4) zawarcia ugody, zrzeczenia się roszczenia albo uznania powództwa, jeżeli 
czynności te nie zostały wyłączone w danym pełnomocnictwie; 
- 5) odbioru kosztów procesu od strony przeciwnej. 
Przepis 
uchylający § 11 w 
art. 89 wejdzie w 
życie 
z 
dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1172). 
Dodany § 12 w 
art. 89 wejdzie w 
życie 
z 
dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 

 
 
 
s. 28/580 
 
2025-09-08

***
## Art. 92. {#kpc-pierwsza-pierwsza-art-92}

Zakres, 
czas 
trwania 
i skutki 
umocowania 
szerszego 
niż 
pełnomocnictwo procesowe, jak również umocowanie do poszczególnych 
czynności procesowych, ocenia się według treści pełnomocnictwa oraz przepisów 
prawa cywilnego.

***
## Art. 93. {#kpc-pierwsza-pierwsza-art-93}

Mocodawca stawający jednocześnie z pełnomocnikiem może 
niezwłocznie prostować lub odwoływać oświadczenia pełnomocnika.

***
## Art. 94. {#kpc-pierwsza-pierwsza-art-94}

**§ 1.** Wypowiedzenie 
pełnomocnictwa 
procesowego 
przez 
mocodawcę odnosi skutek prawny w stosunku do sądu z chwilą zawiadomienia go 
o tym, w stosunku zaś do przeciwnika i innych uczestników – z chwilą doręczenia 
im tego zawiadomienia przez sąd. 
**§ 2.** Adwokat lub radca prawny, który wypowiedział pełnomocnictwo, 
obowiązany jest działać za stronę jeszcze przez dwa tygodnie, chyba że mocodawca 
zwolni go od tego obowiązku. Każdy inny pełnomocnik powinien, mimo 
wypowiedzenia, działać za mocodawcę przez ten sam czas, jeżeli jest to konieczne 
do uchronienia mocodawcy od niekorzystnych skutków prawnych.

***
## Art. 95. {#kpc-pierwsza-pierwsza-art-95}

Przepis artykułu poprzedzającego stosuje się odpowiednio do 
adwokata lub radcy prawnego ustanowionego przez sąd w przypadku zwolnienia 
go od obowiązku zastępowania strony w procesie.

***
## Art. 96. {#kpc-pierwsza-pierwsza-art-96}

W razie śmierci strony albo utraty przez nią zdolności sądowej 
pełnomocnictwo wygasa. Jednakże pełnomocnik procesowy działa aż do czasu 
zawieszenia postępowania.

***
## Art. 97. {#kpc-pierwsza-pierwsza-art-97}

**§ 1.** Po wniesieniu pozwu sąd może dopuścić tymczasowo do 
podjęcia naglącej czynności procesowej osobę niemogącą na razie przedstawić 
pełnomocnictwa. Zarządzenie to sąd może uzależnić od zabezpieczenia kosztów. 
**§ 2.** Sąd wyznaczy równocześnie termin, w ciągu którego osoba działająca 
bez pełnomocnictwa powinna je złożyć albo przedstawić zatwierdzenie swej 
czynności przez stronę. Jeżeli termin upłynął bezskutecznie, sąd pominie czynności 
procesowe tej osoby. W tym wypadku przeciwnik może żądać od działającego bez 
umocowania zwrotu kosztów spowodowanych jego tymczasowym dopuszczeniem. 

 
 
 
s. 29/580 
 
2025-09-08 
### TYTUŁ V
Koszty procesu 
#### DZIAŁ I
Zwrot kosztów procesu

***
## Art. 98. {#kpc-pierwsza-pierwsza-art-98}

**§ 1.** Strona przegrywająca sprawę obowiązana jest zwrócić 
przeciwnikowi na jego żądanie koszty niezbędne do celowego dochodzenia praw 
i celowej obrony (koszty procesu). 
**§ 11.** Od kwoty zasądzonej tytułem zwrotu kosztów procesu należą się 
odsetki, w wysokości odsetek ustawowych za opóźnienie w spełnieniu świadczenia 
pieniężnego, za czas od dnia uprawomocnienia się orzeczenia, którym je 
zasądzono, do dnia zapłaty. Jeżeli orzeczenie to jest prawomocne z chwilą wydania, 
odsetki należą się za czas po upływie tygodnia od dnia jego ogłoszenia do dnia 
zapłaty, a jeżeli orzeczenie takie podlega doręczeniu z urzędu – za czas po upływie 
tygodnia od dnia jego doręczenia zobowiązanemu do dnia zapłaty. O obowiązku 
zapłaty odsetek sąd orzeka z urzędu. 
**§ 12.** W szczególnie uzasadnionym przypadku, na wniosek strony, która 
w toku procesu poniosła szczególnie wysoki wydatek podlegający zwrotowi, sąd 
może przyznać jej odsetki przewidziane w § 11 od kwoty równej temu wydatkowi 
za czas od dnia jego poniesienia przez stronę do dnia zapłaty. 
**§ 2.** Do niezbędnych kosztów procesu prowadzonego przez stronę osobiście 
lub przez pełnomocnika, który nie jest adwokatem, radcą prawnym lub rzecznikiem 
patentowym, zalicza się poniesione przez nią koszty sądowe, koszty przejazdów do 
sądu strony lub jej pełnomocnika oraz równowartość zarobku utraconego wskutek 
stawiennictwa w sądzie. Równowartość utraconego zarobku nie może przekraczać 
wynagrodzenia jednego adwokata wykonującego zawód w siedzibie sądu 
prowadzącego postępowanie. 
**§ 3.** Do niezbędnych kosztów procesu strony reprezentowanej przez adwokata 
zalicza się wynagrodzenie, jednak nie wyższe niż stawki opłat określone 
w odrębnych przepisach i wydatki jednego adwokata, koszty sądowe oraz koszty 
nakazanego przez sąd osobistego stawiennictwa strony. 

 
 
 
s. 30/580 
 
2025-09-08 
**§ 4.** Wysokość kosztów sądowych, zasady zwrotu utraconego zarobku lub 
dochodu oraz kosztów stawiennictwa strony w sądzie, a także wynagrodzenie 
adwokata, radcy prawnego i rzecznika patentowego regulują odrębne przepisy.

***
## Art. 981. {#kpc-pierwsza-pierwsza-art-981}

**§ 1.** Do niezbędnych kosztów procesu zalicza się koszty mediacji 
prowadzonej na skutek skierowania przez sąd, jednak w kwocie nie wyższej niż 
suma przysługującego mediatorowi wynagrodzenia i wydatków podlegających 
zwrotowi związanych z prowadzeniem mediacji określonych w przepisach 
wydanych na podstawie § 4. 
**§ 2.** Jeżeli postępowanie cywilne zostało wszczęte w ciągu trzech miesięcy od 
dnia zakończenia mediacji, która nie została zakończona ugodą albo w ciągu trzech 
miesięcy od dnia uprawomocnienia się postanowienia o odmowie zatwierdzenia 
ugody przez sąd, do niezbędnych kosztów procesu zalicza się także koszty mediacji 
w wysokości nieprzekraczającej czwartej części opłaty. 
**§ 3.** Do określenia kosztów mediacji stosuje się odpowiednio art. 98 § 2 i 3. 
**§ 4.** Minister Sprawiedliwości określi, w drodze rozporządzenia, wysokość 
wynagrodzenia mediatora, w tym stałego mediatora, za prowadzenie postępowania 
mediacyjnego wszczętego na podstawie skierowania sądu i wydatki mediatora, 
w tym stałego mediatora, podlegające zwrotowi, biorąc pod uwagę rodzaj sprawy 
i wartość przedmiotu sporu oraz sprawny przebieg postępowania mediacyjnego, 
a także niezbędne wydatki związane z prowadzeniem mediacji.

***
## Art. 99. {#kpc-pierwsza-pierwsza-art-99}

Stronom reprezentowanym przez radcę prawnego, rzecznika 
patentowego lub Prokuratorię Generalną Rzeczypospolitej Polskiej zwraca się 
koszty w wysokości należnej według przepisów o wynagrodzeniu adwokata.

***
## Art. 100. {#kpc-pierwsza-pierwsza-art-100}

W razie częściowego tylko uwzględnienia żądań koszty będą 
wzajemnie zniesione lub stosunkowo rozdzielone. Sąd może jednak włożyć na 
jedną ze stron obowiązek zwrotu wszystkich kosztów, jeżeli jej przeciwnik uległ 
tylko co do nieznacznej części swego żądania albo gdy określenie należnej mu 
sumy zależało od wzajemnego obrachunku lub oceny sądu.

***
## Art. 101. {#kpc-pierwsza-pierwsza-art-101}

Zwrot kosztów należy się pozwanemu pomimo uwzględnienia 
powództwa, jeżeli nie dał powodu do wytoczenia sprawy i uznał przy pierwszej 
czynności procesowej żądanie pozwu. 

 
 
 
s. 31/580 
 
2025-09-08

***
## Art. 102. {#kpc-pierwsza-pierwsza-art-102}

W wypadkach szczególnie uzasadnionych sąd może zasądzić od 
strony przegrywającej tylko część kosztów albo nie obciążać jej w ogóle kosztami.

***
## Art. 103. {#kpc-pierwsza-pierwsza-art-103}

**§ 1.** Niezależnie od wyniku sprawy sąd może włożyć na stronę lub 
interwenienta obowiązek zwrotu kosztów, wywołanych ich niesumiennym lub 
oczywiście niewłaściwym postępowaniem. 
**§ 2.** Przepis § 1 dotyczy zwłaszcza kosztów powstałych wskutek uchylenia 
się od wyjaśnień lub złożenia wyjaśnień niezgodnych z prawdą, zatajenia lub 
opóźnionego powołania dowodów [, a także oczywiście nieuzasadnionej odmowy 
poddania się mediacji]. 
**§ 3.** Jeżeli strona: 
- 1) pomimo wezwania do osobistego stawiennictwa nie stawiła się w celu udziału 
w czynności sądu i nie usprawiedliwiła swego niestawiennictwa, 
<11) bez uzasadnionej przyczyny odmówiła poddania się mediacji,> 
- 2) w toku postępowania bez usprawiedliwienia nie stawiła się na posiedzenie 
mediacyjne pomimo wcześniejszego wyrażenia zgody na mediację 
– sąd może, niezależnie od wyniku sprawy, włożyć na tę stronę obowiązek zwrotu 
kosztów w części wyższej, niż nakazywałby to wynik sprawy, a nawet zwrotu 
kosztów w całości. 
**§ 4.** O możliwości tej sąd poucza strony przy wezwaniu do osobistego 
stawiennictwa lub przy skierowaniu stron do mediacji.

***
## Art. 104. {#kpc-pierwsza-pierwsza-art-104}

Koszty procesu, w którym zawarto ugodę, znosi się wzajemnie, 
jeżeli strony nie postanowiły inaczej.

***
## Art. 1041. {#kpc-pierwsza-pierwsza-art-1041}

Koszty mediacji prowadzonej na skutek skierowania przez sąd 
i zakończonej ugodą znosi się wzajemnie, jeżeli strony nie postanowiły inaczej.

***
## Art. 105. {#kpc-pierwsza-pierwsza-art-105}

**§ 1.** Współuczestnicy sporu zwracają koszty procesu w częściach 
równych. Sąd może jednak nakazać zwrot kosztów odpowiednio do udziału 
każdego ze współuczestników w sprawie, jeżeli pod tym względem zachodzą 
znaczne różnice. 
**§ 2.** Na współuczestników sporu odpowiadających solidarnie co do istoty 
sprawy sąd włoży solidarny obowiązek zwrotu kosztów. Za koszty wynikłe 
z czynności procesowych, podjętych przez poszczególnych współuczestników 
wyłącznie we własnym interesie, inni współuczestnicy nie odpowiadają. 
Zmiana 
(skreślenie 
wyrazów) w § 2 w 
art. 103 wejdzie 
w życie z dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 
Dodany pkt 11 w 
§ 3 w art. 103 
wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 

 
 
 
s. 32/580 
 
2025-09-08

***
## Art. 106. {#kpc-pierwsza-pierwsza-art-106}

Udział prokuratora w sprawie nie uzasadnia zasądzenia zwrotu 
kosztów na rzecz Skarbu Państwa ani od Skarbu Państwa.

***
## Art. 107. {#kpc-pierwsza-pierwsza-art-107}

Interwenient uboczny, do którego nie mają zastosowania przepisy 
o współuczestnictwie jednolitym, nie zwraca kosztów przeciwnikowi strony, do 
której przystąpił. Sąd może jednak przyznać od interwenienta na rzecz 
wygrywającego sprawę przeciwnika strony, do której interwenient przystąpił, 
zwrot 
kosztów 
wywołanych 
samoistnymi 
czynnościami 
procesowymi 
interwenienta. Sąd może także przyznać interwenientowi koszty interwencji od 
przeciwnika obowiązanego do zwrotu kosztów.

***
## Art. 108. {#kpc-pierwsza-pierwsza-art-108}

**§ 1.** Sąd rozstrzyga o kosztach w każdym orzeczeniu kończącym 
sprawę w instancji. Sąd może jednak rozstrzygnąć jedynie o zasadach poniesienia 
przez strony kosztów procesu, pozostawiając szczegółowe wyliczenie referen-
darzowi sądowemu; w tej sytuacji, po uprawomocnieniu się orzeczenia kończącego 
postępowanie w sprawie, referendarz sądowy w sądzie pierwszej instancji wydaje 
postanowienie, w którym dokonuje szczegółowego wyliczenia kosztów obciąża-
jących strony. 
**§ 2.** Sąd drugiej instancji, uchylając zaskarżone orzeczenie i przekazując 
sprawę sądowi pierwszej instancji do rozpoznania, pozostawia temu sądowi 
rozstrzygnięcie o kosztach instancji odwoławczej.

***
## Art. 1081. {#kpc-pierwsza-pierwsza-art-1081}

Jeżeli w toku postępowania sąd nie orzekł o obowiązku poniesienia 
kosztów sądowych lub orzeczeniem nie objął całej kwoty należnej z tego tytułu, 
postanowienie w tym przedmiocie wydaje sąd, przed którym sprawa toczyła się 
w pierwszej instancji.

***
## Art. 109. {#kpc-pierwsza-pierwsza-art-109}

**§ 1.** Roszczenie o zwrot kosztów wygasa, jeśli strona najpóźniej 
przed zamknięciem rozprawy bezpośrednio poprzedzającej wydanie orzeczenia nie 
złoży sądowi spisu kosztów albo nie zgłosi wniosku o przyznanie kosztów według 
norm przepisanych. Jednakże o kosztach należnych stronie działającej bez 
adwokata, radcy prawnego lub rzecznika patentowego sąd orzeka z urzędu. 
**§ 2.** Orzekając o wysokości przyznanych stronie kosztów procesu, sąd bierze 
pod uwagę celowość poniesionych kosztów oraz niezbędność ich poniesienia 
z uwagi na charakter sprawy. Przy ustalaniu wysokości kosztów poniesionych 
przez stronę reprezentowaną przez pełnomocnika będącego adwokatem, radcą 

 
 
 
s. 33/580 
 
2025-09-08 
 
prawnym lub rzecznikiem patentowym, sąd bierze pod uwagę niezbędny nakład 
pracy pełnomocnika oraz czynności podjęte przez niego w sprawie, w tym 
czynności podjęte w celu polubownego rozwiązania sporu, również przed 
wniesieniem 
pozwu, 
a także 
charakter 
sprawy 
i wkład 
pełnomocnika 
w przyczynienie się do jej wyjaśnienia i rozstrzygnięcia.

***
## Art. 110. {#kpc-pierwsza-pierwsza-art-110}

Sąd może zasądzić od świadka, biegłego, pełnomocnika lub 
przedstawiciela ustawowego – po ich wysłuchaniu – zwrot kosztów wywołanych 
ich rażącą winą. 
#### DZIAŁ II
Pomoc prawna z urzędu

***
## Art. 111. {#kpc-pierwsza-pierwsza-art-111}

(uchylony)

***
## Art. 112. {#kpc-pierwsza-pierwsza-art-112}

(uchylony)

***
## Art. 113. {#kpc-pierwsza-pierwsza-art-113}

(uchylony)

***
## Art. 114. {#kpc-pierwsza-pierwsza-art-114}

(uchylony)

***
## Art. 115. {#kpc-pierwsza-pierwsza-art-115}

(uchylony)

***
## Art. 116. {#kpc-pierwsza-pierwsza-art-116}

(uchylony)

***
## Art. 117. {#kpc-pierwsza-pierwsza-art-117}

**§ 1.** Strona zwolniona przez sąd od kosztów sądowych w całości lub 
części, może domagać się ustanowienia adwokata lub radcy prawnego. 
**§ 2.** Osoba fizyczna, niezwolniona przez sąd od kosztów sądowych, może się 
domagać ustanowienia adwokata lub radcy prawnego, jeżeli złoży oświadczenie, 
z którego wynika, że nie jest w stanie ponieść kosztów wynagrodzenia adwokata 
lub radcy prawnego bez uszczerbku utrzymania koniecznego dla siebie i rodziny. 
**§ 3.** Osoba prawna lub inna jednostka organizacyjna, której ustawa przyznaje 
zdolność sądową, niezwolniona przez sąd od kosztów sądowych, może się domagać 
ustanowienia adwokata lub radcy prawnego, jeżeli wykaże, że nie ma 
dostatecznych środków na poniesienie kosztów wynagrodzenia adwokata lub radcy 
prawnego. 
**§ 4.** Wniosek o ustanowienie adwokata lub radcy prawnego strona zgłasza 
wraz z wnioskiem o zwolnienie od kosztów sądowych lub osobno, na piśmie lub 
ustnie do protokołu, w sądzie, w którym sprawa ma być wytoczona lub już się 

 
 
 
s. 34/580 
 
2025-09-08 
 
toczy. Osoba fizyczna, która nie ma miejsca zamieszkania w siedzibie tego sądu, 
może złożyć wniosek o ustanowienie adwokata lub radcy prawnego w sądzie 
rejonowym właściwym ze względu na miejsce swego zamieszkania, który 
niezwłocznie przesyła ten wniosek sądowi właściwemu. 
**§ 5.** Sąd uwzględni wniosek, jeżeli udział adwokata lub radcy prawnego 
w sprawie uzna za potrzebny. Podstawą oddalenia wniosku nie może być 
skorzystanie przez osobę fizyczną z nieodpłatnej pomocy prawnej lub 
nieodpłatnego poradnictwa obywatelskiego, o których mowa w ustawie z dnia 
5 sierpnia 2015 r. o nieodpłatnej pomocy prawnej, nieodpłatnym poradnictwie 
obywatelskim oraz edukacji prawnej (Dz. U. z 2021 r. poz. 945 oraz z 2024 r. poz. 
928). 
**§ 51.** Prokurator, w terminie 14 dni od dnia wydania postanowienia 
o przedstawieniu zarzutów popełnienia przestępstwa przeciwko bezpieczeństwu 
w komunikacji w ruchu lądowym określonego w przepisach rozdziału XXI ustawy 
z dnia 6 czerwca 1997 r. – Kodeks karny, którego następstwem jest śmierć 
człowieka albo ciężki uszczerbek na zdrowiu, lub zarzutów popełnienia z użyciem 
pojazdu mechanicznego w ruchu lądowym przestępstwa zabójstwa lub umyślnego 
spowodowania ciężkiego uszczerbku na zdrowiu: 
- 1) składa wniosek o ustanowienie pełnomocnika, będącego adwokatem lub 
radcą prawnym, do wytoczenia powództwa o rentę przez osoby do tego 
uprawnione, o których mowa w art. 444 § 2 oraz art. 446 § 2 ustawy z dnia 
23 kwietnia 1964 r. – Kodeks cywilny (Dz. U. z 2024 r. poz. 1061 i 1237), 
jeżeli osoba uprawniona ze względu na wiek, stan zdrowia lub stan majątkowy 
nie jest w stanie samodzielnie dochodzić swoich roszczeń lub dochodzenie 
przez nią tych roszczeń byłoby znacznie utrudnione, a nie ustanowiła 
będącego adwokatem lub radcą prawnym pełnomocnika z wyboru i nie 
zachodzi wysokie prawdopodobieństwo istotnego przyczynienia się 
poszkodowanego lub osoby uprawnionej do zdarzenia, którego dotyczy 
przedstawiony zarzut; 
- 2) może złożyć wniosek, o którym mowa w pkt 1, w przypadku gdy szczególne 
okoliczności odnoszące się do osoby uprawnionej, inne niż wskazane w pkt 1, 
uzasadniają konieczność ochrony jej interesów. 

 
 
 
s. 35/580 
 
2025-09-08 
**§ 52.** Przepis § 51 stosuje się odpowiednio, jeżeli wydanie postanowienia 
o przedstawieniu zarzutów popełnienia przestępstwa, o którym mowa w tym 
przepisie, nie jest możliwe z uwagi na stan zdrowia sprawcy lub z powodów, 
o których mowa w art. 17 § 1 pkt 5, 6, 8 lub 11 ustawy z dnia 6 czerwca 1997 r. – 
Kodeks postępowania karnego (Dz. U. z 2024 r. poz. 37, 1222 i 1248). 
**§ 53.** We wniosku, o którym mowa w § 51, należy określić osobę, na rzecz 
której ma zostać ustanowiony pełnomocnik, oraz wskazać okoliczności 
uzasadniające ustanowienie pełnomocnika i wytoczenie powództwa na podstawie 
art. 444 § 2 lub art. 446 § 2 ustawy z dnia 23 kwietnia 1964 r. – Kodeks cywilny. 
**§ 54.** Sąd uwzględnia wniosek prokuratora, o którym mowa w § 51. 
Pełnomocnictwo udzielone w tym trybie obejmuje umocowanie jedynie do żądania 
udzielenia zabezpieczenia w formie miesięcznego świadczenia na zapewnienie 
środków utrzymania, o którym mowa w art. 7533 § 1, oraz wytoczenia powództwa, 
na podstawie art. 444 § 2 lub art. 446 § 2 ustawy z dnia 23 kwietnia 1964 r. – 
Kodeks cywilny na rzecz osoby uprawnionej i uczestnictwa w postępowaniach 
zainicjowanych żądaniem i powództwem. Ten sam pełnomocnik może być 
umocowany dla więcej niż jednego uprawnionego. 
**§ 6.** Wniosek o ustanowienie adwokata lub radcy prawnego zgłoszony po raz 
pierwszy w postępowaniu kasacyjnym lub postępowaniu ze skargi o stwierdzenie 
niezgodności z prawem prawomocnego orzeczenia sąd przekazuje do rozpoznania 
sądowi pierwszej instancji, chyba że uzna wniosek za oczywiście uzasadniony.

***
## Art. 1171. {#kpc-pierwsza-pierwsza-art-1171}

**§ 1.** Osoba fizyczna dołącza do wniosku o ustanowienie adwokata 
lub radcy prawnego oświadczenie obejmujące szczegółowe dane o swoim stanie 
rodzinnym, majątku, dochodach i źródłach utrzymania. Oświadczenie sporządza 
się według ustalonego wzoru. Jeżeli wniosek o ustanowienie adwokata lub radcy 
prawnego składany jest łącznie z wnioskiem o zwolnienie od kosztów sądowych, 
osoba fizyczna dołącza tylko jedno oświadczenie. 
**§ 2.** Sąd może odebrać od osoby fizycznej przyrzeczenie o treści: „Świadomy 
znaczenia mych słów i odpowiedzialności przed prawem zapewniam, że złożone 
przeze mnie oświadczenie o stanie rodzinnym, majątku, dochodach i źródłach 
utrzymania jest prawdziwe i rzetelne”. Przed odebraniem przyrzeczenia poucza się 
stronę ubiegającą się o ustanowienie adwokata lub radcy prawnego o treści 
art. 120 § 4. 

 
 
 
s. 36/580 
 
2025-09-08 
**§ 3.** Wniosek o ustanowienie adwokata lub radcy prawnego złożony przez 
stronę reprezentowaną przez adwokata lub radcę prawnego bez dołączenia 
oświadczenia, o którym mowa w § 1, przewodniczący zwraca bez wzywania do 
uzupełnienia braków. 
**§ 4.** W razie złożenia wniosku ustnie do protokołu, oświadczenie, o którym 
mowa w § 1, może być złożone także do protokołu. 
**§ 5.** Przepisów § 1–4 nie stosuje się, jeżeli wniosek składa strona, o której 
mowa w art. 117 § 1. 
**§ 6.** Minister Sprawiedliwości określi, w drodze rozporządzenia, wzór 
oświadczenia o stanie rodzinnym, majątku, dochodach i źródłach utrzymania, 
o którym mowa w § 1, a także sposób udostępniania osobom fizycznym wzoru 
druków tych oświadczeń, mając na względzie umożliwienie stronie złożenia 
jednego oświadczenia w razie składania wniosku o ustanowienie adwokata lub 
radcy prawnego wraz z wnioskiem o zwolnienie od kosztów sądowych 
i komunikatywność niezbędnych pouczeń dla stron co do sposobu wypełnienia, 
skutków niezłożenia oraz złożenia nieprawdziwego oświadczenia.

***
## Art. 1172. {#kpc-pierwsza-pierwsza-art-1172}

**§ 1.** W razie oddalenia wniosku o ustanowienie adwokata lub radcy 
prawnego strona nie może ponownie domagać się ustanowienia adwokata lub radcy 
prawnego, powołując się na te same okoliczności, które stanowiły uzasadnie-
nie oddalonego wniosku. 
**§ 2.** Ponowny wniosek, o którym mowa w § 1, jest niedopuszczalny 
i pozostawia się go w aktach sprawy bez żadnych dalszych czynności. To samo 
dotyczy pism związanych z jego wniesieniem. O pozostawieniu wniosku i pism 
związanych z jego wniesieniem zawiadamia się stronę wnoszącą tylko raz – przy 
złożeniu pierwszego pisma.

***
## Art. 1173. {#kpc-pierwsza-pierwsza-art-1173}

**§ 1.** O wyznaczenie adwokata lub radcy prawnego sąd zwraca się 
do właściwej okręgowej rady adwokackiej lub rady okręgowej izby radców 
prawnych. 
**§ 2.** Właściwa okręgowa rada adwokacka lub rada okręgowej izby radców 
prawnych, wyznacza adwokata lub radcę prawnego niezwłocznie, nie później 
jednak niż w terminie dwóch tygodni, zawiadamiając o tym sąd. [W zawiadomieniu 
właściwa okręgowa rada adwokacka lub rada okręgowej izby radców prawnych 
Nowe brzmienie 
zd. drugiego w  
§ 2 oraz dodany  
§ 4 w art. 1173 
wejdą w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 

 
 
 
s. 37/580 
 
2025-09-08 
 
wskazuje imię i nazwisko wyznaczonego adwokata lub radcy prawnego oraz jego 
adres do doręczeń.]  <W zawiadomieniu właściwa okręgowa rada adwokacka 
lub rada okręgowej izby radców prawnych wskazuje imię, nazwisko oraz 
numer wpisu na właściwą listę wyznaczonego adwokata lub radcy prawnego, 
jego adres do doręczeń oraz sprawę, w której został wyznaczony.> 
**§ 3.** Jeżeli strona we wniosku wskazała adwokata lub radcę prawnego, 
właściwa okręgowa rada adwokacka lub rada okręgowej izby radców prawnych, 
w miarę możliwości i w porozumieniu ze wskazanym adwokatem lub radcą 
prawnym, wyznaczy adwokata lub radcę prawnego wskazanego przez stronę. 
<§ 4. W sprawach, w których jest to możliwe, korespondencja między 
sądem a właściwą okręgową radą adwokacką lub radą okręgowej izby radców 
prawnych odbywa się za pośrednictwem portalu informacyjnego. Przepisy 
art. 1311a § 1 i 2 stosuje się odpowiednio.>

***
## Art. 118. {#kpc-pierwsza-pierwsza-art-118}

**§ 1.** Ustanowienie adwokata lub radcy prawnego przez sąd jest 
równoznaczne z udzieleniem pełnomocnictwa procesowego. 
**§ 2.** Adwokat lub radca prawny ustanowiony przez sąd jest obowiązany 
zastępować stronę w zakresie wynikającym z art. 91, chyba że z postanowienia 
sądu wynika, iż obowiązek zastępowania strony ustaje wcześniej. 
**§ 3.** Z ważnych przyczyn adwokat lub radca prawny może wnosić 
o zwolnienie od obowiązku zastępowania strony w procesie. Sąd, zwalniając 
adwokata lub radcę prawnego, zwraca się jednocześnie do właściwej okręgowej 
rady adwokackiej lub rady okręgowej izby radców prawnych o wyznaczenie innego 
adwokata lub radcy prawnego. Przepis art. 1173 § 2 stosuje się odpowiednio. 
**§ 4.** Jeżeli adwokat lub radca prawny ustanowiony przez sąd ma podjąć 
czynności poza siedzibą sądu orzekającego, sąd, na uzasadniony wniosek 
ustanowionego adwokata lub radcy prawnego, zwróci się w razie potrzeby do 
właściwej okręgowej rady adwokackiej lub rady okręgowej izby radców prawnych 
o wyznaczenie adwokata lub radcy prawnego z innej miejscowości. Przepis 
art. 1173 § 2 stosuje się odpowiednio. 
**§ 5.** Jeżeli adwokat lub radca prawny ustanowiony przez sąd lub w związku 
z postępowaniem ze skargi o stwierdzenie niezgodności z prawem prawomocnego 
orzeczenia, nie stwierdza podstaw do wniesienia tej skargi lub skargi kasacyjnej, 
jest obowiązany niezwłocznie zawiadomić na piśmie o tym stronę oraz sąd, nie 

 
 
 
s. 38/580 
 
2025-09-08 
 
później niż w terminie dwóch tygodni od dnia doręczenia orzeczenia 
z uzasadnieniem albo zawiadomienia go o wyznaczeniu. Do zawiadomienia 
adwokat lub radca prawny dołącza sporządzoną przez siebie opinię o braku 
podstaw do wniesienia skargi. Opinia nie jest załączana do akt sprawy i nie jest 
doręczana stronie przeciwnej. 
**§ 6.** Jeżeli opinia, o której mowa w § 5, nie została sporządzona 
z zachowaniem zasad należytej staranności, sąd zawiadamia o tym właściwy organ 
samorządu zawodowego, do którego należy adwokat lub radca prawny. W takim 
przypadku właściwa okręgowa rada adwokacka lub rada okręgowej izby radców 
prawnych 
wyznaczy 
innego 
adwokata 
lub 
radcę 
prawnego. 
Przepis 
art. 1173 § 2 stosuje się odpowiednio.

***
## Art. 119. {#kpc-pierwsza-pierwsza-art-119}

Ustanowienie adwokata lub radcy prawnego wygasa ze śmiercią 
strony, która je uzyskała. Jednakże na zasadzie tego ustanowienia adwokat lub 
radca prawny strony podejmuje czynności niecierpiące zwłoki.

***
## Art. 1191. {#kpc-pierwsza-pierwsza-art-1191}

Sąd może zarządzić stosowne dochodzenie, jeżeli na podstawie 
okoliczności sprawy lub oświadczeń strony przeciwnej powziął wątpliwości co do 
rzeczywistego stanu majątkowego strony domagającej się ustanowienia lub 
zastępowanej przez ustanowionego adwokata lub radcę prawnego.

***
## Art. 120. {#kpc-pierwsza-pierwsza-art-120}

**§ 1.** Sąd cofnie ustanowienie adwokata lub radcy prawnego, jeżeli 
okaże się, że okoliczności, na których podstawie je przyznano, nie istniały lub 
przestały istnieć. 
**§ 2.** W wypadkach, o których mowa w § 1, strona obowiązana jest uiścić 
wynagrodzenie adwokata lub radcy prawnego dla niej ustanowionego. 
**§ 3.** Ponadto, w wypadku gdy okoliczności, na podstawie których przyznano 
ustanowienie adwokata lub radcy prawnego, przestały istnieć, sąd może obciążyć 
stronę tym obowiązkiem tylko częściowo, stosownie do zmiany, jaka nastąpiła 
w jej stosunkach. 
**§ 4.** Stronę, która uzyskała ustanowienie adwokata lub radcy prawnego na 
podstawie podania świadomie nieprawdziwych okoliczności, sąd skaże na 
grzywnę, niezależnie od jej obowiązku uiszczenia wynagrodzenia adwokata lub 
radcy prawnego.

***
## Art. 121. {#kpc-pierwsza-pierwsza-art-121}

(uchylony) 

 
 
 
s. 39/580 
 
2025-09-08

***
## Art. 122. {#kpc-pierwsza-pierwsza-art-122}

**§ 1.** Adwokat lub radca prawny ustanowiony zgodnie z przepisami 
niniejszego działu ma prawo – z wyłączeniem strony – ściągnąć sumę należną mu 
tytułem wynagrodzenia i zwrotu wydatków z kosztów zasądzonych na rzecz tej 
strony od przeciwnika. Przeciwnik nie może czynić żadnych potrąceń, z wyjątkiem 
kosztów nawzajem mu przyznanych od strony korzystającej z pomocy prawnej 
z urzędu. 
**§ 2.** Na kosztach, przypadających od przeciwnika strony korzystającej 
z pomocy prawnej z urzędu, należności adwokata lub radcy prawnego 
ustanowionego według przepisów poprzedzających przysługuje pierwszeństwo 
przed roszczeniami osób trzecich.

***
## Art. 123. {#kpc-pierwsza-pierwsza-art-123}

**§ 1.** Postanowienia, o których mowa w niniejszym dziale, doręcza 
się tylko stronie, która złożyła wniosek o ustanowienie dla niej adwokata lub radcy 
prawnego. 
**§ 2.** Postanowienie o ustanowieniu albo odmowie ustanowienia adwokata lub 
radcy prawnego może wydać także referendarz sądowy.

***
## Art. 124. {#kpc-pierwsza-pierwsza-art-124}

**§ 1.** Zgłoszenie wniosku o ustanowienie adwokata lub radcy 
prawnego, jak również wniesienie środka odwoławczego od odmowy ich 
ustanowienia nie wstrzymuje biegu toczącego się postępowania, chyba że chodzi o 
ustanowienie adwokata lub radcy prawnego dla powoda na skutek wniosku 
zgłoszonego w pozwie lub przed wytoczeniem powództwa. Sąd może jednak 
wstrzymać rozpoznanie sprawy aż do prawomocnego rozstrzygnięcia wniosku 
i w związku z tym nie wyznaczać rozprawy, a wyznaczoną rozprawę odwołać lub 
odroczyć. 
**§ 2.** W razie ustanowienia adwokata lub radcy prawnego na wniosek 
zgłoszony przed upływem terminu do wniesienia zażalenia, dla którego 
sporządzenia ustawa wymaga zastępstwa prawnego przez adwokata lub radcę 
prawnego, sąd doręcza ustanowionemu adwokatowi lub radcy prawnemu odpis 
postanowienia z urzędu, a termin do wniesienia zażalenia na postanowienie biegnie 
od dnia jego doręczenia pełnomocnikowi. Jeżeli strona prawidłowo zażądała 
doręczenia postanowienia z uzasadnieniem, odpis postanowienia doręcza się 
pełnomocnikowi z uzasadnieniem. 

 
 
 
s. 40/580 
 
2025-09-08 
**§ 3.** W razie ustanowienia adwokata lub radcy prawnego na wniosek 
zgłoszony przed upływem terminu do wniesienia skargi kasacyjnej przez stronę, 
która prawidłowo zażądała doręczenia orzeczenia z uzasadnieniem, sąd doręcza 
ustanowionemu adwokatowi lub radcy prawnemu orzeczenie z uzasadnieniem 
z urzędu, a termin do wniesienia skargi kasacyjnej biegnie od dnia doręczenia 
pełnomocnikowi orzeczenia z uzasadnieniem. 
**§ 4.** W razie oddalenia wniosku o ustanowienie adwokata lub radcy 
prawnego, zgłoszonego w przypadkach, o których mowa w § 2 lub § 3, termin do 
wniesienia środka zaskarżenia biegnie od dnia doręczenia stronie postanowienia, 
a jeżeli postanowienie zostało wydane na posiedzeniu jawnym – od dnia jego 
ogłoszenia. Jeżeli jednak strona wniosła zażalenie w przepisanym terminie, termin 
do złożenia środka zaskarżenia biegnie od dnia doręczenia stronie postanowienia 
oddalającego zażalenie, a jeżeli postanowienie sądu drugiej instancji zostało 
wydane na posiedzeniu jawnym – od dnia jego ogłoszenia. 
**§ 5.** Ponowny wniosek o ustanowienie adwokata lub radcy prawnego, oparty 
na tych samych okolicznościach, nie ma wpływu na bieg terminu do wniesienia 
środka zaskarżenia. 
### TYTUŁ VI
Postępowanie 
#### DZIAŁ I
Przepisy ogólne o czynnościach procesowych 
Rozdział 1 
Pisma procesowe

***
## Art. 125. {#kpc-pierwsza-pierwsza-art-125}

**§ 1.** Pisma procesowe obejmują wnioski i oświadczenia stron 
składane poza rozprawą. 
**§ 2.** Jeżeli przepis szczególny tak stanowi, pisma procesowe wnosi się na 
urzędowych formularzach. 
**§ 21.** Jeżeli przepis szczególny tak stanowi albo dokonano wyboru wnoszenia 
pism procesowych za pośrednictwem systemu teleinformatycznego, pisma 
procesowe w tej sprawie wnosi się wyłącznie za pośrednictwem systemu 
teleinformatycznego. 
Pisma 
niewniesione 
za 
pośrednictwem 
systemu 

 
 
 
s. 41/580 
 
2025-09-08 
 
teleinformatycznego nie wywołują skutków prawnych, jakie ustawa wiąże 
z wniesieniem pisma do sądu, o czym sąd poucza wnoszącego pismo. 
**§ 21a.** Dokonanie wyboru wnoszenia pism procesowych za pośrednictwem 
systemu teleinformatycznego oraz dalsze wnoszenie tych pism za pośrednictwem 
tego systemu jest dopuszczalne, jeżeli z przyczyn technicznych, leżących po stronie 
sądu, jest to możliwe. 
**§ 22.** W przypadku 
niewniesienia 
pisma 
za 
pośrednictwem 
systemu 
teleinformatycznego 
przewodniczący 
zawiadamia 
wnoszącego 
pismo 
o bezskuteczności czynności. 
**§ 23.** Jeżeli z przyczyn technicznych leżących po stronie sądu nie jest możliwe 
wniesienie pisma za pośrednictwem systemu teleinformatycznego w wymaganym 
terminie, stosuje się przepisy art. 168–172. 
**§ 24.** Oświadczenie o wyborze lub rezygnacji z wyboru wnoszenia pism 
procesowych za pośrednictwem systemu teleinformatycznego składa się za 
pośrednictwem tego systemu. Oświadczenie to jest wiążące tylko w stosunku do 
osoby, która je złożyła. 
**§ 3.** Minister Sprawiedliwości określi, w drodze rozporządzenia, wzory 
i sposób udostępniania stronom urzędowych formularzy, o których mowa w § 2, 
odpowiadających 
wymaganiom 
przewidzianym 
dla 
pism 
procesowych, 
szczególnym wymaganiom postępowania, w którym mają być stosowane, oraz 
zawierających niezbędne pouczenia dla stron, co do sposobu ich wypełniania, 
wnoszenia i skutków niedostosowania pisma do tych wymagań, uwzględniając, że 
urzędowe formularze powinny być udostępniane w siedzibach sądów oraz 
bezpłatnie w sieci Internet w formie pozwalającej na dogodną edycję treści 
formularza. 
**§ 31.** Minister Sprawiedliwości w porozumieniu z ministrem właściwym do 
spraw informatyzacji określi, w drodze rozporządzenia, sposób wnoszenia pism 
procesowych za pośrednictwem systemu teleinformatycznego, mając na względzie 
skuteczność wnoszenia pism, szczególne wymagania postępowań obsługiwanych 
przez ten system oraz ochronę praw osób wnoszących pisma. 
**§ 4.** (uchylony) 
[<§ 5. Jeżeli warunki techniczne i organizacyjne sądu to umożliwiają, pisma 
procesowe można wnosić także na adres do doręczeń elektronicznych sądu, 
Dodany § 5 w art. 
125 wejdzie w 
życie 
z 
dn. 
1.01.2025 
r. 
określonym 
w 
komunikacie 
Ministra 
Cyfryzacji z dnia 
29 maja 2023 r. w 
Przepis 
uchylający § 5 w 
art. 125 wejdzie w 
życie 
z 
dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 

 
 
 
s. 42/580 
 
2025-09-08 
 
o którym mowa w art. 2 pkt 1 ustawy z dnia 18 listopada 2020 r. o doręczeniach 
elektronicznych (Dz. U. z 2024 r. poz. 1045).>] 
<Art. 1251. § 1. Jeżeli przepis szczególny tak stanowi i nie jest możliwe 
wniesienie 
pisma 
procesowego 
za 
pośrednictwem 
systemu 
teleinformatycznego, pismo procesowe wnosi się za pośrednictwem portalu 
informacyjnego. 
<§ 2. Adwokat, radca prawny, rzecznik patentowy, Prokuratoria 
Generalna Rzeczypospolitej Polskiej lub prokurator wnosi w sposób wskazany 
w § 1: 
- 1) zgłoszenie się do udziału w sprawie; 
- 2) zawiadomienie o wypowiedzeniu pełnomocnictwa procesowego; 
- 3) zawiadomienia, o których mowa w art. 136 § 1, 4 i 5 oraz art. 3871; 
- 4) oświadczenie w przedmiocie zgody na mediację; 
- 5) wniosek o przeprowadzenie posiedzenia zdalnego; 
- 6) apelację, 
zażalenie, 
z wyłączeniem 
zażaleń, 
o których 
mowa 
w art. 3941 § 1 i 11, lub skargę na orzeczenie referendarza sądowego; 
- 7) pisma procesowe w toku postępowań wywołanych wniesieniem apelacji, 
zażalenia lub skargi na orzeczenie referendarza sądowego; 
- 8) wniosek o doręczenie orzeczenia wraz z uzasadnieniem, jak również 
pismo uzupełniające braki formalne takiego wniosku; 
- 9) wniosek o nadanie klauzuli wykonalności tytułom egzekucyjnym, 
o których 
mowa 
w art. 777 § 1 
i 11, 
z wyłączeniem 
wniosków 
w przypadkach, o których mowa w art. 7781, art. 7782, art. 7783, art. 787, 
art. 7871, art. 788 oraz art. 789; 
- 10) wniosek o wydanie odpisu prawomocnego orzeczenia.> 
**§ 3.** Przepisu § 1 nie stosuje się do pism procesowych wnoszonych do 
Sądu Najwyższego.

***
## Art. 1252. {#kpc-pierwsza-pierwsza-art-1252}

**§ 1.** W przypadku gdy załącznik pisma procesowego, ze 
względu na jego właściwości, nie może zostać skutecznie wniesiony wraz z tym 
pismem za pośrednictwem portalu informacyjnego, załącznik ten wnosi się do 
sądu z pominięciem portalu informacyjnego, uprawdopodobniając tę 
Dodane art. 1251–
1254 (bez § 2 w 
art. 1251) wejdą 
w życie z dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 
§ 2 w art. 1251 
wejdzie w życie z 
dn. 1.03.2027 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 
 

 
 
 
s. 43/580 
 
2025-09-08 
 
okoliczność, w terminie 3 dni od dnia wniesienia pisma procesowego. 
W przypadku niedopełnienia tych obowiązków sąd pomija ten załącznik. 
**§ 2.** W przypadku gdy w dniu, w którym upływa termin do wniesienia 
pisma 
procesowego 
wystąpią 
ograniczenia 
w dostępności 
portalu 
informacyjnego leżące po stronie sądu, uniemożliwiające wniesienie tego 
pisma, pismo to wnosi się najpóźniej w następnym dniu po dniu, w którym 
przywrócono dostępność tego portalu, niebędącym dniem wolnym od pracy 
ani sobotą. Jeżeli w ustalonym w ten sposób terminie wystąpią ponownie 
ograniczenia w dostępności portalu informacyjnego leżące po stronie sądu, 
stosuje się zdanie pierwsze. W piśmie procesowym należy uprawdopodobnić 
okoliczności, o których mowa w zdaniu pierwszym lub drugim. 
**§ 3.** Przewodniczący zwraca pismo procesowe albo sąd odrzuca środek 
zaskarżenia w wypadku nieuprawdopodobnienia okoliczności określonych 
w § 2 zdanie pierwsze lub drugie.

***
## Art. 1253. {#kpc-pierwsza-pierwsza-art-1253}

**§ 1.** Jeżeli przepis szczególny stanowi, że pismo procesowe 
wnosi się za pośrednictwem portalu informacyjnego i nie zachodzi okoliczność, 
o której mowa w art. 1252 § 1, pismo procesowe wniesione w inny sposób nie 
wywołuje skutków prawnych, jakie ustawa wiąże z wniesieniem pisma 
procesowego do sądu, o czym przewodniczący zawiadamia wnoszącego to 
pismo. 
**§ 2.** Pismo 
procesowe 
wniesione 
za 
pośrednictwem 
portalu 
informacyjnego w przypadku nieprzewidzianym w przepisie szczególnym lub 
przez osobę nieuprawnioną nie wywołuje skutków prawnych, jakie ustawa 
wiąże z wniesieniem pisma procesowego do sądu, o czym przewodniczący 
zawiadamia wnoszącego to pismo.

***
## Art. 1254. {#kpc-pierwsza-pierwsza-art-1254}

Minister 
Sprawiedliwości 
w porozumieniu 
z ministrem 
właściwym do spraw informatyzacji określi, w drodze rozporządzenia, treść 
dokumentu w postaci elektronicznej potwierdzającego wniesienie pisma 
procesowego do sądu, sposób i zakres informowania o ograniczeniu 
dostępności portalu informacyjnego, sposób wnoszenia do sądu pism 
procesowych i ich załączników za pośrednictwem portalu informacyjnego oraz 
ich elektroniczną postać, w tym wymagania dotyczące dokumentów 

 
 
 
s. 44/580 
 
2025-09-08 
 
składanych w postaci elektronicznej, jak również sposób poświadczania 
dokumentów w portalu informacyjnym, mając na względzie skuteczność ich 
wnoszenia oraz konieczność zapewnienia sprawnego toku postępowania, 
a także ochronę praw osób wnoszących pisma procesowe.>

***
## Art. 126. {#kpc-pierwsza-pierwsza-art-126}

**§ 1.** Każde pismo procesowe powinno zawierać: 
- 1) oznaczenie sądu, do którego jest skierowane; 
- 2) imiona i nazwiska lub nazwy stron, ich przedstawicieli ustawowych 
i pełnomocników; 
- 3) oznaczenie rodzaju pisma; 
- 4) osnowę wniosku lub oświadczenia; 
- 5) w przypadku gdy jest to konieczne do rozstrzygnięcia co do wniosku lub 
oświadczenia – wskazanie faktów, na których strona opiera swój wniosek lub 
oświadczenie, oraz wskazanie dowodu na wykazanie każdego z tych faktów; 
- 6) podpis strony albo jej przedstawiciela ustawowego lub pełnomocnika; 
- 7) wymienienie załączników. 
**§ 11.** Do pisma procesowego dołącza się załączniki wymienione w tym 
piśmie. 
**§ 2.** Gdy pismo procesowe jest pierwszym pismem w sprawie, powinno 
ponadto zawierać oznaczenie przedmiotu sporu oraz: 
- 1) oznaczenie miejsca zamieszkania lub siedziby i adresy stron albo, 
w przypadku gdy strona jest przedsiębiorcą wpisanym do Centralnej 
Ewidencji i Informacji o Działalności Gospodarczej – adres do doręczeń 
wpisany do Centralnej Ewidencji i Informacji o Działalności Gospodarczej; 
- 11) oznaczenie miejsca zamieszkania lub siedziby i adresy przedstawicieli 
ustawowych i pełnomocników stron; 
- 2) numer Powszechnego Elektronicznego Systemu Ewidencji Ludności 
(PESEL) lub numer identyfikacji podatkowej (NIP) powoda będącego osobą 
fizyczną, jeżeli jest on obowiązany do jego posiadania lub posiada go nie 
mając takiego obowiązku lub 
- 3) numer w Krajowym Rejestrze Sądowym, a w przypadku jego braku – numer 
w innym właściwym rejestrze, ewidencji lub NIP powoda niebędącego osobą 
fizyczną, który nie ma obowiązku wpisu we właściwym rejestrze lub 
ewidencji, jeżeli jest on obowiązany do jego posiadania. 

 
 
 
s. 45/580 
 
2025-09-08 
**§ 21.** Dalsze pisma procesowe, poza elementami określonymi w § 1, powinny 
zawierać sygnaturę akt. 
[§ 3. Do pisma należy dołączyć pełnomocnictwo albo uwierzytelniony odpis 
pełnomocnictwa, jeżeli pismo wnosi pełnomocnik, który wcześniej nie złożył 
pełnomocnictwa. Jeżeli pełnomocnik dokonał wyboru wnoszenia pism za 
pośrednictwem 
systemu 
teleinformatycznego, 
uwierzytelniony 
odpis 
pełnomocnictwa wnosi się za pośrednictwem tego systemu.] 
<§ 3. Do pisma procesowego należy dołączyć pełnomocnictwo albo jego 
uwierzytelniony odpis, jeżeli pismo to wnosi pełnomocnik, który wcześniej nie 
złożył pełnomocnictwa. Jeżeli pełnomocnik wnosi pismo procesowe za 
pośrednictwem systemu teleinformatycznego albo portalu informacyjnego, 
pełnomocnictwo udzielone w postaci elektronicznej albo jego elektronicznie 
uwierzytelniony odpis wnosi się wraz z tym pismem. W piśmie tym podaje się 
numer wpisu pełnomocnika na właściwą listę, w przypadku gdy pismo to jest 
wnoszone przez pełnomocnika strony będącego adwokatem, radcą prawnym 
lub rzecznikiem patentowym.> 
**§ 31.** Przepisu § 3 nie stosuje się do pism wnoszonych w elektronicznym 
postępowaniu upominawczym. 
**§ 4.** Za stronę, która nie może się podpisać, podpisuje pismo osoba przez nią 
upoważniona, z wymienieniem przyczyny, dla której strona sama się nie podpisała. 
[§ 5. Pismo 
procesowe 
wniesione 
za 
pośrednictwem 
systemu 
teleinformatycznego 
opatruje 
się 
kwalifikowanym 
podpisem 
elektronicznym, podpisem zaufanym albo podpisem osobistym.] 
<§ 5. Pismo 
procesowe 
wniesione 
za 
pośrednictwem 
systemu 
teleinformatycznego 
albo 
portalu 
informacyjnego 
opatruje 
się 
kwalifikowanym podpisem elektronicznym, podpisem zaufanym albo 
podpisem osobistym, a w przypadku prokuratora – także zaawansowanym 
podpisem 
elektronicznym 
wydawanym 
przez 
właściwe 
jednostki 
organizacyjne prokuratury.> 
**§ 6.** (uchylony)

***
## Art. 1261. {#kpc-pierwsza-pierwsza-art-1261}

**§ 1.** W każdym piśmie należy podać wartość przedmiotu sporu lub 
wartość przedmiotu zaskarżenia, jeżeli od tej wartości zależy właściwość rzeczowa 
Nowe brzmienie 
§ 3 w art. 126 
wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 
Nowe brzmienie 
§ 5 w art. 126 
wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 

 
 
 
s. 46/580 
 
2025-09-08 
 
sądu, wysokość opłaty lub dopuszczalność środka odwoławczego, a przedmiotem 
sprawy nie jest oznaczona kwota pieniężna. 
**§ 2.** Pisma dotyczące części przedmiotu sporu lub zaskarżenia podlegają 
opłacie tylko w stosunku do wartości tej części. 
**§ 3.** Wartości przedmiotu sporu lub zaskarżenia podaje się w złotych, 
zaokrąglając w górę do pełnego złotego.

***
## Art. 1262. {#kpc-pierwsza-pierwsza-art-1262}

**§ 1.** Sąd nie podejmie żadnej czynności na skutek pisma, od 
którego nie została uiszczona należna opłata. 
**§ 2.** Nie żąda się opłaty od pisma, jeżeli już z jego treści wynika, że podlega 
ono odrzuceniu.

***
## Art. 127. {#kpc-pierwsza-pierwsza-art-127}

**§ 1.** W piśmie procesowym mającym na celu przygotowanie sprawy 
do rozstrzygnięcia (pismo przygotowawcze) strona powinna zwięźle podać stan 
sprawy, wyszczególnić, które fakty przyznaje, a którym zaprzecza, oraz 
wypowiedzieć się co do twierdzeń i dowodów zgłoszonych przez stronę przeciwną. 
**§ 2.** W piśmie przygotowawczym strona może także wskazać podstawy 
prawne swoich żądań lub wniosków.

***
## Art. 128. {#kpc-pierwsza-pierwsza-art-128}

**§ 1.** Do pisma procesowego należy dołączyć jego odpisy i odpisy 
załączników dla doręczenia ich uczestniczącym w sprawie osobom, a ponadto, 
jeżeli w sądzie nie złożono załączników w oryginale, po jednym odpisie każdego 
załącznika do akt sądowych. 
[§ 2. Do pisma procesowego wnoszonego za pośrednictwem systemu 
teleinformatycznego dołącza się poświadczone elektronicznie odpisy załączników.] 
<§ 2. Do pisma procesowego wnoszonego za pośrednictwem systemu 
teleinformatycznego albo portalu informacyjnego dołącza się załączniki 
utrwalone w postaci elektronicznej.> 
<§ 3. Jeżeli z przepisu szczególnego lub postanowienia sądu albo 
zarządzenia przewodniczącego wynika obowiązek złożenia oryginału 
dokumentu sporządzonego w postaci papierowej, a strona lub pełnomocnik 
obowiązani są do wnoszenia pism procesowych za pośrednictwem systemu 
teleinformatycznego albo portalu informacyjnego, oryginał dokumentu składa 
się do sądu z ich pominięciem. 
Nowe brzmienie 
§ 2 oraz dodane  
§ 3 i 4 w art. 128 
wejdą w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 

 
 
 
s. 47/580 
 
2025-09-08 
**§ 4.** Jeżeli przepis szczególny przewiduje obowiązek dołączenia do pisma 
procesowego oryginału dokumentu sporządzonego w postaci papierowej, 
a strona lub pełnomocnik obowiązani są do wnoszenia pism procesowych za 
pośrednictwem systemu teleinformatycznego albo portalu informacyjnego, 
oryginał takiego dokumentu składa się w terminie 3 dni roboczych od dnia 
wniesienia pisma procesowego.>

***
## Art. 1281. {#kpc-pierwsza-pierwsza-art-1281}

Pismo wnoszone przez stronę zastępowaną przez adwokata, radcę 
prawnego, rzecznika patentowego lub Prokuratorię Generalną Rzeczypospolitej 
Polskiej powinno zawierać wyraźnie wyodrębnione oświadczenia, twierdzenia oraz 
wnioski, w tym wnioski dowodowe. Jeżeli pismo zawiera uzasadnienie, wnioski 
dowodowe, zgłoszone tylko w tym uzasadnieniu, nie wywołują skutków, jakie 
ustawa wiąże ze zgłoszeniem ich przez stronę.

***
## Art. 129. {#kpc-pierwsza-pierwsza-art-129}

**§ 1.** Strona powołująca się w piśmie na dokument obowiązana jest 
na żądanie przeciwnika złożyć oryginał dokumentu w sądzie jeszcze przed 
rozprawą. 
[§ 2. Zamiast oryginału dokumentu strona może złożyć odpis dokumentu, 
jeżeli jego zgodność z oryginałem została poświadczona przez notariusza albo 
przez występującego w sprawie pełnomocnika strony będącego adwokatem, radcą 
prawnym, 
rzecznikiem 
patentowym 
lub 
radcą 
Prokuratorii 
Generalnej 
Rzeczypospolitej Polskiej.] 
<§ 2. Zamiast oryginału dokumentu 
strona może złożyć odpis 
dokumentu, jeżeli jego zgodność z oryginałem została poświadczona przez 
notariusza albo występującego w sprawie pełnomocnika strony będącego 
adwokatem, radcą prawnym lub rzecznikiem patentowym, albo radcę lub 
referendarza Prokuratorii Generalnej Rzeczypospolitej Polskiej.> 
[§ 21. Elektroniczne poświadczenie odpisu dokumentu przez występującego 
w sprawie pełnomocnika strony będącego adwokatem, radcą prawnym, 
rzecznikiem patentowym lub radcą Prokuratorii Generalnej Rzeczypospolitej 
Polskiej następuje z chwilą wprowadzenia przez tego pełnomocnika dokumentu do 
systemu teleinformatycznego.] 
<§ 21. Występujący w sprawie pełnomocnik będący adwokatem, radcą 
prawnym lub rzecznikiem patentowym albo radca lub referendarz 
Nowe brzmienia 
§ 2–3 w art. 129 
wejdą w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 
 

 
 
 
s. 48/580 
 
2025-09-08 
 
Prokuratorii Generalnej Rzeczypospolitej Polskiej może elektronicznie 
poświadczyć dokument w systemie teleinformatycznym albo portalu 
informacyjnym.> 
[§ 3. Zawarte w odpisie dokumentu poświadczenie zgodności z oryginałem 
przez występującego w sprawie pełnomocnika strony będącego adwokatem, radcą 
prawnym, rzecznikiem patentowym lub radcą Prokuratorii Generalnej Rzeczy-
pospolitej Polskiej ma charakter dokumentu urzędowego.] 
<§ 3. Zawarte 
w odpisie 
dokumentu 
poświadczenie 
zgodności 
z oryginałem przez występującego w sprawie pełnomocnika strony, będącego 
adwokatem, radcą prawnym lub rzecznikiem patentowym albo radcę lub 
referendarza Prokuratorii Generalnej Rzeczypospolitej Polskiej, ma 
charakter dokumentu urzędowego.> 
**§ 4.** Jeżeli jest to uzasadnione okolicznościami sprawy, sąd, na wniosek strony 
albo z urzędu, zażąda od strony składającej odpis dokumentu, o którym mowa 
w § 2, przedłożenia oryginału tego dokumentu. 
**§ 5.** Minister Sprawiedliwości określi, w drodze rozporządzenia, formaty, 
w jakich odpisy pism, dokumentów i pełnomocnictw mogą być poświadczane 
elektronicznie, mając na względzie minimalne wymagania dla rejestrów 
publicznych i wymiany informacji w postaci elektronicznej.

***
## Art. 130. {#kpc-pierwsza-pierwsza-art-130}

**§ 1.** Jeżeli pismo procesowe nie może otrzymać prawidłowego 
biegu wskutek niezachowania warunków formalnych lub jeżeli od pisma nie 
uiszczono należnej opłaty, przewodniczący wzywa stronę, pod rygorem zwrócenia 
pisma, do poprawienia, uzupełnienia lub opłacenia go w terminie tygodniowym. 
Mylne oznaczenie pisma procesowego lub inne oczywiste niedokładności nie 
stanowią przeszkody do nadania pismu biegu i rozpoznania go w trybie 
właściwym. 
**§ 11.** Jeżeli pismo wniosła osoba zamieszkała lub mająca siedzibę za granicą, 
która nie ma w kraju przedstawiciela, przewodniczący wyznacza termin do 
poprawienia lub uzupełnienia pisma albo uiszczenia opłaty nie krótszy niż miesiąc, 
przy czym gdyby doręczenie wezwania miało mieć miejsce poza terytorium Unii 
Europejskiej, oznacza się termin nie krótszy niż trzy miesiące. 

 
 
 
s. 49/580 
 
2025-09-08 
**§ 2.** Po bezskutecznym upływie terminu przewodniczący zwraca pismo 
stronie. Pismo zwrócone nie wywołuje żadnych skutków, jakie ustawa wiąże 
z wniesieniem pisma procesowego do sądu. 
**§ 3.** Pismo poprawione lub uzupełnione w terminie wywołuje skutki od chwili 
jego wniesienia. 
**§ 4.** Zarządzenie przewodniczącego o zwrocie pozwu doręcza się tylko 
powodowi. 
**§ 5.** Pisma procesowe sporządzone z naruszeniem art. 871 podlegają zwrotowi 
bez wzywania do usunięcia braków, chyba że ustawa stanowi inaczej. 
**§ 6.** Jeżeli przepis szczególny przewiduje, że pismo może być wniesione 
wyłącznie za pośrednictwem systemu teleinformatycznego, pismo wnosi się wraz 
z opłatą. Pismo wniesione bez opłaty nie wywołuje skutków, jakie ustawa wiąże 
z wniesieniem pisma do sądu, o czym sąd poucza wnoszącego pismo. W razie 
jednoczesnego wniesienia za pośrednictwem systemu teleinformatycznego więcej 
niż jednego pisma podlegającego opłacie żadne z tych pism nie wywołuje skutków, 
jakie ustawa wiąże z wniesieniem pisma do sądu, jeżeli nie uiszczono opłaty 
w wysokości sumy opłat należnych od wszystkich pism. 
**§ 7.** W przypadku wniesienia pisma podlegającego opłacie z naruszeniem 
§ 6 przewodniczący zawiadamia wnoszącego pismo o bezskuteczności czynności. 
**§ 8.** Przepisów § 6 i 7 nie stosuje się, jeżeli wnoszący pismo jest zwolniony 
z mocy prawa od kosztów sądowych w zakresie opłaty sądowej należnej od tego 
pisma, a także w razie zwolnienia od tych kosztów przyznanego przez sąd lub 
w razie zgłoszenia wniosku o takie zwolnienie.

***
## Art. 1301. {#kpc-pierwsza-pierwsza-art-1301}

**§ 1.** (utracił moc)9) 
**§ 11.** Jeżeli pismo procesowe, które powinno być wniesione na urzędowym 
formularzu, nie zostało wniesione na takim formularzu lub nie może otrzymać 
prawidłowego biegu na skutek niezachowania innych warunków formalnych, 
przewodniczący wzywa stronę do jego poprawienia lub uzupełnienia w terminie 
tygodniowym, przesyłając złożone pismo. Wezwanie powinno wskazywać 
wszystkie braki pisma oraz zawierać pouczenie o treści § 2. 
- 9) Z dniem 25 marca 2002 r. na podstawie wyroku Trybunału Konstytucyjnego z dnia 12 marca 2002 r. 
sygn. akt P. 9/01 (Dz. U. poz. 265). 

 
 
 
s. 50/580 
 
2025-09-08 
**§ 2.** W razie bezskutecznego upływu terminu lub ponownego złożenia pisma 
dotkniętego brakami przewodniczący zarządza zwrot pisma. Sprzeciw od wyroku 
zaocznego, zarzuty od nakazu zapłaty oraz sprzeciw od nakazu zapłaty sąd odrzuca. 
**§ 3.** (uchylony) 
**§ 4.** (uchylony)

***
## Art. 1301a. {#kpc-pierwsza-pierwsza-art-1301a}

(uchylony)

***
## Art. 1302. {#kpc-pierwsza-pierwsza-art-1302}

**§ 1.** Pismo wniesione przez adwokata, radcę prawnego lub 
rzecznika patentowego, które nie zostało należycie opłacone, przewodniczący 
zwraca bez wezwania o uiszczenie opłaty, jeżeli pismo podlega opłacie 
w wysokości stałej lub stosunkowej obliczonej od wskazanej przez stronę wartości 
przedmiotu sporu. 
**§ 2.** W terminie tygodniowym od dnia doręczenia zarządzenia o zwrocie 
pisma z przyczyn określonych w § 1 strona może uiścić brakującą opłatę. Jeżeli 
opłata została wniesiona we właściwej wysokości, pismo wywołuje skutek od daty 
pierwotnego wniesienia. Skutek taki nie następuje w razie kolejnego zwrotu pisma 
z tej samej przyczyny. 
**§ 3.** (uchylony) 
**§ 4.** (uchylony) 
**§ 5.** Przepisu § 1 nie stosuje się, gdy obowiązek uiszczenia opłaty 
stosunkowej powstał na skutek sprawdzenia przez sąd wskazanej przez stronę 
wartości przedmiotu sporu lub zaskarżenia.

***
## Art. 1303. {#kpc-pierwsza-pierwsza-art-1303}

**§ 1.** Przepisy art. 1261, art. 1262, art. 130 § 1 i § 11, art. 1302 stosuje 
się odpowiednio, gdy przed wysłaniem odpisu pisma innym stronom, a w braku 
takich stron – przed wysłaniem zawiadomienia o terminie posiedzenia, powstał 
obowiązek uiszczenia lub uzupełnienia opłaty na skutek ustalenia przez sąd 
wyższej wartości przedmiotu sporu, cofnięcia zwolnienia od kosztów sądowych 
albo uchylenia kurateli. 
**§ 2.** Jeżeli obowiązek uiszczenia lub uzupełnienia opłaty powstał z innych 
przyczyn niż wymienione w § 1 albo po wysłaniu odpisu pisma innym stronom, 
a w przypadku braku takich stron – po wysłaniu zawiadomienia o terminie 
posiedzenia, przewodniczący wzywa zobowiązanego do uiszczenia należnej opłaty 
w terminie tygodnia. W przypadku bezskutecznego upływu terminu sąd prowadzi 

 
 
 
s. 51/580 
 
2025-09-08 
 
sprawę bez wstrzymywania biegu postępowania, a o obowiązku uiszczenia opłaty 
orzeka w orzeczeniu kończącym sprawę w instancji, stosując odpowiednio zasady 
obowiązujące przy zwrocie kosztów procesu. 
**§ 3.** Jeżeli zobowiązany mieszka lub ma siedzibę za granicą i nie ma w kraju 
przedstawiciela, termin, o którym mowa w § 2, wynosi miesiąc, przy czym gdyby 
doręczenie wezwania miało mieć miejsce poza terytorium Unii Europejskiej, 
oznacza się termin nie krótszy niż trzy miesiące.

***
## Art. 1304. {#kpc-pierwsza-pierwsza-art-1304}

**§ 1.** Strona, która wnosi o podjęcie czynności połączonej 
z wydatkami, obowiązana jest uiścić zaliczkę na ich pokrycie w wysokości 
i terminie oznaczonym przez sąd. Jeżeli więcej niż jedna strona wnosi o podjęcie 
czynności, sąd zobowiązuje każdą stronę, która z czynności wywodzi skutki 
prawne, do uiszczenia zaliczki w równych częściach lub w innym stosunku według 
swego uznania. 
**§ 2.** Przewodniczący wzywa stronę zobowiązaną do wniesienia zaliczki, aby 
w wyznaczonym terminie nie dłuższym niż dwa tygodnie zapłaciła oznaczoną 
kwotę. Jeżeli strona zobowiązana mieszka lub ma siedzibę za granicą i nie ma 
w kraju przedstawiciela, termin, o którym mowa w § 1, wynosi miesiąc, przy czym 
gdyby doręczenie wezwania miało mieć miejsce poza terytorium Unii Europejskiej, 
oznacza się termin nie krótszy niż trzy miesiące. 
**§ 3.** Jeżeli okazuje się, że przewidywane lub rzeczywiste wydatki są większe 
od wniesionej zaliczki, przewodniczący wzywa o jej uzupełnienie w trybie 
określonym w § 2. 
**§ 4.** Sąd podejmie czynność połączoną z wydatkami, jeżeli zaliczka zostanie 
uiszczona w oznaczonej wysokości. 
**§ 5.** W razie nieuiszczenia zaliczki sąd pominie czynność połączoną 
z wydatkami.

***
## Art. 1305. {#kpc-pierwsza-pierwsza-art-1305}

W przypadkach, o których mowa w art. 125 oraz art. 130–1304, 
czynności przewodniczącego może wykonywać referendarz sądowy. 
Rozdział 2 
Doręczenia

***
## Art. 131. {#kpc-pierwsza-pierwsza-art-131}

**§ 1.** Sąd 
dokonuje 
doręczeń 
przez 
operatora 
pocztowego 
w rozumieniu ustawy z dnia 23 listopada 2012 r. – Prawo pocztowe (Dz. U. z 2023 

 
 
 
s. 52/580 
 
2025-09-08 
 
r. poz. 1640 oraz z 2024 r. poz. 467 i 1222), osoby zatrudnione w sądzie, lub sądową 
służbę doręczeniową. Sąd może również dokonywać doręczeń za pośrednictwem 
komornika w sposób określony w ustawie z dnia 22 marca 2018 r. o komornikach 
sądowych (Dz. U. z 2024 r. poz. 1458). 
**§ 11.** W wypadkach wskazanych w ustawie sąd może dokonać doręczeń przez 
Policję lub Żandarmerię Wojskową. 
**§ 2.** Minister Sprawiedliwości w porozumieniu z ministrem właściwym do 
spraw łączności określi, w drodze rozporządzenia, szczegółowy tryb i sposób 
doręczania pism sądowych przez podmioty, o których mowa w § 1 zdanie 
pierwsze, mając na uwadze konieczność zapewnienia sprawnego toku 
postępowania, a także realizacji gwarancji procesowych jego uczestników, ochronę 
praw osób, którym pisma są doręczane, oraz ochronę ich danych osobowych. 
**§ 3.** Minister Sprawiedliwości, na uzasadniony wniosek prezesa sądu, 
w drodze zarządzenia, tworzy i znosi w tym sądzie sądową służbę doręczeniową. 
**§ 4.** Minister Sprawiedliwości określi, w drodze rozporządzenia, warunki 
organizacji oraz strukturę sądowej służby doręczeniowej, mając na względzie 
wielkość sądu, koszty oraz zapewnienie skuteczności doręczeń i zachowanie 
wymogów postępowania sądowego.

***
## Art. 1311. {#kpc-pierwsza-pierwsza-art-1311}

**§ 1.** Sąd 
dokonuje 
doręczeń 
za 
pośrednictwem 
systemu 
teleinformatycznego (doręczenie elektroniczne), jeżeli adresat wniósł pismo za 
pośrednictwem systemu teleinformatycznego albo dokonał wyboru wnoszenia 
pism za pośrednictwem systemu teleinformatycznego. 
**§ 2.** W przypadku doręczenia elektronicznego pismo uznaje się za doręczone 
w chwili wskazanej w elektronicznym potwierdzeniu odbioru korespondencji. 
Przepisu art. 134 § 1 nie stosuje się. W przypadku braku takiego potwierdzenia 
doręczenie elektroniczne uznaje się za skuteczne z upływem 14 dni od daty 
umieszczenia pisma w systemie teleinformatycznym. 
**§ 21.** Adresat, który dokonał wyboru wnoszenia pism za pośrednictwem 
systemu teleinformatycznego, może zrezygnować z doręczenia elektronicznego. 
**§ 3.** Minister Sprawiedliwości w porozumieniu z ministrem właściwym do 
spraw informatyzacji określi, w drodze rozporządzenia, tryb i sposób dokonywania 
doręczeń elektronicznych, mając na względzie zapewnienie skuteczności doręczeń 
oraz ochronę praw osób, którym pisma są doręczane. 

 
 
 
s. 53/580 
 
2025-09-08

***
## Art. 1311a. {#kpc-pierwsza-pierwsza-art-1311a}

[§ 1. W razie niemożności doręczenia za pośrednictwem systemu 
teleinformatycznego, sąd doręcza adwokatowi, radcy prawnemu, rzecznikowi 
patentowemu, prokuratorowi, organowi emerytalnemu określonemu przez ministra 
właściwego 
do 
spraw 
wewnętrznych 
oraz 
Prokuratorii 
Generalnej 
Rzeczypospolitej Polskiej pisma sądowe, wyłącznie poprzez umieszczenie ich treści 
w portalu informacyjnym w sposób umożliwiający uzyskanie przez odbiorcę 
dokumentu potwierdzającego doręczenie. Nie dotyczy to pism, które podlegają 
doręczeniu wraz z odpisami pism procesowych stron lub innymi dokumentami 
niepochodzącymi od sądu, chyba że sąd dysponuje ich kopią utrwaloną w postaci 
elektronicznej.] 
<§ 1. W razie niemożności doręczenia za pośrednictwem systemu 
teleinformatycznego sąd doręcza adwokatowi, radcy prawnemu, rzecznikowi 
patentowemu, prokuratorowi, organowi emerytalnemu określonemu przez 
ministra właściwego do spraw wewnętrznych, Prokuratorii Generalnej 
Rzeczypospolitej Polskiej, komornikowi sądowemu lub stałemu mediatorowi, 
a także stronie, która dokonała wyboru takiego sposobu doręczania, pisma 
sądowe 
oraz 
odpisy 
pism 
procesowych 
lub 
innych 
dokumentów 
niepochodzących od sądu, którymi sąd dysponuje w postaci elektronicznej, 
wyłącznie przez umieszczenie ich treści w portalu informacyjnym w sposób 
umożliwiający uzyskanie przez odbiorcę dokumentu potwierdzającego 
doręczenie. Nie dotyczy to pism sądowych, które podlegają doręczeniu wraz 
z odpisami 
pism 
procesowych 
stron 
lub 
innymi 
dokumentami 
niepochodzącymi od sądu, chyba że sąd dysponuje nimi w postaci 
elektronicznej.> 
<§ 11. Oświadczenie o wyborze sposobu doręczeń, o którym mowa w § 1, 
lub oświadczenie o rezygnacji z nich strona składa za pośrednictwem portalu 
informacyjnego i opatruje kwalifikowanym podpisem elektronicznym, 
podpisem zaufanym albo podpisem osobistym. Oświadczenie o rezygnacji ze 
sposobu doręczeń, o którym mowa w § 1, strona może złożyć również na 
piśmie. Oświadczenie o rezygnacji ze sposobu doręczeń, o którym mowa w § 1, 
odnosi skutek prawny z chwilą zawiadomienia sądu.> 
**§ 2.** W przypadku, o którym mowa w § 1, pismo uznaje się za doręczone 
w chwili 
wskazanej 
w dokumencie 
potwierdzającym 
doręczenie. 
Dodany art. 1312 
wejdzie w życie z 
dn. 1.01.2025 r. 
Nowe brzmienie 
§ 1 w art. 1311a 
wejdzie w życie z 
dn. 1.06.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 
Dodany § 11a w 
art. 1311a wejdzie 
w życie z dn. 
1.06.2026 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 

 
 
 
s. 54/580 
 
2025-09-08 
 
Przepisu art. 134 § 1 nie 
stosuje 
się. 
W 
przypadku 
braku 
dokumentu 
potwierdzającego doręczenie, doręczenie uznaje się za skuteczne z upływem 14 dni 
od daty umieszczenia treści pisma w portalu informacyjnym w sposób, o którym 
mowa w § 1 zdanie pierwsze. 
**§ 3.** Przewodniczący zarządza odstąpienie od doręczenia pisma za 
pośrednictwem portalu informacyjnego, jeżeli dokonanie doręczenia w taki sposób 
jest niemożliwe ze względu na charakter pisma, w szczególności jeżeli zachodzi 
potrzeba wydania stronie uwierzytelnionego odpisu orzeczenia lub tytułu 
wykonawczego. 
**§ 4.** Minister Sprawiedliwości w porozumieniu z ministrem właściwym do 
spraw informatyzacji określi, w drodze rozporządzenia, szczegółowy tryb i sposób 
doręczania pism sądowych za pośrednictwem portalu informacyjnego, jak również 
elektroniczną postać, w której pisma te są doręczane, mając na uwadze konieczność 
zapewnienia sprawnego toku postępowania, a także realizacji gwarancji 
procesowych jego uczestników. 
[<Art. 1312. § 1. Jeżeli warunki techniczne i organizacyjne sądu to 
umożliwiają, doręczeń dokonuje się na adres do doręczeń elektronicznych, 
o którym mowa w art. 2 pkt 1 ustawy z dnia 18 listopada 2020 r. o doręczeniach 
elektronicznych, wpisany do bazy adresów elektronicznych, o której mowa 
w art. 25 tej ustawy, a w przypadku braku takiego adresu – na adres do doręczeń 
elektronicznych powiązany z kwalifikowaną usługą rejestrowanego doręczenia 
elektronicznego, z którego adresat wniósł pismo. 
**§ 2.** Doręczenia, o którym mowa w § 1, można dokonać wobec strony 
będącej osobą fizyczną tylko wtedy, gdy wniosła ona pismo z adresu do doręczeń 
elektronicznych albo wskazała ten adres jako adres do doręczeń. Nie dotyczy to 
doręczeń dla przedsiębiorców wpisanych do Centralnej Ewidencji i Informacji 
o Działalności Gospodarczej.>]

***
## Art. 132. {#kpc-pierwsza-pierwsza-art-132}

**§ 1.** W toku sprawy adwokat, radca prawny, rzecznik patentowy 
oraz Prokuratoria Generalna Rzeczypospolitej Polskiej doręczają sobie nawzajem 
bezpośrednio odpisy pism procesowych z załącznikami. [W treści pisma 
procesowego wniesionego do sądu zamieszcza się oświadczenie o doręczeniu 
odpisu pisma drugiej stronie albo o jego nadaniu za pośrednictwem operatora, 
Przepis 
uchylający 
art. 
1312 wejdzie w 
życie 
z 
dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 
Nowe brzmienia 
zd. 
drugiego 
i 
trzeciego w § 1 
oraz 
nowe 
brzmienia § 11 i 
§ 12 w art. 132 
wejdą w życie z 

 
 
 
s. 55/580 
 
2025-09-08 
 
o którym mowa w art. 165 § 2. Pismo niezawierające powyższego oświadczenia 
podlega zwrotowi bez wzywania do usunięcia tego braku.]  <W razie wątpliwości 
co do dochowania obowiązku, o którym mowa w zdaniu poprzedzającym, sąd 
może, na wniosek albo z urzędu, zażądać dowodu nadania pisma procesowego 
za pośrednictwem operatora, o którym mowa w art. 165 § 2, lub dowodu 
doręczenia. W razie nieprzedstawienia w wyznaczonym terminie dowodów, 
o których mowa w zdaniu drugim, pismo procesowe podlega zwrotowi.> 
[§ 11. Przepis § 1 nie dotyczy wniesienia pozwu wzajemnego, apelacji, skargi 
kasacyjnej, zażalenia, sprzeciwu od wyroku zaocznego, sprzeciwu od nakazu 
zapłaty, zarzutów od nakazu zapłaty, wniosku o zabezpieczenie powództwa, skargi 
o wznowienie postępowania, skargi o stwierdzenie niezgodności z prawem 
prawomocnego orzeczenia i skargi na orzeczenia referendarza sądowego, które 
należy złożyć w sądzie z odpisami dla strony przeciwnej.] 
<§ 11. Przepis § 1 nie dotyczy interwencji, zmiany powództwa, zarzutu 
potrącenia, pozwu wzajemnego, apelacji, skargi kasacyjnej, zażalenia, 
sprzeciwu od wyroku zaocznego, sprzeciwu od nakazu zapłaty, zarzutów od 
nakazu zapłaty, wniosku o zabezpieczenie powództwa, skargi o wznowienie 
postępowania, skargi o stwierdzenie niezgodności z prawem prawomocnego 
orzeczenia i skargi na orzeczenia referendarza sądowego, które należy złożyć 
w sądzie z odpisami dla strony przeciwnej.> 
[§ 12. Przepis § 1 nie dotyczy pism wnoszonych za pośrednictwem systemu 
teleinformatycznego, podlegających doręczeniu adwokatowi, radcy prawnemu, 
rzecznikowi patentowemu lub Prokuratorii Generalnej Rzeczypospolitej Polskiej, 
którzy 
dokonali 
wyboru 
wnoszenia 
pism 
za 
pośrednictwem 
systemu 
teleinformatycznego i nie zrezygnowali z doręczenia elektronicznego.] 
<§ 12. Przepis § 1 nie dotyczy pism procesowych wnoszonych za 
pośrednictwem systemu teleinformatycznego, podlegających doręczeniu 
adwokatowi, radcy prawnemu, rzecznikowi patentowemu lub Prokuratorii 
Generalnej Rzeczypospolitej Polskiej, którzy dokonali wyboru wnoszenia 
pism procesowych za pośrednictwem systemu teleinformatycznego i nie 
zrezygnowali z doręczenia elektronicznego.> 
[§ 13. Pisma procesowe z załącznikami, z wyłączeniem pism wymienionych 
w § 11, adwokat, radca prawny, rzecznik patentowy oraz Prokuratoria Generalna 
Przepis 
uchylający § 13 w 
art. 132 wejdzie 
w życie z dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 

 
 
 
s. 56/580 
 
2025-09-08 
 
Rzeczypospolitej Polskiej doręczają sobie nawzajem bezpośrednio wyłącznie 
w postaci elektronicznej, jeżeli złożą sądowi zgodne oświadczenia odpowiedniej 
treści i podadzą do wiadomości sądu używane do tego dane kontaktowe, 
w szczególności adres poczty elektronicznej lub numer faksu. Oświadczenia nie 
podlegają odwołaniu, a zastrzeżenia warunku lub terminu uważa się za 
nieistniejące. Na zgodny wniosek stron lub w innych uzasadnionych przypadkach 
sąd zarządza odstąpienie od takiego sposobu doręczania.] 
<§ 14. W toku sprawy wniesienie do sądu pisma procesowego za 
pośrednictwem portalu informacyjnego oraz uzyskanie przez wnoszącego 
dokumentu potwierdzającego przekazanie tego pisma drugiej stronie jest 
równoznaczne z wykonaniem obowiązku, o którym mowa w § 1 zdanie 
pierwsze. 
**§ 15.** W toku sprawy, w przypadku pism procesowych wnoszonych do 
sądu w inny sposób niż za pośrednictwem portalu informacyjnego, adwokat, 
radca prawny, rzecznik patentowy lub Prokuratoria Generalna Rzeczy-
pospolitej Polskiej mogą doręczać sobie nawzajem bezpośrednio odpisy pism 
procesowych z załącznikami za pośrednictwem portalu informacyjnego 
w sposób umożliwiający uzyskanie przez wnoszącego dokumentu potwier-
dzającego ich przekazanie drugiej stronie. 
**§ 16.** W razie wątpliwości co do przekazania pisma procesowego drugiej 
stronie za pośrednictwem portalu informacyjnego sąd może, na wniosek albo 
z urzędu, zażądać dowodu przekazania tego pisma drugiej stronie. W razie 
nieprzedstawienia dowodu przekazania pisma procesowego drugiej stronie 
w wyznaczonym terminie pismo to podlega zwrotowi. 
**§ 17.** Przepisów 
§ 14 i 15 nie 
stosuje 
się 
do 
pism 
procesowych 
wymienionych w § 11 i 12. 
**§ 18.** Minister Sprawiedliwości w porozumieniu z ministrem właściwym 
do spraw informatyzacji określi, w drodze rozporządzenia, sposób 
bezpośredniego 
wzajemnego 
doręczania 
odpisów 
pism 
procesowych 
z załącznikami pomiędzy adwokatami, radcami prawnymi, rzecznikami 
patentowymi lub Prokuratorią Generalną Rzeczypospolitej Polskiej za 
pośrednictwem portalu informacyjnego oraz ich elektroniczną postać, w tym 
wymagania dotyczące dokumentów składanych w postaci elektronicznej, jak 
Dodane § 14–18 w 
art. 132 wejdą w 
życie 
z 
dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 

 
 
 
s. 57/580 
 
2025-09-08 
 
również treść dokumentu w postaci elektronicznej potwierdzającego 
przekazanie pisma procesowego drugiej stronie, mając na względzie 
skuteczność ich bezpośredniego wzajemnego doręczania, konieczność 
zapewnienia sprawnego toku postępowania, a także ochronę praw osób, 
którym te pisma są doręczane.> 
**§ 2.** Doręczenie adresatowi może nastąpić także przez wręczenie mu pisma 
bezpośrednio w sekretariacie sądu.

***
## Art. 133. {#kpc-pierwsza-pierwsza-art-133}

**§ 1.** Jeżeli stroną jest osoba fizyczna, doręczenia dokonuje się jej 
osobiście, a gdy nie ma ona zdolności procesowej – jej przedstawicielowi 
ustawowemu. 
**§ 2.** Pisma procesowe lub orzeczenia dla osoby prawnej, jak również dla 
organizacji, która nie ma osobowości prawnej, doręcza się organowi uprawnionemu 
do reprezentowania ich przed sądem lub do rąk pracownika upoważnionego do 
odbioru pism. 
**§ 21.** Pisma procesowe lub orzeczenia dla przedsiębiorcy wpisanego do 
Centralnej Ewidencji i Informacji o Działalności Gospodarczej doręcza się na adres 
do doręczeń udostępniony w tej ewidencji, chyba że przedsiębiorca wskazał inny 
adres do doręczeń. 
**§ 22.** Pisma procesowe lub orzeczenia dla przedsiębiorcy wpisanego do 
rejestru sądowego doręcza się na adres udostępniony w tym rejestrze, chyba że 
przedsiębiorca wskazał inny adres do doręczeń. Jeżeli ostatni udostępniony adres 
został wykreślony jako niezgodny z rzeczywistym stanem rzeczy i nie zgłoszono 
wniosku o wpis nowego adresu, który podlegałby udostępnieniu, adres wykreślony 
jest uważany za adres udostępniony w rejestrze. 
**§ 2a.** (uchylony) 
**§ 2b.** (uchylony) 
**§ 23.** Pisma procesowe lub orzeczenia dla osób reprezentujących podmiot 
wpisany do Krajowego Rejestru Sądowego, likwidatorów, prokurentów, członków 
organów lub osób uprawnionych do powołania zarządu doręcza się na adres do 
doręczeń wskazany zgodnie z przepisami art. 19a ust. 5–5b i 5d ustawy z dnia 
20 sierpnia 1997 r. o Krajowym Rejestrze Sądowym (Dz. U. z 2024 r. poz. 979). 
**§ 3.** Jeżeli ustanowiono pełnomocnika procesowego lub pełnomocnika do 
doręczeń, pisma sądowe doręcza się tym osobom. Pismo wzywające stronę do 

 
 
 
s. 58/580 
 
2025-09-08 
 
osobistego stawiennictwa doręcza się tylko bezpośrednio tej stronie, z wyjątkiem 
strony, o której mowa w art. 11355 § 1.

***
## Art. 134. {#kpc-pierwsza-pierwsza-art-134}

**§ 1.** W dni ustawowo uznane za wolne od pracy, jako też w porze 
nocnej doręczać można tylko w wyjątkowych wypadkach za uprzednim 
zarządzeniem prezesa sądu. 
**§ 2.** Za porę nocną uważa się czas od godziny dwudziestej pierwszej do 
godziny siódmej.

***
## Art. 135. {#kpc-pierwsza-pierwsza-art-135}

**§ 1.** Doręczenia dokonuje się w mieszkaniu, w miejscu pracy lub 
tam, gdzie się adresata zastanie. 
**§ 2.** Na wniosek strony doręczenie może być dokonane na wskazany przez nią 
adres skrytki pocztowej. W tym wypadku pismo sądowe przesłane za 
pośrednictwem operatora pocztowego w rozumieniu ustawy z dnia 23 listopada 
2012 r. – Prawo pocztowe składa się w placówce pocztowej tego operatora, 
umieszczając zawiadomienie o tym w skrytce pocztowej adresata. Przepis 
art. 139 § 1 stosuje się odpowiednio.

***
## Art. 136. {#kpc-pierwsza-pierwsza-art-136}

**§ 1.** Strony i ich przedstawiciele mają obowiązek zawiadamiać sąd 
o każdej zmianie swego zamieszkania. 
**§ 2.** W razie zaniedbania tego obowiązku pismo sądowe pozostawia się 
w aktach sprawy ze skutkiem doręczenia, chyba że nowy adres jest sądowi znany. 
O powyższym obowiązku i skutkach jego niedopełnienia sąd powinien pouczyć 
stronę przy pierwszym doręczeniu. 
**§ 3.** Przepisu § 2 nie stosuje się do doręczenia skargi o wznowienie 
postępowania lub skargi o stwierdzenie niezgodności z prawem prawomocnego 
orzeczenia. 
**§ 4.** Strona, która zgłosiła wniosek o dokonywanie doręczeń na adres 
oznaczonej skrytki pocztowej, ma obowiązek zawiadamiać sąd o każdej zmianie 
tego adresu. Przepisy § 2 i 3 stosuje się odpowiednio. 
**§ 5.** Strona będąca przedsiębiorcą wpisanym do Centralnej Ewidencji 
i Informacji o Działalności Gospodarczej ma obowiązek zawiadamiać sąd o każdej 
zmianie adresu do doręczeń, o którym mowa w art. 133 § 21. Przepisy § 2 i 3 
stosuje się odpowiednio. 

 
 
 
s. 59/580 
 
2025-09-08

***
## Art. 137. {#kpc-pierwsza-pierwsza-art-137}

**§ 1.** Doręczenia żołnierzom zasadniczej służby wojskowej, 
funkcjonariuszom Policji i Służby Więziennej dokonuje się przez ich organy 
bezpośrednio przełożone. 
**§ 2.** Doręczenia osobom pozbawionym wolności dokonuje się przez zarząd 
odpowiedniego zakładu.

***
## Art. 138. {#kpc-pierwsza-pierwsza-art-138}

**§ 1.** Jeżeli doręczający nie zastanie adresata w mieszkaniu, może 
doręczyć pismo sądowe dorosłemu domownikowi, a gdyby go nie było – 
administracji domu, dozorcy domu lub sołtysowi, jeżeli osoby te nie są 
przeciwnikami adresata w sprawie i podjęły się oddania mu pisma. 
**§ 2.** Dla adresata, którego doręczający nie zastanie w miejscu pracy, można 
doręczyć pismo osobie upoważnionej do odbioru pism.

***
## Art. 139. {#kpc-pierwsza-pierwsza-art-139}

**§ 1.** W razie niemożności doręczenia w sposób przewidziany 
w artykułach poprzedzających, pismo przesłane za pośrednictwem operatora 
pocztowego w rozumieniu ustawy z dnia 23 listopada 2012 r. – Prawo pocztowe 
należy złożyć w placówce pocztowej tego operatora, a doręczane w inny sposób – 
w urzędzie właściwej gminy. Zawiadomienie o złożeniu pisma umieszcza się 
w drzwiach mieszkania lub biura adresata lub oddawczej skrzynce pocztowej, ze 
wskazaniem, gdzie i kiedy pismo złożono, oraz z pouczeniem, że należy je odebrać 
w terminie siedmiu dni od dnia umieszczenia zawiadomienia. W przypadku 
bezskutecznego upływu tego terminu, czynność zawiadomienia należy powtórzyć. 
**§ 11.** Pismo złożone w placówce pocztowej w rozumieniu ustawy z dnia 
23 listopada 2012 r. – Prawo pocztowe może zostać odebrane także przez osobę 
upoważnioną na podstawie pełnomocnictwa pocztowego do odbioru przesyłek 
pocztowych, w rozumieniu tej ustawy. 
**§ 2.** Jeżeli adresat odmawia przyjęcia pisma, doręczenie uważa się za 
dokonane. W takim przypadku doręczający zwraca pismo do sądu z adnotacją 
o odmowie jego przyjęcia. 
**§ 21.** Jeżeli stronie będącej przedsiębiorcą wpisanym do Centralnej Ewidencji 
i Informacji o Działalności Gospodarczej nie można doręczyć pierwszego pisma 
w sprawie w sposób przewidziany w artykułach poprzedzających lub w § 1 ze 
względu na nieujawnienie w tej ewidencji zmiany adresu do doręczeń, pismo to 
doręcza się na adres, pod którym strona zamieszkuje. W razie potrzeby doręczenia 

 
 
 
s. 60/580 
 
2025-09-08 
 
stronie pisma w sposób przewidziany w art. 1391 koszty doręczenia obciążają tę 
stronę niezależnie od wyniku sprawy. 
**§ 3.** Jeżeli stronie podlegającej wpisowi do rejestru sądowego nie można 
doręczyć pisma w sposób przewidziany w artykułach poprzedzających ze względu 
na nieujawnienie w tym rejestrze zmiany adresu, pismo to pozostawia się w aktach 
sprawy ze skutkiem doręczenia, chyba że nowy adres jest sądowi znany. 
**§ 31.** Pisma dla osób reprezentujących podmiot wpisany do Krajowego 
Rejestru Sądowego, likwidatorów, prokurentów, członków organów lub osób 
uprawnionych do powołania zarządu, w razie niemożności doręczenia ich w sposób 
przewidziany 
w artykułach 
poprzedzających 
z uwagi 
na 
niezgłoszenie 
oświadczenia o zmianie adresu do doręczeń, pozostawia się w aktach sprawy ze 
skutkiem doręczenia, chyba że inny adres do doręczeń lub miejsce zamieszkania 
i adres są sądowi znane. 
**§ 4.** Sąd rejestrowy przy ogłoszeniu lub doręczeniu postanowienia 
o pierwszym wpisie poucza wnioskodawcę o skutkach zaniedbania ujawnienia 
w rejestrze zmian określonych w § 3. 
**§ 41.** Sąd rejestrowy przy doręczeniu postanowienia w przedmiocie wpisu do 
Krajowego Rejestru Sądowego osób reprezentujących podmiot, likwidatorów, 
prokurentów, członków organów lub osób uprawnionych do powołania zarządu 
poucza podmiot wpisany do rejestru o określonych w § 31 skutkach zaniedbania 
zgłoszenia oświadczenia o zmianie adresu do doręczeń. Pouczenie podmiotu 
wpisanego do Krajowego Rejestru Sądowego jest jednoznaczne z pouczeniem 
osób, o których mowa w zdaniu pierwszym. 
**§ 5.** Na wniosek strony wydaje się zaświadczenie, że wyrok zaoczny albo 
nakaz zapłaty został uznany za doręczony na oznaczony adres w sposób 
przewidziany w § 1. W zaświadczeniu stwierdza się z urzędu fakt uchylenia 
zarządzenia o uznaniu wyroku albo nakazu za doręczony.

***
## Art. 1391. {#kpc-pierwsza-pierwsza-art-1391}

**§ 1.** Jeżeli pozwany będący osobą fizyczną, pomimo powtórzenia 
zawiadomienia zgodnie z art. 139 § 1 zdanie drugie, nie odebrał wysłanego pod 
wskazany adres pozwu, innego pisma procesowego lub orzeczenia wywołującego 
potrzebę podjęcia obrony jego praw, a w sprawie nie doręczono mu wcześniej 
żadnego pisma w sposób przewidziany w artykułach poprzedzających ani nie ma 

 
 
 
s. 61/580 
 
2025-09-08 
 
zastosowania art. 139 § 2 lub inny przepis szczególny przewidujący skutek 
doręczenia, przewodniczący zawiadamia o tym powoda, przesyłając mu odpis 
pisma sądowego dla pozwanego i zobowiązując do doręczenia tego odpisu pisma 
pozwanemu za pośrednictwem komornika. 
**§ 11.** Przepisu § 1 nie stosuje się, jeżeli pomimo nieodebrania przez adresata 
korespondencji aktualność wskazanego w pozwie adresu pozwanego nie budzi 
wątpliwości. 
**§ 2.** Powód w terminie dwóch miesięcy od dnia doręczenia mu zobowiązania, 
o którym mowa w § 1, składa do akt potwierdzenie doręczenia korespondencji 
pozwanemu za pośrednictwem komornika albo zwraca korespondencję wraz 
z dowodem na piśmie, że pozwany zamieszkuje pod adresem wskazanym 
w pozwie. Po bezskutecznym upływie terminu stosuje się przepis art. 177 § 1 pkt 6. 
**§ 3.** W przypadku wykazania przez powoda dowodem na piśmie, że pozwany 
zamieszkuje pod adresem wskazanym w pozwie, korespondencję przesłaną 
w sposób przewidziany w art. 139 § 1 uważa się za doręczoną. Późniejsze 
doręczenie tej korespondencji przez komornika na ten sam adres nie powoduje 
ponownego rozpoczęcia biegu terminów, które ustawa wiąże z doręczeniem, 
o czym należy pouczyć pozwanego przy tej czynności.

***
## Art. 1392. {#kpc-pierwsza-pierwsza-art-1392}

W przypadku, o którym mowa w art. 1391 § 1, jeżeli powód 
mieszka lub ma siedzibę za granicą i nie jest zastępowany przez adwokata, radcę 
prawnego lub rzecznika patentowego wykonującego zawód w Rzeczypospolitej 
Polskiej, sąd z urzędu nakazuje doręczenie korespondencji pozwanemu za 
pośrednictwem komornika. Przepis art. 1304 § 2 zdanie drugie stosuje się 
odpowiednio.

***
## Art. 140. {#kpc-pierwsza-pierwsza-art-140}

**§ 1.** Pisma i orzeczenia doręcza się w odpisach. 
**§ 2.** Zamiast odpisu pisma lub orzeczenia może być doręczony dokument 
uzyskany z systemu teleinformatycznego, o ile ma on cechy umożliwiające 
weryfikację istnienia i treści pisma lub orzeczenia w tym systemie. 
**§ 3.** W przypadku doręczenia elektronicznego pisma i orzeczenia mają postać 
dokumentów zawierających dane z systemu teleinformatycznego.

***
## Art. 141. {#kpc-pierwsza-pierwsza-art-141}

**§ 1.** Pełnomocnikowi procesowemu kilku osób doręcza się jeden 
egzemplarz pisma i załączników. 

 
 
 
s. 62/580 
 
2025-09-08 
**§ 2.** Uprawnionemu przez kilku współuczestników sporu do odbioru pism 
sądowych doręcza się po jednym egzemplarzu dla każdego współuczestnika. 
**§ 3.** Jeżeli jest kilku pełnomocników jednej strony, sąd doręcza pismo tylko 
jednemu z nich.

***
## Art. 142. {#kpc-pierwsza-pierwsza-art-142}

**§ 1.** Doręczenie pisma jest potwierdzane przez odbiorcę: 
- 1) pisemnie; 
- 2) za pośrednictwem systemu teleinformatycznego operatora pocztowego, 
o którym mowa w art. 131 § 1; 
- 3) dokumentem uzyskanym z systemu teleinformatycznego; 
- 4) dokumentem uzyskanym z portalu informacyjnego. 
**§ 2.** W przypadku potwierdzenia pisemnego odbiorca potwierdza odbiór 
i jego datę własnoręcznym podpisem. Jeżeli tego nie może lub nie chce uczynić, 
doręczający sam oznacza datę doręczenia oraz przyczyny braku podpisu. 
**§ 3.** Doręczający stwierdza na potwierdzeniu odbioru sposób doręczenia, a na 
doręczonym piśmie zaznacza dzień doręczenia i opatruje to stwierdzenie swoim 
podpisem.

***
## Art. 143. {#kpc-pierwsza-pierwsza-art-143}

Jeżeli stronie, której miejsce pobytu nie jest znane, ma być 
doręczony pozew lub inne pismo procesowe wywołujące potrzebę podjęcia obrony 
jej praw, doręczenie może do chwili zgłoszenia się strony albo jej przedstawiciela 
lub pełnomocnika nastąpić tylko do rąk kuratora ustanowionego na wniosek osoby 
zainteresowanej przez sąd orzekający.

***
## Art. 144. {#kpc-pierwsza-pierwsza-art-144}

**§ 1.** Przewodniczący ustanowi kuratora, jeżeli wnioskodawca 
uprawdopodobni, że miejsce pobytu strony nie jest znane. W sprawach o roszczenia 
alimentacyjne, jak również w sprawach o ustalenie pochodzenia dziecka 
i o związane z tym roszczenia, przewodniczący przed ustanowieniem kuratora 
przeprowadzi stosowne dochodzenie w celu ustalenia miejsca zamieszkania lub 
pobytu pozwanego. 
**§ 2.** O ustanowieniu kuratora przewodniczący ogłosi publicznie w budynku 
sądowym i lokalu wójta (burmistrza, prezydenta miasta), w sprawach zaś większej 
wagi, gdy uzna to za potrzebne, także w prasie. 

 
 
 
s. 63/580 
 
2025-09-08 
**§ 3.** Z chwilą doręczenia pisma kuratorowi doręczenie staje się skuteczne. Sąd 
może jednak uzależnić skuteczność doręczenia od upływu oznaczonego terminu od 
chwili wywieszenia obwieszczenia w budynku sądowym. 
**§ 4.** Czynności określone w § 1–3 może wykonywać także referendarz 
sądowy.

***
## Art. 145. {#kpc-pierwsza-pierwsza-art-145}

W wypadkach, w których ustanowienie kuratora według przepisów 
poprzedzających nie jest wymagane, pismo doręcza się stronie, której miejsce 
pobytu nie jest znane, przez wywieszenie w budynku sądowym. Doręczenie takie 
staje się skuteczne z upływem miesiąca od dnia wywieszenia.

***
## Art. 146. {#kpc-pierwsza-pierwsza-art-146}

Do kuratora ustanowionego zgodnie z art. 143 i art. 144 stosuje się 
odpowiednio przepis art. 69 § 3.

***
## Art. 147. {#kpc-pierwsza-pierwsza-art-147}

Gdy okaże się, że żądanie ustanowienia kuratora lub wywieszenia 
pisma nie było uzasadnione, sąd zarządzi doręczenie pisma w sposób właściwy, 
a w miarę potrzeby zniesie na wniosek strony zainteresowanej postępowanie 
przeprowadzone z udziałem kuratora lub po wywieszeniu pisma w budynku 
sądowym. 
Rozdział 3 
Posiedzenia sądowe

***
## Art. 148. {#kpc-pierwsza-pierwsza-art-148}

**§ 1.** Jeżeli przepis szczególny nie stanowi inaczej, posiedzenia 
sądowe są jawne, a sąd orzekający rozpoznaje sprawy na rozprawie. 
**§ 2.** Sąd może skierować sprawę na posiedzenie jawne i wyznaczyć rozprawę 
także wówczas, gdy sprawa podlega rozpoznaniu na posiedzeniu niejawnym. 
**§ 3.** Sąd może wydać postanowienie na posiedzeniu niejawnym.

***
## Art. 1481. {#kpc-pierwsza-pierwsza-art-1481}

**§ 1.** Sąd może rozpoznać sprawę na posiedzeniu niejawnym, gdy 
pozwany uznał powództwo lub gdy po złożeniu przez strony pism procesowych 
i dokumentów, w tym również po wniesieniu zarzutów lub sprzeciwu od nakazu 
zapłaty albo sprzeciwu od wyroku zaocznego, sąd uzna – mając na względzie 
całokształt przytoczonych twierdzeń i zgłoszonych wniosków dowodowych – że 
przeprowadzenie rozprawy nie jest konieczne. 
**§ 2.** (uchylony) 

 
 
 
s. 64/580 
 
2025-09-08 
**§ 3.** Przepisu § 1 nie stosuje się, jeżeli strona w pierwszym piśmie 
procesowym złożyła wniosek o wysłuchanie jej na rozprawie albo przepis 
szczególny przewiduje taki obowiązek, chyba że pozwany uznał powództwo.

***
## Art. 149. {#kpc-pierwsza-pierwsza-art-149}

**§ 1.** Posiedzenia sądowe wyznacza przewodniczący z urzędu, 
ilekroć wymaga tego stan sprawy. 
**§ 2.** O posiedzeniach jawnych zawiadamia się strony i osoby zainteresowane 
przez wezwanie lub ogłoszenie podczas posiedzenia. Stronie nieobecnej na 
posiedzeniu jawnym należy zawsze doręczyć wezwanie na następne posiedzenie. 
Wezwanie powinno być doręczone co najmniej na tydzień przed posiedzeniem. 
W wypadkach pilnych termin ten może być skrócony do trzech dni.

***
## Art. 1491. {#kpc-pierwsza-pierwsza-art-1491}

Sąd może wzywać strony, świadków, biegłych lub inne osoby 
w sposób, który uzna za najbardziej celowy, z pominięciem sposobów doręczeń 
przewidzianych w rozdziale 2, jeżeli uzna to za niezbędne do przyspieszenia 
rozpoznania sprawy. Wezwanie dokonane w ten sposób wywołuje skutki 
przewidziane w niniejszym kodeksie, jeżeli jest niewątpliwe, że doszło ono do 
wiadomości adresata w terminach określonych w art. 149 § 2.

***
## Art. 150. {#kpc-pierwsza-pierwsza-art-150}

W wezwaniu na posiedzenie oznacza się: 
- 1) imię, nazwisko i miejsce zamieszkania wezwanego; 
- 2) sąd oraz miejsce i czas posiedzenia, a także informację, czy wezwany może 
wziąć udział w posiedzeniu w sposób określony w art. 151 § 2; 
- 3) strony i przedmiot sprawy; 
- 4) cel posiedzenia; 
- 5) skutki niestawiennictwa.

***
## Art. 151. {#kpc-pierwsza-pierwsza-art-151}

**§ 1.** Posiedzenia sądowe odbywają się w budynku sądowym, a poza 
tym budynkiem tylko wówczas, gdy czynności sądowe muszą być wykonane 
w innym miejscu albo gdy odbycie posiedzenia poza budynkiem sądowym ułatwia 
przeprowadzenie sprawy lub przyczynia się znacznie do zaoszczędzenia kosztów. 
**§ 2.** Przewodniczący może zarządzić przeprowadzenie posiedzenia jawnego 
przy użyciu urządzeń technicznych umożliwiających jego przeprowadzenie na 
odległość (posiedzenie zdalne), jeżeli nie stoi temu na przeszkodzie wzgląd na 
charakter czynności, które mają być dokonane na posiedzeniu, a przeprowadzenie 
posiedzenia zdalnego zagwarantuje pełną ochronę praw procesowych stron 

 
 
 
s. 65/580 
 
2025-09-08 
 
i prawidłowy tok postępowania. W takim przypadku na sali sądowej przebywają 
sąd i protokolant, a pozostałe osoby uczestniczące w posiedzeniu nie muszą 
przebywać w budynku sądu prowadzącego postępowanie. Zapis obrazu i dźwięku 
z czynności procesowych odbywających się na sali sądowej przekazuje się do 
miejsca przebywania tych uczestników posiedzenia, którzy zgłosili zamiar 
zdalnego udziału w posiedzeniu sądu, oraz z miejsca przebywania tych 
uczestników posiedzenia do budynku sądu prowadzącego postępowanie. 
**§ 3.** Przewodniczący może zarządzić przeprowadzenie posiedzenia zdalnego 
z urzędu lub na wniosek osoby, która ma uczestniczyć w posiedzeniu i wskazała 
adres poczty elektronicznej. Termin do złożenia wniosku wynosi 7 dni od dnia 
doręczenia zawiadomienia albo wezwania na posiedzenie. Zarządzając 
przeprowadzenie posiedzenia zdalnego, przewodniczący może zastrzec, że 
określona osoba weźmie udział w posiedzeniu zdalnym poza budynkiem sądu 
prowadzącego postępowanie, jeżeli będzie przebywać w budynku innego sądu. 
O treści zarządzeń, o których mowa w zdaniach poprzedzających, w tym 
zmierzających do przeprowadzenia dowodu w sposób zdalny, o odmowie 
uwzględnienia wniosku lub zmianie zarządzeń w tym przedmiocie informuje się 
w sposób przewidziany w art. 1491. 
**§ 4.** Przewodniczący może zarządzić, że osoba pozbawiona wolności będzie 
uczestniczyć w czynnościach procesowych wyłącznie w ramach posiedzenia 
zdalnego. W takim przypadku w miejscu przebywania tej osoby bierze udział 
w posiedzeniu zdalnym przedstawiciel administracji zakładu karnego lub aresztu 
śledczego, pełnomocnik, jeżeli został ustanowiony, oraz tłumacz, jeżeli został 
powołany. Przepis powyższy stosuje się odpowiednio do osób objętych 
postępowaniem terapeutycznym na podstawie odrębnych przepisów. 
**§ 5.** Wzywając na posiedzenie zdalne, informuje się jego uczestników 
o możliwości stawiennictwa na sali sądowej lub zgłoszenia zamiaru zdalnego 
udziału w posiedzeniu, a także poucza się, że zamiar ten należy zgłosić najpóźniej 
na 3 dni robocze przed wyznaczonym terminem posiedzenia oraz że do 
skutecznego 
zgłoszenia 
wystarcza 
zachowanie 
formy 
określonej 
w art. 2261 pkt 2 lit. b, przy jednoczesnym wskazaniu adresu poczty elektronicznej. 
W takim przypadku informuje się także co najmniej na 24 godziny przed terminem 
posiedzenia o treści § 2, 3 oraz 6–8, adresie strony internetowej zawierającej 

 
 
 
s. 66/580 
 
2025-09-08 
 
obwieszczenie, o którym mowa w § 9, oraz o sposobie przyłączenia się do 
posiedzenia zdalnego. Obowiązek zgłoszenia zamiaru zdalnego udziału 
w posiedzeniu nie dotyczy osoby pozbawionej wolności. Powyższe stosuje się 
odpowiednio do uczestników zgłaszających swój udział w posiedzeniu 
w charakterze publiczności lub osób zaufania. 
**§ 6.** Osoba, która nie zgłosiła skutecznie wniosku, o którym mowa w § 3 
zdanie pierwsze, albo nie zgłosiła zamiaru zdalnego udziału w posiedzeniu zgodnie 
z § 5 zdanie pierwsze, ma obowiązek stawić się na posiedzeniu w budynku sądu 
prowadzącego postępowanie bez dodatkowego wezwania. 
**§ 7.** (uchylony) 
**§ 8.** Osoba biorąca udział w posiedzeniu zdalnym przebywająca poza 
budynkiem sądu jest zobowiązana poinformować sąd o miejscu, w którym 
przebywa, oraz dołożyć wszelkich starań, aby warunki w miejscu jej pobytu 
licowały z powagą sądu i nie stanowiły przeszkody do dokonania czynności 
procesowych z jej udziałem. W razie odmowy podania wskazanej informacji lub 
jeżeli zachowanie tej osoby budzi uzasadnione wątpliwości co do prawidłowego 
przebiegu czynności dokonanych zdalnie z jej udziałem, sąd może wezwać tę osobę 
do osobistego stawiennictwa na sali sądowej. 
**§ 9.** Minister Sprawiedliwości podaje, w drodze obwieszczenia, na stronie 
podmiotowej 
Biuletynu 
Informacji 
Publicznej 
informacje 
o standardach 
technicznych oprogramowania i wymaganiach sprzętowych niezbędnych do 
uczestniczenia w posiedzeniu zdalnym.

***
## Art. 152. {#kpc-pierwsza-pierwsza-art-152}

**§ 1.** Na posiedzenia jawne wstęp na salę sądową mają tylko osoby 
nieuzbrojone 
i pełnoletnie. 
Wymóg 
pełnoletności 
nie 
dotyczy 
stron, 
interwenientów ubocznych, ich przedstawicieli ustawowych i pełnomocników oraz 
osób wezwanych. 
**§ 2.** Przewodniczący może zezwolić na obecność na posiedzeniu jawnym 
osobom małoletnim oraz osobom obowiązanym do noszenia broni. 
**§ 3.** Na posiedzenia niejawne mają wstęp tylko osoby wezwane. 
**§ 4.** Przy czynnościach sądu nie mogą być obecne osoby w stanie 
nielicującym z powagą sądu. 

 
 
 
s. 67/580 
 
2025-09-08

***
## Art. 153. {#kpc-pierwsza-pierwsza-art-153}

**§ 1.** Sąd z urzędu zarządza odbycie całego posiedzenia lub jego 
części przy drzwiach zamkniętych, jeżeli publiczne rozpoznanie sprawy zagraża 
porządkowi publicznemu lub moralności lub jeżeli mogą być ujawnione okolicz-
ności objęte ochroną informacji niejawnych. 
**§ 11.** Sąd na wniosek strony zarządza odbycie posiedzenia lub jego części przy 
drzwiach zamkniętych, gdy mogą być ujawnione okoliczności stanowiące 
tajemnicę jej przedsiębiorstwa. 
**§ 2.** Sąd może ponadto zarządzić odbycie posiedzenia lub jego części przy 
drzwiach zamkniętych na wniosek strony, jeżeli podane przez nią przyczyny uzna 
za uzasadnione lub jeżeli roztrząsane być mają szczegóły życia rodzinnego. 
Postępowanie dotyczące tego wniosku odbywa się przy drzwiach zamkniętych. 
Postanowienie w tym przedmiocie sąd ogłasza publicznie.

***
## Art. 154. {#kpc-pierwsza-pierwsza-art-154}

**§ 1.** Podczas posiedzenia odbywającego się przy drzwiach 
zamkniętych mogą być obecni na sali: strony, interwenienci uboczni, ich 
przedstawiciele ustawowi i pełnomocnicy, prokurator oraz osoby zaufania po dwie 
z każdej strony. Przepisów o posiedzeniu zdalnym nie stosuje się, chyba że 
wszyscy uczestnicy czynności przebywają w budynkach sądowych. 
**§ 2.** Ogłoszenie orzeczenia kończącego postępowanie w sprawie odbywa się 
publicznie.

***
## Art. 155. {#kpc-pierwsza-pierwsza-art-155}

**§ 1.** Przewodniczący otwiera, prowadzi i zamyka posiedzenia, 
udziela głosu, zadaje pytania, upoważnia do zadawania pytań i ogłasza orzeczenia. 
**§ 2.** Przewodniczący może odebrać głos, gdy przemawiający go nadużywa, 
jak również uchylić pytanie, jeżeli uzna je za niewłaściwe lub zbyteczne.

***
## Art. 156. {#kpc-pierwsza-pierwsza-art-156}

Sąd nawet na zgodny wniosek stron może odroczyć posiedzenie 
tylko z ważnej przyczyny.

***
## Art. 1561. {#kpc-pierwsza-pierwsza-art-1561}

**§ 1.** W miarę potrzeby na posiedzeniu przewodniczący może 
pouczyć strony o prawdopodobnym wyniku sprawy w świetle zgłoszonych do tej 
chwili twierdzeń i dowodów. 
**§ 2.** Pouczenie, o którym mowa w § 1, może obejmować w szczególności 
wyrażenie poglądu co do: 
- 1) wykładni przepisów prawa mogących znaleźć zastosowanie w sprawie; 

 
 
 
s. 68/580 
 
2025-09-08 
- 2) faktów, które na danym etapie sprawy mogą zostać uznane za bezsporne lub 
dostatecznie wykazane.

***
## Art. 1562. {#kpc-pierwsza-pierwsza-art-1562}

Jeżeli w toku posiedzenia okaże się, że o żądaniu lub wniosku 
strony można rozstrzygnąć na innej podstawie prawnej, niż przez nią wskazana, 
uprzedza się o tym strony obecne na posiedzeniu.

***
## Art. 157. {#kpc-pierwsza-pierwsza-art-157}

**§ 1.** Z przebiegu posiedzenia jawnego protokolant sporządza 
protokół. Protokół sporządza się, utrwalając przebieg posiedzenia za pomocą 
urządzenia rejestrującego dźwięk albo obraz i dźwięk oraz pisemnie, pod 
kierunkiem przewodniczącego, zgodnie z art. 158 § 1. 
**§ 11.** Jeżeli ze względów technicznych utrwalenie przebiegu posiedzenia za 
pomocą urządzenia rejestrującego dźwięk albo obraz i dźwięk nie jest możliwe, 
protokół jest sporządzany wyłącznie pisemnie, pod kierunkiem przewodniczącego, 
zgodnie z art. 158 § 2. 
**§ 2.** Przy wydawaniu wyroków zaocznych wystarcza zaznaczenie w aktach, 
że pozwany nie stawił się na posiedzenie, nie żądał przeprowadzenia rozprawy 
w swej nieobecności i nie złożył żadnych wyjaśnień, oraz wzmianka co do 
ogłoszenia wyroku. 
**§ 3.** Z posiedzenia niejawnego sporządza się notatkę urzędową, jeżeli nie 
wydano orzeczenia.

***
## Art. 158. {#kpc-pierwsza-pierwsza-art-158}

**§ 1.** Protokół sporządzony pisemnie zawiera oznaczenie sądu, 
miejsca i daty posiedzenia, nazwiska sędziów, protokolanta, prokuratora, stron, 
interwenientów, jak również obecnych na posiedzeniu przedstawicieli ustawowych 
i pełnomocników oraz oznaczenie sprawy i wzmianki co do jawności. Ponadto 
protokół sporządzony pisemnie zawiera wymienienie zarządzeń i orzeczeń 
wydanych na posiedzeniu oraz stwierdzenie, czy zostały ogłoszone, streszczenie 
wyników postępowania dowodowego, a także czynności stron wpływające na 
rozstrzygnięcie sądu (ugoda, zrzeczenie się roszczenia, uznanie powództwa, 
cofnięcie, zmiana, rozszerzenie lub ograniczenie żądania pozwu) oraz inne 
czynności stron, które według szczególnych przepisów ustawy powinny być 
wciągnięte, wpisane, przyjęte, złożone, zgłoszone lub wniesione do protokołu. 
Jeżeli sporządzenie odrębnej sentencji orzeczenia nie jest wymagane, wystarcza 
zamieszczenie w protokole treści samego rozstrzygnięcia. Czynności wymagające 

 
 
 
s. 69/580 
 
2025-09-08 
 
podpisu strony mogą być zamieszczane w odrębnym dokumencie stanowiącym 
część protokołu. 
**§ 11.** Protokół, o którym mowa w § 1, może zawierać wnioski i twierdzenia 
stron oraz inne okoliczności istotne dla przebiegu posiedzenia; zamiast wniosków 
i twierdzeń można w protokole powołać się na pisma przygotowawcze. 
**§ 2.** Jeżeli przebiegu posiedzenia nie utrwala się za pomocą urządzenia 
rejestrującego dźwięk albo obraz i dźwięk, protokół sporządzony pisemnie zawiera, 
oprócz danych i okoliczności określonych w § 1, wnioski oraz twierdzenia stron, 
udzielone pouczenia, a także wyniki postępowania dowodowego oraz inne 
okoliczności istotne dla przebiegu posiedzenia; zamiast wniosków i twierdzeń 
można w protokole powołać się na pisma przygotowawcze. 
**§ 3.** Protokół sporządzony za pomocą urządzenia rejestrującego dźwięk albo 
obraz i dźwięk protokolant podpisuje podpisem elektronicznym gwarantującym 
identyfikację osoby protokolanta oraz rozpoznawalność jakiejkolwiek późniejszej 
zmiany protokołu. Protokół sporządzony pisemnie podpisują przewodniczący 
i protokolant. 
**§ 4.** Jeżeli jest to niezbędne dla zapewnienia prawidłowego orzekania 
w sprawie, 
przewodniczący 
może 
zarządzić 
sporządzenie 
transkrypcji 
odpowiedniej 
części 
protokołu 
sporządzonego 
za 
pomocą 
urządzenia 
rejestrującego dźwięk albo obraz i dźwięk. 
**§ 5.** Minister Sprawiedliwości określi, w drodze rozporządzenia, rodzaje 
urządzeń i środków technicznych służących do utrwalania dźwięku albo obrazu 
i dźwięku, sposób sporządzania zapisów dźwięku albo obrazu i dźwięku oraz 
sposób identyfikacji osób je sporządzających, jak również sposób udostępniania 
oraz przechowywania takich zapisów, mając na uwadze: 
- 1) konieczność właściwego zabezpieczenia zapisu dźwięku albo obrazu 
i dźwięku przed ich utratą, zniekształceniem, nieuprawnionym dostępem, 
usunięciem lub inną nieuprawnioną zmianą, a także rozpoznawalność 
dokonania uprawnionej zmiany lub usunięcia i identyfikacji osoby 
dokonującej tych czynności; 
- 2) minimalne wymagania dla systemów teleinformatycznych używanych do 
realizacji zadań publicznych, określone w odrębnych przepisach; 

 
 
 
s. 70/580 
 
2025-09-08 
- 3) konieczność zmiany formatu zapisu dźwięku albo obrazu i dźwięku lub 
przeniesienia na inny informatyczny nośnik danych w celu ponownego 
odtworzenia zapisu; 
- 4) konieczność zapewnienia możliwości zapoznania się z zapisem dźwięku albo 
obrazu i dźwięku oraz uzyskania z akt sprawy zapisu dźwięku albo obrazu 
i dźwięku.

***
## Art. 159. {#kpc-pierwsza-pierwsza-art-159}

(uchylony)

***
## Art. 160. {#kpc-pierwsza-pierwsza-art-160}

**§ 1.** Strony mogą żądać sprostowania lub uzupełnienia protokołu, 
nie później jednak jak na następnym posiedzeniu, a jeśli idzie o protokół rozprawy, 
po której zamknięciu nastąpiło wydanie wyroku – dopóki akta sprawy znajdują się 
w sądzie. Od zarządzenia przewodniczącego strony mogą odwołać się do sądu 
w terminie tygodniowym od doręczenia im zarządzenia. 
**§ 2.** Zapis dźwięku albo obrazu i dźwięku nie podlega sprostowaniu.

***
## Art. 161. {#kpc-pierwsza-pierwsza-art-161}

W toku 
posiedzenia 
wnioski, 
oświadczenia, 
uzupełnienia 
i sprostowania wniosków i oświadczeń można zamieścić w załączniku do 
protokołu. Jeżeli stronę zastępuje adwokat, radca prawny, rzecznik patentowy lub 
Prokuratoria Generalna Rzeczypospolitej Polskiej, przewodniczący może zażądać 
złożenia takiego załącznika w wyznaczonym terminie.

***
## Art. 162. {#kpc-pierwsza-pierwsza-art-162}

**§ 1.** Strona powinna zwrócić uwagę sądu na uchybienie przepisom 
postępowania, wnosząc o wpisanie zastrzeżenia do protokołu. Zastrzeżenie można 
zgłosić najpóźniej na kolejnym posiedzeniu. 
**§ 2.** Stronie zastępowanej przez adwokata, radcę prawnego, rzecznika 
patentowego lub Prokuratorię Generalną Rzeczypospolitej Polskiej, która 
zastrzeżenia nie zgłosiła, nie przysługuje prawo powoływania się na to uchybienie 
w dalszym toku postępowania. Skutku tego nie niweczy wypowiedzenie lub 
cofnięcie pełnomocnictwa. 
**§ 3.** Przepisu § 2 nie stosuje się, gdy chodzi o przepisy postępowania, których 
naruszenie sąd powinien wziąć pod rozwagę z urzędu lub gdy strona 
uprawdopodobni, iż nie zgłosiła zastrzeżeń bez swojej winy.

***
## Art. 1621. {#kpc-pierwsza-pierwsza-art-1621}

(uchylony) 

 
 
 
s. 71/580 
 
2025-09-08

***
## Art. 163. {#kpc-pierwsza-pierwsza-art-163}

**§ 1.** Jeżeli kodeks przewiduje grzywnę bez określenia jej 
wysokości, grzywnę wymierza się w kwocie do trzech tysięcy złotych. Grzywny 
ściąga się w drodze egzekucji sądowej na rzecz Skarbu Państwa. 
**§ 2.** Ilekroć kodeks dopuszcza zarządzenie przymusowego sprowadzenia lub 
aresztowania, stosuje się odpowiednio przepisy kodeksu postępowania karnego. 
**§ 3.** O przymusowe sprowadzenie żołnierza w czynnej służbie wojskowej, z 
wyjątkiem terytorialnej służby wojskowej pełnionej dyspozycyjnie, sąd zwraca się 
do dowódcy jednostki wojskowej, w której pełni on służbę, lub do Żandarmerii 
Wojskowej, a o przymusowe sprowadzenie funkcjonariusza Policji, Służby 
Ochrony Państwa, Agencji Bezpieczeństwa Wewnętrznego, Agencji Wywiadu, 
Służby Kontrwywiadu Wojskowego, Służby Wywiadu Wojskowego, Centralnego 
Biura Antykorupcyjnego lub Straży Granicznej – do jego przełożonego. 
**§ 4.** O ukaranie żołnierza w czynnej służbie wojskowej, z wyjątkiem 
terytorialnej służby wojskowej pełnionej dyspozycyjnie, sąd występuje do 
dowódcy jednostki wojskowej, w której pełni on służbę, a o ukaranie 
funkcjonariusza Policji, Służby Ochrony Państwa, Agencji Bezpieczeństwa 
Wewnętrznego, Agencji Wywiadu, Służby Kontrwywiadu Wojskowego, Służby 
Wywiadu 
Wojskowego, 
Centralnego 
Biura 
Antykorupcyjnego, 
Straży 
Marszałkowskiej lub Straży Granicznej – do jego przełożonego. 
Rozdział 4 
Terminy

***
## Art. 164. {#kpc-pierwsza-pierwsza-art-164}

Bieg terminu wyznaczonego przez sąd lub przewodniczącego 
(termin sądowy) rozpoczyna się od ogłoszenia w tym przedmiocie postanowienia 
lub zarządzenia, a gdy kodeks przewiduje doręczenie z urzędu – od jego 
doręczenia.

***
## Art. 165. {#kpc-pierwsza-pierwsza-art-165}

**§ 1.** Terminy oblicza się według przepisów prawa cywilnego. 
**§ 2.** Oddanie 
pisma 
procesowego 
w polskiej 
placówce 
operatora 
świadczącego pocztowe usługi powszechne na terytorium Rzeczypospolitej 
Polskiej albo w zagranicznej placówce pocztowej operatora świadczącego 
pocztowe usługi powszechne na terytorium innego państwa członkowskiego Unii 
Europejskiej jest równoznaczne z wniesieniem tego pisma do sądu. 

 
 
 
s. 72/580 
 
2025-09-08 
**§ 3.** To samo dotyczy złożenia pisma przez żołnierza w dowództwie jednostki 
wojskowej albo przez osobę pozbawioną wolności w administracji zakładu karnego 
oraz przez członka załogi polskiego statku morskiego u kapitana statku. 
[§ 4. Wprowadzenie 
pisma 
do 
systemu 
teleinformatycznego 
jest 
równoznaczne z wniesieniem pisma do sądu.] 
<§ 4. Wprowadzenie pisma procesowego do systemu teleinformatycznego 
lub jego umieszczenie w portalu informacyjnym i otrzymanie przez 
wnoszącego dokumentu w postaci elektronicznej potwierdzającego wniesienie 
pisma do sądu jest równoznaczne z wniesieniem tego pisma do sądu, jeżeli 
przepis szczególny przewiduje taki sposób wniesienia pisma procesowego. 
Pismo procesowe uważa się za wniesione do sądu z chwilą określoną 
w elektronicznym potwierdzeniu wniesienia tego pisma do sądu.>

***
## Art. 166. {#kpc-pierwsza-pierwsza-art-166}

Przewodniczący może z ważnej przyczyny przedłużyć lub skrócić 
termin sądowy na wniosek zgłoszony przed upływem terminu, nawet bez 
wysłuchania strony przeciwnej. 
Rozdział 5 
Uchybienie i przywrócenie terminu

***
## Art. 167. {#kpc-pierwsza-pierwsza-art-167}

Czynność procesowa podjęta przez stronę po upływie terminu jest 
bezskuteczna.

***
## Art. 168. {#kpc-pierwsza-pierwsza-art-168}

**§ 1.** Jeżeli strona nie dokonała w terminie czynności procesowej bez 
swojej winy, sąd na jej wniosek postanowi przywrócenie terminu. 
**§ 2.** Przywrócenie nie jest dopuszczalne, jeżeli uchybienie terminu nie 
pociąga za sobą ujemnych dla strony skutków procesowych.

***
## Art. 169. {#kpc-pierwsza-pierwsza-art-169}

**§ 1.** Pismo z wnioskiem o przywrócenie terminu wnosi się do sądu, 
w którym czynność miała być dokonana, w ciągu tygodnia od czasu ustania 
przyczyny uchybienia terminu. 
**§ 2.** W piśmie tym należy uprawdopodobnić okoliczności uzasadniające 
wniosek. 
**§ 3.** Równocześnie z wnioskiem strona powinna dokonać czynności 
procesowej. 
Nowe brzmienie 
§ 4 w art. 165 
wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 

 
 
 
s. 73/580 
 
2025-09-08 
**§ 4.** Po upływie roku od uchybionego terminu, jego przywrócenie jest 
dopuszczalne tylko w wypadkach wyjątkowych. 
**§ 5.** (uchylony)

***
## Art. 170. {#kpc-pierwsza-pierwsza-art-170}

Niedopuszczalne jest przywrócenie terminu do złożenia środka 
odwoławczego od wyroku orzekającego unieważnienie małżeństwa lub rozwód 
albo ustalającego nieistnienie małżeństwa, jeżeli choćby jedna ze stron zawarła 
po uprawomocnieniu się wyroku nowy związek małżeński.

***
## Art. 171. {#kpc-pierwsza-pierwsza-art-171}

Spóźniony 
lub 
z mocy 
ustawy 
niedopuszczalny 
wniosek 
o przywrócenie terminu sąd odrzuca.

***
## Art. 172. {#kpc-pierwsza-pierwsza-art-172}

Zgłoszenie wniosku o przywrócenie terminu nie wstrzymuje 
postępowania w sprawie ani wykonania orzeczenia. Sąd może jednak, stosownie 
do okoliczności, wstrzymać postępowanie lub wykonanie orzeczenia. W przypadku 
uwzględnienia wniosku sąd może natychmiast przystąpić do rozpoznania sprawy. 
Rozdział 6 
Zawieszenie postępowania

***
## Art. 173. {#kpc-pierwsza-pierwsza-art-173}

Postępowanie 
ulega 
zawieszeniu 
z mocy 
prawa 
w razie 
zaprzestania czynności przez sąd wskutek siły wyższej.

***
## Art. 174. {#kpc-pierwsza-pierwsza-art-174}

**§ 1.** Sąd zawiesza postępowanie z urzędu: 
- 1) w razie śmierci strony lub jej przedstawiciela ustawowego, utraty przez nich 
zdolności procesowej, utraty przez stronę zdolności sądowej lub utraty przez 
przedstawiciela ustawowego charakteru takiego przedstawiciela; 
- 2) jeżeli w składzie organów jednostki organizacyjnej będącej stroną zachodzą 
braki uniemożliwiające jej działanie, chyba że ustanowiono kuratora na 
podstawie art. 69 § 1 lub art. 42 § 1 Kodeksu cywilnego; 
- 3) jeżeli strona lub jej przedstawiciel ustawowy znajduje się w miejscowości 
pozbawionej wskutek nadzwyczajnych wydarzeń komunikacji z siedzibą 
sądu; 
- 4) jeżeli postępowanie dotyczy masy upadłości, masy układowej lub masy 
sanacyjnej i ogłoszono upadłość lub wszczęto wtórne postępowanie 
upadłościowe 
albo 
ustanowiono 
zarządcę 
w postępowaniu 
restrukturyzacyjnym; 

 
 
 
s. 74/580 
 
2025-09-08 
- 5) jeżeli ustanowiono zarządcę przymusowego w postępowaniu w przedmiocie 
ogłoszenia upadłości lub zarządcę tymczasowego w postępowaniu o otwarcie 
postępowania sanacyjnego, a postępowanie dotyczy majątku objętego 
zabezpieczeniem; 
- 6) jeżeli zarządca sukcesyjny przestał pełnić tę funkcję albo zarząd sukcesyjny 
wygasł, w przypadku gdy postępowanie toczyło się z udziałem zarządcy 
sukcesyjnego. 
**§ 2.** W przypadkach wymienionych w § 1 pkt 1, 4 i 6 zawieszenie ma skutek 
od chwili zdarzeń, które je spowodowały. Zawieszając postępowanie, sąd z urzędu 
uchyla orzeczenia wydane po nastąpieniu tych zdarzeń, chyba że nastąpiły one po 
zamknięciu rozprawy. 
**§ 3.** W przypadkach, o których mowa w § 1 pkt 4 i 5, sąd wezwie syndyka, 
zarządcę przymusowego, zarządcę tymczasowego albo zarządcę do udziału 
w sprawie.

***
## Art. 175. {#kpc-pierwsza-pierwsza-art-175}

W razie śmierci pełnomocnika procesowego postępowanie może 
toczyć się dalej dopiero po wezwaniu strony niestawającej. Wezwanie doręcza się 
stronie w miejscu jej rzeczywistego zamieszkania, zawiadamiając ją równocześnie 
o śmierci pełnomocnika procesowego. W wypadku tym nie stosuje się art. 136 § 2.

***
## Art. 1751. {#kpc-pierwsza-pierwsza-art-1751}

Jeżeli zastępstwo stron przez adwokatów lub radców prawnych jest 
obowiązkowe, w razie śmierci adwokata lub radcy prawnego, skreślenia z listy 
adwokatów lub radców prawnych, utraty możliwości wykonywania zawodu albo 
utraty zdolności procesowej, sąd zawiesza postępowanie z urzędu, wyznaczając 
odpowiedni termin do wskazania innego adwokata lub radcy prawnego, i po 
upływie tego terminu podejmuje postępowanie. Przepis art. 175 stosuje się 
odpowiednio.

***
## Art. 176. {#kpc-pierwsza-pierwsza-art-176}

**§ 1.** Sąd zawiesi postępowanie na wniosek spadkobiercy, jeżeli 
powód dochodzi przeciwko niemu wykonania obowiązku, należącego do długów 
spadkowych, a spadkobierca nie złożył jeszcze oświadczenia o przyjęciu spadku 
i termin do złożenia takiego oświadczenia jeszcze nie upłynął. 
**§ 2.** Sąd zawiesi na wniosek Bankowego Funduszu Gwarancyjnego 
postępowanie, w którym podmiot w restrukturyzacji, o którym mowa w art. 2 
pkt 44 ustawy z dnia 10 czerwca 2016 r. o Bankowym Funduszu Gwarancyjnym, 

 
 
 
s. 75/580 
 
2025-09-08 
 
systemie gwarantowania depozytów oraz przymusowej restrukturyzacji (Dz. U. z 
2024 r. poz. 487), jest stroną.

***
## Art. 177. {#kpc-pierwsza-pierwsza-art-177}

**§ 1.** Sąd może zawiesić postępowanie z urzędu: 
- 1) jeżeli rozstrzygnięcie sprawy zależy od wyniku innego toczącego się 
postępowania cywilnego; 
- 2) jeżeli osoba trzecia wystąpiła przeciwko obu stronom z interwencją główną; 
- 3) jeżeli rozstrzygnięcie sprawy zależy od uprzedniej decyzji organu 
administracji publicznej; 
- 31) jeżeli rozstrzygnięcie sprawy zależy od wyniku postępowania toczącego się 
przed Trybunałem Konstytucyjnym albo Trybunałem Sprawiedliwości Unii 
Europejskiej; 
- 4) jeżeli ujawni się czyn, którego ustalenie w drodze karnej lub dyscyplinarnej 
mogłoby wywrzeć wpływ na rozstrzygnięcie sprawy cywilnej; 
- 5) w razie niestawiennictwa obu stron na rozprawie, jeżeli ustawa nie stanowi 
inaczej, oraz w razie niestawiennictwa powoda, gdy powód nie żądał 
rozpoznania sprawy w jego nieobecności, a pozwany nie zgłosił wniosku o 
rozpoznanie sprawy; 
- 6) jeżeli na skutek braku lub wskazania złego adresu powoda albo niewskazania 
przez powoda w wyznaczonym terminie adresu pozwanego lub danych 
pozwalających sądowi na ustalenie numerów, o których mowa w art. 2081, lub 
niewykonania przez powoda innych zarządzeń nie można nadać sprawie 
dalszego biegu. 
**§ 2.** Jeżeli postępowanie karne, dyscyplinarne lub administracyjne nie jest 
jeszcze rozpoczęte, a jego rozpoczęcie zależy od wniosku strony, sąd wyznaczy 
termin do wszczęcia postępowania, w innych wypadkach może zwrócić się do 
właściwego organu.

***
## Art. 178. {#kpc-pierwsza-pierwsza-art-178}

Sąd może również zawiesić postępowanie na zgodny wniosek stron.

***
## Art. 1781. {#kpc-pierwsza-pierwsza-art-1781}

W postanowieniu o zawieszeniu postępowania wskazuje się 
przepis stanowiący podstawę prawną rozstrzygnięcia.

***
## Art. 179. {#kpc-pierwsza-pierwsza-art-179}

**§ 1.** W wypadku zawieszenia postępowania na zgodny wniosek 
stron albo wskutek ich niestawiennictwa lub niemożności nadania sprawie dalszego 

 
 
 
s. 76/580 
 
2025-09-08 
 
biegu, zawieszenie wstrzymuje tylko bieg terminów sądowych, które biegną dalej 
dopiero z chwilą podjęcia postępowania. 
**§ 2.** We wszystkich innych wypadkach zawieszenia żadne terminy nie biegną 
i zaczynają biec dopiero od początku z chwilą podjęcia postępowania. Terminy 
sądowe należy w miarę potrzeby wyznaczać na nowo. 
**§ 3.** Podczas zawieszenia sąd nie podejmuje żadnych czynności z wyjątkiem 
tych, które mają na celu podjęcie postępowania albo zabezpieczenie powództwa 
lub dowodu. Czynności podejmowane przez strony, a niedotyczące tych 
przedmiotów, wywołują skutki dopiero z chwilą podjęcia postępowania.

***
## Art. 180. {#kpc-pierwsza-pierwsza-art-180}

**§ 1.** Sąd postanowi podjąć postępowanie z urzędu, gdy ustanie 
przyczyna zawieszenia, w szczególności: 
- 1) w razie śmierci strony – z chwilą zgłoszenia się lub wskazania następców 
prawnych zmarłego albo z chwilą ustanowienia we właściwej drodze kuratora 
spadku; 
- 2) w razie utraty zdolności sądowej – z chwilą ustalenia ogólnego następcy 
prawnego; 
- 3) w razie braku przedstawiciela ustawowego – z chwilą jego ustanowienia; 
- 31) w razie braku w składzie organów jednostki organizacyjnej będącej stroną – 
z chwilą wyboru albo powołania tego organu, a w przypadku gdy dla strony 
ustanowiono kuratora umocowanego do podejmowania czynności za stronę – 
z chwilą jego ustanowienia; 
- 4) gdy rozstrzygnięcie sprawy zależy od wyniku innego postępowania – z chwilą 
uprawomocnienia się orzeczenia kończącego to postępowanie; sąd może 
jednak i przedtem, stosownie do okoliczności, podjąć dalsze postępowanie; 
- 5) w przypadku: 
  - a) ustanowienia zarządcy przymusowego w postępowaniu w przedmiocie 
ogłoszenia upadłości – z chwilą ustalenia osoby pełniącej funkcję 
zarządcy przymusowego, 
  - b) ogłoszenia upadłości strony lub wszczęcia wtórnego postępowania 
upadłościowego, z wyjątkiem określonym w art. 145 ust. 1 ustawy z dnia 
28 lutego 2003 r. – Prawo upadłościowe (Dz. U. z 2024 r. poz. 794 i 
- 1222) – z chwilą ustalenia osoby pełniącej funkcję syndyka, 

 
 
 
s. 77/580 
 
2025-09-08 
  - c) ustanowienia zarządcy tymczasowego w postępowaniu o otwarcie 
postępowania sanacyjnego – z chwilą ustalenia osoby pełniącej funkcję 
zarządcy tymczasowego, 
  - d) ustanowienia zarządcy w postępowaniu restrukturyzacyjnym – z chwilą 
ustalenia osoby pełniącej funkcję zarządcy; 
- 6) jeżeli zarządca sukcesyjny, z którego udziałem toczyło się postępowanie, 
przestał pełnić tę funkcję – z dniem zgłoszenia się lub wskazania kolejnego 
zarządcy sukcesyjnego; 
- 7) w przypadku wygaśnięcia zarządu sukcesyjnego – z dniem zgłoszenia się lub 
wskazania następców prawnych zmarłego. 
**§ 2.** Jeżeli w ciągu roku od dnia postanowienia o zawieszeniu postępowania 
nie zgłoszą się lub nie zostaną wskazani następcy prawni zmarłego, a postępowanie 
nie zostanie podjęte z udziałem zarządcy sukcesyjnego, sąd może z urzędu zwrócić 
się do sądu spadku o ustanowienie kuratora spadku, chyba że kurator taki już 
wcześniej został ustanowiony.

***
## Art. 181. {#kpc-pierwsza-pierwsza-art-181}

**§ 1.** Sąd postanowi podjąć postępowanie na wniosek którejkolwiek 
ze stron: 
- 1) gdy postępowanie zostało zawieszone na wniosek spadkobiercy – po złożeniu 
oświadczenia o przyjęciu lub odrzuceniu spadku albo po upływie terminu do 
złożenia takiego oświadczenia; 
- 2) w przypadku zawieszenia postępowania na wniosek obu stron – nie wcześniej 
niż po upływie trzech miesięcy od daty wydania postanowienia o zawieszeniu 
postępowania, jeżeli strony we wniosku o zawieszenie nie oznaczyły 
dłuższego terminu; 
- 3) gdy postępowanie zostało zawieszone wskutek niestawiennictwa stron. 
**§ 2.** Sąd, na wniosek Bankowego Funduszu Gwarancyjnego, podejmie 
postępowanie, o którym mowa w art. 176 § 2.

***
## Art. 1811. {#kpc-pierwsza-pierwsza-art-1811}

Na wniosek zarządcy sukcesyjnego lub drugiej strony sąd 
postanowi podjąć postępowanie z udziałem zarządcy sukcesyjnego, jeżeli 
postępowanie dotyczy spraw wynikających z prowadzenia przedsiębiorstwa 
zmarłej strony objętego zarządem sukcesyjnym.

***
## Art. 182. {#kpc-pierwsza-pierwsza-art-182}

**§ 1.** Sąd umarza postępowanie: 

 
 
 
s. 78/580 
 
2025-09-08 
- 1) zawieszone z przyczyn wskazanych w art. 177 § 1 pkt 5 i 6, jeżeli wniosek 
o podjęcie postępowania nie został zgłoszony w ciągu trzech miesięcy od daty 
postanowienia o zawieszeniu postępowania; 
- 2) zawieszone na zgodny wniosek stron lub na wniosek spadkobiercy, jeżeli 
wniosek o podjęcie postępowania nie został zgłoszony w ciągu sześciu 
miesięcy od daty postanowienia o zawieszeniu postępowania; 
- 3) w przypadku stwierdzenia braku następcy prawnego strony, która utraciła 
zdolność sądową, a w każdym razie po upływie roku od daty postanowienia 
o zawieszeniu postępowania z tej przyczyny; 
- 4) zawieszone z przyczyny wskazanej w art. 174 § 1 pkt 2 po upływie dwóch lat 
od daty postanowienia o zawieszeniu postępowania z tej przyczyny; 
- 5) zawieszone z powodu śmierci strony po upływie pięciu lat od daty 
postanowienia o zawieszeniu postępowania z tej przyczyny. 
**§ 2.** Umorzenie postępowania zawieszonego w pierwszej instancji nie 
pozbawia powoda prawa ponownego wytoczenia powództwa, jednakże poprzedni 
pozew nie wywołuje żadnych skutków, które ustawa wiąże z wytoczeniem 
powództwa. Skutki te wywołuje jednak pozew wniesiony w sprawie, w której 
postępowanie umorzono na podstawie § 1 pkt 4. 
**§ 3.** Umorzenie zawieszonego postępowania przez sąd wyższej instancji 
powoduje uprawomocnienie się zaskarżonego orzeczenia, z wyjątkiem spraw 
o unieważnienie małżeństwa lub o rozwód oraz o ustalenie nieistnienia 
małżeństwa, w których postępowanie umarza się wówczas w całości. 
**§ 4.** Z umorzeniem postępowania umarzają się nawzajem także koszty stron 
w danej instancji.

***
## Art. 1821. {#kpc-pierwsza-pierwsza-art-1821}

(uchylony)

***
## Art. 183. {#kpc-pierwsza-pierwsza-art-183}

(uchylony) 

 
 
 
s. 79/580 
 
2025-09-08 
#### DZIAŁ II
Postępowanie przed sądami pierwszej instancji 
Rozdział 1 
Mediacja i postępowanie pojednawcze 
Oddział 1 
Mediacja

***
## Art. 1831. {#kpc-pierwsza-pierwsza-art-1831}

**§ 1.** Mediacja jest dobrowolna. 
**§ 2.** Mediację prowadzi się na podstawie umowy o mediację albo 
postanowienia sądu kierującego strony do mediacji. Umowa może być zawarta 
także przez wyrażenie przez stronę zgody na mediację, gdy druga strona złożyła 
wniosek, o którym mowa w art. 1836 § 1. 
**§ 3.** W umowie o mediację strony określają w szczególności przedmiot 
mediacji, osobę mediatora albo sposób wyboru mediatora. 
**§ 4.** Mediację prowadzi się przed wszczęciem postępowania, a za zgodą stron 
także w toku sprawy.

***
## Art. 1832. {#kpc-pierwsza-pierwsza-art-1832}

**§ 1.** Mediatorem może być osoba fizyczna mająca pełną zdolność 
do czynności prawnych, korzystająca w pełni z praw publicznych. 
**§ 2.** Mediatorem nie może być sędzia. Nie dotyczy to sędziów w stanie 
spoczynku. 
**§ 3.** Organizacje pozarządowe w zakresie swoich zadań statutowych oraz 
uczelnie mogą prowadzić listy mediatorów oraz tworzyć ośrodki mediacyjne. Wpis 
na listę wymaga wyrażonej na piśmie zgody mediatora. Informację o listach 
mediatorów oraz ośrodkach mediacyjnych przekazuje się prezesowi sądu 
okręgowego. 
**§ 31.** Ilekroć w dalszych przepisach niniejszego kodeksu jest mowa 
o mediatorze, należy przez to rozumieć także stałego mediatora, chyba że przepisy 
niniejszego kodeksu stanowią inaczej. 
**§ 4.** Stały mediator może odmówić prowadzenia mediacji tylko z ważnych 
powodów, o których jest obowiązany niezwłocznie powiadomić strony, a jeżeli 
strony do mediacji skierował sąd – również sąd. 

 
 
 
s. 80/580 
 
2025-09-08

***
## Art. 1833. {#kpc-pierwsza-pierwsza-art-1833}

**§ 1.** Mediator powinien zachować bezstronność przy prowadzeniu 
mediacji. 
**§ 2.** Mediator niezwłocznie ujawnia stronom okoliczności, które mogłyby 
wzbudzić wątpliwości co do jego bezstronności.

***
## Art. 1833a. {#kpc-pierwsza-pierwsza-art-1833a}

Mediator prowadzi mediację, wykorzystując różne metody 
zmierzające do polubownego rozwiązania sporu, w tym poprzez wspieranie stron 
w formułowaniu przez nie propozycji ugodowych, lub na zgodny wniosek stron 
może wskazać sposoby rozwiązania sporu, które nie są dla stron wiążące.

***
## Art. 1834. {#kpc-pierwsza-pierwsza-art-1834}

**§ 1.** Postępowanie mediacyjne nie jest jawne. 
**§ 2.** Mediator, strony i inne osoby biorące udział w postępowaniu 
mediacyjnym są obowiązane zachować w tajemnicy fakty, o których dowiedziały 
się w związku z prowadzeniem mediacji. Strony mogą zwolnić mediatora i inne 
osoby biorące udział w postępowaniu mediacyjnym z tego obowiązku. 
**§ 3.** Bezskuteczne jest powoływanie się w toku postępowania przed sądem lub 
sądem polubownym na propozycje ugodowe, propozycje wzajemnych ustępstw lub 
inne oświadczenia składane w postępowaniu mediacyjnym.

***
## Art. 1835. {#kpc-pierwsza-pierwsza-art-1835}

**§ 1.** Mediator ma prawo do wynagrodzenia i zwrotu wydatków 
związanych z przeprowadzeniem mediacji, chyba że wyraził zgodę na prowadzenie 
mediacji bez wynagrodzenia. Wynagrodzenie i zwrot wydatków obciążają strony. 
**§ 2.** Należności, o których mowa w § 1, mediator pobiera bezpośrednio od 
stron. 
**§ 3.** Należności, o których mowa w § 1, w części niewypłaconej przez strony, 
na wniosek mediatora ustala i przyznaje mediatorowi sąd. We wniosku mediator 
wskazuje wysokość niewypłaconych należności i zamieszcza oświadczenie o ich 
niewypłaceniu. 
**§ 4.** Przed przystąpieniem do postępowania mediacyjnego mediator poucza 
strony o kosztach postępowania mediacyjnego i sposobie pobrania należności 
mediatora.

***
## Art. 1836. {#kpc-pierwsza-pierwsza-art-1836}

**§ 1.** Wszczęcie mediacji przez stronę następuje z chwilą doręczenia 
mediatorowi wniosku o przeprowadzenie mediacji, z dołączonym dowodem 
doręczenia jego odpisu drugiej stronie. 

 
 
 
s. 81/580 
 
2025-09-08 
**§ 2.** Mimo doręczenia wniosku, o którym mowa w § 1, mediacja nie zostaje 
wszczęta, jeżeli: 
- 1) stały mediator, w terminie tygodnia od dnia doręczenia mu wniosku 
o przeprowadzenie mediacji, odmówił przeprowadzenia mediacji; 
- 2) strony zawarły umowę o mediację, w której wskazano jako mediatora osobę 
niebędącą stałym mediatorem, a osoba ta, w terminie tygodnia od dnia 
doręczenia 
jej 
wniosku 
o przeprowadzenie 
mediacji, 
odmówiła 
przeprowadzenia mediacji; 
- 3) strony zawarły umowę o mediację bez wskazania mediatora i osoba, do której 
strona zwróciła się o przeprowadzenie mediacji, w terminie tygodnia od dnia 
doręczenia jej wniosku o przeprowadzenie mediacji, nie wyraziła zgody na 
przeprowadzenie mediacji albo druga strona w terminie tygodnia nie wyraziła 
zgody na osobę mediatora; 
- 4) strony nie zawarły umowy o mediację, a druga strona nie wyraziła zgody na 
mediację. 
**§ 3.** Jeżeli w przypadkach, o których mowa w § 2, strona wytoczy powództwo 
o roszczenie, które było objęte wnioskiem o przeprowadzenie mediacji, w terminie 
trzech miesięcy od dnia: 
- 1) w którym mediator lub druga strona złożyli oświadczenie powodujące, że 
mediacja nie została wszczęta albo 
- 2) następnego 
po 
upływie 
tygodnia 
od 
dnia 
doręczenia 
wniosku 
o przeprowadzenie mediacji, gdy mediator lub druga strona nie złożyli 
oświadczenia, o którym mowa w pkt 1 
– do chwili wytoczenia powództwa, w odniesieniu do tego roszczenia, zostają 
zachowane skutki przewidziane dla czasu trwania mediacji.

***
## Art. 1837. {#kpc-pierwsza-pierwsza-art-1837}

Wniosek o przeprowadzenie mediacji zawiera oznaczenie stron, 
dokładnie określone żądanie, przytoczenie okoliczności uzasadniających żądanie, 
podpis strony oraz wymienienie załączników. Jeżeli strony zawarły umowę 
o mediację na piśmie, do wniosku dołącza się odpis tej umowy.

***
## Art. 1838. {#kpc-pierwsza-pierwsza-art-1838}

**§ 1.** Sąd może skierować strony do mediacji na każdym etapie 
postępowania. Postanowienia o skierowaniu stron do mediacji, zmianie mediatora 

 
 
 
s. 82/580 
 
2025-09-08 
 
lub przedłużeniu terminu na przeprowadzenie mediacji może wydać referendarz 
sądowy. 
**§ 2.** Mediacji nie prowadzi się, jeżeli strona sprzeciwi się jej w terminie 
tygodnia od dnia ogłoszenia lub doręczenia jej postanowienia kierującego strony 
do mediacji, chyba że przed wydaniem postanowienia wyraziła zgodę na 
prowadzenie mediacji. 
**§ 3.** Przepisu 
§ 1 nie 
stosuje 
się 
w sprawach 
rozpoznawanych 
w postępowaniach upominawczym oraz nakazowym, chyba że doszło do 
skutecznego wniesienia zarzutów. 
**§ 4.** Przewodniczący lub referendarz sądowy może wezwać strony do udziału 
w spotkaniu informacyjnym dotyczącym polubownych metod rozwiązywania 
sporów, w szczególności mediacji. Spotkanie informacyjne może prowadzić 
sędzia, referendarz sądowy, urzędnik sądowy, asystent sędziego lub stały mediator. 
**§ 5.** Przed 
pierwszym 
posiedzeniem 
wyznaczonym 
na 
rozprawę 
przewodniczący dokonuje oceny, czy skierować strony do mediacji. W tym celu 
przewodniczący, jeżeli zachodzi potrzeba wysłuchania stron, może wezwać je do 
osobistego stawiennictwa na posiedzeniu niejawnym. 
**§ 6.** Jeżeli strona bez uzasadnienia nie stawi się na spotkanie informacyjne lub 
posiedzenie niejawne, sąd może obciążyć ją kosztami nakazanego stawiennictwa 
poniesionymi przez stronę przeciwną.

***
## Art. 1839. {#kpc-pierwsza-pierwsza-art-1839}

**§ 1.** Jeżeli strony nie dokonały wyboru osoby mediatora, sąd, 
kierując strony do mediacji, wyznacza mediatora mającego odpowiednią wiedzę 
i umiejętności w zakresie prowadzenia mediacji w sprawach danego rodzaju, 
biorąc pod uwagę w pierwszej kolejności stałych mediatorów. 
**§ 2.** Mediator ma prawo do zapoznania się z aktami sprawy, chyba że strona 
w terminie tygodnia od dnia ogłoszenia lub doręczenia postanowienia kierującego 
strony do mediacji nie wyrazi zgody na zapoznanie się mediatora z aktami. 
**§ 3.** Przewodniczący niezwłocznie przekazuje mediatorowi w uzgodniony 
z nim sposób dane kontaktowe stron oraz ich pełnomocników, obejmujące adres 
korespondencyjny, numer telefonu lub adres poczty elektronicznej, jeżeli znajdują 
się w aktach sądowych. 

 
 
 
s. 83/580 
 
2025-09-08

***
## Art. 18310. {#kpc-pierwsza-pierwsza-art-18310}

**§ 1.** Kierując strony do mediacji, sąd wyznacza czas jej trwania na 
okres do trzech miesięcy. Na zgodny wniosek stron lub z innych ważnych 
powodów termin na przeprowadzenie mediacji może zostać przedłużony, jeżeli 
będzie to sprzyjać ugodowemu załatwieniu sprawy. Czasu trwania mediacji nie 
wlicza się do czasu trwania postępowania sądowego. 
**§ 2.** Przewodniczący wyznacza rozprawę po upływie terminu, o którym mowa 
w § 1, a przed jego upływem, jeżeli choć jedna ze stron oświadczy, że nie wyraża 
zgody na mediację.

***
## Art. 18311. {#kpc-pierwsza-pierwsza-art-18311}

Mediator niezwłocznie ustala termin i miejsce posiedzenia 
mediacyjnego. Wyznaczenie posiedzenia mediacyjnego nie jest wymagane, jeżeli 
strony zgodzą się na przeprowadzenie mediacji bez posiedzenia mediacyjnego. 
Mediator może przeprowadzić posiedzenie mediacyjne przy użyciu urządzeń 
technicznych umożliwiających jego przeprowadzenie na odległość, jeżeli strony 
wyrażą na to zgodę.

***
## Art. 18312. {#kpc-pierwsza-pierwsza-art-18312}

**§ 1.** Z przebiegu mediacji sporządza się protokół, w którym 
oznacza się miejsce i czas przeprowadzenia mediacji, a także imię, nazwisko 
(nazwę) i adresy stron, imię i nazwisko oraz adres mediatora, a ponadto wynik 
mediacji. Protokół podpisuje mediator. 
**§ 2.** Jeżeli strony zawarły ugodę przed mediatorem, ugodę zamieszcza się 
w protokole albo załącza się do niego. Strony podpisują ugodę. Niemożność 
podpisania ugody mediator stwierdza w protokole. 
**§ 21.** Przez podpisanie ugody strony wyrażają zgodę na wystąpienie do sądu 
z wnioskiem o jej zatwierdzenie, o czym mediator informuje strony. 
**§ 22.** Protokół lub ugoda w postaci elektronicznej mogą zostać opatrzone 
kwalifikowanym podpisem elektronicznym. 
**§ 3.** Mediator doręcza stronom odpis protokołu.

***
## Art. 18313. {#kpc-pierwsza-pierwsza-art-18313}

[§ 1. W przypadku gdy strona, po zawarciu ugody, w ramach 
mediacji prowadzonej na podstawie umowy o mediację, wystąpi do sądu 
z wnioskiem o zatwierdzenie ugody mediator składa protokół w sądzie, który byłby 
właściwy do rozpoznania sprawy według właściwości ogólnej lub wyłącznej.] 
<§ 1. Strona, po zawarciu ugody w ramach mediacji prowadzonej na 
podstawie umowy o mediację, może wystąpić z wnioskiem o zatwierdzenie 
Nowe brzmienie 
§ 1 w art. 18313 
wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 

 
 
 
s. 84/580 
 
2025-09-08 
 
ugody, do sądu rejonowego właściwego ze względu na miejsce zawarcia ugody, 
chyba że strony w ugodzie wskażą inny sąd rejonowy. W braku tych podstaw 
właściwy 
jest 
sąd 
rejonowy 
miejsca 
zamieszkania 
albo 
siedziby 
wnioskodawcy.> 
<§ 11. Do wniosku, o którym mowa w § 1, dołącza się protokół mediacji 
oraz ugodę, chyba że została ona zamieszczona w protokole mediacji, 
a w przypadku 
wniosku 
wniesionego 
za 
pośrednictwem 
portalu 
informacyjnego 
– 
dokumenty 
w postaci 
elektronicznej 
opatrzone 
kwalifikowanym podpisem elektronicznym albo poświadczone elektronicznie 
odpisy tych dokumentów. 
**§ 12.** W postępowaniu 
o zatwierdzenie 
ugody 
zawartej 
w ramach 
mediacji prowadzonej na podstawie umowy o mediację, adwokat, radca 
prawny, rzecznik patentowy, Prokuratoria Generalna Rzeczypospolitej 
Polskiej albo prokurator wnosi wniosek oraz dalsze pisma procesowe za 
pośrednictwem portalu informacyjnego.> 
**§ 2.** [W razie skierowania przez sąd sprawy do mediacji mediator składa 
protokół w sądzie rozpoznającym sprawę, z oznaczeniem, czy sąd rozpoznający 
sprawę jest sądem wskazanym przez strony w trybie określonym w art. 18314 § 21.]  
<W razie skierowania przez sąd stron do mediacji mediator składa protokół 
oraz ugodę, o ile została zawarta, w sądzie rozpoznającym sprawę.> Strony 
mogą objąć ugodą również roszczenia nieobjęte pozwem.

***
## Art. 18314. {#kpc-pierwsza-pierwsza-art-18314}

[§ 1. Jeżeli zawarto ugodę przed mediatorem, sąd, o którym mowa 
w art. 18313, na wniosek strony niezwłocznie przeprowadza postępowanie co do 
zatwierdzenia ugody zawartej przed mediatorem.] 
<§ 1. Jeżeli zawarto ugodę przed mediatorem, sąd niezwłocznie 
przeprowadza postępowanie co do zatwierdzenia ugody.> 
**§ 2.** Jeżeli ugoda podlega wykonaniu w drodze egzekucji, sąd zatwierdza ją 
przez nadanie jej klauzuli wykonalności; w przeciwnym przypadku sąd zatwierdza 
ugodę postanowieniem. 
[§ 21. Jeżeli ugoda dotyczy roszczeń objętych różnymi postępowaniami 
sądowymi, strony wymieniają w ugodzie te postępowania oraz wskazują sąd, który 
podejmie czynności przewidziane w § 1 i 2, chyba że prowadziłoby to do naruszenia 
przepisów 
o właściwości 
rzeczowej, 
mogącego 
skutkować 
nieważnością 
Dodane § 11 i 12 w 
art. 18313 wejdą 
w życie z dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 
Nowe brzmienie 
zd. pierwszego w 
§ 2 w art. 18313 
wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 
Nowe brzmienia 
§ 1 i 21 w art. 
18313 wejdą w 
życie 
z 
dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 

 
 
 
s. 85/580 
 
2025-09-08 
 
postępowania, lub właściwości wyłącznej. Odpis postanowienia o zatwierdzeniu 
ugody lub nadaniu ugodzie klauzuli wykonalności sąd doręcza pozostałym sądom 
wymienionym w ugodzie. Odpis postanowienia o zatwierdzeniu ugody lub nadaniu 
ugodzie klauzuli wykonalności stanowi podstawę do umorzenia postępowania 
w zakresie, w jakim dotyczy ono roszczeń objętych ugodą.] 
<§ 21. Jeżeli ugoda dotyczy roszczeń objętych różnymi postępowaniami 
sądowymi, strony wymieniają w ugodzie te postępowania oraz wskazują sąd, 
który podejmie czynności przewidziane w § 1 i 2. Jeżeli postępowania 
prowadzą sądy różnego rzędu, właściwy jest sąd wyższego rzędu. Odpis 
postanowienia o zatwierdzeniu ugody lub nadaniu ugodzie klauzuli 
wykonalności sąd doręcza pozostałym sądom wymienionym w ugodzie.> 
**§ 3.** Sąd odmawia nadania klauzuli wykonalności albo zatwierdzenia ugody 
zawartej przed mediatorem, w całości lub części, jeżeli ugoda jest sprzeczna 
z prawem lub zasadami współżycia społecznego albo zmierza do obejścia prawa, 
a także gdy jest niezrozumiała lub zawiera sprzeczności.

***
## Art. 18315. {#kpc-pierwsza-pierwsza-art-18315}

**§ 1.** Ugoda zawarta przed mediatorem, po jej zatwierdzeniu przez 
sąd, ma moc prawną ugody zawartej przed sądem. Ugoda zawarta przed 
mediatorem, którą zatwierdzono przez nadanie jej klauzuli wykonalności, jest 
tytułem wykonawczym. 
**§ 2.** Przepis § 1 nie uchybia przepisom o szczególnej formie czynności 
prawnej. 
Oddział 2 
Postępowanie pojednawcze

***
## Art. 184. {#kpc-pierwsza-pierwsza-art-184}

Sprawy cywilne, których charakter na to zezwala, mogą być 
uregulowane drogą ugody zawartej przed wniesieniem pozwu. Sąd uzna ugodę za 
niedopuszczalną, jeżeli jej treść jest niezgodna z prawem lub zasadami współżycia 
społecznego albo zmierza do obejścia prawa.

***
## Art. 185. {#kpc-pierwsza-pierwsza-art-185}

**§ 1.** O zawezwanie do próby ugodowej – bez względu na 
właściwość rzeczową – można zwrócić się do sądu rejonowego ogólnie właściwego 
dla przeciwnika, a w braku podstaw do ustalenia tej właściwości – do sądu 
rejonowego właściwego dla miejsca zamieszkania albo siedziby wzywającego. 

 
 
 
s. 86/580 
 
2025-09-08 
**§ 11.** W wezwaniu należy zwięźle oznaczyć sprawę i przedstawić propozycje 
ugodowe. Do wezwania niespełniającego tych wymogów przepis art. 130 stosuje 
się odpowiednio. 
**§ 2.** Postępowanie pojednawcze przeprowadza sąd w składzie jednego 
sędziego. 
**§ 3.** Z posiedzenia sporządza się protokół. Jeżeli doszło do ugody, jej osnowę 
wciąga się do protokołu albo zamieszcza się w odrębnym dokumencie 
stanowiącym załącznik do protokołu i stwierdza podpisami stron. Przepis 
art. 223 § 1 zdanie trzecie stosuje się odpowiednio.

***
## Art. 186. {#kpc-pierwsza-pierwsza-art-186}

**§ 1.** Jeżeli wzywający nie stawi się na posiedzenie, sąd na żądanie 
przeciwnika włoży na niego obowiązek zwrotu kosztów wywołanych próbą 
ugodową. 
**§ 2.** Jeżeli przeciwnik bez usprawiedliwienia nie stawi się na posiedzenie, sąd 
na żądanie wzywającego, który wniósł następnie w tej sprawie pozew, odpowiedź 
na pozew, sprzeciw lub zarzuty od nakazu zapłaty, uwzględni koszty wywołane 
próbą ugodową w orzeczeniu kończącym postępowanie w sprawie. 
Rozdział 2 
Pozew

***
## Art. 1861. {#kpc-pierwsza-pierwsza-art-1861}

Pismo, które zostało wniesione jako pozew, a z którego nie wynika 
żądanie rozstrzygnięcia sporu o charakterze sprawy cywilnej, przewodniczący 
zwraca wnoszącemu bez żadnych dalszych czynności, chyba że wyjątkowe 
okoliczności uzasadniają nadanie mu biegu.

***
## Art. 187. {#kpc-pierwsza-pierwsza-art-187}

**§ 1.** Pozew powinien czynić zadość warunkom pisma procesowego, 
a nadto zawierać: 
- 1) dokładnie określone żądanie, a w sprawach o prawa majątkowe także 
oznaczenie wartości przedmiotu sporu, chyba że przedmiotem sprawy jest 
oznaczona kwota pieniężna; 
- 11) oznaczenie daty wymagalności roszczenia w sprawach o zasądzenie 
roszczenia; 
- 2) wskazanie faktów, na których powód opiera swoje żądanie, a w miarę 
potrzeby uzasadniających również właściwość sądu; 

 
 
 
s. 87/580 
 
2025-09-08 
- 3) informację, czy strony podjęły próbę mediacji lub innego pozasądowego 
sposobu rozwiązania sporu, a w przypadku gdy takich prób nie podjęto, 
wyjaśnienie przyczyn ich niepodjęcia. 
**§ 2.** Pozew może zawierać wnioski o zabezpieczenie powództwa, nadanie 
wyrokowi rygoru natychmiastowej wykonalności i przeprowadzenie rozprawy 
w nieobecności powoda oraz wnioski służące do przygotowania rozprawy, 
a w szczególności wnioski o: 
- 1) wezwanie na rozprawę wskazanych przez powoda świadków i biegłych; 
- 2) dokonanie oględzin; 
- 3) polecenie pozwanemu dostarczenia na rozprawę dokumentu będącego w jego 
posiadaniu, a potrzebnego do przeprowadzenia dowodu, lub przedmiotu 
oględzin; 
- 4) zażądanie dowodów znajdujących się w sądach, urzędach lub u osób trzecich, 
wraz z uprawdopodobnieniem, że strona sama nie może ich uzyskać.

***
## Art. 1871. {#kpc-pierwsza-pierwsza-art-1871}

(uchylony)

***
## Art. 1872. {#kpc-pierwsza-pierwsza-art-1872}

(uchylony)

***
## Art. 188. {#kpc-pierwsza-pierwsza-art-188}

(uchylony)

***
## Art. 189. {#kpc-pierwsza-pierwsza-art-189}

Powód może żądać ustalenia przez sąd istnienia lub nieistnienia 
stosunku prawnego lub prawa, gdy ma w tym interes prawny.

***
## Art. 1891. {#kpc-pierwsza-pierwsza-art-1891}

Uprawnienie, o którym mowa w art. 189, przysługuje również, w 
toku prowadzonego postępowania, organowi podatkowemu, jeżeli ustalenie 
istnienia lub nieistnienia stosunku prawnego lub prawa jest niezbędne dla oceny 
skutków podatkowych.

***
## Art. 190. {#kpc-pierwsza-pierwsza-art-190}

Można dochodzić przyszłych powtarzających się świadczeń, jeżeli 
nie sprzeciwia się temu treść łączącego strony stosunku prawnego.

***
## Art. 191. {#kpc-pierwsza-pierwsza-art-191}

Powód może dochodzić jednym pozwem kilku roszczeń przeciwko 
temu samemu pozwanemu, jeżeli nadają się one do tego samego trybu 
postępowania oraz jeżeli sąd jest właściwy ze względu na ogólną wartość roszczeń, 
a ponadto – gdy roszczenia są różnego rodzaju – o tyle tylko, o ile dla 
któregokolwiek z tych roszczeń nie jest przewidziane postępowanie odrębne ani też 

 
 
 
s. 88/580 
 
2025-09-08 
 
nie zachodzi niewłaściwość sądu według przepisów o właściwości bez względu na 
wartość przedmiotu sporu.

***
## Art. 1911. {#kpc-pierwsza-pierwsza-art-1911}

**§ 1.** Jeżeli z treści pozwu i załączników oraz okoliczności 
dotyczących sprawy, a także faktów, o których mowa w art. 228, wynika oczywista 
bezzasadność powództwa, stosuje się przepisy § 2–4. 
**§ 2.** Gdyby czynności, które ustawa nakazuje podjąć w następstwie 
wniesienia pozwu, miały być oczywiście niecelowe, można je pominąć. 
W szczególności można nie wzywać powoda do usunięcia braków, uiszczenia 
opłaty, nie sprawdzać wartości przedmiotu sporu ani nie przekazywać sprawy. 
**§ 3.** Sąd może oddalić powództwo na posiedzeniu niejawnym, nie doręczając 
pozwu osobie wskazanej jako pozwany ani nie rozpoznając wniosków złożonych 
wraz z pozwem. 
**§ 4.** Uzasadnienie wyroku sporządza się na piśmie z urzędu. Powinno ono 
zawierać jedynie wyjaśnienie, dlaczego powództwo zostało uznane za oczywiście 
bezzasadne. Wyrok z uzasadnieniem sąd z urzędu doręcza tylko powodowi z po-
uczeniem o sposobie i terminie wniesienia środka zaskarżenia.

***
## Art. 192. {#kpc-pierwsza-pierwsza-art-192}

Z chwilą doręczenia pozwu: 
- 1) nie można w toku sprawy wszcząć pomiędzy tymi samymi stronami nowego 
postępowania o to samo roszczenie; 
- 2) pozwany może wytoczyć przeciw powodowi powództwo wzajemne; 
- 3) zbycie w toku sprawy rzeczy lub prawa, objętych sporem, nie ma wpływu na 
dalszy bieg sprawy; nabywca może jednak wejść na miejsce zbywcy za 
zezwoleniem strony przeciwnej.

***
## Art. 193. {#kpc-pierwsza-pierwsza-art-193}

**§ 1.** Zmiana powództwa jest dopuszczalna, jeżeli nie wpływa na 
właściwość sądu. 
**§ 2.** Jeżeli w myśl przepisu poprzedzającego zmiana nie jest dopuszczalna, 
a powód zmienia powództwo w ten sposób, że występuje z nowym roszczeniem 
obok pierwotnego, sąd rozpoznaje nowe roszczenie jako sprawę oddzielną, jeżeli 
jest dla niej rzeczowo i miejscowo właściwy, w przeciwnym zaś razie przekazuje 
sprawę sądowi właściwemu. Gdy jednak zmiana taka następuje w sądzie 
rejonowym, należy przekazać całe zmienione powództwo sądowi okręgowemu, 
który dla zmienionego powództwa jest rzeczowo i miejscowo właściwy. 

 
 
 
s. 89/580 
 
2025-09-08 
**§ 21.** Z wyjątkiem spraw o roszczenia alimentacyjne zmiana powództwa może 
być dokonana jedynie w piśmie procesowym. Przepis art. 187 stosuje się 
odpowiednio. 
**§ 3.** Jeżeli powód występuje z nowym roszczeniem zamiast lub obok 
roszczenia pierwotnego, skutki przewidziane w artykule poprzedzającym 
rozpoczynają się z chwilą, w której roszczenie to powód zgłosił na rozprawie 
w obecności pozwanego, w innych zaś wypadkach – z chwilą doręczenia 
pozwanemu pisma zawierającego zmianę i odpowiadającego wymaganiom pozwu. 
**§ 4.** (uchylony)

***
## Art. 194. {#kpc-pierwsza-pierwsza-art-194}

**§ 1.** Jeżeli okaże się, że powództwo nie zostało wniesione 
przeciwko osobie, która powinna być w sprawie stroną pozwaną, sąd na wniosek 
powoda lub pozwanego wezwie tę osobę do wzięcia udziału w sprawie. Osoba 
wezwana do udziału w sprawie na wniosek pozwanego może domagać się zwrotu 
kosztów wyłącznie od pozwanego, jeżeli okaże się, że wniosek był bezzasadny. 
**§ 2.** Osoba wezwana do wzięcia udziału w sprawie w charakterze pozwanego 
może za zgodą obu stron wstąpić w miejsce pozwanego, który wówczas będzie 
zwolniony od udziału w sprawie. W razie wyrażenia zgody na zmianę strony 
pozwanej, pozwany może w terminie dwutygodniowym złożyć sądowi wniosek 
o przyznanie kosztów od strony powodowej, niezależnie od późniejszego wyniku 
sprawy. 
**§ 3.** Jeżeli okaże się, że powództwo o to samo roszczenie może być 
wytoczone przeciwko innym jeszcze osobom, które nie występują w sprawie 
w charakterze pozwanych, sąd na wniosek powoda może wezwać te osoby do 
wzięcia udziału w sprawie. 
**§ 4.** (uchylony)

***
## Art. 195. {#kpc-pierwsza-pierwsza-art-195}

**§ 1.** Jeżeli okaże się, że nie występują w charakterze powodów lub 
pozwanych wszystkie osoby, których łączny udział w sprawie jest konieczny, sąd 
wezwie stronę powodową, aby oznaczyła w wyznaczonym terminie osoby 
niebiorące udziału w taki sposób, by ich wezwanie lub zawiadomienie było 
możliwe, a w razie potrzeby, aby wystąpiła z wnioskiem o ustanowienie kuratora. 
**§ 2.** Sąd wezwie osoby niezapozwane do wzięcia udziału w sprawie 
w charakterze pozwanych. Osoby, których udział w sprawie w charakterze 

 
 
 
s. 90/580 
 
2025-09-08 
 
powodów jest konieczny, sąd zawiadomi o toczącym się procesie. Osoby te mogą 
w ciągu dwóch tygodni od doręczenia zawiadomienia przystąpić do sprawy 
w charakterze powodów.

***
## Art. 196. {#kpc-pierwsza-pierwsza-art-196}

**§ 1.** Jeżeli okaże się, że powództwo zostało wniesione nie przez 
osobę, która powinna występować w sprawie w charakterze powoda, sąd na 
wniosek powoda zawiadomi o toczącym się procesie osobę przez niego wskazaną. 
Osoba ta może w ciągu dwóch tygodni od doręczenia zawiadomienia wstąpić do 
sprawy w charakterze powoda. 
**§ 2.** Osoba zawiadomiona, która zgłosiła przystąpienie do sprawy 
w charakterze powoda, może za zgodą obu stron wstąpić na miejsce strony 
powodowej, która wówczas będzie od udziału w sprawie zwolniona. W razie 
wyrażenia zgody na zmianę strony powodowej pozwany może w terminie 
dwutygodniowym złożyć sądowi wniosek o przyznanie dotychczasowych kosztów 
od osoby, która poprzednio występowała jako powód.

***
## Art. 197. {#kpc-pierwsza-pierwsza-art-197}

(uchylony)

***
## Art. 198. {#kpc-pierwsza-pierwsza-art-198}

**§ 1.** Wezwanie do wzięcia udziału w sprawie w charakterze 
pozwanego, dokonane przez sąd zgodnie z artykułami poprzedzającymi, zastępuje 
pozwanie. Osobom wezwanym sąd doręczy odpisy pism procesowych 
i załączników. 
**§ 2.** Skutki prawne, jakie ustawa wiąże z wytoczeniem powództwa, 
w stosunku do osób zawiadomionych w myśl artykułów poprzedzających następują 
z chwilą przystąpienia tych osób do sprawy w charakterze powodów. 
**§ 3.** Osoby wezwane do wzięcia udziału w sprawie, a także osoby 
zawiadomione w myśl artykułów poprzedzających o toczącym się procesie, które 
w terminie zgłosiły swe przystąpienie do sprawy w charakterze powodów, mogą 
przy pierwszej czynności procesowej żądać powtórzenia dotychczasowego 
postępowania w całości lub w części, stosownie do okoliczności sprawy. 
**§ 4.** W stosunku do osób wezwanych do wzięcia udziału w sprawie i osób 
zawiadomionych, które zgłosiły przystąpienie do sprawy, stosuje się odpowiednio 
przepisy o współuczestnictwie.

***
## Art. 199. {#kpc-pierwsza-pierwsza-art-199}

**§ 1.** Sąd odrzuci pozew: 
- 1) jeżeli droga sądowa jest niedopuszczalna; 

 
 
 
s. 91/580 
 
2025-09-08 
- 2) jeżeli o to samo roszczenie pomiędzy tymi samymi stronami sprawa jest 
w toku albo została już prawomocnie osądzona; 
- 3) jeżeli jedna ze stron nie ma zdolności sądowej albo jeżeli powód nie ma 
zdolności procesowej, a nie działa za niego przedstawiciel ustawowy albo 
jeżeli w składzie organów jednostki organizacyjnej będącej powodem 
zachodzą braki uniemożliwiające jej działanie. 
- 4) (uchylony) 
**§ 2.** Z powodu braku zdolności sądowej jednej ze stron albo zdolności 
procesowej powoda i niedziałania przedstawiciela ustawowego lub braku 
w składzie 
organów 
jednostki 
organizacyjnej 
będącej 
powodem, 
uniemożliwiającego jej działanie, sąd odrzuci pozew dopiero wówczas, gdy brak 
nie będzie uzupełniony zgodnie z przepisami kodeksu. 
**§ 3.** (uchylony)

***
## Art. 1991. {#kpc-pierwsza-pierwsza-art-1991}

Sąd nie może odrzucić pozwu z tego powodu, że do rozpoznania 
sprawy właściwy jest organ administracji publicznej lub sąd administracyjny, jeżeli 
organ administracji publicznej lub sąd administracyjny uznały się w tej sprawie za 
niewłaściwe.

***
## Art. 200. {#kpc-pierwsza-pierwsza-art-200}

**§ 1.** (uchylony) 
**§ 11.** Swoją właściwość sąd bierze pod rozwagę z urzędu w każdym stanie 
sprawy. 
**§ 12.** Niewłaściwość dającą się usunąć za pomocą umowy stron sąd bierze pod 
rozwagę z urzędu tylko do czasu doręczenia pozwu. Po doręczeniu pozwu sąd 
bierze tę niewłaściwość pod rozwagę tylko na zarzut pozwanego, zgłoszony 
i należycie uzasadniony przed wdaniem się w spór co do istoty sprawy. 
**§ 13.** Przepisy § 11 i 12 nie uchybiają przepisowi art. 15. 
**§ 14.** Sąd, który stwierdzi swą niewłaściwość, przekaże sprawę sądowi 
właściwemu. 
**§ 2.** Sąd, któremu sprawa została przekazana, jest związany postanowieniem 
o przekazaniu sprawy. Nie dotyczy to wypadku przekazania sprawy sądowi 
wyższego rzędu. Sąd ten w razie stwierdzenia swej niewłaściwości przekaże 
sprawę innemu sądowi, który uzna za właściwy, nie wyłączając sądu 
przekazującego. 

 
 
 
s. 92/580 
 
2025-09-08 
**§ 3.** Czynności dokonane w sądzie niewłaściwym pozostają w mocy.

***
## Art. 201. {#kpc-pierwsza-pierwsza-art-201}

**§ 1.** Przewodniczący bada, w jakim trybie sprawa powinna być 
rozpoznana oraz czy podlega rozpoznaniu według przepisów o postępowaniu 
odrębnym, i wydaje odpowiednie zarządzenia. W wypadkach przewidzianych 
w ustawie przewodniczący wyznacza posiedzenie niejawne w celu wydania nakazu 
zapłaty w postępowaniu upominawczym. 
**§ 2.** Jeżeli sprawę wszczęto lub prowadzono w trybie niewłaściwym, sąd 
rozpozna ją w trybie właściwym lub przekaże właściwemu sądowi do rozpoznania 
w takim trybie. W wypadku przekazania stosuje się odpowiednio przepisy § 2 i 3 
artykułu poprzedzającego. Każda jednak strona może żądać powtórzenia czynności 
sądu dokonanych bez jej udziału.

***
## Art. 202. {#kpc-pierwsza-pierwsza-art-202}

Okoliczności, które uzasadniają odrzucenie pozwu, jak również 
niewłaściwy tryb postępowania, brak należytego umocowania pełnomocnika, brak 
zdolności procesowej pozwanego, brak w składzie jego organów lub niedziałanie 
jego przedstawiciela ustawowego sąd bierze pod rozwagę z urzędu w każdym 
stanie sprawy.

***
## Art. 2021. {#kpc-pierwsza-pierwsza-art-2021}

Jeżeli strony przed wszczęciem postępowania sądowego zawarły 
umowę o mediację, sąd kieruje strony do mediacji na zarzut pozwanego zgłoszony 
przed wdaniem się w spór co do istoty sprawy.

***
## Art. 203. {#kpc-pierwsza-pierwsza-art-203}

**§ 1.** Pozew może być cofnięty bez zezwolenia pozwanego aż do 
rozpoczęcia rozprawy, a jeżeli z cofnięciem połączone jest zrzeczenie się 
roszczenia – aż do wydania wyroku. 
**§ 2.** Pozew cofnięty nie wywołuje żadnych skutków, jakie ustawa wiąże 
z wytoczeniem powództwa. Na żądanie pozwanego powód zwraca mu koszty, 
jeżeli sąd już przedtem nie orzekł prawomocnie o obowiązku ich uiszczenia przez 
pozwanego. 
**§ 3.** W razie cofnięcia pozwu poza rozprawą przewodniczący odwołuje 
wyznaczoną rozprawę i o cofnięciu zawiadamia pozwanego, który może 
w terminie dwutygodniowym złożyć sądowi wniosek o przyznanie kosztów. Gdy 
skuteczność cofnięcia pozwu zależy od zgody pozwanego, niezłożenie przez niego 
oświadczenia w tym przedmiocie w powyższym terminie uważa się za wyrażenie 
zgody. 

 
 
 
s. 93/580 
 
2025-09-08 
**§ 4.** Sąd może uznać za niedopuszczalne cofnięcie pozwu, zrzeczenie się lub 
ograniczenie roszczenia tylko wtedy, gdy okoliczności sprawy wskazują, że 
wymienione czynności są sprzeczne z prawem lub zasadami współżycia 
społecznego albo zmierzają do obejścia prawa.

***
## Art. 2031. {#kpc-pierwsza-pierwsza-art-2031}

**§ 1.** Podstawą zarzutu potrącenia może być tylko wierzytelność: 
- 1) pozwanego z tego samego stosunku prawnego co wierzytelność dochodzona 
przez powoda, chyba że wierzytelność ta jest niesporna, stwierdzona 
prawomocnym orzeczeniem sądu, orzeczeniem sądu polubownego, ugodą 
zawartą przed sądem albo sądem polubownym, zatwierdzoną przez sąd ugodą 
zawartą 
przed 
mediatorem, 
lub 
uprawdopodobniona 
dokumentem 
potwierdzającym jej uznanie przez powoda; 
- 2) o zwrot spełnionego świadczenia przysługująca jednemu z dłużników 
solidarnych wobec pozostałych współdłużników. 
**§ 2.** Pozwany może podnieść zarzut potrącenia nie później niż przy wdaniu 
się w spór co do istoty sprawy albo w terminie dwóch tygodni od dnia, gdy jego 
wierzytelność stała się wymagalna. 
**§ 3.** Zarzut potrącenia może zostać podniesiony tylko w piśmie procesowym. 
Do pisma tego stosuje się odpowiednio przepisy dotyczące pozwu, z wyjątkiem 
przepisów dotyczących opłat.

***
## Art. 204. {#kpc-pierwsza-pierwsza-art-204}

**§ 1.** Powództwo wzajemne jest dopuszczalne, jeżeli roszczenie 
wzajemne jest w związku z roszczeniem powoda lub nadaje się do potrącenia. 
Powództwo wzajemne można wytoczyć nie później niż w odpowiedzi na pozew, 
a jeżeli jej nie złożono – w sprzeciwie od wyroku zaocznego albo przy rozpoczęciu 
pierwszego posiedzenia, o którym zawiadomiono albo na które wezwano 
pozwanego. 
**§ 2.** Pozew wzajemny wnosi się do sądu pozwu głównego. Jeżeli jednak 
pozew wzajemny podlega rozpoznaniu przez sąd okręgowy, a sprawa wszczęta 
była w sądzie rejonowym, sąd ten przekazuje całą sprawę sądowi właściwemu do 
rozpoznania powództwa wzajemnego. 
**§ 3.** Przepisy dotyczące pozwu stosuje się odpowiednio do pozwu 
wzajemnego. 

 
 
 
s. 94/580 
 
2025-09-08

***
## Art. 205. {#kpc-pierwsza-pierwsza-art-205}

Sąd rejonowy może na wniosek pozwanego, złożony aż do 
zamknięcia rozprawy, przekazać sprawę sądowi okręgowemu, jeżeli pozwany 
wytoczył przeciwko powodowi przed tym sądem powództwo wpływające na 
roszczenie powoda bądź dlatego, że ma z nim związek, bądź dlatego, że roszczenia 
stron nadają się do potrącenia. 
Rozdział 2a 
Organizacja postępowania

***
## Art. 2051. {#kpc-pierwsza-pierwsza-art-2051}

**§ 1.** Przewodniczący zarządza doręczenie pozwu pozwanemu 
i wzywa go do złożenia odpowiedzi na pozew w wyznaczonym terminie nie 
krótszym niż dwa tygodnie. 
**§ 2.** Przewodniczący zarządza zwrot odpowiedzi na pozew złożonej 
z uchybieniem terminu.

***
## Art. 2052. {#kpc-pierwsza-pierwsza-art-2052}

**§ 1.** Równocześnie z doręczeniem pierwszego pisma sądowego 
w sprawie poucza się strony o: 
- 1) możliwości rozwiązania sporu w drodze ugody zawartej przed sądem lub 
mediatorem i o wpływie zawarcia ugody na koszty postępowania, 
- 2) możliwości ustanowienia pełnomocnika procesowego oraz o tym, że 
zastępstwo przez adwokata, radcę prawnego lub rzecznika patentowego nie 
jest obowiązkowe, 
- 3) obowiązku 
złożenia 
pisma 
przygotowawczego 
na 
zarządzenie 
przewodniczącego, 
wymogach 
co 
do 
jego 
treści 
i skutkach 
ich 
niedochowania, 
- 4) zwrocie 
pisma 
przygotowawczego 
złożonego 
bez 
zarządzenia 
przewodniczącego 
– chyba że strona jest zastępowana przez adwokata, radcę prawnego, rzecznika 
patentowego lub Prokuratorię Generalną Rzeczypospolitej Polskiej. 
**§ 2.** Pozwanego poucza się także o czynnościach procesowych, które może 
lub powinien podjąć, jeżeli nie uznaje żądania pozwu w całości lub części, 
w szczególności o obowiązku złożenia odpowiedzi na pozew i o wymaganiach 
co do terminu i formy jej wniesienia, a także o możliwości wydania przez sąd 
wyroku zaocznego na posiedzeniu niejawnym i o warunkach jego wykonalności. 

 
 
 
s. 95/580 
 
2025-09-08 
**§ 3.** Pouczeń, o których mowa w § 1 i 2, nie udziela się, jeżeli stroną jest 
Skarb Państwa, jednostka samorządu terytorialnego, państwowa osoba prawna, 
organ emerytalny lub rentowy, bank, spółdzielcza kasa oszczędnościowo-
-kredytowa, zakład ubezpieczeń, zakład reasekuracji, fundusz inwestycyjny lub 
dom maklerski, chyba że przewodniczący uzna udzielenie pouczenia za konieczne.

***
## Art. 2053. {#kpc-pierwsza-pierwsza-art-2053}

**§ 1.** W uzasadnionych przypadkach, w szczególności w sprawach 
zawiłych lub obrachunkowych, przewodniczący może zarządzić wymianę przez 
strony pism przygotowawczych, oznaczając porządek składania pism, terminy, 
w których pisma należy złożyć, i okoliczności, które mają być wyjaśnione. 
**§ 2.** Przewodniczący 
może 
zobowiązać 
stronę, 
by 
w piśmie 
przygotowawczym 
podała 
wszystkie 
twierdzenia 
i dowody 
istotne 
dla 
rozstrzygnięcia sprawy pod rygorem utraty prawa do ich powoływania w toku 
dalszego postępowania. W takim przypadku twierdzenia i dowody zgłoszone 
z naruszeniem tego obowiązku podlegają pominięciu, chyba że strona 
uprawdopodobni, iż ich powołanie w piśmie przygotowawczym nie było możliwe 
albo że potrzeba ich powołania wynikła później. 
**§ 3.** Późniejsze wyznaczenie posiedzenia przygotowawczego nie powoduje 
otwarcia terminu do zgłaszania nowych twierdzeń i dowodów. 
**§ 4.** Stronę zastępowaną przez adwokata, radcę prawnego, rzecznika 
patentowego 
lub 
Prokuratorię 
Generalną 
Rzeczypospolitej 
Polskiej 
przewodniczący może zobowiązać do wskazania w piśmie przygotowawczym 
także podstaw prawnych jej żądań i wniosków, w miarę potrzeby ograniczając 
zakres tego wskazania. 
**§ 5.** Przewodniczący zarządza zwrot pisma przygotowawczego złożonego 
z uchybieniem terminu albo bez zarządzenia.

***
## Art. 2054. {#kpc-pierwsza-pierwsza-art-2054}

**§ 1.** Po złożeniu odpowiedzi na pozew, a także gdy odpowiedź na 
pozew nie została złożona, ale wyrok zaoczny nie został wydany, przewodniczący 
wyznacza posiedzenie przygotowawcze. 
**§ 11.** Na 
posiedzenie 
przygotowawcze 
wzywa 
się 
do 
osobistego 
stawiennictwa strony i ich pełnomocników. Przewodniczący może odstąpić od 
wzywania strony na posiedzenie przygotowawcze, jeżeli z okoliczności sprawy 
wynika, że udział pełnomocnika będzie wystarczający. Jeżeli stroną jest podmiot, 

 
 
 
s. 96/580 
 
2025-09-08 
 
o którym mowa w art. 2052 § 3, wzywa się tylko jej pełnomocnika, chyba że nie 
został ustanowiony. 
**§ 2.** Przewodniczący i sąd są obowiązani podejmować czynności tak, by 
termin pierwszego posiedzenia przygotowawczego przypadł nie później niż dwa 
miesiące po dniu złożenia odpowiedzi na pozew albo ostatniego pisma 
przygotowawczego złożonego w wykonaniu zarządzenia przewodniczącego, 
a jeżeli odpowiedź na pozew albo pismo przygotowawcze nie zostaną złożone – nie 
później niż dwa miesiące po upływie terminu do złożenia tych pism. 
**§ 3.** Jeżeli okoliczności sprawy wskazują, że przeprowadzenie posiedzenia 
przygotowawczego nie przyczyni się do sprawniejszego rozpoznania sprawy, 
przewodniczący może jej nadać inny właściwy bieg, w szczególności skierować ją 
do rozpoznania, także na rozprawie.

***
## Art. 2054a. {#kpc-pierwsza-pierwsza-art-2054a}

**§ 1.** Równocześnie 
z wezwaniem 
stron 
na 
posiedzenie 
przygotowawcze strony poucza się o: 
- 1) obowiązku udziału w posiedzeniu przygotowawczym; 
- 2) obowiązku przedstawienia wszystkich twierdzeń i dowodów najpóźniej na 
tym posiedzeniu, chyba że wcześniej upłynął termin do złożenia pisma 
przygotowawczego; 
- 3) skutkach niedopełnienia obowiązków, o których mowa w pkt 1 i 2, 
w szczególności możliwości obciążenia kosztami postępowania, umorzenia 
postępowania lub pominięcia spóźnionych twierdzeń i dowodów. 
**§ 2.** O obowiązku, 
o którym 
mowa 
w § 1 pkt 1, 
i skutkach 
jego 
niedopełnienia poucza się bezpośrednio stronę, chyba że przewodniczący uznał 
udział pełnomocnika za wystarczający. 
**§ 3.** Do pouczeń, o których mowa w § 1, przepis art. 2052 § 3 stosuje się 
odpowiednio.

***
## Art. 2055. {#kpc-pierwsza-pierwsza-art-2055}

**§ 1.** Posiedzenie przygotowawcze służy rozwiązaniu sporu bez 
potrzeby prowadzenia dalszych posiedzeń, zwłaszcza rozprawy. Jeżeli nie uda się 
rozwiązać sporu, na posiedzeniu przygotowawczym sporządza się z udziałem stron 
plan rozprawy. 
**§ 11.** Jeżeli w toku posiedzenia przygotowawczego nie udało się rozwiązać 
sporu, a zachodzą przesłanki rozpoznania sprawy w sposób przewidziany 

 
 
 
s. 97/580 
 
2025-09-08 
 
w art. 1481 § 1, przewodniczący może wyznaczyć posiedzenie niejawne. W takim 
przypadku przepisu art. 1481 § 3 nie stosuje się. 
**§ 2.** Posiedzenie 
przygotowawcze 
odbywa 
się 
według 
przepisów 
o posiedzeniu niejawnym. Z uwzględnieniem przepisów niniejszego rozdziału, 
przewodniczący może prowadzić posiedzenie przygotowawcze w taki sposób, jaki 
uzna za właściwy, a jeżeli przyczyni się to do osiągnięcia celów tego posiedzenia, 
przestrzeganie przepisów o posiedzeniach sądu nie jest konieczne. Przewodniczący 
może zarządzić przeprowadzenie posiedzenia jawnego przy użyciu urządzeń 
technicznych umożliwiających jego przeprowadzenie na odległość, z jednoczesną 
transmisją obrazu i dźwięku. W takim przypadku uczestnicy postępowania nie 
muszą przebywać w budynku sądu. 
**§ 21.** Jeżeli przepis szczególny nie stanowi inaczej, postanowienia wydane 
w toku posiedzenia przygotowawczego ogłasza się w obecności stron i nie 
podlegają one doręczeniu. Protokół posiedzenia przygotowawczego zawiera 
wymienienie wydanych postanowień i stwierdzenie, czy zostały ogłoszone. 
**§ 3.** Do udziału w posiedzeniu przygotowawczym są obowiązane osoby 
wezwane. Sąd dopuści do udziału w postępowaniu przygotowawczym stronę, która 
mimo braku wezwania stawiła się na posiedzenie. 
**§ 4.** Przed rozpoczęciem posiedzenia przygotowawczego powód może wnieść 
o jego przeprowadzenie bez swego udziału. Wniosek nie podlega cofnięciu, 
a zastrzeżenie warunku lub terminu uważa się za nieistniejące. W takim przypadku 
niestawiennictwo 
powoda 
lub 
jego 
pełnomocnika 
na 
posiedzeniu 
przygotowawczym nie prowadzi do umorzenia postępowania, plan rozprawy 
sporządza się bez udziału powoda, a ustalenia zawarte w planie rozprawy wiążą 
powoda w dalszym toku postępowania. 
**§ 5.** Jeżeli wezwany na posiedzenie powód lub jego pełnomocnik bez 
usprawiedliwienia nie stawi się na posiedzenie przygotowawcze, sąd umarza 
postępowanie, rozstrzygając o kosztach jak przy cofnięciu pozwu, chyba że 
sprzeciwi się temu obecny na tym posiedzeniu pozwany. Postanowienie doręcza się 
nieobecnym stronom wraz z uzasadnieniem. 
**§ 6.** Jeżeli pozwany nie stawi się na posiedzenie przygotowawcze, plan 
rozprawy sporządza się bez jego udziału. Ustalenia zawarte w planie rozprawy 

 
 
 
s. 98/580 
 
2025-09-08 
 
wiążą pozwanego w dalszym toku postępowania. W przypadku nieusprawied-
liwionego niestawiennictwa przepis art. 103 § 3 stosuje się. 
**§ 7.** Jeżeli strona, która stawiła się na posiedzenie przygotowawcze, nie bierze 
w nim udziału, plan rozprawy sporządza się bez jej udziału. Ustalenia zawarte 
w planie rozprawy wiążą tę stronę w dalszym toku postępowania. Przepis art. 103 
§ 3 stosuje się odpowiednio.

***
## Art. 2056. {#kpc-pierwsza-pierwsza-art-2056}

**§ 1.** Na posiedzeniu przygotowawczym przewodniczący ustala ze 
stronami przedmiot sporu i wyjaśnia stanowiska stron, także w zakresie prawnych 
aspektów sporu. 
**§ 2.** Przewodniczący powinien skłaniać strony do pojednania oraz dążyć do 
ugodowego rozwiązania sporu, w szczególności w drodze mediacji. W tym celu 
przewodniczący może poszukiwać ze stronami ugodowych sposobów rozwiązania 
sporu, wspierać je w formułowaniu propozycji ugodowych oraz wskazywać 
sposoby i skutki rozwiązania sporu, w tym skutki finansowe.

***
## Art. 2057. {#kpc-pierwsza-pierwsza-art-2057}

**§ 1.** Jeżeli na posiedzeniu przygotowawczym sąd skierował strony 
do mediacji, posiedzenie odracza się do czasu zakończenia mediacji. 
**§ 2.** W razie potrzeby, zwłaszcza gdy istnieją widoki ugodowego rozwiązania 
sporu lub gdy zajdzie potrzeba wyjaśnienia okoliczności istotnych dla 
rozstrzygnięcia sprawy albo w przypadku usprawiedliwionego niestawiennictwa 
strony, a także na zgodny wniosek stron, posiedzenie przygotowawcze można 
odroczyć na czas oznaczony, nie dłuższy niż trzy miesiące. 
**§ 3.** Na zgodny wniosek stron posiedzenie przygotowawcze można odroczyć 
po raz drugi – na czas oznaczony, nie dłuższy niż trzy miesiące. 
**§ 4.** Poza przypadkami, o których mowa w § 1–3, odraczanie posiedzenia 
przygotowawczego jest niedopuszczalne.

***
## Art. 2058. {#kpc-pierwsza-pierwsza-art-2058}

**§ 1.** Z przebiegu 
posiedzenia 
przygotowawczego 
protokół 
sporządza się pisemnie. W protokole tym nie zamieszcza się oświadczeń stron 
złożonych w ramach prób ugodowego rozwiązania sporu; przepis art. 1834 
§ 3 stosuje się odpowiednio. Przewodniczący może również odstąpić od 
zamieszczenia innych wzmianek, jeżeli może to ułatwić rozwiązanie sporu bez 
rozprawy. Przebieg posiedzenia przygotowawczego w części obejmującej próbę 

 
 
 
s. 99/580 
 
2025-09-08 
 
ugodowego rozwiązania sporu nie podlega utrwaleniu w sposób przewidziany 
w art. 91. 
**§ 2.** Jeżeli zawarto ugodę, jej osnowę wciąga się do protokołu albo zamieszcza 
w odrębnym dokumencie, podpisanym przez strony, stanowiącym załącznik do 
protokołu. Przepis art. 223 § 1 zdanie trzecie stosuje się odpowiednio.

***
## Art. 2059. {#kpc-pierwsza-pierwsza-art-2059}

**§ 1.** Plan rozprawy zawiera rozstrzygnięcia co do wniosków 
dowodowych stron oraz porządek przeprowadzanych na rozprawie dowodów. 
Jeżeli na etapie sporządzania planu rozprawy rozstrzyganie co do niektórych 
wniosków dowodowych byłoby niecelowe lub przedwczesne, sąd w planie 
rozprawy określa warunki lub termin wydania postanowienia dowodowego. 
**§ 2.** W miarę potrzeby plan rozprawy może zawierać: 
- 1) dokładne określenie przedmiotów żądań stron, w tym rozmiar dochodzonych 
świadczeń wraz z należnościami ubocznymi; 
- 2) dokładnie określone zarzuty, w tym formalne; 
- 3) ustalenie, które fakty i oceny prawne pozostają między stronami sporne; 
- 4) terminy posiedzeń i innych czynności w sprawie; 
- 5) (uchylony) 
- 6) termin zamknięcia rozprawy lub ogłoszenia wyroku; 
- 7) rozstrzygnięcia innych zagadnień, o ile są niezbędne do prowadzenia 
postępowania. 
**§ 3.** W planie rozprawy można się odwoływać do pism procesowych stron. 
**§ 4.** (uchylony)

***
## Art. 20510. {#kpc-pierwsza-pierwsza-art-20510}

**§ 1.** Projekt planu rozprawy podpisany przez obecne strony sąd 
zatwierdza postanowieniem. Projekt planu rozprawy stanowi załącznik do 
protokołu posiedzenia przygotowawczego. Odmowę lub niemożność złożenia 
przez stronę podpisu na projekcie planu rozprawy odnotowuje się w protokole. 
**§ 2.** Sąd odmawia zatwierdzenia projektu planu rozprawy, jeżeli uzna, że nie 
przyczyni się on do sprawnego rozpoznania sprawy lub wyjaśnienia wszystkich 
okoliczności spornych. 
**§ 3.** W razie sporu co do poszczególnych zagadnień objętych planem 
rozprawy, odmowy lub niemożności złożenia przez stronę podpisu na projekcie 
planu rozprawy lub w razie braku podstaw do zatwierdzenia projektu planu 

 
 
 
s. 100/580 
 
2025-09-08 
 
rozprawy sąd postanowieniem sporządza plan rozprawy przez spisanie odrębnej 
sentencji. 
**§ 4.** Plan rozprawy z urzędu doręcza się stronom. Jeżeli plan rozprawy 
zawiera zobowiązanie adresowane do strony, w szczególności do osobistego 
stawiennictwa lub przedstawienia dokumentu, doręcza się go bezpośrednio stronie, 
nawet jeżeli ustanowiła pełnomocnika, z wyjątkiem strony, o której mowa 
w art. 11355 § 1. 
**§ 5.** Doręczenie planu rozprawy zastępuje zawiadomienie strony o terminach 
objętych nim posiedzeń i innych czynności, a także zastępuje wezwanie strony do 
wykonania wskazanych w nim obowiązków, o czym należy stronę pouczyć.

***
## Art. 20511. {#kpc-pierwsza-pierwsza-art-20511}

**§ 1.** Plan rozprawy wiąże sąd w zakresie zawartych w nim 
rozstrzygnięć, o których mowa w art. 2059 § 1. Zmiany planu rozprawy w tym 
zakresie sąd może dokonać postanowieniem. Zmiana terminów rozprawy następuje 
w drodze zarządzenia przewodniczącego. 
**§ 2.** W razie potrzeby rozstrzygnięcia o dowodach nieobjętych planem 
rozprawy sąd wydaje odrębne postanowienie dowodowe. 
**§ 3.** W razie istotnej potrzeby można sporządzić nowy plan rozprawy. 
Czynności dokonane na podstawie poprzedniego planu rozprawy zachowują moc, 
chyba że sąd postanowi inaczej. Na zgodny wniosek stron sąd wyznacza kolejne 
posiedzenie przygotowawcze. 
**§ 4.** Zmiana planu rozprawy lub wyznaczenie kolejnego posiedzenia 
przygotowawczego nie powoduje otwarcia terminu do zgłaszania nowych 
twierdzeń i dowodów, chyba że przewodniczący zarządzi inaczej.

***
## Art. 20512. {#kpc-pierwsza-pierwsza-art-20512}

**§ 1.** Jeżeli wyznaczono posiedzenie przygotowawcze, strona 
może przytaczać twierdzenia i dowody na uzasadnienie swoich wniosków lub dla 
odparcia wniosków i twierdzeń strony przeciwnej do chwili zatwierdzenia projektu 
planu rozprawy albo sporządzenia planu rozprawy. Twierdzenia i dowody 
zgłoszone po zatwierdzeniu projektu planu rozprawy albo sporządzeniu planu 
rozprawy podlegają pominięciu, chyba że strona uprawdopodobni, że ich 
powołanie nie było możliwe albo że potrzeba ich powołania wynikła później. 
**§ 2.** Jeżeli nie zarządzono przeprowadzenia posiedzenia przygotowawczego, 
strona może przytaczać twierdzenia i dowody na uzasadnienie swoich wniosków 

 
 
 
s. 101/580 
 
2025-09-08 
 
lub dla odparcia wniosków i twierdzeń strony przeciwnej aż do zamknięcia 
rozprawy, z zastrzeżeniem niekorzystnych skutków, które według przepisów 
kodeksu mogą dla niej wyniknąć z działania na zwłokę lub niezastosowania się do 
zarządzeń przewodniczącego i postanowień sądu. 
Rozdział 3 
Rozprawa

***
## Art. 206. {#kpc-pierwsza-pierwsza-art-206}

**§ 1.** Przewodniczący i sąd podejmują czynności w sprawie tak, aby 
przebiegła zgodnie z planem rozprawy, a jeżeli planu nie sporządzono – 
w najwcześniejszych możliwych terminach. 
**§ 2.** Przewodniczący wyznacza terminy posiedzeń w sprawie zgodnie 
z planem rozprawy, a jeżeli planu nie sporządzono – najwcześniejsze możliwe 
terminy.

***
## Art. 2061. {#kpc-pierwsza-pierwsza-art-2061}

Rozprawę należy przygotować tak, aby nie było przeszkód do 
rozstrzygnięcia sprawy na pierwszym posiedzeniu na nią wyznaczonym. Więcej 
posiedzeń niż jedno wyznacza się tylko w razie konieczności, zwłaszcza gdy 
przeprowadzenie wszystkich dowodów na jednym posiedzeniu nie jest możliwe. 
W takim przypadku posiedzenia powinny odbywać się w kolejnych dniach, a jeżeli 
nie jest to możliwe – tak, aby upływ czasu pomiędzy kolejnymi posiedzeniami nie 
był nadmierny.

***
## Art. 207. {#kpc-pierwsza-pierwsza-art-207}

(uchylony)

***
## Art. 208. {#kpc-pierwsza-pierwsza-art-208}

**§ 1.** Na podstawie planu rozprawy przewodniczący wydaje 
zarządzenia mające na celu przygotowanie rozprawy. Przewodniczący może 
w szczególności: 
- 1) wezwać strony do stawienia się na rozprawę osobiście lub przez 
pełnomocnika; 
- 2) zażądać od państwowej jednostki organizacyjnej lub jednostki organizacyjnej 
samorządu terytorialnego znajdujących się u niej dowodów, jeżeli strona sama 
dowodów tych otrzymać nie może; 
- 3) wezwać na rozprawę wskazanych przez strony świadków lub biegłych; 
- 4) zarządzić 
przedstawienie 
przedmiotów 
oględzin 
lub 
dokumentów, 
w szczególności ksiąg i planów. 

 
 
 
s. 102/580 
 
2025-09-08 
- 5) (uchylony) 
**§ 2.** Przewodniczący może ponadto zarządzić oględziny jeszcze przed 
rozprawą. 
**§ 3.** Jeżeli planu rozprawy nie sporządzono, zarządzenia mające na celu 
przygotowanie rozprawy wydaje się na podstawie pozwu i innych pism 
procesowych.

***
## Art. 2081. {#kpc-pierwsza-pierwsza-art-2081}

Sąd z urzędu ustala numer PESEL pozwanego będącego osobą 
fizyczną, jeżeli jest on obowiązany do jego posiadania lub posiada go nie mając 
takiego obowiązku, lub numer w Krajowym Rejestrze Sądowym, a w przypadku 
jego braku – numer w innym właściwym rejestrze, ewidencji lub NIP pozwanego 
niebędącego osobą fizyczną, który nie ma obowiązku wpisu we właściwym 
rejestrze lub ewidencji, jeżeli jest on obowiązany do jego posiadania.

***
## Art. 209. {#kpc-pierwsza-pierwsza-art-209}

Każda ze stron może w piśmie procesowym żądać przeprowadzenia 
rozprawy w jej nieobecności.

***
## Art. 210. {#kpc-pierwsza-pierwsza-art-210}

**§ 1.** Rozprawa odbywa się w ten sposób, że po wywołaniu sprawy 
strony – najpierw powód, a potem pozwany – zgłaszają ustnie swe żądania 
i wnioski oraz przedstawiają twierdzenia i dowody na ich poparcie. Strony mogą 
ponadto wskazywać podstawy prawne swych żądań i wniosków. Na żądanie 
prokuratora sąd udziela mu głosu w każdym stanie rozprawy; art. 62 nie stosuje się. 
**§ 2.** Każda ze stron jest obowiązana do złożenia oświadczenia co do twierdzeń 
strony przeciwnej dotyczących faktów. Strona jest przy tym obowiązana 
wyszczególnić fakty, którym zaprzecza. 
**§ 21.** Sąd poucza stronę niezastępowaną przez adwokata, radcę prawnego, 
rzecznika patentowego lub Prokuratorię Generalną Rzeczypospolitej Polskiej 
o treści art. 162 § 1, art. 20512 § 2, art. 229 i art. 230. 
**§ 22.** Sąd poucza strony o możliwości ugodowego załatwienia sporu, 
w szczególności w drodze mediacji. 
**§ 3.** Ponadto rozprawa obejmuje, stosownie do okoliczności, postępowanie 
dowodowe i roztrząsanie jego wyników.

***
## Art. 211. {#kpc-pierwsza-pierwsza-art-211}

W razie nieobecności strony na rozprawie przewodniczący lub 
wyznaczony przez niego sędzia sprawozdawca przedstawia jej wnioski, 
twierdzenia i dowody znajdujące się w aktach sprawy. 

 
 
 
s. 103/580 
 
2025-09-08

***
## Art. 212. {#kpc-pierwsza-pierwsza-art-212}

**§ 1.** Na rozprawie prowadzonej bez planu rozprawy sąd przez 
zadawanie pytań stronom dąży do tego, aby strony przytoczyły lub uzupełniły 
twierdzenia lub dowody na ich poparcie oraz udzieliły wyjaśnień koniecznych do 
zgodnego z prawdą ustalenia podstawy faktycznej dochodzonych przez nie praw 
lub roszczeń. W ten sam sposób sąd dąży do wyjaśnienia istotnych okoliczności 
sprawy, które są sporne. 
**§ 2.** W razie uzasadnionej potrzeby przewodniczący może udzielić stronom 
niezbędnych pouczeń, a stosownie do okoliczności zwraca uwagę na celowość 
ustanowienia pełnomocnika procesowego.

***
## Art. 213. {#kpc-pierwsza-pierwsza-art-213}

**§ 1.** (uchylony) 
**§ 2.** Sąd jest związany uznaniem powództwa, chyba że uznanie jest sprzeczne 
z prawem lub zasadami współżycia społecznego albo zmierza do obejścia prawa.

***
## Art. 214. {#kpc-pierwsza-pierwsza-art-214}

**§ 1.** Rozprawa 
ulega 
odroczeniu, 
jeżeli 
sąd 
stwierdzi 
nieprawidłowość w doręczeniu wezwania albo jeżeli nieobecność strony jest 
wywołana nadzwyczajnym wydarzeniem lub inną znaną sądowi przeszkodą, której 
nie można przezwyciężyć. 
**§ 2.** Sąd może skazać na grzywnę stronę, jeżeli powołała się w złej wierze na 
nieprawdziwe okoliczności, które skutkowały odroczeniem rozprawy. 
**§ 3.** Jeżeli nieprawdziwe okoliczności, które skutkowały odroczeniem 
rozprawy, zostały powołane w złej wierze przez pełnomocnika strony, sąd może go 
skazać na grzywnę.

***
## Art. 2141. {#kpc-pierwsza-pierwsza-art-2141}

**§ 1.** Usprawiedliwienie niestawiennictwa z powodu choroby stron, 
ich przedstawicieli ustawowych, pełnomocników, świadków i innych uczestników 
postępowania, 
wymaga 
przedstawienia 
zaświadczenia 
potwierdzającego 
niemożność stawienia się na wezwanie lub zawiadomienie sądu, wystawionego 
przez lekarza sądowego. 
**§ 2.** Przepisu § 1 nie stosuje się do osób pozbawionych wolności, których 
usprawiedliwianie niestawiennictwa z powodu choroby regulują odrębne przepisy.

***
## Art. 215. {#kpc-pierwsza-pierwsza-art-215}

Rozprawa ulega odroczeniu, jeżeli sąd postanowi wezwać do 
wzięcia udziału w sprawie lub zawiadomić o toczącym się procesie osoby, które 
dotychczas w postępowaniu nie występowały w charakterze powodów lub 
pozwanych. 

 
 
 
s. 104/580 
 
2025-09-08

***
## Art. 216. {#kpc-pierwsza-pierwsza-art-216}

Sąd może w celu dokładniejszego wyjaśnienia stanu sprawy 
zarządzić stawienie się stron lub jednej z nich osobiście albo przez pełnomocnika.

***
## Art. 2161. {#kpc-pierwsza-pierwsza-art-2161}

**§ 1.** Sąd w sprawach dotyczących osoby małoletniego dziecka 
wysłucha je, jeżeli jego rozwój umysłowy, stan zdrowia i stopień dojrzałości na to 
pozwala. Jeżeli przed sądem dziecko odmawia udziału w wysłuchaniu, sąd 
odstępuje od tej czynności. 
**§ 2.** Sąd stosownie do okoliczności, rozwoju umysłowego, stanu zdrowia 
i stopnia dojrzałości dziecka uwzględni jego zdanie i rozsądne życzenia. 
**§ 3.** Wysłuchanie dziecka może nastąpić tylko raz w toku postępowania, 
chyba że dobro dziecka wymaga ponownego przeprowadzenia tej czynności lub 
potrzebę ponownego wysłuchania zgłasza dziecko. Ponowne wysłuchanie dziecka 
przeprowadza ten sam sąd, chyba że jest to niemożliwe lub stoi temu na 
przeszkodzie dobro dziecka. 
**§ 4.** Jeżeli sąd odstąpił od wysłuchania dziecka, najpóźniej przed 
zakończeniem postępowania, wskazuje w protokole posiedzenia lub rozprawy, 
z jakich przyczyn czynność ta nie została przeprowadzona.

***
## Art. 2162. {#kpc-pierwsza-pierwsza-art-2162}

**§ 1.** Wysłuchanie dziecka następuje na posiedzeniu niejawnym, 
które odbywa się w odpowiednio przystosowanych pomieszczeniach w siedzibie 
sądu lub, jeżeli dobro dziecka tego wymaga, poza jego siedzibą. 
**§ 2.** W wysłuchaniu dziecka, oprócz sędziego, może brać udział wyłącznie 
biegły psycholog, jeżeli z uwagi na stan zdrowia, rozwój umysłowy lub wiek 
dziecka niezbędne jest zapewnienie mu pomocy psychologicznej podczas 
wysłuchania lub zachodzi konieczność udzielenia pomocy sędziemu w zakresie 
rozpoznania potrzeb dziecka podczas wysłuchania. 
**§ 3.** Z przebiegu wysłuchania dziecka sporządza się notatkę urzędową. 
Przebiegu wysłuchania dziecka nie utrwala się za pomocą urządzenia rejestrującego 
dźwięk albo obraz i dźwięk. 
**§ 4.** Minister Sprawiedliwości określi, w drodze rozporządzenia, sposób 
przygotowania i przeprowadzenia wysłuchania dziecka oraz warunki, jakim mają 
odpowiadać pomieszczenia przeznaczone do przeprowadzania takich wysłuchań, 
mając na względzie konieczność zapewnienia swobody wypowiedzi i poczucia 
bezpieczeństwa wysłuchiwanych dzieci. 

 
 
 
s. 105/580 
 
2025-09-08

***
## Art. 217. {#kpc-pierwsza-pierwsza-art-217}

(uchylony)

***
## Art. 218. {#kpc-pierwsza-pierwsza-art-218}

Sąd może zarządzić oddzielną rozprawę co do pozwu głównego 
i wzajemnego, jako też co do jednego z kilku roszczeń połączonych w jednym 
pozwie, bądź to głównym, bądź wzajemnym, albo w stosunku do poszczególnych 
współuczestników.

***
## Art. 219. {#kpc-pierwsza-pierwsza-art-219}

Sąd może zarządzić połączenie kilku oddzielnych spraw toczących 
się przed nim w celu ich łącznego rozpoznania lub także rozstrzygnięcia, jeżeli są 
one ze sobą w związku lub mogły być objęte jednym pozwem.

***
## Art. 220. {#kpc-pierwsza-pierwsza-art-220}

Sąd może ograniczyć rozprawę do poszczególnych zarzutów lub 
zagadnień wstępnych.

***
## Art. 221. {#kpc-pierwsza-pierwsza-art-221}

Pozwany nie może odmówić wdania się w spór co do istoty sprawy, 
chociaż wniósł zarzuty formalne.

***
## Art. 222. {#kpc-pierwsza-pierwsza-art-222}

Oddalając 
zarzuty, 
których 
uwzględnienie 
uzasadniałoby 
odrzucenie pozwu, sąd wyda oddzielne postanowienie i może wstrzymać dalsze 
rozpoznanie sprawy, aż do uprawomocnienia się tego postanowienia. Oddalenie 
innych zarzutów formalnych sąd stwierdza w uzasadnieniu orzeczenia kończącego 
postępowanie, przytaczając powody rozstrzygnięcia.

***
## Art. 223. {#kpc-pierwsza-pierwsza-art-223}

**§ 1.** Przewodniczący powinien we właściwej chwili skłaniać strony 
do pojednania, zwłaszcza na pierwszym posiedzeniu, po wstępnym wyjaśnieniu 
stanowiska stron. Osnowę ugody zawartej przed sądem wciąga się do protokołu 
rozprawy albo zamieszcza w odrębnym dokumencie stanowiącym część protokołu 
i stwierdza podpisami stron. Jeżeli do zawarcia ugody dochodzi w ramach 
posiedzenia zdalnego, a także jeżeli podpisanie ugody jest z innych przyczyn 
niemożliwe, sąd stwierdza niemożność podpisania ugody w protokole, o którym 
mowa w art. 158 § 1, wskazując przyczynę braku podpisu. 
**§ 2.** Przepis art. 203 § 4 stosuje się odpowiednio.

***
## Art. 224. {#kpc-pierwsza-pierwsza-art-224}

**§ 1.** Przewodniczący zamyka rozprawę po przeprowadzeniu 
dowodów i udzieleniu głosu stronom. 
**§ 2.** Można zamknąć rozprawę również w przypadku, gdy ma jeszcze zostać 
przeprowadzony dowód przez sędziego wyznaczonego lub przez sąd wezwany, 
dowód z dokumentu sporządzonego przez organ administracji publicznej lub 

 
 
 
s. 106/580 
 
2025-09-08 
 
znajdującego się w jego aktach albo dowód z dokumentu znajdującego się w aktach 
sądowych lub komorniczych, a rozprawę co do tych dowodów sąd uzna za 
zbyteczną. 
**§ 3.** Jeżeli przyczyni się to do sprawniejszego rozpoznania sprawy, 
a wyznaczanie kolejnych posiedzeń jest zbędne, sąd może zamknąć rozprawę na 
posiedzeniu niejawnym. Strony należy uprzedzić o możliwości zamknięcia 
rozprawy i umożliwić im zabranie głosu w piśmie procesowym, w terminie nie 
krótszym niż 7 dni. Sąd zamyka rozprawę w terminie miesiąca od dnia, w którym 
upłynął termin do zabrania głosu przez strony. Postanowienie może być wydane 
jedynie przez sędziów, przed którymi odbyło się ostatnie posiedzenie jawne 
poprzedzające bezpośrednio zamknięcie rozprawy.

***
## Art. 225. {#kpc-pierwsza-pierwsza-art-225}

Sąd może zamkniętą rozprawę otworzyć na nowo.

***
## Art. 226. {#kpc-pierwsza-pierwsza-art-226}

Od zarządzeń przewodniczącego wydanych w toku rozprawy strony 
mogą odwołać się do sądu.

***
## Art. 2261. {#kpc-pierwsza-pierwsza-art-2261}

Ilekroć ustawa przewiduje wysłuchanie stron lub innych osób, 
stosownie do okoliczności może się to odbyć przez: 
- 1) wezwanie stron do złożenia odpowiednich oświadczeń na posiedzeniu albo 
- 2) wyznaczenie terminu do zajęcia stanowiska: 
  - a) w piśmie procesowym lub 
  - b) za pomocą środków porozumiewania się na odległość, o ile dają one 
pewność co do osoby składającej oświadczenie.

***
## Art. 2262. {#kpc-pierwsza-pierwsza-art-2262}

**§ 1.** Ilekroć zachowanie strony w świetle okoliczności sprawy 
wskazuje na nadużycie przez nią prawa procesowego, sąd poucza ją o możliwości 
zastosowania wobec niej środków, o których mowa w § 2. 
**§ 2.** W przypadku gdy sąd stwierdzi nadużycie przez stronę prawa 
procesowego, może w orzeczeniu kończącym postępowanie w sprawie: 
- 1) stronę nadużywającą skazać na grzywnę; 
- 2) niezależnie od wyniku sprawy, odpowiednio do spowodowanej tym 
nadużyciem prawa procesowego zwłoki w jej rozpoznaniu, włożyć na stronę 
nadużywającą 
obowiązek 
zwrotu 
kosztów 
w części 
większej, 
niż 
wskazywałby wynik sprawy, a nawet zwrotu kosztów w całości; 
- 3) na wniosek strony przeciwnej: 

 
 
 
s. 107/580 
 
2025-09-08 
  - a) przyznać od strony nadużywającej koszty procesu podwyższone 
odpowiednio do spowodowanego tym nadużyciem zwiększenia nakładu 
pracy strony przeciwnej na prowadzenie sprawy, nie więcej jednak niż 
dwukrotnie, 
  - b) podwyższyć stopę odsetek zasądzonych od strony, której nadużycie 
spowodowało zwłokę w rozpoznaniu sprawy, za czas odpowiadający tej 
zwłoce, z tym że stopa może zostać podwyższona nie więcej niż 
dwukrotnie; przepisów o maksymalnej dopuszczalnej wysokości odsetek 
ustawowych za opóźnienie nie stosuje się. 
#### DZIAŁ III
Dowody 
Rozdział 1 
Przedmiot i ocena dowodów

***
## Art. 227. {#kpc-pierwsza-pierwsza-art-227}

Przedmiotem dowodu są fakty mające dla rozstrzygnięcia sprawy 
istotne znaczenie.

***
## Art. 228. {#kpc-pierwsza-pierwsza-art-228}

**§ 1.** Fakty powszechnie znane nie wymagają dowodu. Sąd bierze je 
pod rozwagę nawet bez powołania się na nie przez strony. 
**§ 2.** Nie wymagają dowodu również fakty, o których informacja jest 
powszechnie dostępna oraz fakty znane sądowi z urzędu, jednakże sąd powinien 
zwrócić na nie uwagę stron.

***
## Art. 229. {#kpc-pierwsza-pierwsza-art-229}

Nie wymagają również dowodu fakty przyznane w toku 
postępowania przez stronę przeciwną, jeżeli przyznanie nie budzi wątpliwości.

***
## Art. 230. {#kpc-pierwsza-pierwsza-art-230}

Gdy strona nie wypowie się co do twierdzeń strony przeciwnej 
o faktach, sąd, mając na uwadze wyniki całej rozprawy, może fakty te uznać za 
przyznane.

***
## Art. 231. {#kpc-pierwsza-pierwsza-art-231}

Sąd może uznać za ustalone fakty mające istotne znaczenie dla 
rozstrzygnięcia sprawy, jeżeli wniosek taki można wyprowadzić z innych 
ustalonych faktów (domniemanie faktyczne). 

 
 
 
s. 108/580 
 
2025-09-08

***
## Art. 232. {#kpc-pierwsza-pierwsza-art-232}

Strony są obowiązane wskazywać dowody dla stwierdzenia faktów, 
z których wywodzą skutki prawne. Sąd może dopuścić dowód niewskazany przez 
stronę.

***
## Art. 233. {#kpc-pierwsza-pierwsza-art-233}

**§ 1.** Sąd ocenia wiarogodność i moc dowodów według własnego 
przekonania, na podstawie wszechstronnego rozważenia zebranego materiału. 
**§ 2.** Sąd oceni na tej samej podstawie, jakie znaczenie nadać odmowie 
przedstawienia przez stronę dowodu lub przeszkodom stawianym przez nią w jego 
przeprowadzeniu wbrew postanowieniu sądu.

***
## Art. 234. {#kpc-pierwsza-pierwsza-art-234}

Domniemania ustanowione przez prawo (domniemania prawne) 
wiążą sąd; mogą być jednak obalone, ilekroć ustawa tego nie wyłącza. 
Rozdział 2 
Postępowanie dowodowe 
Oddział 1 
Przepisy ogólne

***
## Art. 235. {#kpc-pierwsza-pierwsza-art-235}

**§ 1.** Postępowanie 
dowodowe 
odbywa 
się 
przed 
sądem 
orzekającym, chyba że sprzeciwia się temu charakter dowodu albo wzgląd na 
poważne niedogodności lub niewspółmierność kosztów w stosunku do przedmiotu 
sporu. W takich wypadkach sąd orzekający zleci przeprowadzenie dowodu 
jednemu ze swych członków (sędzia wyznaczony) albo innemu sądowi (sąd 
wezwany). 
**§ 2.** Jeżeli charakter dowodu się temu nie sprzeciwia, sąd orzekający może 
postanowić, że jego przeprowadzenie nastąpi na odległość w ramach posiedzenia 
zdalnego. 
**§ 3.** Minister Sprawiedliwości określi, w drodze rozporządzenia, rodzaje 
urządzeń i środków technicznych wykorzystywanych w budynku sądu do 
przeprowadzenia dowodu w ramach posiedzenia zdalnego, sposób korzystania 
z tego rodzaju urządzeń i środków, jak również sposób przechowywania, 
odtwarzania i kopiowania zapisów dokonanych podczas jego przeprowadzenia, 
mając na względzie konieczność właściwego zabezpieczenia utrwalonego obrazu 
i dźwięku przed utratą dowodu, jego zniekształceniem lub nieuprawnionym 
ujawnieniem. 

 
 
 
s. 109/580 
 
2025-09-08

***
## Art. 2351. {#kpc-pierwsza-pierwsza-art-2351}

We wniosku o przeprowadzenie dowodu strona jest obowiązana 
oznaczyć dowód w sposób umożliwiający przeprowadzenie go oraz wyszczególnić 
fakty, które mają zostać wykazane tym dowodem. We wniosku można także 
wskazać, czy strona domaga się przeprowadzenia dowodu w ramach posiedzenia 
zdalnego.

***
## Art. 2352. {#kpc-pierwsza-pierwsza-art-2352}

**§ 1.** Sąd może w szczególności pominąć dowód: 
- 1) którego przeprowadzenie wyłącza przepis kodeksu; 
- 2) mający wykazać fakt bezsporny, nieistotny dla rozstrzygnięcia sprawy lub 
udowodniony zgodnie z twierdzeniem wnioskodawcy; 
- 3) nieprzydatny do wykazania danego faktu; 
- 4) niemożliwy do przeprowadzenia; 
- 5) zmierzający jedynie do przedłużenia postępowania; 
- 6) gdy wniosek strony nie odpowiada wymogom art. 2351, a strona mimo 
wezwania nie usunęła tego braku. 
**§ 2.** Pomijając dowód, sąd wydaje postanowienie, w którym wskazuje 
podstawę prawną tego rozstrzygnięcia.

***
## Art. 236. {#kpc-pierwsza-pierwsza-art-236}

**§ 1.** W postanowieniu o dopuszczeniu dowodu sąd oznaczy środek 
dowodowy i fakty, które mają nim zostać wykazane, a w miarę potrzeby 
i możliwości – także termin i miejsce przeprowadzenia dowodu. 
**§ 2.** Jeżeli o wydanie postanowienia w przedmiocie dopuszczenia dowodu 
wnosiła strona, w postanowieniu wystarczy powołać się na treść jej wniosku. 
**§ 3.** Zlecając przeprowadzenie dowodu sędziemu wyznaczonemu albo sądowi 
wezwanemu, sąd oznaczy tego sędziego albo ten sąd. Jeżeli nie oznaczono terminu 
lub miejsca przeprowadzenia dowodu, oznaczy je sędzia wyznaczony albo sąd 
wezwany.

***
## Art. 237. {#kpc-pierwsza-pierwsza-art-237}

Niestawiennictwo stron na termin nie wstrzymuje przeprowadzenia 
dowodu, chyba że obecność stron lub jednej z nich okaże się konieczna.

***
## Art. 238. {#kpc-pierwsza-pierwsza-art-238}

**§ 1.** Protokół sporządzony zgodnie z art. 157 § 11, zawierający 
przebieg postępowania dowodowego przed sędzią wyznaczonym lub przed sądem 
wezwanym, podpisują, oprócz sędziego i protokolanta, także osoby przesłuchane 
oraz strony, jeżeli są obecne. 
**§ 2.** Odmowę lub niemożność podpisania stwierdza się w protokole. 

 
 
 
s. 110/580 
 
2025-09-08

***
## Art. 239. {#kpc-pierwsza-pierwsza-art-239}

Sędzia wyznaczony i sąd wezwany mają w zakresie zleconego im 
postępowania dowodowego prawa przewodniczącego i prawa sądu orzekającego. 
Na ich uchybienia strony mogą zwrócić uwagę sądu nie później niż na najbliższej 
rozprawie.

***
## Art. 240. {#kpc-pierwsza-pierwsza-art-240}

**§ 1.** Sąd nie jest związany swym postanowieniem dowodowym 
i może je stosownie do okoliczności uchylić lub zmienić. 
**§ 2.** Sędzia wyznaczony i sąd wezwany mogą uzupełnić na wniosek strony 
postanowienie sądu orzekającego przez przesłuchanie nowych świadków na fakty 
wskazane w tym postanowieniu.

***
## Art. 241. {#kpc-pierwsza-pierwsza-art-241}

Sąd orzekający może zarządzić powtórzenie lub uzupełnienie 
postępowania dowodowego.

***
## Art. 242. {#kpc-pierwsza-pierwsza-art-242}

Jeżeli 
postępowanie 
dowodowe 
napotyka 
przeszkody 
o nieokreślonym czasie trwania, sąd może oznaczyć termin, po którego upływie 
dowód może być przeprowadzony tylko wówczas, gdy nie spowoduje to zwłoki w 
postępowaniu.

***
## Art. 2421. {#kpc-pierwsza-pierwsza-art-2421}

Strona, która wnosiła o wezwanie na rozprawę świadka, biegłego 
lub innej osoby, powinna dołożyć starań, by osoba ta stawiła się w wyznaczonym 
czasie i miejscu, w szczególności zawiadomić ją o obowiązku, czasie i miejscu 
stawiennictwa.

***
## Art. 2422. {#kpc-pierwsza-pierwsza-art-2422}

**§ 1.** Ilekroć ustawa przewiduje odebranie przyrzeczenia od osoby 
stawającej przed sądem, może je odebrać tylko sąd lub sędzia wyznaczony. 
**§ 2.** Osobie, która w danej sprawie składała już przyrzeczenie, przypomina się 
je przy czynności z jej udziałem, chyba że będzie potrzebne ponowne odebranie 
przyrzeczenia.

***
## Art. 243. {#kpc-pierwsza-pierwsza-art-243}

Zachowanie 
szczegółowych 
przepisów 
o postępowaniu 
dowodowym nie jest konieczne, ilekroć ustawa przewiduje uprawdopodobnienie 
zamiast dowodu. 

 
 
 
s. 111/580 
 
2025-09-08 
 
Oddział 2 
Dokumenty

***
## Art. 2431. {#kpc-pierwsza-pierwsza-art-2431}

Przepisy niniejszego oddziału stosuje się do dokumentów 
zawierających tekst, umożliwiających ustalenie ich wystawców.

***
## Art. 2432. {#kpc-pierwsza-pierwsza-art-2432}

Dokumenty znajdujące się w aktach sprawy lub do nich dołączone 
stanowią dowody bez wydawania odrębnego postanowienia. Pomijając dowód 
z takiego dokumentu, sąd wydaje postanowienie.

***
## Art. 244. {#kpc-pierwsza-pierwsza-art-244}

**§ 1.** Dokumenty urzędowe, sporządzone w przepisanej formie przez 
powołane do tego organy władzy publicznej i inne organy państwowe w zakresie 
ich działania, stanowią dowód tego, co zostało w nich urzędowo zaświadczone. 
**§ 2.** Przepis § 1 stosuje się odpowiednio do dokumentów urzędowych 
sporządzonych przez podmioty, inne niż wymienione w § 1, w zakresie zleconych 
im przez ustawę zadań z dziedziny administracji publicznej.

***
## Art. 245. {#kpc-pierwsza-pierwsza-art-245}

Dokument prywatny sporządzony w formie pisemnej albo 
elektronicznej stanowi dowód tego, że osoba, która go podpisała, złożyła 
oświadczenie zawarte w dokumencie.

***
## Art. 246. {#kpc-pierwsza-pierwsza-art-246}

Jeżeli ustawa lub umowa stron wymaga dla czynności prawnej 
zachowania formy pisemnej, dowód ze świadków lub z przesłuchania stron 
w sprawie między uczestnikami tej czynności na fakt jej dokonania jest 
dopuszczalny w wypadku, gdy dokument obejmujący czynność został zagubiony, 
zniszczony lub zabrany przez osobę trzecią, a jeżeli forma pisemna była 
zastrzeżona tylko dla celów dowodowych, także w wypadkach określonych 
w kodeksie cywilnym.

***
## Art. 247. {#kpc-pierwsza-pierwsza-art-247}

Dowód ze świadków lub z przesłuchania stron przeciwko osnowie 
lub ponad osnowę dokumentu obejmującego czynność prawną może być 
dopuszczony między uczestnikami tej czynności tylko w wypadkach, gdy nie 
doprowadzi to do obejścia przepisów o formie zastrzeżonej pod rygorem 
nieważności i gdy ze względu na szczególne okoliczności sprawy sąd uzna to za 
konieczne.

***
## Art. 248. {#kpc-pierwsza-pierwsza-art-248}

**§ 1.** Każdy obowiązany jest przedstawić na zarządzenie sądu 
w oznaczonym terminie i miejscu dokument znajdujący się w jego posiadaniu 

 
 
 
s. 112/580 
 
2025-09-08 
 
i stanowiący dowód faktu istotnego dla rozstrzygnięcia sprawy, chyba że dokument 
zawiera informacje niejawne. 
**§ 2.** Od powyższego obowiązku może uchylić się ten, kto co do okoliczności 
objętych treścią dokumentu mógłby jako świadek odmówić zeznania albo kto 
posiada dokument w imieniu osoby trzeciej, która mogłaby z takich samych 
przyczyn sprzeciwić się przedstawieniu dokumentu. Jednakże i wówczas nie 
można odmówić przedstawienia dokumentu, gdy jego posiadacz lub osoba trzecia 
obowiązani są do tego względem chociażby jednej ze stron albo gdy dokument 
wystawiony jest w interesie strony, która żąda przeprowadzenia dowodu. Strona 
nie może ponadto odmówić przedstawienia dokumentu, jeżeli szkoda, na którą 
byłaby przez to narażona, polega na przegraniu procesu.

***
## Art. 249. {#kpc-pierwsza-pierwsza-art-249}

**§ 1.** W sprawach dotyczących przedsiębiorstwa handlowego lub 
przemysłowego, w razie powołania się jednej ze stron na księgi i dokumenty 
przedsiębiorstwa, należy je przedstawić sądowi, jeżeli sąd uzna wyciąg za 
niewystarczający. 
**§ 2.** Gdy zachodzi istotna trudność w dostarczeniu ksiąg do sądu, sąd może 
przejrzeć je na miejscu lub zlecić sędziemu wyznaczonemu ich przejrzenie 
i sporządzenie niezbędnych wyciągów.

***
## Art. 250. {#kpc-pierwsza-pierwsza-art-250}

**§ 1.** Jeżeli dokument znajduje się w aktach organów lub podmiotów, 
o których mowa w art. 244 § 1 i 2, wystarczy przedstawić urzędowo poświadczony 
przez ten organ lub podmiot odpis lub wyciąg z dokumentu. Sąd zażąda wydania 
odpisu lub wyciągu, jeżeli strona sama nie może go uzyskać. 
**§ 2.** Gdy sąd uzna za konieczne przejrzenie oryginału dokumentu, może 
zarządzić, by go dostarczono na rozprawę, albo przejrzeć go na miejscu przez 
sędziego wyznaczonego lub przez cały skład sądu.

***
## Art. 251. {#kpc-pierwsza-pierwsza-art-251}

Za nieuzasadnioną odmowę przedstawienia dokumentu przez osobę 
trzecią sąd, po wysłuchaniu jej oraz stron co do zasadności odmowy, skaże osobę 
trzecią na grzywnę. Osoba trzecia ma prawo żądać zwrotu wydatków połączonych 
z przedstawieniem dokumentu.

***
## Art. 252. {#kpc-pierwsza-pierwsza-art-252}

Strona, która zaprzecza prawdziwości dokumentu urzędowego albo 
twierdzi, że zawarte w nim oświadczenia organu, od którego dokument ten 
pochodzi, są niezgodne z prawdą, powinna okoliczności te udowodnić. 

 
 
 
s. 113/580 
 
2025-09-08

***
## Art. 253. {#kpc-pierwsza-pierwsza-art-253}

Jeżeli strona zaprzecza prawdziwości dokumentu prywatnego albo 
twierdzi, że zawarte w nim oświadczenie osoby, która je podpisała, od niej nie 
pochodzi, obowiązana jest okoliczności te udowodnić. Jeżeli jednak spór dotyczy 
dokumentu prywatnego pochodzącego od innej osoby niż strona zaprzeczająca, 
prawdziwość dokumentu powinna udowodnić strona, która chce z niego 
skorzystać.

***
## Art. 254. {#kpc-pierwsza-pierwsza-art-254}

**§ 1.** Badania prawdziwości dokumentu można dokonać z udziałem 
biegłego. 
**§ 11.** Badanie prawdziwości pisma może nastąpić przez porównanie pisma na 
zakwestionowanym dokumencie z pismem tej samej osoby na innych dokumentach 
niewątpliwie prawdziwych. Sąd w razie potrzeby może wezwać osobę, od której 
pismo pochodzi, w celu napisania podyktowanych jej wyrazów. 
**§ 2.** Od obowiązku złożenia próby pisma zwolniony jest ten, kto na zapytanie, 
czy pismo na dokumencie jest prawdziwe, mógłby jako świadek odmówić 
zeznania. 
**§ 21.** Sąd 
w razie 
potrzeby 
może 
wezwać 
wystawcę 
dokumentu 
sporządzonego w postaci elektronicznej do udostępnienia informatycznego nośnika 
danych, na którym ten dokument został zapisany. 
**§ 22.** Od obowiązku udostępnienia informatycznego nośnika danych 
zwolniony jest ten, kto na pytanie, czy dokument sporządzono na tym 
informatycznym nośniku danych lub czy pochodzi on od niego, mógłby jako 
świadek odmówić zeznań. 
**§ 3.** Sąd może zastosować do osoby trzeciej, która nie wykonała zarządzeń 
sądu wydanych w myśl paragrafów poprzedzających, takie same środki 
przymusowe, jak wobec świadków. 
**§ 4.** Osoba trzecia może na równi ze świadkiem żądać zwrotu wydatków 
koniecznych związanych ze stawiennictwem do sądu lub udostępnieniem 
informatycznego nośnika danych, a ponadto wynagrodzenia za utratę zarobku.

***
## Art. 255. {#kpc-pierwsza-pierwsza-art-255}

Strona, która w złej wierze lub lekkomyślnie zgłosiła zarzuty 
przewidziane w art. 252 i 253, podlega karze grzywny.

***
## Art. 256. {#kpc-pierwsza-pierwsza-art-256}

Sąd może zażądać, aby dokument w języku obcym był przełożony 
przez tłumacza przysięgłego. 

 
 
 
s. 114/580 
 
2025-09-08

***
## Art. 257. {#kpc-pierwsza-pierwsza-art-257}

Sąd oceni na podstawie okoliczności poszczególnego wypadku, czy 
i o ile dokument zachowuje moc dowodową pomimo przekreśleń, podskrobań lub 
innych uszkodzeń. 
Oddział 3 
Zeznania świadków

***
## Art. 258. {#kpc-pierwsza-pierwsza-art-258}

(uchylony)

***
## Art. 259. {#kpc-pierwsza-pierwsza-art-259}

Świadkami nie mogą być: 
- 1) osoby niezdolne do spostrzegania lub komunikowania swych spostrzeżeń; 
- 2) wojskowi i urzędnicy niezwolnieni od zachowania w tajemnicy informacji 
niejawnych o klauzuli „zastrzeżone” lub „poufne” oraz osoby zobowiązane 
do zachowania tajemnicy Prokuratorii Generalnej Rzeczypospolitej Polskiej, 
jeżeli ich zeznanie miałoby być połączone z jej naruszeniem; 
- 3) przedstawiciele ustawowi stron oraz osoby, które mogą być przesłuchane 
w charakterze strony jako organy osoby prawnej lub innej organizacji mającej 
zdolność sądową; 
- 4) współuczestnicy jednolici.

***
## Art. 2591. {#kpc-pierwsza-pierwsza-art-2591}

Mediator nie może być świadkiem co do faktów, o których 
dowiedział się w związku z prowadzeniem mediacji, chyba że strony zwolnią go 
z obowiązku zachowania tajemnicy mediacji.

***
## Art. 260. {#kpc-pierwsza-pierwsza-art-260}

Współuczestnik sporu, niebędący współuczestnikiem jednolitym, 
może być świadkiem co do faktów dotyczących wyłącznie innego współuczestnika.

***
## Art. 261. {#kpc-pierwsza-pierwsza-art-261}

**§ 1.** Nikt nie ma prawa odmówić zeznań w charakterze świadka, 
z wyjątkiem małżonków stron, ich wstępnych, zstępnych i rodzeństwa oraz 
powinowatych w tej samej linii lub stopniu, jak również osób pozostających ze 
stronami w stosunku przysposobienia. Prawo odmowy zeznań trwa po ustaniu 
małżeństwa lub rozwiązaniu stosunku przysposobienia. Jednakże odmowa zeznań 
nie jest dopuszczalna w sprawach o prawa stanu, z wyjątkiem spraw o rozwód. 
**§ 2.** Świadek może odmówić odpowiedzi na zadane mu pytanie, jeżeli 
zeznanie mogłoby narazić jego lub jego bliskich, wymienionych w paragrafie 
poprzedzającym, na odpowiedzialność karną, hańbę lub dotkliwą i bezpośrednią 
szkodę majątkową albo jeżeli zeznanie miałoby być połączone z pogwałceniem 

 
 
 
s. 115/580 
 
2025-09-08 
 
istotnej tajemnicy zawodowej. Duchowny może odmówić zeznań co do faktów 
powierzonych mu na spowiedzi.

***
## Art. 262. {#kpc-pierwsza-pierwsza-art-262}

Sąd, wzywając świadka, wymieni w wezwaniu imię, nazwisko 
i zamieszkanie wezwanego, miejsce i czas przesłuchania, nazwiska stron 
i przedmiot sprawy oraz zwięzłą osnowę przepisów o karach za pogwałcenie 
obowiązków świadka, a ponadto o zwrocie wydatków koniecznych, związanych ze 
stawiennictwem do sądu, oraz o wynagrodzeniu za utratę zarobku.

***
## Art. 263. {#kpc-pierwsza-pierwsza-art-263}

Świadka, który nie może się stawić na wezwanie z powodu choroby, 
niepełnosprawności lub innej niedającej się usunąć przeszkody, przesłuchuje się 
w miejscu jego pobytu.

***
## Art. 2631. {#kpc-pierwsza-pierwsza-art-2631}

Strona może sprzeciwić się przesłuchaniu świadka poza salą 
sądową w ramach posiedzenia zdalnego, nie później jednak niż w terminie 7 dni od 
dnia uzyskania informacji o zamiarze przeprowadzenia dowodu w taki sposób. 
W razie skutecznego wniesienia sprzeciwu sąd wzywa świadka do osobistego 
stawiennictwa na sali sądowej.

***
## Art. 264. {#kpc-pierwsza-pierwsza-art-264}

Kolejność przesłuchania świadków oznacza przewodniczący. 
Świadkowie, którzy nie złożyli jeszcze zeznań, nie mogą być obecni przy 
przesłuchaniu innych świadków.

***
## Art. 265. {#kpc-pierwsza-pierwsza-art-265}

**§ 1.** Do przesłuchania świadka niewładającego dostatecznie 
językiem polskim sąd może przybrać tłumacza. 
**§ 2.** Do tłumaczy stosuje się odpowiednio przepisy o biegłych. Pracownik 
organów wymiaru sprawiedliwości może pełnić obowiązki tłumacza bez składania 
przyrzeczenia, lecz z powołaniem się na ślubowanie służbowe.

***
## Art. 266. {#kpc-pierwsza-pierwsza-art-266}

**§ 1.** Przed przesłuchaniem świadka uprzedza się go o prawie 
odmowy zeznań i odpowiedzialności karnej za złożenie fałszywych zeznań. 
**§ 2.** Przesłuchanie rozpoczyna się od zadania świadkowi pytań dotyczących 
jego osoby oraz stosunku do stron. 
**§ 3.** Jeżeli świadek ma składać zeznania, odbiera się od niego przyrzeczenie, 
po pouczeniu go o znaczeniu tego aktu.

***
## Art. 267. {#kpc-pierwsza-pierwsza-art-267}

Nie składają przyrzeczenia świadkowie małoletni, którzy nie 
ukończyli lat siedemnastu, oraz osoby skazane wyrokiem prawomocnym za 

 
 
 
s. 116/580 
 
2025-09-08 
 
fałszywe zeznania. Inni świadkowie mogą być za zgodą stron zwolnieni przez sąd 
od złożenia przyrzeczenia.

***
## Art. 268. {#kpc-pierwsza-pierwsza-art-268}

Brzmienie przyrzeczenia jest następujące: „Świadomy znaczenia 
mych słów i odpowiedzialności przed prawem przyrzekam uroczyście, że będę 
mówił szczerą prawdę, niczego nie ukrywając z tego, co mi jest wiadome”.

***
## Art. 269. {#kpc-pierwsza-pierwsza-art-269}

**§ 1.** Świadek składa przyrzeczenie, powtarzając za sędzią lub 
odczytując na głos tekst przyrzeczenia, przy czym wszyscy – z wyjątkiem sędziów 
– stoją. Przewodniczący może zwolnić osoby pozostające poza salą sądową 
z obowiązku powstania, jeżeli wykonanie tego obowiązku nie licowałoby z powagą 
czynności lub mogło niekorzystnie wpłynąć na jakość utrwalenia obrazu i dźwięku 
z tej czynności. 
**§ 2.** Niemi i głusi składają przyrzeczenie przez podpisanie jego tekstu lub przy 
pomocy biegłego.

***
## Art. 270. {#kpc-pierwsza-pierwsza-art-270}

(uchylony)

***
## Art. 271. {#kpc-pierwsza-pierwsza-art-271}

**§ 1.** Świadek składa zeznanie ustnie, zaczynając od odpowiedzi na 
pytania przewodniczącego, co i z jakiego źródła wiadomo mu w sprawie, po czym 
sędziowie i strony mogą w tymże przedmiocie zadawać mu pytania. 
**§ 2.** Niemi i głusi składają zeznania na piśmie lub przy pomocy biegłego.

***
## Art. 2711. {#kpc-pierwsza-pierwsza-art-2711}

Świadek składa zeznanie na piśmie, jeżeli sąd tak postanowi. 
W takim przypadku świadek składa przyrzeczenie przez podpisanie tekstu 
przyrzeczenia. Świadek jest obowiązany złożyć tekst zeznania w sądzie w terminie 
wyznaczonym przez sąd. Przepisy art. 165 § 2, art. 274 § 1 i art. 276 stosuje się 
odpowiednio.

***
## Art. 272. {#kpc-pierwsza-pierwsza-art-272}

Świadkowie, których zeznania przeczą sobie wzajemnie, mogą być 
konfrontowani.

***
## Art. 2721. {#kpc-pierwsza-pierwsza-art-2721}

Jeżeli sąd poweźmie wątpliwość co do zdolności spostrzegania lub 
komunikowania spostrzeżeń przez świadka, może zarządzić przesłuchanie go 
z udziałem biegłego lekarza lub psychologa, a świadek nie może się temu 
sprzeciwić. 

 
 
 
s. 117/580 
 
2025-09-08

***
## Art. 273. {#kpc-pierwsza-pierwsza-art-273}

**§ 1.** Zeznanie świadka, po zapisaniu do protokołu, sporządzonego 
zgodnie z art. 157 § 11, będzie mu odczytane i stosownie do okoliczności na 
podstawie jego uwag uzupełnione i sprostowane. 
**§ 2.** Świadek może oddalić się z sądu nie wcześniej niż po uzyskaniu na to 
zezwolenia przewodniczącego.

***
## Art. 274. {#kpc-pierwsza-pierwsza-art-274}

**§ 1.** Za nieusprawiedliwione niestawiennictwo sąd skaże świadka 
na grzywnę, po czym wezwie go powtórnie, a w razie ponownego niestawiennictwa 
skaże go na ponowną grzywnę i może zarządzić jego przymusowe sprowadzenie. 
**§ 2.** Przepis paragrafu poprzedzającego stosuje się odpowiednio do świadka, 
który oddalił się bez zezwolenia przewodniczącego.

***
## Art. 275. {#kpc-pierwsza-pierwsza-art-275}

Świadek w ciągu tygodnia od dnia doręczenia mu postanowienia 
skazującego go na grzywnę lub na pierwszym posiedzeniu, na które zostanie 
wezwany, może usprawiedliwić swe niestawiennictwo. W przypadku usprawiedli-
wienia niestawiennictwa sąd zwolni świadka od grzywny i przymusowego 
sprowadzenia.

***
## Art. 276. {#kpc-pierwsza-pierwsza-art-276}

**§ 1.** Za nieuzasadnioną odmowę zeznań lub przyrzeczenia sąd, po 
wysłuchaniu obecnych stron co do zasadności odmowy, skaże świadka na grzywnę. 
**§ 2.** Niezależnie od powyższej grzywny sąd może nakazać aresztowanie 
świadka na czas nieprzekraczający tygodnia. Sąd uchyli areszt, jeżeli świadek złoży 
zeznanie lub przyrzeczenie albo jeżeli sprawę ukończono w instancji, w której 
dowód z tego świadka został dopuszczony.

***
## Art. 2761. {#kpc-pierwsza-pierwsza-art-2761}

W razie uchybienia przez żołnierza w czynnej służbie wojskowej, 
z wyjątkiem terytorialnej służby wojskowej pełnionej dyspozycyjnie, obowiązkom, 
o których mowa w art. 274 i art. 276, sąd, zamiast skazać żołnierza na grzywnę, 
występuje do dowódcy jednostki wojskowej, w której żołnierz ten pełni służbę, z 
wnioskiem o pociągnięcie go do odpowiedzialności dyscyplinarnej.

***
## Art. 277. {#kpc-pierwsza-pierwsza-art-277}

Świadek ma prawo żądać zwrotu wydatków koniecznych, 
związanych ze stawiennictwem do sądu, a ponadto wynagrodzenia za utratę 
zarobku. Przewodniczący może przyznać świadkowi zaliczkę na koszty podróży 
i na utrzymanie w miejscu przesłuchania. 

 
 
 
s. 118/580 
 
2025-09-08 
 
Oddział 4 
Opinia biegłych

***
## Art. 278. {#kpc-pierwsza-pierwsza-art-278}

**§ 1.** W wypadkach wymagających wiadomości specjalnych sąd po 
wysłuchaniu wniosków stron co do liczby biegłych i ich wyboru może wezwać 
jednego lub kilku biegłych w celu zasięgnięcia ich opinii. 
**§ 2.** Sąd orzekający może pozostawić prawo wyboru biegłego sędziemu 
wyznaczonemu lub sądowi wezwanemu. 
**§ 3.** Sąd oznaczy, czy opinia ma być przedstawiona ustnie, czy na piśmie. 
**§ 4.** Jeżeli sąd nie wyznaczył osoby biegłego, wskazuje ją przewodniczący.

***
## Art. 2781. {#kpc-pierwsza-pierwsza-art-2781}

Sąd może dopuścić dowód z opinii sporządzonej na zlecenie 
organu władzy publicznej w innym postępowaniu przewidzianym przez ustawę.

***
## Art. 279. {#kpc-pierwsza-pierwsza-art-279}

(uchylony)

***
## Art. 280. {#kpc-pierwsza-pierwsza-art-280}

**§ 1.** Osoba wyznaczona na biegłego może nie przyjąć włożonego na 
nią obowiązku z przyczyn, jakie uprawniają świadka do odmowy zeznań, a ponadto 
z powodu przeszkody, która uniemożliwia jej wydanie opinii. 
**§ 2.** W uzasadnionych przypadkach, w szczególności jeżeli jest to niezbędne 
do ustalenia wysokości kosztów sporządzenia opinii lub terminu jej sporządzenia 
albo pozwoli to na usprawnienie postępowania, przewodniczący może umożliwić 
wskazanej osobie, jeszcze przed wyznaczeniem jej na biegłego, zapoznanie się 
w niezbędnym zakresie z aktami sprawy.

***
## Art. 281. {#kpc-pierwsza-pierwsza-art-281}

**§ 1.** Aż do ukończenia czynności biegłego strona może żądać jego 
wyłączenia z przyczyn, z jakich można żądać wyłączenia sędziego. Gdy strona 
zgłasza wniosek o wyłączenie biegłego po rozpoczęciu przez niego czynności, 
obowiązana jest uprawdopodobnić, że przyczyna wyłączenia powstała później lub 
że przedtem nie była jej znana. 
**§ 2.** O wyłączeniu biegłego rozstrzyga sąd prowadzący sprawę po 
wysłuchaniu stron i biegłego. Od wysłuchania stron lub biegłego można odstąpić, 
gdyby miało to doprowadzić do nadmiernej zwłoki w postępowaniu.

***
## Art. 282. {#kpc-pierwsza-pierwsza-art-282}

**§ 1.** Biegły składa przed rozpoczęciem czynności przyrzeczenie 
w następującym brzmieniu: „Świadomy znaczenia mych słów i odpowiedzialności 

 
 
 
s. 119/580 
 
2025-09-08 
 
przed prawem przyrzekam uroczyście, że powierzone mi obowiązki biegłego 
wykonam z całą sumiennością i bezstronnością”. 
**§ 11.** Biegły, któremu zlecono sporządzenie opinii na piśmie, może złożyć 
przyrzeczenie przez podpisanie tekstu przyrzeczenia, który załącza do opinii. 
**§ 12.** Od biegłego wpisanego na listę biegłych sądowych nie odbiera się 
przyrzeczenia. Biegły taki powołuje się na przyrzeczenie złożone przy 
ustanowieniu go w tym charakterze. 
**§ 2.** Poza tym do przyrzeczenia biegłych stosuje się odpowiednio przepisy 
dotyczące przyrzeczenia świadków.

***
## Art. 283. {#kpc-pierwsza-pierwsza-art-283}

(uchylony)

***
## Art. 284. {#kpc-pierwsza-pierwsza-art-284}

**§ 1.** Sąd może zarządzić przedstawienie biegłemu w niezbędnym 
zakresie akt sprawy lub przedmiotu oględzin oraz zarządzić, by był obecny lub brał 
udział w przeprowadzeniu dowodu. 
**§ 2.** Przedstawienie akt sprawy lub ich kopii biegłemu wpisanemu na listę 
biegłych sądowych może nastąpić za pośrednictwem portalu informacyjnego. 
**§ 3.** Sąd zarządza przeprowadzenie czynności z udziałem biegłego na sali 
sądowej na uzasadniony wniosek strony, albo w przypadku, gdy wiarygodność 
opinii przedstawianej w ramach posiedzenia zdalnego budzi wątpliwości.

***
## Art. 285. {#kpc-pierwsza-pierwsza-art-285}

**§ 1.** Opinia biegłego powinna zawierać uzasadnienie. 
**§ 2.** Biegli mogą złożyć opinię łączną. 
**§ 3.** Jeżeli biegły nie może na razie udzielić wyczerpującej opinii, sąd 
wyznaczy termin dodatkowy do jej przedstawienia.

***
## Art. 286. {#kpc-pierwsza-pierwsza-art-286}

Sąd może zażądać ustnego lub pisemnego uzupełnienia opinii lub 
jej wyjaśnienia, a także dodatkowej opinii od tych samych lub innych biegłych.

***
## Art. 287. {#kpc-pierwsza-pierwsza-art-287}

Za nieusprawiedliwione niestawiennictwo, za nieuzasadnioną 
odmowę złożenia przyrzeczenia lub opinii albo za nieusprawiedliwione opóźnienie 
złożenia opinii sąd skaże biegłego na grzywnę.

***
## Art. 288. {#kpc-pierwsza-pierwsza-art-288}

**§ 1.** Biegły ma prawo żądać wynagrodzenia za stawiennictwo 
w sądzie i wykonaną pracę oraz zwrotu wydatków. 
**§ 2.** Przewodniczący może przyznać biegłemu zaliczkę na poczet wydatków. 

 
 
 
s. 120/580 
 
2025-09-08 
**§ 3.** Jeżeli opinia jest niezrozumiała, zawiera sprzeczności lub istotne braki, 
sąd może zarządzić, że przyznanie wynagrodzenia i zwrot wydatków nastąpi po jej 
uzupełnieniu lub wyjaśnieniu. Na postanowienie sądu zażalenie nie przysługuje.

***
## Art. 289. {#kpc-pierwsza-pierwsza-art-289}

Do wezwania i przesłuchania biegłych stosuje się ponadto 
odpowiednio przepisy o świadkach, z wyjątkiem art. 2631 oraz przepisów 
o przymusowym sprowadzeniu.

***
## Art. 290. {#kpc-pierwsza-pierwsza-art-290}

**§ 1.** Sąd może zażądać opinii odpowiedniego instytutu naukowego 
lub naukowo-badawczego. Sąd może zażądać od instytutu dodatkowych wyjaśnień 
bądź pisemnych, bądź ustnych przez wyznaczoną do tego osobę, może też zarządzić 
złożenie dodatkowej opinii przez ten sam lub inny instytut. 
**§ 2.** W opinii instytutu należy wskazać osoby, które przeprowadziły badanie 
i wydały opinię. 
**§ 3.** Sąd może zażądać ustnego lub pisemnego uzupełnienia opinii lub jej 
wyjaśnienia, a także dodatkowej opinii od tego samego lub innego instytutu 
naukowego lub naukowo-badawczego. 
**§ 4.** Jeżeli opinia została sporządzona przez instytut naukowy lub naukowo-
-badawczy, ustne jej uzupełnienie lub wyjaśnienie albo dodatkową opinię składa 
osoba wyznaczona do tego przez ten instytut. Sąd może jednak zarządzić stawienie 
się na rozprawie i złożenie ustnego uzupełnienia lub wyjaśnienia opinii albo 
dodatkowej opinii także przez osoby, które sporządziły opinię w imieniu tego 
instytutu. 
**§ 5.** Strona może żądać wyłączenia osoby wyznaczonej do sporządzenia 
opinii przez instytut naukowy lub naukowo-badawczy. Przepis art. 281 stosuje się 
odpowiednio.

***
## Art. 2901. {#kpc-pierwsza-pierwsza-art-2901}

W sprawach rodzinnych i opiekuńczych sąd może zażądać opinii 
opiniodawczego zespołu sądowych specjalistów. Do opinii zespołu stosuje się 
odpowiednio przepisy o opinii instytutu naukowego lub naukowo-badawczego.

***
## Art. 291. {#kpc-pierwsza-pierwsza-art-291}

Instytut 
naukowy 
lub 
naukowo-badawczy 
może 
żądać 
wynagrodzenia za wykonaną pracę i za stawiennictwo swoich przedstawicieli. 

 
 
 
s. 121/580 
 
2025-09-08 
 
Oddział 5 
Oględziny

***
## Art. 292. {#kpc-pierwsza-pierwsza-art-292}

Sąd może zarządzić oględziny bez udziału lub z udziałem biegłych, 
a stosownie do okoliczności – również w połączeniu z przesłuchaniem świadków.

***
## Art. 293. {#kpc-pierwsza-pierwsza-art-293}

Przepisy o obowiązku przedstawienia dokumentu stosuje się 
odpowiednio do przedstawienia przedmiotu oględzin. Jeżeli rodzaj przedmiotu na 
to pozwala i nie jest to połączone ze znacznymi kosztami, należy przedmiot 
oględzin dostarczyć do sądu.

***
## Art. 294. {#kpc-pierwsza-pierwsza-art-294}

Jeżeli przedmiot oględzin jest w posiadaniu osoby trzeciej, 
a oględziny mają być dokonane w miejscu, gdzie przedmiot znajduje się, osoba ta 
powinna być wezwana na termin oględzin i obowiązana jest ułatwić dostęp do 
przedmiotu.

***
## Art. 295. {#kpc-pierwsza-pierwsza-art-295}

**§ 1.** Osoba trzecia w ciągu dni trzech od doręczenia jej wezwania 
może z ważnych przyczyn żądać od sądu wzywającego zaniechania oględzin. 
**§ 2.** Przed rozpoznaniem żądania osoby trzeciej sąd nie przystąpi do oględzin.

***
## Art. 296. {#kpc-pierwsza-pierwsza-art-296}

Osobę trzecią, która bez uzasadnionych przyczyn nie zastosowała 
się do zarządzeń w przedmiocie oględzin, sąd skaże na grzywnę.

***
## Art. 297. {#kpc-pierwsza-pierwsza-art-297}

Osoba trzecia wezwana na termin oględzin ma prawo żądać zwrotu 
wydatków koniecznych, związanych ze stawiennictwem do sądu, oraz 
wynagrodzenia za utratę zarobku na równi ze świadkiem, a ponadto zwrotu 
wydatków połączonych z dostarczeniem przedmiotu oględzin.

***
## Art. 298. {#kpc-pierwsza-pierwsza-art-298}

Oględziny osoby mogą odbyć się tylko za jej zgodą. 
Oddział 6 
Przesłuchanie stron

***
## Art. 299. {#kpc-pierwsza-pierwsza-art-299}

Jeżeli po wyczerpaniu środków dowodowych lub w ich braku 
pozostały niewyjaśnione fakty istotne dla rozstrzygnięcia sprawy, sąd dla 
wyjaśnienia tych faktów może dopuścić dowód z przesłuchania stron. 

 
 
 
s. 122/580 
 
2025-09-08

***
## Art. 300. {#kpc-pierwsza-pierwsza-art-300}

**§ 1.** Za osobę prawną sąd przesłuchuje osoby wchodzące w skład 
organu uprawnionego do jej reprezentowania, przy czym sąd decyduje, czy 
przesłuchać wszystkie te osoby, czy też tylko niektóre z nich. 
**§ 2.** Za Skarb Państwa sąd może przesłuchać w charakterze strony osoby 
powołane do reprezentowania państwowej jednostki organizacyjnej, z której 
działalnością wiąże się dochodzone roszczenie, lub inne wskazane osoby.

***
## Art. 301. {#kpc-pierwsza-pierwsza-art-301}

Jeżeli powództwo jest wytoczone przez prokuratora lub organizację 
pozarządową na rzecz oznaczonej osoby, przesłuchuje się w charakterze strony 
powodowej tę osobę, chociażby nie przystąpiła ona do sprawy.

***
## Art. 302. {#kpc-pierwsza-pierwsza-art-302}

**§ 1.** Gdy z przyczyn natury faktycznej lub prawnej przesłuchać 
można co do okoliczności spornych jedną tylko stronę, sąd oceni, czy mimo to 
należy przesłuchać tę stronę, czy też dowód ten pominąć w zupełności. Sąd postąpi 
tak samo, gdy druga strona lub niektórzy ze współuczestników nie stawili się na 
przesłuchanie stron lub odmówili zeznań. 
**§ 2.** W sprawach osób znajdujących się pod władzą rodzicielską, opieką lub 
kuratelą od uznania sądu zależy przesłuchanie bądź samej strony, bądź jej 
przedstawiciela ustawowego, bądź też obojga.

***
## Art. 303. {#kpc-pierwsza-pierwsza-art-303}

Sąd przesłucha najpierw strony bez odbierania przyrzeczenia. Jeżeli 
przesłuchanie to nie wyświetli dostatecznie faktów, sąd może przesłuchać według 
swego wyboru jedną ze stron ponownie, po uprzednim odebraniu od niej 
przyrzeczenia. Przesłuchanie jednej ze stron co do pewnego faktu z odebraniem od 
niej przyrzeczenia nie wyłącza takiego przesłuchania drugiej strony co do innego 
faktu.

***
## Art. 304. {#kpc-pierwsza-pierwsza-art-304}

Przed przystąpieniem do przesłuchania sąd uprzedza strony, że 
obowiązane są zeznawać prawdę i że stosownie do okoliczności mogą być 
przesłuchane ponownie po odebraniu od nich przyrzeczenia. Przed odebraniem 
przyrzeczenia sąd uprzedza stronę o odpowiedzialności karnej za złożenie 
fałszywych zeznań. Poza tym do przesłuchania stron i składania przyrzeczenia 
stosuje się odpowiednio przepisy dotyczące świadków, w tym art. 2631, 
z wyjątkiem przepisów o środkach przymusowych. 

 
 
 
s. 123/580 
 
2025-09-08 
 
Oddział 7 
Inne środki dowodowe

***
## Art. 305. {#kpc-pierwsza-pierwsza-art-305}

Sąd może dopuścić dowód z grupowego badania krwi.

***
## Art. 306. {#kpc-pierwsza-pierwsza-art-306}

Pobranie krwi w celu jej badania może nastąpić tylko za zgodą 
osoby, której krew ma być pobrana, a jeżeli osoba ta nie ukończyła trzynastu lat lub 
jest ubezwłasnowolniona całkowicie – za zgodą jej przedstawiciela ustawowego.

***
## Art. 307. {#kpc-pierwsza-pierwsza-art-307}

**§ 1.** W celu przeprowadzenia dowodu z grupowego badania krwi 
sąd zwraca się do biegłego o pobranie krwi, zbadanie jej i złożenie sprawozdania 
o wynikach badania łącznie z końcową opinią. 
**§ 2.** Sprawozdanie 
z grupowego 
badania 
krwi 
powinno 
zawierać 
stwierdzenie, czy sprawdzono należycie tożsamość osób, których krew pobrano, 
oraz wskazanie sposobu przeprowadzenia badania. Sprawozdanie powinno być 
podpisane przez osobę, która przeprowadziła badanie, a jeżeli krew została pobrana 
przez inną osobę, pobranie krwi powinno być stwierdzone jej podpisem. 
**§ 3.** Pobranie krwi i przesłanie jej do instytutu, o jakim mowa w art. 290, 
można zlecić biegłemu miejsca zamieszkania stron lub siedziby sądu.

***
## Art. 308. {#kpc-pierwsza-pierwsza-art-308}

Dowody z innych dokumentów niż wymienione w art. 2431, 
w szczególności zawierających zapis obrazu, dźwięku albo obrazu i dźwięku, sąd 
przeprowadza, stosując odpowiednio przepisy o dowodzie z oględzin oraz o 
dowodzie z dokumentów.

***
## Art. 309. {#kpc-pierwsza-pierwsza-art-309}

Sposób przeprowadzenia dowodu innymi środkami dowodowymi 
niż wymienione w artykułach poprzedzających określi sąd zgodnie z ich 
charakterem, stosując odpowiednio przepisy o dowodach. 
Rozdział 3 
Zabezpieczenie dowodów

***
## Art. 310. {#kpc-pierwsza-pierwsza-art-310}

Przed 
wszczęciem 
postępowania 
na 
wniosek, 
a w toku 
postępowania również z urzędu, można zabezpieczyć dowód, gdy zachodzi obawa, 
że jego przeprowadzenie stanie się niewykonalne lub zbyt utrudnione, albo gdy 
z innych przyczyn zachodzi potrzeba stwierdzenia istniejącego stanu rzeczy. 

 
 
 
s. 124/580 
 
2025-09-08

***
## Art. 311. {#kpc-pierwsza-pierwsza-art-311}

Wniosek o zabezpieczenie dowodu składa się w sądzie właściwym 
do rozpoznania sprawy, a w wypadkach niecierpiących zwłoki lub gdy 
postępowanie nie zostało jeszcze wszczęte, w sądzie rejonowym, w którego okręgu 
dowód ma być przeprowadzony.

***
## Art. 312. {#kpc-pierwsza-pierwsza-art-312}

Wniosek powinien zawierać: 
- 1) oznaczenie wnioskodawcy i przeciwnika oraz innych osób zainteresowanych, 
jeżeli są znane; 
- 2) wskazanie faktów oraz dowodów; 
- 3) przyczyny uzasadniające potrzebę zabezpieczenia dowodu.

***
## Art. 313. {#kpc-pierwsza-pierwsza-art-313}

Zabezpieczenie dowodu może być dopuszczone bez wezwania 
przeciwnika tylko w wypadkach niecierpiących zwłoki albo gdy przeciwnik nie 
może być wskazany lub gdy miejsce jego pobytu nie jest znane.

***
## Art. 314. {#kpc-pierwsza-pierwsza-art-314}

Sąd wzywa zainteresowanych na termin wyznaczony do 
przeprowadzenia dowodu; jednakże w wypadkach niecierpiących zwłoki 
przeprowadzenie dowodu może być rozpoczęte nawet przed doręczeniem 
wezwania przeciwnikowi.

***
## Art. 315. {#kpc-pierwsza-pierwsza-art-315}

**§ 1.** Strony mają prawo wskazywać przed sądem orzekającym 
uchybienia popełnione przy zabezpieczeniu dowodu. 
**§ 2.** (uchylony) 
#### DZIAŁ IV
Orzeczenia 
Rozdział 1 
Wyroki 
Oddział 1 
Wydanie wyroku

***
## Art. 316. {#kpc-pierwsza-pierwsza-art-316}

**§ 1.** Po zamknięciu rozprawy sąd wydaje wyrok, biorąc za podstawę 
stan rzeczy istniejący w chwili zamknięcia rozprawy; w szczególności zasądzeniu 
roszczenia nie stoi na przeszkodzie okoliczność, że stało się ono wymagalne w toku 
sprawy. 

 
 
 
s. 125/580 
 
2025-09-08 
**§ 2.** Rozprawa powinna być otwarta na nowo, jeżeli istotne okoliczności 
ujawniły się dopiero po jej zamknięciu.

***
## Art. 317. {#kpc-pierwsza-pierwsza-art-317}

**§ 1.** Sąd może wydać wyrok częściowy, jeżeli nadaje się do 
rozstrzygnięcia tylko część żądania lub niektóre z żądań pozwu; to samo dotyczy 
powództwa wzajemnego. 
**§ 2.** Na tej samej podstawie sąd może wydać wyrok częściowy, rozstrzygając 
o całości żądania powództwa głównego lub wzajemnego.

***
## Art. 318. {#kpc-pierwsza-pierwsza-art-318}

**§ 1.** Sąd, uznając roszczenie za usprawiedliwione w zasadzie, może 
wydać wyrok wstępny tylko co do samej zasady, co do spornej zaś wysokości 
żądania – zarządzić bądź dalszą rozprawę, bądź jej odroczenie. 
**§ 2.** W razie zarządzenia dalszej rozprawy, wyrok co do wysokości żądania, 
jak również rozstrzygnięcie co do kosztów może zapaść dopiero po 
uprawomocnieniu się wyroku wstępnego.

***
## Art. 319. {#kpc-pierwsza-pierwsza-art-319}

Jeżeli 
pozwany 
ponosi 
odpowiedzialność 
z określonych 
przedmiotów majątkowych albo do wysokości ich wartości, sąd może, nie 
wymieniając tych przedmiotów ani ich wartości, uwzględnić powództwo 
zastrzegając pozwanemu prawo do powołania się w toku postępowania 
egzekucyjnego na ograniczenie odpowiedzialności.

***
## Art. 3191. {#kpc-pierwsza-pierwsza-art-3191}

Jeżeli z czynności prawnej, ustawy albo orzeczenia sądowego 
będącego źródłem zobowiązania wynika, że świadczenie pieniężne może być 
spełnione wyłącznie w walucie obcej, sąd, uwzględniając powództwo, zastrzega, 
że spełnienie tego świadczenia nastąpi wyłącznie w walucie obcej.

***
## Art. 320. {#kpc-pierwsza-pierwsza-art-320}

W szczególnie uzasadnionych wypadkach sąd może w wyroku 
rozłożyć na raty zasądzone świadczenie, a w sprawach o wydanie nieruchomości 
lub o opróżnienie pomieszczenia – wyznaczyć odpowiedni termin do spełnienia 
tego świadczenia.

***
## Art. 321. {#kpc-pierwsza-pierwsza-art-321}

**§ 1.** Sąd nie może wyrokować co do przedmiotu, który nie był 
objęty żądaniem, ani zasądzać ponad żądanie. 
**§ 2.** (uchylony)

***
## Art. 322. {#kpc-pierwsza-pierwsza-art-322}

Jeżeli w sprawie o naprawienie szkody, o dochody, o zwrot 
bezpodstawnego wzbogacenia lub o świadczenie z umowy o dożywocie sąd uzna, 

 
 
 
s. 126/580 
 
2025-09-08 
 
że ścisłe udowodnienie wysokości żądania jest niemożliwe, nader utrudnione lub 
oczywiście niecelowe, może w wyroku zasądzić odpowiednią sumę według swej 
oceny opartej na rozważeniu wszystkich okoliczności sprawy.

***
## Art. 323. {#kpc-pierwsza-pierwsza-art-323}

Wyrok może być wydany jedynie przez sędziów, przed którymi 
odbyła się rozprawa poprzedzająca bezpośrednio wydanie wyroku.

***
## Art. 324. {#kpc-pierwsza-pierwsza-art-324}

**§ 1.** Sąd wydaje wyrok po niejawnej naradzie sędziów. Narada 
obejmuje dyskusję, głosowanie nad mającym zapaść orzeczeniem i zasadniczymi 
powodami rozstrzygnięcia albo uzasadnieniem, jeżeli ma być wygłoszone, oraz 
spisanie sentencji wyroku. 
**§ 2.** Przewodniczący zbiera głosy sędziów według ich starszeństwa 
służbowego, a ławników według ich wieku, poczynając od najmłodszego, sam zaś 
głosuje ostatni. Sprawozdawca, jeżeli jest wyznaczony, głosuje pierwszy. Wyrok 
zapada większością głosów. Sędzia, który przy głosowaniu nie zgodził się 
z większością, może przy podpisywaniu sentencji zgłosić zdanie odrębne 
i obowiązany jest uzasadnić je na piśmie przed podpisaniem uzasadnienia. W razie 
zgłoszenia zdania odrębnego nie wygłasza się uzasadnienia. 
**§ 3.** Sentencję wyroku podpisuje cały skład sądu. 
**§ 4.** W postępowaniu 
wszczętym 
za 
pośrednictwem 
systemu 
teleinformatycznego wyrok może być utrwalony w systemie teleinformatycznym 
i opatrzony kwalifikowanym podpisem elektronicznym.

***
## Art. 325. {#kpc-pierwsza-pierwsza-art-325}

- 10) Sentencja wyroku powinna zawierać wymienienie sądu, sędziów, 
protokolanta oraz prokuratora, jeżeli brał udział w sprawie, datę i miejsce 
rozpoznania sprawy i wydania wyroku, wymienienie stron i oznaczenie przedmiotu 
sprawy oraz rozstrzygnięcie sądu o żądaniach stron.

***
## Art. 326. {#kpc-pierwsza-pierwsza-art-326}

**§ 1.** Ogłoszenie wyroku powinno nastąpić na posiedzeniu, na 
którym zamknięto rozprawę. Postanowieniem wydanym niezwłocznie po 
- 10) Utracił moc z dniem 11 września 2017 r. w związku z art. 1: 
– w zakresie, w jakim dopuszcza rozstrzygnięcie o prawidłowości procedury wyboru sędziego 
Trybunału Konstytucyjnego, 
– w zakresie, w jakim dopuszcza rozstrzygnięcie o prawidłowości procedury przedstawienia 
kandydatów na stanowisko Prezesa oraz Wiceprezesa Trybunału Konstytucyjnego przez 
Zgromadzenie Ogólne Sędziów Trybunału Konstytucyjnego i powołania ich przez 
Prezydenta Rzeczypospolitej Polskiej 
na podstawie wyroku Trybunału Konstytucyjnego, o którym mowa w odnośniku 3. 

 
 
 
s. 127/580 
 
2025-09-08 
 
zamknięciu rozprawy sąd może odroczyć ogłoszenie wyroku na oznaczony termin 
przypadający nie później niż dwa tygodnie po dniu zamknięcia rozprawy. Jeżeli 
sprawa jest szczególnie zawiła, materiał sprawy jest szczególnie obszerny lub sąd 
jest znacznie obciążony czynnościami w innych sprawach, termin ten wyjątkowo 
może wynosić miesiąc po dniu zamknięcia rozprawy. 
**§ 2.** Ogłoszenie wyroku następuje na posiedzeniu jawnym i może go dokonać 
sam przewodniczący lub sędzia sprawozdawca. Nieobecność stron nie wstrzymuje 
ogłoszenia wyroku. 
**§ 3.** Ogłoszenia wyroku dokonuje się przez odczytanie sentencji. Po 
ogłoszeniu wyroku przewodniczący lub sędzia sprawozdawca podaje ustnie 
zasadnicze powody rozstrzygnięcia albo wygłasza uzasadnienie, może jednak tego 
zaniechać, jeżeli sprawa była rozpoznawana przy drzwiach zamkniętych. 
**§ 4.** Jeżeli na ogłoszenie wyroku nikt się nie stawił, włączając publiczność, 
przewodniczący lub sędzia sprawozdawca może zarządzić odstąpienie od 
odczytania sentencji i podania zasadniczych powodów rozstrzygnięcia. W takim 
przypadku wyrok uważa się za ogłoszony z chwilą zakończenia posiedzenia. 
Sentencję należy jednak odczytać, jeżeli będzie wygłaszane uzasadnienie wyroku.

***
## Art. 3261. {#kpc-pierwsza-pierwsza-art-3261}

Jeżeli do zamknięcia rozprawy doszło na posiedzeniu niejawnym, 
sąd wydaje wyrok na tym samym posiedzeniu.

***
## Art. 327. {#kpc-pierwsza-pierwsza-art-327}

**§ 1.** Stronę niezastępowaną przez adwokata, radcę prawnego, 
rzecznika patentowego lub Prokuratorię Generalną Rzeczypospolitej Polskiej, 
obecną przy ogłoszeniu wyroku, przewodniczący pouczy o sposobie i terminie 
zgłoszenia wniosku o doręczenie wyroku z uzasadnieniem oraz warunkach, 
sposobie i terminie wniesienia środka zaskarżenia. 
**§ 2.** Sąd z urzędu doręcza wyrok stronie niezastępowanej przez adwokata, 
radcę prawnego lub rzecznika patentowego, która na skutek pozbawienia wolności 
była nieobecna przy ogłoszeniu wyroku. 
**§ 3.** Sąd z urzędu doręcza stronom wyrok wydany na posiedzeniu niejawnym. 
**§ 4.** Stronie niezastępowanej przez adwokata, radcę prawnego, rzecznika 
patentowego lub Prokuratorię Generalną Rzeczypospolitej Polskiej wraz 
z wyrokiem, który podlega doręczeniu z urzędu, doręcza się pouczenie o sposobie 

 
 
 
s. 128/580 
 
2025-09-08 
 
i terminie zgłoszenia wniosku o doręczenie wyroku z uzasadnieniem oraz 
warunkach, sposobie i terminie wniesienia środka zaskarżenia. 
**§ 5.** Jeżeli zastępstwo stron przez adwokatów lub radców prawnych jest 
obowiązkowe, należy także pouczyć stronę o treści przepisów o obowiązkowym 
zastępstwie oraz skutkach niezastosowania się do tych przepisów.

***
## Art. 3271. {#kpc-pierwsza-pierwsza-art-3271}

**§ 1.** Uzasadnienie wyroku powinno zawierać: 
- 1) wskazanie podstawy faktycznej rozstrzygnięcia, obejmującej ustalenie 
faktów, które sąd uznał za udowodnione, dowodów, na których się oparł, 
i przyczyn, dla których innym dowodom odmówił wiarygodności i mocy 
dowodowej; 
- 2) wyjaśnienie podstawy prawnej wyroku z przytoczeniem przepisów prawa. 
**§ 2.** Uzasadnienie wyroku sporządza się w sposób zwięzły.

***
## Art. 328. {#kpc-pierwsza-pierwsza-art-328}

**§ 1.** Pisemne uzasadnienie wyroku sporządza się na wniosek strony 
o doręczenie wyroku z uzasadnieniem zgłoszony w terminie tygodnia od dnia 
ogłoszenia wyroku. 
**§ 2.** W przypadkach gdy wyrok doręcza się z urzędu, termin, o którym mowa 
w § 1, liczy się od dnia doręczenia wyroku. 
**§ 3.** We wniosku należy wskazać, czy pisemne uzasadnienie ma dotyczyć 
całości wyroku czy jego części, w szczególności poszczególnych objętych nim 
rozstrzygnięć. 
**§ 4.** Sąd odrzuca wniosek niedopuszczalny, spóźniony, nieopłacony lub 
dotknięty brakami, których nie usunięto mimo wezwania.

***
## Art. 329. {#kpc-pierwsza-pierwsza-art-329}

**§ 1.** Pisemne uzasadnienie wyroku sporządza się w zakresie 
wynikającym z wniosku o doręczenie wyroku z uzasadnieniem. 
**§ 2.** Pisemne uzasadnienie wyroku sporządza się w terminie dwóch tygodni 
od dnia wpływu do właściwego sądu wniosku o doręczenie wyroku 
z uzasadnieniem, a jeżeli wniosek był dotknięty brakami – od dnia usunięcia tych 
braków. 
**§ 3.** W przypadkach gdy pisemne uzasadnienie wyroku sporządza się 
z urzędu, termin, o którym mowa w § 2, biegnie od dnia ogłoszenia wyroku. 
**§ 4.** W przypadku niemożności sporządzenia pisemnego uzasadnienia wyroku 
w terminie prezes sądu może przedłużyć ten termin na czas oznaczony. 

 
 
 
s. 129/580 
 
2025-09-08

***
## Art. 330. {#kpc-pierwsza-pierwsza-art-330}

**§ 1.** W sprawach rozstrzyganych w składzie trzech sędziów 
uzasadnienie wyroku podpisują sędziowie, którzy brali udział w jego wydaniu. 
Jeżeli którykolwiek z sędziów nie może podpisać uzasadnienia, przewodniczący 
lub najstarszy służbą sędzia zaznacza na uzasadnieniu przyczynę braku podpisu. 
**§ 2.** Uzasadnienie wyroku w sprawie rozpoznawanej z udziałem ławników 
podpisuje tylko przewodniczący. W razie złożenia zdania odrębnego uzasadnienie 
wyroku podpisuje przewodniczący wraz z ławnikami.

***
## Art. 331. {#kpc-pierwsza-pierwsza-art-331}

**§ 1.** Wyrok z pisemnym uzasadnieniem doręcza się tylko tej stronie, 
która zgłosiła wniosek o doręczenie wyroku z uzasadnieniem. 
**§ 2.** Sporządzenie pisemnego uzasadnienia wyroku z urzędu nie zwalnia 
strony od obowiązku zgłoszenia wniosku o doręczenie wyroku z uzasadnieniem. 
**§ 3.** Stronie niezastępowanej przez adwokata, radcę prawnego, rzecznika 
patentowego lub Prokuratorię Generalną Rzeczypospolitej Polskiej wraz 
z pisemnym uzasadnieniem wyroku doręcza się pouczenie o sposobie i terminie 
wniesienia środka zaskarżenia. Przepis art. 327 § 5 stosuje się. 
**§ 4.** Jeżeli sporządzenie uzasadnienia okaże się niemożliwe, prezes sądu 
zawiadamia o tym stronę. W takim przypadku termin do wniesienia środka 
zaskarżenia biegnie od dnia doręczenia tego zawiadomienia, o czym należy 
pouczyć stronę. Stronie niezastępowanej przez adwokata, radcę prawnego, 
rzecznika patentowego lub Prokuratorię Generalną Rzeczypospolitej Polskiej wraz 
z tym pouczeniem doręcza się pouczenie przewidziane w § 3. Przepis 
art. 327 § 5 stosuje się.

***
## Art. 3311. {#kpc-pierwsza-pierwsza-art-3311}

**§ 1.** Jeżeli przebieg posiedzenia jest utrwalany w sposób 
przewidziany w art. 157 § 1, uzasadnienie może być wygłoszone po ogłoszeniu 
wyroku i utrwalone za pomocą urządzenia rejestrującego dźwięk albo obraz 
i dźwięk, o czym przewodniczący uprzedza przed wygłoszeniem uzasadnienia. 
**§ 2.** W przypadku, o którym mowa w § 1, nie podaje się odrębnie 
zasadniczych powodów rozstrzygnięcia, a zamiast pisemnego uzasadnienia wyroku 
sporządza się transkrypcję wygłoszonego uzasadnienia. 
**§ 3.** Do transkrypcji wygłoszonego uzasadnienia odpowiednio stosuje się 
przepisy o pisemnym uzasadnieniu wyroku. 

 
 
 
s. 130/580 
 
2025-09-08

***
## Art. 332. {#kpc-pierwsza-pierwsza-art-332}

**§ 1.** Sąd jest związany wydanym wyrokiem od chwili jego 
ogłoszenia. Wyrok wydany na posiedzeniu niejawnym wiąże sąd od chwili 
podpisania sentencji. 
**§ 2.** W przypadku cofnięcia pozwu przed uprawomocnieniem się wyroku albo 
przedstawieniem akt z apelacją sądowi drugiej instancji, z jednoczesnym 
zrzeczeniem się dochodzonego roszczenia, a za zgodą pozwanego również bez tego 
zrzeczenia, sąd pierwszej instancji postanowieniem uchyli swój wyrok i umorzy 
postępowanie, jeżeli uzna takie cofnięcie za dopuszczalne. 
Oddział 2 
Natychmiastowa wykonalność wyroków

***
## Art. 333. {#kpc-pierwsza-pierwsza-art-333}

**§ 1.** Sąd z urzędu nada wyrokowi przy jego wydaniu rygor 
natychmiastowej wykonalności, jeżeli: 
- 1) zasądza alimenty – co do rat płatnych po dniu wniesienia powództwa, a co do 
rat płatnych przed wniesieniem powództwa za okres nie dłuższy niż za trzy 
miesiące; 
- 2) zasądza roszczenie uznane przez pozwanego; 
- 3) wyrok uwzględniający powództwo jest zaoczny. 
**§ 2.** Sąd może nadać wyrokowi przy jego wydaniu rygor natychmiastowej 
wykonalności, jeżeli zasądza należność z weksla, czeku, dokumentu urzędowego 
lub dokumentu prywatnego, którego prawdziwość nie została zaprzeczona, oraz 
jeżeli uwzględnia powództwo o naruszenie posiadania. 
**§ 3.** Sąd może również na wniosek nadać wyrokowi nadającemu się do 
wykonania w drodze egzekucji rygor natychmiastowej wykonalności, gdyby 
opóźnienie uniemożliwiało lub znacznie utrudniało wykonanie wyroku albo 
narażało powoda na szkodę.

***
## Art. 334. {#kpc-pierwsza-pierwsza-art-334}

**§ 1.** Sąd może uzależnić natychmiastową wykonalność wyroku od 
złożenia przez powoda stosownego zabezpieczenia. 
**§ 2.** Zabezpieczenie może polegać również na wstrzymaniu wydania 
powodowi rzeczy odebranych pozwanemu lub sum pieniężnych po ich 
wyegzekwowaniu albo na wstrzymaniu sprzedaży zajętego majątku ruchomego. 
**§ 3.** Sprzedaż lub przejęcie na własność zajętej nieruchomości wstrzymuje się 
z urzędu do czasu uprawomocnienia się wyroku. 

 
 
 
s. 131/580 
 
2025-09-08 
**§ 4.** Zabezpieczenie 
nie 
może 
być 
zarządzone 
co 
do 
należności 
alimentacyjnych w granicach, w jakich sąd nadaje wyrokowi zasądzającemu te 
należności rygor natychmiastowej wykonalności z urzędu.

***
## Art. 335. {#kpc-pierwsza-pierwsza-art-335}

**§ 1.** Natychmiastowa wykonalność nie będzie orzeczona nawet za 
zabezpieczeniem, jeżeli wskutek wykonania wyroku mogłaby wyniknąć dla 
pozwanego niepowetowana szkoda. Przepisu tego nie stosuje się do wyroków za-
sądzających alimenty w granicach, w jakich sąd nadaje wyrokowi rygor 
natychmiastowej wykonalności z urzędu. 
**§ 2.** Natychmiastowa wykonalność nie będzie również orzeczona nawet za 
zabezpieczeniem w sprawach przeciwko Skarbowi Państwa.

***
## Art. 336. {#kpc-pierwsza-pierwsza-art-336}

Rygor natychmiastowej wykonalności obowiązuje od chwili 
ogłoszenia wyroku lub postanowienia, którym go nadano, a gdy ogłoszenia nie było 
– od chwili podpisania sentencji orzeczenia.

***
## Art. 337. {#kpc-pierwsza-pierwsza-art-337}

Natychmiastowa wykonalność wyroku wygasa z chwilą ogłoszenia, 
a jeżeli nie było ogłoszenia, z chwilą podpisania sentencji orzeczenia 
zmieniającego albo uchylającego wyrok lub postanowienie o natychmiastowej 
wykonalności wyroku – w takim zakresie, w jakim nastąpiła zmiana lub uchylenie.

***
## Art. 338. {#kpc-pierwsza-pierwsza-art-338}

**§ 1.** Uchylając lub zmieniając wyrok, któremu nadany został rygor 
natychmiastowej wykonalności, sąd na wniosek pozwanego orzeka w orzeczeniu 
kończącym postępowanie o zwrocie spełnionego lub wyegzekwowanego 
świadczenia lub o przywróceniu poprzedniego stanu. 
**§ 2.** Przepis paragrafu poprzedzającego nie wyłącza możliwości dochodzenia 
w osobnym procesie naprawienia szkody poniesionej wskutek wykonania wyroku. 
Oddział 3 
Wyroki zaoczne

***
## Art. 339. {#kpc-pierwsza-pierwsza-art-339}

**§ 1.** Sąd może wydać wyrok zaoczny na posiedzeniu niejawnym, 
gdy pozwany w wyznaczonym terminie nie złożył odpowiedzi na pozew. 
**§ 2.** W przypadku, o którym mowa w § 1, przyjmuje się za prawdziwe 
twierdzenia powoda o faktach zawarte w pozwie lub pismach procesowych 
doręczonych pozwanemu przed posiedzeniem, chyba że budzą one uzasadnione 
wątpliwości albo zostały przytoczone w celu obejścia prawa. 

 
 
 
s. 132/580 
 
2025-09-08

***
## Art. 340. {#kpc-pierwsza-pierwsza-art-340}

**§ 1.** Sąd wyda wyrok zaoczny, jeżeli mimo niezłożenia odpowiedzi 
na pozew skierowano sprawę do rozpoznania na rozprawie, a pozwany nie stawił 
się na tę rozprawę, albo mimo stawienia się nie bierze w niej udziału. Przepis 
art. 339 § 2 stosuje się. 
**§ 2.** Wyrok wydany w nieobecności pozwanego nie będzie zaoczny, jeżeli 
pozwany żądał przeprowadzenia rozprawy w swej nieobecności lub składał już 
w sprawie wyjaśnienia ustnie lub na piśmie.

***
## Art. 341. {#kpc-pierwsza-pierwsza-art-341}

W razie nienadejścia dowodu doręczenia na dzień rozprawy sąd 
może w ciągu następnych dwóch tygodni wydać na posiedzeniu niejawnym wyrok 
zaoczny, jeżeli w tym czasie otrzyma dowód doręczenia. Wyrok taki wiąże sąd od 
chwili podpisania sentencji.

***
## Art. 342. {#kpc-pierwsza-pierwsza-art-342}

Wyrok zaoczny sąd uzasadnia, gdy powództwo zostało oddalone 
w całości lub części, a powód zażądał uzasadnienia w terminie tygodnia od dnia 
doręczenia mu wyroku.

***
## Art. 343. {#kpc-pierwsza-pierwsza-art-343}

**§ 1.** Wyrok zaoczny doręcza się stronom z urzędu. Stronie 
niezastępowanej przez adwokata, radcę prawnego, rzecznika patentowego lub 
Prokuratorię Generalną Rzeczypospolitej Polskiej doręcza się go z pouczeniem 
o przysługujących jej środkach zaskarżenia, a pozwanemu – także z pouczeniem 
o obowiązku przedstawienia w sprzeciwie wszystkich twierdzeń i dowodów oraz 
skutku niedopełnienia tego obowiązku w postaci możliwości pominięcia 
spóźnionych twierdzeń i dowodów. 
**§ 2.** Jeżeli wyrok, zgodnie z art. 342, nie podlegał uzasadnieniu, termin do 
wniesienia przez powoda apelacji biegnie od dnia jego doręczenia.

***
## Art. 3431. {#kpc-pierwsza-pierwsza-art-3431}

Jeżeli po wydaniu wyroku zaocznego okaże się, że pozwany 
w chwili wniesienia pozwu nie miał zdolności sądowej, zdolności procesowej albo 
organu powołanego do jego reprezentowania, a braki te nie zostały usunięte w wy-
znaczonym terminie zgodnie z przepisami kodeksu, sąd z urzędu uchyla wyrok 
zaoczny i wydaje odpowiednie postanowienie.

***
## Art. 344. {#kpc-pierwsza-pierwsza-art-344}

**§ 1.** Pozwany, przeciwko któremu zapadł wyrok zaoczny, może 
złożyć sprzeciw w ciągu dwóch tygodni od doręczenia mu wyroku. 
**§ 2.** W piśmie zawierającym sprzeciw pozwany powinien przytoczyć zarzuty, 
które pod rygorem ich utraty należy zgłosić przed wdaniem się w spór co do istoty 

 
 
 
s. 133/580 
 
2025-09-08 
 
sprawy, oraz twierdzenia i dowody. Przepis art. 20512 § 1 zdanie drugie stosuje się 
odpowiednio. 
**§ 3.** Sąd odrzuca sprzeciw niedopuszczalny, spóźniony, nieopłacony lub 
dotknięty brakami, których nie usunięto pomimo wezwania.

***
## Art. 345. {#kpc-pierwsza-pierwsza-art-345}

W przypadku wniesienia sprzeciwu przewodniczący zarządza 
doręczenie go powodowi i nadaje sprawie bieg, w razie potrzeby podejmując 
czynności przewidziane w przepisach o organizacji postępowania.

***
## Art. 346. {#kpc-pierwsza-pierwsza-art-346}

**§ 1.** Na wniosek pozwanego sąd zawiesi rygor natychmiastowej 
wykonalności nadany wyrokowi zaocznemu, jeżeli wyrok ten został wydany 
z naruszeniem przepisów o dopuszczalności jego wydania albo jeżeli pozwany 
uprawdopodobni, że jego niestawiennictwo było niezawinione, a przedstawione 
w sprzeciwie okoliczności wywołują wątpliwości co do zasadności wyroku 
zaocznego. Zawieszając wykonalność wyroku, sąd może zarządzić środki 
zabezpieczenia w myśl oddziału poprzedzającego. 
**§ 11.** Sąd może uchylić rygor natychmiastowej wykonalności nadany 
wyrokowi zaocznemu, jeżeli pozwany wykaże, że odpis pozwu doręczono w trybie 
przewidzianym w art. 139 § 1 na inny adres aniżeli aktualne w dacie doręczenia 
miejsce zamieszkania pozwanego. 
**§ 2.** (uchylony)

***
## Art. 347. {#kpc-pierwsza-pierwsza-art-347}

Po ponownym rozpoznaniu sprawy sąd wydaje wyrok, którym 
wyrok zaoczny w całości lub części utrzymuje w mocy albo uchyla go i orzeka 
o żądaniu pozwu, bądź też pozew odrzuca lub postępowanie umarza. Przepis 
art. 332 § 2 stosuje się odpowiednio.

***
## Art. 348. {#kpc-pierwsza-pierwsza-art-348}

Koszty rozprawy zaocznej i sprzeciwu ponosi pozwany, choćby 
następnie wyrok zaoczny został uchylony, chyba że niestawiennictwo pozwanego 
było niezawinione lub że nie dołączono do akt nadesłanych do sądu przed rozprawą 
wyjaśnień pozwanego.

***
## Art. 349. {#kpc-pierwsza-pierwsza-art-349}

**§ 1.** W razie cofnięcia sprzeciwu sąd, jeżeli uzna, że cofnięcie jest 
dopuszczalne, umarza postępowanie wywołane wniesieniem sprzeciwu i orzeka 
o kosztach jak przy cofnięciu pozwu. Wyrok zaoczny staje się wówczas prawo-
mocny. 
**§ 2.** Przepis art. 203 § 4 stosuje się odpowiednio. 

 
 
 
s. 134/580 
 
2025-09-08 
 
Oddział 4 
Sprostowanie, uzupełnienie i wykładnia wyroków

***
## Art. 350. {#kpc-pierwsza-pierwsza-art-350}

**§ 1.** Sąd może z urzędu sprostować w wyroku niedokładności, 
błędy pisarskie albo rachunkowe lub inne oczywiste omyłki. 
**§ 2.** O sprostowaniu umieszcza się wzmiankę na oryginale wyroku, a na 
żądanie stron także na udzielonych im wypisach. Dalsze odpisy i wypisy powinny 
być zredagowane w brzmieniu uwzględniającym postanowienie o sprostowaniu. 
**§ 3.** Jeżeli sprawa toczy się przed sądem drugiej instancji, sąd ten może 
z urzędu sprostować wyrok pierwszej instancji.

***
## Art. 3501. {#kpc-pierwsza-pierwsza-art-3501}

**§ 1.** Niedopuszczalny jest wniosek o sprostowanie wyroku złożony 
jedynie dla zwłoki w postępowaniu. 
**§ 2.** Za wniosek złożony jedynie dla zwłoki w postępowaniu uważa się drugi 
i dalszy wniosek złożony przez tę samą stronę co do tego samego wyroku, chyba 
że okoliczności sprawy wykluczają tę ocenę. 
**§ 3.** Wniosek, o którym mowa w § 1, pozostawia się w aktach sprawy bez 
żadnych dalszych czynności. To samo dotyczy pism związanych z jego złożeniem. 
O pozostawieniu wniosku i pism związanych z jego złożeniem zawiadamia się 
stronę wnoszącą tylko raz – przy złożeniu pierwszego pisma. 
**§ 4.** Przepisy § 1–3 stosuje się odpowiednio do wniosku o uzupełnienie 
i o wykładnię wyroku.

***
## Art. 351. {#kpc-pierwsza-pierwsza-art-351}

**§ 1.** Strona może w ciągu dwóch tygodni od ogłoszenia wyroku, 
a gdy doręczenie wyroku następuje z urzędu – od jego doręczenia, zgłosić wniosek 
o uzupełnienie wyroku, jeżeli sąd nie orzekł o całości żądania, o natychmiastowej 
wykonalności albo nie zamieścił w wyroku dodatkowego orzeczenia, które według 
przepisów ustawy powinien był zamieścić z urzędu. 
**§ 2.** (uchylony) 
**§ 3.** Orzeczenie uzupełniające wyrok zapada w postaci wyroku, chyba że 
uzupełnienie dotyczy wyłącznie kosztów lub natychmiastowej wykonalności.

***
## Art. 352. {#kpc-pierwsza-pierwsza-art-352}

Sąd, który wydał wyrok, rozstrzyga postanowieniem wątpliwości co 
do jego treści. 

 
 
 
s. 135/580 
 
2025-09-08

***
## Art. 353. {#kpc-pierwsza-pierwsza-art-353}

Wniosek o sprostowanie, uzupełnienie lub wykładnię wyroku nie 
ma wpływu na bieg terminu do wniesienia środka zaskarżenia. 
Rozdział 1a 
Nakazy zapłaty

***
## Art. 3531. {#kpc-pierwsza-pierwsza-art-3531}

**§ 1.** Jeżeli przepis szczególny tak stanowi, sąd rozstrzyga sprawę, 
wydając nakaz zapłaty. 
**§ 2.** (uchylony)

***
## Art. 3532. {#kpc-pierwsza-pierwsza-art-3532}

Do nakazów zapłaty stosuje się odpowiednio przepisy o wyrokach, 
jeżeli kodeks nie stanowi inaczej. 
Rozdział 2 
Postanowienia sądu

***
## Art. 354. {#kpc-pierwsza-pierwsza-art-354}

Jeżeli kodeks nie przewiduje wydania wyroku lub nakazu zapłaty, 
sąd wydaje postanowienie.

***
## Art. 355. {#kpc-pierwsza-pierwsza-art-355}

Sąd umorzy postępowanie, jeżeli powód ze skutkiem prawnym 
cofnął pozew, strony zawarły ugodę lub została zatwierdzona ugoda zawarta przed 
mediatorem albo z innych przyczyn wydanie wyroku stało się zbędne lub nie-
dopuszczalne.

***
## Art. 356. {#kpc-pierwsza-pierwsza-art-356}

Rozstrzygnięcia 
zawarte 
w postanowieniach 
niekończących 
postępowania w sprawie, wydanych na posiedzeniach jawnych, wpisuje się do 
protokołu bez spisywania odrębnej sentencji, jeżeli nie przysługuje na nie 
zażalenie.

***
## Art. 357. {#kpc-pierwsza-pierwsza-art-357}

**§ 1.** Postanowienia ogłoszone na posiedzeniu jawnym sąd uzasadnia 
tylko wtedy, gdy podlegają one zaskarżeniu, i tylko na żądanie strony zgłoszone 
w terminie tygodniowym od dnia ogłoszenia postanowienia. Postanowienia te 
doręcza się tylko tej stronie, która zażądała sporządzenia uzasadnienia i doręczenia 
postanowienia z uzasadnieniem. 
**§ 2.** Postanowienie wydane na posiedzeniu niejawnym sąd doręcza z urzędu 
stronom, chyba że przepis szczególny stanowi inaczej. Doręczając postanowienie 
stronie niezastępowanej przez adwokata, radcę prawnego, rzecznika patentowego 
lub Prokuratorię Generalną Rzeczypospolitej Polskiej, należy ją pouczyć o 

 
 
 
s. 136/580 
 
2025-09-08 
 
dopuszczalności, warunkach, terminie i sposobie złożenia wniosku o doręczenie 
uzasadnienia tego postanowienia i wniesienia środka zaskarżenia albo o tym, że 
postanowienie nie podlega uzasadnieniu lub zaskarżeniu. 
**§ 21.** Postanowienie wydane na posiedzeniu niejawnym sąd uzasadnia tylko 
wtedy, gdy podlega ono zaskarżeniu, i tylko na żądanie strony zgłoszone 
w terminie tygodnia od dnia doręczenia postanowienia. Postanowienie z 
uzasadnieniem doręcza się tylko tej stronie, która zażądała sporządzenia 
uzasadnienia i doręczenia postanowienia z uzasadnieniem. 
**§ 22.** Ilekroć przepis szczególny nakazuje sądowi uzasadnić z urzędu 
postanowienie wydane na posiedzeniu niejawnym, postanowienie to doręcza się 
z urzędu z uzasadnieniem. 
**§ 23.** Podlegające zaskarżeniu postanowienie wydane na posiedzeniu 
niejawnym sąd może z urzędu uzasadnić, jeżeli pozwoli to na usprawnienie 
postępowania lub jeżeli postanowienie dotyczy przyznania zwrotu kosztów osobie 
niebędącej stroną. W takim przypadku postanowienie z uzasadnieniem doręcza się 
wszystkim stronom lub osobom, których to postanowienie dotyczy. 
**§ 24.** Doręczenie przez sąd z urzędu postanowienia z uzasadnieniem 
wydanego na posiedzeniu niejawnym zwalnia stronę od obowiązku zgłoszenia 
wniosku o doręczenie postanowienia z uzasadnieniem. 
**§ 3.** O ile przepis szczególny nie nakazuje doręczyć z urzędu postanowienia 
z uzasadnieniem, uzasadnienie sporządza się w terminie tygodnia od dnia wpływu 
do właściwego sądu wniosku o doręczenie postanowienia z uzasadnieniem, a jeżeli 
wniosek był dotknięty brakami – od dnia usunięcia tych braków. 
**§ 4.** Postanowień, które odnoszą się wyłącznie do innych osób (świadka, 
biegłego, osoby trzeciej), nie doręcza się stronom; osobom, których te 
postanowienia dotyczą, doręcza się je tylko wówczas, gdy nie były one obecne na 
posiedzeniu, na którym postanowienia te zostały wydane. 
**§ 5.** Wydając postanowienie, nawet niepodlegające zaskarżeniu, sąd może 
przy nim zwięźle wskazać zasadnicze powody rozstrzygnięcia, jeżeli mając na 
względzie okoliczności sprawy uzna, że pozwoli to na usprawnienie postępowania. 
Wskazanie 
zasadniczych 
powodów 
rozstrzygnięcia 
następuje 
w sposób 
odróżniający je od uzasadnienia postanowienia. 

 
 
 
s. 137/580 
 
2025-09-08 
**§ 6.** Wydając postanowienie podlegające zaskarżeniu sąd może, według swej 
oceny opartej na rozważeniu wszystkich okoliczności sprawy, postanowić 
o odstąpieniu od jego uzasadnienia, jeżeli w całości uwzględnia zawarty w piśmie 
procesowym wniosek strony i podziela argumenty strony przytoczone na jego 
poparcie. W postanowieniu należy powołać to pismo. Jeżeli pismo to zostanie 
doręczone później niż postanowienie, termin do złożenia zażalenia biegnie od dnia 
doręczenia tego pisma.

***
## Art. 358. {#kpc-pierwsza-pierwsza-art-358}

Postanowienie wydane na posiedzeniu niejawnym wiąże sąd od 
chwili, w której zostało podpisane wraz z uzasadnieniem, jeżeli zaś sąd 
postanowienia nie uzasadnia, od chwili podpisania sentencji.

***
## Art. 359. {#kpc-pierwsza-pierwsza-art-359}

**§ 1.** Postanowienia niekończące postępowania w sprawie mogą być 
uchylane i zmieniane wskutek zmiany okoliczności sprawy, chociażby były 
zaskarżone, a nawet prawomocne. 
**§ 2.** Postanowienia, o których mowa w § 1, mogą być zmieniane lub uchylane 
także wówczas, gdy zostały wydane na podstawie aktu normatywnego uznanego 
przez Trybunał Konstytucyjny za niezgodny z Konstytucją, ratyfikowaną umową 
międzynarodową lub z ustawą.

***
## Art. 360. {#kpc-pierwsza-pierwsza-art-360}

Postanowienia stają się skuteczne w takim zakresie i w taki sposób, 
jaki wynika z ich treści, z chwilą ogłoszenia, a jeżeli ogłoszenia nie było – z chwilą 
podpisania sentencji.

***
## Art. 361. {#kpc-pierwsza-pierwsza-art-361}

Do postanowień stosuje się odpowiednio przepisy o wyrokach, 
jeżeli kodeks nie stanowi inaczej.

***
## Art. 362. {#kpc-pierwsza-pierwsza-art-362}

Przepisy niniejszego rozdziału stosuje się odpowiednio do 
zarządzeń przewodniczącego.

***
## Art. 3621. {#kpc-pierwsza-pierwsza-art-3621}

Do postanowień referendarza sądowego stosuje się odpowiednio 
przepisy o postanowieniach sądu. 
Rozdział 3 
Prawomocność orzeczeń

***
## Art. 363. {#kpc-pierwsza-pierwsza-art-363}

**§ 1.** Orzeczenie sądu staje się prawomocne, jeżeli nie przysługuje 
co do niego środek odwoławczy lub inny środek zaskarżenia. 

 
 
 
s. 138/580 
 
2025-09-08 
**§ 2.** Mimo niedopuszczalności odrębnego zaskarżenia nie stają się 
prawomocne postanowienia podlegające rozpoznaniu przez sąd drugiej instancji, 
gdy sąd ten rozpoznaje sprawę, w której je wydano. 
**§ 3.** Jeżeli zaskarżono tylko część orzeczenia, staje się ono prawomocne 
w części pozostałej z upływem terminu do zaskarżenia, chyba że sąd drugiej 
instancji może z urzędu rozpoznać sprawę także w tej części.

***
## Art. 364. {#kpc-pierwsza-pierwsza-art-364}

**§ 1.** Prawomocność orzeczenia stwierdza na wniosek strony sąd 
pierwszej instancji, a dopóki akta sprawy znajdują się w sądzie drugiej instancji – 
ten sąd. 
**§ 2.** Postanowienia w sprawie, o której mowa w § 1, może wydać także 
referendarz sądowy.

***
## Art. 365. {#kpc-pierwsza-pierwsza-art-365}

**§ 1.** 11) Orzeczenie prawomocne wiąże nie tylko strony i sąd, który 
je wydał, lecz również inne sądy oraz inne organy państwowe i organy 
administracji publicznej, a w wypadkach w ustawie przewidzianych także inne 
osoby. 
**§ 2.** Kodeks postępowania karnego określa, w jakim zakresie orzeczenia sądu 
cywilnego nie wiążą sądu w postępowaniu karnym.

***
## Art. 366. {#kpc-pierwsza-pierwsza-art-366}

Wyrok prawomocny ma powagę rzeczy osądzonej tylko co do tego, 
co w związku z podstawą sporu stanowiło przedmiot rozstrzygnięcia, a ponadto 
tylko między tymi samymi stronami. 
#### DZIAŁ V
Środki odwoławcze 
Rozdział 1 
Apelacja

***
## Art. 367. {#kpc-pierwsza-pierwsza-art-367}

**§ 1.** Od wyroku sądu pierwszej instancji przysługuje apelacja do 
sądu drugiej instancji. 
- 11) Utracił moc z dniem 19 kwietnia 2023 r. w zakresie, w jakim przewiduje związanie sądu 
orzeczeniem, 
na 
podstawie 
którego 
wszczęto 
przeciwko 
spółce 
z 
ograniczoną 
odpowiedzialnością bezskuteczną egzekucję, w procesie wytoczonym na podstawie art. 299 § 1 
ustawy z dnia 15 września 2000 r. – Kodeks spółek handlowych (Dz. U. z 2022 r. poz. 1467, ze 
zm.) przeciwko pozwanemu, który utracił status członka zarządu spółki przed datą wszczęcia 
postępowania, w którym orzeczenie przeciwko spółce zapadło, na podstawie wyroku Trybunału 
Konstytucyjnego z dnia 12 kwietnia 2023 r. sygn. akt P 5/19 (Dz. U. poz. 739). 

 
 
 
s. 139/580 
 
2025-09-08 
**§ 2.** Apelację od wyroku sądu rejonowego rozpoznaje sąd okręgowy, a od 
wyroku sądu okręgowego jako pierwszej instancji – sąd apelacyjny. 
**§ 3.** (uchylony) 
**§ 31.** Sąd może zlecić przeprowadzenie dowodu sędziemu wyznaczonemu, 
także gdy przyczyni się to do przyspieszenia postępowania. 
**§ 4.** (uchylony)

***
## Art. 3671. {#kpc-pierwsza-pierwsza-art-3671}

**§ 1.** Sąd rozpoznaje sprawę w składzie jednego sędziego 
z wyjątkiem spraw: 
- 1) o prawa majątkowe, w których wartość przedmiotu zaskarżenia choćby 
w jednej z wniesionych apelacji przekracza milion złotych, 
- 2) rozpoznawanych w pierwszej instancji przez sąd okręgowy jako właściwy 
rzeczowo, z uwzględnieniem pkt 1, 
- 3) rozpoznawanych w pierwszej instancji w składzie trzech sędziów na 
podstawie art. 47 § 4 
– które podlegają rozpoznaniu w składzie trzech sędziów. 
**§ 2.** W sprawach podlegających rozpoznaniu w składzie trzech sędziów sąd 
orzeka na posiedzeniu niejawnym w składzie jednego sędziego, z wyjątkiem 
wydania postanowienia, o którym mowa w art. 224 § 3, lub wyroku. 
**§ 3.** Ilekroć ustawa przewiduje, że sąd drugiej instancji rozpoznaje sprawę 
w składzie jednego sędziego, prezes sądu może zarządzić rozpoznanie sprawy 
w składzie trzech sędziów, jeżeli uzna to za wskazane ze względu na szczególną 
zawiłość lub precedensowy charakter sprawy.

***
## Art. 368. {#kpc-pierwsza-pierwsza-art-368}

**§ 1.** Apelacja powinna czynić zadość wymaganiom przewidzianym 
dla pisma procesowego, a ponadto zawierać: 
- 1) oznaczenie wyroku, od którego jest wniesiona, ze wskazaniem, czy jest on 
zaskarżony w całości czy w części; 
- 2) zwięzłe przedstawienie zarzutów; 
- 3) uzasadnienie zarzutów; 
- 4) powołanie, w razie potrzeby, nowych faktów lub dowodów; 
- 5) wniosek o zmianę lub o uchylenie wyroku z zaznaczeniem zakresu żądanej 
zmiany lub uchylenia. 

 
 
 
s. 140/580 
 
2025-09-08 
**§ 11.** W zarzutach co do podstawy faktycznej rozstrzygnięcia należy wskazać 
fakty ustalone przez sąd pierwszej instancji niezgodnie z rzeczywistym stanem 
rzeczy lub istotne dla rozstrzygnięcia fakty nieustalone przez sąd pierwszej 
instancji. 
**§ 12.** Powołując nowe fakty lub dowody, należy uprawdopodobnić, że ich 
powołanie w postępowaniu przed sądem pierwszej instancji nie było możliwe albo 
potrzeba ich powołania wynikła później. 
**§ 13.** Powołując fakt wykazany dowodem utrwalonym za pomocą urządzenia 
rejestrującego dźwięk albo obraz i dźwięk, należy oznaczyć część zapisu dotyczącą 
tego faktu. 
**§ 2.** W sprawach o prawa majątkowe należy oznaczyć wartość przedmiotu 
zaskarżenia. Wartość ta może być oznaczona na kwotę wyższą od wartości 
przedmiotu sporu wskazanej w pozwie jedynie wtedy, gdy powód rozszerzył 
powództwo lub sąd orzekł ponad żądanie. Przepisy art. 19–24 i 25 § 1 stosuje się 
odpowiednio.

***
## Art. 369. {#kpc-pierwsza-pierwsza-art-369}

**§ 1.** Apelację wnosi się do sądu, który wydał zaskarżony wyrok, 
w terminie 
dwutygodniowym 
od 
doręczenia 
stronie 
skarżącej 
wyroku 
z uzasadnieniem. 
**§ 11.** W przypadku przedłużenia terminu do sporządzenia pisemnego 
uzasadnienia wyroku termin, o którym mowa w § 1, wynosi trzy tygodnie. 
O terminie tym sąd zawiadamia stronę doręczając jej wyrok z uzasadnieniem. 
Jeżeli w zawiadomieniu termin ten wskazano błędnie, a strona się do niego 
zastosowała, apelację uważa się za wniesioną w terminie. 
**§ 2.** (uchylony) 
**§ 3.** Terminy, o których mowa w § 1 i 11, uważa się za zachowane także 
wtedy, gdy przed ich upływem strona wniosła apelację do sądu drugiej instancji. 
W takich przypadkach sąd ten zawiadamia sąd pierwszej instancji o wniesieniu 
apelacji i żąda przedstawienia akt sprawy.

***
## Art. 370. {#kpc-pierwsza-pierwsza-art-370}

(uchylony)

***
## Art. 3701. {#kpc-pierwsza-pierwsza-art-3701}

(utracił moc)12) 
- 12) Z dniem 5 czerwca 2008 r. na podstawie wyroku Trybunału Konstytucyjnego z dnia 20 maja 2008 r. 
sygn. akt P 18/07 (Dz. U. poz. 619). 

 
 
 
s. 141/580 
 
2025-09-08

***
## Art. 371. {#kpc-pierwsza-pierwsza-art-371}

Sąd pierwszej instancji przedstawia niezwłocznie akta sprawy 
sądowi drugiej instancji.

***
## Art. 372. {#kpc-pierwsza-pierwsza-art-372}

(uchylony)

***
## Art. 373. {#kpc-pierwsza-pierwsza-art-373}

**§ 1.** Sąd drugiej instancji odrzuca apelację spóźnioną, nieopłaconą 
lub z innych przyczyn niedopuszczalną, jak również apelację, której braków strona 
nie usunęła w wyznaczonym terminie. 
**§ 2.** Czynności związane z nadaniem biegu apelacji może wykonywać 
referendarz sądowy.

***
## Art. 3731. {#kpc-pierwsza-pierwsza-art-3731}

Przewodniczący zarządza doręczenie odpisów apelacji pozostałym 
stronom, pouczając je o treści art. 374. Pozostałe strony mogą wnieść odpowiedź 
na apelację w terminie dwóch tygodni od dnia doręczenia odpisu apelacji.

***
## Art. 374. {#kpc-pierwsza-pierwsza-art-374}

Sąd drugiej instancji może rozpoznać sprawę na posiedzeniu 
niejawnym, jeżeli przeprowadzenie rozprawy nie jest konieczne. Rozpoznanie 
sprawy na posiedzeniu niejawnym jest niedopuszczalne, jeżeli strona w apelacji lub 
odpowiedzi na apelację złożyła wniosek o przeprowadzenie rozprawy, chyba że 
cofnięto pozew lub apelację albo zachodzi nieważność postępowania.

***
## Art. 375. {#kpc-pierwsza-pierwsza-art-375}

Poza 
przypadkami 
określonymi 
w art. 3911, 
art. 373 
i art. 374 przewodniczący wyznacza rozprawę.

***
## Art. 376. {#kpc-pierwsza-pierwsza-art-376}

Rozprawa przed sądem drugiej instancji odbywa się bez względu na 
niestawiennictwo jednej lub obu stron. Wydany wyrok nie jest zaoczny.

***
## Art. 377. {#kpc-pierwsza-pierwsza-art-377}

Po wywołaniu sprawy rozprawa rozpoczyna się od sprawozdania 
sędziego, który zwięźle przedstawia stan sprawy ze szczególnym uwzględnieniem 
zarzutów i wniosków apelacyjnych. Sąd może zrezygnować ze sprawozdania za 
zgodą obecnych stron albo w przypadku ich niestawiennictwa, chyba że rozprawa 
odbywa się z udziałem publiczności.

***
## Art. 378. {#kpc-pierwsza-pierwsza-art-378}

**§ 1.** Sąd drugiej instancji rozpoznaje sprawę w granicach apelacji; 
w granicach zaskarżenia bierze jednak z urzędu pod uwagę nieważność 
postępowania. 
**§ 2.** W granicach zaskarżenia sąd drugiej instancji może z urzędu rozpoznać 
sprawę także na rzecz współuczestników, którzy wyroku nie zaskarżyli, gdy będące 

 
 
 
s. 142/580 
 
2025-09-08 
 
przedmiotem zaskarżenia prawa lub obowiązki są dla nich wspólne. Współ-
uczestników tych należy zawiadomić o rozprawie; mogą oni składać pisma 
przygotowawcze.

***
## Art. 379. {#kpc-pierwsza-pierwsza-art-379}

Nieważność postępowania zachodzi: 
- 1) jeżeli droga sądowa była niedopuszczalna; 
- 2) jeżeli strona nie miała zdolności sądowej lub procesowej, organu powołanego 
do jej reprezentowania lub przedstawiciela ustawowego, albo gdy 
pełnomocnik strony nie był należycie umocowany; 
- 3) jeżeli o to samo roszczenie między tymi samymi stronami toczy się sprawa 
wcześniej wszczęta albo jeżeli sprawa taka została już prawomocnie 
osądzona; 
- 4) jeżeli skład sądu orzekającego był sprzeczny z przepisami prawa albo jeżeli 
w rozpoznaniu sprawy brał udział sędzia wyłączony z mocy ustawy; 
- 5) jeżeli strona została pozbawiona możności obrony swych praw; 
- 6) jeżeli sąd rejonowy orzekł w sprawie, w której sąd okręgowy jest właściwy 
bez względu na wartość przedmiotu sporu.

***
## Art. 380. {#kpc-pierwsza-pierwsza-art-380}

Sąd drugiej instancji, na wniosek strony, rozpoznaje również te 
postanowienia sądu pierwszej instancji, które nie podlegały zaskarżeniu w drodze 
zażalenia, a miały wpływ na rozstrzygnięcie sprawy.

***
## Art. 381. {#kpc-pierwsza-pierwsza-art-381}

Sąd drugiej instancji może pominąć nowe fakty i dowody, jeżeli 
strona mogła je powołać w postępowaniu przed sądem pierwszej instancji, chyba 
że potrzeba powołania się na nie wynikła później.

***
## Art. 382. {#kpc-pierwsza-pierwsza-art-382}

Sąd drugiej instancji orzeka na podstawie materiału zebranego 
w postępowaniu w pierwszej instancji oraz w postępowaniu apelacyjnym.

***
## Art. 383. {#kpc-pierwsza-pierwsza-art-383}

W postępowaniu apelacyjnym nie można rozszerzyć żądania pozwu 
ani występować z nowymi roszczeniami. Jednakże w razie zmiany okoliczności 
można żądać zamiast pierwotnego przedmiotu sporu jego wartości lub innego 
przedmiotu, a w sprawach o świadczenie powtarzające się można nadto rozszerzyć 
żądanie pozwu o świadczenia za dalsze okresy.

***
## Art. 384. {#kpc-pierwsza-pierwsza-art-384}

Sąd nie może uchylić lub zmienić wyroku na niekorzyść strony 
wnoszącej apelację, chyba że strona przeciwna również wniosła apelację. 

 
 
 
s. 143/580 
 
2025-09-08

***
## Art. 385. {#kpc-pierwsza-pierwsza-art-385}

Sąd drugiej instancji oddala apelację, jeżeli jest ona bezzasadna.

***
## Art. 386. {#kpc-pierwsza-pierwsza-art-386}

**§ 1.** W razie uwzględnienia apelacji sąd drugiej instancji zmienia 
zaskarżony wyrok i orzeka co do istoty sprawy. 
**§ 2.** W razie stwierdzenia nieważności postępowania sąd drugiej instancji 
uchyla 
zaskarżony 
wyrok, 
znosi 
postępowanie 
w zakresie 
dotkniętym 
nieważnością i przekazuje sprawę sądowi pierwszej instancji do ponownego 
rozpoznania. 
**§ 3.** Jeżeli pozew ulega odrzuceniu albo zachodzi podstawa do umorzenia 
postępowania, sąd drugiej instancji uchyla wyrok oraz odrzuca pozew lub umarza 
postępowanie. 
**§ 4.** Poza wypadkami określonymi w § 2 i 3 sąd drugiej instancji może 
uchylić zaskarżony wyrok i przekazać sprawę do ponownego rozpoznania tylko 
w razie nierozpoznania przez sąd pierwszej instancji istoty sprawy albo gdy 
wydanie wyroku wymaga przeprowadzenia postępowania dowodowego w całości. 
**§ 5.** W przypadku uchylenia wyroku i przekazania sprawy do ponownego 
rozpoznania sąd rozpoznaje ją w tym samym składzie, chyba że nie jest to możliwe 
lub powodowałoby nadmierną zwłokę w postępowaniu. 
**§ 6.** Ocena prawna wyrażona w uzasadnieniu wyroku sądu drugiej instancji 
wiąże zarówno sąd, któremu sprawa została przekazana, jak i sąd drugiej instancji, 
przy ponownym rozpoznaniu sprawy. Nie dotyczy to jednak przypadku, gdy 
nastąpiła zmiana stanu prawnego lub faktycznego, albo po wydaniu wyroku sądu 
drugiej instancji Sąd Najwyższy w uchwale rozstrzygającej zagadnienie prawne 
wyraził odmienną ocenę prawną.

***
## Art. 387. {#kpc-pierwsza-pierwsza-art-387}

**§ 1.** Sąd drugiej instancji uzasadnia z urzędu wyrok oraz 
postanowienie kończące postępowanie w sprawie. 
**§ 11.** W sprawach, w których: 
- 1) apelację oddalono, 
- 2) zmieniono zaskarżony wyrok lub 
- 3) skarga kasacyjna ani zażalenie do Sądu Najwyższego nie przysługują 
– pisemne uzasadnienie sporządza się tylko wówczas, gdy strona zgłosiła wniosek 
o doręczenie orzeczenia z uzasadnieniem. 

 
 
 
s. 144/580 
 
2025-09-08 
**§ 2.** Pisemne uzasadnienie albo transkrypcję wygłoszonego uzasadnienia 
sporządza się w terminie dwóch tygodni od dnia ogłoszenia orzeczenia. Jeżeli 
ogłoszenia nie było, termin ten liczy się od dnia wydania orzeczenia. W sprawach, 
o których mowa w § 11, pisemne uzasadnienie albo transkrypcję wygłoszonego 
uzasadnienia sporządza się w terminie dwóch tygodni od dnia zgłoszenia wniosku 
o doręczenie wyroku z uzasadnieniem. 
**§ 21.** W uzasadnieniu wyroku sądu drugiej instancji: 
- 1) wskazanie podstawy faktycznej rozstrzygnięcia może ograniczyć się do 
stwierdzenia, że sąd drugiej instancji przyjął za własne ustalenia sądu 
pierwszej instancji, chyba że sąd drugiej instancji zmienił lub uzupełnił te 
ustalenia; jeżeli sąd drugiej instancji przeprowadził postępowanie dowodowe 
lub odmiennie ocenił dowody przeprowadzone przed sądem pierwszej 
instancji, uzasadnienie powinno także zawierać ustalenie faktów, które sąd 
drugiej instancji uznał za udowodnione, dowodów, na których się oparł, 
i przyczyn, dla których innym dowodom odmówił wiarygodności i mocy 
dowodowej; 
- 2) wyjaśnienie podstawy prawnej wyroku z przytoczeniem przepisów prawa 
powinno objąć ocenę poszczególnych zarzutów apelacyjnych, a poza tym 
może ograniczyć się do stwierdzenia, że sąd drugiej instancji przyjął za własne 
oceny sądu pierwszej instancji. 
**§ 3.** Orzeczenie z uzasadnieniem doręcza się tej stronie, która w terminie 
tygodnia od dnia ogłoszenia orzeczenia zgłosiła wniosek o doręczenie orzeczenia 
z uzasadnieniem. Przepis art. 327 § 2 stosuje się odpowiednio. Jeżeli ogłoszenia 
nie było, orzeczenie z uzasadnieniem doręcza się stronom z urzędu w terminie 
tygodnia od dnia sporządzenia uzasadnienia. 
**§ 4.** Jeżeli nie sporządzono pisemnego uzasadnienia wyroku ani transkrypcji 
wygłoszonego uzasadnienia, a w sprawie została wniesiona skarga kasacyjna lub 
skarga o stwierdzenie niezgodności z prawem prawomocnego orzeczenia, 
sporządza się je w terminie dwóch tygodni od dnia wpływu skargi do sądu, a jeżeli 
skarga była dotknięta brakami – od dnia usunięcia tych braków. Uzasadnienie 
można ograniczyć do zakresu, którego dotyczy skarga.

***
## Art. 3871. {#kpc-pierwsza-pierwsza-art-3871}

W razie wydania przez sąd drugiej instancji orzeczenia, od którego 
przysługuje skarga kasacyjna, strony i ich przedstawiciele mają obowiązek, do 

 
 
 
s. 145/580 
 
2025-09-08 
 
czasu upływu terminu do wniesienia skargi kasacyjnej, zawiadamiać sąd drugiej 
instancji o każdej zmianie miejsca zamieszkania.

***
## Art. 388. {#kpc-pierwsza-pierwsza-art-388}

**§ 1.** Jeżeli na skutek wykonania orzeczenia stronie może być 
wyrządzona niepowetowana szkoda, sąd drugiej instancji na wniosek strony może 
wstrzymać wykonanie swego orzeczenia do czasu ukończenia postępowania kasa-
cyjnego. Jeżeli apelację oddalono, sąd drugiej instancji może wstrzymać wykonanie 
także orzeczenia sądu pierwszej instancji. 
**§ 11.** W przypadku, o którym mowa w § 1, sąd drugiej instancji na wniosek 
strony może także uzależnić wykonanie orzeczenia od złożenia przez powoda 
stosownego zabezpieczenia. 
**§ 2.** Zabezpieczenie może również polegać na wstrzymaniu wydania 
powodowi sum pieniężnych po ich wyegzekwowaniu od pozwanego lub na 
wstrzymaniu sprzedaży zajętego majątku. 
**§ 3.** Do czasu upływu terminu do wniesienia skargi kasacyjnej wstrzymuje się 
z urzędu sprzedaż nieruchomości. 
**§ 4.** Przepis § 1 stosuje się odpowiednio do wstrzymania skuteczności 
zaskarżonego orzeczenia niepodlegającego wykonaniu.

***
## Art. 3881. {#kpc-pierwsza-pierwsza-art-3881}

**§ 1.** W sprawach o odebranie osoby podlegającej władzy 
rodzicielskiej lub pozostającej pod opieką prowadzonych na podstawie Konwencji 
dotyczącej cywilnych aspektów uprowadzenia dziecka za granicę, sporządzonej 
w Hadze dnia 25 października 1980 r. (Dz. U. z 1995 r. poz. 528 oraz z 1999 r. 
poz. 1085), zwanej dalej „konwencją haską z 1980 r.”, na żądanie podmiotu 
wymienionego w art. 5191 § 22 zgłoszone sądowi, o którym mowa w art. 5182 § 1, 
w terminie nieprzekraczającym dwóch tygodni od dnia uprawomocnienia się 
postanowienia w przedmiocie odebrania osoby podlegającej władzy rodzicielskiej 
lub pozostającej pod opieką, wstrzymuje się z mocy prawa wykonanie tego 
postanowienia. 
**§ 2.** Wstrzymanie wykonania postanowienia, o którym mowa w § 1, ustaje, 
jeżeli podmiot wymieniony w art. 5191 § 22 nie wniesie skargi kasacyjnej 
w terminie dwóch miesięcy od dnia uprawomocnienia się tego postanowienia. 
**§ 3.** W przypadku 
wniesienia 
przez 
podmiot 
wymieniony 
w art. 5191 § 22 skargi 
kasacyjnej 
w terminie 
dwóch 
miesięcy 
od 
dnia 

 
 
 
s. 146/580 
 
2025-09-08 
 
uprawomocnienia się postanowienia, o którym mowa w § 1, wstrzymanie 
wykonania tego postanowienia przedłuża się z mocy prawa do czasu ukończenia 
postępowania kasacyjnego. 
**§ 4.** Podmiot, który zgłosił żądanie wstrzymania wykonania postanowienia, 
o którym mowa w § 1, może je cofnąć w terminie dwóch miesięcy od dnia 
uprawomocnienia się postanowienia, chyba że podmiot wymieniony w art. 5191 
§ 22 wniósł skargę kasacyjną. 
**§ 5.** Wskutek cofnięcia żądania wstrzymania wykonania postanowienia, 
o którym mowa w § 1, postanowienie to staje się wykonalne.

***
## Art. 3882. {#kpc-pierwsza-pierwsza-art-3882}

Niezgłoszenie 
żądania 
zgodnie 
z art. 3881 § 1 nie 
wyłącza 
możliwości wstrzymania wykonania postanowienia w przedmiocie odebrania 
osoby podlegającej władzy rodzicielskiej lub pozostającej pod opieką na wniosek 
strony złożony na podstawie art. 388 § 1.

***
## Art. 3883. {#kpc-pierwsza-pierwsza-art-3883}

Wniesienie skargi nadzwyczajnej, o której mowa w art. 89 ustawy 
z dnia 8 grudnia 2017 r. o Sądzie Najwyższym (Dz. U. z 2024 r. poz. 622), 
w sprawie o odebranie osoby podlegającej władzy rodzicielskiej lub pozostającej 
pod opieką prowadzonej na podstawie konwencji haskiej z 1980 r. wstrzymuje 
z mocy prawa wykonanie postanowienia w przedmiocie odebrania osoby 
podlegającej władzy rodzicielskiej lub pozostającej pod opieką do czasu 
zakończenia postępowania z tej skargi.

***
## Art. 389. {#kpc-pierwsza-pierwsza-art-389}

Po bezskutecznym upływie terminu do zaskarżenia wydanego 
wyroku sąd drugiej instancji zwraca akta sądowi pierwszej instancji.

***
## Art. 390. {#kpc-pierwsza-pierwsza-art-390}

**§ 1.** Jeżeli przy rozpoznawaniu apelacji powstanie zagadnienie 
prawne budzące poważne wątpliwości, sąd może przedstawić to zagadnienie do 
rozstrzygnięcia Sądowi Najwyższemu, odraczając rozpoznanie sprawy. Sąd 
Najwyższy władny jest przejąć sprawę do rozpoznania albo przekazać zagadnienie 
do rozstrzygnięcia powiększonemu składowi tego Sądu. 
**§ 2.** Uchwała Sądu Najwyższego rozstrzygająca zagadnienie prawne wiąże 
w danej sprawie.

***
## Art. 391. {#kpc-pierwsza-pierwsza-art-391}

**§ 1.** Jeżeli nie ma szczególnych przepisów o postępowaniu przed 
sądem drugiej instancji, do postępowania tego stosuje się odpowiednio przepisy 

 
 
 
s. 147/580 
 
2025-09-08 
 
o postępowaniu przed sądem pierwszej instancji. Przepisy art. 194–196 i 198 nie 
mają zastosowania. 
**§ 2.** W razie cofnięcia apelacji sąd drugiej instancji umarza postępowanie 
apelacyjne i orzeka o kosztach jak przy cofnięciu pozwu. Gdy cofnięcie apelacji 
nastąpiło przed sądem pierwszej instancji, postępowanie umarza sąd pierwszej 
instancji.

***
## Art. 3911. {#kpc-pierwsza-pierwsza-art-3911}

**§ 1.** W przypadku wniesienia apelacji od wyroku wydanego na 
podstawie art. 1911 można pominąć czynności, które ustawa nakazuje podjąć na 
skutek wniesienia apelacji, w szczególności nie wzywać powoda do usunięcia jej 
braków ani uiszczenia opłaty. Sąd drugiej instancji może rozpoznać apelację na 
posiedzeniu niejawnym, nie doręczając apelacji osobie wskazanej jako pozwany 
ani nie rozpoznając wniosków złożonych wraz z tą apelacją. 
**§ 2.** W przypadku wątpliwości apelację uważa się za wniesioną co do całości 
wyroku z wnioskiem o jego uchylenie i przekazanie sprawy do ponownego 
rozpoznania. 
**§ 3.** W przypadku stwierdzenia, że powództwo nie jest oczywiście 
bezzasadne, sąd drugiej instancji uchyla zaskarżony wyrok i przekazuje sprawę 
sądowi pierwszej instancji do ponownego rozpoznania. W pozostałych 
przypadkach sąd drugiej instancji oddala apelację. 
**§ 4.** Uzasadnienie wyroku oddalającego apelację sąd drugiej instancji może 
ograniczyć do odwołania się do ustaleń i wyjaśnienia podstawy prawnej wyroku 
zawartych w uzasadnieniu wyroku sądu pierwszej instancji. 
**§ 5.** Wyrok z pisemnym uzasadnieniem, o ile je sporządzono, i wymaganymi 
przez ustawę pouczeniami z urzędu doręcza się tylko powodowi. 
**§ 6.** Przepisu art. 3941 § 11 nie stosuje się. 
**§ 7.** W przypadku uchylenia wyroku wydanego na podstawie art. 1911 w toku 
ponownego rozpoznania: 
- 1) ilekroć ustawa przewiduje zwrot pozwu, sąd umarza postępowanie; 
- 2) wraz z odpisem pozwu doręcza się pozwanemu odpisy apelacji oraz wyroków 
sądów obu instancji z uzasadnieniami. 
Rozdział 11 
(zawierający art. 392–39320 – uchylony) 

 
 
 
s. 148/580 
 
2025-09-08 
 
Rozdział 2 
Zażalenie

***
## Art. 394. {#kpc-pierwsza-pierwsza-art-394}

**§ 1.** Zażalenie 
do 
sądu 
drugiej 
instancji 
przysługuje 
na 
postanowienia sądu pierwszej instancji kończące postępowanie w sprawie, 
a ponadto 
na 
postanowienia 
sądu 
pierwszej 
instancji 
i zarządzenia 
przewodniczącego, których przedmiotem jest: 
- 1) zwrot pisma wniesionego jako pozew, z którego nie wynika żądanie 
rozpoznania sprawy; 
- 2) zwrot pozwu; 
- 3) odmowa odrzucenia pozwu; 
- 4) przekazanie sprawy sądowi równorzędnemu lub niższemu albo podjęcie 
postępowania w innym trybie; 
- 5) zawieszenie postępowania i odmowa podjęcia zawieszonego postępowania; 
- 51) sprostowanie lub wykładnia orzeczenia albo ich odmowa; 
- 6) zwrot kosztów, określenie zasad ponoszenia przez strony kosztów procesu, 
zwrot opłaty lub obciążenie kosztami sądowymi – jeżeli strona nie składa 
środka zaskarżenia co do istoty sprawy. 
**§ 2.** Termin do wniesienia zażalenia wynosi tydzień od dnia doręczenia 
postanowienia z uzasadnieniem, w tym także w przypadku, gdy doręczenie to 
nastąpiło z urzędu. Jeżeli przy wydaniu postanowienia sąd odstąpił od jego 
uzasadnienia, termin liczy się od dnia ogłoszenia postanowienia, a jeżeli podlegało 
ono doręczeniu – od dnia jego doręczenia. 
**§ 3.** Zażalenie powinno czynić zadość wymaganiom przepisanym dla pisma 
procesowego oraz zawierać wskazanie zaskarżonego postanowienia i wniosek 
o jego zmianę lub uchylenie, jak również zwięzłe uzasadnienie zażalenia ze 
wskazaniem w miarę potrzeby nowych faktów i dowodów. 
**§ 4.** Jeżeli przepis szczególny przewiduje, że stronie przysługuje zażalenie na 
postanowienie sądu, ale nie określa, jaki sąd ma je rozpoznać, zażalenie rozpoznaje 
sąd drugiej instancji.

***
## Art. 3941. {#kpc-pierwsza-pierwsza-art-3941}

**§ 1.** Zażalenie do Sądu Najwyższego przysługuje na postanowienie 
sądu drugiej instancji odrzucające skargę kasacyjną oraz na postanowienie sądu 

 
 
 
s. 149/580 
 
2025-09-08 
 
drugiej lub pierwszej instancji odrzucające skargę o stwierdzenie niezgodności 
z prawem prawomocnego orzeczenia. 
**§ 11.** Zażalenie do Sądu Najwyższego przysługuje także w razie uchylenia 
przez sąd drugiej instancji wyroku sądu pierwszej instancji i przekazania sprawy 
do ponownego rozpoznania. 
**§ 2.** (uchylony) 
**§ 3.** Do postępowania przed Sądem Najwyższym toczącego się na skutek 
zażalenia stosuje się odpowiednio art. 394 § 2 i 3, art. 395, art. 397 § 1 i 11, 
art. 3986 § 3, art. 39814, art. 39815 § 1 zdanie pierwsze, art. 39816, art. 39817 
i art. 39821.

***
## Art. 3941a. {#kpc-pierwsza-pierwsza-art-3941a}

**§ 1.** Zażalenie do innego składu sądu pierwszej instancji 
przysługuje na postanowienia tego sądu, których przedmiotem jest: 
- 1) odmowa zwolnienia od kosztów sądowych lub cofnięcie takiego zwolnienia 
oraz odmowa ustanowienia adwokata lub radcy prawnego lub ich odwołanie; 
- 2) oddalenie opozycji przeciwko wstąpieniu interwenienta ubocznego oraz 
niedopuszczenie interwenienta do udziału w sprawie wskutek uwzględnienia 
opozycji; 
- 3) rygor natychmiastowej wykonalności; 
- 4) wstrzymanie wykonania prawomocnego orzeczenia do czasu rozstrzygnięcia 
skargi o wznowienie postępowania; 
- 5) stwierdzenie prawomocności orzeczenia; 
- 6) skazanie świadka, biegłego, strony, jej pełnomocnika oraz osoby trzeciej na 
grzywnę, zarządzenie przymusowego sprowadzenia i aresztowania świadka 
oraz odmowa zwolnienia świadka i biegłego od grzywny i świadka od przy-
musowego sprowadzenia; 
- 7) odmowa uzasadnienia orzeczenia oraz jego doręczenia; 
- 8) (uchylony) 
- 9) zwrot zaliczki, zwrot kosztów nieopłaconej pomocy prawnej udzielonej 
z urzędu oraz wynagrodzenie biegłego, mediatora, kuratora ustanowionego 
dla strony w danej sprawie i należności świadka, a także koszty przyznane 
w nakazie zapłaty, jeżeli nie wniesiono środka zaskarżenia od nakazu; 
- 10) oddalenie wniosku o wyłączenie sędziego; 
- 11) zatwierdzenie ugody zawartej przed mediatorem; 

 
 
 
s. 150/580 
 
2025-09-08 
- 12) odrzucenie zażalenia; 
- 13) odrzucenie skargi na orzeczenie referendarza sądowego; 
- 14) zatwierdzenie ugody w sprawie odwołania do sądu ochrony konkurencji 
i konsumentów; 
- 15) wstrzymanie wykonania decyzji, w przypadku zawieszenia postępowania, na 
zgodny wniosek stron zamierzających zawrzeć ugodę w sprawie odwołania 
do sądu ochrony konkurencji i konsumentów. 
**§ 11.** Sąd, który wydał zaskarżone postanowienie, odrzuca w składzie jednego 
sędziego zażalenie spóźnione, nieopłacone lub z innych przyczyn niedopuszczalne, 
jak również zażalenie, którego braków strona nie usunęła w wyznaczonym 
terminie. 
**§ 12.** Sąd rozpoznaje zażalenie, o którym mowa w § 1, w składzie trzech 
sędziów. 
**§ 2.** W postępowaniu toczącym się na skutek zażalenia, o którym mowa 
w § 1, przepisy art. 394 § 2 i 3 oraz art. 395–397 stosuje się odpowiednio. 
**§ 3.** Jeżeli w sądzie pierwszej instancji nie można utworzyć składu do 
rozpoznania zażalenia, zażalenie rozpoznaje sąd drugiej instancji. Okoliczność, 
o której mowa w zdaniu pierwszym, nie podlega badaniu przez sąd drugiej 
instancji.

***
## Art. 3941b. {#kpc-pierwsza-pierwsza-art-3941b}

Jeżeli zaskarżono postanowienie, o którym mowa w art. 394 § 1 
i zarazem w art. 3941a § 1, zażalenie rozpoznaje sąd drugiej instancji.

***
## Art. 3942. {#kpc-pierwsza-pierwsza-art-3942}

**§ 1.** Zażalenie do innego składu sądu drugiej instancji przysługuje 
na postanowienie tego sądu o odrzuceniu apelacji, postanowienie o odrzuceniu 
skargi o wznowienie postępowania i postanowienie o umorzeniu postępowania 
wywołanego wniesieniem apelacji. 
**§ 11.** Zażalenie do innego składu sądu drugiej instancji przysługuje także na 
postanowienia tego sądu, których przedmiotem jest: 
- 1) odmowa zwolnienia od kosztów sądowych lub cofnięcie takiego zwolnienia 
oraz odmowa ustanowienia adwokata lub radcy prawnego lub ich odwołanie, 
- 2) oddalenie wniosku o wyłączenie sędziego, 
- 3) zwrot kosztów procesu, o ile nie wniesiono skargi kasacyjnej, 
- 4) zwrot kosztów nieopłaconej pomocy prawnej udzielonej z urzędu, 

 
 
 
s. 151/580 
 
2025-09-08 
- 41) wynagrodzenie biegłego, mediatora i należności świadka, 
- 5) skazanie świadka, biegłego, strony, jej pełnomocnika oraz osoby trzeciej na 
grzywnę, 
- 51) odmowa uzasadnienia orzeczenia oraz jego doręczenia, 
- 6) zarządzenie przymusowego sprowadzenia i aresztowania świadka, 
- 7) odmowa zwolnienia świadka i biegłego od grzywny i świadka od 
przymusowego sprowadzenia 
– z wyjątkiem postanowień wydanych w wyniku rozpoznania zażalenia na 
postanowienie sądu pierwszej instancji. 
**§ 12.** Jeżeli zażalenie, o którym mowa w § 1 i 11, jest spóźnione, nieopłacone 
lub z innych przyczyn niedopuszczalne albo jego braków strona nie usunęła 
w wyznaczonym terminie, sąd odrzuca je w składzie jednego sędziego. Na 
postanowienie przysługuje zażalenie do innego składu sądu drugiej instancji. 
**§ 13.** Sąd rozpoznaje zażalenie, o którym mowa w § 1 i 11, w składzie trzech 
sędziów. 
**§ 2.** W postępowaniu toczącym się na skutek zażalenia, o którym mowa 
w § 1–12, przepisy art. 394 § 2 i 3 oraz art. 395–397 stosuje się odpowiednio.

***
## Art. 3943. {#kpc-pierwsza-pierwsza-art-3943}

**§ 1.** Niedopuszczalne jest zażalenie wniesione jedynie dla zwłoki 
w postępowaniu. 
**§ 2.** Za zażalenie wniesione jedynie dla zwłoki w postępowaniu uważa się: 
- 1) drugie i dalsze zażalenie wniesione przez tę samą stronę na to samo 
postanowienie, 
- 2) zażalenie na postanowienie wydane w wyniku czynności wywołanych 
wniesieniem przez tę samą stronę wcześniejszego zażalenia 
– chyba że okoliczności sprawy wykluczają tę ocenę. 
**§ 3.** Zażalenie, o którym mowa w § 1, pozostawia się w aktach sprawy bez 
żadnych dalszych czynności, w szczególności nie przedstawia się go do 
rozpoznania sądowi właściwemu. To samo dotyczy pism związanych z jego 
wniesieniem. 
**§ 4.** O pozostawieniu zażalenia i pism związanych z jego wniesieniem 
zawiadamia się stronę wnoszącą tylko raz – przy wniesieniu zażalenia. 
**§ 5.** Przepis art. 380 stosuje się odpowiednio. 

 
 
 
s. 152/580 
 
2025-09-08

***
## Art. 395. {#kpc-pierwsza-pierwsza-art-395}

**§ 1.** W przypadku wniesienia zażalenia sąd pierwszej instancji 
niezwłocznie przedstawia je wraz z aktami sądowi właściwemu do jego 
rozpoznania, chyba że zażalenie jest spóźnione lub z mocy prawa niedopuszczalne. 
W takim przypadku sąd, który wydał zaskarżone postanowienie, odrzuca zażalenie 
w składzie jednego sędziego. 
**§ 11.** Strona przeciwna może wnieść odpowiedź na zażalenie w terminie 
tygodnia od dnia doręczenia zażalenia, a w przypadkach gdy ustawa przewiduje 
doręczenie zaskarżonego postanowienia tylko jednej ze stron oraz w przypadkach 
wskazanych w art. 3941a § 1 pkt 6 – od dnia wniesienia zażalenia. 
**§ 2.** Jeżeli zażalenie zarzuca nieważność postępowania lub jest oczywiście 
uzasadnione, sąd, który wydał zaskarżone postanowienie, może, nie przesyłając akt 
sądowi drugiej instancji, uchylić zaskarżone postanowienie i w miarę potrzeby 
sprawę rozpoznać na nowo. Od ponownie wydanego postanowienia przysługują 
środki odwoławcze na zasadach ogólnych.

***
## Art. 396. {#kpc-pierwsza-pierwsza-art-396}

Sąd może wstrzymać wykonanie zaskarżonego postanowienia do 
czasu rozstrzygnięcia zażalenia.

***
## Art. 397. {#kpc-pierwsza-pierwsza-art-397}

**§ 1.** Sąd rozpoznaje zażalenie na posiedzeniu niejawnym w składzie 
jednego sędziego. 
**§ 11.** Sąd drugiej instancji odrzuca zażalenie, jeżeli podlegało ono odrzuceniu 
przez sąd pierwszej instancji, jak również zażalenie, którego braków strona nie 
usunęła w wyznaczonym terminie. 
**§ 2.** W postępowaniu toczącym się na skutek zażalenia sąd uzasadnia z urzędu 
postanowienie kończące to postępowanie. W sprawach, w których zażalenie 
oddalono lub zmieniono treść sentencji zaskarżonego postanowienia, pisemne 
uzasadnienie sporządza się tylko wówczas, gdy strona zgłosiła wniosek 
o doręczenie postanowienia z uzasadnieniem. 
**§ 3.** Do postępowania toczącego się na skutek zażalenia stosuje się 
odpowiednio przepisy o postępowaniu apelacyjnym.

***
## Art. 3971. {#kpc-pierwsza-pierwsza-art-3971}

(uchylony)

***
## Art. 398. {#kpc-pierwsza-pierwsza-art-398}

Przepisy niniejszego działu stosuje się odpowiednio do zażaleń na 
zarządzenia przewodniczącego. 

 
 
 
s. 153/580 
 
2025-09-08 
 
DZIAŁ Va 
Skarga kasacyjna

***
## Art. 3981. {#kpc-pierwsza-pierwsza-art-3981}

**§ 1.** Od wydanego przez sąd drugiej instancji prawomocnego 
wyroku lub postanowienia w przedmiocie odrzucenia pozwu albo umorzenia 
postępowania kończących postępowanie w sprawie strona, Prokurator Generalny, 
Rzecznik Praw Obywatelskich lub Rzecznik Praw Dziecka może wnieść skargę 
kasacyjną do Sądu Najwyższego, chyba że przepis szczególny stanowi inaczej. 
**§ 2.** Wniesienie skargi kasacyjnej przez stronę wyłącza – w zaskarżonym 
zakresie – wniesienie skargi kasacyjnej przez Prokuratora Generalnego, Rzecznika 
Praw Obywatelskich lub Rzecznika Praw Dziecka.

***
## Art. 3982. {#kpc-pierwsza-pierwsza-art-3982}

**§ 1.** Skarga kasacyjna jest niedopuszczalna w sprawach o prawa 
majątkowe, w których wartość przedmiotu zaskarżenia jest niższa niż pięćdziesiąt 
tysięcy złotych, a w sprawach z zakresu prawa pracy i ubezpieczeń społecznych – 
niższa niż dziesięć tysięcy złotych. Jednakże w sprawach z zakresu ubezpieczeń 
społecznych skarga kasacyjna przysługuje niezależnie od wartości przedmiotu 
zaskarżenia w sprawach o przyznanie i o wstrzymanie emerytury lub renty oraz 
o objęcie obowiązkiem ubezpieczenia społecznego. Niezależnie od wartości 
przedmiotu zaskarżenia skarga kasacyjna przysługuje także w sprawach 
o odszkodowanie z tytułu wyrządzenia szkody przez wydanie prawomocnego 
orzeczenia niezgodnego z prawem. 
**§ 2.** Skarga kasacyjna jest niedopuszczalna także w sprawach: 
- 1) o rozwód, o separację, o alimenty, o czynsz najmu lub dzierżawy oraz 
o naruszenie posiadania; 
- 2) dotyczących kar porządkowych, świadectwa pracy i roszczeń z tym 
związanych oraz o deputaty lub ich ekwiwalent; 
- 3) rozpoznanych w postępowaniu uproszczonym. 
**§ 3.** Niedopuszczalna jest skarga kasacyjna od wyroku ustalającego 
nieistnienie małżeństwa lub orzekającego unieważnienie małżeństwa, jeżeli choćby 
jedna ze stron po uprawomocnieniu się wyroku zawarła związek małżeński. 
**§ 4.** Skarga 
kasacyjna 
jest 
niedopuszczalna 
w sprawach, 
w których 
powództwo oddalono na podstawie art. 1911. Skargę kasacyjną wniesioną w takich 
sprawach pozostawia się w aktach sprawy bez żadnych dalszych czynności. To 

 
 
 
s. 154/580 
 
2025-09-08 
 
samo dotyczy pism związanych z jej wniesieniem. O pozostawieniu skargi 
kasacyjnej i pism związanych z jej wniesieniem zawiadamia się powoda tylko raz 
– przy wniesieniu pierwszego pisma. 
**§ 5.** Przepisu § 4 nie stosuje się: 
- 1) gdy w wyniku uchylenia przez sąd drugiej instancji wyroku wydanego na 
podstawie art. 1911 i przekazania sprawy sądowi pierwszej instancji do 
ponownego rozpoznania została ona rozpoznana na zasadach ogólnych; 
- 2) do skargi kasacyjnej wniesionej przez podmiot, o którym mowa 
w art. 3981 § 1, inny niż powód.

***
## Art. 3983. {#kpc-pierwsza-pierwsza-art-3983}

**§ 1.** Skargę kasacyjną strona może oprzeć na następujących 
podstawach: 
- 1) naruszeniu prawa materialnego przez błędną jego wykładnię lub niewłaściwe 
zastosowanie; 
- 2) naruszeniu przepisów postępowania, jeżeli uchybienie to mogło mieć istotny 
wpływ na wynik sprawy. 
**§ 2.** Prokurator Generalny może oprzeć skargę kasacyjną na podstawach 
określonych w § 1, jeżeli przez wydanie orzeczenia doszło do naruszenia 
podstawowych zasad porządku prawnego, Rzecznik Praw Obywatelskich – jeżeli 
przez wydanie orzeczenia doszło do naruszenia konstytucyjnych wolności albo 
praw człowieka i obywatela, a Rzecznik Praw Dziecka – jeżeli przez wydanie 
orzeczenia doszło do naruszenia praw dziecka. 
**§ 3.** Podstawą skargi kasacyjnej nie mogą być zarzuty dotyczące ustalenia 
faktów lub oceny dowodów.

***
## Art. 3984. {#kpc-pierwsza-pierwsza-art-3984}

**§ 1.** Skarga kasacyjna powinna zawierać: 
- 1) oznaczenie orzeczenia, od którego jest wniesiona, ze wskazaniem, czy jest 
ono zaskarżone w całości czy w części; 
- 2) przytoczenie podstaw kasacyjnych i ich uzasadnienie; 
- 3) wniosek o uchylenie lub uchylenie i zmianę orzeczenia z oznaczeniem 
zakresu żądanego uchylenia i zmiany. 
**§ 2.** Oprócz wymagań przewidzianych w § 1, skarga kasacyjna powinna 
zawierać wniosek o przyjęcie do rozpoznania i jego uzasadnienie. 

 
 
 
s. 155/580 
 
2025-09-08 
**§ 3.** Ponadto skarga kasacyjna powinna czynić zadość wymaganiom 
przewidzianym dla pisma procesowego, a w sprawach o prawa majątkowe 
powinna zawierać również oznaczenie wartości przedmiotu zaskarżenia. Do skargi 
kasacyjnej dołącza się także dwa jej odpisy przeznaczone do akt Sądu Najwyższego 
oraz dla Prokuratora Generalnego, chyba że sam wniósł skargę.

***
## Art. 3985. {#kpc-pierwsza-pierwsza-art-3985}

**§ 1.** Skargę kasacyjną wnosi się do sądu, który wydał zaskarżone 
orzeczenie, w terminie dwóch miesięcy od dnia doręczenia orzeczenia 
z uzasadnieniem stronie skarżącej. 
**§ 2.** Termin do wniesienia skargi kasacyjnej przez Prokuratora Generalnego, 
Rzecznika Praw Obywatelskich i Rzecznika Praw Dziecka wynosi sześć miesięcy 
od dnia uprawomocnienia się orzeczenia, a jeżeli strona zażądała doręczenia 
orzeczenia z uzasadnieniem – od chwili doręczenia orzeczenia stronie.

***
## Art. 3986. {#kpc-pierwsza-pierwsza-art-3986}

**§ 1.** Jeżeli skarga kasacyjna nie spełnia wymagań przewidzianych 
w art. 3984 § 2 lub 3, przewodniczący w sądzie drugiej instancji wzywa skarżącego 
do usunięcia braków w terminie tygodniowym pod rygorem odrzucenia skargi. 
**§ 2.** Sąd drugiej instancji odrzuca skargę kasacyjną wniesioną po upływie 
terminu, skargę niespełniającą wymagań określonych w art. 3984 § 1, nieopłaconą 
oraz skargę, której braków nie usunięto w terminie lub z innych przyczyn nie-
dopuszczalną. 
**§ 3.** 13) Sąd Najwyższy odrzuca skargę kasacyjną, która podlegała odrzuceniu 
przez sąd drugiej instancji, albo zwraca ją temu sądowi w celu usunięcia 
dostrzeżonych braków. 
**§ 4.** O odrzuceniu skargi kasacyjnej niespełniającej wymagań określonych 
w art. 3984 § 1 sąd drugiej instancji albo Sąd Najwyższy zawiadamia właściwy 
organ samorządu zawodowego, do którego należy pełnomocnik.

***
## Art. 3987. {#kpc-pierwsza-pierwsza-art-3987}

**§ 1.** Strona przeciwna może wnieść do sądu drugiej instancji 
odpowiedź na skargę kasacyjną w terminie dwutygodniowym od doręczenia jej 
skargi. W razie wniesienia skargi kasacyjnej przez Prokuratora Generalnego, 
- 13) Utracił moc z dniem 8 lipca 2008 r. w związku z art. 3984 § 1 pkt 3 w zakresie, w jakim 
przewiduje odrzucenie – bez wezwania do usunięcia braków – skargi kasacyjnej niespełniającej 
wymagań określonych w art. 3984 § 1 pkt 3, na podstawie wyroku Trybunału Konstytucyjnego 
z dnia 1 lipca 2008 r. sygn. akt SK 40/07 (Dz. U. poz. 779). 

 
 
 
s. 156/580 
 
2025-09-08 
 
Rzecznika Praw Obywatelskich lub Rzecznika Praw Dziecka odpowiedź na skargę 
mogą wnieść obydwie strony. 
**§ 2.** Po upływie terminu do wniesienia odpowiedzi lub po zarządzeniu 
doręczenia odpowiedzi skarżącemu, sąd drugiej instancji niezwłocznie przedstawia 
skargę kasacyjną i odpowiedź wraz z aktami sprawy Sądowi Najwyższemu. Do akt 
sprawy dołącza się dwa odpisy zaskarżonego orzeczenia z uzasadnieniem.

***
## Art. 3988. {#kpc-pierwsza-pierwsza-art-3988}

**§ 1.** W każdej sprawie Sąd Najwyższy może zwrócić się do 
Prokuratora Generalnego o zajęcie na piśmie stanowiska co do skargi kasacyjnej 
wniesionej przez stronę i odpowiedzi na skargę. Prokurator Generalny lub 
wyznaczony przez niego prokurator przedstawia stanowisko w terminie trzydziestu 
dni, a jeżeli uzna, że wymaga tego ochrona praworządności, praw obywatelskich 
lub interesu publicznego, bierze udział w postępowaniu kasacyjnym. 
**§ 2.** Odpis pisma, o którym mowa w § 1, doręcza się stronom, które mogą się 
do niego ustosunkować w terminie czternastu dni, nie później jednak niż na 
rozprawie kasacyjnej.

***
## Art. 3989. {#kpc-pierwsza-pierwsza-art-3989}

**§ 1.** Sąd Najwyższy przyjmuje skargę kasacyjną do rozpoznania, 
jeżeli: 
- 1) w sprawie występuje istotne zagadnienie prawne; 
- 2) istnieje potrzeba wykładni przepisów prawnych budzących poważne 
wątpliwości lub wywołujących rozbieżności w orzecznictwie sądów; 
- 3) zachodzi nieważność postępowania lub 
- 4) skarga kasacyjna jest oczywiście uzasadniona. 
**§ 2.** O przyjęciu lub odmowie przyjęcia skargi kasacyjnej do rozpoznania Sąd 
Najwyższy orzeka na posiedzeniu niejawnym. Postanowienie nie wymaga 
pisemnego uzasadnienia.14)

***
## Art. 39810. {#kpc-pierwsza-pierwsza-art-39810}

Sąd Najwyższy rozpoznaje skargę kasacyjną w składzie trzech 
sędziów. W pozostałych wypadkach Sąd Najwyższy orzeka w składzie jednego 
sędziego.

***
## Art. 39811. {#kpc-pierwsza-pierwsza-art-39811}

**§ 1.** Sąd Najwyższy rozpoznaje skargę kasacyjną na posiedzeniu 
niejawnym, chyba że w sprawie występuje istotne zagadnienie prawne, a skarżący 
- 14) Zdanie drugie utraciło moc z dniem 15 czerwca 2007 r. na podstawie wyroku Trybunału 
Konstytucyjnego z dnia 30 maja 2007 r. sygn. akt SK 68/06 (Dz. U. poz. 731). 

 
 
 
s. 157/580 
 
2025-09-08 
 
złożył w skardze kasacyjnej wniosek o jej rozpoznanie na rozprawie. Sąd 
Najwyższy może także rozpoznać skargę kasacyjną na rozprawie, jeżeli 
przemawiają za tym inne względy. 
**§ 2.** Sędzia sprawozdawca przedstawia na rozprawie zwięźle stan sprawy, ze 
szczególnym uwzględnieniem podstaw i wniosków kasacyjnych. 
**§ 3.** Udzielając głosu stronom, przewodniczący może ograniczyć czas 
wystąpienia, stosownie do wagi i zawiłości sprawy. 
**§ 4.** Jeżeli w rozprawie bierze udział Prokurator Generalny lub upoważniony 
przez niego prokurator, przewodniczący udziela mu głosu po wysłuchaniu stron.

***
## Art. 39812. {#kpc-pierwsza-pierwsza-art-39812}

Z wyjątkiem 
wypadków 
określonych 
w art. 173–1751, 
postępowanie przed Sądem Najwyższym ulega zawieszeniu jedynie na zgodny 
wniosek stron.

***
## Art. 39813. {#kpc-pierwsza-pierwsza-art-39813}

**§ 1.** Sąd Najwyższy rozpoznaje skargę kasacyjną w granicach 
zaskarżenia oraz w granicach podstaw; w granicach zaskarżenia bierze jednak 
z urzędu pod rozwagę nieważność postępowania. 
**§ 2.** W postępowaniu kasacyjnym nie jest dopuszczalne powołanie nowych 
faktów i dowodów, a Sąd Najwyższy jest związany ustaleniami faktycznymi 
stanowiącymi podstawę zaskarżonego orzeczenia. 
**§ 3.** Skarżący może przytoczyć nowe uzasadnienie podstaw kasacyjnych.

***
## Art. 39814. {#kpc-pierwsza-pierwsza-art-39814}

Sąd Najwyższy oddala skargę kasacyjną, jeżeli nie ma 
uzasadnionych podstaw albo jeżeli zaskarżone orzeczenie mimo błędnego 
uzasadnienia odpowiada prawu.

***
## Art. 39815. {#kpc-pierwsza-pierwsza-art-39815}

**§ 1.** Sąd Najwyższy w razie uwzględnienia skargi kasacyjnej 
uchyla zaskarżone orzeczenie w całości lub w części i przekazuje sprawę do 
ponownego rozpoznania sądowi, który wydał orzeczenie, lub innemu sądowi 
równorzędnemu; Sąd Najwyższy może uchylić także w całości lub w części 
orzeczenie sądu pierwszej instancji i przekazać sprawę do ponownego rozpoznania 
sądowi temu samemu lub równorzędnemu. Przy ponownym rozpoznaniu sprawy 
przepis art. 415 stosuje się odpowiednio. 
**§ 2.** W razie przekazania sprawy do ponownego rozpoznania, sąd rozpoznaje 
ją w innym składzie. 

 
 
 
s. 158/580 
 
2025-09-08

***
## Art. 39816. {#kpc-pierwsza-pierwsza-art-39816}

Jeżeli podstawa naruszenia prawa materialnego jest oczywiście 
uzasadniona, a skargi kasacyjnej nie oparto także na podstawie naruszenia 
przepisów postępowania lub podstawa ta okazała się nieuzasadniona, Sąd 
Najwyższy może na wniosek skarżącego uchylić zaskarżony wyrok i orzec co do 
istoty sprawy. Przepis art. 415 stosuje się odpowiednio.

***
## Art. 39817. {#kpc-pierwsza-pierwsza-art-39817}

**§ 1.** Jeżeli przy rozpoznawaniu skargi kasacyjnej wyłoni się 
zagadnienie prawne budzące poważne wątpliwości, Sąd Najwyższy może odroczyć 
wydanie orzeczenia i przekazać to zagadnienie do rozstrzygnięcia powiększonemu 
składowi tego Sądu. 
**§ 2.** Uchwała powiększonego składu Sądu Najwyższego jest w danej sprawie 
wiążąca. 
**§ 3.** Sąd Najwyższy w powiększonym składzie może przejąć sprawę do swego 
rozpoznania.

***
## Art. 39818. {#kpc-pierwsza-pierwsza-art-39818}

W razie 
wniesienia 
skargi 
kasacyjnej 
przez 
Prokuratora 
Generalnego, Rzecznika Praw Obywatelskich lub Rzecznika Praw Dziecka koszty 
procesu w postępowaniu kasacyjnym podlegają wzajemnemu zniesieniu.

***
## Art. 39819. {#kpc-pierwsza-pierwsza-art-39819}

Jeżeli pozew ulegał odrzuceniu albo istniała podstawa do 
umorzenia postępowania, Sąd Najwyższy uchyla wydane w sprawie wyroki oraz 
odrzuca pozew lub umarza postępowanie. Przepis art. 415 stosuje się odpowiednio.

***
## Art. 39820. {#kpc-pierwsza-pierwsza-art-39820}

Sąd, któremu sprawa została przekazana, związany jest wykładnią 
prawa dokonaną w tej sprawie przez Sąd Najwyższy. Nie można oprzeć skargi 
kasacyjnej od orzeczenia wydanego po ponownym rozpoznaniu sprawy na 
podstawach sprzecznych z wykładnią prawa dokonaną w tej sprawie przez Sąd 
Najwyższy.

***
## Art. 39821. {#kpc-pierwsza-pierwsza-art-39821}

Jeżeli nie ma szczególnych przepisów o postępowaniu przed 
Sądem Najwyższym, do postępowania tego stosuje się odpowiednio przepisy 
o apelacji, z tym że skargę kasacyjną cofnąć może również sama strona, a termin 
na sporządzenie uzasadnienia orzeczenia przez Sąd Najwyższy wynosi miesiąc. 

 
 
 
s. 159/580 
 
2025-09-08 
 
DZIAŁ Vb 
Skarga na orzeczenie referendarza sądowego

***
## Art. 39822. {#kpc-pierwsza-pierwsza-art-39822}

**§ 1.** Na orzeczenie referendarza sądowego służy skarga 
w przypadkach, w których na postanowienie sądu służyłoby zażalenie. 
**§ 2.** Skargę wnosi się do sądu, w którym referendarz sądowy wydał 
zaskarżone orzeczenie, w terminie tygodnia od dnia jego doręczenia. Jeżeli 
orzeczenie doręczono bez uzasadnienia, a strona wniosła o jego sporządzenie, 
termin do wniesienia skargi zaczyna biec od dnia doręczenia orzeczenia 
z uzasadnieniem. 
**§ 3.** W przypadku wniesienia skargi orzeczenie referendarza sądowego traci 
moc. 
**§ 4.** Jeżeli skarga jest oczywiście uzasadniona, referendarz sądowy, który 
wydał zaskarżone orzeczenie, w terminie tygodnia od dnia wniesienia skargi może 
postanowieniem stwierdzić zasadność skargi i w miarę potrzeby wydać ponowne 
orzeczenie. Na ponowne orzeczenie służy skarga na zasadach ogólnych, jednak 
w przypadku jego zaskarżenia przepisu paragrafu niniejszego nie stosuje się. 
**§ 5.** Po utracie mocy orzeczenia referendarza sądowego sąd rozpoznaje 
sprawę jako sąd pierwszej instancji. Jeżeli zaskarżenie postanowienia do sądu 
wyższego rzędu nie jest możliwe ze względu na brak takiego sądu, środek 
zaskarżenia rozpoznaje ten sam sąd w innym składzie. 
**§ 6.** Jeżeli referendarz sądowy uzna, że skarga podlega odrzuceniu, 
przedstawia sprawę sądowi. W przypadku uznania, że brak jest podstaw do 
odrzucenia skargi, sąd może od razu rozpoznać sprawę, o ile stan sprawy na to 
pozwala. 
**§ 7.** Przepisy § 1–6 stosuje się odpowiednio do postępowania ze skargi na 
zarządzenie referendarza sądowego.

***
## Art. 39823. {#kpc-pierwsza-pierwsza-art-39823}

**§ 1.** Wniesienie skargi na postanowienie referendarza sądowego 
w przedmiocie kosztów sądowych lub kosztów procesu oraz na postanowienie 
o odmowie ustanowienia adwokata lub radcy prawnego wstrzymuje wykonalność 
tego postanowienia. 

 
 
 
s. 160/580 
 
2025-09-08 
**§ 11.** Orzeczenia, o których mowa w § 1, doręcza się wraz z uzasadnieniem. 
Uzasadnienie może ograniczać się do wskazania podstawy prawnej rozstrzygnięcia 
wraz z przytoczeniem przepisów prawa. 
**§ 2.** Jeżeli wniesiono skargę na postanowienie referendarza sądowego wydane 
na podstawie art. 395 § 2, ponowne wydanie postanowienia na tej podstawie przez 
referendarza sądowego nie jest dopuszczalne. 
**§ 3.** Sąd rozpoznaje skargę w składzie jednego sędziego jako sąd drugiej 
instancji. Po rozpoznaniu skargi sąd utrzymuje w mocy lub zmienia zaskarżone 
postanowienie, stosując odpowiednio przepisy o zażaleniu.

***
## Art. 39824. {#kpc-pierwsza-pierwsza-art-39824}

W zakresie nieuregulowanym do postępowania ze skargi na 
orzeczenie referendarza sądowego stosuje się odpowiednio przepisy o zażaleniu. 
#### DZIAŁ VI
Wznowienie postępowania

***
## Art. 399. {#kpc-pierwsza-pierwsza-art-399}

**§ 1.** W wypadkach przewidzianych w dziale niniejszym można 
żądać wznowienia postępowania, które zostało zakończone prawomocnym 
wyrokiem. 
**§ 2.** Na podstawie określonej w art. 4011 postępowanie może być wznowione 
również w razie zakończenia go postanowieniem.

***
## Art. 400. {#kpc-pierwsza-pierwsza-art-400}

Niedopuszczalna jest skarga o wznowienie od wyroku orzekającego 
unieważnienie małżeństwa lub rozwód albo ustalającego nieistnienie małżeństwa, 
jeżeli choćby jedna ze stron zawarła po jego uprawomocnieniu się nowy związek 
małżeński.

***
## Art. 401. {#kpc-pierwsza-pierwsza-art-401}

Można żądać wznowienia postępowania z powodu nieważności: 
- 1) jeżeli w składzie sądu uczestniczyła osoba nieuprawniona albo jeżeli orzekał 
sędzia wyłączony z mocy ustawy, a strona przed uprawomocnieniem się 
wyroku nie mogła domagać się wyłączenia; 
- 2) jeżeli strona nie miała zdolności sądowej lub procesowej albo nie była 
należycie reprezentowana bądź jeżeli wskutek naruszenia przepisów prawa 
była pozbawiona możności działania; nie można jednak żądać wznowienia, 
jeżeli przed uprawomocnieniem się wyroku niemożność działania ustała lub 

 
 
 
s. 161/580 
 
2025-09-08 
 
brak reprezentacji był podniesiony w drodze zarzutu albo strona potwierdziła 
dokonane czynności procesowe.

***
## Art. 4011. {#kpc-pierwsza-pierwsza-art-4011}

Można żądać wznowienia postępowania również w wypadku, gdy 
Trybunał Konstytucyjny orzekł o niezgodności aktu normatywnego z Konstytucją, 
ratyfikowaną umową międzynarodową lub z ustawą, na podstawie którego zostało 
wydane orzeczenie.

***
## Art. 402. {#kpc-pierwsza-pierwsza-art-402}

(uchylony)

***
## Art. 403. {#kpc-pierwsza-pierwsza-art-403}

**§ 1.** Można żądać wznowienia na tej podstawie, że: 
- 1) wyrok został oparty na dokumencie podrobionym lub przerobionym albo na 
skazującym wyroku karnym, następnie uchylonym; 
- 2) wyrok został uzyskany za pomocą przestępstwa. 
**§ 2.** Można również żądać wznowienia w razie późniejszego wykrycia 
prawomocnego wyroku, dotyczącego tego samego stosunku prawnego, albo 
wykrycia takich faktów lub środków dowodowych, które mogłyby mieć wpływ na 
wynik sprawy, a z których strona nie mogła skorzystać w poprzednim 
postępowaniu. 
**§ 3.** (uchylony) 
**§ 4.** Można żądać wznowienia, jeżeli na treść wyroku miało wpływ 
postanowienie niekończące postępowania w sprawie, wydane na podstawie aktu 
normatywnego uznanego przez Trybunał Konstytucyjny za niezgodny z 
Konstytucją, ratyfikowaną umową międzynarodową lub z ustawą, uchylone lub 
zmienione zgodnie z art. 4161.

***
## Art. 404. {#kpc-pierwsza-pierwsza-art-404}

Z powodu przestępstwa można żądać wznowienia jedynie 
wówczas, gdy czyn został ustalony prawomocnym wyrokiem skazującym, chyba 
że postępowanie karne nie może być wszczęte lub że zostało umorzone z innych 
przyczyn niż brak dowodów.

***
## Art. 405. {#kpc-pierwsza-pierwsza-art-405}

Do wznowienia postępowania z przyczyn nieważności oraz na 
podstawie przewidzianej w art. 4011 właściwy jest sąd, który wydał zaskarżone 
orzeczenie, a jeżeli zaskarżono orzeczenia sądów różnych instancji, właściwy jest 
sąd instancji wyższej. Do wznowienia postępowania na innej podstawie właściwy 
jest sąd, który ostatnio orzekał co do istoty sprawy. 

 
 
 
s. 162/580 
 
2025-09-08

***
## Art. 406. {#kpc-pierwsza-pierwsza-art-406}

Do postępowania ze skargi o wznowienie stosuje się odpowiednio 
przepisy o postępowaniu przed sądem pierwszej instancji, jeżeli przepisy poniższe 
nie stanowią inaczej.

***
## Art. 407. {#kpc-pierwsza-pierwsza-art-407}

**§ 1.** Skargę o wznowienie wnosi się w terminie trzymiesięcznym; 
termin ten liczy się od dnia, w którym strona dowiedziała się o podstawie 
wznowienia, a gdy podstawą jest pozbawienie możności działania lub brak 
należytej reprezentacji – od dnia, w którym o wyroku dowiedziała się strona, jej 
organ lub jej przedstawiciel ustawowy. 
**§ 2.** W sytuacji określonej w art. 4011 skargę o wznowienie wnosi się 
w terminie trzech miesięcy od dnia wejścia w życie orzeczenia Trybunału 
Konstytucyjnego. Jeżeli w chwili wydania orzeczenia Trybunału Konstytucyjnego 
orzeczenie, o którym mowa w art. 4011, nie było jeszcze prawomocne na skutek 
wniesienia środka odwoławczego, który został następnie odrzucony, termin biegnie 
od dnia doręczenia postanowienia o odrzuceniu, a w wypadku wydania go na 
posiedzeniu jawnym – od dnia ogłoszenia tego postanowienia.

***
## Art. 408. {#kpc-pierwsza-pierwsza-art-408}

Po upływie lat dziesięciu od dnia uprawomocnienia się wyroku nie 
można żądać wznowienia, z wyjątkiem przypadku, gdy strona była pozbawiona 
możności działania lub nie była należycie reprezentowana.

***
## Art. 409. {#kpc-pierwsza-pierwsza-art-409}

Skarga o wznowienie powinna czynić zadość warunkom pozwu 
oraz zawierać oznaczenie zaskarżonego orzeczenia, podstawę wznowienia i jej 
uzasadnienie, okoliczności stwierdzające zachowanie terminu do wniesienia skargi 
oraz wniosek o uchylenie lub zmianę zaskarżonego orzeczenia.

***
## Art. 410. {#kpc-pierwsza-pierwsza-art-410}

**§ 1.** Sąd odrzuca skargę wniesioną po upływie przepisanego 
terminu, niedopuszczalną lub nieopartą na ustawowej podstawie. 
**§ 2.** Na żądanie sądu skarżący uprawdopodobni okoliczności stwierdzające 
zachowanie terminu lub dopuszczalność wznowienia.

***
## Art. 4101. {#kpc-pierwsza-pierwsza-art-4101}

**§ 1.** Niedopuszczalna jest skarga o wznowienie postępowania 
ponownie wniesiona w tej samej sprawie przez tę samą stronę i oparta na tych 
samych podstawach, chyba że okoliczności sprawy wykluczają taką ocenę. 
**§ 2.** Do skargi, o której mowa w § 1, przepisy art. 3943 § 3 i 4 stosuje się 
odpowiednio. 

 
 
 
s. 163/580 
 
2025-09-08

***
## Art. 411. {#kpc-pierwsza-pierwsza-art-411}

(uchylony)

***
## Art. 412. {#kpc-pierwsza-pierwsza-art-412}

**§ 1.** Sąd rozpoznaje sprawę na nowo w granicach, jakie zakreśla 
podstawa wznowienia. 
**§ 2.** Po ponownym rozpoznaniu sprawy sąd stosownie do okoliczności bądź 
oddala skargę o wznowienie, bądź uwzględniając ją zmienia zaskarżone orzeczenie 
albo je uchyla i w razie potrzeby pozew odrzuca lub postępowanie umarza. 
**§ 3.** (uchylony) 
**§ 4.** Jeżeli do rozstrzygnięcia o wznowieniu postępowania zakończonego 
wyrokiem właściwy jest Sąd Najwyższy, sąd ten orzeka tylko o dopuszczalności 
wznowienia, a rozpoznanie sprawy przekazuje sądowi drugiej instancji.

***
## Art. 413. {#kpc-pierwsza-pierwsza-art-413}

Sędzia, którego udziału lub zachowania się w procesie poprzednim 
dotyczy skarga, wyłączony jest od orzekania w postępowaniu ze skargi 
o wznowienie.

***
## Art. 414. {#kpc-pierwsza-pierwsza-art-414}

Wniesienie 
skargi 
o wznowienie 
nie 
tamuje 
wykonania 
zaskarżonego wyroku. W przypadku uprawdopodobnienia, że skarżącemu grozi 
niepowetowana szkoda, sąd może na wniosek strony wstrzymać wykonanie 
wyroku, chyba że strona przeciwna złoży odpowiednie zabezpieczenie.

***
## Art. 415. {#kpc-pierwsza-pierwsza-art-415}

Uchylając lub zmieniając wyrok, sąd na wniosek skarżącego 
w orzeczeniu kończącym postępowanie w sprawie orzeka o zwrocie spełnionego 
lub wyegzekwowanego świadczenia lub o przywróceniu stanu poprzedniego. Nie 
wyłącza to możliwości dochodzenia w osobnym procesie, także od Skarbu 
Państwa, naprawienia szkody poniesionej wskutek wydania lub wykonania 
wyroku.

***
## Art. 416. {#kpc-pierwsza-pierwsza-art-416}

**§ 1.** Niedopuszczalne jest dalsze wznowienie postępowania 
zakończonego 
prawomocnym 
orzeczeniem 
wydanym 
na 
skutek 
skargi 
o wznowienie. 
**§ 2.** Przepisu § 1 nie stosuje się, jeżeli skarga o wznowienie postępowania 
została oparta na podstawie wznowienia określonej w art. 4011.

***
## Art. 4161. {#kpc-pierwsza-pierwsza-art-4161}

W sprawie zakończonej prawomocnym wyrokiem mogą być 
uchylone postanowienia niekończące postępowania w sprawie, jeżeli zostały 
wydane na podstawie aktu normatywnego uznanego przez Trybunał Konstytucyjny 

 
 
 
s. 164/580 
 
2025-09-08 
 
za niezgodny z Konstytucją, ratyfikowaną umową międzynarodową lub z ustawą. 
Przepisy o wznowieniu postępowania stosuje się odpowiednio. 
#### DZIAŁ VII
(zawierający art. 417–424 – uchylony) 
#### DZIAŁ VIII
Skarga o stwierdzenie niezgodności z prawem prawomocnego orzeczenia

***
## Art. 4241. {#kpc-pierwsza-pierwsza-art-4241}

**§ 1.** Można 
żądać 
stwierdzenia 
niezgodności 
z prawem 
prawomocnego wyroku sądu drugiej instancji kończącego postępowanie 
w sprawie, jeżeli przez jego wydanie stronie została wyrządzona szkoda, a zmiana 
lub uchylenie tego wyroku w drodze innych środków prawnych przysługujących 
stronie na podstawie kodeksu nie było i nie jest możliwe. 
**§ 2.** W wyjątkowych wypadkach, gdy niezgodność z prawem wynika 
z naruszenia podstawowych zasad porządku prawnego lub konstytucyjnych 
wolności albo praw człowieka i obywatela, można także żądać stwierdzenia 
niezgodności z prawem prawomocnego wyroku sądu pierwszej lub drugiej 
instancji kończącego postępowanie w sprawie, jeżeli strona nie skorzystała 
z przysługujących jej środków prawnych, chyba że jest możliwa zmiana lub 
uchylenie wyroku w drodze innych przysługujących stronie środków prawnych.

***
## Art. 4241a. {#kpc-pierwsza-pierwsza-art-4241a}

**§ 1.** Od wyroków sądu drugiej instancji, od których wniesiono 
skargę kasacyjną, oraz od orzeczeń Sądu Najwyższego skarga nie przysługuje. 
**§ 2.** Orzeczenie Sądu Najwyższego wydane na skutek wniesienia skargi 
kasacyjnej traktuje się jak orzeczenie wydane w postępowaniu wywołanym 
wniesieniem skargi.

***
## Art. 4241b. {#kpc-pierwsza-pierwsza-art-4241b}

W wypadku prawomocnych orzeczeń, od których skarga nie 
przysługuje, odszkodowania z tytułu szkody wyrządzonej przez wydanie 
prawomocnego orzeczenia niezgodnego z prawem można domagać się bez 
uprzedniego stwierdzenia niezgodności orzeczenia z prawem w postępowaniu ze 
skargi, chyba że strona nie skorzystała z przysługujących jej środków prawnych.

***
## Art. 4242. {#kpc-pierwsza-pierwsza-art-4242}

W wypadkach określonych w art. 4241 skargę może wnieść także 
Prokurator Generalny, jeżeli niezgodność wyroku z prawem wynika z naruszenia 
podstawowych zasad porządku prawnego, Rzecznik Praw Obywatelskich – jeżeli 

 
 
 
s. 165/580 
 
2025-09-08 
 
niezgodność wyroku z prawem wynika z naruszenia konstytucyjnych wolności 
albo praw człowieka i obywatela, albo Rzecznik Praw Dziecka – jeżeli niezgodność 
wyroku z prawem wynika z naruszenia praw dziecka.

***
## Art. 4243. {#kpc-pierwsza-pierwsza-art-4243}

Od tego samego wyroku strona może wnieść tylko jedną skargę.

***
## Art. 4244. {#kpc-pierwsza-pierwsza-art-4244}

Skargę można oprzeć na podstawie naruszeń prawa materialnego 
lub przepisów postępowania, które spowodowały niezgodność wyroku z prawem, 
gdy przez jego wydanie stronie została wyrządzona szkoda. Podstawą skargi nie 
mogą być jednak zarzuty dotyczące ustalenia faktów lub oceny dowodów.

***
## Art. 4245. {#kpc-pierwsza-pierwsza-art-4245}

**§ 1.** Skarga powinna zawierać: 
- 1) oznaczenie wyroku, od którego jest wniesiona, ze wskazaniem, czy jest on 
zaskarżony w całości lub w części; 
- 2) przytoczenie jej podstaw oraz ich uzasadnienie; 
- 3) wskazanie przepisu prawa, z którym zaskarżony wyrok jest niezgodny; 
- 4) uprawdopodobnienie wyrządzenia szkody, spowodowanej przez wydanie 
wyroku, którego skarga dotyczy; 
- 5) wykazanie, że wzruszenie zaskarżonego wyroku w drodze innych środków 
prawnych przysługujących stronie na podstawie kodeksu nie było ani nie jest 
możliwe, a ponadto – gdy skargę wniesiono na podstawie art. 4241 § 2 – że 
występuje wyjątkowy przypadek uzasadniający wniesienie skargi; 
- 6) wniosek o stwierdzenie niezgodności wyroku z prawem. 
**§ 2.** Ponadto skarga powinna czynić zadość wymaganiom przewidzianym dla 
pisma procesowego. Do skargi – oprócz jej odpisów dla doręczenia ich 
uczestniczącym w sprawie osobom – dołącza się dwa odpisy przeznaczone do akt 
Sądu Najwyższego.

***
## Art. 4246. {#kpc-pierwsza-pierwsza-art-4246}

**§ 1.** Skargę wnosi się do sądu, który wydał zaskarżony wyrok, 
w terminie dwóch lat od dnia jego uprawomocnienia się. 
**§ 2.** W razie stwierdzenia niezachowania warunków formalnych określonych 
w art. 4245 § 2, przewodniczący wzywa o poprawienie lub uzupełnienie skargi. 
**§ 3.** Sąd odrzuca skargę wniesioną z naruszeniem art. 871 § 1, spóźnioną, 
nieopłaconą lub z innych przyczyn niedopuszczalną, jak również skargę, której 
braków strona nie usunęła w wyznaczonym terminie. 

 
 
 
s. 166/580 
 
2025-09-08

***
## Art. 4247. {#kpc-pierwsza-pierwsza-art-4247}

Po doręczeniu skargi stronie przeciwnej, a gdy skargę wniósł 
Prokurator Generalny, Rzecznik Praw Obywatelskich lub Rzecznik Praw Dziecka 
– obydwu stronom, sąd przedstawia niezwłocznie akta sprawy Sądowi 
Najwyższemu.

***
## Art. 4248. {#kpc-pierwsza-pierwsza-art-4248}

**§ 1.** Sąd Najwyższy odrzuca skargę, jeżeli ulegała ona odrzuceniu 
przez sąd niższej instancji, skargę niespełniającą wymagań określonych 
w art. 4245 § 1, jak również skargę z innych przyczyn niedopuszczalną. 
**§ 2.** Skarga podlega także odrzuceniu, jeżeli zmiana zaskarżonego wyroku 
w drodze innych środków prawnych przysługujących stronie na podstawie kodeksu 
była lub jest możliwa albo jeżeli nie zachodzi wyjątek, o którym mowa w art. 4241 
**§ 2.** 

***
## Art. 4249. {#kpc-pierwsza-pierwsza-art-4249}

Sąd Najwyższy odmawia przyjęcia skargi do rozpoznania, jeżeli 
jest oczywiście bezzasadna.

***
## Art. 42410. {#kpc-pierwsza-pierwsza-art-42410}

Sąd Najwyższy rozpoznaje skargę w granicach zaskarżenia oraz 
w granicach podstaw. Skarga podlega rozpoznaniu na posiedzeniu niejawnym, 
chyba że ważne względy przemawiają za wyznaczeniem rozprawy.

***
## Art. 42411. {#kpc-pierwsza-pierwsza-art-42411}

**§ 1.** Sąd Najwyższy oddala skargę w razie braku podstawy do 
stwierdzenia, że zaskarżony wyrok jest niezgodny z prawem. 
**§ 2.** Uwzględniając skargę, Sąd Najwyższy stwierdza, że wyrok jest 
w zaskarżonym zakresie niezgodny z prawem. 
**§ 3.** Jeżeli w chwili orzekania sprawa ze względu na osobę nie podlegała 
orzecznictwu sądów polskich albo w sprawie droga sądowa była niedopuszczalna, 
Sąd Najwyższy – stwierdzając niezgodność wyroku z prawem – uchyla zaskarżony 
wyrok oraz wyrok sądu pierwszej instancji i odrzuca pozew albo umarza 
postępowanie.

***
## Art. 42412. {#kpc-pierwsza-pierwsza-art-42412}

W wypadkach nieuregulowanych przepisami niniejszego działu 
do postępowania wywołanego wniesieniem skargi stosuje się odpowiednio 
przepisy o skardze kasacyjnej. 

 
 
 
s. 167/580 
 
2025-09-08 
### TYTUŁ VII
Postępowania odrębne 
#### DZIAŁ I
Postępowanie w sprawach małżeńskich 
Rozdział 1 
Przepisy ogólne

***
## Art. 425. {#kpc-pierwsza-pierwsza-art-425}

Przepisy 
niniejszego 
rozdziału 
stosuje 
się 
w sprawach 
o unieważnienie małżeństwa, o ustalenie istnienia lub nieistnienia małżeństwa 
i o rozwód oraz o separację na żądanie jednego z małżonków.

***
## Art. 426. {#kpc-pierwsza-pierwsza-art-426}

Do reprezentowania strony konieczne jest pełnomocnictwo 
udzielone do prowadzenia danej sprawy.

***
## Art. 427. {#kpc-pierwsza-pierwsza-art-427}

Posiedzenia odbywają się przy drzwiach zamkniętych, chyba że 
obie strony żądają publicznego rozpoznania sprawy, a sąd uzna, że jawność nie 
zagraża moralności. Odbycie posiedzenia przy drzwiach zamkniętych nie stoi na 
przeszkodzie przeprowadzeniu dowodu na odległość w ramach posiedzenia 
zdalnego, jeżeli w istotny sposób przyspieszy to rozpoznanie sprawy lub przyczyni 
się znacznie do zaoszczędzenia kosztów.

***
## Art. 428. {#kpc-pierwsza-pierwsza-art-428}

**§ 1.** Rozprawa odbywa się bez względu na niestawiennictwo jednej 
ze stron. Jednakże w razie nieusprawiedliwionego niestawiennictwa powoda na 
pierwsze posiedzenie sądowe wyznaczone w celu przeprowadzenia rozprawy, 
postępowanie ulega zawieszeniu, chyba że prokurator popiera żądanie 
unieważnienia albo ustalenia istnienia lub nieistnienia małżeństwa. 
**§ 2.** Podjęcie postępowania następuje na wniosek powoda, nie wcześniej 
jednak niż po upływie trzech miesięcy od dnia zawieszenia postępowania. W razie 
niezgłoszenia takiego wniosku w ciągu roku po zawieszeniu, sąd umorzy 
postępowanie. Umorzenie wywołuje takie same skutki, jak umorzenie 
postępowania zawieszonego na zgodny wniosek stron lub z powodu ich 
niestawiennictwa.

***
## Art. 429. {#kpc-pierwsza-pierwsza-art-429}

Jeżeli strona wezwana do osobistego stawiennictwa nie stawi się 
bez usprawiedliwionych powodów na posiedzenie, sąd może skazać ją na grzywnę 

 
 
 
s. 168/580 
 
2025-09-08 
 
według przepisów o karach za niestawiennictwo świadka, nie może jednak nakazać 
przymusowego sprowadzenia jej do sądu.

***
## Art. 430. {#kpc-pierwsza-pierwsza-art-430}

Małoletni, którzy nie ukończyli lat trzynastu, a zstępni stron, którzy 
nie ukończyli lat siedemnastu, nie mogą być przesłuchiwani w charakterze 
świadków.

***
## Art. 431. {#kpc-pierwsza-pierwsza-art-431}

W 
sprawach 
przewidzianych 
w niniejszym 
rozdziale 
rozstrzygnięcia nie można oprzeć wyłącznie na uznaniu powództwa lub przyznaniu 
faktów. W sprawach tych nie stosuje się art. 339 § 2.

***
## Art. 432. {#kpc-pierwsza-pierwsza-art-432}

W każdej sprawie o rozwód lub o separację sąd zarządza 
przeprowadzenie dowodu z przesłuchania stron. W innych sprawach sąd nie może 
odmówić dopuszczenia takiego dowodu, jeżeli strona go powołała. Art. 
302 § 1 stosuje się odpowiednio.

***
## Art. 433. {#kpc-pierwsza-pierwsza-art-433}

Protokół rozprawy powinien zawierać oświadczenie małżonków co 
do liczby, wieku i płci dzieci żyjących, stosunków majątkowych i zarobkowych 
obu małżonków, szczególnych obowiązków utrzymania osób niebędących ich 
wspólnymi dziećmi oraz co do treści umowy majątkowej, jeżeli małżonkowie 
umowę taką zawarli.

***
## Art. 434. {#kpc-pierwsza-pierwsza-art-434}

Sąd może zarządzić przeprowadzenie przez wyznaczoną osobę 
wywiadu środowiskowego w celu ustalenia warunków, w których żyją 
i wychowują się dzieci stron.

***
## Art. 4341. {#kpc-pierwsza-pierwsza-art-4341}

(uchylony)

***
## Art. 435. {#kpc-pierwsza-pierwsza-art-435}

**§ 1.** Wyrok prawomocny ma skutek wobec osób trzecich. 
**§ 2.** Nie dotyczy to części orzekającej o prawach i roszczeniach majątkowych 
poszukiwanych łącznie z prawami niemajątkowymi. 
Rozdział 2 
Sprawy o rozwód i o separację

***
## Art. 436. {#kpc-pierwsza-pierwsza-art-436}

**§ 1.** Jeżeli istnieją widoki na utrzymanie małżeństwa, sąd może 
skierować strony do mediacji. Skierowanie to jest możliwe także wtedy, gdy 
postępowanie zostało zawieszone. 

 
 
 
s. 169/580 
 
2025-09-08 
**§ 2.** Przepisy o mediacji stosuje się odpowiednio, z tym że przedmiotem 
mediacji może być także pojednanie małżonków. 
**§ 3.** (uchylony) 
**§ 4.** Jeżeli strony nie uzgodniły osoby mediatora, sąd kieruje je do stałego 
mediatora posiadającego wiedzę teoretyczną, w szczególności posiadającego 
wykształcenie z zakresu psychologii, pedagogiki, socjologii lub prawa oraz 
umiejętności praktyczne w zakresie prowadzenia mediacji w sprawach rodzinnych.

***
## Art. 437. {#kpc-pierwsza-pierwsza-art-437}

(uchylony)

***
## Art. 438. {#kpc-pierwsza-pierwsza-art-438}

(uchylony)

***
## Art. 439. {#kpc-pierwsza-pierwsza-art-439}

**§ 1.** Powództwo wzajemne o rozwód lub o separację jest 
niedopuszczalne. 
**§ 2.** W czasie trwania procesu o rozwód lub o separację nie może być 
wszczęta odrębna sprawa o rozwód albo o separację. 
**§ 3.** Strona pozwana w sprawie o rozwód może jednak również żądać 
rozwodu albo separacji. Strona pozwana w sprawie o separację może również 
żądać separacji albo rozwodu.

***
## Art. 440. {#kpc-pierwsza-pierwsza-art-440}

**§ 1.** Jeżeli sąd nabierze przekonania, że istnieją widoki na 
utrzymanie pożycia małżeńskiego, zawiesza postępowanie. Zawieszenie takie 
może nastąpić tylko raz w toku postępowania. 
**§ 2.** Podjęcie postępowania następuje na wniosek jednej ze stron; poza tym 
stosuje się odpowiednio art. 428 § 2.

***
## Art. 441. {#kpc-pierwsza-pierwsza-art-441}

Postępowanie dowodowe ma przede wszystkim na celu ustalenie 
okoliczności dotyczących rozkładu pożycia, jak również okoliczności dotyczących 
dzieci stron i ich sytuacji, a w razie uznania powództwa – także przyczyn, które 
skłoniły do tego stronę pozwaną.

***
## Art. 442. {#kpc-pierwsza-pierwsza-art-442}

Jeżeli pozwany uznaje żądanie pozwu a małżonkowie nie mają 
wspólnych małoletnich dzieci, sąd może ograniczyć postępowanie dowodowe do 
przesłuchania stron.

***
## Art. 443. {#kpc-pierwsza-pierwsza-art-443}

(uchylony)

***
## Art. 444. {#kpc-pierwsza-pierwsza-art-444}

Małżonek może dochodzić roszczeń alimentacyjnych od drugiego 
małżonka na wypadek orzeczenia rozwodu, jak również na wypadek orzeczenia 

 
 
 
s. 170/580 
 
2025-09-08 
 
separacji. Dochodzenie następuje przez zgłoszenie wniosku na rozprawie 
w obecności drugiego małżonka albo w piśmie, które należy doręczyć drugiemu 
małżonkowi.

***
## Art. 445. {#kpc-pierwsza-pierwsza-art-445}

**§ 1.** W czasie trwania procesu o rozwód lub o separację nie może 
być wszczęta odrębna sprawa o zaspokojenie potrzeb rodziny i o alimenty 
pomiędzy małżonkami albo pomiędzy nimi a ich wspólnymi małoletnimi dziećmi 
co do świadczeń za okres od wytoczenia powództwa o rozwód lub o separację. 
Pozew lub wniosek o zabezpieczenie w takiej sprawie sąd przekaże sądowi, 
w którym toczy się sprawa o rozwód lub o separację, w celu rozstrzygnięcia 
według przepisów o postępowaniu zabezpieczającym. 
**§ 2.** Postępowanie w sprawie o zaspokojenie potrzeb rodziny lub o alimenty, 
wszczęte przed wytoczeniem powództwa o rozwód lub o separację, ulega z urzędu 
zawieszeniu z chwilą wytoczenia powództwa o rozwód lub o separację co do 
świadczeń za okres od jego wytoczenia. Z chwilą wydania w sprawie o rozwód lub 
o separację postanowienia o udzieleniu zabezpieczenia wykonania obowiązku 
zaspokajania potrzeb rodziny lub o alimenty wstrzymuje się także z mocy prawa 
wykonanie nieprawomocnych orzeczeń o obowiązku tych świadczeń, wydanych 
w poprzednio wszczętej sprawie, za okres od wytoczenia powództwa o rozwód lub 
o separację. 
**§ 3.** Po prawomocnym zakończeniu sprawy o rozwód lub o separację 
zawieszone postępowanie podejmuje się z mocy prawa, orzeczenia zaś, których 
wykonanie było wstrzymane, podlegają wykonaniu, jednak tylko co do okresu, 
za który w sprawie o rozwód lub o separację nie orzeczono o roszczeniach objętych 
zawieszonym postępowaniem. W pozostałym zakresie postępowanie ulega z mocy 
prawa umorzeniu.

***
## Art. 4451. {#kpc-pierwsza-pierwsza-art-4451}

**§ 1.** Jeżeli sprawa o rozwód lub o separację jest w toku, nie może 
być wszczęte odrębne postępowanie dotyczące władzy rodzicielskiej nad 
wspólnymi małoletnimi dziećmi stron lub o ustalenie kontaktów z nimi. W razie 
potrzeby orzeczenia o władzy rodzicielskiej lub o kontaktach stosuje się przepisy 
o postępowaniu zabezpieczającym. 
**§ 2.** Postępowanie w sprawie dotyczącej władzy rodzicielskiej lub kontaktów 
wszczęte przed wytoczeniem powództwa o rozwód lub o separację ulega z urzędu 

 
 
 
s. 171/580 
 
2025-09-08 
 
zawieszeniu, a o władzy rodzicielskiej lub kontaktach przez cały czas trwania 
sprawy o rozwód lub o separację sąd orzeka w postępowaniu zabezpieczającym. 
Sąd postanowi podjąć postępowanie dotyczące władzy rodzicielskiej lub 
kontaktów, jeżeli w prawomocnym orzeczeniu kończącym postępowanie 
w sprawie o rozwód lub o separację nie orzeczono o władzy rodzicielskiej lub 
kontaktach. W przeciwnym wypadku postępowanie ulega umorzeniu.

***
## Art. 4452. {#kpc-pierwsza-pierwsza-art-4452}

W każdym stanie sprawy o rozwód lub separację sąd może 
skierować strony do mediacji w celu ugodowego załatwienia spornych kwestii 
dotyczących zaspokojenia potrzeb rodziny, alimentów, sposobu sprawowania 
władzy 
rodzicielskiej, 
kontaktów 
z dziećmi 
oraz 
spraw 
majątkowych 
podlegających rozstrzygnięciu w wyroku orzekającym rozwód lub separację. 
Przepis art. 436 § 4 stosuje się odpowiednio.

***
## Art. 4453. {#kpc-pierwsza-pierwsza-art-4453}

Na wniosek strony stosuje się przepisy art. 5821 § 2 lub 3.

***
## Art. 446. {#kpc-pierwsza-pierwsza-art-446}

W razie śmierci jednego z małżonków postępowanie umarza się.

***
## Art. 4461. {#kpc-pierwsza-pierwsza-art-4461}

Sąd drugiej instancji rozpoznaje sprawę w składzie jednego 
sędziego. 
Rozdział 3 
Inne sprawy

***
## Art. 447. {#kpc-pierwsza-pierwsza-art-447}

**§ 1.** Na wniosek osoby, która po śmierci jednego z małżonków 
zamierza wytoczyć powództwo o unieważnienie małżeństwa, sąd rejonowy miejsca 
zamieszkania zmarłego ustanawia kuratora. Jeżeli zmarli obydwoje małżonkowie, 
ustanawia się dwóch kuratorów. 
**§ 2.** Przepis paragrafu poprzedzającego stosuje się odpowiednio do 
powództwa o ustalenie istnienia lub nieistnienia małżeństwa.

***
## Art. 448. {#kpc-pierwsza-pierwsza-art-448}

**§ 1.** Jeżeli powództwo o unieważnienie małżeństwa wytacza 
prokurator, pozywa on oboje małżonków, a w wypadku śmierci jednego z nich – 
kuratora ustanowionego na miejsce zmarłego małżonka. 
**§ 2.** Przepis paragrafu poprzedzającego stosuje się odpowiednio do 
powództwa prokuratora o ustalenie istnienia lub nieistnienia małżeństwa. 

 
 
 
s. 172/580 
 
2025-09-08

***
## Art. 449. {#kpc-pierwsza-pierwsza-art-449}

**§ 1.** W sprawach o unieważnienie albo o ustalenie istnienia lub 
nieistnienia małżeństwa odpis pozwu doręcza się prokuratorowi i zawiadamia się 
go o terminach rozprawy. 
**§ 2.** Jeżeli sprawa taka została wytoczona lub jest popierana przez 
prokuratora, nie stosuje się przepisów o zawieszeniu postępowania na zgodny 
wniosek stron lub z powodu niestawiennictwa obu stron.

***
## Art. 450. {#kpc-pierwsza-pierwsza-art-450}

**§ 1.** Postępowanie o unieważnienie małżeństwa w razie śmierci 
jednego z małżonków zawiesza się. 
**§ 2.** Postępowanie umarza się, jeżeli zstępni małżonka, który wytoczył 
powództwo, nie zgłoszą w ciągu sześciu miesięcy po wydaniu postanowienia 
o zawieszeniu wniosku o podjęcie postępowania. 
**§ 3.** W przypadku śmierci pozwanego małżonka, a jeżeli pozwanymi byli 
oboje małżonkowie – w przypadku śmierci jednego z nich, sąd orzekający ustanowi 
kuratora, który wstępuje w miejsce zmarłego małżonka, po czym podejmie 
zawieszone postępowanie.

***
## Art. 451. {#kpc-pierwsza-pierwsza-art-451}

**§ 1.** Przepisy art. 444, art. 445, art. 4451 i art. 4461 stosuje się 
odpowiednio w sprawach o unieważnienie małżeństwa. 
**§ 2.** Przepis art. 4461 stosuje się w sprawach o ustalenie istnienia lub 
nieistnienia małżeństwa.

***
## Art. 452. {#kpc-pierwsza-pierwsza-art-452}

W sprawach o ustanowienie rozdzielności majątkowej między 
małżonkami stosuje się odpowiednio przepisy art. 426, 431, 432, 435 § 1, 441 
i 446. 
#### DZIAŁ II
Postępowanie w sprawach ze stosunków między rodzicami a dziećmi

***
## Art. 453. {#kpc-pierwsza-pierwsza-art-453}

Przepisy niniejszego działu stosuje się w sprawach o ustalenie lub 
zaprzeczenie pochodzenia dziecka, o ustalenie bezskuteczności uznania ojcostwa 
oraz o rozwiązanie przysposobienia.

***
## Art. 4531. {#kpc-pierwsza-pierwsza-art-4531}

W sprawach o ustalenie lub zaprzeczenie pochodzenia dziecka 
oraz o ustalenie bezskuteczności uznania ojcostwa matka i ojciec dziecka mają 
zdolność procesową także wtedy, gdy są ograniczeni w zdolności do czynności 
prawnych, jeżeli ukończyli lat szesnaście. 

 
 
 
s. 173/580 
 
2025-09-08

***
## Art. 454. {#kpc-pierwsza-pierwsza-art-454}

**§ 1.** W sprawach o ustalenie macierzyństwa albo ojcostwa 
prokurator wytaczając powództwo wskazuje w pozwie dziecko, na którego rzecz 
wytacza 
powództwo, 
oraz 
pozywa 
odpowiednio 
matkę 
dziecka 
albo 
domniemanego ojca, a jeżeli osoby te nie żyją – kuratora ustanowionego na ich 
miejsce. 
**§ 11.** W sprawach o zaprzeczenie macierzyństwa prokurator, wytaczając 
powództwo, pozywa kobietę wpisaną jako matka w akcie urodzenia dziecka, 
mężczyznę, 
którego 
ojcostwo 
zostało 
ustalone 
z uwzględnieniem 
jej 
macierzyństwa, oraz dziecko, a jeżeli osoby te nie żyją – kuratora ustanowionego 
na ich miejsce. 
**§ 2.** W sprawach 
o zaprzeczenie 
ojcostwa 
prokurator, 
wytaczając 
powództwo, pozywa męża matki dziecka, a jeżeli ten nie żyje – kuratora 
ustanowionego na jego miejsce, matkę dziecka, jeżeli ta żyje, oraz dziecko, a jeżeli 
dziecko nie żyje – kuratora ustanowionego na jego miejsce. 
**§ 3.** W sprawach o ustalenie bezskuteczności uznania ojcostwa prokurator, 
wytaczając powództwo, pozywa dziecko, a jeżeli dziecko nie żyje – kuratora 
ustanowionego na jego miejsce oraz mężczyznę, który uznał ojcostwo, a jeżeli ten 
nie żyje – kuratora ustanowionego na jego miejsce, a także matkę dziecka, jeżeli ta 
żyje. 
**§ 4.** W sprawach o rozwiązanie przysposobienia prokurator wytaczając 
powództwo pozywa przysposabiającego oraz przysposobionego.

***
## Art. 4541. {#kpc-pierwsza-pierwsza-art-4541}

**§ 1.** Powództwo 
wzajemne 
o ustalenie 
lub 
zaprzeczenie 
macierzyństwa, o ustalenie lub zaprzeczenie ojcostwa, a także o ustalenie 
bezskuteczności uznania ojcostwa nie jest dopuszczalne. 
**§ 2.** W czasie trwania procesu o ustalenie lub zaprzeczenie macierzyństwa, 
o ustalenie lub zaprzeczenie ojcostwa albo o ustalenie bezskuteczności uznania 
ojcostwa nie może być wszczęta odrębna sprawa o ustalenie lub zaprzeczenie 
macierzyństwa, 
o ustalenie 
lub 
zaprzeczenie 
ojcostwa 
albo 
o ustalenie 
bezskuteczności uznania ojcostwa. 
**§ 3.** Strona pozwana może jednak również żądać ustalenia lub zaprzeczenia 
macierzyństwa, ustalenia lub zaprzeczenia ojcostwa albo ustalenia bezskuteczności 
uznania ojcostwa. 

 
 
 
s. 174/580 
 
2025-09-08

***
## Art. 455. {#kpc-pierwsza-pierwsza-art-455}

Rozprawa odbywa się bez względu na niestawiennictwo jednej ze 
stron.

***
## Art. 456. {#kpc-pierwsza-pierwsza-art-456}

**§ 1.** Postępowanie umarza się w razie śmierci jednej ze stron, 
a jeżeli w charakterze tej samej strony występuje kilka osób, w razie śmierci 
wszystkich tych osób, z zastrzeżeniem § 2 i 3. 
**§ 2.** W sprawie wytoczonej przez dziecko o ustalenie albo zaprzeczenie 
macierzyństwa, o zaprzeczenie ojcostwa albo ustalenie bezskuteczności uznania, 
jak również w sprawie wytoczonej przez dziecko albo jego matkę o ustalenie 
ojcostwa, postępowanie zawiesza się w razie śmierci pozwanych do czasu 
ustanowienia przez sąd orzekający kuratora, który wstępuje do sprawy na miejsce 
zmarłego. Przepis ten stosuje się w sprawie o rozwiązanie przysposobienia w razie 
śmierci przysposabiającego. 
**§ 3.** W sprawie o ustalenie lub zaprzeczenie macierzyństwa, ustalenie lub 
zaprzeczenie ojcostwa oraz ustalenie bezskuteczności uznania ojcostwa 
postępowanie zawiesza się w razie śmierci dziecka, które było pozwanym 
w sprawie, do czasu ustanowienia przez sąd orzekający kuratora, który wstępuje do 
sprawy na miejsce zmarłego dziecka. W razie śmierci dziecka, które było powodem 
w sprawie, postępowanie zawiesza się, a jeżeli zstępni dziecka w ciągu sześciu 
miesięcy od dnia wydania postanowienia o zawieszeniu postępowania nie zgłoszą 
wniosku o jego podjęcie, sąd postępowanie umorzy.

***
## Art. 4561. {#kpc-pierwsza-pierwsza-art-4561}

**§ 1.** W sprawach o ustalenie macierzyństwa przewodniczący 
zawiadamia o toczącym się procesie mężczyznę, którego dotyczy domniemanie 
pochodzenia dziecka od męża matki, doręczając mu odpis pozwu. 
**§ 2.** W sprawach o zaprzeczenie macierzyństwa przewodniczący zawiadamia 
o toczącym się procesie mężczyznę, którego ojcostwa dotyczy wynik 
postępowania, doręczając mu odpis pozwu.

***
## Art. 457. {#kpc-pierwsza-pierwsza-art-457}

W sprawach o zaprzeczenie pochodzenia dziecka lub o ustalenie 
bezskuteczności uznania ojcostwa, albo o rozwiązanie przysposobienia odpis 
pozwu doręcza się prokuratorowi i zawiadamia się go o terminach rozprawy.

***
## Art. 458. {#kpc-pierwsza-pierwsza-art-458}

**§ 1.** W sprawach objętych przepisami działu niniejszego stosuje się 
odpowiednio przepisy art. 426, 429, 431, 434 i 435. 

 
 
 
s. 175/580 
 
2025-09-08 
**§ 2.** Jeżeli jednocześnie z ustaleniem ojcostwa dochodzi się związanych z tym 
roszczeń majątkowych, do części postępowania dotyczących tych roszczeń nie 
stosuje się przepisów art. 429 i 456. W razie śmierci pozwanego postępowanie 
w części dotyczącej roszczeń majątkowych zawiesza się do czasu prawomocnego 
rozstrzygnięcia sprawy o ustalenie ojcostwa, po czym może ono być podjęte 
z udziałem następców prawnych zmarłego lub kuratora spadku. 
DZIAŁ IIA 
Postępowanie w sprawach gospodarczych

***
## Art. 4581. {#kpc-pierwsza-pierwsza-art-4581}

**§ 1.** Przepisy niniejszego działu stosuje się w sprawach 
gospodarczych podlegających rozpoznaniu w procesie. Nie dotyczy to spraw, 
o których mowa w art. 4582 § 1 pkt 5 i 6, jeżeli jedną ze stron jest konsument, z tym 
że sprawy te podlegają rozpoznaniu przez sąd gospodarczy. 
**§ 2.** W sprawach 
gospodarczych 
rozpoznawanych 
według 
przepisów 
niniejszego działu przepisy o innych postępowaniach odrębnych stosuje się 
w zakresie, w którym nie są sprzeczne z przepisami niniejszego działu. Nie dotyczy 
to 
spraw 
gospodarczych 
rozpoznawanych 
w europejskim 
postępowaniu 
nakazowym, europejskim postępowaniu w sprawie drobnych roszczeń oraz 
elektronicznym postępowaniu upominawczym.

***
## Art. 4582. {#kpc-pierwsza-pierwsza-art-4582}

**§ 1.** Sprawami gospodarczymi są sprawy: 
- 1) ze stosunków cywilnych między przedsiębiorcami w zakresie prowadzonej 
przez nich działalności gospodarczej; 
- 2) określone w pkt 1, choćby którakolwiek ze stron zaprzestała prowadzenia 
działalności gospodarczej; 
- 3) ze stosunku spółki oraz dotyczące roszczeń, o których mowa w art. 2112–2114, 
art. 291–300, art. 300123–300134 i art. 479–490 ustawy z dnia 15 września 
2000 r. – Kodeks spółek handlowych (Dz. U. z 2024 r. poz. 18 i 96); 
- 4) przeciwko 
przedsiębiorcom 
o zaniechanie 
naruszania 
środowiska 
i przywrócenie do stanu poprzedniego lub o naprawienie szkody z tym 
związanej oraz o zakazanie albo ograniczenie działalności zagrażającej 
środowisku; 
- 5) z umów o roboty budowlane oraz ze ściśle związanych z procesem 
budowlanym umów służących wykonaniu robót budowlanych; 

 
 
 
s. 176/580 
 
2025-09-08 
- 6) z umów leasingu; 
- 7) przeciwko osobom odpowiadającym za dług przedsiębiorcy, także posiłkowo 
lub solidarnie, z mocy prawa lub czynności prawnej; 
- 8) między organami przedsiębiorstwa państwowego; 
- 9) między przedsiębiorstwem państwowym lub jego organami a jego organem 
założycielskim lub organem sprawującym nadzór; 
- 10) z zakresu prawa upadłościowego i restrukturyzacyjnego; 
- 11) o nadanie klauzuli wykonalności tytułowi egzekucyjnemu, którym jest 
orzeczenie 
sądu 
gospodarczego 
prawomocne 
lub 
podlegające 
natychmiastowemu wykonaniu albo ugoda zawarta przed tym sądem; 
- 12) o 
pozbawienie 
wykonalności 
tytułu 
wykonawczego 
opartego 
na 
prawomocnym lub podlegającym natychmiastowemu wykonaniu orzeczeniu 
sądu gospodarczego albo ugodzie zawartej przed tym sądem. 
**§ 2.** Nie są sprawami gospodarczymi sprawy o: 
- 1) podział majątku wspólnego wspólników spółki cywilnej po jej ustaniu; 
- 2) wierzytelność nabytą od osoby niebędącej przedsiębiorcą, chyba że 
wierzytelność ta powstała ze stosunku prawnego w zakresie działalności 
gospodarczej prowadzonej przez wszystkie jego strony.

***
## Art. 4583. {#kpc-pierwsza-pierwsza-art-4583}

(uchylony) 
<Art. 4583a. § 1. W sprawach, o których mowa w art. 4582 § 1 pkt 5, sąd 
przed posiedzeniem przygotowawczym albo pierwszym posiedzeniem 
wyznaczonym na rozprawę kieruje strony do mediacji. 
**§ 2.** Przepisu § 1 nie stosuje się do spraw podlegających rozpoznaniu 
w postępowaniu 
upominawczym, 
elektronicznym 
postępowaniu 
upominawczym albo postępowaniu nakazowym. W przypadku gdy po 
wydaniu nakazu zapłaty wniesiono sprzeciw w postępowaniu upominawczym 
albo zarzuty w postępowaniu nakazowym, sąd przed posiedzeniem 
przygotowawczym albo pierwszym posiedzeniem wyznaczonym na rozprawę 
kieruje strony do mediacji. 
**§ 3.** Po skierowaniu stron do mediacji sąd podejmuje czynności służące 
do przygotowania posiedzenia przygotowawczego albo rozprawy.> 
Dodany art. 4583a 
wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 

 
 
 
s. 177/580 
 
2025-09-08

***
## Art. 4584. {#kpc-pierwsza-pierwsza-art-4584}

**§ 1.** Stronę niezastępowaną przez adwokata, radcę prawnego, 
rzecznika patentowego lub Prokuratorię Generalną Rzeczypospolitej Polskiej sąd 
poucza o treści art. 4585 § 1 i 4, art. 4586, art. 45810 oraz art. 45811. 
**§ 2.** Pouczeń, o których mowa w § 1, udziela się powodowi niezwłocznie po 
wniesieniu pozwu, a pozwanemu – równocześnie z doręczeniem odpisu pozwu. 
Jeżeli zachodzą przesłanki wydania nakazu zapłaty, pouczeń udziela się równo-
cześnie z doręczeniem nakazu zapłaty. 
**§ 3.** (uchylony) 
**§ 4.** (uchylony)

***
## Art. 4585. {#kpc-pierwsza-pierwsza-art-4585}

**§ 1.** Powód jest obowiązany powołać wszystkie twierdzenia 
i dowody w pozwie, a pozwany – w odpowiedzi na pozew. 
**§ 2.** Doręczając pouczenia, o których mowa w art. 4584 § 1, przewodniczący 
wzywa stronę, by w wyznaczonym terminie, nie krótszym niż tydzień, powołała 
wszystkie twierdzenia i dowody. 
**§ 3.** Stosownie do okoliczności sprawy przewodniczący może określić inny 
termin do powołania przez stronę twierdzeń i dowodów. 
**§ 4.** Twierdzenia 
i dowody 
powołane 
z naruszeniem 
§ 1–3 podlegają 
pominięciu, chyba że strona uprawdopodobni, że ich powołanie nie było możliwe 
albo że potrzeba ich powołania wynikła później. W takim przypadku dalsze 
twierdzenia i dowody na ich poparcie powinny być powołane w terminie dwóch 
tygodni od dnia, w którym ich powołanie stało się możliwe lub wynikła potrzeba 
ich powołania.

***
## Art. 4586. {#kpc-pierwsza-pierwsza-art-4586}

**§ 1.** Na wniosek strony, która nie jest przedsiębiorcą lub jest 
przedsiębiorcą będącym osobą fizyczną, sąd rozpoznaje sprawę z pominięciem 
przepisów niniejszego działu. 
**§ 2.** Wniosek, o którym mowa w § 1, strona może złożyć w terminie tygodnia 
od dnia doręczenia jej na piśmie pouczeń, o których mowa w art. 4584 § 1, a jeżeli 
doręczenie pouczeń nie było wymagane – w pozwie albo pierwszym piśmie 
procesowym pozwanego.

***
## Art. 4587. {#kpc-pierwsza-pierwsza-art-4587}

**§ 1.** Sąd gospodarczy, który stwierdzi, że sprawa nie jest sprawą 
gospodarczą, może z tego powodu przekazać ją sądowi właściwemu w terminie 
miesiąca od dnia wdania się w spór co do istoty sprawy przez pozwanego. 

 
 
 
s. 178/580 
 
2025-09-08 
**§ 2.** Przekazanie sprawy gospodarczej może nastąpić w terminie miesiąca od 
dnia wdania się w spór co do istoty sprawy przez pozwanego. Sprawę gospodarczą, 
której nie przekazano sądowi gospodarczemu ze względu na upływ tego terminu, 
rozpoznaje się z pominięciem przepisów niniejszego działu.

***
## Art. 4588. {#kpc-pierwsza-pierwsza-art-4588}

**§ 1.** W toku postępowania nie można występować z nowymi 
roszczeniami zamiast lub obok dotychczasowych. Jednakże w przypadku zmiany 
okoliczności powód może żądać, zamiast pierwotnego przedmiotu sporu, jego 
równowartości lub innego przedmiotu, a w sprawach o świadczenie powtarzające 
się może nadto rozszerzyć powództwo o świadczenia za kolejne okresy. 
**§ 2.** Przepisów art. 177 § 1 pkt 5, art. 194–196, art. 198 oraz art. 205 nie 
stosuje się. 
**§ 3.** Powództwo wzajemne jest niedopuszczalne. 
**§ 4.** Przewodniczący i sąd są obowiązani podejmować czynności tak, by 
rozstrzygnięcie w sprawie zapadło nie później niż sześć miesięcy od dnia złożenia 
odpowiedzi na pozew. Jeżeli odpowiedź ta była dotknięta brakami, termin ten 
biegnie od dnia usunięcia tych braków, a jeżeli jej nie złożono – od dnia upływu 
terminu do jej złożenia.

***
## Art. 4589. {#kpc-pierwsza-pierwsza-art-4589}

**§ 1.** Strony mogą się umówić o wyłączenie określonych dowodów 
w postępowaniu w sprawie z określonego stosunku prawnego powstałego na 
podstawie umowy (umowa dowodowa). 
**§ 2.** Umowę dowodową zawiera się na piśmie pod rygorem nieważności albo 
ustnie przed sądem. W przypadku wątpliwości uważa się, że umowa późniejsza 
utrzymuje w mocy te postanowienia umowy wcześniejszej, które da się z nią 
pogodzić. 
**§ 3.** Umowa dowodowa zawarta pod warunkiem lub z zastrzeżeniem terminu 
jest nieważna. 
**§ 4.** Zarzut nieważności lub bezskuteczności umowy dowodowej można 
podnieść najpóźniej na posiedzeniu, na którym powołano się na tę umowę, a jeśli 
uczyniono to w piśmie procesowym – najpóźniej w następnym piśmie procesowym 
albo na najbliższym posiedzeniu. 
**§ 5.** Objęcie umową dowodową dowodu przeprowadzonego przed sądem 
przed jej zawarciem nie pozbawia go mocy dowodowej. 

 
 
 
s. 179/580 
 
2025-09-08 
**§ 6.** Sąd nie dopuści z urzędu dowodu wyłączonego umową dowodową. 
**§ 7.** Fakty, które miałyby zostać wykazane dowodami wyłączonymi przez 
umowę dowodową, sąd może ustalić na podstawie twierdzeń stron, biorąc pod 
rozwagę całokształt okoliczności sprawy. Jeżeli ustalenia wymaga rozmiar należ-
nego świadczenia, przepis art. 322 stosuje się odpowiednio.

***
## Art. 45810. {#kpc-pierwsza-pierwsza-art-45810}

Dowód z zeznań świadków sąd może dopuścić jedynie wtedy, gdy 
po wyczerpaniu innych środków dowodowych lub w ich braku pozostały 
niewyjaśnione fakty istotne dla rozstrzygnięcia sprawy.

***
## Art. 45811. {#kpc-pierwsza-pierwsza-art-45811}

Czynność strony, w szczególności oświadczenie woli lub wiedzy, 
z którą prawo łączy nabycie, utratę lub zmianę uprawnienia strony w zakresie 
danego stosunku prawnego, może być wykazana tylko dokumentem, o którym 
mowa w art. 773 Kodeksu cywilnego, chyba że strona wykaże, że nie może 
przedstawić dokumentu z przyczyn od niej niezależnych.

***
## Art. 45812. {#kpc-pierwsza-pierwsza-art-45812}

Niezależnie od wyniku sprawy sąd może obciążyć kosztami 
procesu w całości lub części stronę, która przed wytoczeniem powództwa 
zaniechała próby dobrowolnego rozwiązania sporu, uchyliła się od udziału w niej 
lub uczestniczyła w niej w złej wierze i przez to przyczyniła się do zbędnego 
wytoczenia powództwa lub wadliwego określenia przedmiotu sprawy.

***
## Art. 45813. {#kpc-pierwsza-pierwsza-art-45813}

Do wyroku sądu pierwszej instancji zasądzającego świadczenie 
w pieniądzu lub rzeczach zamiennych przepisy art. 492 § 1 i 2 stosuje się 
odpowiednio. 
Dział IIb 
Postępowanie z udziałem konsumentów

***
## Art. 45814. {#kpc-pierwsza-pierwsza-art-45814}

**§ 1.** Przepisy niniejszego działu stosuje się w sprawach 
o roszczenia 
konsumenta 
przeciwko 
przedsiębiorcy 
oraz 
o roszczenia 
przedsiębiorcy przeciwko konsumentowi, o ile konsument ten jest stroną 
postępowania. 
**§ 2.** W sprawach rozpoznawanych według przepisów niniejszego działu 
przepisy o innych postępowaniach odrębnych stosuje się w zakresie, w którym nie 
są sprzeczne z przepisami niniejszego działu. 

 
 
 
s. 180/580 
 
2025-09-08 
**§ 3.** Przepisy niniejszego działu stosuje się, choćby przedsiębiorca będący 
stroną postępowania zaprzestał prowadzenia działalności gospodarczej. 
**§ 4.** W sprawach rozpoznawanych według przepisów niniejszego działu 
konsument może wytoczyć powództwo również przed sąd właściwy dla miejsca 
swojego zamieszkania. Nie dotyczy to spraw, w których właściwość sądu jest 
wyłączna.

***
## Art. 45815. {#kpc-pierwsza-pierwsza-art-45815}

**§ 1.** Przedsiębiorca będący powodem jest obowiązany powołać 
wszystkie twierdzenia i dowody w pozwie, a będący pozwanym – w odpowiedzi na 
pozew. 
**§ 2.** Stronie będącej przedsiębiorcą udziela się pouczenia o treści § 1 i 4, jeżeli 
strona nie jest zastępowana przez adwokata, radcę prawnego, rzecznika 
patentowego lub Prokuratorię Generalną Rzeczypospolitej Polskiej. Pouczenia 
udziela się powodowi niezwłocznie po wniesieniu pozwu, a pozwanemu – 
równocześnie z doręczeniem odpisu pozwu. 
**§ 3.** Doręczając stronie będącej przedsiębiorcą pouczenia o treści § 1 i 4, 
przewodniczący wzywa stronę, aby w wyznaczonym terminie, nie krótszym niż 
dwa tygodnie, powołała wszystkie twierdzenia i dowody. 
**§ 4.** Twierdzenia i dowody powołane z naruszeniem § 1 i 3 podlegają 
pominięciu, chyba że strona będąca przedsiębiorcą uprawdopodobni, że ich 
powołanie nie było możliwe albo że potrzeba ich powołania wynikła później. 
W takim przypadku dalsze twierdzenia i dowody na ich poparcie powinny być 
powołane w terminie dwóch tygodni od dnia, w którym ich powołanie stało się 
możliwe lub wynikła potrzeba ich powołania.

***
## Art. 45816. {#kpc-pierwsza-pierwsza-art-45816}

Jeżeli 
strona 
będąca 
przedsiębiorcą 
przed 
wytoczeniem 
powództwa zaniechała próby dobrowolnego rozwiązania sporu, uchyliła się od 
udziału w niej lub uczestniczyła w niej w złej wierze i przez to przyczyniła się do 
zbędnego wytoczenia powództwa lub wadliwego określenia przedmiotu sprawy, 
niezależnie od wyniku sprawy sąd może obciążyć tę stronę kosztami procesu 
w całości lub części, a w uzasadnionych przypadkach nawet podwyższyć je, jednak 
nie więcej niż dwukrotnie. 

 
 
 
s. 181/580 
 
2025-09-08 
#### DZIAŁ III
Postępowanie w sprawach z zakresu prawa pracy i ubezpieczeń społecznych 
Rozdział 1 
Przepisy ogólne

***
## Art. 459. {#kpc-pierwsza-pierwsza-art-459}

Przepisy niniejszego rozdziału stosuje się w sprawach z zakresu 
prawa pracy, a także w sprawach z zakresu ubezpieczeń społecznych.

***
## Art. 460. {#kpc-pierwsza-pierwsza-art-460}

**§ 1.** Zdolność sądową i procesową ma także pracodawca, chociażby 
nie posiadał osobowości prawnej, a w sprawach z zakresu ubezpieczeń 
społecznych zdolność tę ma organ rentowy i wojewódzki zespół do spraw 
orzekania o niepełnosprawności. 
**§ 2.** W razie potrzeby ustanowienia dla strony kuratora, postanowienie, 
o którym mowa w art. 69, może zapaść również z urzędu.

***
## Art. 461. {#kpc-pierwsza-pierwsza-art-461}

**§ 1.** Powództwo w sprawie z zakresu prawa pracy można wytoczyć 
bądź przed sąd ogólnie właściwy dla pozwanego, bądź przed sąd, w którego 
obszarze właściwości praca jest, była lub miała być wykonywana. 
**§ 11.** Do właściwości sądów rejonowych, bez względu na wartość przedmiotu 
sporu, należą sprawy z zakresu prawa pracy o ustalenie istnienia stosunku pracy, 
o uznanie bezskuteczności wypowiedzenia stosunku pracy, o przywrócenie do 
pracy i przywrócenie poprzednich warunków pracy lub płacy oraz łącznie z nimi 
dochodzone roszczenia i o odszkodowanie w przypadku nieuzasadnionego lub 
naruszającego przepisy wypowiedzenia oraz rozwiązania stosunku pracy, a także 
sprawy dotyczące kar porządkowych i świadectwa pracy oraz roszczenia z tym 
związane. 
**§ 2.** W sprawach z zakresu ubezpieczeń społecznych właściwy jest sąd, w 
którego obszarze właściwości ma miejsce zamieszkania albo siedzibę strona 
odwołująca się od decyzji wydanej przez organ rentowy lub orzeczenia wydanego 
przez wojewódzki zespół do spraw orzekania o niepełnosprawności lub decyzji 
wydanej przez ten zespół, jak również występująca z żądaniem w pozostałych 
sprawach z zakresu ubezpieczeń społecznych wymienionych w art. 476 § 3. Jeżeli 
na tej podstawie nie można ustalić sądu właściwego, właściwy jest sąd, w którego 

 
 
 
s. 182/580 
 
2025-09-08 
 
obszarze właściwości ma siedzibę organ rentowy, a w sprawie, w której występuje 
wymieniony w art. 476 § 3 organ inny niż rentowy – ten organ. 
**§ 21.** W sprawach z zakresu ubezpieczeń społecznych, w których wniesiono 
odwołanie od decyzji organu emerytalnego określonego przez ministra właściwego 
do spraw wewnętrznych, wojskowego organu emerytalnego albo organu 
emerytalnego właściwego w stosunku do funkcjonariuszy Służby Więziennej, 
właściwy jest sąd, w którego obszarze właściwości ma siedzibę ten organ. Przepisu 
art. 44 nie stosuje się, chyba że miałoby to prowadzić do nieważności 
postępowania. 
**§ 22.** (uchylony) 
**§ 3.** Sąd właściwy może na zgodny wniosek stron przekazać sprawę do 
rozpoznania innemu sądowi równorzędnemu, rozpoznającemu sprawy z zakresu 
prawa pracy lub ubezpieczeń społecznych, jeżeli przemawiają za tym względy 
celowości. 
**§ 4.** Przepis art. 442 stosuje się odpowiednio, jeżeli stroną jest sąd będący 
pracodawcą.

***
## Art. 462. {#kpc-pierwsza-pierwsza-art-462}

W sprawach z zakresu prawa pracy i ubezpieczeń społecznych 
organizacje pozarządowe w zakresie swoich zadań statutowych, za zgodą 
pracownika lub ubezpieczonego wyrażoną na piśmie, mogą wytaczać powództwa 
na rzecz pracownika lub wnosić odwołania od decyzji organów rentowych, a także, 
za zgodą pracownika lub ubezpieczonego wyrażoną na piśmie, przystępować do 
nich w toczącym się postępowaniu.

***
## Art. 463. {#kpc-pierwsza-pierwsza-art-463}

(uchylony)

***
## Art. 464. {#kpc-pierwsza-pierwsza-art-464}

**§ 1.** Odrzucenie 
pozwu 
nie 
może 
nastąpić 
z powodu 
niedopuszczalności drogi sądowej, gdy do rozpoznania sprawy właściwy jest inny 
organ. W tym przypadku sąd przekaże sprawę temu organowi. Jeżeli jednak organ 
ten uprzednio uznał się za niewłaściwy, sąd rozpozna sprawę. 
**§ 2.** Wniesienie do sądu pozwu, przekazanego następnie stosownie do 
paragrafu poprzedzającego, wywołuje skutki, jakie ustawa wiąże z wytoczeniem 
powództwa.

***
## Art. 465. {#kpc-pierwsza-pierwsza-art-465}

**§ 1.** Pełnomocnikiem pracownika lub ubezpieczonego może być 
również przedstawiciel związku zawodowego lub inspektor pracy albo pracownik 

 
 
 
s. 183/580 
 
2025-09-08 
 
zakładu pracy, w którym mocodawca jest lub był zatrudniony, a ubezpieczonego – 
także przedstawiciel organizacji zrzeszającej emerytów i rencistów. 
**§ 11.** Pełnomocnikiem 
pracodawcy 
niebędącego 
osobą 
prawną 
lub 
przedsiębiorcą albo organu rentowego może być również jego pracownik. 
Pełnomocnikiem 
wojewódzkiego 
zespołu 
do 
spraw 
orzekania 
o niepełnosprawności może być jego członek. 
**§ 2.** Do odbioru należności zasądzonych na rzecz pracownika lub 
ubezpieczonego jest wymagane pełnomocnictwo szczególne, udzielone po 
powstaniu tytułu egzekucyjnego.

***
## Art. 466. {#kpc-pierwsza-pierwsza-art-466}

Pracownik lub ubezpieczony działający bez adwokata lub radcy 
prawnego może zgłosić w sądzie właściwym ustnie do protokołu powództwo oraz 
treść środków odwoławczych i innych pism procesowych.

***
## Art. 467. {#kpc-pierwsza-pierwsza-art-467}

**§ 1.** (uchylony) 
**§ 2.** (uchylony) 
**§ 3.** (uchylony) 
**§ 31.** Stronę wnoszącą pismo wszczynające postępowanie wzywa się do 
usunięcia jego braków, tylko gdy braki te uniemożliwiają przeprowadzenie 
posiedzenia przygotowawczego z udziałem strony wnoszącej pismo. 
**§ 32.** Posiedzenie przygotowawcze służy także usunięciu braków pisma 
wszczynającego postępowanie w zakresie niezbędnym do nadania sprawie 
prawidłowego biegu oraz, w razie potrzeby, ustaleniu przez sąd dowodów do 
przeprowadzenia z urzędu, a także wyjaśnieniu innych okoliczności istotnych dla 
prawidłowego i szybkiego rozpoznania sprawy. 
**§ 4.** Jeżeli w sprawie z zakresu ubezpieczeń społecznych okaże się, że 
występują istotne braki w materiale, a jego uzupełnienie w postępowaniu sądowym 
byłoby połączone ze znacznymi trudnościami, przewodniczący może zwrócić 
organowi rentowemu akta sprawy w celu uzupełnienia materiału sprawy. To samo 
dotyczy przypadku, w którym decyzja organu rentowego nie zawiera: 
- 1) podstawy prawnej i faktycznej; 
- 2) wskazania sposobu wyliczenia świadczenia.

***
## Art. 468. {#kpc-pierwsza-pierwsza-art-468}

(uchylony) 

 
 
 
s. 184/580 
 
2025-09-08

***
## Art. 469. {#kpc-pierwsza-pierwsza-art-469}

Sąd uzna zawarcie ugody, cofnięcie pozwu, sprzeciwu lub środka 
odwoławczego oraz zrzeczenie się lub ograniczenie roszczenia za niedopuszczalne 
także wówczas, gdyby czynność ta naruszała słuszny interes pracownika lub 
ubezpieczonego.

***
## Art. 470. {#kpc-pierwsza-pierwsza-art-470}

Pozwany ma obowiązek zapewnić, by osoba reprezentująca go przy 
czynnościach sądu była obeznana ze stanem faktycznym sprawy i umocowana do 
zawarcia ugody.

***
## Art. 471. {#kpc-pierwsza-pierwsza-art-471}

Przewodniczący i sąd są obowiązani podejmować czynności tak, by 
termin posiedzenia, na którym sprawa ma zostać rozpoznana, przypadł nie później 
niż miesiąc od dnia zakończenia posiedzenia przygotowawczego, a jeżeli go nie 
przeprowadzono – nie później niż sześć miesięcy od dnia złożenia odpowiedzi na 
pozew. Jeżeli odpowiedź ta była dotknięta brakami, termin ten biegnie od dnia 
usunięcia tych braków, a jeżeli odpowiedzi nie złożono – od dnia upływu terminu 
do jej złożenia.

***
## Art. 472. {#kpc-pierwsza-pierwsza-art-472}

Sąd żąda przedstawienia niezbędnych do rozstrzygnięcia sprawy akt 
osobowych i innych dokumentów, stosując odpowiednio przepis art. 1491.

***
## Art. 473. {#kpc-pierwsza-pierwsza-art-473}

**§ 1.** W sprawach przewidzianych w niniejszym dziale nie stosuje 
się 
przepisów 
ograniczających 
dopuszczalność 
dowodu 
ze 
świadków 
i z przesłuchania stron. 
**§ 2.** (uchylony)

***
## Art. 474. {#kpc-pierwsza-pierwsza-art-474}

(uchylony)

***
## Art. 475. {#kpc-pierwsza-pierwsza-art-475}

Jeżeli strona bez usprawiedliwionych powodów nie wykona w toku 
postępowania postanowień lub zarządzeń, sąd może skazać ją na grzywnę według 
przepisów o karach za niestawiennictwo świadka i odmówić przyznania kosztów 
lub zastosować jeden z tych środków; nie może jednak nakazać przymusowego 
sprowadzenia jej do sądu. Gdy stroną tą jest jednostka organizacyjna, grzywnie 
podlega pracownik odpowiedzialny za wykonanie postanowień lub zarządzeń, 
a w razie niewyznaczenia takiego pracownika lub niemożności jego ustalenia – 
kierownik tej jednostki. 

 
 
 
s. 185/580 
 
2025-09-08

***
## Art. 4751. {#kpc-pierwsza-pierwsza-art-4751}

Przepisów art. 466, art. 467, art. 470 i art. 471 nie stosuje się do 
skargi kasacyjnej i postępowania przed Sądem Najwyższym wywołanego jej 
wniesieniem.

***
## Art. 476. {#kpc-pierwsza-pierwsza-art-476}

**§ 1.** Przez sprawy z zakresu prawa pracy rozumie się sprawy: 
- 1) o roszczenia ze stosunku pracy lub z nim związane; 
- 11) o ustalenie istnienia stosunku pracy, jeżeli łączący strony stosunek prawny, 
wbrew zawartej między nimi umowie, ma cechy stosunku pracy; 
- 2) o roszczenia z innych stosunków prawnych, do których z mocy odrębnych 
przepisów stosuje się przepisy prawa pracy; 
- 3) o odszkodowania dochodzone od pracodawcy na podstawie przepisów 
o świadczeniach z tytułu wypadków przy pracy i chorób zawodowych. 
**§ 2.** Przez sprawy z zakresu ubezpieczeń społecznych rozumie się sprawy, 
w których wniesiono odwołanie od decyzji organów rentowych, dotyczących: 
- 1) ubezpieczeń społecznych; 
- 2) emerytur i rent; 
- 3) (uchylony) 
- 4) innych świadczeń w sprawach należących do właściwości Zakładu 
Ubezpieczeń Społecznych; 
- 5) świadczeń odszkodowawczych przysługujących w razie wypadku lub 
choroby pozostających w związku ze służbą wojskową albo służbą w Policji, 
Straży Granicznej, Straży Marszałkowskiej, Służbie Celno-Skarbowej, 
Państwowej Straży Pożarnej, Biurze Ochrony Rządu, Służbie Ochrony 
Państwa, Służbie Więziennej, Agencji Bezpieczeństwa Wewnętrznego, 
Agencji Wywiadu, Służbie Kontrwywiadu Wojskowego, Służbie Wywiadu 
Wojskowego oraz Centralnym Biurze Antykorupcyjnym. 
**§ 3.** Przez sprawy z zakresu ubezpieczeń społecznych rozumie się także 
sprawy wszczęte na skutek niewydania przez organ rentowy decyzji we właściwym 
terminie, a także sprawy, w których wniesiono odwołanie od orzeczenia 
wojewódzkiego zespołu do spraw orzekania o niepełnosprawności lub od decyzji 
wydanej przez ten zespół, sprawy o roszczenia ze stosunków prawnych między 
członkami otwartych funduszy emerytalnych a tymi funduszami lub ich organami 
oraz sprawy ze stosunków między emerytami lub osobami uposażonymi 

 
 
 
s. 186/580 
 
2025-09-08 
 
w rozumieniu przepisów o emeryturach kapitałowych a Zakładem Ubezpieczeń 
Społecznych. 
**§ 4.** Przez organy rentowe rozumie się: 
- 1) jednostki organizacyjne Zakładu Ubezpieczeń Społecznych określone 
w przepisach o systemie ubezpieczeń społecznych, właściwe do wydawania 
decyzji w sprawach świadczeń, 
- 2) (uchylony) 
- 3) wojskowe organy emerytalne oraz organy emerytalne resortów spraw 
wewnętrznych i sprawiedliwości, a także inne organy wojskowe i organy 
resortów spraw wewnętrznych i sprawiedliwości 
– właściwe do wydawania decyzji w sprawach, o których mowa w § 2, a także 
Prezesa Kasy Rolniczego Ubezpieczenia Społecznego. 
**§ 5.** Przez użyte w niniejszym dziale określenie: 
- 1) pracownik – rozumie się również: 
  - a) członka rolniczej spółdzielni produkcyjnej, osobę świadczącą pracę na 
podstawie umowy o pracę nakładczą oraz członków rodziny 
i spadkobierców pracownika, członka rolniczej spółdzielni produkcyjnej 
i osoby świadczącej pracę na podstawie umowy o pracę nakładczą, 
a także inne osoby, którym z mocy odrębnych przepisów przysługują 
roszczenia z zakresu prawa pracy, 
  - b) osobę dochodzącą od pracodawcy odszkodowania lub ustalenia 
uprawnień do świadczeń na podstawie przepisów o świadczeniach 
z tytułu wypadków przy pracy i chorób zawodowych; 
- 2) ubezpieczony – rozumie się osobę ubiegającą się o: 
  - a) świadczenie z ubezpieczeń społecznych albo o emeryturę lub rentę, 
  - b) ustalenie istnienia bądź nieistnienia obowiązku ubezpieczenia, jego 
zakresu lub wymiaru składki z tego tytułu, 
  - c) świadczenia 
w sprawach 
należących 
do 
właściwości 
Zakładu 
Ubezpieczeń Społecznych, 
  - d) świadczenie odszkodowawcze przysługujące w razie wypadku lub 
choroby pozostające w związku ze służbą wojskową albo służbą 
w Policji, Straży Granicznej, Straży Marszałkowskiej, Służbie Celno-
-Skarbowej, Państwowej Straży Pożarnej, Biurze Ochrony Rządu, 

 
 
 
s. 187/580 
 
2025-09-08 
 
Służbie Ochrony Państwa, Służbie Więziennej, Agencji Bezpieczeństwa 
Wewnętrznego, 
Agencji 
Wywiadu, 
Służbie 
Kontrwywiadu 
Wojskowego, Służbie Wywiadu Wojskowego oraz Centralnym Biurze 
Antykorupcyjnym. 
Rozdział 2 
Postępowanie w sprawach z zakresu prawa pracy

***
## Art. 477. {#kpc-pierwsza-pierwsza-art-477}

W postępowaniu wszczętym z powództwa pracownika wezwania do 
udziału w sprawie, o którym mowa w art. 194 § 1 i § 3, sąd może dokonać również 
z urzędu. Przewodniczący poucza pracownika o roszczeniach wynikających 
z przytoczonych przez niego faktów.

***
## Art. 4771. {#kpc-pierwsza-pierwsza-art-4771}

Jeżeli pracownik dokonał wyboru jednego z przysługujących mu 
alternatywnie roszczeń, a zgłoszone roszczenie okaże się nieuzasadnione, sąd może 
z urzędu uwzględnić inne roszczenie alternatywne.

***
## Art. 4771a. {#kpc-pierwsza-pierwsza-art-4771a}

W przypadku wystąpienia z żądaniem zobowiązania pracodawcy 
do wydania świadectwa pracy, o którym mowa w art. 971 § 1 ustawy z dnia 
26 czerwca 1974 r. – Kodeks pracy (Dz. U. z 2023 r. poz. 1465 oraz z 2024 r. poz. 
878 i 1222), jeżeli okaże się, że pracodawca nie istnieje albo z innych przyczyn 
wytoczenie przeciwko niemu powództwa jest niemożliwe, sąd rozpozna żądanie 
w postępowaniu nieprocesowym jako żądanie ustalenia uprawnienia do otrzymania 
świadectwa pracy.

***
## Art. 4771b. {#kpc-pierwsza-pierwsza-art-4771b}

**§ 1.** W wyroku 
uwzględniającym 
żądanie 
zobowiązania 
pracodawcy do wydania świadectwa pracy, o którym mowa w art. 971 § 1 ustawy 
z dnia 26 czerwca 1974 r. – Kodeks pracy, sąd określa treść świadectwa pracy 
zgodnie z art. 97 § 2 ustawy z dnia 26 czerwca 1974 r. – Kodeks pracy i przepisami 
wydanymi na podstawie art. 97 § 4 tej ustawy. Jeżeli określenie wszystkich faktów 
wymienionych w tych przepisach jest niemożliwe, w wyroku określa się co 
najmniej okres i rodzaj wykonywanej pracy, wymiar czasu pracy, zajmowane 
stanowiska oraz tryb rozwiązania albo okoliczności wygaśnięcia stosunku pracy, 
a w sytuacji gdy określenie trybu rozwiązania albo okoliczności wygaśnięcia 
stosunku pracy również jest niemożliwe – wskazuje się, że rozwiązanie stosunku 
pracy nastąpiło za wypowiedzeniem dokonanym przez pracodawcę. 

 
 
 
s. 188/580 
 
2025-09-08 
**§ 2.** Prawomocny wyrok zobowiązujący pracodawcę do wydania świadectwa 
pracy zastępuje to świadectwo. 
**§ 3.** Przepisy § 1 i 2 stosuje się odpowiednio do żądania sprostowania 
świadectwa pracy.

***
## Art. 4772. {#kpc-pierwsza-pierwsza-art-4772}

**§ 1.** Zasądzając należność pracownika w sprawach z zakresu 
prawa pracy, sąd z urzędu nada wyrokowi przy jego wydaniu rygor 
natychmiastowej 
wykonalności 
w części 
nieprzekraczającej 
pełnego 
jednomiesięcznego wynagrodzenia pracownika. Przepis art. 334 § 4 i art. 335 § 1 
zdanie drugie stosuje się odpowiednio; nie stosuje się przepisu art. 335 § 2. 
**§ 2.** Uznając wypowiedzenie umowy o pracę za bezskuteczne albo 
przywracając pracownika do pracy, sąd na wniosek pracownika nakłada w wyroku 
na pracodawcę obowiązek dalszego zatrudnienia pracownika do czasu 
prawomocnego zakończenia postępowania.

***
## Art. 4773. {#kpc-pierwsza-pierwsza-art-4773}

(uchylony)

***
## Art. 4774. {#kpc-pierwsza-pierwsza-art-4774}

(uchylony)

***
## Art. 4775. {#kpc-pierwsza-pierwsza-art-4775}

(uchylony)

***
## Art. 4776. {#kpc-pierwsza-pierwsza-art-4776}

**§ 1.** Wyrok sądu pierwszej instancji zasądzający świadczenia na 
rzecz pracownika lub członków jego rodziny, w stosunku do którego sąd drugiej 
instancji oddalił apelację pracodawcy, podlega natychmiastowemu wykonaniu 
także w części, w której sąd nie nadał mu rygoru natychmiastowej wykonalności 
na podstawie art. 4772. 
**§ 2.** Przepis § 1 stosuje się również do wyroków sądu drugiej instancji 
zasądzających świadczenia na rzecz pracownika lub członków jego rodziny. 
**§ 3.** Sąd drugiej instancji nadaje z urzędu wyrokowi, o którym mowa w § 1 
i 2, klauzulę wykonalności w dniu ogłoszenia wyroku i wyrok zaopatrzony 
klauzulą wydaje uprawnionemu.

***
## Art. 4777. {#kpc-pierwsza-pierwsza-art-4777}

Przepisów art. 464, art. 467 § 31 i art. 470–473 nie stosuje się 
w sprawach, w których pracownik jest stroną pozwaną.

***
## Art. 4777a. {#kpc-pierwsza-pierwsza-art-4777a}

Przepisu art. 176 § 2 nie stosuje się w postępowaniach z zakresu 
prawa pracy, w sprawach, w których podmiot w restrukturyzacji, o którym mowa 
w art. 2 pkt 44 ustawy z dnia 10 czerwca 2016 r. o Bankowym Funduszu 

 
 
 
s. 189/580 
 
2025-09-08 
 
Gwarancyjnym, 
systemie 
gwarantowania 
depozytów 
oraz 
przymusowej 
restrukturyzacji, jest pozwanym. 
Rozdział 3 
Postępowanie w sprawach z zakresu ubezpieczeń społecznych

***
## Art. 4778. {#kpc-pierwsza-pierwsza-art-4778}

**§ 1.** Do właściwości sądów okręgowych należą sprawy z zakresu 
ubezpieczeń społecznych, z wyjątkiem spraw, dla których zastrzeżona jest 
właściwość sądów rejonowych. 
**§ 2.** Do właściwości sądów rejonowych należą sprawy: 
- 1) o zasiłek chorobowy, wyrównawczy, opiekuńczy, macierzyński oraz 
pogrzebowy; 
- 2) o świadczenie rehabilitacyjne; 
- 3) o odszkodowanie z tytułu wypadku przy pracy rolniczej, wypadku w drodze 
do pracy lub z pracy, wypadku przy pracy lub choroby zawodowej, wypadku 
lub choroby zawodowej pozostającej w związku z czynną służbą wojskową 
albo służbą w Policji, Agencji Bezpieczeństwa Wewnętrznego, Agencji 
Wywiadu, 
Służbie 
Kontrwywiadu 
Wojskowego, 
Służbie 
Wywiadu 
Wojskowego, Centralnym Biurze Antykorupcyjnym, Straży Granicznej, 
Straży Marszałkowskiej, Biurze Ochrony Rządu, Służbie Ochrony Państwa, 
Służbie Więziennej, Państwowej Straży Pożarnej i Służbie Celno-Skarbowej; 
- 4) o ustalenie niepełnosprawności lub stopnia niepełnosprawności; 
4a) o ustalenie poziomu potrzeby wsparcia; 
4b) o zwolnienie z opłacenia składek, o których mowa w art. 17a ustawy z dnia 
13 października 1998 r. o systemie ubezpieczeń społecznych (Dz. U. 
z 2024 r. poz. 497, 863 i 1243). 
- 5) (uchylony) 
- 6) (uchylony)

***
## Art. 4779. {#kpc-pierwsza-pierwsza-art-4779}

**§ 1.** Odwołania od decyzji organów rentowych lub orzeczeń 
wojewódzkich zespołów do spraw orzekania o niepełnosprawności lub decyzji 
wydanych przez ten zespół, wnosi się na piśmie do organu lub zespołu, który wydał 
decyzję lub orzeczenie, lub do protokołu sporządzonego przez ten organ lub zespół, 
w terminie miesiąca od dnia doręczenia decyzji lub orzeczenia. 

 
 
 
s. 190/580 
 
2025-09-08 
**§ 2.** Organ rentowy lub wojewódzki zespół do spraw orzekania 
o niepełnosprawności niezwłocznie, nie później niż w terminie trzydziestu dni od 
dnia, w którym otrzymał odwołanie, przekazuje je wraz z aktami sprawy do sądu. 
Organ ten lub zespół, jeżeli uzna odwołanie w całości za słuszne, może zmienić lub 
uchylić zaskarżoną decyzję lub orzeczenie. W tym przypadku odwołaniu nie nadaje 
się dalszego biegu. 
**§ 21.** Jeżeli w odwołaniu od decyzji organu rentowego wskazano nowe 
okoliczności dotyczące niezdolności do pracy lub niezdolności do samodzielnej 
egzystencji albo stałego lub długotrwałego uszczerbku na zdrowiu, które powstały 
po dniu wydania orzeczenia przez lekarza orzecznika Zakładu Ubezpieczeń 
Społecznych, od którego nie wniesiono sprzeciwu, lub orzeczenia komisji 
lekarskiej Zakładu Ubezpieczeń Społecznych, organ rentowy nie przekazuje 
odwołania do sądu, lecz kieruje do lekarza orzecznika Zakładu Ubezpieczeń 
Społecznych do ponownego rozpatrzenia. Organ rentowy uchyla decyzję, 
rozpatruje nowe okoliczności i wydaje decyzję, od której przysługuje odwołanie do 
sądu. Przepis ten stosuje się także wówczas, gdy nie można ustalić daty powstania 
wskazanych w odwołaniu nowych okoliczności. 
**§ 3.** Sąd odrzuci odwołanie wniesione po upływie terminu, chyba że 
przekroczenie terminu nie jest nadmierne i nastąpiło z przyczyn niezależnych od 
odwołującego się. 
**§ 31.** Sąd odrzuci odwołanie w sprawie o świadczenie z ubezpieczeń 
społecznych, do którego prawo jest uzależnione od stwierdzenia niezdolności do 
pracy lub niezdolności do samodzielnej egzystencji albo stwierdzenia stałego lub 
długotrwałego uszczerbku na zdrowiu, jeżeli podstawę do wydania decyzji stanowi 
orzeczenie lekarza orzecznika Zakładu Ubezpieczeń Społecznych, a osoba 
zainteresowana nie wniosła sprzeciwu od tego orzeczenia do komisji lekarskiej 
Zakładu Ubezpieczeń Społecznych i odwołanie jest oparte wyłącznie na zarzutach 
dotyczących tego orzeczenia. Jeżeli odwołanie opiera się także na zarzucie 
nierozpatrzenia wniesionego po terminie sprzeciwu od tego orzeczenia, 
a wniesienie sprzeciwu po terminie nastąpiło z przyczyn niezależnych od osoby 
zainteresowanej, sąd uchyla decyzję, przekazuje sprawę do ponownego 
rozpoznania organowi rentowemu i umarza postępowanie. W takim przypadku 

 
 
 
s. 191/580 
 
2025-09-08 
 
organ rentowy kieruje sprzeciw do rozpatrzenia do komisji lekarskiej Zakładu 
Ubezpieczeń Społecznych. 
**§ 32.** (uchylony) 
**§ 33.** Przepis § 31 stosuje się odpowiednio w sprawach o świadczenia 
z ubezpieczenia społecznego rolników. 
**§ 4.** Jeżeli organ rentowy lub wojewódzki zespół do spraw orzekania 
o niepełnosprawności nie wydał decyzji lub orzeczenia w terminie dwóch miesięcy 
od dnia zgłoszenia roszczenia w sposób przepisany, odwołanie można wnieść 
w każdym czasie po upływie tego terminu. 
**§ 5.** Ubezpieczony lub osoba odwołująca się od orzeczenia wojewódzkiego 
zespołu do spraw orzekania o niepełnosprawności lub decyzji wydanej przez ten 
zespół, może również wnieść odwołanie – z wyłączeniem odwołania, o którym 
mowa w § 4 – do protokołu w sądzie właściwym do rozpoznania sprawy albo 
w sądzie właściwym dla miejsca zamieszkania ubezpieczonego lub osoby 
odwołującej się od orzeczenia wojewódzkiego zespołu do spraw orzekania 
o niepełnosprawności lub decyzji wydanej przez ten zespół. 
**§ 6.** Sąd, do którego wniesiono odwołanie, niezwłocznie przekazuje protokół 
organowi lub zespołowi, który wydał zaskarżoną decyzję lub orzeczenie, chyba że 
sąd ten jest właściwy do jego rozpoznania. W takim przypadku przewodniczący 
niezwłocznie zażąda akt sprawy i nada bieg odwołaniu, przesyłając odpis protokołu 
organowi lub zespołowi, który wydał zaskarżoną decyzję lub orzeczenie. 
**§ 7.** Jeżeli organ rentowy lub wojewódzki zespół do spraw orzekania 
o niepełnosprawności, pomimo upływu terminu nie przekazał odwołania wraz 
z aktami sprawy do sądu, ubezpieczony albo osoba odwołująca się od orzeczenia 
zespołu może wnieść ponaglenie. Do postępowania wszczętego na skutek 
ponaglenia stosuje się przepisy ustawy z dnia 14 czerwca 1960 r. – Kodeks 
postępowania administracyjnego (Dz. U. z 2024 r. poz. 572).

***
## Art. 47710. {#kpc-pierwsza-pierwsza-art-47710}

**§ 1.** Odwołanie powinno zawierać oznaczenie zaskarżonej decyzji 
lub orzeczenia, zwięzłe przytoczenie zarzutów oraz wniosków i ich uzasadnienie 
oraz podpis ubezpieczonego albo osoby odwołującej się od orzeczenia 
wojewódzkiego zespołu do spraw orzekania o niepełnosprawności lub decyzji 
wydanej przez ten zespół, albo przedstawiciela ustawowego lub pełnomocnika 

 
 
 
s. 192/580 
 
2025-09-08 
 
ubezpieczonego albo osoby odwołującej się od orzeczenia wojewódzkiego zespołu 
do spraw orzekania o niepełnosprawności lub decyzji wydanej przez ten zespół. 
**§ 2.** Jeżeli ubezpieczony zgłosił nowe żądanie, dotychczas nierozpoznane 
przez organ rentowy, sąd przyjmuje to żądanie do protokołu i przekazuje go do 
rozpoznania organowi rentowemu.

***
## Art. 47711. {#kpc-pierwsza-pierwsza-art-47711}

**§ 1.** Stronami są ubezpieczony, osoba odwołująca się od 
orzeczenia wojewódzkiego zespołu do spraw orzekania o niepełnosprawności lub 
decyzji wydanej przez ten zespół, inna osoba, której praw i obowiązków dotyczy 
zaskarżona decyzja, organ rentowy, wojewódzki zespół do spraw orzekania 
o niepełnosprawności i zainteresowany. 
**§ 2.** Zainteresowanym jest ten, czyje prawa lub obowiązki zależą od 
rozstrzygnięcia sprawy. Jeżeli zainteresowany nie bierze udziału w sprawie, sąd 
zawiadomi go o toczącym się postępowaniu. Zainteresowany może przystąpić do 
sprawy w ciągu dwóch tygodni od dnia doręczenia zawiadomienia. Do 
zainteresowanego przepisu art. 174 § 1 nie stosuje się. 
**§ 3.** (uchylony)

***
## Art. 47712. {#kpc-pierwsza-pierwsza-art-47712}

Nie jest dopuszczalne zawarcie ugody, ani poddanie sporu pod 
rozstrzygnięcie sądu polubownego.

***
## Art. 47713. {#kpc-pierwsza-pierwsza-art-47713}

**§ 1.** Zmiana przez organ rentowy zaskarżonej decyzji lub przez 
wojewódzki zespół do spraw orzekania o niepełnosprawności zaskarżonego 
orzeczenia lub decyzji wydanej przez ten zespół, przed rozstrzygnięciem sprawy 
przez sąd – przez wydanie decyzji lub orzeczenia uwzględniającego w całości lub 
w części żądanie strony – powoduje umorzenie postępowania w całości lub w 
części. Poza tym zmiana lub wykonanie decyzji lub orzeczenia nie ma wpływu na 
bieg sprawy. 
**§ 2.** (uchylony)

***
## Art. 47714. {#kpc-pierwsza-pierwsza-art-47714}

**§ 1.** Sąd oddala odwołanie, jeżeli nie ma podstaw do jego 
uwzględnienia. 
**§ 2.** W przypadku uwzględnienia odwołania sąd zmienia w całości lub 
w części zaskarżoną decyzję organu rentowego lub zaskarżone orzeczenie 
wojewódzkiego zespołu do spraw orzekania o niepełnosprawności lub decyzję tego 
zespołu i orzeka co do istoty sprawy. 

 
 
 
s. 193/580 
 
2025-09-08 
**§ 21.** Jeżeli decyzja nakładająca na ubezpieczonego zobowiązanie, ustalająca 
wymiar tego zobowiązania lub obniżająca świadczenie, została wydana z rażącym 
naruszeniem przepisów o postępowaniu przed organem rentowym, sąd uchyla tę 
decyzję i przekazuje sprawę do ponownego rozpoznania organowi rentowemu. 
**§ 3.** Jeżeli odwołanie wniesiono w związku z niewydaniem decyzji przez 
organ rentowy lub niewydaniem orzeczenia przez wojewódzki zespół do spraw 
orzekania o niepełnosprawności lub decyzji przez ten zespół, sąd w razie 
uwzględnienia odwołania zobowiązuje organ lub zespół do wydania decyzji lub 
orzeczenia w określonym terminie, zawiadamiając o tym organ nadrzędny, albo 
orzeka co do istoty sprawy. Jednocześnie sąd stwierdza, czy niewydanie decyzji 
przez organ rentowy nastąpiło z rażącym naruszeniem prawa. 
**§ 4.** W sprawie o świadczenie z ubezpieczeń społecznych, do którego prawo 
jest uzależnione od stwierdzenia niezdolności do pracy lub niezdolności do 
samodzielnej egzystencji albo stwierdzenia stałego lub długotrwałego uszczerbku 
na zdrowiu, jeżeli podstawę do wydania decyzji stanowi orzeczenie lekarza 
orzecznika Zakładu Ubezpieczeń Społecznych lub orzeczenie komisji lekarskiej 
Zakładu Ubezpieczeń Społecznych i odwołanie od decyzji opiera się wyłącznie na 
zarzutach dotyczących tego orzeczenia, sąd nie orzeka co do istoty sprawy na 
podstawie nowych okoliczności dotyczących stwierdzenia niezdolności do pracy 
lub niezdolności do samodzielnej egzystencji albo stwierdzenia stałego lub 
długotrwałego uszczerbku na zdrowiu, które powstały po dniu złożenia odwołania 
od tej decyzji. W tym przypadku sąd uchyla decyzję, przekazuje sprawę do 
rozpoznania organowi rentowemu i umarza postępowanie. 
**§ 5.** Przepis 
§ 4 stosuje się odpowiednio 
w sprawach o świadczenia 
z ubezpieczenia społecznego rolników. 
**§ 6.** W sprawie, w której wniesiono odwołanie od orzeczenia wojewódzkiego 
zespołu do spraw orzekania o niepełnosprawności lub wydanej przez ten zespół 
decyzji, sąd nie orzeka co do istoty sprawy na podstawie nowych okoliczności 
dotyczących niepełnosprawności lub na podstawie nowych okoliczności 
wpływających na poziom potrzeby wsparcia, które powstały po dniu wniesienia 
odwołania od tego orzeczenia lub decyzji. W tym przypadku sąd uchyla orzeczenie 
lub decyzję, przekazuje sprawę do rozpoznania wojewódzkiemu zespołowi do 
spraw orzekania o niepełnosprawności i umarza postępowanie. 

 
 
 
s. 194/580 
 
2025-09-08

***
## Art. 47714a. {#kpc-pierwsza-pierwsza-art-47714a}

Sąd drugiej instancji uchylając wyrok i poprzedzającą go decyzję 
organu rentowego może sprawę przekazać do ponownego rozpoznania 
bezpośrednio organowi rentowemu.

***
## Art. 47715. {#kpc-pierwsza-pierwsza-art-47715}

(uchylony)

***
## Art. 47716. {#kpc-pierwsza-pierwsza-art-47716}

(uchylony) 
#### DZIAŁ IV
Postępowanie w sprawach o naruszenie posiadania

***
## Art. 478. {#kpc-pierwsza-pierwsza-art-478}

W sprawach o naruszenie posiadania sąd bada jedynie ostatni stan 
posiadania i fakt jego naruszenia, nie rozpoznając samego prawa ani dobrej wiary 
pozwanego.

***
## Art. 479. {#kpc-pierwsza-pierwsza-art-479}

W sprawach o naruszenie posiadania powództwo wzajemne nie jest 
dopuszczalne. 
DZIAŁ IVa 
Postępowanie w sprawach z zakresu ochrony konkurencji i konsumentów 
oraz w sprawie praktyk nieuczciwie wykorzystujących przewagę 
kontraktową 
Rozdział 1 
(zawierający art. 4791–47927 – uchylony) 
(Rozdział 2 – uchylony)

***
## Art. 47928. {#kpc-pierwsza-pierwsza-art-47928}

**§ 1.** Sąd Okręgowy w Warszawie – sąd ochrony konkurencji 
i konsumentów jest właściwy w sprawach: 
- 1) odwołań od decyzji Prezesa Urzędu Ochrony Konkurencji i Konsumentów, 
zwanego w przepisach niniejszego rozdziału „Prezesem Urzędu”; 
- 2) zażaleń na postanowienia wydawane przez Prezesa Urzędu w postępowaniach 
prowadzonych 
na 
podstawie 
przepisów 
o ochronie 
konkurencji 
i konsumentów lub przepisów odrębnych; 
2a) zażaleń na postanowienia wydawane przez Prezesa Urzędu w sprawie 
rozpatrzenia sprzeciwu, o którym mowa w art. 59 ustawy z dnia 6 marca 
2018 r. – Prawo przedsiębiorców (Dz. U. z 2024 r. poz. 236 i 1222); 

 
 
 
s. 195/580 
 
2025-09-08 
- 3) zażaleń na postanowienia wydawane przez Prezesa Urzędu w postępowaniu 
zabezpieczającym prowadzonym na podstawie przepisów ustawy o ochronie 
konkurencji i konsumentów; 
- 4) zażaleń na postanowienia wydawane w postępowaniu egzekucyjnym 
prowadzonym w celu wykonania obowiązków wynikających z decyzji 
i postanowień wydawanych przez Prezesa Urzędu; 
- 5) zażaleń, o których mowa w art. 105m i w art. 105p ustawy z dnia 16 lutego 
2007 r. o ochronie konkurencji i konsumentów (Dz. U. z 2024 r. poz. 594 i 
1237); 
- 6) zażaleń, o których mowa w art. 28 ustawy z dnia 17 listopada 2021 r. 
o przeciwdziałaniu nieuczciwemu wykorzystywaniu przewagi kontraktowej 
w obrocie produktami rolnymi i spożywczymi (Dz. U. z 2023 r. poz. 1773); 
- 7) wniosków o udzielenie zgody na przeprowadzenie przeszukania, o którym 
mowa w art. 91 i art. 105n ustawy z dnia 16 lutego 2007 r. o ochronie 
konkurencji i konsumentów; 
- 8) zażaleń, o których mowa w art. 113m ust. 7, art. 113p ust. 9 i art. 113r ust. 12 
ustawy z dnia 16 lutego 2007 r. o ochronie konkurencji i konsumentów. 
**§ 2.** Odwołanie od decyzji Prezesa Urzędu wnosi się za jego pośrednictwem 
do sądu ochrony konkurencji i konsumentów w terminie miesiąca od dnia 
doręczenia decyzji. 
**§ 3.** Odwołanie od decyzji Prezesa Urzędu powinno czynić zadość 
wymaganiom przepisanym dla pisma procesowego oraz zawierać oznaczenie 
zaskarżonej decyzji, przytoczenie zarzutów, zwięzłe ich uzasadnienie, wskazanie 
dowodów, a także zawierać wniosek o uchylenie lub zmianę decyzji w całości lub 
w części.

***
## Art. 47929. {#kpc-pierwsza-pierwsza-art-47929}

**§ 1.** Stroną postępowania przed sądem ochrony konkurencji 
i konsumentów jest Prezes Urzędu oraz podmiot będący stroną w postępowaniu 
przed Prezesem Urzędu, a także wnoszący zażalenie. 
**§ 2.** (uchylony) 
**§ 3.** Pełnomocnikiem Prezesa Urzędu może być pracownik Urzędu Ochrony 
Konkurencji i Konsumentów.

***
## Art. 47929a. {#kpc-pierwsza-pierwsza-art-47929a}

(uchylony) 

 
 
 
s. 196/580 
 
2025-09-08

***
## Art. 47930. {#kpc-pierwsza-pierwsza-art-47930}

**§ 1.** W przypadku wniesienia odwołania od decyzji Prezesa 
Urzędu, sąd ochrony konkurencji i konsumentów może na wniosek strony, która 
wniosła odwołanie, wstrzymać wykonanie decyzji do czasu rozstrzygnięcia 
sprawy. 
**§ 2.** W przypadku zawieszenia postępowania, o którym mowa w art. 47930b, 
sąd ochrony konkurencji i konsumentów wstrzymuje wykonanie decyzji do czasu 
wydania przez Prezesa Urzędu decyzji albo wykonania lub podjęcia innej 
czynności stosownie do okoliczności sprawy na podstawie zatwierdzonej przez sąd 
ugody w sprawie odwołania do sądu ochrony konkurencji i konsumentów albo 
uprawomocnienia się postanowienia o odmowie zatwierdzenia ugody w sprawie 
odwołania do sądu ochrony konkurencji i konsumentów albo podjęcia 
postępowania na wniosek strony.

***
## Art. 47930a. {#kpc-pierwsza-pierwsza-art-47930a}

**§ 1.** W sprawach, o których mowa w art. 47928 § 1 pkt 1, strony 
mogą zawrzeć ugodę w przedmiocie przyjęcia ustaleń co do sposobu jej załatwienia 
(ugoda w sprawie odwołania do sądu ochrony konkurencji i konsumentów). 
**§ 2.** Ugoda 
w sprawie 
odwołania 
do 
sądu 
ochrony 
konkurencji 
i konsumentów zawiera: 
- 1) czas i miejsce jej sporządzenia; 
- 2) imię i nazwisko (nazwę) lub oznaczenie stron, a także ich adresy; 
- 3) dokonane przez strony ustalenia co do sposobu załatwienia sprawy; 
- 4) podpisy stron. 
**§ 3.** W razie ustalenia w ugodzie w sprawie odwołania do sądu ochrony 
konkurencji i konsumentów zasadności uwzględnienia odwołania od decyzji 
stwierdzającej naruszenie zakazów określonych w art. 6 ust. 1 pkt 1–6 ustawy 
z dnia 
16 lutego 
2007 r. 
o ochronie 
konkurencji 
i konsumentów 
lub 
w art. 101 ust. 1 lit. a–e Traktatu o funkcjonowaniu Unii Europejskiej, poprzez jej 
uchylenie w części dotyczącej przedsiębiorcy albo zmianę w taki sposób, że na 
przedsiębiorcę nie jest nakładana kara pieniężna, Prezes Urzędu z urzędu uchyla tę 
decyzję również w części dotyczącej osoby zarządzającej, o której mowa w art. 6a 
tej ustawy, która dopuściła do naruszenia zakazów przez tego przedsiębiorcę.

***
## Art. 47930b. {#kpc-pierwsza-pierwsza-art-47930b}

**§ 1.** Sąd ochrony konkurencji i konsumentów zawiesza 
postępowanie, na zgodny wniosek stron zamierzających zawrzeć ugodę w sprawie 

 
 
 
s. 197/580 
 
2025-09-08 
 
odwołania do sądu ochrony konkurencji i konsumentów, na okres do trzech 
miesięcy. Na zgodny wniosek stron lub z innych ważnych powodów okres 
zawieszenia może zostać przedłużony, jeżeli będzie to sprzyjać załatwieniu sprawy 
w drodze ugody w sprawie odwołania do sądu ochrony konkurencji i konsumen-
tów. 
**§ 2.** Jeżeli mimo upływu okresu, na który zawieszono postępowanie, nie 
zawarto ugody w sprawie odwołania do sądu ochrony konkurencji i konsumentów, 
sąd ochrony konkurencji i konsumentów postanowi podjąć postępowanie z urzędu. 
Przed upływem okresu, na który zawieszono postępowanie, sąd ochrony 
konkurencji i konsumentów postanowi podjąć postępowanie: 
- 1) jeżeli zawarto ugodę w sprawie odwołania do sądu ochrony konkurencji 
i konsumentów albo 
- 2) na wniosek strony.

***
## Art. 47930c. {#kpc-pierwsza-pierwsza-art-47930c}

**§ 1.** Jeżeli zawarto ugodę w sprawie odwołania do sądu ochrony 
konkurencji i konsumentów strona niezwłocznie przekazuje ją do sądu ochrony 
konkurencji i konsumentów, który niezwłocznie przeprowadza postępowanie 
w przedmiocie jej zatwierdzenia. 
**§ 2.** Na podstawie zatwierdzonej ugody w sprawie odwołania do sądu ochrony 
konkurencji i konsumentów Prezes Urzędu uchyla lub zmienia zaskarżoną decyzję 
albo wykonuje lub podejmuje inną czynność stosownie do okoliczności sprawy 
w zakresie swojej właściwości i kompetencji. 
**§ 3.** Sąd ochrony konkurencji i konsumentów odmawia zatwierdzenia ugody 
w sprawie odwołania do sądu ochrony konkurencji i konsumentów, w całości albo 
w części, jeżeli jest ona sprzeczna z prawem lub zasadami współżycia społecznego 
albo zmierza do obejścia prawa, a także gdy jest niezrozumiała lub zawiera 
sprzeczności. 
**§ 4.** Do decyzji Prezesa Urzędu lub do innej czynności stosownej 
do okoliczności sprawy w zakresie, w jakim stanowi ona realizację zatwierdzonej 
ugody w sprawie odwołania do sądu ochrony konkurencji i konsumentów, stosuje 
się odpowiednio przepisy o prawomocnej decyzji. 

 
 
 
s. 198/580 
 
2025-09-08

***
## Art. 47930d. {#kpc-pierwsza-pierwsza-art-47930d}

**§ 1.** Jeżeli ugoda w sprawie odwołania do sądu ochrony 
konkurencji i konsumentów została zatwierdzona, sąd ochrony konkurencji 
i konsumentów umarza postępowanie w zakresie objętym ugodą. 
**§ 2.** Jeżeli zatwierdzona ugoda w sprawie odwołania do sądu ochrony 
konkurencji i konsumentów dotyczy części zaskarżonej decyzji, sąd ochrony 
konkurencji i konsumentów w pozostałym zakresie stosuje przepis art. 47931a.

***
## Art. 47930e. {#kpc-pierwsza-pierwsza-art-47930e}

**§ 1.** Koszty postępowania, w którym zatwierdzono ugodę 
w sprawie odwołania do sądu ochrony konkurencji i konsumentów, znosi się 
wzajemnie, jeżeli strony nie postanowiły inaczej. 
**§ 2.** Jeżeli zatwierdzona ugoda przed sądem 
ochrony konkurencji 
i konsumentów dotyczy części zaskarżonej decyzji, o kosztach postępowania 
w pozostałym zakresie rozstrzyga się na podstawie przepisów tytułu V działu I.

***
## Art. 47930f. {#kpc-pierwsza-pierwsza-art-47930f}

W postępowaniu 
apelacyjnym 
przepisy 
art. 47930 § 2 
i art. 47930a–47930e stosuje się odpowiednio.

***
## Art. 47931. {#kpc-pierwsza-pierwsza-art-47931}

(utracił moc)15)

***
## Art. 47931a. {#kpc-pierwsza-pierwsza-art-47931a}

**§ 1.** Sąd ochrony konkurencji i konsumentów oddala odwołanie 
od decyzji Prezesa Urzędu, jeżeli nie ma podstaw do jego uwzględnienia. 
**§ 2.** Sąd ochrony konkurencji i konsumentów odrzuca odwołanie wniesione 
po upływie terminu do jego wniesienia, niedopuszczalne z innych przyczyn, a także 
wtedy, gdy nie uzupełniono w wyznaczonym terminie braków odwołania. 
**§ 3.** W razie 
uwzględnienia 
odwołania, 
sąd 
ochrony 
konkurencji 
i konsumentów zaskarżoną decyzję albo uchyla, albo zmienia w całości lub 
w części i orzeka co do istoty sprawy. Jednocześnie sąd stwierdza, czy zaskarżona 
decyzja została wydana bez podstawy prawnej albo z rażącym naruszeniem prawa. 
**§ 4.** W razie uwzględnienia odwołania od decyzji stwierdzającej naruszenie 
zakazów określonych w art. 6 ust. 1 pkt 1–6 ustawy z dnia 16 lutego 2007 r. 
o ochronie konkurencji i konsumentów lub w art. 101 ust. 1 lit. a–e Traktatu 
o funkcjonowaniu Unii Europejskiej, poprzez jej uchylenie w części dotyczącej 
przedsiębiorcy albo zmianę w taki sposób, że na przedsiębiorcę nie jest nakładana 
kara pieniężna, sąd ochrony konkurencji i konsumentów z urzędu uchyla tę decyzję 
- 15) Z dniem 30 listopada 2003 r. na podstawie pkt I 1 a oraz pkt II wyroku Trybunału Konstytucyjnego 
z dnia 12 czerwca 2002 r. sygn. akt P. 13/01 (Dz. U. poz. 764). 

 
 
 
s. 199/580 
 
2025-09-08 
 
również w części dotyczącej osoby zarządzającej, o której mowa w art. 6a tej 
ustawy, która dopuściła do naruszenia zakazów przez tego przedsiębiorcę. 
**§ 5.** W postępowaniu apelacyjnym i kasacyjnym przepis § 4 stosuje się 
odpowiednio.

***
## Art. 47932. {#kpc-pierwsza-pierwsza-art-47932}

**§ 1.** Zażalenie na postanowienie Prezesa Urzędu wnosi się do sądu 
ochrony konkurencji i konsumentów w terminie tygodnia od dnia doręczenia tego 
postanowienia. 
**§ 2.** Przepisy art. 47928 § 2 i § 3 oraz art. 47930 i art. 47931a stosuje się 
odpowiednio do zażaleń na postanowienia Prezesa Urzędu.

***
## Art. 47933. {#kpc-pierwsza-pierwsza-art-47933}

**§ 1.** W postępowaniu przed sądem ochrony konkurencji 
i konsumentów chroni się tajemnicę przedsiębiorstwa oraz inne tajemnice 
podlegające ochronie na podstawie odrębnych przepisów. 
**§ 2.** Sąd ochrony konkurencji i konsumentów może, w drodze postanowienia, 
ujawnić stronie postępowania sądowego informacje chronione w postępowaniu 
przed Prezesem Urzędu jako tajemnica przedsiębiorstwa drugiej strony tylko 
wtedy, gdy: 
- 1) zmieniły się istotnie okoliczności będące podstawą wydania przez Prezesa 
Urzędu postanowienia ograniczającego prawo wglądu do materiału 
dowodowego załączonego przez strony do akt sprawy; 
- 2) strona, której tajemnica przedsiębiorstwa jest chroniona, wyraziła zgodę. 
**§ 2a.** Do wykorzystania przez stronę informacji i dokumentów objętych 
ochroną na podstawie ustawy z dnia 16 lutego 2007 r. o ochronie konkurencji 
i konsumentów przepisy art. 70 ust. 1 i 2 tej ustawy stosuje się odpowiednio. 
**§ 2b.** (uchylony) 
**§ 3.** Sąd na wniosek strony lub z urzędu może, w drodze postanowienia, 
w niezbędnym zakresie ograniczyć pozostałym stronom prawo wglądu do 
materiału dowodowego załączonego przez strony do akt sprawy w toku 
postępowania sądowego, jeżeli udostępnienie tego materiału 
groziłoby 
ujawnieniem tajemnicy przedsiębiorstwa lub innych tajemnic podlegających 
ochronie na podstawie odrębnych przepisów. 
**§ 4.** Ograniczenie prawa wglądu do materiału dowodowego, o którym mowa 
w § 3, nie dotyczy Prezesa Urzędu. 

 
 
 
s. 200/580 
 
2025-09-08 
**§ 5.** Na postanowienie, o którym mowa w § 2 i 3, nie przysługuje zażalenie. 
**§ 6.** (uchylony)

***
## Art. 47934. {#kpc-pierwsza-pierwsza-art-47934}

(utracił moc)16)

***
## Art. 47934a. {#kpc-pierwsza-pierwsza-art-47934a}

Sąd rozpoznaje apelację w składzie jednego sędziego.

***
## Art. 47935. {#kpc-pierwsza-pierwsza-art-47935}

**§ 1.** (uchylony) 
**§ 2.** Skarga kasacyjna od orzeczenia sądu drugiej instancji przysługuje 
niezależnie od wartości przedmiotu zaskarżenia. 
DZIAŁ IVb 
(zawierający art. 47936–47944 – uchylony) 
[Art. 47945. § 1. Odpis prawomocnego wyroku uwzględniającego powództwo 
sąd przesyła Prezesowi Urzędu Ochrony Konkurencji i Konsumentów. 
**§ 2.** Prezes Urzędu Ochrony Konkurencji i Konsumentów prowadzi, na 
podstawie wyroków, o których mowa w § 1, rejestr postanowień wzorców umowy 
uznanych za niedozwolone. 
**§ 3.** Rejestr, o którym mowa w § 2, jest jawny. 
**§ 4.** Rada Ministrów określi, w drodze rozporządzenia, wzór rejestru 
postanowień wzorców umowy uznanych za niedozwolone.]  
#### DZIAŁ IVc
Postępowanie w sprawach z zakresu regulacji energetyki

***
## Art. 47946. {#kpc-pierwsza-pierwsza-art-47946}

Sąd Okręgowy w Warszawie – sąd ochrony konkurencji 
i konsumentów jest właściwy w sprawach: 
- 1) odwołań od decyzji Prezesa Urzędu Regulacji Energetyki, zwanego 
w przepisach niniejszego rozdziału „Prezesem Urzędu”; 
- 2) zażaleń na postanowienia wydawane przez Prezesa Urzędu w postępowaniach 
prowadzonych na podstawie przepisów ustawy z dnia 10 kwietnia 1997 r. – 
Prawo energetyczne (Dz. U. z 2024 r. poz. 266, 834 i 859) lub przepisów 
odrębnych. 
- 16) Z dniem 25 czerwca 2002 r. na podstawie pkt I 2 b wyroku Trybunału Konstytucyjnego, 
o którym mowa w odnośniku 15. 
Przepis 
uchylający 
art. 
47945 wejdzie w 
życie 
z 
dn. 
18.04.2026 r. (Dz. 
U. z 2015 r. poz. 
1634). 

 
 
 
s. 201/580 
 
2025-09-08

***
## Art. 47947. {#kpc-pierwsza-pierwsza-art-47947}

**§ 1.** Odwołanie od decyzji Prezesa Urzędu wnosi się za jego 
pośrednictwem do sądu ochrony konkurencji i konsumentów w terminie 
dwutygodniowym od dnia doręczenia decyzji. 
**§ 2.** Sąd ochrony konkurencji i konsumentów odrzuca odwołanie wniesione 
po upływie terminu do jego wniesienia, niedopuszczalne z innych przyczyn, a także 
wtedy, gdy nie uzupełniono w wyznaczonym terminie braków odwołania.

***
## Art. 47948. {#kpc-pierwsza-pierwsza-art-47948}

**§ 1.** Prezes Urzędu przekazuje niezwłocznie odwołanie wraz 
z aktami sprawy do sądu. 
**§ 2.** Jeżeli Prezes Urzędu uzna odwołanie za słuszne, może – nie przekazując 
akt sądowi – uchylić albo zmienić swoją decyzję w całości lub w części, o czym 
bezzwłocznie powiadamia stronę, przesyłając jej nową decyzję, od której stronie 
służy odwołanie.

***
## Art. 47949. {#kpc-pierwsza-pierwsza-art-47949}

Odwołanie od decyzji Prezesa Urzędu powinno czynić zadość 
wymaganiom przepisanym dla pisma procesowego oraz zawierać oznaczenie 
zaskarżonej decyzji i wartości przedmiotu sporu, przytoczenie zarzutów, zwięzłe 
ich uzasadnienie, wskazanie dowodów, a także zawierać wniosek o uchylenie albo 
zmianę decyzji w całości lub w części.

***
## Art. 47950. {#kpc-pierwsza-pierwsza-art-47950}

**§ 1.** W sprawach z zakresu regulacji energetyki stronami są także 
Prezes Urzędu i zainteresowany. 
**§ 2.** Zainteresowanym jest ten, czyje prawa lub obowiązki zależą od 
rozstrzygnięcia procesu. Jeżeli zainteresowany nie został wezwany do udziału 
w sprawie, sąd ochrony konkurencji i konsumentów wezwie go na wniosek strony 
albo z urzędu.

***
## Art. 47951. {#kpc-pierwsza-pierwsza-art-47951}

Pełnomocnikiem Prezesa Urzędu może być pracownik Urzędu 
Regulacji Energetyki.

***
## Art. 47952. {#kpc-pierwsza-pierwsza-art-47952}

W przypadku wniesienia odwołania od decyzji Prezesa Urzędu, 
sąd ochrony konkurencji i konsumentów może na wniosek strony, która wniosła 
odwołanie, wstrzymać wykonanie decyzji do czasu rozstrzygnięcia sprawy.

***
## Art. 47952a. {#kpc-pierwsza-pierwsza-art-47952a}

**§ 1.** W sprawach, o których mowa w art. 47946 pkt 1, strony 
mogą zawrzeć ugodę w sprawie odwołania do sądu ochrony konkurencji 
i konsumentów. 

 
 
 
s. 202/580 
 
2025-09-08 
**§ 2.** W sprawach, o których mowa w art. 47946 pkt 1, stosuje się odpowiednio 
przepisy art. 47930 § 2 i art. 47930a–47930f.

***
## Art. 47953. {#kpc-pierwsza-pierwsza-art-47953}

**§ 1.** Sąd ochrony konkurencji i konsumentów oddala odwołanie 
od decyzji Prezesa Urzędu, jeżeli nie ma podstaw do jego uwzględnienia. 
**§ 2.** W razie 
uwzględnienia 
odwołania, 
sąd 
ochrony 
konkurencji 
i konsumentów zaskarżoną decyzję albo uchyla, albo zmienia w całości lub 
w części i orzeka co do istoty sprawy.

***
## Art. 47954. {#kpc-pierwsza-pierwsza-art-47954}

(uchylony)

***
## Art. 47955. {#kpc-pierwsza-pierwsza-art-47955}

Przepisy art. 47932 § 1 i art. 47947–47953 stosuje się odpowiednio 
do zażaleń na postanowienia Prezesa Urzędu.

***
## Art. 47955a. {#kpc-pierwsza-pierwsza-art-47955a}

Sąd rozpoznaje apelację w składzie jednego sędziego.

***
## Art. 47956. {#kpc-pierwsza-pierwsza-art-47956}

**§ 1.** (uchylony) 
**§ 2.** Skarga kasacyjna od orzeczenia sądu drugiej instancji przysługuje 
niezależnie od wartości przedmiotu zaskarżenia. 
DZIAŁ IVd 
Postępowanie w sprawach z zakresu regulacji  
komunikacji elektronicznej i poczty

***
## Art. 47957. {#kpc-pierwsza-pierwsza-art-47957}

Sąd Okręgowy w Warszawie – sąd ochrony konkurencji 
i konsumentów jest właściwy w sprawach: 
- 1) odwołań od decyzji Prezesa Urzędu Komunikacji Elektronicznej, zwanego 
w przepisach niniejszego rozdziału „Prezesem Urzędu”; 
- 2) zażaleń na postanowienia wydawane przez Prezesa Urzędu w postępowaniach 
prowadzonych na podstawie przepisów ustawy z dnia 12 lipca 2024 r. – Prawo 
komunikacji elektronicznej (Dz. U. poz. 1221), ustawy z dnia 23 listopada 
2012 r. – Prawo pocztowe lub przepisów odrębnych.

***
## Art. 47958. {#kpc-pierwsza-pierwsza-art-47958}

**§ 1.** Odwołanie od decyzji Prezesa Urzędu wnosi się za jego 
pośrednictwem do sądu ochrony konkurencji i konsumentów w terminie miesiąca 
od dnia doręczenia decyzji. 

 
 
 
s. 203/580 
 
2025-09-08 
**§ 2.** Sąd ochrony konkurencji i konsumentów odrzuca odwołanie wniesione 
po upływie terminu do jego wniesienia, niedopuszczalne z innych przyczyn, a także 
wtedy, gdy nie uzupełniono w wyznaczonym terminie braków odwołania.

***
## Art. 47959. {#kpc-pierwsza-pierwsza-art-47959}

**§ 1.** Prezes Urzędu przekazuje niezwłocznie odwołanie wraz 
z aktami sprawy do sądu. 
**§ 2.** Jeżeli Prezes Urzędu uzna odwołanie za słuszne, może – nie przekazując 
akt sądowi – uchylić albo zmienić swoją decyzję w całości lub w części, o czym 
bezzwłocznie powiadamia stronę, przesyłając jej nową decyzję, od której stronie 
służy odwołanie.

***
## Art. 47960. {#kpc-pierwsza-pierwsza-art-47960}

Odwołanie od decyzji Prezesa Urzędu powinno czynić zadość 
wymaganiom przepisanym dla pisma procesowego oraz zawierać oznaczenie 
zaskarżonej decyzji i wartości przedmiotu sporu, przytoczenie zarzutów, zwięzłe 
ich uzasadnienie, wskazanie dowodów, a także zawierać wniosek o uchylenie albo 
zmianę decyzji w całości lub w części.

***
## Art. 47961. {#kpc-pierwsza-pierwsza-art-47961}

**§ 1.** W sprawach z zakresu regulacji komunikacji elektronicznej 
i poczty stronami są także Prezes Urzędu i zainteresowany. 
**§ 2.** Zainteresowanym jest ten, czyje prawa lub obowiązki zależą od 
rozstrzygnięcia procesu oraz ten, kto uczestniczył w postępowaniu przed Prezesem 
Urzędu na prawach strony. Jeżeli zainteresowany nie został wezwany do udziału 
w sprawie, sąd ochrony konkurencji i konsumentów wezwie go na wniosek strony 
albo z urzędu.

***
## Art. 47962. {#kpc-pierwsza-pierwsza-art-47962}

Pełnomocnikiem Prezesa Urzędu może być pracownik Urzędu 
Komunikacji Elektronicznej.

***
## Art. 47963. {#kpc-pierwsza-pierwsza-art-47963}

W przypadku wniesienia odwołania od decyzji Prezesa Urzędu, 
sąd ochrony konkurencji i konsumentów może na wniosek strony, która wniosła 
odwołanie, wstrzymać do czasu rozstrzygnięcia sprawy wykonanie decyzji, jeżeli 
zachodzi niebezpieczeństwo wyrządzenia znacznej szkody lub spowodowania 
trudnych do odwrócenia skutków.

***
## Art. 47963a. {#kpc-pierwsza-pierwsza-art-47963a}

**§ 1.** W sprawach, o których mowa w art. 47957 pkt 1, strony 
mogą zawrzeć ugodę w sprawie odwołania do sądu ochrony konkurencji 
i konsumentów. 

 
 
 
s. 204/580 
 
2025-09-08 
**§ 2.** W sprawach, o których mowa w art. 47957 pkt 1, stosuje się odpowiednio 
przepisy art. 47930 § 2 i art. 47930a–47930f.

***
## Art. 47964. {#kpc-pierwsza-pierwsza-art-47964}

**§ 1.** Sąd ochrony konkurencji i konsumentów oddala odwołanie 
od decyzji Prezesa Urzędu, jeżeli nie ma podstaw do jego uwzględnienia. 
**§ 2.** W razie 
uwzględnienia 
odwołania, 
sąd 
ochrony 
konkurencji 
i konsumentów zaskarżoną decyzję albo uchyla, albo zmienia w całości lub 
w części i orzeka co do istoty sprawy.

***
## Art. 47965. {#kpc-pierwsza-pierwsza-art-47965}

(uchylony)

***
## Art. 47966. {#kpc-pierwsza-pierwsza-art-47966}

Przepisy art. 47932 § 1 i art. 47958–47964 stosuje się odpowiednio 
do zażaleń na postanowienia Prezesa Urzędu.

***
## Art. 47966a. {#kpc-pierwsza-pierwsza-art-47966a}

W postępowaniu w sprawach z zakresu regulacji komunikacji 
elektronicznej i poczty przepisy art. 47933 stosuje się odpowiednio.

***
## Art. 47966b. {#kpc-pierwsza-pierwsza-art-47966b}

Sąd rozpoznaje apelację w składzie jednego sędziego.

***
## Art. 47967. {#kpc-pierwsza-pierwsza-art-47967}

**§ 1.** (uchylony) 
**§ 2.** Skarga kasacyjna od orzeczenia sądu drugiej instancji przysługuje 
niezależnie od wartości przedmiotu zaskarżenia. 
DZIAŁ IVe 
Postępowanie w sprawach z zakresu regulacji transportu kolejowego

***
## Art. 47968. {#kpc-pierwsza-pierwsza-art-47968}

Sąd Okręgowy w Warszawie – sąd ochrony konkurencji 
i konsumentów jest właściwy w sprawach: 
- 1) odwołań od decyzji Prezesa Urzędu Transportu Kolejowego, zwanego 
w przepisach niniejszego rozdziału „Prezesem Urzędu”; 
- 2) zażaleń na postanowienia wydawane przez Prezesa Urzędu w postępowaniach 
prowadzonych na podstawie przepisów ustawy z dnia 28 marca 2003 r. o 
transporcie kolejowym (Dz. U. z 2024 r. poz. 697 i 731) lub przepisów 
odrębnych.

***
## Art. 47969. {#kpc-pierwsza-pierwsza-art-47969}

**§ 1.** Odwołanie od decyzji Prezesa Urzędu wnosi się za jego 
pośrednictwem do sądu ochrony konkurencji i konsumentów w terminie 
dwutygodniowym od dnia doręczenia decyzji. 

 
 
 
s. 205/580 
 
2025-09-08 
**§ 2.** Sąd ochrony konkurencji i konsumentów odrzuca odwołanie wniesione 
po upływie terminu do jego wniesienia, niedopuszczalne z innych przyczyn, a także 
wtedy, gdy nie uzupełniono w wyznaczonym terminie braków odwołania.

***
## Art. 47970. {#kpc-pierwsza-pierwsza-art-47970}

**§ 1.** Prezes Urzędu przekazuje niezwłocznie odwołanie wraz 
z aktami sprawy do sądu. 
**§ 2.** Jeżeli Prezes Urzędu uzna odwołanie za słuszne, może – nie przekazując 
akt sądowi – uchylić albo zmienić swoją decyzję w całości lub w części, o czym 
bezzwłocznie powiadamia stronę, przesyłając jej nową decyzję, od której stronie 
służy odwołanie.

***
## Art. 47971. {#kpc-pierwsza-pierwsza-art-47971}

Odwołanie od decyzji Prezesa Urzędu powinno czynić zadość 
wymaganiom przepisanym dla pisma procesowego oraz zawierać oznaczenie 
zaskarżonej decyzji i wartości przedmiotu sporu, przytoczenie zarzutów, zwięzłe 
ich uzasadnienie, wskazanie dowodów, a także zawierać wniosek o uchylenie albo 
zmianę decyzji w całości lub w części.

***
## Art. 47972. {#kpc-pierwsza-pierwsza-art-47972}

**§ 1.** W sprawach z zakresu regulacji transportu kolejowego 
stronami są także Prezes Urzędu i zainteresowany. 
**§ 2.** Zainteresowanym jest ten, czyje prawa lub obowiązki zależą od 
rozstrzygnięcia procesu. Jeżeli zainteresowany nie został wezwany do udziału 
w sprawie, sąd ochrony konkurencji i konsumentów wezwie go na wniosek strony 
albo z urzędu.

***
## Art. 47973. {#kpc-pierwsza-pierwsza-art-47973}

Pełnomocnikiem Prezesa Urzędu może być pracownik Urzędu 
Transportu Kolejowego.

***
## Art. 47974. {#kpc-pierwsza-pierwsza-art-47974}

W przypadku wniesienia odwołania od decyzji Prezesa Urzędu, 
sąd ochrony konkurencji i konsumentów może na wniosek strony, która wniosła 
odwołanie, wstrzymać wykonanie decyzji do czasu rozstrzygnięcia sprawy.

***
## Art. 47974a. {#kpc-pierwsza-pierwsza-art-47974a}

**§ 1.** W sprawach, o których mowa w art. 47968 pkt 1, strony 
mogą zawrzeć ugodę w sprawie odwołania do sądu ochrony konkurencji 
i konsumentów. 
**§ 2.** W sprawach, o których mowa w art. 47968 pkt 1, stosuje się odpowiednio 
przepisy art. 47930 § 2 i art. 47930a–47930e. 

 
 
 
s. 206/580 
 
2025-09-08

***
## Art. 47975. {#kpc-pierwsza-pierwsza-art-47975}

**§ 1.** Sąd ochrony konkurencji i konsumentów oddala odwołanie 
od decyzji Prezesa Urzędu, jeżeli nie ma podstaw do jego uwzględnienia. 
**§ 2.** W razie 
uwzględnienia 
odwołania, 
sąd 
ochrony 
konkurencji 
i konsumentów zaskarżoną decyzję albo uchyla, albo zmienia w całości lub 
w części i orzeka co do istoty sprawy.

***
## Art. 47976. {#kpc-pierwsza-pierwsza-art-47976}

(uchylony)

***
## Art. 47977. {#kpc-pierwsza-pierwsza-art-47977}

Przepisy art. 47932 § 1 i art. 47969–47975 stosuje się odpowiednio 
do zażaleń na postanowienia Prezesa Urzędu.

***
## Art. 47977a. {#kpc-pierwsza-pierwsza-art-47977a}

W postępowaniach w sprawach z zakresu regulacji transportu 
kolejowego stosuje się przepisy art. 47933 § 1, 2 oraz 3–5.

***
## Art. 47977b. {#kpc-pierwsza-pierwsza-art-47977b}

Sąd rozpoznaje apelację w składzie jednego sędziego.

***
## Art. 47978. {#kpc-pierwsza-pierwsza-art-47978}

**§ 1.** (uchylony) 
**§ 2.** Skarga kasacyjna od orzeczenia sądu drugiej instancji przysługuje 
niezależnie od wartości przedmiotu zaskarżenia. 
DZIAŁ IVf 
Postępowanie w sprawach z zakresu regulacji rynku wodno-kanalizacyjnego

***
## Art. 47979. {#kpc-pierwsza-pierwsza-art-47979}

Sąd Okręgowy w Warszawie – sąd ochrony konkurencji i 
konsumentów jest właściwy w sprawach: 
- 1) odwołań od decyzji, o których mowa w art. 27e ust. 1 ustawy z dnia 7 czerwca 
2001 r. o zbiorowym zaopatrzeniu w wodę i zbiorowym odprowadzaniu 
ścieków (Dz. U. z 2024 r. poz. 757), organu regulacyjnego, o którym mowa 
w art. 27a ust. 1 tej ustawy, zwanego w przepisach niniejszego działu 
„organem regulacyjnym”; 
- 2) zażaleń na postanowienia organu regulacyjnego, o których mowa w art. 27e 
ust. 3 ustawy, o której mowa w pkt 1.

***
## Art. 47980. {#kpc-pierwsza-pierwsza-art-47980}

**§ 1.** Odwołanie od decyzji organu regulacyjnego wnosi się, za jego 
pośrednictwem, do sądu ochrony konkurencji i konsumentów w terminie 14 dni od 
dnia doręczenia decyzji. 

 
 
 
s. 207/580 
 
2025-09-08 
**§ 2.** Sąd ochrony konkurencji i konsumentów odrzuca odwołanie wniesione 
po upływie terminu do jego wniesienia, niedopuszczalne z innych przyczyn, a także 
wtedy, gdy nie uzupełniono w wyznaczonym terminie braków odwołania.

***
## Art. 47981. {#kpc-pierwsza-pierwsza-art-47981}

**§ 1.** Organ regulacyjny niezwłocznie przekazuje odwołanie wraz 
z aktami sprawy do sądu. 
**§ 2.** Jeżeli organ regulacyjny uwzględni odwołanie w całości, może – nie 
przekazując akt sądowi – wydać nową decyzję, w której uchyla lub zmienia swoją 
decyzję, o czym bezzwłocznie powiadamia stronę, przesyłając jej nową decyzję, od 
której stronie służy odwołanie.

***
## Art. 47982. {#kpc-pierwsza-pierwsza-art-47982}

Odwołanie od decyzji organu regulacyjnego powinno czynić 
zadość wymaganiom przepisanym dla pisma procesowego oraz zawierać 
oznaczenie zaskarżonej decyzji i wartości przedmiotu sporu, przytoczenie 
zarzutów, zwięzłe ich uzasadnienie, wskazanie dowodów, a także wniosek o 
uchylenie albo zmianę decyzji w całości lub w części.

***
## Art. 47983. {#kpc-pierwsza-pierwsza-art-47983}

W sprawach z zakresu regulacji rynku wodno-kanalizacyjnego 
stronami są także organ regulacyjny oraz podmioty będące stroną w postępowaniu 
przed tym organem.

***
## Art. 47984. {#kpc-pierwsza-pierwsza-art-47984}

Pełnomocnikiem organu regulacyjnego może być pracownik 
Krajowego Zarządu Gospodarki Wodnej Państwowego Gospodarstwa Wodnego 
Wody Polskie lub pracownik regionalnego zarządu gospodarki wodnej 
Państwowego Gospodarstwa Wodnego Wody Polskie.

***
## Art. 47985. {#kpc-pierwsza-pierwsza-art-47985}

W razie wniesienia odwołania od decyzji organu regulacyjnego 
sąd ochrony konkurencji i konsumentów może na wniosek strony, która wniosła 
odwołanie, wstrzymać wykonanie decyzji do czasu rozstrzygnięcia sprawy.

***
## Art. 47985a. {#kpc-pierwsza-pierwsza-art-47985a}

**§ 1.** W sprawach, o których mowa w art. 47979 pkt 1, strony 
mogą zawrzeć ugodę w sprawie odwołania do sądu ochrony konkurencji 
i konsumentów. 
**§ 2.** W sprawach, o których mowa w art. 47979 pkt 1, stosuje się odpowiednio 
przepisy art. 47930 § 2 i art. 47930a–47930f.

***
## Art. 47986. {#kpc-pierwsza-pierwsza-art-47986}

**§ 1.** Sąd ochrony konkurencji i konsumentów oddala odwołanie 
od decyzji organu regulacyjnego, jeżeli nie ma podstaw do jego uwzględnienia. 

 
 
 
s. 208/580 
 
2025-09-08 
**§ 2.** W razie uwzględnienia odwołania sąd ochrony konkurencji i 
konsumentów uchyla albo zmienia w całości lub w części zaskarżoną decyzję i 
orzeka co do istoty sprawy.

***
## Art. 47987. {#kpc-pierwsza-pierwsza-art-47987}

**§ 1.** Zażalenie na postanowienie organu regulacyjnego wnosi się 
do sądu ochrony konkurencji i konsumentów w terminie 7 dni od dnia doręczenia 
tego postanowienia. 
**§ 2.** Przepisy art. 47931a § 4 i 5 i art. 47980–47986 stosuje się odpowiednio do 
zażaleń na postanowienia organu regulacyjnego.

***
## Art. 47987a. {#kpc-pierwsza-pierwsza-art-47987a}

Sąd rozpoznaje apelację w składzie jednego sędziego.

***
## Art. 47988. {#kpc-pierwsza-pierwsza-art-47988}

Skarga kasacyjna od orzeczenia sądu drugiej instancji przysługuje 
niezależnie od wartości przedmiotu zaskarżenia. 
DZIAŁ IVg 
Postępowanie w sprawach własności intelektualnej 
Rozdział 1 
Przepisy ogólne

***
## Art. 47989. {#kpc-pierwsza-pierwsza-art-47989}

**§ 1.** Przepisy niniejszego działu stosuje się w sprawach o ochronę 
praw autorskich i pokrewnych, o ochronę praw własności przemysłowej oraz 
o ochronę 
innych 
praw 
na dobrach 
niematerialnych 
(sprawy 
własności 
intelektualnej). 
**§ 2.** Sprawami własności intelektualnej w rozumieniu niniejszego działu są 
także sprawy o: 
- 1) zapobieganie i zwalczanie nieuczciwej konkurencji; 
- 2) ochronę dóbr osobistych w zakresie, w jakim dotyczy ona wykorzystania 
dobra 
osobistego 
w celu 
indywidualizacji, 
reklamy 
lub 
promocji 
przedsiębiorcy, towarów lub usług; 
- 3) ochronę dóbr osobistych w związku z działalnością naukową lub wynalazczą.

***
## Art. 47990. {#kpc-pierwsza-pierwsza-art-47990}

**§ 1.** Sprawy własności intelektualnej należą do właściwości sądów 
okręgowych. 
**§ 2.** Sąd Okręgowy w Warszawie jest wyłącznie właściwy w sprawach 
własności intelektualnej dotyczących programów komputerowych, wynalazków, 

 
 
 
s. 209/580 
 
2025-09-08 
 
wzorów użytkowych, topografii układów scalonych, odmian roślin oraz tajemnic 
przedsiębiorstwa o charakterze technicznym. 
**§ 3.** Sąd rozpoznaje apelację w składzie jednego sędziego.

***
## Art. 47991. {#kpc-pierwsza-pierwsza-art-47991}

W sprawach rozpoznawanych według przepisów niniejszego 
działu przepisy o innych postępowaniach odrębnych stosuje się w zakresie, 
w którym nie są one sprzeczne z przepisami niniejszego działu.

***
## Art. 47992. {#kpc-pierwsza-pierwsza-art-47992}

**§ 1.** Sąd właściwy w sprawie własności intelektualnej nie jest 
związany postanowieniem o przekazaniu sprawy. Sąd ten w razie stwierdzenia 
swojej niewłaściwości przekaże sprawę innemu sądowi, nie wyłączając sądu 
przekazującego. 
**§ 2.** Postanowienie o przekazaniu sprawy może zapaść nie później niż 
w terminie dwóch tygodni od dnia wpływu przekazanej sprawy do sądu właściwego 
w sprawie własności intelektualnej. 
**§ 3.** Sąd, któremu sprawa zostanie przekazana, jest związany postanowieniem 
sądu właściwego w sprawie własności intelektualnej.

***
## Art. 47993. {#kpc-pierwsza-pierwsza-art-47993}

Jeżeli w sprawie o naruszenie sąd uzna, że ścisłe udowodnienie 
wysokości żądania jest niemożliwe, nader utrudnione lub oczywiście niecelowe, 
może w wyroku zasądzić odpowiednią sumę według swojej oceny opartej na roz-
ważeniu wszystkich okoliczności sprawy.

***
## Art. 47994. {#kpc-pierwsza-pierwsza-art-47994}

Ilekroć w przepisach niniejszego działu jest mowa o naruszeniu, 
należy przez to rozumieć także zagrożenie tym naruszeniem.

***
## Art. 47995. {#kpc-pierwsza-pierwsza-art-47995}

Stosując środki przewidziane w art. 47997, art. 479109 lub 
art. 479113 § 1, sąd uwzględni interesy stron w takiej mierze, aby uprawnionemu 
zapewnić należytą ochronę prawną, a obowiązanego lub pozwanego nie obciążać 
ponad potrzebę, mając na uwadze obciążenia obowiązanego lub pozwanego, jakie 
wynikałyby z zastosowanych środków, oraz ochronę tajemnicy przedsiębiorstwa. 
Rozdział 2 
Zabezpieczenie środka dowodowego

***
## Art. 47996. {#kpc-pierwsza-pierwsza-art-47996}

Przepisy dotyczące obowiązanego stosuje się do osoby, w tym 
również pozwanego, w której władaniu znajduje się środek dowodowy lub która 
może umożliwić jego zabezpieczenie. 

 
 
 
s. 210/580 
 
2025-09-08

***
## Art. 47997. {#kpc-pierwsza-pierwsza-art-47997}

**§ 1.** Sąd może udzielić zabezpieczenia środka dowodowego przed 
wszczęciem postępowania lub w jego toku aż do zamknięcia rozprawy w pierwszej 
instancji. 
**§ 2.** Wniosek o zabezpieczenie środka dowodowego sąd rozpoznaje 
bezzwłocznie, nie później jednak niż w terminie tygodnia od dnia jego wpływu.

***
## Art. 47998. {#kpc-pierwsza-pierwsza-art-47998}

**§ 1.** Sąd udziela zabezpieczenia środka dowodowego na wniosek 
uprawnionego, który uprawdopodobnił roszczenie, jak również interes prawny 
w zabezpieczeniu. 
**§ 2.** Interes prawny w zabezpieczeniu środka dowodowego istnieje, gdy brak 
żądanego zabezpieczenia uniemożliwia lub poważnie utrudnia przytoczenie lub 
udowodnienie istotnych faktów, jak również, gdy zachodzi ryzyko zniszczenia 
środka dowodowego lub opóźnienie w uzyskaniu środka dowodowego może 
uniemożliwić lub poważnie utrudnić osiągnięcie celu postępowania dowodowego, 
lub gdy z innych przyczyn zachodzi potrzeba stwierdzenia istniejącego stanu 
rzeczy.

***
## Art. 47999. {#kpc-pierwsza-pierwsza-art-47999}

Wniosek 
o zabezpieczenie 
środka 
dowodowego 
powinien 
odpowiadać wymaganiom przepisanym dla pisma procesowego, a ponadto 
zawierać: 
- 1) określenie środka dowodowego i sposobu jego zabezpieczenia; 
- 2) uprawdopodobnienie okoliczności uzasadniających wniosek; 
- 3) zwięzłe przedstawienie przedmiotu sprawy, gdy wniosek jest składany przed 
złożeniem pozwu.

***
## Art. 479100. {#kpc-pierwsza-pierwsza-art-479100}

**§ 1.** Sąd wydaje postanowienie w przedmiocie zabezpieczenia 
środka dowodowego na posiedzeniu niejawnym. 
**§ 2.** W postanowieniu o zabezpieczeniu środka dowodowego sąd określa 
zakres wglądu uprawnionego do zabezpieczonego środka dowodowego oraz 
szczegółowe zasady korzystania i zapoznawania się z nim. Sąd może ograniczyć 
lub wyłączyć kopiowanie środka dowodowego lub jego utrwalanie w inny sposób. 
Uprawniony uzyskuje dostęp do środka dowodowego wraz z uprawomocnieniem 
się postanowienia. 
**§ 3.** Postanowienie o zabezpieczeniu środka dowodowego sąd doręcza 
uprawnionemu. 
Podmiot 
wykonujący 
postanowienie 
równocześnie 

 
 
 
s. 211/580 
 
2025-09-08 
 
z przystąpieniem do wykonania postanowienia dokonuje jego doręczenia 
obowiązanemu oraz pozwanemu. Sąd poucza obowiązanego, pozwanego oraz 
biegłego o ochronie tajemnicy przedsiębiorstwa. 
**§ 4.** Na postanowienie w przedmiocie zabezpieczenia środka dowodowego 
przysługuje zażalenie do sądu drugiej instancji. 
**§ 5.** Zażalenie w przedmiocie zabezpieczenia środka dowodowego sąd 
rozpoznaje bezzwłocznie, nie później jednak niż w terminie miesiąca od dnia jego 
wpływu. 
**§ 6.** Zażalenie obowiązanego lub pozwanego w zakresie, w jakim powołuje 
się na ochronę tajemnicy przedsiębiorstwa, sąd rozpoznaje na posiedzeniu 
niejawnym. Od uznania sądu zależy, czy na posiedzeniu wysłucha uprawnionego 
lub obowiązanego. 
**§ 7.** Uwzględniając zażalenie obowiązanego lub pozwanego powołującego się 
na ochronę tajemnicy przedsiębiorstwa, sąd określa odrębne względem 
oznaczonych na podstawie § 2 zasady korzystania z zabezpieczonego środka 
dowodowego i zapoznawania się z nim przez uprawnionego oraz może 
wprowadzić dodatkowe ograniczenia. 
**§ 8.** W przypadku prawomocnego oddalenia wniosku o zabezpieczenie 
środka dowodowego zabezpieczenie upada. Sąd, na wniosek obowiązanego, 
wydaje postanowienie stwierdzające upadek zabezpieczenia, na podstawie którego 
obowiązany odbiera środki dowodowe złożone w sądzie.

***
## Art. 479101. {#kpc-pierwsza-pierwsza-art-479101}

**§ 1.** Sąd orzeka taki sposób zabezpieczenia środka dowodowego, 
jaki stosownie do okoliczności danej sprawy uzna za odpowiedni. Sposobami 
zabezpieczenia są w szczególności odebranie towarów, materiałów, narzędzi 
użytych do produkcji lub dystrybucji, dokumentów, jak również sporządzenie 
szczegółowego opisu tych przedmiotów połączone, w razie konieczności, 
z pobraniem ich próbek. 
**§ 2.** W przypadku orzeczenia sposobu zabezpieczenia środka dowodowego 
w postaci sporządzenia szczegółowego opisu komornik sporządza protokół. 
**§ 3.** Na wniosek uprawnionego, obowiązanego lub pozwanego sąd może 
wezwać biegłego, aby wziął udział w wykonaniu postanowienia o zabezpieczeniu 
środka dowodowego. 

 
 
 
s. 212/580 
 
2025-09-08 
**§ 4.** Komornik odbiera przedmioty oraz sporządza protokół bez udziału 
uprawnionego. Przepis art. 814 stosuje się odpowiednio. Odebrane przedmioty oraz 
protokół komornik składa w sądzie. Nie podlegają one włączeniu do akt do dnia 
uprawomocnienia się postanowienia o zabezpieczeniu środka dowodowego.

***
## Art. 479102. {#kpc-pierwsza-pierwsza-art-479102}

Udzielając 
zabezpieczenia 
środka 
dowodowego 
przed 
wszczęciem postępowania, sąd wyznacza termin, w którym pozew powinien być 
wniesiony pod rygorem upadku zabezpieczenia. Termin ten nie może być krótszy 
niż dwa tygodnie i dłuższy niż miesiąc od dnia uprawomocnienia się postanowienia 
o zabezpieczeniu środka dowodowego.

***
## Art. 479103. {#kpc-pierwsza-pierwsza-art-479103}

Postanowienie o zabezpieczeniu środka dowodowego podlega 
wykonaniu z chwilą jego wydania. Przepis art. 743 stosuje się odpowiednio.

***
## Art. 479104. {#kpc-pierwsza-pierwsza-art-479104}

Wykonanie 
postanowienia 
o zabezpieczeniu 
środka 
dowodowego sąd może uzależnić od złożenia przez uprawnionego kaucji na 
zabezpieczenie roszczeń obowiązanego lub pozwanego powstałych w wyniku 
wykonania tego postanowienia. Z kaucji tej przysługuje obowiązanemu lub 
pozwanemu pierwszeństwo zaspokojenia przed innymi należnościami zaraz po 
kosztach egzekucyjnych. Przepis art. 739 § 2 stosuje się odpowiednio.

***
## Art. 479105. {#kpc-pierwsza-pierwsza-art-479105}

W zakresie 
nieuregulowanym 
w niniejszym 
rozdziale 
do 
zabezpieczenia środka dowodowego przepisy art. 738, art. 742 § 1 zdanie 
pierwsze, § 2 i 3 oraz art. 744–746 stosuje się odpowiednio. Z żądaniem, o którym 
mowa w art. 742, może wystąpić również pozwany. 
Rozdział 3 
Wyjawienie lub wydanie środka dowodowego

***
## Art. 479106. {#kpc-pierwsza-pierwsza-art-479106}

W sprawie o naruszenie prawa własności intelektualnej powód, 
który uprawdopodobnił roszczenie, może żądać, aby pozwany wyjawił lub wydał 
środek dowodowy, którym dysponuje, w szczególności dokumenty bankowe, 
finansowe lub handlowe, służące ujawnieniu i udowodnieniu faktów.

***
## Art. 479107. {#kpc-pierwsza-pierwsza-art-479107}

Wniosek o wyjawienie lub wydanie środka dowodowego 
powinien odpowiadać wymaganiom przepisanym dla pisma procesowego, 
a ponadto zawierać: 

 
 
 
s. 213/580 
 
2025-09-08 
- 1) określenie środka dowodowego, którego wyjawienia lub wydania żąda 
powód; 
- 2) uprawdopodobnienie 
okoliczności 
uzasadniających 
wniosek, 
w tym 
okoliczności, 
z których 
wynika, 
że 
pozwany 
dysponuje 
środkiem 
dowodowym objętym żądaniem.

***
## Art. 479108. {#kpc-pierwsza-pierwsza-art-479108}

Przed wyznaczeniem posiedzenia przewodniczący zarządza 
wniesienie przez pozwanego odpowiedzi na zgłoszone żądanie w terminie nie 
krótszym niż dwa tygodnie, pouczając go o ochronie tajemnicy przedsiębiorstwa.

***
## Art. 479109. {#kpc-pierwsza-pierwsza-art-479109}

**§ 1.** Uwzględniając żądanie, sąd określa termin wyjawienia lub 
wydania środka dowodowego, zasady korzystania z niego i zapoznawania się 
z nim, a także poucza strony o ochronie tajemnicy przedsiębiorstwa. Jeżeli 
pozwany powołuje się na ochronę tajemnicy przedsiębiorstwa, sąd może określić 
szczególne zasady korzystania ze środka dowodowego i zapoznawania się z nim 
oraz może wprowadzić dodatkowe ograniczenia. 
**§ 2.** Postanowienie nakazujące wyjawienie lub wydanie środka dowodowego 
podlega wykonaniu z chwilą jego wydania. Przepis art. 743 stosuje się 
odpowiednio. 
**§ 3.** Jeżeli pozwany uchyla się od wykonania postanowienia nakazującego 
wyjawienie lub wydanie środka dowodowego lub dopuszcza się zniszczenia 
takiego środka w celu udaremnienia jego wyjawienia lub wydania, sąd może: 
- 1) uznać za ustalone fakty, które mają zostać stwierdzone za pomocą tego środka, 
chyba że pozwany, który uchyla się od wykonania postanowienia 
nakazującego wyjawienie lub wydanie środka dowodowego lub dopuszcza się 
zniszczenia takiego środka, wykaże co innego; 
- 2) obciążyć pozwanego obowiązkiem zwrotu kosztów postępowania, w całości 
lub części, niezależnie od wyniku sprawy.

***
## Art. 479110. {#kpc-pierwsza-pierwsza-art-479110}

**§ 1.** Na postanowienie w przedmiocie wyjawienia lub wydania 
środka dowodowego służy zażalenie do sądu drugiej instancji. 
**§ 2.** Zażalenie pozwanego w zakresie, w jakim powołuje się na ochronę 
tajemnicy przedsiębiorstwa, sąd rozpoznaje na posiedzeniu niejawnym. Od uznania 
sądu zależy, czy na posiedzeniu wysłucha jedną czy więcej niż jedną stronę. 

 
 
 
s. 214/580 
 
2025-09-08

***
## Art. 479111. {#kpc-pierwsza-pierwsza-art-479111}

Gdy wyjawienie lub wydanie środka dowodowego dotyczy 
dokumentów 
bankowych, 
handlowych 
lub 
finansowych, 
przepis 
art. 249 § 2 stosuje się odpowiednio. 
Rozdział 4 
Wezwanie do udzielenia informacji

***
## Art. 479112. {#kpc-pierwsza-pierwsza-art-479112}

Przepisy dotyczące obowiązanego stosuje się do osoby, w tym 
również pozwanego, która posiada informacje, o których mowa w art. 479113, lub 
dostęp do nich.

***
## Art. 479113. {#kpc-pierwsza-pierwsza-art-479113}

**§ 1.** Na wniosek uprawnionego, jeżeli wykaże on w sposób 
wiarygodny okoliczności wskazujące na naruszenie, sąd może przed wszczęciem 
postępowania w sprawie o naruszenie lub w jego toku aż do zamknięcia rozprawy 
w pierwszej 
instancji 
wezwać 
naruszającego 
do 
udzielenia 
informacji 
o pochodzeniu i sieciach dystrybucji towarów lub usług, jeżeli jest to niezbędne dla 
dochodzenia roszczenia. 
**§ 2.** Jeżeli sąd wezwał do udzielenia informacji przed wszczęciem 
postępowania w sprawie o naruszenie, postępowanie to powinno być wszczęte nie 
później niż w terminie miesiąca od dnia wykonania postanowienia o udzieleniu 
informacji. 
**§ 3.** Obowiązanemu 
przysługuje 
roszczenie 
o naprawienie 
szkody 
wyrządzonej wykonaniem obowiązku udzielenia informacji, jeżeli uprawniony nie 
wniósł pisma wszczynającego postępowanie przeciwko naruszającemu w terminie 
wyznaczonym przez sąd albo pismo wszczynające postępowanie zostało cofnięte, 
jak również gdy pismo wszczynające postępowanie zostało zwrócone lub 
odrzucone albo powództwo bądź wniosek oddalono lub postępowanie umorzono. 
**§ 4.** Roszczenie, o którym mowa w § 3, wygasa, jeżeli nie będzie dochodzone 
w ciągu roku od dnia jego powstania. Przepisy art. 746 § 11–3 stosuje się 
odpowiednio. 
**§ 5.** Obowiązanemu 
przysługuje 
roszczenie 
o naprawienie 
szkody 
wyrządzonej wykonaniem obowiązku udzielenia informacji w przypadku 
wykorzystania przez uprawnionego informacji, o której mowa w ust. 1, dla celów 
innych niż dochodzenie przez uprawnionego roszczenia. 

 
 
 
s. 215/580 
 
2025-09-08 
**§ 6.** Do wniosku, o którym mowa w § 1, przepisy art. 739, art. 742 oraz 
art. 745 stosuje się odpowiednio.

***
## Art. 479114. {#kpc-pierwsza-pierwsza-art-479114}

Przepis art. 479113 stosuje się odpowiednio do innego niż 
naruszający obowiązanego, który: 
- 1) posiada w ilości świadczącej o faktycznym prowadzeniu działalności 
gospodarczej towary, przy których zaprojektowaniu, wytworzeniu lub 
wprowadzeniu do obrotu nastąpiło naruszenie prawa własności intelektualnej 
lub których cechy estetyczne lub funkcjonalne naruszają te prawa lub 
- 2) dostarcza, w rozmiarze świadczącym o faktycznym prowadzeniu działalności 
gospodarczej, usługi osobie, która narusza prawa własności intelektualnej, lub 
- 3) wykonuje w rozmiarze świadczącym o faktycznym prowadzeniu działalności 
gospodarczej usługi z naruszeniem prawa własności intelektualnej, lub 
- 4) został przez osobę, o której mowa w pkt 1, 2 lub 3, wskazany jako wytwórca 
lub uczestnik procesu wprowadzenia do obrotu takich towarów, odbiorca 
takich usług lub podmiot, który je świadczy.

***
## Art. 479115. {#kpc-pierwsza-pierwsza-art-479115}

**§ 1.** Wezwanie do udzielenia informacji, o których mowa 
w art. 479113, dotyczy wyłącznie: 
- 1) informacji 
o firmie, 
miejscu 
zamieszkania 
lub 
siedzibie 
i adresie 
producentów, 
wytwórców, 
dystrybutorów, 
dostawców 
oraz 
innych 
poprzednich posiadaczy, od których lub na rzecz których nastąpiło nabycie 
lub zbycie towarów, korzystanie z usług lub ich świadczenie, jak również 
przewidywanych hurtowników i detalistów tych towarów lub usług; 
- 2) informacji 
o ilości 
wyprodukowanych, 
wytworzonych, 
wysłanych, 
otrzymanych lub zamówionych towarów lub świadczonych usług, jak również 
cenach otrzymanych w zamian za towary lub usługi; 
- 3) w szczególnie uzasadnionych okolicznościach innych informacji, które są 
niezbędne do wykazania wysokości roszczenia. 
**§ 2.** Wezwanie banku lub spółdzielczej kasy oszczędnościowo-kredytowej do 
udzielenia informacji niezbędnych dla dochodzenia roszczenia, o którym mowa 
w art. 479113, dotyczy informacji obejmujących wyłącznie imię i nazwisko lub 
firmę, miejsce zamieszkania lub siedzibę posiadacza rachunku bankowego lub 
członka spółdzielczej kasy oszczędnościowo-kredytowej oraz kwotę i termin 

 
 
 
s. 216/580 
 
2025-09-08 
 
realizacji 
rozliczenia 
pieniężnego 
na 
rachunku 
dokonanego 
w związku 
z czynnościami naruszającymi prawa własności intelektualnej.

***
## Art. 479116. {#kpc-pierwsza-pierwsza-art-479116}

Wniosek 
o udzielenie 
informacji 
powinien 
odpowiadać 
wymaganiom przepisanym dla pisma procesowego, a ponadto zawierać: 
- 1) wykazanie w sposób wiarygodny okoliczności wskazujących na naruszenie 
prawa własności intelektualnej; 
- 2) określenie informacji, które są przedmiotem wezwania; 
- 3) określenie obowiązanego oraz wskazanie okoliczności, z których może 
wynikać, że dysponuje on informacjami objętymi wnioskiem; 
- 4) wykazanie, że informacje są konieczne do określenia źródła lub zakresu 
naruszenia prawa.

***
## Art. 479117. {#kpc-pierwsza-pierwsza-art-479117}

**§ 1.** Przed wyznaczeniem posiedzenia przewodniczący zarządza 
doręczenie odpisu wniosku o udzielenie informacji obowiązanemu i równocześnie 
zobowiązuje go do złożenia odpowiedzi na wezwanie w wyznaczonym terminie nie 
krótszym niż dwa tygodnie. 
**§ 2.** W przypadku, o którym mowa w § 1, przewodniczący poucza o ochronie 
tajemnicy przedsiębiorstwa oraz prawie odmowy udzielenia informacji. Przepis 
art. 261 stosuje się odpowiednio. 
**§ 3.** Obowiązany nie może jednak odmówić udzielenia informacji, z tego 
powodu, że ich udzielenie mogłoby narazić jego lub jego bliskich, o których mowa 
w art. 261 § 1, na dotkliwą i bezpośrednią szkodę majątkową.

***
## Art. 479118. {#kpc-pierwsza-pierwsza-art-479118}

**§ 1.** Sąd, uwzględniając wniosek, określa termin udzielenia 
informacji, ich rodzaj i zakres, a także zasady zapoznania się z nimi przez 
uprawnionego. Informacji udziela się pod rygorem odpowiedzialności karnej. 
**§ 2.** Doręczając postanowienie nakazujące udzielenie informacji, sąd 
uprzedza obowiązanego o odpowiedzialności karnej za złożenie fałszywego 
oświadczenia. 
**§ 3.** Postanowienie nakazujące udzielenie informacji podlega wykonaniu 
z chwilą jego wydania. Przepis art. 743 stosuje się odpowiednio. 
**§ 4.** Obowiązek udzielenia informacji podlega wykonaniu w formie pisemnej 
albo postaci elektronicznej. 

 
 
 
s. 217/580 
 
2025-09-08

***
## Art. 479119. {#kpc-pierwsza-pierwsza-art-479119}

**§ 1.** Na postanowienie w przedmiocie udzielenia informacji służy 
zażalenie do sądu drugiej instancji. 
**§ 2.** Zażalenie obowiązanego w zakresie, w jakim powołuje się na prawo 
odmowy udzielenia informacji lub ochronę tajemnicy przedsiębiorstwa, sąd 
rozpoznaje na posiedzeniu niejawnym. Od uznania sądu zależy, czy na posiedzeniu 
wysłucha uprawnionego lub obowiązanego. 
**§ 3.** Jeżeli obowiązany powołuje się na ochronę tajemnicy przedsiębiorstwa, 
sąd może określić szczególne zasady korzystania i zapoznawania się z udzielonymi 
informacjami oraz może wprowadzić dodatkowe ograniczenia.

***
## Art. 479120. {#kpc-pierwsza-pierwsza-art-479120}

Przewodniczący, 
na 
wniosek 
uprawnionego, 
wyznacza 
posiedzenie niejawne w celu ustnego wyjaśnienia udzielonych informacji.

***
## Art. 479121. {#kpc-pierwsza-pierwsza-art-479121}

Na żądanie obowiązanego lub pozwanego uprawniony jest 
obowiązany zwrócić koszty i wydatki celowe poniesione w związku z udzieleniem 
informacji. Przepis art. 277 stosuje się odpowiednio. 
Rozdział 5 
Powództwa szczególne

***
## Art. 479122. {#kpc-pierwsza-pierwsza-art-479122}

**§ 1.** Powództwo wzajemne w sprawach o naruszenie prawa do 
znaku towarowego lub wzoru przemysłowego jest dopuszczalne, jeżeli obejmuje 
żądanie unieważnienia lub stwierdzenia wygaśnięcia prawa ochronnego na znak 
towarowy lub obejmuje żądanie unieważnienia prawa z rejestracji wzoru 
przemysłowego. Przepis art. 204 stosuje się odpowiednio. 
**§ 2.** Przepis § 1 stosuje się odpowiednio do żądania unieważnienia lub 
stwierdzenia wygaśnięcia prawa ochronnego na wspólny znak towarowy, 
wspólnego prawa ochronnego na znak towarowy, prawa ochronnego na znak 
towarowy gwarancyjny, uznania na terytorium Rzeczypospolitej Polskiej ochrony 
międzynarodowego znaku towarowego, a także do żądania unieważnienia uznania 
na terytorium Rzeczypospolitej Polskiej ochrony międzynarodowego wzoru 
przemysłowego.

***
## Art. 479123. {#kpc-pierwsza-pierwsza-art-479123}

**§ 1.** Poza wymogami określonymi w art. 187 pozew wzajemny 
powinien zawierać numer wpisu we właściwym rejestrze związany z danym 
prawem ochronnym lub prawem z rejestracji. 

 
 
 
s. 218/580 
 
2025-09-08 
**§ 2.** Do pozwu wzajemnego należy dołączyć wyciąg z właściwego rejestru, 
określający numer wpisu oraz informacje o stanie prawnym udzielonego prawa, 
chyba że został on załączony do pozwu głównego.

***
## Art. 479124. {#kpc-pierwsza-pierwsza-art-479124}

Sąd jest związany podstawą prawną unieważnienia lub 
stwierdzenia wygaśnięcia prawa wskazaną przez powoda wzajemnego.

***
## Art. 479125. {#kpc-pierwsza-pierwsza-art-479125}

W sprawach rozpoznawanych według przepisów niniejszego 
rozdziału przepisy ustawy z dnia 30 czerwca 2000 r. – Prawo własności 
przemysłowej (Dz. U. z 2023 r. poz. 1170) o unieważnieniu lub stwierdzeniu 
wygaśnięcia prawa, stosuje się w zakresie, w jakim nie są one sprzeczne 
z przepisami niniejszego rozdziału.

***
## Art. 479126. {#kpc-pierwsza-pierwsza-art-479126}

**§ 1.** W przypadku wytoczenia powództwa, o którym mowa 
w art. 479122, sąd zwraca się do Prezesa Urzędu Patentowego Rzeczypospolitej 
Polskiej z żądaniem udzielenia informacji, czy przed Urzędem Patentowym 
Rzeczypospolitej Polskiej toczy się już sprawa o unieważnienie lub stwierdzenie 
wygaśnięcia prawa. 
**§ 2.** Prezes Urzędu Patentowego Rzeczypospolitej Polskiej niezwłocznie 
udziela informacji, o których mowa w § 1, w formie pisemnej albo postaci 
elektronicznej. 
**§ 3.** Jeżeli przed Urzędem Patentowym Rzeczypospolitej Polskiej toczy się 
sprawa o unieważnienie lub stwierdzenie wygaśnięcia prawa, sąd zawiesza 
postępowanie do czasu prawomocnego zakończenia postępowania przed Urzędem 
Patentowym Rzeczypospolitej Polskiej. 
**§ 4.** Sąd odrzuca pozew wzajemny o stwierdzenie wygaśnięcia lub 
unieważnienie 
prawa, 
jeżeli 
decyzja 
wydana 
przez 
Urząd 
Patentowy 
Rzeczypospolitej Polskiej, dotycząca tego samego przedmiotu sprawy, w tym 
podstawy powództwa wzajemnego, stała się prawomocna.

***
## Art. 479127. {#kpc-pierwsza-pierwsza-art-479127}

Sąd zawiesza postępowanie z urzędu, jeżeli toczy się inne 
postępowanie cywilne obejmujące żądanie, którego dotyczy wytaczane powództwo 
wzajemne.

***
## Art. 479128. {#kpc-pierwsza-pierwsza-art-479128}

**§ 1.** Odpis prawomocnego wyroku unieważniającego prawo lub 
stwierdzającego wygaśnięcie prawa, od którego nie przysługuje skarga kasacyjna, 
sąd niezwłocznie przesyła Urzędowi Patentowemu Rzeczypospolitej Polskiej 

 
 
 
s. 219/580 
 
2025-09-08 
 
w celu dokonania wpisu do właściwego rejestru oraz przekazania powiadomienia 
do Biura Międzynarodowego w rozumieniu art. 3 ust. 1 pkt 7 ustawy z dnia 
30 czerwca 2000 r. – Prawo własności przemysłowej. 
**§ 2.** Wyrok, o którym mowa w § 1, jest skuteczny także względem osób 
trzecich.

***
## Art. 479129. {#kpc-pierwsza-pierwsza-art-479129}

**§ 1.** Powód może wystąpić z powództwem o ustalenie, że podjęte 
lub zamierzone przez niego czynności nie stanowią naruszenia patentu, 
dodatkowego prawa ochronnego, prawa ochronnego lub prawa z rejestracji. Przepis 
art. 189 stosuje się odpowiednio. 
**§ 2.** Interes prawny istnieje, gdy pozwany: 
- 1) czynności, których dotyczy powództwo uznał za naruszenie patentu, 
dodatkowego prawa ochronnego, prawa ochronnego lub prawa z rejestracji; 
- 2) nie potwierdził w należycie wyznaczonym przez powoda terminie, że 
czynności, których dotyczy powództwo, nie stanowią naruszenia patentu, 
dodatkowego prawa ochronnego, prawa ochronnego lub prawa z rejestracji. 
**§ 3.** Termin, o którym mowa w § 2 pkt 2, został należycie wyznaczony, jeżeli: 
- 1) jego wyznaczenie nastąpiło w formie pisemnej; 
- 2) nie był krótszy niż dwa miesiące od dnia doręczenia uprawnionemu pisma; 
- 3) w treści pisma powód dokładnie oznaczył czynności, które zamierza podjąć 
i które mogą stanowić naruszenie patentu, dodatkowego prawa ochronnego, 
prawa ochronnego lub prawa z rejestracji, wskazując, w jakim zakresie może 
nastąpić naruszenie, i wezwał uprawnionego do wyraźnego potwierdzenia, że 
nie stanowią one naruszenia. 
#### DZIAŁ V
Postępowanie nakazowe i upominawcze 
Rozdział 1 
Przepisy ogólne

***
## Art. 480. {#kpc-pierwsza-pierwsza-art-480}

(uchylony)

***
## Art. 4801. {#kpc-pierwsza-pierwsza-art-4801}

**§ 1.** Sąd wydaje nakaz zapłaty, jeżeli powód dochodzi roszczenia 
pieniężnego albo świadczenia innych rzeczy zamiennych, a w innych przypadkach 
– jeżeli przepis szczególny tak stanowi. 

 
 
 
s. 220/580 
 
2025-09-08 
**§ 2.** Po utracie mocy lub uchyleniu nakazu zapłaty albo w przypadku braku 
podstaw do jego wydania sąd rozpoznaje sprawę według przepisów ogólnych lub 
w postępowaniu odrębnym właściwym dla danej sprawy, chyba że przepis 
szczególny przewiduje inny skutek, w szczególności umorzenie postępowania.

***
## Art. 4802. {#kpc-pierwsza-pierwsza-art-4802}

**§ 1.** W nakazie zapłaty sąd nakazuje pozwanemu, aby w terminie 
oznaczonym w nakazie zaspokoił roszczenie w całości wraz z kosztami albo wniósł 
środek zaskarżenia. 
**§ 2.** Termin, o którym mowa w § 1, wynosi: 
- 1) dwa tygodnie od dnia doręczenia nakazu w przypadku nakazu zapłaty 
wydanego w postępowaniu upominawczym, gdy doręczenie nakazu 
pozwanemu ma mieć miejsce w kraju; 
- 2) miesiąc od dnia doręczenia nakazu w przypadku nakazu zapłaty wydanego 
w postępowaniu upominawczym, gdy doręczenie nakazu pozwanemu ma 
mieć miejsce poza granicami kraju na terytorium Unii Europejskiej; 
- 3) miesiąc od dnia doręczenia nakazu w przypadku nakazu zapłaty wydanego 
w postępowaniu nakazowym, gdy doręczenie nakazu pozwanemu ma mieć 
miejsce na terytorium Unii Europejskiej; 
- 4) trzy miesiące od dnia doręczenia nakazu, w przypadku gdy doręczenie nakazu 
ma mieć miejsce poza terytorium Unii Europejskiej. 
**§ 21.** Jeżeli po wydaniu nakazu zapłaty okaże się, że doręczenie nakazu 
zapłaty ma nastąpić w miejscu, które zgodnie z § 2 uzasadnia oznaczenie innego 
terminu, niż termin oznaczony w wydanym nakazie, sąd z urzędu wydaje 
postanowienie, którym zmienia nakaz w stosownym zakresie. 
**§ 22.** O zmianie nakazu zapłaty na podstawie § 21 umieszcza się wzmiankę na 
oryginale nakazu, a na żądanie stron także na wydanych im wypisach. Dalsze 
odpisy i wypisy powinny być zredagowane w brzmieniu uwzględniającym 
postanowienie o zmianie nakazu. 
**§ 3.** Nakaz zapłaty doręcza się stronom. Pozwanemu nakaz zapłaty doręcza 
się z odpisem pozwu, z odpisami załączników do pozwu oraz pouczeniem 
o terminie i sposobie zaskarżenia nakazu oraz skutkach jego niezaskarżenia. 
**§ 4.** Nakaz zapłaty, od którego nie wniesiono środka zaskarżenia, ma skutki 
prawomocnego wyroku. 

 
 
 
s. 221/580 
 
2025-09-08 
**§ 5.** Jeżeli po wydaniu nakazu zapłaty okaże się, że pozwany w chwili 
wniesienia pozwu nie miał zdolności sądowej, zdolności procesowej albo organu 
powołanego do jego reprezentowania, a braki te nie zostały usunięte 
w wyznaczonym terminie zgodnie z przepisami kodeksu, sąd z urzędu uchyla 
nakaz zapłaty i wydaje odpowiednie postanowienie.

***
## Art. 4803. {#kpc-pierwsza-pierwsza-art-4803}

**§ 1.** Środek zaskarżenia od nakazu zapłaty wnosi się do sądu, który 
wydał nakaz zapłaty. 
**§ 2.** W piśmie zawierającym środek zaskarżenia od nakazu zapłaty pozwany 
powinien wskazać, czy zaskarża nakaz w całości czy w części oraz przedstawić 
zarzuty, które pod rygorem ich utraty należy zgłosić przed wdaniem się w spór co 
do istoty sprawy. 
**§ 3.** Sąd 
odrzuca 
środek 
zaskarżenia 
niedopuszczalny, 
spóźniony, 
nieopłacony lub dotknięty brakami, których nie usunięto pomimo wezwania.

***
## Art. 4804. {#kpc-pierwsza-pierwsza-art-4804}

**§ 1.** Nakaz zapłaty sąd wydaje na posiedzeniu niejawnym. 
**§ 2.** Czynności w sprawie, z wyłączeniem prowadzenia rozprawy i wydania 
wyroku, może wykonywać referendarz sądowy.

***
## Art. 481. {#kpc-pierwsza-pierwsza-art-481}

(uchylony)

***
## Art. 482. {#kpc-pierwsza-pierwsza-art-482}

(uchylony)

***
## Art. 483. {#kpc-pierwsza-pierwsza-art-483}

(uchylony)

***
## Art. 484. {#kpc-pierwsza-pierwsza-art-484}

(uchylony) 
Rozdział 2 
Postępowanie nakazowe

***
## Art. 4841. {#kpc-pierwsza-pierwsza-art-4841}

Nakaz zapłaty w postępowaniu nakazowym wydaje się na wniosek 
powoda zgłoszony w pozwie.

***
## Art. 485. {#kpc-pierwsza-pierwsza-art-485}

**§ 1.** Sąd wydaje nakaz zapłaty w postępowaniu nakazowym, jeżeli 
fakty uzasadniające dochodzone roszczenie są udowodnione dołączonym do 
pozwu: 
- 1) dokumentem urzędowym; 
- 2) zaakceptowanym przez dłużnika rachunkiem; 

 
 
 
s. 222/580 
 
2025-09-08 
- 3) wezwaniem dłużnika do zapłaty i pisemnym oświadczeniem dłużnika 
o uznaniu długu. 
- 4) (uchylony) 
**§ 2.** Sąd wydaje również nakaz zapłaty przeciwko zobowiązanemu z weksla 
lub czeku należycie wypełnionego, których prawdziwość i treść nie nasuwają 
wątpliwości. W przypadku przejścia na powoda praw z weksla lub czeku, do 
wydania 
nakazu 
niezbędne 
jest 
również 
przedstawienie 
dokumentów 
uzasadniających roszczenie, o ile przejście tych praw na powoda nie wynika 
bezpośrednio z weksla lub czeku. Jeżeli dłużnikiem jest konsument, niezbędne jest 
przedstawienie wraz z pozwem umowy, z której wynika roszczenie zabezpieczone 
wekslem, 
wraz 
z deklaracją 
wekslową 
i załącznikami. 
W treści 
pozwu 
skierowanego przeciwko osobie fizycznej zamieszcza się oświadczenie o tym, czy 
roszczenie dochodzone pozwem powstało w związku z umową zawartą 
z konsumentem. 
**§ 21.** Sąd wydaje nakaz zapłaty na podstawie dołączonej do pozwu umowy, 
dowodu spełnienia wzajemnego świadczenia niepieniężnego, dowodu doręczenia 
dłużnikowi faktury lub rachunku, jeżeli powód dochodzi należności zapłaty 
świadczenia pieniężnego w rozumieniu art. 4 pkt 1a ustawy z dnia 8 marca 2013 r. 
o przeciwdziałaniu nadmiernym opóźnieniom w transakcjach handlowych (Dz. U. 
z 2023 r. poz. 1790), odsetek w transakcjach handlowych określonych w tej ustawie 
lub rekompensaty, o której mowa w art. 10 ust. 1 tej ustawy, oraz na podstawie 
dokumentów potwierdzających poniesienie kosztów odzyskiwania należności, 
jeżeli 
powód 
dochodzi 
również 
zwrotu 
kosztów, 
o których 
mowa 
w art. 10 ust. 2 tej ustawy. 
**§ 3.** (uchylony) 
**§ 4.** Jeżeli nie dołączono oryginału weksla lub czeku lub w treści pozwu nie 
zamieszczono 
oświadczenia, 
o którym 
mowa 
w § 

zdanie 
czwarte, 
przewodniczący wzywa powoda do ich złożenia pod rygorem zwrotu pozwu na 
podstawie art. 130. 
**§ 5.** Sąd może skazać na grzywnę powoda, jego przedstawiciela ustawowego 
lub pełnomocnika, który w złej wierze lub wskutek niezachowania należytej 
staranności złożył niezgodne z prawdą oświadczenie, o którym mowa w § 2 zdanie 

 
 
 
s. 223/580 
 
2025-09-08 
 
czwarte, że roszczenie dochodzone pozwem nie powstało w związku z umową 
zawartą z konsumentem.

***
## Art. 486. {#kpc-pierwsza-pierwsza-art-486}

**§ 1.** (uchylony) 
**§ 2.** W sprawach, o których mowa w art. 485 § 21, przewodniczący i sąd są 
obowiązani podejmować czynności tak, by pierwsze posiedzenie wyznaczone 
w celu wydania nakazu zapłaty, rozpoznania sprawy lub nadania jej innego biegu 
odbyło się nie później niż dwa miesiące od dnia wniesienia pozwu, a jeżeli pozew 
był dotknięty brakami – od dnia ich usunięcia.

***
## Art. 487. {#kpc-pierwsza-pierwsza-art-487}

(uchylony)

***
## Art. 488. {#kpc-pierwsza-pierwsza-art-488}

(uchylony)

***
## Art. 489. {#kpc-pierwsza-pierwsza-art-489}

(uchylony)

***
## Art. 490. {#kpc-pierwsza-pierwsza-art-490}

(uchylony)

***
## Art. 491. {#kpc-pierwsza-pierwsza-art-491}

(uchylony)

***
## Art. 492. {#kpc-pierwsza-pierwsza-art-492}

**§ 1.** Nakaz zapłaty z chwilą wydania stanowi tytuł zabezpieczenia, 
wykonalny bez nadawania mu klauzuli wykonalności. Kwota zasądzona nakazem 
wraz z wymagalnymi odsetkami stanowi sumę, której złożenie przez dłużnika na 
rachunek depozytowy Ministra Finansów w rozumieniu przepisów o finansach 
publicznych, zwany dalej „rachunkiem depozytowym Ministra Finansów”, 
wystarczy do zabezpieczenia. Jeżeli nakaz zobowiązuje do wydania rzeczy 
zamiennych, do zabezpieczenia wystarczy złożenie sumy równej wartości 
przedmiotu sporu. 
**§ 2.** Powód wnosząc o dokonanie zabezpieczenia jest obowiązany wskazać 
sposób zabezpieczenia. Sąd na wniosek pozwanego może ograniczyć 
zabezpieczenie według swego uznania. Przepis art. 742 oraz przepisy 
o ograniczeniu zabezpieczenia przeciwko Skarbowi Państwa stosuje się 
odpowiednio. 
**§ 3.** Nakaz zapłaty wydany na podstawie weksla lub czeku staje się 
natychmiast wykonalny po upływie terminu do zaspokojenia roszczenia. W razie 
wniesienia zarzutów sąd może na wniosek pozwanego wstrzymać wykonanie 
nakazu. Przepisy o ograniczeniu wykonalności w sprawach przeciwko Skarbowi 
Państwa stosuje się odpowiednio. 

 
 
 
s. 224/580 
 
2025-09-08

***
## Art. 4921. {#kpc-pierwsza-pierwsza-art-4921}

(uchylony)

***
## Art. 493. {#kpc-pierwsza-pierwsza-art-493}

**§ 1.** Od nakazu zapłaty pozwany może wnieść zarzuty. 
**§ 2.** W piśmie zawierającym zarzuty pozwany powinien, poza elementami 
wskazanymi w art. 4803 § 2, wymienić fakty, z których wywodzi żądania, i dowody 
na wykazanie każdego z nich. 
**§ 3.** W postępowaniu po wniesieniu zarzutów: 
- 1) nie stosuje się przepisów art. 194–196 i art. 198; 
- 2) powództwo wzajemne jest niedopuszczalne; 
- 3) nie można występować z nowymi roszczeniami zamiast lub obok 
dotychczasowych; jednakże w przypadku zmiany okoliczności powód może 
żądać zamiast pierwotnego przedmiotu sporu jego równowartości lub innego 
przedmiotu, a w sprawach o świadczenie powtarzające się może nadto 
rozszerzyć powództwo o świadczenia za kolejne okresy. 
**§ 4.** Jeżeli zachodzą podstawy do odrzucenia pozwu lub umorzenia 
postępowania, sąd z urzędu postanowieniem uchyla nakaz zapłaty i wydaje 
odpowiednie rozstrzygnięcie. W innym przypadku sąd wydaje wyrok, którym 
w całości lub części utrzymuje nakaz zapłaty w mocy albo go uchyla i orzeka 
o żądaniu pozwu.

***
## Art. 494. {#kpc-pierwsza-pierwsza-art-494}

(uchylony)

***
## Art. 495. {#kpc-pierwsza-pierwsza-art-495}

(uchylony)

***
## Art. 496. {#kpc-pierwsza-pierwsza-art-496}

(uchylony)

***
## Art. 497. {#kpc-pierwsza-pierwsza-art-497}

**§ 1.** W przypadku 
cofnięcia 
zarzutów 
sąd 
stwierdza 
postanowieniem, że nakaz zapłaty pozostaje w mocy i orzeka o kosztach jak przy 
cofnięciu pozwu. Przepis art. 203 § 3 stosuje się odpowiednio. 
**§ 2.** W przypadku, o którym mowa w art. 203 § 4, sąd może uznać cofnięcie 
zarzutów za niedopuszczalne. 
Rozdział 3 
Postępowanie upominawcze

***
## Art. 4971. {#kpc-pierwsza-pierwsza-art-4971}

(uchylony)

***
## Art. 498. {#kpc-pierwsza-pierwsza-art-498}

(uchylony) 

 
 
 
s. 225/580 
 
2025-09-08

***
## Art. 499. {#kpc-pierwsza-pierwsza-art-499}

Sąd wydaje nakaz zapłaty w postępowaniu upominawczym 
w sprawach określonych w art. 4801 § 1, chyba że według treści pozwu: 
- 1) roszczenie jest oczywiście bezzasadne; 
- 2) twierdzenia co do faktów budzą wątpliwość; 
- 3) zaspokojenie roszczenia zależy od świadczenia wzajemnego. 
- 4) (uchylony) 
**§ 2.** (uchylony)

***
## Art. 500. {#kpc-pierwsza-pierwsza-art-500}

(uchylony)

***
## Art. 501. {#kpc-pierwsza-pierwsza-art-501}

(uchylony)

***
## Art. 502. {#kpc-pierwsza-pierwsza-art-502}

(uchylony)

***
## Art. 5021. {#kpc-pierwsza-pierwsza-art-5021}

(uchylony)

***
## Art. 503. {#kpc-pierwsza-pierwsza-art-503}

(uchylony)

***
## Art. 504. {#kpc-pierwsza-pierwsza-art-504}

(uchylony)

***
## Art. 505. {#kpc-pierwsza-pierwsza-art-505}

**§ 1.** Od nakazu zapłaty pozwany może wnieść sprzeciw. 
**§ 2.** Nakaz zapłaty traci moc w części zaskarżonej sprzeciwem. Sprzeciw 
jednego tylko ze współpozwanych o to samo roszczenie oraz co do jednego lub 
niektórych uwzględnionych roszczeń powoduje utratę mocy nakazu jedynie co do 
nich. 
**§ 3.** Na wniosek strony sąd wydaje postanowienie stwierdzające utratę mocy 
nakazu zapłaty w całości lub części. 
#### DZIAŁ VI
Postępowanie uproszczone

***
## Art. 5051. {#kpc-pierwsza-pierwsza-art-5051}

**§ 1.** W postępowaniu uproszczonym rozpoznaje się sprawy 
o świadczenie, jeżeli wartość przedmiotu sporu nie przekracza dwudziestu tysięcy 
złotych, a w sprawach o roszczenia z rękojmi lub gwarancji – jeżeli wartość 
przedmiotu umowy nie przekracza tej kwoty. 
**§ 2.** Spośród spraw wymienionych w § 1 nie rozpoznaje się w postępowaniu 
uproszczonym spraw: 
- 1) należących do właściwości sądów okręgowych; 
- 2) małżeńskich i z zakresu stosunków między rodzicami a dziećmi; 

 
 
 
s. 226/580 
 
2025-09-08 
- 3) z zakresu prawa pracy rozpoznawanych z udziałem ławników; 
- 4) z zakresu ubezpieczeń społecznych, z wyjątkiem spraw wymienionych 
w art. 4778 § 2 i spraw o rentę. 
**§ 3.** Sąd może rozpoznać sprawę z pominięciem przepisów o postępowaniu 
uproszczonym, jeżeli może to przyczynić się do sprawniejszego rozwiązania sporu.

***
## Art. 5051a. {#kpc-pierwsza-pierwsza-art-5051a}

W sprawach, w których wartość przedmiotu sporu nie przekracza 
czterech tysięcy złotych, przepisu art. 1481 § 3 nie stosuje się.

***
## Art. 5052. {#kpc-pierwsza-pierwsza-art-5052}

W sprawach rozpoznawanych według przepisów niniejszego 
działu posiedzenia przygotowawczego nie przeprowadza się, chyba że 
z okoliczności 
sprawy 
wynika, 
że 
przeprowadzenie 
posiedzenia 
przygotowawczego może przyczynić się do sprawniejszego rozpoznania sprawy.

***
## Art. 5053. {#kpc-pierwsza-pierwsza-art-5053}

**§ 1.** Jednym pozwem można dochodzić tylko jednego roszczenia. 
**§ 2.** Połączenie kilku roszczeń w jednym pozwie jest dopuszczalne tylko 
wtedy, gdy wynikają z tego samego stosunku prawnego lub kilku stosunków 
prawnych tego samego rodzaju. W przypadku niedopuszczalnego połączenia 
w jednym pozwie kilku roszczeń przewodniczący zarządza zwrot pozwu bez 
wezwania do usunięcia tego braku. Jeżeli w terminie tygodnia od dnia doręczenia 
zarządzenia o zwrocie powód cofnie pozew w zakresie żądań niepodlegających 
łączeniu, pozew w pozostałej części wywołuje skutek od daty jego pierwotnego 
wniesienia. 
**§ 3.** Jeżeli powód dochodzi części roszczenia, sprawa podlega rozpoznaniu 
w postępowaniu przewidzianym w niniejszym rozdziale tylko wtedy, gdy 
postępowanie to byłoby właściwe dla całego roszczenia wynikającego z faktów 
przytoczonych przez powoda. W przeciwnym wypadku sprawa rozpoznawana jest 
z pominięciem przepisów niniejszego rozdziału.

***
## Art. 5054. {#kpc-pierwsza-pierwsza-art-5054}

**§ 1.** Zmiana powództwa jest niedopuszczalna. Przepisów art. 75–
85 oraz art. 194–196 i art. 198 nie stosuje się. 
**§ 2.** Powództwo wzajemne oraz zarzut potrącenia są dopuszczalne, jeżeli 
roszczenia nadają się do rozpoznania w postępowaniu uproszczonym.

***
## Art. 5055. {#kpc-pierwsza-pierwsza-art-5055}

(uchylony)

***
## Art. 5056. {#kpc-pierwsza-pierwsza-art-5056}

**§ 1.** (uchylony) 

 
 
 
s. 227/580 
 
2025-09-08 
**§ 2.** (uchylony) 
**§ 3.** Jeżeli sąd uzna, że ścisłe udowodnienie wysokości żądania jest 
niemożliwe lub nader utrudnione, może w wyroku zasądzić odpowiednią sumę 
według swej oceny, opartej na rozważeniu wszystkich okoliczności sprawy.

***
## Art. 5057. {#kpc-pierwsza-pierwsza-art-5057}

**§ 1.** Ilekroć ustalenie zasadności lub wysokości świadczenia 
powinno nastąpić przy zastosowaniu wiadomości specjalnych, od uznania sądu 
zależy powzięcie samodzielnej oceny opartej na rozważeniu wszystkich okolicz-
ności sprawy albo zasięgnięcie opinii biegłego. 
**§ 2.** Opinii biegłego nie zasięga się, jeżeli jej przewidywany koszt miałby 
przekroczyć wartość przedmiotu sporu, chyba że uzasadniają to wyjątkowe 
okoliczności. 
**§ 3.** Złożenie zeznań przez świadka nie stoi na przeszkodzie zasięgnięciu jego 
opinii jako biegłego, także co do faktów, o których zeznał jako świadek, nawet 
jeżeli uprzednio sporządził opinię na zlecenie podmiotu innego niż sąd.

***
## Art. 5058. {#kpc-pierwsza-pierwsza-art-5058}

**§ 1.** (uchylony) 
**§ 2.** (uchylony) 
**§ 3.** Strona obecna na posiedzeniu, na którym ogłoszono wyrok, może po jego 
ogłoszeniu w oświadczeniu złożonym do protokołu zrzec się prawa do wniesienia 
apelacji. W razie zrzeczenia się prawa do wniesienia apelacji przez wszystkich 
uprawnionych wyrok staje się prawomocny. 
**§ 4.** W sprawach, w których wartość przedmiotu sporu nie przekracza 
czterech tysięcy złotych, uzasadnienie wyroku ogranicza się do wyjaśnienia 
podstawy prawnej wyroku z przytoczeniem przepisów prawa. Od uznania sądu 
opartego na rozważeniu wszystkich okoliczności sprawy zależy rozszerzenie tego 
uzasadnienia o pozostałą treść określoną w art. 3271 § 1.

***
## Art. 5059. {#kpc-pierwsza-pierwsza-art-5059}

**§ 1.** (uchylony) 
**§ 11.** Apelację można oprzeć na zarzutach: 
- 1) naruszenia prawa materialnego przez błędną jego wykładnię lub niewłaściwe 
zastosowanie; 
- 2) naruszenia przepisów postępowania, jeżeli mogło ono mieć wpływ na wynik 
sprawy. 

 
 
 
s. 228/580 
 
2025-09-08 
**§ 2.** Po upływie terminu do wniesienia apelacji przytaczanie dalszych 
zarzutów jest niedopuszczalne.

***
## Art. 50510. {#kpc-pierwsza-pierwsza-art-50510}

(uchylony)

***
## Art. 50511. {#kpc-pierwsza-pierwsza-art-50511}

(uchylony)

***
## Art. 50512. {#kpc-pierwsza-pierwsza-art-50512}

**§ 1.** Jeżeli sąd drugiej instancji stwierdzi, że zachodzi naruszenie 
prawa materialnego, a zgromadzone dowody nie dają wystarczających podstaw do 
zmiany wyroku, uchyla zaskarżony wyrok i przekazuje sprawę do ponownego 
rozpoznania. 
**§ 11.** W sprawach, w których wartość przedmiotu sporu nie przekracza 
czterech tysięcy złotych, przepisu § 1 nie stosuje się, a zaskarżony wyrok może 
zostać uchylony tylko w przypadkach określonych w art. 386 § 2 i 3. 
**§ 2.** Uchylając zaskarżony wyrok sąd drugiej instancji może przekazać sprawę 
do rozpoznania z wyłączeniem przepisów o postępowaniu uproszczonym także 
wówczas, gdy sprawa stosownie do art. 5051 podlega rozpoznaniu w tym 
postępowaniu. 
**§ 3.** Sąd drugiej instancji oddala apelację również wtedy, gdy mimo 
naruszenia prawa materialnego lub przepisów postępowania albo błędnego 
uzasadnienia zaskarżony wyrok odpowiada prawu.

***
## Art. 50513. {#kpc-pierwsza-pierwsza-art-50513}

**§ 1.** (uchylony) 
**§ 2.** Jeżeli 
sąd 
drugiej 
instancji 
nie 
przeprowadził 
postępowania 
dowodowego, uzasadnienie wyroku powinno zawierać jedynie wyjaśnienie 
podstawy prawnej wyroku z przytoczeniem przepisów prawa. 
**§ 3.** (uchylony)

***
## Art. 50513a. {#kpc-pierwsza-pierwsza-art-50513a}

W postępowaniu toczącym się na skutek zażalenia sąd drugiej 
instancji uzasadnia z urzędu jedynie postanowienia uchylające zaskarżone 
postanowienie albo zarządzenie.

***
## Art. 50514. {#kpc-pierwsza-pierwsza-art-50514}

**§ 1.** W postępowaniu uproszczonym w sprawach z zakresu prawa 
pracy przepisów art. 466, art. 477 i art. 4771 nie stosuje się. 
**§ 2.** (uchylony) 

 
 
 
s. 229/580 
 
2025-09-08 
#### DZIAŁ VII
Europejskie postępowania w sprawach transgranicznych 
Rozdział 1 
Europejskie postępowanie nakazowe

***
## Art. 50515. {#kpc-pierwsza-pierwsza-art-50515}

**§ 1.** Sąd rozpoznaje sprawę w europejskim postępowaniu 
nakazowym, jeżeli są spełnione warunki określone w przepisach rozporządzenia 
(WE) nr 1896/2006 Parlamentu Europejskiego i Rady z dnia 12 grudnia 2006 r. 
ustanawiającego postępowanie w sprawie europejskiego nakazu zapłaty (Dz. Urz. 
UE L 399 z 30.12.2006, str. 1, z późn. zm.), zwanego dalej „rozporządzeniem 
nr 1896/2006”. 
**§ 2.** W sprawie rozpoznawanej według przepisów niniejszego rozdziału nie 
stosuje się przepisów o innych postępowaniach odrębnych.

***
## Art. 50516. {#kpc-pierwsza-pierwsza-art-50516}

**§ 1.** Europejskie postępowanie nakazowe należy do właściwości 
sądów rejonowych i okręgowych. 
**§ 2.** Europejski nakaz zapłaty może wydać także referendarz sądowy. 
**§ 3.** Referendarz sądowy może wydawać zarządzenia.

***
## Art. 50517. {#kpc-pierwsza-pierwsza-art-50517}

Rozpoznanie sprawy następuje na posiedzeniu niejawnym.

***
## Art. 50518. {#kpc-pierwsza-pierwsza-art-50518}

**§ 1.** Jeżeli europejski nakaz zapłaty, zgodnie z przepisami 
rozporządzenia nr 1896/2006, może zostać wydany tylko co do części roszczenia 
i powód wyraża na to zgodę, sprawę co do pozostałej części roszczenia sąd 
przekazuje do sądu według właściwości ogólnej. W przypadkach wskazanych 
w ustawie sąd rozpoznaje sprawę według przepisów o postępowaniach odrębnych, 
z wyłączeniem przepisów o postępowaniu nakazowym i upominawczym. 
**§ 2.** (uchylony)

***
## Art. 50519. {#kpc-pierwsza-pierwsza-art-50519}

**§ 1.** W razie 
wniesienia 
sprzeciwu 
zgodnie 
z przepisami 
rozporządzenia nr 1896/2006, europejski nakaz zapłaty traci moc, a sąd przekazuje 
sprawę do sądu według właściwości ogólnej. W przypadkach wskazanych 
w ustawie sąd rozpoznaje sprawę według przepisów o postępowaniach odrębnych, 
z wyłączeniem przepisów o postępowaniu nakazowym i upominawczym. 
**§ 2.** (uchylony) 
**§ 3.** (uchylony) 

 
 
 
s. 230/580 
 
2025-09-08 
**§ 4.** Jeżeli powód zgodnie z przepisami rozporządzenia nr 1896/2006 zażądał 
zakończenia postępowania na wypadek wniesienia sprzeciwu, sąd umarza 
postępowanie, orzekając o kosztach jak przy cofnięciu pozwu.

***
## Art. 50519a. {#kpc-pierwsza-pierwsza-art-50519a}

Sąd odrzuca sprzeciw wniesiony po upływie przypisanego 
terminu lub z innych przyczyn niedopuszczalny, jak również sprzeciw którego 
braków pozwany nie usunął w terminie.

***
## Art. 50520. {#kpc-pierwsza-pierwsza-art-50520}

**§ 1.** W razie stwierdzenia, że istnieje określona w przepisach 
rozporządzenia nr 1896/2006 podstawa do uchylenia europejskiego nakazu 
zapłaty, na wniosek pozwanego sąd, który go wydał, a w przypadku nakazu 
wydanego przez referendarza sądowego – sąd, przed którym wytoczono 
powództwo, uchyla nakaz zapłaty. 
**§ 2.** Wniosek powinien czynić zadość warunkom pisma procesowego 
i wskazywać okoliczności uzasadniające uchylenie europejskiego nakazu zapłaty. 
**§ 3.** Przed uchyleniem europejskiego nakazu zapłaty sąd wysłucha powoda na 
posiedzeniu lub zażąda od niego oświadczenia na piśmie. 
**§ 4.** Na postanowienie sądu w przedmiocie uchylenia europejskiego nakazu 
zapłaty przysługuje zażalenie. 
Rozdział 2 
Europejskie postępowanie w sprawie drobnych roszczeń

***
## Art. 50521. {#kpc-pierwsza-pierwsza-art-50521}

**§ 1.** Sąd rozpoznaje sprawę w europejskim postępowaniu 
w sprawie drobnych roszczeń, jeżeli są spełnione warunki określone w przepisach 
rozporządzenia (WE) nr 861/2007 Parlamentu Europejskiego i Rady z dnia 
11 lipca 2007 r. ustanawiającego europejskie postępowanie w sprawie drobnych 
roszczeń (Dz. Urz. UE L 199 z 31.07.2007, str. 1, z późn. zm.), zwanego dalej 
„rozporządzeniem nr 861/2007”. 
**§ 2.** W sprawie rozpoznawanej według przepisów niniejszego rozdziału nie 
stosuje się przepisów o innych postępowaniach odrębnych.

***
## Art. 50522. {#kpc-pierwsza-pierwsza-art-50522}

**§ 1.** Europejskie postępowanie w sprawie drobnych roszczeń 
należy do właściwości sądów rejonowych i okręgowych. 
**§ 2.** Referendarz sądowy może wydawać zarządzenia. 

 
 
 
s. 231/580 
 
2025-09-08

***
## Art. 50523. {#kpc-pierwsza-pierwsza-art-50523}

Rozpoznanie sprawy następuje na posiedzeniu niejawnym. Sąd 
może 
wyznaczyć 
rozprawę 
w 
przypadkach 
wskazanych 
w przepisach 
rozporządzenia nr 861/2007.

***
## Art. 50524. {#kpc-pierwsza-pierwsza-art-50524}

Jeżeli przepisy rozporządzenia nr 861/2007 stanowią, że pozew 
powinien zostać zwrócony, sąd wydaje postanowienie.

***
## Art. 50525. {#kpc-pierwsza-pierwsza-art-50525}

**§ 1.** (uchylony) 
**§ 2.** Przesłuchanie strony następuje na piśmie, jeżeli sąd tak postanowi. 
Przepisu art. 303 nie stosuje się.

***
## Art. 50526. {#kpc-pierwsza-pierwsza-art-50526}

Wyrok wydany na posiedzeniu niejawnym wiąże sąd od chwili 
podpisania sentencji. Sąd z urzędu doręcza wyrok obu stronom z pouczeniem 
o przysługujących im środkach zaskarżenia.

***
## Art. 50527. {#kpc-pierwsza-pierwsza-art-50527}

**§ 1.** Przepisy art. 5059, art. 50512 § 1 i 3 oraz art. 50513 stosuje się. 
**§ 2.** Uchylając zaskarżony wyrok, sąd drugiej instancji przekazuje sprawę do 
rozpoznania z wyłączeniem przepisów o postępowaniach odrębnych.

***
## Art. 50527a. {#kpc-pierwsza-pierwsza-art-50527a}

**§ 1.** W razie stwierdzenia, że istnieje określona w przepisach 
rozporządzenia nr 861/2007 podstawa do uchylenia wyroku, na wniosek 
pozwanego sąd, który go wydał, uchyla wyrok. 
**§ 2.** Wniosek powinien czynić zadość warunkom pisma procesowego 
i wskazywać okoliczności uzasadniające uchylenie wyroku. 
**§ 3.** Sąd może rozpoznać wniosek na posiedzeniu niejawnym. Przed 
uchyleniem wyroku sąd wysłucha powoda na posiedzeniu lub zażąda od niego 
oświadczenia na piśmie. 
**§ 4.** Na postanowienie sądu w przedmiocie uchylenia wyroku przysługuje 
zażalenie. 

 
 
 
s. 232/580 
 
2025-09-08 
#### DZIAŁ VIII
Postępowania elektroniczne 
Rozdział 1 
Elektroniczne postępowanie upominawcze

***
## Art. 50528. {#kpc-pierwsza-pierwsza-art-50528}

**§ 1.** W postępowaniu określonym w niniejszym rozdziale stosuje 
się przepisy o postępowaniu upominawczym z odrębnościami wynikającymi 
z niniejszego rozdziału. 
**§ 2.** Nakaz zapłaty nie może być wydany, jeżeli: 
- 1) powód dochodzi roszczenia innego niż pieniężne; 
- 2) doręczenie pozwanemu nakazu miałoby nastąpić poza granicami kraju.

***
## Art. 50529. {#kpc-pierwsza-pierwsza-art-50529}

[§ 1. W elektronicznym postępowaniu upominawczym nie stosuje 
się przepisów o postępowaniach odrębnych innych niż wymienione w art. 50528 § 1 
oraz przepisów art. 1301a, art. 139 § 5 i art. 1391.] 
<§ 1. W elektronicznym postępowaniu upominawczym nie stosuje się 
przepisów 
o postępowaniach 
odrębnych 
innych 
niż 
wymienione 
w art. 50528 § 1 oraz przepisów art. 89 § 1, art. 1251, art. 139 § 5 i art. 1391.> 
**§ 2.** Postanowienia wydane na posiedzeniu niejawnym, które podlegają 
zaskarżeniu, uzasadnia się z urzędu. Termin do wniesienia zażalenia wynosi 
tydzień od dnia doręczenia postanowienia z uzasadnieniem. 
**§ 3.** Przepis § 2 stosuje się odpowiednio do zarządzeń przewodniczącego. 
**§ 4.** Postanowienia wydane na podstawie art. 50533 i art. 50534 doręcza się 
z urzędu tylko powodowi.

***
## Art. 50529a. {#kpc-pierwsza-pierwsza-art-50529a}

W elektronicznym postępowaniu upominawczym mogą być 
dochodzone roszczenia, które stały się wymagalne w okresie trzech lat przed dniem 
wniesienia pozwu.

***
## Art. 50530. {#kpc-pierwsza-pierwsza-art-50530}

**§ 1.** (uchylony) 
**§ 2.** Czynności sądu, referendarza i przewodniczącego utrwalane są 
wyłącznie w systemie teleinformatycznym, a wytworzone w ich wyniku dane 
w postaci 
elektronicznej 
opatrywane 
są 
kwalifikowanym 
podpisem 
elektronicznym. 
Nowe brzmienie 
§ 1 w art. 50529 
wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1172). 
 

 
 
 
s. 233/580 
 
2025-09-08

***
## Art. 50531. {#kpc-pierwsza-pierwsza-art-50531}

**§ 1.** Powód wnosi pisma wyłącznie za pośrednictwem systemu 
teleinformatycznego. 
**§ 2.** Jeżeli pozwany dokona wyboru wnoszenia pism procesowych za 
pośrednictwem systemu teleinformatycznego, dalsze pisma w sprawie wnosi 
wyłącznie za pośrednictwem tego systemu. 
**§ 21.** Pisma wniesione za pośrednictwem systemu teleinformatycznego nie 
wymagają opatrzenia ich podpisem, o którym mowa w art. 126 § 5. 
<§ 22. Pełnomocnik powołuje się na pełnomocnictwo, wskazując jego 
zakres oraz okoliczności wymienione w art. 87, wnosząc pierwsze pismo 
procesowe w sprawie.> 
**§ 3.** (uchylony) 
**§ 4.** O skutkach 
wniesienia 
pisma 
za 
pośrednictwem 
systemu 
teleinformatycznego sąd poucza pozwanego przy pierwszym doręczeniu. 
**§ 5.** (uchylony) 
**§ 6.** (uchylony)

***
## Art. 50532. {#kpc-pierwsza-pierwsza-art-50532}

**§ 1.** W pozwie powód powinien wskazać dowody na poparcie 
swoich twierdzeń. Dowodów nie dołącza się do pozwu. Przepisu art. 128 nie 
stosuje się. 
**§ 2.** Pozew powinien zawierać również: 
- 1) numer PESEL lub NIP pozwanego będącego osobą fizyczną, jeżeli jest on 
obowiązany do jego posiadania lub posiada go nie mając takiego obowiązku 
lub 
- 2) numer w Krajowym Rejestrze Sądowym, a w przypadku jego braku – numer 
w innym właściwym rejestrze, ewidencji lub NIP pozwanego niebędącego 
osobą fizyczną, który nie ma obowiązku wpisu we właściwym rejestrze lub 
ewidencji, jeżeli jest on obowiązany do jego posiadania. 
- 3) (uchylony) 
**§ 3.** Sąd może skazać na grzywnę powoda, jego przedstawiciela ustawowego 
lub pełnomocnika, który w złej wierze lub wskutek niezachowania należytej 
staranności oznaczył nieprawidłowo dane, o których mowa w § 2 pkt 1 lub 2 oraz 
art. 126 § 2 pkt 1. 
**§ 4.** (uchylony) 
Dodany § 22 w 
art. 50531 wejdzie 
w życie z dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 

 
 
 
s. 234/580 
 
2025-09-08

***
## Art. 50533. {#kpc-pierwsza-pierwsza-art-50533}

W przypadku braku podstaw do wydania nakazu zapłaty sąd 
umarza postępowanie.

***
## Art. 50534. {#kpc-pierwsza-pierwsza-art-50534}

**§ 1.** Jeżeli pozwany, pomimo powtórzenia zawiadomienia zgodnie 
z art. 139 § 1 zdanie drugie, nie odebrał nakazu zapłaty, a w sprawie nie doręczono 
mu wcześniej żadnego pisma w sposób przewidziany w art. 131–138 i nie ma 
zastosowania art. 139 § 2 i 3 lub inny przepis szczególny przewidujący skutek 
doręczenia, nakaz zapłaty uznaje się za doręczony, o ile adres, pod którym 
pozostawiono zawiadomienia, jest zgodny z adresem ujawnionym w rejestrze 
PESEL. W przeciwnym przypadku stosuje się przepis § 2. 
**§ 2.** Jeżeli po wydaniu nakazu zapłaty okaże się, że nie można go doręczyć 
pozwanemu w kraju, sąd z urzędu uchyla nakaz zapłaty i umarza postępowanie, 
chyba że powód w wyznaczonym terminie, nie dłuższym niż miesiąc, usunie 
przeszkodę w doręczeniu nakazu zapłaty. Wezwanie do usunięcia przeszkody nie 
podlega powtórzeniu.

***
## Art. 50535. {#kpc-pierwsza-pierwsza-art-50535}

Do sprzeciwu od nakazu zapłaty nie dołącza się dowodów.

***
## Art. 50536. {#kpc-pierwsza-pierwsza-art-50536}

W przypadku wniesienia sprzeciwu sąd umarza postępowanie 
w zakresie, w którym nakaz zapłaty utracił moc.

***
## Art. 50537. {#kpc-pierwsza-pierwsza-art-50537}

**§ 1.** W przypadku umorzenia postępowania każda ze stron ponosi 
koszty procesu związane ze swym udziałem w sprawie. 
**§ 2.** Jeżeli w terminie trzech miesięcy od dnia wydania postanowienia 
o umorzeniu elektronicznego postępowania upominawczego powód wniesie pozew 
przeciwko pozwanemu o to samo roszczenie w postępowaniu innym niż 
elektroniczne postępowanie upominawcze, skutki prawne, które ustawa wiąże 
z wytoczeniem 
powództwa, 
następują 
z dniem 
wniesienia 
pozwu 
w elektronicznym postępowaniu upominawczym. Na żądanie stron sąd, 
rozpoznając sprawę, uwzględni koszty poniesione przez strony w elektronicznym 
postępowaniu upominawczym.

***
## Art. 50538. {#kpc-pierwsza-pierwsza-art-50538}

Rozpoznanie 
zażalenia 
na 
postanowienie 
wydane 
w elektronicznym postępowaniu upominawczym, jak również na postanowienie 
wydane 
w postępowaniu 
o nadanie 
klauzuli 
wykonalności 
tytułowi 
wykonawczemu wydanemu w tym postępowaniu, następuje w składzie jednego 

 
 
 
s. 235/580 
 
2025-09-08 
 
sędziego. W postępowaniu toczącym się na skutek wniesienia zażalenia przepisy 
art. 50530 § 2 i art. 50531 stosuje się odpowiednio.

***
## Art. 50539. {#kpc-pierwsza-pierwsza-art-50539}

W razie wniesienia skargi o wznowienie postępowania sąd 
przekazuje sprawę do sądu według właściwości ogólnej. Do wznowienia 
postępowania właściwy jest sąd według właściwości ogólnej.

