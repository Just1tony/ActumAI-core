## Chunk 1
DZIENNIK USTAW
RZECZYPOSPOLITEJ POLSKIEJ
Warszawa, dnia  29 lutego 2024  r.
Poz. 276
OBWIESZCZENIE
MARSZAŁKA SEJMU RZEC ZYPOSPOLITEJ POLSKIE J
z dnia 20 lutego 2024  r.
w sprawie ogłoszenia jednolitego tekstu ustawy o  Krajowym Rejestrze Karnym
1. Na podstawie  art. 16 ust. 1 zdanie pierwsze ustawy z  dnia 20 lipca 2000  r. o ogłaszaniu aktów normatywnych i  nie-
których innych aktów prawnych ( Dz. U. z 2019 r. poz. 1461) ogłasza się w  załączniku do niniejszego obwieszcz enia jedno-
lity tekst ustawy z  dnia 24 maja 2000  r. o Krajowym Rejestrze Karnym (Dz.  U. z 2023 r. poz. 1068), z uwzględnieniem  zmian
wprowadzon ych ustawą z dnia 16 sierpnia 2023 r. o zmianie ustawy – Kodeks spółek handlowych oraz niektórych innych
ustaw (Dz. U. poz. 1705)  oraz zmian wynikających z  przepisów ogłoszonyc h przed dniem 19 lutego 2024 r.
2. Podany w  załączniku do niniejszego obwieszczenia tekst jednolity ustawy nie obejmuje  art. 16 ustawy z dnia  16 sierpnia
2023 r. o zmianie ustawy – Kodeks spółek handlowych oraz niektórych innych ustaw (Dz. U. poz. 1705) , który stanowi:
„Art. 16. Ustawa wchodzi w życie z dniem 15 września 2023 r., z wyjątkiem:
1) art.

## Chunk 2
11, który wchodzi w życie z dniem 1 stycznia 2024 r.;
2) art. 13, który wchodzi w życie z dniem następującym po dniu ogłoszenia. ”.
Marszałek Sejmu : S. Hołownia



Dziennik Ustaw – 2 – Poz. 276

Załącznik do obwieszczenia Marszałka Sejmu Rzeczypospolitej
Polskiej z dnia 20 lutego 2024  r. (Dz. U. poz. 276)
USTAWA
z dnia 24 maja 2000  r.
o Krajowym Rejestrze Karnym1)
Rozdział 1
Przepisy ogólne
Art. 1. 1. Tworzy się Krajowy Rejestr Karny, zwany dalej „Rejestrem ”.
2. W Rejestrze gromadzi się dane o  osobach:
1) prawomocnie skazanych za przestępstwa lub przestępstwa skarbowe;
2) przeciwko którym prawomocnie warunkowo umorzono postępowanie karne w  sprawach o przestępstwa lub przestępstwa
skarbowe;
3) przeciwko którym prawomocnie umorzono postępowanie karne w  sprawach o  przestępstwa lub przestępstwa skarbowe
na podstawie amnestii;
4) będących obywatelami polskimi prawomocnie skazanymi przez sądy państw obcych ;
5) wobec których prawomocnie orzeczono środki zabezpieczające w  sprawach o  przestępstwa lub przestępstwa skarbowe;
6) nieletnich, wobec których prawomocnie orzeczono środki wychowawcze, środek leczniczy lub środek poprawczy na
podstawie ustawy z dnia 9 c zerwca 2022 r.

## Chunk 3
o wspieraniu i resocjalizacji nieletnich (Dz. U. poz. 1700  oraz z 2023 r.
poz. 289 i 1860);
7) prawomocnie skazanych za wykroczenia na karę aresztu;
8) poszukiwanych listem gończym;
9) tymczasowo aresztowanych;
10) nieletnich umieszczonych w  schroniskach dla nieletnich.
3. W Rejestrze gromadzi się również dane o  podmiotach zbiorowych, wobec których prawomocnie orzeczono karę
pieniężną, przepadek, zakaz lub podanie wyroku do publicznej wiadomości, na podstawie ustawy z  dnia 28 października
2002 r. o odpowiedzialności podmiotów zbiorowych za czyny zabronione pod groźbą kary (Dz.  U. z 2023 r. poz. 659).
Art. 1a. 1. Ilekroć w  ustawie jest mowa o:
1) organie centralnym państwa członkowskiego Unii Europejskiej – należy przez to rozumieć organ wyznac zony przez
to państwo do celów wymiany informacji pochodzących z  rejestru karnego pomiędzy państwami członkowskimi;
2) właściwym organie państwa obcego – należy przez to rozumieć organ państwa obcego uprawniony na podstawie
umowy międzynarodowej do wymiany  informacji pochodzących z  rejestru karnego lub organ centralny państwa członkow-
skiego Unii Europejskiej;
3) systemie ECRIS – należy przez to rozumieć zdecentralizowany system te

## Chunk 4
leinformatyczny oparty na bazach danych
rejestrów karnych, służący do wymiany informacji pomiędzy organami centralnymi państw członkowskich Unii Europej-
skiej poprzez zabezpieczoną sieć teleinformatyczną.
2. Na potrzeby przekazywania informacji organom centralnym państw członkowskich Unii Europejskiej za wyrok ska-
zujący uznaje się każde prawomocne orzeczenie wydane przez sąd karny wo bec osoby fizycznej w  związku z popełnieniem
przestępstwa, której dane podlegają gromadzeniu w  Rejestrze.

1) Niniejsza ustawa dokonuje w  zakresie swojej regulacji wdrożenia:
a) decyzji ramowej Rady 2009/315/WSiSW  z dnia 26 lutego 2009  r. w sprawie organizacji wymiany informacji pochodzących z  rejestru
karnego pomiędzy państwami członkowskimi oraz treści tych informacji (Dz. Urz. UE L 93  z 07.04.2009, str. 23),
b) decyzji Rady 2009/316/WSiSW z  dnia 6 kwietnia 2009  r. w sprawie ustanowienia europejskiego systemu przekazywania informacji
z rejestrów karnych (ECRIS), zgodnie z  art. 11 decyzji ramowej 2009/315/WSiSW (Dz. Urz. UE L 93 z 07.04.2009, str.  33).

Dziennik Ustaw – 3 – Poz. 276

Art. 2. 1. Rejestr prowadzi Minister Sprawiedliwości.

## Chunk 5
W  zakresie określonym w  niniejszej ustawie realizację zadań
związanych z  prowadzeniem Rejestru zapewnia wchodzące w  skład Ministerstwa Sprawiedliwości Biuro Informacyjne Krajo-
wego Rejestru Karnego, zwane dalej „biurem informacyjnym ”.
2. Biuro informacyjne jest organem centralnym Rzeczypospolitej Po lskiej w rozumieniu  art. 1a ust. 1 pkt 1.
Art. 3. (uchylony)
Art. 4. 1. Do zadań biura informacyjnego należy:
1) przetwarzanie danych osobowych oraz danych o  podmiotach zbiorowych, podlegających gromadzeniu w  Rejestrze;
2) zabezpieczanie danych osobowych oraz danych o  podmiotach zbiorowych zgromadzonych w  Rejestrze przed dostępem
osób nieuprawnionych;
3) przygotowywanie projektów decyzji, postanowień i  rozpatrywanie skarg w  sprawach dotyczących przetwarzania danych
osobowych oraz danych o  podmiotach zbioro wych zgromadzonych w  Rejestrze;
4) niezwłoczne przekazywanie właściwym organom państw obcych infor macji o wyrokach skazujących, o zastosowaniu
późniejszych środków oraz informacji związanych z  tym skazaniem w  odniesieniu do obywateli tych państw, podlegają-
cych gromadzeniu w  Rejestrze;
5) występowanie na wniosek podmiotów, o  których mowa w  art. 6 ust.

## Chunk 6
1 pkt 1–10 oraz w art. 7 ust. 1 i 1a, do organów
centralnych państw członkowskich Unii Europejskiej z  zapytaniem o  udzielenie informacji o  skazaniu z  rejestrów kar-
nych tych państw zgodnie z  prawem państwa, do którego kierowany jest wniosek;
5a) występowanie do organów centralnych państw członkowskich Unii Europejskiej, zgodnie z  prawem danego państwa
członkowskiego Unii Europejskiej, z  zapytaniem o  udzielenie in formacji z  rejestru karnego tego państwa o  osobie
będącej jego obywatelem, w  przypadku gdy osoba ta złożyła wniosek o  udzielenie informacji z  Rejestru;
6) niezwłoczne przekazywanie ministrowi właściwemu do spraw rozwoju regionalnego, ministrowi właściwemu do spraw
rybołówstwa oraz Prezesowi Agencji Restrukturyzacji i Modernizacji Rolnictwa informacji na temat wyroków skazują-
cych, zapadłych wobec:
a) osób fizycznych i  przedsiębiorców będących osobami fizycznymi, jeśli czyn zabroniony został popełniony na szk odę
interesów finansowych Wspólnot Europejskich,
b) osób upoważnionych do reprezentowania podmiotu zbiorowego, podejmowania w  jego imieniu decyzji lub sprawowania
nadzoru nad jego działalnością, jeśli czyn zabroniony został popełniony na szkodę intere

## Chunk 7
sów f inansowych Wspól-
not Europejskich,
c) podmiotów zbiorowych, jeśli czyn zabroniony osoby fizycznej stanowiący podstawę odpowiedzialności podmiotu
zbiorowego został popełniony na szkodę interesów finansowych Wspólnot Europejskich;
7) przekazywanie Marszałkowi  Sejmu informacji o:
a) posłach skazanych prawomocnym wyrokiem na karę pozbawienia wolności za przestępstwo umyślne ścigane
z oskarżenia publicznego lub za umyślne przestępstwo skarbowe oraz o  posłach pozbawionych praw publicznych
prawomocnym orzeczeniem s ądu,
b) posłach do Parlamentu Europejskiego karanych za przestępstwo popełnione umyślnie, ścigane z  oskarżenia pub -
licznego oraz o posłach do Parlamentu Europejskiego pozbawionych praw publicznych prawomocnym orzeczeniem
sądu;
8) przekazywanie Marszałkowi Senatu informacji o  senatorach skazanych prawomocnym wyrokiem na karę pozbawienia
wolności za przestępstwo umyślne ścigane z  oskarżenia publicznego lub za umyślne przestępstwo skarbowe oraz o  sena-
torach pozbawionych praw publicznych prawomocnym orzeczeniem  sądu;
9) prowadzenie Rejestru Sprawców Przestępstw na Tle Seksualnym, o którym mowa w u stawie z dnia 13 maja 2016 r.

## Chunk 8
o przeciwdziałaniu zagrożeniom przestępczością na tle seksualnym2) (Dz. U. z 2023 r. poz. 1304 i 1606 ), oraz prze-
twarzanie danych  osobowych podlegających gromadzeniu w tym rejestrze.

2) Obecnie ogólne określenie przedmiotu ustawy brzmi: o przeciw działaniu zagrożeniom przestępczością na tle seksualnym i ochronie
małoletnich , na podstawie art. 7 pkt 1 ustawy z dnia 28 lipca 2023 r.  o zmianie ustawy – Kodeks rodzinny i opiekuńczy oraz niektórych
innych ustaw  (Dz. U. poz. 1606), która weszła w życie z  dniem 15 lutego 2024 r.

Dziennik Ustaw – 4 – Poz. 276

1a. Informacje, o  których mowa w  ust. 1 pkt 4, przesyłane organom centralnym państw członkowskich Unii Europej-
skiej oraz zapytania, o  których mowa w  ust. 1 pkt 5 i 5a, i odpowiedzi na nie przekazywane s ą za pośrednictwem systemu
ECRIS, chyba że nie będzie to możliwe z  przyczyn technicznych.
1b. Informacje, o których mowa w ust. 1 pkt 6, Prezes Agencji Restrukturyzacj i i Modernizacji Rolnictwa może prze-
syłać kierownikom biur powiatowych tej Agencji.
2. Minister Sprawiedliwości jest administratorem danych zgromadzonych w  Rejestrze.
Art. 4a. Rejestr jest prowadzony w  systemie teleinformatycznym.
Art. 5.

## Chunk 9
Dane osobowe oraz dane o  podmiotach zbiorowych zgromadzone w  Rejestrze nie mogą być z  niego usunięte,
chyba że ustawa stanowi inaczej.
Art. 6. 1. Prawo do uzyskania informacji o  osobach, których dane osobowe zgromadzone zostały w  Rejestrze, przy -
sługuje:
1) Prezydentowi Rzeczypospolitej Polskiej;
2) Marszałkowi Sejmu Rzeczypospolitej Polskiej, w  odniesien iu do posłów;
3) Marszałkowi Senatu Rzeczypospolitej Polskiej, w  odniesieniu do senatorów;
3a) Marszałkowi Sejmu Rzeczypospolitej Polskiej, w  odniesieniu do posłów do Parlamentu Europejskiego;
3b) Państwowej Komisji Wyborczej, w  odniesieniu do kandydatów n a Prezydenta Rzeczypospolitej Polskiej;
3c) okręgowym komisjom wyborczym w  odniesieniu do kandydatów na posłów i  senatorów oraz kandydatów na posłów
do Parlamentu Europejskiego;
3d) terytorialnym komisjom wyborczym, w  odniesieniu do kandydatów na radnych;
3e) gminnym komisjom wyborczym, w  odniesieniu do kandydatów na wójta, burmistrza i  prezydenta miasta;
4) sądom sprawującym w  Rzeczypospolitej Polskiej wymiar sprawiedliwości, w  związku z  prowadzonym postępowaniem;
5) Trybunałowi Stanu i  Trybunałowi Konstyt ucyjnemu, w  związku z  prowadzonymi postępowaniami

## Chunk 10
;
6) prokuratorom, Policji i  innym organom uprawnionym do prowadzenia postępowania przygotowawczego w  sprawach
karnych i karnych skarbowych oraz czynności sprawdzających w  sprawach o wykroczenia, w  związku z  prowadzonym
postępowaniem;
7) Agencji Bezpieczeństwa Wewnętrznego, Agencji Wywiadu, Służbie Kontrwywiadu Wojskowego, Służbie Wywiadu
Wojskowego, Policji, Straży Granicznej, Służbie Więziennej, Służbie Ochrony Państwa, Krajowej Administracji Skar-
bowej, Straży Marszałkowskiej, Centralnemu Biuru Antykorupcyjnemu, Biuru Nadzoru Wewnętrznego, Szefowi Krajo-
wego Centrum Informacji Kryminalnych w zakresie, w jakim jest to konieczne do wykonywania nałożonych na nich
zadań określonych w ustawie;
7a) (uchylony)
7b) Przewodniczącemu Komisji Nadzoru Finansowego lub upoważnionemu przez niego przedstawicielowi, w  związku
z wykonywaniem czynności w  ramach nadzoru sprawowanego przez Komisję Nadzoru Finansowego;
7c) Komisji do spraw reprywatyzacji nieruchomości warszawskich , w związku z prowadzonymi czynnościami sprawdza-
jącymi, postępowan iem rozpoznawczym lub ogólnym;
8) organom wykonującym orzeczenia w  postępowaniu karnym, w  sprawach o  przestępstwa skarbowe i  wykroczenia skar

## Chunk 11
-
bowe, w sprawach o  wykroczenia oraz w  sprawach ni eletnich, w  związku z  prowadzonym postępowaniem wykonaw-
czym, w zakresie, w  jakim jest to konieczne do wykonania orzeczenia;
9) organom administracji rządowej, organom samorządu terytorialnego oraz innym organom wykonującym zadania pub -
liczne, w przypadkach  kiedy jest to uzasadnione potrzebą wykonania nałożonych na nie zadań, określonych w  ustawie;
10) pracodawcom, w  zakresie niezbędnym dla zatrudnienia pracownika, co do którego z  przepisów ustawy wynika wymóg
niekaralności, korzystania z  pełni praw publiczn ych, a także ustalenia uprawnienia do zajmowania określonego stano-
wiska, wykonywania określonego zawodu lub prowadzenia określonej działalności gospodarczej;

Dziennik Ustaw – 5 – Poz. 276

10a) osobom prawnym oraz jednostkom organizacyjnym niebędącym osobami prawnymi, którym ustawa przy znaje zdol-
ność prawną – w przypadkach, w których z przepisów ustawy wynika wymóg niekaralności członków ich organów,
wspólników lub prokurentów, w odniesieniu do członków lub kandydatów na członków tych organów, wspólników
lub prokurentów;
11) władzom państw obcych, jeżeli wynika to z  ratyfikowanej umowy międzynarodowej, a  w

## Chunk 12
przypadku braku takiej
umowy, pod warunkiem wzajemności;
12) organom centralnym państw członkowskich Unii Europejskiej w  terminie nieprzekraczającym 10  dni roboczych od
dnia otrzyma nia zapytania, a  w przypadku, gdy zapytanie zostało złożone w  celu udzielenia przez te organy informacji
osobie fizycznej na jej temat, w  terminie nieprzekraczającym 20  dni roboczych od dnia otrzymania zapytania.
1a. Informacje, o których mowa w ust. 1 pkt  3b–3e, przekazuje się niezwłocznie, nie późnie j jednak niż w terminie
3 dni.
2. Przepisy ust. 1 pkt 1, 4–9 i 11 stosuje się odpowiednio do uzyskiwania zgromadzonych w  Rejestrze informacji
o podmiotach zbiorowych.
Art. 6a. 1. Informacje uzyskane na podstaw ie art. 4 ust. 1 pkt 5 przez organy, o  których mowa w  art. 6 ust. 1 pkt 1–10,
mogą być wykorzystywane wyłącznie dla celów postępowania, w  związku z  którym się o  nie zwrócono.
2. W celu uniknięcia natychmiastowego i  poważnego zagrożenia bezpieczeństwa publicznego informacje, o  których
mowa w ust. 1, mogą być wykorzystane przez organy, o  których mowa w  art. 6 ust. 1 pkt 1–9, niezależnie od postępowania,
w związku z  którym się o  nie zwrócono.
Art. 7. 1.

## Chunk 13
Każdemu przysługuje prawo do uzyskania informacji, c zy jego dane osobowe zgromadzone są w  Rejestrze.
Osobie, której dane osobowe znajdują się w  zbiorach danych zgromadzonych w  Rejestrze, na jej wniosek, udostępnia się
informację o  treści wszystkich zapisów dotyczących tej osoby.
1a. Każdemu obywatelowi Rzec zypospolitej Polskiej lub innego państwa członkowskiego Unii Europejskiej oraz każdej
osobie, która mieszka lub mieszkała w  jednym z tych państw, przysługuje prawo do złożenia do Rejestru wniosku o  wystąpienie
z zapytaniem o  informację dotyczącą jego osoby  zawartą w  rejestrze karnym innego państwa członkowskiego Unii Euro-
pejskiej, jeżeli jest lub była obywatelem państwa, do którego kierowane jest zapytanie, lub mieszka albo mieszkała na jego
terytorium.
2. Każdemu podmiotowi zbiorowemu przysługuje prawo do uzyskania informacji, czy jego dane są zgromadzone
w Rejestrze. Podmiotowi, którego dane znajdują się w  zbiorach danych zgromadzonych w  Rejestrze, na jego wniosek, udo-
stępnia się informację o  treści wszystkich zapisów dotyczących tego podmiotu.
3.

## Chunk 14
Minister Sprawiedliwości określi, w  drodze rozporządzenia, wzór formularza zapytania o  udzielenie informacji
pochodzących z  rejestru karnego i  odpowiedzi na zapytanie, wykorzystywany między organami centralnymi państw człon -
kowskich Unii Europejskiej.
Art. 8. 1. Zgromadzone w  zbiorach Rejestru dane osobowe mogą być przetwarzane i  wykorzystywane do badań nauko-
wych, a także, po pozbawieniu tych danych informacji identyfikujących osobę, do celów statystycznych.
2. Udostępnione dane osobowe można wykorzystać wyłącznie zgodnie z  przeznaczeniem, dla którego zostały udostęp-
nione.
3. Administrator danych odmawia udostępnienia danych osobowych, jeżeli spowodowałoby to:
1) ujawnienie wiadomości zawierających informacje niejawne;
2) zagrożenie dla obronności lub bezpieczeństwa  państwa, życia i  zdrowia ludzi lub bezpieczeństwa i  porządku pub licz-
nego;
3) zagrożenie dla podstawowego interesu gospodarczego lub finansowego państwa;
4) istotne naruszenie dóbr osobistych osób, których dane dotyczą, lub innych osób.
4. Minister Sprawi edliwości określi, w  drodze rozporządzenia, szczegółowe zasady i  sposób przetwarzania oraz przeka -
zywania danych, o  których mowa w  ust.

## Chunk 15
1, do celów statystycznych oraz badań naukowych, mając na uwadze potrzebę
corocznego przygotowania odpowiednich informac ji dla oceny stopnia zagrożenia przestępczością.
Art. 9. Do postępowania prowadzonego na podstawie niniejszej ustawy stosuje się przepisy Kodeksu postępowania
administracyjnego, chyba że ustawa stanowi inaczej.

Dziennik Ustaw – 6 – Poz. 276

Rozdział 2
Zasady i sposób przetwarzania dany ch osobowych
Art. 10. 1. Dane o  osobach, o  których mowa w  art. 1 ust. 2, oraz dane o  podmiotach zbiorowych, o  których mowa
w art. 1 ust. 3, gromadzone są w  kartotekach stanowiących zbiory ewidencyjne dokumentów lub w  bazie danych systemu
teleinformatyczneg o.
2. Dane przekazywane do Rejestru za pośrednictwem systemu teleinformatyc znego mogą nie być gromadzone w kartotekach
stanowiących zbiory ewidencyjne dokumentów.
3. Dane gromadzone zarówno w  kartotekach stanowiących zbiory ewidencyjne dokumentów, jak i w bazie danych systemu
teleinformatycznego, są tożsame.
Art. 11. 1. Dokumentami, na podstawie których przetwarza się dane osobowe lub dane o  podmiotach zbiorowych, są:
1) karta rejestracyjna;
2) zawiadomienie o  zmianach ewidencyjnych, zwane dalej „zawiadomieniem ”;
3

## Chunk 16
) zawiadomienie dotyczące podmiotu zbiorowego;
4) zawiadomienie o  skazaniu przez sąd państwa obcego, o  zastosowaniu późniejszych środków oraz informacje związane
z tym skazaniem.
2. Kartę rejestracyjną sporządza sąd pierwszej instancji ni ezwłocznie po uprawomocnieniu się orzeczenia wydanego
wobec osoby, o  której mowa w  art. 1 ust. 2 pkt 1–7, lub wobec podmiotu zbiorowego, o  którym mowa w  art. 1 ust. 3.
3. Zawiadomienie jest sporządzane przez:
1) organ wykonujący orzeczenie w  postępowaniu k arnym w sprawach o  przestępstwa i  przestępstwa skarbowe oraz w  spra-
wach nieletnich;
2) sąd orzekający o  tymczasowym aresztowaniu wykonywanym w  zakładzie leczniczym lub umieszczeniu nieletniego
w schronisku dla  nieletnich;
3) sąd wydający postanowienie o  poszukiwaniu listem gończym;
4) prokuratora wydającego postanowienie o  poszukiwaniu listem gończym lub o  uchyleniu tymczasowego aresztowania.
4. Zawiadomienie dotyczące podmiotu zbiorowego sporządza organ wykonujący orzeczenie w  postępowaniu karnym
w sprawach o przestępstwa i  przestępstwa skarbowe.
5.

## Chunk 17
Zawiadomienie o  skazaniu przez sąd państwa obcego, o  zastosowaniu późniejszych środków oraz informacje związane
z tym skazaniem sporządza i  przesyła właściwy organ państwa obcego.
6. Zawiadomienia o  skazaniu, o  zastosowaniu późniejszych środków oraz informacje związane z  tym skazaniem prze-
syłane przez organy centralne państw członkowskich Unii Europejskiej przekazywane są za pośrednictwem systemu ECRIS,
chyba że nie będzie to możliwe z  przyczyn technicznych.
Art. 12. 1. W karcie rejestracyjnej dotyczącej osoby umieszcza się:
1) dane identyfikujące osobę – nazwisko, w  tym także przybrane, imiona, nazwisko rodowe, płeć, datę i  miejsce urodzenia,
państwo urodzenia, imiona rodziców, obywatelstwo lub obywatelstwa, naz wisko rodowe matki, miejsce zamieszkania,
zawód wyuczony i  wykonywany, informacje o  wykonywaniu funkcji posła, senatora lub posła do Parlamentu Europej-
skiego, a także numer identyfikacyjny Powszechnego Elektronicznego Systemu Ewidencji Ludności, zwany dale j
„numerem PESEL”, oraz numer i  serię dowodu tożsamości;
2) oznaczenie organu, który wydał orzeczenie, oraz sygnaturę akt sprawy;
3) datę wydania oraz uprawomocnienia się orzeczenia;
4) datę i miejsce po

## Chunk 18
pełnienia czynu zabronionego, będącego przedmiotem po stępowania;
5) kwalifikację prawną czynu zabronionego przyjętą w  orzeczeniu;
5a) informację, że pokrzywdzonym był małoletni poniżej lat 15  – w przypadku skazania za przestępstwo przeciwko wol-
ności seksualnej i  obyczajności na karę pozbawienia wolności bez warunkowego zawieszenia jej wykonania;
5b) informację o wieku małoletniego pokrzywdzonego w czasie czynu, jeśli w k walifikacji prawnej przyjętej w orzeczeniu
powołano przepis, o którym mowa w rozdziale XXV Kodeksu karnego, z wyjątkiem wy łączeń, o których mowa w art. 2
ustawy z dnia 13 maja 2016 r. o przeciwdziałaniu zagrożeniom przestępczością na tle seksualnym2);

Dziennik Ustaw – 7 – Poz. 276

5c) informację o wyłączeniu przez sąd zamieszcz enia danych o osobie w Rejestrze Sprawców Przestępstw na Tle Seksualnym
z dostępem ograniczonym lub publicznym, o którym mowa w u stawie z dnia 13 maja 2016 r. o przeciwdziałaniu
zagrożeniom przestępczością na tle seksualnym2);
5d) informację, czy orzeczenie podlega zamieszczeniu w Rejestrze Sprawców Przestę pstw na Tle Seksualnym, jeśli w  kwali-
fikacji prawnej przyjętej w orzeczeniu powołano art. 202 § 3 lub art.

## Chunk 19
2 02 § 4b Kodeksu karnego;
6) informacje o orzeczonych karach, warunkowym umorzeniu postępowania, środkach karnych, kompensacyjnych, zabez -
pieczających , wychowawczych, środku leczniczym, środku poprawczym, przepadku, okresie próby, dozorze kuratora
i nałożonych obowiązkach oraz podstawę prawną ich orzeczenia;
6a) informację, że osoba jest upoważniona do reprezentowania podmiotu zbiorowego, podejmowania w  jego imieniu
decyzji lub sprawowania nadzoru nad jego działalnością, jeśli czyn zabroniony został p opełniony na szkodę interesów
finansowych Wspólnot Europejskich;
6b) informację, że czyn zabroniony popełniony przez przedsiębiorcę będącego osobą fizyczną został popełniony na szkodę
interesów finansowych Wspólnot Europejskich;
6c) informację o  przejęciu do wykonania kary orzeczonej przez właściwy organ sądowy państwa członkowskiego Unii
Europejskiej, w  tym oznaczenie organu, który wydał orzeczenie, państwa wydania orzeczenia, sygnaturę akt sprawy
oraz datę wydania orzeczenia;
7) nazwisko, imię, stanowisko  oraz podpis osoby sporządzającej.
1a.

## Chunk 20
W karcie rejestracyjnej dotyczącej podmiotu zbiorowego umieszcza się:
1) oznaczenie podmiotu zbiorowego oraz jego siedziby;
2) oznaczenie sądu, który wydał wyrok oraz sygnaturę akt sprawy;
3) datę wydania oraz uprawom ocnienia się wyroku;
4) orzeczoną karę pieniężną, przepadek, zakaz oraz podanie wyroku do publicznej wiadomości;
5) kwalifikację prawną czynu zabronionego osoby fizycznej stanowiącego podstawę odpowiedzialności podmiotu zbio-
rowego;
5a) informację, że czyn zabroniony osoby fizycznej stanowiący podstawę odpowiedzialności podmiotu zbiorowego został
popełniony na szkodę interesów finansowych Wspólnot Europejskich;
6) nazwisko, imię, stanowisko oraz podpis osoby sporządzającej.
1b. Karty rejestracyjne przekazywa ne za pośrednictwem systemu teleinformatycznego opatruje się zaawansowanym
podpisem elektronicznym weryfikowanym certyfikatem wystawianym przez Ministra Sprawiedliwości.
2. Zawiadomienie zawiera nazwisko, w  tym także przybrane, imiona, nazwisko rodowe, dat ę i miejsce urodzenia,
imiona rodziców, obywatelstwo, nazwisko rodowe matki, miejsce zamieszkania, numer PESEL, a  także nazwisko, imię,
stanowisko i  podpis osoby sporządzającej oraz informacje o:
1) rozesła

## Chunk 21
niu oraz odwołaniu listów gończych;
2) zastosowani u oraz zakończeniu stosowania tymczasowego aresztowania, a  także miejscu osadzenia tymczasowo aresz-
towanego;
3) rozpoczęciu, zakończeniu oraz miejscu wykonywania kar: dożywotniego pozbawienia wolności, 25  lat pozbawienia
wolności, pozbawienia wolności, are sztu wojskowego i  aresztu;
3a) rozpoczęciu, zakończeniu oraz miejscu wykonywania zastępczej kary pozbawienia wolności;
4) zarządzeniu wykonania warunkowo zawieszonej kary pozbawienia wolności oraz o  skróceniu orzeczonej kary na podstawie
art. 75 § 3a Kodek su karnego;
5) odroczeniu i  przerwie wykonania kary pozbawienia wolności;
6) warunkowym zwolnieniu i  odwołaniu takiego zwolnienia;
6a) zamianie kary pozbawienia wolności z  warunkowym zawieszeniem jej wykonania na karę ograniczenia wolności w for-
mie obowiąz ku wykonywania nieodpłatnej, kontrolowanej pracy na cele s połeczne albo na grzywnę oraz o uchyleniu  tej
zamiany;
6b) zamianie kary pozbawienia wolności wykonywanej w  systemie dozoru elektronicznego na karę ograniczenia wolności,
z zastosowaniem dozoru elek tronicznego oraz o  uchyleniu tej zamiany;

Dziennik Ustaw – 8 – Poz.

## Chunk 22
276

6c) zamianie kary pozbawienia wolności na karę ograniczenia wolności w  formie obowiązku wykonywania nieodpłatnej
kontrolowanej pracy na cele społeczne oraz o  uchyleniu tej zamiany;
7) (uchylony)
8) zamianie kary ograniczenia wolności na zastępczą karę pozbawienia wolności;
9) zwolnieniu z  odbycia reszty kary ograniczenia wolności;
10) zawieszeniu wykonania odroczonej kary pozbawienia wolności;
11) podjęciu warunkowo umorzonego postępowania karnego w  sprawach o  przestępstwa lub przestępstwa skarbowe;
12) zamianie grzywny na zastępczą karę pozbawienia wolności albo na pracę społecznie użyteczną;
13) wykonaniu przez podmiot odpowiedzialny posiłkowo kary grzywny lub środka karnego ściągnięcia równowartości
pieniężnej p rzepadku przedmiotów;
14) wykonaniu kar;
15) wykonaniu środków karnych, z  wyjątkiem środków określonych w  art. 22 § 2 pkt 1 Kodeksu karnego skarbowego oraz
w art. 28 § 1 pkt 4 Kodeksu wykroczeń, środków kompensacyjnych i  przepadku;
16) rozpoczęciu, zakończ eniu i miejscu wykonywania oraz uchyleniu środków zabezpieczających, o  których mowa w  art.

## Chunk 23
93a
§ 1 Kodeksu karnego, oraz o  uchyleniu lub wykonaniu pozostałych środków zabezpieczających;
17) umorzeniu postępowania wykonawczego;
18) odwołaniu warunkowego zaw ieszenia umieszczenia w zakładzie poprawczym i zarządzeniu umieszczenia w zakładzie
poprawczym;
19) warunkowym zwolnieniu z zakładu poprawczego, a także odwołaniu warunkowego zwolnienia z zakładu poprawczego
i zarządzeniu umieszczenia w zakładzie poprawczy m;
20) warunkowym odstąpieniu od wykonania orzeczenia o umieszczeniu w zakładzie poprawczym, a także odwołaniu
warunkowego odstąpienia od wykonania orzeczenia o umieszczeniu w zakładzie poprawczym i zarządzeniu umieszczenia
w zakładzie poprawczym;
20a) (uchylony)
20b) zastosowaniu środka wychowawczego, o którym mowa w art. 7 pkt 2 lub 5 ustawy z dnia 9 czerwca 2022 r. o wspie-
raniu i resocjalizacji nieletnich, wobec nieletniego zwalnianego z zakładu poprawczego po ukończeniu 21 lat;
20c) przedłużeniu wyko nywania środka poprawczego wobec nieletniego, który ukończył 21 lat;
20d) zastosowaniu środka wychowawczego, o którym mowa w art. 7 pkt 2 lub 5 ustawy z dnia 9 czerwca 2022 r.

## Chunk 24
o wspie-
raniu i resocjalizacji nieletnich, wobec nieletniego zwalnianego z zakła du poprawczego po ukończeniu 24 lat;
21) zmianie albo uchyleniu środka wychowawczego;
22) odroczeniu albo przerwaniu wykonywania środków wychowawczych lub środka poprawczego, a także odwołaniu
odroczenia albo przerwy;
23) odstąpieniu od stosowania orzeczon ego środka wychowawczego;
24) umieszczeniu, przedłużeniu pobytu w  schronisku dla nieletnich lub zwolnieniu nieletniego ze schroniska;
25) powołaniu nieletniego do obowiązkowej zasadniczej służby wojskowej lub służby zastępczej;
25a) zwolnieniu z zakładu le czniczego oraz o zastosowaniu środka wychowawczego;
25b) przerwaniu wykonywania środka wychowawczego lub poprawczego i zastosowaniu środka leczniczego;
26) uchyleniu prawomocnego orzeczenia w  wyniku kasacji;
26a) zamianie orzeczonej kary na inną karę, pod legającą gromadzeniu w  Rejestrze, w  przypadku gdy według nowej ustawy  za
czyn objęty wyrokiem nie można orzec kary w  wysokości kary orzeczonej albo gdy czyn zabroniony objęty prawomoc-
nym wyrokiem skazującym za przestępstwo stanowi wykroczenie;
27) zastosowaniu amnestii;
28) ułaskawieniu przez Prezydenta Rzeczypospolitej Polskiej;

Dzienn

## Chunk 25
ik Ustaw – 9 – Poz. 276

29) wznowieniu postępowania sądowego zakończonego prawomocnym orzeczeniem odnotowanym w  Rejestrze;
30) stwierdzeniu nieważności prawomocnego orzeczenia sądu odnotowanego w  Rejestrze;
31) przywróceniu terminu do zaskarżenia orzeczenia odnotowanego w  Rejestrze;
32) zarządzeniu zatarcia skazania;
33) śmierci osoby, której dane osobowe zgromadzono w  Rejestrze;
34) (uchylony)
35) (uchylony)
36) przekazaniu do wykonania orzeczonej  kary właściwemu organowi sądowemu państwa członkowskiego Unii Europej-
skiej oraz o  jej wykonaniu przez ten organ ;
37) przywróceniu terminu do zaskarżenia orzeczenia w przedmiocie zamieszczenia danych o osobie w Rejestrze Sprawców
Przestępstw na Tle Seksual nym z dostępem ograniczonym lub publicznym, o którym mowa w ustawie z dnia 13  maja
2016 r. o przeciwdziałaniu zagrożeniom przestępczością na tle seksualnym2);
38) uchyleniu orzeczenia w przedmiocie zamieszczenia danych o osobie w Rejestrze Sprawców Przestępstw na Tle Seksualnym
z dostępem ograniczonym lub publicznym, o którym mowa w u stawie z dnia 13 maja 2016 r.

## Chunk 26
o przeciwdziałaniu
zagrożeniom przestępczością na  tle seksualnym2);
39) przywróceniu terminu do złożenia wniosku o wyłączenie zamieszczenia danych w Rejestrze Sprawców Przestępstw na
Tle Seksualnym z dostępem ograniczonym lub publicznym, o którym mowa w art . 29 ust. 2 ustawy z dnia 13 maja
2016 r. o przeciwdziałaniu zagrożeniom przestępczością na tle seksualnym2).
2a. Zawiadomienie dotyczące podmiotu zbiorowego z awiera dane, o  których mowa w  ust. 1a pkt 1, 2 i 6, oraz infor-
macje o:
1) wykonaniu kary pieniężnej, przepadków, zakazów oraz podania wyroku do publicznej wiadomości, o  których mowa
w art. 7, 8 i 9 ustawy z dnia 28 października 2002  r. o odpowiedzialności podmiotów zbiorowych za czyny zabronione
pod groźbą kary;
2) zatarciu orzeczenia stwierdzającego odpowiedzialność podmiotu zbiorowego za czyn zabroniony pod groźbą kary;
3) likwidacji podmiotu zbiorowego, którego dane zgromadzono w  Rejestrze.
2b. Informacj a o wyroku skazującym przekazywana organom centralnym państw członkowskich Unii Europejskiej
przez biuro informacyjne zawiera dane określone w  ust. 1 pkt 1–6b, chyba że w  poszczególnym przypadku nie są one znane.
2c.

## Chunk 27
Informacja o zastosowaniu późniejszych środków przekazywana organom centralnym państw członkowskich Unii
Europejskiej zawiera dane określone w ust. 1 pkt 1 –6b oraz w ust. 2 pkt 4 –6, 8–12, 14, 15, 17 i 26 –33 oraz dane o  uchyleniu,
zakończeniu lub wykonaniu środków zabezpieczających. Dane określo ne w ust. 2 pkt 18 –25b umieszcza się w  informacji,
jeżeli środek wychowawczy, leczniczy lub poprawczy został orzeczony przez sąd karny.
2d. Zawiadomienia, o których mowa w art. 11 ust. 1 pkt 2 i 3, przekazywane za pośrednictwem systemu teleinformatycznego
opatruje się zaawansowanym podpisem elektronicznym weryfikowanym certyfikatem wystawianym przez Ministra Sprawiedli-
wości.
2e. (uchylony)
3. Minister Sprawiedliwości określi, w drodze rozporządzenia, szczegółowość informacji umieszczanych na podstawie
ust. 1–2a w karcie rejestracyjnej i w zawiadomieniu, uwzględniając zakres danych zawartych w Rejestrze oraz konieczność
zapewnienia niezwłocznej ich aktualizacji.
4. Minister Sprawiedliwości określi, w  drodze rozporządzenia:
1) wymogi techniczne, jakie musi spe łniać aplikacja do przesyłania kart rejestracyjnych i  zawiadomień za pośrednictwem
systemu teleinformatycznego,
2) tryb przy

## Chunk 28
znawania, zmieniania i  wycofywania oraz sposób weryfikacji podpisu elektronicznego do podpisywania kart
rejestracyjnych i  zawiadomie ń za pośrednictwem systemu teleinformatycznego
– mając na uwadze konieczność zapewnienia zgodności używanych formatów i  innych parametrów technicznych tej aplikacji
z wymogami systemu teleinformatycznego Krajowego Rejestru Karnego, zapewnienia bezpieczeńst wa przetwarzanych
danych oraz konieczność zapewnienia poufności tworzenia i  wydawania zaświadczenia certyfikacyjnego.

Dziennik Ustaw – 10 – Poz. 276

Art. 12a. 1. Przy przekazywaniu za pośrednictwem systemu ECRIS informacji dotyczących kwalifikacji prawnej
czynu zabronionego przyjętej w orzeczeniu oraz orzeczonych kar i środków karnych, jak również środków zabezpieczają-
cych, kompensacyjnych i przepadku, środków wychowawczych, leczniczych i poprawczych stosuje się kod odpowiadający
tym kwalifikacjom i karom oraz środkom karnym, kompensacyj nym i przepadkowi, jak również środkom zabezpieczają-
cym, wychowawczym, leczniczym i poprawczym.
2. Minister Sprawiedliwości określi, w  drodze rozporządzenia, wykaz kodów, o  których mowa w  ust.

## Chunk 29
1, oraz sposób
ich zastosowania, mając na uwadze konieczność za pewnienia sprawnego przekazywania danych.
Art. 12b. Dane zawarte w  zawiadomieniach, o  których mowa w  art. 11 ust. 1 pkt 4, podlegają gromadzeniu w Rejestrze,
z wyjątkiem odcisków palców.
Art. 13. W Rejestrze prowadzi się wyodrębnione kartoteki:
1) kart rejestracyjnych i  zawiadomień, zawierających informacje o  osobach odpowiadających na zasadach określonych
w Kodeksie karnym, Kodeksie karnym skarbowym, Kodeksie wykroczeń oraz zawiadomień o  skazaniu przez sąd państwa
obcego i informacji z  tymi skazaniami zwią zanymi;
2) kart rejestracyjnych i zawiadomień, zawierających informacje o nieletnich, w rozumieniu przepisów ustawy z dnia
9 czerwca 2022 r. o wspieraniu i resocjalizacji nieletnich;
3) zawiadomień zawierających informacje o  osobach pozbawionych wolności o raz osobach poszukiwanych listem gończym;
4) kart rejestracyjnych i  zawiadomień, zawierających informacje o  podmiotach zbiorowych podlegających odpowiedzial-
ności na podstawie przepisów ustawy z  dnia 28 października 2002  r. o odpowiedzialności podmiotów zbi orowych za
czyny zabronione pod groźbą kary.
Art. 14. 1.

## Chunk 30
Dane osobowe osób, o  których mowa w  art. 1 ust. 2 pkt 1, 3 i 7, oraz dane o  podmiotach zbiorowych, o  których
mowa w art. 1 ust. 3, usuwa się z  Rejestru, jeżeli z  mocy prawa skazanie uległo zatarciu, a ponadto po otrzymaniu zawiado-
mienia o:
1) zarządzeniu zatarcia skazania przez sąd, na podstawie  art. 107 § 2 oraz art. 337 Kodeksu karnego;
2) zatarciu skazania w  drodze ułaskawienia lub na podstawie amnestii;
3) przywróceniu terminu do zaskarżenia orzeczenia odnotowanego w  Rejestrze albo  uchyleniu takiego orzeczenia w wyniku
kasacji lub wznowienia postępowania;
4) stwierdzeniu nieważności orzeczenia odnotowanego w  Rejestrze;
5) zwolnieniu skazanego od kary pozbawienia wolności, na podstawie  art. 336 § 3 i 4 Kodeksu karnego, lub od kary
ograniczenia wolności, na podstawie  art. 62 § 2 Kodeksu karnego wykonawczego.
1a. Dane osobowe osób, o  których mowa w  art. 1 ust. 2 pkt 2, usuwa się z  Rejestru po upływie terminu określonego
w art. 68 § 4 Kodeksu karne go, a ponadto po otrzymaniu zawiadomienia o  podjęciu warunkowo umorzonego postępowania
karnego lub postępowania w  sprawie o  przestępstwo skarbowe.
2. Dane osobowe nieletniego, o  którym mowa w  art. 1 ust.

## Chunk 31
2 pkt 6, usuwa się z  Rejestru:
1) po ukończeniu 18. roku życia przez nieletniego, wobec którego wykonywane były środki wychowawcze lub środek
leczniczy, z wyjątkiem przypadków, gdy:
a) środek wychowawczy zastosowano w  okresie warunkowego zawieszenia wykonania umieszczenia w  zakładzie
poprawczym,
b) wykonani e środka wychowawczego ustało z mocy prawa po ukończeniu przez nieletniego 19. roku życia lub
21. roku życia albo z chwilą powołania nieletniego do obowiązkowej zasadniczej służby wojskowej lub służby
zastępczej,
c) wykonanie środka wychowawczego, o którym  mowa w art. 7 pkt 2 lub 5 ustawy z dnia 9 czerwca 2022 r. o  wspie-
raniu i resocjalizacji nieletnich, po ukończeniu przez nieletniego 21 lat ustało z mocy prawa z chwilą ukończenia
przez nieletniego wieku, do którego sąd rodzinny orzekł o wykonywaniu tego ś rodka,
d) wykonanie środka wychowawczego, o którym mowa w art. 7 pkt 2 lub 5 ustawy z dnia 9 czerwca 2022 r. o  wspie-
raniu i resocjalizacji nieletnich, po ukończeniu przez nieletniego 24 lat ustało z mocy prawa z chwilą ukończenia
przez nieletniego 25 lat;
2) po upływie terminów określonych w art. 16 ust. 6, art. 96, art. 235 ust. 6 i art. 237 ust.

## Chunk 32
6 ustawy z dnia 9 czerwca 2022 r.
o wspieraniu i resocjalizacji nieletnich.
3) (uchylony)
4) (uchylony)

Dziennik Ustaw – 11 – Poz. 276

3. Dane osób, o  których mowa w  art. 1 ust. 2 pkt 5, usuwa się z Rejestru:
1) z upływem 3  lat od uchylenia środka zabezpieczającego, o  którym mowa w  art. 93a § 1, art. 99 Kodeksu karnego lub
art. 43 § 1 pkt 1 i § 2 Kodeksu karnego skarbowego;
2) z upływem 3  lat od wykonania przepadku lub środka zabezpieczającego  orzeczonego na podstawie  art. 45a Kodeksu
karnego lub  art. 43 § 1 pkt 2–5 Kodeksu karnego skarbowego.
4. Dane osoby tymczasowo aresztowanej usuwa się z  Rejestru po otrzymaniu zawiadomienia o  zakończeniu stosowania
tego środka zapobiegawczego.
5. Dane osob y poszukiwanej listem gończym usuwa się z  Rejestru po otrzymaniu zawiadomienia o  odwołaniu listu
gończego.
6. Dane osobowe nieletniego umieszczonego w  schronisku dla nieletnich usuwa się z  Rejestru po otrzymaniu zawia-
domienia o  jego zwolnieniu.
7. Dane osób zmarłych usuwa się z  Rejestru po uzyskaniu zawiadomienia o  ich zgonie.
8. Dane osób, o  których mowa w  art. 1 ust.

## Chunk 33
2 pkt 4, usuwa się z  Rejestru po otrzymaniu zawiadomienia o  zatarciu ska-
zania przesłanego przez właściwy organ państwa obcego, które wydało wyrok.
Art. 14a. Informacja o  osobie sporządzona na podstawie danych zgromadzonych w  Rejestrze dla celów innych niż
postępowanie karne nie zawiera danych o  skazaniach, o  których mowa w  art. 1 ust. 2 pkt 4, jeżeli od daty uprawomocnienia
się orzeczenia upłynął okres wskazany w  art. 76 § 1 albo art. 107 Kodeksu karnego w  stosunku do określonych w  nich kar
oraz środków karnych.
Art. 15. Dane oraz informacje podlegające gromadzeniu w  Rejestrze, zawarte w  dokumentach, o  których mowa w  art. 11
ust. 1, wprowad za się niezwłocznie do bazy danych systemu teleinformatycznego.
Art. 16. Do wprowadzania danych do bazy danych systemu teleinformatycznego oraz do dokonywania zmian w  bazie
danych tego systemu uprawnione są wyłącznie osoby upoważnione przez Ministra Sprawi edliwości.
Art. 17. Minister Sprawiedliwości określi, w  drodze rozporządzenia, warunki, w  tym techniczne i  organizacyjne, spo -
sób oraz tryb gromadzenia danych osobowych oraz danych o  podmiotach zbiorowych w  Rejestrze oraz usuwania tych
danych z Rejestru, m ając na uwad

## Chunk 34
ze konieczność zapewnienia sprawnego funkcjonowania Rejestru oraz zabezpieczenia
gromadzonych w  nim danych osobowych oraz danych o  podmiotach zbiorowych przed dostępem osób nieuprawnionych,
wykorzystywaniem przez osoby nieuprawnione, uszkodzeni em lub zniszczeniem.
Art. 18. 1. W przypadku stwierdzenia okoliczności wskazujących na prawdopodobieństwo wprowadzenia do Rejestru
danych osobowych lub danych o  podmiotach zbiorowych sprzecznych z  treścią orzeczenia lub nieodpowiadających zapisom
w odpowiednich aktach przeprowadza się postępowanie w  celu ustalenia p rawidłowych danych. Adnotację o wszczęciu
takiego postępowania umieszcza się na odpowiedniej karcie rejestracyjnej lub zawiadomieniu.
2. Prawomocna decyzja, rozstrzygająca o  sprostowaniu, stanowi  podstawę do dokonania zmiany odpowiednich zapisów
na karcie rejestracyjnej lub zawiadomieniu.
3. Sprostowanie oczywistych błędów pisarskich i  innych omyłek nie wymaga przeprowadzenia postępowania, jeżeli
następuje z  urzędu lub jest zgodne z  wnioskiem stro ny. Czynność taką utrwala się w  formie adnotacji na właściwej karcie
rejestracyjnej lub zawiadomieniu, a  o jej dokonaniu zawiadamia się stronę.
Art. 19. 1.

## Chunk 35
Informacji o  osobie na podstawie zgromadzonych w  Rejestrze danych osobowych udziela się na zapytanie
podmiotów wymienionych w  art. 6 ust. 1 lub na wniosek osoby, o  której mowa w  art. 7 ust. 1.
1a. Informacji o  podmiocie zbiorowym na podstawie danych o  tym podmiocie zgromadzonych w  Rejestrze udziela się  na
zapytanie podmiotów wymienionych w  art. 6 ust. 1 pkt 1, 4–9 i 11 lub na wniosek podmiotu, o  którym mowa w  art. 7 ust. 2.
1aa. Podmioty wymienione w  art. 6 ust. 1 pkt 4–7 i 8 mogą uzyskiwać informacje o  osobie i informacje o  podmiocie
zbiorowym na podstawie danych zgromadzonych w  Rejestrze także na żądani e.
1b. Zapytania i  wnioski, o  których mowa w  ust. 1 i 1a, mogą być składane pisemnie albo za pośrednictwem systemu
teleinformatycznego , a żądania, o  których mowa w  ust. 1aa, są składane za pośrednictwem systemu teleinformatycznego.
1c. Przepisu ust. 1b nie stosuje się do zapytań przekazywanych do Rejestru za pośrednictwem systemu ECRIS.
2. Zapytanie o  udzielenie informacji o  osobie powinno zawierać:
1) nazwisko, w  tym także przybrane, imiona, nazwisko rodowe, datę i  miejsce urodzenia, imiona rodziców, nazwi sko
rodowe matki, miejsce zamieszkania, obywate

## Chunk 36
lstwo oraz numer PESEL, a  w przypadku jego nieposiadania przez
osobę, której zapytanie dotyczy, numer paszportu albo innego dokumentu stwierdzającego tożsamość;

Dziennik Ustaw – 12 – Poz. 276

2) określenie rodzaju i  zakresu danych o  osobie, które mają być przedmiotem informacji;
3) wskazanie postępowania, w  związku z  którym zachodzi potrzeba uzyskania danych o  osobie;
4) nazwę podmiotu kierującego zapytanie;
5) datę wystawienia;
6) podpis sędziego, prokuratora albo uprawnionej osoby lub orga nu podmiotu kierującego zapytanie.
2a. Zapytanie o  udzielenie informacji o  podmiocie zbiorowym powinno zawierać:
1) oznaczenie podmiotu zbiorowego oraz jego siedziby;
2) określenie rodzaju i  zakresu danych o  podmiocie zbiorowym, które mają być przedmiotem informacji;
3) wskazanie postępowania, w  związku z  którym zachodzi potrzeba uzyskania danych o  podmiocie zbiorowym;
4) nazwę podmiotu kierującego zapytanie;
5) datę wystawienia;
6) podpis sędziego, prokuratora albo uprawnionej osoby lub organu podmiotu kierującego zapytanie.
2b. Przepisu ust.  2 nie stosuje się do zapytań przekazywanych przez właściwe organy państw obcych.

## Chunk 37
Zapytanie takie
powinno zawierać dane pozwalające na identyfikację osoby, której ono dotyczy.
2c. Zapytanie o udzielenie informacji o osobie oraz zapytanie o udzielenie informacji o podmiocie zbiorowym  składane
za pośrednictwem systemu teleinformatycznego opatruje się kwalifikowanym podpisem elektronicznym , podpisem zaufa-
nym albo podpisem osobistym .
3. Wniosek osoby, o  której mowa w  art. 7 ust. 1, o udzielenie informacji z  Rejestru zawiera: nazwisko, w  tym także
przybrane, imiona, nazwisko rodowe, datę i  miejsce urodzenia, imiona rodziców, nazwisko rodowe matki, miejsce zamieszkania ,
obywatelstwo oraz numer PESEL i  podpis wnioskodawc y. W przypadku nieposiadania numeru PESEL wniosek powinien zawie-
rać numer paszportu albo innego dokumentu stwierdzającego tożsamość. Wniosek podmiotu zbiorowego, o  którym mowa
w art. 7 ust. 2, zawiera oznaczenie tego podmiotu i  jego adres oraz podpis osoby  uprawnionej do reprezentowania  wniosko-
dawcy. Jeżeli we wniosku nie określono rodzaju i  zakresu danych, które mają być przedmiotem informacji, informacja  ta zawiera
odpis wszystkich zapisów dotyczących wnioskodawcy zamieszczonych na kartach reje stracyjnych  i zawiadomieniach.

## Chunk 38
3a. Wniosek osoby, o której mowa w art. 7 ust. 1, o udzielenie informacji z Rejestru oraz wniosek podmiotu  zbioro-
wego, o którym mowa w art. 7 ust. 2, składany za pośrednictwem systemu teleinformatycznego opatruje  się kwalifikowanym
podpisem elektronicznym , podpisem zaufanym albo podpisem osobistym .
4. Jeżeli zapytanie lub wniosek nie spełniają wymogów, o  których mowa w  ust. 2, 2a, 2c, 3 lub 3a, wzywa się pytającego  lub
wnioskodawcę do usunięcia braków w  terminie 14  dni, z pouczeniem, że nieusunięcie braków spowoduje pozostawienie
zapytania  lub wniosku bez rozpoznania, chyba że braki dotyczą wyłącznie okoliczności, o  których mowa w  ust. 2 pkt 1,
a tożsamość osoby, której zapytanie dotyczy, nie budzi wątpliwości.
5. Jeżeli zapytanie, o  którym mowa w  ust. 2b, nie zawiera danych pozwalających na identyfikację osoby, której dotyczy,
zapytanie takie zwraca się ze wskazaniem przyczyny zwrotu.
Art. 19a. 1. W przypadku złożenia zapytania lub wniosku za pośrednictwem systemu teleinformatycznego info rmacja
o osobie i informacja o  podmiocie zbiorowym oraz inne pisma w  postępowaniu toczącym się na podstawie tego zapytania
lub wniosku są składane i  doręczane za pośrednictwem

## Chunk 39
systemu teleinformatycznego. Przepisy art.  19 ust. 2c, 3a i 4 stosuje się
odpowiednio.
2. W przypadku doręczenia za pośrednictwem systemu teleinformatycznego pismo uznaje się za doręczone z  datą
wskazaną w  elektronicznym potwierdzeniu odbioru korespondencji, a  przy braku takiego potwierdzenia doręczenie uznaje się
za skuteczne z  upływem 14 dni od daty umieszczenia pisma w  systemie teleinformatycznym.
Art. 20. 1. Informacja o  osobie, sporządzona na podstawie danych osobowych zgromadzonych w  Rejestrze, udzielana  na
zapytanie lub wniosek, zawiera:
1) dane identyfikujące osobę – nazwisko, w tym także przybrane, imiona, nazwisko rodowe, datę i  miejsce urodzenia,
imiona rodziców, obywatelstwo, nazwisko rodowe matki, miejsce zamieszkania, zawód wyuczony, a  także numer
PESEL;
2) dane osobowe w  zakresie objętym zapytaniem lub wnioskiem albo stwi erdzenie, że osoba nie figuruje w  Rejestrze;
3) datę wydania;

Dziennik Ustaw – 13 – Poz. 276

4) nazwisko i  imię oraz podpis osoby upoważnionej do jej wydania;
5) pieczęć urzędową.
1a.

## Chunk 40
Jeżeli przepis szczególny, na podstawie którego udzielana jest informacja z  Rejestru, zawiera wymóg nie karalności
w określonym zakresie, informacja z  Rejestru o  skazaniach, o  których mowa w  art. 1 ust. 2 pkt 4, jest udzielana w  zakresie
wskazanym w  tym przepisie szczególnym wyłącznie na podstawie danych przekazanych do Rejestru przez właś ciwe organy
państw obcych. W  takim przypadku biuro informacyjne nie dokonuje oceny, czy czyn, za który nastąpiło skazanie, stanowi
według prawa polskiego czyn karalny, przestępstwo czy wykroczenie oraz czy został popełniony umyślnie czy nieumyślnie,
chyba że okoliczności te  można ustalić na podstawie przekazanych informacji dotyczących rodzaju popełnionego czynu,
jego kwalifikacji prawnej lub rodzaju orzeczonej kary.
1b. Przepis ust. 1a stosuje się odpowiednio, jeżeli podmiot składający wniosek lub zapytanie sam określił zak res
żądanej informacji z  Rejestru, bez istnienia w  tym względzie szczególnej podstawy prawnej.
1c. W przypadku zastrzeżenia przez organ centralny państwa członkowskiego Unii Europejskiej w  zawiadomieniu,
o którym mowa w  art. 11 ust.

## Chunk 41
1 pkt 4, że przekazana informacja może być wykorzystywana wyłącznie dla celów prowadzo-
nego postępowania karnego, informacja o  osobie sporządzona dla celów innych niż postępowanie karne nie zawiera danych
o skazaniach, o  których mowa w  art. 1 ust. 2 pkt 4. W takim przypadku w  informacji o  osobie, udzielanej właściwym orga-
nom państw obcych, wskazuje się fakt zgłoszenia takiego zastrzeżenia, państwo, którego organ centralny zgłosił zastrzeże-
nie, oraz sąd, który wydał wyrok skazujący, i  datę jego wydania, jak również sygnaturę akt sp rawy, jeżeli jest znana.
1d. Informacja o  osobie sporządzona na wniosek osoby, o  której mowa w  art. 7 ust. 1, będącej obywatelem państwa
członkowskiego Unii Europejskiej innego niż Rzeczpospolita Polska zawiera dane  zgromadzone w  Rejestrze oraz w rejestrze
karnym państwa obywatelstwa wnioskodawcy, uzyskane na podstawie  art. 4 ust. 1 pkt 5a.
1e. Informacji o  osobie, wydawanej organom centralnym państw członkowskich Unii Europejskiej, przekazywanej za
pośrednictwem systemu ECRIS, nie opatruje się podpisem osoby upoważnionej do jej wydania ani pieczęcią urzędową.
1f.

## Chunk 42
W informacji przekazywanej właściwym organom państw obcych innym niż organy centralne państw członkow-
skich Unii Europejskiej zamieszcza się wzmiankę o  tym, że przekazane dane mogą być wykorzysta ne jedynie do celów,
w których się o  nie zwrócono.
2. Informacja o  podmiocie zbiorowym, sporządzona na podstawie danych zgromadzonych w  Rejestrze, udzielana na
zapytanie lub wniosek, zawiera:
1) oznaczenie podmiotu zbiorowego wraz z  jego siedzibą;
2) dane o podmiocie zbiorowym w  zakresie objętym zapytaniem lub wnioskiem albo stwierdzenie, że podmiot zbiorowy
nie figuruje w  Rejestrze;
3) datę wydania;
4) nazwisko i  imię oraz podpis osoby upoważnionej do jej wydania;
5) pieczęć urzędową.
3. (uchylony)
4. Do informacji o  osobie i informacji o  podmiocie zbiorowym, sporząd zonych na podstawie danych zgro madzonych
w Rejestrze, udzielanych na żądanie, przepisy ust.  1 i 2 stosuje się odpowiednio.
5. Informację o  osobie i informację o  podmiocie zbiorowym doręczane za pośrednictwem systemu teleinfor matycznego
na zapytanie lub wniosek opatruje się kwalifikowanym podpisem elektronicznym, podpisem osobistym, podpisem zaufanym
osoby upoważnionej do ich wydania albo kwalifikowaną pieczęc

## Chunk 43
ią elektroniczną.
6. Informację o osobie i informację o  podmiocie zbiorowym doręczan e za pośrednictwem systemu tele informatycznego
na żądanie opatruje się kwalifikowaną pieczęcią elektroniczną.
Art. 20a. 1. Sądom rejestrowym udziela się informacji o  osobie, w zakresie określonym w  art. 21a ustawy z  dnia 20 sierp-
nia 1997 r. o Krajowym Rejestrze Sądowym (Dz.  U. z 2023 r. poz. 685, 825 i 1705 ), za pośrednictwem systemu teleinfor-
matycznego:
1) po otrzymaniu żądania z  tego systemu;
2) po wprowadzeniu do Rejestru danych z  tego zakresu – z urzędu.

Dziennik Ustaw – 14 – Poz. 276

1a.3) Sądom rejestrowym, w celu udzielenia odpowiedzi na zapytanie, o którym mowa w art. 4d ust. 1 ustawy z dnia
20 sierpnia 1997 r. o Krajowym Rejestrze Sądowym, udziela się informacji o osobie, w zakresie skazań za przestępstwa,
o których mowa w art. 18 § 2 ustawy z dnia 15 września 2000 r. – Kodeks spółek handlowych  (Dz. U. z 2024 r. poz. 18
i 96), oraz orzeczonych środków karnych, o których mowa w art. 39 pkt 2 i 2aa ustawy z dnia 6 czerwca 1997 r. – Kodeks
karny, za pośrednictwem systemu teleinforma tycznego, po otrzymaniu żądania z tego systemu.
2.4) Żądanie, o którym mowa w ust.

## Chunk 44
1 pkt 1 oraz ust. 1a, zawiera imię (imiona) i nazwisko osoby oraz numer PESEL,
a w przypadku jego nieposiadania – datę urodzenia.
3. Informacja na żądanie o  osobie o wskazanych danych zawiera datę jej wydania oraz stwierdzenie, że osoba:
1) nie figuruje w  Rejestrze w  podanym zakresie albo
2) figuruje w  Rejestrze w  podanym zakresie, albo
3) więcej osób o  takich danych osobowych figuruje w  Rejestrze w  podanym zakresie.
4. W przypadku gdy osoba figuruje w  Rejestrze, informacja zawiera:
1) dane i informacje, o  których mowa w  art. 12 ust. 1 pkt 2, 3 i 5;
2) informacje o  orzeczonych karach, środkach karnych, kompensacyjnych lub przepadku i  podstawie prawnej ich orzeczenia ;
3) informacje o  okresie próby, zarządzeniu wykonania warunkowo zawieszonej kary pozbawienia wolności, skróceniu
orzeczonej kary na podstawie  art. 75 § 3a Kodeksu karnego oraz wykonaniu kar.
5. Informacja udzielona z  urzędu zawiera:
1) datę jej wydania;
2) imię (imiona) i  nazwisko osoby;
3) numer PESEL, o  ile go posiada;
4) dane, o których mowa w  art. 12 ust.

## Chunk 45
1 pkt 2, 3 i 5;
5) informacje o  orzeczonych karach, środkach karnych, kompensacyjnych lub przepadku i  podstawie prawnej ich orzeczenia;
6) informacje o  okresie próby, zarządzeniu wykonania warunkowo zawieszonej kary pozbawienia wolności, skróceniu
orzeczonej kary na podstawie  art. 75 § 3a Kodeksu karnego oraz wykonaniu kar.
6. Przepisów ust. 4 pkt 2 i 3 oraz ust. 5 pkt 5 i 6 nie stosuje się do informacji o osobach skazanych za przestępstwa,
o których mowa w art. 18 § 2 ustawy z dnia 15 września 2000 r. – Kodeks spółek handlowych, wobec których wyrok
uprawomocnił się po dniu 30 września 2018 r.
Art. 21. Minister Sprawiedliwości określi, w  drodze rozporządzeni a:
1) sposób i tryb udzielania informacji o  osobach oraz informacji o  podmiotach zbiorowych na podstawie danych zgroma-
dzonych w  Rejestrze,
2) wzór formularzy: zapytania  o udzielenie informacji o  osobie, zapytania o  udzielenie informacji o  podmiocie zbioro-
wym, informacji o  osobie, informacji o  podmiocie zbiorowym
– uwzględniając konieczność zapewnienia sprawnego udzielania informacji, zabezpieczenia przed uzyskaniem danych z  Rejestru
przez osoby nieuprawnione oraz zakres danych i  informacji określonych w  ar

## Chunk 46
t. 19 ust. 2 i 2a oraz art.  20 ust. 1 i 2.
Art. 21a. Minister Sprawiedliwości określi, w  drodze rozporządzenia:
1) sposób zakładania konta użytkownika i  konta instytucjonalnego oraz sposób i  tryb udzielania informacji o  osobach
i informacji o  podmiotach zbi orowych, udzielanych na zapytanie lub wniosek za pośrednictwem systemu teleinforma-
tycznego,
2) sposób i tryb udzielania informacji o  osobach i  informacji o  podmiotach zbiorowych, udzielanych na żądanie za po-
średnictwem  systemu teleinformatycznego, w  tym dane, jakie należy wskazać w  żądaniu udzielenia informacji o  osobie
lub podmiocie zbiorowym, a  także zakres informacji o  osobie lub podmiocie zbiorowym udzielonej w  ten sposób
– mając na uwadze konieczność zapewnienia sprawnego udzielania informacji oraz zabezpieczenia przed uzyskaniem
danych z Rejestru przez osoby nieuprawnione.

3) Dodany przez art. 6 pkt 1 ustawy z dnia  16 sierpnia 2023 r. o zmianie ustawy – Kodeks spółek handlowych oraz niektórych innych
ustaw (Dz. U. poz. 1705) , która weszła w życie z dniem 15 września 2023 r.
4) W brzmieniu ustalonym p rzez art. 6 pkt 2 ustawy, o której mowa w odnośniku 3.

Dziennik Ustaw – 15 – Poz. 276

Art. 21b. 1.

## Chunk 47
Jeżeli informacja o  osobie lub informacja o  podmiocie zbiorowym została udzielona niezgodnie z  zakresem
wskazanym w  zapytaniu lub wniosku, na podstawie którego udziel ono informacji, można wystąpić z  żądaniem udzielenia
ponownej informacji z  Rejestru.
2. Z żądaniem, o  którym mowa w  ust. 1, może wystąpić osoba albo inny podmiot, któremu udzielono informacji, oraz
osoba albo podmiot zbiorowy, którego informacja dotyczy.
3. Żądanie, o  którym mowa w  ust. 1, powinno zawierać wskazanie danych, które składający żądanie uważa za nie-
zgodne z zakresem zapytania lub wniosku, o  którym mowa w  ust. 1.
4. Ponowna informacja z  Rejestru zawiera dane objęte zakresem zapytania lub wniosku,  o którym mowa w  ust. 1, prze-
twarzane w  Rejestrze w  dniu jej udzielenia.
5. Jeżeli w ponownej informacji z  Rejestru zostaje powtórzona przynajmniej jedna z  danych, o  których mowa w  ust. 3,
ponowna informacja zostaje wydana w  drodze postanowienia.
6. Jeżeli dane, o których mowa w  ust. 3, dotyczą skazań, o  których mowa w  art. 1 ust. 2 pkt 4, do udzielania ponownej
informacji z  Rejestru nie stosuje się przepisów  art. 20 ust. 1a i 1b.
7.

## Chunk 48
W zakresie nieuregulowanym do udzielania ponownej informacji z  Rejestru st osuje się odpowiednio przepisy
o udzielaniu z  Rejestru informacji o  osobach oraz informacji o  podmiotach zbiorowych.
Art. 22. 1. Biuro informacyjne niezwłocznie informuje właściwy sąd o  ponownym prawomocnym skazaniu za prze-
stępstwo lub przestępstwo skarbow e osoby, wobec której warunkowo umorzono postępowanie karne, warunkowo zawie-
szono wykonanie kary, zastosowano warunkowe zwolnienie z  zakładu karnego albo umorzono postępowanie na podstawie
przepisów o  amnestii, z  których wynika, że takie skazanie może mieć  wpływ na jej stosowanie.
2. W sprawach o  wykroczenia biuro informacyjne informuje właściwy sąd o  ponownym prawomocnym skazaniu za
wykroczenie osoby, wobec której warunkowo zawieszono wykonanie kary aresztu.
3. (uchylony)
4. Informacje, o  których mowa w  ust. 1 i 2, są przekazywane za pośrednictwem systemu teleinformatycznego.
Art. 23. Informacja o  osobie, o której mowa w  art. 20 ust. 1–1e, oraz informacja o  podmiocie zbiorowym, o  której
mowa w art. 20 ust.

## Chunk 49
2, bez względu na sposób jej udzielenia, stanowi za świadczenie w  rozumieniu przepisów działu VII
Kodeksu postępowania administracyjnego.
Art. 24. 1. Za wydanie z  Rejestru informacji o  osobie pobiera się opłatę stanowiącą dochód budżetu państwa. Od uisz-
czenia opłaty zwolnione są podmioty wymienione w  art. 6 ust. 1 pkt 1–9 i 11 oraz organy centralne państw członkowskich
Unii Europejskiej występujące o  wydanie informacji dla celów prowadzonego postępowania karnego lub administracyjnego .
1a. Od uiszczenia opłaty za wydanie z Rejestru informacji o osobie zwolnie ni są także będący wolontariuszami kandydaci
na kierowników wypoczynku lub wychowawców wypoczynku, obowiązani do przedstawienia informacji  organizatorowi
wypoczynku na podstawie art. 92p ust. 8 pkt 1 ustawy z dnia 7 września 1991 r. o systemie oświaty (Dz.  U. z 2022 r. poz. 2230
oraz z 2023 r. poz. 1234 i 2005 ).
2. Za wydanie z  Rejestru informacji o  podmiocie zbiorowym pobiera się opłatę stanowiącą dochód budżetu państwa.
Od uiszczenia opłaty zwolnione są podmioty wymienione w  art. 6 ust. 1 pkt 1, 4–9 i 11.
2a. Nie pobiera się opłaty od wydania ponownej informacji z  Rejestru, o  której mowa w  art. 21b.
3.

## Chunk 50
Minister Sprawiedliwości określi, w  drodze rozporządzenia, wysokość oraz sposób uiszczania i  zwrotu opłat, o  których
mowa w ust. 1 i 2, mając na uwadze fakt yczne koszty wydania informacji, w  zależności od sposobu jej udzielenia.
Rozdział 3
Przepis karny
Art. 25. Kto bez uprawnienia uzyskuje z  Rejestru informację o  osobie albo informację o  podmiocie zbiorowym, pod-
lega grzywnie, karze ograniczenia wolności albo  pozbawienia wolności do lat 2.
Rozdział 4
Zmiany w  przepisach obowiązujących i  przepisy końcowe
Art. 26. (pominięty)
Art. 27. (uchylony)

Dziennik Ustaw – 16 – Poz. 276

Art. 28–30. (pominięte)
Art. 31. Ilekroć w  przepisach prawa jest mowa o  „Centralnym Rejestrze Skazanych ” lub „Centralnym Rejestrze Nie -
letnich”, należy przez to rozumieć „Krajowy Rejestr Karny ”.
Art. 32. Ustawa wchodzi w  życie po upływie 12  miesięcy od dnia ogłoszenia5).

5) Ustawa została ogłoszona w  dniu 21 czerwca 2000  r.

