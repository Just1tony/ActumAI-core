---
id: act.kpc.remedies
title: "Kodeks postępowania cywilnego – Część czwarta: Środki zaskarżenia (tekst jednolity)"
category: act
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1964 nr 43 poz. 296"
status: "obowiązujący"
last_consolidated: "2024-01-01"
aliases: ["KPC – środki zaskarżenia","Kodeks postępowania cywilnego – apelacje i zażalenia"]
tags: ["KPC","środki zaskarżenia","apelacja","zażalenie","skarga kasacyjna","wznowienie postępowania","PL"]
source_pdf: "D19640093Lj.pdf"
---

# Kodeks postępowania cywilnego – Środki zaskarżenia

©Kancelaria Sejmu 
 
 
 
s. 1/242 
 
   
 
2025-09-09 
 
 
 
Dz. U. 1964 Nr 16 poz. 93  
 
 
U S TAWA  
z dnia 23 kwietnia 1964 r. 
Kodeks cywilny1) 
KSIĘGA PIERWSZA 
CZĘŚĆ OGÓLNA 
TYTUŁ I 
Przepisy wstępne
***
## Art. 1. {#art-1}

Kodeks niniejszy reguluje stosunki cywilnoprawne między osobami 
fizycznymi i osobami prawnymi.

***
## Art. 2. {#art-2}

(uchylony)

***
## Art. 3. {#art-3}

Ustawa nie ma mocy wstecznej, chyba że to wynika z jej brzmienia lub 
celu.

***
## Art. 4. {#art-4}

(uchylony)

***
## Art. 5. {#art-5}

Nie można czynić ze swego prawa użytku, który by był sprzeczny ze 
społeczno-gospodarczym przeznaczeniem tego prawa lub z zasadami współżycia 
- 1) Niniejsza ustawa w zakresie swojej regulacji wdraża: 
- 1) dyrektywę 2000/31/WE Parlamentu Europejskiego i Rady z dnia 8 czerwca 2000 r. w sprawie 
niektórych aspektów prawnych usług społeczeństwa informacyjnego, w szczególności handlu 
elektronicznego w ramach rynku wewnętrznego (dyrektywa o handlu elektronicznym) (Dz. Urz. 
WE L 178 z 17.07.2000, str. 1 – Dz. Urz. UE Polskie wydanie specjalne, rozdz. 13, t. 25, str. 399 
oraz Dz. Urz. UE L 277 z 27.10.2022, str. 1); 
- 2) dyrektywę Parlamentu Europejskiego i Rady (UE) 2020/1828 z dnia 25 listopada 2020 r. 
w sprawie powództw przedstawicielskich wytaczanych w celu ochrony zbiorowych interesów 
konsumentów i uchylającą dyrektywę 2009/22/WE (Dz. Urz. UE L 409 z 04.12.2020, str. 1, 
Dz. Urz. UE L 265 z 12.10.2022, str. 1, Dz. Urz. UE L 277 z 27.10.2022, str. 1, Dz. Urz. UE L 135 
z 23.05.2023, str. 1 oraz Dz. Urz. UE L 2023/2854 z 22.12.2023). 
Opracowano na 
podstawie: 
t.j. 
Dz. U. z 2025 r. 
poz. 1071, 1172. 

©Kancelaria Sejmu 
 
 
 
s. 2/242 
 
   
 
2025-09-09 
 
społecznego. Takie działanie lub zaniechanie uprawnionego nie jest uważane za 
wykonywanie prawa i nie korzysta z ochrony.

***
## Art. 6. {#art-6}

Ciężar udowodnienia faktu spoczywa na osobie, która z faktu tego 
wywodzi skutki prawne.

***
## Art. 7. {#art-7}

Jeżeli ustawa uzależnia skutki prawne od dobrej lub złej wiary, 
domniemywa się istnienie dobrej wiary. 
TYTUŁ II 
Osoby 
## DZIAŁ I. Osoby fizyczne 
## Rozdział I. Zdolność prawna i zdolność do czynności prawnych

***
## Art. 8. {#art-8}

§ 1. Każdy człowiek od chwili urodzenia ma zdolność prawną. 
§ 2. (uchylony)

***
## Art. 9. {#art-9}

W razie urodzenia się dziecka domniemywa się, że przyszło ono na świat 
żywe.

***
## Art. 10. {#art-10}

§ 1. Pełnoletnim jest, kto ukończył lat osiemnaście. 
§ 2. Przez zawarcie małżeństwa małoletni uzyskuje pełnoletność. Nie traci jej 
w razie unieważnienia małżeństwa.

***
## Art. 11. {#art-11}

Pełną zdolność do czynności prawnych nabywa się z chwilą uzyskania 
pełnoletności.

***
## Art. 12. {#art-12}

Nie mają zdolności do czynności prawnych osoby, które nie ukończyły 
lat trzynastu, oraz osoby ubezwłasnowolnione całkowicie.

***
## Art. 13. {#art-13}

§ 1. Osoba, 
która 
ukończyła 
lat 
trzynaście, 
może 
być 
ubezwłasnowolniona całkowicie, jeżeli wskutek choroby psychicznej, niedorozwoju 
umysłowego albo innego rodzaju zaburzeń psychicznych, w szczególności pijaństwa 
lub narkomanii, nie jest w stanie kierować swym postępowaniem. 
§ 2. Dla ubezwłasnowolnionego całkowicie ustanawia się opiekę, chyba że 
pozostaje on jeszcze pod władzą rodzicielską. 

©Kancelaria Sejmu 
 
 
 
s. 3/242 
 
   
 
2025-09-09

***
## Art. 14. {#art-14}

§ 1. Czynność prawna dokonana przez osobę, która nie ma zdolności do 
czynności prawnych, jest nieważna. 
§ 2. Jednakże gdy osoba niezdolna do czynności prawnych zawarła umowę 
należącą do umów powszechnie zawieranych w drobnych bieżących sprawach życia 
codziennego, umowa taka staje się ważna z chwilą jej wykonania, chyba że pociąga 
za sobą rażące pokrzywdzenie osoby niezdolnej do czynności prawnych.

***
## Art. 15. {#art-15}

Ograniczoną zdolność do czynności prawnych mają małoletni, którzy 
ukończyli lat trzynaście, oraz osoby ubezwłasnowolnione częściowo.

***
## Art. 16. {#art-16}

§ 1. Osoba pełnoletnia może być ubezwłasnowolniona częściowo 
z powodu choroby psychicznej, niedorozwoju umysłowego albo innego rodzaju 
zaburzeń psychicznych, w szczególności pijaństwa lub narkomanii, jeżeli stan tej 
osoby nie uzasadnia ubezwłasnowolnienia całkowitego, lecz potrzebna jest pomoc do 
prowadzenia jej spraw. 
§ 2. Dla osoby ubezwłasnowolnionej częściowo ustanawia się kuratelę.

***
## Art. 17. {#art-17}

Z zastrzeżeniem wyjątków w ustawie przewidzianych, do ważności 
czynności prawnej, przez którą osoba ograniczona w zdolności do czynności 
prawnych zaciąga zobowiązanie lub rozporządza swoim prawem, potrzebna jest zgoda 
jej przedstawiciela ustawowego.

***
## Art. 18. {#art-18}

§ 1. Ważność umowy, która została zawarta przez osobę ograniczoną 
w zdolności do czynności prawnych bez wymaganej zgody przedstawiciela 
ustawowego, zależy od potwierdzenia umowy przez tego przedstawiciela. 
§ 2. Osoba ograniczona w zdolności do czynności prawnych może sama 
potwierdzić umowę po uzyskaniu pełnej zdolności do czynności prawnych. 
§ 3. Strona, która zawarła umowę z osobą ograniczoną w zdolności do czynności 
prawnych, nie może powoływać się na brak zgody jej przedstawiciela ustawowego. 
Może jednak wyznaczyć temu przedstawicielowi odpowiedni termin do potwierdzenia 
umowy; staje się wolna po bezskutecznym upływie wyznaczonego terminu.

***
## Art. 19. {#art-19}

Jeżeli osoba ograniczona w zdolności do czynności prawnych dokonała 
sama jednostronnej czynności prawnej, do której ustawa wymaga zgody 
przedstawiciela ustawowego, czynność jest nieważna. 

©Kancelaria Sejmu 
 
 
 
s. 4/242 
 
   
 
2025-09-09

***
## Art. 20. {#art-20}

Osoba ograniczona w zdolności do czynności prawnych może bez 
zgody przedstawiciela ustawowego zawierać umowy należące do umów powszechnie 
zawieranych w drobnych bieżących sprawach życia codziennego.

***
## Art. 21. {#art-21}

Osoba ograniczona w zdolności do czynności prawnych może bez 
zgody przedstawiciela ustawowego rozporządzać swoim zarobkiem, chyba że sąd 
opiekuńczy z ważnych powodów inaczej postanowi.

***
## Art. 22. {#art-22}

Jeżeli przedstawiciel ustawowy osoby ograniczonej w zdolności do 
czynności prawnych oddał jej określone przedmioty majątkowe do swobodnego 
użytku, osoba ta uzyskuje pełną zdolność w zakresie czynności prawnych, które tych 
przedmiotów dotyczą. Wyjątek stanowią czynności prawne, do których dokonania nie 
wystarcza według ustawy zgoda przedstawiciela ustawowego.

***
## Art. 221. {#art-221}

Za konsumenta uważa się osobę fizyczną dokonującą z przedsiębiorcą 
czynności prawnej niezwiązanej bezpośrednio z jej działalnością gospodarczą lub 
zawodową.

***
## Art. 23. {#art-23}

Dobra osobiste człowieka, jak w szczególności zdrowie, wolność, cześć, 
swoboda sumienia, nazwisko lub pseudonim, wizerunek, tajemnica korespondencji, 
nietykalność 
mieszkania, 
twórczość 
naukowa, 
artystyczna, 
wynalazcza 
i racjonalizatorska, pozostają pod ochroną prawa cywilnego niezależnie od ochrony 
przewidzianej w innych przepisach.

***
## Art. 24. {#art-24}

§ 1. Ten, czyje dobro osobiste zostaje zagrożone cudzym działaniem, 
może żądać zaniechania tego działania, chyba że nie jest ono bezprawne. W razie 
dokonanego naruszenia może on także żądać, ażeby osoba, która dopuściła się 
naruszenia, dopełniła czynności potrzebnych do usunięcia jego skutków, 
w szczególności ażeby złożyła oświadczenie odpowiedniej treści i w odpowiedniej 
formie. Na zasadach przewidzianych w kodeksie może on również żądać 
zadośćuczynienia pieniężnego albo zapłaty odpowiedniej sumy pieniężnej na 
wskazany cel społeczny. 
§ 2. Jeżeli wskutek naruszenia dobra osobistego została wyrządzona szkoda 
majątkowa, poszkodowany może żądać jej naprawienia na zasadach ogólnych. 
§ 3. Przepisy powyższe nie uchybiają uprawnieniom przewidzianym w innych 
przepisach, w szczególności w prawie autorskim oraz w prawie wynalazczym. 

©Kancelaria Sejmu 
 
 
 
s. 5/242 
 
   
 
2025-09-09 
## Rozdział II. Miejsce zamieszkania

***
## Art. 25. {#art-25}

Miejscem zamieszkania osoby fizycznej jest miejscowość, w której 
osoba ta przebywa z zamiarem stałego pobytu.

***
## Art. 26. {#art-26}

§ 1. Miejscem zamieszkania dziecka pozostającego pod władzą 
rodzicielską jest miejsce zamieszkania rodziców albo tego z rodziców, któremu 
wyłącznie przysługuje władza rodzicielska lub któremu zostało powierzone 
wykonywanie władzy rodzicielskiej. 
§ 2. Jeżeli władza rodzicielska przysługuje na równi obojgu rodzicom mającym 
osobne miejsce zamieszkania, miejsce zamieszkania dziecka jest u tego z rodziców, u 
którego dziecko stale przebywa. Jeżeli dziecko nie przebywa stale u żadnego 
z rodziców, jego miejsce zamieszkania określa sąd opiekuńczy.

***
## Art. 27. {#art-27}

Miejscem zamieszkania osoby pozostającej pod opieką jest miejsce 
zamieszkania opiekuna.

***
## Art. 28. {#art-28}

Można mieć tylko jedno miejsce zamieszkania. 
## Rozdział III. Uznanie za zmarłego

***
## Art. 29. {#art-29}

§ 1. Zaginiony może być uznany za zmarłego, jeżeli upłynęło lat 
dziesięć od końca roku kalendarzowego, w którym według istniejących wiadomości 
jeszcze żył; jednakże gdyby w chwili uznania za zmarłego zaginiony ukończył lat 
siedemdziesiąt, wystarcza upływ lat pięciu. 
§ 2. Uznanie za zmarłego nie może nastąpić przed końcem roku kalendarzowego, 
w którym zaginiony ukończyłby lat dwadzieścia trzy.

***
## Art. 30. {#art-30}

§ 1. Kto zaginął w czasie podróży powietrznej lub morskiej w związku 
z katastrofą statku lub okrętu albo w związku z innym szczególnym zdarzeniem, ten 
może być uznany za zmarłego po upływie sześciu miesięcy od dnia, w którym 
nastąpiła katastrofa albo inne szczególne zdarzenie. 
§ 2. Jeżeli nie można stwierdzić katastrofy statku lub okrętu, bieg terminu 
sześciomiesięcznego rozpoczyna się z upływem roku od dnia, w którym statek lub 

©Kancelaria Sejmu 
 
 
 
s. 6/242 
 
   
 
2025-09-09 
 
okręt miał przybyć do portu przeznaczenia, a jeżeli nie miał portu przeznaczenia – 
z upływem lat dwóch od dnia, w którym była ostatnia o nim wiadomość. 
§ 3. Kto zaginął w związku z bezpośrednim niebezpieczeństwem dla życia 
nieprzewidzianym w paragrafach poprzedzających, ten może być uznany za zmarłego 
po upływie roku od dnia, w którym niebezpieczeństwo ustało albo według 
okoliczności powinno było ustać.

***
## Art. 31. {#art-31}

§ 1. Domniemywa się, że zaginiony zmarł w chwili oznaczonej 
w orzeczeniu o uznaniu za zmarłego. 
§ 2. Jako chwilę domniemanej śmierci zaginionego oznacza się chwilę, która 
według okoliczności jest najbardziej prawdopodobna, a w braku wszelkich danych – 
pierwszy dzień terminu, z którego upływem uznanie za zmarłego stało się możliwe. 
§ 3. Jeżeli w orzeczeniu o uznaniu za zmarłego czas śmierci został oznaczony 
tylko datą dnia, za chwilę domniemanej śmierci zaginionego uważa się koniec tego 
dnia.

***
## Art. 32. {#art-32}

Jeżeli kilka osób utraciło życie podczas grożącego im wspólnie 
niebezpieczeństwa, domniemywa się, że zmarły jednocześnie. 
## DZIAŁ II. Osoby prawne

***
## Art. 33. {#art-33}

Osobami prawnymi są Skarb Państwa i jednostki organizacyjne, którym 
przepisy szczególne przyznają osobowość prawną.

***
## Art. 331. {#art-331}

§ 1. Do jednostek organizacyjnych niebędących osobami prawnymi, 
którym ustawa przyznaje zdolność prawną, stosuje się odpowiednio przepisy 
o osobach prawnych. 
§ 2. Jeżeli przepis odrębny nie stanowi inaczej, za zobowiązania jednostki, 
o której mowa w § 1, odpowiedzialność subsydiarną ponoszą jej członkowie; 
odpowiedzialność ta powstaje z chwilą, gdy jednostka organizacyjna stała się nie-
wypłacalna.

***
## Art. 34. {#art-34}

Skarb Państwa jest w stosunkach cywilnoprawnych podmiotem praw 
i obowiązków, które dotyczą mienia państwowego nienależącego do innych 
państwowych osób prawnych. 

©Kancelaria Sejmu 
 
 
 
s. 7/242 
 
   
 
2025-09-09

***
## Art. 35. {#art-35}

Powstanie, ustrój i ustanie osób prawnych określają właściwe przepisy; 
w wypadkach i w zakresie w przepisach tych przewidzianych organizację i sposób 
działania osoby prawnej reguluje także jej statut.

***
## Art. 36. {#art-36}

(uchylony)

***
## Art. 37. {#art-37}

§ 1. Jednostka organizacyjna uzyskuje osobowość prawną z chwilą jej 
wpisu do właściwego rejestru, chyba że przepisy szczególne stanowią inaczej. 
§ 2. Rodzaje rejestrów oraz ich organizację i sposób prowadzenia regulują 
odrębne przepisy.

***
## Art. 38. {#art-38}

Osoba prawna działa przez swoje organy w sposób przewidziany 
w ustawie i w opartym na niej statucie.

***
## Art. 39. {#art-39}

§ 1. Jeżeli zawierający umowę jako organ osoby prawnej nie ma 
umocowania albo przekroczy jego zakres, ważność umowy zależy od jej 
potwierdzenia przez osobę prawną, w której imieniu umowa została zawarta.  
§ 2. Druga strona może wyznaczyć osobie prawnej, w której imieniu umowa 
została zawarta, odpowiedni termin do potwierdzenia umowy; staje się wolna po 
bezskutecznym upływie wyznaczonego terminu.  
§ 3. W braku potwierdzenia ten, kto zawarł umowę jako organ osoby prawnej, 
obowiązany jest do zwrotu tego, co otrzymał od drugiej strony w wykonaniu umowy, 
oraz do naprawienia szkody, którą druga strona poniosła przez to, że zawarła umowę 
nie wiedząc o braku umocowania lub o przekroczeniu jego zakresu.  
§ 4. Jednostronna czynność prawna dokonana przez działającego jako organ 
osoby prawnej bez umocowania albo z przekroczeniem jego zakresu jest nieważna. 
Jednakże gdy ten, komu zostało złożone oświadczenie woli w imieniu osoby prawnej, 
zgodził się na działanie bez umocowania, stosuje się odpowiednio przepisy o zawarciu 
umowy bez umocowania.  
§ 5. Przepis § 3 stosuje się odpowiednio w przypadku, gdy czynność prawna 
została dokonana w imieniu osoby prawnej, która nie istnieje.

***
## Art. 40. {#art-40}

§ 1. Skarb Państwa nie ponosi odpowiedzialności za zobowiązania 
państwowych osób prawnych, chyba że przepis odrębny stanowi inaczej. Państwowe 
osoby prawne nie ponoszą odpowiedzialności za zobowiązania Skarbu Państwa. 
§ 2. W razie nieodpłatnego przejęcia, na podstawie obowiązujących ustaw, 
określonego składnika mienia od państwowej osoby prawnej na rzecz Skarbu Państwa, 

©Kancelaria Sejmu 
 
 
 
s. 8/242 
 
   
 
2025-09-09 
 
ten ostatni odpowiada solidarnie z osobą prawną za zobowiązania powstałe w okresie, 
gdy składnik stanowił własność danej osoby prawnej, do wysokości wartości tego 
składnika ustalonej według stanu z chwili przejęcia, a według cen z chwili zapłaty. 
§ 3. Przepisy § 1 i 2 stosuje się odpowiednio do odpowiedzialności jednostek 
samorządu terytorialnego i samorządowych osób prawnych.

***
## Art. 41. {#art-41}

Jeżeli ustawa lub oparty na niej statut nie stanowi inaczej, siedzibą 
osoby prawnej jest miejscowość, w której ma siedzibę jej organ zarządzający.

***
## Art. 42. {#art-42}

§ 1. Jeżeli osoba prawna nie może być reprezentowana lub prowadzić 
swoich spraw ze względu na brak organu albo brak w składzie organu uprawnionego 
do jej reprezentowania, sąd ustanawia dla niej kuratora. Kurator podlega nadzorowi 
sądu, który go ustanowił.  
§ 2. Do czasu powołania albo uzupełnienia składu organu, o którym mowa w § 
1, albo ustanowienia likwidatora kurator reprezentuje osobę prawną oraz prowadzi jej 
sprawy w granicach określonych w zaświadczeniu sądu.  
§ 3. Kurator niezwłocznie podejmuje czynności zmierzające do powołania albo 
uzupełnienia składu organu osoby prawnej uprawnionego do jej reprezentowania, a w 
razie potrzeby do jej likwidacji.  
§ 4. Pod rygorem nieważności kurator jest obowiązany uzyskać zezwolenie sądu 
rejestrowego na:  
- 1) nabycie i zbycie przedsiębiorstwa lub jego zorganizowanej części oraz na 
dokonanie czynności prawnej, na podstawie której następuje oddanie 
przedsiębiorstwa lub jego zorganizowanej części do czasowego korzystania;  
- 2) nabycie i zbycie oraz obciążanie nieruchomości, użytkowania wieczystego lub 
udziału w nieruchomości.

***
## Art. 421. {#art-421}

§ 1. Kuratora ustanawia się na okres nieprzekraczający roku. W 
szczególnie uzasadnionych przypadkach można przedłużać ustanowienie kuratora na 
czas oznaczony, jeżeli czynności kuratora, o których mowa w art. 42 § 3, nie mogły 
zostać zakończone przed upływem okresu, na który został ustanowiony.  
§ 2. Jeżeli czynności podjęte przez kuratora nie doprowadziły do powołania lub 
uzupełnienia składu organu osoby prawnej uprawnionego do jej reprezentowania albo 
jej likwidacji, występuje on niezwłocznie z wnioskiem do sądu rejestrowego o 
rozwiązanie osoby prawnej. Nie narusza to uprawnień kuratora do wystąpienia z 
żądaniem rozwiązania osoby prawnej na podstawie odrębnych przepisów. 

©Kancelaria Sejmu 
 
 
 
s. 9/242 
 
   
 
2025-09-09

***
## Art. 43. {#art-43}

Przepisy o ochronie dóbr osobistych osób fizycznych stosuje się 
odpowiednio do osób prawnych. 
## DZIAŁ III. Przedsiębiorcy i ich oznaczenia

***
## Art. 431. {#art-431}

Przedsiębiorcą jest osoba fizyczna, osoba prawna i jednostka 
organizacyjna, o której mowa w art. 331 § 1, prowadząca we własnym imieniu 
działalność gospodarczą lub zawodową.

***
## Art. 432. {#art-432}

§ 1. Przedsiębiorca działa pod firmą. 
§ 2. Firmę ujawnia się we właściwym rejestrze, chyba że przepisy odrębne 
stanowią inaczej.

***
## Art. 433. {#art-433}

§ 1. Firma przedsiębiorcy powinna się odróżniać dostatecznie od firm 
innych przedsiębiorców prowadzących działalność na tym samym rynku. 
§ 2. Firma nie może wprowadzać w błąd, w szczególności co do osoby 
przedsiębiorcy, przedmiotu działalności przedsiębiorcy, miejsca działalności, źródeł 
zaopatrzenia.

***
## Art. 434. {#art-434}

Firmą osoby fizycznej jest jej imię i nazwisko. Nie wyklucza to 
włączenia do firmy pseudonimu lub określeń wskazujących na przedmiot działalności 
przedsiębiorcy, miejsce jej prowadzenia oraz innych określeń dowolnie obranych.

***
## Art. 435. {#art-435}

§ 1. Firmą osoby prawnej jest jej nazwa. 
§ 2. Firma zawiera określenie formy prawnej osoby prawnej, które może być 
podane w skrócie, a ponadto może wskazywać na przedmiot działalności, siedzibę tej 
osoby oraz inne określenia dowolnie obrane. 
§ 3. Firma osoby prawnej może zawierać nazwisko lub pseudonim osoby 
fizycznej, jeżeli służy to ukazaniu związków tej osoby z powstaniem lub działalnością 
przedsiębiorcy. Umieszczenie w firmie nazwiska albo pseudonimu osoby fizycznej 
wymaga pisemnej zgody tej osoby, a w razie jej śmierci – zgody jej małżonka i dzieci. 
§ 4. Przedsiębiorca może posługiwać się skrótem firmy. Przepis art. 432 
§ 2 stosuje się odpowiednio.

***
## Art. 436. {#art-436}

Firma oddziału osoby prawnej zawiera pełną nazwę tej osoby oraz 
określenie „oddział” ze wskazaniem miejscowości, w której oddział ma siedzibę. 

©Kancelaria Sejmu 
 
 
 
s. 10/242 
 
   
 
2025-09-09

***
## Art. 437. {#art-437}

Zmiana firmy wymaga ujawnienia w rejestrze. W razie przekształcenia 
osoby prawnej można zachować jej dotychczasową firmę z wyjątkiem określenia 
wskazującego formę prawną osoby prawnej, jeżeli uległa ona zmianie. To samo 
dotyczy przekształcenia spółki osobowej.

***
## Art. 438. {#art-438}

§ 1. W przypadku utraty członkostwa przez wspólnika, którego 
nazwisko było umieszczone w firmie, spółka może zachować w swej firmie nazwisko 
byłego wspólnika tylko za wyrażoną na piśmie jego zgodą, a w razie jego śmierci – za 
zgodą jego małżonka i dzieci. 
§ 2. Przepis § 1 stosuje się odpowiednio w wypadku kontynuowania działalności 
gospodarczej osoby fizycznej przez inną osobę fizyczną będącą jej następcą prawnym. 
§ 3. Kto nabywa przedsiębiorstwo, może je nadal prowadzić pod dotychczasową 
nazwą. Powinien jednak umieścić dodatek wskazujący firmę lub nazwisko nabywcy, 
chyba że strony postanowiły inaczej.

***
## Art. 439. {#art-439}

§ 1. Firma nie może być zbyta. 
§ 2. Przedsiębiorca może upoważnić innego przedsiębiorcę do korzystania ze 
swej firmy, jeżeli nie wprowadza to w błąd.

***
## Art. 4310. {#art-4310}

Przedsiębiorca, którego prawo do firmy zostało zagrożone cudzym 
działaniem, może żądać zaniechania tego działania, chyba że nie jest ono bezprawne. 
W razie dokonanego naruszenia może on także żądać usunięcia jego skutków, złożenia 
oświadczenia lub oświadczeń w odpowiedniej treści i formie, naprawienia na 
zasadach ogólnych szkody majątkowej lub wydania korzyści uzyskanej przez osobę, 
która dopuściła się naruszenia. 
TYTUŁ III 
Mienie

***
## Art. 44. {#art-44}

Mieniem jest własność i inne prawa majątkowe.

***
## Art. 441. {#art-441}

§ 1. Własność i inne prawa majątkowe, stanowiące mienie państwowe, 
przysługują Skarbowi Państwa albo innym państwowym osobom prawnym. 
§ 2. Uprawnienia majątkowe Skarbu Państwa względem państwowych osób 
prawnych określają odrębne przepisy, w szczególności regulujące ich ustrój.

***
## Art. 45. {#art-45}

Rzeczami w rozumieniu niniejszego kodeksu są tylko przedmioty 
materialne. 

©Kancelaria Sejmu 
 
 
 
s. 11/242 
 
   
 
2025-09-09

***
## Art. 46. {#art-46}

§ 1. Nieruchomościami są części powierzchni ziemskiej stanowiące 
odrębny przedmiot własności (grunty), jak również budynki trwale z gruntem 
związane lub części takich budynków, jeżeli na mocy przepisów szczególnych 
stanowią odrębny od gruntu przedmiot własności. 
§ 2. Prowadzenie ksiąg wieczystych regulują odrębne przepisy.

***
## Art. 461. {#art-461}

Nieruchomościami rolnymi (gruntami rolnymi) są nieruchomości, 
które są lub mogą być wykorzystywane do prowadzenia działalności wytwórczej 
w rolnictwie w zakresie produkcji roślinnej i zwierzęcej, nie wyłączając produkcji 
ogrodniczej, sadowniczej i rybnej.

***
## Art. 47. {#art-47}

§ 1. Część składowa rzeczy nie może być odrębnym przedmiotem 
własności i innych praw rzeczowych. 
§ 2. Częścią składową rzeczy jest wszystko, co nie może być od niej odłączone 
bez uszkodzenia lub istotnej zmiany całości albo bez uszkodzenia lub istotnej zmiany 
przedmiotu odłączonego. 
§ 3. Przedmioty połączone z rzeczą tylko dla przemijającego użytku nie stanowią 
jej części składowych.

***
## Art. 48. {#art-48}

Z zastrzeżeniem wyjątków w ustawie przewidzianych, do części 
składowych gruntu należą w szczególności budynki i inne urządzenia trwale 
z gruntem związane, jak również drzewa i inne rośliny od chwili zasadzenia lub 
zasiania.

***
## Art. 49. {#art-49}

§ 1. Urządzenia służące do doprowadzania lub odprowadzania płynów, 
pary, gazu, energii elektrycznej oraz inne urządzenia podobne nie należą do części 
składowych nieruchomości, jeżeli wchodzą w skład przedsiębiorstwa. 
§ 2. Osoba, która poniosła koszty budowy urządzeń, o których mowa w § 1, i jest 
ich właścicielem, może żądać, aby przedsiębiorca, który przyłączył urządzenia do 
swojej sieci, nabył ich własność za odpowiednim wynagrodzeniem, chyba że 
w umowie strony postanowiły inaczej. Z żądaniem przeniesienia własności tych 
urządzeń może wystąpić także przedsiębiorca.

***
## Art. 50. {#art-50}

Za części składowe nieruchomości uważa się także prawa związane z jej 
własnością. 

©Kancelaria Sejmu 
 
 
 
s. 12/242 
 
   
 
2025-09-09

***
## Art. 51. {#art-51}

§ 1. Przynależnościami są rzeczy ruchome potrzebne do korzystania 
z innej rzeczy (rzeczy głównej) zgodnie z jej przeznaczeniem, jeżeli pozostają z nią 
w faktycznym związku odpowiadającym temu celowi. 
§ 2. Nie może być przynależnością rzecz nienależąca do właściciela rzeczy 
głównej. 
§ 3. Przynależność nie traci tego charakteru przez przemijające pozbawienie jej 
faktycznego związku z rzeczą główną.

***
## Art. 52. {#art-52}

Czynność prawna mająca za przedmiot rzecz główną odnosi skutek 
także względem przynależności, chyba że co innego wynika z treści czynności albo 
z przepisów szczególnych.

***
## Art. 53. {#art-53}

§ 1. Pożytkami naturalnymi rzeczy są jej płody i inne odłączone od niej 
części składowe, o ile według zasad prawidłowej gospodarki stanowią normalny 
dochód z rzeczy. 
§ 2. Pożytkami cywilnymi rzeczy są dochody, które rzecz przynosi na podstawie 
stosunku prawnego.

***
## Art. 54. {#art-54}

Pożytkami prawa są dochody, które prawo to przynosi zgodnie ze swym 
społeczno-gospodarczym przeznaczeniem.

***
## Art. 55. {#art-55}

§ 1. Uprawnionemu do pobierania pożytków przypadają pożytki 
naturalne, które zostały odłączone od rzeczy w czasie trwania jego uprawnienia, 
a pożytki cywilne – w stosunku do czasu trwania tego uprawnienia. 
§ 2. Jeżeli uprawniony do pobierania pożytków poczynił nakłady w celu 
uzyskania pożytków, które przypadły innej osobie, należy mu się od niej 
wynagrodzenie za te nakłady. Wynagrodzenie nie może przenosić wartości pożytków.

***
## Art. 551. {#art-551}

Przedsiębiorstwo 
jest 
zorganizowanym 
zespołem 
składników 
niematerialnych i materialnych przeznaczonym do prowadzenia działalności 
gospodarczej. 
Obejmuje ono w szczególności: 
- 1) oznaczenie indywidualizujące przedsiębiorstwo lub jego wyodrębnione części 
(nazwa przedsiębiorstwa); 
- 2) własność nieruchomości lub ruchomości, w tym urządzeń, materiałów, towarów 
i wyrobów, oraz inne prawa rzeczowe do nieruchomości lub ruchomości; 

©Kancelaria Sejmu 
 
 
 
s. 13/242 
 
   
 
2025-09-09 
- 3) prawa wynikające z umów najmu i dzierżawy nieruchomości lub ruchomości 
oraz prawa do korzystania z nieruchomości lub ruchomości wynikające z innych 
stosunków prawnych; 
- 4) wierzytelności, prawa z papierów wartościowych i środki pieniężne; 
- 5) koncesje, licencje i zezwolenia; 
- 6) patenty i inne prawa własności przemysłowej; 
- 7) majątkowe prawa autorskie i majątkowe prawa pokrewne; 
- 8) tajemnice przedsiębiorstwa; 
- 9) księgi i dokumenty związane z prowadzeniem działalności gospodarczej.

***
## Art. 552. {#art-552}

Czynność prawna mająca za przedmiot przedsiębiorstwo obejmuje 
wszystko, co wchodzi w skład przedsiębiorstwa, chyba że co innego wynika z treści 
czynności prawnej albo z przepisów szczególnych.

***
## Art. 553. {#art-553}

Za gospodarstwo rolne uważa się grunty rolne wraz z gruntami 
leśnymi, budynkami lub ich częściami, urządzeniami i inwentarzem, jeżeli stanowią 
lub mogą stanowić zorganizowaną całość gospodarczą, oraz prawami związanymi 
z prowadzeniem gospodarstwa rolnego.

***
## Art. 554. {#art-554}

Nabywca 
przedsiębiorstwa 
lub 
gospodarstwa 
rolnego 
jest 
odpowiedzialny solidarnie ze zbywcą za jego zobowiązania związane z prowadzeniem 
przedsiębiorstwa lub gospodarstwa, chyba że w chwili nabycia nie wiedział o tych 
zobowiązaniach, mimo zachowania należytej staranności. Odpowiedzialność 
nabywcy ogranicza się do wartości nabytego przedsiębiorstwa lub gospodarstwa 
według stanu w chwili nabycia, a według cen w chwili zaspokojenia wierzyciela. 
Odpowiedzialności tej nie można bez zgody wierzyciela wyłączyć ani ograniczyć. 
TYTUŁ IV 
Czynności prawne 
## DZIAŁ I. Przepisy ogólne

***
## Art. 56. {#art-56}

Czynność prawna wywołuje nie tylko skutki w niej wyrażone, lecz 
również te, które wynikają z ustawy, z zasad współżycia społecznego i z ustalonych 
zwyczajów. 

©Kancelaria Sejmu 
 
 
 
s. 14/242 
 
   
 
2025-09-09

***
## Art. 57. {#art-57}

§ 1. Nie można przez czynność prawną wyłączyć ani ograniczyć 
uprawnienia do przeniesienia, obciążenia, zmiany lub zniesienia prawa, jeżeli według 
ustawy prawo to jest zbywalne. 
§ 2. Przepis powyższy nie wyłącza dopuszczalności zobowiązania, że 
uprawniony nie dokona oznaczonych rozporządzeń prawem.

***
## Art. 58. {#art-58}

§ 1. Czynność prawna sprzeczna z ustawą albo mająca na celu obejście 
ustawy jest nieważna, chyba że właściwy przepis przewiduje inny skutek, 
w szczególności ten, iż na miejsce nieważnych postanowień czynności prawnej 
wchodzą odpowiednie przepisy ustawy. 
§ 2. Nieważna jest czynność prawna sprzeczna z zasadami współżycia 
społecznego. 
§ 3. Jeżeli nieważnością jest dotknięta tylko część czynności prawnej, czynność 
pozostaje w mocy co do pozostałych części, chyba że z okoliczności wynika, iż bez 
postanowień dotkniętych nieważnością czynność nie zostałaby dokonana.

***
## Art. 59. {#art-59}

W razie zawarcia umowy, której wykonanie czyni całkowicie lub 
częściowo niemożliwym zadośćuczynienie roszczeniu osoby trzeciej, osoba ta może 
żądać uznania umowy za bezskuteczną w stosunku do niej, jeżeli strony o jej 
roszczeniu wiedziały albo jeżeli umowa była nieodpłatna. Uznania umowy za 
bezskuteczną nie można żądać po upływie roku od jej zawarcia.

***
## Art. 60. {#art-60}

Z zastrzeżeniem wyjątków w ustawie przewidzianych, wola osoby 
dokonującej czynności prawnej może być wyrażona przez każde zachowanie się tej 
osoby, które ujawnia jej wolę w sposób dostateczny, w tym również przez ujawnienie 
tej woli w postaci elektronicznej (oświadczenie woli).

***
## Art. 61. {#art-61}

§ 1. Oświadczenie woli, które ma być złożone innej osobie, jest złożone 
z chwilą, gdy doszło do niej w taki sposób, że mogła zapoznać się z jego treścią. 
Odwołanie takiego oświadczenia jest skuteczne, jeżeli doszło jednocześnie z tym 
oświadczeniem lub wcześniej. 
§ 2. Oświadczenie woli wyrażone w postaci elektronicznej jest złożone innej 
osobie z chwilą, gdy wprowadzono je do środka komunikacji elektronicznej w taki 
sposób, żeby osoba ta mogła zapoznać się z jego treścią.

***
## Art. 62. {#art-62}

Oświadczenie woli, które ma być złożone innej osobie, nie traci mocy 
wskutek tego, że zanim do tej osoby doszło, składający je zmarł lub utracił zdolność 

©Kancelaria Sejmu 
 
 
 
s. 15/242 
 
   
 
2025-09-09 
 
do czynności prawnych, chyba że co innego wynika z treści oświadczenia, z ustawy 
lub z okoliczności.

***
## Art. 63. {#art-63}

§ 1. Jeżeli do dokonania czynności prawnej potrzebna jest zgoda osoby 
trzeciej, osoba ta może wyrazić zgodę także przed złożeniem oświadczenia przez 
osoby dokonywające czynności albo po jego złożeniu. Zgoda wyrażona po złożeniu 
oświadczenia ma moc wsteczną od jego daty. 
§ 2. Jeżeli do ważności czynności prawnej wymagana jest forma szczególna, 
oświadczenie obejmujące zgodę osoby trzeciej powinno być złożone w tej samej 
formie.

***
## Art. 64. {#art-64}

Prawomocne orzeczenie sądu stwierdzające obowiązek danej osoby do 
złożenia oznaczonego oświadczenia woli, zastępuje to oświadczenie.

***
## Art. 65. {#art-65}

§ 1. Oświadczenie woli należy tak tłumaczyć, jak tego wymagają ze 
względu na okoliczności, w których złożone zostało, zasady współżycia społecznego 
oraz ustalone zwyczaje. 
§ 2. W umowach należy raczej badać, jaki był zgodny zamiar stron i cel umowy, 
aniżeli opierać się na jej dosłownym brzmieniu.

***
## Art. 651. {#art-651}

Przepisy o oświadczeniach woli stosuje się odpowiednio do innych 
oświadczeń. 
## DZIAŁ II. Zawarcie umowy

***
## Art. 66. {#art-66}

§ 1. Oświadczenie drugiej stronie woli zawarcia umowy stanowi ofertę, 
jeżeli określa istotne postanowienia tej umowy. 
§ 2. Jeżeli oferent nie oznaczył w ofercie terminu, w ciągu którego oczekiwać 
będzie odpowiedzi, oferta złożona w obecności drugiej strony albo za pomocą środka 
bezpośredniego porozumiewania się na odległość przestaje wiązać, gdy nie zostanie 
przyjęta niezwłocznie; złożona w inny sposób przestaje wiązać z upływem czasu, 
w którym składający ofertę mógł w zwykłym toku czynności otrzymać odpowiedź 
wysłaną bez nieuzasadnionego opóźnienia.

***
## Art. 661. {#art-661}

§ 1. Oferta złożona w postaci elektronicznej wiąże składającego, jeżeli 
druga strona niezwłocznie potwierdzi jej otrzymanie. 

©Kancelaria Sejmu 
 
 
 
s. 16/242 
 
   
 
2025-09-09 
 
§ 2. Przedsiębiorca składający ofertę w postaci elektronicznej jest obowiązany 
przed zawarciem umowy poinformować drugą stronę w sposób jednoznaczny 
i zrozumiały o: 
- 1) czynnościach technicznych składających się na procedurę zawarcia umowy; 
- 2) skutkach prawnych potwierdzenia przez drugą stronę otrzymania oferty; 
- 3) zasadach i sposobach utrwalania, zabezpieczania i udostępniania przez 
przedsiębiorcę drugiej stronie treści zawieranej umowy; 
- 4) metodach i środkach technicznych służących wykrywaniu i korygowaniu błędów 
we wprowadzanych danych, które jest obowiązany udostępnić drugiej stronie; 
- 5) językach, w których umowa może być zawarta; 
- 6) kodeksach etycznych, które stosuje, oraz o ich dostępności w postaci 
elektronicznej. 
§ 3. Przepis § 2 stosuje się odpowiednio, jeżeli przedsiębiorca zaprasza drugą 
stronę do rozpoczęcia negocjacji, składania ofert albo do zawarcia umowy w inny 
sposób. 
§ 4. Przepisy § 1–3 nie mają zastosowania do zawierania umów za pomocą 
poczty elektronicznej albo podobnych środków indywidualnego porozumiewania się 
na odległość. Nie stosuje się ich także w stosunkach między przedsiębiorcami, jeżeli 
strony tak postanowiły.

***
## Art. 662. {#art-662}

§ 1. W stosunkach między przedsiębiorcami oferta może być odwołana 
przed zawarciem umowy, jeżeli oświadczenie o odwołaniu zostało złożone drugiej 
stronie przed wysłaniem przez nią oświadczenia o przyjęciu oferty. 
§ 2. Jednakże oferty nie można odwołać, jeżeli wynika to z jej treści lub 
określono w niej termin przyjęcia.

***
## Art. 67. {#art-67}

Jeżeli oświadczenie o przyjęciu oferty nadeszło z opóźnieniem, lecz 
z jego treści lub z okoliczności wynika, że zostało wysłane w czasie właściwym, 
umowa dochodzi do skutku, chyba że składający ofertę zawiadomi niezwłocznie drugą 
stronę, iż wskutek opóźnienia odpowiedzi poczytuje umowę za niezawartą.

***
## Art. 68. {#art-68}

Przyjęcie oferty dokonane z zastrzeżeniem zmiany lub uzupełnienia jej 
treści poczytuje się za nową ofertę.

***
## Art. 681. {#art-681}

§ 1. W stosunkach między przedsiębiorcami odpowiedź na ofertę 
z zastrzeżeniem zmian lub uzupełnień niezmieniających istotnie treści oferty 

©Kancelaria Sejmu 
 
 
 
s. 17/242 
 
   
 
2025-09-09 
 
poczytuje się za jej przyjęcie. W takim wypadku strony wiąże umowa o treści 
określonej w ofercie, z uwzględnieniem zastrzeżeń zawartych w odpowiedzi na nią. 
§ 2. Przepisu paragrafu poprzedzającego nie stosuje się, jeżeli w treści oferty 
wskazano, że może ona być przyjęta jedynie bez zastrzeżeń, albo gdy oferent 
niezwłocznie sprzeciwił się włączeniu zastrzeżeń do umowy, albo gdy druga strona 
w odpowiedzi na ofertę uzależniła jej przyjęcie od zgody oferenta na włączenie 
zastrzeżeń do umowy, a zgody tej niezwłocznie nie otrzymała.

***
## Art. 682. {#art-682}

Jeżeli przedsiębiorca otrzymał od osoby, z którą pozostaje w stałych 
stosunkach gospodarczych, ofertę zawarcia umowy w ramach swej działalności, brak 
niezwłocznej odpowiedzi poczytuje się za przyjęcie oferty.

***
## Art. 69. {#art-69}

Jeżeli według ustalonego w danych stosunkach zwyczaju lub według 
treści oferty dojście do składającego ofertę oświadczenia drugiej strony o jej przyjęciu 
nie jest wymagane, w szczególności jeżeli składający ofertę żąda niezwłocznego 
wykonania umowy, umowa dochodzi do skutku, skoro druga strona w czasie 
właściwym przystąpi do jej wykonania; w przeciwnym razie oferta przestaje wiązać.

***
## Art. 70. {#art-70}

§ 1. W razie wątpliwości umowę poczytuje się za zawartą w chwili 
otrzymania przez składającego ofertę oświadczenia o jej przyjęciu, a jeżeli dojście do 
składającego ofertę oświadczenia o jej przyjęciu nie jest wymagane – w chwili 
przystąpienia przez drugą stronę do wykonania umowy. 
§ 2. W razie wątpliwości umowę poczytuje się za zawartą w miejscu otrzymania 
przez składającego ofertę oświadczenia o jej przyjęciu, a jeżeli dojście do 
składającego ofertę oświadczenia o jej przyjęciu nie jest wymagane albo oferta jest 
składana w postaci elektronicznej – w miejscu zamieszkania albo w siedzibie 
składającego ofertę w chwili zawarcia umowy.

***
## Art. 701. {#art-701}

§ 1. Umowa może być zawarta w drodze aukcji albo przetargu. 
§ 2. W ogłoszeniu aukcji albo przetargu należy określić czas, miejsce, przedmiot 
oraz warunki aukcji albo przetargu albo wskazać sposób udostępnienia tych 
warunków. 
§ 3. Ogłoszenie, a także warunki aukcji albo przetargu mogą być zmienione lub 
odwołane tylko wtedy, gdy zastrzeżono to w ich treści. 

©Kancelaria Sejmu 
 
 
 
s. 18/242 
 
   
 
2025-09-09 
 
§ 4. Organizator od chwili udostępnienia warunków, a oferent od chwili złożenia 
oferty zgodnie z ogłoszeniem aukcji albo przetargu są obowiązani postępować 
zgodnie z postanowieniami ogłoszenia, a także warunków aukcji albo przetargu.

***
## Art. 702. {#art-702}

§ 1. Oferta złożona w toku aukcji przestaje wiązać, gdy inny uczestnik 
aukcji (licytant) złożył ofertę korzystniejszą, chyba że w warunkach aukcji 
zastrzeżono inaczej. 
§ 2. Zawarcie umowy w wyniku aukcji następuje z chwilą udzielenia przybicia. 
§ 3. Jeżeli ważność umowy zależy od spełnienia szczególnych wymagań 
przewidzianych w ustawie, zarówno organizator aukcji, jak i jej uczestnik, którego 
oferta została przyjęta, mogą dochodzić zawarcia umowy.

***
## Art. 703. {#art-703}

§ 1. Oferta złożona w toku przetargu przestaje wiązać, gdy została 
wybrana inna oferta albo gdy przetarg został zamknięty bez wybrania którejkolwiek 
z ofert, chyba że w warunkach przetargu zastrzeżono inaczej. 
§ 2. Organizator jest obowiązany niezwłocznie powiadomić na piśmie 
uczestników przetargu o jego wyniku albo o zamknięciu przetargu bez dokonania 
wyboru. 
§ 3. Do ustalenia chwili zawarcia umowy w drodze przetargu stosuje się przepisy 
dotyczące przyjęcia oferty, chyba że w warunkach przetargu zastrzeżono inaczej. 
Przepis art. 702 § 3 stosuje się odpowiednio.

***
## Art. 704. {#art-704}

§ 1. W warunkach aukcji albo przetargu można zastrzec, że 
przystępujący do aukcji albo przetargu powinien, pod rygorem niedopuszczenia do 
nich, wpłacić organizatorowi określoną sumę albo ustanowić odpowiednie 
zabezpieczenie jej zapłaty (wadium). 
§ 2. Jeżeli uczestnik aukcji albo przetargu, mimo wyboru jego oferty, uchyla się 
od zawarcia umowy, której ważność zależy od spełnienia szczególnych wymagań 
przewidzianych w ustawie, organizator aukcji albo przetargu może pobraną sumę 
zachować albo dochodzić zaspokojenia z przedmiotu zabezpieczenia. W pozostałych 
wypadkach zapłacone wadium należy niezwłocznie zwrócić, a ustanowione 
zabezpieczenie wygasa. Jeżeli organizator aukcji albo przetargu uchyla się od 
zawarcia umowy, ich uczestnik, którego oferta została wybrana, może żądać zapłaty 
podwójnego wadium albo naprawienia szkody. 

©Kancelaria Sejmu 
 
 
 
s. 19/242 
 
   
 
2025-09-09

***
## Art. 705. {#art-705}

§ 1. Organizator oraz uczestnik aukcji albo przetargu może żądać 
unieważnienia zawartej umowy, jeżeli strona tej umowy, inny uczestnik lub osoba 
działająca w porozumieniu z nimi wpłynęła na wynik aukcji albo przetargu w sposób 
sprzeczny z prawem lub dobrymi obyczajami. Jeżeli umowa została zawarta na cudzy 
rachunek, jej unieważnienia może żądać także ten, na czyj rachunek umowa została 
zawarta, lub dający zlecenie. 
§ 2. Uprawnienie powyższe wygasa z upływem miesiąca od dnia, w którym 
uprawniony dowiedział się o istnieniu przyczyny unieważnienia, nie później jednak 
niż z upływem roku od dnia zawarcia umowy.

***
## Art. 71. {#art-71}

Ogłoszenia, reklamy, cenniki i inne informacje, skierowane do ogółu 
lub do poszczególnych osób, poczytuje się w razie wątpliwości nie za ofertę, lecz za 
zaproszenie do zawarcia umowy.

***
## Art. 72. {#art-72}

§ 1. Jeżeli strony prowadzą negocjacje w celu zawarcia oznaczonej 
umowy, umowa zostaje zawarta, gdy strony dojdą do porozumienia co do wszystkich 
jej postanowień, które były przedmiotem negocjacji. 
§ 2. Strona, która rozpoczęła lub prowadziła negocjacje z naruszeniem dobrych 
obyczajów, w szczególności bez zamiaru zawarcia umowy, jest obowiązana do 
naprawienia szkody, jaką druga strona poniosła przez to, że liczyła na zawarcie 
umowy.

***
## Art. 721. {#art-721}

§ 1. Jeżeli 
w toku 
negocjacji 
strona 
udostępniła 
informacje 
z zastrzeżeniem poufności, druga strona jest obowiązana do nieujawniania 
i nieprzekazywania ich innym osobom oraz do niewykorzystywania tych informacji 
dla własnych celów, chyba że strony uzgodniły inaczej. 
§ 2. W razie niewykonania lub nienależytego wykonania obowiązków, o których 
mowa w § 1, uprawniony może żądać od drugiej strony naprawienia szkody albo 
wydania uzyskanych przez nią korzyści. 
## DZIAŁ III. Forma czynności prawnych

***
## Art. 73. {#art-73}

§ 1. Jeżeli ustawa zastrzega dla czynności prawnej formę pisemną, 
dokumentową albo elektroniczną, czynność dokonana bez zachowania zastrzeżonej 
formy jest nieważna tylko wtedy, gdy ustawa przewiduje rygor nieważności. 

©Kancelaria Sejmu 
 
 
 
s. 20/242 
 
   
 
2025-09-09 
 
§ 2. Jeżeli ustawa zastrzega dla czynności prawnej inną formę szczególną, 
czynność dokonana bez zachowania tej formy jest nieważna. Nie dotyczy to jednak 
wypadków, gdy zachowanie formy szczególnej jest zastrzeżone jedynie dla 
wywołania określonych skutków czynności prawnej.

***
## Art. 74. {#art-74}

§ 1. Zastrzeżenie formy pisemnej, dokumentowej albo elektronicznej 
bez rygoru nieważności ma ten skutek, że w razie niezachowania zastrzeżonej formy 
nie jest w sporze dopuszczalny dowód z zeznań świadków lub z przesłuchania stron 
na fakt dokonania czynności. Przepisu tego nie stosuje się, gdy zachowanie formy 
pisemnej, dokumentowej albo elektronicznej jest zastrzeżone jedynie dla wywołania 
określonych skutków czynności prawnej. 
§ 2. Jednakże mimo niezachowania formy pisemnej, dokumentowej albo 
elektronicznej przewidzianej dla celów dowodowych dowód z zeznań świadków lub 
z przesłuchania stron jest dopuszczalny, jeżeli obie strony wyrażą na to zgodę, żąda 
tego konsument w sporze z przedsiębiorcą albo fakt dokonania czynności prawnej jest 
uprawdopodobniony za pomocą dokumentu. 
§ 3. Jeżeli forma pisemna, dokumentowa albo elektroniczna jest zastrzeżona dla 
oświadczenia jednej ze stron, w razie jej niezachowania dowód z zeznań świadków 
lub z przesłuchania stron na fakt dokonania tej czynności jest dopuszczalny także na 
żądanie drugiej strony. 
§ 4. Przepisów o skutkach niezachowania formy pisemnej, dokumentowej albo 
elektronicznej przewidzianej dla celów dowodowych nie stosuje się do czynności 
prawnych w stosunkach między przedsiębiorcami.

***
## Art. 75. {#art-75}

(uchylony)

***
## Art. 751. {#art-751}

§ 1. Zbycie lub wydzierżawienie przedsiębiorstwa albo ustanowienie 
na nim użytkowania powinno być dokonane w formie pisemnej z podpisami 
notarialnie poświadczonymi. 
§ 2. Zbycie przedsiębiorstwa należącego do osoby wpisanej do rejestru powinno 
być wpisane do rejestru. 
§ 3. Przepis 
§ 2 stosuje 
się 
odpowiednio 
w wypadku 
wydzierżawienia 
przedsiębiorstwa lub ustanowienia na nim użytkowania. 
§ 4. Przepisy powyższe nie uchybiają przepisom o formie czynności prawnych 
dotyczących nieruchomości. 

©Kancelaria Sejmu 
 
 
 
s. 21/242 
 
   
 
2025-09-09

***
## Art. 76. {#art-76}

Jeżeli strony zastrzegły w umowie, że określona czynność prawna 
między nimi ma być dokonana w szczególnej formie, czynność ta dochodzi do skutku 
tylko przy zachowaniu zastrzeżonej formy. Jednakże gdy strony zastrzegły dokonanie 
czynności w formie pisemnej, dokumentowej albo elektronicznej, nie określając 
skutków niezachowania tej formy, w razie wątpliwości poczytuje się, że była ona 
zastrzeżona wyłącznie dla celów dowodowych.

***
## Art. 77. {#art-77}

§ 1. Uzupełnienie lub zmiana umowy wymaga zachowania takiej formy, 
jaką ustawa lub strony przewidziały w celu jej zawarcia. 
§ 2. Jeżeli umowa została zawarta w formie pisemnej, dokumentowej albo 
elektronicznej, jej rozwiązanie za zgodą obu stron, jak również odstąpienie od niej 
albo jej wypowiedzenie wymaga zachowania formy dokumentowej, chyba że ustawa 
lub umowa zastrzega inną formę. 
§ 3. Jeżeli umowa została zawarta w innej formie szczególnej, jej rozwiązanie za 
zgodą obu stron wymaga zachowania takiej formy, jaką ustawa lub strony 
przewidziały w celu jej zawarcia; natomiast odstąpienie od umowy albo jej 
wypowiedzenie powinno być stwierdzone pismem.

***
## Art. 771. {#art-771}

§ 1. W wypadku gdy umowę zawartą pomiędzy przedsiębiorcami bez 
zachowania formy pisemnej jedna strona niezwłocznie potwierdzi w piśmie 
skierowanym do drugiej strony, a pismo to zawiera zmiany lub uzupełnienia umowy, 
niezmieniające istotnie jej treści, strony wiąże umowa o treści określonej w piśmie 
potwierdzającym, chyba że druga strona niezwłocznie się temu sprzeciwiła na piśmie. 
§ 2. W przypadku gdy umowę zawartą pomiędzy przedsiębiorcami bez 
zachowania 
formy 
dokumentowej 
jedna 
strona 
niezwłocznie 
potwierdzi 
w dokumencie skierowanym do drugiej strony, a dokument ten zawiera zmiany lub 
uzupełnienia umowy, niezmieniające istotnie jej treści, strony wiąże umowa o treści 
określonej w dokumencie potwierdzającym, chyba że druga strona niezwłocznie się 
temu sprzeciwiła w dokumencie.

***
## Art. 772. {#art-772}

Do zachowania dokumentowej formy czynności prawnej wystarcza 
złożenie oświadczenia woli w postaci dokumentu, w sposób umożliwiający ustalenie 
osoby składającej oświadczenie.

***
## Art. 773. {#art-773}

Dokumentem jest nośnik informacji umożliwiający zapoznanie się z jej 
treścią. 

©Kancelaria Sejmu 
 
 
 
s. 22/242 
 
   
 
2025-09-09

***
## Art. 78. {#art-78}

§ 1. Do zachowania pisemnej formy czynności prawnej wystarcza 
złożenie własnoręcznego podpisu na dokumencie obejmującym treść oświadczenia 
woli. Do zawarcia umowy wystarcza wymiana dokumentów obejmujących treść 
oświadczeń woli, z których każdy jest podpisany przez jedną ze stron, lub 
dokumentów, z których każdy obejmuje treść oświadczenia woli jednej ze stron i jest 
przez nią podpisany. 
§ 2. (uchylony)

***
## Art. 781. {#art-781}

§ 1. Do zachowania elektronicznej formy czynności prawnej wystarcza 
złożenie oświadczenia woli w postaci elektronicznej i opatrzenie go kwalifikowanym 
podpisem elektronicznym. 
§ 2. Oświadczenie woli złożone w formie elektronicznej jest równoważne 
z oświadczeniem woli złożonym w formie pisemnej.

***
## Art. 79. {#art-79}

Osoba niemogąca pisać może złożyć oświadczenie woli w formie 
pisemnej w ten sposób, że uczyni na dokumencie tuszowy odcisk palca, a obok tego 
odcisku osoba przez nią upoważniona wypisze jej imię i nazwisko oraz złoży swój 
podpis, albo w ten sposób, że zamiast składającego oświadczenie podpisze się osoba 
przez niego upoważniona, a jej podpis będzie poświadczony przez notariusza, wójta 
(burmistrza, prezydenta miasta), starostę lub marszałka województwa z zaznaczeniem, 
że został złożony na życzenie osoby niemogącej pisać.

***
## Art. 80. {#art-80}

(uchylony)

***
## Art. 81. {#art-81}

§ 1. Jeżeli ustawa uzależnia ważność albo określone skutki czynności 
prawnej od urzędowego poświadczenia daty, poświadczenie takie jest skuteczne także 
względem osób nieuczestniczących w dokonaniu tej czynności prawnej (data pewna). 
§ 2. Czynność prawna ma datę pewną także w wypadkach następujących: 
- 1) w razie stwierdzenia dokonania czynności w jakimkolwiek dokumencie 
urzędowym – od daty dokumentu urzędowego; 
- 2) w razie umieszczenia na obejmującym czynność dokumencie jakiejkolwiek 
wzmianki przez organ państwowy, organ jednostki samorządu terytorialnego 
albo przez notariusza – od daty wzmianki; 
- 3) w razie opatrzenia kwalifikowanym elektronicznym znacznikiem czasu 
dokumentu w postaci elektronicznej – od daty opatrzenia kwalifikowanym 
elektronicznym znacznikiem czasu. 

©Kancelaria Sejmu 
 
 
 
s. 23/242 
 
   
 
2025-09-09 
 
§ 3. W razie śmierci jednej z osób podpisanych na dokumencie datę złożenia 
przez tę osobę podpisu na dokumencie uważa się za pewną od daty śmierci tej osoby. 
## DZIAŁ IV. Wady oświadczenia woli

***
## Art. 82. {#art-82}

Nieważne jest oświadczenie woli złożone przez osobę, która 
z jakichkolwiek powodów znajdowała się w stanie wyłączającym świadome albo 
swobodne powzięcie decyzji i wyrażenie woli. Dotyczy to w szczególności choroby 
psychicznej, 
niedorozwoju 
umysłowego 
albo 
innego, 
chociażby 
nawet 
przemijającego, zaburzenia czynności psychicznych.

***
## Art. 83. {#art-83}

§ 1. Nieważne jest oświadczenie woli złożone drugiej stronie za jej 
zgodą dla pozoru. Jeżeli oświadczenie takie zostało złożone dla ukrycia innej 
czynności prawnej, ważność oświadczenia ocenia się według właściwości tej 
czynności. 
§ 2. Pozorność oświadczenia woli nie ma wpływu na skuteczność odpłatnej 
czynności prawnej, dokonanej na podstawie pozornego oświadczenia, jeżeli wskutek 
tej czynności osoba trzecia nabywa prawo lub zostaje zwolniona od obowiązku, chyba 
że działała w złej wierze.

***
## Art. 84. {#art-84}

§ 1. W razie błędu co do treści czynności prawnej można uchylić się od 
skutków prawnych swego oświadczenia woli. Jeżeli jednak oświadczenie woli było 
złożone innej osobie, uchylenie się od jego skutków prawnych dopuszczalne jest tylko 
wtedy, gdy błąd został wywołany przez tę osobę, chociażby bez jej winy, albo gdy 
wiedziała ona o błędzie lub mogła z łatwością błąd zauważyć; ograniczenie to nie 
dotyczy czynności prawnej nieodpłatnej. 
§ 2. Można powoływać się tylko na błąd uzasadniający przypuszczenie, że gdyby 
składający oświadczenie woli nie działał pod wpływem błędu i oceniał sprawę 
rozsądnie, nie złożyłby oświadczenia tej treści (błąd istotny).

***
## Art. 85. {#art-85}

Zniekształcenie oświadczenia woli przez osobę użytą do jego przesłania 
ma takie same skutki, jak błąd przy złożeniu oświadczenia.

***
## Art. 86. {#art-86}

§ 1. Jeżeli błąd wywołała druga strona podstępnie, uchylenie się od 
skutków prawnych oświadczenia woli złożonego pod wpływem błędu może nastąpić 

©Kancelaria Sejmu 
 
 
 
s. 24/242 
 
   
 
2025-09-09 
 
także wtedy, gdy błąd nie był istotny, jak również wtedy, gdy nie dotyczył treści 
czynności prawnej. 
§ 2. Podstęp osoby trzeciej jest jednoznaczny z podstępem strony, jeżeli ta 
o podstępie wiedziała i nie zawiadomiła o nim drugiej strony albo jeżeli czynność 
prawna była nieodpłatna.

***
## Art. 87. {#art-87}

Kto złożył oświadczenie woli pod wpływem bezprawnej groźby drugiej 
strony lub osoby trzeciej, ten może uchylić się od skutków prawnych swego 
oświadczenia, jeżeli z okoliczności wynika, że mógł się obawiać, iż jemu samemu lub 
innej osobie grozi poważne niebezpieczeństwo osobiste lub majątkowe.

***
## Art. 88. {#art-88}

§ 1. Uchylenie się od skutków prawnych oświadczenia woli, które 
zostało złożone innej osobie pod wpływem błędu lub groźby, następuje przez 
oświadczenie złożone tej osobie na piśmie. 
§ 2. Uprawnienie do uchylenia się wygasa: w razie błędu – z upływem roku od 
jego wykrycia, a w razie groźby – z upływem roku od chwili, kiedy stan obawy ustał. 
## DZIAŁ V. Warunek

***
## Art. 89. {#art-89}

Z zastrzeżeniem 
wyjątków 
w ustawie 
przewidzianych 
albo 
wynikających z właściwości czynności prawnej, powstanie lub ustanie skutków 
czynności prawnej można uzależnić od zdarzenia przyszłego i niepewnego (warunek).

***
## Art. 90. {#art-90}

Ziszczenie się warunku nie ma mocy wstecznej, chyba że inaczej 
zastrzeżono.

***
## Art. 91. {#art-91}

Warunkowo uprawniony może wykonywać wszelkie czynności, które 
zmierzają do zachowania jego prawa.

***
## Art. 92. {#art-92}

§ 1. Jeżeli czynność prawna obejmująca rozporządzenie prawem została 
dokonana pod warunkiem, późniejsze rozporządzenia tym prawem tracą moc z chwilą 
ziszczenia się warunku o tyle, o ile udaremniają lub ograniczają skutek ziszczenia się 
warunku. 
§ 2. Jednakże gdy na podstawie takiego rozporządzenia osoba trzecia nabywa 
prawo lub zostaje zwolniona od obowiązku, stosuje się odpowiednio przepisy 
o ochronie osób, które w dobrej wierze dokonały czynności prawnej z osobą 
nieuprawnioną do rozporządzania prawem. 

©Kancelaria Sejmu 
 
 
 
s. 25/242 
 
   
 
2025-09-09

***
## Art. 93. {#art-93}

§ 1. Jeżeli strona, której zależy na nieziszczeniu się warunku, 
przeszkodzi w sposób sprzeczny z zasadami współżycia społecznego ziszczeniu się 
warunku, następują skutki takie, jakby warunek się ziścił. 
§ 2. Jeżeli strona, której zależy na ziszczeniu się warunku, doprowadzi w sposób 
sprzeczny z zasadami współżycia społecznego do ziszczenia się warunku, następują 
skutki takie, jakby warunek się nie ziścił.

***
## Art. 94. {#art-94}

Warunek niemożliwy, jak również warunek przeciwny ustawie lub 
zasadom współżycia społecznego pociąga za sobą nieważność czynności prawnej, gdy 
jest zawieszający; uważa się za niezastrzeżony, gdy jest rozwiązujący. 
## DZIAŁ VI. Przedstawicielstwo 
## Rozdział I. Przepisy ogólne

***
## Art. 95. {#art-95}

§ 1. Z zastrzeżeniem wyjątków w ustawie przewidzianych albo 
wynikających z właściwości czynności prawnej, można dokonać czynności prawnej 
przez przedstawiciela. 
§ 2. Czynność prawna dokonana przez przedstawiciela w granicach umocowania 
pociąga za sobą skutki bezpośrednio dla reprezentowanego.

***
## Art. 96. {#art-96}

Umocowanie do działania w cudzym imieniu może opierać się na 
ustawie (przedstawicielstwo ustawowe) albo na oświadczeniu reprezentowanego 
(pełnomocnictwo).

***
## Art. 97. {#art-97}

Osobę 
czynną 
w lokalu 
przedsiębiorstwa 
przeznaczonym 
do 
obsługiwania publiczności poczytuje się w razie wątpliwości za umocowaną do 
dokonywania czynności prawnych, które zazwyczaj bywają dokonywane z osobami 
korzystającymi z usług tego przedsiębiorstwa. 
## Rozdział II. Pełnomocnictwo

***
## Art. 98. {#art-98}

Pełnomocnictwo ogólne obejmuje umocowanie do czynności zwykłego 
zarządu. Do czynności przekraczających zakres zwykłego zarządu potrzebne jest 

©Kancelaria Sejmu 
 
 
 
s. 26/242 
 
   
 
2025-09-09 
 
pełnomocnictwo określające ich rodzaj, chyba że ustawa wymaga pełnomocnictwa do 
poszczególnej czynności.

***
## Art. 99. {#art-99}

§ 1. Jeżeli do ważności czynności prawnej potrzebna jest szczególna 
forma, pełnomocnictwo do dokonania tej czynności powinno być udzielone w tej 
samej formie. 
§ 2. Pełnomocnictwo ogólne powinno być pod rygorem nieważności udzielone 
na piśmie.

***
## Art. 100. {#art-100}

Okoliczność, że pełnomocnik jest ograniczony w zdolności do 
czynności prawnych, nie ma wpływu na ważność czynności dokonanej przez niego 
w imieniu mocodawcy.

***
## Art. 101. {#art-101}

§ 1. Pełnomocnictwo może być w każdym czasie odwołane, chyba że 
mocodawca zrzekł się odwołania pełnomocnictwa z przyczyn uzasadnionych treścią 
stosunku prawnego będącego podstawą pełnomocnictwa. 
§ 2. Umocowanie wygasa ze śmiercią mocodawcy lub pełnomocnika, chyba że 
w pełnomocnictwie inaczej zastrzeżono z przyczyn uzasadnionych treścią stosunku 
prawnego będącego podstawą pełnomocnictwa.

***
## Art. 102. {#art-102}

Po wygaśnięciu umocowania pełnomocnik obowiązany jest zwrócić 
mocodawcy dokument pełnomocnictwa. Może żądać poświadczonego odpisu tego 
dokumentu; wygaśnięcie umocowania powinno być na odpisie zaznaczone.

***
## Art. 103. {#art-103}

§ 1. Jeżeli zawierający umowę jako pełnomocnik nie ma umocowania 
albo przekroczy jego zakres, ważność umowy zależy od jej potwierdzenia przez osobę, 
w której imieniu umowa została zawarta. 
§ 2. Druga strona może wyznaczyć osobie, w której imieniu umowa została 
zawarta, odpowiedni termin do potwierdzenia umowy; staje się wolna po 
bezskutecznym upływie wyznaczonego terminu. 
§ 3. W braku potwierdzenia ten, kto zawarł umowę w cudzym imieniu, 
obowiązany jest do zwrotu tego, co otrzymał od drugiej strony w wykonaniu umowy, 
oraz do naprawienia szkody, którą druga strona poniosła przez to, że zawarła umowę 
nie wiedząc o braku umocowania lub o przekroczeniu jego zakresu.

***
## Art. 104. {#art-104}

Jednostronna czynność prawna dokonana w cudzym imieniu bez 
umocowania lub z przekroczeniem jego zakresu jest nieważna. Jednakże gdy ten, 

©Kancelaria Sejmu 
 
 
 
s. 27/242 
 
   
 
2025-09-09 
 
komu zostało złożone oświadczenie woli w cudzym imieniu, zgodził się na działanie 
bez umocowania, stosuje się odpowiednio przepisy o zawarciu umowy bez 
umocowania.

***
## Art. 105. {#art-105}

Jeżeli pełnomocnik po wygaśnięciu umocowania dokona w imieniu 
mocodawcy czynności prawnej w granicach pierwotnego umocowania, czynność 
prawna jest ważna, chyba że druga strona o wygaśnięciu umocowania wiedziała lub 
z łatwością mogła się dowiedzieć.

***
## Art. 106. {#art-106}

Pełnomocnik może ustanowić dla mocodawcy innych pełnomocników 
tylko wtedy, gdy umocowanie takie wynika z treści pełnomocnictwa, z ustawy lub ze 
stosunku prawnego będącego podstawą pełnomocnictwa.

***
## Art. 107. {#art-107}

Jeżeli mocodawca ustanowił kilku pełnomocników z takim samym 
zakresem umocowania, każdy z nich może działać samodzielnie, chyba że co innego 
wynika z treści pełnomocnictwa. Przepis ten stosuje się odpowiednio do 
pełnomocników, których pełnomocnik sam dla mocodawcy ustanowił.

***
## Art. 108. {#art-108}

Pełnomocnik nie może być drugą stroną czynności prawnej, której 
dokonywa w imieniu mocodawcy, chyba że co innego wynika z treści 
pełnomocnictwa albo że ze względu na treść czynności prawnej wyłączona jest 
możliwość naruszenia interesów mocodawcy. Przepis ten stosuje się odpowiednio 
w wypadku, gdy pełnomocnik reprezentuje obie strony.

***
## Art. 109. {#art-109}

Przepisy działu niniejszego stosuje się odpowiednio w wypadku, gdy 
oświadczenie woli ma być złożone przedstawicielowi. 
## Rozdział III. Prokura

***
## Art. 1091. {#art-1091}

§ 1. Prokura jest pełnomocnictwem udzielonym przez przedsiębiorcę 
podlegającego obowiązkowi wpisu do Centralnej Ewidencji i Informacji o 
Działalności Gospodarczej albo do rejestru przedsiębiorców Krajowego Rejestru 
Sądowego, które obejmuje umocowanie do czynności sądowych i pozasądowych, 
jakie są związane z prowadzeniem przedsiębiorstwa. 
§ 2. Nie można ograniczyć prokury ze skutkiem wobec osób trzecich, chyba że 
przepis szczególny stanowi inaczej. 

©Kancelaria Sejmu 
 
 
 
s. 28/242 
 
   
 
2025-09-09

***
## Art. 1092. {#art-1092}

§ 1. Prokura powinna być pod rygorem nieważności udzielona na 
piśmie. Przepisu art. 99 § 1 nie stosuje się. 
§ 2. Prokurentem może być osoba fizyczna mająca pełną zdolność do czynności 
prawnych.

***
## Art. 1093. {#art-1093}

Do zbycia przedsiębiorstwa, do dokonania czynności prawnej, na 
podstawie której następuje oddanie go do czasowego korzystania, oraz do zbywania 
i obciążania nieruchomości jest wymagane pełnomocnictwo do poszczególnej 
czynności.

***
## Art. 1094. {#art-1094}

§ 1. Prokura może być udzielona kilku osobom łącznie (prokura 
łączna) lub oddzielnie. 
§ 11. Prokura może obejmować umocowanie także albo wyłącznie do 
dokonywania czynności wspólnie z członkiem organu zarządzającego lub 
wspólnikiem uprawnionym do reprezentowania handlowej spółki osobowej. 
§ 2. Kierowane do przedsiębiorcy oświadczenia lub doręczenia pism mogą być 
dokonywane wobec jednej z osób, którym udzielono prokury.

***
## Art. 1095. {#art-1095}

Prokurę można ograniczyć do zakresu spraw wpisanych do rejestru 
oddziału przedsiębiorstwa (prokura oddziałowa).

***
## Art. 1096. {#art-1096}

Prokura nie może być przeniesiona. Prokurent może ustanowić 
pełnomocnika do poszczególnej czynności lub pewnego rodzaju czynności.

***
## Art. 1097. {#art-1097}

§ 1. Prokura może być w każdym czasie odwołana. 
§ 2. Prokura wygasa wskutek wykreślenia przedsiębiorcy z Centralnej Ewidencji 
i Informacji o Działalności Gospodarczej albo z rejestru przedsiębiorców Krajowego 
Rejestru Sądowego, a także ogłoszenia upadłości, otwarcia likwidacji oraz 
przekształcenia przedsiębiorcy. 
§ 3. Prokura wygasa ze śmiercią prokurenta. 
§ 31. Prokura wygasa wskutek ustanowienia kuratora na podstawie art. 42 § 1. W 
okresie kurateli prokura nie może być ustanowiona. 
§ 4. Utrata przez przedsiębiorcę zdolności do czynności prawnych nie powoduje 
wygaśnięcia prokury. 

©Kancelaria Sejmu 
 
 
 
s. 29/242 
 
   
 
2025-09-09

***
## Art. 1098. {#art-1098}

§ 1. Udzielenie i wygaśnięcie prokury przedsiębiorca powinien 
zgłosić do Centralnej Ewidencji i Informacji o Działalności Gospodarczej albo rejestru 
przedsiębiorców Krajowego Rejestru Sądowego. 
§ 2. Zgłoszenie o udzieleniu prokury powinno określać jej rodzaj, a w przypadku 
prokury łącznej oraz prokury, o której mowa w art. 1094 § 11, także sposób jej 
wykonywania.

***
## Art. 1099. {#art-1099}

(uchylony) 
TYTUŁ V 
Termin

***
## Art. 110. {#art-110}

Jeżeli ustawa, orzeczenie sądu lub decyzja innego organu 
państwowego albo czynność prawna oznacza termin nie określając sposobu jego 
obliczania, stosuje się przepisy poniższe.

***
## Art. 111. {#art-111}

§ 1. Termin oznaczony w dniach kończy się z upływem ostatniego 
dnia. 
§ 2. Jeżeli początkiem terminu oznaczonego w dniach jest pewne zdarzenie, nie 
uwzględnia się przy obliczaniu terminu dnia, w którym to zdarzenie nastąpiło.

***
## Art. 112. {#art-112}

Termin oznaczony w tygodniach, miesiącach lub latach kończy się 
z upływem dnia, który nazwą lub datą odpowiada początkowemu dniowi terminu, 
a gdyby takiego dnia w ostatnim miesiącu nie było – w ostatnim dniu tego miesiąca. 
Jednakże przy obliczaniu wieku osoby fizycznej termin upływa z początkiem 
ostatniego dnia.

***
## Art. 113. {#art-113}

§ 1. Jeżeli termin jest oznaczony na początek, środek lub koniec 
miesiąca, rozumie się przez to pierwszy, piętnasty lub ostatni dzień miesiąca. 
§ 2. Termin półmiesięczny jest równy piętnastu dniom.

***
## Art. 114. {#art-114}

Jeżeli termin jest oznaczony w miesiącach lub latach, a ciągłość 
terminu nie jest wymagana, miesiąc liczy się za dni trzydzieści, a rok za dni trzysta 
sześćdziesiąt pięć.

***
## Art. 115. {#art-115}

Jeżeli koniec terminu do wykonania czynności przypada na dzień 
uznany ustawowo za wolny od pracy lub na sobotę, termin upływa następnego dnia, 
który nie jest dniem wolnym od pracy ani sobotą. 

©Kancelaria Sejmu 
 
 
 
s. 30/242 
 
   
 
2025-09-09

***
## Art. 116. {#art-116}

§ 1. Jeżeli skutki czynności prawnej mają powstać w oznaczonym 
terminie, stosuje się odpowiednio przepisy o warunku zawieszającym. 
§ 2. Jeżeli skutki czynności prawnej mają ustać w oznaczonym terminie, stosuje 
się odpowiednio przepisy o warunku rozwiązującym. 
TYTUŁ VI 
Przedawnienie roszczeń

***
## Art. 117. {#art-117}

§ 1. Z zastrzeżeniem wyjątków w ustawie przewidzianych, roszczenia 
majątkowe ulegają przedawnieniu. 
§ 2. Po upływie terminu przedawnienia ten, przeciwko komu przysługuje 
roszczenie, może uchylić się od jego zaspokojenia, chyba że zrzeka się korzystania 
z zarzutu przedawnienia. Jednakże zrzeczenie się zarzutu przedawnienia przed 
upływem terminu jest nieważne. 
§ 21. Po upływie terminu przedawnienia nie można domagać się zaspokojenia 
roszczenia przysługującego przeciwko konsumentowi. 
§ 3. (uchylony)

***
## Art. 1171. {#art-1171}

§ 1. W wyjątkowych przypadkach sąd może, po rozważeniu interesów 
stron, nie uwzględnić upływu terminu przedawnienia roszczenia przysługującego 
przeciwko konsumentowi, jeżeli wymagają tego względy słuszności.  
§ 2. Korzystając z uprawnienia, o którym mowa w § 1, sąd powinien rozważyć 
w szczególności:  
- 1) długość terminu przedawnienia;  
- 2) długość okresu od upływu terminu przedawnienia do chwili dochodzenia 
roszczenia;  
- 3) charakter okoliczności, które spowodowały niedochodzenie roszczenia przez 
uprawnionego, w tym wpływ zachowania zobowiązanego na opóźnienie 
uprawnionego w dochodzeniu roszczenia.

***
## Art. 118. {#art-118}

Jeżeli przepis szczególny nie stanowi inaczej, termin przedawnienia 
wynosi sześć lat, a dla roszczeń o świadczenia okresowe oraz roszczeń związanych z 
prowadzeniem działalności gospodarczej – trzy lata. Jednakże koniec terminu 
przedawnienia przypada na ostatni dzień roku kalendarzowego, chyba że termin 
przedawnienia jest krótszy niż dwa lata. 

©Kancelaria Sejmu 
 
 
 
s. 31/242 
 
   
 
2025-09-09

***
## Art. 119. {#art-119}

Terminy przedawnienia nie mogą być skracane ani przedłużane przez 
czynność prawną.

***
## Art. 120. {#art-120}

§ 1. Bieg przedawnienia rozpoczyna się od dnia, w którym roszczenie 
stało się wymagalne. Jeżeli wymagalność roszczenia zależy od podjęcia określonej 
czynności przez uprawnionego, bieg terminu rozpoczyna się od dnia, w którym 
roszczenie stałoby się wymagalne, gdyby uprawniony podjął czynność w najwcześniej 
możliwym terminie. 
§ 2. Bieg przedawnienia roszczeń o zaniechanie rozpoczyna się od dnia, 
w którym ten, przeciwko komu roszczenie przysługuje, nie zastosował się do treści 
roszczenia.

***
## Art. 121. {#art-121}

Bieg przedawnienia nie rozpoczyna się, a rozpoczęty ulega 
zawieszeniu: 
- 1) co do roszczeń, które przysługują dzieciom przeciwko rodzicom – przez czas 
trwania władzy rodzicielskiej; 
- 2) co do roszczeń, które przysługują osobom niemającym pełnej zdolności do 
czynności prawnych przeciwko osobom sprawującym opiekę lub kuratelę – przez 
czas sprawowania przez te osoby opieki lub kurateli; 
- 3) co do roszczeń, które przysługują jednemu z małżonków przeciwko drugiemu – 
przez czas trwania małżeństwa; 
- 4) co do wszelkich roszczeń, gdy z powodu siły wyższej uprawniony nie może ich 
dochodzić przed sądem lub innym organem powołanym do rozpoznawania spraw 
danego rodzaju – przez czas trwania przeszkody; 
- 5) co do roszczeń objętych umową o mediację – przez czas trwania mediacji; 
- 6) co do roszczeń objętych wnioskiem o zawezwanie do próby ugodowej – przez 
czas trwania postępowania pojednawczego.

***
## Art. 122. {#art-122}

§ 1. Przedawnienie względem osoby, która nie ma pełnej zdolności do 
czynności prawnych, nie może skończyć się wcześniej niż z upływem lat dwóch od 
ustanowienia dla niej przedstawiciela ustawowego albo od ustania przyczyny jego 
ustanowienia. 
§ 2. Jeżeli termin przedawnienia jest krótszy niż dwa lata, jego bieg liczy się od 
dnia ustanowienia przedstawiciela ustawowego albo od dnia, w którym ustała 
przyczyna jego ustanowienia. 

©Kancelaria Sejmu 
 
 
 
s. 32/242 
 
   
 
2025-09-09 
 
§ 3. Przepisy powyższe stosuje się odpowiednio do biegu przedawnienia 
przeciwko osobie, co do której istnieje podstawa do jej całkowitego 
ubezwłasnowolnienia.

***
## Art. 123. {#art-123}

§ 1. Bieg przedawnienia przerywa się: 
- 1) przez każdą czynność przed sądem lub innym organem powołanym do 
rozpoznawania spraw lub egzekwowania roszczeń danego rodzaju albo przed 
sądem polubownym, przedsięwziętą bezpośrednio w celu dochodzenia lub 
ustalenia albo zaspokojenia lub zabezpieczenia roszczenia; 
- 2) przez uznanie roszczenia przez osobę, przeciwko której roszczenie przysługuje; 
- 3) (uchylony) 
§ 2. (uchylony)

***
## Art. 124. {#art-124}

§ 1. Po każdym przerwaniu przedawnienia biegnie ono na nowo. 
§ 2. W razie przerwania przedawnienia przez czynność w postępowaniu przed 
sądem lub innym organem powołanym do rozpoznawania spraw lub egzekwowania 
roszczeń danego rodzaju albo przed sądem polubownym przedawnienie nie biegnie na 
nowo, dopóki postępowanie to nie zostanie zakończone.

***
## Art. 125. {#art-125}

§ 1. Roszczenie stwierdzone prawomocnym orzeczeniem sądu lub 
innego organu powołanego do rozpoznawania spraw danego rodzaju albo orzeczeniem 
sądu polubownego, jak również roszczenie stwierdzone ugodą zawartą przed sądem 
albo sądem polubownym albo ugodą zawartą przed mediatorem i zatwierdzoną przez 
sąd przedawnia się z upływem sześciu lat. Jeżeli stwierdzone w ten sposób roszczenie 
obejmuje świadczenia okresowe, roszczenie o świadczenie okresowe należne w 
przyszłości przedawnia się z upływem trzech lat. 
§ 2. (uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 33/242 
 
   
 
2025-09-09 
 
KSIĘGA DRUGA 
WŁASNOŚĆ I INNE PRAWA RZECZOWE 
TYTUŁ I 
Własność 
## DZIAŁ I. Przepisy ogólne

***
## Art. 126. {#art-126}

(uchylony)

***
## Art. 127. {#art-127}

(uchylony)

***
## Art. 128. {#art-128}

(uchylony)

***
## Art. 129. {#art-129}

(uchylony)

***
## Art. 130. {#art-130}

(uchylony)

***
## Art. 131. {#art-131}

(uchylony)

***
## Art. 132. {#art-132}

(uchylony)

***
## Art. 133. {#art-133}

(uchylony)

***
## Art. 134. {#art-134}

(uchylony)

***
## Art. 135. {#art-135}

(uchylony)

***
## Art. 136. {#art-136}

(uchylony)

***
## Art. 137. {#art-137}

(uchylony)

***
## Art. 138. {#art-138}

(uchylony)

***
## Art. 139. {#art-139}

(uchylony) 
## DZIAŁ II. Treść i wykonywanie własności

***
## Art. 140. {#art-140}

W granicach 
określonych 
przez 
ustawy 
i zasady 
współżycia 
społecznego właściciel może, z wyłączeniem innych osób, korzystać z rzeczy zgodnie 
ze społeczno-gospodarczym przeznaczeniem swego prawa, w szczególności może 
pobierać pożytki i inne dochody z rzeczy. W tych samych granicach może 
rozporządzać rzeczą. 

©Kancelaria Sejmu 
 
 
 
s. 34/242 
 
   
 
2025-09-09

***
## Art. 141. {#art-141}

(uchylony)

***
## Art. 142. {#art-142}

§ 1. Właściciel nie może się sprzeciwić użyciu a nawet uszkodzeniu 
lub zniszczeniu rzeczy przez inną osobę, jeżeli to jest konieczne do odwrócenia 
niebezpieczeństwa grożącego bezpośrednio dobrom osobistym tej osoby lub osoby 
trzeciej. Może jednak żądać naprawienia wynikłej stąd szkody. 
§ 2. Przepis powyższy stosuje się także w razie niebezpieczeństwa grożącego 
dobrom majątkowym, chyba że grożąca szkoda jest oczywiście i niewspółmiernie 
mniejsza aniżeli uszczerbek, który mógłby ponieść właściciel wskutek użycia, 
uszkodzenia lub zniszczenia rzeczy.

***
## Art. 143. {#art-143}

W granicach określonych przez społeczno-gospodarcze przeznaczenie 
gruntu własność gruntu rozciąga się na przestrzeń nad i pod jego powierzchnią. 
Przepis ten nie uchybia przepisom regulującym prawa do wód.

***
## Art. 144. {#art-144}

Właściciel nieruchomości powinien przy wykonywaniu swego prawa 
powstrzymywać się od działań, które by zakłócały korzystanie z nieruchomości 
sąsiednich ponad przeciętną miarę, wynikającą ze społeczno-gospodarczego 
przeznaczenia nieruchomości i stosunków miejscowych.

***
## Art. 145. {#art-145}

§ 1. Jeżeli nieruchomość nie ma odpowiedniego dostępu do drogi 
publicznej lub do należących do tej nieruchomości budynków gospodarskich, 
właściciel może żądać od właścicieli gruntów sąsiednich ustanowienia za 
wynagrodzeniem potrzebnej służebności drogowej (droga konieczna). 
§ 2. Przeprowadzenie drogi koniecznej nastąpi z uwzględnieniem potrzeb 
nieruchomości niemającej dostępu do drogi publicznej oraz z najmniejszym 
obciążeniem gruntów, przez które droga ma prowadzić. Jeżeli potrzeba ustanowienia 
drogi jest następstwem sprzedaży gruntu lub innej czynności prawnej, a między 
interesowanymi nie dojdzie do porozumienia, sąd zarządzi, o ile to jest możliwe, 
przeprowadzenie drogi przez grunty, które były przedmiotem tej czynności prawnej. 
§ 3. Przeprowadzenie drogi koniecznej powinno uwzględniać interes społeczno-
-gospodarczy.

***
## Art. 146. {#art-146}

Przepisy artykułu poprzedzającego stosuje się odpowiednio do 
samoistnego posiadacza nieruchomości; jednakże posiadacz może żądać tylko 
ustanowienia służebności osobistej. 

©Kancelaria Sejmu 
 
 
 
s. 35/242 
 
   
 
2025-09-09

***
## Art. 147. {#art-147}

Właścicielowi nie wolno dokonywać robót ziemnych w taki sposób, 
żeby to groziło nieruchomościom sąsiednim utratą oparcia.

***
## Art. 148. {#art-148}

Owoce opadłe z drzewa lub krzewu na grunt sąsiedni stanowią jego 
pożytki. Przepisu tego nie stosuje się, gdy grunt sąsiedni jest przeznaczony na użytek 
publiczny.

***
## Art. 149. {#art-149}

Właściciel gruntu może wejść na grunt sąsiedni w celu usunięcia 
zwieszających się z jego drzew gałęzi lub owoców. Właściciel sąsiedniego gruntu 
może jednak żądać naprawienia wynikłej stąd szkody.

***
## Art. 150. {#art-150}

Właściciel gruntu może obciąć i zachować dla siebie korzenie 
przechodzące z sąsiedniego gruntu. To samo dotyczy gałęzi i owoców zwieszających 
się z sąsiedniego gruntu; jednakże w wypadku takim właściciel powinien uprzednio 
wyznaczyć sąsiadowi odpowiedni termin do ich usunięcia.

***
## Art. 151. {#art-151}

Jeżeli przy wznoszeniu budynku lub innego urządzenia przekroczono 
bez winy umyślnej granice sąsiedniego gruntu, właściciel tego gruntu nie może żądać 
przywrócenia stanu poprzedniego, chyba że bez nieuzasadnionej zwłoki sprzeciwił się 
przekroczeniu granicy albo że grozi mu niewspółmiernie wielka szkoda. Może on 
żądać albo stosownego wynagrodzenia w zamian za ustanowienie odpowiedniej 
służebności gruntowej, albo wykupienia zajętej części gruntu, jak również tej części, 
która na skutek budowy straciła dla niego znaczenie gospodarcze.

***
## Art. 152. {#art-152}

Właściciele gruntów sąsiadujących obowiązani są do współdziałania 
przy rozgraniczeniu gruntów oraz przy utrzymywaniu stałych znaków granicznych; 
koszty rozgraniczenia oraz koszty urządzenia i utrzymywania stałych znaków 
granicznych ponoszą po połowie.

***
## Art. 153. {#art-153}

Jeżeli granice gruntów stały się sporne, a stanu prawnego nie można 
stwierdzić, ustala się granice według ostatniego spokojnego stanu posiadania. Gdyby 
również takiego stanu nie można było stwierdzić, a postępowanie rozgraniczeniowe 
nie doprowadziło do ugody między interesowanymi, sąd ustali granice 
z uwzględnieniem wszelkich okoliczności; może przy tym przyznać jednemu 
z właścicieli odpowiednią dopłatę pieniężną. 

©Kancelaria Sejmu 
 
 
 
s. 36/242 
 
   
 
2025-09-09

***
## Art. 154. {#art-154}

§ 1. Domniemywa się, że mury, płoty, miedze, rowy i inne urządzenia 
podobne, znajdujące się na granicy gruntów sąsiadujących, służą do wspólnego użytku 
sąsiadów. To samo dotyczy drzew i krzewów na granicy. 
§ 2. Korzystający z wymienionych urządzeń obowiązani są ponosić wspólnie 
koszty ich utrzymania. 
## DZIAŁ III. Nabycie i utrata własności 
## Rozdział I. Przeniesienie własności

***
## Art. 155. {#art-155}

§ 1. 
Umowa 
sprzedaży, 
zamiany, 
darowizny, 
przekazania 
nieruchomości lub inna umowa zobowiązująca do przeniesienia własności rzeczy co 
do tożsamości oznaczonej przenosi własność na nabywcę, chyba że przepis szczególny 
stanowi inaczej albo że strony inaczej postanowiły. 
§ 2. Jeżeli przedmiotem umowy zobowiązującej do przeniesienia własności są 
rzeczy oznaczone tylko co do gatunku, do przeniesienia własności potrzebne jest 
przeniesienie posiadania rzeczy. To samo dotyczy wypadku, gdy przedmiotem umowy 
zobowiązującej do przeniesienia własności są rzeczy przyszłe.

***
## Art. 156. {#art-156}

Jeżeli zawarcie umowy przenoszącej własność następuje w wykonaniu 
zobowiązania wynikającego z uprzednio zawartej umowy zobowiązującej do 
przeniesienia własności, z zapisu zwykłego, z bezpodstawnego wzbogacenia lub 
z innego zdarzenia, ważność umowy przenoszącej własność zależy od istnienia tego 
zobowiązania.

***
## Art. 157. {#art-157}

§ 1. Własność nieruchomości nie może być przeniesiona pod 
warunkiem ani z zastrzeżeniem terminu. 
§ 2. Jeżeli umowa zobowiązująca do przeniesienia własności nieruchomości 
została zawarta pod warunkiem lub z zastrzeżeniem terminu, do przeniesienia 
własności potrzebne jest dodatkowe porozumienie stron obejmujące ich bez-
warunkową zgodę na niezwłoczne przejście własności.

***
## Art. 158. {#art-158}

Umowa zobowiązująca do przeniesienia własności nieruchomości 
powinna być zawarta w formie aktu notarialnego. To samo dotyczy umowy 
przenoszącej własność, która zostaje zawarta w celu wykonania istniejącego 

©Kancelaria Sejmu 
 
 
 
s. 37/242 
 
   
 
2025-09-09 
 
uprzednio zobowiązania do przeniesienia własności nieruchomości; zobowiązanie 
powinno być w akcie wymienione.

***
## Art. 159. {#art-159}

(uchylony)

***
## Art. 160. {#art-160}

(uchylony)

***
## Art. 161. {#art-161}

(uchylony)

***
## Art. 162. {#art-162}

(uchylony)

***
## Art. 163. {#art-163}

(uchylony)

***
## Art. 164. {#art-164}

(uchylony)

***
## Art. 165. {#art-165}

(uchylony)

***
## Art. 166. {#art-166}

§ 1. W razie sprzedaży przez współwłaściciela nieruchomości rolnej 
udziału we współwłasności lub części tego udziału pozostałym współwłaścicielom 
przysługuje prawo pierwokupu, jeżeli prowadzą gospodarstwo rolne na gruncie 
wspólnym. Nie dotyczy to jednak wypadku, gdy współwłaściciel prowadzący 
jednocześnie gospodarstwo rolne sprzedaje swój udział we współwłasności wraz 
z tym gospodarstwem albo gdy nabywcą jest inny współwłaściciel lub osoba, która 
dziedziczyłaby gospodarstwo po sprzedawcy. 
§ 2. (uchylony) 
§ 3. Do sprzedaży przez współwłaściciela nieruchomości rolnej w rozumieniu 
przepisów ustawy z dnia 11 kwietnia 2003 r. o kształtowaniu ustroju rolnego (Dz. U. 
z 2024 r. poz. 423 oraz z 2025 r. poz. 620) udziału we współwłasności lub części tego 
udziału stosuje się przepisy tej ustawy.

***
## Art. 167. {#art-167}

(uchylony)

***
## Art. 168. {#art-168}

(uchylony)

***
## Art. 169. {#art-169}

§ 1. Jeżeli osoba nieuprawniona do rozporządzania rzeczą ruchomą 
zbywa rzecz i wydaje ją nabywcy, nabywca uzyskuje własność z chwilą objęcia rzeczy 
w posiadanie, chyba że działa w złej wierze. 
§ 2. Jednakże gdy rzecz zgubiona, skradziona lub w inny sposób utracona przez 
właściciela zostaje zbyta przed upływem lat trzech od chwili jej zgubienia, skradzenia 
lub utraty, nabywca może uzyskać własność dopiero z upływem powyższego 
trzyletniego terminu. Ograniczenie to nie dotyczy pieniędzy i dokumentów na 

©Kancelaria Sejmu 
 
 
 
s. 38/242 
 
   
 
2025-09-09 
 
okaziciela ani rzeczy nabytych na urzędowej licytacji publicznej lub w toku 
postępowania egzekucyjnego. 
§ 3. Przepisów § 1 i 2 nie stosuje się do rzeczy wpisanej do krajowego rejestru 
utraconych dóbr kultury.

***
## Art. 170. {#art-170}

§ 1. W razie przeniesienia własności rzeczy ruchomej, która jest 
obciążona prawem osoby trzeciej, prawo to wygasa z chwilą wydania rzeczy nabywcy, 
chyba że ten działa w złej wierze. Przepis paragrafu drugiego artykułu 
poprzedzającego stosuje się odpowiednio. 
§ 2. Przepisu § 1 nie stosuje się do rzeczy wpisanej do krajowego rejestru 
utraconych dóbr kultury.

***
## Art. 171. {#art-171}

(uchylony) 
## Rozdział II. Zasiedzenie

***
## Art. 172. {#art-172}

§ 1. Posiadacz nieruchomości niebędący jej właścicielem nabywa 
własność, jeżeli posiada nieruchomość nieprzerwanie od lat dwudziestu jako 
posiadacz samoistny, chyba że uzyskał posiadanie w złej wierze (zasiedzenie). 
§ 2. Po upływie lat trzydziestu posiadacz nieruchomości nabywa jej własność, 
choćby uzyskał posiadanie w złej wierze. 
§ 3. (uchylony)

***
## Art. 173. {#art-173}

Jeżeli właściciel nieruchomości, 
przeciwko któremu biegnie 
zasiedzenie, jest małoletni, zasiedzenie nie może skończyć się wcześniej niż 
z upływem dwóch lat od uzyskania pełnoletności przez właściciela.

***
## Art. 174. {#art-174}

§ 1. Posiadacz rzeczy ruchomej niebędący jej właścicielem nabywa 
własność, jeżeli posiada rzecz nieprzerwanie od lat trzech jako posiadacz samoistny, 
chyba że posiada w złej wierze. 
§ 2. Przepisu § 1 nie stosuje się do rzeczy wpisanej do krajowego rejestru 
utraconych dóbr kultury.

***
## Art. 175. {#art-175}

Do biegu zasiedzenia stosuje się odpowiednio przepisy o biegu 
przedawnienia roszczeń. 

©Kancelaria Sejmu 
 
 
 
s. 39/242 
 
   
 
2025-09-09

***
## Art. 176. {#art-176}

§ 1. Jeżeli podczas biegu zasiedzenia nastąpiło przeniesienie 
posiadania, obecny posiadacz może doliczyć do czasu, przez który sam posiada, czas 
posiadania swego poprzednika. Jeżeli jednak poprzedni posiadacz uzyskał posiadanie 
nieruchomości w złej wierze, czas jego posiadania może być doliczony tylko wtedy, 
gdy łącznie z czasem posiadania obecnego posiadacza wynosi przynajmniej lat 
trzydzieści. 
§ 2. Przepisy powyższe stosuje się odpowiednio w wypadku, gdy obecny 
posiadacz jest spadkobiercą poprzedniego posiadacza.

***
## Art. 177. {#art-177}

(uchylony)

***
## Art. 178. {#art-178}

(uchylony) 
## Rozdział III. Inne wypadki nabycia i utraty własności

***
## Art. 179. {#art-179}

(utracił moc)2)

***
## Art. 180. {#art-180}

Właściciel może wyzbyć się własności rzeczy ruchomej przez to, że 
w tym zamiarze rzecz porzuci.

***
## Art. 181. {#art-181}

Własność ruchomej rzeczy niczyjej nabywa się przez jej objęcie 
w posiadanie samoistne.

***
## Art. 182. {#art-182}

§ 1. Rój pszczół staje się niczyim, jeżeli właściciel nie odszukał go 
przed upływem trzech dni od dnia wyrojenia. Właścicielowi wolno w pościgu za rojem 
wejść na cudzy grunt, powinien jednak naprawić wynikłą stąd szkodę. 
§ 2. Jeżeli rój osiadł w cudzym ulu niezajętym, właściciel może domagać się 
wydania roju za zwrotem kosztów. 
§ 3. Jeżeli rój osiadł w cudzym ulu zajętym, staje się on własnością tego, czyją 
własnością był rój, który się w ulu znajdował. Dotychczasowemu właścicielowi nie 
przysługuje w tym wypadku roszczenie z tytułu bezpodstawnego wzbogacenia.

***
## Art. 183. {#art-183}

(uchylony)

***
## Art. 184. {#art-184}

(uchylony)

***
## Art. 185. {#art-185}

(uchylony) 
- 2) Z dniem 15 lipca 2006 r. na podstawie wyroku Trybunału Konstytucyjnego z dnia 15 marca 2005 r. 
sygn. akt K 9/04 (Dz. U. poz. 462). 

©Kancelaria Sejmu 
 
 
 
s. 40/242 
 
   
 
2025-09-09

***
## Art. 186. {#art-186}

(uchylony)

***
## Art. 187. {#art-187}

§ 1. Rzecz znaleziona, która nie zostanie przez osobę uprawnioną 
odebrana w ciągu roku od dnia doręczenia jej wezwania do odbioru, a w przypadku 
niemożności wezwania – w ciągu dwóch lat od dnia jej znalezienia, staje się włas-
nością znalazcy, jeżeli uczynił on zadość swoim obowiązkom. Jeżeli jednak rzecz 
została oddana staroście, znalazca staje się jej właścicielem, jeżeli rzecz odebrał 
w wyznaczonym przez starostę terminie. 
§ 2. Rzecz znaleziona będąca zabytkiem lub materiałem archiwalnym po upływie 
terminu do jej odebrania przez osobę uprawnioną staje się własnością Skarbu Państwa. 
Inne rzeczy znalezione stają się własnością powiatu po upływie terminu do ich odbioru 
przez znalazcę. 
§ 3. Z chwilą nabycia własności rzeczy przez znalazcę, powiat albo Skarb 
Państwa wygasają obciążające ją ograniczone prawa rzeczowe.

***
## Art. 188. {#art-188}

(uchylony)

***
## Art. 189. {#art-189}

Jeżeli rzecz znaleziono w takich okolicznościach, że poszukiwanie 
właściciela byłoby oczywiście bezcelowe, staje się ona przedmiotem współwłasności 
w częściach ułamkowych znalazcy i właściciela nieruchomości, na której rzecz 
została znaleziona, jeżeli jednak rzecz ta jest zabytkiem lub materiałem archiwalnym, 
staje się ona własnością Skarbu Państwa, a znalazca jest obowiązany wydać ją 
niezwłocznie właściwemu staroście.

***
## Art. 190. {#art-190}

Uprawniony do pobierania pożytków naturalnych rzeczy nabywa ich 
własność przez odłączenie ich od rzeczy.

***
## Art. 191. {#art-191}

Własność nieruchomości rozciąga się na rzecz ruchomą, która została 
połączona z nieruchomością w taki sposób, że stała się jej częścią składową.

***
## Art. 192. {#art-192}

§ 1. Ten, kto wytworzył nową rzecz ruchomą z cudzych materiałów, 
staje się jej właścicielem, jeżeli wartość nakładu pracy jest większa od wartości 
materiałów. 
§ 2. Jeżeli przetworzenie rzeczy było dokonane w złej wierze albo jeżeli wartość 
materiałów jest większa od wartości nakładu pracy, rzecz wytworzona staje się 
własnością właściciela materiałów. 

©Kancelaria Sejmu 
 
 
 
s. 41/242 
 
   
 
2025-09-09

***
## Art. 193. {#art-193}

§ 1. Jeżeli rzeczy ruchome zostały połączone lub pomieszane w taki 
sposób, że przywrócenie stanu poprzedniego byłoby związane z nadmiernymi 
trudnościami lub kosztami, dotychczasowi właściciele stają się współwłaścicielami 
całości. Udziały we współwłasności oznacza się według stosunku wartości rzeczy 
połączonych lub pomieszanych. 
§ 2. Jednakże gdy jedna z rzeczy połączonych ma wartość znacznie większą 
aniżeli pozostałe, rzeczy mniejszej wartości stają się jej częściami składowymi.

***
## Art. 194. {#art-194}

Przepisy o przetworzeniu, połączeniu i pomieszaniu nie uchybiają 
przepisom o obowiązku naprawienia szkody ani przepisom o bezpodstawnym 
wzbogaceniu. 
## DZIAŁ IV. Współwłasność

***
## Art. 195. {#art-195}

Własność tej samej rzeczy może przysługiwać niepodzielnie kilku 
osobom (współwłasność).

***
## Art. 196. {#art-196}

§ 1. 
Współwłasność 
jest 
albo 
współwłasnością 
w częściach 
ułamkowych, albo współwłasnością łączną. 
§ 2. Współwłasność łączną regulują przepisy dotyczące stosunków, z których 
ona wynika. Do współwłasności w częściach ułamkowych stosuje się przepisy 
niniejszego działu.

***
## Art. 197. {#art-197}

Domniemywa się, że udziały współwłaścicieli są równe.

***
## Art. 198. {#art-198}

Każdy ze współwłaścicieli może rozporządzać swoim udziałem bez 
zgody pozostałych współwłaścicieli.

***
## Art. 199. {#art-199}

Do rozporządzania rzeczą wspólną oraz do innych czynności, które 
przekraczają zakres zwykłego zarządu, potrzebna jest zgoda 
wszystkich 
współwłaścicieli. W braku takiej zgody współwłaściciele, których udziały wynoszą co 
najmniej połowę, mogą żądać rozstrzygnięcia przez sąd, który orzeknie mając na 
względzie cel zamierzonej czynności oraz interesy wszystkich współwłaścicieli.

***
## Art. 200. {#art-200}

Każdy ze współwłaścicieli jest obowiązany do współdziałania 
w zarządzie rzeczą wspólną. 

©Kancelaria Sejmu 
 
 
 
s. 42/242 
 
   
 
2025-09-09

***
## Art. 201. {#art-201}

Do czynności zwykłego zarządu rzeczą wspólną potrzebna jest zgoda 
większości współwłaścicieli. W braku takiej zgody każdy ze współwłaścicieli może 
żądać upoważnienia sądowego do dokonania czynności.

***
## Art. 202. {#art-202}

Jeżeli większość współwłaścicieli postanawia dokonać czynności 
rażąco sprzecznej z zasadami prawidłowego zarządu rzeczą wspólną, każdy 
z pozostałych współwłaścicieli może żądać rozstrzygnięcia przez sąd.

***
## Art. 203. {#art-203}

Każdy ze współwłaścicieli może wystąpić do sądu o wyznaczenie 
zarządcy, jeżeli nie można uzyskać zgody większości współwłaścicieli w istotnych 
sprawach dotyczących zwykłego zarządu albo jeżeli większość współwłaścicieli 
narusza zasady prawidłowego zarządu lub krzywdzi mniejszość.

***
## Art. 204. {#art-204}

Większość współwłaścicieli oblicza się według wielkości udziałów.

***
## Art. 205. {#art-205}

Współwłaściciel sprawujący zarząd rzeczą wspólną może żądać od 
pozostałych współwłaścicieli wynagrodzenia odpowiadającego uzasadnionemu 
nakładowi jego pracy.

***
## Art. 206. {#art-206}

Każdy ze współwłaścicieli jest uprawniony do współposiadania rzeczy 
wspólnej oraz do korzystania z niej w takim zakresie, jaki daje się pogodzić ze 
współposiadaniem i korzystaniem z rzeczy przez pozostałych współwłaścicieli.

***
## Art. 207. {#art-207}

Pożytki 
i inne 
przychody 
z rzeczy 
wspólnej 
przypadają 
współwłaścicielom w stosunku do wielkości udziałów; w takim samym stosunku 
współwłaściciele ponoszą wydatki i ciężary związane z rzeczą wspólną.

***
## Art. 208. {#art-208}

Każdy ze współwłaścicieli niesprawujących zarządu rzeczą wspólną 
może żądać w odpowiednich terminach rachunku z zarządu.

***
## Art. 209. {#art-209}

Każdy ze współwłaścicieli może wykonywać wszelkie czynności 
i dochodzić wszelkich roszczeń, które zmierzają do zachowania wspólnego prawa.

***
## Art. 210. {#art-210}

§ 1. Każdy ze współwłaścicieli może żądać zniesienia współwłasności. 
Uprawnienie to może być wyłączone przez czynność prawną na czas nie dłuższy niż 
lat pięć. Jednakże w ostatnim roku przed upływem zastrzeżonego terminu 
dopuszczalne jest jego przedłużenie na dalsze lat pięć; przedłużenie można ponowić. 

©Kancelaria Sejmu 
 
 
 
s. 43/242 
 
   
 
2025-09-09 
 
§ 2. Zniesienie współwłasności nieruchomości rolnej oraz gospodarstwa rolnego 
w rozumieniu przepisów ustawy, o której mowa w art. 166 § 3, następuje 
z uwzględnieniem przepisów tej ustawy.

***
## Art. 211. {#art-211}

Każdy 
ze 
współwłaścicieli 
może 
żądać, 
ażeby 
zniesienie 
współwłasności nastąpiło przez podział rzeczy wspólnej, chyba że podział byłby 
sprzeczny z przepisami ustawy lub ze społeczno-gospodarczym przeznaczeniem 
rzeczy albo że pociągałby za sobą istotną zmianę rzeczy lub znaczne zmniejszenie jej 
wartości.

***
## Art. 212. {#art-212}

§ 1. Jeżeli zniesienie współwłasności następuje na mocy orzeczenia 
sądu, wartość poszczególnych udziałów może być wyrównana przez dopłaty 
pieniężne. Przy podziale gruntu sąd może obciążyć poszczególne części potrzebnymi 
służebnościami gruntowymi. 
§ 2. Rzecz, która nie daje się podzielić, może być przyznana stosownie do 
okoliczności jednemu ze współwłaścicieli z obowiązkiem spłaty pozostałych albo 
sprzedana stosownie do przepisów kodeksu postępowania cywilnego. 
§ 3. Jeżeli ustalone zostały dopłaty lub spłaty, sąd oznaczy termin i sposób ich 
uiszczenia, wysokość i termin uiszczenia odsetek, a w razie potrzeby także sposób ich 
zabezpieczenia. W razie rozłożenia dopłat i spłat na raty terminy ich uiszczenia nie 
mogą łącznie przekraczać lat dziesięciu. W wypadkach zasługujących na szczególne 
uwzględnienie sąd na wniosek dłużnika może odroczyć termin zapłaty rat już 
wymagalnych.

***
## Art. 213. {#art-213}

§ 1. Jeżeli zniesienie współwłasności gospodarstwa rolnego przez 
podział między współwłaścicieli byłoby sprzeczne z zasadami prawidłowej 
gospodarki rolnej, sąd przyzna to gospodarstwo temu współwłaścicielowi, na którego 
wyrażą zgodę wszyscy współwłaściciele. 
§ 2. Przyznanie przez sąd gospodarstwa rolnego w rozumieniu przepisów 
ustawy, o której mowa w art. 166 § 3, następuje z uwzględnieniem przepisów tej 
ustawy.

***
## Art. 214. {#art-214}

§ 1. W razie braku zgody wszystkich współwłaścicieli, sąd przyzna 
gospodarstwo rolne temu z nich, który je prowadzi lub stale w nim pracuje, chyba że 
interes społeczno-gospodarczy przemawia za wyborem innego współwłaściciela. 

©Kancelaria Sejmu 
 
 
 
s. 44/242 
 
   
 
2025-09-09 
 
§ 2. Jeżeli warunki przewidziane w paragrafie poprzedzającym spełnia kilku 
współwłaścicieli albo jeżeli nie spełnia ich żaden ze współwłaścicieli, sąd przyzna 
gospodarstwo rolne temu z nich, który daje najlepszą gwarancję jego należytego 
prowadzenia. 
§ 3. Na 
wniosek 
wszystkich 
współwłaścicieli 
sąd 
zarządzi 
sprzedaż 
gospodarstwa rolnego stosownie do przepisów Kodeksu postępowania cywilnego, 
a w przypadku gospodarstwa rolnego w rozumieniu przepisów ustawy, o której mowa 
w art. 166 § 3, z uwzględnieniem przepisów tej ustawy. 
§ 4. Sprzedaż gospodarstwa rolnego sąd zarządzi również w wypadku 
niewyrażenia zgody przez żadnego ze współwłaścicieli na przyznanie mu 
gospodarstwa.

***
## Art. 215. {#art-215}

Przepisy dwóch artykułów poprzedzających stosuje się odpowiednio 
w wypadku, gdy gospodarstwo rolne może być podzielone, lecz liczba wydzielonych 
części jest mniejsza od liczby współwłaścicieli.

***
## Art. 216. {#art-216}

§ 1. 
Wysokość 
przysługujących 
współwłaścicielom 
spłat 
z gospodarstwa rolnego ustala się stosownie do ich zgodnego porozumienia. 
§ 2. W razie 
braku 
takiego 
porozumienia 
spłaty 
przysługujące 
współwłaścicielom mogą być obniżone. Przy określaniu stopnia ich obniżenia bierze 
się pod uwagę: 
- 1) typ, wielkość i stan gospodarstwa rolnego będącego przedmiotem zniesienia 
współwłasności; 
- 2) sytuację osobistą i majątkową współwłaściciela zobowiązanego do spłat 
i współwłaściciela uprawnionego do ich otrzymania. 
§ 3. Obniżenie spłat, stosownie do przepisu paragrafu poprzedzającego, nie 
wyklucza możliwości rozłożenia ich na raty lub odroczenia terminu ich zapłaty, 
stosownie do przepisu art. 212 § 3. 
§ 4. Przepisów § 2 i 3 nie stosuje się do spłat na rzecz małżonka w razie 
zniesienia współwłasności gospodarstwa rolnego, które stosownie do przepisów 
Kodeksu rodzinnego i opiekuńczego należy do wspólnego majątku małżonków.

***
## Art. 217. {#art-217}

Współwłaściciel, który w wyniku zniesienia współwłasności otrzymał 
gospodarstwo rolne, wchodzące zaś w skład tego gospodarstwa nieruchomości rolne 
zbył odpłatnie przed upływem pięciu lat od chwili zniesienia współwłasności, jest 

©Kancelaria Sejmu 
 
 
 
s. 45/242 
 
   
 
2025-09-09 
 
obowiązany pozostałym współwłaścicielom, którym przypadły spłaty niższe od 
należnych, wydać – proporcjonalnie do wielkości ich udziałów – korzyści uzyskane 
z obniżenia spłat, chyba że celem zbycia jest zapewnienie racjonalnego prowadzenia 
tego gospodarstwa.

***
## Art. 218. {#art-218}

§ 1. Współwłaściciele, którzy nie otrzymali gospodarstwa rolnego lub 
jego części, lecz do chwili zniesienia współwłasności w tym gospodarstwie mieszkali, 
zachowują uprawnienia do dalszego zamieszkiwania, jednakże nie dłużej niż przez 
pięć lat, a gdy w chwili znoszenia współwłasności są małoletni – nie dłużej niż pięć 
lat od osiągnięcia pełnoletności. Ograniczenie terminem powyższym nie dotyczy 
współwłaścicieli trwale niezdolnych do pracy. 
§ 2. Do uprawnień wynikających z przepisów paragrafu poprzedzającego stosuje 
się odpowiednio przepisy o służebności mieszkania.

***
## Art. 219. {#art-219}

(uchylony)

***
## Art. 220. {#art-220}

Roszczenie o zniesienie współwłasności nie ulega przedawnieniu.

***
## Art. 221. {#art-221}

Czynności prawne określające zarząd i sposób korzystania z rzeczy 
wspólnej albo wyłączające uprawnienie do zniesienia współwłasności odnoszą skutek 
także względem nabywcy udziału, jeżeli nabywca o nich wiedział lub z łatwością 
mógł się dowiedzieć. To samo dotyczy wypadku, gdy sposób korzystania z rzeczy 
został ustalony w orzeczeniu sądowym. 
## DZIAŁ V. Ochrona własności

***
## Art. 222. {#art-222}

§ 1. Właściciel może żądać od osoby, która włada faktycznie jego 
rzeczą, ażeby rzecz została mu wydana, chyba że osobie tej przysługuje skuteczne 
względem właściciela uprawnienie do władania rzeczą. 
§ 2. Przeciwko osobie, która narusza własność w inny sposób aniżeli przez 
pozbawienie właściciela faktycznego władztwa nad rzeczą, przysługuje właścicielowi 
roszczenie o przywrócenie stanu zgodnego z prawem i o zaniechanie naruszeń.

***
## Art. 223. {#art-223}

§ 1. Roszczenia właściciela przewidziane w artykule poprzedzającym 
nie ulegają przedawnieniu, jeżeli dotyczą nieruchomości. 
§ 2. (uchylony) 
§ 3. (uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 46/242 
 
   
 
2025-09-09 
 
§ 4. Roszczenie właściciela, o którym mowa w art. 222 § 1, nie ulega 
przedawnieniu, jeżeli dotyczy rzeczy wpisanej do krajowego rejestru utraconych dóbr 
kultury.

***
## Art. 224. {#art-224}

§ 1. Samoistny posiadacz w dobrej wierze nie jest obowiązany do 
wynagrodzenia za korzystanie z rzeczy i nie jest odpowiedzialny ani za jej zużycie, 
ani za jej pogorszenie lub utratę. Nabywa własność pożytków naturalnych, które 
zostały od rzeczy odłączone w czasie jego posiadania, oraz zachowuje pobrane pożytki 
cywilne, jeżeli stały się w tym czasie wymagalne. 
§ 2. Jednakże od chwili, w której samoistny posiadacz w dobrej wierze 
dowiedział się o wytoczeniu przeciwko niemu powództwa o wydanie rzeczy, jest on 
obowiązany do wynagrodzenia za korzystanie z rzeczy i jest odpowiedzialny za jej 
zużycie, pogorszenie lub utratę, chyba że pogorszenie lub utrata nastąpiła bez jego 
winy. Obowiązany jest zwrócić pobrane od powyższej chwili pożytki, których nie 
zużył, jak również uiścić wartość tych, które zużył.

***
## Art. 225. {#art-225}

Obowiązki samoistnego posiadacza w złej wierze względem 
właściciela są takie same jak obowiązki samoistnego posiadacza w dobrej wierze od 
chwili, w której ten dowiedział się o wytoczeniu przeciwko niemu powództwa 
o wydanie rzeczy. Jednakże samoistny posiadacz w złej wierze obowiązany jest nadto 
zwrócić wartość pożytków, których z powodu złej gospodarki nie uzyskał, oraz jest 
odpowiedzialny za pogorszenie i utratę rzeczy, chyba że rzecz uległaby pogorszeniu 
lub utracie także wtedy, gdyby znajdowała się w posiadaniu uprawnionego.

***
## Art. 226. {#art-226}

§ 1. Samoistny posiadacz w dobrej wierze może żądać zwrotu 
nakładów koniecznych o tyle, o ile nie mają pokrycia w korzyściach, które uzyskał 
z rzeczy. Zwrotu innych nakładów może żądać o tyle, o ile zwiększają wartość rzeczy 
w chwili jej wydania właścicielowi. Jednakże gdy nakłady zostały dokonane po 
chwili, w której samoistny posiadacz w dobrej wierze dowiedział się o wytoczeniu 
przeciwko niemu powództwa o wydanie rzeczy, może on żądać zwrotu jedynie 
nakładów koniecznych. 
§ 2. Samoistny posiadacz w złej wierze może żądać jedynie zwrotu nakładów 
koniecznych, i to tylko o tyle, o ile właściciel wzbogaciłby się bezpodstawnie jego 
kosztem. 

©Kancelaria Sejmu 
 
 
 
s. 47/242 
 
   
 
2025-09-09

***
## Art. 227. {#art-227}

§ 1. Samoistny posiadacz może, przywracając stan poprzedni, zabrać 
przedmioty, które połączył z rzeczą, chociażby stały się jej częściami składowymi. 
§ 2. Jednakże gdy połączenia dokonał samoistny posiadacz w złej wierze albo 
samoistny posiadacz w dobrej wierze po chwili, w której dowiedział się o wytoczeniu 
przeciwko niemu powództwa o wydanie rzeczy, właściciel może przyłączone 
przedmioty zatrzymać, zwracając samoistnemu posiadaczowi ich wartość i koszt 
robocizny albo sumę odpowiadającą zwiększeniu wartości rzeczy.

***
## Art. 228. {#art-228}

Przepisy określające prawa i obowiązki samoistnego posiadacza 
w dobrej wierze od chwili, w której dowiedział się on o wytoczeniu przeciwko niemu 
powództwa o wydanie rzeczy, stosuje się także w wypadku, gdy samoistny posiadacz 
rzeczy będącej przedmiotem własności państwowej został wezwany przez właściwy 
organ państwowy do wydania rzeczy.

***
## Art. 229. {#art-229}

§ 1. Roszczenia właściciela przeciwko samoistnemu posiadaczowi 
o wynagrodzenie za korzystanie z rzeczy, o zwrot pożytków lub o zapłatę ich wartości, 
jak również roszczenia o naprawienie szkody z powodu pogorszenia rzeczy 
przedawniają się z upływem roku od dnia zwrotu rzeczy. To samo dotyczy roszczeń 
samoistnego posiadacza przeciwko właścicielowi o zwrot nakładów na rzecz. 
§ 2. (uchylony)

***
## Art. 230. {#art-230}

Przepisy dotyczące roszczeń właściciela przeciwko samoistnemu 
posiadaczowi o wynagrodzenie za korzystanie z rzeczy, o zwrot pożytków lub 
o zapłatę ich wartości oraz o naprawienie szkody z powodu pogorszenia lub utraty 
rzeczy, jak również przepisy dotyczące roszczeń samoistnego posiadacza o zwrot 
nakładów na rzecz, stosuje się odpowiednio do stosunku między właścicielem rzeczy 
a posiadaczem zależnym, o ile z przepisów regulujących ten stosunek nie wynika nic 
innego.

***
## Art. 231. {#art-231}

§ 1. Samoistny posiadacz gruntu w dobrej wierze, który wzniósł na 
powierzchni lub pod powierzchnią gruntu budynek lub inne urządzenie o wartości 
przenoszącej znacznie wartość zajętej na ten cel działki, może żądać, aby właściciel 
przeniósł na niego własność zajętej działki za odpowiednim wynagrodzeniem. 
§ 2. Właściciel gruntu, na którym wzniesiono budynek lub inne urządzenie 
o wartości przenoszącej znacznie wartość zajętej na ten cel działki, może żądać, aby 

©Kancelaria Sejmu 
 
 
 
s. 48/242 
 
   
 
2025-09-09 
 
ten, kto wzniósł budynek lub inne urządzenie, nabył od niego własność działki za 
odpowiednim wynagrodzeniem. 
§ 3. (uchylony) 
TYTUŁ II 
Użytkowanie wieczyste

***
## Art. 232. {#art-232}

§ 1. Grunty stanowiące własność Skarbu Państwa a położone 
w granicach administracyjnych miast oraz grunty Skarbu Państwa położone poza tymi 
granicami, lecz włączone do planu zagospodarowania przestrzennego miasta 
i przekazane do realizacji zadań jego gospodarki, a także grunty stanowiące własność 
jednostek samorządu terytorialnego lub ich związków mogą być oddawane 
w użytkowanie wieczyste osobom fizycznym, i osobom prawnym. 
§ 2. W wypadkach przewidzianych w przepisach szczególnych przedmiotem 
użytkowania wieczystego mogą być także inne grunty Skarbu Państwa, jednostek 
samorządu terytorialnego lub ich związków.

***
## Art. 233. {#art-233}

W granicach, określonych przez ustawy i zasady współżycia 
społecznego oraz przez umowę o oddanie gruntu Skarbu Państwa lub gruntu 
należącego do jednostek samorządu terytorialnego bądź ich związków w użytkowanie 
wieczyste, użytkownik może korzystać z gruntu z wyłączeniem innych osób. W tych 
samych granicach użytkownik wieczysty może swoim prawem rozporządzać.

***
## Art. 234. {#art-234}

Do oddania gruntu Skarbu Państwa lub gruntu należącego do jednostek 
samorządu terytorialnego bądź ich związków w użytkowanie wieczyste stosuje się 
odpowiednio przepisy o przeniesieniu własności nieruchomości.

***
## Art. 235. {#art-235}

§ 1. Budynki i inne urządzenia wzniesione na gruncie Skarbu Państwa 
lub gruncie należącym do jednostek samorządu terytorialnego bądź ich związków 
przez wieczystego użytkownika stanowią jego własność. To samo dotyczy budynków 
i innych urządzeń, które wieczysty użytkownik nabył zgodnie z właściwymi 
przepisami przy zawarciu umowy o oddanie gruntu w użytkowanie wieczyste. 
§ 2. Przysługująca wieczystemu użytkownikowi własność budynków i urządzeń 
na użytkowanym gruncie jest prawem związanym z użytkowaniem wieczystym.

***
## Art. 236. {#art-236}

§ 1. Oddanie gruntu Skarbu Państwa lub gruntu należącego do 
jednostek samorządu terytorialnego bądź ich związków w użytkowanie wieczyste 

©Kancelaria Sejmu 
 
 
 
s. 49/242 
 
   
 
2025-09-09 
 
następuje na okres dziewięćdziesięciu dziewięciu lat. W wypadkach wyjątkowych, 
gdy cel gospodarczy użytkowania wieczystego nie wymaga oddania gruntu na 
dziewięćdziesiąt dziewięć lat, dopuszczalne jest oddanie gruntu na okres krótszy, co 
najmniej jednak na lat czterdzieści. 
§ 2. W ciągu ostatnich pięciu lat przed upływem zastrzeżonego w umowie 
terminu wieczysty użytkownik może żądać jego przedłużenia na dalszy okres od 
czterdziestu do dziewięćdziesięciu dziewięciu lat; jednakże wieczysty użytkownik 
może wcześniej wystąpić z takim żądaniem, jeżeli okres amortyzacji zamierzonych na 
użytkowanym gruncie nakładów jest znacznie dłuższy aniżeli czas, który pozostaje do 
upływu zastrzeżonego w umowie terminu. Odmowa przedłużenia jest dopuszczalna 
tylko ze względu na ważny interes społeczny. 
§ 3. Umowa o przedłużenie wieczystego użytkowania powinna być zawarta 
w formie aktu notarialnego.

***
## Art. 237. {#art-237}

Do przeniesienia użytkowania wieczystego stosuje się odpowiednio 
przepisy o przeniesieniu własności nieruchomości.

***
## Art. 238. {#art-238}

Wieczysty użytkownik uiszcza przez czas trwania swego prawa opłatę 
roczną.

***
## Art. 239. {#art-239}

§ 1. Sposób korzystania z gruntu Skarbu Państwa lub gruntu 
należącego do jednostek samorządu terytorialnego bądź ich związków przez 
wieczystego użytkownika powinien być określony w umowie. 
§ 2. Jeżeli oddanie gruntu w użytkowanie wieczyste następuje w celu 
wzniesienia na gruncie budynków lub innych urządzeń, umowa powinna określać: 
- 1) termin rozpoczęcia i zakończenia robót; 
- 2) rodzaj budynków lub urządzeń oraz obowiązek ich utrzymywania w należytym 
stanie; 
- 3) warunki i termin odbudowy w razie zniszczenia albo rozbiórki budynków lub 
urządzeń w czasie trwania użytkowania wieczystego; 
- 4) wynagrodzenie należne wieczystemu użytkownikowi za budynki lub urządzenia 
istniejące na gruncie w dniu wygaśnięcia użytkowania wieczystego.

***
## Art. 240. {#art-240}

Umowa o oddanie gruntu Skarbu Państwa lub gruntu należącego do 
jednostek samorządu terytorialnego bądź ich związków w użytkowanie wieczyste 
może ulec rozwiązaniu przed upływem określonego w niej terminu, jeżeli wieczysty 

©Kancelaria Sejmu 
 
 
 
s. 50/242 
 
   
 
2025-09-09 
 
użytkownik korzysta z gruntu w sposób oczywiście sprzeczny z jego przeznaczeniem 
określonym w umowie, w szczególności jeżeli wbrew umowie użytkownik nie 
wzniósł określonych w niej budynków lub urządzeń.

***
## Art. 241. {#art-241}

Wraz 
z wygaśnięciem 
użytkowania 
wieczystego 
wygasają 
ustanowione na nim obciążenia.

***
## Art. 242. {#art-242}

(uchylony)

***
## Art. 243. {#art-243}

Roszczenie przeciwko wieczystemu użytkownikowi o naprawienie 
szkód wynikłych z niewłaściwego korzystania z gruntu Skarbu Państwa lub gruntu 
należącego do jednostek samorządu terytorialnego bądź ich związków, jak również 
roszczenie wieczystego użytkownika o wynagrodzenie za budynki i urządzenia 
istniejące w dniu zwrotu użytkowanego gruntu przedawniają się z upływem lat trzech 
od tej daty. 
TYTUŁ III 
Prawa rzeczowe ograniczone 
## DZIAŁ I. Przepisy ogólne

***
## Art. 244. {#art-244}

§ 1. Ograniczonymi 
prawami 
rzeczowymi 
są: 
użytkowanie, 
służebność, zastaw, spółdzielcze własnościowe prawo do lokalu oraz hipoteka. 
§ 2. Spółdzielcze własnościowe prawo do lokalu oraz hipotekę regulują odrębne 
przepisy.

***
## Art. 245. {#art-245}

§ 1. Z zastrzeżeniem wyjątków w ustawie przewidzianych, do 
ustanowienia ograniczonego prawa rzeczowego stosuje się odpowiednio przepisy 
o przeniesieniu własności. 
§ 2. Jednakże 
do 
ustanowienia 
ograniczonego 
prawa 
rzeczowego 
na 
nieruchomości nie stosuje się przepisów o niedopuszczalności warunku lub terminu. 
Forma aktu notarialnego jest potrzebna tylko dla oświadczenia właściciela, który 
prawo ustanawia.

***
## Art. 2451. {#art-2451}

Do przeniesienia ograniczonego prawa rzeczowego na nieruchomości 
potrzebna jest umowa między uprawnionym a nabywcą oraz – jeżeli prawo jest 

©Kancelaria Sejmu 
 
 
 
s. 51/242 
 
   
 
2025-09-09 
 
ujawnione w księdze wieczystej – wpis do tej księgi, chyba że przepis szczególny 
stanowi inaczej.

***
## Art. 246. {#art-246}

§ 1. Jeżeli uprawniony zrzeka się ograniczonego prawa rzeczowego, 
prawo to wygasa. Oświadczenie o zrzeczeniu się prawa powinno być złożone 
właścicielowi rzeczy obciążonej. 
§ 2. Jednakże gdy ustawa nie stanowi inaczej, a prawo było ujawnione w księdze 
wieczystej, do jego wygaśnięcia potrzebne jest wykreślenie prawa z księgi wieczystej.

***
## Art. 247. {#art-247}

Ograniczone prawo rzeczowe wygasa, jeżeli przejdzie na właściciela 
rzeczy obciążonej albo jeżeli ten, komu prawo takie przysługuje, nabędzie własność 
rzeczy obciążonej.

***
## Art. 248. {#art-248}

§ 1. Do zmiany treści ograniczonego prawa rzeczowego potrzebna jest 
umowa między uprawnionym a właścicielem rzeczy obciążonej, a jeżeli prawo było 
ujawnione w księdze wieczystej – wpis do tej księgi. 
§ 2. Jeżeli zmiana treści prawa dotyka praw osoby trzeciej, do zmiany potrzebna 
jest zgoda tej osoby. Oświadczenie osoby trzeciej powinno być złożone jednej ze stron.

***
## Art. 249. {#art-249}

§ 1. Jeżeli kilka ograniczonych praw rzeczowych obciąża tę samą 
rzecz, prawo powstałe później nie może być wykonywane z uszczerbkiem dla prawa 
powstałego wcześniej (pierwszeństwo). 
§ 2. Przepis powyższy nie uchybia przepisom, które określają pierwszeństwo 
w sposób odmienny.

***
## Art. 250. {#art-250}

§ 1. Pierwszeństwo ograniczonych praw rzeczowych może być 
zmienione. Zmiana nie narusza praw mających pierwszeństwo niższe aniżeli prawo 
ustępujące pierwszeństwa, a wyższe aniżeli prawo, które uzyskuje pierwszeństwo 
ustępującego prawa. 
§ 2. Do zmiany pierwszeństwa praw rzeczowych ograniczonych potrzebna jest 
umowa między tym, czyje prawo ma ustąpić pierwszeństwa, a tym, czyje prawo ma 
uzyskać pierwszeństwo ustępującego prawa. Jeżeli chociaż jedno z tych praw jest 
ujawnione w księdze wieczystej, potrzebny jest także wpis do księgi wieczystej. 
§ 3. Zmiana pierwszeństwa staje się bezskuteczna z chwilą wygaśnięcia prawa, 
które ustąpiło pierwszeństwa. 

©Kancelaria Sejmu 
 
 
 
s. 52/242 
 
   
 
2025-09-09

***
## Art. 251. {#art-251}

Do ochrony praw rzeczowych ograniczonych stosuje się odpowiednio 
przepisy o ochronie własności. 
## DZIAŁ II. Użytkowanie 
## Rozdział I. Przepisy ogólne

***
## Art. 252. {#art-252}

Rzecz można obciążyć prawem do jej używania i do pobierania jej 
pożytków (użytkowanie).

***
## Art. 253. {#art-253}

§ 1. Zakres użytkowania można ograniczyć przez wyłączenie 
oznaczonych pożytków rzeczy. 
§ 2. Wykonywanie użytkowania nieruchomości można ograniczyć do jej 
oznaczonej części.

***
## Art. 254. {#art-254}

Użytkowanie jest niezbywalne.

***
## Art. 255. {#art-255}

Użytkowanie wygasa wskutek niewykonywania przez lat dziesięć.

***
## Art. 256. {#art-256}

Użytkownik 
powinien 
wykonywać 
swoje 
prawo 
zgodnie 
z wymaganiami prawidłowej gospodarki.

***
## Art. 257. {#art-257}

§ 1. Jeżeli użytkowanie obejmuje określony zespół środków produkcji, 
użytkownik może w granicach prawidłowej gospodarki zastępować poszczególne 
składniki innymi. Włączone w ten sposób składniki stają się własnością właściciela 
użytkowanego zespołu środków produkcji. 
§ 2. Jeżeli użytkowany zespół środków produkcji ma być zwrócony według 
oszacowania, użytkownik nabywa własność jego poszczególnych składników 
z chwilą, gdy zostały mu wydane; po ustaniu użytkowania obowiązany jest zwrócić 
zespół tego samego rodzaju i tej samej wartości, chyba że inaczej zastrzeżono.

***
## Art. 258. {#art-258}

W stosunkach wzajemnych między użytkownikiem a właścicielem 
użytkownik ponosi ciężary, które zgodnie z wymaganiami prawidłowej gospodarki 
powinny być pokrywane z pożytków rzeczy. 

©Kancelaria Sejmu 
 
 
 
s. 53/242 
 
   
 
2025-09-09

***
## Art. 259. {#art-259}

Właściciel nie ma obowiązku czynić nakładów na rzecz obciążoną 
użytkowaniem. Jeżeli takie nakłady poczynił, może od użytkownika żądać ich zwrotu 
według przepisów o prowadzeniu cudzych spraw bez zlecenia.

***
## Art. 260. {#art-260}

§ 1. Użytkownik obowiązany jest dokonywać napraw i innych 
nakładów związanych ze zwykłym korzystaniem z rzeczy. O potrzebie innych napraw 
i nakładów powinien niezwłocznie zawiadomić właściciela i zezwolić mu na 
dokonanie potrzebnych robót. 
§ 2. Jeżeli użytkownik poczynił nakłady, do których nie był obowiązany, stosuje 
się odpowiednio przepisy o prowadzeniu cudzych spraw bez zlecenia.

***
## Art. 261. {#art-261}

Jeżeli osoba trzecia dochodzi przeciwko użytkownikowi roszczeń 
dotyczących własności rzeczy, użytkownik powinien niezwłocznie zawiadomić o tym 
właściciela.

***
## Art. 262. {#art-262}

Po wygaśnięciu użytkowania użytkownik obowiązany jest zwrócić 
rzecz właścicielowi w takim stanie, w jakim powinna się znajdować stosownie do 
przepisów o wykonywaniu użytkowania.

***
## Art. 263. {#art-263}

Roszczenie właściciela przeciwko użytkownikowi o naprawienie 
szkody z powodu pogorszenia rzeczy albo o zwrot nakładów na rzecz, jak również 
roszczenie użytkownika przeciwko właścicielowi o zwrot nakładów na rzecz 
przedawniają się z upływem roku od dnia zwrotu rzeczy. 
§ 2. (uchylony)

***
## Art. 264. {#art-264}

Jeżeli użytkowanie obejmuje pieniądze lub inne rzeczy oznaczone 
tylko co do gatunku, użytkownik staje się z chwilą wydania mu tych przedmiotów ich 
właścicielem. Po wygaśnięciu użytkowania obowiązany jest do zwrotu według 
przepisów o zwrocie pożyczki (użytkowanie nieprawidłowe).

***
## Art. 265. {#art-265}

§ 1. Przedmiotem użytkowania mogą być także prawa. 
§ 2. Do użytkowania praw stosuje się odpowiednio przepisy o użytkowaniu 
rzeczy. 
§ 3. Do ustanowienia użytkowania na prawie stosuje się odpowiednio przepisy 
o przeniesieniu tego prawa. 

©Kancelaria Sejmu 
 
 
 
s. 54/242 
 
   
 
2025-09-09 
## Rozdział II. Użytkowanie przez osoby fizyczne

***
## Art. 266. {#art-266}

Użytkowanie ustanowione na rzecz osoby fizycznej wygasa najpóźniej 
z jej śmiercią.

***
## Art. 267. {#art-267}

§ 1. Użytkownik obowiązany jest zachować substancję rzeczy oraz jej 
dotychczasowe przeznaczenie. 
§ 2. Jednakże użytkownik gruntu może zbudować i eksploatować nowe 
urządzenia służące do wydobywania kopalin z zachowaniem przepisów prawa 
geologicznego i górniczego. 
§ 3. Przed przystąpieniem do robót użytkownik powinien w odpowiednim 
terminie zawiadomić właściciela o swym zamiarze. Jeżeli zamierzone urządzenia 
zmieniałyby przeznaczenie gruntu albo naruszały wymagania prawidłowej 
gospodarki, właściciel może żądać ich zaniechania albo zabezpieczenia roszczenia 
o naprawienie szkody.

***
## Art. 268. {#art-268}

Użytkownik może zakładać w pomieszczeniach nowe urządzenia 
w takich granicach jak najemca.

***
## Art. 269. {#art-269}

§ 1. Właściciel może z ważnych powodów żądać od użytkownika 
zabezpieczenia, wyznaczając mu w tym celu odpowiedni termin. Po bezskutecznym 
upływie wyznaczonego terminu właściciel może wystąpić do sądu o wyznaczenie 
zarządcy. 
§ 2. Użytkownik może żądać uchylenia zarządu, jeżeli daje odpowiednie 
zabezpieczenie.

***
## Art. 270. {#art-270}

Właściciel 
może 
odmówić 
wydania 
przedmiotów 
objętych 
użytkowaniem nieprawidłowym, dopóki nie otrzyma odpowiedniego zabezpieczenia.

***
## Art. 2701. {#art-2701}

(uchylony) 
## Rozdział III. Użytkowanie przez rolnicze spółdzielnie produkcyjne

***
## Art. 271. {#art-271}

Użytkowanie gruntu stanowiącego własność Skarbu Państwa może 
być ustanowione na rzecz rolniczej spółdzielni produkcyjnej jako prawo terminowe 

©Kancelaria Sejmu 
 
 
 
s. 55/242 
 
   
 
2025-09-09 
 
lub jako prawo bezterminowe. W każdym razie użytkowanie takie wygasa z chwilą 
likwidacji spółdzielni.

***
## Art. 272. {#art-272}

§ 1. Jeżeli rolniczej spółdzielni produkcyjnej zostaje przekazany do 
użytkowania zabudowany grunt Skarbu Państwa, przekazanie budynków i innych 
urządzeń może nastąpić albo do użytkowania, albo na własność. 
§ 2. Budynki i inne urządzenia wzniesione przez rolniczą spółdzielnię 
produkcyjną na użytkowanym przez nią gruncie Skarbu Państwa stanowią własność 
spółdzielni, chyba że w decyzji o przekazaniu gruntu zostało zastrzeżone, iż mają się 
stać własnością Skarbu Państwa. 
§ 3. Odrębna 
własność 
budynków 
i innych 
urządzeń, 
przewidziana 
w paragrafach poprzedzających, jest prawem związanym z użytkowaniem gruntu.

***
## Art. 273. {#art-273}

Jeżeli użytkowanie gruntu Skarbu Państwa przez rolniczą spółdzielnię 
produkcyjną wygasło, budynki i inne urządzenia trwale z gruntem związane 
i stanowiące własność spółdzielni stają się własnością Skarbu Państwa. Spółdzielnia 
może żądać zapłaty wartości tych budynków i urządzeń w chwili wygaśnięcia 
użytkowania, chyba że zostały wzniesione wbrew społeczno-gospodarczemu 
przeznaczeniu gruntu.

***
## Art. 274. {#art-274}

Przepisy dotyczące własności budynków i innych urządzeń na gruncie 
Skarbu Państwa użytkowanym przez rolniczą spółdzielnię produkcyjną stosuje się 
odpowiednio do drzew i innych roślin.

***
## Art. 275. {#art-275}

Rolnicza spółdzielnia produkcyjna może zmienić przeznaczenie 
użytkowanych przez siebie gruntów Skarbu Państwa albo naruszyć ich substancję, 
chyba że w decyzji o przekazaniu gruntu inaczej zastrzeżono.

***
## Art. 276. {#art-276}

(uchylony)

***
## Art. 277. {#art-277}

§ 1. Jeżeli statut rolniczej spółdzielni produkcyjnej lub umowa 
z członkiem spółdzielni inaczej nie postanawia, spółdzielnia nabywa z chwilą 
przejęcia wniesionych przez członków wkładów gruntowych ich użytkowanie. 
§ 2. Do wniesienia wkładów gruntowych nie stosuje się przepisów o obowiązku 
zachowania formy aktu notarialnego przy ustanowieniu użytkowania nieruchomości.

***
## Art. 278. {#art-278}

Statut rolniczej spółdzielni produkcyjnej może postanawiać, że – gdy 
wymaga tego prawidłowe wykonanie zadań spółdzielni – przysługuje jej uprawnienie 

©Kancelaria Sejmu 
 
 
 
s. 56/242 
 
   
 
2025-09-09 
 
do zmiany przeznaczenia wkładów gruntowych oraz uprawnienie do naruszenia ich 
substancji albo jedno z tych uprawnień.

***
## Art. 279. {#art-279}

§ 1. Budynki i inne urządzenia wzniesione przez rolniczą spółdzielnię 
produkcyjną na gruncie stanowiącym wkład gruntowy stają się jej własnością. To 
samo dotyczy drzew i innych roślin zasadzonych lub zasianych przez spółdzielnię. 
§ 2. W razie wygaśnięcia użytkowania gruntu działka, na której znajdują się 
budynki lub urządzenia będące własnością spółdzielni, może być przez spółdzielnię 
przejęta na własność za zapłatą wartości w chwili wygaśnięcia użytkowania. Drzewa 
i inne rośliny zasadzone lub zasiane przez spółdzielnię stają się własnością właściciela 
gruntu.

***
## Art. 280. {#art-280}

(uchylony)

***
## Art. 281. {#art-281}

(uchylony)

***
## Art. 282. {#art-282}

(uchylony) 
## Rozdział IV. Inne wypadki użytkowania

***
## Art. 283. {#art-283}

(uchylony)

***
## Art. 284. {#art-284}

Do innych wypadków użytkowania przez osoby prawne stosuje się 
przepisy rozdziału I i odpowiednio rozdziału II niniejszego działu, o ile użytkowanie 
to nie jest inaczej uregulowane odrębnymi przepisami. 
## DZIAŁ III. Służebności 
## Rozdział I. Służebności gruntowe

***
## Art. 285. {#art-285}

§ 1. Nieruchomość można obciążyć na rzecz właściciela innej 
nieruchomości (nieruchomości władnącej) prawem, którego treść polega bądź na tym, 
że właściciel nieruchomości władnącej może korzystać w oznaczonym zakresie 
z nieruchomości obciążonej, bądź na tym, że właściciel nieruchomości obciążonej 
zostaje ograniczony w możności dokonywania w stosunku do niej określonych 
działań, bądź też na tym, że właścicielowi nieruchomości obciążonej nie wolno 

©Kancelaria Sejmu 
 
 
 
s. 57/242 
 
   
 
2025-09-09 
 
wykonywać określonych uprawnień, które mu względem nieruchomości władnącej 
przysługują na podstawie przepisów o treści i wykonywaniu własności (służebność 
gruntowa). 
§ 2. Służebność gruntowa może mieć jedynie na celu zwiększenie użyteczności 
nieruchomości władnącej lub jej oznaczonej części.

***
## Art. 286. {#art-286}

Na rzecz rolniczej spółdzielni produkcyjnej można ustanowić 
służebność gruntową bez względu na to, czy spółdzielnia jest właścicielem gruntu.

***
## Art. 287. {#art-287}

Zakres służebności gruntowej i sposób jej wykonywania oznacza się, 
w braku innych danych, według zasad współżycia społecznego przy uwzględnieniu 
zwyczajów miejscowych.

***
## Art. 288. {#art-288}

Służebność gruntowa powinna być wykonywana w taki sposób, żeby 
jak najmniej utrudniała korzystanie z nieruchomości obciążonej.

***
## Art. 289. {#art-289}

§ 1. W braku odmiennej umowy obowiązek utrzymywania urządzeń 
potrzebnych 
do 
wykonywania 
służebności 
gruntowej 
obciąża 
właściciela 
nieruchomości władnącej. 
§ 2. Jeżeli obowiązek utrzymywania takich urządzeń został włożony na 
właściciela nieruchomości obciążonej, właściciel odpowiedzialny jest także osobiście 
za wykonywanie tego obowiązku. Odpowiedzialność osobista współwłaścicieli jest 
solidarna.

***
## Art. 290. {#art-290}

§ 1. W razie podziału nieruchomości władnącej służebność utrzymuje 
się w mocy na rzecz każdej z części utworzonych przez podział; jednakże gdy 
służebność zwiększa użyteczność tylko jednej lub kilku z nich, właściciel nie-
ruchomości obciążonej może żądać zwolnienia jej od służebności względem części 
pozostałych. 
§ 2. W razie podziału nieruchomości obciążonej służebność utrzymuje się 
w mocy na częściach utworzonych przez podział; jednakże gdy wykonywanie 
służebności ogranicza się do jednej lub kilku z nich, właściciele pozostałych części 
mogą żądać ich zwolnienia od służebności. 
§ 3. Jeżeli wskutek podziału nieruchomości władnącej albo nieruchomości 
obciążonej sposób wykonywania służebności wymaga zmiany, sposób ten w braku 
porozumienia stron będzie ustalony przez sąd. 

©Kancelaria Sejmu 
 
 
 
s. 58/242 
 
   
 
2025-09-09

***
## Art. 291. {#art-291}

Jeżeli po ustanowieniu służebności gruntowej powstanie ważna 
potrzeba gospodarcza, właściciel nieruchomości obciążonej może żądać za 
wynagrodzeniem zmiany treści lub sposobu wykonywania służebności, chyba że 
żądana zmiana przyniosłaby niewspółmierny uszczerbek nieruchomości władnącej.

***
## Art. 292. {#art-292}

Służebność gruntowa może być nabyta przez zasiedzenie tylko 
w wypadku, gdy polega na korzystaniu z trwałego i widocznego urządzenia. Przepisy 
o nabyciu własności nieruchomości przez zasiedzenie stosuje się odpowiednio.

***
## Art. 293. {#art-293}

§ 1. Służebność gruntowa wygasa wskutek niewykonywania przez lat 
dziesięć. 
§ 2. Jeżeli treść służebności gruntowej polega na obowiązku nieczynienia, 
przepis powyższy stosuje się tylko wtedy, gdy na nieruchomości obciążonej istnieje 
od lat dziesięciu stan rzeczy sprzeczny z treścią służebności.

***
## Art. 294. {#art-294}

Właściciel 
nieruchomości 
obciążonej 
może żądać zniesienia 
służebności gruntowej za wynagrodzeniem, jeżeli wskutek zmiany stosunków 
służebność stała się dla niego szczególnie uciążliwa, a nie jest konieczna do 
prawidłowego korzystania z nieruchomości władnącej.

***
## Art. 295. {#art-295}

Jeżeli służebność gruntowa utraciła dla nieruchomości władnącej 
wszelkie znaczenie, właściciel nieruchomości obciążonej może żądać zniesienia 
służebności bez wynagrodzenia. 
## Rozdział II. Służebności osobiste

***
## Art. 296. {#art-296}

Nieruchomość można obciążyć na rzecz oznaczonej osoby fizycznej 
prawem, którego treść odpowiada treści służebności gruntowej (służebność osobista).

***
## Art. 297. {#art-297}

Do służebności osobistych stosuje się odpowiednio przepisy 
o służebnościach gruntowych z zachowaniem przepisów rozdziału niniejszego.

***
## Art. 298. {#art-298}

Zakres służebności osobistej i sposób jej wykonywania oznacza się, 
w braku innych danych, według osobistych potrzeb uprawnionego z uwzględnieniem 
zasad współżycia społecznego i zwyczajów miejscowych.

***
## Art. 299. {#art-299}

Służebność osobista wygasa najpóźniej ze śmiercią uprawnionego. 

©Kancelaria Sejmu 
 
 
 
s. 59/242 
 
   
 
2025-09-09

***
## Art. 300. {#art-300}

Służebności osobiste są niezbywalne. Nie można również przenieść 
uprawnienia do ich wykonywania.

***
## Art. 301. {#art-301}

§ 1. Mający służebność mieszkania może przyjąć na mieszkanie 
małżonka i dzieci małoletnie. Inne osoby może przyjąć tylko wtedy, gdy są przez 
niego utrzymywane albo potrzebne przy prowadzeniu gospodarstwa domowego. 
Dzieci przyjęte jako małoletnie mogą pozostać w mieszkaniu także po uzyskaniu 
pełnoletności. 
§ 2. Można się umówić, że po śmierci uprawnionego służebność mieszkania 
przysługiwać będzie jego dzieciom, rodzicom i małżonkowi.

***
## Art. 302. {#art-302}

§ 1. Mający służebność mieszkania może korzystać z pomieszczeń 
i urządzeń przeznaczonych do wspólnego użytku mieszkańców budynku. 
§ 2. Do wzajemnych stosunków między mającym służebność mieszkania 
a właścicielem nieruchomości obciążonej stosuje się odpowiednio przepisy 
o użytkowaniu przez osoby fizyczne.

***
## Art. 303. {#art-303}

Jeżeli uprawniony z tytułu służebności osobistej dopuszcza się 
rażących uchybień przy wykonywaniu swego prawa, właściciel nieruchomości 
obciążonej może żądać zamiany służebności na rentę.

***
## Art. 304. {#art-304}

Służebności osobistej nie można nabyć przez zasiedzenie.

***
## Art. 305. {#art-305}

Jeżeli nieruchomość obciążona służebnością osobistą została 
wniesiona jako wkład do rolniczej spółdzielni produkcyjnej, spółdzielnia może 
z ważnych powodów żądać zmiany sposobu wykonywania służebności albo jej 
zamiany na rentę. 
## Rozdział III. Służebność przesyłu

***
## Art. 3051. {#art-3051}

Nieruchomość można obciążyć na rzecz przedsiębiorcy, który 
zamierza wybudować lub którego własność stanowią urządzenia, o których mowa 
w art. 49 § 1, prawem polegającym na tym, że przedsiębiorca może korzystać 
w oznaczonym zakresie z nieruchomości obciążonej, zgodnie z przeznaczeniem tych 
urządzeń (służebność przesyłu). 

©Kancelaria Sejmu 
 
 
 
s. 60/242 
 
   
 
2025-09-09

***
## Art. 3052. {#art-3052}

§ 1. Jeżeli właściciel nieruchomości odmawia zawarcia umowy 
o ustanowienie służebności przesyłu, a jest ona konieczna dla właściwego korzystania 
z urządzeń, o których mowa w art. 49 § 1, przedsiębiorca może żądać jej ustanowienia 
za odpowiednim wynagrodzeniem. 
§ 2. Jeżeli przedsiębiorca odmawia zawarcia umowy o ustanowienie służebności 
przesyłu, a jest ona konieczna do korzystania z urządzeń, o których mowa w art. 49 
§ 1, właściciel nieruchomości może żądać odpowiedniego wynagrodzenia w zamian 
za ustanowienie służebności przesyłu.

***
## Art. 3053. {#art-3053}

§ 1. Służebność przesyłu przechodzi na nabywcę przedsiębiorstwa lub 
nabywcę urządzeń, o których mowa w art. 49 § 1. 
§ 2. Służebność przesyłu wygasa najpóźniej wraz z zakończeniem likwidacji 
przedsiębiorstwa. 
§ 3. Po wygaśnięciu służebności przesyłu na przedsiębiorcy ciąży obowiązek 
usunięcia urządzeń, o których mowa w art. 49 § 1, utrudniających korzystanie 
z nieruchomości. Jeżeli powodowałoby to nadmierne trudności lub koszty, przedsię-
biorca jest obowiązany do naprawienia wynikłej stąd szkody.

***
## Art. 3054. {#art-3054}

Do służebności przesyłu stosuje się odpowiednio przepisy 
o służebnościach gruntowych. 
## DZIAŁ IV. Zastaw 
## Rozdział I. Zastaw na rzeczach ruchomych

***
## Art. 306. {#art-306}

§ 1. W celu zabezpieczenia oznaczonej wierzytelności można rzecz 
ruchomą obciążyć prawem, na mocy którego wierzyciel będzie mógł dochodzić 
zaspokojenia z rzeczy bez względu na to, czyją stała się własnością, i z 
pierwszeństwem przed wierzycielami osobistymi właściciela rzeczy, wyjąwszy tych, 
którym z mocy ustawy przysługuje pierwszeństwo szczególne. 
§ 2. Zastaw można ustanowić także w celu zabezpieczenia wierzytelności 
przyszłej lub warunkowej.

***
## Art. 307. {#art-307}

§ 1. Do ustanowienia zastawu potrzebna jest umowa między 
właścicielem 
a wierzycielem 
oraz, 
z 
zastrzeżeniem 
wyjątków 
w ustawie 

©Kancelaria Sejmu 
 
 
 
s. 61/242 
 
   
 
2025-09-09 
 
przewidzianych, wydanie rzeczy wierzycielowi albo osobie trzeciej, na którą strony 
się zgodziły. 
§ 2. Jeżeli rzecz znajduje się w dzierżeniu wierzyciela, do ustanowienia zastawu 
wystarcza sama umowa. 
§ 3. Zastaw jest skuteczny wobec wierzycieli zastawcy, jeżeli umowa 
o ustanowienie zastawu została zawarta na piśmie z datą pewną.

***
## Art. 308. {#art-308}

Wierzytelność można także zabezpieczyć zastawem rejestrowym, 
który regulują odrębne przepisy.

***
## Art. 309. {#art-309}

Przepisy 
o nabyciu 
własności 
rzeczy 
ruchomej 
od 
osoby 
nieuprawnionej do rozporządzania rzeczą stosuje się odpowiednio do ustanowienia 
zastawu.

***
## Art. 310. {#art-310}

Jeżeli w chwili ustanowienia zastawu rzecz jest już obciążona innym 
prawem rzeczowym, zastaw powstały później ma pierwszeństwo przed prawem 
powstałym wcześniej, chyba że zastawnik działał w złej wierze.

***
## Art. 311. {#art-311}

Nieważne jest zastrzeżenie, przez które zastawca zobowiązuje się 
względem zastawnika, że nie dokona zbycia lub obciążenia rzeczy przed 
wygaśnięciem zastawu.

***
## Art. 312. {#art-312}

Zaspokojenie zastawnika z rzeczy obciążonej następuje według 
przepisów o sądowym postępowaniu egzekucyjnym.

***
## Art. 313. {#art-313}

Jeżeli przedmiotem zastawu są rzeczy mające określoną przez 
zarządzenie właściwego organu państwowego cenę sztywną, można się umówić, że 
w razie zwłoki z zapłatą długu przypadną one w odpowiednim stosunku zastawnikowi 
na własność zamiast zapłaty, według ceny z dnia wymagalności wierzytelności 
zabezpieczonej.

***
## Art. 314. {#art-314}

Zastaw zabezpiecza także roszczenia o odsetki za trzy ostatnie lata 
przed zbyciem rzeczy w postępowaniu egzekucyjnym lub upadłościowym, przyznane 
koszty postępowania w wysokości nieprzekraczającej dziesiątej części kapitału oraz 
inne roszczenia o świadczenia uboczne, w szczególności roszczenie o odszkodowanie 
z powodu niewykonania lub nienależytego wykonania zobowiązania oraz o zwrot 
nakładów na rzecz. 

©Kancelaria Sejmu 
 
 
 
s. 62/242 
 
   
 
2025-09-09

***
## Art. 315. {#art-315}

Zastawca niebędący dłużnikiem może niezależnie od zarzutów, które 
mu przysługują osobiście przeciwko zastawnikowi, podnosić zarzuty, które 
przysługują dłużnikowi, jak również te, których dłużnik zrzekł się po ustanowieniu 
zastawu.

***
## Art. 316. {#art-316}

Zastawnik może dochodzić zaspokojenia z rzeczy obciążonej 
zastawem bez względu na ograniczenie odpowiedzialności dłużnika wynikające 
z przepisów prawa spadkowego.

***
## Art. 317. {#art-317}

Przedawnienie wierzytelności zabezpieczonej zastawem nie narusza 
uprawnienia zastawnika do uzyskania zaspokojenia z rzeczy obciążonej. Przepisu 
powyższego nie stosuje się do roszczenia o odsetki lub inne świadczenia uboczne.

***
## Art. 318. {#art-318}

Zastawnik, któremu rzecz została wydana, powinien czuwać nad jej 
zachowaniem stosownie do przepisów o przechowaniu za wynagrodzeniem. Po 
wygaśnięciu zastawu powinien zwrócić rzecz zastawcy.

***
## Art. 319. {#art-319}

Jeżeli rzecz obciążona zastawem przynosi pożytki, zastawnik 
powinien, w braku odmiennej umowy, pobierać je i zaliczać na poczet wierzytelności 
i związanych z nią roszczeń. Po wygaśnięciu zastawu obowiązany jest złożyć 
zastawcy rachunek.

***
## Art. 320. {#art-320}

Jeżeli zastawnik poczynił nakłady na rzecz, do których nie był 
obowiązany, stosuje się odpowiednio przepisy o prowadzeniu cudzych spraw bez 
zlecenia.

***
## Art. 321. {#art-321}

§ 1. Jeżeli rzecz obciążona zastawem zostaje narażona na utratę lub 
uszkodzenie, zastawca może żądać bądź złożenia rzeczy do depozytu sądowego, bądź 
zwrotu rzeczy za jednoczesnym ustanowieniem innego zabezpieczenia wierzytelności, 
bądź sprzedaży rzeczy. 
§ 2. W razie sprzedaży rzeczy zastaw przechodzi na uzyskaną cenę, która 
powinna być złożona do depozytu sądowego.

***
## Art. 322. {#art-322}

§ 1. Roszczenie zastawcy przeciwko zastawnikowi o naprawienie 
szkody z powodu pogorszenia rzeczy, jak również roszczenie zastawnika przeciwko 
zastawcy o zwrot nakładów na rzecz przedawniają się z upływem roku od dnia zwrotu 
rzeczy. 
§ 2. (uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 63/242 
 
   
 
2025-09-09

***
## Art. 323. {#art-323}

§ 1. Przeniesienie wierzytelności zabezpieczonej zastawem pociąga za 
sobą przeniesienie zastawu. W razie przeniesienia wierzytelności z wyłączeniem 
zastawu zastaw wygasa. 
§ 2. Zastaw nie może być przeniesiony bez wierzytelności, którą zabezpiecza.

***
## Art. 324. {#art-324}

Nabywca wierzytelności zabezpieczonej zastawem może żądać od 
zbywcy wydania rzeczy obciążonej, jeżeli zastawca wyrazi na to zgodę. W braku 
takiej zgody nabywca może żądać złożenia rzeczy do depozytu sądowego.

***
## Art. 325. {#art-325}

§ 1. Jeżeli zastawnik zwróci rzecz zastawcy, zastaw wygasa bez 
względu na zastrzeżenia przeciwne. 
§ 2. Zastaw nie wygasa pomimo nabycia rzeczy obciążonej przez zastawnika na 
własność, jeżeli wierzytelność zabezpieczona zastawem jest obciążona prawem osoby 
trzeciej lub na jej rzecz zajęta.

***
## Art. 326. {#art-326}

Przepisy rozdziału niniejszego stosuje się odpowiednio do zastawu, 
który powstaje z mocy ustawy. 
## Rozdział II. Zastaw na prawach

***
## Art. 327. {#art-327}

Przedmiotem zastawu mogą być także prawa, jeżeli są zbywalne.

***
## Art. 328. {#art-328}

Do zastawu na prawach stosuje się odpowiednio przepisy o zastawie 
na rzeczach ruchomych z zachowaniem przepisów rozdziału niniejszego.

***
## Art. 329. {#art-329}

§ 1. Do ustanowienia zastawu na prawie stosuje się odpowiednio 
przepisy o przeniesieniu tego prawa. Jednakże umowa o ustanowienie zastawu 
powinna być zawarta na piśmie z datą pewną, chociażby umowa o przeniesienie prawa 
nie wymagała takiej formy. 
§ 2. Jeżeli ustanowienie zastawu na wierzytelności nie następuje przez wydanie 
dokumentu ani przez indos, do ustanowienia zastawu potrzebne jest pisemne 
zawiadomienie dłużnika wierzytelności przez zastawcę.

***
## Art. 330. {#art-330}

Zastawnik może wykonywać wszelkie czynności i dochodzić 
wszelkich roszczeń, które zmierzają do zachowania prawa obciążonego zastawem.

***
## Art. 331. {#art-331}

§ 1. Jeżeli wymagalność wierzytelności obciążonej zależy od 
wypowiedzenia przez wierzyciela, zastawca może dokonać wypowiedzenia bez zgody 

©Kancelaria Sejmu 
 
 
 
s. 64/242 
 
   
 
2025-09-09 
 
zastawnika. Jeżeli wierzytelność zabezpieczona zastawem jest już wymagalna, 
zastawnik może wierzytelność obciążoną wypowiedzieć do wysokości wierzytelności 
zabezpieczonej. 
§ 2. Jeżeli wymagalność wierzytelności obciążonej zastawem zależy od 
wypowiedzenia przez dłużnika, wypowiedzenie powinno nastąpić także względem 
zastawnika.

***
## Art. 332. {#art-332}

W razie spełnienia świadczenia zastaw na wierzytelności przechodzi 
na przedmiot świadczenia.

***
## Art. 333. {#art-333}

Do odbioru świadczenia uprawnieni są zastawca wierzytelności 
i zastawnik łącznie. Każdy z nich może żądać spełnienia świadczenia do rąk ich obu 
łącznie albo złożenia przedmiotu świadczenia do depozytu sądowego.

***
## Art. 334. {#art-334}

Jeżeli 
dłużnik 
wierzytelności 
obciążonej 
zastawem 
spełnia 
świadczenie, zanim wierzytelność zabezpieczona stała się wymagalna, zarówno 
zastawca, jak i zastawnik mogą żądać złożenia przedmiotu świadczenia do depozytu 
sądowego.

***
## Art. 335. {#art-335}

Jeżeli wierzytelność pieniężna zastawem zabezpieczona jest już 
wymagalna, zastawnik może żądać zamiast zapłaty, ażeby zastawca przeniósł na niego 
wierzytelność obciążoną, jeżeli jest pieniężna, do wysokości wierzytelności 
zabezpieczonej zastawem. Zastawnik może dochodzić przypadłej mu z tego tytułu 
części wierzytelności z pierwszeństwem przed częścią przysługującą zastawcy. 
TYTUŁ IV 
Posiadanie

***
## Art. 336. {#art-336}

Posiadaczem rzeczy jest zarówno ten, kto nią faktycznie włada jak 
właściciel (posiadacz samoistny), jak i ten, kto nią faktycznie włada jak użytkownik, 
zastawnik, najemca, dzierżawca lub mający inne prawo, z którym łączy się określone 
władztwo nad cudzą rzeczą (posiadacz zależny).

***
## Art. 337. {#art-337}

Posiadacz samoistny nie traci posiadania przez to, że oddaje drugiemu 
rzecz w posiadanie zależne.

***
## Art. 338. {#art-338}

Kto rzeczą faktycznie włada za kogo innego, jest dzierżycielem. 

©Kancelaria Sejmu 
 
 
 
s. 65/242 
 
   
 
2025-09-09

***
## Art. 339. {#art-339}

Domniemywa się, że ten, kto rzeczą faktycznie włada, jest 
posiadaczem samoistnym.

***
## Art. 340. {#art-340}

Domniemywa się ciągłość posiadania. Niemożność posiadania 
wywołana przez przeszkodę przemijającą nie przerywa posiadania.

***
## Art. 341. {#art-341}

Domniemywa się, że posiadanie jest zgodne ze stanem prawnym. 
Domniemanie to dotyczy również posiadania przez poprzedniego posiadacza.

***
## Art. 342. {#art-342}

Nie wolno naruszać samowolnie posiadania, chociażby posiadacz był 
w złej wierze.

***
## Art. 343. {#art-343}

§ 1. Posiadacz może zastosować obronę konieczną, ażeby odeprzeć 
samowolne naruszenie posiadania. 
§ 2. Posiadacz nieruchomości może niezwłocznie po samowolnym naruszeniu 
posiadania przywrócić własnym działaniem stan poprzedni; nie wolno mu jednak 
stosować przy tym przemocy względem osób. Posiadacz rzeczy ruchomej, jeżeli grozi 
mu niebezpieczeństwo niepowetowanej szkody, może natychmiast po samowolnym 
pozbawieniu go posiadania zastosować niezbędną samopomoc w celu przywrócenia 
stanu poprzedniego. 
§ 3. Przepisy paragrafów poprzedzających stosuje się odpowiednio do 
dzierżyciela.

***
## Art. 3431. {#art-3431}

Do ochrony władania lokalem stosuje się odpowiednio przepisy 
o ochronie posiadania.

***
## Art. 344. {#art-344}

§ 1. Przeciwko temu, kto samowolnie naruszył posiadanie, jak również 
przeciwko temu, na czyją korzyść naruszenie nastąpiło, przysługuje posiadaczowi 
roszczenie o przywrócenie stanu poprzedniego i o zaniechanie naruszeń. Roszczenie 
to nie jest zależne od dobrej wiary posiadacza ani od zgodności posiadania ze stanem 
prawnym, chyba że prawomocne orzeczenie sądu lub innego powołanego do 
rozpoznawania spraw tego rodzaju organu państwowego stwierdziło, że stan 
posiadania powstały na skutek naruszenia jest zgodny z prawem. 
§ 2. Roszczenie wygasa, jeżeli nie będzie dochodzone w ciągu roku od chwili 
naruszenia.

***
## Art. 345. {#art-345}

Posiadanie przywrócone poczytuje się za nieprzerwane. 

©Kancelaria Sejmu 
 
 
 
s. 66/242 
 
   
 
2025-09-09

***
## Art. 346. {#art-346}

Roszczenie o ochronę posiadania nie przysługuje w stosunkach 
pomiędzy współposiadaczami tej samej rzeczy, jeżeli nie da się ustalić zakresu 
współposiadania.

***
## Art. 347. {#art-347}

§ 1. 
Posiadaczowi 
nieruchomości 
przysługuje 
roszczenie 
o wstrzymanie budowy, jeżeli budowa mogłaby naruszyć jego posiadanie albo grozić 
wyrządzeniem mu szkody. 
§ 2. Roszczenie może być dochodzone przed rozpoczęciem budowy; wygasa 
ono, jeżeli nie będzie dochodzone w ciągu miesiąca od rozpoczęcia budowy.

***
## Art. 348. {#art-348}

Przeniesienie posiadania następuje przez wydanie rzeczy. Wydanie 
dokumentów, które umożliwiają rozporządzanie rzeczą, jak również wydanie 
środków, które dają faktyczną władzę nad rzeczą, jest jednoznaczne z wydaniem 
samej rzeczy.

***
## Art. 349. {#art-349}

Przeniesienie posiadania samoistnego może nastąpić także w ten 
sposób, że dotychczasowy posiadacz samoistny zachowa rzecz w swoim władaniu 
jako posiadacz zależny albo jako dzierżyciel na podstawie stosunku prawnego, który 
strony jednocześnie ustalą.

***
## Art. 350. {#art-350}

Jeżeli rzecz znajduje się w posiadaniu zależnym albo w dzierżeniu 
osoby trzeciej, przeniesienie posiadania samoistnego następuje przez umowę między 
stronami i przez zawiadomienie posiadacza zależnego albo dzierżyciela.

***
## Art. 351. {#art-351}

Przeniesienie posiadania samoistnego na posiadacza zależnego albo na 
dzierżyciela następuje na mocy samej umowy między stronami.

***
## Art. 352. {#art-352}

§ 1. Kto faktycznie korzysta z cudzej nieruchomości w zakresie 
odpowiadającym treści służebności, jest posiadaczem służebności. 
§ 2. Do posiadania służebności stosuje się odpowiednio przepisy o posiadaniu 
rzeczy. 

©Kancelaria Sejmu 
 
 
 
s. 67/242 
 
   
 
2025-09-09 
 
KSIĘGA TRZECIA 
ZOBOWIĄZANIA 
TYTUŁ I 
Przepisy ogólne

***
## Art. 353. {#art-353}

§ 1. Zobowiązanie polega na tym, że wierzyciel może żądać od 
dłużnika świadczenia, a dłużnik powinien świadczenie spełnić. 
§ 2. Świadczenie może polegać na działaniu albo na zaniechaniu.

***
## Art. 3531. {#art-3531}

Strony zawierające umowę mogą ułożyć stosunek prawny według 
swego uznania, byleby jego treść lub cel nie sprzeciwiały się właściwości (naturze) 
stosunku, ustawie ani zasadom współżycia społecznego.

***
## Art. 354. {#art-354}

§ 1. Dłużnik powinien wykonać zobowiązanie zgodnie z jego treścią 
i w sposób odpowiadający jego celowi społeczno-gospodarczemu oraz zasadom 
współżycia społecznego, a jeżeli istnieją w tym zakresie ustalone zwyczaje – także 
w sposób odpowiadający tym zwyczajom. 
§ 2. W taki sam sposób powinien współdziałać przy wykonaniu zobowiązania 
wierzyciel.

***
## Art. 355. {#art-355}

§ 1. Dłużnik obowiązany jest do staranności ogólnie wymaganej 
w stosunkach danego rodzaju (należyta staranność). 
§ 2. Należytą staranność dłużnika w zakresie prowadzonej przez niego 
działalności gospodarczej określa się przy uwzględnieniu zawodowego charakteru tej 
działalności.

***
## Art. 356. {#art-356}

§ 1. Wierzyciel może żądać osobistego świadczenia dłużnika tylko 
wtedy, gdy to wynika z treści czynności prawnej, z ustawy albo z właściwości 
świadczenia. 
§ 2. Jeżeli wierzytelność pieniężna jest wymagalna, wierzyciel nie może 
odmówić przyjęcia świadczenia od osoby trzeciej, chociażby działała bez wiedzy 
dłużnika.

***
## Art. 357. {#art-357}

Jeżeli dłużnik jest zobowiązany do świadczenia rzeczy oznaczonych 
tylko co do gatunku, a jakość rzeczy nie jest oznaczona przez właściwe przepisy lub 

©Kancelaria Sejmu 
 
 
 
s. 68/242 
 
   
 
2025-09-09 
 
przez czynność prawną ani nie wynika z okoliczności, dłużnik powinien świadczyć 
rzeczy średniej jakości.

***
## Art. 3571. {#art-3571}

Jeżeli z powodu nadzwyczajnej zmiany stosunków spełnienie 
świadczenia byłoby połączone z nadmiernymi trudnościami albo groziłoby jednej ze 
stron rażącą stratą, czego strony nie przewidywały przy zawarciu umowy, sąd może 
po rozważeniu interesów stron, zgodnie z zasadami współżycia społecznego, oznaczyć 
sposób wykonania zobowiązania, wysokość świadczenia lub nawet orzec 
o rozwiązaniu umowy. Rozwiązując umowę sąd może w miarę potrzeby orzec 
o rozliczeniach stron, kierując się zasadami określonymi w zdaniu poprzedzającym. 
§ 2. (uchylony)

***
## Art. 358. {#art-358}

§ 1. Jeżeli przedmiotem zobowiązania podlegającego wykonaniu na 
terytorium Rzeczypospolitej Polskiej jest suma pieniężna wyrażona w walucie obcej, 
dłużnik może spełnić świadczenie w walucie polskiej, chyba że ustawa, orzeczenie 
sądowe będące źródłem zobowiązania lub czynność prawna zastrzega spełnienie 
świadczenia wyłącznie w walucie obcej. 
§ 2. Wartość waluty obcej określa się według kursu średniego ogłaszanego przez 
Narodowy Bank Polski z dnia wymagalności roszczenia, chyba że ustawa, orzeczenie 
sądowe lub czynność prawna zastrzega inaczej. 
§ 3. Jeżeli dłużnik opóźnia się ze spełnieniem świadczenia, wierzyciel może 
żądać spełnienia świadczenia w walucie polskiej według kursu średniego ogłaszanego 
przez Narodowy Bank Polski z dnia, w którym zapłata jest dokonywana.

***
## Art. 3581. {#art-3581}

§ 1. Jeżeli przedmiotem zobowiązania od chwili jego powstania jest 
suma pieniężna, spełnienie świadczenia następuje przez zapłatę sumy nominalnej, 
chyba że przepisy szczególne stanowią inaczej. 
§ 2. Strony mogą zastrzec w umowie, że wysokość świadczenia pieniężnego 
zostanie ustalona według innego niż pieniądz miernika wartości. 
§ 3. W razie istotnej zmiany siły nabywczej pieniądza po powstaniu 
zobowiązania, sąd może po rozważeniu interesów stron, zgodnie z zasadami 
współżycia społecznego, zmienić wysokość lub sposób spełnienia świadczenia 
pieniężnego, chociażby były ustalone w orzeczeniu lub umowie. 

©Kancelaria Sejmu 
 
 
 
s. 69/242 
 
   
 
2025-09-09 
 
§ 4. Z żądaniem zmiany wysokości lub sposobu spełnienia świadczenia 
pieniężnego nie może wystąpić strona prowadząca przedsiębiorstwo, jeżeli 
świadczenie pozostaje w związku z prowadzeniem tego przedsiębiorstwa. 
§ 5. Przepisy § 2 i 3 nie uchybiają przepisom regulującym wysokość cen i innych 
świadczeń pieniężnych.

***
## Art. 359. {#art-359}

§ 1. Odsetki od sumy pieniężnej należą się tylko wtedy, gdy to wynika 
z czynności prawnej albo z ustawy, z orzeczenia sądu lub z decyzji innego właściwego 
organu. 
§ 2. Jeżeli wysokość odsetek nie jest w inny sposób określona, należą się odsetki 
ustawowe w wysokości równej sumie stopy referencyjnej Narodowego Banku 
Polskiego i 3,5 punktów procentowych. 
§ 21. Maksymalna wysokość odsetek wynikających z czynności prawnej nie 
może w stosunku rocznym przekraczać dwukrotności wysokości odsetek ustawowych 
(odsetki maksymalne). 
§ 22. Jeżeli wysokość odsetek wynikających z czynności prawnej przekracza 
wysokość odsetek maksymalnych, należą się odsetki maksymalne. 
§ 23. Postanowienia umowne nie mogą wyłączać ani ograniczać przepisów 
o odsetkach maksymalnych, także w razie dokonania wyboru prawa obcego. W takim 
przypadku stosuje się przepisy ustawy. 
§ 3. (uchylony) 
§ 4. Minister Sprawiedliwości ogłasza, w drodze obwieszczenia, w Dzienniku 
Urzędowym Rzeczypospolitej Polskiej „Monitor Polski”, wysokość odsetek 
ustawowych.

***
## Art. 360. {#art-360}

W braku odmiennego zastrzeżenia co do terminu płatności odsetek są 
one płatne co roku z dołu, a jeżeli termin płatności sumy pieniężnej jest krótszy niż 
rok – jednocześnie z zapłatą tej sumy.

***
## Art. 361. {#art-361}

§ 1. Zobowiązany do odszkodowania ponosi odpowiedzialność tylko 
za normalne następstwa działania lub zaniechania, z którego szkoda wynikła. 
§ 2. W powyższych granicach, w braku odmiennego przepisu ustawy lub 
postanowienia umowy, naprawienie szkody obejmuje straty, które poszkodowany 
poniósł, oraz korzyści, które mógłby osiągnąć, gdyby mu szkody nie wyrządzono. 

©Kancelaria Sejmu 
 
 
 
s. 70/242 
 
   
 
2025-09-09

***
## Art. 362. {#art-362}

Jeżeli poszkodowany przyczynił się do powstania lub zwiększenia 
szkody, obowiązek jej naprawienia ulega odpowiedniemu zmniejszeniu stosownie do 
okoliczności, a zwłaszcza do stopnia winy obu stron.

***
## Art. 363. {#art-363}

§ 1. Naprawienie 
szkody 
powinno 
nastąpić, 
według 
wyboru 
poszkodowanego, bądź przez przywrócenie stanu poprzedniego, bądź przez zapłatę 
odpowiedniej sumy pieniężnej. Jednakże gdyby przywrócenie stanu poprzedniego 
było niemożliwe albo gdyby pociągało za sobą dla zobowiązanego nadmierne 
trudności lub koszty, roszczenie poszkodowanego ogranicza się do świadczenia 
w pieniądzu. 
§ 2. Jeżeli 
naprawienie 
szkody 
ma 
nastąpić 
w pieniądzu, 
wysokość 
odszkodowania powinna być ustalona według cen z daty ustalenia odszkodowania, 
chyba że szczególne okoliczności wymagają przyjęcia za podstawę cen istniejących 
w innej chwili.

***
## Art. 364. {#art-364}

§ 1. 
Ilekroć 
ustawa 
przewiduje 
obowiązek 
zabezpieczenia, 
zabezpieczenie powinno nastąpić przez złożenie pieniędzy do depozytu sądowego. 
§ 2. Jednakże z ważnych powodów zabezpieczenie może nastąpić w inny 
sposób.

***
## Art. 365. {#art-365}

§ 1. Jeżeli dłużnik jest zobowiązany w ten sposób, że wykonanie 
zobowiązania może nastąpić przez spełnienie jednego z kilku świadczeń 
(zobowiązanie przemienne), wybór świadczenia należy do dłużnika, chyba że z 
czynności prawnej, z ustawy lub z okoliczności wynika, iż uprawnionym do wyboru 
jest wierzyciel lub osoba trzecia. 
§ 2. Wyboru dokonywa się przez złożenie oświadczenia drugiej stronie. Jeżeli 
uprawnionym do wyboru jest dłużnik, może on dokonać wyboru także przez spełnienie 
świadczenia. 
§ 3. Jeżeli strona uprawniona do wyboru świadczenia wyboru tego nie dokona, 
druga strona może jej wyznaczyć w tym celu odpowiedni termin. Po bezskutecznym 
upływie wyznaczonego terminu uprawnienie do dokonania wyboru przechodzi na 
stronę drugą.

***
## Art. 3651. {#art-3651}

Zobowiązanie bezterminowe o charakterze ciągłym wygasa po 
wypowiedzeniu przez dłużnika lub wierzyciela z zachowaniem terminów umownych, 

©Kancelaria Sejmu 
 
 
 
s. 71/242 
 
   
 
2025-09-09 
 
ustawowych lub zwyczajowych, a w razie braku takich terminów niezwłocznie po 
wypowiedzeniu. 
TYTUŁ II 
Wielość dłużników albo wierzycieli 
## DZIAŁ I. Zobowiązania solidarne

***
## Art. 366. {#art-366}

§ 1. Kilku dłużników może być zobowiązanych w ten sposób, że 
wierzyciel może żądać całości lub części świadczenia od wszystkich dłużników 
łącznie, od kilku z nich lub od każdego z osobna, a zaspokojenie wierzyciela przez 
któregokolwiek z dłużników zwalnia pozostałych (solidarność dłużników). 
§ 2. Aż do zupełnego zaspokojenia wierzyciela wszyscy dłużnicy solidarni 
pozostają zobowiązani.

***
## Art. 367. {#art-367}

§ 1. Kilku wierzycieli może być uprawnionych w ten sposób, że 
dłużnik może spełnić całe świadczenie do rąk jednego z nich, a przez zaspokojenie 
któregokolwiek z wierzycieli dług wygasa względem wszystkich (solidarność 
wierzycieli). 
§ 2. Dłużnik może spełnić świadczenie, według swego wyboru, do rąk 
któregokolwiek z wierzycieli solidarnych. Jednakże w razie wytoczenia powództwa 
przez jednego z wierzycieli dłużnik powinien spełnić świadczenie do jego rąk.

***
## Art. 368. {#art-368}

Zobowiązanie może być solidarne, chociażby każdy z dłużników był 
zobowiązany w sposób odmienny albo chociażby wspólny dłużnik był zobowiązany 
w sposób odmienny względem każdego z wierzycieli.

***
## Art. 369. {#art-369}

Zobowiązanie jest solidarne, jeżeli to wynika z ustawy lub z czynności 
prawnej.

***
## Art. 370. {#art-370}

Jeżeli kilka osób zaciągnęło zobowiązanie dotyczące ich wspólnego 
mienia, są one zobowiązane solidarnie, chyba że umówiono się inaczej.

***
## Art. 371. {#art-371}

Działania i zaniechania jednego z dłużników solidarnych nie mogą 
szkodzić współdłużnikom.

***
## Art. 372. {#art-372}

Przerwanie lub zawieszenie biegu przedawnienia w stosunku do 
jednego z dłużników solidarnych nie ma skutku względem współdłużników. 

©Kancelaria Sejmu 
 
 
 
s. 72/242 
 
   
 
2025-09-09

***
## Art. 373. {#art-373}

Zwolnienie z długu lub zrzeczenie się solidarności przez wierzyciela 
względem 
jednego 
z dłużników 
solidarnych 
nie 
ma 
skutku 
względem 
współdłużników.

***
## Art. 374. {#art-374}

§ 1. 
Odnowienie 
dokonane 
między 
wierzycielem 
a jednym 
z dłużników solidarnych zwalnia współdłużników, chyba że wierzyciel zastrzegł, iż 
zachowuje przeciwko nim swe prawa. 
§ 2. Zwłoka wierzyciela względem jednego z dłużników solidarnych ma skutek 
także względem współdłużników.

***
## Art. 375. {#art-375}

§ 1. Dłużnik solidarny może się bronić zarzutami, które przysługują 
mu osobiście względem wierzyciela, jak również tymi, które ze względu na sposób 
powstania lub treść zobowiązania są wspólne wszystkim dłużnikom. 
§ 2. Wyrok zapadły na korzyść jednego z dłużników solidarnych zwalnia 
współdłużników, jeżeli uwzględnia zarzuty, które są im wszystkim wspólne.

***
## Art. 376. {#art-376}

§ 1. Jeżeli jeden z dłużników solidarnych spełnił świadczenie, treść 
istniejącego między współdłużnikami stosunku prawnego rozstrzyga o tym, czy 
i w jakich częściach może on żądać zwrotu od współdłużników. Jeżeli z treści tego 
stosunku nie wynika nic innego, dłużnik, który świadczenie spełnił, może żądać 
zwrotu w częściach równych. 
§ 2. Część przypadająca na dłużnika niewypłacalnego rozkłada się między 
współdłużników.

***
## Art. 377. {#art-377}

Zwłoka dłużnika, jak również przerwanie lub zawieszenie biegu 
przedawnienia względem jednego z wierzycieli solidarnych ma skutek także 
względem współwierzycieli.

***
## Art. 378. {#art-378}

Jeżeli jeden z wierzycieli solidarnych przyjął świadczenie, treść 
istniejącego między współwierzycielami stosunku prawnego rozstrzyga o tym, czy 
i w jakich częściach jest on odpowiedzialny względem współwierzycieli. Jeżeli 
z treści tego stosunku nie wynika nic innego, wierzyciel, który przyjął świadczenie, 
jest odpowiedzialny w częściach równych. 

©Kancelaria Sejmu 
 
 
 
s. 73/242 
 
   
 
2025-09-09 
## DZIAŁ II. Zobowiązania podzielne i niepodzielne

***
## Art. 379. {#art-379}

§ 1. Jeżeli jest kilku dłużników albo kilku wierzycieli, a świadczenie 
jest podzielne, zarówno dług, jak i wierzytelność dzielą się na tyle niezależnych od 
siebie części, ilu jest dłużników albo wierzycieli. Części te są równe, jeżeli 
z okoliczności nie wynika nic innego. 
§ 2. Świadczenie jest podzielne, jeżeli może być spełnione częściowo bez istotnej 
zmiany przedmiotu lub wartości.

***
## Art. 380. {#art-380}

§ 1. Dłużnicy zobowiązani do świadczenia niepodzielnego są 
odpowiedzialni za spełnienie świadczenia jak dłużnicy solidarni. 
§ 2. W braku odmiennej umowy dłużnicy zobowiązani do świadczenia 
podzielnego są odpowiedzialni za jego spełnienie solidarnie, jeżeli wzajemne 
świadczenie wierzyciela jest niepodzielne. 
§ 3. Dłużnik, który spełnił świadczenie niepodzielne, może żądać od pozostałych 
dłużników zwrotu wartości świadczenia według tych samych zasad co dłużnik 
solidarny.

***
## Art. 381. {#art-381}

§ 1. Jeżeli jest kilku wierzycieli uprawnionych do świadczenia 
niepodzielnego, każdy z nich może żądać spełnienia całego świadczenia. 
§ 2. Jednakże w razie sprzeciwu chociażby jednego z wierzycieli, dłużnik 
obowiązany jest świadczyć wszystkim wierzycielom łącznie albo złożyć przedmiot 
świadczenia do depozytu sądowego.

***
## Art. 382. {#art-382}

§ 1. Zwolnienie dłużnika z długu przez jednego z wierzycieli 
uprawnionych do świadczenia niepodzielnego nie ma skutku względem pozostałych 
wierzycieli. 
§ 2. Zwłoka dłużnika, jak również przerwanie lub zawieszenie biegu 
przedawnienia względem jednego z wierzycieli uprawnionych do świadczenia 
niepodzielnego ma skutek względem pozostałych wierzycieli.

***
## Art. 383. {#art-383}

Jeżeli 
jeden 
z wierzycieli 
uprawnionych 
do 
świadczenia 
niepodzielnego przyjął świadczenie, jest on odpowiedzialny względem pozostałych 
wierzycieli według tych samych zasad co wierzyciel solidarny. 

©Kancelaria Sejmu 
 
 
 
s. 74/242 
 
   
 
2025-09-09 
 
TYTUŁ III 
Ogólne przepisy o zobowiązaniach umownych

***
## Art. 3831. {#art-3831}

Przedsiębiorca nie może żądać od konsumenta opłaty za skorzystanie 
z określonego sposobu zapłaty przewyższającej poniesione przez przedsiębiorcę 
koszty w związku z tym sposobem zapłaty.

***
## Art. 384. {#art-384}

§ 1. Ustalony przez jedną ze stron wzorzec umowy, w szczególności 
ogólne warunki umów, wzór umowy, regulamin, wiąże drugą stronę, jeżeli został jej 
doręczony przed zawarciem umowy. 
§ 2. W razie gdy posługiwanie się wzorcem jest w stosunkach danego rodzaju 
zwyczajowo przyjęte, wiąże on także wtedy, gdy druga strona mogła się z łatwością 
dowiedzieć o jego treści. Nie dotyczy to jednak umów zawieranych z udziałem 
konsumentów, z wyjątkiem umów powszechnie zawieranych w drobnych, bieżących 
sprawach życia codziennego. 
§ 3. (uchylony) 
§ 4. Jeżeli jedna ze stron posługuje się wzorcem umowy w postaci 
elektronicznej, powinna udostępnić go drugiej stronie przed zawarciem umowy w taki 
sposób, aby mogła ona wzorzec ten przechowywać i odtwarzać w zwykłym toku 
czynności. 
§ 5. (uchylony)

***
## Art. 3841. {#art-3841}

Wzorzec wydany w czasie trwania stosunku umownego o charakterze 
ciągłym wiąże drugą stronę, jeżeli zostały zachowane wymagania określone 
w art. 384, 
a strona 
nie 
wypowiedziała 
umowy 
w najbliższym 
terminie 
wypowiedzenia.

***
## Art. 385. {#art-385}

§ 1. W razie sprzeczności treści umowy z wzorcem umowy strony są 
związane umową. 
§ 2. Wzorzec umowy powinien być sformułowany jednoznacznie i w sposób 
zrozumiały. Postanowienia niejednoznaczne tłumaczy się na korzyść konsumenta. 
Zasady wyrażonej w zdaniu poprzedzającym nie stosuje się w postępowaniu 
w sprawach o uznanie postanowień wzorca umowy za niedozwolone.

***
## Art. 3851. {#art-3851}

§ 1. Postanowienia umowy zawieranej z konsumentem nieuzgodnione 
indywidualnie nie wiążą go, jeżeli kształtują jego prawa i obowiązki w sposób 

©Kancelaria Sejmu 
 
 
 
s. 75/242 
 
   
 
2025-09-09 
 
sprzeczny z dobrymi obyczajami, rażąco naruszając jego interesy (niedozwolone 
postanowienia umowne). Nie dotyczy to postanowień określających główne 
świadczenia stron, w tym cenę lub wynagrodzenie, jeżeli zostały sformułowane 
w sposób jednoznaczny. 
§ 2. Jeżeli postanowienie umowy zgodnie z § 1 nie wiąże konsumenta, strony są 
związane umową w pozostałym zakresie. 
§ 3. Nieuzgodnione indywidualnie są te postanowienia umowy, na których treść 
konsument nie miał rzeczywistego wpływu. W szczególności odnosi się to do 
postanowień umowy przejętych z wzorca umowy zaproponowanego konsumentowi 
przez kontrahenta. 
§ 4. Ciężar dowodu, że postanowienie zostało uzgodnione indywidualnie, 
spoczywa na tym, kto się na to powołuje.

***
## Art. 3852. {#art-3852}

Oceny zgodności postanowienia umowy z dobrymi obyczajami 
dokonuje się według stanu z chwili zawarcia umowy, biorąc pod uwagę jej treść, 
okoliczności zawarcia oraz uwzględniając umowy pozostające w związku z umową 
obejmującą postanowienie będące przedmiotem oceny.

***
## Art. 3853. {#art-3853}

W razie wątpliwości uważa się, że niedozwolonymi postanowieniami 
umownymi są te, które w szczególności: 
- 1) wyłączają lub ograniczają odpowiedzialność względem konsumenta za szkody 
na osobie; 
- 2) wyłączają lub istotnie ograniczają odpowiedzialność względem konsumenta za 
niewykonanie lub nienależyte wykonanie zobowiązania; 
- 3) wyłączają lub istotnie ograniczają potrącenie wierzytelności konsumenta 
z wierzytelnością drugiej strony; 
- 4) przewidują postanowienia, z którymi konsument nie miał możliwości zapoznać 
się przed zawarciem umowy; 
- 5) zezwalają kontrahentowi konsumenta na przeniesienie praw i przekazanie 
obowiązków wynikających z umowy bez zgody konsumenta; 
- 6) uzależniają zawarcie umowy od przyrzeczenia przez konsumenta zawierania 
w przyszłości dalszych umów podobnego rodzaju; 

©Kancelaria Sejmu 
 
 
 
s. 76/242 
 
   
 
2025-09-09 
- 7) uzależniają zawarcie, treść lub wykonanie umowy od zawarcia innej umowy, 
niemającej 
bezpośredniego 
związku 
z umową 
zawierającą 
oceniane 
postanowienie; 
- 8) uzależniają spełnienie świadczenia od okoliczności zależnych tylko od woli 
kontrahenta konsumenta; 
- 9) przyznają kontrahentowi konsumenta uprawnienia do dokonywania wiążącej 
interpretacji umowy; 
- 10) uprawniają kontrahenta konsumenta do jednostronnej zmiany umowy bez ważnej 
przyczyny wskazanej w tej umowie; 
- 11) przyznają tylko kontrahentowi konsumenta uprawnienie do stwierdzania 
zgodności świadczenia z umową; 
- 12) wyłączają obowiązek zwrotu konsumentowi uiszczonej zapłaty za świadczenie 
niespełnione w całości lub części, jeżeli konsument zrezygnuje z zawarcia 
umowy lub jej wykonania; 
- 13) przewidują utratę prawa żądania zwrotu świadczenia konsumenta spełnionego 
wcześniej niż świadczenie kontrahenta, gdy strony wypowiadają, rozwiązują lub 
odstępują od umowy; 
- 14) pozbawiają wyłącznie konsumenta uprawnienia do rozwiązania umowy, 
odstąpienia od niej lub jej wypowiedzenia; 
- 15) zastrzegają dla kontrahenta konsumenta uprawnienie wypowiedzenia umowy 
zawartej na czas nieoznaczony, bez wskazania ważnych przyczyn i stosownego 
terminu wypowiedzenia; 
- 16) nakładają wyłącznie na konsumenta obowiązek zapłaty ustalonej sumy na 
wypadek rezygnacji z zawarcia lub wykonania umowy; 
- 17) nakładają na konsumenta, który nie wykonał zobowiązania lub odstąpił od 
umowy, obowiązek zapłaty rażąco wygórowanej kary umownej lub odstępnego; 
- 18) stanowią, że umowa zawarta na czas oznaczony ulega przedłużeniu, o ile 
konsument, dla którego zastrzeżono rażąco krótki termin, nie złoży przeciwnego 
oświadczenia; 
- 19) przewidują wyłącznie dla kontrahenta konsumenta jednostronne uprawnienie do 
zmiany, bez ważnych przyczyn, istotnych cech świadczenia; 

©Kancelaria Sejmu 
 
 
 
s. 77/242 
 
   
 
2025-09-09 
- 20) przewidują 
uprawnienie 
kontrahenta 
konsumenta 
do 
określenia 
lub 
podwyższenia ceny lub wynagrodzenia po zawarciu umowy bez przyznania 
konsumentowi prawa odstąpienia od umowy; 
- 21) uzależniają 
odpowiedzialność 
kontrahenta 
konsumenta 
od 
wykonania 
zobowiązań przez osoby, za pośrednictwem których kontrahent konsumenta 
zawiera umowę lub przy których pomocy wykonuje swoje zobowiązanie, albo 
uzależniają tę odpowiedzialność od spełnienia przez konsumenta nadmiernie 
uciążliwych formalności; 
- 22) przewidują obowiązek wykonania zobowiązania przez konsumenta mimo 
niewykonania lub nienależytego wykonania zobowiązania przez jego 
kontrahenta; 
- 23) wyłączają jurysdykcję sądów polskich lub poddają sprawę pod rozstrzygnięcie 
sądu polubownego polskiego lub zagranicznego albo innego organu, a także 
narzucają rozpoznanie sprawy przez sąd, który wedle ustawy nie jest miejscowo 
właściwy.

***
## Art. 3854. {#art-3854}

§ 1. Umowa między przedsiębiorcami stosującymi różne wzorce 
umów nie obejmuje tych postanowień wzorców, które są ze sobą sprzeczne. 
§ 2. Umowa nie jest zawarta, gdy po otrzymaniu oferty strona niezwłocznie 
zawiadomi, że nie zamierza zawierać umowy na warunkach przewidzianych w § 1.

***
## Art. 3855. {#art-3855}

§ 1. Przepisy dotyczące konsumenta, zawarte w art. 3851–3853, 
stosuje się do osoby fizycznej zawierającej umowę bezpośrednio związaną z jej 
działalnością gospodarczą, gdy z treści tej umowy wynika, że nie posiada ona dla niej 
charakteru zawodowego, wynikającego w szczególności z przedmiotu wykonywanej 
przez nią działalności gospodarczej, udostępnionego na podstawie przepisów 
o Centralnej Ewidencji i Informacji o Działalności Gospodarczej. 
<§ 11. Jeżeli z treści umowy, która ma być zawarta, nie wynika, czy posiada 
ona charakter zawodowy dla osoby fizycznej, o której mowa w § 1, osoba ta 
najpóźniej w chwili zawarcia umowy może złożyć oświadczenie, że umowa 
posiada dla niej charakter zawodowy albo że nie posiada takiego charakteru. 
Druga strona umowy nie może jednak uzależnić zawarcia umowy od złożenia 
takiego oświadczenia.> 
§ 2. (uchylony) 
Dodany § 11 w 
art. 3855 wejdzie 
w życie z dn. 
27.11.2025 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 

©Kancelaria Sejmu 
 
 
 
s. 78/242 
 
   
 
2025-09-09

***
## Art. 386. {#art-386}

(uchylony)

***
## Art. 387. {#art-387}

§ 1. Umowa o świadczenie niemożliwe jest nieważna. 
§ 2. Strona, która w chwili zawarcia umowy wiedziała o niemożliwości 
świadczenia, a drugiej strony z błędu nie wyprowadziła, obowiązana jest do 
naprawienia szkody, którą druga strona poniosła przez to, że zawarła umowę nie 
wiedząc o niemożliwości świadczenia.

***
## Art. 3871. {#art-3871}

Nieważna jest umowa, w której osoba fizyczna zobowiązuje się do 
przeniesienia 
własności 
nieruchomości 
służącej 
zaspokojeniu 
jej 
potrzeb 
mieszkaniowych w celu zabezpieczenia roszczeń wynikających z tej lub innej umowy 
niezwiązanej bezpośrednio z działalnością gospodarczą lub zawodową tej osoby, 
w przypadku gdy: 
- 1) wartość nieruchomości jest wyższa niż wartość zabezpieczanych tą 
nieruchomością roszczeń pieniężnych powiększonych o wysokość odsetek 
maksymalnych za opóźnienie od tej wartości za okres 24 miesięcy lub 
- 2) wartość zabezpieczanych tą nieruchomością roszczeń pieniężnych nie jest 
oznaczona, lub 
- 3) zawarcie tej umowy nie zostało poprzedzone dokonaniem wyceny wartości 
rynkowej nieruchomości przez biegłego rzeczoznawcę.

***
## Art. 388. {#art-388}

§ 1. Jeżeli jedna ze stron, wyzyskując przymusowe położenie, 
niedołęstwo, niedoświadczenie lub brak dostatecznego rozeznania drugiej strony co 
do przedmiotu umowy, w zamian za swoje świadczenie przyjmuje albo zastrzega dla 
siebie lub dla osoby trzeciej świadczenie, którego wartość w chwili zawarcia umowy 
przewyższa w rażącym stopniu wartość jej własnego świadczenia, druga strona może 
według swego wyboru żądać zmniejszenia swego świadczenia lub zwiększenia 
należnego jej świadczenia albo unieważnienia umowy. 
§ 11. Jeżeli wartość świadczenia jednej ze stron w chwili zawarcia umowy 
przewyższa co najmniej dwukrotnie wartość świadczenia wzajemnego, domniemywa 
się, że przewyższa je w stopniu rażącym. 
§ 2. Uprawnienia określone w § 1 wygasają z upływem lat trzech od dnia 
zawarcia umowy, a jeżeli stroną umowy jest konsument – z upływem lat sześciu. 

©Kancelaria Sejmu 
 
 
 
s. 79/242 
 
   
 
2025-09-09

***
## Art. 389. {#art-389}

§ 1. Umowa, przez którą jedna ze stron lub obie zobowiązują się do 
zawarcia oznaczonej umowy (umowa przedwstępna), powinna określać istotne 
postanowienia umowy przyrzeczonej. 
§ 2. Jeżeli termin, w ciągu którego ma być zawarta umowa przyrzeczona, nie 
został oznaczony, powinna ona być zawarta w odpowiednim terminie wyznaczonym 
przez stronę uprawnioną do żądania zawarcia umowy przyrzeczonej. Jeżeli obie strony 
są uprawnione do żądania zawarcia umowy przyrzeczonej i każda z nich wyznaczyła 
inny termin, strony wiąże termin wyznaczony przez stronę, która wcześniej złożyła 
stosowne oświadczenie. Jeżeli w ciągu roku od dnia zawarcia umowy przedwstępnej 
nie został wyznaczony termin do zawarcia umowy przyrzeczonej, nie można żądać jej 
zawarcia.

***
## Art. 390. {#art-390}

§ 1. Jeżeli strona zobowiązana do zawarcia umowy przyrzeczonej 
uchyla się od jej zawarcia, druga strona może żądać naprawienia szkody, którą 
poniosła przez to, że liczyła na zawarcie umowy przyrzeczonej. Strony mogą 
w umowie przedwstępnej odmiennie określić zakres odszkodowania. 
§ 2. Jednakże gdy umowa przedwstępna czyni zadość wymaganiom, od których 
zależy ważność umowy przyrzeczonej, w szczególności wymaganiom co do formy, 
strona uprawniona może dochodzić zawarcia umowy przyrzeczonej. 
§ 3. Roszczenia z umowy przedwstępnej przedawniają się z upływem roku od 
dnia, w którym umowa przyrzeczona miała być zawarta. Jeżeli sąd oddali żądanie 
zawarcia umowy przyrzeczonej, roszczenia z umowy przedwstępnej przedawniają się 
z upływem roku od dnia, w którym orzeczenie stało się prawomocne.

***
## Art. 391. {#art-391}

Jeżeli w umowie zastrzeżono, że osoba trzecia zaciągnie określone 
zobowiązanie albo spełni określone świadczenie, ten, kto takie przyrzeczenie uczynił, 
odpowiedzialny jest za szkodę, którą druga strona ponosi przez to, że osoba trzecia 
odmawia zaciągnięcia zobowiązania albo nie spełnia świadczenia. Może jednak 
zwolnić się od obowiązku naprawienia szkody spełniając przyrzeczone świadczenie, 
chyba że sprzeciwia się to umowie lub właściwości świadczenia.

***
## Art. 392. {#art-392}

Jeżeli osoba trzecia zobowiązała się przez umowę z dłużnikiem 
zwolnić go od obowiązku świadczenia, jest ona odpowiedzialna względem dłużnika 
za to, że wierzyciel nie będzie od niego żądał spełnienia świadczenia. 

©Kancelaria Sejmu 
 
 
 
s. 80/242 
 
   
 
2025-09-09

***
## Art. 393. {#art-393}

§ 1. Jeżeli w umowie zastrzeżono, że dłużnik spełni świadczenie na 
rzecz osoby trzeciej, osoba ta, w braku odmiennego postanowienia umowy, może 
żądać bezpośrednio od dłużnika spełnienia zastrzeżonego świadczenia. 
§ 2. Zastrzeżenie co do obowiązku świadczenia na rzecz osoby trzeciej nie może 
być odwołane ani zmienione, jeżeli osoba trzecia oświadczyła którejkolwiek ze stron, 
że chce z zastrzeżenia skorzystać. 
§ 3. Dłużnik może podnieść zarzuty z umowy także przeciwko osobie trzeciej.

***
## Art. 394. {#art-394}

§ 1. W braku odmiennego zastrzeżenia umownego albo zwyczaju 
zadatek dany przy zawarciu umowy ma to znaczenie, że w razie niewykonania umowy 
przez jedną ze stron druga strona może bez wyznaczenia terminu dodatkowego od 
umowy odstąpić i otrzymany zadatek zachować, a jeżeli sama go dała, może żądać 
sumy dwukrotnie wyższej. 
§ 2. W razie wykonania umowy zadatek ulega zaliczeniu na poczet świadczenia 
strony, która go dała; jeżeli zaliczenie nie jest możliwe, zadatek ulega zwrotowi. 
§ 3. W razie rozwiązania umowy zadatek powinien być zwrócony, a obowiązek 
zapłaty sumy dwukrotnie wyższej odpada. To samo dotyczy wypadku, gdy 
niewykonanie umowy nastąpiło wskutek okoliczności, za które żadna ze stron nie 
ponosi odpowiedzialności albo za które ponoszą odpowiedzialność obie strony.

***
## Art. 395. {#art-395}

§ 1. Można zastrzec, że jednej lub obu stronom przysługiwać będzie 
w ciągu oznaczonego terminu prawo odstąpienia od umowy. Prawo to wykonywa się 
przez oświadczenie złożone drugiej stronie. 
§ 2. W razie wykonania prawa odstąpienia umowa uważana jest za niezawartą. 
To, co strony już świadczyły, ulega zwrotowi w stanie niezmienionym, chyba że 
zmiana była konieczna w granicach zwykłego zarządu. Za świadczone usługi oraz za 
korzystanie z rzeczy należy się drugiej stronie odpowiednie wynagrodzenie.

***
## Art. 396. {#art-396}

Jeżeli zostało zastrzeżone, że jednej lub obu stronom wolno od umowy 
odstąpić za zapłatą oznaczonej sumy (odstępne), oświadczenie o odstąpieniu jest 
skuteczne tylko wtedy, gdy zostało złożone jednocześnie z zapłatą odstępnego. 
TYTUŁ IV 
(zawierający art. 397–404 – uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 81/242 
 
   
 
2025-09-09 
 
TYTUŁ V 
Bezpodstawne wzbogacenie

***
## Art. 405. {#art-405}

Kto bez podstawy prawnej uzyskał korzyść majątkową kosztem innej 
osoby, obowiązany jest do wydania korzyści w naturze, a gdyby to nie było możliwe, 
do zwrotu jej wartości.

***
## Art. 406. {#art-406}

Obowiązek wydania korzyści obejmuje nie tylko korzyść bezpośrednio 
uzyskaną, lecz także wszystko, co w razie zbycia, utraty lub uszkodzenia zostało 
uzyskane w zamian tej korzyści albo jako naprawienie szkody.

***
## Art. 407. {#art-407}

Jeżeli ten, kto bez podstawy prawnej uzyskał korzyść majątkową 
kosztem innej osoby, rozporządził korzyścią na rzecz osoby trzeciej bezpłatnie, 
obowiązek wydania korzyści przechodzi na tę osobę trzecią.

***
## Art. 408. {#art-408}

§ 1. Zobowiązany do wydania korzyści może żądać zwrotu nakładów 
koniecznych o tyle, o ile nie znalazły pokrycia w użytku, który z nich osiągnął. Zwrotu 
innych nakładów może żądać o tyle, o ile zwiększają wartość korzyści w chwili jej 
wydania; może jednak zabrać te nakłady, przywracając stan poprzedni. 
§ 2. Kto czyniąc nakłady wiedział, że korzyść mu się nie należy, ten może żądać 
zwrotu nakładów tylko o tyle, o ile zwiększają wartość korzyści w chwili jej wydania. 
§ 3. Jeżeli żądający wydania korzyści jest zobowiązany do zwrotu nakładów, sąd 
może zamiast wydania korzyści w naturze nakazać zwrot jej wartości w pieniądzu 
z odliczeniem wartości nakładów, które żądający byłby obowiązany zwrócić.

***
## Art. 409. {#art-409}

Obowiązek wydania korzyści lub zwrotu jej wartości wygasa, jeżeli 
ten, kto korzyść uzyskał, zużył ją lub utracił w taki sposób, że nie jest już wzbogacony, 
chyba że wyzbywając się korzyści lub zużywając ją powinien był liczyć się 
z obowiązkiem zwrotu.

***
## Art. 410. {#art-410}

§ 1. Przepisy artykułów poprzedzających stosuje się w szczególności 
do świadczenia nienależnego. 
§ 2. Świadczenie jest nienależne, jeżeli ten, kto je spełnił, nie był w ogóle 
zobowiązany lub nie był zobowiązany względem osoby, której świadczył, albo jeżeli 
podstawa świadczenia odpadła lub zamierzony cel świadczenia nie został osiągnięty, 
albo jeżeli czynność prawna zobowiązująca do świadczenia była nieważna i nie stała 
się ważna po spełnieniu świadczenia. 

©Kancelaria Sejmu 
 
 
 
s. 82/242 
 
   
 
2025-09-09

***
## Art. 411. {#art-411}

Nie można żądać zwrotu świadczenia: 
- 1) jeżeli spełniający świadczenie wiedział, że nie był do świadczenia zobowiązany, 
chyba że spełnienie świadczenia nastąpiło z zastrzeżeniem zwrotu albo w celu 
uniknięcia przymusu lub w wykonaniu nieważnej czynności prawnej; 
- 2) jeżeli spełnienie świadczenia czyni zadość zasadom współżycia społecznego; 
- 3) jeżeli świadczenie zostało spełnione w celu zadośćuczynienia przedawnionemu 
roszczeniu; 
- 4) jeżeli świadczenie zostało spełnione, zanim wierzytelność stała się wymagalna.

***
## Art. 412. {#art-412}

Sąd może orzec przepadek świadczenia na rzecz Skarbu Państwa, 
jeżeli świadczenie to zostało świadomie spełnione w zamian za dokonanie czynu 
zabronionego przez ustawę lub w celu niegodziwym. Jeżeli przedmiot świadczenia 
został zużyty lub utracony, przepadkowi może ulec jego wartość.

***
## Art. 413. {#art-413}

§ 1. Kto spełnia świadczenie z gry lub zakładu, nie może żądać zwrotu, 
chyba że gra lub zakład były zakazane albo nierzetelne. 
§ 2. Roszczeń z gry lub zakładu można dochodzić tylko wtedy, gdy gra lub 
zakład były prowadzone na podstawie zezwolenia właściwego organu państwowego.

***
## Art. 414. {#art-414}

Przepisy niniejszego tytułu nie uchybiają przepisom o obowiązku 
naprawienia szkody. 
TYTUŁ VI 
Czyny niedozwolone

***
## Art. 415. {#art-415}

Kto z winy swej wyrządził drugiemu szkodę, obowiązany jest do jej 
naprawienia.

***
## Art. 416. {#art-416}

Osoba prawna jest obowiązana do naprawienia szkody wyrządzonej 
z winy jej organu.

***
## Art. 417. {#art-417}

§ 1. Za szkodę wyrządzoną przez niezgodne z prawem działanie 
lub zaniechanie przy wykonywaniu władzy publicznej ponosi odpowiedzialność 
Skarb Państwa lub jednostka samorządu terytorialnego lub inna osoba prawna 
wykonująca tę władzę z mocy prawa. 
§ 2. Jeżeli wykonywanie zadań z zakresu władzy publicznej zlecono, 
na podstawie porozumienia, jednostce samorządu terytorialnego albo innej osobie 

©Kancelaria Sejmu 
 
 
 
s. 83/242 
 
   
 
2025-09-09 
 
prawnej, solidarną odpowiedzialność za wyrządzoną szkodę ponosi ich wykonawca 
oraz zlecająca je jednostka samorządu terytorialnego albo Skarb Państwa.

***
## Art. 4171. {#art-4171}

§ 1. Jeżeli szkoda została wyrządzona przez wydanie aktu 
normatywnego, jej naprawienia można żądać po stwierdzeniu we właściwym 
postępowaniu niezgodności tego aktu z Konstytucją, ratyfikowaną umową 
międzynarodową lub ustawą. 
§ 2. Jeżeli szkoda została wyrządzona przez wydanie prawomocnego orzeczenia 
lub ostatecznej decyzji, jej naprawienia można żądać po stwierdzeniu we właściwym 
postępowaniu ich niezgodności z prawem, chyba że przepisy odrębne stanowią 
inaczej. Odnosi się to również do wypadku, gdy prawomocne orzeczenie lub 
ostateczna decyzja zostały wydane na podstawie aktu normatywnego niezgodnego 
z Konstytucją, ratyfikowaną umową międzynarodową lub ustawą. 
§ 3. Jeżeli szkoda została wyrządzona przez niewydanie orzeczenia lub decyzji, 
gdy obowiązek ich wydania przewiduje przepis prawa, jej naprawienia można żądać 
po stwierdzeniu we właściwym postępowaniu niezgodności z prawem niewydania 
orzeczenia lub decyzji, chyba że przepisy odrębne stanowią inaczej. 
§ 4. Jeżeli szkoda została wyrządzona przez niewydanie aktu normatywnego, 
którego obowiązek wydania przewiduje przepis prawa, niezgodność z prawem 
niewydania tego aktu stwierdza sąd rozpoznający sprawę o naprawienie szkody.

***
## Art. 4172. {#art-4172}

Jeżeli przez zgodne z prawem wykonywanie władzy publicznej 
została wyrządzona szkoda na osobie, poszkodowany może żądać całkowitego lub 
częściowego jej naprawienia oraz zadośćuczynienia pieniężnego za doznaną krzywdę, 
gdy okoliczności, a zwłaszcza niezdolność poszkodowanego do pracy lub jego ciężkie 
położenie materialne, wskazują, że wymagają tego względy słuszności.

***
## Art. 418. {#art-418}

(utracił moc)3)

***
## Art. 419. {#art-419}

(uchylony)

***
## Art. 420. {#art-420}

(uchylony)

***
## Art. 4201. {#art-4201}

(uchylony)

***
## Art. 4202. {#art-4202}

(uchylony) 
- 3) Z dniem 18 grudnia 2001 r. na podstawie wyroku Trybunału Konstytucyjnego z dnia 4 grudnia 
2001 r. sygn. akt SK. 18/2000 (Dz. U. poz. 1638). 

©Kancelaria Sejmu 
 
 
 
s. 84/242 
 
   
 
2025-09-09

***
## Art. 421. {#art-421}

Przepisów art. 417, art. 4171 i art. 4172 nie stosuje się, jeżeli 
odpowiedzialność za szkodę wyrządzoną przy wykonywaniu władzy publicznej jest 
uregulowana w przepisach szczególnych.

***
## Art. 422. {#art-422}

Za szkodę odpowiedzialny jest nie tylko ten, kto ją bezpośrednio 
wyrządził, lecz także ten, kto inną osobę do wyrządzenia szkody nakłonił albo był jej 
pomocny, jak również ten, kto świadomie skorzystał z wyrządzonej drugiemu szkody.

***
## Art. 423. {#art-423}

Kto działa w obronie koniecznej, odpierając bezpośredni i bezprawny 
zamach na jakiekolwiek dobro własne lub innej osoby, ten nie jest odpowiedzialny za 
szkodę wyrządzoną napastnikowi.

***
## Art. 424. {#art-424}

Kto zniszczył lub uszkodził cudzą rzecz albo zabił lub zranił cudze 
zwierzę w celu odwrócenia od siebie lub od innych niebezpieczeństwa grożącego 
bezpośrednio od tej rzeczy lub zwierzęcia, ten nie jest odpowiedzialny za wynikłą stąd 
szkodę, jeżeli niebezpieczeństwa sam nie wywołał, a niebezpieczeństwu nie można 
było inaczej zapobiec i jeżeli ratowane dobro jest oczywiście ważniejsze aniżeli dobro 
naruszone.

***
## Art. 425. {#art-425}

§ 1. Osoba, która z jakichkolwiek powodów znajduje się w stanie 
wyłączającym świadome albo swobodne powzięcie decyzji i wyrażenie woli, nie jest 
odpowiedzialna za szkodę w tym stanie wyrządzoną. 
§ 2. Jednakże kto uległ zakłóceniu czynności psychicznych wskutek użycia 
napojów odurzających albo innych podobnych środków, ten obowiązany jest do 
naprawienia szkody, chyba że stan zakłócenia został wywołany bez jego winy.

***
## Art. 426. {#art-426}

Małoletni, 
który 
nie 
ukończył 
lat 
trzynastu, 
nie 
ponosi 
odpowiedzialności za wyrządzoną szkodę.

***
## Art. 427. {#art-427}

Kto z mocy ustawy lub umowy jest zobowiązany do nadzoru nad 
osobą, której z powodu wieku albo stanu psychicznego lub cielesnego winy poczytać 
nie można, ten obowiązany jest do naprawienia szkody wyrządzonej przez tę osobę, 
chyba że uczynił zadość obowiązkowi nadzoru albo że szkoda byłaby powstała także 
przy starannym wykonywaniu nadzoru. Przepis ten stosuje się również do osób 
wykonywających bez obowiązku ustawowego ani umownego stałą pieczę nad osobą, 
której z powodu wieku albo stanu psychicznego lub cielesnego winy poczytać nie 
można. 

©Kancelaria Sejmu 
 
 
 
s. 85/242 
 
   
 
2025-09-09

***
## Art. 428. {#art-428}

Gdy sprawca z powodu wieku albo stanu psychicznego lub cielesnego 
nie jest odpowiedzialny za szkodę, a brak jest osób zobowiązanych do nadzoru albo 
gdy nie można od nich uzyskać naprawienia szkody, poszkodowany może żądać 
całkowitego lub częściowego naprawienia szkody od samego sprawcy, jeżeli 
z okoliczności, a zwłaszcza z porównania stanu majątkowego poszkodowanego 
i sprawcy, wynika, że wymagają tego zasady współżycia społecznego.

***
## Art. 429. {#art-429}

Kto powierza wykonanie czynności drugiemu, ten jest odpowiedzialny 
za szkodę wyrządzoną przez sprawcę przy wykonywaniu powierzonej mu czynności, 
chyba że nie ponosi winy w wyborze albo że wykonanie czynności powierzył osobie, 
przedsiębiorstwu lub zakładowi, które w zakresie swej działalności zawodowej 
trudnią się wykonywaniem takich czynności.

***
## Art. 430. {#art-430}

Kto na własny rachunek powierza wykonanie czynności osobie, która 
przy wykonywaniu tej czynności podlega jego kierownictwu i ma obowiązek 
stosować się do jego wskazówek, ten jest odpowiedzialny za szkodę wyrządzoną 
z winy tej osoby przy wykonywaniu powierzonej jej czynności.

***
## Art. 431. {#art-431}

§ 1. Kto zwierzę chowa albo się nim posługuje, obowiązany jest do 
naprawienia wyrządzonej przez nie szkody niezależnie od tego, czy było pod jego 
nadzorem, czy też zabłąkało się lub uciekło, chyba że ani on, ani osoba, za którą ponosi 
odpowiedzialność, nie ponoszą winy. 
§ 2. Chociażby osoba, która zwierzę chowa lub się nim posługuje, nie była 
odpowiedzialna według przepisów paragrafu poprzedzającego, poszkodowany może 
od niej żądać całkowitego lub częściowego naprawienia szkody, jeżeli z okoliczności, 
a zwłaszcza z porównania stanu majątkowego poszkodowanego i tej osoby, wynika, 
że wymagają tego zasady współżycia społecznego.

***
## Art. 432. {#art-432}

§ 1. Posiadacz gruntu może zająć cudze zwierzę, które wyrządza 
szkodę na gruncie, jeżeli zajęcie jest potrzebne do zabezpieczenia roszczenia 
o naprawienie szkody. 
§ 2. Na zajętym zwierzęciu posiadacz gruntu uzyskuje ustawowe prawo zastawu 
dla zabezpieczenia należnego mu naprawienia szkody oraz kosztów żywienia 
i utrzymania zwierzęcia. 
§ 3. (uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 86/242 
 
   
 
2025-09-09

***
## Art. 433. {#art-433}

Za szkodę wyrządzoną wyrzuceniem, wylaniem lub spadnięciem 
jakiegokolwiek przedmiotu z pomieszczenia jest odpowiedzialny ten, kto 
pomieszczenie zajmuje, chyba że szkoda nastąpiła wskutek siły wyższej albo 
wyłącznie z winy poszkodowanego lub osoby trzeciej, za którą zajmujący 
pomieszczenie nie ponosi odpowiedzialności i której działaniu nie mógł zapobiec.

***
## Art. 434. {#art-434}

Za szkodę wyrządzoną przez zawalenie się budowli lub oderwanie się 
jej części odpowiedzialny jest samoistny posiadacz budowli, chyba że zawalenie się 
budowli lub oderwanie się jej części nie wynikło ani z braku utrzymania budowli 
w należytym stanie, ani z wady w budowie.

***
## Art. 435. {#art-435}

§ 1. Prowadzący na własny rachunek przedsiębiorstwo lub zakład 
wprawiany w ruch za pomocą sił przyrody (pary, gazu, elektryczności, paliw płynnych 
itp.) ponosi odpowiedzialność za szkodę na osobie lub mieniu, wyrządzoną 
komukolwiek przez ruch przedsiębiorstwa lub zakładu, chyba że szkoda nastąpiła 
wskutek siły wyższej albo wyłącznie z winy poszkodowanego lub osoby trzeciej, za 
którą nie ponosi odpowiedzialności. 
§ 2. Przepis powyższy stosuje się odpowiednio do przedsiębiorstw lub zakładów 
wytwarzających środki wybuchowe albo posługujących się takimi środkami.

***
## Art. 436. {#art-436}

§ 1. Odpowiedzialność przewidzianą w artykule poprzedzającym 
ponosi również samoistny posiadacz mechanicznego środka komunikacji poruszanego 
za pomocą sił przyrody. Jednakże gdy posiadacz samoistny oddał środek komunikacji 
w posiadanie zależne, odpowiedzialność ponosi posiadacz zależny. 
§ 2. W razie zderzenia się mechanicznych środków komunikacji poruszanych za 
pomocą sił przyrody wymienione osoby mogą wzajemnie żądać naprawienia 
poniesionych szkód tylko na zasadach ogólnych. Również tylko na zasadach ogólnych 
osoby te są odpowiedzialne za szkody wyrządzone tym, których przewożą 
z grzeczności.

***
## Art. 437. {#art-437}

Nie można wyłączyć ani ograniczyć z góry odpowiedzialności 
określonej w dwóch artykułach poprzedzających.

***
## Art. 438. {#art-438}

Kto w celu odwrócenia grożącej drugiemu szkody albo w celu 
odwrócenia wspólnego niebezpieczeństwa przymusowo lub nawet dobrowolnie 
poniósł szkodę majątkową, może żądać naprawienia poniesionych strat w 
odpowiednim stosunku od osób, które z tego odniosły korzyść. 

©Kancelaria Sejmu 
 
 
 
s. 87/242 
 
   
 
2025-09-09

***
## Art. 439. {#art-439}

Ten, komu wskutek zachowania się innej osoby, w szczególności 
wskutek braku należytego nadzoru nad ruchem kierowanego przez nią 
przedsiębiorstwa lub zakładu albo nad stanem posiadanego przez nią budynku lub 
innego urządzenia, zagraża bezpośrednio szkoda, może żądać, ażeby osoba ta 
przedsięwzięła środki niezbędne do odwrócenia grożącego niebezpieczeństwa, 
a w razie potrzeby także, by dała odpowiednie zabezpieczenie.

***
## Art. 440. {#art-440}

W stosunkach między osobami fizycznymi zakres obowiązku 
naprawienia szkody może być stosownie do okoliczności ograniczony, jeżeli ze 
względu na stan majątkowy poszkodowanego lub osoby odpowiedzialnej za szkodę 
wymagają takiego ograniczenia zasady współżycia społecznego.

***
## Art. 441. {#art-441}

§ 1. Jeżeli kilka osób ponosi odpowiedzialność za szkodę wyrządzoną 
czynem niedozwolonym, ich odpowiedzialność jest solidarna. 
§ 2. Jeżeli szkoda była wynikiem działania lub zaniechania kilku osób, ten, kto 
szkodę naprawił, może żądać od pozostałych zwrotu odpowiedniej części zależnie od 
okoliczności, a zwłaszcza od winy danej osoby oraz od stopnia, w jakim przyczyniła 
się do powstania szkody. 
§ 3. Ten, kto naprawił szkodę, za którą jest odpowiedzialny mimo braku winy, 
ma zwrotne roszczenie do sprawcy, jeżeli szkoda powstała z winy sprawcy.

***
## Art. 442. {#art-442}

(uchylony)

***
## Art. 4421. {#art-4421}

§ 1. Roszczenie o naprawienie szkody wyrządzonej czynem 
niedozwolonym ulega przedawnieniu z upływem lat trzech od dnia, w którym 
poszkodowany dowiedział się albo przy zachowaniu należytej staranności mógł się 
dowiedzieć o szkodzie i o osobie obowiązanej do jej naprawienia. Jednakże termin ten 
nie może być dłuższy niż dziesięć lat od dnia, w którym nastąpiło zdarzenie 
wywołujące szkodę. 
§ 2. Jeżeli szkoda wynikła ze zbrodni lub występku, roszczenie o naprawienie 
szkody ulega przedawnieniu z upływem lat dwudziestu od dnia popełnienia 
przestępstwa bez względu na to, kiedy poszkodowany dowiedział się o szkodzie 
i o osobie obowiązanej do jej naprawienia. 
§ 3. W razie wyrządzenia szkody na osobie, przedawnienie nie może skończyć 
się wcześniej niż z upływem lat trzech od dnia, w którym poszkodowany dowiedział 
się o szkodzie i o osobie obowiązanej do jej naprawienia. 

©Kancelaria Sejmu 
 
 
 
s. 88/242 
 
   
 
2025-09-09 
 
§ 4. Przedawnienie roszczeń osoby małoletniej o naprawienie szkody na osobie 
nie może skończyć się wcześniej niż z upływem lat dwóch od uzyskania przez nią 
pełnoletności.

***
## Art. 443. {#art-443}

Okoliczność, że działanie lub zaniechanie, z którego szkoda wynikła, 
stanowiło niewykonanie lub nienależyte wykonanie istniejącego uprzednio 
zobowiązania, nie wyłącza roszczenia o naprawienie szkody z tytułu czynu nie-
dozwolonego, chyba że z treści istniejącego uprzednio zobowiązania wynika co 
innego.

***
## Art. 444. {#art-444}

§ 1. W razie uszkodzenia ciała lub wywołania rozstroju zdrowia 
naprawienie szkody obejmuje wszelkie wynikłe z tego powodu koszty. Na żądanie 
poszkodowanego zobowiązany do naprawienia szkody powinien wyłożyć z góry sumę 
potrzebną na koszty leczenia, a jeżeli poszkodowany stał się inwalidą, także sumę 
potrzebną na koszty przygotowania do innego zawodu. 
§ 2. Jeżeli poszkodowany utracił całkowicie lub częściowo zdolność do pracy 
zarobkowej albo jeżeli zwiększyły się jego potrzeby lub zmniejszyły widoki 
powodzenia na przyszłość, może on żądać od zobowiązanego do naprawienia szkody 
odpowiedniej renty. 
§ 3. Jeżeli w chwili wydania wyroku szkody nie da się dokładnie ustalić, 
poszkodowanemu może być przyznana renta tymczasowa.

***
## Art. 445. {#art-445}

§ 1. W wypadkach przewidzianych w artykule poprzedzającym sąd 
może przyznać poszkodowanemu odpowiednią sumę tytułem zadośćuczynienia 
pieniężnego za doznaną krzywdę. 
§ 2. Przepis powyższy stosuje się również w wypadku pozbawienia wolności 
oraz w wypadku skłonienia za pomocą podstępu, gwałtu lub nadużycia stosunku 
zależności do poddania się czynowi nierządnemu. 
§ 3. Roszczenie o zadośćuczynienie przechodzi na spadkobierców tylko wtedy, 
gdy zostało uznane na piśmie albo gdy powództwo zostało wytoczone za życia 
poszkodowanego.

***
## Art. 446. {#art-446}

§ 1. Jeżeli wskutek uszkodzenia ciała lub wywołania rozstroju zdrowia 
nastąpiła śmierć poszkodowanego, zobowiązany do naprawienia szkody powinien 
zwrócić koszty leczenia i pogrzebu temu, kto je poniósł. 

©Kancelaria Sejmu 
 
 
 
s. 89/242 
 
   
 
2025-09-09 
 
§ 2. Osoba, względem której ciążył na zmarłym ustawowy obowiązek 
alimentacyjny, może żądać od zobowiązanego do naprawienia szkody renty obliczonej 
stosownie do potrzeb poszkodowanego oraz do możliwości zarobkowych i mająt-
kowych zmarłego przez czas prawdopodobnego trwania obowiązku alimentacyjnego. 
Takiej samej renty mogą żądać inne osoby bliskie, którym zmarły dobrowolnie i stale 
dostarczał środków utrzymania, jeżeli z okoliczności wynika, że wymagają tego 
zasady współżycia społecznego. 
§ 3. Sąd może ponadto przyznać najbliższym członkom rodziny zmarłego 
stosowne odszkodowanie, jeżeli wskutek jego śmierci nastąpiło znaczne pogorszenie 
ich sytuacji życiowej. 
§ 4. Sąd może także przyznać najbliższym członkom rodziny zmarłego 
odpowiednią sumę tytułem zadośćuczynienia pieniężnego za doznaną krzywdę.

***
## Art. 4461. {#art-4461}

- 4) Z chwilą urodzenia dziecko może żądać naprawienia szkód 
doznanych przed urodzeniem.

***
## Art. 4462. {#art-4462}

W razie ciężkiego i trwałego uszkodzenia ciała lub wywołania 
rozstroju zdrowia, skutkującego niemożnością nawiązania lub kontynuowania więzi 
rodzinnej, sąd może przyznać najbliższym członkom rodziny poszkodowanego 
odpowiednią sumę tytułem zadośćuczynienia pieniężnego za doznaną krzywdę.

***
## Art. 447. {#art-447}

Z ważnych powodów sąd może na żądanie poszkodowanego przyznać 
mu zamiast renty lub jej części odszkodowanie jednorazowe. Dotyczy to 
w szczególności wypadku, gdy poszkodowany stał się inwalidą, a przyznanie jedno-
razowego odszkodowania ułatwi mu wykonywanie nowego zawodu.

***
## Art. 448. {#art-448}

§ 1. W razie naruszenia dobra osobistego sąd może przyznać temu, 
czyje dobro osobiste zostało naruszone, odpowiednią sumę tytułem zadośćuczynienia 
pieniężnego za doznaną krzywdę albo zasądzić odpowiednią sumę pieniężną na 
wskazany przez niego cel społeczny, niezależnie od innych środków potrzebnych do 
usunięcia skutków naruszenia. 
- 4) Zdanie drugie utraciło moc z dniem 23 grudnia 1997 r. na podstawie obwieszczenia Prezesa 
Trybunału Konstytucyjnego z dnia 18 grudnia 1997 r. o utracie mocy obowiązującej art. 1 pkt 2, 
art. 1 pkt 5, art. 2 pkt 2, art. 3 pkt 1 i art. 3 pkt 4 ustawy o zmianie ustawy o planowaniu rodziny, 
ochronie płodu ludzkiego i warunkach dopuszczalności przerywania ciąży oraz o zmianie 
niektórych innych ustaw (Dz. U. poz. 1040). 

©Kancelaria Sejmu 
 
 
 
s. 90/242 
 
   
 
2025-09-09 
 
§ 2. W przypadkach określonych w art. 445 § 1 i 2 oraz art. 4462 ten, czyje dobro 
osobiste zostało naruszone, może obok zadośćuczynienia pieniężnego żądać 
zasądzenia odpowiedniej sumy na wskazany przez niego cel społeczny. 
§ 3. Do roszczeń, o których mowa w § 1 i 2, przepis art. 445 § 3 stosuje się.

***
## Art. 449. {#art-449}

Roszczenia przewidziane w art. 444–448 nie mogą być zbyte, chyba że 
są już wymagalne i że zostały uznane na piśmie albo przyznane prawomocnym 
orzeczeniem. 
TYTUŁ VI1 
Odpowiedzialność za szkodę wyrządzoną przez produkt niebezpieczny

***
## Art. 4491. {#art-4491}

§ 1. Kto wytwarza w zakresie swojej działalności gospodarczej 
(producent) produkt niebezpieczny, odpowiada za szkodę wyrządzoną komukolwiek 
przez ten produkt. 
§ 2. Przez produkt rozumie się rzecz ruchomą, choćby została ona połączona 
z inną rzeczą. Za produkt uważa się także zwierzęta i energię elektryczną. 
§ 3. Niebezpieczny jest produkt niezapewniający bezpieczeństwa, jakiego można 
oczekiwać, uwzględniając normalne użycie produktu. O tym, czy produkt jest 
bezpieczny, decydują okoliczności z chwili wprowadzenia go do obrotu, a zwłaszcza 
sposób zaprezentowania go na rynku oraz podane konsumentowi informacje 
o właściwościach produktu. Produkt nie może być uznany za niezapewniający 
bezpieczeństwa tylko dlatego, że później wprowadzono do obrotu podobny produkt 
ulepszony.

***
## Art. 4492. {#art-4492}

Producent odpowiada za szkodę na mieniu tylko wówczas, gdy rzecz 
zniszczona lub uszkodzona należy do rzeczy zwykle przeznaczanych do osobistego 
użytku i w taki przede wszystkim sposób korzystał z niej poszkodowany.

***
## Art. 4493. {#art-4493}

§ 1. Producent nie odpowiada za szkodę wyrządzoną przez produkt 
niebezpieczny, jeżeli produktu nie wprowadził do obrotu albo gdy wprowadzenie 
produktu do obrotu nastąpiło poza zakresem jego działalności gospodarczej. 
§ 2. Producent nie odpowiada również wtedy, gdy właściwości niebezpieczne 
produktu ujawniły się po wprowadzeniu go do obrotu, chyba że wynikały one 
z przyczyny tkwiącej poprzednio w produkcie. Nie odpowiada on także wtedy, gdy 
nie można było przewidzieć niebezpiecznych właściwości produktu, uwzględniając 

©Kancelaria Sejmu 
 
 
 
s. 91/242 
 
   
 
2025-09-09 
 
stan nauki i techniki w chwili wprowadzenia produktu do obrotu, albo gdy 
właściwości te wynikały z zastosowania przepisów prawa.

***
## Art. 4494. {#art-4494}

Domniemywa się, że produkt niebezpieczny, który spowodował 
szkodę, został wytworzony i wprowadzony do obrotu w zakresie działalności 
gospodarczej producenta.

***
## Art. 4495. {#art-4495}

§ 1. Wytwórca materiału, surowca albo części składowej produktu 
odpowiada tak jak producent, chyba że wyłączną przyczyną szkody była wadliwa 
konstrukcja produktu lub wskazówki producenta. 
§ 2. Kto przez umieszczenie na produkcie swojej nazwy, znaku towarowego lub 
innego oznaczenia odróżniającego podaje się za producenta, odpowiada jak producent. 
Tak samo odpowiada ten, kto produkt pochodzenia zagranicznego wprowadza do 
obrotu krajowego w zakresie swojej działalności gospodarczej (importer). 
§ 3. Producent oraz osoby wymienione w paragrafach poprzedzających 
odpowiadają solidarnie. 
§ 4. Jeżeli nie wiadomo, kto jest producentem lub osobą określoną w § 2, 
odpowiada ten, kto w zakresie swojej działalności gospodarczej zbył produkt 
niebezpieczny, chyba że w ciągu miesiąca od daty zawiadomienia o szkodzie wskaże 
poszkodowanemu osobę i adres producenta lub osoby określonej w § 2 zdanie 
pierwsze, a w wypadku towaru importowanego – osobę i adres importera. 
§ 5. Jeżeli zbywca produktu nie może wskazać producenta ani osób określonych 
w § 4, zwalnia go od odpowiedzialności wskazanie osoby, od której sam nabył 
produkt.

***
## Art. 4496. {#art-4496}

Jeżeli za szkodę wyrządzoną przez produkt niebezpieczny odpowiada 
także osoba trzecia, odpowiedzialność tej osoby i osób wymienionych w artykułach 
poprzedzających jest solidarna. Przepisy art. 441 § 2 i 3 stosuje się odpowiednio.

***
## Art. 4497. {#art-4497}

§ 1. Odszkodowanie za szkodę na mieniu nie obejmuje uszkodzenia 
samego produktu ani korzyści, jakie poszkodowany mógłby osiągnąć w związku 
z jego używaniem. 
§ 2. Odszkodowanie na podstawie art. 4491 nie przysługuje, gdy szkoda na 
mieniu nie przekracza kwoty będącej równowartością 500 euro.

***
## Art. 4498. {#art-4498}

Roszczenie o naprawienie szkody wyrządzonej przez produkt 
niebezpieczny ulega przedawnieniu z upływem lat trzech od dnia, w którym 

©Kancelaria Sejmu 
 
 
 
s. 92/242 
 
   
 
2025-09-09 
 
poszkodowany dowiedział się lub przy zachowaniu należytej staranności mógł się 
dowiedzieć o szkodzie i osobie obowiązanej do jej naprawienia. Jednak w każdym 
wypadku roszczenie przedawnia się z upływem lat dziesięciu od wprowadzenia 
produktu do obrotu.

***
## Art. 4499. {#art-4499}

Odpowiedzialności 
za 
szkodę 
wyrządzoną 
przez 
produkt 
niebezpieczny nie można wyłączyć ani ograniczyć.

***
## Art. 44910. {#art-44910}

Przepisy o odpowiedzialności za szkodę wyrządzoną przez produkt 
niebezpieczny nie wyłączają odpowiedzialności za szkody na zasadach ogólnych, za 
szkody wynikłe z niewykonania lub nienależytego wykonania zobowiązania oraz 
odpowiedzialności z tytułu rękojmi za wady i gwarancji jakości.

***
## Art. 44911. {#art-44911}

(uchylony) 
TYTUŁ VII 
Wykonanie zobowiązań i skutki ich niewykonania 
## DZIAŁ I. Wykonanie zobowiązań

***
## Art. 450. {#art-450}

Wierzyciel nie może odmówić przyjęcia świadczenia częściowego, 
chociażby cała wierzytelność była już wymagalna, chyba że przyjęcie takiego 
świadczenia narusza jego uzasadniony interes.

***
## Art. 451. {#art-451}

§ 1. Dłużnik mający względem tego samego wierzyciela kilka długów 
tego samego rodzaju może przy spełnieniu świadczenia wskazać, który dług chce 
zaspokoić. Jednakże to, co przypada na poczet danego długu, wierzyciel może przede 
wszystkim zaliczyć na związane z tym długiem zaległe należności uboczne oraz na 
zalegające świadczenia główne. 
§ 2. Jeżeli dłużnik nie wskazał, który z kilku długów chce zaspokoić, a przyjął 
pokwitowanie, w którym wierzyciel zaliczył otrzymane świadczenie na poczet 
jednego z tych długów, dłużnik nie może już żądać zaliczenia na poczet innego długu. 
§ 3. W braku oświadczenia dłużnika lub wierzyciela spełnione świadczenie 
zalicza się przede wszystkim na poczet długu wymagalnego, a jeżeli jest kilka długów 
wymagalnych – na poczet najdawniej wymagalnego. 

©Kancelaria Sejmu 
 
 
 
s. 93/242 
 
   
 
2025-09-09

***
## Art. 452. {#art-452}

Jeżeli świadczenie zostało spełnione do rąk osoby nieuprawnionej do 
jego przyjęcia, a przyjęcie świadczenia nie zostało potwierdzone przez wierzyciela, 
dłużnik jest zwolniony w takim zakresie, w jakim wierzyciel ze świadczenia 
skorzystał. Przepis ten stosuje się odpowiednio w wypadku, gdy świadczenie zostało 
spełnione do rąk wierzyciela, który był niezdolny do jego przyjęcia.

***
## Art. 453. {#art-453}

Jeżeli dłużnik w celu zwolnienia się z zobowiązania spełnia za zgodą 
wierzyciela inne świadczenie, zobowiązanie wygasa. Jednakże gdy przedmiot 
świadczenia ma wady, dłużnik obowiązany jest do rękojmi według przepisów 
o rękojmi przy sprzedaży.

***
## Art. 454. {#art-454}

§ 1. Jeżeli miejsce spełnienia świadczenia nie jest oznaczone ani nie 
wynika z właściwości zobowiązania, świadczenie powinno być spełnione w miejscu, 
gdzie w chwili powstania zobowiązania dłużnik miał zamieszkanie lub siedzibę. 
Jednakże świadczenie pieniężne powinno być spełnione w miejscu zamieszkania lub 
w siedzibie wierzyciela w chwili spełnienia świadczenia; jeżeli wierzyciel zmienił 
miejsce zamieszkania lub siedzibę po powstaniu zobowiązania, ponosi spowodowaną 
przez tę zmianę nadwyżkę kosztów przesłania. 
§ 2. Jeżeli zobowiązanie ma związek z przedsiębiorstwem dłużnika lub 
wierzyciela, o miejscu spełnienia świadczenia rozstrzyga siedziba przedsiębiorstwa.

***
## Art. 4541. {#art-4541}

Jeżeli przedsiębiorca jest obowiązany przesłać rzecz konsumentowi 
do oznaczonego miejsca, miejsce to uważa się za miejsce spełnienia świadczenia. 
Zastrzeżenie przeciwne jest nieważne.

***
## Art. 455. {#art-455}

Jeżeli termin spełnienia świadczenia nie jest oznaczony ani nie wynika 
z właściwości zobowiązania, świadczenie powinno być spełnione niezwłocznie po 
wezwaniu dłużnika do wykonania.

***
## Art. 456. {#art-456}

Jeżeli strony zastrzegły w umowie, że spełnienie świadczenia 
następować będzie częściami w ciągu określonego czasu, ale nie ustaliły wielkości 
poszczególnych świadczeń częściowych albo terminów, w których ma nastąpić 
spełnienie każdego z tych świadczeń, wierzyciel może przez oświadczenie, złożone 
dłużnikowi w czasie właściwym, ustalić zarówno wielkość poszczególnych świadczeń 
częściowych, jak i termin spełnienia każdego z nich, jednakże powinien uwzględnić 
możliwości dłużnika oraz sposób spełnienia świadczenia. 

©Kancelaria Sejmu 
 
 
 
s. 94/242 
 
   
 
2025-09-09

***
## Art. 457. {#art-457}

Termin spełnienia świadczenia oznaczony przez czynność prawną 
poczytuje się w razie wątpliwości za zastrzeżony na korzyść dłużnika.

***
## Art. 458. {#art-458}

Jeżeli dłużnik stał się niewypłacalny albo jeżeli wskutek okoliczności, 
za które ponosi odpowiedzialność, zabezpieczenie wierzytelności uległo znacznemu 
zmniejszeniu, wierzyciel może żądać spełnienia świadczenia bez względu na 
zastrzeżony termin.

***
## Art. 459. {#art-459}

§ 1. Zobowiązany do wydania zbioru rzeczy lub masy majątkowej albo 
do udzielenia wiadomości o zbiorze rzeczy lub o masie majątkowej powinien 
przedstawić wierzycielowi spis rzeczy należących do zbioru lub spis przedmiotów 
wchodzących w skład masy majątkowej. 
§ 2. Jeżeli istnieje uzasadnione przypuszczenie, że przedstawiony spis nie jest 
rzetelny lub dokładny, wierzyciel może żądać, ażeby dłużnik złożył zapewnienie przed 
sądem, iż sporządził spis według swojej najlepszej wiedzy.

***
## Art. 460. {#art-460}

§ 1. Zobowiązany do złożenia rachunku z zarządu powinien 
przedstawić wierzycielowi na piśmie zestawienie wpływów i wydatków wraz 
z potrzebnymi dowodami. 
§ 2. Jeżeli istnieje uzasadnione przypuszczenie, że przedstawione zestawienie 
wpływów nie jest rzetelne lub dokładne, wierzyciel może żądać, ażeby dłużnik złożył 
zapewnienie przed sądem, iż sporządził zestawienie według swojej najlepszej wiedzy.

***
## Art. 461. {#art-461}

§ 1. Zobowiązany do wydania cudzej rzeczy może ją zatrzymać aż do 
chwili zaspokojenia lub zabezpieczenia przysługujących mu roszczeń o zwrot 
nakładów na rzecz oraz roszczeń o naprawienie szkody przez rzecz wyrządzonej 
(prawo zatrzymania). 
§ 2. Przepisu powyższego nie stosuje się, gdy obowiązek wydania rzeczy wynika 
z czynu 
niedozwolonego 
albo 
gdy 
chodzi 
o zwrot 
rzeczy 
wynajętych, 
wydzierżawionych lub użyczonych. 
§ 3. (uchylony)

***
## Art. 462. {#art-462}

§ 1. Dłużnik, spełniając świadczenie, może żądać od wierzyciela 
pokwitowania. 
§ 2. Dłużnik może żądać pokwitowania w szczególnej formie, jeżeli ma w tym 
interes. 
§ 3. Koszty pokwitowania ponosi dłużnik, chyba że umówiono się inaczej. 

©Kancelaria Sejmu 
 
 
 
s. 95/242 
 
   
 
2025-09-09

***
## Art. 463. {#art-463}

Jeżeli wierzyciel odmawia pokwitowania, dłużnik może powstrzymać 
się ze spełnieniem świadczenia albo złożyć przedmiot świadczenia do depozytu 
sądowego.

***
## Art. 464. {#art-464}

Świadczenie do rąk osoby, która okazuje pokwitowanie wystawione 
przez wierzyciela, zwalnia dłużnika, chyba że było zastrzeżone, iż świadczenie ma 
nastąpić do rąk własnych wierzyciela, albo chyba że dłużnik działał w złej wierze.

***
## Art. 465. {#art-465}

§ 1. Jeżeli istnieje dokument stwierdzający zobowiązanie, dłużnik 
spełniając świadczenie może żądać zwrotu dokumentu. Jednakże gdy wierzyciel ma 
interes w zachowaniu dokumentu, w szczególności gdy świadczenie zostało spełnione 
tylko częściowo, dłużnik może żądać uczynienia odpowiedniej wzmianki na 
dokumencie. 
§ 2. W razie utraty dokumentu dłużnik może, niezależnie od pokwitowania, 
żądać od wierzyciela oświadczenia na piśmie, że dokument został utracony. 
§ 3. Jeżeli wierzyciel odmawia zwrotu dokumentu lub uczynienia na nim 
odpowiedniej wzmianki albo pisemnego oświadczenia o utracie dokumentu, dłużnik 
może powstrzymać się ze spełnieniem świadczenia albo złożyć jego przedmiot do 
depozytu sądowego.

***
## Art. 466. {#art-466}

Z pokwitowania zapłaty dłużnej sumy wynika domniemanie zapłaty 
należności 
ubocznych. 
Z 
pokwitowania 
świadczenia 
okresowego 
wynika 
domniemanie, że spełnione zostały również świadczenia okresowe wymagalne wcześ-
niej.

***
## Art. 467. {#art-467}

Poza wypadkami przewidzianymi w innych przepisach dłużnik może 
złożyć przedmiot świadczenia do depozytu sądowego: 
- 1) jeżeli wskutek okoliczności, za które nie ponosi odpowiedzialności, nie wie, kto 
jest wierzycielem, albo nie zna miejsca zamieszkania lub siedziby wierzyciela; 
- 2) jeżeli wierzyciel nie ma pełnej zdolności do czynności prawnych ani 
przedstawiciela uprawnionego do przyjęcia świadczenia; 
- 3) jeżeli powstał spór, kto jest wierzycielem; 
- 4) jeżeli z powodu innych okoliczności dotyczących osoby wierzyciela świadczenie 
nie może być spełnione.

***
## Art. 468. {#art-468}

§ 1. O złożeniu przedmiotu świadczenia do depozytu sądowego 
dłużnik powinien niezwłocznie zawiadomić wierzyciela, chyba że zawiadomienie 

©Kancelaria Sejmu 
 
 
 
s. 96/242 
 
   
 
2025-09-09 
 
napotyka trudne do przezwyciężenia przeszkody. Zawiadomienie powinno nastąpić na 
piśmie. 
§ 2. W razie niewykonania powyższego obowiązku dłużnik jest odpowiedzialny 
za wynikłą stąd szkodę.

***
## Art. 469. {#art-469}

§ 1. Dopóki wierzyciel nie zażądał wydania przedmiotu świadczenia 
z depozytu sądowego, dłużnik może przedmiot złożony odebrać. 
§ 2. Jeżeli dłużnik odbierze przedmiot świadczenia z depozytu sądowego, 
złożenie do depozytu uważa się za niebyłe.

***
## Art. 470. {#art-470}

Ważne złożenie do depozytu sądowego ma takie same skutki jak 
spełnienie świadczenia i zobowiązuje wierzyciela do zwrotu dłużnikowi kosztów 
złożenia. 
## DZIAŁ II. Skutki niewykonania zobowiązań

***
## Art. 471. {#art-471}

Dłużnik 
obowiązany 
jest 
do 
naprawienia 
szkody 
wynikłej 
z niewykonania lub nienależytego wykonania zobowiązania, chyba że niewykonanie 
lub nienależyte wykonanie jest następstwem okoliczności, za które dłużnik odpowie-
dzialności nie ponosi.

***
## Art. 472. {#art-472}

Jeżeli ze szczególnego przepisu ustawy albo z czynności prawnej nie 
wynika nic innego, dłużnik odpowiedzialny jest za niezachowanie należytej 
staranności.

***
## Art. 473. {#art-473}

§ 1. Dłużnik może przez umowę przyjąć odpowiedzialność za 
niewykonanie lub za nienależyte wykonanie zobowiązania z powodu oznaczonych 
okoliczności, za które na mocy ustawy odpowiedzialności nie ponosi. 
§ 2. Nieważne jest zastrzeżenie, iż dłużnik nie będzie odpowiedzialny za szkodę, 
którą może wyrządzić wierzycielowi umyślnie.

***
## Art. 474. {#art-474}

Dłużnik odpowiedzialny jest jak za własne działanie lub zaniechanie 
za działania i zaniechania osób, z których pomocą zobowiązanie wykonywa, jak 
również osób, którym wykonanie zobowiązania powierza. Przepis powyższy stosuje 
się także w wypadku, gdy zobowiązanie wykonywa przedstawiciel ustawowy 
dłużnika. 

©Kancelaria Sejmu 
 
 
 
s. 97/242 
 
   
 
2025-09-09

***
## Art. 475. {#art-475}

§ 1. Jeżeli świadczenie stało się niemożliwe skutkiem okoliczności, za 
które dłużnik odpowiedzialności nie ponosi, zobowiązanie wygasa. 
§ 2. Jeżeli rzecz będąca przedmiotem świadczenia została zbyta, utracona lub 
uszkodzona, dłużnik obowiązany jest wydać wszystko, co uzyskał w zamian za tę 
rzecz albo jako naprawienie szkody.

***
## Art. 476. {#art-476}

Dłużnik dopuszcza się zwłoki, gdy nie spełnia świadczenia w terminie, 
a jeżeli termin nie jest oznaczony, gdy nie spełnia świadczenia niezwłocznie po 
wezwaniu przez wierzyciela. Nie dotyczy to wypadku, gdy opóźnienie w spełnieniu 
świadczenia jest następstwem okoliczności, za które dłużnik odpowiedzialności nie 
ponosi.

***
## Art. 477. {#art-477}

§ 1. W razie zwłoki dłużnika wierzyciel może żądać, niezależnie od 
wykonania zobowiązania, naprawienia szkody wynikłej ze zwłoki. 
§ 2. Jednakże gdy wskutek zwłoki dłużnika świadczenie utraciło dla wierzyciela 
całkowicie lub w przeważającym stopniu znaczenie, wierzyciel może świadczenia nie 
przyjąć i żądać naprawienia szkody wynikłej z niewykonania zobowiązania.

***
## Art. 478. {#art-478}

Jeżeli przedmiotem świadczenia jest rzecz oznaczona co do 
tożsamości, dłużnik będący w zwłoce odpowiedzialny jest za utratę lub uszkodzenie 
przedmiotu świadczenia, chyba że utrata lub uszkodzenie nastąpiłoby także wtedy, 
gdyby świadczenie zostało spełnione w czasie właściwym.

***
## Art. 479. {#art-479}

Jeżeli przedmiotem świadczenia jest określona ilość rzeczy 
oznaczonych tylko co do gatunku, wierzyciel może w razie zwłoki dłużnika nabyć na 
jego koszt taką samą ilość rzeczy tego samego gatunku albo żądać od dłużnika zapłaty 
ich wartości, zachowując w obu wypadkach roszczenie o naprawienie szkody 
wynikłej ze zwłoki.

***
## Art. 480. {#art-480}

§ 1. W razie zwłoki dłużnika w wykonaniu zobowiązania czynienia, 
wierzyciel może, zachowując roszczenie o naprawienie szkody, żądać upoważnienia 
przez sąd do wykonania czynności na koszt dłużnika. 
§ 2. Jeżeli świadczenie polega na zaniechaniu, wierzyciel może, zachowując 
roszczenie o naprawienie szkody, żądać upoważnienia przez sąd do usunięcia na koszt 
dłużnika wszystkiego, co dłużnik wbrew zobowiązaniu uczynił. 

©Kancelaria Sejmu 
 
 
 
s. 98/242 
 
   
 
2025-09-09 
 
§ 3. W wypadkach 
nagłych 
wierzyciel 
może, 
zachowując 
roszczenie 
o naprawienie szkody, wykonać bez upoważnienia sądu czynność na koszt dłużnika 
lub usunąć na jego koszt to, co dłużnik wbrew zobowiązaniu uczynił. 
§ 4. Przepisów § 1 i 3 nie stosuje się do roszczeń o złożenie oświadczenia 
odpowiedniej treści i w odpowiedniej formie w związku z naruszeniem dóbr 
osobistych.

***
## Art. 481. {#art-481}

§ 1. Jeżeli dłużnik opóźnia się ze spełnieniem świadczenia 
pieniężnego, wierzyciel może żądać odsetek za czas opóźnienia, chociażby nie poniósł 
żadnej szkody i chociażby opóźnienie było następstwem okoliczności, za które 
dłużnik odpowiedzialności nie ponosi. 
§ 2. Jeżeli stopa odsetek za opóźnienie nie była oznaczona, należą się odsetki 
ustawowe za opóźnienie w wysokości równej sumie stopy referencyjnej Narodowego 
Banku Polskiego i 5,5 punktów procentowych. Jednakże gdy wierzytelność jest 
oprocentowana według stopy wyższej, wierzyciel może żądać odsetek za opóźnienie 
według tej wyższej stopy. 
§ 21. Maksymalna wysokość odsetek za opóźnienie nie może w stosunku 
rocznym przekraczać dwukrotności wysokości odsetek ustawowych za opóźnienie 
(odsetki maksymalne za opóźnienie). 
§ 22. Jeżeli wysokość odsetek za opóźnienie przekracza wysokość odsetek 
maksymalnych za opóźnienie, należą się odsetki maksymalne za opóźnienie. 
§ 23. Postanowienia umowne nie mogą wyłączać ani ograniczać przepisów 
o odsetkach maksymalnych za opóźnienie, także w przypadku dokonania wyboru 
prawa obcego. W takim przypadku stosuje się przepisy ustawy. 
§ 24. Minister Sprawiedliwości ogłasza, w drodze obwieszczenia, w Dzienniku 
Urzędowym Rzeczypospolitej Polskiej „Monitor Polski”, wysokość odsetek 
ustawowych za opóźnienie. 
§ 3. W razie zwłoki dłużnika wierzyciel może nadto żądać naprawienia szkody 
na zasadach ogólnych.

***
## Art. 482. {#art-482}

§ 1. Od zaległych odsetek można żądać odsetek za opóźnienie dopiero 
od chwili wytoczenia o nie powództwa, chyba że po powstaniu zaległości strony 
zgodziły się na doliczenie zaległych odsetek do dłużnej sumy. 
§ 2. (uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 99/242 
 
   
 
2025-09-09

***
## Art. 483. {#art-483}

§ 1. Można zastrzec w umowie, że naprawienie szkody wynikłej 
z niewykonania lub nienależytego wykonania zobowiązania niepieniężnego nastąpi 
przez zapłatę określonej sumy (kara umowna). 
§ 2. Dłużnik nie może bez zgody wierzyciela zwolnić się z zobowiązania przez 
zapłatę kary umownej.

***
## Art. 484. {#art-484}

§ 1. W razie niewykonania lub nienależytego wykonania zobowiązania 
kara umowna należy się wierzycielowi w zastrzeżonej na ten wypadek wysokości bez 
względu na wysokość poniesionej szkody. Żądanie odszkodowania przenoszącego 
wysokość zastrzeżonej kary nie jest dopuszczalne, chyba że strony inaczej 
postanowiły. 
§ 2. Jeżeli zobowiązanie zostało w znacznej części wykonane, dłużnik może 
żądać zmniejszenia kary umownej; to samo dotyczy wypadku, gdy kara umowna jest 
rażąco wygórowana.

***
## Art. 485. {#art-485}

Jeżeli przepis szczególny stanowi, że w razie niewykonania lub 
nienależytego wykonania zobowiązania niepieniężnego dłużnik, nawet bez 
umownego zastrzeżenia, obowiązany jest zapłacić wierzycielowi określoną sumę, 
stosuje się odpowiednio przepisy o karze umownej.

***
## Art. 486. {#art-486}

§ 1. W razie zwłoki wierzyciela dłużnik może żądać naprawienia 
wynikłej stąd szkody; może również złożyć przedmiot świadczenia do depozytu 
sądowego. 
§ 2. Wierzyciel dopuszcza się zwłoki, gdy bez uzasadnionego powodu bądź 
uchyla się od przyjęcia zaofiarowanego świadczenia, bądź odmawia dokonania 
czynności, bez której świadczenie nie może być spełnione, bądź oświadcza 
dłużnikowi, że świadczenia nie przyjmie. 
## DZIAŁ III. Wykonanie i skutki niewykonania zobowiązań z umów wzajemnych

***
## Art. 487. {#art-487}

§ 1. Wykonanie 
i skutki 
niewykonania 
zobowiązań 
z umów 
wzajemnych podlegają przepisom działów poprzedzających niniejszego tytułu, o ile 
przepisy działu niniejszego nie stanowią inaczej. 
§ 2. Umowa jest wzajemna, gdy obie strony zobowiązują się w taki sposób, że 
świadczenie jednej z nich ma być odpowiednikiem świadczenia drugiej. 

©Kancelaria Sejmu 
 
 
 
s. 100/242 
 
   
 
2025-09-09

***
## Art. 488. {#art-488}

§ 1. 
Świadczenia 
będące 
przedmiotem 
zobowiązań 
z umów 
wzajemnych (świadczenia wzajemne) powinny być spełnione jednocześnie, chyba że 
z umowy, z ustawy albo z orzeczenia sądu lub decyzji innego właściwego organu 
wynika, iż jedna ze stron obowiązana jest do wcześniejszego świadczenia. 
§ 2. Jeżeli świadczenia wzajemne powinny być spełnione jednocześnie, każda ze 
stron może powstrzymać się ze spełnieniem świadczenia, dopóki druga strona nie 
zaofiaruje świadczenia wzajemnego.

***
## Art. 489. {#art-489}

(uchylony)

***
## Art. 490. {#art-490}

§ 1. Jeżeli jedna ze stron obowiązana jest spełnić świadczenie 
wzajemne wcześniej, a spełnienie świadczenia przez drugą stronę jest wątpliwe ze 
względu na jej stan majątkowy, strona zobowiązana do wcześniejszego świadczenia 
może powstrzymać się z jego spełnieniem, dopóki druga strona nie zaofiaruje 
świadczenia wzajemnego lub nie da zabezpieczenia. 
§ 2. Uprawnienia powyższe nie przysługują stronie, która w chwili zawarcia 
umowy wiedziała o złym stanie majątkowym drugiej strony. 
§ 3. (uchylony)

***
## Art. 491. {#art-491}

§ 1. Jeżeli jedna ze stron dopuszcza się zwłoki w wykonaniu 
zobowiązania z umowy wzajemnej, druga strona może wyznaczyć jej odpowiedni 
dodatkowy termin do wykonania z zagrożeniem, iż w razie bezskutecznego upływu 
wyznaczonego terminu będzie uprawniona do odstąpienia od umowy. Może również 
bądź bez wyznaczenia terminu dodatkowego, bądź też po jego bezskutecznym upływie 
żądać wykonania zobowiązania i naprawienia szkody wynikłej ze zwłoki. 
§ 2. Jeżeli świadczenia obu stron są podzielne, a jedna ze stron dopuszcza się 
zwłoki tylko co do części świadczenia, uprawnienie do odstąpienia od umowy 
przysługujące drugiej stronie ogranicza się, według jej wyboru, albo do tej części, albo 
do całej reszty niespełnionego świadczenia. Strona ta może także odstąpić od umowy 
w całości, jeżeli wykonanie częściowe nie miałoby dla niej znaczenia ze względu na 
właściwości zobowiązania albo ze względu na zamierzony przez nią cel umowy, 
wiadomy stronie będącej w zwłoce.

***
## Art. 492. {#art-492}

Jeżeli uprawnienie do odstąpienia od umowy wzajemnej zostało 
zastrzeżone na wypadek niewykonania zobowiązania w terminie ściśle określonym, 
strona uprawniona może w razie zwłoki drugiej strony odstąpić od umowy bez 

©Kancelaria Sejmu 
 
 
 
s. 101/242 
 
   
 
2025-09-09 
 
wyznaczenia terminu dodatkowego. To samo dotyczy wypadku, gdy wykonanie 
zobowiązania przez jedną ze stron po terminie nie miałoby dla drugiej strony 
znaczenia ze względu na właściwości zobowiązania albo ze względu na zamierzony 
przez nią cel umowy, wiadomy stronie będącej w zwłoce.

***
## Art. 4921. {#art-4921}

Jeżeli strona obowiązana do spełnienia świadczenia oświadczy, że 
świadczenia tego nie spełni, druga strona może odstąpić od umowy bez wyznaczenia 
terminu dodatkowego, także przed nadejściem oznaczonego terminu spełnienia 
świadczenia.

***
## Art. 493. {#art-493}

§ 1. Jeżeli jedno ze świadczeń wzajemnych stało się niemożliwe 
wskutek okoliczności, za które ponosi odpowiedzialność strona zobowiązana, druga 
strona może, według swego wyboru, albo żądać naprawienia szkody wynikłej 
z niewykonania zobowiązania, albo od umowy odstąpić. 
§ 2. W razie częściowej niemożliwości świadczenia jednej ze stron druga strona 
może od umowy odstąpić, jeżeli wykonanie częściowe nie miałoby dla niej znaczenia 
ze względu na właściwości zobowiązania albo ze względu na zamierzony przez tę 
stronę cel umowy, wiadomy stronie, której świadczenie stało się częściowo 
niemożliwe.

***
## Art. 494. {#art-494}

§ 1. Strona, która odstępuje od umowy wzajemnej, obowiązana jest 
zwrócić drugiej stronie wszystko, co otrzymała od niej na mocy umowy, a druga strona 
obowiązana jest to przyjąć. Strona, która odstępuje od umowy, może żądać nie tylko 
zwrotu tego, co świadczyła, lecz również na zasadach ogólnych naprawienia szkody 
wynikłej z niewykonania zobowiązania. 
§ 2. Zwrot świadczenia na rzecz konsumenta powinien nastąpić niezwłocznie.

***
## Art. 495. {#art-495}

§ 1. Jeżeli jedno ze świadczeń wzajemnych stało się niemożliwe 
wskutek okoliczności, za które żadna ze stron odpowiedzialności nie ponosi, strona, 
która miała to świadczenie spełnić, nie może żądać świadczenia wzajemnego, 
a w wypadku, gdy je już otrzymała, obowiązana jest do zwrotu według przepisów 
o bezpodstawnym wzbogaceniu. 
§ 2. Jeżeli świadczenie jednej ze stron stało się niemożliwe tylko częściowo, 
strona ta traci prawo do odpowiedniej części świadczenia wzajemnego. Jednakże 
druga strona może od umowy odstąpić, jeżeli wykonanie częściowe nie miałoby dla 
niej znaczenia ze względu na właściwości zobowiązania albo ze względu na 

©Kancelaria Sejmu 
 
 
 
s. 102/242 
 
   
 
2025-09-09 
 
zamierzony przez tę stronę cel umowy, wiadomy stronie, której świadczenie stało się 
częściowo niemożliwe.

***
## Art. 496. {#art-496}

Jeżeli wskutek odstąpienia od umowy strony mają dokonać zwrotu 
świadczeń wzajemnych, każdej z nich przysługuje prawo zatrzymania, dopóki druga 
strona nie zaofiaruje zwrotu otrzymanego świadczenia albo nie zabezpieczy 
roszczenia o zwrot.

***
## Art. 497. {#art-497}

Przepis artykułu poprzedzającego stosuje się odpowiednio w razie 
rozwiązania lub nieważności umowy wzajemnej. 
TYTUŁ VIII 
Potrącenie, odnowienie, zwolnienie z długu

***
## Art. 498. {#art-498}

§ 1. Gdy dwie osoby są jednocześnie względem siebie dłużnikami 
i wierzycielami, każda z nich może potrącić swoją wierzytelność z wierzytelności 
drugiej strony, jeżeli przedmiotem obu wierzytelności są pieniądze lub rzeczy tej 
samej jakości oznaczone tylko co do gatunku, a obie wierzytelności są wymagalne 
i mogą być dochodzone przed sądem lub przed innym organem państwowym. 
§ 2. Wskutek potrącenia obie wierzytelności umarzają się nawzajem do 
wysokości wierzytelności niższej.

***
## Art. 499. {#art-499}

Potrącenia dokonywa się przez oświadczenie złożone drugiej stronie. 
Oświadczenie ma moc wsteczną od chwili, kiedy potrącenie stało się możliwe.

***
## Art. 500. {#art-500}

Jeżeli przedmiotem potrącenia są wierzytelności, których miejsca 
spełnienia świadczeń są różne, strona korzystająca z możności potrącenia obowiązana 
jest uiścić drugiej stronie sumę potrzebną do pokrycia wynikającego dla niej 
uszczerbku.

***
## Art. 501. {#art-501}

Odroczenie wykonania zobowiązania udzielone przez sąd albo 
bezpłatnie przez wierzyciela nie wyłącza potrącenia.

***
## Art. 502. {#art-502}

Wierzytelność przedawniona może być potrącona, jeżeli w chwili, gdy 
potrącenie stało się możliwe, przedawnienie jeszcze nie nastąpiło.

***
## Art. 503. {#art-503}

Przepisy o zaliczeniu zapłaty stosuje się odpowiednio do potrącenia.

***
## Art. 504. {#art-504}

Zajęcie wierzytelności przez osobę trzecią wyłącza umorzenie tej 
wierzytelności przez potrącenie tylko wtedy, gdy dłużnik stał się wierzycielem swego 

©Kancelaria Sejmu 
 
 
 
s. 103/242 
 
   
 
2025-09-09 
 
wierzyciela dopiero po dokonaniu zajęcia albo gdy jego wierzytelność stała się 
wymagalna po tej chwili, a przy tym dopiero później aniżeli wierzytelność zajęta.

***
## Art. 505. {#art-505}

Nie mogą być umorzone przez potrącenie: 
- 1) wierzytelności nieulegające zajęciu; 
- 2) wierzytelności o dostarczenie środków utrzymania; 
- 3) wierzytelności wynikające z czynów niedozwolonych; 
- 4) wierzytelności, co do których potrącenie jest wyłączone przez przepisy 
szczególne.

***
## Art. 506. {#art-506}

§ 1. Jeżeli w celu umorzenia zobowiązania dłużnik zobowiązuje się za 
zgodą wierzyciela spełnić inne świadczenie albo nawet to samo świadczenie, lecz 
z innej podstawy prawnej, zobowiązanie dotychczasowe wygasa (odnowienie). 
§ 2. W razie wątpliwości poczytuje się, że zmiana treści dotychczasowego 
zobowiązania nie stanowi odnowienia. Dotyczy to w szczególności wypadku, gdy 
wierzyciel otrzymuje od dłużnika weksel lub czek.

***
## Art. 507. {#art-507}

Jeżeli 
wierzytelność 
była 
zabezpieczona 
poręczeniem 
lub 
ograniczonym prawem rzeczowym ustanowionym przez osobę trzecią, poręczenie lub 
ograniczone prawo rzeczowe wygasa z chwilą odnowienia, chyba że poręczyciel lub 
osoba trzecia wyrazi zgodę na dalsze trwanie zabezpieczenia.

***
## Art. 508. {#art-508}

Zobowiązanie wygasa, gdy wierzyciel zwalnia dłużnika z długu, 
a dłużnik zwolnienie przyjmuje. 
TYTUŁ IX 
Zmiana wierzyciela lub dłużnika 
## DZIAŁ I. Zmiana wierzyciela

***
## Art. 509. {#art-509}

§ 1. Wierzyciel może bez zgody dłużnika przenieść wierzytelność na 
osobę trzecią (przelew), chyba że sprzeciwiałoby się to ustawie, zastrzeżeniu 
umownemu albo właściwości zobowiązania. 
§ 2. Wraz z wierzytelnością przechodzą na nabywcę wszelkie związane z nią 
prawa, w szczególności roszczenie o zaległe odsetki. 

©Kancelaria Sejmu 
 
 
 
s. 104/242 
 
   
 
2025-09-09

***
## Art. 510. {#art-510}

§ 1. Umowa sprzedaży, zamiany, darowizny lub inna umowa 
zobowiązująca do przeniesienia wierzytelności przenosi wierzytelność na nabywcę, 
chyba że przepis szczególny stanowi inaczej albo że strony inaczej postanowiły. 
§ 2. Jeżeli zawarcie umowy przelewu następuje w wykonaniu zobowiązania 
wynikającego z uprzednio zawartej umowy zobowiązującej do przeniesienia 
wierzytelności, z zapisu zwykłego, z bezpodstawnego wzbogacenia lub z innego 
zdarzenia, ważność umowy przelewu zależy od istnienia tego zobowiązania.

***
## Art. 511. {#art-511}

Jeżeli 
wierzytelność 
jest 
stwierdzona 
pismem, 
przelew 
tej 
wierzytelności powinien być również pismem stwierdzony.

***
## Art. 512. {#art-512}

Dopóki zbywca nie zawiadomił dłużnika o przelewie, spełnienie 
świadczenia do rąk poprzedniego wierzyciela ma skutek względem nabywcy, chyba 
że w chwili spełnienia świadczenia dłużnik wiedział o przelewie. Przepis ten stosuje 
się odpowiednio do innych czynności prawnych dokonanych między dłużnikiem 
a poprzednim wierzycielem.

***
## Art. 513. {#art-513}

§ 1. Dłużnikowi przysługują przeciwko nabywcy wierzytelności 
wszelkie zarzuty, które miał przeciwko zbywcy w chwili powzięcia wiadomości 
o przelewie. 
§ 2. Dłużnik może z przelanej wierzytelności potrącić wierzytelność, która mu 
przysługuje względem zbywcy, chociażby stała się wymagalna dopiero po otrzymaniu 
przez dłużnika zawiadomienia o przelewie. Nie dotyczy to jednak wypadku, gdy 
wierzytelność przysługująca względem zbywcy stała się wymagalna później niż 
wierzytelność będąca przedmiotem przelewu.

***
## Art. 514. {#art-514}

Jeżeli wierzytelność jest stwierdzona pismem, zastrzeżenie umowne, 
iż przelew nie może nastąpić bez zgody dłużnika, jest skuteczne względem nabywcy 
tylko wtedy, gdy pismo zawiera wzmiankę o tym zastrzeżeniu, chyba że nabywca 
w chwili przelewu o zastrzeżeniu wiedział.

***
## Art. 515. {#art-515}

Jeżeli dłużnik, który otrzymał o przelewie pisemne zawiadomienie 
pochodzące od zbywcy, spełnił świadczenie do rąk nabywcy wierzytelności, zbywca 
może powołać się wobec dłużnika na nieważność przelewu albo na zarzuty wynikające 
z jego podstawy prawnej tylko wtedy, gdy w chwili spełnienia świadczenia były one 
dłużnikowi wiadome. Przepis ten stosuje się odpowiednio do innych czynności 
prawnych dokonanych między dłużnikiem a nabywcą wierzytelności. 

©Kancelaria Sejmu 
 
 
 
s. 105/242 
 
   
 
2025-09-09

***
## Art. 516. {#art-516}

Zbywca wierzytelności ponosi względem nabywcy odpowiedzialność 
za to, że wierzytelność mu przysługuje. Za wypłacalność dłużnika w chwili przelewu 
ponosi odpowiedzialność tylko o tyle, o ile tę odpowiedzialność na siebie przyjął.

***
## Art. 517. {#art-517}

§ 1. Przepisów o przelewie nie stosuje się do wierzytelności 
związanych z dokumentem na okaziciela lub z dokumentem zbywalnym przez indos. 
§ 2. Przeniesienie wierzytelności z dokumentu na okaziciela następuje przez 
przeniesienie własności dokumentu. Do przeniesienia własności dokumentu potrzebne 
jest jego wydanie.

***
## Art. 518. {#art-518}

§ 1. Osoba trzecia, która spłaca wierzyciela, nabywa spłaconą 
wierzytelność do wysokości dokonanej zapłaty: 
- 1) jeżeli płaci cudzy dług, za który jest odpowiedzialna osobiście albo pewnymi 
przedmiotami majątkowymi; 
- 2) jeżeli przysługuje jej prawo, przed którym spłacona wierzytelność ma 
pierwszeństwo zaspokojenia; 
- 3) jeżeli działa za zgodą dłużnika w celu wstąpienia w prawa wierzyciela; zgoda 
dłużnika powinna być pod nieważnością wyrażona na piśmie; 
- 4) jeżeli to przewidują przepisy szczególne. 
§ 2. W wypadkach powyższych wierzyciel nie może odmówić przyjęcia 
świadczenia, które jest już wymagalne. 
§ 3. Jeżeli wierzyciel został spłacony przez osobę trzecią tylko w części, 
przysługuje mu co do pozostałej części pierwszeństwo zaspokojenia przed 
wierzytelnością, która przeszła na osobę trzecią wskutek zapłaty częściowej. 
## DZIAŁ II. Zmiana dłużnika

***
## Art. 519. {#art-519}

§ 1. Osoba trzecia może wstąpić na miejsce dłużnika, który zostaje 
z długu zwolniony (przejęcie długu). 
§ 2. Przejęcie długu może nastąpić: 
- 1) przez umowę między wierzycielem a osobą trzecią za zgodą dłużnika; 
oświadczenie dłużnika może być złożone którejkolwiek ze stron; 
- 2) przez umowę między dłużnikiem a osobą trzecią za zgodą wierzyciela; 
oświadczenie wierzyciela może być złożone którejkolwiek ze stron; jest ono 

©Kancelaria Sejmu 
 
 
 
s. 106/242 
 
   
 
2025-09-09 
 
bezskuteczne, jeżeli wierzyciel nie wiedział, że osoba przejmująca dług jest nie-
wypłacalna.

***
## Art. 520. {#art-520}

Każda ze stron, które zawarły umowę o przejęcie długu, może 
wyznaczyć osobie, której zgoda jest potrzebna do skuteczności przejęcia, odpowiedni 
termin do wyrażenia zgody; bezskuteczny upływ wyznaczonego terminu jest 
jednoznaczny z odmówieniem zgody.

***
## Art. 521. {#art-521}

§ 1. Jeżeli skuteczność umowy o przejęcie długu zależy od zgody 
dłużnika, a dłużnik zgody odmówił, umowę uważa się za niezawartą. 
§ 2. Jeżeli skuteczność umowy o przejęcie długu zależy od zgody wierzyciela, 
a wierzyciel zgody odmówił, strona, która według umowy miała przejąć dług, jest 
odpowiedzialna względem dłużnika za to, że wierzyciel nie będzie od niego żądał 
spełnienia świadczenia.

***
## Art. 522. {#art-522}

Umowa o przejęcie długu powinna być pod nieważnością zawarta na 
piśmie. To samo dotyczy zgody wierzyciela na przejęcie długu.

***
## Art. 523. {#art-523}

Jeżeli w umowie o przeniesienie własności nieruchomości nabywca 
zobowiązał się zwolnić zbywcę od związanych z własnością długów, poczytuje się 
w razie wątpliwości, że strony zawarły umowę o przejęcie tych długów przez 
nabywcę.

***
## Art. 524. {#art-524}

§ 1. Przejmującemu dług przysługują przeciwko wierzycielowi 
wszelkie zarzuty, które miał dotychczasowy dłużnik, z wyjątkiem zarzutu potrącenia 
z wierzytelności dotychczasowego dłużnika. 
§ 2. Przejmujący dług nie może powoływać się względem wierzyciela na zarzuty 
wynikające z istniejącego między przejmującym dług a dotychczasowym dłużnikiem 
stosunku prawnego, będącego podstawą prawną przejęcia długu; nie dotyczy to jednak 
zarzutów, o których wierzyciel wiedział.

***
## Art. 525. {#art-525}

Jeżeli 
wierzytelność 
była 
zabezpieczona 
poręczeniem 
lub 
ograniczonym prawem rzeczowym ustanowionym przez osobę trzecią, poręczenie lub 
ograniczone prawo rzeczowe wygasa z chwilą przejęcia długu, chyba że poręczyciel 
lub osoba trzecia wyrazi zgodę na dalsze trwanie zabezpieczenia.

***
## Art. 526. {#art-526}

(uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 107/242 
 
   
 
2025-09-09 
 
TYTUŁ X 
Ochrona wierzyciela w razie niewypłacalności dłużnika

***
## Art. 527. {#art-527}

§ 1. Gdy 
wskutek 
czynności 
prawnej 
dłużnika 
dokonanej 
z pokrzywdzeniem wierzycieli osoba trzecia uzyskała korzyść majątkową, każdy 
z wierzycieli może żądać uznania tej czynności za bezskuteczną w stosunku do niego, 
jeżeli dłużnik działał ze świadomością pokrzywdzenia wierzycieli, a osoba trzecia 
o tym wiedziała lub przy zachowaniu należytej staranności mogła się dowiedzieć. 
§ 2. Czynność prawna dłużnika jest dokonana z pokrzywdzeniem wierzycieli, 
jeżeli wskutek tej czynności dłużnik stał się niewypłacalny albo stał się niewypłacalny 
w wyższym stopniu, niż był przed dokonaniem czynności. 
§ 3. Jeżeli wskutek czynności prawnej dłużnika dokonanej z pokrzywdzeniem 
wierzycieli uzyskała korzyść majątkową osoba będąca w bliskim z nim stosunku, 
domniemywa się, że osoba ta wiedziała, iż dłużnik działał ze świadomością 
pokrzywdzenia wierzycieli. 
§ 4. Jeżeli wskutek czynności prawnej dłużnika dokonanej z pokrzywdzeniem 
wierzycieli korzyść majątkową uzyskał przedsiębiorca pozostający z dłużnikiem 
w stałych stosunkach gospodarczych, domniemywa się, że było mu wiadome, iż 
dłużnik działał ze świadomością pokrzywdzenia wierzycieli.

***
## Art. 528. {#art-528}

Jeżeli wskutek czynności prawnej dokonanej przez dłużnika 
z pokrzywdzeniem wierzycieli osoba trzecia uzyskała korzyść majątkową bezpłatnie, 
wierzyciel może żądać uznania czynności za bezskuteczną, chociażby osoba ta nie 
wiedziała i nawet przy zachowaniu należytej staranności nie mogła się dowiedzieć, że 
dłużnik działał ze świadomością pokrzywdzenia wierzycieli.

***
## Art. 529. {#art-529}

Jeżeli w chwili darowizny dłużnik był niewypłacalny, domniemywa 
się, iż działał ze świadomością pokrzywdzenia wierzycieli. To samo dotyczy 
wypadku, gdy dłużnik stał się niewypłacalny wskutek dokonania darowizny.

***
## Art. 530. {#art-530}

Przepisy artykułów poprzedzających stosuje się odpowiednio 
w wypadku, gdy dłużnik działał w zamiarze pokrzywdzenia przyszłych wierzycieli. 
Jeżeli jednak osoba trzecia uzyskała korzyść majątkową odpłatnie, wierzyciel może 
żądać uznania czynności za bezskuteczną tylko wtedy, gdy osoba trzecia o zamiarze 
dłużnika wiedziała. 

©Kancelaria Sejmu 
 
 
 
s. 108/242 
 
   
 
2025-09-09

***
## Art. 531. {#art-531}

§ 1. Uznanie za bezskuteczną czynności prawnej dłużnika dokonanej 
z pokrzywdzeniem wierzycieli następuje w drodze powództwa lub zarzutu przeciwko 
osobie trzeciej, która wskutek tej czynności uzyskała korzyść majątkową. 
§ 2. W wypadku gdy osoba trzecia rozporządziła uzyskaną korzyścią, wierzyciel 
może wystąpić bezpośrednio przeciwko osobie, na której rzecz rozporządzenie 
nastąpiło, jeżeli osoba ta wiedziała o okolicznościach uzasadniających uznanie 
czynności dłużnika za bezskuteczną albo jeżeli rozporządzenie było nieodpłatne.

***
## Art. 532. {#art-532}

Wierzyciel, względem którego czynność prawna dłużnika została 
uznana za bezskuteczną, może z pierwszeństwem przed wierzycielami osoby trzeciej 
dochodzić zaspokojenia z przedmiotów majątkowych, które wskutek czynności 
uznanej za bezskuteczną wyszły z majątku dłużnika albo do niego nie weszły.

***
## Art. 533. {#art-533}

Osoba trzecia, która uzyskała korzyść majątkową wskutek czynności 
prawnej dłużnika dokonanej z pokrzywdzeniem wierzycieli, może zwolnić się od 
zadośćuczynienia roszczeniu wierzyciela żądającego uznania czynności za 
bezskuteczną, jeżeli zaspokoi tego wierzyciela albo wskaże mu wystarczające do jego 
zaspokojenia mienie dłużnika.

***
## Art. 534. {#art-534}

Uznania czynności prawnej dokonanej z pokrzywdzeniem wierzycieli 
za bezskuteczną nie można żądać po upływie lat pięciu od daty tej czynności. 
TYTUŁ XI 
Sprzedaż 
## DZIAŁ I. Przepisy ogólne

***
## Art. 535. {#art-535}

Przez umowę sprzedaży sprzedawca zobowiązuje się przenieść na 
kupującego własność rzeczy i wydać mu rzecz, a kupujący zobowiązuje się rzecz 
odebrać i zapłacić sprzedawcy cenę. 
§ 2. (uchylony)

***
## Art. 5351. {#art-5351}

(uchylony)

***
## Art. 536. {#art-536}

§ 1. Cenę można określić przez wskazanie podstaw do jej ustalenia. 

©Kancelaria Sejmu 
 
 
 
s. 109/242 
 
   
 
2025-09-09 
 
§ 2. Jeżeli z okoliczności wynika, że strony miały na względzie cenę przyjętą 
w stosunkach danego rodzaju, poczytuje się w razie wątpliwości, że chodziło o cenę 
w miejscu i czasie, w którym rzecz ma być kupującemu wydana.

***
## Art. 537. {#art-537}

§ 1. Jeżeli w miejscu i czasie zawarcia umowy sprzedaży obowiązuje 
zarządzenie, według którego za rzeczy danego rodzaju lub gatunku może być 
zapłacona jedynie cena ściśle określona (cena sztywna), cena ta wiąże strony bez 
względu na to, jaką cenę w umowie ustaliły. 
§ 2. Sprzedawca, który otrzymał cenę wyższą od ceny sztywnej, obowiązany jest 
zwrócić kupującemu pobraną różnicę. 
§ 3. Kupujący, który według umowy miał zapłacić cenę niższą od ceny sztywnej, 
a rzecz zużył lub odprzedał po cenie obliczonej na podstawie ceny umówionej, 
obowiązany jest zapłacić cenę sztywną tylko wtedy, gdy przed zużyciem lub 
odprzedaniem rzeczy znał cenę sztywną lub mógł ją znać przy zachowaniu należytej 
staranności. Kupujący, który rzeczy nie zużył ani nie odprzedał, może od umowy 
odstąpić.

***
## Art. 538. {#art-538}

Jeżeli w miejscu i czasie zawarcia umowy sprzedaży obowiązuje 
zarządzenie, według którego za rzeczy danego rodzaju lub gatunku nie może być 
zapłacona cena wyższa od ceny określonej (cena maksymalna), kupujący nie jest 
obowiązany do zapłaty ceny wyższej, a sprzedawca, który otrzymał cenę wyższą, 
obowiązany jest zwrócić kupującemu pobraną różnicę.

***
## Art. 539. {#art-539}

Jeżeli w miejscu i czasie zawarcia umowy sprzedaży obowiązuje 
zarządzenie, według którego za rzeczy danego rodzaju lub gatunku nie może być 
zapłacona cena niższa od ceny określonej (cena minimalna), sprzedawcy, który 
otrzymał cenę niższą, przysługuje roszczenie o dopłatę różnicy.

***
## Art. 540. {#art-540}

§ 1. Jeżeli właściwy organ państwowy ustalił, w jaki sposób 
sprzedawca ma obliczyć cenę za rzeczy danego rodzaju lub gatunku (cena wynikowa), 
stosuje się, zależnie od właściwości takiej ceny, bądź przepisy o cenie sztywnej, bądź 
przepisy o cenie maksymalnej. 
§ 2. W razie sporu co do prawidłowości obliczenia ceny wynikowej cenę tę ustali 
sąd. 

©Kancelaria Sejmu 
 
 
 
s. 110/242 
 
   
 
2025-09-09

***
## Art. 541. {#art-541}

Wynikające z przepisów o cenie sztywnej, maksymalnej, minimalnej 
lub wynikowej roszczenie sprzedawcy o dopłatę różnicy ceny, jak również roszczenie 
kupującego o zwrot tej różnicy przedawnia się z upływem roku od dnia zapłaty.

***
## Art. 542. {#art-542}

(uchylony)

***
## Art. 543. {#art-543}

Wystawienie rzeczy w miejscu sprzedaży na widok publiczny 
z oznaczeniem ceny uważa się za ofertę sprzedaży.

***
## Art. 5431. {#art-5431}

§ 1. Jeżeli kupującym jest konsument, sprzedawca obowiązany jest 
niezwłocznie wydać rzecz kupującemu, nie później niż trzydzieści dni od dnia 
zawarcia umowy, chyba że umowa stanowi inaczej. 
§ 2. W razie opóźnienia sprzedawcy kupujący może wyznaczyć dodatkowy 
termin do wydania rzeczy, a po jego bezskutecznym upływie może od umowy 
odstąpić. Przepisy art. 492, art. 4921 i art. 494 stosuje się.

***
## Art. 544. {#art-544}

§ 1. Jeżeli rzecz sprzedana ma być przesłana przez sprzedawcę do 
miejsca, które nie jest miejscem spełnienia świadczenia, poczytuje się w razie 
wątpliwości, że wydanie zostało dokonane z chwilą, gdy w celu dostarczenia rzeczy 
na miejsce przeznaczenia sprzedawca powierzył ją przewoźnikowi trudniącemu się 
przewozem rzeczy tego rodzaju. 
§ 2. Jednakże kupujący obowiązany jest zapłacić cenę dopiero po nadejściu 
rzeczy na miejsce przeznaczenia i po umożliwieniu mu zbadania rzeczy.

***
## Art. 545. {#art-545}

§ 1. Sposób wydania i odebrania rzeczy sprzedanej powinien zapewnić 
jej całość i nienaruszalność; w szczególności sposób opakowania i przewozu 
powinien odpowiadać właściwościom rzeczy. 
§ 2. W razie przesłania rzeczy sprzedanej na miejsce przeznaczenia za 
pośrednictwem przewoźnika, kupujący obowiązany jest zbadać przesyłkę w czasie 
i w sposób przyjęty przy przesyłkach tego rodzaju; jeżeli stwierdził, że w czasie prze-
wozu nastąpił ubytek lub uszkodzenie rzeczy, obowiązany jest dokonać wszelkich 
czynności niezbędnych do ustalenia odpowiedzialności przewoźnika.

***
## Art. 546. {#art-546}

§ 1. Sprzedawca obowiązany jest przed zawarciem umowy udzielić 
kupującemu 
potrzebnych 
wyjaśnień 
o stosunkach 
prawnych 
i faktycznych 
dotyczących rzeczy. 

©Kancelaria Sejmu 
 
 
 
s. 111/242 
 
   
 
2025-09-09 
 
§ 2. Sprzedawca obowiązany jest wydać posiadane przez siebie dokumenty, 
które dotyczą rzeczy. Jeżeli treść takiego dokumentu dotyczy także innych rzeczy, 
sprzedawca obowiązany jest wydać uwierzytelniony wyciąg z dokumentu. Ponadto, 
jeżeli jest to potrzebne do należytego korzystania z rzeczy zgodnie z jej 
przeznaczeniem, sprzedawca obowiązany jest załączyć instrukcję i udzielić wyjaśnień 
dotyczących sposobu korzystania z rzeczy.

***
## Art. 5461. {#art-5461}

§ 1. Jeżeli kupującym jest konsument, sprzedawca jest obowiązany 
udzielić mu przed zawarciem umowy jasnych, zrozumiałych i niewprowadzających 
w błąd informacji w języku polskim, wystarczających do prawidłowego i pełnego 
korzystania z rzeczy sprzedanej. W szczególności należy podać: rodzaj rzeczy, 
określenie jej producenta lub importera, znak bezpieczeństwa i znak zgodności 
wymagane przez odrębne przepisy, informacje o dopuszczeniu do obrotu 
w Rzeczypospolitej Polskiej oraz, stosownie do rodzaju rzeczy, określenie jego 
energochłonności, a także inne dane wskazane w odrębnych przepisach. 
§ 2. Jeżeli rzecz jest sprzedawana w opakowaniu jednostkowym lub w zestawie, 
informacje, o których mowa w § 1, powinny znajdować się na rzeczy sprzedanej lub 
być z nią trwale połączone. W pozostałych przypadkach sprzedawca jest obowiązany 
umieścić w miejscu sprzedaży informację, która może być ograniczona do rodzaju 
rzeczy, jej głównej cechy użytkowej oraz wskazania producenta lub importera rzeczy. 
§ 3. Sprzedawca jest obowiązany zapewnić w miejscu sprzedaży odpowiednie 
warunki techniczno-organizacyjne umożliwiające dokonanie wyboru rzeczy 
sprzedanej i sprawdzenie jej jakości, kompletności oraz funkcjonowania głównych 
mechanizmów i podstawowych podzespołów. 
§ 4. Na żądanie kupującego sprzedawca jest obowiązany wyjaśnić znaczenie 
poszczególnych postanowień umowy. 
§ 5. Sprzedawca jest obowiązany wydać kupującemu wraz z rzeczą sprzedaną 
wszystkie elementy jej wyposażenia oraz sporządzone w języku polskim instrukcje 
obsługi, konserwacji i inne dokumenty wymagane przez odrębne przepisy.

***
## Art. 547. {#art-547}

§ 1. Jeżeli ani z umowy, ani z zarządzeń określających cenę nie 
wynika, kogo obciążają koszty wydania i odebrania rzeczy, sprzedawca ponosi koszty 
wydania, 
w szczególności 
koszty 
zmierzenia 
lub 
zważenia, 
opakowania, 

©Kancelaria Sejmu 
 
 
 
s. 112/242 
 
   
 
2025-09-09 
 
ubezpieczenia za czas przewozu i koszty przesłania rzeczy, a koszty odebrania ponosi 
kupujący. 
§ 2. Jeżeli rzecz ma być przesłana do miejsca, które nie jest miejscem spełnienia 
świadczenia, koszty ubezpieczenia i przesłania ponosi kupujący. 
§ 3. Koszty niewymienione w paragrafach poprzedzających ponoszą obie strony 
po połowie.

***
## Art. 548. {#art-548}

§ 1. Z chwilą wydania rzeczy sprzedanej przechodzą na kupującego 
korzyści i ciężary związane z rzeczą oraz niebezpieczeństwo przypadkowej utraty lub 
uszkodzenia rzeczy. 
§ 2. Jeżeli strony zastrzegły inną chwilę przejścia korzyści i ciężarów, poczytuje 
się w razie wątpliwości, że niebezpieczeństwo przypadkowej utraty lub uszkodzenia 
rzeczy przechodzi na kupującego z tą samą chwilą. 
§ 3. Jeżeli rzecz sprzedana ma zostać przesłana przez sprzedawcę kupującemu 
będącemu konsumentem, niebezpieczeństwo przypadkowej utraty lub uszkodzenia 
rzeczy przechodzi na kupującego z chwilą jej wydania kupującemu. Za wydanie 
rzeczy uważa się jej powierzenie przez sprzedawcę przewoźnikowi, jeżeli sprzedawca 
nie miał wpływu na wybór przewoźnika przez kupującego. Postanowienia mniej 
korzystne dla kupującego są nieważne.

***
## Art. 549. {#art-549}

Jeżeli kupujący zastrzegł sobie oznaczenie kształtu, wymiaru lub 
innych właściwości rzeczy albo terminu i miejsca wydania, a dopuszcza się zwłoki 
z dokonaniem oznaczenia, sprzedawca może: 
- 1) wykonać uprawnienia, które przysługują wierzycielowi w razie zwłoki dłużnika 
ze spełnieniem świadczenia wzajemnego, albo 
- 2) dokonać sam oznaczenia i podać je do wiadomości kupującego wyznaczając mu 
odpowiedni termin do odmiennego oznaczenia; po bezskutecznym upływie 
wyznaczonego terminu oznaczenie dokonane przez sprzedawcę staje się dla 
kupującego wiążące.

***
## Art. 550. {#art-550}

Jeżeli w umowie sprzedaży zastrzeżona została na rzecz kupującego 
wyłączność bądź w ten sposób, że sprzedawca nie będzie dostarczał rzeczy 
określonego rodzaju innym osobom, bądź też w ten sposób, że kupujący będzie 
jedynym odprzedawcą zakupionych rzeczy na oznaczonym obszarze, sprzedawca nie 
może w zakresie, w którym wyłączność została zastrzeżona, ani bezpośrednio, ani 

©Kancelaria Sejmu 
 
 
 
s. 113/242 
 
   
 
2025-09-09 
 
pośrednio zawierać umów sprzedaży, które mogłyby naruszyć wyłączność 
przysługującą kupującemu.

***
## Art. 551. {#art-551}

§ 1. Jeżeli kupujący dopuścił się zwłoki z odebraniem rzeczy 
sprzedanej, 
sprzedawca 
może 
oddać 
rzecz 
na 
przechowanie 
na 
koszt 
i niebezpieczeństwo kupującego. 
§ 2. Sprzedawca może również sprzedać rzecz na rachunek kupującego, 
powinien jednak uprzednio wyznaczyć kupującemu dodatkowy termin do odebrania, 
chyba że wyznaczenie terminu nie jest możliwe albo że rzecz jest narażona na 
zepsucie, albo że z innych względów groziłaby szkoda. O dokonaniu sprzedaży 
sprzedawca obowiązany jest niezwłocznie zawiadomić kupującego.

***
## Art. 552. {#art-552}

Jeżeli kupujący dopuścił się zwłoki z zapłatą ceny za dostarczoną część 
rzeczy sprzedanych albo jeżeli ze względu na jego stan majątkowy jest wątpliwe, czy 
zapłata ceny za część rzeczy, które mają być dostarczone później, nastąpi w terminie, 
sprzedawca może powstrzymać się z dostarczeniem dalszych części rzeczy 
sprzedanych wyznaczając kupującemu odpowiedni termin do zabezpieczenia zapłaty, 
a po bezskutecznym upływie wyznaczonego terminu może od umowy odstąpić.

***
## Art. 553. {#art-553}

(uchylony)

***
## Art. 554. {#art-554}

Roszczenia z tytułu sprzedaży dokonanej w zakresie działalności 
przedsiębiorstwa sprzedawcy, roszczenia rzemieślników z takiego tytułu oraz 
roszczenia prowadzących gospodarstwa rolne z tytułu sprzedaży płodów rolnych 
i leśnych przedawniają się z upływem lat dwóch.

***
## Art. 555. {#art-555}

Przepisy o sprzedaży rzeczy stosuje się odpowiednio do sprzedaży 
energii, praw oraz wody.

***
## Art. 5551. {#art-5551}

(uchylony) 
## DZIAŁ II. Rękojmia za wady

***
## Art. 556. {#art-556}

Sprzedawca jest odpowiedzialny względem kupującego, jeżeli rzecz 
sprzedana ma wadę (rękojmia).

***
## Art. 5561. {#art-5561}

§ 1. Wada polega na niezgodności rzeczy sprzedanej z umową. 
W szczególności rzecz sprzedana jest niezgodna z umową, jeżeli: 

©Kancelaria Sejmu 
 
 
 
s. 114/242 
 
   
 
2025-09-09 
- 1) nie ma właściwości, które rzecz tego rodzaju powinna mieć ze względu na cel 
w umowie oznaczony albo wynikający z okoliczności lub przeznaczenia; 
- 2) nie ma właściwości, o których istnieniu sprzedawca zapewnił kupującego, w tym 
przedstawiając próbkę lub wzór; 
- 3) nie nadaje się do celu, o którym kupujący poinformował sprzedawcę przy 
zawarciu umowy, a sprzedawca nie zgłosił zastrzeżenia co do takiego jej 
przeznaczenia; 
- 4) została kupującemu wydana w stanie niezupełnym. 
§ 2. Jeżeli kupującym jest konsument, na równi z zapewnieniem sprzedawcy 
traktuje się publiczne zapewnienia producenta lub jego przedstawiciela, osoby, która 
wprowadza rzecz do obrotu w zakresie swojej działalności gospodarczej, oraz osoby, 
która przez umieszczenie na rzeczy sprzedanej swojej nazwy, znaku towarowego lub 
innego oznaczenia odróżniającego przedstawia się jako producent. 
§ 3. Rzecz sprzedana ma wadę także w razie nieprawidłowego jej zamontowania 
i uruchomienia, jeżeli czynności te zostały wykonane przez sprzedawcę lub osobę 
trzecią, za którą sprzedawca ponosi odpowiedzialność, albo przez kupującego, który 
postąpił według instrukcji otrzymanej od sprzedawcy.

***
## Art. 5562. {#art-5562}

Jeżeli kupującym jest konsument, a wada została stwierdzona przed 
upływem roku od dnia wydania rzeczy sprzedanej, domniemywa się, że wada lub jej 
przyczyna istniała w chwili przejścia niebezpieczeństwa na kupującego.

***
## Art. 5563. {#art-5563}

Rzecz dotknięta jest wadą prawną, jeżeli stanowi własność osoby 
trzeciej, jest obciążona prawem osoby trzeciej albo ograniczenie w korzystaniu lub 
rozporządzaniu rzeczą wynika z decyzji lub orzeczenia właściwego organu. 
W przypadku sprzedaży prawa wada prawna może również polegać na nieistnieniu 
prawa. Pozostałe wady stanowią wady fizyczne.

***
## Art. 5564. {#art-5564}

<§ 1.> Zawarte w niniejszym dziale przepisy dotyczące konsumenta, 
z wyjątkiem art. 558 § 1 zdanie drugie, stosuje się do osoby fizycznej zawierającej 
umowę bezpośrednio związaną z jej działalnością gospodarczą, gdy z treści tej umowy 
wynika, że nie posiada ona dla tej osoby charakteru zawodowego, wynikającego 
w szczególności z przedmiotu wykonywanej przez nią działalności gospodarczej, 
udostępnionego na podstawie przepisów o Centralnej Ewidencji i Informacji 
o Działalności Gospodarczej. 
Ozn. § 1 oraz 
dodany § 2 w art. 

wejdą 
w 
życie 
z 
dn. 
27.11.2025 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 

©Kancelaria Sejmu 
 
 
 
s. 115/242 
 
   
 
2025-09-09 
 
<§ 2. Jeżeli z treści umowy, która ma być zawarta, nie wynika, czy posiada 
ona charakter zawodowy dla osoby fizycznej, o której mowa w § 1, osoba ta 
najpóźniej w chwili zawarcia umowy może złożyć oświadczenie, że umowa 
posiada dla niej charakter zawodowy albo że nie posiada takiego charakteru. 
Druga strona umowy nie może jednak uzależnić zawarcia umowy od złożenia 
takiego oświadczenia.>

***
## Art. 5565. {#art-5565}

<§ 1.>Przepisów art. 563 oraz art. 567 § 2 dotyczących kupującego 
nie stosuje się do osoby fizycznej zawierającej umowę bezpośrednio związaną z jej 
działalnością gospodarczą, gdy z treści tej umowy wynika, że nie posiada ona dla tej 
osoby charakteru zawodowego, wynikającego w szczególności z przedmiotu 
wykonywanej przez nią działalności gospodarczej, udostępnionego na podstawie 
przepisów o Centralnej Ewidencji i Informacji o Działalności Gospodarczej. 
<§ 2. Jeżeli z treści umowy, która ma być zawarta, nie wynika, czy posiada 
ona charakter zawodowy dla osoby fizycznej, o której mowa w § 1, osoba ta 
najpóźniej w chwili zawarcia umowy może złożyć oświadczenie, że umowa 
posiada dla niej charakter zawodowy albo że nie posiada takiego charakteru. 
Druga strona umowy nie może jednak uzależnić zawarcia umowy od złożenia 
takiego oświadczenia.>

***
## Art. 557. {#art-557}

§ 1. Sprzedawca jest zwolniony od odpowiedzialności z tytułu 
rękojmi, jeżeli kupujący wiedział o wadzie w chwili zawarcia umowy. 
§ 2. Gdy przedmiotem sprzedaży są rzeczy oznaczone tylko co do gatunku albo 
rzeczy 
mające 
powstać 
w 
przyszłości, 
sprzedawca 
jest 
zwolniony 
od 
odpowiedzialności z tytułu rękojmi, jeżeli kupujący wiedział o wadzie w chwili 
wydania rzeczy.  
§ 3. Sprzedawca nie jest odpowiedzialny względem kupującego będącego 
konsumentem za to, że rzecz sprzedana nie ma właściwości wynikających 
z publicznych zapewnień, o których mowa w art. 5561 § 2, jeżeli zapewnień tych nie 
znał ani, oceniając rozsądnie, nie mógł znać albo nie mogły one mieć wpływu na 
decyzję kupującego o zawarciu umowy sprzedaży, albo gdy ich treść została 
sprostowana przed zawarciem umowy sprzedaży.

***
## Art. 558. {#art-558}

§ 1. Strony mogą odpowiedzialność z tytułu rękojmi rozszerzyć, 
ograniczyć lub wyłączyć. Jeżeli kupującym jest konsument, ograniczenie lub 
Ozn. § 1 oraz 
dodany § 2 w art. 

wejdą 
w 
życie 
z 
dn. 
27.11.2025 r. (Dz. 
U. z 2025 r. poz. 
1172). 
 
 

©Kancelaria Sejmu 
 
 
 
s. 116/242 
 
   
 
2025-09-09 
 
wyłączenie odpowiedzialności z tytułu rękojmi jest dopuszczalne tylko w 
przypadkach określonych w przepisach szczególnych. 
§ 2. Wyłączenie lub ograniczenie odpowiedzialności z tytułu rękojmi jest 
bezskuteczne, jeżeli sprzedawca zataił podstępnie wadę przed kupującym.

***
## Art. 559. {#art-559}

Sprzedawca jest odpowiedzialny z tytułu rękojmi za wady fizyczne, 
które istniały w chwili przejścia niebezpieczeństwa na kupującego lub wynikły 
z przyczyny tkwiącej w rzeczy sprzedanej w tej samej chwili.

***
## Art. 560. {#art-560}

§ 1. Jeżeli rzecz sprzedana ma wadę, kupujący może złożyć 
oświadczenie o obniżeniu ceny albo odstąpieniu od umowy, chyba że sprzedawca 
niezwłocznie i bez nadmiernych niedogodności dla kupującego wymieni rzecz wad-
liwą na wolną od wad albo wadę usunie. Ograniczenie to nie ma zastosowania, jeżeli 
rzecz była już wymieniona lub naprawiana przez sprzedawcę albo sprzedawca nie 
uczynił zadość obowiązkowi wymiany rzeczy na wolną od wad lub usunięcia wady. 
§ 2. (uchylony) 
§ 3. Obniżona cena powinna pozostawać w takiej proporcji do ceny wynikającej 
z umowy, w jakiej wartość rzeczy z wadą pozostaje do wartości rzeczy bez wady. 
§ 4. Kupujący nie może odstąpić od umowy, jeżeli wada jest nieistotna.

***
## Art. 561. {#art-561}

§ 1. Jeżeli rzecz sprzedana ma wadę, kupujący może żądać wymiany 
rzeczy na wolną od wad albo usunięcia wady. 
§ 2. Sprzedawca jest obowiązany wymienić rzecz wadliwą na wolną od wad lub 
usunąć wadę w rozsądnym czasie bez nadmiernych niedogodności dla kupującego. 
§ 3. Sprzedawca może odmówić zadośćuczynienia żądaniu kupującego, jeżeli 
doprowadzenie do zgodności z umową rzeczy wadliwej w sposób wybrany przez 
kupującego jest niemożliwe albo w porównaniu z drugim możliwym sposobem 
doprowadzenia do zgodności z umową wymagałoby nadmiernych kosztów. Jeżeli 
kupującym jest przedsiębiorca, sprzedawca może odmówić wymiany rzeczy na wolną 
od wad lub usunięcia wady także wtedy, gdy koszty zadośćuczynienia temu 
obowiązkowi przewyższają cenę rzeczy sprzedanej.

***
## Art. 5611. {#art-5611}

§ 1. Jeżeli rzecz wadliwa została zamontowana, kupujący może żądać 
od sprzedawcy demontażu i ponownego zamontowania po dokonaniu wymiany na 
wolną od wad lub usunięciu wady. W razie niewykonania tego obowiązku przez 

©Kancelaria Sejmu 
 
 
 
s. 117/242 
 
   
 
2025-09-09 
 
sprzedawcę kupujący jest upoważniony do dokonania tych czynności na koszt 
i niebezpieczeństwo sprzedawcy. 
§ 2. Sprzedawca może odmówić demontażu i ponownego zamontowania, jeżeli 
koszt tych czynności przewyższa cenę rzeczy sprzedanej. 
§ 3. (uchylony)

***
## Art. 5612. {#art-5612}

§ 1. Kupujący, który wykonuje uprawnienia z tytułu rękojmi, jest 
obowiązany na koszt sprzedawcy dostarczyć rzecz wadliwą do miejsca oznaczonego 
w umowie sprzedaży, a gdy takiego miejsca nie określono w umowie – do miejsca, 
w którym rzecz została wydana kupującemu. 
§ 2. Jeżeli ze względu na rodzaj rzeczy lub sposób jej zamontowania dostarczenie 
rzeczy przez kupującego byłoby nadmiernie utrudnione, kupujący obowiązany jest 
udostępnić rzecz sprzedawcy w miejscu, w którym rzecz się znajduje. 
§ 3. Przepisy § 1 i 2 stosuje się do zwrotu rzeczy w razie odstąpienia od umowy 
i wymiany rzeczy na wolną od wad.

***
## Art. 5613. {#art-5613}

Z zastrzeżeniem art. 5611 § 2 koszty wymiany lub naprawy ponosi 
sprzedawca. W szczególności obejmuje to koszty demontażu i dostarczenia rzeczy, 
robocizny, materiałów oraz ponownego zamontowania i uruchomienia.

***
## Art. 5614. {#art-5614}

Sprzedawca obowiązany jest przyjąć od kupującego rzecz wadliwą 
w razie wymiany rzeczy na wolną od wad lub odstąpienia od umowy.

***
## Art. 5615. {#art-5615}

Jeżeli kupujący będący konsumentem zażądał wymiany rzeczy lub 
usunięcia wady albo złożył oświadczenie o obniżeniu ceny, określając kwotę, o którą 
cena ma być obniżona, a sprzedawca nie ustosunkował się do tego żądania w terminie 
czternastu dni, uważa się, że żądanie to uznał za uzasadnione.

***
## Art. 562. {#art-562}

Jeżeli w umowie sprzedaży zastrzeżono, że dostarczenie rzeczy 
sprzedanych ma nastąpić częściami, a sprzedawca mimo żądania kupującego nie 
dostarczył zamiast rzeczy wadliwych takiej samej ilości rzeczy wolnych od wad, 
kupujący może od umowy odstąpić także co do części rzeczy, które mają być 
dostarczone później. 
§ 2. (uchylony)

***
## Art. 563. {#art-563}

§ 1. Przy sprzedaży między przedsiębiorcami kupujący traci 
uprawnienia z tytułu rękojmi, jeżeli nie zbadał rzeczy w czasie i w sposób przyjęty 

©Kancelaria Sejmu 
 
 
 
s. 118/242 
 
   
 
2025-09-09 
 
przy rzeczach tego rodzaju i nie zawiadomił niezwłocznie sprzedawcy o wadzie, 
a w przypadku gdy wada wyszła na jaw dopiero później – jeżeli nie zawiadomił 
sprzedawcy niezwłocznie po jej stwierdzeniu. 
§ 2. Do zachowania powyższego terminu wystarczy wysłanie przed jego 
upływem zawiadomienia o wadzie.

***
## Art. 564. {#art-564}

W przypadkach przewidzianych w art. 563 utrata uprawnień z tytułu 
rękojmi za wady fizyczne rzeczy nie następuje mimo niezachowania terminów do 
zbadania rzeczy przez kupującego lub do zawiadomienia sprzedawcy o wadzie, jeżeli 
sprzedawca wiedział o wadzie albo zapewnił kupującego, że wady nie istnieją.

***
## Art. 565. {#art-565}

Jeżeli spośród rzeczy sprzedanych tylko niektóre są wadliwe i dają się 
odłączyć od rzeczy wolnych od wad, bez szkody dla stron obu, uprawnienie 
kupującego do odstąpienia od umowy ogranicza się do rzeczy wadliwych.

***
## Art. 566. {#art-566}

§ 1. Jeżeli z powodu wady fizycznej rzeczy sprzedanej kupujący złożył 
oświadczenie o odstąpieniu od umowy albo obniżeniu ceny, może on żądać 
naprawienia szkody, którą poniósł przez to, że zawarł umowę, nie wiedząc o istnieniu 
wady, choćby szkoda była następstwem okoliczności, za które sprzedawca nie ponosi 
odpowiedzialności, a w szczególności może żądać zwrotu kosztów zawarcia umowy, 
kosztów odebrania, przewozu, przechowania i ubezpieczenia rzeczy oraz zwrotu 
dokonanych nakładów w takim zakresie, w jakim nie odniósł korzyści z tych 
nakładów. Nie uchybia to przepisom o obowiązku naprawienia szkody na zasadach 
ogólnych. 
§ 2. Przepis § 1 stosuje się odpowiednio w razie dostarczenia rzeczy wolnej od 
wad zamiast rzeczy wadliwej albo usunięcia wady przez sprzedawcę.

***
## Art. 567. {#art-567}

§ 1. Jeżeli sprzedawca dopuszcza się zwłoki z odebraniem rzeczy, 
kupujący może odesłać rzecz na koszt i niebezpieczeństwo sprzedawcy. 
§ 2. W przypadku 
sprzedaży 
między 
przedsiębiorcami 
kupujący 
jest 
uprawniony, a gdy interes sprzedawcy tego wymaga – obowiązany sprzedać rzecz 
z zachowaniem należytej staranności, jeżeli istnieje niebezpieczeństwo pogorszenia 
rzeczy. O zamiarze sprzedaży kupujący powinien w miarę możliwości zawiadomić 
sprzedawcę, w każdym zaś razie powinien wysłać mu zawiadomienie niezwłocznie po 
dokonaniu sprzedaży. Kupujący może również odesłać rzecz sprzedawcy na jego koszt 
i niebezpieczeństwo. 

©Kancelaria Sejmu 
 
 
 
s. 119/242 
 
   
 
2025-09-09

***
## Art. 568. {#art-568}

§ 1. Sprzedawca odpowiada z tytułu rękojmi, jeżeli wada fizyczna 
zostanie stwierdzona przed upływem dwóch lat, a gdy chodzi o wady nieruchomości 
– przed upływem pięciu lat od dnia wydania rzeczy kupującemu.  
§ 2. Roszczenie o usunięcie wady lub wymianę rzeczy sprzedanej na wolną od 
wad przedawnia się z upływem roku, licząc od dnia stwierdzenia wady. Jeżeli 
kupującym jest konsument, bieg terminu przedawnienia nie może zakończyć się przed 
upływem terminów określonych w § 1 zdanie pierwsze. 
§ 3. W terminach określonych w § 2 kupujący może złożyć oświadczenie 
o odstąpieniu od umowy albo obniżeniu ceny z powodu wady rzeczy sprzedanej. 
Jeżeli kupujący żądał wymiany rzeczy na wolną od wad lub usunięcia wady, bieg 
terminu do złożenia oświadczenia o odstąpieniu od umowy albo obniżeniu ceny 
rozpoczyna się z chwilą bezskutecznego upływu terminu do wymiany rzeczy lub 
usunięcia wady. 
§ 4. W razie dochodzenia przed sądem albo sądem polubownym jednego 
z uprawnień 
z tytułu 
rękojmi 
termin 
do 
wykonania 
innych 
uprawnień, 
przysługujących 
kupującemu 
z tego 
tytułu, 
ulega 
zawieszeniu 
do 
czasu 
prawomocnego zakończenia postępowania. 
§ 5. Przepis § 4 stosuje się odpowiednio do postępowania mediacyjnego, przy 
czym termin do wykonania innych uprawnień z tytułu rękojmi, przysługujących 
kupującemu, zaczyna biec od dnia odmowy przez sąd zatwierdzenia ugody zawartej 
przed mediatorem lub bezskutecznego zakończenia mediacji. 
§ 6. Upływ terminu do stwierdzenia wady nie wyłącza wykonania uprawnień 
z tytułu rękojmi, jeżeli sprzedawca wadę podstępnie zataił.

***
## Art. 5681. {#art-5681}

Jeżeli 
określony 
przez 
sprzedawcę 
lub 
producenta 
termin 
przydatności rzeczy do użycia kończy się po upływie dwóch lat od dnia wydania 
rzeczy kupującemu, sprzedawca odpowiada z tytułu rękojmi za wady fizyczne tej 
rzeczy stwierdzone przed upływem tego terminu. Przepis art. 568 § 6 stosuje się.

***
## Art. 569. {#art-569}

(uchylony)

***
## Art. 570. {#art-570}

(uchylony)

***
## Art. 571. {#art-571}

(uchylony)

***
## Art. 572. {#art-572}

(uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 120/242 
 
   
 
2025-09-09

***
## Art. 5721. {#art-5721}

(uchylony)

***
## Art. 573. {#art-573}

Kupujący, przeciwko któremu osoba trzecia dochodzi roszczeń 
dotyczących rzeczy sprzedanej, obowiązany jest niezwłocznie zawiadomić o tym 
sprzedawcę i wezwać go do wzięcia udziału w sprawie. Jeżeli tego zaniechał, a osoba 
trzecia uzyskała orzeczenie dla siebie korzystne, sprzedawca zostaje zwolniony od 
odpowiedzialności z tytułu rękojmi za wadę prawną o tyle, o ile jego udział 
w postępowaniu był potrzebny do wykazania, że roszczenia osoby trzeciej były 
całkowicie lub częściowo bezzasadne.

***
## Art. 574. {#art-574}

§ 1. Jeżeli z powodu wady prawnej rzeczy sprzedanej kupujący złożył 
oświadczenie o odstąpieniu od umowy albo obniżeniu ceny, może on żądać 
naprawienia szkody, którą poniósł przez to, że zawarł umowę, nie wiedząc o istnieniu 
wady, choćby szkoda była następstwem okoliczności, za które sprzedawca nie ponosi 
odpowiedzialności, a w szczególności może żądać zwrotu kosztów zawarcia umowy, 
kosztów odebrania, przewozu, przechowania i ubezpieczenia rzeczy, zwrotu 
dokonanych nakładów w takim zakresie, w jakim nie odniósł z nich korzyści, a nie 
otrzymał ich zwrotu od osoby trzeciej, oraz zwrotu kosztów procesu. Nie uchybia to 
przepisom o obowiązku naprawienia szkody na zasadach ogólnych. 
§ 2. Przepis § 1 stosuje się odpowiednio w razie dostarczenia rzeczy wolnej od 
wad zamiast rzeczy wadliwej.

***
## Art. 575. {#art-575}

Jeżeli z powodu wady prawnej rzeczy sprzedanej kupujący jest 
zmuszony wydać rzecz osobie trzeciej, umowne wyłączenie odpowiedzialności 
z tytułu rękojmi nie zwalnia sprzedawcy od obowiązku zwrotu otrzymanej ceny, 
chyba że kupujący wiedział, iż prawa sprzedawcy były sporne, albo że nabył rzecz na 
własne niebezpieczeństwo.

***
## Art. 5751. {#art-5751}

Jeżeli kupujący uniknął utraty w całości lub w części nabytej rzeczy, 
albo skutków jej obciążenia na korzyść osoby trzeciej przez zapłatę sumy pieniężnej 
lub spełnienie innego świadczenia, sprzedawca może zwolnić się od odpo-
wiedzialności z tytułu rękojmi, zwracając kupującemu zapłaconą sumę lub wartość 
spełnionego świadczenia wraz z odsetkami i kosztami.

***
## Art. 576. {#art-576}

Do wykonywania uprawnień z tytułu rękojmi za wady prawne rzeczy 
sprzedanej stosuje się przepisy art. 568 § 2–5, z tym że bieg terminu, o którym mowa 
w art. 568 § 2, rozpoczyna się od dnia, w którym kupujący dowiedział się o istnieniu 

©Kancelaria Sejmu 
 
 
 
s. 121/242 
 
   
 
2025-09-09 
 
wady, a jeżeli kupujący dowiedział się o istnieniu wady dopiero na skutek powództwa 
osoby trzeciej – od dnia, w którym orzeczenie wydane w sporze z osobą trzecią stało 
się prawomocne. 
## DZIAŁ II1. (uchylony) 
## DZIAŁ III. Gwarancja przy sprzedaży

***
## Art. 577. {#art-577}

§ 1. Udzielenie gwarancji następuje przez złożenie oświadczenia 
gwarancyjnego, które określa obowiązki gwaranta i uprawnienia kupującego 
w przypadku, gdy rzecz sprzedana nie ma właściwości określonych w tym 
oświadczeniu. Oświadczenie gwarancyjne może zostać złożone w reklamie. 
§ 2. Obowiązki gwaranta mogą w szczególności polegać na zwrocie zapłaconej 
ceny, wymianie rzeczy bądź jej naprawie oraz zapewnieniu innych usług. 
§ 3. Jeżeli została udzielona gwarancja co do jakości rzeczy sprzedanej, 
poczytuje się w razie wątpliwości, że gwarant jest obowiązany do usunięcia wady 
fizycznej rzeczy lub do dostarczenia rzeczy wolnej od wad, o ile wady te ujawnią się 
w ciągu terminu określonego w oświadczeniu gwarancyjnym. 
§ 4. Jeżeli nie zastrzeżono innego terminu, termin gwarancji wynosi dwa lata 
licząc od dnia, kiedy rzecz została kupującemu wydana.

***
## Art. 5771. {#art-5771}

§ 1. Gwarant formułuje oświadczenie gwarancyjne w sposób jasny 
i zrozumiały, a gdy rodzaj informacji na to pozwala – w powszechnie zrozumiałej 
formie graficznej. Jeżeli rzecz jest wprowadzana do obrotu w Rzeczypospolitej 
Polskiej, oświadczenie gwarancyjne sporządza się w języku polskim. Wymagania 
używania języka polskiego nie stosuje się do nazw własnych, znaków towarowych, 
nazw handlowych, oznaczeń pochodzenia towarów oraz zwyczajowo stosowanej 
terminologii naukowej i technicznej. 
§ 2. Oświadczenie gwarancyjne zawiera:  
- 1) wyraźne stwierdzenie, że w przypadku braku zgodności rzeczy sprzedanej z 
umową kupującemu z mocy prawa przysługują środki ochrony prawnej ze strony 
i na koszt sprzedawcy oraz że gwarancja nie ma wpływu na te środki ochrony 
prawnej;  

©Kancelaria Sejmu 
 
 
 
s. 122/242 
 
   
 
2025-09-09 
- 2) nazwę i adres gwaranta;  
- 3) opis procedury, której uprawniony ma przestrzegać, aby móc skorzystać z 
gwarancji; 
- 4) wskazanie rzeczy, których dotyczy gwarancja;  
- 5) warunki gwarancji. 
§ 3. Uchybienie wymaganiom określonym w § 1 i 2 nie wpływa na ważność 
oświadczenia gwarancyjnego i nie pozbawia wynikających z niego uprawnień.

***
## Art. 5772. {#art-5772}

Uprawniony z gwarancji może żądać od gwaranta wydania 
oświadczenia gwarancyjnego utrwalonego na papierze lub innym trwałym nośniku 
(dokument gwarancyjny).

***
## Art. 5773. {#art-5773}

Sprzedawca wydaje kupującemu wraz z rzeczą sprzedaną dokument 
gwarancyjny oraz sprawdza zgodność znajdujących się na rzeczy oznaczeń z danymi 
zawartymi w dokumencie gwarancyjnym oraz stan plomb i innych umieszczonych na 
rzeczy zabezpieczeń.

***
## Art. 578. {#art-578}

Jeżeli w gwarancji inaczej nie zastrzeżono, odpowiedzialność z tytułu 
gwarancji obejmuje tylko wady powstałe z przyczyn tkwiących w sprzedanej rzeczy.

***
## Art. 579. {#art-579}

§ 1. Kupujący może wykonywać uprawnienia z tytułu niezgodności 
rzeczy sprzedanej z umową niezależnie od uprawnień wynikających z gwarancji. 
§ 2. Wykonanie uprawnień z gwarancji nie wpływa na odpowiedzialność 
sprzedawcy z tytułu niezgodności rzeczy sprzedanej z umową. 
§ 3. Jednakże w razie wykonywania przez kupującego uprawnień z gwarancji 
bieg terminu do wykonania uprawnień z tytułu niezgodności rzeczy sprzedanej z 
umową ulega zawieszeniu z dniem zawiadomienia sprzedawcy o wadzie. Termin ten 
biegnie dalej od dnia odmowy przez gwaranta wykonania obowiązków wynikających 
z gwarancji albo bezskutecznego upływu czasu na ich wykonanie.

***
## Art. 580. {#art-580}

§ 1. Kto wykonuje uprawnienia wynikające z gwarancji, powinien 
dostarczyć rzecz na koszt gwaranta do miejsca wskazanego w gwarancji lub do 
miejsca, w którym rzecz została wydana przy udzieleniu gwarancji, chyba że 
z okoliczności wynika, iż wada powinna być usunięta w miejscu, w którym rzecz 
znajdowała się w chwili ujawnienia wady. 
§ 2. Gwarant jest obowiązany wykonać swoje obowiązki w terminie określonym 
w treści oświadczenia gwarancyjnego, a gdy go nie określono – niezwłocznie, ale nie 

©Kancelaria Sejmu 
 
 
 
s. 123/242 
 
   
 
2025-09-09 
 
później niż w terminie czternastu dni, licząc od dnia dostarczenia rzeczy przez 
uprawnionego z gwarancji, oraz dostarczyć mu rzecz na swój koszt do miejsca 
wskazanego w § 1. 
§ 3. Niebezpieczeństwo przypadkowej utraty lub uszkodzenia rzeczy w czasie od 
wydania jej gwarantowi do jej odebrania przez uprawnionego z gwarancji ponosi 
gwarant.

***
## Art. 581. {#art-581}

§ 1. Jeżeli w wykonaniu swoich obowiązków gwarant dostarczył 
uprawnionemu z gwarancji zamiast rzeczy wadliwej rzecz wolną od wad albo dokonał 
istotnych napraw rzeczy objętej gwarancją, termin gwarancji biegnie na nowo od 
chwili dostarczenia rzeczy wolnej od wad lub zwrócenia rzeczy naprawionej. Jeżeli 
gwarant wymienił część rzeczy, przepis powyższy stosuje się odpowiednio do części 
wymienionej. 
§ 2. W innych wypadkach termin gwarancji ulega przedłużeniu o czas, w ciągu 
którego wskutek wady rzeczy objętej gwarancją uprawniony z gwarancji nie mógł 
z niej korzystać.

***
## Art. 582. {#art-582}

(uchylony) 
## DZIAŁ IV. Szczególne rodzaje sprzedaży 
## Rozdział I. Sprzedaż na raty

***
## Art. 583. {#art-583}

§ 1. Sprzedażą na raty jest dokonana w zakresie działalności 
przedsiębiorstwa sprzedaż rzeczy ruchomej osobie fizycznej za cenę płatną 
w określonych ratach, jeżeli według umowy rzecz ma być kupującemu wydana przed 
całkowitym zapłaceniem ceny. 
§ 2. Wystawienie przez kupującego weksli na pokrycie lub zabezpieczenie ceny 
kupna nie wyłącza stosowania przepisów rozdziału niniejszego.

***
## Art. 584. {#art-584}

§ 1. Odpowiedzialność sprzedawcy z tytułu rękojmi za wady rzeczy 
sprzedanej na raty może być przez umowę wyłączona lub ograniczona tylko 
w wypadkach przewidzianych przez przepisy szczególne. 
§ 2. Umowa nie może utrudnić kupującemu wykonania uprawnień z tytułu 
rękojmi. 

©Kancelaria Sejmu 
 
 
 
s. 124/242 
 
   
 
2025-09-09

***
## Art. 585. {#art-585}

Kupujący może płacić raty przed terminem płatności. W razie 
przedterminowej zapłaty kupujący może odliczyć kwotę, która odpowiada wysokości 
stopy procentowej obowiązującej dla danego rodzaju kredytów Narodowego Banku 
Polskiego.

***
## Art. 586. {#art-586}

§ 1. Zastrzeżenie natychmiastowej wymagalności nieuiszczonej ceny 
na wypadek uchybienia terminom poszczególnych rat jest skuteczne tylko wtedy, gdy 
było uczynione na piśmie przy zawarciu umowy, a kupujący jest w zwłoce z zapłatą 
co najmniej dwóch rat, łączna zaś suma zaległych rat przewyższa jedną piątą część 
umówionej ceny. 
§ 2. Sprzedawca może odstąpić od umowy z powodu niezapłacenia ceny tylko 
wtedy, gdy kupujący jest w zwłoce z zapłatą co najmniej dwóch rat, a łączna suma 
zaległych rat przewyższa jedną piątą część umówionej ceny. W wypadku takim 
sprzedawca powinien wyznaczyć kupującemu odpowiedni termin dodatkowy do 
zapłacenia zaległości z zagrożeniem, iż w razie bezskutecznego upływu 
wyznaczonego terminu będzie uprawniony do odstąpienia od umowy. 
§ 3. Postanowienia umowne mniej korzystne dla kupującego są nieważne. 
Zamiast nich stosuje się przepisy niniejszego artykułu.

***
## Art. 587. {#art-587}

Przepisów rozdziału niniejszego nie stosuje się do sprzedaży na raty, 
jeżeli kupujący nabył rzecz w zakresie działalności swego przedsiębiorstwa.

***
## Art. 588. {#art-588}

§ 1. Przepisy rozdziału niniejszego stosuje się odpowiednio 
w wypadkach, gdy rzecz ruchoma zostaje sprzedana osobie fizycznej korzystającej 
z kredytu udzielonego w tym celu przez bank, jeżeli kredyt ten ma być spłacony 
ratami, a rzecz została kupującemu wydana przed całkowitą spłatą kredytu. 
§ 2. Do zabezpieczenia roszczeń banku, który kredytu udziela, przysługuje mu 
ustawowe prawo zastawu na rzeczy sprzedanej, dopóki rzecz znajduje się 
u kupującego. 
§ 3. Odpowiedzialność z tytułu rękojmi za wady rzeczy ponosi wyłącznie 
sprzedawca. 

©Kancelaria Sejmu 
 
 
 
s. 125/242 
 
   
 
2025-09-09 
## Rozdział II. Zastrzeżenie własności rzeczy sprzedanej. Sprzedaż na próbę

***
## Art. 589. {#art-589}

Jeżeli sprzedawca zastrzegł sobie własność sprzedanej rzeczy 
ruchomej aż do uiszczenia ceny, poczytuje się w razie wątpliwości, że przeniesienie 
własności rzeczy nastąpiło pod warunkiem zawieszającym.

***
## Art. 590. {#art-590}

§ 1. Jeżeli rzecz zostaje kupującemu wydana, zastrzeżenie własności 
powinno być stwierdzone pismem. Jest ono skuteczne względem wierzycieli 
kupującego, jeżeli pismo ma datę pewną. 
§ 2. (uchylony)

***
## Art. 591. {#art-591}

W razie zastrzeżenia prawa własności sprzedawca odbierając rzecz 
może żądać odpowiedniego wynagrodzenia za zużycie lub uszkodzenie rzeczy.

***
## Art. 592. {#art-592}

§ 1. Sprzedaż na próbę albo z zastrzeżeniem zbadania rzeczy przez 
kupującego poczytuje się w razie wątpliwości za zawartą pod warunkiem 
zawieszającym, że kupujący uzna przedmiot sprzedaży za dobry. W braku oznaczenia 
w umowie terminu próby lub zbadania rzeczy sprzedawca może wyznaczyć 
kupującemu odpowiedni termin. 
§ 2. Jeżeli kupujący rzecz odebrał i nie złożył oświadczenia przed upływem 
umówionego przez strony lub wyznaczonego przez sprzedawcę terminu, uważa się, że 
uznał przedmiot sprzedaży za dobry. 
## Rozdział III. Prawo odkupu

***
## Art. 593. {#art-593}

§ 1. Prawo odkupu może być zastrzeżone na czas nieprzenoszący lat 
pięciu; termin dłuższy ulega skróceniu do lat pięciu. 
§ 2. Prawo odkupu wykonywa się przez oświadczenie sprzedawcy złożone 
kupującemu. Jeżeli zawarcie umowy sprzedaży wymagało zachowania szczególnej 
formy, oświadczenie o wykonaniu prawa odkupu powinno być złożone w tej samej 
formie.

***
## Art. 594. {#art-594}

§ 1. Z chwilą wykonania prawa odkupu kupujący obowiązany jest 
przenieść z powrotem na sprzedawcę własność kupionej rzeczy za zwrotem ceny 
i kosztów sprzedaży oraz za zwrotem nakładów; jednakże zwrot nakładów, które 

©Kancelaria Sejmu 
 
 
 
s. 126/242 
 
   
 
2025-09-09 
 
nie stanowiły nakładów koniecznych, należy się kupującemu tylko w granicach 
istniejącego zwiększenia wartości rzeczy. 
§ 2. Jeżeli określona w umowie sprzedaży cena odkupu przenosi cenę i koszty 
sprzedaży, sprzedawca może żądać obniżenia ceny odkupu do wartości rzeczy 
w chwili wykonania prawa odkupu, jednakże nie niżej sumy obliczonej według 
paragrafu poprzedzającego.

***
## Art. 595. {#art-595}

§ 1. Prawo odkupu jest niezbywalne i niepodzielne. 
§ 2. Jeżeli jest kilku uprawnionych do odkupu, a niektórzy z nich nie 
wykonywają tego prawa, pozostali mogą je wykonać w całości. 
## Rozdział IV. Prawo pierwokupu

***
## Art. 596. {#art-596}

Jeżeli ustawa lub czynność prawna zastrzega dla jednej ze stron 
pierwszeństwo kupna oznaczonej rzeczy na wypadek, gdyby druga strona sprzedała 
rzecz osobie trzeciej (prawo pierwokupu), stosuje się w braku przepisów szczególnych 
przepisy niniejszego rozdziału.

***
## Art. 597. {#art-597}

§ 1. Rzecz, której dotyczy prawo pierwokupu, może być sprzedana 
osobie trzeciej tylko pod warunkiem, że uprawniony do pierwokupu swego prawa nie 
wykona. 
§ 2. Prawo 
pierwokupu 
wykonywa 
się 
przez 
oświadczenie 
złożone 
zobowiązanemu. Jeżeli zawarcie umowy sprzedaży rzeczy, której dotyczy prawo 
pierwokupu, wymaga zachowania szczególnej formy, oświadczenie o wykonaniu 
prawa pierwokupu powinno być złożone w tej samej formie.

***
## Art. 598. {#art-598}

§ 1. Zobowiązany z tytułu prawa pierwokupu powinien niezwłocznie 
zawiadomić uprawnionego o treści umowy sprzedaży zawartej z osobą trzecią. 
§ 2. Prawo pierwokupu co do nieruchomości można wykonać w ciągu miesiąca, 
a co do innych rzeczy – w ciągu tygodnia od otrzymania zawiadomienia o sprzedaży, 
chyba że zostały zastrzeżone inne terminy.

***
## Art. 599. {#art-599}

§ 1. Jeżeli zobowiązany z tytułu prawa pierwokupu sprzedał rzecz 
osobie trzeciej bezwarunkowo albo jeżeli nie zawiadomił uprawnionego o sprzedaży 
lub podał mu do wiadomości istotne postanowienia umowy sprzedaży niezgodnie 
z rzeczywistością, ponosi on odpowiedzialność za wynikłą stąd szkodę. 

©Kancelaria Sejmu 
 
 
 
s. 127/242 
 
   
 
2025-09-09 
 
§ 2. Jednakże jeżeli prawo pierwokupu przysługuje z mocy ustawy Skarbowi 
Państwa lub jednostce samorządu terytorialnego, współwłaścicielowi albo 
dzierżawcy, sprzedaż dokonana bezwarunkowo jest nieważna.

***
## Art. 600. {#art-600}

§ 1. Przez wykonanie prawa pierwokupu dochodzi do skutku między 
zobowiązanym a uprawnionym umowa sprzedaży tej samej treści, co umowa zawarta 
przez zobowiązanego z osobą trzecią, chyba że przepis szczególny stanowi inaczej. 
Jednakże postanowienia umowy z osobą trzecią, mające na celu udaremnienie prawa 
pierwokupu, są względem uprawnionego bezskuteczne. 
§ 2. Jeżeli umowa sprzedaży zawarta z osobą trzecią przewiduje świadczenia 
dodatkowe, których uprawniony do pierwokupu nie mógłby spełnić, może on swe 
prawo wykonać uiszczając wartość tych świadczeń. Jednakże gdy prawo pierwokupu 
przysługuje Skarbowi Państwa lub jednostce samorządu terytorialnego z mocy 
ustawy, takie świadczenie dodatkowe uważa się za niezastrzeżone.

***
## Art. 601. {#art-601}

Jeżeli według umowy sprzedaży zawartej z osobą trzecią cena ma być 
zapłacona w terminie późniejszym, uprawniony do pierwokupu może z tego terminu 
skorzystać tylko wtedy, gdy zabezpieczy zapłatę ceny. Przepisu tego nie stosuje się, 
gdy uprawnionym jest państwowa jednostka organizacyjna.

***
## Art. 602. {#art-602}

§ 1. Prawo pierwokupu jest niezbywalne. Jest ono niepodzielne, chyba 
że przepisy szczególne zezwalają na częściowe wykonanie tego prawa. 
§ 2. Jeżeli jest kilku uprawnionych, a niektórzy z nich nie wykonywają prawa 
pierwokupu, pozostali mogą wykonać je w całości. 
TYTUŁ XII 
Zamiana

***
## Art. 603. {#art-603}

Przez umowę zamiany każda ze stron zobowiązuje się przenieść na 
drugą stronę własność rzeczy w zamian za zobowiązanie się do przeniesienia 
własności innej rzeczy.

***
## Art. 604. {#art-604}

Do zamiany stosuje się odpowiednio przepisy o sprzedaży. 

©Kancelaria Sejmu 
 
 
 
s. 128/242 
 
   
 
2025-09-09 
 
TYTUŁ XIII 
Dostawa

***
## Art. 605. {#art-605}

Przez umowę dostawy dostawca zobowiązuje się do wytworzenia 
rzeczy oznaczonych tylko co do gatunku oraz do ich dostarczania częściami albo 
periodycznie, a odbiorca zobowiązuje się do odebrania tych rzeczy i do zapłacenia 
ceny.

***
## Art. 6051. {#art-6051}

(uchylony)

***
## Art. 606. {#art-606}

Umowa dostawy powinna być stwierdzona pismem.

***
## Art. 607. {#art-607}

Jeżeli surowce lub materiały niezbędne do wykonania przedmiotu 
dostawy a dostarczane przez odbiorcę są nieprzydatne do prawidłowego wykonania 
przedmiotu dostawy, dostawca obowiązany jest niezwłocznie zawiadomić o tym 
odbiorcę.

***
## Art. 608. {#art-608}

§ 1. Jeżeli w umowie zastrzeżono, że wytworzenie zamówionych 
rzeczy ma nastąpić z surowców określonego gatunku lub pochodzenia, dostawca 
powinien zawiadomić odbiorcę o ich przygotowaniu do produkcji i jest obowiązany 
zezwolić odbiorcy na sprawdzenie ich jakości. 
§ 2. Jeżeli w umowie zastrzeżono, że wytworzenie zamówionych rzeczy ma 
nastąpić w określony sposób, dostawca jest obowiązany zezwolić odbiorcy na 
sprawdzenie procesu produkcji.

***
## Art. 609. {#art-609}

Dostawca ponosi odpowiedzialność z tytułu rękojmi za wady fizyczne 
dostarczonych rzeczy także w tym wypadku, gdy wytworzenie rzeczy nastąpiło 
w sposób określony przez odbiorcę lub według dostarczonej przez niego dokumentacji 
technologicznej, chyba że dostawca, mimo zachowania należytej staranności, nie mógł 
wykryć wadliwości sposobu produkcji lub dokumentacji technologicznej albo że 
odbiorca, mimo zwrócenia przez dostawcę uwagi na powyższe wadliwości, obstawał 
przy podanym przez siebie sposobie produkcji lub dokumentacji technologicznej.

***
## Art. 610. {#art-610}

Jeżeli dostawca opóźnia się z rozpoczęciem wytwarzania przedmiotu 
dostawy lub poszczególnych jego części tak dalece, że nie jest prawdopodobne, żeby 
zdołał je dostarczyć w czasie umówionym, odbiorca może nie wyznaczając terminu 
dodatkowego od umowy odstąpić jeszcze przed upływem terminu do dostarczenia 
przedmiotu dostawy. 

©Kancelaria Sejmu 
 
 
 
s. 129/242 
 
   
 
2025-09-09

***
## Art. 611. {#art-611}

Jeżeli w toku wytwarzania przedmiotu dostawy okaże się, że dostawca 
wykonywa ten przedmiot w sposób wadliwy albo sprzeczny z umową, odbiorca może 
wezwać dostawcę do zmiany sposobu wykonania wyznaczając dostawcy w tym celu 
odpowiedni termin, a po bezskutecznym upływie wyznaczonego terminu od umowy 
odstąpić.

***
## Art. 612. {#art-612}

W przedmiotach nieuregulowanych przepisami niniejszego tytułu, do 
praw i obowiązków dostawcy i odbiorcy stosuje się odpowiednio przepisy 
o sprzedaży. 
TYTUŁ XIV 
Kontraktacja

***
## Art. 613. {#art-613}

§ 1. Przez umowę kontraktacji producent rolny zobowiązuje się 
wytworzyć i dostarczyć kontraktującemu oznaczoną ilość produktów rolnych 
określonego rodzaju, a kontraktujący zobowiązuje się te produkty odebrać w terminie 
umówionym, zapłacić umówioną cenę oraz spełnić określone świadczenie dodatkowe, 
jeżeli umowa lub przepisy szczególne przewidują obowiązek spełnienia takiego 
świadczenia. 
§ 2. Ilość produktów rolnych może być w umowie oznaczona także według 
obszaru, z którego produkty te mają być zebrane. 
§ 3. Przepisy dotyczące sprzedaży według cen sztywnych, maksymalnych, 
minimalnych i wynikowych stosuje się odpowiednio. 
§ 4. Przez producenta rolnego rozumie się również grupę producentów rolnych 
lub ich związek oraz spółdzielnię rolników w rozumieniu ustawy z dnia 4 października 
2018 r. o spółdzielniach rolników (Dz. U. z 2025 r. poz. 443) lub ich związek.

***
## Art. 614. {#art-614}

Jeżeli przedmiot kontraktacji ma być wytworzony w gospodarstwie 
prowadzonym przez kilka osób wspólnie, odpowiedzialność tych osób względem 
kontraktującego jest solidarna.

***
## Art. 615. {#art-615}

Świadczeniami dodatkowymi ze strony kontraktującego mogą być 
w szczególności: 
- 1) zapewnienie producentowi możności nabycia określonych środków produkcji 
i uzyskania pomocy finansowej; 
- 2) pomoc agrotechniczna i zootechniczna; 

©Kancelaria Sejmu 
 
 
 
s. 130/242 
 
   
 
2025-09-09 
- 3) premie pieniężne; 
- 4) premie rzeczowe.

***
## Art. 616. {#art-616}

Umowa kontraktacyjna powinna być zawarta na piśmie.

***
## Art. 617. {#art-617}

Kontraktujący 
jest 
uprawniony 
do 
nadzoru 
i kontroli 
nad 
wykonywaniem umowy kontraktacji przez producenta.

***
## Art. 618. {#art-618}

Świadczenie 
producenta 
powinno 
być 
spełnione 
w miejscu 
wytworzenia zakontraktowanych produktów, chyba że co innego wynika z umowy.

***
## Art. 619. {#art-619}

(uchylony)

***
## Art. 620. {#art-620}

Jeżeli przedmiot kontraktacji jest podzielny, kontraktujący nie może 
odmówić przyjęcia świadczenia częściowego, chyba że inaczej zastrzeżono.

***
## Art. 621. {#art-621}

Do rękojmi za wady fizyczne i prawne przedmiotu kontraktacji oraz 
środków produkcji dostarczonych producentowi przez kontraktującego stosuje się 
odpowiednio przepisy o rękojmi przy sprzedaży z tą zmianą, że prawo odstąpienia od 
umowy 
z powodu 
wad 
fizycznych 
przedmiotu 
kontraktacji 
przysługuje 
kontraktującemu tylko wtedy, gdy wady są istotne.

***
## Art. 622. {#art-622}

§ 1. Jeżeli wskutek okoliczności, za które żadna ze stron 
odpowiedzialności nie ponosi, producent nie może dostarczyć przedmiotu 
kontraktacji, obowiązany jest on tylko do zwrotu pobranych zaliczek i kredytów 
bankowych. 
§ 2. W umowie strony mogą zastrzec warunki zwrotu zaliczek i kredytu 
korzystniejsze dla producenta.

***
## Art. 623. {#art-623}

Jeżeli umowa kontraktacji wkłada na producenta obowiązek 
zgłoszenia w określonym terminie niemożności dostarczenia przedmiotu kontraktacji 
wskutek okoliczności, za które producent odpowiedzialności nie ponosi, niedopeł-
nienie tego obowiązku z winy producenta wyłącza możność powoływania się na te 
okoliczności. Nie dotyczy to jednak wypadku, gdy kontraktujący o powyższych 
okolicznościach wiedział albo gdy były one powszechnie znane.

***
## Art. 624. {#art-624}

§ 1. Wzajemne roszczenia producenta i kontraktującego przedawniają 
się z upływem lat dwóch od dnia spełnienia świadczenia przez producenta, a jeżeli 

©Kancelaria Sejmu 
 
 
 
s. 131/242 
 
   
 
2025-09-09 
 
świadczenie producenta nie zostało spełnione – od dnia, w którym powinno było być 
spełnione. 
§ 2. Jeżeli świadczenie producenta było spełniane częściami, przedawnienie 
biegnie od dnia, w którym zostało spełnione ostatnie świadczenie częściowe.

***
## Art. 625. {#art-625}

Jeżeli po zawarciu umowy kontraktacji gospodarstwo producenta 
przeszło w posiadanie innej osoby, prawa i obowiązki z tej umowy wynikające 
przechodzą na nowego posiadacza. Nie dotyczy to jednak wypadku, gdy przejście 
posiadania było następstwem odpłatnego nabycia gospodarstwa, a nabywca nie 
wiedział i mimo zachowania należytej staranności nie mógł się dowiedzieć o istnieniu 
umowy kontraktacji.

***
## Art. 626. {#art-626}

§ 1. Jeżeli po zawarciu umowy kontraktacji producent wniósł 
posiadane gospodarstwo jako wkład do rolniczej spółdzielni produkcyjnej, 
spółdzielnia ta wstępuje w prawa i obowiązki producenta, chyba że stan wniesionego 
gospodarstwa stoi temu na przeszkodzie. 
§ 2. Jeżeli stan gospodarstwa producenta w chwili jego przystąpienia do 
spółdzielni nie pozwala na wykonanie umowy kontraktacji przez spółdzielnię, umowa 
wygasa, a producent obowiązany jest zwrócić pobrane zaliczki i kredyty bankowe; 
inne korzyści wynikające z tej umowy obowiązany jest zwrócić w takim zakresie, 
w jakim ich nie zużył w celu wykonania umowy. 
§ 3. Jeżeli producent po przystąpieniu do spółdzielni dokonywa indywidualnie 
sprzętu zakontraktowanych zbiorów, ponosi on wyłączną odpowiedzialność za 
wykonanie umowy kontraktacji. 
TYTUŁ XV 
Umowa o dzieło

***
## Art. 627. {#art-627}

Przez umowę o dzieło przyjmujący zamówienie zobowiązuje się do 
wykonania oznaczonego dzieła, a zamawiający do zapłaty wynagrodzenia.

***
## Art. 6271. {#art-6271}

(uchylony)

***
## Art. 628. {#art-628}

§ 1. Wysokość wynagrodzenia za wykonanie dzieła można określić 
przez wskazanie podstaw do jego ustalenia. Jeżeli strony nie określiły wysokości 
wynagrodzenia ani nie wskazały podstaw do jego ustalenia, poczytuje się w razie 
wątpliwości, że strony miały na myśli zwykłe wynagrodzenie za dzieło tego rodzaju. 

©Kancelaria Sejmu 
 
 
 
s. 132/242 
 
   
 
2025-09-09 
 
Jeżeli także w ten sposób nie da się ustalić wysokości wynagrodzenia, należy się 
wynagrodzenie odpowiadające uzasadnionemu nakładowi pracy oraz innym nakładom 
przyjmującego zamówienie. 
§ 2. Przepisy dotyczące sprzedaży według cen sztywnych, maksymalnych, 
minimalnych i wynikowych stosuje się odpowiednio.

***
## Art. 629. {#art-629}

Jeżeli strony określiły wynagrodzenie na podstawie zestawienia 
planowanych prac i przewidywanych kosztów (wynagrodzenie kosztorysowe), 
a w toku wykonywania dzieła zarządzenie właściwego organu państwowego zmieniło 
wysokość 
cen 
lub 
stawek 
obowiązujących 
dotychczas 
w obliczeniach 
kosztorysowych, każda ze stron może żądać odpowiedniej zmiany umówionego 
wynagrodzenia. Nie dotyczy to jednak należności uiszczonej za materiały lub 
robociznę przed zmianą cen lub stawek.

***
## Art. 630. {#art-630}

§ 1. Jeżeli w toku wykonywania dzieła zajdzie konieczność 
przeprowadzenia prac, które nie były przewidziane w zestawieniu prac planowanych 
będących podstawą obliczenia wynagrodzenia kosztorysowego, a zestawienie 
sporządził zamawiający, przyjmujący zamówienie może żądać odpowiedniego 
podwyższenia umówionego wynagrodzenia. Jeżeli zestawienie planowanych prac 
sporządził przyjmujący zamówienie, może on żądać podwyższenia wynagrodzenia 
tylko wtedy, gdy mimo zachowania należytej staranności nie mógł przewidzieć 
konieczności prac dodatkowych. 
§ 2. Przyjmujący zamówienie nie może żądać podwyższenia wynagrodzenia, 
jeżeli wykonał prace dodatkowe bez uzyskania zgody zamawiającego.

***
## Art. 631. {#art-631}

Gdyby 
w wypadkach 
przewidzianych 
w dwóch 
artykułach 
poprzedzających zaszła konieczność znacznego podwyższenia wynagrodzenia 
kosztorysowego, zamawiający może od umowy odstąpić, powinien jednak uczynić to 
niezwłocznie i zapłacić przyjmującemu zamówienie odpowiednią część umówionego 
wynagrodzenia.

***
## Art. 632. {#art-632}

§ 1. Jeżeli strony umówiły się o wynagrodzenie ryczałtowe, 
przyjmujący zamówienie nie może żądać podwyższenia wynagrodzenia, chociażby 
w czasie zawarcia umowy nie można było przewidzieć rozmiaru lub kosztów prac. 

©Kancelaria Sejmu 
 
 
 
s. 133/242 
 
   
 
2025-09-09 
 
§ 2. Jeżeli jednak wskutek zmiany stosunków, której nie można było 
przewidzieć, wykonanie dzieła groziłoby przyjmującemu zamówienie rażącą stratą, 
sąd może podwyższyć ryczałt lub rozwiązać umowę.

***
## Art. 633. {#art-633}

Jeżeli materiałów na wykonanie dzieła dostarcza zamawiający, 
przyjmujący zamówienie powinien ich użyć w sposób odpowiedni oraz złożyć 
rachunek i zwrócić niezużytą część.

***
## Art. 634. {#art-634}

Jeżeli materiał dostarczony przez zamawiającego nie nadaje się do 
prawidłowego wykonania dzieła albo jeżeli zajdą inne okoliczności, które mogą 
przeszkodzić prawidłowemu wykonaniu, przyjmujący zamówienie powinien 
niezwłocznie zawiadomić o tym zamawiającego.

***
## Art. 635. {#art-635}

Jeżeli przyjmujący zamówienie opóźnia się z rozpoczęciem lub 
wykończeniem dzieła tak dalece, że nie jest prawdopodobne, żeby zdołał je ukończyć 
w czasie umówionym, zamawiający może bez wyznaczenia terminu dodatkowego od 
umowy odstąpić jeszcze przed upływem terminu do wykonania dzieła.

***
## Art. 636. {#art-636}

§ 1. Jeżeli przyjmujący zamówienie wykonywa dzieło w sposób 
wadliwy albo sprzeczny z umową, zamawiający może wezwać go do zmiany sposobu 
wykonania i wyznaczyć mu w tym celu odpowiedni termin. Po bezskutecznym 
upływie wyznaczonego terminu zamawiający może od umowy odstąpić albo 
powierzyć poprawienie lub dalsze wykonanie dzieła innej osobie na koszt 
i niebezpieczeństwo przyjmującego zamówienie. 
§ 2. Jeżeli zamawiający sam dostarczył materiału, może on w razie odstąpienia 
od umowy lub powierzenia wykonania dzieła innej osobie żądać zwrotu materiału 
i wydania rozpoczętego dzieła.

***
## Art. 6361. {#art-6361}

Jeżeli konsument zamówił dzieło będące rzeczą ruchomą, stosuje się 
przepisy art. 5431, art. 5461 i art. 548.

***
## Art. 637. {#art-637}

(uchylony)

***
## Art. 638. {#art-638}

§ 1. Do odpowiedzialności za wady dzieła stosuje się odpowiednio 
przepisy o rękojmi przy sprzedaży. Odpowiedzialność przyjmującego zamówienie jest 
wyłączona, jeżeli wada dzieła powstała z przyczyny tkwiącej w materiale 
dostarczonym przez zamawiającego. 

©Kancelaria Sejmu 
 
 
 
s. 134/242 
 
   
 
2025-09-09 
 
§ 2. Jeżeli zamawiającemu udzielono gwarancji na wykonane dzieło, przepisy 
o gwarancji przy sprzedaży stosuje się odpowiednio.

***
## Art. 639. {#art-639}

Zamawiający nie może odmówić zapłaty wynagrodzenia mimo 
niewykonania dzieła, jeżeli przyjmujący zamówienie był gotów je wykonać, lecz 
doznał przeszkody z przyczyn dotyczących zamawiającego. Jednakże w wypadku 
takim zamawiający może odliczyć to, co przyjmujący zamówienie oszczędził 
z powodu niewykonania dzieła.

***
## Art. 640. {#art-640}

Jeżeli 
do 
wykonania 
dzieła 
potrzebne 
jest 
współdziałanie 
zamawiającego, a tego współdziałania brak, przyjmujący zamówienie może 
wyznaczyć zamawiającemu odpowiedni termin z zagrożeniem, iż po bezskutecznym 
upływie wyznaczonego terminu będzie uprawniony do odstąpienia od umowy.

***
## Art. 641. {#art-641}

§ 1. Niebezpieczeństwo 
przypadkowej 
utraty 
lub 
uszkodzenia 
materiału na wykonanie dzieła obciąża tego, kto materiału dostarczył. 
§ 2. Gdy dzieło uległo zniszczeniu lub uszkodzeniu wskutek wadliwości 
materiału dostarczonego przez zamawiającego albo wskutek wykonania dzieła według 
jego wskazówek, przyjmujący zamówienie może żądać za wykonaną pracę 
umówionego wynagrodzenia lub jego odpowiedniej części, jeżeli uprzedził 
zamawiającego o niebezpieczeństwie zniszczenia lub uszkodzenia dzieła.

***
## Art. 642. {#art-642}

§ 1. W braku odmiennej umowy przyjmującemu zamówienie należy 
się wynagrodzenie w chwili oddania dzieła. 
§ 2. Jeżeli dzieło ma być oddawane częściami, a wynagrodzenie zostało 
obliczone za każdą część z osobna, wynagrodzenie należy się z chwilą spełnienia 
każdego ze świadczeń częściowych.

***
## Art. 643. {#art-643}

Zamawiający obowiązany jest odebrać dzieło, które przyjmujący 
zamówienie wydaje mu zgodnie ze swym zobowiązaniem.

***
## Art. 644. {#art-644}

Dopóki dzieło nie zostało ukończone, zamawiający może w każdej 
chwili od umowy odstąpić płacąc umówione wynagrodzenie. Jednakże w wypadku 
takim zamawiający może odliczyć to, co przyjmujący zamówienie oszczędził 
z powodu niewykonania dzieła. 

©Kancelaria Sejmu 
 
 
 
s. 135/242 
 
   
 
2025-09-09

***
## Art. 645. {#art-645}

§ 1. Umowa o dzieło, którego wykonanie zależy od osobistych 
przymiotów przyjmującego zamówienie, rozwiązuje się wskutek jego śmierci lub 
niezdolności do pracy. 
§ 2. Jeżeli materiał był własnością przyjmującego zamówienie, a dzieło 
częściowo wykonane przedstawia ze względu na zamierzony cel umowy wartość dla 
zamawiającego, przyjmujący zamówienie lub jego spadkobierca może żądać, ażeby 
zamawiający odebrał materiał w stanie, w jakim się znajduje, za zapłatą jego wartości 
oraz odpowiedniej części wynagrodzenia.

***
## Art. 646. {#art-646}

Roszczenia wynikające z umowy o dzieło przedawniają się z upływem 
lat dwóch od dnia oddania dzieła, a jeżeli dzieło nie zostało oddane – od dnia, 
w którym zgodnie z treścią umowy miało być oddane. 
TYTUŁ XVI 
Umowa o roboty budowlane

***
## Art. 647. {#art-647}

Przez umowę o roboty budowlane wykonawca zobowiązuje się do 
oddania przewidzianego w umowie obiektu, wykonanego zgodnie z projektem 
i z zasadami wiedzy technicznej, a inwestor zobowiązuje się do dokonania 
wymaganych przez właściwe przepisy czynności związanych z przygotowaniem 
robót, w szczególności do przekazania terenu budowy i dostarczenia projektu, oraz do 
odebrania obiektu i zapłaty umówionego wynagrodzenia.

***
## Art. 6471. {#art-6471}

§ 1. Inwestor odpowiada solidarnie z wykonawcą (generalnym 
wykonawcą) za zapłatę wynagrodzenia należnego podwykonawcy z tytułu 
wykonanych przez niego robót budowlanych, których szczegółowy przedmiot został 
zgłoszony inwestorowi przez wykonawcę lub podwykonawcę przed przystąpieniem 
do wykonywania tych robót, chyba że w ciągu trzydziestu dni od dnia doręczenia 
inwestorowi zgłoszenia inwestor złożył podwykonawcy i wykonawcy sprzeciw wobec 
wykonywania tych robót przez podwykonawcę. 
§ 2. Zgłoszenie, o którym mowa w § 1, nie jest wymagane, jeżeli inwestor i 
wykonawca określili w umowie, zawartej w formie pisemnej pod rygorem 
nieważności, szczegółowy przedmiot robót budowlanych wykonywanych przez 
oznaczonego podwykonawcę. 
§ 
3. 
Inwestor 
ponosi 
odpowiedzialność 
za 
zapłatę 
podwykonawcy 
wynagrodzenia w wysokości ustalonej w umowie między podwykonawcą a 

©Kancelaria Sejmu 
 
 
 
s. 136/242 
 
   
 
2025-09-09 
 
wykonawcą, chyba że ta wysokość przekracza wysokość wynagrodzenia należnego 
wykonawcy za roboty budowlane, których szczegółowy przedmiot wynika 
odpowiednio ze zgłoszenia albo z umowy, o których mowa w § 1 albo 2. W takim 
przypadku odpowiedzialność inwestora za zapłatę podwykonawcy wynagrodzenia jest 
ograniczona do wysokości wynagrodzenia należnego wykonawcy za roboty 
budowlane, których szczegółowy przedmiot wynika odpowiednio ze zgłoszenia albo 
z umowy, o których mowa w § 1 albo 2. 
§ 4. Zgłoszenie oraz sprzeciw, o których mowa w § 1, wymagają zachowania 
formy pisemnej pod rygorem nieważności. 
§ 5. Przepisy § 1–4 stosuje się odpowiednio do solidarnej odpowiedzialności 
inwestora, wykonawcy i podwykonawcy, który zawarł umowę z dalszym 
podwykonawcą, za zapłatę wynagrodzenia dalszemu podwykonawcy. 
§ 6. Postanowienia umowne sprzeczne z treścią § 1–5 są nieważne.

***
## Art. 648. {#art-648}

§ 1. Umowa o roboty budowlane powinna być stwierdzona pismem. 
§ 2. Wymagana przez właściwe przepisy dokumentacja stanowi część składową 
umowy. 
§ 3. (uchylony)

***
## Art. 649. {#art-649}

W razie wątpliwości poczytuje się, iż wykonawca podjął się 
wszystkich robót objętych projektem stanowiącym część składową umowy.

***
## Art. 6491. {#art-6491}

§ 1. Gwarancji zapłaty za roboty budowlane, zwanej dalej „gwarancją 
zapłaty”, inwestor udziela wykonawcy (generalnemu wykonawcy) w celu 
zabezpieczenia terminowej zapłaty umówionego wynagrodzenia za wykonanie robót 
budowlanych. 
§ 11. Przepisu § 1 nie stosuje się w przypadku, gdy inwestorem jest Skarb 
Państwa. 
§ 2. Gwarancją zapłaty jest gwarancja bankowa lub ubezpieczeniowa, a także 
akredytywa bankowa lub poręczenie banku udzielone na zlecenie inwestora. 
§ 3. Strony 
ponoszą 
w równych 
częściach 
udokumentowane 
koszty 
zabezpieczenia wierzytelności.

***
## Art. 6492. {#art-6492}

§ 1. Nie można przez czynność prawną wyłączyć ani ograniczyć 
prawa wykonawcy (generalnego wykonawcy) do żądania od inwestora gwarancji 
zapłaty. 

©Kancelaria Sejmu 
 
 
 
s. 137/242 
 
   
 
2025-09-09 
 
§ 2. Odstąpienie inwestora od umowy spowodowane żądaniem wykonawcy 
(generalnego wykonawcy) przedstawienia gwarancji zapłaty jest bezskuteczne.

***
## Art. 6493. {#art-6493}

§ 1. Wykonawca (generalny wykonawca) robót budowlanych może 
w każdym czasie żądać od inwestora gwarancji zapłaty do wysokości ewentualnego 
roszczenia z tytułu wynagrodzenia wynikającego z umowy oraz robót dodatkowych 
lub koniecznych do wykonania umowy, zaakceptowanych na piśmie przez inwestora. 
§ 2. Udzielenie gwarancji zapłaty nie stoi na przeszkodzie żądaniu gwarancji 
zapłaty do łącznej wysokości określonej w § 1.

***
## Art. 6494. {#art-6494}

§ 1. Jeżeli wykonawca (generalny wykonawca) nie uzyska żądanej 
gwarancji zapłaty w wyznaczonym przez siebie terminie, nie krótszym niż 45 dni, 
uprawniony jest do odstąpienia od umowy z winy inwestora ze skutkiem na dzień 
odstąpienia. 
§ 2. Brak żądanej gwarancji zapłaty stanowi przeszkodę w wykonaniu robót 
budowlanych z przyczyn dotyczących inwestora. 
§ 3. Inwestor nie może odmówić zapłaty wynagrodzenia mimo niewykonania 
robót budowlanych, jeżeli wykonawca (generalny wykonawca) był gotów je wykonać, 
lecz doznał przeszkody z przyczyn dotyczących inwestora. Jednakże w wypadku 
takim inwestor może odliczyć to, co wykonawca (generalny wykonawca) oszczędził 
z powodu niewykonania robót budowlanych.

***
## Art. 6495. {#art-6495}

Przepisy art. 6491–6494 stosuje się do umów zawartych między 
wykonawcą 
(generalnym 
wykonawcą) 
a dalszymi 
wykonawcami 
(podwykonawcami).

***
## Art. 650. {#art-650}

(uchylony)

***
## Art. 651. {#art-651}

Jeżeli dostarczona przez inwestora dokumentacja, teren budowy, 
maszyny lub urządzenia nie nadają się do prawidłowego wykonania robót albo jeżeli 
zajdą inne okoliczności, które mogą przeszkodzić prawidłowemu wykonaniu robót, 
wykonawca powinien niezwłocznie zawiadomić o tym inwestora.

***
## Art. 652. {#art-652}

Jeżeli wykonawca przejął protokolarnie od inwestora teren budowy, 
ponosi on aż do chwili oddania obiektu odpowiedzialność na zasadach ogólnych za 
szkody wynikłe na tym terenie.

***
## Art. 653. {#art-653}

(uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 138/242 
 
   
 
2025-09-09

***
## Art. 654. {#art-654}

W braku odmiennego postanowienia umowy inwestor obowiązany jest 
na żądanie wykonawcy przyjmować wykonane roboty częściowo, w miarę ich 
ukończenia, za zapłatą odpowiedniej części wynagrodzenia.

***
## Art. 655. {#art-655}

Gdyby wykonany obiekt uległ zniszczeniu lub uszkodzeniu wskutek 
wadliwości dostarczonych przez inwestora materiałów, maszyn lub urządzeń albo 
wskutek wykonania robót według wskazówek inwestora, wykonawca może żądać 
umówionego wynagrodzenia lub jego odpowiedniej części, jeżeli uprzedził inwestora 
o niebezpieczeństwie zniszczenia lub uszkodzenia obiektu albo jeżeli mimo 
zachowania należytej staranności nie mógł stwierdzić wadliwości dostarczonych przez 
inwestora materiałów, maszyn lub urządzeń.

***
## Art. 656. {#art-656}

§ 1. Do skutków opóźnienia się przez wykonawcę z rozpoczęciem 
robót lub wykończeniem obiektu albo wykonywania przez wykonawcę robót 
w sposób wadliwy lub sprzeczny z umową, do rękojmi za wady wykonanego obiektu, 
jak również do uprawnienia inwestora do odstąpienia od umowy przed ukończeniem 
obiektu stosuje się odpowiednio przepisy o umowie o dzieło. 
§ 2. (uchylony)

***
## Art. 657. {#art-657}

Uprawnienie do odstąpienia od umowy przez wykonawcę lub przez 
inwestora może być ograniczone lub wyłączone przez przepisy szczególne.

***
## Art. 658. {#art-658}

Przepisy niniejszego tytułu stosuje się odpowiednio do umowy 
o wykonanie remontu budynku lub budowli. 
TYTUŁ XVII 
Najem i dzierżawa 
## DZIAŁ I. Najem 
## Rozdział I. Przepisy ogólne

***
## Art. 659. {#art-659}

§ 1. Przez umowę najmu wynajmujący zobowiązuje się oddać najemcy 
rzecz do używania przez czas oznaczony lub nieoznaczony, a najemca zobowiązuje 
się płacić wynajmującemu umówiony czynsz. 

©Kancelaria Sejmu 
 
 
 
s. 139/242 
 
   
 
2025-09-09 
 
§ 2. Czynsz może być oznaczony w pieniądzach lub w świadczeniach innego 
rodzaju.

***
## Art. 660. {#art-660}

Umowa najmu nieruchomości lub pomieszczenia na czas dłuższy niż 
rok powinna być zawarta na piśmie. W razie niezachowania tej formy poczytuje się 
umowę za zawartą na czas nieoznaczony.

***
## Art. 661. {#art-661}

§ 1. Najem zawarty na czas dłuższy niż lat dziesięć poczytuje się po 
upływie tego terminu za zawarty na czas nieoznaczony. 
§ 2. Najem zawarty między przedsiębiorcami na czas dłuższy niż lat trzydzieści 
poczytuje się po upływie tego terminu za zawarty na czas nieoznaczony.

***
## Art. 662. {#art-662}

§ 1. Wynajmujący powinien wydać najemcy rzecz w stanie 
przydatnym do umówionego użytku i utrzymywać ją w takim stanie przez czas trwania 
najmu. 
§ 2. Drobne nakłady połączone ze zwykłym używaniem rzeczy obciążają 
najemcę. 
§ 3. Jeżeli rzecz najęta uległa zniszczeniu z powodu okoliczności, za które 
wynajmujący odpowiedzialności nie ponosi, wynajmujący nie ma obowiązku 
przywrócenia stanu poprzedniego.

***
## Art. 663. {#art-663}

Jeżeli w czasie trwania najmu rzecz wymaga napraw, które obciążają 
wynajmującego, a bez których rzecz nie jest przydatna do umówionego użytku, 
najemca może wyznaczyć wynajmującemu odpowiedni termin do wykonania napraw. 
Po bezskutecznym upływie wyznaczonego terminu najemca może dokonać 
koniecznych napraw na koszt wynajmującego.

***
## Art. 664. {#art-664}

§ 1. Jeżeli rzecz najęta ma wady, które ograniczają jej przydatność do 
umówionego użytku, najemca może żądać odpowiedniego obniżenia czynszu za czas 
trwania wad. 
§ 2. Jeżeli w chwili wydania najemcy rzecz miała wady, które uniemożliwiają 
przewidziane w umowie używanie rzeczy, albo jeżeli wady takie powstały później, 
a wynajmujący mimo otrzymanego zawiadomienia nie usunął ich w czasie 
odpowiednim, albo jeżeli wady usunąć się nie dadzą, najemca może wypowiedzieć 
najem bez zachowania terminów wypowiedzenia. 

©Kancelaria Sejmu 
 
 
 
s. 140/242 
 
   
 
2025-09-09 
 
§ 3. Roszczenie o obniżenie czynszu z powodu wad rzeczy najętej, jak również 
uprawnienie do niezwłocznego wypowiedzenia najmu nie przysługuje najemcy, jeżeli 
w chwili zawarcia umowy wiedział o wadach.

***
## Art. 665. {#art-665}

Jeżeli osoba trzecia dochodzi przeciwko najemcy roszczeń 
dotyczących rzeczy najętej, najemca powinien niezwłocznie zawiadomić o tym 
wynajmującego.

***
## Art. 666. {#art-666}

§ 1. Najemca powinien przez czas trwania najmu używać rzeczy 
najętej w sposób w umowie określony, a gdy umowa nie określa sposobu używania – 
w sposób odpowiadający właściwościom i przeznaczeniu rzeczy. 
§ 2. Jeżeli w czasie trwania najmu okaże się potrzeba napraw, które obciążają 
wynajmującego, najemca powinien zawiadomić go o tym niezwłocznie.

***
## Art. 667. {#art-667}

§ 1. Bez zgody wynajmującego najemca nie może czynić w rzeczy 
najętej zmian sprzecznych z umową lub z przeznaczeniem rzeczy. 
§ 2. Jeżeli najemca używa rzeczy w sposób sprzeczny z umową lub 
z przeznaczeniem rzeczy i mimo upomnienia nie przestaje jej używać w taki sposób 
albo gdy rzecz zaniedbuje do tego stopnia, że zostaje ona narażona na utratę lub 
uszkodzenie, wynajmujący może wypowiedzieć najem bez zachowania terminów 
wypowiedzenia.

***
## Art. 668. {#art-668}

§ 1. Najemca może rzecz najętą oddać w całości lub części osobie 
trzeciej do bezpłatnego używania albo w podnajem, jeżeli umowa mu tego nie 
zabrania. W razie oddania rzeczy osobie trzeciej zarówno najemca, jak i osoba trzecia 
są odpowiedzialni względem wynajmującego za to, że rzecz najęta będzie używana 
zgodnie z obowiązkami wynikającymi z umowy najmu. 
§ 2. Stosunek wynikający z zawartej przez najemcę umowy o bezpłatne 
używanie lub podnajem rozwiązuje się najpóźniej z chwilą zakończenia stosunku 
najmu.

***
## Art. 669. {#art-669}

§ 1. 
Najemca 
obowiązany 
jest 
uiszczać 
czynsz 
w terminie 
umówionym. 
§ 2. Jeżeli termin płatności czynszu nie jest w umowie określony, czynsz 
powinien być płacony z góry, a mianowicie: gdy najem ma trwać nie dłużej niż 
miesiąc – za cały czas najmu, a gdy najem ma trwać dłużej niż miesiąc albo gdy 

©Kancelaria Sejmu 
 
 
 
s. 141/242 
 
   
 
2025-09-09 
 
umowa była zawarta na czas nieoznaczony – miesięcznie, do dziesiątego dnia 
miesiąca.

***
## Art. 670. {#art-670}

§ 1. Dla zabezpieczenia czynszu oraz świadczeń dodatkowych, 
z którymi najemca zalega nie dłużej niż rok, przysługuje wynajmującemu ustawowe 
prawo zastawu na rzeczach ruchomych najemcy wniesionych do przedmiotu najmu, 
chyba że rzeczy te nie podlegają zajęciu. 
§ 2. (uchylony)

***
## Art. 671. {#art-671}

§ 1. Przysługujące wynajmującemu ustawowe prawo zastawu wygasa, 
gdy rzeczy obciążone zastawem zostaną z przedmiotu najmu usunięte. 
§ 2. Wynajmujący może się sprzeciwić usunięciu rzeczy obciążonych zastawem 
i zatrzymać je na własne niebezpieczeństwo, dopóki zaległy czynsz nie będzie 
zapłacony lub zabezpieczony. 
§ 3. W wypadku gdy rzeczy obciążone zastawem zostaną usunięte na mocy 
zarządzenia organu państwowego, wynajmujący zachowuje ustawowe prawo zastawu, 
jeżeli przed upływem trzech dni zgłosi je organowi, który zarządził usunięcie.

***
## Art. 672. {#art-672}

Jeżeli najemca dopuszcza się zwłoki z zapłatą czynszu co najmniej za 
dwa pełne okresy płatności, wynajmujący może najem wypowiedzieć bez zachowania 
terminów wypowiedzenia.

***
## Art. 673. {#art-673}

§ 1. Jeżeli czas trwania najmu nie jest oznaczony, zarówno 
wynajmujący, jak i najemca mogą wypowiedzieć najem z zachowaniem terminów 
umownych, a w ich braku z zachowaniem terminów ustawowych. 
§ 2. Ustawowe terminy wypowiedzenia najmu są następujące: gdy czynsz jest 
płatny w odstępach czasu dłuższych niż miesiąc, najem można wypowiedzieć 
najpóźniej na trzy miesiące naprzód na koniec kwartału kalendarzowego; gdy czynsz 
jest płatny miesięcznie – na miesiąc naprzód na koniec miesiąca kalendarzowego; gdy 
czynsz jest płatny w krótszych odstępach czasu – na trzy dni naprzód; gdy najem jest 
dzienny – na jeden dzień naprzód. 
§ 3. Jeżeli czas trwania najmu jest oznaczony, zarówno wynajmujący, jak 
i najemca mogą wypowiedzieć najem w wypadkach określonych w umowie.

***
## Art. 674. {#art-674}

Jeżeli 
po 
upływie 
terminu 
oznaczonego 
w umowie 
albo 
w wypowiedzeniu najemca używa nadal rzeczy za zgodą wynajmującego, poczytuje 
się w razie wątpliwości, że najem został przedłużony na czas nieoznaczony. 

©Kancelaria Sejmu 
 
 
 
s. 142/242 
 
   
 
2025-09-09

***
## Art. 675. {#art-675}

§ 1. Po zakończeniu najmu najemca obowiązany jest zwrócić rzecz 
w stanie niepogorszonym; jednakże nie ponosi odpowiedzialności za zużycie rzeczy 
będące następstwem prawidłowego używania. 
§ 2. Jeżeli najemca oddał innej osobie rzecz do bezpłatnego używania lub 
w podnajem, obowiązek powyższy ciąży także na tej osobie. 
§ 3. Domniemywa się, że rzecz była wydana najemcy w stanie dobrym 
i przydatnym do umówionego użytku.

***
## Art. 676. {#art-676}

Jeżeli najemca ulepszył rzecz najętą, wynajmujący, w braku odmiennej 
umowy, może według swego wyboru albo zatrzymać ulepszenia za zapłatą sumy 
odpowiadającej ich wartości w chwili zwrotu, albo żądać przywrócenia stanu 
poprzedniego.

***
## Art. 677. {#art-677}

Roszczenia wynajmującego przeciwko najemcy o naprawienie szkody 
z powodu uszkodzenia lub pogorszenia rzeczy, jak również roszczenia najemcy 
przeciwko wynajmującemu o zwrot nakładów na rzecz albo o zwrot nadpłaconego 
czynszu przedawniają się z upływem roku od dnia zwrotu rzeczy.

***
## Art. 678. {#art-678}

§ 1. W razie zbycia rzeczy najętej w czasie trwania najmu nabywca 
wstępuje w stosunek najmu na miejsce zbywcy; może jednak wypowiedzieć najem 
z zachowaniem ustawowych terminów wypowiedzenia. 
§ 2. Powyższe uprawnienie do wypowiedzenia najmu nie przysługuje nabywcy, 
jeżeli umowa najmu była zawarta na czas oznaczony z zachowaniem formy pisemnej 
i z datą pewną, a rzecz została najemcy wydana.

***
## Art. 679. {#art-679}

§ 1. Jeżeli wskutek wypowiedzenia najmu przez nabywcę rzeczy 
najętej najemca jest zmuszony zwrócić rzecz wcześniej, aniżeli byłby zobowiązany 
według umowy najmu, może on żądać od zbywcy naprawienia szkody. 
§ 2. Najemca powinien niezwłocznie zawiadomić zbywcę o przedwczesnym 
wypowiedzeniu przez nabywcę; w przeciwnym razie przysługują zbywcy przeciwko 
najemcy wszelkie zarzuty, których najemca nie podniósł, a których podniesienie 
pociągnęłoby za sobą bezskuteczność wypowiedzenia ze strony nabywcy. 

©Kancelaria Sejmu 
 
 
 
s. 143/242 
 
   
 
2025-09-09 
## Rozdział II. Najem lokalu

***
## Art. 680. {#art-680}

Do najmu lokalu stosuje się przepisy rozdziału poprzedzającego, 
z zachowaniem przepisów poniższych.

***
## Art. 6801. {#art-6801}

§ 1. Małżonkowie są najemcami lokalu bez względu na istniejące 
między nimi stosunki majątkowe, jeżeli nawiązanie stosunku najmu lokalu mającego 
służyć zaspokojeniu potrzeb mieszkaniowych założonej przez nich rodziny nastąpiło 
w czasie trwania małżeństwa. Jeżeli między małżonkami istnieje rozdzielność 
majątkowa albo rozdzielność majątkowa z wyrównaniem dorobków do wspólności 
najmu stosuje się odpowiednio przepisy o wspólności ustawowej. 
§ 2. Ustanie wspólności majątkowej w czasie trwania małżeństwa nie powoduje 
ustania wspólności najmu lokalu mającego służyć zaspokojeniu potrzeb 
mieszkaniowych rodziny. Sąd, stosując odpowiednio przepisy o ustanowieniu 
w wyroku rozdzielności majątkowej, może z ważnych powodów na żądanie jednego 
z małżonków znieść wspólność najmu lokalu.

***
## Art. 681. {#art-681}

Do drobnych nakładów, które obciążają najemcę lokalu, należą 
w szczególności: drobne naprawy podłóg, drzwi i okien, malowanie ścian, podłóg oraz 
wewnętrznej strony drzwi wejściowych, jak również drobne naprawy instalacji 
i urządzeń technicznych, zapewniających korzystanie ze światła, ogrzewania lokalu, 
dopływu i odpływu wody.

***
## Art. 682. {#art-682}

Jeżeli wady najętego lokalu są tego rodzaju, że zagrażają zdrowiu 
najemcy lub jego domowników albo osób u niego zatrudnionych, najemca może 
wypowiedzieć najem bez zachowania terminów wypowiedzenia, chociażby w chwili 
zawarcia umowy wiedział o wadach.

***
## Art. 683. {#art-683}

Najemca lokalu powinien stosować się do porządku domowego, o ile 
ten nie jest sprzeczny z uprawnieniami wynikającymi z umowy; powinien również 
liczyć się z potrzebami innych mieszkańców i sąsiadów.

***
## Art. 684. {#art-684}

Najemca może założyć w najętym lokalu oświetlenie elektryczne, gaz, 
telefon, radio i inne podobne urządzenia, chyba że sposób ich założenia sprzeciwia się 
obowiązującym przepisom albo zagraża bezpieczeństwu nieruchomości. Jeżeli do 

©Kancelaria Sejmu 
 
 
 
s. 144/242 
 
   
 
2025-09-09 
 
założenia urządzeń potrzebne jest współdziałanie wynajmującego, najemca może 
domagać się tego współdziałania za zwrotem wynikłych stąd kosztów.

***
## Art. 685. {#art-685}

Jeżeli najemca lokalu wykracza w sposób rażący lub uporczywy 
przeciwko obowiązującemu porządkowi domowemu albo przez swoje niewłaściwe 
zachowanie czyni korzystanie z innych lokali w budynku uciążliwym, wynajmujący 
może wypowiedzieć najem bez zachowania terminów wypowiedzenia.

***
## Art. 6851. {#art-6851}

Wynajmujący lokal może podwyższyć czynsz, wypowiadając 
dotychczasową wysokość czynszu najpóźniej na miesiąc naprzód, na koniec miesiąca 
kalendarzowego.

***
## Art. 686. {#art-686}

Ustawowe prawo zastawu wynajmującego lokal mieszkalny rozciąga 
się także na wniesione do lokalu ruchomości członków rodziny najemcy razem z nim 
mieszkających.

***
## Art. 687. {#art-687}

Jeżeli najemca lokalu dopuszcza się zwłoki z zapłatą czynszu co 
najmniej za dwa pełne okresy płatności, a wynajmujący zamierza najem 
wypowiedzieć bez zachowania terminów wypowiedzenia, powinien on uprzedzić 
najemcę na piśmie, udzielając mu dodatkowego terminu miesięcznego do zapłaty 
zaległego czynszu.

***
## Art. 688. {#art-688}

Jeżeli czas trwania najmu lokalu nie jest oznaczony, a czynsz jest 
płatny miesięcznie, najem można wypowiedzieć najpóźniej na trzy miesiące naprzód 
na koniec miesiąca kalendarzowego.

***
## Art. 6881. {#art-6881}

§ 1. Za zapłatę czynszu i innych należnych opłat odpowiadają 
solidarnie z najemcą stale zamieszkujące z nim osoby pełnoletnie, z wyjątkiem 
pełnoletnich zstępnych pozostających na jego utrzymaniu, którzy nie są w stanie 
utrzymać się samodzielnie. 
§ 2. Odpowiedzialność osób, o których mowa w § 1, ogranicza się do wysokości 
czynszu i innych opłat należnych za okres ich stałego zamieszkiwania.

***
## Art. 6882. {#art-6882}

Bez zgody wynajmującego najemca nie może oddać lokalu lub jego 
części do bezpłatnego używania ani go podnająć. Zgoda wynajmującego nie jest 
wymagana co do osoby, względem której najemca jest obciążony obowiązkiem 
alimentacyjnym.

***
## Art. 689. {#art-689}

(uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 145/242 
 
   
 
2025-09-09

***
## Art. 690. {#art-690}

Do ochrony praw najemcy do używania lokalu stosuje się odpowiednio 
przepisy o ochronie własności.

***
## Art. 691. {#art-691}

§ 1. W razie śmierci najemcy lokalu mieszkalnego w stosunek najmu 
lokalu wstępują: małżonek niebędący współnajemcą lokalu, dzieci najemcy i jego 
współmałżonka, inne osoby, wobec których najemca był obowiązany do świadczeń 
alimentacyjnych, oraz osoba, która pozostawała faktycznie we wspólnym pożyciu 
z najemcą. 
§ 2. Osoby wymienione w § 1 wstępują w stosunek najmu lokalu mieszkalnego, 
jeżeli stale zamieszkiwały z najemcą w tym lokalu do chwili jego śmierci. 
§ 3. W razie braku osób wymienionych w § 1 stosunek najmu lokalu 
mieszkalnego wygasa. 
§ 4. Osoby, które wstąpiły w stosunek najmu lokalu mieszkalnego na podstawie 
§ 1, mogą go wypowiedzieć z zachowaniem terminów ustawowych, chociażby umowa 
najmu była zawarta na czas oznaczony. W razie wypowiedzenia stosunku najmu przez 
niektóre z tych osób stosunek ten wygasa względem osób, które go wypowiedziały. 
§ 5. Przepisów § 1–4 nie stosuje się w razie śmierci jednego ze współnajemców 
lokalu mieszkalnego.

***
## Art. 692. {#art-692}

Przepisów o wypowiedzeniu najmu przez nabywcę rzeczy najętej nie 
stosuje się do najmu lokali mieszkalnych, chyba że najemca nie objął jeszcze lokalu. 
## DZIAŁ II. Dzierżawa

***
## Art. 693. {#art-693}

§ 1. Przez umowę dzierżawy wydzierżawiający zobowiązuje się oddać 
dzierżawcy rzecz do używania i pobierania pożytków przez czas oznaczony lub 
nieoznaczony, a dzierżawca zobowiązuje się płacić wydzierżawiającemu umówiony 
czynsz. 
§ 2. Czynsz może być zastrzeżony w pieniądzach lub świadczeniach innego 
rodzaju. Może być również oznaczony w ułamkowej części pożytków.

***
## Art. 694. {#art-694}

Do 
dzierżawy 
stosuje 
się 
odpowiednio 
przepisy 
o najmie 
z zachowaniem przepisów poniższych.

***
## Art. 695. {#art-695}

§ 1. Dzierżawę zawartą na czas dłuższy niż lat trzydzieści poczytuje 
się po upływie tego terminu za zawartą na czas nieoznaczony. 

©Kancelaria Sejmu 
 
 
 
s. 146/242 
 
   
 
2025-09-09 
 
§ 2. (uchylony)

***
## Art. 696. {#art-696}

Dzierżawca 
powinien 
wykonywać 
swoje 
prawo 
zgodnie 
z wymaganiami prawidłowej gospodarki i nie może zmieniać przeznaczenia 
przedmiotu dzierżawy bez zgody wydzierżawiającego.

***
## Art. 697. {#art-697}

Dzierżawca ma obowiązek dokonywania napraw niezbędnych do 
zachowania przedmiotu dzierżawy w stanie niepogorszonym.

***
## Art. 698. {#art-698}

§ 1. Bez zgody wydzierżawiającego dzierżawca nie może oddawać 
przedmiotu dzierżawy osobie trzeciej do bezpłatnego używania ani go 
poddzierżawiać. 
§ 2. W razie naruszenia powyższego obowiązku wydzierżawiający może 
dzierżawę wypowiedzieć bez zachowania terminów wypowiedzenia.

***
## Art. 699. {#art-699}

Jeżeli termin płatności czynszu nie jest w umowie oznaczony, czynsz 
jest płatny z dołu w terminie zwyczajowo przyjętym, a w braku takiego zwyczaju – 
półrocznie z dołu.

***
## Art. 700. {#art-700}

Jeżeli wskutek okoliczności, za które dzierżawca odpowiedzialności 
nie ponosi i które nie dotyczą jego osoby, zwykły przychód z przedmiotu dzierżawy 
uległ znacznemu zmniejszeniu, dzierżawca może żądać obniżenia czynszu 
przypadającego za dany okres gospodarczy.

***
## Art. 701. {#art-701}

Do rzeczy ruchomych objętych ustawowym prawem zastawu 
wydzierżawiającego należą także rzeczy służące do prowadzenia gospodarstwa lub 
przedsiębiorstwa, jeżeli znajdują się w obrębie przedmiotu dzierżawy.

***
## Art. 702. {#art-702}

Jeżeli w umowie zastrzeżono, że oprócz czynszu dzierżawca będzie 
obowiązany uiszczać podatki i inne ciężary związane z własnością lub z posiadaniem 
przedmiotu dzierżawy oraz ponosić koszty jego ubezpieczenia, ustawowe prawo 
zastawu przysługujące wydzierżawiającemu zabezpiecza również roszczenie 
wydzierżawiającego względem dzierżawcy o zwrot sum, które z powyższych tytułów 
zapłacił.

***
## Art. 703. {#art-703}

Jeżeli dzierżawca dopuszcza się zwłoki z zapłatą czynszu co najmniej 
za dwa pełne okresy płatności, a w wypadku gdy czynsz jest płatny rocznie, jeżeli 
dopuszcza się zwłoki z zapłatą ponad trzy miesiące, wydzierżawiający może 
dzierżawę wypowiedzieć bez zachowania terminu wypowiedzenia. Jednakże 

©Kancelaria Sejmu 
 
 
 
s. 147/242 
 
   
 
2025-09-09 
 
wydzierżawiający powinien uprzedzić dzierżawcę udzielając mu dodatkowego 
trzymiesięcznego terminu do zapłaty zaległego czynszu.

***
## Art. 704. {#art-704}

W braku odmiennej umowy dzierżawę gruntu rolnego można 
wypowiedzieć na jeden rok naprzód na koniec roku dzierżawnego, inną zaś dzierżawę 
na sześć miesięcy naprzód przed upływem roku dzierżawnego.

***
## Art. 705. {#art-705}

Po zakończeniu dzierżawy dzierżawca obowiązany jest, w braku 
odmiennej umowy, zwrócić przedmiot dzierżawy w takim stanie, w jakim powinien 
się znajdować stosownie do przepisów o wykonywaniu dzierżawy.

***
## Art. 706. {#art-706}

Jeżeli przy zakończeniu dzierżawy dzierżawca gruntu rolnego 
pozostawia zgodnie ze swym obowiązkiem zasiewy, może on żądać zwrotu 
poczynionych na te zasiewy nakładów o tyle, o ile wbrew wymaganiom prawidłowej 
gospodarki nie otrzymał odpowiednich zasiewów przy rozpoczęciu dzierżawy.

***
## Art. 707. {#art-707}

Jeżeli dzierżawa kończy się przed upływem roku dzierżawnego, 
dzierżawca obowiązany jest zapłacić czynsz w takim stosunku, w jakim pożytki, które 
w tym roku pobrał lub mógł pobrać, pozostają do pożytków z całego roku 
dzierżawnego.

***
## Art. 708. {#art-708}

Przepisy działu niniejszego stosuje się odpowiednio w wypadku, gdy 
osoba biorąca nieruchomość rolną do używania i pobierania pożytków nie jest 
obowiązana do uiszczania czynszu, lecz tylko do ponoszenia podatków i innych 
ciężarów związanych z własnością lub z posiadaniem gruntu.

***
## Art. 709. {#art-709}

Przepisy o dzierżawie rzeczy stosuje się odpowiednio do dzierżawy 
praw. 
TYTUŁ XVII1 
Umowa leasingu

***
## Art. 7091. {#art-7091}

Przez umowę leasingu finansujący zobowiązuje się, w zakresie 
działalności swego przedsiębiorstwa, nabyć rzecz od oznaczonego zbywcy na 
warunkach określonych w tej umowie i oddać tę rzecz korzystającemu do używania 
albo używania i pobierania pożytków przez czas oznaczony, a korzystający 
zobowiązuje się zapłacić finansującemu w uzgodnionych ratach wynagrodzenie 

©Kancelaria Sejmu 
 
 
 
s. 148/242 
 
   
 
2025-09-09 
 
pieniężne, równe co najmniej cenie lub wynagrodzeniu z tytułu nabycia rzeczy przez 
finansującego.

***
## Art. 7092. {#art-7092}

Umowa leasingu wymaga zachowania formy dokumentowej.

***
## Art. 7093. {#art-7093}

Jeżeli rzecz nie zostanie wydana korzystającemu w ustalonym 
terminie na skutek okoliczności, za które ponosi on odpowiedzialność, umówione 
terminy płatności rat pozostają niezmienione.

***
## Art. 7094. {#art-7094}

§ 1. Finansujący powinien wydać korzystającemu rzecz w takim 
stanie, w jakim znajdowała się ona w chwili wydania finansującemu przez zbywcę. 
§ 2. Finansujący nie odpowiada wobec korzystającego za przydatność rzeczy do 
umówionego użytku. 
§ 3. Finansujący obowiązany jest wydać korzystającemu razem z rzeczą odpis 
umowy ze zbywcą lub odpisy innych posiadanych dokumentów dotyczących tej 
umowy, w szczególności odpis dokumentu gwarancyjnego co do jakości rzeczy, 
otrzymanego od zbywcy lub producenta.

***
## Art. 7095. {#art-7095}

§ 1. Jeżeli po wydaniu korzystającemu rzecz została utracona 
z powodu okoliczności, za które finansujący nie ponosi odpowiedzialności, umowa 
leasingu wygasa. 
§ 2. Korzystający powinien niezwłocznie zawiadomić finansującego o utracie 
rzeczy. 
§ 3. Jeżeli umowa leasingu wygasła z przyczyn określonych w § 1, finansujący 
może 
żądać 
od 
korzystającego 
natychmiastowego 
zapłacenia 
wszystkich 
przewidzianych w umowie a niezapłaconych rat, pomniejszonych o korzyści, jakie 
finansujący uzyskał wskutek ich zapłaty przed umówionym terminem i wygaśnięcia 
umowy leasingu oraz z tytułu ubezpieczenia rzeczy, a także naprawienia szkody.

***
## Art. 7096. {#art-7096}

Jeżeli w umowie leasingu zastrzeżono, że korzystający obowiązany 
jest ponosić koszty ubezpieczenia rzeczy od jej utraty w czasie trwania leasingu, 
w braku odmiennego postanowienia umownego, koszty te obejmują składkę z tytułu 
ubezpieczenia na ogólnie przyjętych warunkach.

***
## Art. 7097. {#art-7097}

§ 1. Korzystający obowiązany jest utrzymywać rzecz w należytym 
stanie, w szczególności dokonywać jej konserwacji i napraw niezbędnych do 
zachowania rzeczy w stanie niepogorszonym, z uwzględnieniem jej zużycia wskutek 

©Kancelaria Sejmu 
 
 
 
s. 149/242 
 
   
 
2025-09-09 
 
prawidłowego używania, oraz ponosić ciężary związane z własnością lub posiadaniem 
rzeczy. 
§ 2. Jeżeli w umowie leasingu nie zostało zastrzeżone, że konserwacji i napraw 
rzeczy dokonuje osoba mająca określone kwalifikacje, korzystający powinien 
niezwłocznie zawiadomić finansującego o konieczności dokonania istotnej naprawy 
rzeczy. 
§ 3. Korzystający obowiązany jest umożliwić finansującemu sprawdzenie rzeczy 
w zakresie określonym w § 1 i 2.

***
## Art. 7098. {#art-7098}

§ 1. Finansujący nie odpowiada wobec korzystającego za wady 
rzeczy, chyba że wady te powstały na skutek okoliczności, za które finansujący ponosi 
odpowiedzialność. Postanowienia umowne mniej korzystne dla korzystającego są 
nieważne. 
§ 2. Z chwilą zawarcia przez finansującego umowy ze zbywcą z mocy ustawy 
przechodzą na korzystającego uprawnienia z tytułu wad rzeczy przysługujące 
finansującemu względem zbywcy, z wyjątkiem uprawnienia odstąpienia przez 
finansującego od umowy ze zbywcą. 
§ 3. Wykonanie przez korzystającego uprawnień określonych w § 2 nie wpływa 
na jego obowiązki wynikające z umowy leasingu, chyba że finansujący odstąpi od 
umowy ze zbywcą z powodu wad rzeczy. 
§ 4. Korzystający może żądać odstąpienia przez finansującego od umowy ze 
zbywcą z powodu wad rzeczy, jeżeli uprawnienie finansującego do odstąpienia 
wynika z przepisów prawa lub umowy ze zbywcą. Bez zgłoszenia żądania przez 
korzystającego finansujący nie może odstąpić od umowy ze zbywcą z powodu wad 
rzeczy. 
§ 5. W razie odstąpienia przez finansującego od umowy ze zbywcą z powodu 
wad rzeczy, umowa leasingu wygasa. Finansujący może żądać od korzystającego 
natychmiastowego zapłacenia wszystkich przewidzianych w umowie a nie-
zapłaconych rat, pomniejszonych o korzyści, jakie finansujący uzyskał wskutek ich 
zapłaty przed umówionym terminem i wygaśnięcia umowy leasingu oraz umowy ze 
zbywcą. 

©Kancelaria Sejmu 
 
 
 
s. 150/242 
 
   
 
2025-09-09

***
## Art. 7099. {#art-7099}

Korzystający powinien używać rzeczy i pobierać jej pożytki w sposób 
określony w umowie leasingu, a gdy umowa tego nie określa – w sposób 
odpowiadający właściwościom i przeznaczeniu rzeczy.

***
## Art. 70910. {#art-70910}

Bez zgody finansującego korzystający nie może czynić w rzeczy 
zmian, chyba że wynikają one z przeznaczenia rzeczy.

***
## Art. 70911. {#art-70911}

Jeżeli 
mimo 
upomnienia 
przez 
finansującego, 
w formie 
dokumentowej, korzystający narusza obowiązki określone w art. 7097 § 1 lub art. 7099 
albo nie usunie zmian w rzeczy dokonanych z naruszeniem art. 70910, finansujący 
może wypowiedzieć umowę leasingu ze skutkiem natychmiastowym, chyba że strony 
uzgodniły termin wypowiedzenia.

***
## Art. 70912. {#art-70912}

§ 1. Bez zgody finansującego korzystający nie może oddać rzeczy do 
używania osobie trzeciej. 
§ 2. W razie naruszenia obowiązku określonego w § 1, finansujący może 
wypowiedzieć umowę leasingu ze skutkiem natychmiastowym, chyba że strony 
uzgodniły termin wypowiedzenia.

***
## Art. 70913. {#art-70913}

§ 1. Korzystający obowiązany jest płacić raty w terminach 
umówionych. 
§ 2.  Jeżeli korzystający dopuszcza się zwłoki z zapłatą co najmniej jednej raty, 
finansujący powinien wyznaczyć korzystającemu, w formie dokumentowej, 
odpowiedni termin dodatkowy do zapłacenia zaległości, z zagrożeniem, że w razie 
bezskutecznego upływu wyznaczonego terminu może wypowiedzieć umowę leasingu 
ze skutkiem natychmiastowym, chyba że strony uzgodniły termin wypowiedzenia. 
Postanowienia umowne mniej korzystne dla korzystającego są nieważne.

***
## Art. 70914. {#art-70914}

§ 1. W razie zbycia rzeczy przez finansującego nabywca wstępuje 
w stosunek leasingu na miejsce finansującego. 
§ 2. Finansujący powinien niezwłocznie zawiadomić korzystającego o zbyciu 
rzeczy.

***
## Art. 70915. {#art-70915}

W razie wypowiedzenia przez finansującego umowy leasingu na 
skutek okoliczności, za które korzystający ponosi odpowiedzialność, finansujący 
może 
żądać 
od 
korzystającego 
natychmiastowego 
zapłacenia 
wszystkich 
przewidzianych w umowie a niezapłaconych rat, pomniejszonych o korzyści, jakie 

©Kancelaria Sejmu 
 
 
 
s. 151/242 
 
   
 
2025-09-09 
 
finansujący uzyskał wskutek ich zapłaty przed umówionym terminem i rozwiązania 
umowy leasingu.

***
## Art. 70916. {#art-70916}

Jeżeli finansujący zobowiązał się, bez dodatkowego świadczenia, 
przenieść na korzystającego własność rzeczy po upływie oznaczonego w umowie 
czasu trwania leasingu, korzystający może żądać przeniesienia własności rzeczy 
w terminie miesiąca od upływu tego czasu, chyba że strony uzgodniły inny termin.

***
## Art. 70917. {#art-70917}

Do odpowiedzialności finansującego za wady rzeczy powstałe na 
skutek okoliczności, za które finansujący ponosi odpowiedzialność, uprawnień 
i obowiązków stron w razie dochodzenia 
przez osobę trzecią przeciwko 
korzystającemu roszczeń dotyczących rzeczy, odpowiedzialności korzystającego 
i osoby trzeciej wobec finansującego w razie oddania rzeczy tej osobie przez 
korzystającego do używania, zabezpieczenia rat leasingu i świadczeń dodatkowych 
korzystającego, zwrotu rzeczy przez korzystającego po zakończeniu leasingu oraz do 
ulepszenia rzeczy przez korzystającego stosuje się odpowiednio przepisy o najmie, 
a do zapłaty przez korzystającego rat przed terminem płatności stosuje się 
odpowiednio przepisy o sprzedaży na raty.

***
## Art. 70918. {#art-70918}

Do umowy, przez którą jedna strona zobowiązuje się oddać rzecz 
stanowiącą jej własność do używania albo do używania i pobierania pożytków drugiej 
stronie, a druga strona zobowiązuje się zapłacić właścicielowi rzeczy w umówionych 
ratach wynagrodzenie pieniężne, równe co najmniej wartości rzeczy w chwili 
zawarcia tej umowy, stosuje się odpowiednio przepisy niniejszego tytułu. 
TYTUŁ XVIII 
Użyczenie

***
## Art. 710. {#art-710}

Przez umowę użyczenia użyczający zobowiązuje się zezwolić 
biorącemu, przez czas oznaczony lub nieoznaczony, na bezpłatne używanie oddanej 
mu w tym celu rzeczy.

***
## Art. 711. {#art-711}

Jeżeli rzecz użyczona ma wady, użyczający obowiązany jest do 
naprawienia szkody, którą wyrządził biorącemu przez to, że wiedząc o wadach nie 
zawiadomił go o nich. Przepisu powyższego nie stosuje się, gdy biorący mógł wadę 
z łatwością zauważyć. 

©Kancelaria Sejmu 
 
 
 
s. 152/242 
 
   
 
2025-09-09

***
## Art. 712. {#art-712}

§ 1. Jeżeli umowa nie określa sposobu używania rzeczy, biorący może 
rzeczy używać w sposób odpowiadający jej właściwościom i przeznaczeniu. 
§ 2. Bez zgody użyczającego biorący nie może oddać rzeczy użyczonej osobie 
trzeciej do używania.

***
## Art. 713. {#art-713}

Biorący do używania ponosi zwykłe koszty utrzymania rzeczy 
użyczonej. Jeżeli poczynił inne wydatki lub nakłady na rzecz, stosuje się odpowiednio 
przepisy o prowadzeniu cudzych spraw bez zlecenia.

***
## Art. 714. {#art-714}

Biorący do używania jest odpowiedzialny za przypadkową utratę lub 
uszkodzenie rzeczy, jeżeli jej używa w sposób sprzeczny z umową albo 
z właściwościami lub z przeznaczeniem rzeczy, albo gdy nie będąc do tego 
upoważniony przez umowę ani zmuszony przez okoliczności powierza rzecz innej 
osobie, a rzecz nie byłaby uległa utracie lub uszkodzeniu, gdyby jej używał w sposób 
właściwy albo gdyby ją zachował u siebie.

***
## Art. 715. {#art-715}

Jeżeli umowa użyczenia została zawarta na czas nieoznaczony, 
użyczenie kończy się, gdy biorący uczynił z rzeczy użytek odpowiadający umowie 
albo gdy upłynął czas, w którym mógł ten użytek uczynić.

***
## Art. 716. {#art-716}

Jeżeli biorący używa rzeczy w sposób sprzeczny z umową albo 
z właściwościami lub z przeznaczeniem rzeczy, jeżeli powierza rzecz innej osobie nie 
będąc do tego upoważniony przez umowę ani zmuszony przez okoliczności, albo jeżeli 
rzecz stanie się potrzebna użyczającemu z powodów nieprzewidzianych w chwili 
zawarcia umowy, użyczający może żądać zwrotu rzeczy, chociażby umowa była 
zawarta na czas oznaczony.

***
## Art. 717. {#art-717}

Jeżeli kilka osób wspólnie wzięło rzecz do używania, ich 
odpowiedzialność jest solidarna.

***
## Art. 718. {#art-718}

§ 1. Po zakończeniu użyczenia biorący do używania obowiązany jest 
zwrócić użyczającemu rzecz w stanie niepogorszonym; jednakże biorący nie ponosi 
odpowiedzialności za zużycie rzeczy będące następstwem prawidłowego używania. 
§ 2. Jeżeli biorący do używania powierzył rzecz innej osobie, obowiązek 
powyższy ciąży także na tej osobie.

***
## Art. 719. {#art-719}

Roszczenie użyczającego przeciwko biorącemu do używania 
o naprawienie szkody za uszkodzenie lub pogorszenie rzeczy, jak również roszczenia 

©Kancelaria Sejmu 
 
 
 
s. 153/242 
 
   
 
2025-09-09 
 
biorącego do używania przeciwko użyczającemu o zwrot nakładów na rzecz oraz 
o naprawienie szkody poniesionej wskutek wad rzeczy przedawniają się z upływem 
roku od dnia zwrotu rzeczy. 
TYTUŁ XIX 
Pożyczka

***
## Art. 720. {#art-720}

§ 1. Przez umowę pożyczki dający pożyczkę zobowiązuje się przenieść 
na własność biorącego określoną ilość pieniędzy albo rzeczy oznaczonych tylko co do 
gatunku, a biorący zobowiązuje się zwrócić tę samą ilość pieniędzy albo tę samą ilość 
rzeczy tego samego gatunku i tej samej jakości. 
§ 2. Umowa pożyczki, której wartość przekracza tysiąc złotych, wymaga 
zachowania formy dokumentowej.

***
## Art. 7201. {#art-7201}

§ 1. Przepis art. 720 § 1 nie wyłącza prawa dającego pożyczkę 
pieniężną do żądania od biorącego pożyczkę odsetek oraz pozaodsetkowych kosztów, 
z zachowaniem przepisów poniższych. 
§ 2. Przez pozaodsetkowe koszty związane z zawarciem umowy pożyczki 
pieniężnej należy rozumieć wynikające z tej lub innej umowy lub z innej czynności 
prawnej: 
- 1) marże, prowizje lub opłaty związane z przygotowaniem umowy pożyczki, 
udzieleniem pożyczki lub jej obsługą, albo koszty o podobnym charakterze, 
- 2) opłaty związane z odroczeniem terminu spłaty pożyczki, jej nieterminową spłatą 
albo koszty o podobnym charakterze, 
- 3) koszty usług dodatkowych, w szczególności koszty ubezpieczeń, koszty 
związane z ustanowieniem zabezpieczenia pożyczki, koszty pozyskiwania 
informacji dotyczących biorącego pożyczkę, w przypadku gdy ich poniesienie 
jest niezbędne do zawarcia umowy 
– z wyłączeniem opłat notarialnych oraz danin o charakterze publicznoprawnym, 
które strony są zobowiązane ponieść w związku z zawarciem umowy. 
§ 3. Jeżeli dającego pożyczkę reprezentuje przy zawarciu umowy agent lub inna 
osoba, za której pośrednictwem dający pożyczkę zawiera umowę lub przy której 
pomocy wykonuje swoje zobowiązanie, do pozaodsetkowych kosztów związanych 
z zawarciem umowy pożyczki wlicza się również wynagrodzenie agenta lub tej osoby, 
o ile ponosi je biorący pożyczkę. 

©Kancelaria Sejmu 
 
 
 
s. 154/242 
 
   
 
2025-09-09

***
## Art. 7202. {#art-7202}

§ 1. Jeżeli przepisy szczególne nie stanowią inaczej, w umowie 
pożyczki pieniężnej zawieranej z osobą fizyczną i niezwiązanej bezpośrednio 
z działalnością gospodarczą lub zawodową tej osoby łączna wysokość pozaodset-
kowych kosztów nie może przekraczać maksymalnej wysokości pozaodsetkowych 
kosztów określonej wzorem: 
MPK = K × n/R × 20 % 
w którym poszczególne symbole oznaczają: 
MPK  – maksymalną wysokość pozaodsetkowych kosztów, 
K  – całkowitą kwotę pożyczki, rozumianą jako suma wszystkich środków 
pieniężnych nieobejmujących współfinansowanych kosztów pożyczki, które dający 
pożyczkę wydaje biorącemu pożyczkę na podstawie umowy, 
n  –  okres spłaty wyrażony w dniach, licząc od dnia wydania przedmiotu 
pożyczki, 
R  –  liczbę dni w roku. 
§ 2. Pozaodsetkowe koszty, o których mowa w § 1, w całym okresie spłaty 
pożyczki nie mogą być wyższe od 25 % całkowitej kwoty pożyczki. 
§ 3. Jeżeli pozaodsetkowe koszty 
przekraczają maksymalną wysokość 
pozaodsetkowych kosztów określoną w § 1 lub 2, należą się pozaodsetkowe koszty 
w maksymalnej wysokości. 
§ 4. Postanowienia umowne nie mogą wyłączać ani ograniczać przepisów 
o maksymalnej wysokości pozaodsetkowych kosztów, także w razie dokonania 
wyboru prawa obcego. W takim przypadku stosuje się przepisy ustawy.

***
## Art. 7203. {#art-7203}

§ 1. Jeżeli w związku z zawarciem umowy, o której mowa 
w art. 7202 § 1, biorący pożyczkę zobowiązuje się udzielić zabezpieczenia zwrotu 
pożyczki, zobowiązanie to należy określić w umowie. W takim przypadku w umowie 
wskazuje się sposób zabezpieczenia oraz, stosownie do okoliczności, rzecz lub prawo 
majątkowe będące przedmiotem zabezpieczenia i jego wartość albo określoną w inny 
sposób sumę zabezpieczenia. 
§ 2. Czynność 
prawna 
zobowiązująca 
do 
udzielenia 
zabezpieczenia 
z naruszeniem § 1 jest nieważna. 
§ 3. Suma 
zabezpieczenia 
roszczeń 
z tytułu 
umowy, 
o której 
mowa 
w art. 7202 § 1, nie może być wyższa od sumy kwoty pożyczki powiększonej 
o wysokość odsetek maksymalnych obliczonych bezpośrednio od tej kwoty za okres, 

©Kancelaria Sejmu 
 
 
 
s. 155/242 
 
   
 
2025-09-09 
 
na który została udzielona pożyczka, wysokości odsetek maksymalnych za opóźnienie 
obliczonych od kwoty pożyczki za okres do 6 miesięcy oraz maksymalnej wysokości 
pozaodsetkowych kosztów, chyba że przepis szczególny stanowi inaczej. 
§ 4. Przepisów § 1–3 nie stosuje się do zabezpieczenia przyjmującego postać 
hipoteki lub zastawu rejestrowego.

***
## Art. 7204. {#art-7204}

Przed zawarciem umowy, o której mowa w art. 7202 § 1, dający 
pożyczkę informuje biorącego pożyczkę w sposób jednoznaczny i zrozumiały 
o łącznej wysokości pozaodsetkowych kosztów, wysokości odsetek oraz kwocie 
należnej z tytułu odsetek, którą jest on zobowiązany zapłacić w związku z zawarciem 
umowy.

***
## Art. 7205. {#art-7205}

§ 1. W przypadku spłaty pożyczki, o której mowa w art. 7202 § 1, 
przed terminem określonym w umowie nie można żądać odsetek za okres pozostały 
do zakończenia okresu, na który zgodnie z umową została udzielona pożyczka. 
§ 2. W przypadku spłaty pożyczki, o której mowa w art. 7202 § 1, przed 
terminem określonym w umowie poniesione pozaodsetkowe koszty ulegają obniżeniu 
o te koszty, które dotyczą okresu, o który skrócono czas obowiązywania umowy, 
chociażby biorący pożyczkę poniósł je przed tą spłatą.

***
## Art. 7206. {#art-7206}

(uchylony)

***
## Art. 721. {#art-721}

Dający pożyczkę może odstąpić od umowy i odmówić wydania 
przedmiotu pożyczki, jeżeli zwrot pożyczki jest wątpliwy z powodu złego stanu 
majątkowego drugiej strony. Uprawnienie to nie przysługuje dającemu pożyczkę, 
jeżeli w chwili zawarcia umowy o złym stanie majątkowym drugiej strony wiedział 
lub z łatwością mógł się dowiedzieć.

***
## Art. 722. {#art-722}

Roszczenie biorącego pożyczkę o wydanie przedmiotu pożyczki 
przedawnia się z upływem sześciu miesięcy od chwili, gdy przedmiot miał być 
wydany.

***
## Art. 723. {#art-723}

Jeżeli termin zwrotu pożyczki nie jest oznaczony, dłużnik obowiązany 
jest zwrócić pożyczkę w ciągu sześciu tygodni po wypowiedzeniu przez dającego 
pożyczkę.

***
## Art. 724. {#art-724}

Jeżeli rzeczy otrzymane przez biorącego pożyczkę mają wady, dający 
pożyczkę obowiązany jest do naprawienia szkody, którą wyrządził biorącemu przez 

©Kancelaria Sejmu 
 
 
 
s. 156/242 
 
   
 
2025-09-09 
 
to, że wiedząc o wadach nie zawiadomił go o nich. Przepisu powyższego nie stosuje 
się w wypadku, gdy biorący mógł z łatwością wadę zauważyć.

***
## Art. 7241. {#art-7241}

§ 1. Do nieuregulowanych innymi przepisami umów, na mocy 
których osobie fizycznej zostaje przekazana suma pieniężna z obowiązkiem jej 
zwrotu, niezwiązanych bezpośrednio z działalnością gospodarczą lub zawodową tej 
osoby stosuje się odpowiednio przepisy art. 7201–7205. 
§ 2. Przepisy art. 7201–7205 stosuje się odpowiednio także do nieuregulowanych 
innymi przepisami umów przeniesienia na osobę fizyczną za wynagrodzeniem 
wierzytelności lub innych praw majątkowych, których wartość oznaczono sumą 
pieniężną z obowiązkiem ich zwrotu, jeżeli umowy te nie są związane bezpośrednio 
z działalnością gospodarczą lub zawodową tej osoby. W takim przypadku przez 
całkowitą wartość pożyczki należy rozumieć wartość tych wierzytelności lub praw 
według stanu na dzień rozporządzenia nimi. 
TYTUŁ XX 
Umowa rachunku bankowego

***
## Art. 725. {#art-725}

Przez umowę rachunku bankowego bank zobowiązuje się względem 
posiadacza rachunku, na czas oznaczony lub nieoznaczony, do przechowywania jego 
środków pieniężnych oraz, jeżeli umowa tak stanowi, do przeprowadzania na jego 
zlecenie rozliczeń pieniężnych.

***
## Art. 726. {#art-726}

Bank może obracać czasowo wolne środki pieniężne zgromadzone na 
rachunku bankowym z obowiązkiem ich zwrotu w całości lub w części na każde 
żądanie, chyba że umowa uzależnia obowiązek zwrotu od wypowiedzenia.

***
## Art. 727. {#art-727}

Bank może odmówić wykonania zlecenia posiadacza rachunku 
bankowego tylko w wypadkach przewidzianych w przepisach szczególnych.

***
## Art. 728. {#art-728}

§ 1. Przy umowie zawartej na czas nieoznaczony bank jest obowiązany 
informować posiadacza rachunku, w sposób określony w umowie, o każdej zmianie 
stanu rachunku bankowego. 
§ 2. Bank jest obowiązany przesyłać posiadaczowi co najmniej raz w miesiącu 
bezpłatnie wyciąg z rachunku z informacją o zmianach stanu rachunku i ustaleniem 
salda, chyba że posiadacz wyraził pisemnie zgodę na inny sposób informowania 
o zmianach stanu rachunku i ustaleniu salda. 

©Kancelaria Sejmu 
 
 
 
s. 157/242 
 
   
 
2025-09-09 
 
§ 3. Posiadacz rachunku bankowego jest obowiązany zgłosić bankowi 
niezgodność zmian stanu rachunku lub salda w ciągu czternastu dni od dnia 
otrzymania wyciągu z rachunku.

***
## Art. 729. {#art-729}

Posiadacz 
imiennego 
rachunku 
bankowego 
obowiązany 
jest 
zawiadamiać bank o każdej zmianie swego zamieszkania lub siedziby.

***
## Art. 730. {#art-730}

Rozwiązanie umowy rachunku bankowego zawartej na czas 
nieoznaczony może nastąpić w każdym czasie wskutek wypowiedzenia przez 
którąkolwiek ze stron; jednakże bank może wypowiedzieć taką umowę tylko 
z ważnych powodów.

***
## Art. 731. {#art-731}

Roszczenia 
wynikające 
ze 
stosunku 
rachunku 
bankowego 
przedawniają się z upływem lat dwóch. Nie dotyczy to roszczeń o zwrot wkładów 
oszczędnościowych.

***
## Art. 732. {#art-732}

Przepisy niniejszego tytułu stosuje się odpowiednio również do 
rachunków prowadzonych przez spółdzielcze kasy oszczędnościowo-kredytowe.

***
## Art. 733. {#art-733}

Przepisy niniejszego tytułu nie uchybiają przepisom o rozliczeniach 
pieniężnych. 
TYTUŁ XXI 
Zlecenie

***
## Art. 734. {#art-734}

§ 1. Przez umowę zlecenia przyjmujący zlecenie zobowiązuje się do 
dokonania określonej czynności prawnej dla dającego zlecenie. 
§ 2. W braku odmiennej umowy zlecenie obejmuje umocowanie do wykonania 
czynności w imieniu dającego zlecenie. Przepis ten nie uchybia przepisom o formie 
pełnomocnictwa.

***
## Art. 735. {#art-735}

§ 1. Jeżeli ani z umowy, ani z okoliczności nie wynika, że przyjmujący 
zlecenie zobowiązał się wykonać je bez wynagrodzenia, za wykonanie zlecenia należy 
się wynagrodzenie. 
§ 2. Jeżeli nie ma obowiązującej taryfy, a nie umówiono się o wysokość 
wynagrodzenia, należy się wynagrodzenie odpowiadające wykonanej pracy.

***
## Art. 736. {#art-736}

Kto zawodowo trudni się załatwianiem czynności dla drugich, 
powinien, jeżeli nie chce zlecenia przyjąć, zawiadomić o tym niezwłocznie dającego 

©Kancelaria Sejmu 
 
 
 
s. 158/242 
 
   
 
2025-09-09 
 
zlecenie. Taki sam obowiązek ciąży na osobie, która dającemu zlecenie oświadczyła 
gotowość załatwiania czynności danego rodzaju.

***
## Art. 737. {#art-737}

Przyjmujący zlecenie może bez uprzedniej zgody dającego zlecenie 
odstąpić od wskazanego przez niego sposobu wykonania zlecenia, jeżeli nie ma 
możności uzyskania jego zgody, a zachodzi uzasadniony powód do przypuszczenia, 
że dający zlecenie zgodziłby się na zmianę, gdyby wiedział o istniejącym stanie 
rzeczy.

***
## Art. 738. {#art-738}

§ 1. Przyjmujący zlecenie może powierzyć wykonanie zlecenia osobie 
trzeciej tylko wtedy, gdy to wynika z umowy lub ze zwyczaju albo gdy jest do tego 
zmuszony przez okoliczności. W wypadku takim obowiązany jest zawiadomić 
niezwłocznie dającego zlecenie o osobie i o miejscu zamieszkania swego zastępcy 
i w razie zawiadomienia odpowiedzialny jest tylko za brak należytej staranności 
w wyborze zastępcy. 
§ 2. Zastępca odpowiedzialny jest za wykonanie zlecenia także względem 
dającego zlecenie. Jeżeli przyjmujący zlecenie ponosi odpowiedzialność za czynności 
swego zastępcy jak za swoje własne czynności, ich odpowiedzialność jest solidarna.

***
## Art. 739. {#art-739}

W wypadku gdy przyjmujący zlecenie powierzył wykonanie zlecenia 
innej osobie nie będąc do tego uprawniony, a rzecz należąca do dającego zlecenie 
uległa przy wykonywaniu zlecenia utracie lub uszkodzeniu, przyjmujący zlecenie jest 
odpowiedzialny także za utratę lub uszkodzenie przypadkowe, chyba że jedno lub 
drugie nastąpiłoby również wtedy, gdyby sam zlecenie wykonywał.

***
## Art. 740. {#art-740}

Przyjmujący 
zlecenie 
powinien 
udzielać 
dającemu 
zlecenie 
potrzebnych wiadomości o przebiegu sprawy, a po wykonaniu zlecenia lub po 
wcześniejszym rozwiązaniu umowy złożyć mu sprawozdanie. Powinien mu wydać 
wszystko, co przy wykonaniu zlecenia dla niego uzyskał, chociażby w imieniu 
własnym.

***
## Art. 741. {#art-741}

Przyjmującemu zlecenie nie wolno używać we własnym interesie 
rzeczy i pieniędzy dającego zlecenie. Od sum pieniężnych zatrzymanych ponad 
potrzebę wynikającą z wykonywania zlecenia powinien płacić dającemu zlecenie 
odsetki ustawowe. 

©Kancelaria Sejmu 
 
 
 
s. 159/242 
 
   
 
2025-09-09

***
## Art. 742. {#art-742}

Dający zlecenie powinien zwrócić przyjmującemu zlecenie wydatki, 
które ten poczynił w celu należytego wykonania zlecenia, wraz z odsetkami 
ustawowymi; powinien również zwolnić przyjmującego zlecenie od zobowiązań, 
które ten w powyższym celu zaciągnął w imieniu własnym.

***
## Art. 743. {#art-743}

Jeżeli wykonanie zlecenia wymaga wydatków, dający zlecenie 
powinien na żądanie przyjmującego udzielić mu odpowiedniej zaliczki.

***
## Art. 744. {#art-744}

W razie odpłatnego zlecenia wynagrodzenie należy się przyjmującemu 
dopiero po wykonaniu zlecenia, chyba że co innego wynika z umowy lub z przepisów 
szczególnych.

***
## Art. 745. {#art-745}

Jeżeli kilka osób dało lub przyjęło zlecenie wspólnie, ich 
odpowiedzialność względem drugiej strony jest solidarna.

***
## Art. 746. {#art-746}

§ 1. Dający zlecenie może je wypowiedzieć w każdym czasie. 
Powinien jednak zwrócić przyjmującemu zlecenie wydatki, które ten poczynił w celu 
należytego wykonania zlecenia; w razie odpłatnego zlecenia obowiązany jest uiścić 
przyjmującemu zlecenie część wynagrodzenia odpowiadającą jego dotychczasowym 
czynnościom, a jeżeli wypowiedzenie nastąpiło bez ważnego powodu, powinien także 
naprawić szkodę. 
§ 2. Przyjmujący zlecenie może je wypowiedzieć w każdym czasie. Jednakże 
gdy zlecenie jest odpłatne, a wypowiedzenie nastąpiło bez ważnego powodu, 
przyjmujący zlecenie jest odpowiedzialny za szkodę. 
§ 3. Nie można zrzec się z góry uprawnienia do wypowiedzenia zlecenia 
z ważnych powodów.

***
## Art. 747. {#art-747}

W braku odmiennej umowy zlecenie nie wygasa ani wskutek śmierci 
dającego zlecenie, ani wskutek utraty przez niego zdolności do czynności prawnych. 
Jeżeli jednak, zgodnie z umową, zlecenie wygasło, przyjmujący zlecenie powinien, 
gdyby z przerwania powierzonych mu czynności mogła wyniknąć szkoda, prowadzić 
te czynności nadal, dopóki spadkobierca albo przedstawiciel ustawowy dającego 
zlecenie nie będzie mógł zarządzić inaczej.

***
## Art. 748. {#art-748}

W braku odmiennej umowy zlecenie wygasa wskutek śmierci 
przyjmującego zlecenie albo wskutek utraty przez niego pełnej zdolności do czynności 
prawnych. 

©Kancelaria Sejmu 
 
 
 
s. 160/242 
 
   
 
2025-09-09

***
## Art. 749. {#art-749}

Jeżeli zlecenie wygasło, uważa się je mimo to za istniejące na korzyść 
przyjmującego zlecenie aż do chwili, kiedy dowiedział się o wygaśnięciu zlecenia.

***
## Art. 750. {#art-750}

Do umów o świadczenie usług, które nie są uregulowane innymi 
przepisami, stosuje się odpowiednio przepisy o zleceniu.

***
## Art. 751. {#art-751}

Z upływem lat dwóch przedawniają się: 
- 1) roszczenia o wynagrodzenie za spełnione czynności i o zwrot poniesionych 
wydatków przysługujące osobom, które stale lub w zakresie działalności 
przedsiębiorstwa trudnią się czynnościami danego rodzaju; to samo dotyczy 
roszczeń z tytułu zaliczek udzielonych tym osobom; 
- 2) roszczenia z tytułu utrzymania, pielęgnowania, wychowania lub nauki, jeżeli 
przysługują osobom trudniącym się zawodowo takimi czynnościami albo 
osobom utrzymującym zakłady na ten cel przeznaczone. 
TYTUŁ XXII 
Prowadzenie cudzych spraw bez zlecenia

***
## Art. 752. {#art-752}

Kto bez zlecenia prowadzi cudzą sprawę, powinien działać z korzyścią 
osoby, której sprawę prowadzi, i zgodnie z jej prawdopodobną wolą, a przy 
prowadzeniu sprawy obowiązany jest zachowywać należytą staranność.

***
## Art. 753. {#art-753}

§ 1. Prowadzący cudzą sprawę bez zlecenia powinien w miarę 
możności zawiadomić o tym osobę, której sprawę prowadzi, i stosownie do 
okoliczności albo oczekiwać jej zleceń, albo prowadzić sprawę dopóty, dopóki osoba 
ta nie będzie mogła sama się nią zająć. 
§ 2. Z czynności swych prowadzący cudzą sprawę powinien złożyć rachunek 
oraz wydać wszystko, co przy prowadzeniu sprawy uzyskał dla osoby, której sprawę 
prowadzi. Jeżeli działał zgodnie ze swoimi obowiązkami, może żądać zwrotu 
uzasadnionych wydatków i nakładów wraz z ustawowymi odsetkami oraz zwolnienia 
od zobowiązań, które zaciągnął przy prowadzeniu sprawy.

***
## Art. 754. {#art-754}

Kto prowadzi cudzą sprawę wbrew wiadomej mu woli osoby, której 
sprawę prowadzi, nie może żądać zwrotu poniesionych wydatków i odpowiedzialny 
jest za szkodę, chyba że wola tej osoby sprzeciwia się ustawie lub zasadom współżycia 
społecznego. 

©Kancelaria Sejmu 
 
 
 
s. 161/242 
 
   
 
2025-09-09

***
## Art. 755. {#art-755}

Jeżeli prowadzący cudzą sprawę dokonał zmian w mieniu osoby, 
której sprawę prowadzi, bez wyraźnej potrzeby lub korzyści tej osoby albo wbrew 
wiadomej mu jej woli, obowiązany jest przywrócić stan poprzedni, a gdyby to nie było 
możliwe, naprawić szkodę. Nakłady może zabrać z powrotem, o ile może to uczynić 
bez uszkodzenia rzeczy.

***
## Art. 756. {#art-756}

Potwierdzenie osoby, której sprawa była prowadzona, nadaje 
prowadzeniu sprawy skutki zlecenia.

***
## Art. 757. {#art-757}

Kto w celu odwrócenia niebezpieczeństwa grożącego drugiemu ratuje 
jego dobro, może żądać od niego zwrotu uzasadnionych wydatków, chociażby jego 
działanie nie odniosło skutku, i jest odpowiedzialny tylko za winę umyślną lub rażące 
niedbalstwo. 
TYTUŁ XXIII 
Umowa agencyjna

***
## Art. 758. {#art-758}

§ 1. Przez 
umowę agencyjną przyjmujący zlecenie (agent) 
zobowiązuje się, w zakresie działalności swego przedsiębiorstwa, do stałego 
pośredniczenia, za wynagrodzeniem, przy zawieraniu z klientami umów na rzecz 
dającego zlecenie przedsiębiorcy albo do zawierania ich w jego imieniu. 
§ 2. Do zawierania umów w imieniu dającego zlecenie oraz do odbierania dla 
niego oświadczeń agent jest uprawniony tylko wtedy, gdy ma do tego umocowanie.

***
## Art. 7581. {#art-7581}

§ 1. Jeżeli sposób wynagrodzenia nie został w umowie określony, 
agentowi należy się prowizja. 
§ 2. Prowizją jest wynagrodzenie, którego wysokość zależy od liczby lub 
wartości zawartych umów. 
§ 3. Jeżeli wysokość prowizji nie została w umowie określona, należy się ona 
w wysokości zwyczajowo przyjętej w stosunkach danego rodzaju, w miejscu 
działalności prowadzonej przez agenta, a w razie niemożności ustalenia prowizji w ten 
sposób, agentowi należy się prowizja w odpowiedniej wysokości, uwzględniającej 
wszystkie okoliczności bezpośrednio związane z wykonaniem zleconych mu 
czynności. 

©Kancelaria Sejmu 
 
 
 
s. 162/242 
 
   
 
2025-09-09

***
## Art. 7582. {#art-7582}

Każda ze stron może żądać od drugiej pisemnego potwierdzenia treści 
umowy oraz postanowień ją zmieniających lub uzupełniających. Zrzeczenie się tego 
uprawnienia jest nieważne.

***
## Art. 759. {#art-759}

W razie wątpliwości poczytuje się, że agent jest upoważniony do 
przyjmowania dla dającego zlecenie zapłaty za świadczenie, które spełnia za dającego 
zlecenie, oraz do przyjmowania dla niego świadczeń, za które płaci, jak również do 
odbierania zawiadomień o wadach oraz oświadczeń dotyczących wykonania umowy, 
którą zawarł w imieniu dającego zlecenie.

***
## Art. 760. {#art-760}

Każda ze stron obowiązana jest do zachowania lojalności wobec 
drugiej.

***
## Art. 7601. {#art-7601}

§ 1. Agent obowiązany jest w szczególności przekazywać wszelkie 
informacje mające znaczenie dla dającego zlecenie oraz przestrzegać jego wskazówek 
uzasadnionych w danych okolicznościach, a także podejmować, w zakresie 
prowadzonych spraw, czynności potrzebne do ochrony praw dającego zlecenie. 
§ 2. Postanowienia umowy sprzeczne z treścią § 1 są nieważne.

***
## Art. 7602. {#art-7602}

§ 1. Dający zlecenie obowiązany jest przekazywać agentowi 
dokumenty i informacje potrzebne do prawidłowego wykonania umowy. 
§ 2. Dający zlecenie obowiązany jest w rozsądnym czasie zawiadomić agenta 
o przyjęciu lub odrzuceniu propozycji zawarcia umowy oraz o niewykonaniu umowy, 
przy której zawarciu agent pośredniczył lub którą zawarł w imieniu dającego zlecenie. 
§ 3. Dający zlecenie obowiązany jest zawiadomić w rozsądnym czasie agenta 
o tym, że liczba umów, których zawarcie przewiduje, lub wartość ich przedmiotu 
będzie znacznie niższa niż ta, której agent mógłby się normalnie spodziewać. 
§ 4. Postanowienia umowy sprzeczne z treścią § 1–3 są nieważne.

***
## Art. 7603. {#art-7603}

W razie gdy agent zawierający umowę w imieniu dającego zlecenie 
nie ma umocowania albo przekroczy jego zakres, umowę uważa się za potwierdzoną, 
jeżeli dający zlecenie niezwłocznie po otrzymaniu wiadomości o zawarciu umowy nie 
oświadczy klientowi, że umowy nie potwierdza.

***
## Art. 761. {#art-761}

§ 1. Agent może żądać prowizji od umów zawartych w czasie trwania 
umowy agencyjnej, jeżeli do ich zawarcia doszło w wyniku jego działalności lub jeżeli 

©Kancelaria Sejmu 
 
 
 
s. 163/242 
 
   
 
2025-09-09 
 
zostały one zawarte z klientami pozyskanymi przez agenta poprzednio dla umów tego 
samego rodzaju. 
§ 2. Jeżeli agentowi zostało przyznane prawo wyłączności w odniesieniu do 
oznaczonej grupy klientów lub obszaru geograficznego, a w czasie trwania umowy 
agencyjnej została bez udziału agenta zawarta umowa z klientem z tej grupy lub 
obszaru, agent może żądać prowizji od tej umowy. Dający zlecenie obowiązany jest 
w rozsądnym czasie zawiadomić agenta o zawarciu takiej umowy.

***
## Art. 7611. {#art-7611}

§ 1. Agent może żądać prowizji od umowy zawartej po rozwiązaniu 
umowy agencyjnej, jeżeli – przy spełnieniu przesłanek z art. 761 – propozycję 
zawarcia umowy dający zlecenie lub agent otrzymał od klienta przed rozwiązaniem 
umowy agencyjnej. 
§ 2. Agent może żądać prowizji od umowy zawartej po rozwiązaniu umowy 
agencyjnej także wtedy, gdy do jej zawarcia doszło w przeważającej mierze w wyniku 
jego działalności w okresie trwania umowy agencyjnej, a zarazem w rozsądnym czasie 
od jej rozwiązania.

***
## Art. 7612. {#art-7612}

Agent nie może żądać prowizji, o której mowa w art. 761, jeżeli 
prowizja ta należy się zgodnie z art. 7611 poprzedniemu agentowi, chyba że 
z okoliczności wynika, że względy słuszności przemawiają za podziałem prowizji 
między obu agentów.

***
## Art. 7613. {#art-7613}

§ 1. W braku odmiennego postanowienia umowy agencyjnej agent 
nabywa prawo do prowizji z chwilą, w której dający zlecenie powinien był, zgodnie 
z umową z klientem, spełnić świadczenie albo faktycznie je spełnił, albo też swoje 
świadczenie spełnił klient. Jednakże strony nie mogą umówić się, że agent nabywa 
prawo do prowizji później niż w chwili, w której klient spełnił świadczenie albo 
powinien był je spełnić, gdyby dający zlecenie spełnił świadczenie. 
§ 2. Jeżeli umowa zawarta pomiędzy dającym zlecenie i klientem ma być 
wykonywana częściami, agent nabywa prawo do prowizji w miarę wykonywania tej 
umowy. 
§ 3. Roszczenie o zapłatę prowizji staje się wymagalne z upływem ostatniego 
dnia miesiąca następującego po kwartale, w którym agent nabył prawo do prowizji. 
Postanowienie umowy mniej korzystne dla agenta jest nieważne. 

©Kancelaria Sejmu 
 
 
 
s. 164/242 
 
   
 
2025-09-09

***
## Art. 7614. {#art-7614}

Agent nie może żądać prowizji, gdy oczywiste jest, że umowa 
z klientem nie zostanie wykonana na skutek okoliczności, za które dający zlecenie nie 
ponosi odpowiedzialności, jeżeli zaś prowizja została już agentowi wypłacona, 
podlega ona zwrotowi. Postanowienie umowy agencyjnej mniej korzystne dla agenta 
jest nieważne.

***
## Art. 7615. {#art-7615}

§ 1. Dający zlecenie obowiązany jest złożyć agentowi oświadczenie 
zawierające dane o należnej mu prowizji nie później niż w ostatnim dniu miesiąca 
następującego po kwartale, w którym agent nabył prawo do prowizji. Oświadczenie to 
powinno wskazywać wszystkie dane stanowiące podstawę do obliczenia wysokości 
należnej prowizji. Postanowienie umowy agencyjnej mniej korzystne dla agenta jest 
nieważne. 
§ 2. Agent może domagać się udostępnienia informacji potrzebnych do ustalenia, 
czy wysokość należnej mu prowizji została prawidłowo obliczona, w szczególności 
może domagać się wyciągów z ksiąg handlowych dającego zlecenie albo żądać, aby 
wgląd i wyciąg z tych ksiąg został zapewniony biegłemu rewidentowi wybranemu 
przez strony. Postanowienie umowy agencyjnej mniej korzystne dla agenta jest 
nieważne. 
§ 3. W razie nieudostępnienia agentowi informacji, o których mowa w § 2, agent 
może domagać się ich udostępnienia w drodze powództwa wytoczonego w okresie 
sześciu miesięcy od dnia zgłoszenia żądania dającemu zlecenie. 
§ 4. W razie nieosiągnięcia przez strony porozumienia co do wyboru biegłego 
rewidenta, o którym mowa w § 2, agent może domagać się, w drodze powództwa 
wytoczonego w okresie sześciu miesięcy od dnia zgłoszenia żądania dającemu 
zlecenie, dokonania wglądu i wyciągu z ksiąg przez biegłego wskazanego przez sąd.

***
## Art. 7616. {#art-7616}

Przepisy art. 761–7615 stosuje się w razie gdy prowizja stanowi całość 
lub część wynagrodzenia, chyba że strony uzgodniły stosowanie tych przepisów do 
innego rodzaju wynagrodzenia.

***
## Art. 7617. {#art-7617}

§ 1. W umowie agencyjnej zawartej w formie pisemnej można 
zastrzec, że agent za odrębnym wynagrodzeniem (prowizja del credere), 
w uzgodnionym zakresie, odpowiada za wykonanie zobowiązania przez klienta. Jeżeli 
umowa nie stanowi inaczej, agent odpowiada za to, że klient spełni świadczenie. 

©Kancelaria Sejmu 
 
 
 
s. 165/242 
 
   
 
2025-09-09 
 
W razie niezachowania formy pisemnej poczytuje się umowę agencyjną za zawartą 
bez tego zastrzeżenia. 
§ 2. Odpowiedzialność agenta może dotyczyć tylko oznaczonej umowy lub 
umów z oznaczonym klientem, przy których zawarciu pośredniczył albo które zawarł 
w imieniu dającego zlecenie.

***
## Art. 762. {#art-762}

W braku odmiennego postanowienia umowy agent może domagać się 
zwrotu wydatków związanych z wykonaniem zlecenia tylko o tyle, o ile były 
uzasadnione i o ile ich wysokość przekracza zwykłą w danych stosunkach miarę.

***
## Art. 763. {#art-763}

Dla zabezpieczenia roszczenia o wynagrodzenie oraz o zwrot 
wydatków i zaliczek udzielonych dającemu zlecenie agentowi przysługuje ustawowe 
prawo zastawu na rzeczach i papierach wartościowych dającego zlecenie, 
otrzymanych w związku z umową agencyjną, dopóki przedmioty te znajdują się u 
niego lub osoby, która je dzierży w jego imieniu, albo dopóki może nimi rozporządzać 
za pomocą dokumentów.

***
## Art. 764. {#art-764}

Umowę zawartą na czas oznaczony, a wykonywaną przez strony po 
upływie terminu, na jaki została zawarta, poczytuje się za zawartą na czas 
nieoznaczony.

***
## Art. 7641. {#art-7641}

§ 1. Umowa zawarta na czas nieoznaczony może być wypowiedziana 
na miesiąc naprzód w pierwszym roku, na dwa miesiące naprzód w drugim roku oraz 
na trzy miesiące naprzód w trzecim i następnych latach trwania umowy. Ustawowe 
terminy wypowiedzenia nie mogą być skracane. 
§ 2. Ustawowe terminy wypowiedzenia mogą zostać umownie przedłużone, 
z tym że termin ustalony dla dającego zlecenie nie może być krótszy niż termin 
ustalony dla agenta. Przedłużenie terminu dla agenta powoduje takie samo 
przedłużenie dla dającego zlecenie. 
§ 3. Jeżeli umowa nie stanowi inaczej, termin wypowiedzenia upływa z końcem 
miesiąca kalendarzowego. 
§ 4. Przepisy § 1–3 mają zastosowanie do umowy zawartej na czas oznaczony, 
a przekształconej z mocy art. 764 w umowę zawartą na czas nieoznaczony. Okres, na 
jaki umowa na czas oznaczony była zawarta, uwzględnia się przy ustalaniu terminu 
wypowiedzenia. 

©Kancelaria Sejmu 
 
 
 
s. 166/242 
 
   
 
2025-09-09

***
## Art. 7642. {#art-7642}

§ 1. Umowa agencyjna, chociażby była zawarta na czas oznaczony, 
może być wypowiedziana bez zachowania terminów wypowiedzenia z powodu 
niewykonania obowiązków przez jedną ze stron w całości lub znacznej części, a także 
w przypadku zaistnienia nadzwyczajnych okoliczności. 
§ 2. Jeżeli wypowiedzenia dokonano na skutek okoliczności, za które ponosi 
odpowiedzialność druga strona, jest ona zobowiązana do naprawienia szkody 
poniesionej przez wypowiadającego w następstwie rozwiązania umowy.

***
## Art. 7643. {#art-7643}

§ 1. Po rozwiązaniu umowy agencyjnej agent może żądać od dającego 
zlecenie świadczenia wyrównawczego, jeżeli w czasie trwania umowy agencyjnej 
pozyskał nowych klientów lub doprowadził do istotnego wzrostu obrotów 
z dotychczasowymi klientami, a dający zlecenie czerpie nadal znaczne korzyści 
z umów z tymi klientami. Roszczenie to przysługuje agentowi, jeżeli, biorąc pod 
uwagę wszystkie okoliczności, a zwłaszcza utratę przez agenta prowizji od umów 
zawartych przez dającego zlecenie z tymi klientami, przemawiają za tym względy 
słuszności. 
§ 2. Świadczenie 
wyrównawcze 
nie 
może 
przekroczyć 
wysokości 
wynagrodzenia agenta za jeden rok, obliczonego na podstawie średniego rocznego 
wynagrodzenia uzyskanego w okresie ostatnich pięciu lat. Jeżeli umowa agencyjna 
trwała krócej niż pięć lat, wynagrodzenie to oblicza się z uwzględnieniem średniej 
z całego okresu jej trwania. 
§ 3. Uzyskanie świadczenia wyrównawczego nie pozbawia agenta możności 
dochodzenia odszkodowania na zasadach ogólnych. 
§ 4. W razie śmierci agenta, świadczenia wyrównawczego, o którym mowa 
w § 1, mogą żądać jego spadkobiercy. 
§ 5. Możliwość dochodzenia roszczenia o świadczenie wyrównawcze zależy od 
zgłoszenia przez agenta lub jego spadkobierców odpowiedniego żądania wobec 
dającego zlecenie przed upływem roku od rozwiązania umowy.

***
## Art. 7644. {#art-7644}

Świadczenie wyrównawcze nie przysługuje agentowi, jeżeli: 
- 1) dający zlecenie wypowiedział umowę na skutek okoliczności, za które 
odpowiedzialność ponosi agent, usprawiedliwiających wypowiedzenie umowy 
bez zachowania terminów wypowiedzenia; 

©Kancelaria Sejmu 
 
 
 
s. 167/242 
 
   
 
2025-09-09 
- 2) agent wypowiedział umowę, chyba że wypowiedzenie jest uzasadnione 
okolicznościami, za które odpowiada dający zlecenie, albo jest usprawiedliwione 
wiekiem, ułomnością lub chorobą agenta, a względy słuszności nie pozwalają 
domagać się od niego dalszego wykonywania czynności agenta; 
- 3) agent za zgodą dającego zlecenie przeniósł na inną osobę swoje prawa 
i obowiązki wynikające z umowy.

***
## Art. 7645. {#art-7645}

Do czasu rozwiązania umowy strony nie mogą umówić się w sposób 
odbiegający na niekorzyść agenta od postanowień art. 7643 i art. 7644.

***
## Art. 7646. {#art-7646}

§ 1. Strony mogą, w formie pisemnej pod rygorem nieważności, 
ograniczyć działalność agenta mającą charakter konkurencyjny na okres po 
rozwiązaniu umowy agencyjnej (ograniczenie działalności konkurencyjnej). 
Ograniczenie jest ważne, jeżeli dotyczy grupy klientów lub obszaru geograficznego, 
objętych działalnością agenta, oraz rodzaju towarów lub usług stanowiących 
przedmiot umowy. 
§ 2. Ograniczenie działalności konkurencyjnej nie może być zastrzeżone na 
okres dłuższy niż dwa lata od rozwiązania umowy. 
§ 3. Dający zlecenie obowiązany jest do wypłacania agentowi odpowiedniej 
sumy pieniężnej za ograniczenie działalności konkurencyjnej w czasie jego trwania, 
chyba że co innego wynika z umowy albo że umowa agencyjna została rozwiązana na 
skutek okoliczności, za które agent ponosi odpowiedzialność. 
§ 4. Jeżeli wysokość sumy, o której mowa w § 3, nie została w umowie 
określona, należy się suma w wysokości odpowiedniej do korzyści osiągniętych przez 
dającego zlecenie na skutek ograniczenia działalności konkurencyjnej oraz utraconych 
z tego powodu możliwości zarobkowych agenta.

***
## Art. 7647. {#art-7647}

Dający zlecenie może do dnia rozwiązania umowy odwołać 
ograniczenie działalności konkurencyjnej z takim skutkiem, że po upływie sześciu 
miesięcy od chwili odwołania jest on zwolniony z obowiązku wypłacania sumy, 
o której 
mowa 
w art. 7646 
§ 3 
i 4. 
Odwołanie 
ograniczenia 
działalności 
konkurencyjnej wymaga formy pisemnej pod rygorem nieważności.

***
## Art. 7648. {#art-7648}

Jeżeli agent wypowiedział umowę na skutek okoliczności, za które 
odpowiedzialność ponosi dający zlecenie, może on zwolnić się z obowiązku 

©Kancelaria Sejmu 
 
 
 
s. 168/242 
 
   
 
2025-09-09 
 
przestrzegania ograniczenia działalności konkurencyjnej przez złożenie dającemu 
zlecenie oświadczenia na piśmie przed upływem miesiąca od dnia wypowiedzenia.

***
## Art. 7649. {#art-7649}

Do umowy o treści określonej w art. 758 § 1, zawartej z agentem 
przez osobę niebędącą przedsiębiorcą, stosuje się przepisy niniejszego tytułu, 
z wyłączeniem art. 761–7612, art. 7615 oraz art. 7643–7648. 
TYTUŁ XXIV 
Umowa komisu

***
## Art. 765. {#art-765}

Przez umowę komisu przyjmujący zlecenie (komisant) zobowiązuje 
się za wynagrodzeniem (prowizja) w zakresie działalności swego przedsiębiorstwa do 
kupna lub sprzedaży rzeczy ruchomych na rachunek dającego zlecenie (komitenta), 
lecz w imieniu własnym.

***
## Art. 766. {#art-766}

Komisant powinien wydać komitentowi wszystko, co przy wykonaniu 
zlecenia dla niego uzyskał, w szczególności powinien przelać na niego wierzytelności, 
które nabył na jego rachunek. Powyższe uprawnienia komitenta są skuteczne także 
względem wierzycieli komisanta.

***
## Art. 767. {#art-767}

Jeżeli komisant zawarł umowę na warunkach korzystniejszych od 
warunków oznaczonych przez komitenta, uzyskana korzyść należy się komitentowi.

***
## Art. 768. {#art-768}

§ 1. Jeżeli komisant sprzedał oddaną mu do sprzedaży rzecz za cenę 
niższą od ceny oznaczonej przez komitenta, obowiązany jest zapłacić komitentowi 
różnicę. 
§ 2. Jeżeli komisant nabył rzecz za cenę wyższą od ceny oznaczonej przez 
komitenta, komitent może niezwłocznie po otrzymaniu zawiadomienia o wykonaniu 
zlecenia oświadczyć, że nie uznaje czynności za dokonaną na jego rachunek; brak 
takiego oświadczenia jest jednoznaczny z wyrażeniem zgody na wyższą cenę. 
§ 3. Komitent nie może żądać zapłacenia różnicy ceny ani odmówić zgody na 
wyższą cenę, jeżeli zlecenie nie mogło być wykonane po cenie oznaczonej, a zawarcie 
umowy uchroniło komitenta od szkody.

***
## Art. 769. {#art-769}

§ 1. Jeżeli rzecz jest narażona na zepsucie, a nie można czekać na 
zarządzenie komitenta, komisant jest uprawniony, a gdy tego interes komitenta 
wymaga – zobowiązany sprzedać rzecz z zachowaniem należytej staranności. 
O dokonaniu sprzedaży obowiązany jest zawiadomić niezwłocznie komitenta. 

©Kancelaria Sejmu 
 
 
 
s. 169/242 
 
   
 
2025-09-09 
 
§ 2. Jeżeli komitent dopuścił się zwłoki z odebraniem rzeczy, stosuje się 
odpowiednio przepisy o skutkach zwłoki kupującego z odebraniem rzeczy sprzedanej.

***
## Art. 770. {#art-770}

§ 1. Komisant nie ponosi odpowiedzialności za ukryte wady fizyczne 
rzeczy, jak również za jej wady prawne, jeżeli przed zawarciem umowy podał to do 
wiadomości kupującego. Jednakże wyłączenie odpowiedzialności nie dotyczy wad 
rzeczy, o których komisant wiedział lub z łatwością mógł się dowiedzieć. 
§ 2. Przepisu § 1 nie stosuje się, jeżeli kupującym jest konsument.

***
## Art. 7701. {#art-7701}

(uchylony)

***
## Art. 771. {#art-771}

Komisant, który bez upoważnienia komitenta udzielił osobie trzeciej 
kredytu lub zaliczki, działa na własne niebezpieczeństwo.

***
## Art. 772. {#art-772}

§ 1. Komisant nabywa roszczenie o zapłatę prowizji z chwilą, gdy 
komitent otrzymał rzecz albo cenę. Jeżeli umowa ma być wykonywana częściami, 
komisant nabywa roszczenie o prowizję w miarę wykonywania umowy. 
§ 2. Komisant może żądać prowizji także wtedy, gdy umowa nie została 
wykonana z przyczyn dotyczących komitenta.

***
## Art. 773. {#art-773}

§ 1. Dla zabezpieczenia roszczeń o prowizję oraz roszczeń o zwrot 
wydatków i zaliczek udzielonych komitentowi, jak również dla zabezpieczenia 
wszelkich innych należności wynikłych ze zleceń komisowych przysługuje 
komisantowi ustawowe prawo zastawu na rzeczach stanowiących przedmiot komisu, 
dopóki rzeczy te znajdują się u niego lub u osoby która je dzierży w jego imieniu, albo 
dopóki może nimi rozporządzać za pomocą dokumentów. 
§ 2. Wymienione należności mogą być zaspokojone z wierzytelności nabytych 
przez komisanta na rachunek komitenta, z pierwszeństwem przed wierzycielami 
komitenta. 
§ 3. (uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 170/242 
 
   
 
2025-09-09 
 
TYTUŁ XXV 
Umowa przewozu 
## DZIAŁ I. Przepisy ogólne

***
## Art. 774. {#art-774}

Przez umowę przewozu przewoźnik zobowiązuje się w zakresie 
działalności swego przedsiębiorstwa do przewiezienia za wynagrodzeniem osób lub 
rzeczy.

***
## Art. 775. {#art-775}

Przepisy tytułu niniejszego stosuje się do przewozu w zakresie 
poszczególnych rodzajów transportu tylko o tyle, o ile przewóz ten nie jest 
uregulowany odrębnymi przepisami. 
## DZIAŁ II. Przewóz osób

***
## Art. 776. {#art-776}

Przewoźnik 
obowiązany 
jest 
do 
zapewnienia 
podróżnym 
odpowiadających rodzajowi transportu warunków bezpieczeństwa i higieny oraz 
takich wygód, jakie ze względu na rodzaj transportu uważa się za niezbędne.

***
## Art. 777. {#art-777}

§ 1. Za bagaż, który podróżny przewozi ze sobą, przewoźnik ponosi 
odpowiedzialność tylko wtedy, gdy szkoda wynikła z winy umyślnej lub rażącego 
niedbalstwa przewoźnika. 
§ 2. Za bagaż powierzony przewoźnikowi przewoźnik ponosi odpowiedzialność 
według zasad przewidzianych dla przewozu rzeczy.

***
## Art. 778. {#art-778}

Roszczenia z umowy przewozu osób przedawniają się z upływem roku 
od dnia wykonania przewozu, a gdy przewóz nie został wykonany – od dnia, kiedy 
miał być wykonany. 
## DZIAŁ III. Przewóz rzeczy

***
## Art. 779. {#art-779}

Wysyłający powinien podać przewoźnikowi swój adres oraz adres 
odbiorcy, miejsce przeznaczenia, oznaczenie przesyłki według rodzaju, ilości oraz 
sposobu opakowania, jak również wartość rzeczy szczególnie cennych. 

©Kancelaria Sejmu 
 
 
 
s. 171/242 
 
   
 
2025-09-09

***
## Art. 780. {#art-780}

§ 1. Na żądanie przewoźnika wysyłający powinien wystawić list 
przewozowy zawierający dane wymienione w artykule poprzedzającym, a ponadto 
wszelkie inne istotne postanowienia umowy. Wysyłający ponosi skutki niedokładnego 
lub nieprawdziwego oświadczenia. 
§ 2. Wysyłający może żądać od przewoźnika wydania mu odpisu listu 
przewozowego albo innego poświadczenia przyjęcia przesyłki do przewozu.

***
## Art. 781. {#art-781}

§ 1. Jeżeli stan zewnętrzny przesyłki lub jej opakowanie nie są 
odpowiednie dla danego rodzaju przewozu, przewoźnik może żądać, aby wysyłający 
złożył pisemne oświadczenie co do stanu przesyłki, a w wypadku rażących braków 
odmówić przewozu. 
§ 2. Jeżeli przewoźnik przyjmie przesyłkę bez zastrzeżeń, domniemywa się, że 
znajdowała się w należytym stanie.

***
## Art. 782. {#art-782}

Wysyłający powinien dać przewoźnikowi wszelkie dokumenty 
potrzebne ze względu na przepisy celne, podatkowe i administracyjne.

***
## Art. 783. {#art-783}

Jeżeli rozpoczęcie lub dokonanie przewozu dozna czasowej 
przeszkody wskutek okoliczności dotyczącej przewoźnika, wysyłający może od 
umowy odstąpić, powinien jednak dać przewoźnikowi odpowiednie wynagrodzenie 
za dokonaną część przewozu w granicach tego, co na kosztach przewozu oszczędził. 
Nie wyłącza to roszczenia o naprawienie szkody, jeżeli przeszkoda była następstwem 
okoliczności, za które przewoźnik ponosi odpowiedzialność.

***
## Art. 784. {#art-784}

Przewoźnik powinien zawiadomić niezwłocznie odbiorcę o nadejściu 
przesyłki do miejsca przeznaczenia.

***
## Art. 785. {#art-785}

Po nadejściu przesyłki do miejsca przeznaczenia odbiorca może 
w imieniu własnym wykonać wszelkie prawa wynikające z umowy przewozu, 
w szczególności może żądać wydania przesyłki i listu przewozowego, jeżeli jedno-
cześnie wykona zobowiązania wynikające z tej umowy.

***
## Art. 786. {#art-786}

Przez przyjęcie przesyłki i listu przewozowego odbiorca zobowiązuje 
się do zapłaty oznaczonych w liście przewozowym należności przewoźnika.

***
## Art. 787. {#art-787}

§ 1. Jeżeli odbiorca odmawia przyjęcia przesyłki albo jeżeli z innych 
przyczyn nie można mu jej doręczyć, przewoźnik powinien niezwłocznie zawiadomić 
o tym wysyłającego. Jeżeli wysyłający nie nadeśle w odpowiednim czasie 

©Kancelaria Sejmu 
 
 
 
s. 172/242 
 
   
 
2025-09-09 
 
wskazówek, przewoźnik powinien oddać przesyłkę na przechowanie lub inaczej ją 
zabezpieczyć, zawiadamiając o tym wysyłającego i odbiorcę. 
§ 2. Jeżeli przesyłka jest narażona na zepsucie albo jeżeli jej przechowanie 
wymaga kosztów, na które nie ma pokrycia, przewoźnik może ją sprzedać przy 
odpowiednim zastosowaniu przepisów o skutkach zwłoki kupującego z odebraniem 
rzeczy sprzedanej.

***
## Art. 788. {#art-788}

§ 1. Odszkodowanie za utratę, ubytek lub uszkodzenie przesyłki 
w czasie od jej przyjęcia do przewozu aż do wydania odbiorcy nie może przewyższać 
zwykłej wartości przesyłki, chyba że szkoda wynikła z winy umyślnej lub rażącego 
niedbalstwa przewoźnika. 
§ 2. Przewoźnik nie ponosi odpowiedzialności za ubytek nieprzekraczający 
granic ustalonych we właściwych przepisach, a w braku takich przepisów – granic 
zwyczajowo przyjętych (ubytek naturalny). 
§ 3. Za utratę, ubytek lub uszkodzenie pieniędzy, kosztowności, papierów 
wartościowych albo rzeczy szczególnie cennych przewoźnik ponosi odpowiedzialność 
jedynie wtedy, gdy właściwości przesyłki były podane przy zawarciu umowy, chyba 
że szkoda wynikła z winy umyślnej lub rażącego niedbalstwa przewoźnika.

***
## Art. 789. {#art-789}

§ 1. Przewoźnik może oddać przesyłkę do przewozu innemu 
przewoźnikowi na całą przestrzeń przewozu lub jej część, jednakże ponosi 
odpowiedzialność za czynności dalszych przewoźników jak za swoje własne 
czynności. 
§ 2. Każdy przewoźnik, który przyjmuje przesyłkę na podstawie tego samego 
listu przewozowego, ponosi solidarną odpowiedzialność za cały przewóz według 
treści listu. 
§ 3. Przewoźnik, który z tytułu swej solidarnej odpowiedzialności za cały 
przewóz zapłacił odszkodowanie, ma zwrotne roszczenie do przewoźnika 
ponoszącego odpowiedzialność za okoliczności, z których szkoda wynikła. Jeżeli 
okoliczności tych ustalić nie można, odpowiedzialność ponoszą wszyscy przewoźnicy 
w stosunku do przypadającego im przewoźnego. Wolny od odpowiedzialności jest 
przewoźnik, który udowodni, że szkoda nie powstała na przestrzeni, przez którą 
przewoził. 

©Kancelaria Sejmu 
 
 
 
s. 173/242 
 
   
 
2025-09-09

***
## Art. 790. {#art-790}

§ 1. Dla zabezpieczenia roszczeń wynikających z umowy przewozu, 
w szczególności: przewoźnego, składowego, opłat celnych i innych wydatków, jak 
również dla zabezpieczenia takich roszczeń przysługujących poprzednim spedytorom 
i przewoźnikom, przysługuje przewoźnikowi ustawowe prawo zastawu na przesyłce, 
dopóki przesyłka znajduje się u niego lub u osoby, która ją dzierży w jego imieniu, 
albo dopóki może nią rozporządzać za pomocą dokumentów. 
§ 2. (uchylony)

***
## Art. 791. {#art-791}

§ 1. Wskutek zapłaty należności przewoźnika i przyjęcia przesyłki bez 
zastrzeżeń wygasają wszelkie roszczenia przeciwko przewoźnikowi wynikające 
z umowy przewozu. Nie dotyczy to jednak roszczeń z tytułu niewidocznych 
uszkodzeń przesyłki, jeżeli odbiorca w ciągu tygodnia od chwili przyjęcia przesyłki 
zawiadomił o nich przewoźnika. 
§ 2. Przepisu powyższego nie stosuje się, gdy szkoda wynikła z winy umyślnej 
lub rażącego niedbalstwa przewoźnika.

***
## Art. 792. {#art-792}

Roszczenia z umowy przewozu rzeczy przedawniają się z upływem 
roku od dnia dostarczenia przesyłki, a w razie całkowitej utraty przesyłki lub jej 
dostarczenia z opóźnieniem – od dnia, kiedy przesyłka miała być dostarczona.

***
## Art. 793. {#art-793}

Roszczenia 
przysługujące 
przewoźnikowi 
przeciwko 
innym 
przewoźnikom, którzy uczestniczyli w przewozie przesyłki, przedawniają się 
z upływem sześciu miesięcy od dnia, w którym przewoźnik naprawił szkodę, albo od 
dnia, w którym wytoczono przeciwko niemu powództwo. 
TYTUŁ XXVI 
Umowa spedycji

***
## Art. 794. {#art-794}

§ 1. Przez 
umowę 
spedycji 
spedytor 
zobowiązuje 
się 
za 
wynagrodzeniem w zakresie działalności swego przedsiębiorstwa do wysyłania lub 
odbioru przesyłki albo do dokonania innych usług związanych z jej przewozem. 
§ 2. Spedytor może występować w imieniu własnym albo w imieniu dającego 
zlecenie.

***
## Art. 795. {#art-795}

Przepisy niniejszego tytułu stosuje się do spedycji tylko o tyle, o ile nie 
jest ona uregulowana odrębnymi przepisami. 

©Kancelaria Sejmu 
 
 
 
s. 174/242 
 
   
 
2025-09-09

***
## Art. 796. {#art-796}

Jeżeli przepisy tytułu niniejszego albo przepisy szczególne nie 
stanowią inaczej, do umowy spedycji stosuje się odpowiednio przepisy o umowie 
zlecenia.

***
## Art. 797. {#art-797}

Spedytor obowiązany jest do podejmowania czynności potrzebnych do 
uzyskania zwrotu nienależnie pobranych sum z tytułu przewoźnego, cła i innych 
należności związanych z przewozem przesyłki.

***
## Art. 798. {#art-798}

Spedytor obowiązany jest do podjęcia czynności potrzebnych do 
zabezpieczenia praw dającego zlecenie lub osoby przez niego wskazanej względem 
przewoźnika albo innego spedytora.

***
## Art. 799. {#art-799}

Spedytor 
jest 
odpowiedzialny 
za 
przewoźników 
i dalszych 
spedytorów, którymi posługuje się przy wykonaniu zlecenia, chyba że nie ponosi winy 
w wyborze.

***
## Art. 800. {#art-800}

Spedytor może sam dokonać przewozu. W tym wypadku spedytor ma 
jednocześnie prawa i obowiązki przewoźnika.

***
## Art. 801. {#art-801}

§ 1. Odszkodowanie za utratę, ubytek lub uszkodzenie przesyłki 
w czasie od jej przyjęcia aż do wydania przewoźnikowi, dalszemu spedytorowi, 
dającemu zlecenie lub osobie przez niego wskazanej, nie może przewyższać zwykłej 
wartości przesyłki, chyba że szkoda wynikła z winy umyślnej lub rażącego 
niedbalstwa spedytora. 
§ 2. Spedytor nie ponosi odpowiedzialności za ubytek nieprzekraczający granic 
ustalonych we właściwych przepisach, a w braku takich przepisów – granic 
zwyczajowo przyjętych. 
§ 3. Za utratę, ubytek lub uszkodzenie pieniędzy, kosztowności, papierów 
wartościowych albo rzeczy szczególnie cennych spedytor ponosi odpowiedzialność 
jedynie wtedy, gdy właściwości przesyłki były podane przy zawarciu umowy, chyba 
że szkoda wynikła z winy umyślnej lub rażącego niedbalstwa spedytora.

***
## Art. 802. {#art-802}

§ 1. Dla zabezpieczenia roszczeń o przewoźne oraz roszczeń 
o prowizję, o zwrot wydatków i innych należności wynikłych ze zleceń spedycyjnych, 
jak również dla zabezpieczenia takich roszczeń przysługujących poprzednim 
spedytorom i przewoźnikom, przysługuje spedytorowi ustawowe prawo zastawu na 

©Kancelaria Sejmu 
 
 
 
s. 175/242 
 
   
 
2025-09-09 
 
przesyłce, dopóki przesyłka znajduje się u niego lub u osoby, która ją dzierży w jego 
imieniu, albo dopóki może nią rozporządzać za pomocą dokumentów. 
§ 2. (uchylony)

***
## Art. 803. {#art-803}

§ 1. Roszczenia z umowy spedycji przedawniają się z upływem roku. 
§ 2. Termin przedawnienia zaczyna biec: w wypadku roszczeń z tytułu 
uszkodzenia lub ubytku przesyłki – od dnia dostarczenia przesyłki; w wypadku 
całkowitej utraty przesyłki lub jej dostarczenia z opóźnieniem – od dnia, w którym 
przesyłka miała być dostarczona; we wszystkich innych wypadkach – od dnia 
wykonania zlecenia.

***
## Art. 804. {#art-804}

Roszczenia przysługujące spedytorowi przeciwko przewoźnikom 
i dalszym spedytorom, którymi się posługiwał przy przewozie przesyłki, przedawniają 
się z upływem sześciu miesięcy od dnia, kiedy spedytor naprawił szkodę, albo od dnia, 
kiedy wytoczono przeciwko niemu powództwo. Przepis ten stosuje się odpowiednio 
do wymienionych roszczeń między osobami, którymi spedytor posługiwał się przy 
przewozie przesyłki. 
TYTUŁ XXVII 
Umowa ubezpieczenia 
## DZIAŁ I. Przepisy ogólne

***
## Art. 805. {#art-805}

§ 1. Przez umowę ubezpieczenia ubezpieczyciel zobowiązuje się, 
w zakresie działalności swego przedsiębiorstwa, spełnić określone świadczenie 
w razie zajścia przewidzianego w umowie wypadku, a ubezpieczający zobowiązuje 
się zapłacić składkę. 
§ 2. Świadczenie ubezpieczyciela polega w szczególności na zapłacie: 
- 1) przy ubezpieczeniu majątkowym – określonego odszkodowania za szkodę 
powstałą wskutek przewidzianego w umowie wypadku; 
- 2) przy ubezpieczeniu osobowym – umówionej sumy pieniężnej, renty lub innego 
świadczenia w razie zajścia przewidzianego w umowie wypadku w życiu osoby 
ubezpieczonej. 
§ 3. Do renty z umowy ubezpieczenia nie stosuje się przepisów kodeksu 
niniejszego o rencie. 

©Kancelaria Sejmu 
 
 
 
s. 176/242 
 
   
 
2025-09-09 
 
§ 4. Przepisy art. 3851–3853 stosuje się odpowiednio, jeżeli ubezpieczającym jest 
osoba fizyczna zawierająca umowę związaną bezpośrednio z jej działalnością 
gospodarczą lub zawodową.

***
## Art. 806. {#art-806}

§ 1. 
Umowa 
ubezpieczenia 
jest 
nieważna, 
jeżeli 
zajście 
przewidzianego w umowie wypadku nie jest możliwe. 
§ 2. Objęcie ubezpieczeniem okresu poprzedzającego zawarcie umowy jest 
bezskuteczne, jeżeli w chwili zawarcia umowy którakolwiek ze stron wiedziała lub 
przy zachowaniu należytej staranności mogła się dowiedzieć, że wypadek zaszedł lub 
że odpadła możliwość jego zajścia w tym okresie.

***
## Art. 807. {#art-807}

§ 1. Postanowienia 
ogólnych 
warunków 
ubezpieczenia 
lub 
postanowienia umowy ubezpieczenia sprzeczne z przepisami niniejszego tytułu są 
nieważne, chyba że dalsze przepisy przewidują wyjątki. 
§ 2. (uchylony)

***
## Art. 808. {#art-808}

§ 1. Ubezpieczający może zawrzeć umowę ubezpieczenia na cudzy 
rachunek. Ubezpieczony może nie być imiennie wskazany w umowie, chyba że jest to 
konieczne do określenia przedmiotu ubezpieczenia. 
§ 2. Roszczenie o zapłatę składki przysługuje ubezpieczycielowi wyłącznie 
przeciwko ubezpieczającemu. Zarzut mający wpływ na odpowiedzialność 
ubezpieczyciela może on podnieść również przeciwko ubezpieczonemu. 
§ 3. Ubezpieczony jest uprawniony do żądania należnego świadczenia 
bezpośrednio od ubezpieczyciela, chyba że strony uzgodniły inaczej; jednakże 
uzgodnienie takie nie może zostać dokonane, jeżeli wypadek już zaszedł. 
§ 4. Ubezpieczony może żądać by ubezpieczyciel udzielił mu informacji 
o postanowieniach zawartej umowy oraz ogólnych warunków ubezpieczenia 
w zakresie, w jakim dotyczą praw i obowiązków ubezpieczonego. 
§ 5. Jeżeli umowa ubezpieczenia nie wiąże się bezpośrednio z działalnością 
gospodarczą lub zawodową ubezpieczonej osoby fizycznej, art. 3851–3853 stosuje się 
odpowiednio 
w zakresie, 
w jakim 
umowa 
dotyczy 
praw 
i obowiązków 
ubezpieczonego.

***
## Art. 809. {#art-809}

§ 1. Ubezpieczyciel zobowiązany jest potwierdzić zawarcie umowy 
dokumentem ubezpieczenia. 

©Kancelaria Sejmu 
 
 
 
s. 177/242 
 
   
 
2025-09-09 
 
§ 2. Z zastrzeżeniem wyjątku przewidzianego w art. 811, w razie wątpliwości 
umowę uważa się za zawartą z chwilą doręczenia ubezpieczającemu dokumentu 
ubezpieczenia.

***
## Art. 810. {#art-810}

(uchylony)

***
## Art. 811. {#art-811}

§ 1. Jeżeli w odpowiedzi na złożoną ofertę ubezpieczyciel doręcza 
ubezpieczającemu dokument ubezpieczenia zawierający postanowienia, które 
odbiegają na niekorzyść ubezpieczającego od treści złożonej przez niego oferty, 
ubezpieczyciel obowiązany jest zwrócić ubezpieczającemu na to uwagę na piśmie przy 
doręczeniu tego dokumentu, wyznaczając mu co najmniej 7-dniowy termin do 
zgłoszenia sprzeciwu. W razie niewykonania tego obowiązku zmiany dokonane na 
niekorzyść ubezpieczającego nie są skuteczne, a umowa jest zawarta zgodnie 
z warunkami oferty. 
§ 2. W braku sprzeciwu umowa dochodzi do skutku zgodnie z treścią dokumentu 
ubezpieczenia następnego dnia po upływie terminu wyznaczonego do złożenia 
sprzeciwu.

***
## Art. 812. {#art-812}

§ 1. (uchylony) 
§ 2. (uchylony) 
§ 3. (uchylony) 
§ 4. Jeżeli umowa ubezpieczenia jest zawarta na okres dłuższy niż 6 miesięcy, 
ubezpieczający ma prawo odstąpienia od umowy ubezpieczenia w terminie 30 dni, 
a w przypadku gdy ubezpieczający jest przedsiębiorcą – w terminie 7 dni od dnia 
zawarcia umowy. Jeżeli najpóźniej w chwili zawarcia umowy ubezpieczyciel nie 
poinformował ubezpieczającego będącego konsumentem o prawie odstąpienia od 
umowy, termin 30 dni biegnie od dnia, w którym ubezpieczający będący 
konsumentem dowiedział się o tym prawie. Odstąpienie od umowy ubezpieczenia nie 
zwalnia ubezpieczającego z obowiązku zapłacenia składki za okres, w jakim 
ubezpieczyciel udzielał ochrony ubezpieczeniowej. 
§ 5. Jeżeli umowa zawarta jest na czas określony, ubezpieczyciel może ją 
wypowiedzieć jedynie w przypadkach wskazanych w ustawie, a także z ważnych 
powodów określonych w umowie lub ogólnych warunkach ubezpieczenia. 
§ 6. (uchylony) 
§ 7. (uchylony) 

©Kancelaria Sejmu 
 
 
 
s. 178/242 
 
   
 
2025-09-09 
 
§ 8. Różnicę między treścią umowy a ogólnymi warunkami ubezpieczenia 
ubezpieczyciel zobowiązany jest przedstawić ubezpieczającemu w formie pisemnej 
przed zawarciem umowy. W razie niedopełnienia tego obowiązku ubezpieczyciel nie 
może powoływać się na różnicę niekorzystną dla ubezpieczającego. Przepisu nie 
stosuje się do umów ubezpieczenia zawieranych w drodze negocjacji. 
§ 9. Przepisy § 5 i 8 stosuje się odpowiednio w razie zmiany ogólnych 
warunków ubezpieczenia w czasie trwania stosunku umownego. Nie uchybia to 
stosowaniu w takim przypadku przepisu art. 3841.

***
## Art. 813. {#art-813}

§ 1. Składkę oblicza się za czas trwania odpowiedzialności 
ubezpieczyciela. W przypadku wygaśnięcia stosunku ubezpieczenia przed upływem 
okresu na jaki została zawarta umowa, ubezpieczającemu przysługuje zwrot składki 
za okres niewykorzystanej ochrony ubezpieczeniowej. 
§ 2. Jeżeli nie umówiono się inaczej, składka powinna być zapłacona 
jednocześnie z zawarciem umowy ubezpieczenia, a jeżeli umowa doszła do skutku 
przed doręczeniem dokumentu ubezpieczenia – w ciągu czternastu dni od jego 
doręczenia.

***
## Art. 814. {#art-814}

§ 1. 
Jeżeli 
nie 
umówiono 
się 
inaczej, 
odpowiedzialność 
ubezpieczyciela rozpoczyna się od dnia następującego po zawarciu umowy, nie 
wcześniej jednak niż od dnia następnego po zapłaceniu składki lub jej pierwszej raty. 
§ 2. Jeżeli ubezpieczyciel ponosi odpowiedzialność jeszcze przed zapłaceniem 
składki lub jej pierwszej raty, a składka lub jej pierwsza rata nie została zapłacona 
w terminie, 
ubezpieczyciel 
może 
wypowiedzieć 
umowę 
ze 
skutkiem 
natychmiastowym i żądać zapłaty składki za okres, przez który ponosił 
odpowiedzialność. W braku wypowiedzenia umowy wygasa ona z końcem okresu, za 
który przypadała niezapłacona składka. 
§ 3. W razie opłacania składki w ratach niezapłacenie w terminie kolejnej raty 
składki może powodować ustanie odpowiedzialności ubezpieczyciela, tylko wtedy, 
gdy skutek taki przewidywała umowa lub ogólne warunki ubezpieczenia, 
a ubezpieczyciel po upływie terminu wezwał ubezpieczającego do zapłaty 
z zagrożeniem, że brak zapłaty w terminie 7 dni od dnia otrzymania wezwania 
spowoduje ustanie odpowiedzialności. 

©Kancelaria Sejmu 
 
 
 
s. 179/242 
 
   
 
2025-09-09

***
## Art. 815. {#art-815}

§ 1. Ubezpieczający obowiązany jest podać do wiadomości 
ubezpieczyciela wszystkie znane sobie okoliczności, o które ubezpieczyciel zapytywał 
w formularzu oferty albo przed zawarciem umowy w innych pismach. Jeżeli 
ubezpieczający zawiera umowę przez przedstawiciela, obowiązek ten ciąży również 
na przedstawicielu i obejmuje ponadto okoliczności jemu znane. W razie zawarcia 
przez ubezpieczyciela umowy ubezpieczenia mimo braku odpowiedzi na 
poszczególne pytania, pominięte okoliczności uważa się za nieistotne. 
§ 2. Jeżeli w umowie ubezpieczenia zastrzeżono, że w czasie jej trwania należy 
zgłaszać zmiany okoliczności wymienionych w paragrafie poprzedzającym, 
ubezpieczający obowiązany jest zawiadamiać o tych zmianach ubezpieczyciela 
niezwłocznie po otrzymaniu o nich wiadomości. Przepisu tego nie stosuje się do 
ubezpieczeń na życie. 
§ 21. W razie zawarcia umowy ubezpieczenia na cudzy rachunek obowiązki 
określone w paragrafach poprzedzających spoczywają zarówno na ubezpieczającym, 
jak i na ubezpieczonym, chyba że ubezpieczony nie wiedział o zawarciu umowy na 
jego rachunek. 
§ 3. Ubezpieczyciel nie ponosi odpowiedzialności za skutki okoliczności, które 
z naruszeniem paragrafów poprzedzających nie zostały podane do jego wiadomości. 
Jeżeli do naruszenia paragrafów poprzedzających doszło z winy umyślnej, w razie 
wątpliwości przyjmuje się, że wypadek przewidziany umową i jego następstwa są 
skutkiem okoliczności, o których mowa w zdaniu poprzedzającym.

***
## Art. 816. {#art-816}

W razie ujawnienia okoliczności, która pociąga za sobą istotną zmianę 
prawdopodobieństwa wypadku, każda ze stron może żądać odpowiedniej zmiany 
wysokości składki, poczynając od chwili, w której zaszła ta okoliczność, nie wcześniej 
jednak niż od początku bieżącego okresu ubezpieczenia. W razie zgłoszenia takiego 
żądania druga strona może w terminie 14 dni wypowiedzieć umowę ze skutkiem 
natychmiastowym. Przepisu tego nie stosuje się do ubezpieczeń na życie.

***
## Art. 817. {#art-817}

§ 1. Ubezpieczyciel obowiązany jest spełnić świadczenie w terminie 
trzydziestu dni, licząc od daty otrzymania zawiadomienia o wypadku. 
§ 2. Gdyby wyjaśnienie w powyższym terminie okoliczności koniecznych do 
ustalenia odpowiedzialności ubezpieczyciela albo wysokości świadczenia okazało się 
niemożliwe, świadczenie powinno być spełnione w ciągu 14 dni od dnia, w którym 

©Kancelaria Sejmu 
 
 
 
s. 180/242 
 
   
 
2025-09-09 
 
przy zachowaniu należytej staranności wyjaśnienie tych okoliczności było możliwe. 
Jednakże bezsporną część świadczenia ubezpieczyciel powinien spełnić w terminie 
przewidzianym w § 1. 
§ 3. Umowa ubezpieczenia lub ogólne warunki ubezpieczenia mogą zawierać 
postanowienia korzystniejsze dla uprawnionego niż określone w paragrafach 
poprzedzających.

***
## Art. 818. {#art-818}

§ 1. Umowa ubezpieczenia lub ogólne warunki ubezpieczenia mogą 
przewidywać, że ubezpieczający ma obowiązek w określonym terminie powiadomić 
ubezpieczyciela o wypadku. 
§ 2. W razie zawarcia umowy ubezpieczenia na cudzy rachunek obowiązkiem 
określonym 
w paragrafie 
poprzedzającym 
można 
obciążyć 
zarówno 
ubezpieczającego, jak i ubezpieczonego, chyba że ubezpieczony nie wie o zawarciu 
umowy na jego rachunek. 
§ 3. W razie naruszenia z winy umyślnej lub rażącego niedbalstwa obowiązków 
określonych w paragrafach poprzedzających ubezpieczyciel może odpowiednio 
zmniejszyć świadczenie, jeżeli naruszenie przyczyniło się do zwiększenia szkody lub 
uniemożliwiło ubezpieczycielowi ustalenie okoliczności i skutków wypadku. 
§ 4. Skutki braku zawiadomienia ubezpieczyciela o wypadku nie następują, 
jeżeli ubezpieczyciel w terminie wyznaczonym do zawiadomienia otrzymał 
wiadomość o okolicznościach, które należało podać do jego wiadomości.

***
## Art. 819. {#art-819}

§ 1. Roszczenia z umowy ubezpieczenia przedawniają się z upływem 
lat trzech. 
§ 2. (uchylony) 
§ 3. W wypadku 
ubezpieczenia 
odpowiedzialności 
cywilnej 
roszczenie 
poszkodowanego do ubezpieczyciela o odszkodowanie lub zadośćuczynienie 
przedawnia się z upływem terminu przewidzianego dla tego roszczenia w przepisach 
o odpowiedzialności za szkodę wyrządzoną czynem niedozwolonym lub wynikłą 
z niewykonania bądź nienależytego wykonania zobowiązania. 
§ 4. Bieg przedawnienia roszczenia o świadczenie do ubezpieczyciela przerywa 
się także przez zgłoszenie ubezpieczycielowi tego roszczenia lub przez zgłoszenie 
zdarzenia objętego ubezpieczeniem. Bieg przedawnienia rozpoczyna się na nowo od 

©Kancelaria Sejmu 
 
 
 
s. 181/242 
 
   
 
2025-09-09 
 
dnia, w którym zgłaszający roszczenie lub zdarzenie otrzymał na piśmie oświadczenie 
ubezpieczyciela o przyznaniu lub odmowie świadczenia.

***
## Art. 820. {#art-820}

Przepisów tytułu niniejszego nie stosuje się do ubezpieczeń morskich 
oraz do ubezpieczeń pośrednich (reasekuracji). 
## DZIAŁ II. Ubezpieczenia majątkowe

***
## Art. 821. {#art-821}

Przedmiotem ubezpieczenia majątkowego może być każdy interes 
majątkowy, który nie jest sprzeczny z prawem i daje się ocenić w pieniądzu.

***
## Art. 822. {#art-822}

§ 1. Przez umowę ubezpieczenia odpowiedzialności cywilnej 
ubezpieczyciel zobowiązuje się do zapłacenia określonego w umowie odszkodowania 
za szkody wyrządzone osobom trzecim, wobec których odpowiedzialność za szkodę 
ponosi ubezpieczający albo ubezpieczony. 
§ 2. Jeżeli 
strony 
nie 
umówiły 
się 
inaczej, 
umowa 
ubezpieczenia 
odpowiedzialności cywilnej obejmuje szkody, o jakich mowa w § 1, będące 
następstwem przewidzianego w umowie zdarzenia, które miało miejsce w okresie 
ubezpieczenia. 
§ 3. Strony mogą postanowić, że umowa będzie obejmować szkody powstałe, 
ujawnione lub zgłoszone w okresie ubezpieczenia. 
§ 4. Uprawniony do odszkodowania w związku ze zdarzeniem objętym umową 
ubezpieczenia odpowiedzialności cywilnej może dochodzić roszczenia bezpośrednio 
od ubezpieczyciela. 
§ 5. Ubezpieczyciel nie może przeciwko uprawnionemu do odszkodowania 
podnieść zarzutu naruszenia obowiązków wynikających z umowy lub ogólnych 
warunków ubezpieczenia przez ubezpieczającego lub ubezpieczonego, jeżeli nastąpiło 
ono po zajściu wypadku.

***
## Art. 823. {#art-823}

§ 1. W razie zbycia przedmiotu ubezpieczenia prawa z umowy 
ubezpieczenia mogą być przeniesione na nabywcę przedmiotu ubezpieczenia. 
Przeniesienie tych praw wymaga zgody ubezpieczyciela, chyba że umowa ubezpie-
czenia lub ogólne warunki ubezpieczenia stanowią inaczej. 
§ 2. W razie przeniesienia praw, o których mowa w § 1, na nabywcę przedmiotu 
przechodzą także obowiązki, które ciążyły na zbywcy, chyba że strony za zgodą 

©Kancelaria Sejmu 
 
 
 
s. 182/242 
 
   
 
2025-09-09 
 
ubezpieczyciela umówiły się inaczej. Pomimo tego przejścia obowiązków zbywca 
odpowiada solidarnie z nabywcą za zapłatę składki przypadającej za czas do chwili 
przejścia przedmiotu ubezpieczenia na nabywcę. 
§ 3. Jeżeli prawa, o których mowa w § 1, nie zostały przeniesione na nabywcę 
przedmiotu ubezpieczenia, stosunek ubezpieczenia wygasa z chwilą przejścia 
przedmiotu ubezpieczenia na nabywcę. 
§ 4. Przepisów § 1–3 nie stosuje się przy przenoszeniu wierzytelności, jakie 
powstały lub mogą powstać wskutek zajścia przewidzianego w umowie wypadku.

***
## Art. 824. {#art-824}

§ 1. Jeżeli nie umówiono się inaczej, suma ubezpieczenia ustalona 
w umowie stanowi górną granicę odpowiedzialności ubezpieczyciela. 
§ 2. Jeżeli po zawarciu umowy wartość ubezpieczonego mienia uległa 
zmniejszeniu, ubezpieczający może żądać odpowiedniego zmniejszenia sumy 
ubezpieczenia. Zmniejszenia sumy ubezpieczenia może także z tej samej przyczyny 
dokonać 
jednostronnie 
ubezpieczyciel, 
zawiadamiając 
o tym 
jednocześnie 
ubezpieczającego. 
§ 3. Zmniejszenie sumy ubezpieczenia pociąga za sobą odpowiednie 
zmniejszenie składki począwszy od dnia pierwszego tego miesiąca, w którym 
ubezpieczający 
zażądał 
zmniejszenia 
sumy 
ubezpieczenia 
lub 
w którym 
ubezpieczyciel zawiadomił ubezpieczającego o jednostronnym zmniejszeniu tej sumy.

***
## Art. 8241. {#art-8241}

§ 1. O ile nie umówiono się inaczej, suma pieniężna wypłacona przez 
ubezpieczyciela z tytułu ubezpieczenia nie może być wyższa od poniesionej szkody. 
§ 2. Jeżeli ten sam przedmiot ubezpieczenia w tym samym czasie jest 
ubezpieczony od tego samego ryzyka u dwóch lub więcej ubezpieczycieli na sumy, 
które łącznie przewyższają jego wartość ubezpieczeniową, ubezpieczający nie może 
żądać świadczenia przenoszącego wysokość szkody. Między ubezpieczycielami 
każdy z nich odpowiada w takim stosunku, w jakim przyjęta przez niego suma 
ubezpieczenia pozostaje do łącznych sum wynikających z podwójnego lub 
wielokrotnego ubezpieczenia. 
§ 3. Jeżeli w którejkolwiek z umów ubezpieczenia, o jakich mowa w § 2, 
uzgodniono, że suma wypłacona przez ubezpieczyciela z tytułu ubezpieczenia może 
być wyższa od poniesionej szkody, zapłaty świadczenia w części przenoszącej wyso-
kość szkody ubezpieczający może żądać tylko od tego ubezpieczyciela. W takim 

©Kancelaria Sejmu 
 
 
 
s. 183/242 
 
   
 
2025-09-09 
 
przypadku dla określenia odpowiedzialności między ubezpieczycielami należy 
przyjąć, że w ubezpieczeniu, o którym mowa w niniejszym paragrafie, suma 
ubezpieczenia równa jest wartości ubezpieczeniowej.

***
## Art. 825. {#art-825}

(uchylony)

***
## Art. 826. {#art-826}

§ 1. W razie zajścia wypadku ubezpieczający obowiązany jest użyć 
dostępnych mu środków w celu ratowania przedmiotu ubezpieczenia oraz 
zapobieżenia szkodzie lub zmniejszenia jej rozmiarów. 
§ 2. Umowa 
ubezpieczenia 
lub 
ogólne 
warunki 
ubezpieczenia 
mogą 
przewidywać, że w razie zajścia wypadku ubezpieczający obowiązany jest 
zabezpieczyć możność dochodzenia roszczeń odszkodowawczych wobec osób 
odpowiedzialnych za szkodę. 
§ 3. Jeżeli ubezpieczający umyślnie lub wskutek rażącego niedbalstwa nie 
zastosował 
środków 
określonych 
w § 1, 
ubezpieczyciel 
jest 
wolny 
od 
odpowiedzialności za szkody powstałe z tego powodu. 
§ 4. Ubezpieczyciel obowiązany jest, w granicach sumy ubezpieczenia, zwrócić 
koszty wynikłe z zastosowania środków, o których mowa w § 1, jeżeli środki te były 
celowe, chociażby okazały się bezskuteczne. Umowa lub ogólne warunki 
ubezpieczenia mogą zawierać postanowienia korzystniejsze dla ubezpieczającego. 
§ 5. W razie 
ubezpieczenia 
na 
cudzy 
rachunek 
przepisy 
paragrafów 
poprzedzających stosuje się również do ubezpieczonego.

***
## Art. 827. {#art-827}

§ 1. Ubezpieczyciel 
jest 
wolny 
od 
odpowiedzialności, 
jeżeli 
ubezpieczający wyrządził szkodę umyślnie; w razie rażącego niedbalstwa 
odszkodowanie nie należy się, chyba że umowa lub ogólne warunki ubezpieczenia 
stanowią inaczej lub zapłata odszkodowania odpowiada w danych okolicznościach 
względom słuszności. 
§ 2. W ubezpieczeniu odpowiedzialności cywilnej można ustalić inne zasady 
odpowiedzialności ubezpieczyciela niż określone w § 1. 
§ 3. Jeżeli 
nie 
umówiono 
się 
inaczej, 
ubezpieczyciel 
nie 
ponosi 
odpowiedzialności za szkodę wyrządzoną umyślnie przez osobę, z którą 
ubezpieczający pozostaje we wspólnym gospodarstwie domowym. 

©Kancelaria Sejmu 
 
 
 
s. 184/242 
 
   
 
2025-09-09 
 
§ 4. W razie zawarcia umowy ubezpieczenia na cudzy rachunek zasady 
określone 
w paragrafach 
poprzedzających 
stosuje 
się 
odpowiednio 
do 
ubezpieczonego.

***
## Art. 828. {#art-828}

§ 1. Jeżeli nie umówiono się inaczej, z dniem zapłaty odszkodowania 
przez ubezpieczyciela roszczenie ubezpieczającego przeciwko osobie trzeciej 
odpowiedzialnej za szkodę przechodzi z mocy prawa na ubezpieczyciela do 
wysokości zapłaconego odszkodowania. Jeżeli zakład pokrył tylko część szkody, 
ubezpieczającemu przysługuje co do pozostałej części pierwszeństwo zaspokojenia 
przed roszczeniem ubezpieczyciela. 
§ 2. Nie przechodzą na ubezpieczyciela roszczenia ubezpieczającego przeciwko 
osobom, z którymi ubezpieczający pozostaje we wspólnym gospodarstwie domowym, 
chyba że sprawca wyrządził szkodę umyślnie. 
§ 3. Zasady wynikające z paragrafów poprzedzających stosuje się odpowiednio 
w razie zawarcia umowy na cudzy rachunek. 
## DZIAŁ III. Ubezpieczenia osobowe

***
## Art. 829. {#art-829}

§ 1. Ubezpieczenie osobowe może w szczególności dotyczyć: 
- 1) przy ubezpieczeniu na życie – śmierci osoby ubezpieczonej lub dożycia przez nią 
oznaczonego wieku; 
- 2) przy ubezpieczeniu następstw nieszczęśliwych wypadków – uszkodzenia ciała, 
rozstroju zdrowia lub śmierci wskutek nieszczęśliwego wypadku. 
§ 2. W umowie ubezpieczenia na życie zawartej na cudzy rachunek, 
odpowiedzialność ubezpieczyciela rozpoczyna się nie wcześniej niż następnego dnia 
po tym, gdy ubezpieczony oświadczył stronie wskazanej w umowie, że chce 
skorzystać z zastrzeżenia na jego rzecz ochrony ubezpieczeniowej. Oświadczenie 
powinno obejmować także wysokość sumy ubezpieczenia. Zmiana umowy na 
niekorzyść ubezpieczonego lub osoby uprawnionej do otrzymania sumy 
ubezpieczenia w razie śmierci ubezpieczonego wymaga zgody tego ubezpieczonego.

***
## Art. 830. {#art-830}

§ 1. 
Przy 
ubezpieczeniu 
osobowym 
ubezpieczający 
może 
wypowiedzieć umowę w każdym czasie z zachowaniem terminu określonego 
w umowie lub ogólnych warunkach ubezpieczenia, a w razie jego braku – ze skutkiem 
natychmiastowym. 

©Kancelaria Sejmu 
 
 
 
s. 185/242 
 
   
 
2025-09-09 
 
§ 2. W braku odmiennego zastrzeżenia umowę uważa się za wypowiedzianą 
przez ubezpieczającego, jeżeli składka lub jej rata nie została zapłacona w terminie 
określonym w umowie lub ogólnych warunkach ubezpieczenia mimo uprzedniego 
wezwania do zapłaty w dodatkowym terminie określonym w ogólnych warunkach 
ubezpieczenia; w wezwaniu powinny być podane do wiadomości ubezpieczającego 
skutki niezapłacenia składki. 
§ 3. Ubezpieczyciel może wypowiedzieć umowę ubezpieczenia na życie jedynie 
w wypadkach wskazanych w ustawie. 
§ 4. Przepisy § 3 oraz art. 812 § 8 stosuje się odpowiednio w razie zmiany 
ogólnych warunków ubezpieczenia na życie w czasie trwania stosunku umownego. 
Nie uchybia to stosowaniu w takim przypadku przepisu art. 3841.

***
## Art. 831. {#art-831}

§ 1. Ubezpieczający może wskazać jedną lub więcej osób 
uprawnionych do otrzymania sumy ubezpieczenia w razie śmierci osoby 
ubezpieczonej; może również zawrzeć umowę ubezpieczenia na okaziciela. 
Ubezpieczający może każde z tych zastrzeżeń zmienić lub odwołać w każdym czasie. 
§ 11. W razie zawarcia umowy ubezpieczenia na cudzy rachunek do 
wykonywania uprawnień, o których mowa w paragrafie poprzedzającym, konieczna 
jest uprzednia zgoda ubezpieczonego; umowa lub ogólne warunki ubezpieczenia mogą 
przewidywać, że uprawnienia te ubezpieczony może wykonywać samodzielnie. 
§ 2. Jeżeli wskazano kilka osób uprawnionych do otrzymania sumy 
ubezpieczenia, a nie oznaczono udziału każdej z nich w tej sumie, ich udziały są 
równe. 
§ 3. Suma ubezpieczenia przypadająca uprawnionemu nie należy do spadku po 
ubezpieczonym.

***
## Art. 832. {#art-832}

§ 1. Wskazanie uprawnionego do otrzymania sumy ubezpieczenia 
staje się bezskuteczne, jeżeli uprawniony zmarł przed śmiercią ubezpieczonego albo 
jeżeli umyślnie przyczynił się do jego śmierci. 
§ 2. Jeżeli w chwili śmierci ubezpieczonego nie ma osoby uprawnionej do 
otrzymania 
sumy 
ubezpieczenia, 
suma 
ta 
przypada 
najbliższej 
rodzinie 
ubezpieczonego w kolejności ustalonej w ogólnych warunkach ubezpieczenia, chyba 
że umówiono się inaczej. 

©Kancelaria Sejmu 
 
 
 
s. 186/242 
 
   
 
2025-09-09

***
## Art. 833. {#art-833}

Przy ubezpieczeniu na życie samobójstwo ubezpieczonego nie zwalnia 
ubezpieczyciela od obowiązku świadczenia, jeżeli samobójstwo nastąpiło po upływie 
lat dwóch od zawarcia umowy ubezpieczenia. Umowa lub ogólne warunki 
ubezpieczenia mogą skrócić ten termin, nie bardziej jednak niż do 6 miesięcy.

***
## Art. 834. {#art-834}

Jeżeli do wypadku doszło po upływie lat trzech od zawarcia umowy 
ubezpieczenia na życie, ubezpieczyciel nie może podnieść zarzutu, że przy zawieraniu 
umowy podano wiadomości nieprawdziwe, w szczególności że zatajona została 
choroba osoby ubezpieczonej. Umowa lub ogólne warunki ubezpieczenia mogą 
skrócić powyższy termin. 
TYTUŁ XXVIII 
Przechowanie

***
## Art. 835. {#art-835}

Przez umowę przechowania przechowawca zobowiązuje się zachować 
w stanie niepogorszonym rzecz ruchomą oddaną mu na przechowanie.

***
## Art. 836. {#art-836}

Jeżeli wysokość wynagrodzenia za przechowanie nie jest określona 
w umowie albo w taryfie, przechowawcy należy się wynagrodzenie w danych 
stosunkach przyjęte, chyba że z umowy lub z okoliczności wynika, iż zobowiązał się 
przechować rzecz bez wynagrodzenia.

***
## Art. 837. {#art-837}

Przechowawca powinien przechowywać rzecz w taki sposób, do 
jakiego się zobowiązał, a w braku umowy w tym względzie, w taki sposób, jaki 
wynika z właściwości przechowywanej rzeczy i z okoliczności.

***
## Art. 838. {#art-838}

Przechowawca jest uprawniony, a nawet obowiązany zmienić 
określone w umowie miejsce i sposób przechowania rzeczy, jeżeli okaże się to 
konieczne dla jej ochrony przed utratą lub uszkodzeniem. Jeżeli uprzednie uzyskanie 
zgody składającego jest możliwe, przechowawca powinien ją uzyskać przed 
dokonaniem zmiany.

***
## Art. 839. {#art-839}

Przechowawcy nie wolno używać rzeczy bez zgody składającego, 
chyba że jest to konieczne do jej zachowania w stanie niepogorszonym.

***
## Art. 840. {#art-840}

§ 1. Przechowawca nie może oddać rzeczy na przechowanie innej 
osobie, chyba że jest do tego zmuszony przez okoliczności. W wypadku takim 
obowiązany jest zawiadomić niezwłocznie składającego, gdzie i u kogo rzecz złożył, 

©Kancelaria Sejmu 
 
 
 
s. 187/242 
 
   
 
2025-09-09 
 
i w razie zawiadomienia odpowiedzialny jest tylko za brak należytej staranności 
w wyborze zastępcy. 
§ 2. Zastępca odpowiedzialny jest także względem składającego. Jeżeli 
przechowawca ponosi odpowiedzialność za czynności swego zastępcy jak za swoje 
własne czynności, ich odpowiedzialność jest solidarna.

***
## Art. 841. {#art-841}

Jeżeli przechowawca, bez zgody składającego i bez koniecznej 
potrzeby, używa rzeczy albo zmienia miejsce lub sposób jej przechowywania albo 
jeżeli oddaje rzecz na przechowanie innej osobie, jest on odpowiedzialny także za 
przypadkową utratę lub uszkodzenie rzeczy, które by w przeciwnym razie nie 
nastąpiło.

***
## Art. 842. {#art-842}

Składający powinien zwrócić przechowawcy wydatki, które ten 
poniósł w celu należytego przechowania rzeczy, wraz z odsetkami ustawowymi oraz 
zwolnić przechowawcę od zobowiązań zaciągniętych przez niego w powyższym celu 
w imieniu własnym.

***
## Art. 843. {#art-843}

Jeżeli kilka osób wspólnie przyjęło lub oddało rzecz na przechowanie, 
ich odpowiedzialność względem drugiej strony jest solidarna.

***
## Art. 844. {#art-844}

§ 1. Składający może w każdym czasie żądać zwrotu rzeczy oddanej 
na przechowanie. 
§ 2. Przechowawca może żądać odebrania rzeczy przed upływem terminu 
oznaczonego w umowie, jeżeli wskutek okoliczności, których nie mógł przewidzieć, 
nie może bez własnego uszczerbku lub bez zagrożenia rzeczy przechowywać jej w taki 
sposób, do jakiego jest zobowiązany. Jeżeli czas przechowania nie był oznaczony albo 
jeżeli rzecz była przyjęta na przechowanie bez wynagrodzenia, przechowawca może 
żądać odebrania rzeczy w każdym czasie, byleby jej zwrot nie nastąpił w chwili 
nieodpowiedniej dla składającego. 
§ 3. Zwrot 
rzeczy 
powinien 
nastąpić 
w miejscu, 
gdzie 
miała 
być 
przechowywana.

***
## Art. 845. {#art-845}

Jeżeli z przepisów szczególnych albo z umowy lub okoliczności 
wynika, że przechowawca może rozporządzać oddanymi na przechowanie pieniędzmi 
lub innymi rzeczami oznaczonymi tylko co do gatunku, stosuje się odpowiednio 
przepisy o pożyczce (depozyt nieprawidłowy). Czas i miejsce zwrotu określają 
przepisy o przechowaniu. 

©Kancelaria Sejmu 
 
 
 
s. 188/242 
 
   
 
2025-09-09 
 
TYTUŁ XXIX 
Odpowiedzialność, prawo zastawu i przedawnienie roszczeń utrzymujących 
hotele i podobne zakłady

***
## Art. 846. {#art-846}

§ 1. Utrzymujący zarobkowo hotel lub podobny zakład jest 
odpowiedzialny za utratę lub uszkodzenie rzeczy wniesionych przez osobę 
korzystającą z usług hotelu lub podobnego zakładu, zwaną dalej „gościem”, chyba że 
szkoda wynikła z właściwości rzeczy wniesionej lub wskutek siły wyższej albo że 
powstała wyłącznie z winy poszkodowanego lub osoby, która mu towarzyszyła, była 
u niego zatrudniona albo go odwiedzała. 
§ 2. Rzeczą wniesioną w rozumieniu przepisów tytułu niniejszego jest rzecz, 
która w czasie korzystania przez gościa z usług hotelu lub podobnego zakładu 
znajduje się w tym hotelu lub podobnym zakładzie albo znajduje się poza nim, 
a została powierzona utrzymującemu zarobkowo hotel lub podobny zakład lub osobie 
u niego zatrudnionej albo umieszczona w miejscu przez nich wskazanym lub na ten 
cel przeznaczonym. 
§ 3. Rzeczą wniesioną jest również rzecz, która w krótkim, zwyczajowo 
przyjętym okresie poprzedzającym lub następującym po tym, kiedy gość korzystał 
z usług hotelu lub podobnego zakładu, została powierzona utrzymującemu zarobkowo 
hotel lub podobny zakład lub osobie u niego zatrudnionej albo umieszczona w miejscu 
przez nich wskazanym lub na ten cel przeznaczonym. 
§ 4. Pojazdów mechanicznych i rzeczy w nich pozostawionych oraz żywych 
zwierząt nie uważa się za rzeczy wniesione. Utrzymujący zarobkowo hotel lub 
podobny zakład może za nie odpowiadać jako przechowawca, jeżeli została zawarta 
umowa przechowania. 
§ 5. Wyłączenie lub ograniczenie odpowiedzialności, o której mowa w § 1, przez 
umowę lub ogłoszenie nie ma skutku prawnego.

***
## Art. 847. {#art-847}

Roszczenie o naprawienie szkody z powodu utraty lub uszkodzenia 
rzeczy wniesionych do hotelu lub podobnego zakładu wygasa, jeżeli poszkodowany 
po otrzymaniu wiadomości o szkodzie nie zawiadomił o niej niezwłocznie 
utrzymującego zakład. Przepisu tego nie stosuje się, gdy szkodę wyrządził 
utrzymujący zarobkowo hotel lub podobny zakład albo gdy przyjął rzecz na 
przechowanie. 

©Kancelaria Sejmu 
 
 
 
s. 189/242 
 
   
 
2025-09-09

***
## Art. 848. {#art-848}

Roszczenia o naprawienie szkody wynikłej z utraty lub uszkodzenia 
rzeczy wniesionych do hotelu lub podobnego zakładu przedawniają się z upływem 
sześciu miesięcy od dnia, w którym poszkodowany dowiedział się o szkodzie, 
a w każdym razie z upływem roku od dnia, w którym poszkodowany przestał 
korzystać z usług hotelu lub podobnego zakładu.

***
## Art. 849. {#art-849}

§ 1. Zakres obowiązku naprawienia szkody przez utrzymującego 
zarobkowo hotel lub podobny zakład w wypadku utraty lub uszkodzenia rzeczy 
wniesionych ogranicza się, względem jednego gościa, do wysokości stokrotnej 
należności za dostarczone mu mieszkanie, liczonej za jedną dobę. Jednakże 
odpowiedzialność za każdą rzecz nie może przekraczać pięćdziesięciokrotnej 
wysokości tej należności. 
§ 2. Ograniczenia zakresu obowiązku naprawienia szkody nie dotyczą wypadku, 
gdy utrzymujący zarobkowo hotel lub podobny zakład przyjął rzeczy na przechowanie 
albo odmówił ich przyjęcia na przechowanie, mimo że obowiązany był je przyjąć, jak 
również wypadku, gdy szkoda wynikła z winy umyślnej lub rażącego niedbalstwa jego 
lub osoby u niego zatrudnionej. 
§ 3. Utrzymujący zarobkowo hotel lub podobny zakład jest obowiązany przyjąć 
na przechowanie pieniądze, papiery wartościowe i cenne przedmioty, w szczególności 
kosztowności i przedmioty mające wartość naukową lub artystyczną. Może odmówić 
przyjęcia tych rzeczy tylko wówczas, jeżeli zagrażają one bezpieczeństwu albo jeżeli 
w stosunku do wielkości lub standardu hotelu albo podobnego zakładu mają zbyt dużą 
wartość lub gdy zajmują zbyt dużo miejsca.

***
## Art. 850. {#art-850}

Dla zabezpieczenia należności za mieszkanie, utrzymanie i usługi 
dostarczone osobie korzystającej z usług hotelu lub podobnego zakładu, jak również 
dla zabezpieczenia roszczenia o zwrot wydatków dla tej osoby poniesionych 
przysługuje utrzymującemu zarobkowo hotel lub podobny zakład ustawowe prawo 
zastawu na rzeczach wniesionych. Prawo to podlega przepisom o ustawowym prawie 
zastawu wynajmującego.

***
## Art. 851. {#art-851}

Roszczenia 
powstałe 
w zakresie 
działalności 
przedsiębiorstw 
hotelowych z tytułu należności za dostarczone mieszkanie, utrzymanie i usługi oraz 
z tytułu wydatków poniesionych na rzecz osób, które korzystają z usług takich 

©Kancelaria Sejmu 
 
 
 
s. 190/242 
 
   
 
2025-09-09 
 
przedsiębiorstw, przedawniają się z upływem lat dwóch. Przepis ten stosuje się 
odpowiednio do przedsiębiorstw gastronomicznych.

***
## Art. 852. {#art-852}

Przepisy 
o odpowiedzialności 
i ustawowym 
prawie 
zastawu 
utrzymującego zarobkowo hotel lub podobny zakład stosuje się odpowiednio do 
zakładów kąpielowych. Jednakże co się tyczy przedmiotów, które zazwyczaj nie 
bywają wnoszone przez osoby korzystające z usług tych zakładów, odpowiedzialność 
prowadzącego zakład ogranicza się do wypadku, gdy przyjął taki przedmiot na 
przechowanie albo gdy szkoda wynikła z winy umyślnej lub rażącego niedbalstwa 
jego albo osoby u niego zatrudnionej. 
TYTUŁ XXX 
Umowa składu

***
## Art. 853. {#art-853}

§ 1. Przez umowę składu przedsiębiorca składowy zobowiązuje się do 
przechowania, za wynagrodzeniem, oznaczonych w umowie rzeczy ruchomych. 
§ 2. Przedsiębiorca 
składowy 
jest 
obowiązany 
wydać 
składającemu 
pokwitowanie, które powinno wymieniać rodzaj, ilość, oznaczenie oraz sposób 
opakowania rzeczy, jak też inne istotne postanowienia umowy.

***
## Art. 854. {#art-854}

Przepisów tytułu niniejszego nie stosuje się w przypadkach, gdy 
przedsiębiorca składowy nabywa własność złożonych rzeczy i jest obowiązany 
zwrócić tylko taką samą ilość rzeczy tego samego gatunku i takiej samej jakości.

***
## Art. 855. {#art-855}

§ 1. Przedsiębiorca składowy odpowiada za szkodę wynikłą z utraty, 
ubytku lub uszkodzenia rzeczy w czasie od przyjęcia jej na skład do wydania osobie 
uprawnionej do odbioru, chyba że udowodni, że nie mógł zapobiec szkodzie, mimo 
dołożenia należytej staranności. 
§ 2. Przedsiębiorca składowy jest obowiązany dokonywać odpowiednich 
czynności konserwacyjnych. Przeciwne postanowienie umowy jest nieważne. 
§ 3. Przedsiębiorca składowy nie ponosi odpowiedzialności za ubytek 
nieprzekraczający granic określonych właściwymi przepisami, a w razie braku takich 
przepisów – granic zwyczajowo przyjętych. 
§ 4. Odszkodowanie nie może przewyższać zwykłej wartości rzeczy, chyba że 
szkoda wynika z winy umyślnej albo rażącego niedbalstwa przedsiębiorcy 
składowego. 

©Kancelaria Sejmu 
 
 
 
s. 191/242 
 
   
 
2025-09-09

***
## Art. 856. {#art-856}

Przedsiębiorca składowy jest obowiązany do ubezpieczenia rzeczy 
jedynie wtedy, gdy otrzymał takie zlecenie.

***
## Art. 857. {#art-857}

Jeżeli stan rzeczy nadesłanych przedsiębiorcy składowemu nasuwa 
podejrzenie, że ma miejsce brak, ubytek, zepsucie albo uszkodzenie rzeczy, 
przedsiębiorca składowy powinien dokonać czynności niezbędnych do zabezpieczenia 
mienia i praw składającego.

***
## Art. 858. {#art-858}

Przedsiębiorca 
składowy 
powinien 
zawiadamiać 
składającego 
o zdarzeniach ważnych ze względu na ochronę praw składającego lub dotyczących 
stanu rzeczy oddanych na skład, chyba że zawiadomienie nie jest możliwe.

***
## Art. 859. {#art-859}

Jeżeli rzecz narażona jest na zepsucie, a nie można czekać na 
zarządzenie składającego, przedsiębiorca składowy ma prawo, a gdy wymaga tego 
interes składającego – także obowiązek, sprzedać rzecz z zachowaniem należytej 
staranności.

***
## Art. 8591. {#art-8591}

Przedsiębiorca 
składowy 
powinien 
umożliwić 
składającemu 
obejrzenie rzeczy, dzielenie ich lub łączenie, pobieranie próbek oraz dokonywanie 
innych czynności w celu zachowania rzeczy w należytym stanie.

***
## Art. 8592. {#art-8592}

§ 1. Przedsiębiorca składowy może łączyć rzeczy zamienne tego 
samego gatunku i tej samej jakości, należące do kilku składających, za ich pisemną 
zgodą. 
§ 2. Wydanie składającemu przypadającej mu części rzeczy w ten sposób 
połączonych nie wymaga zgody pozostałych składających. 
§ 3. Podział i połączenie rzeczy powinny być ujawnione w dokumentach 
przedsiębiorcy składowego.

***
## Art. 8593. {#art-8593}

Przedsiębiorcy składowemu służy na zabezpieczenie roszczeń 
o składowe i należności uboczne, o zwrot wydatków i kosztów, w szczególności 
przewoźnego i opłat celnych, o zwrot udzielonych składającemu zaliczek oraz 
wszelkich innych należności powstałych z tytułu umowy lub umów składu, ustawowe 
prawo zastawu na rzeczach oddanych na skład, dopóki znajdują się u niego lub u 
osoby, która je dzierży w jego imieniu, albo dopóki może nimi rozporządzać za 
pomocą dokumentów. 

©Kancelaria Sejmu 
 
 
 
s. 192/242 
 
   
 
2025-09-09

***
## Art. 8594. {#art-8594}

Umowę składu zawartą na czas oznaczony uważa się za przedłużoną 
na czas nieoznaczony, jeżeli na 14 dni przed upływem terminu przedsiębiorca 
składowy nie zażądał listem poleconym albo na adres do doręczeń elektronicznych, 
o którym mowa w art. 2 pkt 1 ustawy z dnia 18 listopada 2020 r. o doręczeniach 
elektronicznych (Dz. U. z 2024 r. poz. 1045 i 1841), odebrania rzeczy w umówionym 
terminie.

***
## Art. 8595. {#art-8595}

Umowę składu zawartą na czas nieoznaczony przedsiębiorca 
składowy może wypowiedzieć listem poleconym albo na adres do doręczeń 
elektronicznych, o którym mowa w art. 2 pkt 1 ustawy z dnia 18 listopada 2020 r. 
o doręczeniach elektronicznych, z zachowaniem terminu miesięcznego, jednakże nie 
wcześniej niż po upływie 2 miesięcy od złożenia rzeczy.

***
## Art. 8596. {#art-8596}

Jeżeli składający nie odbiera rzeczy pomimo upływu umówionego 
terminu lub terminu wypowiedzenia umowy, przedsiębiorca składowy może oddać 
rzecz na przechowanie na koszt i ryzyko składającego. Może on jednak wykonać to 
prawo tylko wtedy, jeżeli uprzedził składającego o zamiarze skorzystania 
z przysługującego mu prawa listem poleconym albo na adres do doręczeń 
elektronicznych, o którym mowa w art. 2 pkt 1 ustawy z dnia 18 listopada 2020 r. 
o doręczeniach elektronicznych, wysłanym nie później niż na 14 dni przed upływem 
umówionego terminu.

***
## Art. 8597. {#art-8597}

Pomimo zawarcia umowy na czas oznaczony przedsiębiorca 
składowy może z ważnych przyczyn, w każdym czasie, wezwać składającego do 
odebrania rzeczy, wyznaczając jednak odpowiedni termin ich odebrania.

***
## Art. 8598. {#art-8598}

§ 1. Przez odebranie rzeczy bez zastrzeżeń oraz zapłatę wszystkich 
należności 
przedsiębiorcy 
składowego 
wygasają 
wszelkie 
roszczenia 
do 
przedsiębiorcy składowego z tytułu umowy składu, z wyjątkiem roszczeń z tytułu nie-
widocznych uszkodzeń rzeczy, jeżeli składający, w ciągu siedmiu dni od odbioru, 
zawiadomił o nich przedsiębiorcę składowego. 
§ 2. Przepisu § 1 nie stosuje się w przypadku, gdy powstanie uszkodzenia jest 
następstwem winy umyślnej albo rażącego niedbalstwa.

***
## Art. 8599. {#art-8599}

Roszczenia z tytułu umowy składu przedawniają się z upływem roku. 

©Kancelaria Sejmu 
 
 
 
s. 193/242 
 
   
 
2025-09-09 
 
TYTUŁ XXXI 
Spółka

***
## Art. 860. {#art-860}

§ 1. Przez umowę spółki wspólnicy zobowiązują się dążyć do 
osiągnięcia wspólnego celu gospodarczego przez działanie w sposób oznaczony, 
w szczególności przez wniesienie wkładów. 
§ 2. Umowa spółki powinna być stwierdzona pismem.

***
## Art. 861. {#art-861}

§ 1. Wkład wspólnika może polegać na wniesieniu do spółki własności 
lub innych praw albo na świadczeniu usług. 
§ 2. Domniemywa się, że wkłady wspólników mają jednakową wartość.

***
## Art. 862. {#art-862}

Jeżeli wspólnik zobowiązał się wnieść do spółki własność rzeczy, do 
wykonania tego zobowiązania, jak również do odpowiedzialności z tytułu rękojmi 
oraz do niebezpieczeństwa utraty lub uszkodzenia rzeczy stosuje się odpowiednio 
przepisy o sprzedaży. Jeżeli rzeczy mają być wniesione tylko do używania, stosuje się 
odpowiednio w powyższym zakresie przepisy o najmie.

***
## Art. 863. {#art-863}

§ 1. Wspólnik nie może rozporządzać udziałem we wspólnym majątku 
wspólników ani udziałem w poszczególnych składnikach tego majątku. 
§ 2. W czasie trwania spółki wspólnik nie może domagać się podziału wspólnego 
majątku wspólników. 
§ 3. W czasie trwania spółki wierzyciel wspólnika nie może żądać zaspokojenia 
z jego udziału we wspólnym majątku wspólników ani z udziału w poszczególnych 
składnikach tego majątku.

***
## Art. 864. {#art-864}

Za zobowiązania spółki wspólnicy odpowiedzialni są solidarnie.

***
## Art. 865. {#art-865}

§ 1. Każdy wspólnik jest uprawniony i zobowiązany do prowadzenia 
spraw spółki. 
§ 2. Każdy wspólnik może bez uprzedniej uchwały wspólników prowadzić 
sprawy, które nie przekraczają zakresu zwykłych czynności spółki. Jeżeli jednak przed 
zakończeniem takiej sprawy chociażby jeden z pozostałych wspólników sprzeciwi się 
jej prowadzeniu, potrzebna jest uchwała wspólników. 
§ 3. Każdy wspólnik może bez uprzedniej uchwały wspólników wykonać 
czynność nagłą, której zaniechanie mogłoby narazić spółkę na niepowetowane straty. 

©Kancelaria Sejmu 
 
 
 
s. 194/242 
 
   
 
2025-09-09

***
## Art. 866. {#art-866}

W braku odmiennej umowy lub uchwały wspólników każdy wspólnik 
jest umocowany do reprezentowania spółki w takich granicach, w jakich jest 
uprawniony do prowadzenia jej spraw.

***
## Art. 867. {#art-867}

§ 1. Każdy wspólnik jest uprawniony do równego udziału w zyskach 
i w tym samym stosunku uczestniczy w stratach, bez względu na rodzaj i wartość 
wkładu. W umowie spółki można inaczej ustalić stosunek udziału wspólników 
w zyskach i stratach. Można nawet zwolnić niektórych wspólników od udziału 
w stratach. Natomiast nie można wyłączyć wspólnika od udziału w zyskach. 
§ 2. Ustalony w umowie stosunek udziału wspólnika w zyskach odnosi się 
w razie wątpliwości także do udziału w stratach.

***
## Art. 868. {#art-868}

§ 1. Wspólnik może żądać podziału i wypłaty zysków dopiero po 
rozwiązaniu spółki. 
§ 2. Jednakże gdy spółka została zawarta na czas dłuższy, wspólnicy mogą żądać 
podziału i wypłaty zysków z końcem każdego roku obrachunkowego.

***
## Art. 869. {#art-869}

§ 1. Jeżeli spółka została zawarta na czas nieoznaczony, każdy 
wspólnik może z niej wystąpić wypowiadając swój udział na trzy miesiące naprzód na 
koniec roku obrachunkowego. 
§ 2. Z ważnych powodów wspólnik może wypowiedzieć swój udział bez 
zachowania terminów wypowiedzenia, chociażby spółka była zawarta na czas 
oznaczony. Zastrzeżenie przeciwne jest nieważne.

***
## Art. 870. {#art-870}

Jeżeli w ciągu ostatnich sześciu miesięcy została przeprowadzona 
bezskuteczna egzekucja z ruchomości wspólnika, jego wierzyciel osobisty, który 
uzyskał zajęcie praw przysługujących wspólnikowi na wypadek wystąpienia ze spółki 
lub jej rozwiązania, może wypowiedzieć jego udział w spółce na trzy miesiące 
naprzód, chociażby spółka była zawarta na czas oznaczony. Jeżeli umowa spółki 
przewiduje krótszy termin wypowiedzenia, wierzyciel może z tego terminu 
skorzystać.

***
## Art. 871. {#art-871}

§ 1. Wspólnikowi występującemu ze spółki zwraca się w naturze 
rzeczy, które wniósł do spółki do używania, oraz wypłaca się w pieniądzu wartość 
jego wkładu oznaczoną w umowie spółki, a w braku takiego oznaczenia – wartość, 
którą wkład ten miał w chwili wniesienia. Nie ulega zwrotowi wartość wkładu 

©Kancelaria Sejmu 
 
 
 
s. 195/242 
 
   
 
2025-09-09 
 
polegającego na świadczeniu usług albo na używaniu przez spółkę rzeczy należących 
do wspólnika. 
§ 2. Ponadto wypłaca się występującemu wspólnikowi w pieniądzu taką część 
wartości wspólnego majątku pozostałego po odliczeniu wartości wkładów wszystkich 
wspólników, jaka odpowiada stosunkowi, w którym występujący wspólnik 
uczestniczył w zyskach spółki.

***
## Art. 872. {#art-872}

Można zastrzec, że spadkobiercy wspólnika wejdą do spółki na jego 
miejsce. W wypadku takim powinni oni wskazać spółce jedną osobę, która będzie 
wykonywała ich prawa. Dopóki to nie nastąpi, pozostali wspólnicy mogą sami 
podejmować wszelkie czynności w zakresie prowadzenia spraw spółki.

***
## Art. 873. {#art-873}

Jeżeli 
mimo 
istnienia 
przewidzianych 
w umowie 
powodów 
rozwiązania spółki trwa ona nadal za zgodą wszystkich wspólników, poczytuje się ją 
za przedłużoną na czas nieoznaczony.

***
## Art. 874. {#art-874}

§ 1. Z ważnych powodów każdy wspólnik może żądać rozwiązania 
spółki przez sąd. 
§ 2. Spółka ulega rozwiązaniu z dniem ogłoszenia upadłości wspólnika.

***
## Art. 875. {#art-875}

§ 1. Od chwili rozwiązania spółki stosuje się odpowiednio do 
wspólnego majątku wspólników przepisy o współwłasności w częściach ułamkowych 
z zachowaniem przepisów poniższych. 
§ 2. Z majątku pozostałego po zapłaceniu długów spółki zwraca się wspólnikom 
ich wkłady, stosując odpowiednio przepisy o zwrocie wkładów w razie wystąpienia 
wspólnika ze spółki. 
§ 3. Pozostałą nadwyżkę wspólnego majątku dzieli się między wspólników 
w takim stosunku, w jakim uczestniczyli w zyskach spółki. 
TYTUŁ XXXII 
Poręczenie

***
## Art. 876. {#art-876}

§ 1. Przez umowę poręczenia poręczyciel zobowiązuje się względem 
wierzyciela wykonać zobowiązanie na wypadek, gdyby dłużnik zobowiązania nie 
wykonał. 
§ 2. Oświadczenie poręczyciela powinno być pod rygorem nieważności złożone 
na piśmie. 

©Kancelaria Sejmu 
 
 
 
s. 196/242 
 
   
 
2025-09-09

***
## Art. 877. {#art-877}

W razie poręczenia za dług osoby, która nie mogła się zobowiązać 
z powodu braku zdolności do czynności prawnych, poręczyciel powinien spełnić 
świadczenie jako dłużnik główny, jeżeli w chwili poręczenia o braku zdolności tej 
osoby wiedział lub z łatwością mógł się dowiedzieć.

***
## Art. 878. {#art-878}

§ 1. Można poręczyć za dług przyszły do wysokości z góry 
oznaczonej. 
§ 2. Bezterminowe poręczenie za dług przyszły może być przed powstaniem 
długu odwołane w każdym czasie.

***
## Art. 879. {#art-879}

§ 1. O zakresie zobowiązania poręczyciela rozstrzyga każdoczesny 
zakres zobowiązania dłużnika. 
§ 2. Jednakże czynność prawna dokonana przez dłużnika z wierzycielem po 
udzieleniu poręczenia nie może zwiększyć zobowiązania poręczyciela.

***
## Art. 880. {#art-880}

Jeżeli dłużnik opóźnia się ze spełnieniem świadczenia, wierzyciel 
powinien zawiadomić o tym niezwłocznie poręczyciela.

***
## Art. 881. {#art-881}

W braku odmiennego zastrzeżenia poręczyciel jest odpowiedzialny jak 
współdłużnik solidarny.

***
## Art. 882. {#art-882}

Jeżeli termin płatności długu nie jest oznaczony albo jeżeli płatność 
długu zależy od wypowiedzenia, poręczyciel może po upływie sześciu miesięcy od 
daty poręczenia, a jeżeli poręczył za dług przyszły – od daty powstania długu żądać, 
aby wierzyciel wezwał dłużnika do zapłaty albo z najbliższym terminem dokonał 
wypowiedzenia. Jeżeli wierzyciel nie uczyni zadość powyższemu żądaniu, 
zobowiązanie poręczyciela wygasa.

***
## Art. 883. {#art-883}

§ 1. Poręczyciel może podnieść przeciwko wierzycielowi wszelkie 
zarzuty, które przysługują dłużnikowi; w szczególności poręczyciel może potrącić 
wierzytelność przysługującą dłużnikowi względem wierzyciela. 
§ 2. Poręczyciel nie traci powyższych zarzutów, chociażby dłużnik zrzekł się ich 
albo uznał roszczenie wierzyciela. 
§ 3. W razie śmierci dłużnika poręczyciel nie może powoływać się na 
ograniczenie odpowiedzialności spadkobiercy wynikające z przepisów prawa 
spadkowego. 

©Kancelaria Sejmu 
 
 
 
s. 197/242 
 
   
 
2025-09-09

***
## Art. 884. {#art-884}

§ 1. Poręczyciel, przeciwko któremu wierzyciel dochodzi roszczenia, 
powinien zawiadomić niezwłocznie dłużnika wzywając go do wzięcia udziału 
w sprawie. 
§ 2. Jeżeli dłużnik nie weźmie udziału w sprawie, nie może on podnieść 
przeciwko 
poręczycielowi 
zarzutów, 
które 
mu 
przysługiwały 
przeciwko 
wierzycielowi, a których poręczyciel nie podniósł z tego powodu, że o nich nie 
wiedział.

***
## Art. 885. {#art-885}

Poręczyciel powinien niezwłocznie zawiadomić dłużnika o dokonanej 
przez siebie zapłacie długu, za który poręczył. Gdyby tego nie uczynił, a dłużnik 
zobowiązanie wykonał, nie może żądać od dłużnika zwrotu tego, co sam 
wierzycielowi zapłacił, chyba że dłużnik działał w złej wierze.

***
## Art. 886. {#art-886}

Jeżeli poręczenie udzielone zostało za wiedzą dłużnika, dłużnik 
powinien niezwłocznie zawiadomić poręczyciela o wykonaniu zobowiązania. Gdyby 
tego nie uczynił, poręczyciel, który zaspokoił wierzyciela, może żądać od dłużnika 
zwrotu tego, co wierzycielowi zapłacił, chyba że działał w złej wierze.

***
## Art. 887. {#art-887}

Jeżeli wierzyciel wyzbył się zabezpieczenia wierzytelności albo 
środków dowodowych, ponosi on względem poręczyciela odpowiedzialność za 
wynikłą stąd szkodę. 
TYTUŁ XXXIII 
Darowizna

***
## Art. 888. {#art-888}

§ 1. Przez umowę darowizny darczyńca zobowiązuje się do 
bezpłatnego świadczenia na rzecz obdarowanego kosztem swego majątku. 
§ 2. (uchylony)

***
## Art. 889. {#art-889}

Nie stanowią darowizny następujące bezpłatne przysporzenia: 
- 1) gdy zobowiązanie do bezpłatnego świadczenia wynika z umowy uregulowanej 
innymi przepisami kodeksu; 
- 2) gdy kto zrzeka się prawa, którego jeszcze nie nabył albo które nabył w taki 
sposób, że w razie zrzeczenia się prawo jest uważane za nienabyte.

***
## Art. 890. {#art-890}

§ 1. Oświadczenie darczyńcy powinno być złożone w formie aktu 
notarialnego. Jednakże umowa darowizny zawarta bez zachowania tej formy staje się 
ważna, jeżeli przyrzeczone świadczenie zostało spełnione. 

©Kancelaria Sejmu 
 
 
 
s. 198/242 
 
   
 
2025-09-09 
 
§ 2. Przepisy powyższe nie uchybiają przepisom, które ze względu na przedmiot 
darowizny wymagają zachowania szczególnej formy dla oświadczeń obu stron.

***
## Art. 891. {#art-891}

§ 1. Darczyńca obowiązany jest do naprawienia szkody wynikłej 
z niewykonania lub nienależytego wykonania zobowiązania, jeżeli szkoda została 
wyrządzona umyślnie lub wskutek rażącego niedbalstwa. 
§ 2. Jeżeli darczyńca opóźnia się ze spełnieniem świadczenia pieniężnego, 
obdarowany może żądać odsetek za opóźnienie dopiero od dnia wytoczenia 
powództwa.

***
## Art. 892. {#art-892}

Jeżeli rzecz darowana ma wady, darczyńca obowiązany jest do 
naprawienia szkody, którą wyrządził obdarowanemu przez to, że wiedząc o wadach 
nie zawiadomił go o nich w czasie właściwym. Przepisu tego nie stosuje się, gdy 
obdarowany mógł z łatwością wadę zauważyć.

***
## Art. 893. {#art-893}

Darczyńca może włożyć na obdarowanego obowiązek oznaczonego 
działania lub zaniechania, nie czyniąc nikogo wierzycielem (polecenie).

***
## Art. 894. {#art-894}

§ 1. Darczyńca, który wykonał zobowiązanie wynikające z umowy 
darowizny, może żądać wypełnienia polecenia, chyba że ma ono wyłącznie na celu 
korzyść obdarowanego. 
§ 2. Po śmierci darczyńcy wypełnienia polecenia mogą żądać spadkobiercy 
darczyńcy, a jeżeli polecenie ma na względzie interes społeczny – także właściwy 
organ państwowy.

***
## Art. 895. {#art-895}

§ 1. Obdarowany może odmówić wypełnienia polecenia, jeżeli jest to 
usprawiedliwione wskutek istotnej zmiany stosunków. 
§ 2. Jeżeli wypełnienia polecenia żąda darczyńca lub jego spadkobiercy, 
obdarowany może zwolnić się przez wydanie przedmiotu darowizny w naturze 
w takim stanie, w jakim przedmiot ten się znajduje. Przepisu tego nie stosuje się, gdy 
wypełnienia polecenia żąda właściwy organ państwowy.

***
## Art. 896. {#art-896}

Darczyńca może odwołać darowiznę jeszcze niewykonaną, jeżeli po 
zawarciu umowy jego stan majątkowy uległ takiej zmianie, że wykonanie darowizny 
nie może nastąpić bez uszczerbku dla jego własnego utrzymania odpowiednio do jego 
usprawiedliwionych potrzeb albo bez uszczerbku dla ciążących na nim ustawowych 
obowiązków alimentacyjnych. 

©Kancelaria Sejmu 
 
 
 
s. 199/242 
 
   
 
2025-09-09

***
## Art. 897. {#art-897}

Jeżeli po wykonaniu darowizny darczyńca popadnie w niedostatek, 
obdarowany ma obowiązek, w granicach istniejącego jeszcze wzbogacenia, dostarczać 
darczyńcy środków, których mu brak do utrzymania odpowiadającego jego 
usprawiedliwionym potrzebom albo do wypełnienia ciążących na nim ustawowych 
obowiązków alimentacyjnych. Obdarowany może jednak zwolnić się od tego 
obowiązku zwracając darczyńcy wartość wzbogacenia.

***
## Art. 898. {#art-898}

§ 1. Darczyńca może odwołać darowiznę nawet już wykonaną, jeżeli 
obdarowany dopuścił się względem niego rażącej niewdzięczności. 
§ 2. Zwrot przedmiotu odwołanej darowizny powinien nastąpić stosownie do 
przepisów o bezpodstawnym wzbogaceniu. Od chwili zdarzenia uzasadniającego 
odwołanie obdarowany ponosi odpowiedzialność na równi z bezpodstawnie 
wzbogaconym, który powinien się liczyć z obowiązkiem zwrotu.

***
## Art. 899. {#art-899}

§ 1. Darowizna nie może być odwołana z powodu niewdzięczności, 
jeżeli darczyńca obdarowanemu przebaczył. Jeżeli w chwili przebaczenia darczyńca 
nie miał zdolności do czynności prawnych, przebaczenie jest skuteczne, gdy nastąpiło 
z dostatecznym rozeznaniem. 
§ 2. Spadkobiercy 
darczyńcy 
mogą 
odwołać 
darowiznę 
z powodu 
niewdzięczności tylko wtedy, gdy darczyńca w chwili śmierci był uprawniony do 
odwołania albo gdy obdarowany umyślnie pozbawił darczyńcę życia lub umyślnie 
wywołał rozstrój zdrowia, którego skutkiem była śmierć darczyńcy. 
§ 3. Darowizna nie może być odwołana po upływie roku od dnia, w którym 
uprawniony do odwołania dowiedział się o niewdzięczności obdarowanego.

***
## Art. 900. {#art-900}

Odwołanie darowizny następuje przez oświadczenie złożone 
obdarowanemu na piśmie.

***
## Art. 901. {#art-901}

§ 1. Przedstawiciel 
osoby 
ubezwłasnowolnionej 
może 
żądać 
rozwiązania 
umowy 
darowizny 
dokonanej 
przez 
tę 
osobę 
przed 
ubezwłasnowolnieniem, jeżeli darowizna ze względu na wartość świadczenia i brak 
uzasadnionych pobudek jest nadmierna. 
§ 2. Rozwiązania umowy darowizny nie można żądać po upływie dwóch lat od 
jej wykonania.

***
## Art. 902. {#art-902}

Przepisów o odwołaniu darowizny nie stosuje się, gdy darowizna czyni 
zadość obowiązkowi wynikającemu z zasad współżycia społecznego. 

©Kancelaria Sejmu 
 
 
 
s. 200/242 
 
   
 
2025-09-09 
 
TYTUŁ XXXIII1 
Przekazanie nieruchomości

***
## Art. 9021. {#art-9021}

§ 1. Przez umowę przekazania nieruchomości jej właściciel 
zobowiązuje się nieodpłatnie przenieść na gminę albo na Skarb Państwa własność 
nieruchomości. 
§ 2. Skarb Państwa może zawrzeć umowę przekazania nieruchomości, gdy 
gmina miejsca położenia całej albo części nieruchomości nie skorzystała z zaproszenia 
do jej zawarcia w terminie trzech miesięcy od dnia złożenia zaproszenia przez 
właściciela nieruchomości.

***
## Art. 9022. {#art-9022}

Jeżeli strony nie postanowiły inaczej właściciel przekazujący 
nieruchomość nie ponosi odpowiedzialności za jej wady. 
TYTUŁ XXXIV 
Renta i dożywocie 
## DZIAŁ I. Renta

***
## Art. 903. {#art-903}

Przez umowę renty jedna ze stron zobowiązuje się względem drugiej 
do określonych świadczeń okresowych w pieniądzu lub w rzeczach oznaczonych 
tylko co do gatunku.

***
## Art. 9031. {#art-9031}

Umowa renty powinna być stwierdzona pismem.

***
## Art. 904. {#art-904}

Jeżeli nie oznaczono inaczej terminów płatności renty, rentę pieniężną 
należy płacić miesięcznie z góry, a rentę polegającą na świadczeniach w rzeczach 
oznaczonych tylko co do gatunku należy uiszczać w terminach wynikających 
z właściwości świadczenia i celu renty.

***
## Art. 905. {#art-905}

Jeżeli uprawniony dożył dnia płatności renty płatnej z góry, należy mu 
się całe świadczenie przypadające za dany okres. Renta płatna z dołu powinna być 
zapłacona za czas do dnia, w którym obowiązek ustał.

***
## Art. 906. {#art-906}

§ 1. Do renty ustanowionej za wynagrodzeniem stosuje się 
odpowiednio przepisy o sprzedaży. 
§ 2. Do renty ustanowionej bez wynagrodzenia stosuje się przepisy o darowiźnie. 

©Kancelaria Sejmu 
 
 
 
s. 201/242 
 
   
 
2025-09-09

***
## Art. 907. {#art-907}

§ 1. Przepisy działu niniejszego stosuje się w braku przepisów 
szczególnych także w wypadku, gdy renta wynika ze źródeł pozaumownych. 
§ 2. Jeżeli obowiązek płacenia renty wynika z ustawy, każda ze stron może 
w razie zmiany stosunków żądać zmiany wysokości lub czasu trwania renty, 
chociażby wysokość renty i czas jej trwania były ustalone w orzeczeniu sądowym lub 
w umowie. 
## DZIAŁ II. Dożywocie

***
## Art. 908. {#art-908}

§ 1. Jeżeli w zamian za przeniesienie własności nieruchomości 
nabywca zobowiązał się zapewnić zbywcy dożywotnie utrzymanie (umowa 
o dożywocie), powinien on, w braku odmiennej umowy, przyjąć zbywcę jako 
domownika, dostarczać mu wyżywienia, ubrania, mieszkania, światła i opału, 
zapewnić mu odpowiednią pomoc i pielęgnowanie w chorobie oraz sprawić mu 
własnym kosztem pogrzeb odpowiadający zwyczajom miejscowym. 
§ 2. Jeżeli w umowie o dożywocie nabywca nieruchomości zobowiązał się 
obciążyć ją na rzecz zbywcy użytkowaniem, którego wykonywanie jest ograniczone 
do części nieruchomości, służebnością mieszkania lub inną służebnością osobistą albo 
spełniać powtarzające się świadczenia w pieniądzach lub w rzeczach oznaczonych co 
do gatunku, użytkowanie, służebność osobista oraz uprawnienie do powtarzających 
się świadczeń należą do treści prawa dożywocia. 
§ 3. Dożywocie można zastrzec także na rzecz osoby bliskiej zbywcy 
nieruchomości.

***
## Art. 909. {#art-909}

(uchylony)

***
## Art. 910. {#art-910}

§ 1. Przeniesienie własności nieruchomości na podstawie umowy 
o dożywocie następuje z jednoczesnym obciążeniem nieruchomości prawem 
dożywocia. Do takiego obciążenia stosuje się odpowiednio przepisy o prawach 
rzeczowych ograniczonych. 
§ 2. W razie zbycia nieruchomości obciążonej prawem dożywocia nabywca 
ponosi także osobistą odpowiedzialność za świadczenia tym prawem objęte, chyba że 
stały się wymagalne w czasie, kiedy nieruchomość nie była jego własnością. Osobista 
odpowiedzialność współwłaścicieli jest solidarna. 

©Kancelaria Sejmu 
 
 
 
s. 202/242 
 
   
 
2025-09-09

***
## Art. 911. {#art-911}

Prawo dożywocia ustanowione na rzecz kilku osób ulega w razie 
śmierci jednej z tych osób odpowiedniemu zmniejszeniu.

***
## Art. 912. {#art-912}

Prawo dożywocia jest niezbywalne.

***
## Art. 913. {#art-913}

§ 1. Jeżeli 
z jakichkolwiek 
powodów 
wytworzą 
się 
między 
dożywotnikiem a zobowiązanym takie stosunki, że nie można wymagać od stron, żeby 
pozostawały nadal w bezpośredniej ze sobą styczności, sąd na żądanie jednej z nich 
zamieni wszystkie lub niektóre uprawnienia objęte treścią prawa dożywocia na 
dożywotnią rentę odpowiadającą wartości tych uprawnień. 
§ 2. W wypadkach wyjątkowych sąd może na żądanie zobowiązanego lub 
dożywotnika, jeżeli dożywotnik jest zbywcą nieruchomości, rozwiązać umowę 
o dożywocie.

***
## Art. 914. {#art-914}

Jeżeli zobowiązany z tytułu umowy o dożywocie zbył otrzymaną 
nieruchomość, dożywotnik może żądać zamiany prawa dożywocia na dożywotnią 
rentę odpowiadającą wartości tego prawa.

***
## Art. 915. {#art-915}

Przepisy dwóch artykułów poprzedzających stosuje się odpowiednio 
do umów, przez które nabywca nieruchomości zobowiązał się, w celu zapewnienia 
zbywcy dożywotniego utrzymania, do obciążenia nieruchomości użytkowaniem 
z ograniczeniem jego wykonywania do części nieruchomości.

***
## Art. 916. {#art-916}

§ 1. Osoba, względem której ciąży na dożywotniku ustawowy 
obowiązek alimentacyjny, może żądać uznania umowy o dożywocie za bezskuteczną 
w stosunku do niej, jeżeli wskutek tej umowy dożywotnik stał się niewypłacalny. 
Uprawnienie to przysługuje bez względu na to, czy dożywotnik działał ze 
świadomością pokrzywdzenia wierzycieli, oraz bez względu na czas zawarcia umowy. 
§ 2. Uznania umowy o dożywocie za bezskuteczną nie można żądać po upływie 
lat pięciu od daty tej umowy. 
TYTUŁ XXXV 
Ugoda

***
## Art. 917. {#art-917}

Przez ugodę strony czynią sobie wzajemne ustępstwa w zakresie 
istniejącego między nimi stosunku prawnego w tym celu, aby uchylić niepewność co 
do roszczeń wynikających z tego stosunku lub zapewnić ich wykonanie albo by 
uchylić spór istniejący lub mogący powstać. 

©Kancelaria Sejmu 
 
 
 
s. 203/242 
 
   
 
2025-09-09

***
## Art. 918. {#art-918}

§ 1. Uchylenie się od skutków prawnych ugody zawartej pod 
wpływem błędu jest dopuszczalne tylko wtedy, gdy błąd dotyczy stanu faktycznego, 
który według treści ugody obie strony uważały za niewątpliwy, a spór albo 
niepewność nie byłyby powstały, gdyby w chwili zawarcia ugody strony wiedziały 
o prawdziwym stanie rzeczy. 
§ 2. Nie można uchylić się od skutków prawnych ugody z powodu odnalezienia 
dowodów co do roszczeń, których ugoda dotyczy, chyba że została zawarta w złej 
wierze. 
TYTUŁ XXXVI 
Przyrzeczenie publiczne

***
## Art. 919. {#art-919}

§ 1. Kto przez ogłoszenie publiczne przyrzekł nagrodę za wykonanie 
oznaczonej czynności, obowiązany jest przyrzeczenia dotrzymać. 
§ 2. Jeżeli w przyrzeczeniu nie był oznaczony termin wykonania czynności ani 
nie było zastrzeżenia, że przyrzeczenie jest nieodwołalne, przyrzekający może je 
odwołać. Odwołanie powinno nastąpić przez ogłoszenie publiczne w taki sam sposób, 
w jaki było uczynione przyrzeczenie. Odwołanie jest bezskuteczne względem osoby, 
która wcześniej czynność wykonała.

***
## Art. 920. {#art-920}

§ 1. Jeżeli czynność wykonało kilka osób niezależnie od siebie, każdej 
z nich należy się nagroda w pełnej wysokości, chyba że została przyrzeczona tylko 
jedna nagroda. 
§ 2. Jeżeli była przyrzeczona tylko jedna nagroda, otrzyma ją osoba, która 
pierwsza się zgłosi, a w razie jednoczesnego zgłoszenia się kilku osób – ta, która 
pierwsza czynność wykonała. 
§ 3. Jeżeli czynność wykonało kilka osób wspólnie, w razie sporu sąd 
odpowiednio podzieli nagrodę.

***
## Art. 921. {#art-921}

§ 1. Publiczne przyrzeczenie nagrody za najlepsze dzieło lub za 
najlepszą czynność jest bezskuteczne, jeśli nie został w nim oznaczony termin, 
w ciągu którego można ubiegać się o nagrodę. 
§ 2. Ocena, czy i które dzieło lub czynność zasługuje na nagrodę, należy do 
przyrzekającego, chyba że w przyrzeczeniu nagrody inaczej zastrzeżono. 
§ 3. Przyrzekający nagrodę nabywa własność nagrodzonego dzieła tylko wtedy, 
gdy to zastrzegł w przyrzeczeniu. W wypadku takim nabycie własności następuje 

©Kancelaria Sejmu 
 
 
 
s. 204/242 
 
   
 
2025-09-09 
 
z chwilą wypłacenia nagrody. Przepis ten stosuje się również do nabycia praw 
autorskich albo praw wynalazczych. 
TYTUŁ XXXVII 
Przekaz i papiery wartościowe 
## DZIAŁ I. Przekaz

***
## Art. 9211. {#art-9211}

Kto przekazuje drugiemu (odbiorcy przekazu) świadczenie osoby 
trzeciej (przekazanego), upoważnia tym samym odbiorcę przekazu do przyjęcia, 
a przekazanego do spełnienia świadczenia na rachunek przekazującego.

***
## Art. 9212. {#art-9212}

§ 1. Jeżeli przekazany oświadczył odbiorcy przekazu, że przekaz 
przyjmuje, obowiązany jest względem odbiorcy do spełnienia świadczenia 
określonego w przekazie. 
§ 2. W takim wypadku przekazany może powoływać się tylko na zarzuty 
wynikające z treści przekazu oraz na zarzuty, które przysługują mu osobiście 
względem odbiorcy. 
§ 3. Roszczenia odbiorcy przeciw przekazanemu, wynikające z przyjęcia 
przekazu, przedawniają się z upływem roku.

***
## Art. 9213. {#art-9213}

Przekazujący może przekaz odwołać, dopóki przekazany nie przyjął 
go albo nie spełnił świadczenia.

***
## Art. 9214. {#art-9214}

Jeżeli przekazany jest dłużnikiem przekazującego co do przekazanego 
świadczenia, jest on obowiązany względem niego do zadośćuczynienia przekazowi.

***
## Art. 9215. {#art-9215}

Jeżeli przekazujący jest dłużnikiem odbiorcy przekazu, umorzenie 
długu następuje dopiero przez spełnienie świadczenia, chyba że umówiono się inaczej. 
## DZIAŁ II. Papiery wartościowe

***
## Art. 9216. {#art-9216}

Jeżeli zobowiązanie wynika z wystawionego papieru wartościowego, 
dłużnik jest obowiązany do świadczenia za zwrotem dokumentu albo udostępnieniem 
go dłużnikowi celem pozbawienia dokumentu jego mocy prawnej w sposób 
zwyczajowo przyjęty. 

©Kancelaria Sejmu 
 
 
 
s. 205/242 
 
   
 
2025-09-09

***
## Art. 9217. {#art-9217}

Spełnienie świadczenia do rąk posiadacza legitymowanego treścią 
papieru wartościowego zwalnia dłużnika, chyba że działał on w złej wierze.

***
## Art. 9218. {#art-9218}

Papiery wartościowe imienne legitymują osobę imiennie wskazaną 
w treści dokumentu. Przeniesienie praw następuje przez przelew połączony 
z wydaniem dokumentu.

***
## Art. 9219. {#art-9219}

§ 1. Papiery wartościowe na zlecenie legitymują osobę wymienioną 
w dokumencie oraz każdego, na kogo prawa zostały przeniesione przez indos. 
§ 2. Indos jest pisemnym oświadczeniem umieszczonym na papierze 
wartościowym na zlecenie i zawierającym co najmniej podpis zbywcy, oznaczającym 
przeniesienie praw na inną osobę. 
§ 3. Do przeniesienia praw z dokumentu potrzebne jest jego wydanie oraz 
istnienie nieprzerwanego szeregu indosów.

***
## Art. 92110. {#art-92110}

§ 1. Jeżeli do puszczenia w obieg dokumentu na okaziciela jest 
wymagane zezwolenie właściwego organu państwowego, dokument wystawiony bez 
takiego zezwolenia jest nieważny. 
§ 2. Podpis dłużnika może być odbity sposobem mechanicznym, chyba że 
przepisy szczególne stanowią inaczej.

***
## Art. 92111. {#art-92111}

§ 1. Dłużnik nie ma obowiązku dochodzenia, czy okaziciel jest 
właścicielem dokumentu. Jednakże w razie uzasadnionych wątpliwości, czy okaziciel 
dokumentu jest wierzycielem, dłużnik powinien złożyć przedmiot świadczenia do 
depozytu sądowego. 
§ 2. Jeżeli właściwy organ państwowy wydał zakaz świadczenia, zwolnienie 
z zobowiązania następuje przez złożenie przedmiotu świadczenia do depozytu 
sądowego.

***
## Art. 92112. {#art-92112}

Przeniesienie praw z dokumentu na okaziciela wymaga wydania tego 
dokumentu.

***
## Art. 92113. {#art-92113}

Dłużnik może powołać się względem wierzyciela na zarzuty, które 
dotyczą ważności dokumentu lub wynikają z jego treści albo służą mu osobiście 
przeciw wierzycielowi. Dłużnik może także powołać się na zarzuty, które mu służą 
przeciw poprzedniemu wierzycielowi, jeżeli nabywca dokumentu działał świadomie 
na szkodę dłużnika. 

©Kancelaria Sejmu 
 
 
 
s. 206/242 
 
   
 
2025-09-09

***
## Art. 92114. {#art-92114}

§ 1. Umarzanie papierów wartościowych regulują przepisy 
szczególne. 
§ 2. Jeżeli papier wartościowy został prawomocnie umorzony, dłużnik jest 
obowiązany wydać osobie, na której rzecz nastąpiło umorzenie, na jej koszt nowy 
dokument, a gdy wierzytelność jest wymagalna – spełnić świadczenie.

***
## Art. 92115. {#art-92115}

§ 1. Przepisy o papierach wartościowych stosuje się odpowiednio do 
znaków legitymacyjnych stwierdzających obowiązek świadczenia. 
§ 2. W razie utraty znaku legitymacyjnego stwierdzającego w swej treści 
obowiązek świadczenia na żądanie wierzyciela, dłużnik może uzależnić spełnienie 
świadczenia od wykazania uprawnienia przez osobę zgłaszającą takie żądanie. 
§ 3. Do znaku legitymacyjnego, który nie określa imiennie osoby uprawnionej, 
stosuje się odpowiednio przepisy o papierach wartościowych na okaziciela, chyba że 
co innego wynika z przepisów szczególnych.

***
## Art. 92116. {#art-92116}

Przepisy niniejszego działu stosuje się odpowiednio do papierów 
wartościowych opiewających na prawa inne niż wierzytelności. 
KSIĘGA CZWARTA 
SPADKI 
TYTUŁ I 
Przepisy ogólne

***
## Art. 922. {#art-922}

§ 1. Prawa i obowiązki majątkowe zmarłego przechodzą z chwilą jego 
śmierci na jedną lub kilka osób stosownie do przepisów księgi niniejszej. 
§ 2. Nie należą do spadku prawa i obowiązki zmarłego ściśle związane z jego 
osobą, jak również prawa, które z chwilą jego śmierci przechodzą na oznaczone osoby 
niezależnie od tego, czy są one spadkobiercami. 
§ 3. Do długów spadkowych należą także koszty pogrzebu spadkodawcy 
w takim zakresie, w jakim pogrzeb ten odpowiada zwyczajom przyjętym w danym 
środowisku, koszty postępowania spadkowego, obowiązek zaspokojenia roszczeń 
o zachowek oraz obowiązek wykonania zapisów zwykłych i poleceń, jak również inne 
obowiązki przewidziane w przepisach księgi niniejszej.

***
## Art. 923. {#art-923}

§ 1. Małżonek i inne osoby bliskie spadkodawcy, które mieszkały 
z nim do dnia jego śmierci, są uprawnione do korzystania w ciągu trzech miesięcy od 

©Kancelaria Sejmu 
 
 
 
s. 207/242 
 
   
 
2025-09-09 
 
otwarcia spadku z mieszkania i urządzenia domowego w zakresie dotychczasowym. 
Rozrządzenie spadkodawcy wyłączające lub ograniczające to uprawnienie jest 
nieważne. 
§ 2. Przepisy powyższe nie ograniczają uprawnień małżonka i innych osób 
bliskich spadkodawcy, które wynikają z najmu lokali lub ze spółdzielczego prawa do 
lokalu.

***
## Art. 924. {#art-924}

Spadek otwiera się z chwilą śmierci spadkodawcy.

***
## Art. 925. {#art-925}

Spadkobierca nabywa spadek z chwilą otwarcia spadku.

***
## Art. 926. {#art-926}

§ 1. Powołanie do spadku wynika z ustawy albo z testamentu. 
§ 2. Dziedziczenie ustawowe co do całości spadku następuje wtedy, gdy 
spadkodawca nie powołał spadkobiercy albo gdy żadna z osób, które powołał, nie chce 
lub nie może być spadkobiercą. 
§ 3. Z zastrzeżeniem wyjątków w ustawie przewidzianych, dziedziczenie 
ustawowe co do części spadku następuje wtedy, gdy spadkodawca nie powołał do tej 
części spadkobiercy albo gdy którakolwiek z kilku osób, które powołał do całości 
spadku, nie chce lub nie może być spadkobiercą.

***
## Art. 927. {#art-927}

§ 1. Nie może być spadkobiercą osoba fizyczna, która nie żyje w chwili 
otwarcia spadku, ani osoba prawna, która w tym czasie nie istnieje. 
§ 2. Jednakże dziecko w chwili otwarcia spadku już poczęte może być 
spadkobiercą, jeżeli urodzi się żywe. 
§ 3. Fundacja lub fundacja rodzinna, ustanowiona w testamencie przez 
spadkodawcę może być spadkobiercą, jeżeli zostanie wpisana do rejestru w ciągu 
dwóch lat od ogłoszenia testamentu.

***
## Art. 928. {#art-928}

§ 1. Spadkobierca może być uznany przez sąd za niegodnego, jeżeli: 
- 1) dopuścił się umyślnie ciężkiego przestępstwa przeciwko spadkodawcy; 
- 2) podstępem lub groźbą nakłonił spadkodawcę do sporządzenia lub odwołania 
testamentu albo w taki sam sposób przeszkodził mu w dokonaniu jednej z tych 
czynności; 
- 3) umyślnie ukrył lub zniszczył testament spadkodawcy, podrobił lub przerobił jego 
testament albo świadomie skorzystał z testamentu przez inną osobę 
podrobionego lub przerobionego; 

©Kancelaria Sejmu 
 
 
 
s. 208/242 
 
   
 
2025-09-09 
- 4) uporczywie uchylał się od wykonywania wobec spadkodawcy obowiązku 
alimentacyjnego określonego co do wysokości orzeczeniem sądowym, ugodą 
zawartą przed sądem albo innym organem albo inną umową; 
- 5) uporczywie uchylał się od wykonywania obowiązku pieczy nad spadkodawcą, 
w szczególności wynikającego z władzy rodzicielskiej, opieki, sprawowania 
funkcji rodzica zastępczego, małżeńskiego obowiązku wzajemnej pomocy albo 
obowiązku wzajemnego szacunku i wspierania się rodzica i dziecka. 
§ 2. Spadkobierca niegodny zostaje wyłączony od dziedziczenia, tak jakby nie 
dożył otwarcia spadku.

***
## Art. 929. {#art-929}

Uznania spadkobiercy za niegodnego może żądać każdy, kto ma w tym 
interes. Z żądaniem takim może wystąpić w ciągu roku od dnia, w którym dowiedział 
się o przyczynie niegodności, nie później jednak niż przed upływem lat trzech od 
otwarcia spadku.

***
## Art. 930. {#art-930}

§ 1. Spadkobierca nie może być uznany za niegodnego, jeżeli 
spadkodawca mu przebaczył. 
§ 2. Jeżeli w chwili przebaczenia spadkodawca nie miał zdolności do czynności 
prawnych, przebaczenie jest skuteczne, gdy nastąpiło z dostatecznym rozeznaniem. 
TYTUŁ II 
Dziedziczenie ustawowe

***
## Art. 931. {#art-931}

§ 1. W pierwszej kolejności powołane są z ustawy do spadku dzieci 
spadkodawcy oraz jego małżonek; dziedziczą oni w częściach równych. Jednakże 
część przypadająca małżonkowi nie może być mniejsza niż jedna czwarta całości 
spadku. 
§ 2. Jeżeli dziecko spadkodawcy nie dożyło otwarcia spadku, udział spadkowy, 
który by mu przypadał, przypada jego dzieciom w częściach równych. Przepis ten 
stosuje się odpowiednio do dalszych zstępnych.

***
## Art. 932. {#art-932}

§ 1. W braku zstępnych spadkodawcy powołani są do spadku z ustawy 
jego małżonek i rodzice. 
§ 2. Udział spadkowy każdego z rodziców, które dziedziczy w zbiegu 
z małżonkiem spadkodawcy, wynosi jedną czwartą całości spadku. Jeżeli ojcostwo 

©Kancelaria Sejmu 
 
 
 
s. 209/242 
 
   
 
2025-09-09 
 
rodzica nie zostało ustalone, udział spadkowy matki spadkodawcy, dziedziczącej 
w zbiegu z jego małżonkiem, wynosi połowę spadku. 
§ 3. W braku zstępnych i małżonka spadkodawcy cały spadek przypada jego 
rodzicom w częściach równych. 
§ 4. Jeżeli jedno z rodziców spadkodawcy nie dożyło otwarcia spadku, udział 
spadkowy, który by mu przypadał, przypada rodzeństwu spadkodawcy w częściach 
równych. 
§ 5. Jeżeli którekolwiek z rodzeństwa spadkodawcy nie dożyło otwarcia spadku 
pozostawiając zstępnych, udział spadkowy, który by mu przypadał, przypada jego 
zstępnym. Podział tego udziału następuje według zasad, które dotyczą podziału 
między dalszych zstępnych spadkodawcy. 
§ 6. Jeżeli jedno z rodziców nie dożyło otwarcia spadku i brak jest rodzeństwa 
spadkodawcy lub ich zstępnych, udział spadkowy rodzica dziedziczącego w zbiegu 
z małżonkiem spadkodawcy wynosi połowę spadku.

***
## Art. 933. {#art-933}

§ 1. Udział spadkowy małżonka, który dziedziczy w zbiegu 
z rodzicami, rodzeństwem i zstępnymi rodzeństwa spadkodawcy, wynosi połowę 
spadku. 
§ 2. W braku zstępnych spadkodawcy, jego rodziców, rodzeństwa i ich 
zstępnych, cały spadek przypada małżonkowi spadkodawcy.

***
## Art. 934. {#art-934}

§ 1. W braku zstępnych, małżonka, rodziców, rodzeństwa i zstępnych 
rodzeństwa spadkodawcy cały spadek przypada dziadkom spadkodawcy; dziedziczą 
oni w częściach równych. 
§ 2. Jeżeli którekolwiek z dziadków spadkodawcy nie dożyło otwarcia spadku, 
udział spadkowy, który by mu przypadał, przypada jego dzieciom w częściach 
równych. 
§ 21. Jeżeli dziecko któregokolwiek z dziadków spadkodawcy nie dożyło 
otwarcia spadku, udział spadkowy, który by mu przypadał, przypada jego dzieciom 
w częściach równych. 
§ 3. W braku dzieci i wnuków tego z dziadków, który nie dożył otwarcia spadku, 
udział spadkowy, który by mu przypadał, przypada pozostałym dziadkom w częściach 
równych. 

©Kancelaria Sejmu 
 
 
 
s. 210/242 
 
   
 
2025-09-09

***
## Art. 9341. {#art-9341}

W braku małżonka spadkodawcy i krewnych, powołanych do 
dziedziczenia z ustawy, spadek przypada w częściach równych tym dzieciom 
małżonka spadkodawcy, których żadne z rodziców nie dożyło chwili otwarcia spadku.

***
## Art. 935. {#art-935}

W braku małżonka spadkodawcy, jego krewnych i dzieci małżonka 
spadkodawcy, powołanych do dziedziczenia z ustawy, spadek przypada gminie 
ostatniego miejsca zamieszkania spadkodawcy jako spadkobiercy ustawowemu. Jeżeli 
ostatniego miejsca zamieszkania spadkodawcy w Rzeczypospolitej Polskiej nie da się 
ustalić albo ostatnie miejsce zamieszkania spadkodawcy znajdowało się za granicą, 
spadek przypada Skarbowi Państwa jako spadkobiercy ustawowemu.

***
## Art. 9351. {#art-9351}

Przepisów o powołaniu do dziedziczenia z ustawy nie stosuje się do 
małżonka spadkodawcy pozostającego w separacji.

***
## Art. 936. {#art-936}

§ 1. Przysposobiony dziedziczy po przysposabiającym i jego 
krewnych tak, jakby był dzieckiem przysposabiającego, a przysposabiający i jego 
krewni dziedziczą po przysposobionym tak, jakby przysposabiający był rodzicem 
przysposobionego. 
§ 2. Przysposobiony nie dziedziczy po swoich wstępnych naturalnych i ich 
krewnych, a osoby te nie dziedziczą po nim. 
§ 3. W wypadku gdy jeden z małżonków przysposobił dziecko drugiego 
małżonka, przepisu § 2 nie stosuje się względem tego małżonka i jego krewnych, 
a jeżeli 
takie 
przysposobienie 
nastąpiło 
po 
śmierci 
drugiego 
z rodziców 
przysposobionego, także względem krewnych zmarłego, których prawa i obowiązki 
wynikające z pokrewieństwa zostały w orzeczeniu o przysposobieniu utrzymane.

***
## Art. 937. {#art-937}

Jeżeli skutki przysposobienia polegają wyłącznie na powstaniu 
stosunku między przysposabiającym a przysposobionym, stosuje się przepisy 
poniższe: 
- 1) przysposobiony dziedziczy po przysposabiającym na równi z jego dziećmi, 
a zstępni przysposobionego dziedziczą po przysposabiającym na tych samych 
zasadach co dalsi zstępni spadkodawcy; 
- 2) przysposobiony i jego zstępni nie dziedziczą po krewnych przysposabiającego, 
a krewni przysposabiającego nie dziedziczą po przysposobionym i jego 
zstępnych; 

©Kancelaria Sejmu 
 
 
 
s. 211/242 
 
   
 
2025-09-09 
- 3) rodzice przysposobionego nie dziedziczą po przysposobionym, a zamiast nich 
dziedziczy po przysposobionym przysposabiający; poza tym przysposobienie nie 
narusza powołania do dziedziczenia wynikającego z pokrewieństwa.

***
## Art. 938. {#art-938}

Dziadkowie spadkodawcy, jeżeli znajdują się w niedostatku i nie mogą 
otrzymać należnych im środków utrzymania od osób, na których ciąży względem nich 
ustawowy obowiązek alimentacyjny, mogą żądać od spadkobiercy nieobciążonego 
takim obowiązkiem środków utrzymania w stosunku do swoich potrzeb i do wartości 
jego udziału spadkowego. Spadkobierca może uczynić zadość temu roszczeniu także 
w ten sposób, że zapłaci dziadkom spadkodawcy sumę pieniężną odpowiadającą 
wartości jednej czwartej części swojego udziału spadkowego.

***
## Art. 939. {#art-939}

§ 1. 
Małżonek 
dziedziczący 
z ustawy 
w zbiegu 
z innymi 
spadkobiercami, wyjąwszy zstępnych spadkodawcy, którzy mieszkali z nim razem 
w chwili jego śmierci, może żądać ze spadku ponad swój udział spadkowy 
przedmiotów urządzenia domowego, z których za życia spadkodawcy korzystał 
wspólnie z nim lub wyłącznie sam. Do roszczeń małżonka z tego tytułu stosuje się 
odpowiednio przepisy o zapisie zwykłym. 
§ 2. Uprawnienie powyższe nie przysługuje małżonkowi, jeżeli wspólne pożycie 
małżonków ustało za życia spadkodawcy.

***
## Art. 940. {#art-940}

§ 1. Małżonek jest wyłączony od dziedziczenia, jeżeli spadkodawca 
wystąpił o orzeczenie rozwodu lub separacji z jego winy, a żądanie to było 
uzasadnione. 
§ 2. Wyłączenie małżonka od dziedziczenia następuje na mocy orzeczenia sądu. 
Wyłączenia może żądać każdy z pozostałych spadkobierców ustawowych 
powołanych do dziedziczenia w zbiegu z małżonkiem; termin do wytoczenia 
powództwa wynosi sześć miesięcy od dnia, w którym spadkobierca dowiedział się 
o otwarciu spadku, nie więcej jednak niż jeden rok od otwarcia spadku. 

©Kancelaria Sejmu 
 
 
 
s. 212/242 
 
   
 
2025-09-09 
 
TYTUŁ III 
Rozrządzenia na wypadek śmierci 
## DZIAŁ I. Testament 
## Rozdział I. Przepisy ogólne

***
## Art. 941. {#art-941}

Rozrządzić majątkiem na wypadek śmierci można jedynie przez 
testament.

***
## Art. 942. {#art-942}

Testament może zawierać rozrządzenia tylko jednego spadkodawcy.

***
## Art. 943. {#art-943}

Spadkodawca może w każdej chwili odwołać zarówno cały testament, 
jak i jego poszczególne postanowienia.

***
## Art. 944. {#art-944}

§ 1. Sporządzić i odwołać testament może tylko osoba mająca pełną 
zdolność do czynności prawnych. 
§ 2. Testamentu nie można sporządzić ani odwołać przez przedstawiciela.

***
## Art. 945. {#art-945}

§ 1. Testament jest nieważny, jeżeli został sporządzony: 
- 1) w stanie wyłączającym świadome albo swobodne powzięcie decyzji i wyrażenie 
woli; 
- 2) pod wpływem błędu uzasadniającego przypuszczenie, że gdyby spadkodawca 
nie działał pod wpływem błędu, nie sporządziłby testamentu tej treści; 
- 3) pod wpływem groźby. 
§ 2. Na nieważność testamentu z powyższych przyczyn nie można się powołać 
po upływie lat trzech od dnia, w którym osoba mająca w tym interes dowiedziała się 
o przyczynie nieważności, a w każdym razie po upływie lat dziesięciu od otwarcia 
spadku.

***
## Art. 946. {#art-946}

Odwołanie testamentu może nastąpić bądź w ten sposób, że 
spadkodawca sporządzi nowy testament, bądź też w ten sposób, że w zamiarze 
odwołania testament zniszczy lub pozbawi go cech, od których zależy jego ważność, 
bądź wreszcie w ten sposób, że dokona w testamencie zmian, z których wynika wola 
odwołania jego postanowień. 

©Kancelaria Sejmu 
 
 
 
s. 213/242 
 
   
 
2025-09-09

***
## Art. 947. {#art-947}

Jeżeli spadkodawca sporządził nowy testament nie zaznaczając w nim, 
że poprzedni odwołuje, ulegają odwołaniu tylko te postanowienia poprzedniego 
testamentu, których nie można pogodzić z treścią nowego testamentu.

***
## Art. 948. {#art-948}

§ 1. Testament należy tak tłumaczyć, ażeby zapewnić możliwie 
najpełniejsze urzeczywistnienie woli spadkodawcy. 
§ 2. Jeżeli testament może być tłumaczony rozmaicie, należy przyjąć taką 
wykładnię, która pozwala utrzymać rozrządzenia spadkodawcy w mocy i nadać im 
rozsądną treść. 
## Rozdział II. Forma testamentu 
Oddział 1 
Testamenty zwykłe

***
## Art. 949. {#art-949}

§ 1. Spadkodawca może sporządzić testament w ten sposób, że napisze 
go w całości pismem ręcznym, podpisze i opatrzy datą. 
§ 2. Jednakże brak daty nie pociąga za sobą nieważności testamentu 
własnoręcznego, jeżeli nie wywołuje wątpliwości co do zdolności spadkodawcy do 
sporządzenia testamentu, co do treści testamentu lub co do wzajemnego stosunku kilku 
testamentów.

***
## Art. 950. {#art-950}

Testament może być sporządzony w formie aktu notarialnego.

***
## Art. 951. {#art-951}

§ 1. Spadkodawca może sporządzić testament także w ten sposób, że 
w obecności dwóch świadków oświadczy swoją ostatnią wolę ustnie wobec wójta 
(burmistrza, prezydenta miasta), starosty, marszałka województwa, sekretarza powiatu 
albo gminy lub kierownika urzędu stanu cywilnego. 
§ 2. Oświadczenie spadkodawcy spisuje się w protokole z podaniem daty jego 
sporządzenia. Protokół odczytuje się spadkodawcy w obecności świadków. Protokół 
powinien być podpisany przez spadkodawcę, przez osobę, wobec której wola została 
oświadczona, oraz przez świadków. Jeżeli spadkodawca nie może podpisać protokołu, 
należy to zaznaczyć w protokole ze wskazaniem przyczyny braku podpisu. 
§ 3. Osoby głuche lub nieme nie mogą sporządzić testamentu w sposób 
przewidziany w artykule niniejszym. 

©Kancelaria Sejmu 
 
 
 
s. 214/242 
 
   
 
2025-09-09 
 
Oddział 2 
Testamenty szczególne

***
## Art. 952. {#art-952}

§ 1. Jeżeli istnieje obawa rychłej śmierci spadkodawcy albo jeżeli 
wskutek szczególnych okoliczności zachowanie zwykłej formy testamentu jest 
niemożliwe lub bardzo utrudnione, spadkodawca może oświadczyć ostatnią wolę 
ustnie przy jednoczesnej obecności co najmniej trzech świadków. 
§ 2. Treść testamentu ustnego może być stwierdzona w ten sposób, że jeden ze 
świadków albo osoba trzecia spisze oświadczenie spadkodawcy przed upływem roku 
od jego złożenia, z podaniem miejsca i daty oświadczenia oraz miejsca i daty 
sporządzenia pisma, a pismo to podpiszą spadkodawca i dwaj świadkowie albo 
wszyscy świadkowie. 
§ 3. W wypadku gdy treść testamentu ustnego nie została w powyższy sposób 
stwierdzona, można ją w ciągu sześciu miesięcy od dnia otwarcia spadku stwierdzić 
przez zgodne zeznania świadków złożone przed sądem. Jeżeli przesłuchanie jednego 
ze świadków nie jest możliwe lub napotyka trudne do przezwyciężenia przeszkody, 
sąd może poprzestać na zgodnych zeznaniach dwóch świadków.

***
## Art. 953. {#art-953}

Podczas podróży na polskim statku morskim lub powietrznym można 
sporządzić testament przed dowódcą statku lub jego zastępcą w ten sposób, że 
spadkodawca oświadcza swą wolę dowódcy statku lub jego zastępcy w obecności 
dwóch świadków; dowódca statku lub jego zastępca spisuje wolę spadkodawcy, 
podając datę jej spisania, i pismo to w obecności świadków odczytuje spadkodawcy, 
po czym pismo podpisują spadkodawca, świadkowie oraz dowódca statku lub jego 
zastępca. Jeżeli spadkodawca nie może podpisać pisma, należy w piśmie podać 
przyczynę braku podpisu spadkodawcy. Jeżeli zachowanie tej formy nie jest możliwe, 
można sporządzić testament ustny.

***
## Art. 954. {#art-954}

Szczególną formę testamentów wojskowych określi rozporządzenie 
Ministra Obrony Narodowej wydane w porozumieniu z Ministrem Sprawiedliwości.

***
## Art. 955. {#art-955}

Testament szczególny traci moc z upływem sześciu miesięcy od 
ustania okoliczności, które uzasadniały niezachowanie formy testamentu zwykłego, 
chyba że spadkodawca zmarł przed upływem tego terminu. Bieg terminu ulega 
zawieszeniu przez czas, w ciągu którego spadkodawca nie ma możności sporządzenia 
testamentu zwykłego. 

©Kancelaria Sejmu 
 
 
 
s. 215/242 
 
   
 
2025-09-09 
 
Oddział 3 
Przepisy wspólne dla testamentów zwykłych i szczególnych

***
## Art. 956. {#art-956}

Nie może być świadkiem przy sporządzaniu testamentu: 
- 1) kto nie ma pełnej zdolności do czynności prawnych; 
- 2) niewidomy, głuchy lub niemy; 
- 3) kto nie może czytać i pisać; 
- 4) kto nie włada językiem, w którym spadkodawca sporządza testament; 
- 5) skazany prawomocnie wyrokiem sądowym za fałszywe zeznania.

***
## Art. 957. {#art-957}

§ 1. Nie może być świadkiem przy sporządzaniu testamentu osoba, dla 
której w testamencie została przewidziana jakakolwiek korzyść. Nie mogą być 
również świadkami: małżonek tej osoby, jej krewni lub powinowaci pierwszego 
i drugiego stopnia oraz osoby pozostające z nią w stosunku przysposobienia. 
§ 2. Jeżeli świadkiem 
była jedna 
z osób wymienionych 
w paragrafie 
poprzedzającym, nieważne jest tylko postanowienie, które przysparza korzyści tej 
osobie, jej małżonkowi, krewnym lub powinowatym pierwszego lub drugiego stopnia 
albo osobie pozostającej z nią w stosunku przysposobienia. Jednakże gdy z treści 
testamentu lub z okoliczności wynika, że bez nieważnego postanowienia 
spadkodawca nie sporządziłby testamentu danej treści, nieważny jest cały testament.

***
## Art. 958. {#art-958}

Testament 
sporządzony 
z naruszeniem 
przepisów 
rozdziału 
niniejszego jest nieważny, chyba że przepisy te stanowią inaczej. 
## DZIAŁ II. Powołanie spadkobiercy

***
## Art. 959. {#art-959}

Spadkodawca może powołać do całości lub części spadku jedną lub 
kilka osób.

***
## Art. 960. {#art-960}

Jeżeli spadkodawca powołał do spadku lub do oznaczonej części 
spadku kilku spadkobierców, nie określając ich udziałów spadkowych, dziedziczą oni 
w częściach równych.

***
## Art. 961. {#art-961}

Jeżeli spadkodawca przeznaczył oznaczonej osobie w testamencie 
poszczególne przedmioty majątkowe, które wyczerpują prawie cały spadek, osobę tę 
poczytuje się w razie wątpliwości nie za zapisobiercę, lecz za spadkobiercę 

©Kancelaria Sejmu 
 
 
 
s. 216/242 
 
   
 
2025-09-09 
 
powołanego do całego spadku. Jeżeli takie rozrządzenie testamentowe zostało 
dokonane na rzecz kilku osób, osoby te poczytuje się w razie wątpliwości za powołane 
do całego spadku w częściach ułamkowych odpowiadających stosunkowi wartości 
przeznaczonych im przedmiotów.

***
## Art. 962. {#art-962}

Zastrzeżenie warunku lub terminu, uczynione przy powołaniu 
spadkobiercy testamentowego, uważane jest za nieistniejące. Jeżeli jednak z treści 
testamentu lub z okoliczności wynika, że bez takiego zastrzeżenia spadkobierca nie 
zostałby powołany, powołanie spadkobiercy jest nieważne. Przepisów tych nie stosuje 
się, jeżeli ziszczenie się lub nieziszczenie się warunku albo nadejście terminu nastąpiło 
przed otwarciem spadku.

***
## Art. 963. {#art-963}

Można powołać spadkobiercę testamentowego na wypadek, gdyby 
inna osoba powołana jako spadkobierca ustawowy lub testamentowy nie chciała lub 
nie mogła być spadkobiercą (podstawienie).

***
## Art. 964. {#art-964}

Postanowienie testamentu, przez które spadkodawca zobowiązuje 
spadkobiercę do zachowania nabytego spadku i do pozostawienia go innej osobie, ma 
tylko ten skutek, że ta inna osoba jest powołana do spadku na wypadek, gdyby 
spadkobierca nie chciał lub nie mógł być spadkobiercą. Jeżeli jednak z treści 
testamentu lub z okoliczności wynika, iż spadkobierca bez takiego ograniczenia nie 
byłby powołany, powołanie spadkobiercy jest nieważne.

***
## Art. 965. {#art-965}

Jeżeli spadkodawca powołał kilku spadkobierców testamentowych, 
a jeden z nich nie chce lub nie może być spadkobiercą, przeznaczony dla niego udział, 
w braku odmiennej woli spadkodawcy, przypada pozostałym spadkobiercom 
testamentowym w stosunku do przypadających im udziałów (przyrost).

***
## Art. 966. {#art-966}

Gdy 
na 
mocy 
testamentu 
spadek 
przypadł 
spadkobiercy 
nieobciążonemu ustawowym obowiązkiem alimentacyjnym względem dziadków 
spadkodawcy, dziadkowie, jeżeli znajdują się w niedostatku i nie mogą otrzymać 
środków utrzymania od osób, na których ciąży ustawowy obowiązek alimentacyjny, 
mogą żądać od spadkobiercy środków utrzymania w stosunku do swoich potrzeb i do 
wartości jego udziału spadkowego. Spadkobierca może uczynić zadość temu 
roszczeniu także w ten sposób, że zapłaci dziadkom spadkodawcy sumę pieniężną 
odpowiadającą wartości jednej czwartej części swego udziału spadkowego. 

©Kancelaria Sejmu 
 
 
 
s. 217/242 
 
   
 
2025-09-09

***
## Art. 967. {#art-967}

§ 1. Jeżeli osoba powołana jako spadkobierca testamentowy nie chce 
lub nie może być spadkobiercą, spadkobierca ustawowy, któremu przypadł 
przeznaczony dla tej osoby udział spadkowy, obowiązany jest, w braku odmiennej 
woli spadkodawcy, wykonać obciążające tę osobę zapisy zwykłe, polecenia i inne 
rozrządzenia spadkodawcy. 
§ 2. Przepis powyższy stosuje się odpowiednio do spadkobiercy podstawionego 
oraz do spadkobiercy, któremu przypada udział spadkowy z tytułu przyrostu. 
## DZIAŁ III. Zapis i polecenie 
## Rozdział I. Zapis zwykły

***
## Art. 968. {#art-968}

§ 1. Spadkodawca może przez rozrządzenie testamentowe zobowiązać 
spadkobiercę ustawowego lub testamentowego do spełnienia określonego świadczenia 
majątkowego na rzecz oznaczonej osoby (zapis zwykły). 
§ 2. Spadkodawca może obciążyć zapisem zwykłym także zapisobiercę (dalszy 
zapis).

***
## Art. 969. {#art-969}

(uchylony)

***
## Art. 970. {#art-970}

W braku odmiennej woli spadkodawcy zapisobierca może żądać 
wykonania zapisu niezwłocznie po ogłoszeniu testamentu. Jednakże zapisobierca 
obciążony dalszym zapisem może powstrzymać się z jego wykonaniem aż do chwili 
wykonania zapisu przez spadkobiercę.

***
## Art. 971. {#art-971}

Jeżeli spadek przypada kilku spadkobiercom, zapis obciąża ich 
w stosunku do wielkości ich udziałów spadkowych, chyba że spadkodawca postanowił 
inaczej. Przepis ten stosuje się odpowiednio do dalszego zapisu.

***
## Art. 972. {#art-972}

Przepisy o powołaniu spadkobiercy, o zdolności do dziedziczenia 
i o niegodności stosuje się odpowiednio do zapisów.

***
## Art. 973. {#art-973}

Jeżeli osoba, na której rzecz został uczyniony zapis, nie chce lub nie 
może być zapisobiercą, obciążony zapisem zostaje zwolniony od obowiązku jego 
wykonania, powinien jednak w braku odmiennej woli spadkodawcy wykonać dalsze 
zapisy. 

©Kancelaria Sejmu 
 
 
 
s. 218/242 
 
   
 
2025-09-09

***
## Art. 974. {#art-974}

Zapisobierca obciążony obowiązkiem wykonania dalszego zapisu 
może zwolnić się od tego obowiązku także w ten sposób, że dokona bezpłatnie na 
rzecz dalszego zapisobiercy przeniesienia praw otrzymanych z tytułu zapisu albo 
przelewu roszczenia o jego wykonanie.

***
## Art. 975. {#art-975}

Zapis może być uczyniony pod warunkiem lub z zastrzeżeniem 
terminu.

***
## Art. 976. {#art-976}

W braku odmiennej woli spadkodawcy zapis rzeczy oznaczonej co do 
tożsamości jest bezskuteczny, jeżeli rzecz zapisana nie należy do spadku w chwili jego 
otwarcia albo jeżeli spadkodawca był w chwili swej śmierci zobowiązany do zbycia 
tej rzeczy.

***
## Art. 977. {#art-977}

Jeżeli przedmiotem zapisu jest rzecz oznaczona co do tożsamości, do 
roszczeń zapisobiercy o wynagrodzenie za korzystanie z rzeczy, o zwrot pożytków lub 
o zapłatę ich wartości, jak również do roszczeń obciążonego zapisem o zwrot 
nakładów na rzecz stosuje się odpowiednio przepisy o roszczeniach między 
właścicielem a samoistnym posiadaczem rzeczy.

***
## Art. 978. {#art-978}

Jeżeli przedmiotem zapisu jest rzecz oznaczona co do tożsamości, 
obciążony zapisem ponosi względem zapisobiercy odpowiedzialność za wady rzeczy 
jak darczyńca.

***
## Art. 979. {#art-979}

Jeżeli przedmiotem zapisu są rzeczy oznaczone tylko co do gatunku, 
obciążony powinien świadczyć rzeczy średniej jakości, uwzględniając przy tym 
potrzeby zapisobiercy.

***
## Art. 980. {#art-980}

Jeżeli przedmiotem zapisu są rzeczy oznaczone tylko co do gatunku, 
do odpowiedzialności obciążonego względem zapisobiercy za wady fizyczne i prawne 
rzeczy stosuje się odpowiednio przepisy o rękojmi przy sprzedaży. Jednakże 
zapisobierca może żądać od obciążonego zapisem tylko odszkodowania za nienależyte 
wykonanie zapisu albo dostarczenia zamiast rzeczy wadliwych rzeczy takiego samego 
gatunku wolnych od wad oraz naprawienia szkody wynikłej z opóźnienia.

***
## Art. 981. {#art-981}

Roszczenie z tytułu zapisu przedawnia się z upływem lat pięciu od dnia 
wymagalności zapisu. 

©Kancelaria Sejmu 
 
 
 
s. 219/242 
 
   
 
2025-09-09 
## Rozdział II. Zapis windykacyjny

***
## Art. 9811. {#art-9811}

§ 1. W testamencie sporządzonym w formie aktu notarialnego 
spadkodawca może postanowić, że oznaczona osoba nabywa przedmiot zapisu 
z chwilą otwarcia spadku (zapis windykacyjny). 
§ 2. Przedmiotem zapisu windykacyjnego może być: 
- 1) rzecz oznaczona co do tożsamości; 
- 2) zbywalne prawo majątkowe; 
- 3) przedsiębiorstwo lub gospodarstwo rolne; 
- 4) ustanowienie na rzecz zapisobiercy użytkowania lub służebności; 
- 5) ogół praw i obowiązków wspólnika spółki osobowej.

***
## Art. 9812. {#art-9812}

Zapis windykacyjny jest bezskuteczny, jeżeli w chwili otwarcia 
spadku przedmiot zapisu nie należy do spadkodawcy albo spadkodawca był 
zobowiązany do jego zbycia. Jeżeli przedmiotem zapisu jest ustanowienie dla 
zapisobiercy użytkowania lub służebności, zapis jest bezskuteczny, gdy w chwili 
otwarcia spadku przedmiot majątkowy, który miał być obciążony użytkowaniem lub 
służebnością nie należy do spadku albo spadkodawca był zobowiązany do jego zbycia.

***
## Art. 9813. {#art-9813}

§ 1. Zastrzeżenie warunku lub terminu uczynione przy ustanawianiu 
zapisu windykacyjnego uważa się za nieistniejące. Jeżeli jednak z treści testamentu 
lub z okoliczności wynika, że bez takiego zastrzeżenia zapis nie zostałby uczyniony, 
zapis windykacyjny jest nieważny. Przepisów tych nie stosuje się, jeżeli ziszczenie się 
lub nieziszczenie się warunku albo nadejście terminu nastąpiło przed otwarciem 
spadku. 
§ 2. Zapis windykacyjny nieważny ze względu na zastrzeżenie warunku lub 
terminu wywołuje skutki zapisu zwykłego uczynionego pod warunkiem lub 
z zastrzeżeniem terminu, chyba że co innego wynika z treści testamentu lub z okolicz-
ności.

***
## Art. 9814. {#art-9814}

Spadkodawca może obciążyć zapisem zwykłym osobę, na której rzecz 
uczynił zapis windykacyjny. 

©Kancelaria Sejmu 
 
 
 
s. 220/242 
 
   
 
2025-09-09

***
## Art. 9815. {#art-9815}

Przepisy o powołaniu spadkobiercy, przyjęciu i odrzuceniu spadku, 
o zdolności do dziedziczenia i o niegodności stosuje się odpowiednio do zapisów 
windykacyjnych.

***
## Art. 9816. {#art-9816}

W sprawach 
nieuregulowanych 
w niniejszym 
rozdziale 
oraz 
w przepisach szczególnych do zapisu windykacyjnego stosuje się odpowiednio 
przepisy o zapisie zwykłym. 
## Rozdział III. Polecenie

***
## Art. 982. {#art-982}

Spadkodawca może w testamencie włożyć na spadkobiercę lub na 
zapisobiercę obowiązek oznaczonego działania lub zaniechania, nie czyniąc nikogo 
wierzycielem (polecenie).

***
## Art. 983. {#art-983}

Zapisobierca obciążony poleceniem może powstrzymać się z jego 
wykonaniem aż do chwili wykonania zapisu przez spadkobiercę. Przepis ten stosuje 
się odpowiednio w wypadku, gdy polecenie obciąża dalszego zapisobiercę.

***
## Art. 984. {#art-984}

Jeżeli osoba, na której rzecz został uczyniony zapis z obowiązkiem 
wykonania polecenia, nie chce lub nie może być zapisobiercą, spadkobierca zwolniony 
od obowiązku wykonania zapisu powinien w braku odmiennej woli spadkodawcy 
polecenie wykonać. Przepis ten stosuje się odpowiednio w wypadku, gdy polecenie 
obciąża dalszego zapisobiercę.

***
## Art. 985. {#art-985}

Wykonania polecenia może żądać każdy ze spadkobierców, jak 
również wykonawca testamentu, chyba że polecenie ma wyłącznie na celu korzyść 
obciążonego poleceniem. Jeżeli polecenie ma na względzie interes społeczny, 
wykonania polecenia może żądać także właściwy organ państwowy. 
## DZIAŁ IV. Wykonawca testamentu

***
## Art. 986. {#art-986}

§ 1. Spadkodawca może w testamencie powołać wykonawcę lub 
wykonawców testamentu. 
§ 2. Nie może być wykonawcą testamentu, kto nie ma pełnej zdolności do 
czynności prawnych. 

©Kancelaria Sejmu 
 
 
 
s. 221/242 
 
   
 
2025-09-09

***
## Art. 9861. {#art-9861}

Spadkodawca może powołać wykonawcę testamentu do sprawowania 
zarządu spadkiem, jego zorganizowaną częścią lub oznaczonym składnikiem.

***
## Art. 987. {#art-987}

Jeżeli osoba powołana jako wykonawca testamentu nie chce tego 
obowiązku przyjąć, składa odpowiednie oświadczenie przed sądem albo notariuszem.

***
## Art. 988. {#art-988}

§ 1. Jeżeli spadkodawca nie postanowił inaczej, wykonawca 
testamentu powinien zarządzać majątkiem spadkowym, spłacić długi spadkowe, 
w szczególności 
wykonać 
zapisy 
zwykłe 
i polecenia, 
a następnie 
wydać 
spadkobiercom majątek spadkowy zgodnie z wolą spadkodawcy i z ustawą, 
a w każdym razie niezwłocznie po dokonaniu działu spadku. 
§ 2. Wykonawca testamentu może pozywać i być pozywany w sprawach 
wynikających z zarządu spadkiem, jego zorganizowaną częścią lub oznaczonym 
składnikiem. Może również pozywać w sprawach o prawa należące do spadku i być 
pozwany w sprawach o długi spadkowe. 
§ 3. Wykonawca testamentu powinien wydać osobie, na której rzecz został 
uczyniony zapis windykacyjny, przedmiot tego zapisu.

***
## Art. 989. {#art-989}

§ 1. Do wzajemnych roszczeń między spadkobiercą a wykonawcą 
testamentu wynikających ze sprawowania zarządu spadkiem, jego zorganizowaną 
częścią lub oznaczonym składnikiem stosuje się odpowiednio przepisy o zleceniu za 
wynagrodzeniem. 
§ 2. Koszty zarządu majątkiem spadkowym, jego zorganizowaną częścią lub 
oznaczonym składnikiem oraz wynagrodzenie wykonawcy testamentu należą do 
długów spadkowych.

***
## Art. 990. {#art-990}

Z ważnych powodów sąd może zwolnić wykonawcę testamentu.

***
## Art. 9901. {#art-9901}

Spadkodawca może powołać wykonawcę testamentu do sprawowania 
zarządu przedmiotem zapisu windykacyjnego, do chwili objęcia we władanie tego 
przedmiotu przez osobę, na której rzecz uczyniono zapis windykacyjny. 
TYTUŁ IV 
Zachowek

***
## Art. 991. {#art-991}

§ 1. Zstępnym, małżonkowi oraz rodzicom spadkodawcy, którzy 
byliby powołani do spadku z ustawy, należą się, jeżeli uprawniony jest trwale 

©Kancelaria Sejmu 
 
 
 
s. 222/242 
 
   
 
2025-09-09 
 
niezdolny do pracy albo jeżeli zstępny uprawniony jest małoletni – dwie trzecie war-
tości udziału spadkowego, który by mu przypadał przy dziedziczeniu ustawowym, 
w innych zaś wypadkach – połowa wartości tego udziału (zachowek). 
§ 2. Jeżeli uprawniony nie otrzymał należnego mu zachowku bądź w postaci 
uczynionej przez spadkodawcę darowizny, bądź w postaci powołania do spadku, bądź 
w postaci zapisu, bądź w postaci świadczenia od fundacji rodzinnej lub mienia 
w związku z rozwiązaniem fundacji rodzinnej, przysługuje mu przeciwko 
spadkobiercy roszczenie o zapłatę sumy pieniężnej potrzebnej do pokrycia zachowku 
albo do jego uzupełnienia.

***
## Art. 992. {#art-992}

Przy ustalaniu udziału spadkowego stanowiącego podstawę do 
obliczania zachowku uwzględnia się także spadkobierców niegodnych oraz 
spadkobierców, którzy spadek odrzucili, natomiast nie uwzględnia się spadkobierców, 
którzy zrzekli się dziedziczenia albo zostali wydziedziczeni.

***
## Art. 993. {#art-993}

§ 1. Przy obliczaniu zachowku nie uwzględnia się zapisów zwykłych 
i poleceń, natomiast dolicza się do spadku, stosownie do przepisów poniższych, 
darowizny oraz zapisy windykacyjne dokonane przez spadkodawcę. 
§ 2. Przy obliczaniu zachowku dolicza się także do spadku, stosownie do 
przepisów poniższych, fundusz założycielski fundacji rodzinnej wniesiony przez 
spadkodawcę, w przypadku gdy fundacja ta nie jest ustanowiona w testamencie. 
§ 3. Przy obliczaniu zachowku dolicza się także do spadku, stosownie do 
przepisów poniższych, mienie w związku z rozwiązaniem fundacji rodzinnej, 
o wartości nie większej niż wysokość funduszu założycielskiego fundacji rodzinnej 
wniesionego przez spadkodawcę.

***
## Art. 994. {#art-994}

§ 1. Przy obliczaniu zachowku nie dolicza się do spadku drobnych 
darowizn, zwyczajowo w danych stosunkach przyjętych, ani dokonanych przed więcej 
niż dziesięciu laty, licząc wstecz od otwarcia spadku, darowizn na rzecz osób 
niebędących spadkobiercami albo uprawnionymi do zachowku. 
§ 2. Przy obliczaniu zachowku należnego zstępnemu nie dolicza się do spadku 
darowizn uczynionych przez spadkodawcę w czasie, kiedy nie miał zstępnych. Nie 
dotyczy to jednak wypadku, gdy darowizna została uczyniona na mniej niż trzysta dni 
przed urodzeniem się zstępnego. 

©Kancelaria Sejmu 
 
 
 
s. 223/242 
 
   
 
2025-09-09 
 
§ 3. Przy obliczaniu zachowku należnego małżonkowi nie dolicza się do spadku 
darowizn, które spadkodawca uczynił przed zawarciem z nim małżeństwa.

***
## Art. 9941. {#art-9941}

§ 1. Przy obliczaniu zachowku nie dolicza się do spadku funduszu 
założycielskiego fundacji rodzinnej wniesionego przed więcej niż dziesięciu laty, 
licząc wstecz od otwarcia spadku, chyba że fundacja rodzinna jest spadkobiercą. 
§ 2. Przy obliczaniu zachowku nie dolicza się do spadku mienia w związku 
z rozwiązaniem 
fundacji 
rodzinnej 
otrzymanego 
przez 
osoby 
niebędące 
spadkobiercami albo uprawnionymi do zachowku przed więcej niż dziesięciu laty, 
licząc wstecz od otwarcia spadku. 
§ 3. Przy obliczaniu zachowku należnego zstępnemu nie dolicza się do spadku 
funduszu założycielskiego fundacji rodzinnej i mienia w związku z rozwiązaniem 
fundacji rodzinnej, jeśli ich przekazanie nastąpiło w czasie, kiedy spadkodawca nie 
miał zstępnych. Nie dotyczy to jednak wypadku, gdy przekazanie nastąpiło na mniej 
niż trzysta dni przed urodzeniem się zstępnego. 
§ 4. Przy obliczaniu zachowku należnego małżonkowi nie dolicza się do spadku 
funduszu założycielskiego fundacji rodzinnej i mienia w związku z rozwiązaniem 
fundacji rodzinnej przekazanych przed zawarciem małżeństwa ze spadkodawcą.

***
## Art. 995. {#art-995}

§ 1. Wartość przedmiotu darowizny oblicza się według stanu z chwili 
jej dokonania, a według cen z chwili ustalania zachowku. 
§ 2. Wartość przedmiotu zapisu windykacyjnego oblicza się według stanu 
z chwili otwarcia spadku, a według cen z chwili ustalania zachowku. 
§ 3. Wartość funduszu założycielskiego fundacji rodzinnej i mienia w związku 
z rozwiązaniem fundacji rodzinnej oblicza się według stanu z chwili ich przekazania, 
a według cen z chwili ustalania zachowku. W przypadku mienia w związku 
z rozwiązaniem fundacji rodzinnej w pierwszej kolejności oblicza się wartość 
funduszu założycielskiego i wartość mienia w związku z rozwiązaniem fundacji 
rodzinnej, a następnie porównuje się obie wartości, z uwzględnieniem art. 993 § 3.

***
## Art. 996. {#art-996}

§ 1. Zapis windykacyjny oraz darowiznę dokonane przez spadkodawcę 
na rzecz uprawnionego do zachowku zalicza się na należny mu zachowek. Jeżeli 
uprawnionym do zachowku jest dalszy zstępny spadkodawcy, zalicza się na należny 
mu zachowek także zapis windykacyjny oraz darowiznę dokonane przez spadkodawcę 
na rzecz jego wstępnego. 

©Kancelaria Sejmu 
 
 
 
s. 224/242 
 
   
 
2025-09-09 
 
§ 2. Świadczenie od fundacji rodzinnej i mienie w związku z rozwiązaniem 
fundacji rodzinnej przekazane na rzecz uprawnionego do zachowku zalicza się na 
należny mu zachowek. Jeżeli uprawnionym do zachowku jest dalszy zstępny 
spadkodawcy, zalicza się na należny mu zachowek także świadczenie od fundacji 
rodzinnej i mienie w związku z rozwiązaniem fundacji rodzinnej na rzecz jego 
wstępnego.

***
## Art. 997. {#art-997}

§ 1. Jeżeli uprawnionym do zachowku jest zstępny spadkodawcy, 
zalicza się na należny mu zachowek poniesione przez spadkodawcę koszty 
wychowania oraz wykształcenia ogólnego i zawodowego, o ile koszty te przekraczają 
przeciętną miarę przyjętą w danym środowisku. 
§ 2. Jeżeli uprawnionym do zachowku jest zstępny spadkodawcy, zalicza się na 
należny mu zachowek koszty zrealizowanego przez fundację rodzinną obowiązku 
alimentacyjnego ciążącego na spadkodawcy, o ile koszty te przekraczają przeciętną 
miarę przyjętą w danym środowisku.

***
## Art. 9971. {#art-9971}

§ 1. Obowiązany do zaspokojenia roszczenia z tytułu zachowku może 
żądać odroczenia terminu jego płatności, rozłożenia go na raty, a w wyjątkowych 
przypadkach – jego obniżenia, przy uwzględnieniu sytuacji osobistej i majątkowej 
uprawnionego do zachowku oraz obowiązanego do zaspokojenia roszczenia z tytułu 
zachowku. 
§ 2. W przypadku rozłożenia na raty roszczenia z tytułu zachowku terminy 
ich uiszczenia nie mogą przekraczać łącznie pięciu lat. W wypadkach zasługujących 
na szczególne uwzględnienie sąd, na wniosek zobowiązanego, może odroczyć termin 
zapłaty rat już wymagalnych lub przedłużyć termin, o którym mowa w zdaniu 
pierwszym. Zmieniony termin nie może być dłuższy niż dziesięć lat. 
§ 3. W razie ustania okoliczności uzasadniających obniżenie zachowku 
obowiązany z tytułu zachowku na wniosek osoby uprawnionej do zachowku zwraca 
uprawnionemu do zachowku sumę pieniężną, o którą obniżono zachowek. Zwrotu 
sumy pieniężnej nie można żądać po upływie pięciu lat od dnia obniżenia zachowku.

***
## Art. 998. {#art-998}

§ 1. Jeżeli uprawniony do zachowku jest powołany do dziedziczenia, 
ponosi on odpowiedzialność za zapisy zwykłe i polecenia tylko do wysokości 
nadwyżki przekraczającej wartość udziału spadkowego, który stanowi podstawę do 
obliczenia należnego uprawnionemu zachowku. 

©Kancelaria Sejmu 
 
 
 
s. 225/242 
 
   
 
2025-09-09 
 
§ 2. Przepis powyższy stosuje się odpowiednio w wypadku, gdy zapis zwykły na 
rzecz uprawnionego do zachowku został obciążony dalszym zapisem lub poleceniem 
albo uczyniony pod warunkiem lub z zastrzeżeniem terminu.

***
## Art. 999. {#art-999}

Jeżeli spadkobierca obowiązany do zapłaty zachowku jest sam 
uprawniony do zachowku, jego odpowiedzialność ogranicza się tylko do wysokości 
nadwyżki przekraczającej jego własny zachowek.

***
## Art. 9991. {#art-9991}

§ 1. Jeżeli uprawniony nie może otrzymać od spadkobiercy należnego 
mu zachowku, może on żądać od osoby, na której rzecz został uczyniony zapis 
windykacyjny doliczony do spadku, sumy pieniężnej potrzebnej do uzupełnienia 
zachowku. Jednakże osoba ta jest obowiązana do zapłaty powyższej sumy tylko 
w granicach wzbogacenia będącego skutkiem zapisu windykacyjnego. 
§ 2. Jeżeli osoba, na której rzecz został uczyniony zapis windykacyjny, sama jest 
uprawniona do zachowku, ponosi ona odpowiedzialność względem innych 
uprawnionych do zachowku tylko do wysokości nadwyżki przekraczającej jej własny 
zachowek. 
§ 3. Osoba, na której rzecz został uczyniony zapis windykacyjny, może zwolnić 
się od obowiązku zapłaty sumy potrzebnej do uzupełnienia zachowku przez wydanie 
przedmiotu zapisu. 
§ 4. Jeżeli spadkodawca uczynił zapisy windykacyjne na rzecz kilku osób, ich 
odpowiedzialność względem uprawnionego do zachowku jest solidarna. Jeżeli jedna 
z osób, na których rzecz zostały uczynione zapisy windykacyjne, spełniła świadczenie 
uprawnionemu do zachowku, może ona żądać od pozostałych osób części świadczenia 
proporcjonalnych do wartości otrzymanych zapisów windykacyjnych.

***
## Art. 1000. {#art-1000}

§ 1. Jeżeli uprawniony nie może otrzymać należnego mu zachowku 
od spadkobiercy lub osoby, na której rzecz został uczyniony zapis windykacyjny, 
może on żądać od osoby, która otrzymała od spadkodawcy darowiznę doliczoną do 
spadku, sumy pieniężnej potrzebnej do uzupełnienia zachowku. Jednakże obdarowany 
jest obowiązany do zapłaty powyższej sumy tylko w granicach wzbogacenia będącego 
skutkiem darowizny. 
§ 2. Jeżeli obdarowany sam jest uprawniony do zachowku, ponosi on 
odpowiedzialność względem innych uprawnionych do zachowku tylko do wysokości 
nadwyżki przekraczającej jego własny zachowek. 

©Kancelaria Sejmu 
 
 
 
s. 226/242 
 
   
 
2025-09-09 
 
§ 3. Obdarowany może zwolnić się od obowiązku zapłaty sumy potrzebnej do 
uzupełnienia zachowku przez wydanie przedmiotu darowizny. 
§ 4. Jeżeli uprawniony nie może otrzymać należnego mu zachowku od 
spadkobiercy lub osoby, na której rzecz został uczyniony zapis windykacyjny, może 
on żądać od fundacji rodzinnej, której fundusz założycielski doliczono do spadku, 
sumy pieniężnej potrzebnej do uzupełnienia zachowku. Jednakże fundacja rodzinna 
jest obowiązana do zapłaty powyższej sumy tylko w granicach wzbogacenia będącego 
skutkiem pokrycia funduszu założycielskiego przez spadkodawcę. 
§ 5. Jeżeli uprawniony nie może otrzymać należnego mu zachowku od 
spadkobiercy lub osoby, na której rzecz został uczyniony zapis windykacyjny, może 
on żądać od osoby, która otrzymała mienie w związku z rozwiązaniem fundacji 
rodzinnej doliczone do spadku, sumy pieniężnej potrzebnej do uzupełnienia 
zachowku. Jednakże osoba, która otrzymała mienie w związku z rozwiązaniem 
fundacji rodzinnej, jest obowiązana do zapłaty powyższej sumy tylko w granicach 
wzbogacenia będącego skutkiem otrzymania mienia w związku z rozwiązaniem 
fundacji rodzinnej. 
§ 6. Jeżeli osoba, która otrzymała mienie w związku z rozwiązaniem fundacji 
rodzinnej sama jest uprawniona do zachowku, ponosi ona odpowiedzialność 
względem innych uprawnionych do zachowku tylko do wysokości nadwyżki prze-
kraczającej jej własny zachowek. 
§ 7. Osoba, która otrzymała mienie w związku z rozwiązaniem fundacji 
rodzinnej, może zwolnić się od obowiązku zapłaty sumy potrzebnej do uzupełnienia 
zachowku przez wydanie tego mienia.

***
## Art. 1001. {#art-1001}

§ 1. Spośród kilku obdarowanych obdarowany wcześniej ponosi 
odpowiedzialność stosownie do przepisów artykułu poprzedzającego tylko wtedy, gdy 
uprawniony do zachowku nie może uzyskać uzupełnienia zachowku od osoby, która 
została obdarowana później. 
§ 2. Spośród osób, które otrzymały mienie w związku z rozwiązaniem fundacji 
rodzinnej, osoba otrzymująca mienie wcześniej ponosi odpowiedzialność stosownie 
do przepisów artykułu poprzedzającego tylko wtedy, gdy uprawniony do zachowku 
nie może uzyskać uzupełnienia zachowku od osoby, która otrzymała mienie później. 

©Kancelaria Sejmu 
 
 
 
s. 227/242 
 
   
 
2025-09-09

***
## Art. 1002. {#art-1002}

Roszczenie z tytułu zachowku przechodzi na spadkobiercę osoby 
uprawnionej do zachowku tylko wtedy, gdy spadkobierca ten należy do osób 
uprawnionych do zachowku po pierwszym spadkodawcy.

***
## Art. 1003. {#art-1003}

Spadkobiercy obowiązani do zaspokojenia roszczenia z tytułu 
zachowku mogą żądać stosunkowego zmniejszenia zapisów zwykłych i poleceń.

***
## Art. 1004. {#art-1004}

§ 1. Zmniejszenie zapisów zwykłych i poleceń następuje w stosunku 
do ich wartości, chyba że z treści testamentu wynika odmienna wola spadkodawcy. 
§ 2. W razie zmniejszenia zapisu zwykłego obciążonego dalszym zapisem lub 
poleceniem, dalszy zapis lub polecenie podlega stosunkowemu zmniejszeniu.

***
## Art. 1005. {#art-1005}

§ 1. Jeżeli spadkobierca obowiązany do zaspokojenia roszczenia 
z tytułu zachowku sam jest uprawniony do zachowku, może on żądać zmniejszenia 
zapisów zwykłych i poleceń w takim stopniu, ażeby pozostał mu jego własny 
zachowek. 
§ 2. Jeżeli zapisobierca sam jest uprawniony do zachowku, zapis zwykły 
uczyniony na jego rzecz podlega zmniejszeniu tylko do wysokości nadwyżki 
przekraczającej jego własny zachowek.

***
## Art. 1006. {#art-1006}

Jeżeli zmniejszeniu podlega zapis zwykły, którego przedmiot nie da 
się podzielić bez istotnej zmiany lub bez znacznego zmniejszenia wartości, 
zapisobierca może żądać całkowitego wykonania zapisu, uiszczając odpowiednią 
sumę pieniężną.

***
## Art. 1007. {#art-1007}

§ 1. Roszczenia uprawnionego z tytułu zachowku oraz roszczenia 
spadkobierców o zmniejszenie zapisów zwykłych i poleceń przedawniają się 
z upływem lat pięciu od ogłoszenia testamentu. 
§ 2. Roszczenie przeciwko osobie obowiązanej do uzupełnienia zachowku 
z tytułu otrzymanych od spadkodawcy zapisu windykacyjnego lub darowizny 
przedawnia się z upływem lat pięciu od otwarcia spadku. 
§ 3. Roszczenie przeciwko fundacji rodzinnej obowiązanej do uzupełnienia 
zachowku z tytułu otrzymanego funduszu założycielskiego przedawnia się z upływem 
lat pięciu od otwarcia spadku. 
§ 4. Roszczenie przeciwko osobie obowiązanej do uzupełnienia zachowku 
z tytułu otrzymanego mienia w związku z rozwiązaniem fundacji rodzinnej 
przedawnia się z upływem lat pięciu od otwarcia spadku. 

©Kancelaria Sejmu 
 
 
 
s. 228/242 
 
   
 
2025-09-09

***
## Art. 1008. {#art-1008}

Spadkodawca może w testamencie pozbawić zstępnych, małżonka 
i rodziców zachowku (wydziedziczenie), jeżeli uprawniony do zachowku: 
- 1) wbrew woli spadkodawcy postępuje uporczywie w sposób sprzeczny z zasadami 
współżycia społecznego; 
- 2) dopuścił się względem spadkodawcy albo jednej z najbliższych mu osób 
umyślnego przestępstwa przeciwko życiu, zdrowiu lub wolności albo rażącej 
obrazy czci; 
- 3) uporczywie nie dopełnia względem spadkodawcy obowiązków rodzinnych.

***
## Art. 1009. {#art-1009}

Przyczyna wydziedziczenia uprawnionego do zachowku powinna 
wynikać z treści testamentu.

***
## Art. 1010. {#art-1010}

§ 1. Spadkodawca nie może wydziedziczyć uprawnionego do 
zachowku, jeżeli mu przebaczył. 
§ 2. Jeżeli w chwili przebaczenia spadkodawca nie miał zdolności do czynności 
prawnych, przebaczenie jest skuteczne, gdy nastąpiło z dostatecznym rozeznaniem.

***
## Art. 1011. {#art-1011}

Zstępni wydziedziczonego zstępnego są uprawnieni do zachowku, 
chociażby przeżył on spadkodawcę. 
TYTUŁ V 
Przyjęcie i odrzucenie spadku

***
## Art. 1012. {#art-1012}

Spadkobierca może bądź przyjąć spadek bez ograniczenia 
odpowiedzialności za długi (przyjęcie proste), bądź przyjąć spadek z ograniczeniem 
tej odpowiedzialności (przyjęcie z dobrodziejstwem inwentarza), bądź też spadek 
odrzucić.

***
## Art. 1013. {#art-1013}

(uchylony)

***
## Art. 1014. {#art-1014}

§ 1. Przyjęcie lub odrzucenie udziału spadkowego przypadającego 
spadkobiercy z tytułu podstawienia może nastąpić niezależnie od przyjęcia lub 
odrzucenia udziału spadkowego, który temu spadkobiercy przypada z innego tytułu. 
§ 2. Spadkobierca może odrzucić udział spadkowy przypadający mu z tytułu 
przyrostu, a przyjąć udział przypadający mu jako spadkobiercy powołanemu. 
§ 3. Poza 
wypadkami 
przewidzianymi 
w paragrafach 
poprzedzających 
spadkobierca nie może spadku częściowo przyjąć, a częściowo odrzucić. 

©Kancelaria Sejmu 
 
 
 
s. 229/242 
 
   
 
2025-09-09

***
## Art. 1015. {#art-1015}

§ 1. Oświadczenie o przyjęciu lub o odrzuceniu spadku może być 
złożone w ciągu sześciu miesięcy od dnia, w którym spadkobierca dowiedział się 
o tytule swego powołania. 
§ 11. Do zachowania terminu, o którym mowa w § 1, wystarcza złożenie przed 
jego upływem wniosku do sądu o odebranie oświadczenia o przyjęciu lub 
o odrzuceniu spadku. 
§ 12. Jeżeli złożenie oświadczenia o przyjęciu lub o odrzuceniu spadku wymaga 
zezwolenia sądu, bieg terminu do złożenia oświadczenia ulega zawieszeniu na czas 
trwania postępowania sądowego w tym przedmiocie. 
§ 2. Brak oświadczenia spadkobiercy w terminie określonym w § 1 jest 
jednoznaczny z przyjęciem spadku z dobrodziejstwem inwentarza.

***
## Art. 1016. {#art-1016}

(uchylony)

***
## Art. 1017. {#art-1017}

Jeżeli przed upływem terminu do złożenia oświadczenia o przyjęciu 
lub o odrzuceniu spadku spadkobierca zmarł nie złożywszy takiego oświadczenia, 
oświadczenie o przyjęciu lub o odrzuceniu spadku może być złożone przez jego 
spadkobierców. Termin do złożenia tego oświadczenia nie może się skończyć 
wcześniej aniżeli termin do złożenia oświadczenia co do spadku po zmarłym 
spadkobiercy.

***
## Art. 1018. {#art-1018}

§ 1. Oświadczenie o przyjęciu lub o odrzuceniu spadku złożone pod 
warunkiem lub z zastrzeżeniem terminu jest nieważne. 
§ 2. Oświadczenie o przyjęciu lub o odrzuceniu spadku nie może być odwołane. 
§ 3. Oświadczenie o przyjęciu lub o odrzuceniu spadku składa się przed sądem 
lub przed notariuszem. Można je złożyć ustnie lub na piśmie z podpisem urzędowo 
poświadczonym. Pełnomocnictwo do złożenia oświadczenia o przyjęciu lub 
o odrzuceniu spadku powinno być pisemne z podpisem urzędowo poświadczonym.

***
## Art. 1019. {#art-1019}

§ 1. Jeżeli oświadczenie o przyjęciu lub o odrzuceniu spadku zostało 
złożone pod wpływem błędu lub groźby, stosuje się przepisy o wadach oświadczenia 
woli z następującymi zmianami: 
- 1) uchylenie się od skutków prawnych oświadczenia powinno nastąpić przed 
sądem; 
- 2) spadkobierca powinien jednocześnie oświadczyć, czy i jak spadek przyjmuje, 
czy też go odrzuca; 

©Kancelaria Sejmu 
 
 
 
s. 230/242 
 
   
 
2025-09-09 
- 3) do zachowania terminu, o którym mowa w art. 88 § 2, wystarcza złożenie przed 
jego upływem wniosku do sądu o odebranie oświadczenia o uchyleniu się od 
skutków prawnych oświadczenia. 
§ 2. Spadkobierca, który pod wpływem błędu lub groźby nie złożył żadnego 
oświadczenia w terminie, może w powyższy sposób uchylić się od skutków prawnych 
niezachowania terminu. 
§ 3. Uchylenie się od skutków prawnych oświadczenia o przyjęciu lub 
o odrzuceniu spadku wymaga zatwierdzenia przez sąd.

***
## Art. 1020. {#art-1020}

Spadkobierca, który spadek odrzucił, zostaje wyłączony od 
dziedziczenia, tak jakby nie dożył otwarcia spadku.

***
## Art. 1021. {#art-1021}

Jeżeli spadkobierca zarządzał spadkiem, a potem go odrzucił, do 
stosunków między nim a spadkobiercami, którzy zamiast niego doszli do spadku, 
stosuje się odpowiednio przepisy o prowadzeniu cudzych spraw bez zlecenia.

***
## Art. 1022. {#art-1022}

Spadkobierca powołany do spadku zarówno z mocy testamentu, jak 
i z mocy ustawy może spadek odrzucić jako spadkobierca testamentowy, a przyjąć 
spadek jako spadkobierca ustawowy.

***
## Art. 1023. {#art-1023}

§ 1. Skarb Państwa ani gmina nie mogą odrzucić spadku, który im 
przypadł z mocy ustawy. 
§ 2. Skarb Państwa ani gmina nie składają oświadczenia o przyjęciu spadku, 
a spadek uważa się za przyjęty z dobrodziejstwem inwentarza.

***
## Art. 1024. {#art-1024}

§ 1. Jeżeli 
spadkobierca 
odrzucił 
spadek 
z pokrzywdzeniem 
wierzycieli, każdy z wierzycieli, którego wierzytelność istniała w chwili odrzucenia 
spadku, może żądać, ażeby odrzucenie spadku zostało uznane za bezskuteczne 
w stosunku 
do 
niego 
według 
przepisów 
o ochronie 
wierzycieli 
w razie 
niewypłacalności dłużnika. 
§ 2. Uznania odrzucenia spadku za bezskuteczne można żądać w ciągu sześciu 
miesięcy od chwili powzięcia wiadomości o odrzuceniu spadku, lecz nie później niż 
przed upływem trzech lat od odrzucenia spadku. 

©Kancelaria Sejmu 
 
 
 
s. 231/242 
 
   
 
2025-09-09 
 
TYTUŁ VI 
Stwierdzenie nabycia spadku lub przedmiotu zapisu 
windykacyjnego, poświadczenie dziedziczenia i ochrona spadkobiercy

***
## Art. 1025. {#art-1025}

§ 1. Sąd na wniosek osoby mającej w tym interes stwierdza nabycie 
spadku przez spadkobiercę. Notariusz na zasadach określonych w przepisach 
odrębnych sporządza akt poświadczenia dziedziczenia. 
§ 2. Domniemywa się, że osoba, która uzyskała stwierdzenie nabycia spadku 
albo poświadczenie dziedziczenia, jest spadkobiercą. 
§ 3. Przeciwko domniemaniu wynikającemu ze stwierdzenia nabycia spadku nie 
można powoływać się na domniemanie wynikające z zarejestrowanego aktu 
poświadczenia dziedziczenia.

***
## Art. 1026. {#art-1026}

Stwierdzenie nabycia spadku oraz poświadczenie dziedziczenia nie 
może nastąpić przed upływem sześciu miesięcy od otwarcia spadku, chyba że wszyscy 
znani spadkobiercy złożyli już oświadczenia o przyjęciu lub o odrzuceniu spadku.

***
## Art. 1027. {#art-1027}

Względem osoby trzeciej, która nie rości sobie praw do spadku 
z tytułu dziedziczenia, spadkobierca może udowodnić swoje prawa wynikające 
z dziedziczenia tylko stwierdzeniem nabycia spadku albo zarejestrowanym aktem 
poświadczenia dziedziczenia.

***
## Art. 1028. {#art-1028}

Jeżeli ten, kto uzyskał stwierdzenie nabycia spadku albo 
poświadczenie dziedziczenia, lecz spadkobiercą nie jest, rozporządza prawem 
należącym do spadku na rzecz osoby trzeciej, osoba, na której rzecz rozporządzenie 
następuje, nabywa prawo lub zostaje zwolniona od obowiązku, chyba że działa w złej 
wierze.

***
## Art. 1029. {#art-1029}

§ 1. Spadkobierca może żądać, ażeby osoba, która włada spadkiem 
jako spadkobierca, lecz spadkobiercą nie jest, wydała mu spadek. To samo dotyczy 
poszczególnych przedmiotów należących do spadku. 
§ 2. Do roszczeń spadkobiercy o wynagrodzenie za korzystanie z przedmiotów 
należących do spadku, o zwrot pożytków lub o zapłatę ich wartości, jak również 
o naprawienie szkody z powodu zużycia, pogorszenia lub utraty tych przedmiotów 
oraz do roszczeń przeciwko spadkobiercy o zwrot nakładów stosuje się odpowiednio 
przepisy o roszczeniach między właścicielem a samoistnym posiadaczem rzeczy. 

©Kancelaria Sejmu 
 
 
 
s. 232/242 
 
   
 
2025-09-09 
 
§ 3. Przepisy powyższe stosuje się odpowiednio w wypadku, gdy żąda wydania 
swego majątku osoba, co do której zostało uchylone orzeczenie o uznaniu jej za 
zmarłą.

***
## Art. 10291. {#art-10291}

Przepisy niniejszego tytułu stosuje się odpowiednio do stwierdzenia 
nabycia przedmiotu zapisu windykacyjnego. 
TYTUŁ VII 
Odpowiedzialność za długi spadkowe

***
## Art. 1030. {#art-1030}

Do chwili przyjęcia spadku spadkobierca ponosi odpowiedzialność za 
długi spadkowe tylko ze spadku. Od chwili przyjęcia spadku ponosi odpowiedzialność 
za te długi z całego swego majątku.

***
## Art. 1031. {#art-1031}

§ 1. W razie prostego przyjęcia spadku spadkobierca ponosi 
odpowiedzialność za długi spadkowe bez ograniczenia. 
§ 2. W razie przyjęcia spadku z dobrodziejstwem inwentarza spadkobierca 
ponosi odpowiedzialność za długi spadkowe tylko do wartości ustalonego w wykazie 
inwentarza albo spisie inwentarza stanu czynnego spadku. Powyższe ograniczenie 
odpowiedzialności odpada, jeżeli spadkobierca podstępnie pominął w wykazie 
inwentarza lub podstępnie nie podał do spisu inwentarza przedmiotów należących do 
spadku lub przedmiotów zapisów windykacyjnych albo podstępnie uwzględnił 
w wykazie inwentarza lub podstępnie podał do spisu inwentarza nieistniejące długi.

***
## Art. 10311. {#art-10311}

§ 1. Spadkobierca, który przyjął spadek z dobrodziejstwem 
inwentarza, zapisobierca windykacyjny lub wykonawca testamentu mogą złożyć 
w sądzie albo przed notariuszem wykaz inwentarza. Wykaz inwentarza składany przed 
notariuszem zostaje objęty protokołem. 
§ 2. Wykaz inwentarza może zostać złożony wspólnie przez więcej niż jednego 
spadkobiercę, zapisobiercę windykacyjnego lub wykonawcę testamentu. 
§ 3. W wykazie inwentarza z należytą starannością ujawnia się przedmioty 
należące do spadku oraz przedmioty zapisów windykacyjnych, z podaniem ich 
wartości według stanu i cen z chwili otwarcia spadku, a także długi spadkowe i ich 
wysokość według stanu z chwili otwarcia spadku. 
§ 4. W razie ujawnienia po złożeniu wykazu inwentarza przedmiotów 
należących do spadku, przedmiotów zapisów windykacyjnych lub długów 

©Kancelaria Sejmu 
 
 
 
s. 233/242 
 
   
 
2025-09-09 
 
spadkowych pominiętych w wykazie inwentarza składający wykaz uzupełnia go. Do 
uzupełnienia wykazu stosuje się przepisy dotyczące składania wykazu inwentarza.

***
## Art. 10312. {#art-10312}

§ 1. Wykaz inwentarza składany w sądzie sporządza się według 
ustalonego wzoru. 
§ 2. Minister Sprawiedliwości określi, w drodze rozporządzenia: 
- 1) wzór wykazu inwentarza obejmujący: 
  - a) dane, o których mowa w art. 10311 § 3, 
  - b) imię i nazwisko, numer Powszechnego Elektronicznego Systemu Ewidencji 
Ludności (PESEL), jeżeli został nadany, oraz ostatni adres spadkodawcy, 
  - c) imię i nazwisko, numer PESEL albo numer w Krajowym Rejestrze 
Sądowym, a w przypadku jego braku – numer w innym właściwym 
rejestrze, ewidencji lub numer identyfikacji podatkowej (NIP), jeżeli został 
nadany, oraz adres składającego wykaz inwentarza, 
  - d) pouczenie składającego wykaz inwentarza co do obowiązku jego 
uzupełnienia, w przypadkach wskazanych w art. 10311 § 4 
– mając na uwadze zamieszczenie danych koniecznych do ustalenia stanu 
czynnego spadku oraz standaryzację danych zawartych w wykazie; 
- 2) sposób udostępnienia druków wzoru wykazu inwentarza mając na uwadze 
przyspieszenie postępowania spadkowego.

***
## Art. 10313. {#art-10313}

§ 1. Spadkobierca, który złożył wykaz inwentarza spłaca długi 
spadkowe zgodnie ze złożonym wykazem. Nie może jednak zasłaniać się brakiem 
znajomości wykazu inwentarza złożonego przez innego spadkobiercę, zapisobiercę 
windykacyjnego lub wykonawcę testamentu. 
§ 2. Od chwili sporządzenia spisu inwentarza spadkobierca spłaca długi 
spadkowe zgodnie ze sporządzonym spisem. 
§ 3. Przepisy § 1 i 2 stosuje się odpowiednio do zapisobierców windykacyjnych 
i wykonawców testamentu.

***
## Art. 10314. {#art-10314}

Wierzyciel, który zażądał sporządzenia spisu inwentarza, nie może 
odmówić przyjęcia należnego mu świadczenia, chociażby dług nie był jeszcze 
wymagalny.

***
## Art. 1032. {#art-1032}

§ 1. Spadkobierca, który przyjął spadek z dobrodziejstwem 
inwentarza i spłacił niektóre długi spadkowe, a nie wiedział i przy dołożeniu należytej 

©Kancelaria Sejmu 
 
 
 
s. 234/242 
 
   
 
2025-09-09 
 
staranności nie mógł się dowiedzieć o istnieniu innych długów spadkowych, ponosi 
odpowiedzialność za niespłacone długi spadkowe tylko do wysokości różnicy między 
wartością stanu czynnego spadku a wartością świadczeń spełnionych na zaspokojenie 
długów spadkowych, które spłacił. 
§ 2. Spadkobierca, który przyjął spadek z dobrodziejstwem inwentarza 
i spłacając niektóre długi spadkowe, wiedział lub przy dołożeniu należytej staranności 
mógł 
się 
dowiedzieć 
o istnieniu 
innych 
długów 
spadkowych, 
ponosi 
odpowiedzialność za te długi ponad wartość stanu czynnego spadku, jednakże tylko 
do takiej wysokości, w jakiej byłby obowiązany je zaspokoić, gdyby spłacał należycie 
wszystkie długi spadkowe. Nie dotyczy to spadkobiercy niemającego pełnej zdolności 
do czynności prawnych oraz spadkobiercy, co do którego istnieje podstawa do jego 
ubezwłasnowolnienia.

***
## Art. 1033. {#art-1033}

Odpowiedzialność spadkobiercy z tytułu zapisów zwykłych i poleceń 
ogranicza się do wartości stanu czynnego spadku.

***
## Art. 1034. {#art-1034}

§ 1. Do chwili działu spadku spadkobiercy ponoszą solidarną 
odpowiedzialność za długi spadkowe. Jeżeli jeden ze spadkobierców spełnił 
świadczenie, może on żądać zwrotu od pozostałych spadkobierców w częściach, które 
odpowiadają wielkości ich udziałów. 
§ 2. Od chwili działu spadku spadkobiercy ponoszą odpowiedzialność za długi 
spadkowe w stosunku do wielkości udziałów.

***
## Art. 10341. {#art-10341}

§ 1. Do chwili działu spadku wraz ze spadkobiercami solidarną 
odpowiedzialność za długi spadkowe ponoszą także osoby, na których rzecz 
spadkodawca uczynił zapisy windykacyjne. 
§ 2. Rozliczenia między spadkobiercami i osobami, na których rzecz zostały 
uczynione zapisy windykacyjne, następują proporcjonalnie do wartości otrzymanych 
przez nich przysporzeń. Spadkobiercom uwzględnia się ich udział w wartości 
ustalonego w wykazie inwentarza albo spisie inwentarza stanu czynnego spadku.

***
## Art. 10342. {#art-10342}

Od chwili działu spadku spadkobiercy i osoby, na których rzecz 
zostały uczynione zapisy windykacyjne, ponoszą odpowiedzialność za długi 
spadkowe proporcjonalnie do wartości otrzymanych przez nich przysporzeń. 

©Kancelaria Sejmu 
 
 
 
s. 235/242 
 
   
 
2025-09-09

***
## Art. 10343. {#art-10343}

Odpowiedzialność osoby, na której rzecz został uczyniony zapis 
windykacyjny za długi spadkowe, jest ograniczona do wartości przedmiotu zapisu 
windykacyjnego według stanu i cen z chwili otwarcia spadku. 
TYTUŁ VIII 
Wspólność majątku spadkowego i dział spadku

***
## Art. 1035. {#art-1035}

Jeżeli spadek przypada kilku spadkobiercom, do wspólności majątku 
spadkowego 
oraz 
do 
działu 
spadku 
stosuje 
się 
odpowiednio 
przepisy 
o współwłasności w częściach ułamkowych z zachowaniem przepisów niniejszego 
tytułu.

***
## Art. 1036. {#art-1036}

Spadkobierca 
może 
za 
zgodą 
pozostałych 
spadkobierców 
rozporządzić udziałem w przedmiocie należącym do spadku. W braku zgody 
któregokolwiek z pozostałych spadkobierców rozporządzenie jest bezskuteczne 
o tyle, o ile naruszałoby uprawnienia przysługujące temu spadkobiercy na podstawie 
przepisów o dziale spadku.

***
## Art. 1037. {#art-1037}

§ 1. Dział spadku może nastąpić bądź na mocy umowy między 
wszystkimi spadkobiercami, bądź na mocy orzeczenia sądu na żądanie 
któregokolwiek ze spadkobierców. 
§ 2. Jeżeli do spadku należy nieruchomość, umowa o dział powinna być zawarta 
w formie aktu notarialnego. 
§ 3. Jeżeli do spadku należy przedsiębiorstwo, umowa o dział spadku powinna 
być zawarta w formie pisemnej z podpisami notarialnie poświadczonymi. Jeżeli 
jednak w skład przedsiębiorstwa wchodzi nieruchomość albo przedsiębiorstwo jest 
objęte zarządem sukcesyjnym, umowa o dział spadku powinna być zawarta w formie 
aktu notarialnego.

***
## Art. 1038. {#art-1038}

§ 1. Sądowy dział spadku powinien obejmować cały spadek. 
Jednakże z ważnych powodów może być ograniczony do części spadku. 
§ 2. Umowny dział spadku może objąć cały spadek lub być ograniczony do 
części spadku. 
§ 3. Sądowy częściowy dział spadku może nastąpić w szczególności z tego 
powodu, że w skład spadku wchodzi przedsiębiorstwo. 

©Kancelaria Sejmu 
 
 
 
s. 236/242 
 
   
 
2025-09-09

***
## Art. 10381. {#art-10381}

W przypadku gdy w skład spadku wchodzi przedsiębiorstwo, dział 
spadku obejmuje to przedsiębiorstwo z uwzględnieniem potrzeby zapewnienia 
kontynuacji prowadzonej przy jego wykorzystaniu działalności gospodarczej, chyba 
że spadkobiercy oraz małżonek spadkodawcy, któremu przysługuje udział w 
przedsiębiorstwie, nie osiągnęli porozumienia co do kontynuacji tej działalności.

***
## Art. 1039. {#art-1039}

§ 1. Jeżeli w razie dziedziczenia ustawowego dział spadku następuje 
między zstępnymi albo między zstępnymi i małżonkiem, spadkobiercy ci są 
wzajemnie zobowiązani do zaliczenia na schedę spadkową otrzymanych od 
spadkodawcy darowizn oraz zapisów windykacyjnych, chyba że z oświadczenia 
spadkodawcy lub z okoliczności wynika, że darowizna lub zapis windykacyjny zostały 
dokonane ze zwolnieniem od obowiązku zaliczenia. 
§ 2. Spadkodawca może włożyć obowiązek zaliczenia darowizny lub zapisu 
windykacyjnego na schedę spadkową także na spadkobiercę ustawowego 
niewymienionego w paragrafie poprzedzającym. 
§ 3. Nie podlegają zaliczeniu na schedę spadkową drobne darowizny 
zwyczajowo w danych stosunkach przyjęte.

***
## Art. 1040. {#art-1040}

Jeżeli wartość darowizny lub zapisu windykacyjnego podlegających 
zaliczeniu przewyższa wartość schedy spadkowej, spadkobierca nie jest obowiązany 
do zwrotu nadwyżki. W wypadku takim nie uwzględnia się przy dziale spadku ani 
darowizny lub zapisu windykacyjnego, ani spadkobiercy zobowiązanego do ich 
zaliczenia.

***
## Art. 1041. {#art-1041}

Dalszy zstępny spadkodawcy obowiązany jest do zaliczenia na 
schedę spadkową darowizny oraz zapisu windykacyjnego dokonanych przez 
spadkodawcę na rzecz jego wstępnego.

***
## Art. 1042. {#art-1042}

§ 1. Zaliczenie na schedę spadkową przeprowadza się w ten sposób, 
że wartość darowizn lub zapisów windykacyjnych podlegających zaliczeniu dolicza 
się do spadku lub do części spadku, która ulega podziałowi między spadkobierców 
obowiązanych wzajemnie do zaliczenia, po czym oblicza się schedę spadkową 
każdego z tych spadkobierców, a następnie każdemu z nich zalicza się na poczet jego 
schedy wartość darowizny lub zapisu windykacyjnego podlegającej zaliczeniu. 
§ 2. Wartość przedmiotu darowizny oblicza się według stanu z chwili jej 
dokonania, a według cen z chwili działu spadku. 

©Kancelaria Sejmu 
 
 
 
s. 237/242 
 
   
 
2025-09-09 
 
§ 21. Wartość przedmiotu zapisu windykacyjnego oblicza się według stanu 
z chwili otwarcia spadku, a według cen z chwili działu spadku. 
§ 3. Przy zaliczaniu na schedę spadkową nie uwzględnia się pożytków 
przedmiotu darowizny lub zapisu windykacyjnego.

***
## Art. 1043. {#art-1043}

Przepisy o zaliczeniu darowizn na schedę spadkową stosuje się 
odpowiednio do poniesionych przez spadkodawcę na rzecz zstępnego kosztów 
wychowania oraz wykształcenia ogólnego i zawodowego, o ile koszty te przekraczają 
przeciętną miarę przyjętą w danym środowisku.

***
## Art. 1044. {#art-1044}

Na żądanie dwóch lub więcej spadkobierców sąd może wydzielić im 
schedy spadkowe w całości lub w części w taki sposób, że przyzna im pewien 
przedmiot lub pewne przedmioty należące do spadku jako współwłasność 
w określonych częściach ułamkowych.

***
## Art. 1045. {#art-1045}

Uchylenie się od skutków prawnych umowy o dział spadku zawartej 
pod wpływem błędu może nastąpić tylko wtedy, gdy błąd dotyczył stanu faktycznego, 
który strony uważały za niewątpliwy.

***
## Art. 1046. {#art-1046}

Po dokonaniu działu spadku spadkobiercy są wzajemnie obowiązani 
do rękojmi za wady fizyczne i prawne według przepisów o rękojmi przy sprzedaży. 
Rękojmia co do wierzytelności spadkowych rozciąga się także na wypłacalność 
dłużnika. 
TYTUŁ IX 
Umowy dotyczące spadku

***
## Art. 1047. {#art-1047}

Z zastrzeżeniem wyjątków przewidzianych w tytule niniejszym 
umowa o spadek po osobie żyjącej jest nieważna.

***
## Art. 1048. {#art-1048}

§ 1. Spadkobierca ustawowy może przez umowę z przyszłym 
spadkodawcą zrzec się dziedziczenia po nim. Umowa taka powinna być zawarta 
w formie aktu notarialnego. 
§ 2. Zrzeczenie się dziedziczenia może być ograniczone do zrzeczenia się tylko 
prawa do zachowku w całości lub w części. 
§ 3. Zrzeczenie się dziedziczenia na korzyść innej osoby uważa się w razie 
wątpliwości za zrzeczenie się pod warunkiem, że ta osoba będzie dziedziczyć. 

©Kancelaria Sejmu 
 
 
 
s. 238/242 
 
   
 
2025-09-09

***
## Art. 1049. {#art-1049}

§ 1. Zrzeczenie się dziedziczenia obejmuje również zstępnych 
zrzekającego się, chyba że umówiono się inaczej. 
§ 2. Zrzekający się oraz jego zstępni, których obejmuje zrzeczenie się 
dziedziczenia, zostają wyłączeni od dziedziczenia, tak jakby nie dożyli otwarcia 
spadku.

***
## Art. 1050. {#art-1050}

Zrzeczenie się dziedziczenia może być uchylone przez umowę 
między tym, kto zrzekł się dziedziczenia, a tym, po kim się dziedziczenia zrzeczono. 
Umowa powinna być zawarta w formie aktu notarialnego.

***
## Art. 1051. {#art-1051}

Spadkobierca, który spadek przyjął, może spadek ten zbyć w całości 
lub w części. To samo dotyczy zbycia udziału spadkowego.

***
## Art. 1052. {#art-1052}

§ 1. Umowa sprzedaży, zamiany, darowizny lub inna umowa 
zobowiązująca do zbycia spadku przenosi spadek na nabywcę, chyba że strony inaczej 
postanowiły. 
§ 2. Jeżeli zawarcie umowy przenoszącej spadek następuje w wykonaniu 
zobowiązania wynikającego z uprzednio zawartej umowy zobowiązującej do zbycia 
spadku, ważność umowy przenoszącej spadek zależy od istnienia tego zobowiązania. 
§ 3. Umowa zobowiązująca do zbycia spadku powinna być zawarta w formie 
aktu notarialnego. To samo dotyczy umowy przenoszącej spadek, która zostaje 
zawarta w celu wykonania istniejącego uprzednio zobowiązania do zbycia spadku.

***
## Art. 1053. {#art-1053}

Nabywca spadku wstępuje w prawa i obowiązki spadkobiercy.

***
## Art. 1054. {#art-1054}

§ 1. Zbywca spadku zobowiązany jest do wydania tego, co wskutek 
zbycia, utraty lub uszkodzenia przedmiotów należących do spadku zostało uzyskane 
w zamian tych przedmiotów albo jako naprawienie szkody, a jeżeli zbycie spadku było 
odpłatne, także do wyrównania ubytku wartości powstałego przez zużycie lub 
rozporządzenie nieodpłatne przedmiotami należącymi do spadku. 
§ 2. Zbywca może żądać od nabywcy zwrotu wydatków i nakładów 
poczynionych na spadek.

***
## Art. 1055. {#art-1055}

§ 1. Nabywca spadku ponosi odpowiedzialność za długi spadkowe 
w tym samym zakresie co zbywca. Ich odpowiedzialność względem wierzycieli jest 
solidarna. 

©Kancelaria Sejmu 
 
 
 
s. 239/242 
 
   
 
2025-09-09 
 
§ 2. W braku odmiennej umowy nabywca ponosi względem zbywcy 
odpowiedzialność za to, że wierzyciele nie będą od niego żądali spełnienia świadczeń 
na zaspokojenie długów spadkowych.

***
## Art. 1056. {#art-1056}

W razie zbycia spadku spadkobierca nie ponosi odpowiedzialności 
z tytułu rękojmi za wady fizyczne i prawne poszczególnych przedmiotów należących 
do spadku.

***
## Art. 1057. {#art-1057}

Korzyści i ciężary związane z przedmiotami należącymi do spadku, 
jak również niebezpieczeństwo ich przypadkowej utraty lub uszkodzenia przechodzą 
na nabywcę z chwilą zawarcia umowy o zbycie spadku, chyba że umówiono się 
inaczej. 
TYTUŁ X 
Przepisy szczególne o dziedziczeniu gospodarstw rolnych

***
## Art. 1058. {#art-1058}

Do dziedziczenia z ustawy gospodarstw rolnych obejmujących 
grunty rolne o powierzchni przekraczającej 1 ha stosuje się przepisy tytułów 
poprzedzających księgi niniejszej ze zmianami wynikającymi z przepisów 
poniższych.

***
## Art. 1059. {#art-1059}

- 5) Spadkobiercy dziedziczą z ustawy gospodarstwo rolne, jeżeli 
w chwili otwarcia spadku: 
- 1) stale pracują bezpośrednio przy produkcji rolnej albo 
- 2) mają przygotowanie zawodowe do prowadzenia produkcji rolnej, albo 
- 3) są małoletni bądź też pobierają naukę zawodu lub uczęszczają do szkół, albo 
- 4) są trwale niezdolni do pracy.

***
## Art. 1060. {#art-1060}

- 6) W granicach określonych w art. 931 § 2 wnuki spadkodawcy, które 
w chwili otwarcia spadku odpowiadają warunkom przewidzianym w art. 1059 pkt 1 
i 2, dziedziczą gospodarstwo rolne także wtedy, gdy ich ojciec lub matka nie mogą 
- 5) Utracił moc z dniem 14 lutego 2001 r. w zakresie, w którym odnosi się do spadków otwartych od dnia 
14 lutego 2001 r., na podstawie wyroku Trybunału Konstytucyjnego z dnia 31 stycznia 2001 r. sygn. 
akt P. 4/99 (Dz. U. poz. 91). 
- 6) Utracił moc z dniem 14 lutego 2001 r. w zakresie, w którym odnosi się do spadków otwartych od dnia 
14 lutego 2001 r., na podstawie wyroku Trybunału Konstytucyjnego, o którym mowa w odnośniku 
5. 

©Kancelaria Sejmu 
 
 
 
s. 240/242 
 
   
 
2025-09-09 
 
gospodarstwa dziedziczyć dla braku warunków przewidzianych w art. 1059. Przepis 
ten stosuje się odpowiednio do dalszych zstępnych.

***
## Art. 1061. {#art-1061}

(uchylony)

***
## Art. 1062. {#art-1062}

- 7) § 1. Rodzeństwo spadkodawcy, które w chwili otwarcia spadku 
odpowiada warunkom przewidzianym w art. 1059 pkt 1 i 2, dziedziczy gospodarstwo 
rolne także wtedy, gdy zstępni spadkodawcy nie mogą gospodarstwa dziedziczyć dla 
braku warunków przewidzianych w art. 1059 lub w art. 1060. 
§ 2. W granicach określonych w art. 934 dzieci rodzeństwa spadkodawcy, które 
w chwili otwarcia spadku odpowiadają warunkom przewidzianym w art. 1059 pkt 1 
i 2, dziedziczą gospodarstwo rolne także wtedy, gdy ich ojciec lub matka nie mogą 
gospodarstwa dziedziczyć dla braku warunków przewidzianych w art. 1059 lub 
w § 1 niniejszego artykułu. Przepis ten stosuje się odpowiednio do dalszych 
zstępnych.

***
## Art. 1063. {#art-1063}

Jeżeli ani małżonek spadkodawcy, ani żaden z jego krewnych 
powołanych do dziedziczenia z ustawy nie odpowiada warunkom przewidzianym dla 
dziedziczenia gospodarstwa rolnego albo jeżeli uprawnionymi do dziedziczenia są 
wyłącznie osoby, które w chwili otwarcia spadku są trwale niezdolne do pracy, 
gospodarstwo dziedziczą spadkobiercy na zasadach ogólnych.

***
## Art. 1064. {#art-1064}

- 8) Rozporządzenie Rady Ministrów określi, jakie przygotowanie 
zawodowe uważa się za przygotowanie zawodowe do prowadzenia produkcji rolnej, 
a także wypadki, w których pobieranie nauki zawodu lub uczęszczanie do szkół 
uprawnia do dziedziczenia gospodarstwa rolnego, oraz zasady i tryb stwierdzania 
trwałej niezdolności do pracy.

***
## Art. 1065. {#art-1065}

(uchylony)

***
## Art. 1066. {#art-1066}

(uchylony) 
- 7) Utracił moc z dniem 14 lutego 2001 r. w zakresie, w którym odnosi się do spadków otwartych od dnia 
14 lutego 2001 r., na podstawie wyroku Trybunału Konstytucyjnego, o którym mowa w odnośniku 
5. 
- 8) Utracił moc z dniem 14 lutego 2001 r. w zakresie, w którym odnosi się do spadków otwartych od dnia 
14 lutego 2001 r., na podstawie wyroku Trybunału Konstytucyjnego, o którym mowa w odnośniku 
5. 

©Kancelaria Sejmu 
 
 
 
s. 241/242 
 
   
 
2025-09-09

***
## Art. 1067. {#art-1067}

§ 1. Do zapisu, którego przedmiotem jest świadczenie pieniężne, 
stosuje się odpowiednio przepis art. 216. 
§ 2. Jeżeli wykonanie zapisu prowadziłoby do podziału gospodarstwa rolnego 
lub wkładu gruntowego w rolniczej spółdzielni produkcyjnej, sprzecznego z zasadami 
prawidłowej gospodarki rolnej, spadkobierca zobowiązany do wykonania zapisu może 
żądać zamiany przedmiotu zapisu na świadczenie pieniężne.

***
## Art. 1068. {#art-1068}

(uchylony)

***
## Art. 1069. {#art-1069}

(uchylony)

***
## Art. 1070. {#art-1070}

W razie podziału gospodarstwa rolnego, które należy do spadku, 
stosuje się odpowiednio przepisy o podziale gospodarstw rolnych przy zniesieniu 
współwłasności.

***
## Art. 10701. {#art-10701}

Do zbycia spadku lub części spadku lub udziału w spadku 
obejmującym gospodarstwo rolne lub nieruchomość rolną w rozumieniu przepisów 
ustawy, o której mowa w art. 166 § 3, stosuje się przepisy tej ustawy dotyczące zbycia 
nieruchomości rolnej.

***
## Art. 1071. {#art-1071}

(uchylony)

***
## Art. 1072. {#art-1072}

(uchylony)

***
## Art. 1073. {#art-1073}

(uchylony)

***
## Art. 1074. {#art-1074}

(uchylony)

***
## Art. 1075. {#art-1075}

(uchylony)

***
## Art. 1076. {#art-1076}

(uchylony)

***
## Art. 1077. {#art-1077}

(uchylony)

***
## Art. 1078. {#art-1078}

(uchylony)

***
## Art. 1079. {#art-1079}

Jeżeli oprócz gospodarstwa rolnego spadek obejmuje inne 
przedmioty majątkowe, udziały spadkobierców w gospodarstwie rolnym zalicza się na 
poczet ich udziałów w całości spadku.

***
## Art. 1080. {#art-1080}

(uchylony)

***
## Art. 1081. {#art-1081}

Odpowiedzialność za długi spadkowe związane z prowadzeniem 
gospodarstwa rolnego ponosi od chwili działu spadku spadkobierca, któremu to 

©Kancelaria Sejmu 
 
 
 
s. 242/242 
 
   
 
2025-09-09 
 
gospodarstwo przypadło, oraz spadkobiercy otrzymujący od niego spłaty. Każdy 
z tych spadkobierców ponosi odpowiedzialność w stosunku do wartości otrzymanego 
udziału. Odpowiedzialność za inne długi ponoszą wszyscy spadkobiercy na zasadach 
ogólnych.

***
## Art. 1082. {#art-1082}

Jeżeli do spadku należy gospodarstwo rolne, ustalenie zachowku 
następuje z uwzględnieniem przepisów niniejszego tytułu, a także odpowiednio 
art. 216.

***
## Art. 1083. {#art-1083}

(uchylony)

***
## Art. 1084. {#art-1084}

(uchylony)

***
## Art. 1085. {#art-1085}

(uchylony)

***
## Art. 1086. {#art-1086}

Przepisy tytułu niniejszego stosuje się odpowiednio w wypadku, gdy 
do spadku należy wkład gruntowy w rolniczej spółdzielni produkcyjnej, o ile przepisy 
poniższe nie stanowią inaczej.

***
## Art. 1087. {#art-1087}

- 9) § 1. Należący do spadku wkład gruntowy w rolniczej spółdzielni 
produkcyjnej dziedziczą ci spośród spadkobierców, którzy w chwili otwarcia spadku: 
- 1) są członkami tej spółdzielni albo 
- 2) bądź są małoletni, bądź też pobierają naukę zawodu lub uczęszczają do szkół, 
albo 
- 3) są trwale niezdolni do pracy. 
§ 2. W braku spadkobierców określonych w punkcie pierwszym paragrafu 
poprzedzającego wkład gruntowy w rolniczej spółdzielni produkcyjnej dziedziczą 
również spadkobiercy, którzy pracują w gospodarstwie rolnym spółdzielni albo 
w ciągu sześciu miesięcy od otwarcia spadku zostaną członkami tej spółdzielni. 
§ 3. Przepisy 
paragrafów 
poprzedzających 
dotyczą 
również 
działki 
przyzagrodowej i siedliskowej, jeżeli należą one do spadku.

***
## Art. 1088. {#art-1088}

(uchylony) 
- 9) Utracił moc z dniem 14 lutego 2001 r. w zakresie, w którym odnosi się do spadków otwartych od dnia 
14 lutego 2001 r., na podstawie wyroku Trybunału Konstytucyjnego, o którym mowa w odnośniku 
5.

