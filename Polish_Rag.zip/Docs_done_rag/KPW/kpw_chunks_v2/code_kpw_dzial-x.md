---
title: "Kodeks postępowania w sprawach o wykroczenia"
short: "KPW"
unit: "DZIAŁ X"
dz_u: "Dz.U. 2001 Nr 106 poz. 1148"
status: "obowiązujący"
last_consolidated: "2025-09-09"
articles: "Art. 103–109"
source: "D20011148Lj (1).pdf"
---
DZIAŁ X

Środki odwoławcze


## Art. 103. {#kpw-art-103}
 § 1. Środkami odwoławczymi są apelacja i zażalenie.

§ 2. Od wyroku sądu pierwszej instancji służy stronom apelacja, chyba że ustawa

stanowi inaczej.

§ 3. Zażalenie przysługuje w wypadkach wskazanych w ustawie. Przysługuje

ono stronom, a także osobie, której postanowienie, zarządzenie lub inne czynności

bezpośrednio dotyczą.

2025-09-09








s. 54/62

§ 3a. Od postanowień i zarządzeń referendarza sądowego może być wniesiony

sprzeciw. Powoduje on utratę mocy postanowienia lub zarządzenia.

§ 3b. Sprzeciw przysługuje stronie, a także osobie, której postanowienie lub

zarządzenie dotyczy. Składa się go w terminie 7 dni od ogłoszenia postanowienia lub

zarządzenia, a gdy podlega ono doręczeniu – od daty doręczenia. Prezes sądu odmawia

przyjęcia sprzeciwu, jeżeli został on wniesiony po terminie lub przez osobę

nieuprawnioną.

§ 4. Orzeczenie można zaskarżyć w całości lub części.


## Art. 104. {#kpw-art-104}
 § 1. Sąd odwoławczy uchyla na posiedzeniu zaskarżone orzeczenie,

niezależnie od granic zaskarżenia, podniesionych zarzutów i wpływu uchybienia na

treść orzeczenia, jeżeli:

1)

orzeczenie wydała osoba nieuprawniona do orzekania albo sędzia podlegający

2)

3)

wyłączeniu z mocy prawa lub niezdolny do orzekania;

sąd był nienależycie obsadzony lub orzeczenie nie zostało podpisane;

sąd powszechny orzekł w sprawie należącej do właściwości sądu wojskowego

albo sąd wojskowy orzekł w sprawie należącej do właściwości sądu

powszechnego;

3a) sąd niższego rzędu orzekł w sprawie należącej do właściwości sądu wyższego

4)

5)

6)

rzędu;

orzeczono karę lub środek karny nieznany ustawie;

zachodzi sprzeczność w treści orzeczenia uniemożliwiająca jego wykonanie;

obwiniony nie miał obrońcy w wypadkach określonych w art. 21 § 1 lub obrońca

nie brał udziału w czynnościach, w których jego udział był obowiązkowy;

7)

zachodzi

jedna z okoliczności wyłączających postępowanie, określonych

w art. 5 § 1 pkt 4–10.

§ 1a. Uchylenie orzeczenia jedynie z powodów określonych w § 1 pkt 6 oraz

w art. 5 § 1 pkt 4 i 5 może nastąpić tylko na korzyść obwinionego.

§ 2. (uchylony)


## Art. 105. {#kpw-art-105}
 § 1. Apelację wnosi się na piśmie w terminie 7 dni od daty otrzymania

wyroku wraz z uzasadnieniem, chyba że ustawa stanowi inaczej.

§ 1a. W wypadku, gdy uzasadnienie wyroku zostało przedstawione wyłącznie

w formie ustnej, apelację wnosi się na piśmie w terminie 7 dni od daty otrzymania

wyroku wraz z przekładem tego uzasadnienia.

2025-09-09








s. 55/62

§ 2. Wniesienie apelacji przed upływem

terminu do złożenia wniosku

o uzasadnienie wyroku

albo wniosku

o przekład

uzasadnienia wyroku

przedstawionego w formie ustnej wywołuje skutki wskazane odpowiednio w art. 35

§ 1 albo art. 82 § 7 i podlega rozpoznaniu; można ją uzupełnić w terminie wskazanym

odpowiednio w § 1 albo 1a.

<§ 2a. Prokurator, obrońca lub pełnomocnik będący adwokatem lub radcą

prawnym mogą złożyć apelację

i dalsze pisma w toku postępowania

odwoławczego przez umieszczenie ich treści w portalu informacyjnym, o którym

mowa w art. 53e § 1 ustawy z dnia 27 lipca 2001 r. – Prawo o ustroju sądów

powszechnych (Dz. U. z 2024 r. poz. 334 i 1907 oraz z 2025 r. poz. 526, 820, 1172

Dodany § 2a w
art. 105 wejdzie
w życie z dn.
1.03.2026 r. (Dz.
U. z 2025 r. poz.
1178).

i 1178).>

§ 3. O przyjęciu apelacji zawiadamia się strony, obrońców i pełnomocników, po

czym akta przekazuje się niezwłocznie sądowi odwoławczemu.


## Art. 106. {#kpw-art-106}
 § 1. Strony mają prawo uczestniczyć w rozprawie i w posiedzeniu sądu

odwoławczego. Udział stron nie jest obowiązkowy, chyba że prezes sądu lub sąd tak

zarządzi. Obowiązkowy jest jednak udział obrońcy w wypadku określonym w art. 21

§ 1.

§ 2. Sąd odwoławczy na żądanie obwinionego pozbawionego wolności, złożone

nie później niż w ciągu 7 dni od zawiadomienia go o przyjęciu apelacji, zarządza jego

sprowadzenie na rozprawę, chyba że uzna za wystarczający udział w niej jego

obrońcy. Jeżeli obwiniony nie ma obrońcy, wyznacza się obrońcę z urzędu.

§ 3. Niestawiennictwo prawidłowo zawiadomionych o terminie stron i ich

przedstawicieli procesowych nie tamuje rozpoznania sprawy, chyba że stawiennictwo

było obowiązkowe.

Art. 106a. Sąd odwoławczy może, uznając potrzebę uzupełnienia przewodu

sądowego, przeprowadzić dowód na rozprawie, jeżeli przyczyni się to do

przyspieszenia postępowania, a nie jest konieczne przeprowadzenie na nowo

przewodu w całości. Dowód można dopuścić również przed rozprawą.


## Art. 107. {#kpw-art-107}
 § 1. Uzasadnienie wyroku sąd odwoławczy sporządza w terminie

7 dni.

§ 2. Uzasadnienie wyroku zmieniającego lub utrzymującego w mocy wyrok sądu

pierwszej instancji sporządza się wyłącznie na żądanie strony, złożone w terminie

zawitym 7 dni od daty wydania wyroku przez sąd odwoławczy.

2025-09-09








s. 56/62

§ 2a. Jeżeli przebieg rozprawy utrwala się za pomocą urządzenia rejestrującego

dźwięk albo obraz i dźwięk, uzasadnienie wyroku może być z urzędu przedstawione

wyłącznie w formie ustnej, bezpośrednio po ogłoszeniu wyroku. Przepisu art. 418

§ 3 Kodeksu postępowania karnego nie stosuje się. Przed przedstawieniem

uzasadnienia wyroku w formie ustnej należy uprzedzić o tym strony.

§ 3. W uzasadnieniu należy podać, czym kierował się sąd wydając wyrok oraz

dlaczego zarzuty i wnioski apelacji sąd uznał za zasadne albo niezasadne.

[
## Art. 108. {#kpw-art-108}
 Zażalenie wnosi się na piśmie w terminie 7 dni od daty ogłoszenia

rozstrzygnięcia albo ustnie do protokołu rozprawy lub posiedzenia, a gdy podlega ono

doręczeniu, od daty doręczenia lub od daty dokonania zaskarżonej czynności, chyba

że ustawa stanowi inaczej.]

<
## Art. 108. {#kpw-art-108}
 § 1. Zażalenie wnosi się na piśmie w terminie 7 dni od daty

ogłoszenia rozstrzygnięcia albo ustnie do protokołu rozprawy lub posiedzenia,

a gdy podlega ono doręczeniu – od daty doręczenia lub od daty dokonania

zaskarżonej czynności, chyba że ustawa stanowi inaczej.

§ 2. Prokurator, obrońca lub pełnomocnik będący adwokatem lub radcą

prawnym mogą wnieść zażalenie przez umieszczenie jego treści w portalu

informacyjnym, o którym mowa w art. 53e § 1 ustawy z dnia 27 lipca 2001 r. –

Prawo o ustroju sądów powszechnych.>


## Art. 109. {#kpw-art-109}
 § 1. W postępowaniu odwoławczym stosuje się odpowiednio przepisy

dotyczące postępowania przed sądem pierwszej instancji, chyba że przepisy

niniejszego rozdziału stanowią inaczej.

§ 2. Przy rozpoznawaniu środka odwoławczego stosuje się odpowiednio także

przepisy art. 425 § 3 i 4, art. 426, 427, 429–438, 440–443, 447, 449, 453, 454 § 1,

art. 455, 456, 462, 463 § 1, art. 465 § 1 i 2, art. 466 i 467 Kodeksu postępowania

karnego.

Nowe brzmienie
art. 108 wejdzie
w życie z dn.
1.03.2026 r. (Dz.
U. z 2025 r. poz.
1178).

2025-09-09









s. 57/62
