---
title: "Kodeks postępowania w sprawach o wykroczenia"
short: "KPW"
unit: "DZIAŁ XII"
dz_u: "Dz.U. 2001 Nr 106 poz. 1148"
status: "obowiązujący"
last_consolidated: "2025-09-09"
articles: "Art. 114–116"
source: "D20011148Lj (1).pdf"
---
DZIAŁ XII

Postępowanie po uprawomocnieniu się orzeczenia

## Rozdział 20

Odszkodowanie za niesłuszne ukaranie lub zatrzymanie


## Art. 114. {#kpw-art-114}
 § 1. Obwinionemu, który w wyniku kasacji

lub wznowienia

postępowania został następnie uniewinniony albo wobec którego umorzono

postępowanie wskutek okoliczności nieuwzględnionych we wcześniejszym

postępowaniu, przysługuje od Skarbu Państwa odszkodowanie za poniesioną szkodę

oraz zadośćuczynienie za doznaną krzywdę, wynikłą z wykonania względem niego

w całości lub części kary lub środka karnego, których nie powinien był ponieść.

§ 2. Odszkodowanie i zadośćuczynienie przysługuje także osobie niewątpliwie

niesłusznie zatrzymanej oraz osobie osadzonej w zakładzie karnym na podstawie

art. 82 § 5 pkt 2 albo pkt 3, która następnie została prawomocnie uniewinniona albo

wobec której prawomocnie umorzono postępowanie.

§ 2a. Odszkodowanie i zadośćuczynienie przysługuje również obwinionemu,

wobec którego zastosowano zabezpieczenie majątkowe środka karnego przepadku,

w zakresie szkody i krzywdy wyrządzonej tym środkiem przymusu, gdy został on

następnie prawomocnie uniewinniony albo umorzono wobec niego postępowanie lub

mimo skazania go nie orzeczono środka karnego przepadku.

§ 3. W razie

śmierci

obwinionego,

który

żądanie

odszkodowania

i zadośćuczynienia zgłosił za życia, prawa jego przechodzą na małżonka, dzieci

i rodziców.


## Art. 115. {#kpw-art-115}
 § 1. Roszczenie o odszkodowanie i zadośćuczynienie należy zgłosić

w sądzie okręgowym, w okręgu którego wydano orzeczenie w pierwszej instancji lub

w którym nastąpiło zwolnienie zatrzymanego.

2025-09-09








s. 59/62

§ 2. Roszczenia, o których mowa w § 1, przedawniają się po upływie 6 miesięcy

od daty uprawomocnienia się orzeczenia uniewinniającego lub umarzającego

postępowanie, o którym mowa w art. 114 § 1, albo od daty zwolnienia zatrzymanego.

§ 3. W przedmiocie roszczenia orzeka jednoosobowo wyrokiem sąd okręgowy

na rozprawie. Postępowanie w sprawie o odszkodowanie i zadośćuczynienie za

niesłuszne ukaranie oraz za niewątpliwie niesłuszne zatrzymanie wolne jest od

kosztów.

§ 4. Żądający odszkodowania może ustanowić pełnomocnika, którym może być

adwokat lub radca prawny. Przepis art. 30 § 2 stosuje się odpowiednio.


## Art. 116. {#kpw-art-116}
 Przy rozpoznawaniu roszczeń o odszkodowanie oraz zadośćuczynienie

stosuje się odpowiednio przepisy art. 553, art. 556 § 4, art. 557 i art. 558 Kodeksu

postępowania karnego.

# DZIAŁ XIIA

Postępowanie w sprawach ze stosunków międzynarodowych

## Rozdział 20a

Wystąpienie do państwa członkowskiego Unii Europejskiej o wykonanie

postanowienia o zatrzymaniu dowodów lub mającego na celu zabezpieczenie

mienia oraz wykonanie orzeczenia sądu lub innego organu państwa

członkowskiego Unii Europejskiej o zatrzymaniu dowodów lub mającego na

celu zabezpieczenie mienia

Art. 116a. Do wystąpienia do państwa członkowskiego Unii Europejskiej

o wykonanie postanowienia o zatrzymaniu dowodów

lub mającego na celu

zabezpieczenie mienia oraz do wykonania orzeczenia sądu lub innego organu państwa

członkowskiego Unii Europejskiej o zatrzymaniu dowodów lub mającego na celu

zabezpieczenie mienia stosuje się odpowiednio przepisy rozdziałów 62a i 62b

Kodeksu postępowania karnego.

## Rozdział 20b

Wystąpienie do państwa członkowskiego Unii Europejskiej o wykonanie

grzywny, środków karnych w postaci nawiązki lub obowiązku naprawienia

szkody lub też orzeczenia zasądzającego koszty postępowania oraz wykonanie

2025-09-09








s. 60/62

orzeczenia sądu lub innego organu państwa członkowskiego Unii Europejskiej

o karach o charakterze pieniężnym

Art. 116b. § 1. Do wystąpienia do państwa członkowskiego Unii Europejskiej

o wykonanie grzywny, środków karnych w postaci nawiązki lub obowiązku

naprawienia szkody lub orzeczenia zasądzającego koszty postępowania oraz do

wykonania orzeczenia sądu lub innego organu państwa członkowskiego Unii

Europejskiej o karach o charakterze pieniężnym stosuje się odpowiednio przepisy

rozdziałów 66a i 66b Kodeksu postępowania karnego.

§ 2. W postępowaniu mandatowym o wykonanie grzywny nałożonej mandatem

karnym kredytowanym do właściwego sądu

lub

innego organu państwa

członkowskiego Unii Europejskiej występuje wierzyciel uprawniony według

przepisów o postępowaniu egzekucyjnym w administracji.

## Rozdział 20c

Wystąpienie do państwa członkowskiego Unii Europejskiej o przeprowadzenie

dowodu na podstawie europejskiego nakazu dochodzeniowego oraz wykonanie

europejskiego nakazu dochodzeniowego wydanego w innym państwie

członkowskim Unii Europejskiej

Art. 116c. § 1. Do wystąpienia do państwa członkowskiego Unii Europejskiej

o przeprowadzenie dowodu na podstawie europejskiego nakazu dochodzeniowego

oraz do wykonania europejskiego nakazu dochodzeniowego wydanego w innym

państwie członkowskim Unii Europejskiej stosuje się odpowiednio przepisy

rozdziałów 62c i 62d Kodeksu postępowania karnego.

§ 2. Wystąpienie, o którym mowa w § 1, jest dopuszczalne w sprawach

o wykroczenia przewidziane w przepisach rozdziałów XI i XIV Kodeksu wykroczeń.
