---
title: "Kodeks postępowania w sprawach o wykroczenia"
short: "KPW"
unit: "DZIAŁ VI"
dz_u: "Dz.U. 2001 Nr 106 poz. 1148"
status: "obowiązujący"
last_consolidated: "2025-09-09"
articles: "Art. 45–53"
source: "D20011148Lj (1).pdf"
---
DZIAŁ VI

Środki przymusu

## Rozdział 8

Zatrzymanie


## Art. 45. {#kpw-art-45}
 § 1. Policja ma prawo zatrzymać osobę ujętą na gorącym uczynku

popełnienia wykroczenia lub bezpośrednio potem, jeżeli:

1)2) zachodzą podstawy do zastosowania wobec niej postępowania przyspieszonego;

2) Utracił moc w związku z art. 90 § 2 z dniem 15 stycznia 2019 r. w zakresie, w jakim dopuszcza
zatrzymanie osoby przebywającej jedynie czasowo na terytorium Rzeczypospolitej Polskiej, której
tożsamość została ustalona, a której zarzuca się popełnienie wykroczenia zagrożonego wyłącznie
2025-09-09









s. 20/62

2)

nie można ustalić jej tożsamości.

§ 2. Art. 243 Kodeksu postępowania karnego stosuje się odpowiednio.


## Art. 46. {#kpw-art-46}
 § 1. Zatrzymanego należy natychmiast poinformować o przyczynach

zatrzymania i o przysługujących mu uprawnieniach oraz wysłuchać go.

§ 2. Z zatrzymania sporządza się protokół, którego odpis doręcza się

zatrzymanemu za pokwitowaniem. W protokole należy podać imię i nazwisko oraz

funkcję osoby dokonującej zatrzymania, imię i nazwisko zatrzymanego, a w razie

niemożności ustalenia tożsamości – rysopis tej osoby, a ponadto dzień, godzinę,

miejsce i przyczynę zatrzymania z określeniem wykroczenia, w związku z którym

została zatrzymana. Należy również zapisać złożone przez zatrzymanego oświad-

czenia i zaznaczyć udzielenie mu informacji o przysługujących prawach.

§ 3. Na żądanie zatrzymanego zawiadamia się o zatrzymaniu osobę najbliższą,

a także pracodawcę. O zatrzymaniu osoby wskazanej w art. 10 § 1 zawiadamia się

niezwłocznie właściwego dowódcę jednostki wojskowej, nawet gdy zatrzymany tego

nie żąda. Przepis art. 612 § 2 Kodeksu postępowania karnego stosuje się odpowiednio.

§ 4. Zatrzymanemu należy na jego żądanie umożliwić nawiązanie w dostępnej

formie kontaktu z adwokatem albo z radcą prawnym oraz zapewnić możliwość

bezpośredniej z nim rozmowy; zatrzymujący może zastrzec, że będzie przy niej

obecny.

§ 5. Zatrzymanego należy natychmiast zwolnić, gdy ustanie przyczyna

zatrzymania, a także z upływem czasu zatrzymania.

§ 6. Czas zatrzymania osoby liczy się od chwili jej ujęcia i nie może przekroczyć

24 godzin, a w wypadkach wskazanych w art. 45 § 1 pkt 1 – 48 godzin.

§ 7. Minister Sprawiedliwości określi, w drodze

rozporządzenia, wzór

pouczenia, o którym mowa w § 1, zawierając w nim w szczególności informacje

o przysługujących zatrzymanemu uprawnieniach: do złożenia oświadczenia i odmowy

złożenia oświadczenia w przedmiocie zatrzymania, do korzystania z bezpłatnej

pomocy tłumacza, do przeglądania akt w zakresie dotyczącym przyczyn zatrzymania,

do dostępu do pierwszej pomocy medycznej, jak również prawach wskazanych w § 1,

3–4 i 6, art. 47 § 1 oraz w art. 612 § 2 Kodeksu postępowania karnego, mając na

grzywną przewidzianą w art. 18 pkt 3 ustawy z dnia 20 maja 1971 r. – Kodeks wykroczeń (Dz. U.
z 2018 r. poz. 618, ze zm.), na podstawie wyroku Trybunału Konstytucyjnego z dnia 8 stycznia 2019
r. sygn. akt SK 6/16 (Dz. U. poz. 76).

2025-09-09









s. 21/62

względzie konieczność zrozumienia pouczenia także przez osoby niekorzystające

z pomocy pełnomocnika.


## Art. 47. {#kpw-art-47}
 § 1. Zatrzymanemu przysługuje zażalenie na zatrzymanie do sądu.

W zażaleniu zatrzymany może domagać się zbadania zasadności, legalności oraz

prawidłowości zatrzymania.

§ 2.3) Zażalenie przekazuje się niezwłocznie sądowi rejonowemu miejsca

zatrzymania, który również niezwłocznie je rozpoznaje.

§ 3. Przy rozpoznawaniu zażalenia sąd stosuje odpowiednio przepisy art. 246 § 3

i 4 Kodeksu postępowania karnego.

§ 4. W razie uznania zatrzymania za niewątpliwie niesłuszne zatrzymanemu

przysługuje odszkodowanie, którego może dochodzić w trybie określonym w dziale

XII niniejszego kodeksu.

## Rozdział 9

Zabezpieczenie i zajęcie przedmiotów


## Art. 48. {#kpw-art-48}
 § 1. Policja i inne organy uprawnione do prowadzenia czynności

określonych w dziale VII mogą dokonać tymczasowego zajęcia przedmiotu, jeżeli

w zakresie swego działania dowiedziały się lub ujawniły wykroczenie zagrożone

przepadkiem przedmiotów, a zajęcie takie jest niezbędne dla zabezpieczenia

wykonania tego przepadku. Z czynności zajęcia sporządza się protokół.

§ 2. Tymczasowe zajęcie upada, jeżeli w ciągu 7 dni od daty jego dokonania nie

zostanie wydane postanowienie o zabezpieczeniu albo rozstrzygnięcie orzekające

przepadek. Postanowienie o zabezpieczeniu wydaje sąd właściwy do rozpoznania

sprawy; doręcza się je niezwłocznie osobie, u której dokonano zajęcia.

§ 3. Zabezpieczenie może nastąpić także na mocy postanowienia sądu po

wszczęciu postępowania w sprawie o wykroczenie zagrożone przepadkiem

przedmiotów, jeżeli nie dokonano tymczasowego zajęcia. Postanowienie to wykonuje

Policja, stosując odpowiednio przepisy o przeszukaniu i doręczając postanowienie

osobie, u której dokonuje zajęcia.

§ 4. Na postanowienia, o których mowa w § 2 i 3, przysługuje zażalenie osobie,

której prawa zostały naruszone.

3) Utracił moc w związku z art. 33 i art. 109 § 2 z dniem 15 stycznia 2019 r. w zakresie, w jakim nie
gwarantuje osobie zatrzymanej prawa do udziału w posiedzeniu sądu rozpatrującego zażalenie na
zatrzymanie, na podstawie wyroku Trybunału Konstytucyjnego, o którym mowa w odnośniku 2.

2025-09-09









s. 22/62

§ 5. Przy dokonywaniu czynności, o których mowa w § 1–3, stosuje się

odpowiednio przepisy art. 44.

§ 6. Zabezpieczenie majątkowe upada,

jeżeli nie zostanie prawomocnie

orzeczony przepadek przedmiotów.

## Rozdział 10

Kary porządkowe i pozostałe środki przymusu


## Art. 49. {#kpw-art-49}
 § 1. Na świadka, biegłego, tłumacza lub specjalistę, który bez

usprawiedliwienia nie stawił się na wezwanie uprawnionego organu lub bez

zezwolenia tego organu samowolnie wydalił się z miejsca czynności przed jej

zakończeniem albo bezpodstawnie odmówił złożenia zeznań, wykonania czynności

biegłego, tłumacza lub specjalisty, można nałożyć karę porządkową od 50 do

1000 złotych, a w razie ponownego niezastosowania się do wezwania od 100 do

1500 złotych.

§ 2. Przepis § 1 stosuje się również do osoby, która będąc obowiązana do

okazania albo wydania przedmiotu oględzin lub dowodu rzeczowego odmówiła jego

okazania lub wydania; nie dotyczy to osoby, której przysługuje prawo odmowy

zeznań.

§ 3. Nałożoną karę należy uchylić, jeżeli osoba ukarana w ciągu 7 dni od daty

doręczenia

lub ogłoszenia

jej postanowienia o nałożeniu kary porządkowej

dostatecznie usprawiedliwi swoje niestawiennictwo, samowolne oddalenie się,

odmowę złożenia zeznań albo wykonania innego obowiązku, o którym mowa w § 1

lub 2.

§ 4. W przypadku uchybienia obowiązkom wskazanym w § 1 lub 2 przez

żołnierza w czynnej służbie wojskowej, sąd występuje do dowódcy jednostki

wojskowej, w której żołnierz pełni służbę, o pociągnięcie go do odpowiedzialności

dyscyplinarnej.

§ 5. Przepis § 4 stosuje się, choćby za uchybienie, którego dopuścił się żołnierz

przed wstąpieniem do wojska, była mu poprzednio wymierzona kara porządkowa, lecz

nie została do tego czasu wykonana.


## Art. 50. {#kpw-art-50}
 § 1. W razie niestawienia

się

świadka na wezwanie bez

usprawiedliwienia można, niezależnie od nałożenia kary porządkowej, zarządzić jego

zatrzymanie i przymusowe doprowadzenie przez Policję. Zatrzymanie i przymusowe

doprowadzenie może być zarządzone także wobec osoby przesłuchanej w trybie
2025-09-09








s. 23/62

określonym w art. 54 § 6, jeżeli nie stawiła się ona na wezwanie organu prowadzącego

czynności wyjaśniające bez usprawiedliwienia. Przepis art. 47 stosuje się wówczas

odpowiednio, z tym że zażalenie na zatrzymanie rozpoznaje sąd rejonowy miejsca

prowadzenia postępowania lub prowadzenia czynności wyjaśniających, w ramach

których zarządzono zatrzymanie w celu przymusowego doprowadzenia. Zatrzymanie

może nastąpić na czas konieczny do wykonania zarządzenia o doprowadzeniu.

§ 2. W razie nieusprawiedliwionej odmowy okazania albo wydania przedmiotu

oględzin lub dowodu rzeczowego można zarządzić jego odebranie przez Policję.


## Art. 51. {#kpw-art-51}
 § 1. Środki przymusu, o których mowa w art. 49 i 50, stosuje sąd

właściwy do rozpoznania sprawy, a w toku czynności wyjaśniających

także

prokurator, jeżeli prowadzi te czynności. W toku czynności wyjaśniających,

prowadzonych przez organ inny niż prokurator, środki przymusu, o których mowa

w art. 50 § 1, stosuje sąd właściwy do rozpoznania sprawy na wniosek organu

dokonującego tych czynności, a pozostałe środki przymusu – organ dokonujący

czynności wyjaśniających.

§ 2. Karę porządkową wskazaną w art. 49 § 1 i 2 uchyla odpowiednio sąd lub

organ przełożony nad organem, który daną karę nałożył.

§ 3. Na postanowienie odmawiające uchylenia kary porządkowej przysługuje

ukaranemu zażalenie; jeżeli postanowienie wydano w toku czynności wyjaśniających,

zażalenie rozpoznaje sąd właściwy do rozpoznania sprawy.

§ 4. Kary porządkowe nałożone w toku czynności wyjaśniających ściąga się

w trybie przepisów o postępowaniu egzekucyjnym w administracji. Kary te stanowią

dochód budżetu państwa, z wyjątkiem kar porządkowych pobieranych przez organy

Inspekcji Transportu Drogowego, które stanowią wpływy Funduszu rozwoju

przewozów autobusowych o charakterze użyteczności publicznej, o którym mowa

w ustawie z dnia 16 maja 2019 r. o Funduszu rozwoju przewozów autobusowych

o charakterze użyteczności publicznej (Dz. U. z 2024 r. poz. 402 i 1572 oraz z 2025 r.

poz. 303).


## Art. 52. {#kpw-art-52}
 (uchylony)


## Art. 53. {#kpw-art-53}
 Jeżeli miejsce pobytu osoby podejrzanej o popełnienie wykroczenia nie

jest znane, sąd może zarządzić ustalenie miejsca jej pobytu przez Policję. Policja ustala

też miejsce pobytu z własnej inicjatywy albo na wniosek organu dokonującego

czynności wyjaśniających.

2025-09-09








s. 24/62
