---
title: "Kodeks postępowania w sprawach o wykroczenia"
short: "KPW"
unit: "DZIAŁ V"
dz_u: "Dz.U. 2001 Nr 106 poz. 1148"
status: "obowiązujący"
last_consolidated: "2025-09-09"
articles: "Art. 39–44"
source: "D20011148Lj (1).pdf"
---
DZIAŁ V

Dowody

## Rozdział 6

Przepisy ogólne


## Art. 39. {#kpw-art-39}
 § 1. Dowody przeprowadza się na wniosek stron albo z urzędu. Przepis

art. 168 Kodeksu postępowania karnego stosuje się.

§ 2. Do wniosku dowodowego stosuje się odpowiednio przepisy art. 169

i 170 Kodeksu postępowania karnego, a przy przeprowadzaniu dowodu także

art. 171–173 Kodeksu postępowania karnego.

§ 3. Poza rozprawą o dopuszczeniu dowodu

lub o jego zabezpieczeniu

rozstrzyga prezes sądu, sąd albo organ prowadzący czynności wyjaśniające,

a w sprawach osób podlegających orzecznictwu sądów wojskowych także prokurator

do spraw wojskowych.

§ 4. Dowodu z wyjaśnień lub zeznań nie wolno zastępować treścią pism,

zapisków lub notatek urzędowych, chyba że ustawa stanowi inaczej.


## Art. 40. {#kpw-art-40}
 § 1. Na wniosek osoby przesłuchiwanej przyjmuje się od niej

oświadczenie na piśmie.

§ 2. W wypadku, o którym mowa w § 1, należy umożliwić

tej osobie

sporządzenie oświadczenia w warunkach uniemożliwiających porozumienie się

z innymi osobami, a następnie przesłuchać ją w celu wyjaśnienia, uzupełnienia lub

2025-09-09








s. 18/62

uściślenia okoliczności zawartych w oświadczeniu pisemnym. Oświadczenie pisemne

stanowi załącznik do protokołu.

§ 3. Wyjaśnienia lub zeznania, złożone w formie oświadczenia pisemnego

w postępowaniu przed sądem, odczytuje się.

## Rozdział 7

Przeprowadzanie poszczególnych dowodów. Przeszukanie


## Art. 41. {#kpw-art-41}
 § 1. Przy przeprowadzaniu dowodu z zeznań świadka stosuje się

odpowiednio przepisy art. 177, art. 178, art. 178a, art. 182, art. 183, art. 185–190,

art. 191 § 1–2 oraz art. 192 Kodeksu postępowania karnego.

§ 2. Osoby obowiązane do zachowania w tajemnicy informacji niejawnych

o klauzuli tajności „tajne” lub „ściśle tajne” mogą być przesłuchane co do

okoliczności, na które rozciąga się ten obowiązek, tylko po zwolnieniu tych osób od

obowiązku zachowania tajemnicy przez uprawniony organ przełożony.

§ 3. Osoby obowiązane do zachowania w tajemnicy informacji niejawnych

o klauzuli

tajności „zastrzeżone”

lub „poufne”

lub

tajemnicy związanej

z wykonywaniem zawodu lub funkcji mogą odmówić zeznań co do okoliczności, na

które rozciąga się ten obowiązek, chyba że sąd zwolni te osoby od obowiązku

zachowania

tajemnicy,

jeżeli ustawy szczególne nie stanowią

inaczej. Na

postanowienie sądu służy zażalenie.

§ 4. Sąd nie może zwolnić jednak od obowiązku zachowania:

1)

tajemnicy związanej z wykonywaniem zawodu adwokata, radcy prawnego,

lekarza lub dziennikarza;

2)

tajemnicy statystycznej.

§ 5. W wypadkach wskazanych w § 2 i 3 sąd przesłuchuje taką osobę na

rozprawie z wyłączeniem

jawności. Przepisy wydane na podstawie art. 181

§ 2 Kodeksu postępowania karnego stosuje się odpowiednio.


## Art. 42. {#kpw-art-42}
 § 1. Przy przeprowadzaniu dowodu z opinii biegłego stosuje się

odpowiednio przepisy art. 193–201 Kodeksu postępowania karnego.

§ 2. W razie uzasadnionych wątpliwości co do stanu zdrowia psychicznego

obwinionego sąd lub prokurator działający na podstawie art. 56 § 1 powołuje biegłego

psychiatrę. Przepis art. 202 § 5 Kodeksu postępowania karnego stosuje się

odpowiednio.

2025-09-09








s. 19/62

§ 3. Do tłumacza i specjalistów stosuje się odpowiednio przepisy art. 204–

206 Kodeksu postępowania karnego.


## Art. 43. {#kpw-art-43}
 Przy przeprowadzaniu oględzin i eksperymentu procesowego stosuje się

odpowiednio przepisy art. 207, 208, 211 i 212 Kodeksu postępowania karnego.


## Art. 44. {#kpw-art-44}
 § 1. W celu znalezienia i zatrzymania przedmiotów podlegających

oględzinom lub mogących stanowić dowód rzeczowy, Policja, a w toku czynności

wyjaśniających również inne organy je prowadzące, mogą dokonać przeszukania

pomieszczeń i innych miejsc, jeżeli istnieją uzasadnione podstawy do przypuszczenia,

że przedmioty te lub dowody tam się znajdują.

§ 2. Przepis § 1 stosuje się odpowiednio do przeszukania osoby, jej odzieży lub

podręcznych przedmiotów. Przeszukanie osoby odbywa się z uwzględnieniem zasad

i granic określonych w art. 227 Kodeksu postępowania karnego.

§ 3. Przeszukanie następuje na mocy postanowienia prokuratora lub sądu.

§ 4. W wypadkach niecierpiących zwłoki, jeżeli postanowienie nie mogło być

uprzednio wydane, można przeprowadzić przeszukanie bez takiego postanowienia,

jednak organ dokonujący tej czynności zobowiązany jest następnie zwrócić się

niezwłocznie do prokuratora o zatwierdzenie przeszukania. Na żądanie osoby, u której

dokonano przeszukania, doręcza się

jej w terminie 14 dni postanowienie

w przedmiocie zatwierdzenia przeszukania. O prawie wystąpienia z takim żądaniem

należy ją pouczyć.

§ 5. Przy przeprowadzaniu przeszukania i zatrzymania przedmiotów stosuje się

odpowiednio przepisy art. 217, 221–234 i 236 Kodeksu postępowania karnego.
