---
title: "Kodeks postępowania w sprawach o wykroczenia"
short: "KPW"
unit: "DZIAŁ IV"
dz_u: "Dz.U. 2001 Nr 106 poz. 1148"
status: "obowiązujący"
last_consolidated: "2025-09-09"
articles: "Art. 32–38"
source: "D20011148Lj (1).pdf"
---
DZIAŁ IV

Czynności procesowe


## Art. 32. {#kpw-art-32}
 § 1. Rozstrzygnięcia zapadają w postaci orzeczeń, zarządzeń albo

mandatów karnych.

2025-09-09








s. 12/62

§ 2. Orzeczenie wydaje

się w formie wyroku

lub

postanowienia.

Postanowieniem rozstrzyga się, gdy ustawa nie wymaga wydania wyroku.

§ 3. Postanowienie wydaje sąd, prezes sądu i upoważniony sędzia, a w toku

czynności wyjaśniających również organ prowadzący te czynności. W kwestii

niewymagającej postanowienia wydaje się zarządzenie.

§ 3a. Postanowienia i zarządzenia, o których mowa w § 3, może wydawać także

referendarz sądowy, gdy ustawa to przewiduje.

§ 4. W sprawach osób podlegających orzecznictwu sądów wojskowych przepis

§ 3 odnosi się także do prokuratora do spraw wojskowych.

§ 5. Przepisy art. 94, 95 i 97 Kodeksu postępowania karnego stosuje się

odpowiednio.


## Art. 33. {#kpw-art-33}
 Strony mogą uczestniczyć w posiedzeniu, jeżeli ustawa to przewiduje

albo gdy prezes sądu lub sąd tak zarządzi.


## Art. 34. {#kpw-art-34}
 Podstawę orzeczenia może stanowić tylko całokształt okoliczności

ujawnionych w postępowaniu, mających znaczenie dla rozstrzygnięcia.


## Art. 35. {#kpw-art-35}
 § 1. Wyrok sądu pierwszej instancji uzasadnia się i doręcza stronie wraz

z uzasadnieniem jedynie na jej żądanie zgłoszone w zawitym terminie 7 dni od daty

jego ogłoszenia, chyba że ustawa stanowi inaczej.

§ 2. Wyrok zaoczny doręcza się z urzędu obwinionemu i jego obrońcy, jeżeli

został ustanowiony. Termin do żądania doręczenia uzasadnienia tego wyroku albo

przekładu uzasadnienia wyroku zaocznego przedstawionego wyłącznie w formie

ustnej, biegnie od daty doręczenia wyroku.

§ 3. (uchylony)


## Art. 36. {#kpw-art-36}
 § 1. Postanowienie i zarządzenie uzasadnia się jedynie, gdy podlega ono

zaskarżeniu. Uzasadnienie sporządza się wówczas z urzędu i doręcza się je wraz

z rozstrzygnięciem osobom, którym przysługuje środek odwoławczy, jeżeli nie brały

udziału w rozprawie lub posiedzeniu albo nie były obecne przy ogłoszeniu

rozstrzygnięcia, chyba że oddaliły się samowolnie.

§ 2. Orzeczenie wydane w wyniku rozpoznania środka zaskarżenia uzasadnia się

z urzędu, chyba że ustawa stanowi inaczej.

2025-09-09








s. 13/62


## Art. 37. {#kpw-art-37}
 § 1. Protokół sporządza się z każdej czynności mającej

istotne

znaczenie dla sprawy, a w szczególności z rozprawy, a także z dokonanych poza

rozprawą czynności dowodowych, chyba że ustawa stanowi inaczej.

§ 2. Z rozprawy sporządza się:

1)

protokół utrwalający przebieg rozprawy za pomocą urządzenia rejestrującego

dźwięk albo obraz i dźwięk oraz

2)

protokół pisemny.

§ 3. O utrwalaniu przebiegu rozprawy za pomocą urządzenia rejestrującego

dźwięk albo obraz i dźwięk należy uprzedzić osoby uczestniczące w rozprawie.

§ 4. Protokół, o którym mowa w § 2 pkt 1, podpisuje protokolant podpisem

elektronicznym

gwarantującym

identyfikację

osoby

protokolanta

oraz

rozpoznawalność jakiejkolwiek późniejszej zmiany protokołu. Protokół ten nie

podlega sprostowaniu.

§ 5. Protokół pisemny, o którym mowa w § 2 pkt 2, jest jednobrzmiący

z zapisem tekstowym i jest sporządzany przy użyciu systemu teleinformatycznego

służącego do utrwalania przebiegu rozprawy za pomocą urządzenia rejestrującego

dźwięk albo obraz i dźwięk oraz powinien zawierać:

1)

oznaczenie rozpoznawanej sprawy, sądu, czasu i miejsca rozprawy oraz –

w zakresie niezbędnym ze względu na cele postępowania lub określonym przez

przepisy szczególne – osób w niej uczestniczących;

2) wzmiankę co do jawności rozprawy i trybu postępowania;

3) wydane na rozprawie postanowienia i zarządzenia, a jeżeli postanowienie lub

zarządzenie sporządzono osobno – wzmiankę o jego wydaniu;

4) wniesione ustnie na rozprawie zażalenia;

5) wzmiankę o złożeniu lub cofnięciu żądania ścigania wykroczenia, o odstąpieniu

oskarżyciela od oskarżenia, o wstąpieniu prokuratora do postępowania,

o złożeniu przez obwinionego wniosku o skazanie go w określony sposób bez

przeprowadzania postępowania dowodowego, o prowadzeniu sprawy w trybie

przyspieszonym i godzinie doprowadzenia obwinionego albo o odstąpieniu od

jego przymusowego doprowadzenia, o złożeniu przez stronę w trybie przy-

spieszonym wniosku o sporządzenie uzasadnienia wyroku, a także o cofnięciu

środka zaskarżenia.

§ 6. Jeżeli jest to niezbędne dla zapewnienia prawidłowego orzekania w sprawie,

prezes sądu może zarządzić sporządzenie przekładu odpowiedniej części protokołu,

2025-09-09








s. 14/62

o którym mowa w § 2 pkt 1. Przekład stanowi załącznik do protokołu. Przepis § 10

stosuje się odpowiednio.

§ 7. Jeżeli ze względów technicznych utrwalenie przebiegu rozprawy za pomocą

urządzenia rejestrującego dźwięk albo obraz i dźwięk nie jest możliwe, sporządza się

wyłącznie protokół pisemny.

§ 8. Protokół rozprawy sporządza pracownik sekretariatu albo inna osoba

upoważniona przez prezesa sądu.

§ 9. Przebieg także innych niż rozprawa czynności protokołowanych może być

ponadto utrwalony za pomocą urządzenia rejestrującego dźwięk albo obraz i dźwięk,

o czym należy uprzedzić osoby uczestniczące w czynności. Zapis taki i jego przekład,

jeżeli został sporządzony, są załącznikami do protokołu.

§ 10. Strony i osoby mające w tym interes prawny mogą złożyć wniosek

o sprostowanie protokołu pisemnego rozprawy lub posiedzenia, wskazując na

nieścisłości lub opuszczenia. W przedmiocie sprostowania protokołu rozstrzyga, po

wysłuchaniu protokolanta, sędzia, który prowadził czynność. Jeżeli przebieg rozprawy

lub posiedzenia został utrwalony za pomocą urządzenia rejestrującego dźwięk albo

obraz i dźwięk, sędzia przed rozstrzygnięciem w przedmiocie sprostowania zapoznaje

się również z odpowiednim fragmentem tego zapisu.

§ 11. Do protokołu pisemnego stosuje się odpowiednio przepisy art. 144 § 2 i 3,

art. 146, art. 149 § 1, art. 150, art. 151, art. 153 § 3 i 4, art. 154 oraz art. 155 Kodeksu

postępowania karnego, a w przypadku:

1)

protokołu pisemnego innego niż ten, o którym mowa w § 2 pkt 2, stosuje się

odpowiednio także przepisy art. 145, art. 148 § 1, 2, 3 i 4 i art. 149 § 2 Kodeksu

postępowania karnego;

2)

protokołu z posiedzenia

lub z dokonanych poza

rozprawą czynności

dowodowych stosuje się odpowiednio także przepis art. 147 § 3 i przepisy

wydane na podstawie art. 147 § 5 Kodeksu postępowania karnego.

§ 12. Czynności, z których nie sporządza się protokołu, a także inne zdarzenia,

które mają znaczenie dla postępowania, utrwala się w aktach w formie notatki

urzędowej podpisanej przez osobę, która dokonała tych czynności.

§ 13. Na wniosek pokrzywdzonego lub świadka stosuje się odpowiednio

przepisy art. 148a oraz art. 156a Kodeksu postępowania karnego, chyba że utrudni to

postępowanie lub sprzeciwia się temu ważny interes jego uczestnika. O prawie tym

należy pokrzywdzonego i świadka pouczyć.

2025-09-09








s. 15/62

Art. 37a. Minister Sprawiedliwości określi, w drodze rozporządzenia, rodzaje

urządzeń i środków technicznych służących do utrwalania dźwięku albo obrazu

i dźwięku, sposób i tryb sporządzania zapisów dźwięku albo obrazu i dźwięku,

identyfikacji osób je sporządzających, sposób użycia systemu teleinformatycznego

służącego do utrwalania przebiegu rozprawy za pomocą urządzenia rejestrującego

dźwięk albo obraz i dźwięk do sporządzania protokołu pisemnego, o którym mowa

w art. 37 § 2 pkt 2, jak również sposób przechowywania tych zapisów oraz warunki

i sposób wprowadzenia zmiany wymaganej względami technicznymi lub zakresem

czynności, z której sporządza się protokół, mając na uwadze konieczność:

1) właściwego zabezpieczenia zapisu dźwięku albo obrazu i dźwięku przed ich

utratą, zniekształceniem, nieuprawnionym dostępem, usunięciem lub inną

nieuprawnioną zmianą, a także rozpoznawalność wprowadzenia zmiany

wymaganej względami technicznymi i identyfikacji osoby dokonującej tych

czynności;

2)

zmiany formatu zapisu dźwięku albo obrazu i dźwięku lub przeniesienia na inny

informatyczny nośnik danych w celu ponownego odtworzenia zapisu;

3)

zapewnienia możliwości użycia systemu teleinformatycznego służącego do

utrwalania przebiegu rozprawy za pomocą urządzenia rejestrującego dźwięk albo

obraz i dźwięk do sporządzania protokołu pisemnego, o którym mowa w art. 37

§ 2 pkt 2, w sposób umożliwiający wewnętrzną synchronizację obu funkcji

systemu oraz właściwe zabezpieczenie zapisu

tekstowego na nośniku

elektronicznym przed jego utratą, zniekształceniem, nieuprawnionym dostępem,

usunięciem lub inną nieuprawnioną zmianą;

4)

zapewnienia możliwości przekazania zapisów dźwięku albo obrazu i dźwięku

oraz zapisu tekstowego, stanowiących materiały archiwalne, do archiwów

państwowych w sposób uporządkowany, określony w przepisach o narodowym

zasobie archiwalnym i archiwach.

Art. 37b. § 1. Strony, obrońcy, pełnomocnicy i przedstawiciele ustawowi mają

prawo do zapoznania się z zapisem dźwięku albo obrazu i dźwięku z rozprawy

w siedzibie

sądu,

a obwiniony

pozbawiony wolności

– w administracji

odpowiedniego zakładu, oraz do bezpłatnego otrzymania z akt sprawy, za pomocą

środków komunikacji elektronicznej, zapisu dźwięku z rozprawy, chyba że został

2025-09-09








s. 16/62

sporządzony wyłącznie protokół pisemny, o którym mowa w art. 37 § 7. Przepis

art. 156 § 4 Kodeksu postępowania karnego stosuje się odpowiednio.

§ 2. Wydanie na wniosek zapisu dźwięku z rozprawy na informatycznym

nośniku danych następuje odpłatnie.

§ 3. Minister Sprawiedliwości określi, w drodze rozporządzenia, sposób i tryb

udostępniania stronom, obrońcom, pełnomocnikom i przedstawicielom ustawowym

zapisu dźwięku albo obrazu i dźwięku z rozprawy w siedzibie sądu, a obwinionemu

pozbawionemu wolności – w administracji odpowiednego

zakładu, oraz

przekazywania im z akt sprawy zapisu dźwięku z rozprawy, jak też wysokość opłaty

za wydanie zapisu dźwięku z rozprawy na informatycznym nośniku danych, mając na

uwadze konieczność niezwłocznego i szerokiego, w tym bezpłatnego, dostępu

uczestników postępowania do tego zapisu oraz niezwłocznego uzyskania z akt sprawy

zapisu dźwięku z rozprawy, a także zapewnienia, by wysokość opłaty odpowiadała

kosztom jego wydania.


## ### [Obowiązuje]

Art. 38. {#kpw-art-38}
 [§ 1. Do czynności procesowych prowadzonych w postępowaniu

w sprawach o wykroczenia stosuje się odpowiednio także przepisy art. 95, art. 100 § 1

i 8, art. 105, art. 107, art. 108, art. 116–134, art. 136–142, art. 143 § 1 pkt 10,

art. 156 § 1–5 i 6, art. 157, art. 158, art. 160–166 Kodeksu postępowania karnego,

a gdy

sąd orzeka

jednoosobowo,

również przepisy art. 109–115 Kodeksu

postępowania karnego.]

<§ 1. Do

czynności

procesowych

prowadzonych w postępowaniu

w sprawach o wykroczenia stosuje się odpowiednio także przepisy art. 95,

art. 100 § 1 i 8, art. 100a, art. 105, art. 107, art. 108, art. 116–134, art. 136–142,

art. 143 § 1 pkt 10, art. 156 § 1–5 i 6, art. 157, art. 158, art. 160–166 oraz art. 300a

Kodeksu postępowania karnego, a gdy sąd orzeka jednoosobowo, również

przepisy art. 109–115 Kodeksu postępowania karnego.>

§ 1a. Na odmowę udostępnienia akt osobie, o której mowa w art. 4 § 2,

przysługuje zażalenie do sądu.

[§ 2. Przy pierwszym wysłuchaniu oraz w wypadku, o którym mowa w art. 54

§ 7, osoba podejrzana o popełnienie wykroczenia ma obowiązek wskazać adres dla

doręczeń w kraju; w razie nieuczynienia tego pismo wysłane pod ostatnio znanym

adresem w kraju albo jeżeli adresu tego nie ma, załączone do akt sprawy, uważa się

2025-09-09

Nowe brzmienia
§ 1 i 2 w art. 38
wejdą w życie z
dn. 1.10.2029 r.
(Dz. U. z 2020 r.
poz. 2320, z 2021
r. poz. 1135, z
2022 r. poz. 1002
i 2754 oraz z 2023
r. poz. 1860
i
2699).








s. 17/62

za doręczone, o czym należy ją pouczyć. Pouczenie to odnotowuje się w protokole,

o którym mowa w art. 54 § 6, lub w notatce wskazanej w art. 54 § 7.]

<§ 2. Przy pierwszym wysłuchaniu oraz w wypadku, o którym mowa

w art. 54 § 7, osoba podejrzana o popełnienie wykroczenia ma obowiązek

wskazać adres dla doręczeń w kraju lub złożyć oświadczenie o wyrażeniu zgody

na dokonywanie doręczeń na adres do doręczeń elektronicznych wraz

z podaniem tego adresu albo o braku takiej zgody. W razie niewskazania adresu

dla doręczeń w kraju lub niezłożenia oświadczenia o wyrażeniu zgody pismo

wysłane pod ostatnio znanym adresem w kraju albo jeżeli adresu tego nie ma,

załączone do akt sprawy, uważa się za doręczone, o czym należy ją pouczyć.

Pouczenie to odnotowuje się w protokole, o którym mowa w art. 54 § 6, lub

w notatce wskazanej w art. 54 § 7.>
