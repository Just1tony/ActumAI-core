---
title: "Kodeks postępowania w sprawach o wykroczenia"
short: "KPW"
unit: "Preambuła"
dz_u: "Dz.U. 2001 Nr 106 poz. 1148"
status: "obowiązujący"
last_consolidated: "2025-09-09"
articles: null
source: "D20011148Lj (1).pdf"
---
s. 1/62

Dz. U. 2001 Nr 106 poz. 1148

Opracowano na
podstawie:
t.j.
Dz. U. z 2025 r.
poz. 860, 1178.

U S T A W A

z dnia 24 sierpnia 2001 r.

Kodeks postępowania w sprawach o wykroczenia
