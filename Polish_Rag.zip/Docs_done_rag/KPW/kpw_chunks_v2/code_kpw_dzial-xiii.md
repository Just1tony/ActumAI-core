---
title: "Kodeks postępowania w sprawach o wykroczenia"
short: "KPW"
unit: "DZIAŁ XIII"
dz_u: "Dz.U. 2001 Nr 106 poz. 1148"
status: "obowiązujący"
last_consolidated: "2025-09-09"
articles: "Art. 117–121"
source: "D20011148Lj (1).pdf"
---
DZIAŁ XIII

Koszty postępowania


## Art. 117. {#kpw-art-117}
 § 1. Jeżeli ustawa nie stanowi inaczej, wszelkie wydatki w toku

postępowania w sprawach o wykroczenia, w tym wydatki ponoszone w toku

czynności wyjaśniających, wykłada tymczasowo Skarb Państwa.

§ 2. Wydatki związane z ustanowieniem obrońcy lub pełnomocnika wykłada

strona, która go ustanowiła.

2025-09-09








s. 61/62

§ 3. Wydatki, o których mowa w § 1, ponoszone w toku czynności

wyjaśniających przeprowadzanych przez organ podległy władzom

jednostki

samorządu terytorialnego wykłada tymczasowo właściwa jednostka samorządu

terytorialnego.


## Art. 118. {#kpw-art-118}
 § 1. Wydatki wykładane przez Skarb Państwa lub jednostkę samorządu

terytorialnego mają charakter

zryczałtowany. Zryczałtowane wydatki nie obejmują:

należności biegłych lub instytucji wyznaczonych do wydania opinii;

nieopłaconej przez strony pomocy prawnej udzielonej z urzędu przez adwokatów

1)

2)

lub radców prawnych.

§ 2. Minister Sprawiedliwości określi, w drodze rozporządzenia, wysokość

zryczałtowanych wydatków postępowania w sprawach o wykroczenia, w tym

wysokość

zryczałtowanych wydatków

ponoszonych w

toku

czynności

wyjaśniających, a także wysokość opłaty, o której mowa w art. 113 § 2, uwzględniając

przeciętne koszty poszczególnych czynności.


## Art. 119. {#kpw-art-119}
 § 1. W razie skazania od obwinionego sąd zasądza opłatę na rzecz

Skarbu Państwa, zryczałtowane wydatki i należności, o których mowa w art. 118 § 1

pkt 1 i 2, na rzecz odpowiednio Skarbu Państwa lub jednostki samorządu

terytorialnego oraz wydatki na rzecz oskarżyciela posiłkowego.

§ 2. W razie uniewinnienia obwinionego lub umorzenia postępowania koszty

postępowania ponosi:

1) w sprawie, w której wniosek o ukaranie złożył oskarżyciel publiczny –

odpowiednio Skarb Państwa lub jednostka samorządu terytorialnego, z

wyjątkiem należności z tytułu udziału adwokata lub radcy prawnego w

charakterze pełnomocnika oskarżyciela posiłkowego;

2) w sprawie, w której wniosek o ukaranie złożył oskarżyciel posiłkowy –

oskarżyciel posiłkowy, a w razie umorzenia postępowania w przypadku

określonym w art. 31 § 1 – odpowiednio Skarb Państwa lub jednostka samorządu

terytorialnego.

§ 3. Koszty postępowania mediacyjnego ponosi odpowiednio Skarb Państwa lub

jednostka samorządu terytorialnego.

2025-09-09








s. 62/62

§ 4. Koszty związane z udziałem w postępowaniu tłumacza w zakresie

koniecznym dla zapewnienia obwinionemu jego prawa do obrony ponosi odpowiednio

Skarb Państwa lub jednostka samorządu terytorialnego.


## Art. 120. {#kpw-art-120}
 § 1. Zażalenie na postanowienie organu prowadzącego czynności

wyjaśniające w przedmiocie kosztów wnosi się do organu nadrzędnego, a w

przypadku:

1)

czynności wyjaśniających przeprowadzanych przez straż gminną (miejską) – do

prokuratora;

2)

czynności wyjaśniających przeprowadzanych przez prokuratora – do prokuratora

nadrzędnego.

§ 2. Jeżeli organ nadrzędny, prokurator albo prokurator nadrzędny nie przychyli

się do zażalenia, kieruje je do sądu właściwego do rozpoznania sprawy.


## Art. 121. {#kpw-art-121}
 § 1. Do kosztów postępowania stosuje się odpowiednio przepisy art.

616, art. 618 § 1 i 3, art. 618a–618l, art. 623, art. 624 § 1, art. 625, art. 626, art. 630,

art. 632a–635, art. 636 § 1 i 2, art. 637–639 i art. 641 Kodeksu postępowania karnego,

przy czym wydatkami są także wydatki Skarbu Państwa i jednostki samorządu

terytorialnego ponoszone w toku czynności wyjaśniających.

§ 2. Rodzaje i wysokość opłat oraz zasady i tryb ich wymierzania określa odrębna

ustawa.

2025-09-09
