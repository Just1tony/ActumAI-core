---
title: "Kodeks postępowania w sprawach o wykroczenia"
short: "KPW"
unit: "DZIAŁ VII"
dz_u: "Dz.U. 2001 Nr 106 poz. 1148"
status: "obowiązujący"
last_consolidated: "2025-09-09"
articles: "Art. 54–56"
source: "D20011148Lj (1).pdf"
---
DZIAŁ VII

Czynności wyjaśniające


## Art. 54. {#kpw-art-54}
 § 1. W celu ustalenia, czy

istnieją podstawy do wystąpienia

z wnioskiem o ukaranie oraz zebrania danych niezbędnych do sporządzenia takiego

wniosku, Policja z urzędu przeprowadza czynności wyjaśniające. Czynności te

w miarę możności należy podjąć w miejscu popełnienia czynu bezpośrednio po jego

ujawnieniu. Powinny one być zakończone w ciągu miesiąca od ich podjęcia.

§ 2. Jeżeli czynności wyjaśniające nie dostarczyły podstaw do wniesienia

wniosku o ukaranie, zawiadamia się o tym ujawnionych pokrzywdzonych oraz osobę,

o której mowa w art. 56a, wskazując przyczynę niewniesienia wniosku o ukaranie.

Zawiadamiając pokrzywdzonego, poucza się go także o prawie, o którym mowa

w art. 27 § 2, oraz o możliwości zaznajomienia się z materiałem dowodowym

uzyskanym w toku czynności wyjaśniających oraz sporządzania odpisów i kopii. Na

wniosek pokrzywdzonego lub jego pełnomocnika wydaje się odpłatnie kopie

i uwierzytelnione odpisy tych materiałów; do odpłatności za wydawanie kopii

i uwierzytelnionych odpisów stosuje się odpowiednio przepisy wydane na podstawie

art. 156 § 6 Kodeksu postępowania karnego.

§ 3. Jeżeli okoliczności czynu nie budzą wątpliwości, utrwalenie czynności

wyjaśniających można ograniczyć do sporządzenia notatki urzędowej, zawierającej

ustalenia niezbędne do sporządzenia wniosku o ukaranie. Notatka powinna zawierać

wskazanie rodzaju czynności, czasu i miejsca oraz osób uczestniczących, a także

krótki opis przebiegu czynności i podpis osoby, która sporządziła notatkę.

§ 4. Jeżeli okoliczności czynu budzą wątpliwości, dla realizacji celu określonego

w § 1 można, z urzędu lub na wniosek pokrzywdzonego albo osoby, o której mowa

w § 5 i 6, przeprowadzić odpowiedni dowód. Utrwalenie takiej czynności następuje

w formie protokołu.

§ 5. W stosunku do osoby podejrzanej o popełnienie wykroczenia stosuje się

odpowiednio przepisy art. 74 § 3 i 3a i art. 308 § 1 Kodeksu postępowania karnego.

§ 6. Należy niezwłocznie przesłuchać osobę, co do której istnieje uzasadniona

podstawa do sporządzenia przeciwko niej wniosku o ukaranie. Osoba taka ma prawo

odmówić złożenia wyjaśnień oraz zgłosić wnioski dowodowe, o czym należy ją

pouczyć. Przesłuchanie tej osoby zaczyna się od powiadomienia jej o treści zarzutu

wpisanego do protokołu przesłuchania; przepis § 4 zdanie drugie stosuje się.

2025-09-09








s. 25/62

§ 6a. Osoba przesłuchana w trybie określonym w § 6 ma obowiązek

informowania organu prowadzącego czynności wyjaśniające o każdej zmianie miejsca

swego zamieszkania lub pobytu trwającego dłużej niż 7 dni oraz stawienia się na

wezwanie tego organu pod rygorem zatrzymania i przymusowego doprowadzenia,

o czym należy ją pouczyć przy przesłuchaniu, odnotowując to w protokole tej

czynności.

§ 7. Od przesłuchania osoby, o której mowa w § 6, można odstąpić, jeżeli byłoby

ono połączone ze znacznymi trudnościami; osoba ta może nadesłać wyjaśnienia do

właściwego organu w terminie 7 dni od odstąpienia od przesłuchania, o czym należy

ją pouczyć. Odstąpienie od przesłuchania oraz pouczenie dokumentuje się notatką

urzędową.

§ 8. Przepis art. 213 § 1 Kodeksu postępowania karnego

stosuje

się

odpowiednio.

§ 9. W ramach czynności wyjaśniających organ

je prowadzący może,

z inicjatywy lub za zgodą osoby określonej w § 6 i pokrzywdzonego, skierować

sprawę do instytucji lub osoby do tego uprawnionej w celu przeprowadzenia mediacji.

Przepis art. 23a Kodeksu postępowania karnego stosuje się odpowiednio.

§ 10. W toku czynności wyjaśniających w sprawach o wykroczenia określone

w art. 119 § 1, art. 120 § 1, art. 122 § 1 i 2 oraz art. 124 § 1 ustawy z dnia 20 maja

1971 r. – Kodeks wykroczeń (Dz. U. z 2025 r. poz. 734) organ prowadzący uzyskuje

ze zbioru danych dotyczącego sprawców wykroczeń, o którym mowa w art. 20f ust. 4

ustawy z dnia 6 kwietnia 1990 r. o Policji (Dz. U. z 2025 r. poz. 636 i 718), informacje

o wcześniejszym popełnieniu tego rodzaju wykroczeń przez osobę, o której mowa

w § 6.


## Art. 55. {#kpw-art-55}
 § 1. Czynności wyjaśniające przeprowadza

się

także w celu

uzupełnienia lub sprawdzenia faktów podanych we wniosku o ukaranie w wypadku

wskazanym w art. 60 § 1 pkt 6.

§ 2. Czynności wskazane w § 1 należy przeprowadzić w terminie oraz

w zakresie określonym poleceniem sądu, chyba że w toku wykonywania tych

czynności wyjdą na jaw okoliczności wymagające utrwalenia dowodu, którego nie

będzie można powtórzyć przed sądem, lub znalezienia i zatrzymania przedmiotu.

2025-09-09








s. 26/62

§ 3. W razie przesłuchiwania w ramach czynności, o których mowa w § 1,

obwinionego wskazanego we wniosku o ukaranie, przepisy art. 54 § 6 stosuje się

odpowiednio.


## Art. 56. {#kpw-art-56}
 § 1. Czynności wyjaśniające, o których mowa w art. 54, może także

przeprowadzić prokurator lub zlecić je Policji.

§ 2. Przepisy art. 54 i 55 stosuje się odpowiednio do organów wskazanych

w art. 17 § 2 i 3, w granicach ich właściwości, a także do innych organów, gdy ustawa

tak stanowi.

§ 3. Instytucje, którym nadano uprawnienia oskarżyciela publicznego w drodze

rozporządzenia określonego w art. 17 § 4, mogą w sprawie, w której ujawniły

wykroczenie, zwracać się do Policji o przeprowadzenie czynności wyjaśniających

w zakresie niezbędnym do ustalenia, czy istnieją podstawy do wystąpienia

z wnioskiem o ukaranie oraz do zebrania danych koniecznych do sporządzenia

wniosku o ukaranie.

§ 4. Nadzór nad czynnościami wyjaśniającymi sprawuje organ nadrzędny nad

organem prowadzącym te czynności.

Art. 56a. Jeżeli nie zachodzą okoliczności określone w art. 27, osobie, która

złożyła zawiadomienie o popełnieniu wykroczenia, przysługuje zażalenie do organu

nadrzędnego na niewniesienie wniosku o ukaranie.
