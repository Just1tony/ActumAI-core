---
title: "Kodeks postępowania w sprawach o wykroczenia"
short: "KPW"
unit: "DZIAŁ XI"
dz_u: "Dz.U. 2001 Nr 106 poz. 1148"
status: "obowiązujący"
last_consolidated: "2025-09-09"
articles: "Art. 110–113"
source: "D20011148Lj (1).pdf"
---
DZIAŁ XI

Nadzwyczajne środki zaskarżenia

## Rozdział 18

Kasacja


## Art. 110. {#kpw-art-110}
 § 1. Kasację w sprawach o wykroczenia może wnieść wyłącznie

Prokurator Generalny lub Rzecznik Praw Obywatelskich, w sprawach podlegających

orzecznictwu sądów wojskowych także Zastępca Prokuratora Generalnego do Spraw

Wojskowych, a w sprawach naruszenia praw dziecka także Rzecznik Praw Dziecka.

Kasację można wnieść od każdego prawomocnego orzeczenia kończącego

postępowanie sądowe.

§ 2. Niedopuszczalne jest uwzględnienie kasacji na niekorzyść obwinionego

wniesionej po upływie 3 miesięcy od daty uprawomocnienia się orzeczenia.

§ 3. Kasację wnosi się bezpośrednio do Sądu Najwyższego.


## Art. 111. {#kpw-art-111}
 Kasacja może być wniesiona tylko z powodu uchybień wskazanych

w art. 104 § 1 lub innego rażącego naruszenia prawa, jeżeli mogło ono mieć istotny

wpływ na treść orzeczenia; kasacja nie może być wniesiona wyłącznie z powodu

niewspółmierności kary.


## Art. 112. {#kpw-art-112}
 W postępowaniu w przedmiocie kasacji stosuje się odpowiednio

przepisy działu X niniejszego kodeksu oraz art. 522, 526 § 1, art. 529, 530 § 2 i 3,

art. 531 § 1, art. 532 § 1, art. 534 § 2, art. 535–537, 538 § 1 i 3 oraz art. 539 Kodeksu

postępowania karnego.

## Rozdział 19

Wznowienie postępowania


## Art. 113. {#kpw-art-113}
 § 1. Postępowanie sądowe, prowadzone w trybie określonym przez

przepisy rozdziałów 11–16 oraz działu X niniejszego kodeksu, zakończone

prawomocnym orzeczeniem, może być wznowione na wniosek strony, a gdy ustawa

to przewiduje – z urzędu. Do wznowienia tego stosuje się odpowiednio przepisy

art. 540–542, art. 544 § 2 i 3 oraz art. 545–548 Kodeksu postępowania karnego.

§ 2. Do wniosku o wznowienie postępowania strona niebędąca prokuratorem

dołącza dowód wniesienia opłaty sądowej; opłata ta podlega zwrotowi w razie

uwzględnienia wniosku.

2025-09-09








s. 58/62

§ 3. W kwestii wznowienia orzeka na posiedzeniu jednoosobowo sąd okręgowy,

a w sprawie zakończonej orzeczeniem tego sądu – jednoosobowo sąd apelacyjny.

§ 4. W sprawach należących do właściwości sądów wojskowych w kwestii

wznowienia orzeka na posiedzeniu jednoosobowo wojskowy sąd okręgowy, a w

sprawie zakończonej orzeczeniem tego sądu orzeka Sąd Najwyższy.
