---
title: "Kodeks postępowania w sprawach o wykroczenia"
short: "KPW"
unit: "DZIAŁ III"
dz_u: "Dz.U. 2001 Nr 106 poz. 1148"
status: "obowiązujący"
last_consolidated: "2025-09-09"
articles: "Art. 17–31"
source: "D20011148Lj (1).pdf"
---
DZIAŁ III

Strony, obrońcy i pełnomocnicy

## Rozdział 3

Oskarżyciel publiczny


## Art. 17. {#kpw-art-17}
 § 1. Oskarżycielem publicznym we wszystkich sprawach o wykroczenia

jest Policja, chyba że ustawa stanowi inaczej.

2025-09-09








s. 7/62

§ 2. W sprawach o wykroczenia przeciwko prawom pracownika określonych w

Kodeksie pracy, w sprawach o wykroczenia określonych w art. 27–27b ustawy z dnia

9 lipca 2003 r. o zatrudnianiu pracowników tymczasowych (Dz. U. z 2025 r. poz. 236),

w sprawach o wykroczenia określonych w art. 465 ust. 1a ustawy z dnia 12 grudnia

2013 r. o cudzoziemcach (Dz. U. z 2024 r. poz. 769, 1222 i 1688 oraz z 2025 r. poz.

619, 621 i 622), w sprawach o wykroczenia określonych w art. 27–28b ustawy z dnia

10 czerwca 2016 r. o delegowaniu pracowników w ramach świadczenia usług (Dz. U.

z 2024 r. poz. 73 oraz z 2025 r. poz. 621), w sprawach o wykroczenie określone w art.

8e ustawy z dnia 10 października 2002 r. o minimalnym wynagrodzeniu za pracę (Dz.

U. z 2024 r. poz. 1773), w sprawach o wykroczenia określonych w art. 10 ustawy z

dnia 10 stycznia 2018 r. o ograniczeniu handlu w niedziele i święta oraz w niektóre

inne dni (Dz. U. z 2025 r. poz. 301), w sprawach o wykroczenia określonych w art.

362–365 i art. 367 ustawy z dnia 20 marca 2025 r. o rynku pracy i służbach

zatrudnienia (Dz. U. poz. 620), w sprawach o wykroczenia określonych w art. 84

ustawy z dnia 20 marca 2025 r. o warunkach dopuszczalności powierzania pracy

cudzoziemcom na terytorium Rzeczypospolitej Polskiej (Dz. U. poz. 621), a także w

sprawach o inne wykroczenia związane z wykonywaniem pracy zarobkowej, jeżeli

ustawa tak stanowi, oskarżycielem publicznym jest inspektor pracy.

§ 3. Organom administracji rządowej

i samorządowej, organom kontroli

państwowej i kontroli samorządu terytorialnego oraz strażom gminnym (miejskim)

uprawnienia oskarżyciela publicznego przysługują tylko wówczas, gdy w zakresie

swego działania w tym w trakcie prowadzonych czynności wyjaśniających ujawniły

wykroczenia i wystąpiły z wnioskiem o ukaranie.

§ 4. Rada Ministrów może, w drodze rozporządzenia, nadać w sprawach

o wykroczenia uprawnienia oskarżyciela publicznego także innym instytucjom

państwowym, samorządowym lub społecznym, określając zakres spraw, w których

w ramach swego działania mogą występować z wnioskiem o ukaranie za ujawnione

przez siebie wykroczenia, mając na względzie zakres ustawowych uprawnień takich

instytucji oraz potrzebę ochrony dóbr szczególnie narażonych na naruszenia ze strony

sprawców wykroczeń.

§ 5. Udział w sprawie organu, który złożył wniosek o ukaranie, wyłącza Policję

od udziału w sprawie.

2025-09-09








s. 8/62


## Art. 18. {#kpw-art-18}
 § 1. W każdej sprawie o wykroczenie wniosek o ukaranie może wnieść

prokurator, stając się oskarżycielem publicznym.

§ 2. Prokurator może także wstąpić do postępowania wszczętego na podstawie

wniosku o ukaranie wniesionego przez innego oskarżyciela.

§ 3. W wypadkach wskazanych w § 1 i 2 udział prokuratora wyłącza udział

innego oskarżyciela publicznego.

Art. 18a. Udział w rozprawie oskarżyciela publicznego, który złożył wniosek

o ukaranie, jest obowiązkowy, gdy w sprawie występuje obrońca, o którym mowa

w art. 21 § 1.


## Art. 19. {#kpw-art-19}
 § 1. Przepisy art. 40 § 1 pkt 1–4 i 6, § 2 oraz art. 41 i 42 Kodeksu

postępowania karnego stosuje się odpowiednio do oskarżyciela publicznego.

§ 2. W sprawie wyłączenia orzeka organ bezpośrednio przełożony nad osobą

podlegającą wyłączeniu. Przepis art. 48 § 2 Kodeksu postępowania karnego stosuje się

odpowiednio.

## Rozdział 4

Obwiniony i jego obrońca


## Art. 20. {#kpw-art-20}
 § 1. Obwinionym jest osoba, przeciwko której wniesiono wniosek

o ukaranie w sprawie o wykroczenie.

§ 2. Jeżeli obwiniony nie zna języka polskiego, wniosek o ukaranie oraz

rozstrzygnięcia podlegające zaskarżeniu lub kończące postępowanie ogłasza się lub

doręcza obwinionemu wraz z tłumaczeniem.

§ 3. Do obwinionego stosuje się odpowiednio art. 72 § 1 i 2, art. 74 § 1 i 2,

art. 75, art. 76 i art. 175 Kodeksu postępowania karnego.


## Art. 21. {#kpw-art-21}
 § 1. W postępowaniu w sprawie o wykroczenia obwiniony musi mieć

obrońcę przed sądem, jeżeli:

1)

2)

jest głuchy, niemy lub niewidomy;

zachodzi uzasadniona wątpliwość co do jego poczytalności.

§ 2. W wypadku, o którym mowa w § 1 pkt 2, obowiązek korzystania z pomocy

obrońcy ustaje, jeżeli sąd uznaje za uzasadnioną opinię biegłego psychiatry, że czyn

obwinionego nie został popełniony w warunkach wyłączenia lub znacznego

ograniczenia zdolności rozpoznania znaczenia czynu

lub kierowania swoim

postępowaniem i że stan psychiczny obwinionego pozwala na udział w postępowaniu

2025-09-09








s. 9/62

i prowadzenie obrony w sposób samodzielny i rozsądny. Sąd zwalnia wówczas

obrońcę z jego obowiązków.

§ 3. W wypadkach, o których mowa w § 1, udział obrońcy w rozprawie jest

obowiązkowy, a w posiedzeniu, jeżeli ustawa tak stanowi.

§ 4. Jeżeli w wypadkach, o których mowa w § 1, obwiniony nie ma obrońcy

z wyboru, wyznacza mu się obrońcę z urzędu.


## Art. 22. {#kpw-art-22}
 Gdy wymaga tego dobro wymiaru sprawiedliwości, obwinionemu, który

nie ma obrońcy z wyboru, wyznacza się na jego wniosek obrońcę z urzędu, jeżeli w

sposób należyty wykaże, że nie jest w stanie ponieść kosztów obrony bez poważnego

uszczerbku dla niezbędnego utrzymania siebie i rodziny. Podstawą odmowy

wyznaczenia obrońcy z urzędu nie może być skorzystanie przez obwinionego z

nieodpłatnej pomocy prawnej lub nieodpłatnego poradnictwa obywatelskiego, o

których mowa w ustawie z dnia 5 sierpnia 2015 r. o nieodpłatnej pomocy prawnej,

nieodpłatnym poradnictwie obywatelskim oraz edukacji prawnej (Dz. U. z 2024 r. poz.

1534). Przepis art. 78 § 2 Kodeksu postępowania karnego stosuje się.


## Art. 23. {#kpw-art-23}
 § 1. Obrońcę z urzędu wyznacza prezes lub referendarz sądowy sądu

właściwego do rozpoznania sprawy. Na zarządzenie prezesa o odmowie wyznaczenia

obrońcy przysługuje zażalenie do sądu właściwego do rozpoznania sprawy.

§ 1a. Ponowny wniosek o wyznaczenie obrońcy, oparty na tych samych

okolicznościach, pozostawia się bez rozpoznania.

§ 2. Przepis art. 81a Kodeksu postępowania karnego stosuje się odpowiednio.


## Art. 24. {#kpw-art-24}
 § 1. Obrońcą w sprawach o wykroczenia może być adwokat albo radca

prawny.

§ 2. Do obrońcy obwinionego stosuje się odpowiednio przepisy art. 83–

86 Kodeksu postępowania karnego.

§ 3. Ilekroć w przepisach Kodeksu postępowania karnego stosowanych na

podstawie art. 1 § 2 mówi się o obrońcy albo o adwokacie, rozumie się przez to także

radcę prawnego.

## Rozdział 5

Pokrzywdzony, oskarżyciel posiłkowy i pełnomocnicy


## Art. 25. {#kpw-art-25}
 § 1. Pokrzywdzonym jest ten, czyje dobro prawne zostało bezpośrednio

naruszone lub zagrożone przez wykroczenie.

2025-09-09








s. 10/62

§ 2. W razie śmierci pokrzywdzonego prawa, które by mu przysługiwały, mogą

wykonywać osoby najbliższe.

§ 3. Do pokrzywdzonego

stosuje

się odpowiednio art. 49 § 3 oraz

art. 51 Kodeksu postępowania karnego.

§ 4. Pokrzywdzony może działać jako strona w charakterze oskarżyciela

posiłkowego obok oskarżyciela publicznego lub zamiast niego.

§ 5. Do pokrzywdzonego, który

złożył

zawiadomienie o popełnieniu

wykroczenia, stosuje się odpowiednio art. 304b Kodeksu postępowania karnego.


## Art. 26. {#kpw-art-26}
 § 1. O przesłaniu wniosku o ukaranie oskarżyciel publiczny zawiadamia

ujawnionego pokrzywdzonego, wskazując sąd, do którego wniosek skierowano,

i pouczając go o uprawnieniach, o których mowa w § 3.

§ 2. (uchylony)

§ 3. Pokrzywdzony może w terminie 7 dni od zawiadomienia, o którym mowa

w § 1, oświadczyć, że będzie działać obok oskarżyciela publicznego jako oskarżyciel

posiłkowy; po upływie tego terminu uprawnienie wygasa.

§ 4. (uchylony)

§ 5. Art. 54 § 2 i art. 56 Kodeksu postępowania karnego stosuje się odpowiednio.


## Art. 27. {#kpw-art-27}
 § 1. W sprawach o wykroczenia ścigane na żądanie pokrzywdzonego,

pokrzywdzony może samodzielnie wnieść wniosek o ukaranie jako oskarżyciel

posiłkowy.

§ 2. W sprawach o wykroczenia inne niż określone w § 1, pokrzywdzony może

samodzielnie wnieść wniosek o ukaranie jako oskarżyciel posiłkowy, jeżeli w ciągu

miesiąca od powiadomienia o wykroczeniu organu uprawnionego do występowania

w tych sprawach w charakterze oskarżyciela publicznego nie zostanie powiadomiony

o wniesieniu przez ten organ wniosku o ukaranie albo otrzyma zawiadomienie,

o którym mowa w art. 54 § 2.

§ 3. Jeżeli pokrzywdzony złożył wniosek o ukaranie, pomimo że oskarżyciel

publiczny także złożył taki wniosek, wniosek pokrzywdzonego traktuje się jako

oświadczenie wskazane w art. 26 § 3.

§ 4. Prezes sądu lub referendarz sądowy zawiadamia o wniesieniu wniosku

o ukaranie, o którym mowa w § 1 i 2, właściwego oskarżyciela publicznego. Jeżeli

oskarżyciel ten w ciągu 14 dni od otrzymania zawiadomienia wniesie w sprawie o ten

2025-09-09








s. 11/62

sam czyn tej samej osoby publiczny wniosek o ukaranie, wniosek pokrzywdzonego

traktuje się jak oświadczenie wskazane w art. 26 § 3.

§ 5. Art. 55 § 3 Kodeksu postępowania karnego stosuje się.


## Art. 28. {#kpw-art-28}
 § 1. Odstąpienie oskarżyciela posiłkowego, o którym mowa w art. 27

§ 1 i 2, od oskarżenia powoduje umorzenie postępowania. Postanowienie o umorzeniu

postępowania może wydać także referendarz sądowy.

§ 2. Odstąpienie oskarżyciela posiłkowego, o którym mowa w art. 26 § 3, od

oskarżenia nie tamuje rozpoznania sprawy. Art. 57 § 1 Kodeksu postępowania

karnego stosuje się odpowiednio.


## Art. 29. {#kpw-art-29}
 § 1. Niestawiennictwo prawidłowo powiadomionego pokrzywdzonego

i oskarżyciela posiłkowego na rozprawę lub posiedzenie nie tamuje toku sprawy,

chyba że ustawa stanowi inaczej.

§ 2. Niestawiennictwo oskarżyciela posiłkowego, o którym mowa w art. 27 § 1

i 2, bez usprawiedliwienia, uważa się za odstąpienie od oskarżenia; w takim

przypadku sąd umarza postępowanie.


## Art. 30. {#kpw-art-30}
 § 1. Pokrzywdzony i oskarżyciel posiłkowy może korzystać z pomocy

jednego pełnomocnika. Pełnomocnikiem może być adwokat, radca prawny,

a w wypadku, gdy pokrzywdzonym jest instytucja państwowa, samorządowa lub

społeczna, także pracownik tej instytucji lub jej organu nadrzędnego.

§ 2. Do pełnomocnika stosuje się odpowiednio przepisy art. 22 i 23 niniejszego

kodeksu oraz art. 83, 84, 86 § 2 i art. 89 Kodeksu postępowania karnego.


## Art. 31. {#kpw-art-31}
 § 1. W razie śmierci oskarżyciela posiłkowego, o którym mowa

w art. 27 § 1 i 2, sąd lub referendarz sądowy zawiesza postępowanie, a osoby

najbliższe mogą wstąpić w prawa zmarłego. Jeżeli w terminie zawitym miesiąca od

dnia śmierci oskarżyciela osoba uprawniona nie wstąpi w prawa zmarłego, sąd lub

referendarz sądowy umarza postępowanie.

§ 2. W razie śmierci oskarżyciela posiłkowego, wskazanego w art. 26 § 3, osoby

najbliższe mogą przystąpić do postępowania w każdym jego stadium.
