---
title: "Kodeks postępowania w sprawach o wykroczenia"
short: "KPW"
unit: "DZIAŁ I"
dz_u: "Dz.U. 2001 Nr 106 poz. 1148"
status: "obowiązujący"
last_consolidated: "2025-09-09"
articles: "Art. 1–8"
source: "D20011148Lj (1).pdf"
---
DZIAŁ I

Zasady ogólne


## Art. 1. {#kpw-art-1}
 § 1. Postępowanie w sprawach o wykroczenia

toczy się według

przepisów niniejszego kodeksu.

§ 2. W postępowaniu, o którym mowa w § 1, przepisy Kodeksu postępowania

karnego stosuje się jedynie, gdy niniejszy kodeks tak stanowi.


## Art. 2. {#kpw-art-2}
 § 1. Orzekanie następuje w postępowaniu:

1)

2)

3)

zwyczajnym;

przyspieszonym;

nakazowym.

§ 1a. Orzekanie w postępowaniu zwyczajnym następuje wówczas, gdy brak jest

podstaw do rozpoznania sprawy w postępowaniu przyspieszonym albo nakazowym.

§ 2. W wypadkach wskazanych w ustawie i na zasadach w niej określonych

uprawniony organ może nałożyć grzywnę w drodze mandatu karnego.


## Art. 3. {#kpw-art-3}
 W razie stwierdzenia w toku postępowania

istotnego uchybienia

w czynnościach instytucji państwowej, samorządowej lub społecznej, sprzyjającego

naruszeniom prawa, sąd, a w toku czynności wyjaśniających organ je prowadzący,

zawiadamia o stwierdzonym uchybieniu tę instytucję bądź organ powołany do

sprawowania nad nią nadzoru.


## Art. 4. {#kpw-art-4}
 § 1. Obwinionemu przysługuje prawo do obrony, w tym do korzystania

z pomocy jednego obrońcy, o czym należy go pouczyć.

2025-09-09












s. 2/62

§ 2. Prawo, o którym mowa w § 1, przysługuje również osobie określonej

w art. 54 § 6 z chwilą przystąpienia do przesłuchania po powiadomieniu jej o treści

zarzutów albo z chwilą wezwania jej do złożenia pisemnych wyjaśnień. Osobę tę

należy pouczyć o przysługującym jej prawie. Przepisy art. 21–24 stosuje się

odpowiednio.

§ 3. Pouczenie, o którym mowa w § 2, następuje przed przesłuchaniem albo wraz

z wezwaniem do złożenia pisemnych wyjaśnień. Jeżeli pouczenie następuje wraz

z wezwaniem do złożenia pisemnych wyjaśnień, wzmiankę o pouczeniu zamieszcza

się w notatce urzędowej, o której mowa w art. 54 § 7.


## Art. 5. {#kpw-art-5}
 § 1.1) Nie wszczyna się postępowania, a wszczęte umarza, gdy:

1)

czynu nie popełniono albo brak jest danych dostatecznie uzasadniających

podejrzenie jego popełnienia;

2)

czyn nie zawiera znamion wykroczenia albo ustawa stanowi, że sprawca nie

popełnia wykroczenia;

ustawa stanowi, że sprawca nie podlega karze;

nastąpiło przedawnienie orzekania;

obwiniony zmarł;

obwiniony jest:

3)

4)

5)

6)

a) uwierzytelnionym w Rzeczypospolitej Polskiej, szefem przedstawicielstwa

dyplomatycznego państwa obcego,

b) osobą należącą do personelu dyplomatycznego tego przedstawicielstwa,

c) osobą należącą do personelu administracyjnego lub technicznego tego

przedstawicielstwa,

d)

członkiem rodziny osób wymienionych w lit. a–c i pozostaje z nimi we

wspólnocie domowej,

e)

inną osobą korzystającą z immunitetu dyplomatycznego, na podstawie

ustaw, umów lub powszechnie uznanych zwyczajów międzynarodowych,

f)

kierownikiem urzędu konsularnego lub innym urzędnikiem konsularnym

państwa obcego albo inną osobą zrównaną z nimi na podstawie ustaw,

umów lub powszechnie uznanych zwyczajów międzynarodowych;

1) Uznany za niezgodny z Konstytucją z dniem 19 lipca 2018 r. w zakresie, w jakim nie czyni aktu
abolicji
indywidualnej negatywną przesłanką prowadzenia postępowania w sprawach o
wykroczenia, na podstawie wyroku Trybunału Konstytucyjnego z dnia 17 lipca 2018 r. sygn. akt K
9/17 (Dz. U. poz. 1387).

2025-09-09









s. 3/62

7)

obwiniony z mocy przepisów szczególnych nie podlega orzecznictwu na

podstawie niniejszego kodeksu;

8)

postępowanie co do tego samego czynu obwinionego zostało prawomocnie

zakończone lub wcześniej wszczęte, toczy się;

9)

brak jest skargi uprawnionego oskarżyciela albo żądania ścigania pochodzącego

od osoby uprawnionej lub zezwolenia na ściganie, gdy ustawa tego wymaga;

10) zachodzi

inna

okoliczność wyłączająca

z mocy

ustawy

orzekanie

w postępowaniu na podstawie niniejszego kodeksu.

§ 2. Przepisu § 1 pkt 6 nie stosuje się:

1)

do osób w nim wymienionych, jeżeli są obywatelami polskimi lub mają w Polsce

miejsce stałego zamieszkania, przy czym osoby, o których mowa w lit. f, nie

podlegają orzecznictwu na podstawie niniejszego kodeksu, tylko w zakresie

czynności pełnionych w toku i w wykonaniu funkcji urzędowych;

2)

jeżeli umowa międzynarodowa, której Rzeczpospolita Polska jest stroną, stanowi

inaczej.

§ 3. Przepisu § 1 pkt 6 można nie stosować do obywatela państwa obcego,

z którym nie ma w tym przedmiocie umowy, a państwo to nie zapewnia wzajemności.

§ 4. Do chwili otrzymania wymaganego przez ustawę zezwolenia na ściganie lub

żądania ścigania organ prowadzący czynności wyjaśniające może dokonywać

czynności niecierpiących zwłoki w celu zabezpieczenia śladów i dowodów, a także

czynności zmierzających do wyjaśnienia, czy żądanie będzie złożone lub zezwolenie

będzie wydane.


## Art. 6. {#kpw-art-6}
 § 1. W sprawach o wykroczenia ścigane na żądanie pokrzywdzonego

występujący z wnioskiem o ukaranie, jeżeli nie jest nim pokrzywdzony, powinien

uzyskać wymagane żądanie od osoby uprawnionej do jego złożenia. Żądanie może

być złożone na piśmie albo zgłoszone ustnie do protokołu.

§ 2. Żądanie złożone co do niektórych tylko współdziałających w popełnieniu

czynu pozostaje skuteczne także wobec osób niewskazanych w żądaniu, jeżeli nie są

to osoby najbliższe dla pokrzywdzonego, o czym należy pouczyć składającego

żądanie przed jego przyjęciem.

§ 3. Żądanie może być cofnięte. Niedopuszczalne jest cofnięcie żądania wobec

niektórych tylko współdziałających w popełnieniu czynu, chyba że są to osoby

najbliższe dla pokrzywdzonego. Cofnięcie może nastąpić do momentu rozpoczęcia

2025-09-09








s. 4/62

przewodu sądowego na pierwszej rozprawie. W razie cofnięcia żądania ponowne jego

złożenie jest niedopuszczalne.

§ 4. Jeżeli wniosek o ukaranie pochodzi od pokrzywdzonego, odstąpienie przez

niego od popierania takiego wniosku oznacza także odstąpienie przez niego od

popierania żądania ścigania.


## Art. 7. {#kpw-art-7}
 Policja

i inne

organy w zakresie

postępowania w sprawach

o wykroczenia wykonują polecenia sądu oraz prowadzą w granicach określonych

w ustawie czynności wyjaśniające.


## Art. 8. {#kpw-art-8}
 W postępowaniu uregulowanym w niniejszym kodeksie stosuje się

odpowiednio przepisy art. 2, art. 4, art. 5, art. 7–9, art. 13, art. 14, art. 15 § 2 i 3,

art. 16, art. 18 § 2, art. 20, art. 23 i art. 23a Kodeksu postępowania karnego.
