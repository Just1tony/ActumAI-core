---
title: "Kodeks postępowania w sprawach o wykroczenia"
short: "KPW"
unit: "DZIAŁ IX"
dz_u: "Dz.U. 2001 Nr 106 poz. 1148"
status: "obowiązujący"
last_consolidated: "2025-09-09"
articles: "Art. 89–102"
source: "D20011148Lj (1).pdf"
---
DZIAŁ IX

Postępowania szczególne

## Rozdział 15

Postępowanie przyspieszone


## Art. 89. {#kpw-art-89}
 W postępowaniu przyspieszonym stosuje się przepisy o postępowaniu

zwyczajnym, jeżeli przepisy niniejszego rozdziału nie stanowią inaczej.


## Art. 90. {#kpw-art-90}
 § 1. Postępowanie przyspieszone stosuje się do osób niemających

stałego miejsca zamieszkania lub miejsca stałego pobytu, jeżeli zachodzi uzasadniona

obawa, że rozpoznanie sprawy w postępowaniu zwyczajnym będzie niemożliwe lub

znacznie utrudnione.

§ 2. Postępowanie przyspieszone stosuje się również do osób przebywających

jedynie czasowo na terytorium Rzeczypospolitej Polskiej, jeżeli zachodzi uzasadniona

obawa, że rozpoznanie sprawy w postępowaniu zwyczajnym będzie niemożliwe lub

znacznie utrudnione.

§ 2a. Postępowanie przyspieszone stosuje się

także wobec sprawców

wykroczenia, o którym mowa w art. 66b Kodeksu wykroczeń.

§ 3. Postępowanie przyspieszone stosuje się także wobec sprawców wykroczeń

popełnionych w związku

z imprezą masową,

określoną w przepisach

o bezpieczeństwie imprez masowych:

1)

przeciwko porządkowi i spokojowi publicznemu, określonych w art. 50, art. 50a,

art. 51 i art. 52a Kodeksu wykroczeń;

2)

przeciwko mieniu i urządzeniom użytku publicznego, określonych w art. 124

i 143 Kodeksu wykroczeń.

§ 4. Postępowanie przyspieszone stosuje się ponadto, gdy ustawa tak stanowi.

2025-09-09








s. 41/62

§ 5. Postępowania przyspieszonego nie stosuje się wobec osób podlegających

orzecznictwu sądów wojskowych.


## Art. 91. {#kpw-art-91}
 § 1. W wypadkach, o których mowa w art. 90, w postępowaniu

przyspieszonym orzeka się tylko wówczas, gdy sprawca został ujęty na gorącym

uczynku lub bezpośrednio po popełnieniu wykroczenia i niezwłocznie doprowadzono

go do sądu.

§ 2. Policja lub inny organ, któremu szczególne ustawy powierzają zadania

w zakresie ochrony porządku

lub bezpieczeństwa publicznego, w wypadku

schwytania na gorącym uczynku lub bezpośrednio potem sprawcy wykroczenia, o któ-

rym mowa w art. 90, może go zatrzymać i doprowadzić do sądu.

§ 2a. Organ określony w § 2 może odstąpić od przymusowego doprowadzenia

sprawcy do sądu, jeżeli zostanie zapewnione uczestniczenie przez sprawcę we

wszystkich czynnościach sądowych, w których ma on prawo uczestniczyć,

w szczególności możliwość złożenia przez niego wyjaśnień, przy użyciu urządzeń

technicznych umożliwiających przeprowadzenie tych czynności na odległość

z jednoczesnym bezpośrednim przekazem obrazu i dźwięku.

§ 3. Organ określony w § 2 może odstąpić od zatrzymania i przymusowego

doprowadzenia sprawcy do sądu, zobowiązując go do stawienia się w sądzie

w wyznaczonym czasie i miejscu ze skutkami wezwania, o których mowa w art. 71

§ 4. Wydanego wówczas pod nieobecność obwinionego wyroku nie uważa się za

zaoczny.

§ 4. W wypadku wskazanym w § 3 Policja i Straż Graniczna mogą zatrzymać

sprawcy paszport lub inny dokument uprawniający do przekroczenia granicy, który

wraz z wnioskiem o ukaranie przekazują sądowi. Zwrotu dokumentu dokonuje sąd,

nie później niż przy wydaniu orzeczenia albo z chwilą zmiany trybu postępowania.

§ 5. Osoba wezwana przez organ, o którym mowa w § 2, do stawienia się

w sądzie w charakterze świadka obowiązana jest stawić się we wskazanym czasie

i miejscu; art. 49 i art. 50 § 1 stosuje się odpowiednio.


## Art. 92. {#kpw-art-92}
 § 1. W postępowaniu przyspieszonym, z zastrzeżeniem art. 92a:

1) wniosek o ukaranie może ograniczyć się do wymogów wskazanych w art. 57 § 2

i § 3 pkt 1 i 3; może też być złożony ustnie do protokołu;

2025-09-09








s. 42/62

2)

sąd bez zbędnej zwłoki przystępuje do rozpoznania sprawy, zaznaczając

w protokole, że prowadzi ją w trybie przyspieszonym oraz odnotowując godzinę

doprowadzenia obwinionego;

3)

sąd zobowiązuje obwinionego do pozostania do dyspozycji sądu do zakończenia

rozprawy pod rygorem wydania orzeczenia pod jego nieobecność; tak wydanego

wyroku nie uważa się za zaoczny;

4) w razie przerwania rozprawy na okres dłuższy niż 3 dni sprawę rozpoznaje się

w postępowaniu zwyczajnym;

5)

uzasadnienie wyroku sporządza się tylko na wniosek strony złożony ustnie do

protokołu rozprawy bezpośrednio po ogłoszeniu wyroku;

6)

termin do wniesienia środka odwoławczego wynosi 3 dni i biegnie od daty

doręczenia wyroku z uzasadnieniem;

7)

sąd odwoławczy rozpoznaje sprawę najpóźniej w ciągu miesiąca od daty jej

wpływu do tego sądu.

§ 2. Sąd sporządza uzasadnienie w terminie 3 dni od daty ogłoszenia wyroku.

§ 3. W razie ustalenia, że brak jest warunków uzasadniających prowadzenie

sprawy w trybie przyspieszonym:

1)

prezes sądu przed wszczęciem postępowania zwraca oskarżycielowi wniosek

o ukaranie do uzupełnienia braków formalnych, gdy wniosek ten ograniczał się

do wymogów wskazanych w § 1 pkt 1, jeżeli jednak wniosek o ukaranie

odpowiada wymogom określonym w art. 57 § 2–4, rozpoznaje się go

w postępowaniu zwyczajnym;

2)

sąd wydaje postanowienie o zmianie trybu na zwyczajny, gdy brak podstaw do

prowadzenia

postępowania

przyspieszonego

ustalono

po wszczęciu

postępowania.

Art. 92a. W postępowaniu przyspieszonym, toczącym się z zastosowaniem

art. 91 § 2a, stosuje się przepisy niniejszego rozdziału z następującymi zmianami:

1) wniosek o ukaranie nie może być złożony ustnie do protokołu;

2) we wszystkich czynnościach sądowych przy użyciu urządzeń technicznych,

umożliwiających przeprowadzenie tych czynności na odległość, bierze udział

w miejscu przebywania sprawcy referendarz sądowy lub asystent sędziego

zatrudniony w sądzie, w którego okręgu przebywa sprawca;

2025-09-09








s. 43/62

3)

jeżeli został ustanowiony obrońca lub wezwano tłumacza, uczestniczą oni

w czynnościach sądowych przy użyciu urządzeń technicznych umożliwiających

przeprowadzenie tych czynności na odległość, w miejscu przebywania sprawcy;

4)

prezes sądu lub sąd, w sposób wskazany w art. 137 Kodeksu postępowania

karnego,

zawiadamia obwinionego o doręczeniu wniosku o ukaranie;

obwinionemu doręcza się za pokwitowaniem przez funkcjonariusza organu, o

którym mowa w art. 91 § 2, odpis wniosku o ukaranie oraz udostępnia się kopie

wszystkich dokumentów materiału dowodowego przekazywanych do sądu;

5)

art. 517ea Kodeksu postępowania karnego stosuje się odpowiednio; świadków

i biegłych można także przesłuchać przy zastosowaniu art. 177 § 1a Kodeksu

postępowania karnego;

6) w razie zarządzenia przerwy w rozprawie lub zmiany trybu postępowania

w dalszym postępowaniu nie stosuje się w stosunku do obwinionego sposobu

uczestniczenia w czynnościach sądowych przewidzianego w art. 91 § 2a; termin

rozpoznania sprawy przed sądem należy tak ustalić, aby umożliwić osobiste

uczestniczenie w niej obwinionego.

## Rozdział 16

Postępowanie nakazowe


## Art. 93. {#kpw-art-93}
 § 1. Sąd na posiedzeniu może wydać wyrok nakazowy w sprawach

o wykroczenia, w których wystarczające jest wymierzenie nagany, grzywny albo kary

ograniczenia wolności. Sąd orzeka bez udziału stron.

§ 2. Orzekanie w postępowaniu nakazowym może nastąpić, jeżeli okoliczności

czynu i wina obwinionego nie budzą wątpliwości. Wydając wyrok nakazowy, sąd

uznaje za ujawnione dowody dołączone do wniosku o ukaranie.

§ 3. Wyrokiem nakazowym można orzec również środek karny.

§ 4. Postępowanie nakazowe jest niedopuszczalne, jeżeli zachodzą okoliczności

określone w art. 21 § 1.


## Art. 94. {#kpw-art-94}
 § 1. Do wyroku nakazowego stosuje się odpowiednio przepisy art. 504

i 505 z wyłączeniem zdania drugiego, a także art. 506 § 1–3, § 5 i 6 Kodeksu

postępowania karnego.

§ 2. Na zarządzenie odmawiające przyjęcia sprzeciwu przysługuje zażalenie.

§ 3. Wyrok nakazowy, od którego nie wniesiono sprzeciwu lub sprzeciw

cofnięto, staje się prawomocny.

2025-09-09








s. 44/62

## Rozdział 17

Postępowanie mandatowe


## Art. 95. {#kpw-art-95}
 § 1. Postępowanie mandatowe prowadzi Policja, a inne organy, gdy

przepis szczególny tak stanowi.

§ 2. (uchylony)

§ 3. W sprawach określonych w art. 17 § 2 postępowanie mandatowe prowadzi

inspektor pracy. Inspektor pracy może nałożyć grzywnę w drodze mandatu karnego

także po przeprowadzeniu czynności wyjaśniających, jeżeli uzna, że kara ta będzie

wystarczająca.

§ 4. Jeżeli uprawnienie dla funkcjonariuszy określonego organu do nakładania

grzywien wynika z innej ustawy, a ustawa ta nie określa wykroczeń, do których

stosuje się postępowanie mandatowe, zakres wykroczeń, za które można nałożyć

grzywnę w drodze mandatu karnego, określi, w drodze rozporządzenia, właściwy

minister, w porozumieniu z Ministrem Sprawiedliwości, mając na względzie

konieczność zapewnienia szybkiej reakcji na fakt popełnienia wykroczenia, a także

potrzebę należytej ochrony dóbr szczególnie narażonych na naruszenia ze strony

sprawców wykroczeń. Rozporządzenie to określa jednocześnie warunki i sposób

wydawania upoważnień do nakładania grzywien w drodze mandatu karnego.

§ 5. Prezes Rady Ministrów, na wniosek ministra właściwego do spraw

wewnętrznych, złożony w porozumieniu z Ministrem Sprawiedliwości, może nadać,

w drodze rozporządzenia, uprawnienia do nakładania grzywien w drodze mandatu

karnego

funkcjonariuszom

innych organów, określając

jednocześnie wykaz

wykroczeń, za które funkcjonariusze ci uprawnieni są do nakładania grzywien, oraz

zasady i sposób wydawania upoważnień do nakładania grzywien, mając na względzie

zakres ustawowych uprawnień takich organów, potrzebę szybkiej reakcji na fakt

popełnienia wykroczenia oraz potrzebę ochrony dóbr szczególnie narażonych na

naruszenia ze strony sprawców wykroczeń.

§ 6. W celu ujednolicenia sposobu reakcji organów uprawnionych do nakładania

grzywien w drodze mandatu karnego za określone wykroczenia Prezes Rady

Ministrów, na wniosek ministra właściwego do spraw wewnętrznych, złożony

w porozumieniu z Ministrem Sprawiedliwości, określi, w drodze rozporządzenia,

zróżnicowaną wysokość mandatów karnych za wybrane rodzaje wykroczeń,

2025-09-09








s. 45/62

uwzględniając rodzaj naruszonego lub zagrożonego dobra oraz stopień szkodliwości

poszczególnych czynów.


## Art. 96. {#kpw-art-96}
 § 1. W postępowaniu mandatowym można nałożyć grzywnę

w wysokości do 500 zł, a w przypadku, o którym mowa w art. 9 § 1 Kodeksu

wykroczeń – do 1000 zł.

§ 1a. W postępowaniu mandatowym, w sprawach:

1) w których oskarżycielem publicznym jest właściwy organ Państwowej Inspekcji

Pracy,

2)

naruszeń wymienionych w art. 92f ust. 1 i w załączniku nr 1 do ustawy z dnia

6 września 2001 r. o transporcie drogowym (Dz. U. z 2024 r. poz. 1539, 1544 i

1855), w których oskarżycielem publicznym jest właściwy organ Inspekcji

Transportu Drogowego, Policji, Krajowej Administracji Skarbowej lub Straży

Granicznej

3)

(uchylony)

– można nałożyć grzywnę w wysokości do 2000 zł.

§ 1aa. W postępowaniu mandatowym, w sprawach o czyny określone w art. 54–

56 i art. 57a ustawy z dnia 20 marca 2009 r. o bezpieczeństwie imprez masowych

(Dz. U. z 2023 r. poz. 616) można nałożyć grzywnę w wysokości 2000 zł.

§ 1ab. W postępowaniu mandatowym, w sprawach o czyn określony w art. 32

ust. 1 ustawy z dnia 9 marca 2017 r. o systemie monitorowania drogowego

i kolejowego przewozu towarów oraz obrotu paliwami opałowymi (Dz. U. z 2024 r.

poz. 1218) można nałożyć grzywnę w wysokości od 5000 zł do 7500 zł.

§ 1ac. W postępowaniu mandatowym, w sprawach o czyny określone w art. 13na

ust. 1 i art. 13naa ust. 1 ustawy z dnia 21 marca 1985 r. o drogach publicznych (Dz. U.

z 2024 r. poz. 320 i 1222 oraz z 2025 r. poz. 641) można nałożyć grzywnę w wyso-

kości 1500 zł.

§ 1ad. W postępowaniu mandatowym w sprawach o wykroczenia określone

w rozdziale XI Kodeksu wykroczeń można nałożyć grzywnę w wysokości do 5000 zł,

a w przypadku, o którym mowa w art. 9 § 1 Kodeksu wykroczeń – do 6000 zł.

§ 1ae. W postępowaniu mandatowym, w sprawach

o czyny

określone

w art. 476 ust. 1 i 2, art. 477 pkt 4–8 i 12 oraz art. 478 pkt 2, 6, 7, 9, 10 i 12–16 ustawy

z dnia 20 lipca 2017 r. ‒ Prawo wodne (Dz. U. z 2024 r. poz. 1087, 1089 i 1473 oraz

z 2025 r. poz. 216 i 680) można nałożyć grzywnę w wysokości od 1000 zł do 7500 zł.

2025-09-09








s. 46/62

§ 1af. W postępowaniu mandatowym, w sprawach o czyny określone w:

1)

art. 84 ustawy z dnia 20 marca 2025 r. o warunkach dopuszczalności powierzania

pracy cudzoziemcom na terytorium Rzeczypospolitej Polskiej, w których

oskarżycielem publicznym jest właściwy organ Państwowej Inspekcji Pracy lub

Straży Granicznej,

2)

art. 465 ust. 1a ustawy z dnia 12 grudnia 2013 r. o cudzoziemcach, w których

oskarżycielem publicznym jest właściwy organ Straży Granicznej

– można nałożyć grzywnę w wysokości do 10 000 zł.

§ 1b. Jeżeli ukarany co najmniej dwukrotnie za wykroczenie przeciwko prawom

pracownika określone w Kodeksie pracy popełnia w ciągu dwóch lat od dnia

ostatniego ukarania takie wykroczenie, właściwy organ Państwowej Inspekcji Pracy

może w postępowaniu mandatowym nałożyć grzywnę w wysokości do 5000 zł.

§ 1ba. Jeżeli ukarany co najmniej dwukrotnie za wykroczenie określone w

ustawie z dnia 9 lipca 2003 r. o zatrudnianiu pracowników tymczasowych popełnia w

ciągu dwóch lat od dnia ostatniego ukarania takie wykroczenie, właściwy organ

Państwowej Inspekcji Pracy może w postępowaniu mandatowym nałożyć grzywnę w

wysokości do 5000 zł.

§ 1bb. Jeżeli ukarany co najmniej dwukrotnie za wykroczenie określone w

ustawie z dnia 10 października 2002 r. o minimalnym wynagrodzeniu za pracę

popełnia w ciągu dwóch lat od dnia ostatniego ukarania takie wykroczenie, właściwy

organ Państwowej Inspekcji Pracy może w postępowaniu mandatowym nałożyć

grzywnę w wysokości do 5000 zł.

§ 1bc. Jeżeli ukarany co najmniej dwukrotnie za wykroczenie określone

w ustawie z dnia 10 stycznia 2018 r. o ograniczeniu handlu w niedziele i święta oraz

w niektóre inne dni popełnia w ciągu dwóch lat od dnia ostatniego ukarania takie

wykroczenie, właściwy organ Państwowej Inspekcji Pracy może w postępowaniu

mandatowym nałożyć grzywnę w wysokości do 5000 zł.

§ 1bd. W postępowaniu mandatowym, w sprawach,

o których mowa

w art. 116 § 1 Kodeksu wykroczeń, można nałożyć grzywnę w wysokości do 1000 zł.

§ 1be. Środki

pochodzące

z grzywien,

o których mowa w § 1bd,

są przekazywane, w terminie 30 dni od dnia ich wpływu, na rachunek bankowy

Narodowego Funduszu Zdrowia, który przeznacza je na finansowanie świadczeń

opieki zdrowotnej.

2025-09-09








s. 47/62

§ 1c. W postępowaniu mandatowym, w sprawach o czyny określone w art. 93

pkt 12 ustawy z dnia 7 lipca 1994 r. – Prawo budowlane (Dz. U. z 2025 r. poz. 418)

można nałożyć grzywnę w wysokości do 2000 zł.

§ 1d. W postępowaniu mandatowym, w sprawach,

o których mowa

w art. 96 § 3 Kodeksu wykroczeń, można nałożyć grzywnę w wysokości do 8000 zł.

§ 2. W drodze mandatu karnego nie nakłada się grzywny za wykroczenia, za

które należałoby orzec środek karny, a także w wypadku określonym w art. 10

§ 1 Kodeksu wykroczeń. W sytuacji określonej w art. 9 § 1 Kodeksu wykroczeń

nałożenie grzywny w drodze mandatu karnego jest możliwe jedynie, gdy w zakresie

wszystkich naruszonych przepisów postępowanie mandatowe jest dopuszczalne.

§ 3. Prezes Rady Ministrów, w drodze rozporządzenia, określi wzory formularzy

mandatu karnego oraz szczegółowy sposób nakładania grzywien w drodze mandatu

karnego, mając na względzie potrzebę ujednolicenia zasad wymierzania przez

funkcjonariuszy uprawnionych organów grzywny w drodze mandatu karnego, a także

pouczenia osób ukaranych mandatem o ich prawach i obowiązkach.


## Art. 97. {#kpw-art-97}
 § 1. W postępowaniu mandatowym, jeżeli ustawa nie stanowi inaczej,

funkcjonariusz uprawniony do nakładania grzywny w drodze mandatu karnego może

ją nałożyć jedynie, gdy:

1)

schwytano sprawcę wykroczenia na gorącym uczynku lub bezpośrednio po

2)

3)

popełnieniu wykroczenia,

(uchylony)

stwierdzi popełnienie wykroczenia, w szczególności za pomocą przyrządu

kontrolno-pomiarowego lub urządzenia rejestrującego, a sprawca nie został

schwytany na gorącym uczynku lub bezpośrednio potem, i nie zachodzi

wątpliwość co do sprawcy czynu

– w tym także, w razie potrzeby, po przeprowadzeniu w niezbędnym zakresie

czynności wyjaśniających, podjętych niezwłocznie po ujawnieniu wykroczenia.

Nałożenie grzywny w drodze mandatu karnego nie może nastąpić po upływie 60 dni

od dnia ustalenia sprawcy wykroczenia.

§ 2. Sprawca wykroczenia może odmówić przyjęcia mandatu karnego.

§ 3. Funkcjonariusz nakładający grzywnę

jest obowiązany wskazać

jej

wysokość, określić zachowanie stanowiące wykroczenie, czas i miejsce jego

2025-09-09








s. 48/62

popełnienia oraz kwalifikację prawną, a także poinformować sprawcę wykroczenia

o prawie odmowy przyjęcia mandatu karnego i o skutkach prawnych takiej odmowy.


## Art. 98. {#kpw-art-98}
 § 1. W postępowaniu mandatowym można nakładać grzywnę w drodze

mandatu karnego:

1) wydawanego

ukaranemu

po

uiszczeniu

grzywny

bezpośrednio

funkcjonariuszowi, który ją nałożył;

kredytowanego, wydawanego ukaranemu za potwierdzeniem odbioru;

zaocznego.

2)

3)

§ 2. Mandatem karnym, o którym mowa w § 1 pkt 1, może być nałożona

grzywna jedynie wobec osoby czasowo przebywającej na terytorium Rzeczypospolitej

Polskiej lub niemającej stałego miejsca zamieszkania albo pobytu. Mandat taki staje

się prawomocny z chwilą uiszczenia grzywny funkcjonariuszowi, który ją nałożył.

§ 3. Mandatem karnym, o którym mowa w § 1 pkt 2, może być nałożona

grzywna jedynie wobec osoby innej niż wymieniona w § 2 albo mającej miejsce

stałego zamieszkania lub pobytu na terytorium innego niż Rzeczpospolita Polska

państwa członkowskiego Unii Europejskiej. Mandat powinien zawierać pouczenie

o obowiązku uiszczenia grzywny w terminie 7 dni od daty przyjęcia mandatu oraz

o skutkach nieuiszczenia grzywny w terminie. Staje się on prawomocny z chwilą

pokwitowania jego odbioru przez ukaranego.

§ 3a. Grzywna nałożona mandatem karnym, o którym mowa w § 1 pkt 1 i 2, może

być uiszczona w formie bezgotówkowej, za pomocą karty płatniczej lub innego

instrumentu płatniczego, o ile funkcjonariusz ją nakładający dysponuje odpowiednim

urządzeniem do autoryzacji rozliczeń. Grzywnę uważa się za uiszczoną z chwilą

potwierdzenia dokonania płatności uzyskanego z urządzenia do autoryzacji rozliczeń.

§ 3b. W przypadku uiszczenia grzywny w formie, o której mowa w § 3a, koszty

związane z autoryzacją transakcji i przekazem środków na właściwy rachunek

bankowy ponosi ukarany.

§ 3c. Funkcjonariusz informuje ukaranego o możliwości uiszczenia grzywny w

formie, o której mowa w § 3a, oraz treści § 3b.

§ 4. Mandatem karnym, o którym mowa w § 1 pkt 3, można nałożyć grzywnę

w razie stwierdzenia wykroczenia, którego sprawcy nie zastano na miejscu jego

popełnienia, gdy nie zachodzi wątpliwość co do osoby tego sprawcy. Mandat ten:

2025-09-09








s. 49/62

1)

pozostawia się w takim miejscu, aby sprawca mógł go niezwłocznie odebrać,

albo

2)

doręcza się sprawcy.

§ 5. Mandat karny, o którym mowa w § 1 pkt 3, powinien wskazywać organ, na

rzecz którego w terminie 14 dni ukarany może uiścić grzywnę, oraz informować

o skutkach jej nieuiszczenia w tym terminie. Mandat ten staje się prawomocny

z chwilą uiszczenia uprawnionemu organowi grzywny we wskazanym terminie.

Termin do uiszczenia grzywny liczy się od dnia:

1) wystawienia mandatu – w przypadku, o którym mowa w § 4 pkt 1;

2)

doręczenia mandatu – w przypadku, o którym mowa w § 4 pkt 2.


## Art. 99. {#kpw-art-99}
 W razie odmowy przyjęcia mandatu karnego

lub nieuiszczenia

w wyznaczonym terminie grzywny nałożonej mandatem zaocznym, organ, którego

funkcjonariusz nałożył grzywnę, występuje do sądu z wnioskiem o ukaranie. We

wniosku tym należy zaznaczyć, że obwiniony odmówił przyjęcia mandatu albo nie

uiścił grzywny nałożonej mandatem zaocznym, a w miarę możności podać także

przyczyny odmowy.


## Art. 100. {#kpw-art-100}
 § 1. Uprawnionym do poboru należności wynikających z grzywien

nałożonych w drodze mandatu karnego, stanowiących dochód budżetu państwa, jest

właściwy naczelnik urzędu skarbowego, z zastrzeżeniem § 2.

§ 2. Uprawnionym do poboru należności wynikających z grzywien nałożonych

w drodze mandatu karnego przez organy Inspekcji Transportu Drogowego jest

Główny Inspektor Transportu Drogowego.

§ 3. Grzywna stanowi dochód budżetu państwa, z wyjątkiem grzywien

nakładanych przez organy Inspekcji Transportu Drogowego stanowiących wpływy

Funduszu rozwoju przewozów autobusowych o charakterze użyteczności publicznej,

o którym mowa w ustawie z dnia 16 maja 2019 r. o Funduszu rozwoju przewozów

autobusowych o charakterze użyteczności publicznej albo Krajowego Funduszu

Drogowego, o którym mowa w ustawie z dnia 27 października 1994 r. o autostradach

płatnych oraz o Krajowym Funduszu Drogowym (Dz. U. z 2025 r. poz. 561),

a w przypadku gdy nałoży ją funkcjonariusz organu podległego władzom jednostki

samorządu terytorialnego – stanowi dochód tej jednostki samorządu.

§ 4. Organem uprawnionym do:

2025-09-09








s. 50/62

1)

zaopatrywania w formularze mandatu karnego oraz przydziału serii i numerów

mandatów

karnych

generowanych

przy wykorzystaniu

systemu

teleinformatycznego jest minister właściwy do spraw finansów publicznych;

2)

dystrybucji oraz

rozliczania

formularzy mandatu karnego, przydziału

i rozliczania

serii

i numerów mandatów karnych generowanych przy

wykorzystaniu systemu teleinformatycznego jest odpowiednio:

a) właściwy miejscowo dyrektor izby administracji skarbowej,

b) Główny Inspektor Transportu Drogowego – dla organów Inspekcji

Transportu Drogowego.

§ 4a. Minister właściwy do spraw finansów publicznych może wyznaczyć, w

drodze obwieszczenia, organ Krajowej Administracji Skarbowej właściwy do

zaopatrywania w formularze mandatu karnego oraz przydziału serii i numerów

mandatów karnych generowanych przy wykorzystaniu systemu teleinformatycznego.

§ 5. Organy, o których mowa w § 4 pkt 2, zaopatrują nieodpłatnie organy

uprawnione do nakładania grzywien w drodze mandatu karnego w formularze

mandatu karnego, z wyjątkiem podmiotów wskazanych w przepisach wydanych na

podstawie § 14 pkt 2, które nabywają formularze mandatu karnego odpłatnie.

§ 6. Odpłatność za nabycie formularzy mandatu karnego obejmuje wyłącznie

koszty ich wytworzenia i dystrybucji.

§ 7. Organy, o których mowa w § 4 pkt 2, oraz organ uprawniony do nakładania

grzywien w drodze mandatu karnego prowadzą ewidencję formularzy mandatu

karnego oraz przydzielonych serii i numerów mandatów karnych generowanych przy

wykorzystaniu systemu teleinformatycznego.

§ 8. Organ uprawniony do poboru należności wynikających z grzywien

nałożonych w drodze mandatu karnego prowadzi ewidencję tych grzywien, zgodnie

z przepisami o rachunkowości.

§ 9. Organ uprawniony do nakładania grzywien w drodze mandatu karnego

współpracuje z organem, o którym mowa w § 4 pkt 2

lit. a, oraz organem

uprawnionym do poboru należności wynikających z grzywien nałożonych w drodze

mandatu karnego w zakresie niezbędnym do wykonywania zadań tych organów

wynikających z niniejszego kodeksu, w tym poprzez udzielanie

informacji

w sprawach dotyczących odpowiednio formularzy mandatu karnego, przydzielonych

serii

i numerów mandatów generowanych przy wykorzystaniu

systemu

teleinformatycznego oraz nałożonych grzywien.

2025-09-09








s. 51/62

§ 10. Organ uprawniony do nakładania grzywien w drodze mandatu karnego,

z wyjątkiem organów Inspekcji Transportu Drogowego, sporządza informację

dotyczącą liczby otrzymanych i wykorzystanych formularzy mandatu karnego oraz

liczby przydzielonych

i wykorzystanych serii

i numerów mandatów karnych

generowanych przy wykorzystaniu systemu

teleinformatycznego

i przekazuje

organowi, o którym mowa w § 4 pkt 2 lit. a.

§ 11. Organ uprawniony do nakładania grzywien w drodze mandatu karnego,

stanowiących dochód budżetu państwa, z wyjątkiem organów Inspekcji Transportu

Drogowego, sporządza informację dotyczącą danych objętych formularzem mandatu

karnego oraz uiszczonych

i nieuiszczonych grzywien

i przekazuje

ją za

pośrednictwem systemu teleinformatycznego organowi, o którym mowa w § 1.

Informacja stanowi dowód księgowy należności wynikających z grzywien nałożonych

w drodze mandatu karnego, bez konieczności zamieszczania podpisu wystawcy

dowodu, o którym mowa w przepisach o rachunkowości.

§ 12. Ściąganie grzywny nałożonej w drodze mandatu karnego następuje

w trybie przepisów o postępowaniu egzekucyjnym w administracji.

§ 13. Minister właściwy do spraw finansów publicznych w porozumieniu

z Ministrem Sprawiedliwości określi, w drodze

rozporządzenia, właściwość

miejscową naczelnika urzędu skarbowego uprawnionego do poboru należności,

o których mowa w § 1, uwzględniając

sprawność

i skuteczność czynności

zmierzających do uregulowania należności.

§ 14. Rada Ministrów określi, w drodze rozporządzenia:

1)

sposób zaopatrywania, dystrybucji i rozliczania formularzy mandatu karnego

oraz przydziału i rozliczania serii i numerów mandatów generowanych przy

wykorzystaniu systemu teleinformatycznego,

podmioty, które nabywają formularze mandatu karnego odpłatnie,

tryb i szczegółowy zakres współpracy, o której mowa w § 9,

tryb i terminy przekazania oraz szczegółowy zakres informacji, o których mowa

2)

3)

4)

w § 10 i 11

– mając na względzie zapewnienie bezzwłocznego ewidencjonowania, rozliczania

i ściągania

należności wynikających

z grzywien,

zapewnienie

stałego

i niezakłóconego dostępu organom uprawnionym do nakładania grzywien w drodze

mandatu karnego do odpowiedniej liczby formularzy mandatu karnego oraz serii

i numerów mandatów karnych generowanych przy wykorzystaniu systemu

2025-09-09








s. 52/62

teleinformatycznego, a także niezwłocznego i prawidłowego rozliczania formularzy

mandatu karnego oraz przydzielonych serii i numerów mandatów generowanych przez

system teleinformatyczny.


## Art. 101. {#kpw-art-101}
 § 1. Prawomocny mandat karny podlega niezwłocznie uchyleniu, jeżeli

grzywnę nałożono za czyn niebędący czynem zabronionym jako wykroczenie albo na

osobę, która popełniła czyn zabroniony przed ukończeniem 17 lat, albo gdy ustawa

stanowi, że sprawca nie popełnia wykroczenia z przyczyn, o których mowa w art. 15–

17 Kodeksu wykroczeń. Uchylenie następuje na wniosek ukaranego,

jego

przedstawiciela ustawowego lub opiekuna prawnego złożony nie później niż

w terminie 7 dni od uprawomocnienia się mandatu lub na wniosek organu, którego

funkcjonariusz nałożył grzywnę, albo z urzędu.

§ 1a. Prawomocny mandat karny podlega uchyleniu w trybie określonym w § 1,

jeżeli grzywnę nałożono wbrew zakazom określonym w art. 96 § 2. Podlega on

również uchyleniu, gdy grzywnę nałożono w wysokości wyższej niż wynika to

z art. 96 § 1–1b, z tym że w takim wypadku jedynie w części przekraczającej jej

dopuszczalną wysokość.

§ 1b. Prawomocny mandat karny podlega uchyleniu w każdym czasie na

wniosek ukaranego, jego przedstawiciela ustawowego lub opiekuna prawnego lub na

wniosek organu, którego funkcjonariusz nałożył grzywnę, albo z urzędu, jeżeli:

1) Trybunał Konstytucyjny orzekł o niezgodności z Konstytucją, ratyfikowaną

umową międzynarodową lub z ustawą przepisu prawnego, na podstawie którego

została nałożona grzywna tym mandatem;

2)

potrzeba taka wynika z rozstrzygnięcia organu międzynarodowego działającego

na mocy umowy międzynarodowej ratyfikowanej przez Rzeczpospolitą Polską.

§ 2. Uprawniony do uchylenia prawomocnego mandatu karnego jest sąd

właściwy do rozpoznania sprawy, na którego obszarze działania została nałożona

grzywna. W przedmiocie uchylenia mandatu karnego sąd orzeka na posiedzeniu.

W posiedzeniu ma prawo uczestniczyć ukarany, organ, który

lub którego

funkcjonariusz nałożył grzywnę w drodze mandatu, albo przedstawiciel tego organu

oraz ujawniony pokrzywdzony. Przed wydaniem postanowienia sąd może zarządzić

stosowne czynności w celu sprawdzenia podstaw do uchylenia mandatu karnego.

§ 3. Uchylając mandat karny nakazuje się podmiotowi, na rachunek którego

pobrano grzywnę, zwrot uiszczonej kwoty.

2025-09-09








s. 53/62

§ 4. W razie wydania ponownego rozstrzygnięcia w sprawie, w której uchylono

prawomocny mandat karny, nie można orzec na niekorzyść obwinionego, jeżeli

uchylenie mandatu nastąpiło z przyczyn wskazanych w § 1b.


## Art. 102. {#kpw-art-102}
 Nadzór nad postępowaniem mandatowym sprawuje minister właściwy

do spraw wewnętrznych, a w sprawach, o których mowa w art. 95 § 3 – Główny

Inspektor Pracy.

Art. 102a. § 1. Zlecenia płatnicze na rzecz organów właściwych do poboru

należności wynikających z grzywien nałożonych w drodze mandatu karnego mogą być

składane również w formie dokumentu elektronicznego przy użyciu oprogramowania

udostępnionego przez banki lub innego dostawcę usług płatniczych w rozumieniu

ustawy z dnia 19 sierpnia 2011 r. o usługach płatniczych (Dz. U. z 2025 r. poz. 611)

uprawnionego do przyjmowania zleceń płatniczych albo w inny sposób uzgodniony z

bankiem lub innym dostawcą usług płatniczych przyjmującym zlecenie.

§ 2. Zlecenie płatnicze, o którym mowa w § 1, zawiera serię i numer mandatu

karnego oraz datę wystawienia mandatu karnego, przy czym niepodanie lub błędne

podanie tych informacji stanowi podstawę do odmowy realizacji wpłaty gotówkowej

lub polecenia przelewu.

§ 3. Minister właściwy do spraw finansów publicznych, w porozumieniu z

ministrem właściwym do spraw informatyzacji i po zasięgnięciu opinii Prezesa

Narodowego Banku Polskiego, może określić, w drodze rozporządzenia, wzór

formularza wpłaty gotówkowej oraz polecenia przelewu na rachunek organu

właściwego do poboru należności wynikających z grzywien nałożonych w drodze

mandatu karnego, uwzględniając dane identyfikujące wpłacającego oraz tytuł wpłaty.
