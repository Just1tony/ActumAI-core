---
title: "Kodeks postępowania w sprawach o wykroczenia"
short: "KPW"
unit: "DZIAŁ VIII"
dz_u: "Dz.U. 2001 Nr 106 poz. 1148"
status: "obowiązujący"
last_consolidated: "2025-09-09"
articles: "Art. 57–88"
source: "D20011148Lj (1).pdf"
---
DZIAŁ VIII

Postępowanie zwyczajne

## Rozdział 11

Wszczęcie postępowania. Orzekanie przed rozprawą


## Art. 57. {#kpw-art-57}
 § 1. Podstawę do wszczęcia postępowania stanowi wniosek o ukaranie

złożony przez organ uprawniony do występowania w charakterze oskarżyciela

publicznego w danej sprawie, a w wypadkach określonych w art. 27 § 1 i 2 także

wniosek złożony przez pokrzywdzonego.

§ 2. Wniosek o ukaranie powinien zawierać:

1)

imię i nazwisko oraz adres obwinionego, a także inne dane niezbędne do

ustalenia jego tożsamości;

2)

określenie zarzucanego obwinionemu czynu ze wskazaniem miejsca, czasu,

sposobu i okoliczności jego popełnienia;

2025-09-09








s. 27/62

3) wskazanie dowodów;

4)

imię i nazwisko oraz podpis sporządzającego wniosek, a także adres gdy wniosek

pochodzi od pokrzywdzonego.

§ 3. Wniosek o ukaranie składany przez oskarżyciela publicznego powinien

ponadto zawierać wskazanie:

1)

przepisów, pod które zarzucany czyn podpada;

2) miejsca zatrudnienia obwinionego oraz, w miarę możności, danych o jego

warunkach materialnych, rodzinnych i osobistych;

3)

pokrzywdzonych, o ile takich ujawniono;

4) wysokości wyrządzonej szkody;

5)

6)

7)

stanowiska osoby sporządzającej wniosek;

sądu właściwego do rozpoznania sprawy;

danych dotyczących uprzedniego

skazania obwinionego za podobne

przestępstwo lub wykroczenie, jeżeli oskarżyciel powołuje się na tę okoliczność.

§ 4. Do wniosku o ukaranie oskarżyciel publiczny dołącza materiały czynności

wyjaśniających lub postępowania przygotowawczego, a także, do wiadomości sądu,

adresy świadków i pokrzywdzonych oraz po jednym odpisie wniosku dla każdego

z obwinionych.

§ 5. W razie wniesienia wniosku o ukaranie przez pokrzywdzonego, prezes sądu

przesyłając właściwemu oskarżycielowi publicznemu zawiadomienie, o którym mowa

w art. 27 § 4, wzywa go jednocześnie do nadesłania w terminie 7 dni materiału

dowodowego w razie niewnoszenia przez niego wniosku o ukaranie, jeżeli w sprawie

przeprowadzono czynności wyjaśniające lub dochodzenie, albo do nadesłania

oświadczenia o braku takiego materiału.


## Art. 58. {#kpw-art-58}
 § 1. Oskarżyciel publiczny może,

za

zgodą obwinionego,

przesłuchanego uprzednio w toku czynności wyjaśniających w trybie art. 54 § 6,

umieścić we wniosku o ukaranie wniosek o skazanie obwinionego za zarzucany mu

czyn bez przeprowadzania rozprawy i wymierzenie mu określonej kary lub środka

karnego albo odstąpienie od wymierzenia kary lub środka karnego.

§ 2. Wniosek o skazanie, o którym mowa w § 1, jest możliwy tylko wówczas,

gdy w świetle zebranych dowodów wyjaśnienia obwinionego oraz okoliczności

popełnienia wykroczenia nie budzą wątpliwości, a cele postępowania zostaną osiąg-

nięte mimo nieprzeprowadzenia rozprawy.

2025-09-09








s. 28/62

§ 3. Obwiniony, jeżeli nie dotyczy go wniosek o skazanie, może po wezwaniu na

rozprawę lub zawiadomieniu o jej terminie wystąpić z wnioskiem o skazanie

w określony sposób bez przeprowadzania rozprawy.


## Art. 59. {#kpw-art-59}
 § 1. Jeżeli wniosek o ukaranie nie odpowiada warunkom formalnym

wskazanym w art. 57 § 2–4, prezes sądu zwraca wniosek w celu usunięcia braków

w terminie 7 dni.

§ 2. Jeżeli wniosek o ukaranie odpowiada warunkom formalnym, prezes sądu,

wszczynając postępowanie zarządzeniem, kieruje sprawę do rozpoznania na rozprawie

lub na posiedzeniu albo – w razie stwierdzenia okoliczności wyłączających

postępowanie lub wskazanych w art. 61 § 1 – orzekając jednoosobowo, odmawia

wszczęcia postępowania. Na postanowienie o odmowie wszczęcia postępowania służy

zażalenie ujawnionemu pokrzywdzonemu oraz organowi, który wniósł wniosek

o ukaranie.

§ 3. W razie złożenia wniosku o ukaranie przez oskarżyciela posiłkowego,

w przedmiocie wszczęcia rozstrzyga się po przekazaniu przez oskarżyciela

publicznego materiału dowodowego lub oświadczenia, o którym mowa w art. 57 § 5.


## Art. 60. {#kpw-art-60}
 § 1. Prezes sądu, po wszczęciu postępowania, kieruje sprawę na

posiedzenie, jeżeli:

1)

oskarżyciel publiczny wystąpił z wnioskiem o skazanie obwinionego bez

przeprowadzania rozprawy;

2)

obwiniony, po wezwaniu go na rozprawę lub zawiadomieniu o jej terminie,

wystąpił z wnioskiem o skazanie bez przeprowadzania rozprawy;

3)

4)

5)

zostały stwierdzone przed rozprawą okoliczności wyłączające postępowanie;

zachodzi potrzeba wydania postanowienia o niewłaściwości sądu;

zachodzi potrzeba umorzenia postępowania z powodu oczywistego braku

podstaw obwinienia;

6) w sprawie, w której wniosek o ukaranie złożył oskarżyciel posiłkowy, niezbędne

jest polecenie Policji lub innemu organowi dokonania określonych czynności

7)

8)

dowodowych;

zachodzi możliwość wydania wyroku nakazowego;

zachodzi potrzeba wydania

innego

rozstrzygnięcia przekraczającego

uprawnienia prezesa.

2025-09-09








s. 29/62

§ 2. O terminie posiedzenia w wypadkach wskazanych w § 1 pkt 1, 2, 3

i 5 powiadamia się strony i ich przedstawicieli procesowych. Niestawiennictwo

prawidłowo powiadomionych osób nie tamuje toku postępowania. Udział obrońcy,

o którym mowa w art. 21 § 1, jest jednak obowiązkowy w posiedzeniu określonym

w § 1 pkt 1 i 2.

§ 3. W wypadku wskazanym w § 1 pkt 2 prezes sądu może zarządzić

rozpoznanie wniosku obwinionego na rozprawie, jeżeli przyspieszy to bieg

postępowania. Wniosek ten rozpoznaje się wówczas przed rozpoczęciem przewodu

sądowego.

§ 4. W dalszym postępowaniu sąd nie jest związany oceną faktyczną ani prawną

przyjętą za podstawę rozstrzygnięć wydanych w trybie określonym w § 1–3.


## Art. 61. {#kpw-art-61}
 § 1. Można odmówić wszczęcia postępowania, a wszczęte umorzyć,

także wtedy, jeżeli:

1) w sprawie o ten sam czyn, jako mający jednocześnie znamiona przestępstwa

i wykroczenia, postępowanie karne zostało już prawomocnie zakończone

orzeczeniem skazującym lub toczy się postępowanie karne z oskarżenia pub-

licznego;

2) wobec sprawcy zastosowano środek oddziaływania w postaci pouczenia,

zwrócenia uwagi lub ostrzeżenia albo środek przewidziany w przepisach

o odpowiedzialności dyscyplinarnej lub porządkowej, a środek ten jest wystar-

czającą reakcją na wykroczenie.

§ 2. Na postanowienie o umorzeniu postępowania z przyczyn wskazanych

w § 1 przysługuje zażalenie.

§ 3. W sprawie o wykroczenie, w której odmówiono wszczęcia postępowania

lub

je umorzono, można podjąć postępowanie w terminie 3 miesięcy od

uprawomocnienia się orzeczenia w sprawie o przestępstwo, jeżeli orzeczeniem tym

uniewinniono oskarżonego lub umorzono postępowanie, a nie ustała jeszcze karalność

wykroczenia.


## Art. 62. {#kpw-art-62}
 § 1. Okoliczności wyłączające orzekanie na podstawie niniejszego

kodeksu uwzględnia się z urzędu w każdym stadium postępowania.

§ 2. W razie stwierdzenia okoliczności wyłączających orzekanie po wszczęciu

postępowania, sąd wydaje postanowienie o jego umorzeniu, a jeżeli rozpoczęto już

2025-09-09








s. 30/62

przewód sądowy – wyrok o umorzeniu postępowania, z wyjątkiem określonym w § 3.

Na postanowienie o umorzeniu przysługuje zażalenie.

§ 3. W razie stwierdzenia okoliczności, o których mowa w art. 5 § 1 pkt 1 i 2, po

rozpoczęciu przewodu sądowego sąd wydaje wyrok uniewinniający, chyba że sprawca

był w chwili czynu niepoczytalny.


## Art. 63. {#kpw-art-63}
 § 1. Uwzględniając wniosek oskarżyciela publicznego, o którym mowa

w art. 58 § 1, sąd uznaje za ujawnione dowody dołączone do wniosku o ukaranie.

§ 2. Sąd może uzależnić uwzględnienie wniosku od dokonania w nim

określonych przez siebie zmian. Wniosek ze zmianami nie może zostać uwzględniony,

jeżeli obwiniony, należycie o zmianach tych powiadomiony, zgłosi wobec nich

sprzeciw w terminie określonym przez sąd.

§ 3. Wniosek nie może zostać uwzględniony, jeżeli w terminie określonym przez

sąd zgłosi wobec niego sprzeciw pokrzywdzony, który złożył już oświadczenie

o przyłączeniu się do postępowania w charakterze oskarżyciela posiłkowego.

§ 4. Sąd uwzględniając wniosek skazuje obwinionego wyrokiem.

§ 5. Jeżeli sąd uzna, że nie ma podstaw do uwzględnienia wniosku, sprawa

podlega rozpoznaniu na zasadach ogólnych.


## Art. 64. {#kpw-art-64}
 § 1. Przy rozpoznawaniu wniosku obwinionego o skazanie go

w określony sposób bez przeprowadzania rozprawy, zgłoszonego przed

jej

rozpoczęciem, sąd stosuje odpowiednio art. 63.

§ 2. Sąd może uwzględnić wniosek, o którym mowa w § 1, jeżeli nie zgłosił

wobec niego sprzeciwu oskarżyciel publiczny, a także oskarżyciel posiłkowy, gdy

występuje w sprawie i jedynie wtedy, gdy okoliczności popełnienia czynu oraz

wyjaśnienia obwinionego w świetle ujawnionego materiału dowodowego nie budzą

wątpliwości.

§ 3. Jeżeli obwiniony nie był przesłuchany w toku czynności wyjaśniających, sąd

przesłuchuje go na posiedzeniu, chyba że obwiniony bez usprawiedliwienia nie stawił

się na posiedzenie albo nadesłał swoje wyjaśnienia na piśmie w trybie określonym

w art. 67 § 3.

§ 4. Brak stanowiska oskarżyciela w przedmiocie sprzeciwu, o którym mowa

w § 2, nie stoi na przeszkodzie uwzględnieniu wniosku, jeżeli oskarżyciel prawidłowo

powiadomiony o terminie posiedzenia nie stawił się bez usprawiedliwienia.

2025-09-09








s. 31/62

## Rozdział 12

Przygotowanie do rozprawy


## Art. 65. {#kpw-art-65}
 § 1. Prezes sądu, kierując sprawę na rozprawę, zarządza zawiadomienie

o jej miejscu i terminie oskarżyciela, pokrzywdzonego i obwinionego oraz obrońcę

i pełnomocnika, gdy zostali ustanowieni; zarządza on także wezwanie na rozprawę

świadków oraz sprowadzenie innych dowodów.

§ 2. Oskarżyciela publicznego zawiadamia się o rozprawie i posiedzeniu przez

dostarczenie mu wykazu spraw, które mają być rozpoznane w danym dniu.

§ 3. Jeżeli prezes sądu lub sąd uzna udział obwinionego na rozprawie za

niezbędny, zarządzając zawiadomienie go o jej miejscu

i terminie, zarządza

jednocześnie wezwanie obwinionego do osobistego stawiennictwa, pod rygorem

przymusowego doprowadzenia. Przepis ten stosuje się odpowiednio do posiedzeń.


## Art. 66. {#kpw-art-66}
 § 1. Osoby wymienione w art. 5 § 1 pkt 6 lit. a–e nie są obowiązane do

składania zeznań w charakterze świadka lub do występowania w charakterze biegłego,

można jednak zwrócić się o wyrażenie przez te osoby zgody na złożenie zeznań lub

wystąpienie w charakterze biegłego. W razie wyrażenia zgody, wezwania dla tych

osób nie mogą zawierać zagrożenia zastosowania środków przymusu, a w razie

niestawiennictwa na wezwanie lub odmowy złożenia zeznań nie można do nich

stosować tych środków.

§ 2. Do osób wymienionych w art. 5 § 1 pkt 6 lit. f stosuje się odpowiednio § 1,

jeżeli okoliczności, których zeznania lub opinie mają dotyczyć, związane są

z wykonywaniem przez te osoby funkcji urzędowych lub służbowych.

§ 3. Do osób, o których mowa w § 1 i 2, przepisy art. 5 § 2 i 3 stosuje się

odpowiednio.

§ 4. Z osobami, o których mowa w § 1 i 2, organy prowadzące postępowanie

porozumiewają się we wszystkich wypadkach, w tym również przy doręczaniu pism

procesowych, za pośrednictwem Ministra Sprawiedliwości, a ten w razie potrzeby

przez Ministra Spraw Zagranicznych4). Przepis art. 613 § 2 Kodeksu postępowania

karnego stosuje się.

4) Obecnie ministra właściwego do spraw zagranicznych, na podstawie art. 4 ust. 1, art. 5 pkt 27 i art. 32
ustawy z dnia 4 września 1997 r. o działach administracji rządowej (Dz. U. z 2024 r. poz. 1370 i
1907), która weszła w życie z dniem 1 kwietnia 1999 r.

2025-09-09









s. 32/62


## Art. 67. {#kpw-art-67}
 § 1. Zawiadamiając obwinionego o terminie pierwszej rozprawy lub

posiedzeniu, o którym mowa w art. 60 § 1 pkt 1, dołącza się do zawiadomienia odpis

wniosku o ukaranie.

§ 2. Zawiadomienie obwinionego o terminie pierwszej rozprawy powinno

zawierać pouczenie o tym, że może on sprowadzić na rozprawę świadków

i przedstawić inne dowody na swoją obronę lub wskazać je sądowi w takim czasie,

aby dowody te mogły być przeprowadzone na rozprawie, nie później jednak niż

w terminie 7 dni od doręczenia zawiadomienia, a także o przysługującym mu prawie

do odmowy złożenia wyjaśnień lub udzielenia odpowiedzi na pytanie i do korzystania

z pomocy obrońcy oraz o prawie przeglądania akt sprawy, jak również o obowiązku

powiadomienia sądu o każdej zmianie miejsca pobytu lub zamieszkania na okres

dłuższy niż 7 dni, a w razie pobytu za granicą – o konieczności wskazania w kraju

adresu

dla

doręczeń

i o konsekwencjach

uchybienia

tym

obowiązkom.

W zawiadomieniu należy pouczyć obwinionego o przysługującym mu prawie

wystąpienia z wnioskiem, o którym mowa w art. 58 § 3. Zawiadomienie lub wezwanie

powinno także zawierać pouczenie, iż rozprawa może być prowadzona pod

nieobecność obwinionego jako zaoczna oraz pouczenie o możliwości przymusowego

doprowadzenia obwinionego na rozprawę.

§ 3. Zawiadomienie kierowane do obwinionego, którego obecności na rozprawie

nie uznano za obowiązkową, powinno zawierać pouczenie, że może on nie stawiając

się do sądu nadesłać swoje wyjaśnienia. Wyjaśnienia te podlegają odczytaniu na

rozprawie. Rozprawa ma wówczas charakter zaoczny.

§ 4. W zawiadomieniu kierowanym do oskarżyciela posiłkowego należy

pouczyć go o obowiązku powiadomienia sądu o zmianie miejsca zamieszkania oraz

podania adresu dla doręczeń w czasie pobytu za granicą i konsekwencjach nie-

dopełnienia tego obowiązku, a w zawiadomieniu kierowanym do pokrzywdzonego –

o uprawnieniach, o których mowa w art. 26 § 3.

§ 5. Sąd może, uznając obecność obwinionego na rozprawie za obowiązkową

mimo wcześniejszego uznania jej za nieobowiązkową, wezwać obwinionego,

odraczając w tym celu rozprawę.

§ 6. Minister Sprawiedliwości określi, w drodze

rozporządzenia, wzór

pouczenia, o którym mowa w § 2, zawierając w nim informacje dotyczące praw

i obowiązków obwinionego w postępowaniu w sprawach o wykroczenia, w tym

o uprawnieniach określonych w § 1 oraz w art. 20 § 2 i art. 22, mając na względzie

2025-09-09








s. 33/62

konieczność zrozumienia pouczenia także przez osoby niekorzystające z pomocy

pełnomocnika.


## Art. 68. {#kpw-art-68}
 § 1. Jeżeli obwiniony lub świadek mieszka poza miejscowością,

w której ma siedzibę właściwy sąd, prezes sądu lub sąd może zwrócić się do sądu, na

którego terenie działania mieszkają te osoby, o przesłuchanie ich co do wskazanych

okoliczności.

§ 2. Przepis § 1 stosuje się odpowiednio do obwinionego

lub świadka

pozbawionego wolności.


## Art. 69. {#kpw-art-69}
 Przy przygotowaniu do rozprawy stosuje się odpowiednio przepisy

art. 348, 349, 350, 352 i 353 Kodeksu postępowania karnego.

## Rozdział 13

Rozprawa


## Art. 70. {#kpw-art-70}
 § 1. Rozprawa odbywa się ustnie i jawnie.

§ 2. Sąd wyłącza jawność całości lub części rozprawy, jeżeli jawność mogłaby

obrażać dobre obyczaje, wywołać zakłócenie spokoju publicznego lub gdy ważny

interes prywatny tego wymaga. Sąd wyłącza jawność w całości lub części rozprawy,

także wówczas, gdy ustawa tak stanowi.

§ 3. W razie wyłączenia jawności na rozprawie mogą być obecni, poza osobami

biorącymi udział w postępowaniu, po jednej osobie wskazanej przez każdą ze stron,

chyba że zachodzi obawa ujawnienia informacji niejawnych o klauzuli tajności „tajne”

lub „ściśle tajne”. Sąd może zezwolić poszczególnym osobom na obecność na

rozprawie prowadzonej z wyłączeniem jawności.

§ 4. Rozstrzygnięcie ogłasza się jawnie. Jeżeli jawność rozprawy wyłączono

w całości lub części, ustne podanie motywów rozstrzygnięcia może nastąpić również

z wyłączeniem jawności.

§ 5. Przepisy art. 357, 358, 362, 363, 366 i 367 Kodeksu postępowania karnego

stosuje się odpowiednio.


## Art. 71. {#kpw-art-71}
 § 1. Rozprawę rozpoczyna wywołanie sprawy. Następnie sąd sprawdza,

czy wszyscy wezwani i zawiadomieni o terminie rozprawy stawili się oraz czy nie ma

przeszkód do rozpoznania sprawy.

§ 2. Jeżeli oskarżyciel publiczny, oskarżyciel posiłkowy, pokrzywdzony lub

obwiniony nie stawił się na rozprawę i w aktach sprawy brak jest dowodu doręczenia

2025-09-09








s. 34/62

im wezwania lub zawiadomienia, rozprawę odracza się, przy czym sąd może, jeżeli

uzna to za celowe, przeprowadzić postępowanie dowodowe, a w szczególności

przesłuchać świadków, którzy stawili się na rozprawę. Na następnej rozprawie

dowody te przeprowadza się ponownie tylko, jeżeli zażąda tego strona nieobecna na

poprzedniej rozprawie, chyba że była o jej terminie prawidłowo powiadomiona.

§ 3. Przepis § 2 stosuje się odpowiednio w razie niestawiennictwa prawidłowo

powiadomionego obrońcy, gdy jego stawiennictwo jest obowiązkowe.

§ 4. W razie nieusprawiedliwionej nieobecności obwinionego, któremu

doręczono wezwanie na rozprawę, przeprowadza się rozprawę zaocznie, chociażby

nie był on przesłuchany w toku czynności wyjaśniających, chyba że sąd uzna udział

obwinionego za konieczny i rozprawę odroczy, po ewentualnym przeprowadzeniu

postępowania dowodowego, w szczególności po przesłuchaniu świadków, którzy

stawili się na rozprawę. Jeżeli jednak obecność obwinionego jest konieczna, a nie

stawił się on bez usprawiedliwienia, sąd może zarządzić jego zatrzymanie

i przymusowe doprowadzenie przez Policję.

§ 5. W razie usprawiedliwionego niestawiennictwa obwinionego, któremu

doręczono wezwanie, stosuje się odpowiednio § 2.


## Art. 72. {#kpw-art-72}
 § 1. Przewód sądowy rozpoczyna się od odczytania wniosku o ukaranie.

§ 2. Wniosek o ukaranie odczytuje oskarżyciel publiczny, jeżeli bierze udział

w rozprawie, a w innym wypadku protokolant.

§ 3. Jeżeli obwiniony przyznaje się do winy, a jego wyjaśnienia nie budzą

wątpliwości, można nie przeprowadzać dalszych dowodów, w razie gdy żadna

z obecnych stron temu się nie sprzeciwia.


## Art. 73. {#kpw-art-73}
 Do chwili zakończenia pierwszego przesłuchania na rozprawie

obwiniony może złożyć wniosek o skazanie go w określony sposób bez

przeprowadzania postępowania dowodowego. Przy rozpoznawaniu tego wniosku

stosuje się odpowiednio art. 64.


## Art. 74. {#kpw-art-74}
 § 1. Jeżeli obwiniony odmawia złożenia wyjaśnień albo wyjaśnia

odmiennie niż poprzednio lub oświadcza, że pewnych okoliczności nie pamięta, wolno

odczytywać w odpowiednim zakresie jego wyjaśnienia złożone poprzednio w trybie

art. 54 § 6 lub 7, a także jego wyjaśnienia złożone w charakterze obwinionego albo

oskarżonego przed sądem w tej lub innej sprawie albo w innym postępowaniu

przewidzianym przez ustawę. Po odczytaniu protokołu sąd wzywa obecnego

2025-09-09








s. 35/62

obwinionego do wypowiedzenia się co do treści protokołu i do wyjaśnienia

zachodzących sprzeczności.

§ 2. Na rozprawie zaocznej złożone uprzednio przez obwinionego w tej sprawie

wyjaśnienia podlegają odczytaniu.


## Art. 75. {#kpw-art-75}
 § 1. Przepis art. 74 § 1 stosuje się odpowiednio do świadka, który

bezpodstawnie odmawia złożenia zeznań, zeznaje odmiennie niż poprzednio lub

oświadcza, że pewnych okoliczności nie pamięta.

§ 2. Na rozprawie wolno też odczytywać protokoły zeznań świadków, jeżeli

bezpośrednie przeprowadzenie dowodu jest niemożliwe lub utrudnione.

§ 3. Protokoły, o których mowa w § 2, można uznać za ujawnione bez

odczytywania. Należy je jednak odczytać, jeżeli którakolwiek z obecnych stron o to

wnosi.

§ 4. Protokoły zeznań świadków wolno odczytywać również, gdy bezpośrednie

przesłuchanie świadka na rozprawie nie jest niezbędne, jeżeli żadna z obecnych stron

temu się nie sprzeciwia; sprzeciw strony, której zeznania nie dotyczą, nie stoi na

przeszkodzie odczytaniu protokołów. Przepis § 3 stosuje się odpowiednio.

§ 5. W wypadkach wskazanych w § 1 i 2 wolno również odczytywać protokoły

wyjaśnień złożonych poprzednio przez świadka w charakterze obwinionego lub

oskarżonego.

Art. 75a. Za odczytanie wyjaśnień lub zeznań złożonych na rozprawie uznaje się

odtworzenie wyjaśnień lub zeznań utrwalonych na rozprawie za pomocą urządzenia

rejestrującego dźwięk albo obraz i dźwięk.


## Art. 76. {#kpw-art-76}
 § 1. Sąd może odczytywać na rozprawie protokoły oględzin,

przeszukania, zajęcia, zatrzymania przedmiotów, opinie, notatki urzędowe, o których

mowa w art. 37 § 2, oraz inne dokumenty znajdujące się w aktach sprawy lub

przedkładane przez strony; można je uznać za ujawnione bez odczytywania, jeżeli

żadna z obecnych stron temu się nie sprzeciwia. Sprzeciw strony, której dowody lub

dokumenty nie dotyczą, nie stoi na przeszkodzie ich uznaniu za ujawnione bez

odczytywania.

§ 2. Przepis § 1 stosuje się także do notatek urzędowych, o których mowa

w art. 54 § 3, z tym że na żądanie strony sąd przeprowadza na rozprawie czynności

dowodowe, których dotyczy notatka, chyba że stwierdza ona okoliczności, którym

obwiniony w wyjaśnieniach swych nie zaprzeczał.

2025-09-09








s. 36/62


## Art. 77. {#kpw-art-77}
 Obwinionemu, świadkom i biegłym zarówno sąd, jak i strony zadają

pytania bezpośrednio, chyba że sąd zarządzi inaczej. Sąd uchyla pytania nieistotne dla

sprawy lub sugerujące treść odpowiedzi albo które z innych powodów uznaje za

niestosowne.


## Art. 78. {#kpw-art-78}
 Jeżeli po rozpoczęciu rozprawy obwiniony lub obrońca wypowiedział

stosunek obrończy w sprawie, w której obwiniony nie musi mieć obrońcy, sąd na

uzasadniony wniosek obwinionego zakreśla mu termin do ustanowienia nowego

obrońcy i w razie potrzeby rozprawę przerywa lub odracza, podejmując jednocześnie

decyzję, czy dotychczasowy obrońca może bez naruszenia prawa obwinionego do

obrony pełnić swe obowiązki do czasu podjęcia obrony przez nowego obrońcę. Po

bezskutecznym upływie tego terminu rozprawę można prowadzić bez udziału

obrońcy. W sprawach, w których obwiniony musi mieć obrońcę lub korzysta

z obrońcy z urzędu, art. 378 Kodeksu postępowania karnego stosuje się odpowiednio.


## Art. 79. {#kpw-art-79}
 § 1. Sąd może zarządzić przerwę w rozprawie w celu doprowadzenia

obwinionego, sprowadzenia dowodu, dla wypoczynku lub z innej ważnej przyczyny.

Każdorazowa przerwa nie może trwać dłużej niż 21 dni; w razie przekroczenia tego

terminu rozprawę uważa się za odroczoną.

§ 2. Zarządzając przerwę, oznacza się czas i miejsce dalszego ciągu rozprawy,

a osoby obecne na rozprawie poucza się o obowiązku stawiennictwa bez wezwania

oraz o konsekwencjach nieusprawiedliwionego niestawiennictwa.

§ 3. Sąd odracza rozprawę, gdy ustawa tak stanowi, a także gdy zarządzenie

przerwy nie byłoby wystarczające. W razie odroczenia rozprawy na określony termin

przepis § 2 stosuje się odpowiednio.


## Art. 80. {#kpw-art-80}
 Rozprawę przerwaną lub odroczoną prowadzi się w dalszym ciągu,

chociażby skład sądu uległ zmianie, chyba że sąd po wysłuchaniu stron obecnych

postanowi inaczej.


## Art. 81. {#kpw-art-81}
 Przy przeprowadzaniu rozprawy stosuje się odpowiednio przepisy

art. 369, art. 371, art. 372, art. 374 § 2, art. 375–377, art. 379, art. 384, art. 386,

art. 395, art. 396, art. 399, art. 405 i art. 406 Kodeksu postępowania karnego.


## Art. 82. {#kpw-art-82}
 § 1. Po wysłuchaniu głosów stron sąd sporządza wyrok na piśmie.

Przepisy art. 409–411, 413 § 1, art. 418 § 1 i 3, art. 418a, art. 419, 422–424 Kodeksu

postępowania karnego stosuje się odpowiednio.

2025-09-09








s. 37/62

§ 2. Wyrok skazujący powinien zawierać także:

1)

dokładne określenie przypisanego obwinionemu czynu oraz jego kwalifikację

prawną;

2)

rozstrzygnięcie co do kary i środków karnych, a w razie potrzeby co do

zaliczenia na poczet zakazu prowadzenia pojazdów okresu zatrzymania

dokumentu stwierdzającego uprawnienie do ich prowadzenia oraz zaliczenie

okresu zatrzymania na poczet wymierzonej kary aresztu lub grzywny.

§ 3. Okres zatrzymania zalicza się na poczet wymierzonej kary aresztu i kary

ograniczenia wolności, przyjmując jeden dzień zatrzymania, z zaokrągleniem do

pełnego dnia, za równoważny jednemu dniowi kary aresztu i dwóm dniom kary

ograniczenia wolności, a na poczet grzywny – przyjmując za równoważny grzywnie

w wysokości 200 zł.

§ 4. Jeżeli obwiniony

jest osobą czasowo przebywającą na

terytorium

Rzeczypospolitej Polskiej albo nie ma na nim stałego miejsca zamieszkania lub

miejsca stałego pobytu, można orzec natychmiastową wykonalność wyroku

skazującego, gdy zachodzi uzasadniona obawa, że jego wykonanie będzie niemożliwe

lub znacznie utrudnione. Orzeczenie takie podlega wykonaniu z chwilą wydania.

§ 5. W wypadku wskazanym w § 4 sąd:

1) wobec osoby czasowo przebywającej na terytorium Rzeczypospolitej Polskiej

zarządza zatrzymanie jej paszportu lub innego dokumentu uprawniającego do

przekroczenia granicy, na czas do stawienia się do wykonania kary lub uiszczenia

grzywny w terminie 3 dni, pod rygorem wykonania zastępczej kary aresztu, którą

na wypadek nieuiszczenia grzywny w terminie orzeka, stosując odpowiednio

przepis pkt 3;

2) wobec osoby niemającej stałego miejsca zamieszkania lub pobytu na terytorium

Rzeczypospolitej Polskiej, skazanej na karę aresztu, zarządza natychmiastowe

osadzenie jej w zakładzie karnym;

3) wobec osoby, o której mowa w pkt 2, skazanej na karę grzywny, orzeka

zastępczą karę aresztu, przyjmując 1 dzień aresztu za równoważny grzywnie od

20 zł do 150 zł, przy czym kara zastępcza nie może przekroczyć 30 dni aresztu;

zarządza ponadto, na wypadek nieuiszczenia grzywny w terminie 3 dni,

natychmiastowe wykonanie kary zastępczej.

§ 6. Jeżeli przebieg rozprawy utrwala się za pomocą urządzenia rejestrującego

dźwięk albo obraz i dźwięk, uzasadnienie wyroku może być z urzędu przedstawione

2025-09-09








s. 38/62

wyłącznie w formie ustnej, bezpośrednio po ogłoszeniu wyroku. Przepisu art. 92 § 1

pkt 5, a także przepisów art. 418 § 3, art. 422 i art. 423 Kodeksu postępowania

karnego nie stosuje się. Przed przedstawieniem uzasadnienia wyroku w formie ustnej

należy uprzedzić o tym strony.

§ 7. W wypadku, o którym mowa w § 6, w terminie zawitym 7 dni od daty

ogłoszenia wyroku strona może złożyć pisemny wniosek o sporządzenie i doręczenie

przekładu uzasadnienia wyroku przedstawionego w formie ustnej. Dla obwinionego

pozbawionego wolności, który nie ma obrońcy i nie był obecny podczas ogłaszania

wyroku lub przedstawiania ustnego uzasadnienia, termin ten biegnie od daty

doręczenia mu wyroku. Prezes sądu odmawia przyjęcia wniosku złożonego przez

osobę nieuprawnioną lub po terminie; na zarządzenie prezesa przysługuje zażalenie.

Przepis art. 423 § 2 Kodeksu postępowania karnego stosuje się odpowiednio.


## Art. 83. {#kpw-art-83}
 W razie niedoręczenia obwinionemu wyroku zaocznego, w terminie

3 miesięcy od dnia wydania, sąd może umorzyć postępowanie, jeżeli upłynął już

termin przedawnienia karalności wykroczenia.


## Art. 84. {#kpw-art-84}
 § 1. Jeżeli w wyroku nie rozstrzygnięto lub rozstrzygnięto wadliwie

o zaliczeniu na poczet kar lub środków karnych okresów, o których mowa w art. 82

§ 2 pkt 2, albo odnośnie do dowodów rzeczowych, sąd rozstrzyga o tym

postanowieniem na posiedzeniu.

§ 2. Na postanowienie, o którym mowa w § 1, przysługuje zażalenie. W razie

złożenia apelacji, zażalenie

to rozpoznaje

łącznie z apelacją właściwy sąd

odwoławczy.

## Rozdział 14

Postępowanie w sprawach osób podlegających orzecznictwu sądów wojskowych


## Art. 85. {#kpw-art-85}
 § 1. W postępowaniu przed sądem wojskowym podstawę do wszczęcia

postępowania stanowi wniosek o ukaranie sporządzony lub zatwierdzony przez

prokuratora do spraw wojskowych.

§ 2. Żandarmerii Wojskowej, w stosunku do osoby wskazanej w art. 10 § 1,

która popełniła wykroczenie podlegające orzecznictwu sądów wojskowych,

przysługują uprawnienia i obowiązki procesowe Policji wynikające z niniejszego

kodeksu.

2025-09-09








s. 39/62

§ 3. Prawo zatrzymania osoby wskazanej w art. 10 § 1 przysługuje także

wojskowym organom porządkowym oraz przełożonemu wojskowemu.

§ 4. Przymusowego doprowadzenia osoby, o której mowa w art. 10 § 1, jeżeli

zachodzi przypadek wymieniony w art. 50 § 1, art. 53, art. 71 § 4, dokonują właściwe

organy wojskowe, chyba że ważne powody stoją temu na przeszkodzie.


## Art. 86. {#kpw-art-86}
 § 1. O popełnieniu przez osobę wskazaną w art. 10 § 1 wykroczenia

podlegającego orzecznictwu sądów wojskowych, w tym także o odmowie przyjęcia

mandatu karnego lub nieuiszczeniu w terminie grzywny nałożonej w drodze mandatu

zaocznego, zawiadamia się prokuratora do spraw wojskowych.

§ 2. O wszczęciu postępowania przeciwko żołnierzowi powiadamia się

właściwego dowódcę jednostki wojskowej.

§ 3. W stosunku do osób, o których mowa w art. 10 § 1 pkt 2, stosuje się

odpowiednio art. 649 Kodeksu postępowania karnego.

Art. 86a. § 1. Ściganie wykroczenia popełnionego przez żołnierza, o którym

mowa w art. 10 § 1 pkt 1, następuje na żądanie dowódcy jednostki wojskowej,

w której żołnierz pełni służbę wojskową, z zastrzeżeniem § 3 i 4.

§ 2. W razie odstąpienia od żądania ścigania wykroczenia dowódca jednostki

wojskowej wszczyna wobec sprawcy tego czynu postępowanie dyscyplinarne albo

wydaje polecenie wszczęcia postępowania dyscyplinarnego, bądź występuje

z wnioskiem w tej sprawie do innego przełożonego dyscyplinarnego.

§ 3. W przypadku popełnienia przez żołnierza wykroczenia, za które można

orzec albo orzeka się środki karne zakazu prowadzenia pojazdów, przepadku

przedmiotów lub nawiązki, nie wszczyna się postępowania dyscyplinarnego, a stosuje

się przepis art. 86 § 1.

§ 4. W czasie pełnienia służby wojskowej po ogłoszeniu mobilizacji, w stanach

nadzwyczajnych, w czasie wojny, a także podczas wykonywania zadań służbowych

w strefie działań wojennych oraz w przypadku użycia Sił Zbrojnych Rzeczypospolitej

Polskiej

poza

granicami

państwa,

udziału w akcjach

humanitarnych,

poszukiwawczych lub ratowniczych, jak również w warunkach, o których mowa

w art. 10 § 1 pkt 1 lit. c, w stosunku do żołnierza, który popełnił wykroczenie, stosuje

się wyłącznie § 2.


## Art. 87. {#kpw-art-87}
 § 1. Sąd wojskowy może odmówić wszczęcia postępowania, a wszczęte

umorzyć i sprawę przekazać właściwemu dowódcy z wnioskiem o wymierzenie kary

2025-09-09








s. 40/62

przewidzianej w wojskowych przepisach dyscyplinarnych,

jeżeli uzna

to za

wystarczającą reakcję na wykroczenie.

§ 2. Na postanowienie wskazane w § 1 przysługuje zażalenie.

§ 3. Przed złożeniem wniosku o ukaranie uprawnienie do przekazania sprawy,

o którym mowa w § 1, przysługuje prokuratorowi do spraw wojskowych. Zażalenie

na postanowienie prokuratora rozpoznaje wojskowy sąd garnizonowy.


## Art. 88. {#kpw-art-88}
 Pokrzywdzony może korzystać przed sądem wojskowym z praw

oskarżyciela posiłkowego jedynie w sytuacjach określonych w art. 26 § 3 i art. 27 § 2.
