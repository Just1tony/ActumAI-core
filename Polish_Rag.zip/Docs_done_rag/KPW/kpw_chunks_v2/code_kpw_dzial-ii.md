---
title: "Kodeks postępowania w sprawach o wykroczenia"
short: "KPW"
unit: "DZIAŁ II"
dz_u: "Dz.U. 2001 Nr 106 poz. 1148"
status: "obowiązujący"
last_consolidated: "2025-09-09"
articles: "Art. 9–16"
source: "D20011148Lj (1).pdf"
---
DZIAŁ II

Sąd

## Rozdział 1

Właściwość i skład sądu


## Art. 9. {#kpw-art-9}
 § 1. W sprawach o wykroczenia w pierwszej instancji orzeka sąd

rejonowy, z zastrzeżeniem spraw określonych w art. 10.

§ 2. Sąd właściwy do rozpoznania sprawy rozpoznaje także środki zaskarżenia

w wypadkach wskazanych w ustawie oraz przeprowadza inne czynności, gdy ustawa

to przewiduje.


## Art. 10. {#kpw-art-10}
 § 1. W sprawach o wykroczenia popełnione przez:

1)

żołnierzy w czynnej służbie wojskowej, z wyłączeniem żołnierzy pełniących

terytorialną służbę wojskową dyspozycyjnie:

a) przeciwko organowi wojskowemu lub innemu żołnierzowi,

b) podczas lub w związku z pełnieniem obowiązków służbowych, w obrębie

obiektu wojskowego lub wyznaczonego miejsca przebywania, na szkodę

wojska lub z naruszeniem obowiązku wynikającego ze służby wojskowej,

c)

za granicą, podczas użycia lub pobytu Sił Zbrojnych Rzeczypospolitej

Polskiej poza granicami państwa, w rozumieniu ustawy z dnia 17 grudnia

1998 r. o zasadach użycia lub pobytu Sił Zbrojnych Rzeczypospolitej

Polskiej poza granicami państwa (Dz. U. z 2023 r. poz. 755),

2025-09-09








s. 5/62

2)

żołnierzy sił zbrojnych państw obcych, przebywających na

terytorium

Rzeczypospolitej Polskiej oraz członków ich personelu cywilnego, jeżeli

pozostają w związku z pełnieniem obowiązków służbowych, o ile ustawa lub

umowa międzynarodowa, której Rzeczpospolita Polska jest stroną, nie stanowi

inaczej

– orzekają w pierwszej instancji wojskowe sądy garnizonowe.

§ 2. Przepis art. 9 § 2 stosuje się odpowiednio do sądów wojskowych.


## Art. 11. {#kpw-art-11}
 § 1. Przy ustalaniu właściwości sądu stosuje się odpowiednio przepisy

art. 31, 32, 33 § 1, art. 34–36, 39 i 43 Kodeksu postępowania karnego, a w odniesieniu

do sądu, o którym mowa w art. 10, także art. 651 Kodeksu postępowania karnego.

§ 2. Sąd okręgowy może z inicjatywy właściwego sądu przekazać sprawę do

rozpoznania innemu sądowi równorzędnemu w ramach okręgu tego samego sądu

okręgowego, jeżeli wymaga tego dobro wymiaru sprawiedliwości.

§ 3. Przepis § 2 stosuje się odpowiednio do wojskowego sądu okręgowego,

w wypadku, w którym inicjatywa pochodzi od wojskowego sądu garnizonowego.


## Art. 12. {#kpw-art-12}
 § 1. Spory o właściwość między sądami rejonowymi rozstrzyga sąd

okręgowy, właściwy dla okręgu, w którym działa sąd, który pierwszy wszczął spór.

§ 2. Spory o właściwość między wojskowymi sądami garnizonowymi rozstrzyga

wojskowy sąd okręgowy, nadrzędny nad sądem, który pierwszy wszczął spór.


## Art. 13. {#kpw-art-13}
 § 1. Sąd rejonowy orzeka na rozprawie i na posiedzeniu jednoosobowo.

§ 2. Przepis § 1 stosuje się odpowiednio do wojskowego sądu garnizonowego

oraz do sądu orzekającego w sprawach, o którym mowa w art. 12 § 1 i 2.


## Art. 14. {#kpw-art-14}
 § 1. Sądem odwoławczym w sprawach o wykroczenia podlegających

właściwości sądów powszechnych, jeżeli ustawa nie stanowi inaczej, jest:

1)

sąd okręgowy do rozpoznania apelacji oraz zażaleń na postanowienia

i zarządzenia zamykające drogę do wydania wyroku;

2)

sąd rejonowy w innym równorzędnym składzie do rozpoznania pozostałych

zażaleń.

§ 2. Sądem

odwoławczym w sprawach

o wykroczenia

podlegających

właściwości sądów wojskowych, jeżeli ustawa nie stanowi inaczej, jest wojskowy sąd

okręgowy.

§ 3. Sąd okręgowy i wojskowy sąd okręgowy ponadto rozpoznają sprawy

przekazane im przez ustawę.

2025-09-09








s. 6/62

§ 4. W sprawach określonych w § 1 i 2 sądy w nich wskazane orzekają na

rozprawie i na posiedzeniu jednoosobowo.

§ 5. W sprawach określonych w § 3 sądy orzekają jednoosobowo, chyba że

ustawa stanowi inaczej albo prezes sądu zarządzi orzekanie w składzie trzech sędziów.


## Art. 15. {#kpw-art-15}
 § 1. Sąd apelacyjny rozpoznaje środki odwoławcze od orzeczeń

i zarządzeń wydawanych w pierwszej instancji przez sąd okręgowy oraz inne sprawy

przekazane mu przez ustawę.

§ 2. Sąd Najwyższy rozpoznaje kasacje i inne sprawy przekazane mu przez

ustawę.

§ 3. W sprawach, w których orzekały sądy wojskowe, uprawnienia sądu

okręgowego ma wojskowy sąd okręgowy, a uprawnienia sądu apelacyjnego ma Sąd

Najwyższy.

§ 4. Sądy wskazane w § 1–3 orzekają jednoosobowo, chyba że ustawa stanowi

inaczej albo prezes sądu lub Prezes Sądu Najwyższego zarządzi orzekanie w składzie

trzech sędziów.

## Rozdział 2

Wyłączenie sędziego


## Art. 16. {#kpw-art-16}
 § 1. Do wyłączenia sędziego i referendarza sądowego stosuje się

odpowiednio przepisy art. 40, art. 41, art. 41a i art. 42 § 1–3 Kodeksu postępowania

karnego.

§ 2. O wyłączeniu sędziego rozstrzyga inny równorzędny skład sądu, przed

którym sprawa się

toczy. W razie niemożności utworzenia

takiego składu

o wyłączeniu orzeka sąd wyższego rzędu. O wyłączeniu referendarza sądowego sąd

orzeka w składzie jednego sędziego.
