---
id: code.kro.iv
title: Kodeks rodzinny i opiekuńczy — DZIAŁ IV
short: KRO
dz_u: Dz.U. 1964 Nr 9 poz. 59
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '55'
  last: '61'
source_pdf: D19640059Lj.pdf
chunking:
  strategy: by-article
  anchor_pattern: '### Art. {n}. {#kro-art-{n}}'
  hierarchy:
  - DZIAŁ
  - Rozdział
  - Art.
---

# DZIAŁ IV

### Art. 55. {#kro-art-55}

§ 1. W razie uznania jednego z małżonków za zmarłego domniemywa 
się, że małżeństwo ustało z chwilą, która w orzeczeniu o uznaniu tego małżonka za 
zmarłego została oznaczona jako chwila jego śmierci. 
§ 2. Jeżeli po uznaniu jednego z małżonków za zmarłego drugi małżonek zawarł 
nowy związek małżeński, związek ten nie może być unieważniony z tego powodu, że 
małżonek uznany za zmarłego żyje albo że jego śmierć nastąpiła w innej chwili aniżeli 
chwila oznaczona w orzeczeniu o uznaniu za zmarłego. Przepisu tego nie stosuje się, 
jeżeli w chwili zawarcia nowego związku małżeńskiego strony wiedziały, że 
małżonek uznany za zmarłego pozostaje przy życiu.

***
### Art. 56. {#kro-art-56}

§ 1. Jeżeli między małżonkami nastąpił zupełny i trwały rozkład 
pożycia, każdy z małżonków może żądać, ażeby sąd rozwiązał małżeństwo przez 
rozwód. 
§ 2. Jednakże mimo zupełnego i trwałego rozkładu pożycia rozwód nie jest 
dopuszczalny, jeżeli wskutek niego miałoby ucierpieć dobro wspólnych małoletnich 
dzieci małżonków albo jeżeli z innych względów orzeczenie rozwodu byłoby 
sprzeczne z zasadami współżycia społecznego. 
§ 3. Rozwód nie jest również dopuszczalny, jeżeli żąda go małżonek wyłącznie 
winny rozkładu pożycia, chyba że drugi małżonek wyrazi zgodę na rozwód albo że 
odmowa jego zgody na rozwód jest w danych okolicznościach sprzeczna z zasadami 
współżycia społecznego.

***
### Art. 57. {#kro-art-57}

§ 1. Orzekając rozwód sąd orzeka także, czy i który z małżonków 
ponosi winę rozkładu pożycia. 
§ 2. Jednakże na zgodne żądanie małżonków sąd zaniecha orzekania o winie. 
W tym wypadku następują skutki takie, jak gdyby żaden z małżonków nie ponosił 
winy. 

 
 
 
s. 19/62 
 
 
 
2025-07-21

***
### Art. 58. {#kro-art-58}

§ 1. W wyroku orzekającym rozwód sąd rozstrzyga o władzy 
rodzicielskiej nad wspólnym małoletnim dzieckiem obojga małżonków i kontaktach 
rodziców z dzieckiem oraz orzeka, w jakiej wysokości każdy z małżonków jest 
obowiązany do ponoszenia kosztów utrzymania i wychowania dziecka. Sąd 
uwzględnia pisemne porozumienie małżonków o sposobie wykonywania władzy 
rodzicielskiej i utrzymywaniu kontaktów z dzieckiem po rozwodzie, jeżeli jest ono 
zgodne z dobrem dziecka. Rodzeństwo powinno wychowywać się wspólnie, chyba że 
dobro dziecka wymaga innego rozstrzygnięcia. 
§ 1a. W braku porozumienia, o którym mowa w § 1, sąd, uwzględniając prawo 
dziecka do wychowania przez oboje rodziców, rozstrzyga o sposobie wspólnego 
wykonywania władzy rodzicielskiej i utrzymywaniu kontaktów z dzieckiem po 
rozwodzie. Sąd może powierzyć wykonywanie władzy rodzicielskiej jednemu z 
rodziców, ograniczając władzę rodzicielską drugiego do określonych obowiązków i 
uprawnień w stosunku do osoby dziecka, jeżeli dobro dziecka za tym przemawia. 
§ 1b. Na zgodny wniosek stron sąd nie orzeka o utrzymywaniu kontaktów z 
dzieckiem. 
§ 2. Jeżeli małżonkowie zajmują wspólne mieszkanie, sąd w wyroku 
rozwodowym orzeka także o sposobie korzystania z tego mieszkania przez czas 
wspólnego w nim zamieszkiwania rozwiedzionych małżonków. W wypadkach 
wyjątkowych, gdy jeden z małżonków swym rażąco nagannym postępowaniem 
uniemożliwia wspólne zamieszkiwanie, sąd może nakazać jego eksmisję na żądanie 
drugiego małżonka. Na zgodny wniosek stron sąd może w wyroku orzekającym 
rozwód orzec również o podziale wspólnego mieszkania albo o przyznaniu 
mieszkania jednemu z małżonków, jeżeli drugi małżonek wyraża zgodę na jego 
opuszczenie bez dostarczenia lokalu zamiennego i pomieszczenia zastępczego, o ile 
podział bądź jego przyznanie jednemu z małżonków są możliwe. 
§ 3. Na wniosek jednego z małżonków sąd może w wyroku orzekającym rozwód 
dokonać podziału majątku wspólnego, jeżeli przeprowadzenie tego podziału nie 
spowoduje nadmiernej zwłoki w postępowaniu. 
§ 4. Orzekając o wspólnym mieszkaniu małżonków sąd uwzględnia przede 
wszystkim potrzeby dzieci i małżonka, któremu powierza wykonywanie władzy 
rodzicielskiej. 
 

 
 
 
s. 20/62 
 
 
 
2025-07-21 
 
[

***
### Art. 59. {#kro-art-59}

W ciągu trzech miesięcy od chwili uprawomocnienia się orzeczenia 
rozwodu małżonek rozwiedziony, który wskutek zawarcia małżeństwa zmienił swoje 
dotychczasowe nazwisko, może przez oświadczenie złożone przed kierownikiem urzędu 
stanu cywilnego lub konsulem powrócić do nazwiska, które nosił przed zawarciem 
małżeństwa.] 
<

***
### Art. 59. {#kro-art-59}

W ciągu roku od chwili uprawomocnienia się orzeczenia rozwodu 
małżonek rozwiedziony, który wskutek zawarcia małżeństwa zmienił swoje 
dotychczasowe nazwisko, może przez oświadczenie złożone przed kierownikiem 
urzędu stanu cywilnego lub konsulem powrócić do nazwiska, które nosił przed 
zawarciem małżeństwa.>

***
### Art. 60. {#kro-art-60}

§ 1. Małżonek rozwiedziony, który nie został uznany za wyłącznie 
winnego rozkładu pożycia i który znajduje się w niedostatku, może żądać od drugiego 
małżonka 
rozwiedzionego 
dostarczania 
środków 
utrzymania 
w zakresie 
odpowiadającym usprawiedliwionym potrzebom uprawnionego oraz możliwościom 
zarobkowym i majątkowym zobowiązanego. 
§ 2. Jeżeli jeden z małżonków został uznany za wyłącznie winnego rozkładu 
pożycia, a rozwód pociąga za sobą istotne pogorszenie sytuacji materialnej małżonka 
niewinnego, sąd na żądanie małżonka niewinnego może orzec, że małżonek wyłącznie 
winny obowiązany jest przyczyniać się w odpowiednim zakresie do zaspokajania 
usprawiedliwionych potrzeb małżonka niewinnego, chociażby ten nie znajdował się 
w niedostatku. 
§ 3. Obowiązek dostarczania środków utrzymania małżonkowi rozwiedzionemu 
wygasa w razie zawarcia przez tego małżonka nowego małżeństwa. Jednakże gdy 
zobowiązanym jest małżonek rozwiedziony, który nie został uznany za winnego 
rozkładu pożycia, obowiązek ten wygasa także z upływem pięciu lat od orzeczenia 
rozwodu, chyba że ze względu na wyjątkowe okoliczności sąd, na żądanie 
uprawnionego, przedłuży wymieniony termin pięcioletni.

***
### Art. 61. {#kro-art-61}

Z zastrzeżeniem przepisu artykułu poprzedzającego do obowiązku 
dostarczania środków utrzymania przez jednego z małżonków rozwiedzionych 
drugiemu stosuje się odpowiednio przepisy o obowiązku alimentacyjnym między 
krewnymi. 
Nowe brzmienie 
art. 59 wejdzie w 
życie 
z 
dn. 
8.10.2025 r. (Dz. 
U. z 2025 r. poz. 
897). 

 
 
 
s. 21/62 
 
 
 
2025-07-21

