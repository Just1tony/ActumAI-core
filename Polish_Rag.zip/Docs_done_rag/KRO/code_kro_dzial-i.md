---
id: code.kro.i
title: Kodeks rodzinny i opiekuńczy — DZIAŁ I
short: KRO
dz_u: Dz.U. 1964 Nr 9 poz. 59
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '145'
  last: '174'
source_pdf: D19640059Lj.pdf
chunking:
  strategy: by-article
  anchor_pattern: '### Art. {n}. {#kro-art-{n}}'
  hierarchy:
  - DZIAŁ
  - Rozdział
  - Art.
---

# DZIAŁ I

### Art. 145. {#kro-art-145}

§ 1. 
Opiekę 
ustanawia 
się 
dla 
małoletniego 
w wypadkach 
przewidzianych w tytule II niniejszego kodeksu. 
§ 2. Opiekę ustanawia sąd opiekuńczy, skoro tylko poweźmie wiadomość, że 
zachodzi prawny po temu powód.

***
### Art. 146. {#kro-art-146}

Opiekę sprawuje opiekun. Wspólne sprawowanie opieki nad 
dzieckiem sąd może powierzyć tylko małżonkom.

***
### Art. 147. {#kro-art-147}

Jeżeli dobro pozostającego pod opieką tego wymaga, sąd opiekuńczy 
wydaje niezbędne zarządzenia dla ochrony jego osoby lub majątku aż do czasu objęcia 
opieki przez opiekuna; w szczególności sąd opiekuńczy może ustanowić w tym celu 
kuratora.

***
### Art. 148. {#kro-art-148}

§ 1. Nie może być ustanowiona opiekunem osoba, która nie ma pełnej 
zdolności do czynności prawnych albo została pozbawiona praw publicznych. 
§ 1a. Opiekunem małoletniego nie może być ustanowiona także osoba, która 
została pozbawiona władzy rodzicielskiej albo skazana za przestępstwo przeciwko 
wolności seksualnej lub obyczajności albo za umyślne przestępstwo z użyciem 
przemocy wobec osoby lub przestępstwo popełnione na szkodę małoletniego lub we 
współdziałaniu z nim, albo osoba, wobec której orzeczono zakaz prowadzenia 
działalności związanej z wychowywaniem, leczeniem, edukacją małoletnich lub 

 
 
 
s. 55/62 
 
 
 
2025-07-21 
 
opieką nad nimi, lub obowiązek powstrzymywania się od przebywania w określonych 
środowiskach lub miejscach, zakaz kontaktowania się z określonymi osobami lub 
zakaz opuszczania określonego miejsca pobytu bez zgody sądu. 
§ 2. Nie może być ustanowiony opiekunem ten, w stosunku do kogo zachodzi 
prawdopodobieństwo, że nie wywiąże się należycie z obowiązków opiekuna.

***
### Art. 149. {#kro-art-149}

§ 1. Gdy wzgląd na dobro pozostającego pod opieką nie stoi temu na 
przeszkodzie, opiekunem małoletniego powinna być ustanowiona przede wszystkim 
osoba wskazana przez ojca lub matkę, jeżeli nie byli pozbawieni władzy rodzicielskiej. 
§ 2. Jeżeli opiekunem nie została ustanowiona osoba wymieniona w paragrafie 
poprzedzającym, opiekun powinien być ustanowiony spośród krewnych lub innych 
osób bliskich pozostającego pod opieką albo jego rodziców. 
§ 3. W braku takich osób sąd opiekuńczy zwraca się o wskazanie osoby, której 
opieka mogłaby być powierzona, do właściwej jednostki organizacyjnej pomocy 
społecznej albo do organizacji społecznej, do której należy piecza nad małoletnimi, 
a jeżeli pozostający pod opieką przebywa w placówce opiekuńczo-wychowawczej 
albo innej podobnej placówce, w zakładzie poprawczym lub w schronisku dla 
nieletnich sąd może się zwrócić także do tej placówki albo do tego zakładu lub 
schroniska. 
§ 4. W razie potrzeby ustanowienia opieki dla małoletniego umieszczonego 
w pieczy zastępczej, sąd powierza sprawowanie opieki, przede wszystkim: 
1) 
w przypadku umieszczenia dziecka w rodzinie zastępczej – rodzicom 
zastępczym, 
2) 
w przypadku umieszczenia dziecka w rodzinnym domu dziecka – osobom 
prowadzącym ten dom, 
3) 
w przypadku umieszczenia dziecka w placówce opiekuńczo-wychowawczej 
typu rodzinnego – osobom prowadzącym tę placówkę, 
4) 
w przypadku umieszczenia dziecka w placówce opiekuńczo-wychowawczej: 
socjalizacyjnej, specjalistyczno-terapeutycznej, interwencyjnej lub regionalnej 
placówce opiekuńczo-terapeutycznej – osobom bliskim dziecka 
– w terminie 7 dni od uprawomocnienia się postanowienia o pozbawieniu władzy 
rodzicielskiej. 
§ 5. W wypadku, o którym mowa w art. 1191 § 1, nie stosuje się przepisów § 1, 
2 i 4 pkt 4. 

 
 
 
s. 56/62 
 
 
 
2025-07-21

***
### Art. 150. {#kro-art-150}

(uchylony)

***
### Art. 151. {#kro-art-151}

Sąd opiekuńczy może ustanowić jednego opiekuna dla kilku osób, 
jeżeli nie ma sprzeczności między ich interesami. Opieka nad rodzeństwem powinna 
być w miarę możności powierzona jednej osobie.

***
### Art. 152. {#kro-art-152}

Każdy, kogo sąd opiekuńczy ustanowi opiekunem, obowiązany jest 
opiekę objąć. Z ważnych powodów sąd opiekuńczy może zwolnić od tego obowiązku.

***
### Art. 153. {#kro-art-153}

Objęcie opieki następuje przez złożenie przyrzeczenia przed sądem 
opiekuńczym. Opiekun powinien objąć swe obowiązki niezwłocznie. 

## Rozdział II
 
Sprawowanie opieki

***
### Art. 154. {#kro-art-154}

Opiekun obowiązany jest wykonywać swe czynności z należytą 
starannością, jak tego wymaga dobro pozostającego pod opieką i interes społeczny.

***
### Art. 155. {#kro-art-155}

§ 1. Opiekun sprawuje pieczę nad osobą i majątkiem pozostającego 
pod opieką; podlega przy tym nadzorowi sądu opiekuńczego. 
§ 2. Do sprawowania opieki stosuje się odpowiednio przepisy o władzy 
rodzicielskiej z zachowaniem przepisów poniższych.

***
### Art. 156. {#kro-art-156}

Opiekun powinien uzyskać zezwolenie sądu opiekuńczego albo, 
w przypadkach wskazanych w art. 6401 ustawy z dnia 17 listopada 1964 r. – Kodeks 
postępowania cywilnego, sądu spadku we wszelkich ważniejszych sprawach, które 
dotyczą osoby lub majątku małoletniego.

***
### Art. 157. {#kro-art-157}

Jeżeli opiekun doznaje przemijającej przeszkody w sprawowaniu 
opieki, sąd opiekuńczy może ustanowić kuratora.

***
### Art. 158. {#kro-art-158}

O decyzjach w ważniejszych sprawach, które dotyczą osoby lub 
majątku małoletniego opiekun powinien informować jego rodziców, którzy 
uczestniczą w sprawowaniu bieżącej pieczy nad osobą dziecka i w jego wychowaniu.

***
### Art. 159. {#kro-art-159}

§ 1. Opiekun nie może reprezentować osób pozostających pod jego 
opieką: 
1) 
przy czynnościach prawnych między tymi osobami; 
2) 
przy czynnościach prawnych między jedną z tych osób a opiekunem albo jego 
małżonkiem, zstępnymi, wstępnymi lub rodzeństwem, chyba że czynność 

 
 
 
s. 57/62 
 
 
 
2025-07-21 
 
prawna polega na bezpłatnym przysporzeniu na rzecz osoby pozostającej pod 
opieką. 
§ 2. Przepisy powyższe stosuje się odpowiednio w postępowaniu przed sądem 
lub innym organem państwowym.

***
### Art. 160. {#kro-art-160}

§ 1. Niezwłocznie po objęciu opieki opiekun obowiązany jest 
sporządzić inwentarz majątku osoby pozostającej pod opieką i przedstawić go sądowi 
opiekuńczemu. Przepis powyższy stosuje się odpowiednio w razie późniejszego 
nabycia majątku przez osobę pozostającą pod opieką. 
§ 2. Sąd opiekuńczy może zwolnić opiekuna od obowiązku sporządzenia 
inwentarza, jeżeli majątek jest nieznaczny.

***
### Art. 161. {#kro-art-161}

§ 1. Sąd opiekuńczy może zobowiązać opiekuna do złożenia do 
depozytu sądowego kosztowności, papierów wartościowych i innych dokumentów 
należących do pozostającego pod opieką. Przedmioty te nie mogą być odebrane bez 
zezwolenia sądu opiekuńczego. 
§ 2. Gotówka pozostającego pod opieką, jeżeli nie jest potrzebna do zaspokajania 
jego uzasadnionych potrzeb, powinna być złożona przez opiekuna w instytucji 
bankowej. Opiekun może podejmować ulokowaną gotówkę tylko za zezwoleniem 
sądu opiekuńczego.

***
### Art. 162. {#kro-art-162}

§ 1. Sąd opiekuńczy przyzna opiekunowi za sprawowanie opieki na 
jego żądanie stosowne wynagrodzenie okresowe albo wynagrodzenie jednorazowe 
w dniu ustania opieki lub zwolnienia go od niej. 
§ 2. Wynagrodzenia nie przyznaje się, jeżeli nakład pracy opiekuna jest 
nieznaczny lub gdy sprawowanie opieki jest związane z pełnieniem funkcji rodziny 
zastępczej albo czyni zadość zasadom współżycia społecznego. 
§ 3. Wynagrodzenie pokrywa się z dochodów lub z majątku osoby, dla której 
opieka została ustanowiona, a jeżeli osoba ta nie ma odpowiednich dochodów lub 
majątku, wynagrodzenie jest pokrywane ze środków publicznych na podstawie 
przepisów o pomocy społecznej.

***
### Art. 163. {#kro-art-163}

§ 1. Opiekun może żądać od pozostającego pod opieką zwrotu 
nakładów i wydatków związanych ze sprawowaniem opieki. Do roszczeń z tego tytułu 
stosuje się odpowiednio przepisy o zleceniu. 

 
 
 
s. 58/62 
 
 
 
2025-07-21 
 
§ 2. Roszczenia powyższe przedawniają się z upływem lat trzech od ustania 
opieki lub zwolnienia opiekuna. 
§ 3. Przepis art. 162 § 3 stosuje się odpowiednio.

***
### Art. 164. {#kro-art-164}

Roszczenie osoby pozostającej pod opieką o naprawienie szkody 
wyrządzonej nienależytym sprawowaniem opieki przedawnia się z upływem lat trzech 
od ustania opieki lub zwolnienia opiekuna. 

## Rozdział III
 
Nadzór nad sprawowaniem opieki

***
### Art. 165. {#kro-art-165}

§ 1. Sąd opiekuńczy wykonywa nadzór nad sprawowaniem opieki, 
zaznajamiając się bieżąco z działalnością opiekuna oraz udzielając mu wskazówek 
i poleceń. 
§ 2. Sąd opiekuńczy może żądać od opiekuna wyjaśnień we wszelkich sprawach 
należących do zakresu opieki oraz przedstawiania dokumentów związanych z jej 
sprawowaniem.

***
### Art. 166. {#kro-art-166}

§ 1. Opiekun obowiązany jest, w terminach oznaczonych przez sąd 
opiekuńczy, nie rzadziej niż co roku, składać temu sądowi sprawozdania dotyczące 
osoby pozostającego pod opieką oraz rachunki z zarządu jego majątkiem. 
§ 2. Jeżeli dochody z majątku nie przekraczają prawdopodobnych kosztów 
utrzymania i wychowania pozostającego pod opieką, sąd opiekuńczy może zwolnić 
opiekuna od przedstawiania szczegółowych rachunków z zarządu; w wypadku takim 
opiekun składa tylko ogólne sprawozdanie o zarządzie majątkiem.

***
### Art. 167. {#kro-art-167}

§ 1. Sąd opiekuńczy bada sprawozdania i rachunki opiekuna pod 
względem rzeczowym i rachunkowym, zarządza w razie potrzeby ich sprostowanie 
i uzupełnienie oraz orzeka, czy i w jakim zakresie rachunki zatwierdza. 
§ 2. Zatwierdzenie 
rachunku 
przez 
sąd 
opiekuńczy 
nie 
wyłącza 
odpowiedzialności opiekuna za szkodę wyrządzoną nienależytym sprawowaniem 
zarządu majątkiem.

***
### Art. 168. {#kro-art-168}

Jeżeli opiekun nie sprawuje należycie opieki, sąd opiekuńczy wyda 
odpowiednie zarządzenia. 

 
 
 
s. 59/62 
 
 
 
2025-07-21 
 

## Rozdział IV
 
Zwolnienie opiekuna i ustanie opieki

***
### Art. 169. {#kro-art-169}

§ 1. Z ważnych powodów sąd opiekuńczy może na żądanie opiekuna 
zwolnić go z opieki. 
§ 2. Sąd opiekuńczy zwolni opiekuna, jeżeli z powodu przeszkód faktycznych 
lub prawnych opiekun jest niezdolny do sprawowania opieki albo dopuszcza się 
czynów lub zaniedbań, które naruszają dobro pozostającego pod opieką. 
§ 3. Jeżeli sąd opiekuńczy nie postanowił inaczej, opiekun obowiązany jest 
prowadzić nadal pilne sprawy związane z opieką aż do czasu jej objęcia przez nowego 
opiekuna.

***
### Art. 170. {#kro-art-170}

Gdy małoletni osiągnie pełnoletność albo gdy przywrócona zostanie 
nad nim władza rodzicielska, opieka ustaje z mocy prawa.

***
### Art. 171. {#kro-art-171}

Jeżeli 
w chwili 
ustania 
opieki 
zachodzi 
przeszkoda 
do 
natychmiastowego przejęcia zarządu majątkiem przez osobę, która pozostawała pod 
opieką, albo przez jej przedstawiciela ustawowego lub spadkobierców, opiekun 
obowiązany jest nadal prowadzić pilne sprawy związane z zarządem majątku, chyba 
że sąd opiekuńczy postanowi inaczej.

***
### Art. 172. {#kro-art-172}

§ 1. W razie zwolnienia opiekuna lub ustania opieki opiekun 
obowiązany jest złożyć w ciągu trzech miesięcy rachunek końcowy z zarządu 
majątkiem. 
§ 2. Do rachunku końcowego stosuje się odpowiednio przepisy o rachunku 
rocznym.

***
### Art. 173. {#kro-art-173}

Sąd opiekuńczy może zwolnić opiekuna od obowiązku składania 
rachunku końcowego.

***
### Art. 174. {#kro-art-174}

Niezwłocznie po swym zwolnieniu lub po ustaniu opieki opiekun 
obowiązany jest oddać osobie, która pozostawała pod opieką, albo jej 
przedstawicielowi ustawowemu lub spadkobiercom zarządzany przez siebie majątek 
tej osoby. 

 
 
 
s. 60/62 
 
 
 
2025-07-21

