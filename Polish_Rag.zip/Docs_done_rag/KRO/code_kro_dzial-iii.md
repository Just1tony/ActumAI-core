---
id: code.kro.iii
title: Kodeks rodzinny i opiekuńczy — DZIAŁ III
short: KRO
dz_u: Dz.U. 1964 Nr 9 poz. 59
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '178'
  last: '184'
source_pdf: D19640059Lj.pdf
chunking:
  strategy: by-article
  anchor_pattern: '### Art. {n}. {#kro-art-{n}}'
  hierarchy:
  - DZIAŁ
  - Rozdział
  - Art.
---

# DZIAŁ III

### Art. 178. {#kro-art-178}

§ 1. Kuratora ustanawia się w wypadkach w ustawie przewidzianych. 
§ 2. W zakresie 
nieuregulowanym 
przez 
przepisy, 
które 
przewidują 
ustanowienie kuratora, stosuje się odpowiednio do kurateli przepisy o opiece 
z zachowaniem przepisów poniższych.

***
### Art. 179. {#kro-art-179}

§ 1. Organ państwowy, który ustanowił kuratora, przyzna mu na jego 
żądanie stosowne wynagrodzenie za sprawowanie kurateli. Wynagrodzenie pokrywa 
się z dochodów lub z majątku osoby, dla której kurator jest ustanowiony, a jeżeli osoba 
ta nie ma odpowiednich dochodów lub majątku, wynagrodzenie pokrywa ten, kto 
żądał ustanowienia kuratora. 
§ 2. Wynagrodzenia nie przyznaje się, jeżeli nakład pracy kuratora jest 
nieznaczny, a sprawowanie kurateli czyni zadość zasadom współżycia społecznego.

***
### Art. 180. {#kro-art-180}

§ 1. Z zastrzeżeniem wyjątków w ustawie przewidzianych, organ 
państwowy, który ustanowił kuratora, uchyli kuratelę, gdy odpadnie jej cel. 
§ 2. Jeżeli kurator został ustanowiony do załatwienia poszczególnej sprawy, 
kuratela ustaje z chwilą ukończenia tej sprawy. 

 
 
 
s. 61/62 
 
 
 
2025-07-21

***
### Art. 181. {#kro-art-181}

§ 1. Kurator osoby ubezwłasnowolnionej częściowo jest powołany do 
jej reprezentowania i do zarządu jej majątkiem tylko wtedy, gdy sąd opiekuńczy tak 
postanowi. 
§ 2. W razie uchylenia ubezwłasnowolnienia kuratela ustaje z mocy prawa.

***
### Art. 182. {#kro-art-182}

Dla dziecka poczętego, lecz jeszcze nieurodzonego, ustanawia się 
kuratora, jeżeli jest to potrzebne do strzeżenia przyszłych praw dziecka. Kuratela 
ustaje z chwilą urodzenia się dziecka.

***
### Art. 183. {#kro-art-183}

§ 1. Jeżeli pełnoletnia osoba niepełnosprawna potrzebuje wsparcia 
w prowadzeniu wszelkich spraw, spraw określonego rodzaju albo załatwieniu 
określonej sprawy, ustanawia się dla niej kuratora. Zakres obowiązków i uprawnień 
kuratora określa sąd opiekuńczy. 
 § 11. Kurator dla osoby niepełnosprawnej jest powołany do jej reprezentowania 
tylko wtedy, gdy sąd tak postanowi. Sąd opiekuńczy może określić sprawę lub zakres 
spraw wskazanych w postanowieniu o ustanowieniu kuratora, w których jest on 
uprawniony do reprezentowania osoby niepełnosprawnej. 
§ 12. Kuratorem może zostać ustanowiona osoba pełnoletnia, która wyraziła na 
to zgodę i której kwalifikacje osobiste uzasadniają przekonanie, że będzie należycie 
wywiązywała się z powierzonych jej obowiązków kuratora osoby niepełnosprawnej. 
Osoba niepełnosprawna może wskazać kandydata na kuratora. 
§ 13. Przy wyborze kuratora i określeniu zakresu jego obowiązków oraz 
uprawnień sąd opiekuńczy uwzględnia w szczególności sposób funkcjonowania osoby 
niepełnosprawnej, w tym w zakresie jej funkcji intelektualnych oraz sposobu 
porozumiewania się z otoczeniem. 
§ 14. Kurator uzgadnia z osobą niepełnosprawną sposób prowadzenia lub 
załatwienia spraw, o których mowa w § 1, i informuje osobę niepełnosprawną 
o podjętych działaniach oraz ich wynikach, tak aby mogła podejmować decyzje 
i działania odpowiednie do aktualnego stanu sprawy.  
§ 2. Kuratelę uchyla się na żądanie osoby niepełnosprawnej, dla której była 
ustanowiona.

***
### Art. 184. {#kro-art-184}

§ 1. Dla ochrony praw osoby, która z powodu nieobecności nie może 
prowadzić swoich spraw, a nie ma pełnomocnika, ustanawia się kuratora. To samo 

 
 
 
s. 62/62 
 
 
 
2025-07-21 
 
dotyczy wypadku, gdy pełnomocnik nieobecnego nie może wykonywać swoich 
czynności albo gdy je wykonywa nienależycie. 
§ 2. Kurator powinien przede wszystkim postarać się o ustalenie miejsca pobytu 
osoby nieobecnej i zawiadomić ją o stanie jej spraw. 
§ 3. Nie ustanawia się kuratora dla ochrony praw osoby, jeżeli istnieją przesłanki 
uznania jej za zmarłą.

