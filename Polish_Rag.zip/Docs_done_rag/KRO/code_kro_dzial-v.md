---
id: code.kro.v
title: Kodeks rodzinny i opiekuńczy — DZIAŁ V
short: KRO
dz_u: Dz.U. 1964 Nr 9 poz. 59
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '611'
  last: '616'
source_pdf: D19640059Lj.pdf
chunking:
  strategy: by-article
  anchor_pattern: '### Art. {n}. {#kro-art-{n}}'
  hierarchy:
  - DZIAŁ
  - Rozdział
  - Art.
---

# DZIAŁ V

### Art. 611. {#kro-art-611}

§ 1. Jeżeli między małżonkami nastąpił zupełny rozkład pożycia, każdy 
z małżonków może żądać, ażeby sąd orzekł separację. 
§ 2. Jednakże mimo zupełnego rozkładu pożycia orzeczenie separacji nie jest 
dopuszczalne, jeżeli wskutek niej miałoby ucierpieć dobro wspólnych małoletnich 
dzieci małżonków albo jeżeli z innych względów orzeczenie separacji byłoby 
sprzeczne z zasadami współżycia społecznego. 
§ 3. Jeżeli małżonkowie nie mają wspólnych małoletnich dzieci, sąd może orzec 
separację na podstawie zgodnego żądania małżonków.

***
### Art. 612. {#kro-art-612}

§ 1. Jeżeli jeden z małżonków żąda orzeczenia separacji, a drugi 
orzeczenia rozwodu i żądanie to jest uzasadnione, sąd orzeka rozwód. 
§ 2. Jeżeli jednak orzeczenie rozwodu nie jest dopuszczalne, a żądanie 
orzeczenia separacji jest uzasadnione, sąd orzeka separację.

***
### Art. 613. {#kro-art-613}

§ 1. Przy orzekaniu separacji stosuje się przepisy art. 57 i art. 58. 
§ 2. Orzekając separację na podstawie zgodnego żądania małżonków, sąd nie 
orzeka o winie rozkładu pożycia. W tym wypadku następują skutki takie, jak gdyby 
żaden z małżonków nie ponosił winy.

***
### Art. 614. {#kro-art-614}

§ 1. Orzeczenie separacji ma skutki takie jak rozwiązanie małżeństwa 
przez rozwód, chyba że ustawa stanowi inaczej. 
§ 2. Małżonek pozostający w separacji nie może zawrzeć małżeństwa. 
§ 3. Jeżeli wymagają tego względy słuszności, małżonkowie pozostający 
w separacji obowiązani są do wzajemnej pomocy. 
§ 4. Do 
obowiązku 
dostarczania 
środków 
utrzymania 
przez 
jednego 
z małżonków pozostających w separacji drugiemu stosuje się odpowiednio przepisy 
art. 60, z wyjątkiem § 3. 
§ 5. Przepisu art. 59 nie stosuje się.

***
### Art. 615. {#kro-art-615}

(uchylony)

***
### Art. 616. {#kro-art-616}

§ 1. Na zgodne żądanie małżonków sąd orzeka o zniesieniu separacji. 
§ 2. Z chwilą zniesienia separacji ustają jej skutki. 

 
 
 
s. 22/62 
 
 
 
2025-07-21 
 
§ 3. Znosząc separację, sąd rozstrzyga o władzy rodzicielskiej nad wspólnym 
małoletnim dzieckiem małżonków. 
Tytuł II 
Pokrewieństwo i powinowactwo

