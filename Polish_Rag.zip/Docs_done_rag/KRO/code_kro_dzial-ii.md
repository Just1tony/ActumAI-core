---
id: code.kro.ii
title: Kodeks rodzinny i opiekuńczy — DZIAŁ II
short: KRO
dz_u: Dz.U. 1964 Nr 9 poz. 59
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '175'
  last: '177'
source_pdf: D19640059Lj.pdf
chunking:
  strategy: by-article
  anchor_pattern: '### Art. {n}. {#kro-art-{n}}'
  hierarchy:
  - DZIAŁ
  - Rozdział
  - Art.
---

# DZIAŁ II

### Art. 175. {#kro-art-175}

Do opieki nad ubezwłasnowolnionym całkowicie stosuje się 
odpowiednio przepisy o opiece nad małoletnim z zachowaniem przepisów 
poniższych.

***
### Art. 176. {#kro-art-176}

Jeżeli wzgląd na dobro pozostającego pod opieką nie stoi temu na 
przeszkodzie, 
opiekunem 
ubezwłasnowolnionego 
całkowicie 
powinien 
być 
ustanowiony przede wszystkim jego małżonek, a w braku tegoż – jego ojciec lub 
matka.

***
### Art. 177. {#kro-art-177}

Opieka nad ubezwłasnowolnionym całkowicie ustaje z mocy prawa 
w razie 
uchylenia 
ubezwłasnowolnienia 
lub 
zmiany 
ubezwłasnowolnienia 
całkowitego na częściowe.

