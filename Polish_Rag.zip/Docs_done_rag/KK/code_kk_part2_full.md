---
id: code.kk.part2
title: "Kodeks karny – Część szczególna (Art. 117–316)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1997 nr 88 poz. 553"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KK – Część szczególna"]
tags: ["KK","kodeks karny","część szczególna","przestępstwa","PL"]
source_pdf: "D19970553Lj.pdf"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kk-art-{n}}"
  separators: "***"
  hierarchy: ["Część","Dział","Rozdział"]
---

# Kodeks karny – Część szczególna

CZĘŚĆ SZCZEGÓLNA 
### Rozdział XVI Przestępstwa przeciwko pokojowi, ludzkości oraz przestępstwa wojenne
***
## Art. 117. {#kk-art-117}

§ 1. Kto wszczyna lub prowadzi wojnę napastniczą, 
podlega karze pozbawienia wolności na czas nie krótszy od lat 12 albo karze 
dożywotniego pozbawienia wolności. 
§ 2. (uchylony) 

 
 
 
s. 58/146 
 
   
 
2025-04-09 
 
§ 3. Kto publicznie nawołuje do wszczęcia wojny napastniczej lub publicznie 
pochwala wszczęcie lub prowadzenie takiej wojny, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 118. {#kk-art-118}

§ 1. Kto, w celu wyniszczenia w całości albo w części grupy 
narodowej, etnicznej, rasowej, politycznej, wyznaniowej lub grupy o określonym 
światopoglądzie, dopuszcza się zabójstwa albo powoduje ciężki uszczerbek na 
zdrowiu osoby należącej do takiej grupy, 
podlega karze pozbawienia wolności na czas nie krótszy od lat 12 albo karze 
dożywotniego pozbawienia wolności. 
§ 2. Kto, w celu określonym w § 1, stwarza dla osób należących do takiej grupy 
warunki życia grożące jej biologicznym wyniszczeniem, stosuje środki mające służyć 
do wstrzymania urodzeń w obrębie grupy lub przymusowo odbiera dzieci osobom do 
niej należącym, 
podlega karze pozbawienia wolności od lat 5 do 25. 
§ 3. (uchylony) 
Art. 118a. § 1. Kto, biorąc udział w masowym zamachu lub choćby w jednym 
z powtarzających się zamachów skierowanych przeciwko grupie ludności podjętych 
w celu wykonania lub wsparcia polityki państwa lub organizacji: 
- 1) dopuszcza się zabójstwa, 
- 2) powoduje ciężki uszczerbek na zdrowiu człowieka, 
- 3) stwarza dla osób należących do grupy ludności warunki życia grożące ich 
biologicznej egzystencji, w szczególności przez pozbawienie dostępu do 
żywności lub opieki medycznej, które są obliczone na ich wyniszczenie, 
podlega karze pozbawienia wolności na czas nie krótszy od lat 12 albo karze 
dożywotniego pozbawienia wolności. 
§ 2. Kto, biorąc udział w masowym zamachu lub choćby w jednym 
z powtarzających się zamachów skierowanych przeciwko grupie ludności podjętych 
w celu wykonania lub wsparcia polityki państwa lub organizacji: 
- 1) powoduje oddanie osoby w stan niewolnictwa lub utrzymuje ją w tym stanie, 
- 2) pozbawia osobę wolności na czas przekraczający 7 dni lub ze szczególnym 
udręczeniem, 
- 3) stosuje tortury lub poddaje osobę okrutnemu lub nieludzkiemu traktowaniu, 

 
 
 
s. 59/146 
 
   
 
2025-04-09 
- 4) dopuszcza się zgwałcenia albo stosując przemoc, groźbę bezprawną lub podstęp 
w inny sposób narusza wolność seksualną osoby, 
- 5) stosując przemoc lub groźbę bezprawną powoduje zajście przez kobietę w ciążę 
w zamiarze wpłynięcia na skład etniczny grupy ludności lub dokonania innych 
poważnych naruszeń prawa międzynarodowego, 
- 6) pozbawia osobę wolności i odmawia udzielenia informacji dotyczących tej 
osoby lub miejsca jej pobytu lub przekazuje nieprawdziwe informacje dotyczące 
tej osoby lub miejsca jej pobytu, w zamiarze pozbawienia takiej osoby ochrony 
prawnej przez dłuższy okres, 
podlega karze pozbawienia wolności od lat 5 do 25. 
§ 3. Kto, biorąc udział w masowym zamachu lub choćby w jednym 
z powtarzających się zamachów skierowanych przeciwko grupie ludności podjętych 
w celu wykonania lub wsparcia polityki państwa lub organizacji: 
- 1) naruszając prawo międzynarodowe zmusza osoby do zmiany ich zgodnego 
z prawem miejsca zamieszkania, 
- 2) dopuszcza się poważnego prześladowania grupy ludności z powodów uznanych 
za niedopuszczalne na podstawie prawa międzynarodowego, w szczególności 
politycznych, rasowych, narodowych, etnicznych, kulturowych, wyznaniowych 
lub z powodu bezwyznaniowości, światopoglądu lub płci, powodując 
pozbawienie praw podstawowych, 
podlega karze pozbawienia wolności od lat 3 do 20.

***
## Art. 119. {#kk-art-119}

§ 1. Kto stosuje przemoc lub groźbę bezprawną wobec grupy osób lub 
poszczególnej osoby z powodu jej przynależności narodowej, etnicznej, rasowej, 
politycznej, wyznaniowej lub z powodu jej bezwyznaniowości, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. (uchylony)

***
## Art. 120. {#kk-art-120}

Kto stosuje środek masowej zagłady zakazany przez prawo 
międzynarodowe, 
podlega karze pozbawienia wolności na czas nie krótszy od lat 10 albo karze 
dożywotniego pozbawienia wolności.

***
## Art. 121. {#kk-art-121}

§ 1. Kto, wbrew zakazom prawa międzynarodowego lub przepisom 
ustawy, wytwarza, gromadzi, nabywa, zbywa, przechowuje, przewozi lub przesyła 

 
 
 
s. 60/146 
 
   
 
2025-04-09 
 
środki masowej zagłady lub środki walki bądź prowadzi badania mające na celu 
wytwarzanie lub stosowanie takich środków, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 2. Tej samej karze podlega, kto dopuszcza do popełnienia czynu określonego 
w § 1.

***
## Art. 122. {#kk-art-122}

§ 1. Kto w czasie działań zbrojnych atakuje miejscowość lub obiekt 
niebroniony, strefę sanitarną, zdemilitaryzowaną lub zneutralizowaną albo stosuje 
inny sposób walki zakazany przez prawo międzynarodowe, 
podlega karze pozbawienia wolności od lat 5 do 25. 
§ 2. Tej samej karze podlega, kto w czasie działań zbrojnych stosuje środek walki 
zakazany przez prawo międzynarodowe.

***
## Art. 123. {#kk-art-123}

§ 1. Kto, naruszając prawo międzynarodowe, dopuszcza się zabójstwa 
wobec: 
- 1) osób, które składając broń lub nie dysponując środkami obrony poddały się, 
- 2) rannych, chorych, rozbitków, personelu medycznego lub osób duchownych, 
- 3) jeńców wojennych, 
- 4) ludności cywilnej obszaru okupowanego, zajętego lub na którym toczą się 
działania zbrojne, albo innych osób korzystających w czasie działań zbrojnych 
z ochrony międzynarodowej, 
podlega karze pozbawienia wolności na czas nie krótszy od lat 12 albo karze 
dożywotniego pozbawienia wolności. 
§ 2. Kto, naruszając prawo międzynarodowe, powoduje u osób wymienionych 
w § 1 ciężki uszczerbek na zdrowiu, poddaje te osoby torturom, okrutnemu lub 
nieludzkiemu traktowaniu, dokonuje na nich, nawet za ich zgodą, eksperymentów 
poznawczych, używa ich do ochraniania swoją obecnością określonego terenu lub 
obiektu przed działaniami zbrojnymi albo własnych oddziałów lub zatrzymuje jako 
zakładników, 
podlega karze pozbawienia wolności od lat 5 do 25.

***
## Art. 124. {#kk-art-124}

§ 1. Kto, naruszając prawo międzynarodowe, zmusza osoby 
wymienione w art. 123 § 1 do służby w nieprzyjacielskich siłach zbrojnych lub do 
uczestnictwa w działaniach zbrojnych skierowanych przeciwko własnemu krajowi, 
stosuje kary cielesne, przemocą, groźbą bezprawną lub podstępem doprowadza te 

 
 
 
s. 61/146 
 
   
 
2025-04-09 
 
osoby do obcowania płciowego, poddania się innej czynności seksualnej albo do 
wykonania takiej czynności, dopuszcza się zamachu na godność osobistą, w 
szczególności poniżającego i upokarzającego traktowania, pozbawia wolności, 
pozbawia prawa do niezawisłego i bezstronnego sądu albo ogranicza prawo tych osób 
do obrony w postępowaniu karnym, ogłasza prawa lub roszczenia obywateli strony 
przeciwnej za wygasłe, zawieszone lub niedopuszczalne do dochodzenia przed sądem, 
podlega karze pozbawienia wolności od lat 3 do 20. 
§ 2. Tej samej karze podlega, kto, naruszając prawo międzynarodowe, opóźnia 
repatriację jeńców wojennych lub osób cywilnych, dokonuje przemieszczenia, 
przesiedlenia lub deportacji ludności cywilnej, wciela, werbuje do sił zbrojnych osoby 
poniżej 18 roku życia lub faktycznie używa takich osób w działaniach zbrojnych.

***
## Art. 125. {#kk-art-125}

§ 1. Kto, na obszarze okupowanym, zajętym lub na którym toczą się 
działania zbrojne, naruszając prawo międzynarodowe, niszczy, uszkadza, zabiera lub 
przywłaszcza mienie albo dobro kultury, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 2. Jeżeli czyn dotyczy mienia znacznej wartości albo dobra o szczególnym 
znaczeniu dla kultury, sprawca 
podlega karze pozbawienia wolności od lat 3 do 20.

***
## Art. 126. {#kk-art-126}

§ 1. Kto w czasie działań zbrojnych używa niezgodnie z prawem 
międzynarodowym znaku Czerwonego Krzyża lub Czerwonego Półksiężyca, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Tej samej karze podlega, kto w czasie działań zbrojnych używa niezgodnie 
z prawem międzynarodowym znaku ochronnego dla dóbr kultury lub innego znaku 
chronionego przez prawo międzynarodowe albo posługuje się flagą państwową lub 
odznaką wojskową nieprzyjaciela, państwa neutralnego albo organizacji lub komisji 
międzynarodowej. 
Art. 126a. Kto publicznie nawołuje do popełnienia czynu określonego 
w art. 118, 118a, 119 § 1, art. 120–125 lub publicznie pochwala popełnienie czynu 
określonego w tych przepisach, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 

 
 
 
s. 62/146 
 
   
 
2025-04-09 
 
Art. 126b. § 1. Kto, nie dopełniając obowiązku należytej kontroli, dopuszcza do 
popełnienia czynu określonego w art. 117 § 3, art. 118, 118a, 119 § 1, art. 120–126a 
przez osobę pozostającą pod jego faktyczną władzą lub kontrolą, 
podlega karze określonej w tych przepisach. 
§ 2. Jeżeli sprawca działa nieumyślnie, podlega karze pozbawienia wolności od 
3 miesięcy do lat 5. 
Art. 126c. § 1. Kto czyni przygotowania do przestępstwa określonego 
w art. 117, art. 118 lub art. 120, 
podlega karze pozbawienia wolności od lat 3 do 20. 
§ 2. Kto czyni przygotowania do przestępstwa określonego w art. 118a § 1 lub 
§ 2, art. 122 lub art. 123, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 3. Kto czyni przygotowania do przestępstwa określonego w art. 124 § 1 lub 
art. 125, 
podlega karze pozbawienia wolności do lat 3. 
### Rozdział XVII Przestępstwa przeciwko Rzeczypospolitej Polskiej

***
## Art. 127. {#kk-art-127}

§ 1. Kto, mając na celu pozbawienie niepodległości, oderwanie części 
obszaru lub zmianę przemocą konstytucyjnego ustroju Rzeczypospolitej Polskiej, 
podejmuje w porozumieniu z innymi osobami działalność zmierzającą bezpośrednio 
do urzeczywistnienia tego celu, 
podlega karze pozbawienia wolności na czas nie krótszy od lat 10 albo karze 
dożywotniego pozbawienia wolności. 
§ 2. Kto czyni przygotowania do popełnienia przestępstwa określonego w § 1, 
podlega karze pozbawienia wolności od lat 3 do 20.

***
## Art. 128. {#kk-art-128}

§ 1. Kto, w celu usunięcia przemocą konstytucyjnego organu 
Rzeczypospolitej Polskiej, podejmuje działalność zmierzającą bezpośrednio do 
urzeczywistnienia tego celu, 
podlega karze pozbawienia wolności od lat 3 do 20. 
§ 2. Kto czyni przygotowania do popełnienia przestępstwa określonego w § 1, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 

 
 
 
s. 63/146 
 
   
 
2025-04-09 
 
§ 3. Kto przemocą lub groźbą bezprawną wywiera wpływ na czynności 
urzędowe konstytucyjnego organu Rzeczypospolitej Polskiej, 
podlega karze pozbawienia wolności od roku do lat 10.

***
## Art. 129. {#kk-art-129}

Kto, 
będąc 
upoważniony 
do 
występowania 
w imieniu 
Rzeczypospolitej Polskiej w stosunkach z rządem obcego państwa lub zagraniczną 
organizacją, działa na szkodę Rzeczypospolitej Polskiej, 
podlega karze pozbawienia wolności od roku do lat 10.

***
## Art. 130. {#kk-art-130}

§ 1. Kto bierze udział w działalności obcego wywiadu albo działa na 
jego rzecz, przeciwko Rzeczypospolitej Polskiej, 
podlega karze pozbawienia wolności na czas nie krótszy od lat 5. 
§ 2. Kto, biorąc udział w działalności obcego wywiadu albo działając na jego 
rzecz, udziela temu wywiadowi wiadomości, której przekazanie może wyrządzić 
szkodę Rzeczypospolitej Polskiej, 
podlega karze pozbawienia wolności na czas nie krótszy od lat 8 albo karze 
dożywotniego pozbawienia wolności. 
§ 3. Kto zgłasza gotowość działania na rzecz obcego wywiadu przeciwko 
Rzeczypospolitej Polskiej albo w celu udzielenia obcemu wywiadowi wiadomości, 
których przekazanie może wyrządzić szkodę Rzeczypospolitej Polskiej, gromadzi je 
lub przechowuje lub wchodzi do systemu informatycznego w celu ich uzyskania, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 4. Kto działalność obcego wywiadu, o której mowa w § 1, organizuje lub nią 
kieruje, 
podlega karze pozbawienia wolności na czas nie krótszy od lat 10 albo karze 
dożywotniego pozbawienia wolności. 
§ 5. Funkcjonariusz publiczny oraz osoba pełniąca dyspozycyjnie terytorialną 
służbę wojskową, dopuszczający się czynu, o którym mowa w § 1, 
podlega karze pozbawienia wolności na czas nie krótszy od lat 8 albo karze 
dożywotniego pozbawienia wolności. 
§ 6. Kto bierze udział w działalności obcego wywiadu nieskierowanej przeciwko 
Rzeczypospolitej Polskiej prowadzonej na jej terytorium bez zgody właściwego 
organu udzielonej na podstawie odrębnych przepisów, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 

 
 
 
s. 64/146 
 
   
 
2025-04-09 
 
§ 7. Kto, biorąc udział w działalności obcego wywiadu albo działając na jego 
rzecz, dokonuje dywersji, sabotażu lub dopuszcza się przestępstwa o charakterze 
terrorystycznym, 
podlega karze pozbawienia wolności na czas nie krótszy od lat 10 albo karze 
dożywotniego pozbawienia wolności. 
§ 8. Kto czyni przygotowania do przestępstwa określonego w § 7, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 9. Kto, biorąc udział w działalności obcego wywiadu albo działając na jego 
rzecz, prowadzi dezinformację, polegającą na rozpowszechnianiu nieprawdziwych lub 
wprowadzających w błąd informacji, mając na celu wywołanie poważnych zakłóceń 
w ustroju lub gospodarce Rzeczypospolitej Polskiej, państwa sojuszniczego lub 
organizacji międzynarodowej, której członkiem jest Rzeczpospolita Polska albo 
skłonienie 
organu 
władzy 
publicznej 
Rzeczypospolitej 
Polskiej, 
państwa 
sojuszniczego lub organizacji międzynarodowej, której członkiem jest Rzeczpospolita 
Polska, do podjęcia lub zaniechania określonych czynności, 
podlega karze pozbawienia wolności na czas nie krótszy od lat 8.

***
## Art. 131. {#kk-art-131}

§ 1. Nie podlega karze za usiłowanie przestępstwa określonego 
w art. 127 § 1, art. 128 § 1 lub art. 130 § 1, 2, 5, 7 i 9 kto dobrowolnie poniechał 
dalszej działalności i ujawnił wobec organu powołanego do ścigania przestępstw 
wszystkie istotne okoliczności popełnionego czynu; przepis art. 17 § 2 stosuje się 
odpowiednio. 
§ 2. Nie podlega karze za przestępstwo określone w art. 128 § 2, art. 129 lub 
art. 130 § 3, 6 i 8, kto dobrowolnie poniechał dalszej działalności i podjął istotne 
starania zmierzające do zapobieżenia popełnieniu zamierzonego czynu zabronionego 
oraz ujawnił wobec organu powołanego do ścigania przestępstw wszystkie istotne 
okoliczności popełnionego czynu.

***
## Art. 132. {#kk-art-132}

Kto, oddając usługi wywiadowcze Rzeczypospolitej Polskiej, 
wprowadza w błąd polski organ państwowy przez dostarczanie podrobionych lub 
przerobionych dokumentów lub innych przedmiotów albo przez ukrywanie 
prawdziwych lub udzielanie fałszywych wiadomości mających istotne znaczenie dla 
Rzeczypospolitej Polskiej, 
podlega karze pozbawienia wolności od roku do lat 10. 

 
 
 
s. 65/146 
 
   
 
2025-04-09 
 
Art. 132a. (utracił moc)4)

***
## Art. 133. {#kk-art-133}

Kto publicznie znieważa Naród lub Rzeczpospolitą Polską, 
podlega karze pozbawienia wolności do lat 3.

***
## Art. 134. {#kk-art-134}

Kto dopuszcza się zamachu na życie Prezydenta Rzeczypospolitej 
Polskiej, 
podlega karze pozbawienia wolności na czas nie krótszy od lat 12 albo karze 
dożywotniego pozbawienia wolności.

***
## Art. 135. {#kk-art-135}

§ 1. 
Kto 
dopuszcza 
się 
czynnej 
napaści 
na 
Prezydenta 
Rzeczypospolitej Polskiej, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Kto publicznie znieważa Prezydenta Rzeczypospolitej Polskiej, 
podlega karze pozbawienia wolności do lat 3.

***
## Art. 136. {#kk-art-136}

§ 1. Kto na terytorium Rzeczypospolitej Polskiej dopuszcza się 
czynnej 
napaści 
na 
głowę 
obcego 
państwa 
lub 
akredytowanego 
szefa 
przedstawicielstwa dyplomatycznego takiego państwa albo osobę korzystającą 
z podobnej ochrony na mocy ustaw, umów lub powszechnie uznanych zwyczajów 
międzynarodowych, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Kto na terytorium Rzeczypospolitej Polskiej dopuszcza się czynnej napaści 
na osobę należącą do personelu dyplomatycznego przedstawicielstwa obcego państwa 
albo urzędnika konsularnego obcego państwa, w związku z pełnieniem przez nich 
obowiązków służbowych, 
podlega karze pozbawienia wolności do lat 3. 
§ 3. Karze określonej w § 2 podlega, kto na terytorium Rzeczypospolitej Polskiej 
publicznie znieważa osobę określoną w § 1. 
§ 4. Kto na terytorium Rzeczypospolitej Polskiej publicznie znieważa osobę 
określoną w § 2, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku.

***
## Art. 137. {#kk-art-137}

§ 1. Kto publicznie znieważa, niszczy, uszkadza lub usuwa godło, 
sztandar, chorągiew, banderę, flagę lub inny znak państwowy, 

 
 
 
s. 66/146 
 
   
 
2025-04-09 
 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 2. Tej samej karze podlega, kto na terytorium Rzeczypospolitej Polskiej 
znieważa, niszczy, uszkadza lub usuwa godło, sztandar, chorągiew, banderę, flagę lub 
inny znak państwa obcego, wystawione publicznie przez przedstawicielstwo tego 
państwa lub na zarządzenie polskiego organu władzy.

***
## Art. 138. {#kk-art-138}

§ 1. Przepisy art. 136 oraz 137 § 2 stosuje się, jeżeli państwo obce 
zapewnia wzajemność. 
§ 2. Przepisy art. 127, 128, 130 oraz 131 stosuje się odpowiednio, jeżeli czyn 
zabroniony popełniono na szkodę państwa sojuszniczego, a państwo to zapewnia 
wzajemność.

***
## Art. 139. {#kk-art-139}

W sprawie o przestępstwo określone w art. 127, art. 128 oraz 
art. 130 sąd może orzec przepadek przedmiotów również wtedy, gdy przedmioty nie 
stanowią własności sprawcy. 
### Rozdział XVIII Przestępstwa przeciwko obronności

***
## Art. 140. {#kk-art-140}

§ 1. Kto, w celu osłabienia mocy obronnej Rzeczypospolitej Polskiej, 
dopuszcza się gwałtownego zamachu na jednostkę Sił Zbrojnych Rzeczypospolitej 
Polskiej, niszczy lub uszkadza obiekt albo urządzenie o znaczeniu obronnym, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 2. Jeżeli następstwem czynu jest śmierć człowieka lub ciężki uszczerbek na 
zdrowiu wielu osób, sprawca 
podlega karze pozbawienia wolności od lat 2 do 15. 
§ 3. Kto czyni przygotowania do przestępstwa określonego w § 1, 
podlega karze pozbawienia wolności do lat 3. 
§ 4. W sprawie o przestępstwo określone w § 1–3 sąd może orzec przepadek 
przedmiotów również wtedy, gdy przedmioty nie stanowią własności sprawcy.

***
## Art. 141. {#kk-art-141}

§ 1. Kto, będąc obywatelem polskim, przyjmuje bez zgody właściwego 
organu obowiązki wojskowe w obcym wojsku lub w obcej organizacji wojskowej, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 

 
 
 
s. 67/146 
 
   
 
2025-04-09 
 
§ 2. Kto przyjmuje obowiązki w zakazanej przez prawo międzynarodowe 
wojskowej służbie najemnej, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 3. Nie popełnia przestępstwa określonego w § 1 obywatel polski będący 
równocześnie obywatelem innego państwa, jeżeli zamieszkuje na jego terytorium 
i pełni tam służbę wojskową.

***
## Art. 142. {#kk-art-142}

§ 1. Kto, wbrew przepisom ustawy, prowadzi zaciąg obywateli 
polskich lub przebywających w Rzeczypospolitej Polskiej cudzoziemców do służby 
wojskowej w obcym wojsku lub w obcej organizacji wojskowej, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Kto 
prowadzi 
zaciąg 
obywateli 
polskich 
lub 
przebywających 
w Rzeczypospolitej Polskiej cudzoziemców do służby w zakazanej przez prawo 
międzynarodowe wojskowej służbie najemnej albo taką służbę najemną opłaca, 
organizuje, szkoli lub wykorzystuje, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8.

***
## Art. 143. {#kk-art-143}

§ 1. Kto, w celu uzyskania zwolnienia od obowiązku służby wojskowej 
albo odroczenia tej służby, powoduje u siebie lub dopuszcza, by kto inny spowodował 
u niego skutek określony w art. 156 § 1 lub art. 157 § 1 albo w tym celu używa 
podstępu dla wprowadzenia w błąd właściwego organu, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Tej samej karze podlega, kto, w celu ułatwienia innej osobie zwolnienia od 
obowiązku służby wojskowej albo odroczenia tej służby, za jej zgodą powoduje u niej 
skutek określony w art. 156 § 1 lub art. 157 § 1 albo w tym celu używa podstępu dla 
wprowadzenia w błąd właściwego organu. 
§ 3. Kto dopuszcza się czynu zabronionego określonego w § 1 lub 2, jeżeli 
obowiązek dotyczy służby zastępującej służbę wojskową, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 144. {#kk-art-144}

§ 1. Kto, będąc powołanym do pełnienia czynnej służby wojskowej, 
nie zgłasza się do odbywania tej służby w określonym terminie i miejscu, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. W wypadku mniejszej wagi, sprawca 

 
 
 
s. 68/146 
 
   
 
2025-04-09 
 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 3. Kto nie zgłasza się do odbywania służby zastępującej służbę wojskową 
w warunkach określonych w § 1, 
podlega grzywnie albo karze ograniczenia wolności. 
Art. 144a. § 1. Kto, będąc powołanym do pełnienia służby w obronie cywilnej, 
nie zgłasza się do odbywania tej służby w określonym terminie i miejscu, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. W wypadku mniejszej wagi, sprawca 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
Art. 144b. § 1. Kto, odbywając służbę w obronie cywilnej, odmawia pełnienia 
tej służby, złośliwie lub uporczywie odmawia wykonania obowiązku wynikającego 
z tej służby albo polecenia w sprawach służbowych, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Tej samej karze podlega, kto, pełniąc służbę określoną w § 1, samowolnie 
opuszcza wyznaczone miejsce wykonywania obowiązków służbowych lub 
samowolnie poza nim pozostaje. 
§ 3. Jeżeli sprawca czynu zabronionego określonego w § 2 opuszcza, w celu 
trwałego uchylenia się od tej służby, wyznaczone miejsce wykonywania obowiązków 
służbowych albo w takim celu poza nim pozostaje, 
podlega karze pozbawienia wolności do lat 3.

***
## Art. 145. {#kk-art-145}

§ 1. Kto, odbywając służbę zastępującą służbę wojskową: 
- 1) odmawia pełnienia tej służby, złośliwie lub uporczywie odmawia wykonania 
obowiązku wynikającego z tej służby albo polecenia w sprawach służbowych, 
- 2) w celu częściowego lub zupełnego uchylenia się od tej służby albo wykonania 
obowiązku wynikającego z tej służby: 
  - a) powoduje u siebie lub dopuszcza, by kto inny spowodował u niego skutek 
określony w art. 156 § 1 lub art. 157 § 1, 
  - b) używa podstępu dla wprowadzenia w błąd przełożonego, 

 
 
 
s. 69/146 
 
   
 
2025-04-09 
 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Tej samej karze podlega, kto, pełniąc służbę określoną w § 1, samowolnie 
opuszcza wyznaczone miejsce wykonywania obowiązków służbowych lub 
samowolnie poza nim pozostaje. 
§ 3. Jeżeli sprawca czynu zabronionego określonego w § 2 opuszcza, w celu 
trwałego uchylenia się od tej służby, wyznaczone miejsce wykonywania obowiązków 
służbowych albo w takim celu poza nimi pozostaje, 
podlega karze pozbawienia wolności do lat 3.

***
## Art. 146. {#kk-art-146}

Jeżeli 
sprawca 
przestępstwa 
określonego 
w art. 145 § 2 
i 3 dobrowolnie powrócił, a jego nieobecność trwała nie dłużej niż 14 dni, sąd może 
zastosować nadzwyczajne złagodzenie kary, a nawet odstąpić od jej wymierzenia.

***
## Art. 147. {#kk-art-147}

W stosunku do sprawcy przestępstwa określonego w art. 143 § 1 lub 
w art. 144 lub 145, który w chwili czynu był niezdolny do pełnienia służby wojskowej, 
sąd może zastosować nadzwyczajne złagodzenie kary, a nawet odstąpić od jej 
wymierzenia. 
### Rozdział XIX Przestępstwa przeciwko życiu i zdrowiu

***
## Art. 148. {#kk-art-148}

§ 1. Kto zabija człowieka, 
podlega karze pozbawienia wolności na czas nie krótszy od lat 10 albo karze 
dożywotniego pozbawienia wolności. 
§ 2. Kto zabija człowieka: 
- 1) ze szczególnym okrucieństwem, 
- 2) w związku z wzięciem zakładnika, zgwałceniem albo rozbojem, 
- 3) w wyniku motywacji zasługującej na szczególne potępienie, 
- 4) z użyciem materiałów wybuchowych, 
podlega karze pozbawienia wolności na czas nie krótszy od lat 15 albo karze 
dożywotniego pozbawienia wolności. 
§ 3. Karze określonej w § 2 podlega, kto jednym czynem zabija więcej niż jedną 
osobę lub był wcześniej prawomocnie skazany za zabójstwo oraz sprawca zabójstwa 
funkcjonariusza publicznego popełnionego podczas lub w związku z pełnieniem przez 

 
 
 
s. 70/146 
 
   
 
2025-04-09 
 
niego obowiązków służbowych związanych z ochroną bezpieczeństwa ludzi lub 
ochroną bezpieczeństwa lub porządku publicznego. 
§ 4. Kto zabija człowieka pod wpływem silnego wzburzenia usprawiedliwionego 
okolicznościami, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 5. Kto czyni przygotowania do przestępstwa określonego w § 1, 2 lub 3,  
podlega karze pozbawienia wolności od lat 2 do 15. 
Art. 148a. § 1. Kto przyjmuje zlecenie zabójstwa człowieka w zamian za 
udzieloną lub obiecaną korzyść majątkową lub osobistą,  
podlega karze pozbawienia wolności od lat 2 do 15.  
§ 2. Nie podlega karze za przestępstwo określone w § 1, kto przed wszczęciem 
postępowania karnego ujawnił wobec organu powołanego do ścigania przestępstw 
osobę lub osoby zlecające zabójstwo oraz istotne okoliczności popełnionego czynu.

***
## Art. 149. {#kk-art-149}

Matka, która zabija dziecko w okresie porodu pod wpływem jego 
przebiegu, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 150. {#kk-art-150}

§ 1. Kto zabija człowieka na jego żądanie i pod wpływem współczucia 
dla niego, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. W wyjątkowych 
wypadkach 
sąd 
może 
zastosować 
nadzwyczajne 
złagodzenie kary, a nawet odstąpić od jej wymierzenia.

***
## Art. 151. {#kk-art-151}

Kto namową lub przez udzielenie pomocy doprowadza człowieka do 
targnięcia się na własne życie, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 152. {#kk-art-152}

§ 1. Kto za zgodą kobiety przerywa jej ciążę z naruszeniem przepisów 
ustawy, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Tej samej karze podlega, kto udziela kobiecie ciężarnej pomocy 
w przerwaniu ciąży z naruszeniem przepisów ustawy lub ją do tego nakłania. 
§ 3. Kto dopuszcza się czynu określonego w § 1 lub 2, gdy dziecko poczęte 
osiągnęło zdolność do samodzielnego życia poza organizmem kobiety ciężarnej, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 

 
 
 
s. 71/146 
 
   
 
2025-04-09

***
## Art. 153. {#kk-art-153}

§ 1. Kto stosując przemoc wobec kobiety ciężarnej lub w inny sposób 
bez jej zgody przerywa ciążę albo przemocą, groźbą bezprawną lub podstępem 
doprowadza kobietę ciężarną do przerwania ciąży, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. Kto dopuszcza się czynu określonego w § 1, gdy dziecko poczęte osiągnęło 
zdolność do samodzielnego życia poza organizmem kobiety ciężarnej, 
podlega karze pozbawienia wolności od roku do lat 10.

***
## Art. 154. {#kk-art-154}

§ 1. Jeżeli następstwem czynu określonego w art. 152 § 1 lub 2 jest 
śmierć kobiety ciężarnej, sprawca 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 2. Jeżeli następstwem czynu określonego w art. 152 § 3 lub w art. 153 jest 
śmierć kobiety ciężarnej, sprawca 
podlega karze pozbawienia wolności od lat 2 do 15.

***
## Art. 155. {#kk-art-155}

Kto nieumyślnie powoduje śmierć człowieka, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 156. {#kk-art-156}

§ 1. Kto powoduje ciężki uszczerbek na zdrowiu w postaci: 
- 1) pozbawienia człowieka wzroku, słuchu, mowy, zdolności płodzenia, 
- 2) innego ciężkiego kalectwa, ciężkiej choroby nieuleczalnej lub długotrwałej, 
choroby realnie zagrażającej życiu, trwałej choroby psychicznej, całkowitej albo 
znacznej trwałej niezdolności do pracy w zawodzie lub trwałego, istotnego 
zeszpecenia lub zniekształcenia ciała, 
- 3) wycięcia, infibulacji lub innego trwałego i istotnego okaleczenia żeńskiego 
narządu płciowego, 
podlega karze pozbawienia wolności od lat 3 do 20. 
§ 2. Jeżeli sprawca działa nieumyślnie, 
podlega karze pozbawienia wolności do lat 3. 
§ 3. Jeżeli następstwem czynu określonego w § 1 jest śmierć człowieka, sprawca 
podlega karze pozbawienia wolności na czas nie krótszy od lat 5 albo karze 
dożywotniego pozbawienia wolności. 
Art. 156a. § 1. Kto nakłania inną osobę do spowodowania u niej ciężkiego 
uszczerbku na zdrowiu, o którym mowa w art. 156 § 1 pkt 3,  
podlega karze pozbawienia wolności do lat 3.  

 
 
 
s. 72/146 
 
   
 
2025-04-09 
 
§ 2. Kto przemocą lub groźbą bezprawną zmusza inną osobę do spowodowania 
u niej ciężkiego uszczerbku na zdrowiu, o którym mowa w art. 156 § 1 pkt 3,  
podlega karze pozbawienia wolności od 3 miesięcy do 5 lat.

***
## Art. 157. {#kk-art-157}

§ 1. Kto powoduje naruszenie czynności narządu ciała lub rozstrój 
zdrowia, inny niż określony w art. 156 § 1, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Kto powoduje naruszenie czynności narządu ciała lub rozstrój zdrowia 
trwający nie dłużej niż 7 dni, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 3. Jeżeli sprawca czynu określonego w § 1 lub 2 działa nieumyślnie, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 4. Ściganie przestępstwa określonego w § 2 lub 3, jeżeli naruszenie czynności 
narządu ciała lub rozstrój zdrowia nie trwał dłużej niż 7 dni, odbywa się z oskarżenia 
prywatnego, chyba że pokrzywdzonym jest osoba najbliższa zamieszkująca wspólnie 
ze sprawcą. 
§ 5. Jeżeli pokrzywdzonym jest osoba najbliższa, ściganie przestępstwa 
określonego w § 3 następuje na jej wniosek. 
Art. 157a. § 1. Kto powoduje uszkodzenie ciała dziecka poczętego lub rozstrój 
zdrowia zagrażający jego życiu, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Nie popełnia przestępstwa lekarz, jeżeli uszkodzenie ciała lub rozstrój 
zdrowia dziecka poczętego są następstwem działań leczniczych, koniecznych dla 
uchylenia niebezpieczeństwa grożącego zdrowiu lub życiu kobiety ciężarnej albo 
dziecka poczętego. 
§ 3. Nie podlega karze matka dziecka poczętego, która dopuszcza się czynu 
określonego w § 1.

***
## Art. 158. {#kk-art-158}

§ 1. Kto bierze udział w bójce lub pobiciu, w którym naraża się 
człowieka na bezpośrednie niebezpieczeństwo utraty życia albo nastąpienie skutku 
określonego w art. 156 § 1 lub w art. 157 § 1, 

 
 
 
s. 73/146 
 
   
 
2025-04-09 
 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Jeżeli następstwem bójki lub pobicia jest ciężki uszczerbek na zdrowiu 
człowieka, sprawca 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 3. Jeżeli następstwem bójki lub pobicia jest śmierć człowieka, sprawca 
podlega karze pozbawienia wolności od lat 2 do 15.

***
## Art. 159. {#kk-art-159}

Kto, biorąc udział w bójce lub pobiciu człowieka, używa broni palnej, 
noża lub innego podobnie niebezpiecznego przedmiotu, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8.

***
## Art. 160. {#kk-art-160}

§ 1. Kto naraża człowieka na bezpośrednie niebezpieczeństwo utraty 
życia albo ciężkiego uszczerbku na zdrowiu, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Jeżeli na sprawcy ciąży obowiązek opieki nad osobą narażoną na 
niebezpieczeństwo, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 3. Jeżeli sprawca czynu określonego w § 1 lub 2 działa nieumyślnie, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 4. Nie podlega karze za przestępstwo określone w § 1–3 sprawca, który 
dobrowolnie uchylił grożące niebezpieczeństwo. 
§ 5. Ściganie 
przestępstwa 
określonego 
w § 3 następuje 
na 
wniosek 
pokrzywdzonego.

***
## Art. 161. {#kk-art-161}

§ 1. Kto, wiedząc, że jest zarażony wirusem HIV lub dotknięty chorobą 
weneryczną lub zakaźną, ciężką chorobą nieuleczalną lub realnie zagrażającą życiu, 
naraża bezpośrednio inną osobę na zarażenie tym wirusem lub taką chorobą,  
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. (uchylony) 
§ 3. Jeżeli sprawca czynu określonego w § 1 naraża na zarażenie wiele osób,  
podlega karze pozbawienia wolności od roku do lat 10. 
§ 4. Ściganie przestępstwa określonego w § 1 następuje na wniosek 
pokrzywdzonego. 

 
 
 
s. 74/146 
 
   
 
2025-04-09

***
## Art. 162. {#kk-art-162}

§ 1. Kto człowiekowi znajdującemu się w położeniu grożącym 
bezpośrednim niebezpieczeństwem utraty życia albo ciężkiego uszczerbku na zdrowiu 
nie udziela pomocy, mogąc jej udzielić bez narażenia siebie lub innej osoby 
na niebezpieczeństwo utraty życia albo ciężkiego uszczerbku na zdrowiu, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Nie popełnia przestępstwa, kto nie udziela pomocy, do której jest konieczne 
poddanie się zabiegowi lekarskiemu albo w warunkach, w których możliwa jest 
niezwłoczna pomoc ze strony instytucji lub osoby do tego powołanej. 
### Rozdział XX Przestępstwa przeciwko bezpieczeństwu powszechnemu

***
## Art. 163. {#kk-art-163}

§ 1. Kto sprowadza zdarzenie, które zagraża życiu lub zdrowiu wielu 
osób albo mieniu w wielkich rozmiarach, mające postać: 
- 1) pożaru, 
- 2) zawalenia się budowli, zalewu albo obsunięcia się ziemi, skał lub śniegu, 
- 3) eksplozji materiałów wybuchowych lub łatwopalnych albo innego gwałtownego 
wyzwolenia energii, rozprzestrzeniania się substancji trujących, duszących lub 
parzących, 
- 4) gwałtownego wyzwolenia energii jądrowej lub wyzwolenia promieniowania 
jonizującego, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 2. Jeżeli sprawca działa nieumyślnie, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 3. Jeżeli następstwem czynu określonego w § 1 jest śmierć człowieka lub 
ciężki uszczerbek na zdrowiu wielu osób, sprawca 
podlega karze pozbawienia wolności od lat 2 do 15. 
§ 4. Jeżeli następstwem czynu określonego w § 2 jest śmierć człowieka lub 
ciężki uszczerbek na zdrowiu wielu osób, sprawca 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8.

***
## Art. 164. {#kk-art-164}

§ 1. Kto sprowadza bezpośrednie niebezpieczeństwo zdarzenia 
określonego w art. 163 § 1, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. Jeżeli sprawca działa nieumyślnie, 

 
 
 
s. 75/146 
 
   
 
2025-04-09 
 
podlega karze pozbawienia wolności do lat 3.

***
## Art. 165. {#kk-art-165}

§ 1. Kto sprowadza niebezpieczeństwo dla życia lub zdrowia wielu 
osób albo dla mienia w wielkich rozmiarach: 
- 1) powodując zagrożenie epidemiologiczne lub szerzenie się choroby zakaźnej albo 
zarazy zwierzęcej lub roślinnej, 
- 2) wyrabiając lub wprowadzając do obrotu szkodliwe dla zdrowia substancje, 
środki spożywcze lub inne artykuły powszechnego użytku lub też środki 
farmaceutyczne nieodpowiadające obowiązującym warunkom jakości, 
- 3) powodując 
uszkodzenie 
lub 
unieruchomienie 
urządzenia 
użyteczności 
publicznej, w szczególności urządzenia dostarczającego wodę, światło, ciepło, 
gaz, 
energię 
albo 
urządzenia 
zabezpieczającego 
przed 
nastąpieniem 
niebezpieczeństwa powszechnego lub służącego do jego uchylenia, 
- 4) zakłócając, uniemożliwiając lub w inny sposób wpływając na automatyczne 
przetwarzanie, gromadzenie lub przekazywanie danych informatycznych, 
- 5) działając w inny sposób w okolicznościach szczególnie niebezpiecznych, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. Jeżeli sprawca działa nieumyślnie, 
podlega karze pozbawienia wolności do lat 3. 
§ 3. Jeżeli następstwem czynu określonego w § 1 jest śmierć człowieka lub 
ciężki uszczerbek na zdrowiu wielu osób, sprawca 
podlega karze pozbawienia wolności od lat 2 do 15. 
§ 4. Jeżeli następstwem czynu określonego w § 2 jest śmierć człowieka lub 
ciężki uszczerbek na zdrowiu wielu osób, sprawca 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
Art. 165a. § 1. Kto gromadzi, przekazuje lub oferuje środki płatnicze, 
instrumenty finansowe, papiery wartościowe, wartości dewizowe, prawa majątkowe 
lub inne mienie ruchome lub nieruchomości w zamiarze sfinansowania przestępstwa 
o charakterze terrorystycznym lub przestępstwa, o którym mowa w art. 120, art. 121, 
art. 136, art. 166, art. 167, art. 171, art. 252, art. 255a lub art. 259a, 
podlega karze pozbawienia wolności od lat 2 do 15. 
§ 2. Tej 
samej 
karze 
podlega, 
kto 
udostępnia 
mienie 
określone 
w § 1 zorganizowanej grupie lub związkowi mającym na celu popełnienie 

 
 
 
s. 76/146 
 
   
 
2025-04-09 
 
przestępstwa, o którym mowa w tym przepisie, osobie biorącej udział w takiej grupie 
lub związku lub osobie, która ma zamiar popełnienia takiego przestępstwa. 
§ 3. Kto, nie będąc do tego obowiązany na mocy ustawy, pokrywa koszty 
związane z zaspokojeniem potrzeb lub wykonaniem zobowiązań finansowych grupy, 
związku lub osoby, o których mowa w § 2, 
podlega karze pozbawienia wolności do lat 3. 
§ 4. Tej samej karze podlega sprawca czynu określonego w § 1 lub 2, który działa 
nieumyślnie.

***
## Art. 166. {#kk-art-166}

§ 1. Kto, stosując podstęp albo gwałt na osobie lub groźbę 
bezpośredniego użycia takiego gwałtu, przejmuje kontrolę nad statkiem wodnym lub 
powietrznym albo nad publicznym środkiem transportu lądowego,  
podlega karze pozbawienia wolności od lat 2 do 15. 
§ 2. Kto, działając w sposób określony w § 1, sprowadza bezpośrednie 
niebezpieczeństwo dla życia lub zdrowia wielu osób, 
podlega karze pozbawienia wolności od lat 3 do 20. 
§ 3. Jeżeli następstwem czynu określonego w § 2 jest śmierć człowieka lub 
ciężki uszczerbek na zdrowiu wielu osób, sprawca 
podlega karze pozbawienia wolności od lat 5 do 25.

***
## Art. 167. {#kk-art-167}

§ 1. Kto umieszcza na statku wodnym lub powietrznym albo w 
publicznym środku transportu lądowego urządzenie lub substancję zagrażającą 
bezpieczeństwu osób lub mieniu znacznej wartości,  
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Tej samej karze podlega, kto niszczy, uszkadza lub czyni niezdatnym do 
użytku urządzenie nawigacyjne albo uniemożliwia jego obsługę, jeżeli może to 
zagrażać bezpieczeństwu osób.

***
## Art. 168. {#kk-art-168}

Kto czyni przygotowania do przestępstwa określonego w art. 163 § 1, 
art. 165 § 1, art. 166 § 1 lub w art. 167 § 1, 
podlega karze pozbawienia wolności do lat 3.

***
## Art. 169. {#kk-art-169}

§ 1. Nie podlega karze za przestępstwo określone w art. 164 lub 
167 sprawca, który dobrowolnie uchylił grożące niebezpieczeństwo. 
§ 2. Wobec sprawcy przestępstwa określonego w art. 163 § 1 lub 2, art. 165 § 1 
lub 2 lub w art. 166 § 2 sąd może zastosować nadzwyczajne złagodzenie kary, jeżeli 

 
 
 
s. 77/146 
 
   
 
2025-04-09 
 
sprawca dobrowolnie uchylił niebezpieczeństwo grożące życiu lub zdrowiu wielu 
osób. 
§ 3. Wobec sprawcy przestępstwa określonego w art. 166 § 1 sąd może 
zastosować nadzwyczajne złagodzenie kary, jeżeli sprawca przekazał statek lub 
kontrolę nad nim osobie uprawnionej.

***
## Art. 170. {#kk-art-170}

Kto uzbraja lub przysposabia statek morski przeznaczony do 
dokonania na morzu rabunku lub na takim statku przyjmuje służbę, 
podlega karze pozbawienia wolności od roku do lat 10.

***
## Art. 171. {#kk-art-171}

§ 1. Kto, bez wymaganego zezwolenia lub wbrew jego warunkom, 
wyrabia, przetwarza, gromadzi, posiada, posługuje się lub handluje substancją lub 
przyrządem wybuchowym, materiałem radioaktywnym, urządzeniem emitującym 
promienie jonizujące lub innym przedmiotem lub substancją, która może sprowadzić 
niebezpieczeństwo dla życia lub zdrowia wielu osób albo mienia w wielkich 
rozmiarach, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. Tej samej karze podlega, kto wbrew obowiązkowi dopuszcza do popełnienia 
czynu określonego w § 1. 
§ 3. Tej samej karze podlega, kto przedmioty określone w § 1 odstępuje osobie 
nieuprawnionej.

***
## Art. 172. {#kk-art-172}

Kto przeszkadza działaniu mającemu na celu zapobieżenie 
niebezpieczeństwu dla życia lub zdrowia wielu osób albo mienia w wielkich 
rozmiarach, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
### Rozdział XXI Przestępstwa przeciwko bezpieczeństwu w komunikacji

***
## Art. 173. {#kk-art-173}

§ 1. Kto sprowadza katastrofę w ruchu lądowym, wodnym lub 
powietrznym zagrażającą życiu lub zdrowiu wielu osób albo mieniu w wielkich 
rozmiarach, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 2. Jeżeli sprawca działa nieumyślnie, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 

 
 
 
s. 78/146 
 
   
 
2025-04-09 
 
§ 3. Jeżeli następstwem czynu określonego w § 1 jest śmierć człowieka lub 
ciężki uszczerbek na zdrowiu wielu osób, sprawca 
podlega karze pozbawienia wolności od lat 2 do 15. 
§ 4. Jeżeli następstwem czynu określonego w § 2 jest śmierć człowieka lub 
ciężki uszczerbek na zdrowiu wielu osób, sprawca 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8.

***
## Art. 174. {#kk-art-174}

§ 1. Kto sprowadza bezpośrednie niebezpieczeństwo katastrofy 
w ruchu lądowym, wodnym lub powietrznym, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. Jeżeli sprawca działa nieumyślnie, 
podlega karze pozbawienia wolności do lat 3.

***
## Art. 175. {#kk-art-175}

Kto czyni przygotowania do przestępstwa określonego w art. 173 § 1, 
podlega karze pozbawienia wolności do lat 3.

***
## Art. 176. {#kk-art-176}

§ 1. Nie podlega karze sprawca przestępstwa określonego w art. 174, 
który dobrowolnie uchylił grożące niebezpieczeństwo. 
§ 2. Wobec sprawcy przestępstwa określonego w art. 173 § 1 lub 2 sąd może 
zastosować nadzwyczajne złagodzenie kary, jeżeli sprawca dobrowolnie uchylił 
niebezpieczeństwo grożące życiu lub zdrowiu wielu osób.

***
## Art. 177. {#kk-art-177}

§ 1. Kto, naruszając, chociażby nieumyślnie, zasady bezpieczeństwa 
w ruchu lądowym, wodnym lub powietrznym, powoduje nieumyślnie wypadek, 
w którym inna osoba odniosła obrażenia ciała określone w art. 157 § 1, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Jeżeli następstwem wypadku jest śmierć innej osoby albo ciężki uszczerbek 
na jej zdrowiu, sprawca 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 3. Jeżeli pokrzywdzonym jest wyłącznie osoba najbliższa, ściganie 
przestępstwa określonego w § 1 następuje na jej wniosek.

***
## Art. 178. {#kk-art-178}

§ 1. Skazując sprawcę, który popełnił przestępstwo określone w art. 
173 § 1 lub 2, art. 174 lub art. 177 § 1 znajdując się w stanie nietrzeźwości lub pod 
wpływem środka odurzającego lub zbiegł z miejsca zdarzenia lub spożywał alkohol 
lub zażywał środek odurzający po popełnieniu czynu określonego w art. 173 § 1 lub 
2, art. 174 lub art. 177 § 1, a przed poddaniem go przez uprawniony organ badaniu w 

 
 
 
s. 79/146 
 
   
 
2025-04-09 
 
celu ustalenia w organizmie zawartości alkoholu lub obecności środka odurzającego, 
sąd orzeka karę pozbawienia wolności przewidzianą za przypisane sprawcy 
przestępstwo w wysokości od dolnej granicy ustawowego zagrożenia zwiększonego o 
połowę do górnej granicy tego zagrożenia zwiększonego o połowę. 
§ 1a. Skazując sprawcę, który popełnił przestępstwo określone w art. 173 § 3 lub 
4 lub art. 177 § 2, w warunkach określonych w § 1 lub którego dotyczy wskazana 
w tym przepisie okoliczność, sąd orzeka karę pozbawienia wolności w wysokości: 
- 1) nie niższej niż 3 lata, jeżeli następstwem wypadku jest ciężki uszczerbek na 
zdrowiu innej osoby albo następstwem katastrofy jest ciężki uszczerbek na 
zdrowiu wielu osób, do dwukrotności górnej granicy ustawowego zagrożenia, 
- 2) nie niższej niż 5 lat, jeżeli następstwem czynu jest śmierć człowieka, do 
dwukrotności górnej granicy ustawowego zagrożenia w przypadku katastrofy, 
a 20 lat pozbawienia wolności w przypadku wypadku. 
§ 2. (uchylony) 
§ 3. W razie skazania, o którym mowa w § 1 lub 1a, sąd może orzec przepadek, 
o którym mowa w art. 44b, a orzeka go, jeżeli zawartość alkoholu w organizmie 
sprawcy była wyższa niż 1 promil we krwi lub 0,5 mg/dm3 w wydychanym powietrzu 
albo prowadziła do takiego stężenia. 
Art. 178a. § 1. Kto, znajdując się w stanie nietrzeźwości lub pod wpływem 
środka odurzającego, prowadzi pojazd mechaniczny w ruchu lądowym, wodnym lub 
powietrznym, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. (uchylony) 
§ 3. (uchylony) 
§ 4. Jeżeli sprawca czynu określonego w § 1 był wcześniej prawomocnie skazany 
za prowadzenie pojazdu mechanicznego w stanie nietrzeźwości lub pod wpływem 
środka odurzającego albo za przestępstwo określone w art. 173, art. 174, art. 177 lub 
art. 355 § 2 popełnione w stanie nietrzeźwości lub pod wpływem środka odurzającego 
lub dopuścił się czynu określonego w § 1 w okresie obowiązywania zakazu 
prowadzenia pojazdów mechanicznych orzeczonego w związku ze skazaniem 
za przestępstwo, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 

 
 
 
s. 80/146 
 
   
 
2025-04-09 
 
§ 5. Sąd orzeka przepadek, o którym mowa w art. 44b, w razie popełnienia 
przestępstwa określonego w § 1 lub 4, chyba że zawartość alkoholu w organizmie 
sprawcy przestępstwa określonego w § 1 była niższa niż 1,5 promila we krwi lub 0,75 
mg/dm3 w wydychanym powietrzu albo nie prowadziła do takiego stężenia. Sąd może 
odstąpić od orzeczenia przepadku, jeżeli zachodzi wyjątkowy wypadek, uzasadniony 
szczególnymi okolicznościami. 
Art. 178b. Kto, pomimo wydania przez osobę uprawnioną do kontroli ruchu 
drogowego, poruszającą się pojazdem lub znajdującą się na statku wodnym albo 
powietrznym, przy użyciu sygnałów dźwiękowych i świetlnych, polecenia 
zatrzymania pojazdu mechanicznego nie zatrzymuje niezwłocznie pojazdu 
i kontynuuje jazdę, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 179. {#kk-art-179}

Kto wbrew szczególnemu obowiązkowi dopuszcza do ruchu pojazd 
mechaniczny albo inny pojazd w stanie bezpośrednio zagrażającym bezpieczeństwu 
w ruchu lądowym, wodnym lub powietrznym lub dopuszcza do prowadzenia pojazdu 
mechanicznego albo innego pojazdu na drodze publicznej, w strefie zamieszkania lub 
w strefie ruchu przez osobę znajdującą się w stanie nietrzeźwości, będącą pod 
wpływem środka odurzającego lub osobę nieposiadającą wymaganych uprawnień, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 180. {#kk-art-180}

Kto, znajdując się w stanie nietrzeźwości lub pod wpływem środka 
odurzającego, 
pełni 
czynności 
związane 
bezpośrednio 
z zapewnieniem 
bezpieczeństwa ruchu pojazdów mechanicznych, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
Art. 180a. Kto na drodze publicznej, w strefie zamieszkania lub w strefie ruchu, 
prowadzi pojazd mechaniczny, nie stosując się do decyzji właściwego organu 
o cofnięciu uprawnienia do kierowania pojazdami, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 

 
 
 
s. 81/146 
 
   
 
2025-04-09 
### Rozdział XXII Przestępstwa przeciwko środowisku

***
## Art. 181. {#kk-art-181}

§ 1. Kto powoduje zniszczenie w świecie roślinnym lub zwierzęcym w 
znacznych rozmiarach,  
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. Kto, wbrew przepisom obowiązującym na terenie objętym ochroną, niszczy 
lub uszkadza rośliny, zwierzęta, grzyby lub ich siedliska, lub siedliska przyrodnicze, 
powodując istotną szkodę,  
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności od 3 
miesięcy do lat 5. 
§ 3. Karze określonej w § 2 podlega także ten, kto niezależnie od miejsca czynu 
niszczy lub uszkadza rośliny, zwierzęta, grzyby pozostające pod ochroną gatunkową 
lub ich siedliska, powodując istotną szkodę. 
§ 4. Jeżeli sprawca czynu określonego w § 1 działa nieumyślnie, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 5. Jeżeli sprawca czynu określonego w § 2 lub 3 działa nieumyślnie, 
podlega grzywnie albo karze ograniczenia wolności.

***
## Art. 182. {#kk-art-182}

§ 1. Kto zanieczyszcza wodę, powietrze lub powierzchnię ziemi 
substancją albo promieniowaniem jonizującym w takiej ilości lub w takiej postaci, że 
może to zagrozić życiu lub zdrowiu człowieka lub spowodować istotne obniżenie 
jakości wody, powietrza lub powierzchni ziemi lub zniszczenie w świecie roślinnym 
lub zwierzęcym w znacznych rozmiarach,  
podlega karze pozbawienia wolności od 6 miesięcy do lat 8.  
§ 2. Jeżeli sprawca czynu określonego w § 1 działa nieumyślnie,  
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 3.  
§ 3. Jeżeli czyn określony w § 1 został popełniony w związku z eksploatacją 
instalacji działającej w ramach zakładu, w zakresie korzystania ze środowiska, na 
które wymagane jest pozwolenie, sprawca  
podlega karze pozbawienia wolności od roku do lat 10.  
§ 4. Jeżeli sprawca czynu określonego w § 3 działa nieumyślnie,  

 
 
 
s. 82/146 
 
   
 
2025-04-09 
 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 183. {#kk-art-183}

§ 1. Kto wbrew przepisom składuje, usuwa, przetwarza, zbiera, 
unieszkodliwia, transportuje odpady lub substancje albo dokonuje odzysku odpadów 
lub substancji w takich warunkach lub w taki sposób, że może to zagrozić życiu lub 
zdrowiu człowieka lub spowodować obniżenie jakości wody, powietrza lub 
powierzchni ziemi lub zniszczenie w świecie roślinnym lub zwierzęcym,  
podlega karze pozbawienia wolności od roku do lat 10. 
§ 2. Tej samej karze podlega, kto wbrew przepisom przywozi z zagranicy 
substancje zagrażające środowisku. 
§ 3. Karze określonej w § 1 podlega, kto wbrew obowiązkowi dopuszcza do 
popełnienia czynu określonego w § 1, 2 i 4. 
§ 4. Karze określonej w § 1 podlega, kto wbrew przepisom przywozi odpady 
z zagranicy lub wywozi odpady za granicę. 
§ 5. Kto bez wymaganego zgłoszenia lub zezwolenia albo wbrew jego warunkom 
przywozi z zagranicy lub wywozi za granicę odpady niebezpieczne,  
podlega karze pozbawienia wolności od lat 2 do 12. 
§ 5a. Karze określonej w § 5 podlega, kto porzuca odpady niebezpieczne w 
miejscu nieprzeznaczonym do ich składowania lub magazynowania. 
§ 6. Jeżeli sprawca czynu określonego w § 1–5a działa nieumyślnie, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 5.

***
## Art. 184. {#kk-art-184}

§ 1. Kto wyrabia, przetwarza, transportuje, przywozi z zagranicy, 
wywozi za granicę, gromadzi, składuje, przechowuje, posiada, wykorzystuje, 
posługuje się, usuwa, porzuca lub pozostawia bez właściwego zabezpieczenia materiał 
jądrowy albo inne źródło promieniowania jonizującego, w takich warunkach lub 
w taki sposób, że może to zagrozić życiu lub zdrowiu człowieka lub spowodować 
istotne obniżenie jakości wody, powietrza lub powierzchni ziemi lub zniszczenie 
w świecie roślinnym lub zwierzęcym w znacznych rozmiarach, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Tej samej karze podlega, kto wbrew obowiązkowi dopuszcza do popełnienia 
czynu określonego w § 1. 
§ 3. Jeżeli sprawca czynu określonego w § 1 lub 2 działa nieumyślnie, 

 
 
 
s. 83/146 
 
   
 
2025-04-09 
 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 185. {#kk-art-185}

§ 1. Jeżeli następstwem czynu określonego w art. 182 § 1 lub 3, art. 
183 § 1 lub 3 lub w art. 184 § 1 lub 2 jest zniszczenie w świecie roślinnym lub 
zwierzęcym w znacznych rozmiarach lub istotne obniżenie jakości wody, powietrza 
lub powierzchni ziemi, sprawca  
podlega karze pozbawienia wolności od lat 2 do 12.  
§ 2. Jeżeli następstwem czynu określonego w art. 182 § 1 lub 3, art. 183 § 1 lub 
3 lub w art. 184 § 1 lub 2 jest ciężki uszczerbek na zdrowiu człowieka, sprawca  
podlega karze pozbawienia wolności od lat 2 do 12.  
§ 3. Jeżeli następstwem czynu określonego w art. 182 § 1 lub 3, art. 183 § 1 lub 
3 lub w art. 184 § 1 lub 2 jest śmierć człowieka lub ciężki uszczerbek na zdrowiu wielu 
osób, sprawca  
podlega karze pozbawienia wolności od lat 3 do 20.

***
## Art. 186. {#kk-art-186}

§ 1. Kto wbrew obowiązkowi nie utrzymuje w należytym stanie lub nie 
używa urządzeń zabezpieczających wodę, powietrze lub powierzchnię ziemi przed 
zanieczyszczeniem 
lub 
urządzeń 
zabezpieczających 
przed 
skażeniem 
promieniotwórczym lub promieniowaniem jonizującym,  
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności od 3 
miesięcy do lat 5. 
§ 2. Tej samej karze podlega, kto oddaje lub wbrew obowiązkowi dopuszcza do 
użytkowania obiekt budowlany lub zespół obiektów niemających wymaganych 
prawem urządzeń określonych w § 1. 
§ 3. Jeżeli sprawca czynu określonego w § 1 lub 2 działa nieumyślnie, 
podlega grzywnie albo karze ograniczenia wolności.

***
## Art. 187. {#kk-art-187}

§ 1. Kto niszczy, poważnie uszkadza lub istotnie zmniejsza wartość 
przyrodniczą prawnie chronionego terenu lub obiektu, powodując istotną szkodę, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Jeżeli sprawca działa nieumyślnie, 
podlega grzywnie albo karze ograniczenia wolności. 

 
 
 
s. 84/146 
 
   
 
2025-04-09

***
## Art. 188. {#kk-art-188}

Kto, na terenie objętym ochroną ze względów przyrodniczych lub 
krajobrazowych albo w otulinie takiego terenu, wbrew przepisom, wznosi nowy lub 
powiększa istniejący obiekt budowlany albo prowadzi działalność gospodarczą 
zagrażającą środowisku, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
Art. 188a. Wobec sprawcy przestępstwa określonego w art. 182 § 1 lub 3, art. 
183 § 1, 3, 5a lub 6 lub w art. 184 § 1 lub 2, który dobrowolnie naprawił szkodę w 
całości albo w znacznej części, sąd może zastosować nadzwyczajne złagodzenie kary, 
a nawet odstąpić od jej wymierzenia. 
### Rozdział XXIII Przestępstwa przeciwko wolności

***
## Art. 189. {#kk-art-189}

§ 1. Kto pozbawia człowieka wolności, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Jeżeli pozbawienie wolności trwało dłużej niż 7 dni, sprawca 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 2a. Jeżeli pozbawienie wolności, o którym mowa w § 2, dotyczy osoby 
nieporadnej ze względu na jej wiek, stan psychiczny lub fizyczny, sprawca 
podlega karze pozbawienia wolności od lat 2 do 15. 
§ 3. Jeżeli pozbawienie wolności, o którym mowa w § 1–2a, łączyło się ze 
szczególnym udręczeniem, sprawca 
podlega karze pozbawienia wolności od lat 5 do 25. 
Art. 189a. § 1. Kto dopuszcza się handlu ludźmi, 
podlega karze pozbawienia wolności od lat 3 do 20. 
§ 2. Kto czyni przygotowania do popełnienia przestępstwa określonego w § 1, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 190. {#kk-art-190}

§ 1. Kto grozi innej osobie popełnieniem przestępstwa na jej szkodę 
lub na szkodę osoby dla niej najbliższej, jeżeli groźba wzbudza w osobie, do której 
została skierowana lub której dotyczy, uzasadnioną obawę, że będzie spełniona,  
podlega karze pozbawienia wolności do lat 3. 
§ 2. Ściganie następuje na wniosek pokrzywdzonego. 

 
 
 
s. 85/146 
 
   
 
2025-04-09 
 
Art. 190a. § 1. Kto przez uporczywe nękanie innej osoby lub osoby dla niej 
najbliższej wzbudza u niej uzasadnione okolicznościami poczucie zagrożenia, 
poniżenia lub udręczenia lub istotnie narusza jej prywatność,  
podlega karze pozbawienia wolności od 6 miesięcy do lat 8.  
§ 2. Tej samej karze podlega, kto, podszywając się pod inną osobę, wykorzystuje 
jej wizerunek, inne jej dane osobowe lub inne dane, za pomocą których jest ona 
publicznie identyfikowana, przez co wyrządza jej szkodę majątkową lub osobistą.  
§ 3. Jeżeli następstwem czynu określonego w § 1 lub 2 jest targnięcie się 
pokrzywdzonego na własne życie, sprawca podlega karze pozbawienia wolności od 
lat 2 do 15.  
§ 4. Ściganie przestępstwa określonego w § 1 lub 2 następuje na wniosek 
pokrzywdzonego.

***
## Art. 191. {#kk-art-191}

§ 1. Kto, stosując przemoc wobec osoby lub groźbę bezprawną, zmusza 
ją lub inną osobę do określonego działania, zaniechania lub znoszenia,  
podlega karze pozbawienia wolności do lat 3. 
§ 1a. Tej samej karze podlega, kto w celu zmuszenia innej osoby do określonego 
działania, zaniechania lub znoszenia stosuje przemoc innego rodzaju uporczywie lub 
w sposób istotnie utrudniający innej osobie korzystanie z zajmowanego lokalu 
mieszkalnego. 
§ 2. Jeżeli sprawca działa w sposób określony w § 1 w celu wymuszenia zwrotu 
wierzytelności, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 3. Ściganie przestępstwa określonego w § 1 lub 1a następuje na wniosek 
pokrzywdzonego. 
Art. 191a. § 1. Kto utrwala wizerunek nagiej osoby lub osoby w trakcie 
czynności seksualnej, używając w tym celu wobec niej przemocy, groźby bezprawnej 
lub podstępu, albo wizerunek nagiej osoby lub osoby w trakcie czynności seksualnej 
bez jej zgody rozpowszechnia, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Ściganie następuje na wniosek pokrzywdzonego. 
Art. 191b. § 1. Kto przemocą, groźbą bezprawną lub przez nadużycie stosunku 
zależności lub wykorzystanie krytycznego położenia doprowadza inną osobę do 

 
 
 
s. 86/146 
 
   
 
2025-04-09 
 
zawarcia małżeństwa lub związku, który odpowiada małżeństwu w kręgu 
wyznaniowym lub kulturowym sprawcy,  
podlega karze pozbawienia wolności od 3 miesięcy do 5 lat.  
§ 2. Tej samej karze podlega kto w celu popełnienia przestępstwa określonego w 
§ 1, używając podstępu lub nadużywając stosunku zależności lub wykorzystując 
krytyczne położenie, nakłania inną osobę do opuszczenia terytorium Rzeczypospolitej 
Polskiej.

***
## Art. 192. {#kk-art-192}

§ 1. Kto wykonuje zabieg leczniczy bez zgody pacjenta, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Ściganie następuje na wniosek pokrzywdzonego.

***
## Art. 193. {#kk-art-193}

§ 1. Kto wdziera się do cudzego domu, mieszkania, lokalu, 
pomieszczenia albo ogrodzonego terenu albo wbrew żądaniu osoby uprawnionej 
miejsca takiego nie opuszcza, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 2. Ściganie następuje na wniosek pokrzywdzonego. 
### Rozdział XXIV Przestępstwa przeciwko wolności sumienia i wyznania

***
## Art. 194. {#kk-art-194}

Kto ogranicza człowieka w przysługujących mu prawach ze względu 
na jego przynależność wyznaniową albo bezwyznaniowość, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 195. {#kk-art-195}

§ 1. Kto złośliwie przeszkadza publicznemu wykonywaniu aktu 
religijnego kościoła lub innego związku wyznaniowego o uregulowanej sytuacji 
prawnej, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Tej samej karze podlega, kto złośliwie przeszkadza pogrzebowi, 
uroczystościom lub obrzędom żałobnym. 

 
 
 
s. 87/146 
 
   
 
2025-04-09

***
## Art. 196. {#kk-art-196}

Kto obraża uczucia religijne innych osób, znieważając publicznie 
przedmiot czci religijnej lub miejsce przeznaczone do publicznego wykonywania 
obrzędów religijnych, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
### Rozdział XXV Przestępstwa przeciwko wolności seksualnej i obyczajności

***
## Art. 197. {#kk-art-197}

§ 1. Kto doprowadza inną osobę do obcowania płciowego przemocą, 
groźbą bezprawną, podstępem lub w inny sposób mimo braku jej zgody, 
podlega karze pozbawienia wolności od lat 2 do 15. 
§ 1a. Tej samej karze podlega, kto doprowadza inną osobę do obcowania 
płciowego wykorzystując brak możliwości rozpoznania przez nią znaczenia czynu lub 
pokierowania swoim postępowaniem. 
§ 2. Jeżeli sprawca w sposób określony w § 1 lub 1a doprowadza inną osobę do 
poddania się innej czynności seksualnej albo wykonania takiej czynności, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 3. Jeżeli sprawca dopuszcza się zgwałcenia: 
- 1) wspólnie z inną osobą, 
- 2) (uchylony) 
- 3) wobec wstępnego, zstępnego, przysposobionego, przysposabiającego, brata lub 
siostry, 
- 4) posługując się bronią palną, nożem lub innym podobnie niebezpiecznym 
przedmiotem lub środkiem obezwładniającym albo działając w inny sposób 
bezpośrednio zagrażający życiu,  
- 5) wobec kobiety ciężarnej,  
- 6) utrwalając obraz lub dźwięk z przebiegu czynu, 
podlega karze pozbawienia wolności od lat 3 do 20. 
§ 4. Jeżeli sprawca dopuszcza się zgwałcenia wobec małoletniego poniżej lat 15 
lub sprawca czynu określonego w § 1–3 działa ze szczególnym okrucieństwem lub 
następstwem tego czynu jest ciężki uszczerbek na zdrowiu,  
podlega karze pozbawienia wolności na czas nie krótszy od lat 5 albo karze 
dożywotniego pozbawienia wolności. 

 
 
 
s. 88/146 
 
   
 
2025-04-09 
 
§ 5. Jeżeli następstwem czynu określonego w § 1–4 jest śmierć człowieka, 
sprawca  
podlega karze pozbawienia wolności na czas nie krótszy od lat 8 albo karze 
dożywotniego pozbawienia wolności.

***
## Art. 198. {#kk-art-198}

Kto, wykorzystując bezradność innej osoby lub wynikające 
z upośledzenia umysłowego, choroby psychicznej lub innego zakłócenia czynności 
psychicznych znaczne ograniczenie zdolności do rozpoznania znaczenia czynu lub 
pokierowania swoim postępowaniem, doprowadza ją do obcowania płciowego lub do 
poddania się innej czynności seksualnej albo do wykonania takiej czynności, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8.

***
## Art. 199. {#kk-art-199}

§ 1. Kto, przez nadużycie stosunku zależności lub wykorzystanie 
krytycznego położenia, doprowadza inną osobę do obcowania płciowego lub do 
poddania się innej czynności seksualnej albo do wykonania takiej czynności, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Jeżeli czyn określony w § 1 został popełniony na szkodę małoletniego, 
sprawca podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 3. Karze określonej w § 2 podlega, kto obcuje płciowo z małoletnim lub 
dopuszcza się wobec takiej osoby innej czynności seksualnej albo doprowadza ją do 
poddania się takim czynnościom albo do ich wykonania, nadużywając zaufania lub 
udzielając w zamian korzyści majątkowej lub osobistej albo jej obietnicy.

***
## Art. 200. {#kk-art-200}

§ 1. Kto obcuje płciowo z małoletnim poniżej lat 15 lub dopuszcza się 
wobec takiej osoby innej czynności seksualnej lub doprowadza ją do poddania się 
takim czynnościom albo do ich wykonania, 
podlega karze pozbawienia wolności od lat 2 do 15. 
§ 2. (uchylony) 
§ 3. Kto małoletniemu poniżej lat 15 prezentuje treści pornograficzne lub 
udostępnia mu przedmioty mające taki charakter albo rozpowszechnia treści 
pornograficzne w sposób umożliwiający takiemu małoletniemu zapoznanie się z nimi, 
podlega karze pozbawienia wolności do lat 3. 
§ 4. Karze określonej w § 3 podlega, kto w celu swojego zaspokojenia 
seksualnego lub zaspokojenia seksualnego innej osoby prezentuje małoletniemu 
poniżej lat 15 wykonanie czynności seksualnej. 

 
 
 
s. 89/146 
 
   
 
2025-04-09 
 
§ 5. Karze określonej w § 3 podlega, kto prowadzi reklamę lub promocję 
działalności polegającej na rozpowszechnianiu treści pornograficznych w sposób 
umożliwiający zapoznanie się z nimi małoletniemu poniżej lat 15. 
§ 6. Skazując sprawcę, który popełnił przestępstwo określone w § 1, 3 lub 4 
wobec małoletniego poniżej lat 15, który w chwili czynu pozostawał w stosunku 
zależności od sprawcy, w szczególności pod jego pieczą, lub z wykorzystaniem 
krytycznego położenia małoletniego poniżej lat 15, sąd orzeka karę pozbawienia 
wolności przewidzianą za przypisane sprawcy przestępstwo w wysokości od dolnej 
granicy ustawowego zagrożenia zwiększonego o połowę. 
Art. 200a. § 1. Kto w celu popełnienia przestępstwa określonego w art. 197 § 4 
lub art. 200, jak również produkowania lub utrwalania treści pornograficznych, za 
pośrednictwem systemu teleinformatycznego lub sieci telekomunikacyjnej nawiązuje 
kontakt z małoletnim poniżej lat 15, zmierzając, za pomocą wprowadzenia go w błąd, 
wyzyskania błędu lub niezdolności do należytego pojmowania sytuacji albo przy 
użyciu groźby bezprawnej, do spotkania z nim,  
podlega karze pozbawienia wolności do lat 3. 
§ 2. Kto 
za 
pośrednictwem 
systemu 
teleinformatycznego 
lub 
sieci 
telekomunikacyjnej małoletniemu poniżej lat 15 składa propozycję obcowania 
płciowego, poddania się lub wykonania innej czynności seksualnej lub udziału 
w produkowaniu lub utrwalaniu treści pornograficznych, i zmierza do jej realizacji, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
Art. 200b. Kto publicznie propaguje lub pochwala zachowania o charakterze 
pedofilskim,  
podlega karze pozbawienia wolności do lat 3.

***
## Art. 201. {#kk-art-201}

Kto dopuszcza się obcowania płciowego w stosunku do wstępnego, 
zstępnego, przysposobionego, przysposabiającego, brata lub siostry, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 202. {#kk-art-202}

§ 1. Kto publicznie prezentuje treści pornograficzne w taki sposób, że 
może to narzucić ich odbiór osobie, która tego sobie nie życzy,  
podlega karze pozbawienia wolności do lat 3. 
§ 2. (uchylony) 

 
 
 
s. 90/146 
 
   
 
2025-04-09 
 
§ 3. Kto w celu rozpowszechniania produkuje, utrwala lub sprowadza, 
przechowuje lub posiada albo rozpowszechnia lub prezentuje treści pornograficzne 
z udziałem małoletniego albo treści pornograficzne związane z prezentowaniem 
przemocy lub posługiwaniem się zwierzęciem, podlega karze pozbawienia wolności 
od lat 2 do 15. 
§ 4. Kto utrwala treści pornograficzne z udziałem małoletniego, podlega karze 
pozbawienia wolności od roku do lat 10. 
§ 4a. Kto przechowuje, posiada lub uzyskuje dostęp do treści pornograficznych 
z udziałem małoletniego, podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 4b. Kto produkuje, rozpowszechnia, prezentuje, przechowuje lub posiada treści 
pornograficzne 
przedstawiające 
wytworzony 
albo 
przetworzony 
wizerunek 
małoletniego uczestniczącego w czynności seksualnej  
podlega karze pozbawienia wolności do lat 3. 
§ 4c. Karze określonej w § 4b podlega, kto w celu zaspokojenia seksualnego 
uczestniczy w prezentacji treści pornograficznych z udziałem małoletniego. 
§ 5. Sąd może orzec przepadek narzędzi lub innych przedmiotów, które służyły 
lub były przeznaczone do popełnienia przestępstw określonych w § 1–4b, chociażby 
nie stanowiły własności sprawcy.

***
## Art. 203. {#kk-art-203}

§ 1. Kto, wykorzystując stosunek zależności lub krytyczne położenie, 
doprowadza inną osobę do uprawiania prostytucji,  
podlega karze pozbawienia wolności od roku do lat 10.  
§ 2. Kto, przemocą, groźbą bezprawną lub podstępem doprowadza inną osobę do 
uprawiania prostytucji,  
podlega karze pozbawienia wolności od lat 2 do 15.

***
## Art. 204. {#kk-art-204}

§ 1. Kto, w celu osiągnięcia korzyści majątkowej, nakłania inną osobę 
do uprawiania prostytucji lub jej to ułatwia, podlega karze pozbawienia wolności od 
3 miesięcy do lat 5. 
§ 2. Karze określonej w § 1 podlega, kto czerpie korzyści majątkowe 
z uprawiania prostytucji przez inną osobę. 
§ 3. Jeżeli osoba określona w § 1 lub 2 jest małoletnim, sprawca 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 4. (uchylony) 

 
 
 
s. 91/146 
 
   
 
2025-04-09

***
## Art. 205. {#kk-art-205}

(uchylony) 
### Rozdział XXVI Przestępstwa przeciwko rodzinie i opiece

***
## Art. 206. {#kk-art-206}

Kto zawiera małżeństwo, pomimo że pozostaje w związku 
małżeńskim, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 207. {#kk-art-207}

§ 1. Kto znęca się fizycznie lub psychicznie nad osobą najbliższą lub 
nad inną osobą pozostającą w stałym lub przemijającym stosunku zależności od 
sprawcy, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 1a. Kto znęca się fizycznie lub psychicznie nad osobą nieporadną ze względu 
na jej wiek, stan psychiczny lub fizyczny, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. Jeżeli czyn określony w § 1 lub 1a połączony jest ze stosowaniem 
szczególnego okrucieństwa, sprawca 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 3. Jeżeli następstwem czynu określonego w § 1–2 jest targnięcie się 
pokrzywdzonego na własne życie, sprawca 
podlega karze pozbawienia wolności od lat 2 do 15.

***
## Art. 208. {#kk-art-208}

Kto rozpija małoletniego, dostarczając mu napoju alkoholowego, 
ułatwiając jego spożycie lub nakłaniając go do spożycia takiego napoju, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 209. {#kk-art-209}

§ 1. Kto uchyla się od wykonania obowiązku alimentacyjnego 
określonego co do wysokości orzeczeniem sądowym, ugodą zawartą przed sądem albo 
innym organem albo inną umową, jeżeli łączna wysokość powstałych wskutek tego 
zaległości stanowi równowartość co najmniej 3 świadczeń okresowych albo jeżeli 
opóźnienie zaległego świadczenia innego niż okresowe wynosi co najmniej 
3 miesiące, 

 
 
 
s. 92/146 
 
   
 
2025-04-09 
 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 1a. Jeżeli sprawca czynu określonego w § 1 naraża osobę uprawnioną na 
niemożność zaspokojenia podstawowych potrzeb życiowych, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Ściganie przestępstwa określonego w § 1 lub 1a następuje na wniosek 
pokrzywdzonego, organu pomocy społecznej lub organu podejmującego działania 
wobec dłużnika alimentacyjnego. 
§ 3. Jeżeli pokrzywdzonemu przyznano odpowiednie świadczenia rodzinne albo 
świadczenia pieniężne wypłacane w przypadku bezskuteczności egzekucji alimentów, 
ściganie przestępstwa określonego w § 1 lub 1a odbywa się z urzędu. 
§ 4. Nie podlega karze sprawca przestępstwa określonego w § 1, który nie 
później niż przed upływem 30 dni od dnia pierwszego przesłuchania w charakterze 
podejrzanego uiścił w całości zaległe alimenty. 
§ 5. Sąd odstępuje od wymierzenia kary, jeżeli nie później niż przed upływem 
30 dni od dnia pierwszego przesłuchania w charakterze podejrzanego sprawca 
przestępstwa określonego w § 1a uiścił w całości zaległe alimenty, chyba że wina 
i społeczna szkodliwość czynu przemawiają przeciwko odstąpieniu od wymierzenia 
kary.

***
## Art. 210. {#kk-art-210}

§ 1. Kto wbrew obowiązkowi troszczenia się o małoletniego poniżej 
lat 15 albo o osobę nieporadną ze względu na jej stan psychiczny lub fizyczny osobę 
tę porzuca, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Jeżeli następstwem czynu jest śmierć osoby określonej w § 1, sprawca 
podlega karze pozbawienia wolności od lat 2 do 15.

***
## Art. 211. {#kk-art-211}

Kto, wbrew woli osoby powołanej do opieki lub nadzoru, uprowadza 
lub zatrzymuje małoletniego poniżej lat 15 albo osobę nieporadną ze względu na jej 
stan psychiczny lub fizyczny, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
Art. 211a. § 1. Kto, w celu osiągnięcia korzyści majątkowej, zajmuje się 
organizowaniem adopcji dzieci wbrew przepisom ustawy, 

 
 
 
s. 93/146 
 
   
 
2025-04-09 
 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Tej samej karze podlega, kto, będąc osobą, której przysługuje władza 
rodzicielska nad dzieckiem, wyraża zgodę na adopcję tego dziecka przez inną osobę: 
- 1) w celu osiągnięcia korzyści majątkowej lub osobistej, zatajając ten cel przed 
sądem 
orzekającym 
w 
postępowaniu 
w sprawie 
o przysposobienie, 
a w przypadku wyrażenia przez rodzica zgody na przysposobienie dziecka w 
przyszłości bez wskazania osoby przysposabiającego – przed sądem 
przyjmującym oświadczenie o wyrażeniu tej zgody, 
- 2) z pominięciem postępowania w sprawie o przysposobienie. 
§ 3. Tej samej karze podlega, kto wyraża zgodę na adopcję dziecka przez siebie 
w warunkach, o których mowa w § 2. 
### Rozdział XXVII Przestępstwa przeciwko czci i nietykalności cielesnej

***
## Art. 212. {#kk-art-212}

§ 1. Kto pomawia inną osobę, grupę osób, instytucję, osobę prawną lub 
jednostkę organizacyjną niemającą osobowości prawnej o takie postępowanie lub 
właściwości, które mogą poniżyć ją w opinii publicznej lub narazić na utratę zaufania 
potrzebnego dla danego stanowiska, zawodu lub rodzaju działalności, 
podlega grzywnie albo karze ograniczenia wolności. 
§ 2. Jeżeli sprawca dopuszcza się czynu określonego w § 1 za pomocą środków 
masowego komunikowania, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 3. W razie skazania za przestępstwo określone w § 1 lub 2 sąd może orzec 
nawiązkę na rzecz pokrzywdzonego, Polskiego Czerwonego Krzyża albo na inny cel 
społeczny wskazany przez pokrzywdzonego. 
§ 4. Ściganie przestępstwa określonego w § 1 lub 2 odbywa się z oskarżenia 
prywatnego.

***
## Art. 213. {#kk-art-213}

§ 1. Nie ma przestępstwa określonego w art. 212 § 1, jeżeli zarzut 
uczyniony niepublicznie jest prawdziwy. 
§ 2. Nie popełnia przestępstwa określonego w art. 212 § 1 lub 2, kto publicznie 
podnosi lub rozgłasza prawdziwy zarzut: 
- 1) dotyczący postępowania osoby pełniącej funkcję publiczną lub 

 
 
 
s. 94/146 
 
   
 
2025-04-09 
- 2) służący obronie społecznie uzasadnionego interesu. 
Jeżeli zarzut dotyczy życia prywatnego lub rodzinnego, dowód prawdy może być 
przeprowadzony tylko wtedy, gdy zarzut ma zapobiec niebezpieczeństwu dla życia lub 
zdrowia człowieka albo demoralizacji małoletniego.

***
## Art. 214. {#kk-art-214}

Brak przestępstwa wynikający z przyczyn określonych w art. 213 nie 
wyłącza odpowiedzialności sprawcy za zniewagę ze względu na formę podniesienia 
lub rozgłoszenia zarzutu.

***
## Art. 215. {#kk-art-215}

Na wniosek pokrzywdzonego sąd orzeka podanie wyroku skazującego 
do publicznej wiadomości.

***
## Art. 216. {#kk-art-216}

§ 1. Kto znieważa inną osobę w jej obecności albo choćby pod jej 
nieobecność, lecz publicznie lub w zamiarze, aby zniewaga do osoby tej dotarła, 
podlega grzywnie albo karze ograniczenia wolności. 
§ 2. Kto znieważa inną osobę za pomocą środków masowego komunikowania, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 3. Jeżeli zniewagę wywołało wyzywające zachowanie się pokrzywdzonego 
albo jeżeli pokrzywdzony odpowiedział naruszeniem nietykalności cielesnej lub 
zniewagą wzajemną, sąd może odstąpić od wymierzenia kary. 
§ 4. W razie skazania za przestępstwo określone w § 2 sąd może orzec nawiązkę 
na rzecz pokrzywdzonego, Polskiego Czerwonego Krzyża albo na inny cel społeczny 
wskazany przez pokrzywdzonego. 
§ 5. Ściganie odbywa się z oskarżenia prywatnego.

***
## Art. 217. {#kk-art-217}

§ 1. Kto uderza człowieka lub w inny sposób narusza jego nietykalność 
cielesną, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 2. Jeżeli naruszenie nietykalności wywołało wyzywające zachowanie się 
pokrzywdzonego albo jeżeli pokrzywdzony odpowiedział naruszeniem nietykalności, 
sąd może odstąpić od wymierzenia kary. 
§ 3. Ściganie odbywa się z oskarżenia prywatnego. 

 
 
 
s. 95/146 
 
   
 
2025-04-09 
 
Art. 217a. Kto uderza człowieka lub w inny sposób narusza jego nietykalność 
cielesną w związku z podjętą przez niego interwencją na rzecz ochrony 
bezpieczeństwa ludzi lub ochrony bezpieczeństwa lub porządku publicznego, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
### Rozdział XXVIII Przestępstwa przeciwko prawom osób wykonujących pracę zarobkową

***
## Art. 218. {#kk-art-218}

§ 1. (utracił moc)5) 
§ 1a. Kto, 
wykonując 
czynności 
w sprawach 
z zakresu 
prawa 
pracy 
i ubezpieczeń społecznych, złośliwie lub uporczywie narusza prawa pracownika 
wynikające ze stosunku pracy lub ubezpieczenia społecznego, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Osoba określona w § 1a, odmawiająca ponownego przyjęcia do pracy, 
o której przywróceniu orzekł właściwy organ, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 3. Osoba określona w § 1a, która będąc zobowiązana orzeczeniem sądu do 
wypłaty wynagrodzenia za pracę lub innego świadczenia ze stosunku pracy, 
obowiązku tego nie wykonuje, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 3. 
Art. 218a. Kto, złośliwie lub uporczywie: 
- 1) wbrew zakazowi handlu oraz wykonywania czynności związanych z handlem 
w niedziele i święta, powierza wykonywanie pracy w handlu lub wykonywanie 
czynności związanych z handlem pracownikowi lub zatrudnionemu, 
- 2) wbrew zakazowi handlu oraz wykonywania czynności związanych z handlem po 
godzinie 1400 w sobotę bezpośrednio poprzedzającą pierwszy dzień Wielkiej 
Nocy, powierza wykonywanie pracy w handlu lub wykonywanie czynności 
związanych z handlem pracownikowi lub zatrudnionemu, 
- 5) Z dniem 31 maja 2012 r. na podstawie wyroku Trybunału Konstytucyjnego z dnia 18 listopada 2010 r. 
sygn. akt P 29/09 (Dz. U. poz. 1474). 

 
 
 
s. 96/146 
 
   
 
2025-04-09 
 
podlega grzywnie albo karze ograniczenia wolności.

***
## Art. 219. {#kk-art-219}

Kto narusza przepisy prawa o ubezpieczeniach społecznych, nie 
zgłaszając, nawet za zgodą zainteresowanego, wymaganych danych albo zgłaszając 
nieprawdziwe dane mające wpływ na prawo do świadczeń albo ich wysokość, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 220. {#kk-art-220}

§ 1. Kto, będąc odpowiedzialny za bezpieczeństwo i higienę pracy, nie 
dopełnia wynikającego stąd obowiązku i przez to naraża pracownika na bezpośrednie 
niebezpieczeństwo utraty życia albo ciężkiego uszczerbku na zdrowiu, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Jeżeli sprawca działa nieumyślnie, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 3. Nie podlega karze sprawca, który dobrowolnie uchylił grożące 
niebezpieczeństwo.

***
## Art. 221. {#kk-art-221}

Kto wbrew obowiązkowi nie zawiadamia w terminie właściwego 
organu o wypadku przy pracy lub chorobie zawodowej albo nie sporządza lub nie 
przedstawia wymaganej dokumentacji, 
podlega grzywnie do 180 stawek dziennych albo karze ograniczenia wolności. 
### Rozdział XXIX Przestępstwa przeciwko działalności instytucji państwowych oraz samorządu 
terytorialnego

***
## Art. 222. {#kk-art-222}

§ 1. Kto narusza nietykalność cielesną funkcjonariusza publicznego 
lub osoby do pomocy mu przybranej podczas lub w związku z pełnieniem 
obowiązków służbowych, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 3. 
§ 2. Jeżeli czyn określony w § 1 wywołało niewłaściwe zachowanie się 
funkcjonariusza lub osoby do pomocy mu przybranej, sąd może zastosować 
nadzwyczajne złagodzenie kary, a nawet odstąpić od jej wymierzenia. 

 
 
 
s. 97/146 
 
   
 
2025-04-09

***
## Art. 223. {#kk-art-223}

§ 1. Kto, działając wspólnie i w porozumieniu z inną osobą lub 
używając broni palnej, noża lub innego podobnie niebezpiecznego przedmiotu albo 
środka obezwładniającego, dopuszcza się czynnej napaści na funkcjonariusza 
publicznego lub osobę do pomocy mu przybraną podczas lub w związku z pełnieniem 
obowiązków służbowych, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 2. Jeżeli w wyniku czynnej napaści nastąpił skutek w postaci ciężkiego 
uszczerbku na zdrowiu funkcjonariusza publicznego lub osoby do pomocy mu 
przybranej, sprawca 
podlega karze pozbawienia wolności od lat 2 do 15. 
Art. 223a. § 1. Kto publicznie nawołuje do udostępnienia informacji 
dotyczących życia prywatnego funkcjonariusza organu powołanego do ochrony 
bezpieczeństwa publicznego albo funkcjonariusza Służby Więziennej, których 
udostępnienie może spowodować zagrożenie bezpieczeństwa tego funkcjonariusza lub 
osoby dla niego najbliższej,  
podlega karze pozbawienia wolności do lat 3.  
§ 2. Tej samej karze podlega sprawca czynu określonego w § 1 popełnionego na 
szkodę byłego funkcjonariusza publicznego, o którym mowa w § 1, jeżeli czyn ten 
pozostaje w związku z zadaniami z zakresu ochrony bezpieczeństwa publicznego lub 
zadaniami Służby Więziennej, które pokrzywdzony wykonywał. 
Art. 223b. § 1. Kto bez zgody funkcjonariusza organu powołanego do ochrony 
bezpieczeństwa publicznego albo funkcjonariusza Służby Więziennej, udostępnia 
innej osobie informacje dotyczące jego życia prywatnego, których udostępnienie może 
spowodować zagrożenie bezpieczeństwa tego funkcjonariusza lub osoby dla niego 
najbliższej,  
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.  
§ 2. Tej samej karze podlega sprawca czynu określonego w § 1, popełnionego na 
szkodę byłego funkcjonariusza publicznego, o którym mowa w § 1, jeżeli czyn ten 
pozostaje w związku z zadaniami z zakresu ochrony bezpieczeństwa publicznego lub 
zadaniami Służby Więziennej, które pokrzywdzony wykonywał.  
§ 3. Jeżeli udostępnienie informacji przez sprawcę czynu określonego w § 1 lub 
2 następuje przez ich publiczne rozpowszechnienie, sprawca  

 
 
 
s. 98/146 
 
   
 
2025-04-09 
 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8.

***
## Art. 224. {#kk-art-224}

§ 1. Kto przemocą lub groźbą bezprawną wywiera wpływ na czynności 
urzędowe organu administracji rządowej, innego organu państwowego lub samorządu 
terytorialnego, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Tej samej karze podlega, kto stosuje przemoc lub groźbę bezprawną w celu 
zmuszenia funkcjonariusza publicznego albo osoby do pomocy mu przybranej do 
przedsięwzięcia lub zaniechania prawnej czynności służbowej. 
§ 3. Jeżeli następstwem czynu określonego w § 2 jest skutek określony 
w art. 156 § 1 lub w art. 157 § 1, sprawca 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
Art. 224a. § 1. Kto wiedząc, że zagrożenie nie istnieje, zawiadamia o zdarzeniu, 
które zagraża życiu lub zdrowiu wielu osób lub mieniu w znacznych rozmiarach lub 
stwarza sytuację, mającą wywołać przekonanie o istnieniu takiego zagrożenia, czym 
wywołuje czynność instytucji użyteczności publicznej lub organu ochrony 
bezpieczeństwa, porządku publicznego lub zdrowia mającą na celu uchylenie 
zagrożenia, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. Jeżeli sprawca czynu określonego w § 1 zawiadamia o więcej niż jednym 
zdarzeniu, 
podlega karze pozbawienia wolności od lat 2 do 15. 
Art. 224b. W razie skazania za przestępstwo określone w art. 224a sąd orzeka: 
- 1) nawiązkę na rzecz Skarbu Państwa w wysokości co najmniej 10 000 zł oraz 
- 2) świadczenie pieniężne wymienione w art. 39 pkt 7 w wysokości co najmniej 
10 000 zł.

***
## Art. 225. {#kk-art-225}

§ 1. Kto osobie uprawnionej do przeprowadzania kontroli w zakresie 
ochrony środowiska lub osobie przybranej jej do pomocy udaremnia lub utrudnia 
wykonanie czynności służbowej, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Tej samej karze podlega, kto osobie uprawnionej do kontroli w zakresie 
inspekcji pracy lub osobie przybranej jej do pomocy udaremnia lub utrudnia 
wykonanie czynności służbowej. 

 
 
 
s. 99/146 
 
   
 
2025-04-09 
 
§ 3. (uchylony) 
§ 4. Tej samej karze podlega, kto osobie upoważnionej do przeprowadzania 
czynności w zakresie nadzoru i kontroli w jednostkach organizacyjnych pomocy 
społecznej lub w placówkach zapewniających całodobową opiekę osobom niepełno-
sprawnym, przewlekle chorym lub osobom w podeszłym wieku udaremnia lub 
utrudnia wykonanie czynności służbowych.

***
## Art. 226. {#kk-art-226}

§ 1. Kto znieważa funkcjonariusza publicznego lub osobę do pomocy 
mu przybraną, podczas i w związku z pełnieniem obowiązków służbowych, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 2. Przepis art. 222 § 2 stosuje się odpowiednio. 
§ 3. Kto publicznie znieważa lub poniża konstytucyjny organ Rzeczypospolitej 
Polskiej, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 227. {#kk-art-227}

Kto, podając się za funkcjonariusza publicznego albo wyzyskując 
błędne przeświadczenie o tym innej osoby, wykonuje czynność związaną z jego 
funkcją, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku.

***
## Art. 228. {#kk-art-228}

§ 1. Kto, w związku z pełnieniem funkcji publicznej, przyjmuje 
korzyść majątkową lub osobistą albo jej obietnicę, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. W wypadku mniejszej wagi, sprawca 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 3. Kto, w związku z pełnieniem funkcji publicznej, przyjmuje korzyść 
majątkową lub osobistą albo jej obietnicę za zachowanie stanowiące naruszenie 
przepisów prawa, 
podlega karze pozbawienia wolności od roku do lat 10. 

 
 
 
s. 100/146 
 
   
 
2025-04-09 
 
§ 4. Karze określonej w § 3 podlega także ten, kto, w związku z pełnieniem 
funkcji publicznej, uzależnia wykonanie czynności służbowej od otrzymania korzyści 
majątkowej lub osobistej albo jej obietnicy lub takiej korzyści żąda. 
§ 5. Kto, w związku z pełnieniem funkcji publicznej, przyjmuje korzyść 
majątkową znacznej wartości albo jej obietnicę, 
podlega karze pozbawienia wolności od lat 2 do 15. 
§ 5a. Kto, w związku z pełnieniem funkcji publicznej, przyjmuje korzyść 
majątkową wielkiej wartości albo jej obietnicę,  
podlega karze pozbawienia wolności od lat 3 do 20. 
§ 6. Karom określonym w § 1–5a podlega odpowiednio także ten, kto, w związku 
z 
pełnieniem 
funkcji 
publicznej 
w państwie 
obcym 
lub 
w 
organizacji 
międzynarodowej, przyjmuje korzyść majątkową lub osobistą albo jej obietnicę lub 
takiej korzyści żąda, albo uzależnia wykonanie czynności służbowej od jej 
otrzymania.

***
## Art. 229. {#kk-art-229}

§ 1. Kto udziela albo obiecuje udzielić korzyści majątkowej lub 
osobistej osobie pełniącej funkcję publiczną w związku z pełnieniem tej funkcji, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. W wypadku mniejszej wagi, sprawca 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 3. Jeżeli sprawca czynu określonego w § 1 działa, aby skłonić osobę pełniącą 
funkcję publiczną do naruszenia przepisów prawa lub udziela albo obiecuje udzielić 
takiej osobie korzyści majątkowej lub osobistej za naruszenie przepisów prawa, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 4. Kto osobie pełniącej funkcję publiczną, w związku z pełnieniem tej funkcji, 
udziela albo obiecuje udzielić korzyści majątkowej znacznej wartości, 
podlega karze pozbawienia wolności od lat 2 do 15. 
§ 4a. Kto osobie pełniącej funkcję publiczną, w związku z pełnieniem tej funkcji, 
udziela albo obiecuje udzielić korzyści majątkowej wielkiej wartości,  
podlega karze pozbawienia wolności od lat 3 do 20. 
§ 5. Karom określonym w § 1–4a podlega odpowiednio także ten, kto udziela 
albo obiecuje udzielić korzyści majątkowej lub osobistej osobie pełniącej funkcję 

 
 
 
s. 101/146 
 
   
 
2025-04-09 
 
publiczną w państwie obcym lub w organizacji międzynarodowej, w związku z 
pełnieniem tej funkcji. 
§ 6. Nie podlega karze sprawca przestępstwa określonego w § 1–5, jeżeli korzyść 
majątkowa lub osobista albo ich obietnica zostały przyjęte przez osobę pełniącą 
funkcję publiczną, a sprawca zawiadomił o tym fakcie organ powołany do ścigania 
przestępstw i ujawnił wszystkie istotne okoliczności przestępstwa, zanim organ ten 
o nim się dowiedział.

***
## Art. 230. {#kk-art-230}

§ 1. Kto, w zamian za korzyść majątkową lub osobistą albo jej 
obietnicę, podejmuje się pośrednictwa w załatwieniu sprawy, powołując się na 
wpływy, wywołując u innej osoby przekonanie o istnieniu wpływów, wykorzystując 
takie przekonanie lub utwierdzając ją w przekonaniu o istnieniu wpływów w:  
- 1) instytucji państwowej lub samorządowej, 
- 2) organizacji krajowej lub międzynarodowej,  
- 3) krajowej lub zagranicznej jednostce organizacyjnej dysponującej środkami 
publicznymi,  
- 4) przedsiębiorstwie państwowym,  
- 5) spółce handlowej z udziałem Skarbu Państwa, samorządu terytorialnego lub 
państwowej osoby prawnej,  
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. W wypadku mniejszej wagi, sprawca 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
Art. 230a. § 1. Kto udziela albo obiecuje udzielić korzyści majątkowej lub 
osobistej w zamian za pośrednictwo w załatwieniu sprawy w podmiocie wskazanym 
w art. 230 § 1, polegające na bezprawnym wywarciu wpływu na decyzję, działanie lub 
zaniechanie osoby pełniącej funkcję publiczną, w związku z pełnieniem tej funkcji,  
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. W wypadku mniejszej wagi, sprawca 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 3. Nie podlega karze sprawca przestępstwa określonego w § 1 albo 
w § 2, jeżeli korzyść majątkowa lub osobista  

 
 
 
s. 102/146 
 
   
 
2025-04-09 
 
albo ich obietnica zostały przyjęte, a sprawca zawiadomił o tym fakcie organ 
powołany do ścigania przestępstw i ujawnił wszystkie istotne okoliczności 
przestępstwa, zanim organ ten o nim się dowiedział.

***
## Art. 231. {#kk-art-231}

§ 1. Funkcjonariusz publiczny, który, przekraczając swoje uprawnienia 
lub nie dopełniając obowiązków, działa na szkodę interesu publicznego lub 
prywatnego, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Jeżeli sprawca dopuszcza się czynu określonego w § 1 w celu osiągnięcia 
korzyści majątkowej lub osobistej, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 3. Jeżeli sprawca czynu określonego w § 1 działa nieumyślnie i wyrządza 
istotną szkodę, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 4. Przepisu § 2 nie stosuje się, jeżeli czyn wyczerpuje znamiona czynu 
zabronionego określonego w art. 228. 
Art. 231a. Z ochrony prawnej przewidzianej dla funkcjonariuszy publicznych 
podczas lub w związku z pełnieniem obowiązków służbowych funkcjonariusz 
publiczny korzysta również wtedy, jeżeli bezprawny zamach na jego osobę został 
podjęty z powodu wykonywanego przez niego zawodu lub zajmowanego stanowiska. 
Art. 231b. § 1. Osoba, która w obronie koniecznej odpiera zamach na 
jakiekolwiek cudze dobro chronione prawem, chroniąc bezpieczeństwo lub porządek 
publiczny, korzysta z ochrony prawnej przewidzianej dla funkcjonariuszy 
publicznych. 
§ 2. Przepisu § 1 nie stosuje się, jeżeli czyn sprawcy zamachu skierowany 
przeciwko osobie odpierającej zamach godzi wyłącznie w cześć lub godność tej 
osoby. 
### Rozdział XXX Przestępstwa przeciwko wymiarowi sprawiedliwości

***
## Art. 232. {#kk-art-232}

§ 1. Kto przemocą lub groźbą bezprawną wywiera wpływ na czynności 
urzędowe sądu, 

 
 
 
s. 103/146 
 
   
 
2025-04-09 
 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Tej samej karze podlega sprawca przestępstwa określonego w § 1, 
popełnionego na szkodę międzynarodowego trybunału karnego lub jego organu 
działającego na podstawie umowy międzynarodowej, której Rzeczpospolita Polska 
jest stroną, albo powołanego przez organizację międzynarodową ukonstytuowaną 
umową ratyfikowaną przez Rzeczpospolitą Polską.

***
## Art. 233. {#kk-art-233}

§ 1. Kto, składając zeznanie mające służyć za dowód w postępowaniu 
sądowym lub w innym postępowaniu prowadzonym na podstawie ustawy, zeznaje 
nieprawdę lub zataja prawdę, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 1a. Jeżeli sprawca czynu określonego w § 1 zeznaje nieprawdę lub zataja 
prawdę z obawy przed odpowiedzialnością karną grożącą jemu samemu lub jego 
najbliższym, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Warunkiem odpowiedzialności jest, aby przyjmujący zeznanie, działając 
w zakresie swoich uprawnień, uprzedził zeznającego o odpowiedzialności karnej za 
fałszywe zeznanie lub odebrał od niego przyrzeczenie. 
§ 3. Nie podlega karze za czyn określony w § 1a, kto składa fałszywe zeznanie, 
nie wiedząc o prawie odmowy zeznania lub odpowiedzi na pytania. 
§ 4. Kto, jako biegły, rzeczoznawca lub tłumacz, przedstawia fałszywą opinię, 
ekspertyzę lub tłumaczenie mające służyć za dowód w postępowaniu określonym 
w § 1, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 4a. Jeżeli sprawca czynu określonego w § 4 działa nieumyślnie, narażając na 
istotną szkodę interes publiczny, 
podlega karze pozbawienia wolności do lat 3. 
§ 5. Sąd może zastosować nadzwyczajne złagodzenie kary, a nawet odstąpić od 
jej wymierzenia, jeżeli: 
- 1) fałszywe zeznanie, opinia, ekspertyza lub tłumaczenie dotyczy okoliczności 
niemogących mieć wpływu na rozstrzygnięcie sprawy, 
- 2) sprawca dobrowolnie sprostuje fałszywe zeznanie, opinię, ekspertyzę lub 
tłumaczenie, zanim nastąpi, chociażby nieprawomocne, rozstrzygnięcie sprawy. 

 
 
 
s. 104/146 
 
   
 
2025-04-09 
 
§ 6. Przepisy § 1–3 oraz 5 stosuje się odpowiednio do osoby, która składa 
fałszywe oświadczenie, jeżeli przepis ustawy przewiduje możliwość odebrania 
oświadczenia pod rygorem odpowiedzialności karnej.

***
## Art. 234. {#kk-art-234}

Kto, przed organem powołanym do ścigania lub orzekania w sprawach 
o przestępstwo, w tym i przestępstwo skarbowe, wykroczenie, wykroczenie skarbowe 
lub przewinienie dyscyplinarne, fałszywie oskarża inną osobę o popełnienie tych 
czynów zabronionych lub przewinienia dyscyplinarnego, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 235. {#kk-art-235}

Kto, przez tworzenie fałszywych dowodów lub inne podstępne zabiegi, 
kieruje przeciwko określonej osobie ściganie o przestępstwo, w tym i przestępstwo 
skarbowe, wykroczenie, wykroczenie skarbowe lub przewinienie dyscyplinarne albo 
w toku postępowania zabiegi takie przedsiębierze, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 236. {#kk-art-236}

§ 1. Kto zataja dowody niewinności osoby podejrzanej o popełnienie 
przestępstwa, w tym i przestępstwa skarbowego, wykroczenia, wykroczenia 
skarbowego lub przewinienia dyscyplinarnego, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Nie podlega karze, kto zataja dowody niewinności z obawy przed 
odpowiedzialnością karną grożącą jemu samemu lub jego najbliższym.

***
## Art. 237. {#kk-art-237}

Przepis art. 233 § 5 pkt 2 stosuje się odpowiednio do przestępstw 
określonych w art. 234, art. 235 oraz w art. 236 § 1.

***
## Art. 238. {#kk-art-238}

Kto zawiadamia o przestępstwie, lub o przestępstwie skarbowym 
organ powołany do ścigania wiedząc, że przestępstwa nie popełniono, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 239. {#kk-art-239}

§ 1. Kto utrudnia lub udaremnia postępowanie karne, pomagając 
sprawcy przestępstwa, w tym i przestępstwa skarbowego uniknąć odpowiedzialności 
karnej, w szczególności kto sprawcę ukrywa, tworzy fałszywe dowody, zaciera ślady 
przestępstwa, w tym i przestępstwa skarbowego, albo odbywa za skazanego karę,  
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 

 
 
 
s. 105/146 
 
   
 
2025-04-09 
 
§ 2. Nie podlega karze sprawca, który ukrywa osobę najbliższą. 
§ 3. Sąd może zastosować nadzwyczajne złagodzenie kary, a nawet odstąpić od 
jej wymierzenia, jeżeli sprawca udzielił pomocy osobie najbliższej albo działał 
z obawy przed odpowiedzialnością karną grożącą jemu samemu lub jego najbliższym.

***
## Art. 240. {#kk-art-240}

§ 1. Kto, mając wiarygodną wiadomość o karalnym przygotowaniu 
albo usiłowaniu lub dokonaniu czynu zabronionego określonego w art. 118, art. 118a, 
art. 120–124, art. 127, art. 128, art. 130, art. 134, art. 140, art. 148, art. 148a, art. 156, 
art. 163, art. 166, art. 189, art. 197 § 3–5, art. 198, art. 200, art. 252 lub przestępstwa 
o charakterze terrorystycznym, nie zawiadamia niezwłocznie organu powołanego do 
ścigania przestępstw,  
podlega karze pozbawienia wolności do lat 3. 
§ 2. Nie popełnia przestępstwa określonego w § 1, kto zaniechał zawiadomienia, 
mając dostateczną podstawę do przypuszczenia, że wymieniony w § 1 organ wie 
o przygotowywanym, usiłowanym lub dokonanym czynie zabronionym; nie popełnia 
przestępstwa również ten, kto zapobiegł popełnieniu przygotowywanego lub 
usiłowanego czynu zabronionego określonego w § 1. 
§ 2a. Nie podlega karze pokrzywdzony czynem wymienionym w § 1, który 
zaniechał zawiadomienia o tym czynie. 
§ 3. Nie podlega karze, kto zaniechał zawiadomienia z obawy przed 
odpowiedzialnością karną grożącą jemu samemu lub jego najbliższym.

***
## Art. 241. {#kk-art-241}

§ 1. Kto bez zezwolenia rozpowszechnia publicznie wiadomości 
z postępowania przygotowawczego, zanim zostały ujawnione w postępowaniu 
sądowym, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Tej samej karze podlega, kto rozpowszechnia publicznie wiadomości 
z rozprawy sądowej prowadzonej z wyłączeniem jawności. 
§ 3. Karze określonej w § 1 podlega, kto bez zezwolenia rozpowszechnia 
publicznie wiadomości z postępowania prowadzonego na podstawie przepisów o 
postępowaniu w sprawach nieletnich.

***
## Art. 242. {#kk-art-242}

§ 1. Kto uwalnia się sam, będąc pozbawionym wolności na podstawie 
orzeczenia sądu lub prawnego nakazu wydanego przez inny organ państwowy, 

 
 
 
s. 106/146 
 
   
 
2025-04-09 
 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 1a. Tej samej karze podlega, kto, będąc pozbawionym wolności na podstawie 
orzeczenia sądu lub prawnego nakazu wydanego przez inny organ państwowy oraz 
przebywając bez dozoru poza zakładem karnym lub aresztem śledczym w związku z 
wykonywaniem pracy, samowolnie opuszcza wyznaczone miejsce wykonywania 
pracy lub samowolnie poza nim pozostaje. 
§ 2. Kto, korzystając z zezwolenia na czasowe opuszczenie zakładu karnego lub 
aresztu śledczego bez dozoru albo zakładu psychiatrycznego dysponującego 
warunkami podstawowego zabezpieczenia, bez usprawiedliwionej przyczyny nie 
powróci najpóźniej w ciągu 3 dni po upływie wyznaczonego terminu, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 3. Karze określonej w § 2 podlega, kto, korzystając z przerwy w odbywaniu 
kary pozbawienia wolności, bez usprawiedliwionej przyczyny nie powróci do zakładu 
karnego najpóźniej w ciągu 3 dni po upływie wyznaczonego terminu. 
§ 4. Jeżeli sprawca czynu określonego w § 1 działa w porozumieniu z innymi 
osobami, używa przemocy lub grozi jej użyciem albo uszkadza miejsce zamknięcia, 
podlega karze pozbawienia wolności do lat 3.

***
## Art. 243. {#kk-art-243}

Kto osobę pozbawioną wolności na podstawie orzeczenia sądu lub 
prawnego nakazu wydanego przez inny organ państwowy uwalnia lub ułatwia jej 
ucieczkę, 
podlega karze pozbawienia wolności do lat 3.

***
## Art. 244. {#kk-art-244}

Kto nie stosuje się do orzeczonego przez sąd zakazu zajmowania 
stanowiska, wykonywania zawodu, prowadzenia działalności, zajmowania stanowiska 
lub wykonywania zawodu lub pracy w organach i instytucjach państwowych 
i samorządu terytorialnego, a także w spółkach prawa handlowego, w których Skarb 
Państwa lub jednostka samorządu terytorialnego posiadają bezpośrednio lub pośrednio 
przez inne podmioty co najmniej 10 % akcji lub udziałów, wykonywania czynności 
wymagających zezwolenia, które są związane z wykorzystywaniem zwierząt lub 
oddziaływaniem na nie, prowadzenia pojazdów, wstępu do ośrodków gier 
i uczestnictwa w grach hazardowych, wstępu na imprezę masową, przebywania 

 
 
 
s. 107/146 
 
   
 
2025-04-09 
 
w określonych środowiskach lub miejscach, nakazu okresowego opuszczenia lokalu 
zajmowanego wspólnie z pokrzywdzonym, zakazu kontaktowania się z określonymi 
osobami, zakazu zbliżania się do określonych osób lub zakazu opuszczania 
określonego miejsca pobytu bez zgody sądu, zakazu posiadania wszelkich zwierząt 
albo określonej kategorii zwierząt albo nie wykonuje zarządzenia sądu o ogłoszeniu 
orzeczenia w sposób w nim przewidziany, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
Art. 244a. § 1. Kto nie stosuje się do orzeczonego w związku z zakazem wstępu 
na imprezę masową obowiązku przebywania w miejscu stałego pobytu lub obowiązku 
stawiennictwa w jednostce organizacyjnej Policji lub w miejscu określonym przez 
właściwego, ze względu na miejsce zamieszkania osoby skazanej albo ukaranej, 
komendanta powiatowego, rejonowego lub miejskiego Policji, w czasie trwania 
imprezy masowej, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Tej samej karze podlega, kto udaremnia lub utrudnia kontrolowanie, 
w systemie dozoru elektronicznego, orzeczonego wobec niego obowiązku, o którym 
mowa w § 1. 
Art. 244b. § 1. Kto nie stosuje się do określonych w ustawie obowiązków 
związanych z orzeczonym wobec niego środkiem zabezpieczającym, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Tej samej karze podlega, kto bezprawnie udaremnia wykonywanie 
orzeczonego wobec innej osoby środka zabezpieczającego w postaci elektronicznej 
kontroli miejsca pobytu. 
Art. 244c. § 1. Kto uchyla się od wykonania orzeczonego przez sąd na rzecz 
pokrzywdzonego lub osoby dla niego najbliższej, za przestępstwo ścigane z oskarżenia 
publicznego, środka kompensacyjnego w postaci obowiązku naprawienia szkody lub 
zadośćuczynienia za doznaną krzywdę albo nawiązki,  
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.  

 
 
 
s. 108/146 
 
   
 
2025-04-09 
 
§ 2. Nie podlega karze sprawca przestępstwa określonego w § 1, który wykonał 
w całości orzeczony wobec niego środek kompensacyjny nie później niż przed 
upływem 30 dni od dnia pierwszego przesłuchania w charakterze podejrzanego.  
§ 3. Ściganie przestępstwa określonego w § 1 następuje na wniosek 
pokrzywdzonego.

***
## Art. 245. {#kk-art-245}

Kto używa przemocy lub groźby bezprawnej w celu wywarcia wpływu 
na świadka, biegłego, tłumacza, oskarżyciela albo oskarżonego lub w związku z tym 
narusza jego nietykalność cielesną, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 246. {#kk-art-246}

Funkcjonariusz publiczny lub ten, który działając na jego polecenie 
w celu uzyskania określonych zeznań, wyjaśnień, informacji lub oświadczenia stosuje 
przemoc, groźbę bezprawną lub w inny sposób znęca się fizycznie lub psychicznie nad 
inną osobą, 
podlega karze pozbawienia wolności od roku do lat 10.

***
## Art. 247. {#kk-art-247}

§ 1. Kto znęca się fizycznie lub psychicznie nad osobą prawnie 
pozbawioną wolności, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Jeżeli sprawca działa ze szczególnym okrucieństwem, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 3. Funkcjonariusz publiczny, który wbrew obowiązkowi dopuszcza do 
popełnienia czynu określonego w § 1 lub 2, 
podlega karze określonej w tych przepisach. 
Art. 247a. Przepisy 
art. 233–237 
oraz 
art. 239, 

i 246 stosuje 
się 
odpowiednio 
do 
czynu 
popełnionego 
w związku 
z postępowaniem 
przed 
międzynarodowym trybunałem karnym lub jego organem działającym na podstawie 
umowy między- 
narodowej, której Rzeczpospolita Polska jest stroną, albo powołanym przez 
organizację 
międzynarodową 
ukonstytuowaną 
umową 
ratyfikowaną 
przez 
Rzeczpospolitą Polską. 

 
 
 
s. 109/146 
 
   
 
2025-04-09 
### Rozdział XXXI Przestępstwa przeciwko wyborom i referendum

***
## Art. 248. {#kk-art-248}

Kto w związku z wyborami do Sejmu, do Senatu, wyborem Prezydenta 
Rzeczypospolitej Polskiej, wyborami do Parlamentu Europejskiego, wyborami 
organów samorządu terytorialnego lub referendum: 
- 1) sporządza listę kandydujących lub głosujących, z pominięciem uprawnionych 
lub wpisaniem nieuprawnionych, 
- 2) używa podstępu celem nieprawidłowego sporządzenia listy kandydujących lub 
głosujących, 
protokołów 
lub 
innych 
dokumentów 
wyborczych 
albo 
referendalnych, 
- 3) niszczy, uszkadza, ukrywa, przerabia lub podrabia protokoły lub inne dokumenty 
wyborcze albo referendalne, 
- 4) dopuszcza się nadużycia lub dopuszcza do nadużycia przy przyjmowaniu 
lub obliczaniu głosów, 
- 5) odstępuje innej osobie przed zakończeniem głosowania niewykorzystaną kartę 
do głosowania lub pozyskuje od innej osoby w celu wykorzystania w głosowaniu 
niewykorzystaną kartę do głosowania, 
- 6) dopuszcza 
się 
nadużycia 
w sporządzaniu 
list 
z podpisami 
obywateli 
zgłaszających kandydatów w wyborach lub inicjujących referendum 
– podlega karze pozbawienia wolności do lat 3.

***
## Art. 249. {#kk-art-249}

Kto przemocą, groźbą bezprawną lub podstępem przeszkadza: 
- 1) odbyciu zgromadzenia poprzedzającego głosowanie, 
- 2) swobodnemu wykonywaniu prawa do kandydowania lub głosowania, 
- 3) głosowaniu lub obliczaniu głosów, 
- 4) sporządzaniu 
protokołów 
lub 
innych 
dokumentów 
wyborczych 
albo 
referendalnych, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 250. {#kk-art-250}

Kto, przemocą, groźbą bezprawną lub przez nadużycie stosunku 
zależności, wywiera wpływ na sposób głosowania osoby uprawnionej albo zmusza ją 
do głosowania lub powstrzymuje od głosowania, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 

 
 
 
s. 110/146 
 
   
 
2025-04-09 
 
Art. 250a. § 1. Kto, będąc uprawniony do głosowania, przyjmuje korzyść 
majątkową lub osobistą albo takiej korzyści żąda za głosowanie w określony sposób, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Tej samej karze podlega, kto udziela korzyści majątkowej lub osobistej 
osobie uprawnionej do głosowania, aby skłonić ją do głosowania w określony sposób 
lub za głosowanie w określony sposób. 
§ 3. W wypadku mniejszej wagi, sprawca czynu określonego w § 1 lub 2 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 4. Jeżeli sprawca przestępstwa określonego w § 1 albo w § 3 w związku 
z § 1 zawiadomił organ powołany do ścigania o fakcie przestępstwa i okolicznościach 
jego popełnienia, zanim organ ten o nich się dowiedział, sąd stosuje nadzwyczajne 
złagodzenie kary, a nawet może odstąpić od jej wymierzenia.

***
## Art. 251. {#kk-art-251}

Kto, naruszając przepisy o tajności głosowania, wbrew woli 
głosującego zapoznaje się z treścią jego głosu, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
### Rozdział XXXII Przestępstwa przeciwko porządkowi publicznemu

***
## Art. 252. {#kk-art-252}

§ 1. Kto bierze lub przetrzymuje zakładnika w celu zmuszenia organu 
państwowego lub samorządowego, instytucji, organizacji, osoby fizycznej lub prawnej 
albo grupy osób do określonego zachowania się, 
podlega karze pozbawienia wolności od lat 3 do 20. 
§ 2. Jeżeli czyn określony w § 1 łączył się ze szczególnym udręczeniem 
zakładnika, sprawca 
podlega karze pozbawienia wolności od lat 5 do 25. 
§ 3. Kto czyni przygotowania do przestępstwa określonego w § 1, 
podlega karze pozbawienia wolności do lat 3. 
§ 4. Nie podlega karze za przestępstwo określone w § 1, kto odstąpił od zamiaru 
wymuszenia i zwolnił zakładnika. 
§ 5. Sąd może zastosować nadzwyczajne złagodzenie kary wobec sprawcy czynu 
określonego w § 2, który odstąpił od zamiaru wymuszenia i zwolnił zakładnika, 

 
 
 
s. 111/146 
 
   
 
2025-04-09 
 
a stosuje nadzwyczajne złagodzenie kary, jeżeli odstąpienie od zamiaru wymuszenia 
i zwolnienie zakładnika nastąpiło dobrowolnie.

***
## Art. 253. {#kk-art-253}

(uchylony)

***
## Art. 254. {#kk-art-254}

§ 1. Kto bierze czynny udział w zbiegowisku wiedząc, że jego 
uczestnicy wspólnymi siłami dopuszczają się gwałtownego zamachu na osobę lub 
mienie, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Jeżeli następstwem gwałtownego zamachu jest śmierć człowieka lub ciężki 
uszczerbek na zdrowiu, uczestnik zbiegowiska określony w § 1, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
Art. 254a. Kto zabiera, niszczy, uszkadza lub czyni niezdatnym do użytku 
element wchodzący w skład sieci wodociągowej, kanalizacyjnej, ciepłowniczej, 
elektroenergetycznej, gazowej, telekomunikacyjnej albo linii kolejowej, tramwajowej, 
trolejbusowej lub linii metra, powodując przez to zakłócenie działania całości lub 
części sieci albo linii, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8.

***
## Art. 255. {#kk-art-255}

§ 1. Kto publicznie nawołuje do popełnienia występku lub 
przestępstwa skarbowego, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Kto publicznie nawołuje do popełnienia zbrodni, 
podlega karze pozbawienia wolności do lat 3. 
§ 3. Kto publicznie pochwala popełnienie przestępstwa, 
podlega grzywnie do 180 stawek dziennych, karze ograniczenia wolności albo 
pozbawienia wolności do roku. 
Art. 255a. § 1. Kto rozpowszechnia lub publicznie prezentuje treści mogące 
ułatwić popełnienie przestępstwa o charakterze terrorystycznym w zamiarze, aby 
przestępstwo takie zostało popełnione, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Tej samej karze podlega, kto w celu popełnienia przestępstwa o charakterze 
terrorystycznym uczestniczy w szkoleniu mogącym umożliwić popełnienie takiego 
przestępstwa lub samodzielnie zapoznaje się z treściami, o których mowa w § 1. 

 
 
 
s. 112/146 
 
   
 
2025-04-09

***
## Art. 256. {#kk-art-256}

§ 1. Kto 
publicznie 
propaguje 
nazistowski, 
komunistyczny, 
faszystowski lub inny totalitarny ustrój państwa lub nawołuje do nienawiści na tle 
różnic narodowościowych, etnicznych, rasowych, wyznaniowych albo ze względu na 
bezwyznaniowość,  
podlega karze pozbawienia wolności do lat 3. 
§ 1a. Tej samej karze podlega, kto publicznie propaguje ideologię nazistowską, 
komunistyczną, faszystowską lub ideologię nawołującą do użycia przemocy w celu 
wpływania na życie polityczne lub społeczne. 
§ 2. Karze określonej w § 1 podlega, kto w celu rozpowszechniania produkuje, 
utrwala lub sprowadza, nabywa, zbywa, oferuje, przechowuje, posiada, prezentuje, 
przewozi lub przesyła druk, nagranie lub inny przedmiot, zawierające treść określoną 
w § 1 lub 1a albo będące nośnikiem symboliki nazistowskiej, komunistycznej, 
faszystowskiej lub innej totalitarnej, użytej w sposób służący propagowaniu treści 
określonej w § 1 lub 1a. 
§ 3. Nie popełnia przestępstwa sprawca czynu zabronionego określonego w § 2, 
jeżeli dopuścił się tego czynu w ramach działalności artystycznej, edukacyjnej, 
kolekcjonerskiej lub naukowej. 
§ 4. W razie skazania za przestępstwo określone w § 2 sąd orzeka przepadek 
przedmiotów, o których mowa w § 2, chociażby nie stanowiły własności sprawcy.

***
## Art. 257. {#kk-art-257}

Kto publicznie znieważa grupę ludności albo poszczególną osobę 
z powodu jej przynależności narodowej, etnicznej, rasowej, wyznaniowej albo 
z powodu jej bezwyznaniowości lub z takich powodów narusza nietykalność cielesną 
innej osoby, 
podlega karze pozbawienia wolności do lat 3.

***
## Art. 258. {#kk-art-258}

§ 1. Kto bierze udział w zorganizowanej grupie albo związku 
mających na celu popełnienie przestępstwa lub przestępstwa skarbowego, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. Jeżeli grupa albo związek określone w § 1 mają charakter zbrojny albo mają 
na celu popełnienie przestępstwa o charakterze terrorystycznym, sprawca 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 3. Kto grupę albo związek określone w § 1, w tym mające charakter zbrojny, 
zakłada lub taką grupą albo związkiem kieruje,  

 
 
 
s. 113/146 
 
   
 
2025-04-09 
 
podlega karze pozbawienia wolności od lat 2 do 15. 
§ 4. Kto grupę albo związek mające na celu popełnienie przestępstwa 
o charakterze terrorystycznym zakłada lub taką grupą lub związkiem kieruje, 
podlega karze pozbawienia wolności od lat 3 do 20.

***
## Art. 259. {#kk-art-259}

Nie podlega karze za przestępstwo określone w art. 258, kto 
dobrowolnie odstąpił od udziału w grupie albo związku i ujawnił przed organem 
powołanym do ścigania przestępstw wszystkie istotne okoliczności popełnionego 
czynu lub zapobiegł popełnieniu zamierzonego przestępstwa, w tym i przestępstwa 
skarbowego. 
Art. 259a. Kto przekracza granicę Rzeczypospolitej Polskiej w celu popełnienia 
przestępstwa o charakterze terrorystycznym lub przestępstwa określonego w art. 255a 
lub art. 258 § 2 lub 4, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
Art. 259b. Na wniosek prokuratora sąd stosuje nadzwyczajne złagodzenie kary, 
a nawet może warunkowo zawiesić jej wykonanie w stosunku do sprawcy 
przestępstwa określonego w art. 259a, który dobrowolnie odstąpił od: 
- 1) popełnienia przestępstwa o charakterze terrorystycznym lub przestępstwa 
określonego w art. 255a lub art. 258 § 2 lub 4 i ujawnił przed organem 
powołanym do ścigania przestępstw wszystkie istotne okoliczności popełnienia 
czynu lub zapobiegł popełnieniu zamierzonego przestępstwa; 
- 2) pomocnictwa innym 
osobom w popełnieniu przestępstwa określonego 
w art. 259a i ujawnił przed organem powołanym do ścigania przestępstw 
wszystkie istotne okoliczności popełnienia czynu, w szczególności informacje o 
osobach, które popełniły przestępstwa określone w art. 259a.

***
## Art. 260. {#kk-art-260}

Kto przemocą lub groźbą bezprawną udaremnia przeprowadzenie 
odbywanego zgodnie z prawem zebrania, zgromadzenia lub pochodu albo takie 
zebranie, zgromadzenie lub pochód rozprasza, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 261. {#kk-art-261}

Kto znieważa pomnik lub inne miejsce publiczne urządzone w celu 
upamiętnienia zdarzenia historycznego lub uczczenia osoby, 
podlega grzywnie albo karze ograniczenia wolności. 

 
 
 
s. 114/146 
 
   
 
2025-04-09

***
## Art. 262. {#kk-art-262}

§ 1. Kto znieważa zwłoki, prochy ludzkie lub miejsce spoczynku 
zmarłego, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Kto ograbia zwłoki, grób lub inne miejsce spoczynku zmarłego, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8.

***
## Art. 263. {#kk-art-263}

§ 1. Kto bez wymaganego zezwolenia wyrabia broń palną albo 
amunicję lub nią handluje, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 2. Kto bez wymaganego zezwolenia posiada broń palną lub amunicję, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 3. Kto, mając zezwolenie na posiadanie broni palnej lub amunicji, udostępnia 
lub przekazuje ją osobie nieuprawnionej, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 4. Kto nieumyślnie powoduje utratę broni palnej lub amunicji, która zgodnie 
z prawem pozostaje w jego dyspozycji, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku.

***
## Art. 264. {#kk-art-264}

§ 1. (uchylony) 
§ 2. Kto wbrew przepisom przekracza granicę Rzeczypospolitej Polskiej, 
używając przemocy, groźby, podstępu lub we współdziałaniu z innymi osobami, 
podlega karze pozbawienia wolności do lat 3. 
§ 3. Kto organizuje innym osobom przekraczanie wbrew przepisom granicy 
Rzeczypospolitej Polskiej, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 4. Karze określonej w § 3 podlega ten, kto organizuje innym osobom 
przekraczanie wbrew przepisom granicy innego państwa, jeżeli obowiązek ścigania 
takiego czynu wynika z ratyfikowanej przez Rzeczpospolitą Polską umowy między-
narodowej. 

 
 
 
s. 115/146 
 
   
 
2025-04-09 
 
Art. 264a. § 1. Kto, w celu osiągnięcia korzyści majątkowej lub osobistej, 
umożliwia lub ułatwia innej osobie pobyt na terytorium Rzeczypospolitej Polskiej 
wbrew przepisom, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. W wyjątkowych wypadkach, gdy sprawca nie osiągnął korzyści majątkowej, 
sąd może zastosować nadzwyczajne złagodzenie kary, a nawet odstąpić od jej 
wymierzenia. 
### Rozdział XXXIII Przestępstwa przeciwko ochronie informacji

***
## Art. 265. {#kk-art-265}

§ 1. Kto ujawnia lub wbrew przepisom ustawy wykorzystuje 
informacje niejawne o klauzuli „tajne” lub „ściśle tajne”, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Jeżeli informację określoną w § 1 ujawniono osobie działającej w imieniu 
lub na rzecz podmiotu zagranicznego, sprawca 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 3. Kto nieumyślnie ujawnia informację określoną w § 1, z którą zapoznał się 
w związku z pełnieniem funkcji pub- 
licznej lub otrzymanym upoważnieniem, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku.

***
## Art. 266. {#kk-art-266}

§ 1. Kto, wbrew przepisom ustawy lub przyjętemu na siebie 
zobowiązaniu, ujawnia lub wykorzystuje informację, z którą zapoznał się w związku 
z pełnioną funkcją, wykonywaną pracą, działalnością publiczną, społeczną, gospo-
darczą lub naukową, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Funkcjonariusz publiczny, który ujawnia osobie nieuprawnionej informację 
niejawną o klauzuli „zastrzeżone” lub „poufne” lub informację, którą uzyskał 
w związku z wykonywaniem czynności służbowych, a której ujawnienie może narazić 
na szkodę prawnie chroniony interes, 
podlega karze pozbawienia wolności do lat 3. 

 
 
 
s. 116/146 
 
   
 
2025-04-09 
 
§ 3. Ściganie 
przestępstwa 
określonego 
w § 1 następuje 
na 
wniosek 
pokrzywdzonego.

***
## Art. 267. {#kk-art-267}

§ 1. Kto bez uprawnienia uzyskuje dostęp do informacji dla niego 
nieprzeznaczonej, 
otwierając 
zamknięte 
pismo, 
podłączając 
się 
do 
sieci 
telekomunikacyjnej lub przełamując albo omijając elektroniczne, magnetyczne, 
informatyczne lub inne szczególne jej zabezpieczenie, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Tej samej karze podlega, kto bez uprawnienia uzyskuje dostęp do całości lub 
części systemu informatycznego. 
§ 3. Tej samej karze podlega, kto w celu uzyskania informacji, do której nie jest 
uprawniony, zakłada lub posługuje się urządzeniem podsłuchowym, wizualnym albo 
innym urządzeniem lub oprogramowaniem. 
§ 4. Tej samej karze podlega, kto informację uzyskaną w sposób określony 
w § 1–3 ujawnia innej osobie. 
§ 5. Ściganie 
przestępstwa 
określonego 
w § 1–4 następuje 
na 
wniosek 
pokrzywdzonego.

***
## Art. 268. {#kk-art-268}

§ 1. Kto, nie będąc do tego uprawnionym, niszczy, uszkadza, usuwa 
lub zmienia zapis istotnej informacji albo w inny sposób udaremnia lub znacznie 
utrudnia osobie uprawnionej zapoznanie się z nią, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Jeżeli czyn określony w § 1 dotyczy zapisu na informatycznym nośniku 
danych, sprawca podlega karze pozbawienia wolności do lat 3. 
§ 3. Kto, dopuszczając się czynu określonego w § 1 lub 2, wyrządza znaczną 
szkodę majątkową, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 4. Ściganie 
przestępstwa 
określonego 
w § 1–3 następuje 
na 
wniosek 
pokrzywdzonego. 
Art. 268a. § 1. Kto, nie będąc do tego uprawnionym, niszczy, uszkadza, usuwa, 
zmienia lub utrudnia dostęp do danych informatycznych albo w istotnym stopniu 

 
 
 
s. 117/146 
 
   
 
2025-04-09 
 
zakłóca lub uniemożliwia automatyczne przetwarzanie, gromadzenie lub przekazy-
wanie takich danych, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Kto, dopuszczając się czynu określonego w § 1, wyrządza znaczną szkodę 
majątkową, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 3. Ściganie przestępstwa określonego w § 1 lub 2 następuje na wniosek 
pokrzywdzonego.

***
## Art. 269. {#kk-art-269}

§ 1. Kto niszczy, uszkadza, usuwa lub zmienia dane informatyczne 
o szczególnym znaczeniu dla obronności kraju, bezpieczeństwa w komunikacji, 
funkcjonowania administracji rządowej, innego organu państwowego lub instytucji 
państwowej albo samorządu terytorialnego albo zakłóca lub uniemożliwia 
automatyczne przetwarzanie, gromadzenie lub przekazywanie takich danych, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. Tej samej karze podlega, kto dopuszcza się czynu określonego w § 1, 
niszcząc albo wymieniając informatyczny nośnik danych lub niszcząc albo 
uszkadzając urządzenie służące do automatycznego przetwarzania, gromadzenia lub 
przekazywania danych informatycznych. 
Art. 269a. Kto, nie będąc do tego uprawnionym, przez transmisję, zniszczenie, 
usunięcie, uszkodzenie, utrudnienie dostępu lub zmianę danych informatycznych, 
w istotnym stopniu zakłóca pracę systemu informatycznego, systemu teleinformatycz-
nego lub sieci teleinformatycznej, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
Art. 269b. § 1. Kto wytwarza, pozyskuje, zbywa lub udostępnia innym osobom 
urządzenia lub programy komputerowe przystosowane do popełnienia przestępstwa 
określonego w art. 165 § 1 pkt 4, art. 267 § 3, art. 268a § 1 albo § 2 w związku z § 1, 
art. 269 § 1 lub 2, art. 269a, art. 270 § 1 albo art. 270a § 1, a także hasła komputerowe, 
kody dostępu lub inne dane umożliwiające nieuprawniony dostęp do informacji 
przechowywanych w systemie informatycznym, systemie teleinformatycznym lub 
sieci teleinformatycznej, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 

 
 
 
s. 118/146 
 
   
 
2025-04-09 
 
§ 1a. Nie popełnia przestępstwa określonego w § 1, kto działa wyłącznie w celu 
zabezpieczenia systemu informatycznego, systemu teleinformatycznego lub sieci 
teleinformatycznej przed popełnieniem przestępstwa wymienionego w tym przepisie 
albo opracowania metody takiego zabezpieczenia. 
§ 2. W razie skazania za przestępstwo określone w § 1, sąd orzeka przepadek 
określonych w nim przedmiotów, a może orzec ich przepadek, jeżeli nie stanowiły 
własności sprawcy. 
Art. 269c. Nie podlega karze za przestępstwo określone w art. 267 § 2 lub 
art. 269a, kto działa wyłącznie w celu zabezpieczenia systemu informatycznego, 
systemu teleinformatycznego lub sieci teleinformatycznej albo opracowania metody 
takiego zabezpieczenia i niezwłocznie powiadomił dysponenta tego systemu lub sieci 
o ujawnionych zagrożeniach, a jego działanie nie naruszyło interesu publicznego lub 
prywatnego i nie wyrządziło szkody. 
### Rozdział XXXIV Przestępstwa przeciwko wiarygodności dokumentów

***
## Art. 270. {#kk-art-270}

§ 1. Kto, w celu użycia za autentyczny, podrabia lub przerabia 
dokument lub takiego dokumentu jako autentycznego używa, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Tej samej karze podlega, kto wypełnia blankiet, opatrzony cudzym 
podpisem, niezgodnie z wolą podpisanego i na jego szkodę albo takiego dokumentu 
używa. 
§ 2a. W wypadku mniejszej wagi, sprawca 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 3. Kto czyni przygotowania do przestępstwa określonego w § 1, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
Art. 270a. § 1. Kto, w celu użycia za autentyczną, podrabia lub przerabia fakturę 
w zakresie okoliczności faktycznych mogących mieć znaczenie dla określenia 
wysokości należności publicznoprawnej lub jej zwrotu albo zwrotu innej należności 
o charakterze podatkowym lub takiej faktury jako autentycznej używa, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 

 
 
 
s. 119/146 
 
   
 
2025-04-09 
 
§ 2. Jeżeli sprawca dopuszcza się czynu określonego w § 1 wobec faktury lub 
faktur, zawierających kwotę należności ogółem, której wartość lub łączna wartość jest 
większa niż pięciokrotność kwoty określającej mienie wielkiej wartości, albo 
z popełnienia przestępstwa uczynił sobie stałe źródło dochodu, 
podlega karze pozbawienia wolności od lat 3 do 20. 
§ 3. W wypadku mniejszej wagi, sprawca czynu określonego w § 1 lub 2 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 271. {#kk-art-271}

§ 1. Funkcjonariusz publiczny lub inna osoba uprawniona do 
wystawienia dokumentu, która poświadcza w nim nieprawdę co do okoliczności 
mającej znaczenie prawne, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. W wypadku mniejszej wagi, sprawca 
podlega grzywnie albo karze ograniczenia wolności. 
§ 3. Jeżeli sprawca dopuszcza się czynu określonego w § 1 w celu osiągnięcia 
korzyści majątkowej lub osobistej, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
Art. 271a. § 1. Kto wystawia fakturę lub faktury, zawierające kwotę należności 
ogółem, której wartość lub łączna wartość jest znaczna, poświadczając nieprawdę co 
do okoliczności faktycznych mogących mieć znaczenie dla określenia wysokości 
należności publicznoprawnej lub jej zwrotu albo zwrotu innej należności o charakterze 
podatkowym lub takiej faktury lub faktur używa, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. Jeżeli sprawca dopuszcza się czynu określonego w § 1 wobec faktury lub 
faktur, zawierających kwotę należności ogółem, której wartość lub łączna wartość jest 
większa niż pięciokrotność kwoty określającej mienie wielkiej wartości, albo 
z popełnienia przestępstwa uczynił sobie stałe źródło dochodu, 
podlega karze pozbawienia wolności od lat 3 do 20. 
§ 3. W wypadku mniejszej wagi, sprawca czynu określonego w § 1 lub 2 
podlega karze pozbawienia wolności do lat 3. 

 
 
 
s. 120/146 
 
   
 
2025-04-09

***
## Art. 272. {#kk-art-272}

Kto 
wyłudza 
poświadczenie 
nieprawdy 
przez 
podstępne 
wprowadzenie w błąd funkcjonariusza publicznego lub innej osoby upoważnionej do 
wystawienia dokumentu, 
podlega karze pozbawienia wolności do lat 3.

***
## Art. 273. {#kk-art-273}

Kto używa dokumentu określonego w art. 271 lub 272, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 274. {#kk-art-274}

Kto zbywa własny lub cudzy dokument stwierdzający tożsamość, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 275. {#kk-art-275}

§ 1. Kto posługuje się dokumentem stwierdzającym tożsamość innej 
osoby albo jej prawa majątkowe lub dokument taki kradnie lub go przywłaszcza, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Tej samej karze podlega, kto bezprawnie przewozi, przenosi lub przesyła za 
granicę dokument stwierdzający tożsamość innej osoby albo jej prawa majątkowe.

***
## Art. 276. {#kk-art-276}

Kto niszczy, uszkadza, czyni bezużytecznym, ukrywa lub usuwa 
dokument, którym nie ma prawa wyłącznie rozporządzać, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 277. {#kk-art-277}

Kto znaki graniczne niszczy, uszkadza, usuwa, przesuwa lub czyni 
niewidocznymi albo fałszywie wystawia, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
Art. 277a. § 1. Kto dopuszcza się przestępstwa określonego w art. 270a § 1 albo 
art. 271a § 1 wobec faktury lub faktur, zawierających kwotę należności ogółem, której 
wartość lub łączna wartość jest większa niż dziesięciokrotność kwoty określającej 
mienie wielkiej wartości, 
podlega karze pozbawienia wolności od lat 5 do 25. 
§ 2. W wypadku mniejszej wagi, sprawca czynu określonego w § 1 
podlega karze pozbawienia wolności do lat 5. 

 
 
 
s. 121/146 
 
   
 
2025-04-09 
 
Art. 277b. W razie skazania za przestępstwo określone w art. 270a § 1 lub 2, 
art. 271a § 1 lub 2 albo art. 277a § 1, grzywnę orzeczoną obok kary pozbawienia 
wolności można wymierzyć w wysokości do 3000 stawek dziennych. 
Art. 277c. § 1. Sąd na wniosek prokuratora stosuje nadzwyczajne złagodzenie 
kary wobec sprawcy przestępstwa określonego w art. 270a § 1 lub 2 lub art. 271a § 1 
lub 2, który zawiadomił o nim organ powołany do ścigania przestępstw i ujawnił 
wszystkie istotne okoliczności przestępstwa, a także wskazał czyny pozostające 
w związku z popełnionym przez niego przestępstwem i ich sprawców, zanim organ 
ten o nich się dowiedział. 
§ 2. Sąd na wniosek prokuratora może odstąpić od wymierzenia kary wobec 
sprawcy przestępstwa określonego w art. 270a § 1, 2 lub 3, art. 271a § 1, 2 lub 3 lub 
art. 277a § 2, który, oprócz spełnienia warunków określonych w § 1, zwrócił korzyść 
majątkową osiągniętą z popełnienia tego przestępstwa w całości albo w istotnej 
części. 
§ 3. Sąd może zastosować nadzwyczajne złagodzenie kary wobec sprawcy 
przestępstwa określonego w art. 277a § 1, który, oprócz spełnienia warunków 
określonych w § 1, zwrócił korzyść majątkową osiągniętą z popełnienia tego 
przestępstwa w całości albo w istotnej części. 
Art. 277d. Przepisy art. 277c § 1 i 3 stosuje się odpowiednio do sprawcy, który 
po wszczęciu postępowania ujawnił wobec organu powołanego do ścigania 
przestępstw wszystkie jemu znane, a nieznane dotychczas temu organowi istotne 
okoliczności 
przestępstwa, 
a także 
wskazał 
czyny 
pozostające 
w związku 
z popełnionym przez niego przestępstwem i ich sprawców. 
### Rozdział XXXV Przestępstwa przeciwko mieniu

***
## Art. 278. {#kk-art-278}

§ 1. Kto zabiera w celu przywłaszczenia cudzą rzecz ruchomą, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 1a. Tej samej karze podlega, kto zabiera w celu przywłaszczenia cudzą kartę 
uprawniającą do podjęcia pieniędzy z automatu bankowego. 
§ 2. Tej samej karze podlega, kto bez zgody osoby uprawnionej uzyskuje cudzy 
program komputerowy w celu osiągnięcia korzyści majątkowej. 
§ 3. W wypadku mniejszej wagi, sprawca czynu określonego w § 1, 1a lub 2 

 
 
 
s. 122/146 
 
   
 
2025-04-09 
 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 3a. Kto dopuszcza się kradzieży szczególnie zuchwałej,  
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 4. Jeżeli kradzież popełniono na szkodę osoby najbliższej, ściganie następuje 
na wniosek pokrzywdzonego. 
§ 5. Przepisy § 1, 3, 3a i 4 stosuje się odpowiednio do kradzieży energii. 
Art. 278a. (uchylony)

***
## Art. 279. {#kk-art-279}

§ 1. Kto kradnie z włamaniem, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 2. Jeżeli kradzież z włamaniem popełniono na szkodę osoby najbliższej, 
ściganie następuje na wniosek pokrzywdzonego.

***
## Art. 280. {#kk-art-280}

§ 1. Kto kradnie, używając przemocy wobec osoby lub grożąc 
natychmiastowym 
jej 
użyciem 
albo 
doprowadzając 
człowieka 
do 
stanu 
nieprzytomności lub bezbronności, 
podlega karze pozbawienia wolności od lat 2 do 15. 
§ 2. Jeżeli sprawca rozboju posługuje się bronią palną, nożem lub innym 
podobnie niebezpiecznym przedmiotem lub środkiem obezwładniającym albo działa 
w inny sposób bezpośrednio zagrażający życiu lub wspólnie z inną osobą, która 
posługuje się taką bronią, przedmiotem, środkiem lub sposobem, 
podlega karze pozbawienia wolności od lat 3 do 20.

***
## Art. 281. {#kk-art-281}

Kto, 
w celu 
utrzymania 
się 
w posiadaniu 
zabranej 
rzeczy, 
bezpośrednio po dokonaniu kradzieży, używa przemocy wobec osoby lub grozi 
natychmiastowym jej użyciem albo doprowadza człowieka do stanu nieprzytomności 
lub bezbronności, 
podlega karze pozbawienia wolności od roku do lat 10.

***
## Art. 282. {#kk-art-282}

§ 1. Kto, w celu osiągnięcia korzyści majątkowej, przemocą, groźbą 
zamachu na życie lub zdrowie albo gwałtownego zamachu na mienie, doprowadza 
inną osobę do rozporządzenia mieniem własnym lub cudzym albo do zaprzestania lub 
ograniczenia działalności gospodarczej,  
podlega karze pozbawienia wolności od roku do lat 10.  

 
 
 
s. 123/146 
 
   
 
2025-04-09 
 
§ 2. Tej samej karze podlega, kto, w celu osiągnięcia korzyści majątkowej, 
groźbą rozgłoszenia dotyczącej innej osoby lub osoby dla niej najbliższej wiadomości 
uwłaczającej czci lub istotnie naruszającej prywatność lub zarzutu, który może 
poniżyć w opinii publicznej lub narazić na utratę zaufania potrzebnego dla danego 
stanowiska, zawodu lub rodzaju działalności, doprowadza inną osobę do 
rozporządzenia mieniem własnym lub cudzym albo do zaprzestania lub ograniczenia 
działalności gospodarczej.

***
## Art. 283. {#kk-art-283}

W wypadku mniejszej wagi, sprawca czynu określonego w art. 279 § 
1, art. 280 § 1, art. 281 lub art. 282,  
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 284. {#kk-art-284}

§ 1. Kto przywłaszcza sobie cudzą rzecz ruchomą lub prawo 
majątkowe, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Kto przywłaszcza sobie powierzoną mu rzecz ruchomą, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 3. W wypadku mniejszej wagi lub przywłaszczenia rzeczy znalezionej, 
sprawca 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 4. Jeżeli przywłaszczenie nastąpiło na szkodę osoby najbliższej, ściganie 
następuje na wniosek pokrzywdzonego.

***
## Art. 285. {#kk-art-285}

§ 1. Kto, włączając się do urządzenia telekomunikacyjnego, uruchamia 
na cudzy rachunek impulsy telefoniczne, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Jeżeli czyn określony w § 1 popełniono na szkodę osoby najbliższej, 
ściganie następuje na wniosek pokrzywdzonego.

***
## Art. 286. {#kk-art-286}

§ 1. Kto, w celu osiągnięcia korzyści majątkowej, doprowadza inną 
osobę do niekorzystnego rozporządzenia własnym lub cudzym mieniem za pomocą 
wprowadzenia jej w błąd albo wyzyskania błędu lub niezdolności do należytego 
pojmowania przedsiębranego działania, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 

 
 
 
s. 124/146 
 
   
 
2025-04-09 
 
§ 2. Tej samej karze podlega, kto żąda korzyści majątkowej w zamian za zwrot 
bezprawnie zabranej rzeczy. 
§ 3. W wypadku mniejszej wagi, sprawca 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 4. Jeżeli czyn określony w § 1–3 popełniono na szkodę osoby najbliższej, 
ściganie następuje na wniosek pokrzywdzonego.

***
## Art. 287. {#kk-art-287}

§ 1. Kto, w celu osiągnięcia korzyści majątkowej lub wyrządzenia 
innej osobie szkody, bez upoważnienia, wpływa na automatyczne przetwarzanie, 
gromadzenie lub przekazywanie danych informatycznych lub zmienia, usuwa albo 
wprowadza nowy zapis danych informatycznych, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. W wypadku mniejszej wagi, sprawca 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 3. Jeżeli oszustwo popełniono na szkodę osoby najbliższej, ściganie następuje 
na wniosek pokrzywdzonego.

***
## Art. 288. {#kk-art-288}

§ 1. Kto cudzą rzecz niszczy, uszkadza lub czyni niezdatną do użytku, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. W wypadku mniejszej wagi, sprawca 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 3. Karze określonej w § 1 podlega także ten, kto przerywa lub uszkadza kabel 
podmorski albo narusza przepisy obowiązujące przy zakładaniu lub naprawie takiego 
kabla. 
§ 4. Ściganie przestępstwa określonego w § 1 lub 2 następuje na wniosek 
pokrzywdzonego.

***
## Art. 289. {#kk-art-289}

§ 1. Kto zabiera w celu krótkotrwałego użycia cudzy pojazd 
mechaniczny, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Jeżeli sprawca czynu określonego w § 1 pokonuje zabezpieczenie pojazdu 
przed jego użyciem przez osobę nieupoważnioną, pojazd stanowi mienie znacznej 

 
 
 
s. 125/146 
 
   
 
2025-04-09 
 
wartości albo sprawca następnie porzuca pojazd w stanie uszkodzonym lub w takich 
okolicznościach, że zachodzi niebezpieczeństwo utraty lub uszkodzenia pojazdu albo 
jego części lub zawartości, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 3. Jeżeli czyn określony w § 1 popełniono używając przemocy lub grożąc 
natychmiastowym 
jej 
użyciem 
albo 
doprowadzając 
człowieka 
do 
stanu 
nieprzytomności lub bezbronności, sprawca 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 4. W wypadkach określonych w § 1–3 sąd może wymierzyć grzywnę obok 
kary pozbawienia wolności. 
§ 5. Jeżeli czyn określony w § 1–3 popełniono na szkodę osoby najbliższej, 
ściganie następuje na wniosek pokrzywdzonego.

***
## Art. 290. {#kk-art-290}

§ 1. Kto w celu przywłaszczenia dopuszcza się wyrębu drzewa w lesie, 
podlega odpowiedzialności jak za kradzież. 
§ 2. W razie skazania za wyrąb drzewa albo za kradzież drzewa wyrąbanego lub 
powalonego, sąd orzeka na rzecz pokrzywdzonego nawiązkę w wysokości podwójnej 
wartości drzewa.

***
## Art. 291. {#kk-art-291}

§ 1. Kto rzecz uzyskaną za pomocą czynu zabronionego nabywa lub 
pomaga do jej zbycia albo tę rzecz przyjmuje lub pomaga do jej ukrycia, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. W wypadku mniejszej wagi, sprawca 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku.

***
## Art. 292. {#kk-art-292}

§ 1. Kto rzecz, o której na podstawie towarzyszących okoliczności 
powinien i może przypuszczać, że została uzyskana za pomocą czynu zabronionego, 
nabywa lub pomaga do jej zbycia albo tę rzecz przyjmuje lub pomaga do jej ukrycia, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. W wypadku znacznej wartości rzeczy, o której mowa w § 1, sprawca 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 293. {#kk-art-293}

§ 1. Przepisy art. 291 i 292 stosuje się odpowiednio do programu 
komputerowego. 

 
 
 
s. 126/146 
 
   
 
2025-04-09 
 
§ 2. Sąd może orzec przepadek rzeczy określonej w § 1 oraz w art. 291 i 292, 
chociażby nie stanowiła ona własności sprawcy.

***
## Art. 294. {#kk-art-294}

§ 1. Kto dopuszcza się przestępstwa określonego w art. 278 § 1, 1a, 2, 
3a lub 5, art. 284 § 1 lub 2, art. 285 § 1, art. 286 § 1 lub 2, art. 287 § 1, art. 288 § 1 lub 
3, art. 290 § 1 lub w art. 291 § 1, w stosunku do mienia znacznej wartości,  
podlega karze pozbawienia wolności od roku do lat 10. 
§ 2. Tej samej karze podlega sprawca, który dopuszcza się przestępstwa 
wymienionego w § 1 w stosunku do dobra o szczególnym znaczeniu dla kultury. 
§ 3. Kto dopuszcza się przestępstwa określonego w art. 278 § 1, 1a, 2, 3a lub 5, 
art. 279 § 1, art. 280 § 1, art. 281, art. 282, art. 284 § 1 lub 2, art. 285 § 1, art. 286 § 1 
lub 2, art. 287 § 1, art. 288 § 1 lub 3, art. 290 § 1 lub w art. 291 § 1, w stosunku do 
mienia o wartości większej niż pięciokrotność kwoty określającej mienie wielkiej 
wartości,  
podlega karze pozbawienia wolności od lat 3 do 20. 
§ 4. Kto dopuszcza się przestępstwa określonego w art. 278 § 1, 1a, 2, 3a lub 5, 
art. 279 § 1, art. 280, art. 281, art. 282, art. 284 § 1 lub 2, art. 285 § 1, art. 286 § 1 lub 
2, art. 287 § 1, art. 288 § 1 lub 3, art. 290 § 1 lub w art. 291 § 1, w stosunku do mienia 
o wartości większej niż dziesięciokrotność kwoty określającej mienie wielkiej 
wartości, 
podlega karze pozbawienia wolności od lat 5 do 25.

***
## Art. 295. {#kk-art-295}

§ 1. Wobec sprawcy przestępstwa określonego w art. 278, 284–289, 
291, 292 lub 294, który dobrowolnie naprawił szkodę w całości albo zwrócił pojazd 
lub rzecz mającą szczególne znaczenie dla kultury w stanie nieuszkodzonym, sąd 
może zastosować nadzwyczajne złagodzenie kary, a nawet odstąpić od jej 
wymierzenia. 
§ 2. Wobec sprawcy przestępstwa wymienionego w § 1, który dobrowolnie 
naprawił szkodę w znacznej części, sąd może zastosować nadzwyczajne złagodzenie 
kary. 

 
 
 
s. 127/146 
 
   
 
2025-04-09 
### Rozdział XXXVI Przestępstwa przeciwko obrotowi gospodarczemu i interesom majątkowym 
w obrocie cywilnoprawnym

***
## Art. 296. {#kk-art-296}

§ 1. Kto, będąc obowiązany na podstawie przepisu ustawy, decyzji 
właściwego organu lub umowy do zajmowania się sprawami majątkowymi lub 
działalnością gospodarczą osoby fizycznej, prawnej albo jednostki organizacyjnej 
niemającej osobowości prawnej, przez nadużycie udzielonych mu uprawnień lub 
niedopełnienie ciążącego na nim obowiązku, wyrządza jej znaczną szkodę majątkową, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 1a. Jeżeli sprawca, o którym mowa w § 1, przez nadużycie udzielonych mu 
uprawnień lub niedopełnienie ciążącego na nim obowiązku, sprowadza bezpośrednie 
niebezpieczeństwo wyrządzenia znacznej szkody majątkowej, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Jeżeli sprawca przestępstwa określonego w § 1 lub 1a działa w celu 
osiągnięcia korzyści majątkowej, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 3. Jeżeli sprawca przestępstwa określonego w § 1 lub 2 wyrządza szkodę 
majątkową w wielkich rozmiarach, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 4. Jeżeli sprawca przestępstwa określonego w § 1 lub 3 działa nieumyślnie, 
podlega karze pozbawienia wolności do lat 3. 
§ 4a. Jeżeli pokrzywdzonym nie jest Skarb Państwa, ściganie przestępstwa 
określonego w § 1a następuje na wniosek pokrzywdzonego, wspólnika, akcjonariusza 
lub udziałowca pokrzywdzonej spółki lub członka pokrzywdzonej spółdzielni. 
§ 5. Nie podlega karze, kto przed wszczęciem postępowania karnego 
dobrowolnie naprawił w całości wyrządzoną szkodę. 
Art. 296a. § 1. Kto, pełniąc funkcję kierowniczą w jednostce organizacyjnej 
wykonującej działalność gospodarczą lub pozostając z nią w stosunku pracy, umowy 
zlecenia lub umowy o dzieło, żąda lub przyjmuje korzyść majątkową lub osobistą albo 
jej obietnicę, w zamian za nadużycie udzielonych mu uprawnień lub niedopełnienie 
ciążącego na nim obowiązku mogące wyrządzić tej jednostce szkodę majątkową albo 

 
 
 
s. 128/146 
 
   
 
2025-04-09 
 
stanowiące 
czyn 
nieuczciwej 
konkurencji 
lub 
niedopuszczalną 
czynność 
preferencyjną na rzecz nabywcy lub odbiorcy towaru, usługi lub świadczenia, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Tej samej karze podlega, kto w wypadkach określonych w § 1 udziela albo 
obiecuje udzielić korzyści majątkowej lub osobistej. 
§ 3. W wypadku mniejszej wagi, sprawca czynu określonego w § 1 lub 2 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 4. Jeżeli sprawca czynu określonego w § 1 wyrządza znaczną szkodę 
majątkową, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 5. Nie podlega karze sprawca przestępstwa określonego w § 2 albo w § 3 
w związku z § 2, jeżeli korzyść majątkowa lub osobista albo ich obietnica zostały 
przyjęte, a sprawca zawiadomił o tym fakcie organ powołany do ścigania przestępstw 
i ujawnił wszystkie istotne okoliczności przestępstwa, zanim organ ten o nim się 
dowiedział. 
Art. 296b. (uchylony)

***
## Art. 297. {#kk-art-297}

§ 1. Kto, w celu uzyskania dla siebie lub kogo innego, od banku lub 
jednostki organizacyjnej prowadzącej podobną działalność gospodarczą na podstawie 
ustawy albo od organu lub instytucji dysponujących środkami publicznymi – kredytu, 
pożyczki pieniężnej, poręczenia, gwarancji, akredytywy, dotacji, subwencji, 
potwierdzenia przez bank zobowiązania wynikającego z poręczenia lub z gwarancji 
lub podobnego świadczenia pieniężnego na określony cel gospodarczy, instrumentu 
płatniczego lub zamówienia publicznego, przedkłada podrobiony, przerobiony, 
poświadczający nieprawdę albo nierzetelny dokument albo nierzetelne, pisemne 
oświadczenie 
dotyczące 
okoliczności 
o istotnym 
znaczeniu 
dla 
uzyskania 
wymienionego wsparcia finansowego, instrumentu płatniczego lub zamówienia, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Tej samej karze podlega, kto wbrew ciążącemu obowiązkowi, nie 
powiadamia właściwego podmiotu o powstaniu sytuacji mogącej mieć wpływ na 

 
 
 
s. 129/146 
 
   
 
2025-04-09 
 
wstrzymanie albo ograniczenie wysokości udzielonego wsparcia finansowego, okreś-
lonego w § 1, lub zamówienia publicznego albo na możliwość dalszego korzystania 
z instrumentu płatniczego. 
§ 3. Nie podlega karze, kto przed wszczęciem postępowania karnego 
dobrowolnie zapobiegł wykorzystaniu wsparcia finansowego lub instrumentu 
płatniczego, określonych w § 1, zrezygnował z dotacji lub zamówienia publicznego 
albo zaspokoił roszczenia pokrzywdzonego.

***
## Art. 298. {#kk-art-298}

§ 1. Kto, w celu uzyskania odszkodowania z tytułu umowy 
ubezpieczenia, powoduje zdarzenie będące podstawą do wypłaty takiego 
odszkodowania, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Nie podlega karze, kto przed wszczęciem postępowania karnego 
dobrowolnie zapobiegł wypłacie odszkodowania.

***
## Art. 299. {#kk-art-299}

§ 1. Kto środki płatnicze, instrumenty finansowe, papiery wartościowe, 
wartości dewizowe, prawa majątkowe lub inne mienie ruchome lub nieruchomości, 
pochodzące z korzyści związanych z popełnieniem czynu zabronionego, przyjmuje, 
posiada, używa, przekazuje lub wywozi za granicę, ukrywa, dokonuje ich transferu 
lub konwersji, pomaga do przenoszenia ich własności lub posiadania albo podejmuje 
inne czynności, które mogą udaremnić lub znacznie utrudnić stwierdzenie ich 
przestępnego pochodzenia lub miejsca umieszczenia, ich wykrycie, zajęcie albo 
orzeczenie przepadku, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 2. Karze określonej w § 1 podlega, kto będąc pracownikiem lub działając 
w imieniu lub na rzecz banku, instytucji finansowej lub kredytowej lub innego 
podmiotu, na którym na podstawie przepisów prawa ciąży obowiązek rejestracji 
transakcji i osób dokonujących transakcji, przyjmuje, wbrew przepisom, środki 
płatnicze, instrumenty finansowe, papiery wartościowe, wartości dewizowe, dokonuje 
ich transferu lub konwersji, lub przyjmuje je w innych okolicznościach 
wzbudzających uzasadnione podejrzenie, że stanowią one przedmiot czynu 
określonego w § 1, lub świadczy inne usługi mające ukryć ich przestępne pochodzenie 
lub usługi w zabezpieczeniu przed zajęciem. 
§ 3. (uchylony) 

 
 
 
s. 130/146 
 
   
 
2025-04-09 
 
§ 4. (uchylony) 
§ 5. Jeżeli sprawca dopuszcza się czynu określonego w § 1 lub 2, działając 
w porozumieniu z innymi osobami, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 6. Karze określonej w § 5 podlega sprawca, jeżeli dopuszczając się czynu 
określonego w § 1 lub 2, osiąga znaczną korzyść majątkową. 
§ 6a. Kto czyni przygotowania do przestępstwa określonego w § 1 lub 2, 
podlega karze pozbawienia wolności do lat 3. 
§ 7. W razie skazania za przestępstwo określone w § 1 lub 2, sąd orzeka 
przepadek przedmiotów pochodzących bezpośrednio albo pośrednio z przestępstwa, 
a także korzyści z tego przestępstwa lub ich równowartość, chociażby nie stanowiły 
one własności sprawcy. Przepadku nie orzeka się w całości lub w części, jeżeli 
przedmiot, korzyść lub jej równowartość podlega zwrotowi pokrzywdzonemu lub 
innemu podmiotowi. 
§ 8. Nie podlega karze za przestępstwo określone w § 1 lub 2, kto dobrowolnie 
ujawnił wobec organu powołanego do ścigania przestępstw informacje dotyczące osób 
uczestniczących w popełnieniu przestępstwa oraz okoliczności jego popełnienia, jeżeli 
zapobiegło to popełnieniu innego przestępstwa; jeżeli sprawca czynił starania 
zmierzające do ujawnienia tych informacji i okoliczności, sąd stosuje nadzwyczajne 
złagodzenie kary.

***
## Art. 300. {#kk-art-300}

§ 1. Kto, w razie grożącej mu niewypłacalności lub upadłości, 
udaremnia lub uszczupla zaspokojenie swojego wierzyciela przez to, że usuwa, 
ukrywa, zbywa, darowuje, niszczy, rzeczywiście lub pozornie obciąża albo uszkadza 
składniki swojego majątku, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Kto, w celu udaremnienia wykonania orzeczenia sądu lub innego organu 
państwowego, udaremnia lub uszczupla zaspokojenie swojego wierzyciela przez to, 
że usuwa, ukrywa, zbywa, darowuje, niszczy, rzeczywiście lub pozornie obciąża albo 
uszkadza składniki swojego majątku zajęte lub zagrożone zajęciem, bądź usuwa znaki 
zajęcia, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 3. Jeżeli czyn określony w § 1 wyrządził szkodę wielu wierzycielom, sprawca 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 

 
 
 
s. 131/146 
 
   
 
2025-04-09 
 
§ 4. Jeżeli pokrzywdzonym nie jest Skarb Państwa, ściganie przestępstwa 
określonego w § 1 następuje na wniosek pokrzywdzonego.

***
## Art. 301. {#kk-art-301}

§ 1. Kto będąc dłużnikiem kilku wierzycieli udaremnia lub ogranicza 
zaspokojenie ich należności przez to, że tworzy w oparciu o przepisy prawa nową 
jednostkę gospodarczą i przenosi na nią składniki swojego majątku, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Tej samej karze podlega, kto będąc dłużnikiem kilku wierzycieli 
doprowadza do swojej upadłości lub niewypłacalności. 
§ 3. Kto będąc dłużnikiem kilku wierzycieli w sposób lekkomyślny doprowadza 
do swojej upadłości lub niewypłacalności, w szczególności przez trwonienie części 
składowych majątku, zaciąganie zobowiązań lub zawieranie transakcji oczywiście 
sprzecznych z zasadami gospodarowania, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 302. {#kk-art-302}

§ 1. Kto, w razie grożącej mu niewypłacalności lub upadłości, nie 
mogąc zaspokoić wszystkich wierzycieli, spłaca lub zabezpiecza tylko niektórych, 
czym działa na szkodę pozostałych, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Kto wierzycielowi udziela lub obiecuje udzielić korzyści majątkowej za 
działanie na szkodę innych wierzycieli w związku z postępowaniem upadłościowym 
lub zmierzającym do zapobiegnięcia upadłości, 
podlega karze pozbawienia wolności do lat 3. 
§ 3. Tej samej karze podlega wierzyciel, który w związku z określonym 
w § 2 postępowaniem przyjmuje korzyść za działanie na szkodę innych wierzycieli 
albo takiej korzyści żąda.

***
## Art. 303. {#kk-art-303}

§ 1. Kto wyrządza szkodę majątkową osobie fizycznej, prawnej albo 
jednostce organizacyjnej niemającej osobowości prawnej, przez nieprowadzenie 
dokumentacji działalności gospodarczej albo prowadzenie jej w sposób nierzetelny 
lub niezgodny z prawdą, w szczególności niszcząc, usuwając, ukrywając, przerabiając 
lub podrabiając dokumenty dotyczące tej działalności, 
podlega karze pozbawienia wolności do lat 3. 

 
 
 
s. 132/146 
 
   
 
2025-04-09 
 
§ 2. Jeżeli sprawca przestępstwa określonego w § 1 wyrządza znaczną szkodę 
majątkową, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 3. W wypadku mniejszej wagi, sprawca przestępstwa określonego w § 1 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku. 
§ 4. Jeżeli pokrzywdzonym nie jest Skarb Państwa, ściganie przestępstwa 
określonego w § 1–3 następuje na wniosek pokrzywdzonego.

***
## Art. 304. {#kk-art-304}

§ 1. Kto, wyzyskując przymusowe położenie innej osoby fizycznej, 
prawnej albo jednostki organizacyjnej niemającej osobowości prawnej, zawiera z nią 
umowę, nakładając na nią obowiązek świadczenia niewspółmiernego ze 
świadczeniem wzajemnym, 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Kto, w zamian za udzielone osobie fizycznej świadczenie pieniężne 
wynikające z umowy pożyczki, kredytu lub innej umowy, której przedmiotem jest 
udzielenie takiego świadczenia z obowiązkiem jego zwrotu, niezwiązanej 
bezpośrednio z działalnością gospodarczą lub zawodową tej osoby, żąda od niej 
zapłaty kosztów innych niż odsetki w kwocie co najmniej dwukrotnie przekraczającej 
maksymalną wysokość tych kosztów określoną w ustawie, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 3. Tej samej karze podlega, kto, w związku z udzieleniem osobie fizycznej 
świadczenia pieniężnego wynikającego z umowy pożyczki, kredytu lub innej umowy, 
której przedmiotem jest udzielenie świadczenia pieniężnego z obowiązkiem jego 
zwrotu, niezwiązanej bezpośrednio z działalnością gospodarczą lub zawodową tej 
osoby, żąda od niej zapłaty odsetek w wysokości co najmniej dwukrotnie 
przekraczającej stopę odsetek maksymalnych lub odsetek maksymalnych za 
opóźnienie, określonych w ustawie.

***
## Art. 305. {#kk-art-305}

§ 1. Kto utrudnia lub udaremnia przetarg albo postępowanie o 
udzielenie zamówienia publicznego, działając na szkodę właściciela mienia, osoby lub 
instytucji, na rzecz której przetarg jest dokonywany bądź która prowadzi 
postępowanie, albo na szkodę interesu publicznego,  
podlega karze pozbawienia wolności do lat 3.  

 
 
 
s. 133/146 
 
   
 
2025-04-09 
 
§ 2. Kto, w celu wywarcia bezprawnego wpływu na wynik trwającego lub 
przygotowywanego 
przetargu 
lub 
postępowania 
o 
udzielenie 
zamówienia 
publicznego, wchodzi w porozumienie z inną osobą, przekazuje lub rozpowszechnia 
informacje lub przemilcza istotne okoliczności, działając na szkodę właściciela 
mienia, osoby lub instytucji, na rzecz której przetarg jest lub ma być dokonywany bądź 
która prowadzi lub ma prowadzić postępowanie, albo na szkodę interesu publicznego,  
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.  
§ 3. Jeżeli sprawca dopuszcza się czynu określonego w § 1 lub 2 w celu 
osiągnięcia korzyści majątkowej lub osobistej,  
podlega karze pozbawienia wolności od 6 miesięcy do lat 8.  
§ 4. Przepisy § 1–3 stosuje się odpowiednio do aukcji.  
§ 5. Ściganie przestępstwa określonego w § 1–4 następuje na wniosek 
pokrzywdzonego, chyba że pokrzywdzonym jest Skarb Państwa lub przedmiot 
przetargu, aukcji lub zamówienia publicznego jest co najmniej w części finansowany 
ze środków publicznych. 
§ 6. Nie podlega karze sprawca przestępstwa określonego w § 1 lub 2, który 
zawiadomił o fakcie jego popełnienia organ powołany do ścigania przestępstw lub 
organ ochrony konkurencji państwa członkowskiego Unii Europejskiej lub Komisję 
Europejską i ujawnił wszystkie istotne okoliczności tego przestępstwa, zanim organ 
powołany do ścigania przestępstw o nim się dowiedział.

***
## Art. 306. {#kk-art-306}

Kto usuwa, podrabia lub przerabia znaki identyfikacyjne, datę 
produkcji lub datę przydatności towaru lub urządzenia, 
podlega karze pozbawienia wolności do lat 3. 
Art. 306a. § 1. Kto zmienia wskazanie drogomierza pojazdu mechanicznego lub 
ingeruje w prawidłowość jego pomiaru, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Tej samej karze podlega, kto zleca innej osobie wykonanie czynu, o którym 
mowa w § 1. 
§ 3. W wypadku mniejszej wagi, sprawca czynu określonego w § 1 lub 2, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 

 
 
 
s. 134/146 
 
   
 
2025-04-09 
 
Art. 306b. § 1. Kto dopuszcza się przestępstwa określonego w art. 296 § 1 lub 2, 
art. 296a § 1 lub 4, art. 299 § 1, 2, 5 lub 6 lub w art. 303 § 1, w stosunku do mienia o 
wartości większej niż pięciokrotność kwoty określającej mienie wielkiej wartości lub 
powodując szkodę w rozmiarach odpowiadających takiej wartości,  
podlega karze pozbawienia wolności od lat 3 do 20.  
§ 2. Kto dopuszcza się przestępstwa określonego w art. 296 § 1 lub 2, art. 296a § 
1 lub 4, art. 299 § 1, 2, 5 lub 6 lub w art. 303 § 1, w stosunku do mienia o wartości 
większej niż dziesięciokrotność kwoty określającej mienie wielkiej wartości lub 
powodując szkodę w rozmiarach odpowiadających takiej wartości,  
podlega karze pozbawienia wolności od lat 5 do 25.  
Art. 306c. § 1. 
Kto 
dokonuje 
zaboru 
tablicy 
rejestracyjnej 
pojazdu 
mechanicznego, umożliwiającej dopuszczenie tego pojazdu do ruchu na obszarze 
Rzeczypospolitej Polskiej, albo w celu użycia za autentyczną tablicę rejestracyjną 
pojazdu mechanicznego podrabia lub przerabia,  
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.  
§ 2. Tej samej karze podlega, kto używa tablicy rejestracyjnej pojazdu 
mechanicznego nieprzypisanej do pojazdu, na którym ją umieszczono, albo używa 
jako autentycznej podrobionej lub przerobionej tablicy rejestracyjnej pojazdu 
mechanicznego.

***
## Art. 307. {#kk-art-307}

§ 1. Wobec sprawcy przestępstwa określonego w art. 296, art. 299–305 
lub w art. 306b, który dobrowolnie naprawił szkodę w całości, sąd może zastosować 
nadzwyczajne złagodzenie kary, a nawet odstąpić od jej wymierzenia. 
§ 2. Wobec sprawcy przestępstwa wymienionego w § 1, który dobrowolnie 
naprawił szkodę w znacznej części, sąd może zastosować nadzwyczajne złagodzenie 
kary.

***
## Art. 308. {#kk-art-308}

Za przestępstwa określone w tym rozdziale odpowiada jak dłużnik lub 
wierzyciel, kto, na podstawie przepisu prawnego, decyzji właściwego organu, umowy 
lub faktycznego wykonywania, zajmuje się sprawami majątkowymi innej osoby 
prawnej, fizycznej, grupy osób lub podmiotu niemającego osobowości prawnej.

***
## Art. 309. {#kk-art-309}

W razie skazania za przestępstwo określone w art. 296 § 3, art. 297, 
art. 299 lub w art. 306b sąd może wymierzyć obok kary pozbawienia wolności 
grzywnę w wysokości do 3000 stawek dziennych. 

 
 
 
s. 135/146 
 
   
 
2025-04-09 
### Rozdział XXXVII Przestępstwa przeciwko obrotowi pieniędzmi i papierami wartościowymi

***
## Art. 310. {#kk-art-310}

§ 1. Kto podrabia albo przerabia polski albo obcy pieniądz, polski albo 
obcy znak pieniężny, który został ustalony jako prawny środek płatniczy, jednak nie 
został jeszcze wprowadzony do obiegu, inny środek płatniczy albo dokument 
uprawniający do otrzymania sumy pieniężnej albo zawierający obowiązek wypłaty 
kapitału, odsetek, udziału w zyskach albo stwierdzenie uczestnictwa w spółce lub 
z pieniędzy, innego środka płatniczego albo z takiego dokumentu usuwa oznakę 
umorzenia, 
podlega karze pozbawienia wolności od lat 5 do 25. 
§ 2. Kto pieniądz, inny środek płatniczy lub znak pieniężny albo dokument 
określone w § 1 puszcza w obieg albo go w takim celu przyjmuje, przechowuje, 
przewozi, przenosi, przesyła albo pomaga do jego zbycia lub ukrycia, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 3. W wypadku mniejszej wagi sąd może zastosować nadzwyczajne 
złagodzenie kary. 
§ 4. Kto czyni przygotowania do popełnienia przestępstwa określonego w § 1 lub 
2, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 311. {#kk-art-311}

Kto, w dokumentacji związanej z obrotem papierami wartościowymi, 
rozpowszechnia nieprawdziwe informacje lub przemilcza informacje o stanie 
majątkowym oferenta, mające istotne znaczenie dla nabycia, zbycia papierów 
wartościowych, podwyższenia albo obniżenia wkładu, 
podlega karze pozbawienia wolności do lat 3.

***
## Art. 312. {#kk-art-312}

Kto puszcza w obieg podrobiony albo przerobiony pieniądz, inny 
środek płatniczy albo dokument określony w art. 310 § 1, który sam otrzymał jako 
prawdziwy, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
roku.

***
## Art. 313. {#kk-art-313}

§ 1. Kto, w celu użycia lub puszczenia w obieg, podrabia albo 
przerabia urzędowy znak wartościowy albo ze znaku takiego usuwa oznakę 
umorzenia, 

 
 
 
s. 136/146 
 
   
 
2025-04-09 
 
podlega karze pozbawienia wolności do lat 3. 
§ 2. Tej samej karze podlega, kto urzędowy znak wartościowy podrobiony, 
przerobiony albo z usuniętą oznaką umorzenia puszcza w obieg, nabywa lub go używa 
albo przechowuje w celu puszczenia w obieg.

***
## Art. 314. {#kk-art-314}

Kto, w celu użycia w obrocie gospodarczym, podrabia albo przerabia 
znak urzędowy, mający stwierdzić upoważnienie lub wynik badania albo w obrocie 
publicznym 
używa 
przedmiotów 
opatrzonych 
takimi 
podrobionymi 
albo 
przerobionymi znakami, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2.

***
## Art. 315. {#kk-art-315}

§ 1. Kto, w celu użycia w obrocie gospodarczym, podrabia lub 
przerabia zalegalizowane narzędzie pomiarowe lub probiercze, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Tej samej karze podlega, kto podrobionego albo przerobionego narzędzia 
pomiarowego lub probierczego w obrocie gospodarczym używa albo takie narzędzie 
w celu użycia w obrocie gospodarczym przechowuje.

***
## Art. 316. {#kk-art-316}

§ 1. 
Pieniądze, 
dokumenty 
i znaki 
wartościowe 
podrobione, 
przerobione albo z usuniętą oznaką umorzenia oraz podrobione lub przerobione 
narzędzia pomiarowe, jak również przedmioty służące do popełnienia przestępstw 
określonych w tym rozdziale ulegają przepadkowi, chociażby nie stanowiły własności 
sprawcy. 
§ 2. Podrobione albo przerobione znaki urzędowe określone w art. 314 należy 
usunąć, chociażby to miało być połączone ze zniszczeniem przedmiotu.

