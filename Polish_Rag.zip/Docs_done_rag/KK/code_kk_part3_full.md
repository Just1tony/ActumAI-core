---
id: code.kk.part3
title: "Kodeks karny – Część wojskowa (Art. 317–363)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1997 nr 88 poz. 553"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KK – Część wojskowa"]
tags: ["KK","kodeks karny","część wojskowa","przestępstwa wojskowe","PL"]
source_pdf: "D19970553Lj.pdf"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kk-art-{n}}"
  separators: "***"
  hierarchy: ["Część","Dział","Rozdział"]
---

# Kodeks karny – Część wojskowa

CZĘŚĆ WOJSKOWA 
### Rozdział XXXVIII Przepisy ogólne dotyczące żołnierzy
***
## Art. 317. {#kk-art-317}

§ 1. Przepisy części ogólnej i szczególnej tego kodeksu stosuje się do 
żołnierzy, jeżeli część wojskowa nie zawiera przepisów odmiennych. 

 
 
 
s. 137/146 
 
   
 
2025-04-09 
 
§ 2. Przepisy art. 356–363 oraz, w wypadku popełnienia określonego w nich 
przestępstwa, przepisy ogólne dotyczące żołnierzy stosuje się odpowiednio także do 
pracowników wojska. 
§ 3. Przepisy części wojskowej stosuje się odpowiednio także do innych osób, 
jeżeli ustawa tak stanowi.

***
## Art. 318. {#kk-art-318}

Nie popełnia przestępstwa żołnierz, który dopuszcza się czynu 
zabronionego będącego wykonaniem rozkazu, chyba że wykonując rozkaz umyślnie 
popełnia przestępstwo.

***
## Art. 319. {#kk-art-319}

§ 1. 
Nie 
popełnia 
przestępstwa 
żołnierz, 
gdy 
w wypadku 
nieposłuszeństwa lub oporu stosuje środki niezbędne w celu wymuszenia posłuchu dla 
rozkazu, do którego wydania był uprawniony, jeżeli okoliczności wymagają 
natychmiastowego przeciwdziałania, a posłuchu dla rozkazu nie można osiągnąć 
w inny sposób. 
§ 2. W razie przekroczenia granic ostatecznej potrzeby sąd może zastosować 
nadzwyczajne złagodzenie kary.

***
## Art. 320. {#kk-art-320}

W stosunku 
do 
sprawcy 
przestępstwa 
określonego 
w części 
wojskowej, który w chwili czynu był niezdolny do pełnienia służby wojskowej, sąd 
może zastosować nadzwyczajne złagodzenie kary, a nawet odstąpić od jej 
wymierzenia.

***
## Art. 321. {#kk-art-321}

W wypadku przewidzianym w art. 10 § 4 sąd może zamiast orzekania 
środków wychowawczych lub poprawczych, o których mowa w tym przepisie, 
przekazać sprawcę właściwemu dowódcy w celu wymierzenia kary przewidzianej 
w wojskowych przepisach dyscyplinarnych.

***
## Art. 322. {#kk-art-322}

§ 1. Karą stosowaną wobec żołnierzy jest także areszt wojskowy; do 
kary aresztu wojskowego stosuje się odpowiednio przepisy o karze pozbawienia 
wolności. 
§ 2. Kara aresztu wojskowego trwa najkrócej miesiąc, najdłużej 2 lata; wymierza 
się ją w miesiącach i latach. 
§ 3. Karę aresztu wojskowego odbywa się w przeznaczonym do tego zakładzie 
karnym; w czasie odbywania kary skazany podlega także szkoleniu wojskowemu.

***
## Art. 323. {#kk-art-323}

§ 1. Do żołnierzy nie stosuje się przepisów art. 34 § 1a pkt 1. 

 
 
 
s. 138/146 
 
   
 
2025-04-09 
 
§ 2. W czasie odbywania kary ograniczenia wolności skazany: 
- 1) nie może być mianowany na wyższy stopień wojskowy ani wyznaczony na 
wyższe stanowisko służbowe; 
- 2) nie może brać udziału w uroczystościach i paradach organizowanych 
w jednostce wojskowej lub z udziałem jednostki. 
§ 3. Żołnierze innej służby niż zasadnicza odbywają karę ograniczenia wolności, 
pozostając w określonym miejscu w dyspozycji przełożonego w czasie od 
zakończenia zajęć służbowych przez 4 godziny 2 dni w tygodniu. Sąd może również 
orzec potrącenie od 5 do 15 % miesięcznego zasadniczego uposażenia na wskazany 
cel społeczny. 
§ 4. Żołnierze zasadniczej służby wojskowej odbywają karę ograniczenia 
wolności w wydzielonej jednostce wojskowej według zasad określonych w Kodeksie 
karnym wykonawczym. 
§ 5. Jeżeli skazany na karę ograniczenia wolności, według zasad określonych 
w § 1–4, w chwili przystąpienia do jej wykonania w całości lub w części, przestał być 
żołnierzem lub, w wypadku przewidzianym w art. 317 § 2, pracownikiem wojska, sąd 
zamienia tę karę na karę ograniczenia wolności orzekaną według zasad ogólnych.

***
## Art. 324. {#kk-art-324}

§ 1. Środkami karnymi stosowanymi wobec żołnierzy są także: 
- 1) (uchylony) 
- 2) wydalenie z zawodowej służby wojskowej. 
- 3) (uchylony) 
§ 2. Wobec żołnierzy służby zasadniczej nie orzeka się środka karnego 
wymienionego w art. 39 pkt 7.

***
## Art. 325. {#kk-art-325}

(uchylony)

***
## Art. 326. {#kk-art-326}

§ 1. Wydalenie z zawodowej służby wojskowej obejmuje bezzwłoczne 
usunięcie ze służby oraz utratę odznak i zaszczytnych wyróżnień nadanych przez 
właściwego dowódcę. 
§ 2. Sąd może orzec wydalenie z zawodowej służby wojskowej, jeżeli sprawca 
przy popełnieniu przestępstwa umyślnego rażąco nadużył swoich uprawnień albo 
okazał, że dalsze pełnienie tej służby zagraża istotnym dobrom chronionym prawem.

***
## Art. 327. {#kk-art-327}

(uchylony)

***
## Art. 328. {#kk-art-328}

(uchylony)  

 
 
 
s. 139/146 
 
   
 
2025-04-09

***
## Art. 329. {#kk-art-329}

Jeżeli przestępstwo zagrożone jest karą pozbawienia wolności nie 
przekraczającą 5 lat, a wymierzona kara nie byłaby surowsza niż 2 lata pozbawienia 
wolności, sąd może w stosunku do żołnierza orzec karę aresztu wojskowego.

***
## Art. 330. {#kk-art-330}

Jeżeli wymierzona za przestępstwo kara aresztu wojskowego nie 
byłaby surowsza od roku, sąd może w stosunku do żołnierza orzec karę ograniczenia 
wolności.

***
## Art. 331. {#kk-art-331}

Odstępując od wymierzenia kary, sąd może zwrócić się do właściwego 
dowódcy 
o wymierzenie 
kary 
dyscyplinarnej 
przewidzianej 
w wojskowych 
przepisach dyscyplinarnych.

***
## Art. 332. {#kk-art-332}

§ 1. W razie orzeczenia za zbiegające się przestępstwa pozbawienia 
praw publicznych i degradacji lub wydalenia z zawodowej służby wojskowej sąd 
orzeka tylko pozbawienie praw publicznych. 
§ 2. W razie orzeczenia za zbiegające się przestępstwa degradacji oraz wydalenia 
z zawodowej służby wojskowej sąd orzeka tylko degradację.

***
## Art. 333. {#kk-art-333}

§ 1. Stosując warunkowe umorzenie postępowania karnego wobec 
żołnierza, sąd może także zwrócić się do właściwego dowódcy o wymierzenie kary 
przewidzianej w wojskowych przepisach dyscyplinarnych. 
§ 2. Sąd może podjąć postępowanie karne także wtedy, gdy sprawca rażąco 
narusza zasady dyscypliny wojskowej.

***
## Art. 334. {#kk-art-334}

§ 1. Nakładając na żołnierza obowiązki lub stosując środki 
przewidziane w art. 67 lub 72, uwzględnia się warunki służby wojskowej. 
§ 2. Orzekając dozór wobec żołnierza, sąd może powierzyć wykonywanie 
czynności dozoru kuratorowi wojskowemu, przełożonemu lub żołnierzowi 
wskazanemu przez przełożonego.

***
## Art. 335. {#kk-art-335}

Zawieszając wykonanie kary wobec żołnierza, sąd może orzec także 
środki przewidziane w art. 323 § 2.

***
## Art. 336. {#kk-art-336}

§ 1. Sąd może odroczyć żołnierzowi służby zasadniczej wykonanie 
kary pozbawienia wolności nie przekraczającej 6 miesięcy do czasu ukończenia 
służby. 
§ 2. Sąd może zarządzić wykonanie odroczonej kary, jeżeli skazany w okresie 
odroczenia rażąco narusza porządek prawny lub zasady dyscypliny wojskowej. 

 
 
 
s. 140/146 
 
   
 
2025-04-09 
 
§ 3. Sąd po zapoznaniu się z opinią dowódcy jednostki może zwolnić od kary 
pozbawienia wolności nie przekraczającej 6 miesięcy, jeżeli okres odroczenia trwał co 
najmniej 6 miesięcy, a żołnierz w tym okresie wyróżnił się w wykonywaniu 
obowiązków służbowych albo wykazał się odwagą. 
§ 4. Sąd może zwolnić od kary określonej w § 3, nawet gdy okres odroczenia 
trwał krócej, jeżeli przemawiają za tym szczególnie ważne powody. 
§ 5. Zwolnienie od kary w myśl § 3 lub 4 pociąga za sobą zatarcie skazania 
z mocy prawa; jeżeli wobec skazanego orzeczono grzywnę lub środek karny, zatarcie 
skazania nie może nastąpić przed wykonaniem tej kary lub środka karnego. 
§ 6. Przepisy § 1–5 stosuje się odpowiednio do osoby powołanej do służby 
wojskowej.

***
## Art. 337. {#kk-art-337}

Wobec żołnierza służby zasadniczej, który został skazany, za 
przestępstwo określone w części wojskowej popełnione w czasie tej służby, na 
grzywnę, karę ograniczenia wolności albo pozbawienia wolności nie przekraczającą 
roku, sąd może zarządzić zatarcie skazania po przeniesieniu go do rezerwy, jeżeli kara 
lub orzeczony środek karny zostały wykonane. 
### Rozdział XXXIX Przestępstwa przeciwko obowiązkowi pełnienia służby wojskowej

***
## Art. 338. {#kk-art-338}

§ 1. Żołnierz, który co najmniej dwukrotnie w okresie nie dłuższym 
niż 3 miesiące samowolnie opuszcza swoją jednostkę lub wyznaczone miejsce 
przebywania albo samowolnie poza nimi pozostaje w wymiarze nieprzekraczającym 
jednorazowo 48 godzin, 
podlega karze ograniczenia wolności. 
§ 2. Żołnierz, który samowolnie opuszcza swoją jednostkę lub wyznaczone 
miejsce przebywania albo samowolnie poza nimi pozostaje przez okres powyżej 
48 godzin, nie dłużej jednak niż przez okres 7 dni, 
podlega karze ograniczenia wolności, karze aresztu wojskowego do roku albo 
pozbawienia wolności do roku. 
§ 3. Żołnierz, który samowolnie opuszcza swoją jednostkę lub wyznaczone 
miejsce przebywania albo samowolnie poza nimi pozostaje przez okres powyżej 7 dni, 
podlega karze aresztu wojskowego albo pozbawienia wolności do lat 3. 

 
 
 
s. 141/146 
 
   
 
2025-04-09 
 
§ 4. Ściganie przestępstwa określonego w § 1 i 2 następuje na wniosek dowódcy 
jednostki wojskowej.

***
## Art. 339. {#kk-art-339}

§ 1. Żołnierz, który w celu trwałego uchylenia się od służby wojskowej 
opuszcza swoją jednostkę lub wyznaczone miejsce przebywania lub w takim celu poza 
nimi pozostaje, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Jeżeli sprawca dopuszcza się dezercji wspólnie z innymi żołnierzami lub 
zabierając broń, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 3. Żołnierz, który w czasie dezercji ucieka za granicę albo przebywając za 
granicą uchyla się od powrotu do kraju, 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 4. Żołnierz, który czyni przygotowania do przestępstwa określonego w § 1–3, 
podlega karze aresztu wojskowego albo pozbawienia wolności do lat 2.

***
## Art. 340. {#kk-art-340}

Jeżeli sprawca przestępstwa określonego w art. 339 dobrowolnie 
powrócił, a nieobecność jego trwała nie dłużej niż 14 dni, sąd może zastosować 
nadzwyczajne złagodzenie kary.

***
## Art. 341. {#kk-art-341}

§ 1. Żołnierz, który odmawia pełnienia służby wojskowej albo 
wykonywania obowiązku wynikającego z tej służby, 
podlega karze aresztu wojskowego albo pozbawienia wolności do lat 3. 
§ 2. Tej samej karze podlega żołnierz innej służby niż zasadnicza, który 
uporczywie nie wykonuje obowiązku z niej wynikającego. 
§ 3. Ściganie przestępstwa określonego w § 2 następuje na wniosek dowódcy 
jednostki.

***
## Art. 342. {#kk-art-342}

§ 1. Żołnierz, który w celu zupełnego albo częściowego uchylenia się 
od służby wojskowej albo od wykonania obowiązku wynikającego z tej służby: 
- 1) powoduje u siebie lub dopuszcza, by kto inny spowodował u niego skutek 
określony w art. 156 § 1 lub art. 157 § 1, 
- 2) używa podstępu dla wprowadzenia w błąd organu wojskowego, 
podlega karze aresztu wojskowego albo pozbawienia wolności do lat 3. 
§ 2. W wypadku mniejszej wagi, sprawca 

 
 
 
s. 142/146 
 
   
 
2025-04-09 
 
podlega karze ograniczenia wolności, aresztu wojskowego do roku albo 
pozbawienia wolności do roku. 
### Rozdział XL Przestępstwa przeciwko zasadom dyscypliny wojskowej

***
## Art. 343. {#kk-art-343}

§ 1. Żołnierz, który nie wykonuje lub odmawia wykonania rozkazu 
albo wykonuje rozkaz niezgodnie z jego treścią, 
podlega karze aresztu wojskowego albo pozbawienia wolności do lat 3. 
§ 2. Jeżeli sprawca czynu określonego w § 1 działa wspólnie z innymi 
żołnierzami lub w obecności zebranych żołnierzy albo następstwem czynu 
określonego w § 1 jest znaczna szkoda majątkowa lub inna poważna szkoda, sprawca 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 3. Żołnierz, który wchodzi w porozumienie z innymi żołnierzami w celu 
popełnienia czynu zabronionego określonego w § 1 lub 2, 
podlega karze ograniczenia wolności, aresztu wojskowego albo pozbawienia 
wolności do lat 2. 
§ 4. Ściganie przestępstwa określonego w § 1 lub 3 następuje na wniosek 
dowódcy jednostki.

***
## Art. 344. {#kk-art-344}

§ 1. Nie popełnia przestępstwa określonego w art. 343 żołnierz, który 
odmawia wykonania rozkazu polecającego popełnienie przestępstwa albo nie 
wykonuje go. 
§ 2. W razie wykonania rozkazu, o którym mowa w § 1, niezgodnie z jego 
treścią w celu istotnego zmniejszenia szkodliwości czynu, sąd może zastosować 
nadzwyczajne złagodzenie kary lub odstąpić od jej wymierzenia.

***
## Art. 345. {#kk-art-345}

§ 1. Żołnierz, który dopuszcza się czynnej napaści na przełożonego, 
podlega karze aresztu wojskowego albo pozbawienia wolności do lat 3. 
§ 2. Jeżeli sprawca dopuszcza się czynnej napaści w związku z pełnieniem przez 
przełożonego obowiązków służbowych albo wspólnie z innymi żołnierzami lub 
w obecności zebranych żołnierzy, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 3. Jeżeli sprawca czynu określonego w § 1 lub 2 używa broni, noża lub innego 
podobnie niebezpiecznego przedmiotu, 
podlega karze pozbawienia wolności od roku do lat 10. 

 
 
 
s. 143/146 
 
   
 
2025-04-09 
 
§ 4. Karze przewidzianej w § 3 podlega sprawca czynu określonego w § 1 lub 2, 
jeżeli jego następstwem jest skutek określony w art. 156 lub 157 § 1.

***
## Art. 346. {#kk-art-346}

§ 1. Żołnierz, który stosuje przemoc lub groźbę bezprawną w celu 
przeszkodzenia przełożonemu w czynności służbowej albo w celu zmuszenia 
przełożonego do przedsięwzięcia albo zaniechania czynności służbowej, 
podlega karze aresztu wojskowego albo pozbawienia wolności do lat 3. 
§ 2. Jeżeli sprawca działa wspólnie z innymi żołnierzami lub w obecności 
zebranych żołnierzy, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5.

***
## Art. 347. {#kk-art-347}

§ 1. Żołnierz, który znieważa przełożonego, 
podlega karze ograniczenia wolności, aresztu wojskowego albo pozbawienia 
wolności do lat 2. 
§ 2. Ściganie następuje na wniosek pokrzywdzonego lub dowódcy jednostki.

***
## Art. 348. {#kk-art-348}

Przepisy art. 345–347 stosuje się odpowiednio do żołnierza, który 
dopuszcza się czynu określonego w tych przepisach względem żołnierza niebędącego 
jego przełożonym w związku z pełnieniem przez niego obowiązków służbowych.

***
## Art. 349. {#kk-art-349}

Przepisy tego rozdziału stosuje się odpowiednio, jeżeli czyn 
zabroniony popełniono względem żołnierza państwa sprzymierzonego, a państwo to 
zapewnia wzajemność. 
### Rozdział XLI Przestępstwa przeciwko zasadom postępowania z podwładnymi

***
## Art. 350. {#kk-art-350}

§ 1. Żołnierz, który poniża lub znieważa podwładnego, 
podlega karze ograniczenia wolności, aresztu wojskowego albo pozbawienia 
wolności do lat 2. 
§ 2. Ściganie następuje na wniosek pokrzywdzonego lub dowódcy jednostki.

***
## Art. 351. {#kk-art-351}

Żołnierz, który uderza podwładnego lub w inny sposób narusza jego 
nietykalność cielesną, 
podlega karze aresztu wojskowego albo pozbawienia wolności do lat 2.

***
## Art. 352. {#kk-art-352}

§ 1. Żołnierz, który znęca się fizycznie lub psychicznie nad 
podwładnym, 

 
 
 
s. 144/146 
 
   
 
2025-04-09 
 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. Jeżeli czyn określony w § 1 połączony jest ze stosowaniem szczególnego 
okrucieństwa, sprawca 
podlega karze pozbawienia wolności od roku do lat 10. 
§ 3. Jeżeli następstwem czynu określonego w § 1 lub 2 jest targnięcie się 
pokrzywdzonego na własne życie, sprawca 
podlega karze pozbawienia wolności od lat 2 do 15.

***
## Art. 353. {#kk-art-353}

Przepisy art. 350–352 stosuje się odpowiednio do żołnierza, który 
dopuszcza się czynu określonego w tych przepisach względem żołnierza młodszego 
stopniem albo równego stopniem o krótszym okresie pełnienia służby wojskowej. 
### Rozdział XLII Przestępstwa przeciwko zasadom obchodzenia się z uzbrojeniem i uzbrojonym 
sprzętem wojskowym

***
## Art. 354. {#kk-art-354}

§ 1. Żołnierz, który nieostrożnie obchodzi się z bronią wojskową, 
amunicją, materiałem wybuchowym lub innym środkiem walki albo ich nieostrożnie 
używa i przez to nieumyślnie powoduje naruszenie czynności narządu ciała lub 
rozstrój zdrowia innej osoby, 
podlega karze aresztu wojskowego albo pozbawienia wolności do lat 3. 
§ 2. Jeżeli następstwem czynu określonego w § 1 jest śmierć innej osoby lub 
ciężki uszczerbek na jej zdrowiu, sprawca 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8.

***
## Art. 355. {#kk-art-355}

§ 1. Żołnierz, który prowadząc uzbrojony pojazd mechaniczny, 
narusza chociażby nieumyślnie zasady bezpieczeństwa w ruchu lądowym, wodnym 
lub powietrznym i powoduje nieumyślnie wypadek, w którym inna osoba odniosła 
obrażenia ciała określone w art. 157 § 1 lub wyrządzona została znaczna szkoda 
w mieniu, 
podlega karze aresztu wojskowego albo pozbawienia wolności do lat 3. 
§ 2. Jeżeli następstwem wypadku określonego w § 1 jest śmierć innej osoby lub 
ciężki uszczerbek na jej zdrowiu, sprawca 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8. 
§ 3. Przepisy art. 42 i 178 stosuje się odpowiednio. 

 
 
 
s. 145/146 
 
   
 
2025-04-09 
### Rozdział XLIII Przestępstwa przeciwko zasadom pełnienia służby

***
## Art. 356. {#kk-art-356}

§ 1. Żołnierz, który, po wyznaczeniu go do służby lub będąc w służbie, 
narusza obowiązek wynikający z przepisu lub zarządzenia regulującego tok tej służby, 
przez co stwarza bezpośrednie niebezpieczeństwo powstania szkody, której 
wyznaczona służba miała zapobiec, 
podlega karze ograniczenia wolności, aresztu wojskowego albo pozbawienia 
wolności do lat 3. 
§ 2. Jeżeli następstwem czynu jest szkoda, o której mowa w § 1, sprawca 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 3. Ściganie przestępstwa określonego w § 1 następuje na wniosek dowódcy 
jednostki.

***
## Art. 357. {#kk-art-357}

§ 1. Żołnierz, który, po wyznaczeniu do służby lub będąc w służbie, 
wprawia się w stan nietrzeźwości lub odurzenia innym środkiem, 
podlega karze ograniczenia wolności, aresztu wojskowego albo pozbawienia 
wolności do lat 2. 
§ 2. Ściganie następuje na wniosek dowódcy jednostki. 
### Rozdział XLIV Przestępstwa przeciwko mieniu wojskowemu

***
## Art. 358. {#kk-art-358}

§ 1. Żołnierz, który samowolnie dysponuje bronią, amunicją, 
materiałem wybuchowym lub innym środkiem walki, 
podlega karze aresztu wojskowego albo pozbawienia wolności do lat 3. 
§ 2. Żołnierz, który samowolnie zabiera broń, amunicję, materiał wybuchowy 
lub inny środek walki, 
podlega karze pozbawienia wolności od roku do lat 10.

***
## Art. 359. {#kk-art-359}

Żołnierz, który, nie dopełniając obowiązku lub przekraczając 
uprawnienia w zakresie ochrony lub nadzoru nad bronią, amunicją, materiałem 
wybuchowym lub innym środkiem walki, powoduje choćby nieumyślnie ich utratę, 
podlega karze aresztu wojskowego albo pozbawienia wolności od 3 miesięcy do 
lat 5. 

 
 
 
s. 146/146 
 
   
 
2025-04-09

***
## Art. 360. {#kk-art-360}

§ 1. Żołnierz, który broń, amunicję, materiał wybuchowy lub inny 
środek walki niszczy, uszkadza lub czyni niezdatnym do użytku, 
podlega grzywnie, karze ograniczenia wolności, aresztu wojskowego albo 
pozbawienia wolności do lat 2. 
§ 2. Jeżeli sprawca czynu określonego w § 1 powoduje przez to znaczną szkodę 
w mieniu, 
podlega karze pozbawienia wolności od 6 miesięcy do lat 8.

***
## Art. 361. {#kk-art-361}

§ 1. Żołnierz, który samowolnie używa wojskowego statku 
powietrznego lub wodnego dla celu niemającego związku ze służbą, 
podlega karze pozbawienia wolności od 3 miesięcy do lat 5. 
§ 2. W wypadku mniejszej wagi, sprawca 
podlega grzywnie, karze ograniczenia wolności, aresztu wojskowego albo 
pozbawienia wolności do roku.

***
## Art. 362. {#kk-art-362}

§ 1. Żołnierz, który samowolnie używa wojskowego pojazdu 
mechanicznego z uszczerbkiem dla interesów służby lub w celu osiągnięcia korzyści 
majątkowej, 
podlega grzywnie, karze ograniczenia wolności, aresztu wojskowego albo 
pozbawienia wolności do lat 2. 
§ 2. W wypadku mniejszej wagi, sprawca 
podlega grzywnie albo karze ograniczenia wolności.

***
## Art. 363. {#kk-art-363}

§ 1. Żołnierz, który samowolnie rozporządza przedmiotem swojego 
wyposażenia, w szczególności przedmiot taki zbywa, zastawia lub go użycza innej 
osobie, 
podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do 
lat 2. 
§ 2. Ściganie następuje na wniosek dowódcy jednostki.

