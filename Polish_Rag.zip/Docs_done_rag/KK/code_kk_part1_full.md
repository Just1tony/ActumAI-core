---
id: code.kk.part1
title: "Kodeks karny – Część ogólna (Art. 1–116)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1997 nr 88 poz. 553"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KK – Część ogólna"]
tags: ["KK","kodeks karny","część ogólna","odpowiedzialność karna","kary","PL"]
source_pdf: "D19970553Lj.pdf"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kk-art-{n}}"
  separators: "***"
  hierarchy: ["Część","Dział","Rozdział"]
---

# Kodeks karny – Część ogólna

CZĘŚĆ OGÓLNA 
### Rozdział I Zasady odpowiedzialności karnej
***
## Art. 1. {#kk-art-1}

§ 1. Odpowiedzialności karnej podlega ten tylko, kto popełnia czyn 
zabroniony pod groźbą kary przez ustawę obowiązującą w czasie jego popełnienia. 
§ 2. Nie stanowi przestępstwa czyn zabroniony, którego społeczna szkodliwość 
jest znikoma. 
§ 3. Nie popełnia przestępstwa sprawca czynu zabronionego, jeżeli nie można 
mu przypisać winy w czasie czynu.

***
## Art. 2. {#kk-art-2}

Odpowiedzialności karnej za przestępstwo skutkowe popełnione przez 
zaniechanie podlega ten tylko, na kim ciążył prawny, szczególny obowiązek 
zapobiegnięcia skutkowi. 
- 1) Niniejsza ustawa w zakresie swojej regulacji realizuje postanowienia:  
- 1) dyrektywy Parlamentu Europejskiego i Rady (UE) 2018/1673 z dnia 23 października 2018 r. w 
sprawie zwalczania prania pieniędzy za pomocą środków prawnokarnych (Dz. Urz. UE L 284 z 
12.11.2018, str. 22);  
- 2) dyrektywy Parlamentu Europejskiego i Rady (UE) 2019/713 z dnia 17 kwietnia 2019 r. w 
sprawie zwalczania fałszowania i oszustw związanych z bezgotówkowymi środkami 
płatniczymi, zastępującej decyzję ramową Rady 2001/413/WSiSW (Dz. Urz. UE L 123 z 
10.05.2019, str. 18);  
- 3) dyrektywy Parlamentu Europejskiego i Rady 2011/93/UE z dnia 13 grudnia 2011 r. w sprawie 
zwalczania niegodziwego traktowania w celach seksualnych i wykorzystywania seksualnego 
dzieci oraz pornografii dziecięcej, zastępującej decyzję ramową Rady 2004/68/WSiSW (Dz. 
Urz. UE L 335 z 17.12.2011, str. 1 oraz Dz. Urz. UE L 18 z 21.01.2012, str. 7). 
Opracowano na 
podstawie: 
t.j. 
Dz. U. z 2025 r. 
poz. 383. 

 
 
 
s. 2/146 
 
   
 
2025-04-09

***
## Art. 3. {#kk-art-3}

Kary oraz inne środki przewidziane w tym kodeksie stosuje się 
z uwzględnieniem 
zasad 
humanitaryzmu, 
w szczególności 
z poszanowaniem 
godności człowieka.

***
## Art. 4. {#kk-art-4}

§ 1. Jeżeli w czasie orzekania obowiązuje ustawa inna niż w czasie 
popełnienia przestępstwa, stosuje się ustawę nową, jednakże należy stosować ustawę 
obowiązującą poprzednio, jeżeli jest względniejsza dla sprawcy. 
§ 2. Jeżeli według nowej ustawy za czyn objęty wyrokiem nie można orzec kary 
w wysokości kary orzeczonej, wymierzoną karę obniża się do wysokości najsurowszej 
kary możliwej do orzeczenia na podstawie nowej ustawy. 
§ 3. Jeżeli według nowej ustawy czyn objęty wyrokiem nie jest już zagrożony 
karą pozbawienia wolności, wymierzoną karę pozbawienia wolności podlegającą 
wykonaniu zamienia się na grzywnę albo karę ograniczenia wolności, przyjmując że 
jeden miesiąc pozbawienia wolności równa się 60 stawkom dziennym grzywny albo 
2 miesiącom ograniczenia wolności. 
§ 4. Jeżeli według nowej ustawy czyn objęty wyrokiem nie jest już zabroniony 
pod groźbą kary, skazanie ulega zatarciu z mocy prawa.

***
## Art. 5. {#kk-art-5}

Ustawę karną polską stosuje się do sprawcy, który popełnił czyn 
zabroniony na terytorium Rzeczypospolitej Polskiej, jak również na polskim statku 
wodnym lub powietrznym, chyba że umowa międzynarodowa, której Rzeczpospolita 
Polska jest stroną, stanowi inaczej.

***
## Art. 6. {#kk-art-6}

§ 1. Czyn zabroniony uważa się za popełniony w czasie, w którym 
sprawca działał lub zaniechał działania, do którego był obowiązany. 
§ 2. Czyn zabroniony uważa się za popełniony w miejscu, w którym sprawca 
działał lub zaniechał działania, do którego był obowiązany, albo gdzie skutek 
stanowiący znamię czynu zabronionego nastąpił lub według zamiaru sprawcy miał 
nastąpić.

***
## Art. 7. {#kk-art-7}

§ 1. Przestępstwo jest zbrodnią albo występkiem. 
§ 2. Zbrodnią jest czyn zabroniony zagrożony karą pozbawienia wolności na czas 
nie krótszy od lat 3 albo karą surowszą. 
§ 3. Występkiem jest czyn zabroniony zagrożony grzywną powyżej 30 stawek 
dziennych albo powyżej 5000 złotych, karą ograniczenia wolności przekraczającą 
miesiąc albo karą pozbawienia wolności przekraczającą miesiąc. 

 
 
 
s. 3/146 
 
   
 
2025-04-09

***
## Art. 8. {#kk-art-8}

Zbrodnię można popełnić tylko umyślnie; występek można popełnić 
także nieumyślnie, jeżeli ustawa tak stanowi.

***
## Art. 9. {#kk-art-9}

§ 1. Czyn zabroniony popełniony jest umyślnie, jeżeli sprawca ma zamiar 
jego popełnienia, to jest chce go popełnić albo przewidując możliwość jego 
popełnienia, na to się godzi. 
§ 2. Czyn zabroniony popełniony jest nieumyślnie, jeżeli sprawca nie mając 
zamiaru jego popełnienia, popełnia go jednak na skutek niezachowania ostrożności 
wymaganej w danych okolicznościach, mimo że możliwość popełnienia tego czynu 
przewidywał albo mógł przewidzieć. 
§ 3. Sprawca ponosi surowszą odpowiedzialność, którą ustawa uzależnia od 
określonego następstwa czynu zabronionego, jeżeli następstwo to przewidywał albo 
mógł przewidzieć.

***
## Art. 10. {#kk-art-10}

§ 1. Na zasadach określonych w tym kodeksie odpowiada ten, kto 
popełnia czyn zabroniony po ukończeniu 17 lat. 
§ 2. Nieletni, który po ukończeniu 15 lat dopuszcza się czynu zabronionego 
określonego w art. 134, art. 148 § 1, 2 lub 3, art. 156 § 1 lub 3, art. 163 § 1 lub 3, art. 
166, art. 173 § 1 lub 3, art. 197 § 1, 1a, 3, 4 lub 5, art. 223 § 2, art. 252 § 1 lub 2 oraz 
w art. 280, może odpowiadać na zasadach określonych w tym kodeksie, jeżeli 
okoliczności sprawy oraz stopień rozwoju sprawcy, jego właściwości i warunki 
osobiste za tym przemawiają, a w szczególności, jeżeli poprzednio stosowane środki 
wychowawcze lub poprawcze okazały się bezskuteczne. 
§ 2a. Nieletni, który po ukończeniu 14 lat, a przed ukończeniem 15 lat, dopuszcza 
się czynu zabronionego określonego w art. 148 § 2 lub 3, może odpowiadać na 
zasadach określonych w tym kodeksie, jeżeli okoliczności sprawy oraz stopień 
rozwoju sprawcy, jego właściwości i warunki osobiste za tym przemawiają oraz 
zachodzi uzasadnione przypuszczenie, że stosowanie środków wychowawczych lub 
poprawczych nie jest w stanie zapewnić resocjalizacji nieletniego. 
§ 3. W wypadku określonym w § 2 orzeczona kara nie może przekroczyć dwóch 
trzecich górnej granicy ustawowego zagrożenia przewidzianego za przypisane 
sprawcy przestępstwo, które nie jest zagrożone karą dożywotniego pozbawienia 
wolności. W wypadkach określonych w § 2 i 2a sąd może zastosować nadzwyczajne 
złagodzenie kary. 

 
 
 
s. 4/146 
 
   
 
2025-04-09 
 
§ 4. W stosunku do sprawcy, który popełnił występek po ukończeniu lat 17, lecz 
przed ukończeniem lat 18, sąd zamiast kary stosuje środki wychowawcze, lecznicze 
albo poprawcze przewidziane dla nieletnich, jeżeli okoliczności sprawy oraz stopień 
rozwoju sprawcy, jego właściwości i warunki osobiste za tym przemawiają.

***
## Art. 11. {#kk-art-11}

§ 1. Ten sam czyn może stanowić tylko jedno przestępstwo. 
§ 2. Jeżeli czyn wyczerpuje znamiona określone w dwóch albo więcej przepisach 
ustawy karnej, sąd skazuje za jedno przestępstwo na podstawie wszystkich 
zbiegających się przepisów. 
§ 3. W wypadku określonym w § 2 sąd wymierza karę na podstawie przepisu 
przewidującego karę najsurowszą, co nie stoi na przeszkodzie orzeczeniu innych 
środków przewidzianych w ustawie na podstawie wszystkich zbiegających się prze-
pisów.

***
## Art. 12. {#kk-art-12}

§ 1. Dwa lub więcej zachowań, podjętych w krótkich odstępach czasu 
w wykonaniu z góry powziętego zamiaru, uważa się za jeden czyn zabroniony; jeżeli 
przedmiotem zamachu jest dobro osobiste, warunkiem uznania wielości zachowań za 
jeden czyn zabroniony jest tożsamość pokrzywdzonego. 
§ 2. Odpowiada jak za jeden czyn zabroniony wyczerpujący znamiona 
przestępstwa ten, kto w krótkich odstępach czasu, przy wykorzystaniu tej samej albo 
takiej samej sposobności lub w podobny sposób popełnia dwa lub więcej umyślnych 
wykroczeń 
przeciwko 
mieniu, 
jeżeli 
łączna 
wartość 
mienia 
uzasadnia 
odpowiedzialność za przestępstwo. 
### Rozdział II Formy popełnienia przestępstwa

***
## Art. 13. {#kk-art-13}

§ 1. Odpowiada za usiłowanie, kto w zamiarze popełnienia czynu 
zabronionego swoim zachowaniem bezpośrednio zmierza do jego dokonania, które 
jednak nie następuje. 
§ 2. Usiłowanie zachodzi także wtedy, gdy sprawca nie uświadamia sobie, że 
dokonanie jest niemożliwe ze względu na brak przedmiotu nadającego się do 
popełnienia na nim czynu zabronionego lub ze względu na użycie środka nie 
nadającego się do popełnienia czynu zabronionego. 

 
 
 
s. 5/146 
 
   
 
2025-04-09

***
## Art. 14. {#kk-art-14}

§ 1. Sąd wymierza karę za usiłowanie w granicach zagrożenia 
przewidzianego dla danego przestępstwa. 
§ 2. W wypadku określonym w art. 13 § 2 sąd może zastosować nadzwyczajne 
złagodzenie kary, a nawet odstąpić od jej wymierzenia.

***
## Art. 15. {#kk-art-15}

§ 1. Nie podlega karze za usiłowanie, kto dobrowolnie odstąpił od 
dokonania lub zapobiegł skutkowi stanowiącemu znamię czynu zabronionego. 
§ 2. Sąd może zastosować nadzwyczajne złagodzenie kary w stosunku do 
sprawcy, który dobrowolnie starał się zapobiec skutkowi stanowiącemu znamię czynu 
zabronionego.

***
## Art. 16. {#kk-art-16}

§ 1. Przygotowanie zachodzi tylko wtedy, gdy sprawca w celu 
popełnienia czynu zabronionego podejmuje czynności mające stworzyć warunki do 
przedsięwzięcia czynu zmierzającego bezpośrednio do jego dokonania, w 
szczególności w tymże celu wchodzi w porozumienie z inną osobą, uzyskuje lub 
przysposabia środki, zbiera informacje lub sporządza plan działania. 
§ 2. Przygotowanie jest karalne tylko wtedy, gdy ustawa tak stanowi.

***
## Art. 17. {#kk-art-17}

§ 1. Nie podlega karze za przygotowanie, kto dobrowolnie od niego 
odstąpił, w szczególności zniszczył przygotowane środki lub zapobiegł skorzystaniu 
z nich w przyszłości; w razie wejścia w porozumienie z inną osobą w celu popełnienia 
czynu zabronionego, nie podlega karze ten, kto nadto podjął istotne starania 
zmierzające do zapobieżenia dokonaniu. 
§ 2. Nie podlega karze za przygotowanie osoba, do której stosuje się art. 15 § 1.

***
## Art. 18. {#kk-art-18}

§ 1. Odpowiada za sprawstwo nie tylko ten, kto wykonuje czyn 
zabroniony sam albo wspólnie i w porozumieniu z inną osobą, ale także ten, kto 
kieruje wykonaniem czynu zabronionego przez inną osobę lub wykorzystując 
uzależnienie innej osoby od siebie, poleca jej wykonanie takiego czynu. 
§ 2. Odpowiada za podżeganie, kto chcąc, aby inna osoba dokonała czynu 
zabronionego, nakłania ją do tego. 
§ 3. Odpowiada za pomocnictwo, kto w zamiarze, aby inna osoba dokonała 
czynu zabronionego, swoim zachowaniem ułatwia jego popełnienie, w szczególności 
dostarczając narzędzie, środek przewozu, udzielając rady lub informacji; odpowiada 
za pomocnictwo także ten, kto wbrew prawnemu, szczególnemu obowiązkowi 

 
 
 
s. 6/146 
 
   
 
2025-04-09 
 
niedopuszczenia do popełnienia czynu zabronionego swoim zaniechaniem ułatwia 
innej osobie jego popełnienie.

***
## Art. 19. {#kk-art-19}

§ 1. Sąd wymierza karę za podżeganie lub pomocnictwo w granicach 
zagrożenia przewidzianego za sprawstwo. 
§ 2. Wymierzając karę za pomocnictwo sąd może zastosować nadzwyczajne 
złagodzenie kary.

***
## Art. 20. {#kk-art-20}

Każdy ze współdziałających w popełnieniu czynu zabronionego 
odpowiada w granicach swojej umyślności lub nieumyślności niezależnie od 
odpowiedzialności pozostałych współdziałających.

***
## Art. 21. {#kk-art-21}

§ 1. Okoliczności osobiste, wyłączające lub łagodzące albo zaostrzające 
odpowiedzialność karną, uwzględnia się tylko co do osoby, której dotyczą. 
§ 2. Jeżeli okoliczność osobista dotycząca sprawcy, wpływająca chociażby tylko 
na wyższą karalność, stanowi znamię czynu zabronionego, współdziałający podlega 
odpowiedzialności karnej przewidzianej za ten czyn zabroniony, gdy o tej 
okoliczności wiedział, chociażby go nie dotyczyła. 
§ 3. Wobec współdziałającego, którego nie dotyczy okoliczność określona w § 2, 
sąd może zastosować nadzwyczajne złagodzenie kary.

***
## Art. 22. {#kk-art-22}

§ 1. Jeżeli czynu zabronionego tylko usiłowano dokonać, podmiot 
określony w art. 18 § 2 i 3 odpowiada jak za usiłowanie. 
§ 2. Jeżeli czynu zabronionego nie usiłowano dokonać, sąd może zastosować 
nadzwyczajne złagodzenie kary, a nawet odstąpić od jej wymierzenia.

***
## Art. 23. {#kk-art-23}

§ 1. Nie podlega karze współdziałający, który dobrowolnie zapobiegł 
dokonaniu czynu zabronionego. 
§ 2. Sąd może zastosować nadzwyczajne złagodzenie kary w stosunku do 
współdziałającego, który dobrowolnie starał się zapobiec dokonaniu czynu 
zabronionego.

***
## Art. 24. {#kk-art-24}

Odpowiada jak za podżeganie, kto w celu skierowania przeciwko innej 
osobie postępowania karnego nakłania ją do popełnienia czynu zabronionego; w tym 
wypadku nie stosuje się art. 22 i 23. 

 
 
 
s. 7/146 
 
   
 
2025-04-09 
### Rozdział III Wyłączenie odpowiedzialności karnej

***
## Art. 25. {#kk-art-25}

§ 1. Nie popełnia przestępstwa, kto w obronie koniecznej odpiera 
bezpośredni, bezprawny zamach na jakiekolwiek dobro chronione prawem. 
§ 2. W razie przekroczenia granic obrony koniecznej, w szczególności gdy 
sprawca zastosował sposób obrony niewspółmierny do niebezpieczeństwa zamachu, 
sąd może zastosować nadzwyczajne złagodzenie kary, a nawet odstąpić od jej 
wymierzenia. 
§ 2a. Nie podlega karze, kto przekracza granice obrony koniecznej, odpierając 
zamach polegający na wdarciu się do mieszkania, lokalu, domu albo na przylegający 
do nich ogrodzony teren lub odpierając zamach poprzedzony wdarciem się do tych 
miejsc, chyba że przekroczenie granic obrony koniecznej było rażące. 
§ 3. Nie podlega karze, kto przekracza granice obrony koniecznej pod wpływem 
strachu lub wzburzenia usprawiedliwionych okolicznościami zamachu. 
§ 4. (uchylony) 
§ 5. (uchylony)

***
## Art. 26. {#kk-art-26}

§ 1. Nie popełnia przestępstwa, kto działa w celu uchylenia 
bezpośredniego niebezpieczeństwa grożącego jakiemukolwiek dobru chronionemu 
prawem, jeżeli niebezpieczeństwa nie można inaczej uniknąć, a dobro poświęcone 
przedstawia wartość niższą od dobra ratowanego. 
§ 2. Nie popełnia przestępstwa także ten, kto, ratując dobro chronione prawem 
w warunkach określonych w § 1, poświęca dobro, które nie przedstawia wartości 
oczywiście wyższej od dobra ratowanego. 
§ 3. W razie przekroczenia granic stanu wyższej konieczności, sąd może 
zastosować nadzwyczajne złagodzenie kary, a nawet odstąpić od jej wymierzenia. 
§ 4. Przepisu § 2 nie stosuje się, jeżeli sprawca poświęca dobro, które ma 
szczególny obowiązek chronić nawet z na- 
rażeniem się na niebezpieczeństwo osobiste. 
§ 5. Przepisy § 1–3 stosuje się odpowiednio w wypadku, gdy z ciążących na 
sprawcy obowiązków tylko jeden może być spełniony.

***
## Art. 27. {#kk-art-27}

§ 1. Nie popełnia przestępstwa, kto działa w celu przeprowadzenia 
eksperymentu poznawczego, medycznego, technicznego lub ekonomicznego, jeżeli 

 
 
 
s. 8/146 
 
   
 
2025-04-09 
 
spodziewana korzyść ma istotne znaczenie poznawcze, medyczne lub gospodarcze, 
a oczekiwanie jej osiągnięcia, celowość oraz sposób przeprowadzenia eksperymentu 
są zasadne w świetle aktualnego stanu wiedzy. 
§ 2. Eksperyment jest niedopuszczalny bez zgody uczestnika, na którym jest 
przeprowadzany, 
należycie 
poinformowanego 
o spodziewanych 
korzyściach 
i grożących mu ujemnych skutkach oraz prawdopodobieństwie ich powstania, jak 
również o możliwości odstąpienia od udziału w eksperymencie na każdym jego etapie. 
§ 3. Zasady i warunki dopuszczalności eksperymentu medycznego określa 
ustawa.

***
## Art. 28. {#kk-art-28}

§ 1. Nie popełnia przestępstwa, kto pozostaje w usprawiedliwionym 
błędzie co do okoliczności stanowiącej znamię czynu zabronionego. 
§ 2. Odpowiada 
na 
podstawie 
przepisu 
przewidującego 
łagodniejszą 
odpowiedzialność sprawca, który dopuszcza się czynu w usprawiedliwionym błędnym 
przekonaniu, że zachodzi okoliczność stanowiąca znamię czynu zabronionego, od 
której taka łagodniejsza odpowiedzialność zależy.

***
## Art. 29. {#kk-art-29}

Nie popełnia przestępstwa, kto dopuszcza się czynu zabronionego 
w usprawiedliwionym błędnym przekonaniu, że zachodzi okoliczność wyłączająca 
bezprawność albo winę; jeżeli błąd sprawcy jest nieusprawiedliwiony, sąd może 
zastosować nadzwyczajne złagodzenie kary.

***
## Art. 30. {#kk-art-30}

Nie popełnia przestępstwa, kto dopuszcza się czynu zabronionego 
w usprawiedliwionej nieświadomości jego bezprawności; jeżeli błąd sprawcy jest 
nieusprawiedliwiony, sąd może zastosować nadzwyczajne złagodzenie kary.

***
## Art. 31. {#kk-art-31}

§ 1. Nie popełnia przestępstwa, kto, z powodu choroby psychicznej, 
upośledzenia umysłowego lub innego zakłócenia czynności psychicznych, nie mógł 
w czasie czynu rozpoznać jego znaczenia lub pokierować swoim postępowaniem. 
§ 2. Jeżeli w czasie popełnienia przestępstwa zdolność rozpoznania znaczenia 
czynu lub kierowania postępowaniem była w znacznym stopniu ograniczona, sąd 
może zastosować nadzwyczajne złagodzenie kary. 
§ 3. Przepisów § 1 i 2 nie stosuje się, gdy sprawca wprawił się w stan 
nietrzeźwości lub odurzenia powodujący wyłączenie lub ograniczenie poczytalności, 
które przewidywał albo mógł przewidzieć. 

 
 
 
s. 9/146 
 
   
 
2025-04-09 
### Rozdział IV Kary

***
## Art. 32. {#kk-art-32}

Karami są: 
- 1) grzywna; 
- 2) ograniczenie wolności; 
- 3) pozbawienie wolności; 
- 4) (uchylony) 
- 5) dożywotnie pozbawienie wolności.

***
## Art. 33. {#kk-art-33}

§ 1. Grzywnę wymierza się w stawkach dziennych, określając liczbę 
stawek oraz wysokość jednej stawki;  
jeżeli ustawa nie stanowi inaczej, najniższa liczba stawek wynosi 10, zaś 
najwyższa 540. 
§ 1a. Jeżeli ustawa nie stanowi inaczej, a przestępstwo jest zagrożone zarówno 
grzywną, jak i karą pozbawienia wolności, grzywnę wymierza się w wysokości nie 
niższej od:  
- 1) 50 stawek – w przypadku czynu zagrożonego karą pozbawienia wolności 
nieprzekraczającą roku;  
- 2) 100 stawek – w przypadku czynu zagrożonego karą pozbawienia wolności 
nieprzekraczającą 2 lat;  
- 3) 150 stawek – w przypadku czynu zagrożonego karą pozbawienia wolności 
przekraczającą 2 lata. 
§ 2. Sąd może wymierzyć grzywnę także obok kary pozbawienia wolności 
wymienionej w art. 32 pkt 3, jeżeli sprawca dopuścił się czynu w celu osiągnięcia 
korzyści majątkowej lub gdy korzyść majątkową osiągnął. 
§ 2a. Przepis § 1a stosuje się również do grzywny wymierzanej obok kary 
pozbawienia wolności. 
§ 3. Ustalając stawkę dzienną, sąd bierze pod uwagę dochody sprawcy, jego 
warunki osobiste, rodzinne, stosunki majątkowe i możliwości zarobkowe; stawka 
dzienna nie może być niższa od 10 złotych, ani też przekraczać 2000 złotych.

***
## Art. 34. {#kk-art-34}

§ 1. Jeżeli ustawa nie stanowi inaczej, kara ograniczenia wolności trwa 
najkrócej miesiąc, najdłużej 2 lata; wymierza się ją w miesiącach i latach. 
§ 1a. Kara ograniczenia wolności polega na: 

 
 
 
s. 10/146 
 
   
 
2025-04-09 
- 1) obowiązku wykonywania nieodpłatnej, kontrolowanej pracy na cele społeczne; 
- 2) (uchylony) 
- 3) (uchylony) 
- 4) potrąceniu od 10 % do 25 % wynagrodzenia za pracę w stosunku miesięcznym 
na cel społeczny wskazany przez sąd. 
§ 1aa. Jeżeli ustawa nie stanowi inaczej, a przestępstwo jest zagrożone zarówno 
karą ograniczenia wolności, jak i karą pozbawienia wolności, karę ograniczenia 
wolności wymierza się w wysokości nie niższej od:  
- 1) 2 miesięcy – w przypadku czynu zagrożonego karą pozbawienia wolności 
nieprzekraczającą roku;  
- 2) 3 miesięcy – w przypadku czynu zagrożonego karą pozbawienia wolności 
nieprzekraczającą 2 lat; 
- 3) 4 miesięcy – w przypadku czynu zagrożonego karą pozbawienia wolności 
przekraczającą 2 lata. 
§ 1b. Obowiązki i potrącenie, o których mowa w § 1a, orzeka się łącznie lub 
osobno. 
§ 2. W czasie odbywania kary ograniczenia wolności skazany: 
- 1) nie może bez zgody sądu zmieniać miejsca stałego pobytu; 
- 2) (uchylony) 
- 3) ma obowiązek udzielania wyjaśnień dotyczących przebiegu odbywania kary. 
§ 3. Wymierzając karę ograniczenia wolności, sąd może orzec świadczenie 
pieniężne 
wymienione 
w art. 39 pkt 7 
lub 
obowiązki, 
o których 
mowa 
w art. 72 § 1 pkt 2–7a.

***
## Art. 35. {#kk-art-35}

§ 1. Nieodpłatna, kontrolowana praca na cele społeczne jest 
wykonywana w wymiarze od 20 do 40 godzin w stosunku miesięcznym. 
§ 2. Potrącenie wynagrodzenia za pracę może być orzeczone wobec osoby 
zatrudnionej; w okresie, na jaki zostało orzeczone potrącenie, skazany nie może 
rozwiązać bez zgody sądu stosunku pracy. 
§ 3. (uchylony) 
§ 4. Do orzekania świadczenia pieniężnego wymienionego w art. 39 pkt 7 oraz 
obowiązków, o których mowa w art. 72 § 1 pkt 2–7a, przepis art. 74 stosuje się 
odpowiednio. 

 
 
 
s. 11/146 
 
   
 
2025-04-09

***
## Art. 36. {#kk-art-36}

§ 1. (uchylony) 
§ 2. (uchylony) 
§ 3. (uchylony)

***
## Art. 37. {#kk-art-37}

Kara pozbawienia wolności wymieniona w art. 32 pkt 3 trwa najkrócej 
miesiąc, najdłużej 30 lat; wymierza się ją w miesiącach i latach. 
Art. 37a. § 1. Jeżeli przestępstwo jest zagrożone tylko karą pozbawienia 
wolności nieprzekraczającą 8 lat, a wymierzona za nie kara pozbawienia wolności nie 
byłaby surowsza od roku, sąd może zamiast tej kary orzec karę ograniczenia wolności 
nie niższą od 4 miesięcy albo grzywnę nie niższą od 150 stawek dziennych, w 
szczególności jeżeli równocześnie orzeka środek karny, środek kompensacyjny lub 
przepadek.  
§ 2. Przepisu § 1 nie stosuje się do sprawców określonych w art. 64 § 1 lub do 
sprawców, którzy popełniają przestępstwo działając w zorganizowanej grupie albo 
związku mających na celu popełnienie przestępstwa lub przestępstwa skarbowego, 
sprawców przestępstw o charakterze terrorystycznym i sprawców przestępstwa 
określonego w art. 178a § 4. 
Art. 37b. W sprawie o występek zagrożony karą pozbawienia wolności, 
niezależnie od dolnej granicy ustawowego zagrożenia przewidzianego w ustawie za 
dany czyn, sąd może orzec jednocześnie karę pozbawienia wolności w wymiarze 
nieprzekraczającym 3 miesięcy, a jeżeli górna granica ustawowego zagrożenia wynosi 
przynajmniej 10 lat – 6 miesięcy, oraz karę ograniczenia wolności do lat 2. Przepisów 
art. 69–75 nie stosuje się. W pierwszej kolejności wykonuje się wówczas karę 
pozbawienia wolności, chyba że ustawa stanowi inaczej.

***
## Art. 38. {#kk-art-38}

§ 1. Jeżeli ustawa przewiduje obniżenie albo nadzwyczajne obostrzenie 
górnej granicy ustawowego zagrożenia, a ustawowe zagrożenie obejmuje więcej niż 
jedną z kar wymienionych w art. 32 pkt 1–3, obniżenie albo obostrzenie odnosi się do 
każdej z tych kar. 
§ 2. Kara nadzwyczajnie obostrzona nie może przekroczyć 810 stawek dziennych 
grzywny, 2 lat ograniczenia wolności lub 30 lat pozbawienia wolności. 
§ 3. Jeżeli ustawa przewiduje obniżenie górnej granicy ustawowego zagrożenia, 
kara wymierzona za przestępstwo zagrożone karą dożywotniego pozbawienia 
wolności nie może przekroczyć 30 lat pozbawienia wolności. 

 
 
 
s. 12/146 
 
   
 
2025-04-09 
### Rozdział V Środki karne

***
## Art. 39. {#kk-art-39}

Środkami karnymi są: 
- 1) pozbawienie praw publicznych; 
- 2) zakaz zajmowania określonego stanowiska, wykonywania określonego zawodu 
lub prowadzenia określonej działalności gospodarczej; 
2a) zakaz prowadzenia działalności związanej z wychowaniem, leczeniem, edukacją 
małoletnich lub z opieką nad nimi; 
2aa) zakaz zajmowania stanowiska lub wykonywania zawodu lub pracy w organach 
i instytucjach państwowych i samorządu terytorialnego, a także w spółkach 
prawa handlowego, w których Skarb Państwa lub jednostka samorządu 
terytorialnego posiadają bezpośrednio lub pośrednio przez inne podmioty co 
najmniej 10 % akcji lub udziałów; 
2b) zakaz przebywania w określonych środowiskach lub miejscach, kontaktowania 
się z określonymi osobami, zbliżania się do określonych osób lub opuszczania 
określonego miejsca pobytu bez zgody sądu; 
2c) zakaz wstępu na imprezę masową; 
2d) zakaz wstępu do ośrodków gier i uczestnictwa w grach hazardowych; 
2e) nakaz 
okresowego 
opuszczenia 
lokalu 
zajmowanego 
wspólnie 
z pokrzywdzonym; 
- 3) zakaz prowadzenia pojazdów; 
- 4) (uchylony) 
- 5) (uchylony) 
- 6) (uchylony) 
- 7) świadczenie pieniężne; 
- 8) podanie wyroku do publicznej wiadomości; 
- 9) degradacja.

***
## Art. 40. {#kk-art-40}

§ 1. Pozbawienie praw publicznych obejmuje utratę czynnego 
i biernego prawa wyborczego do organu władzy publicznej, organu samorządu 
zawodowego lub gospodarczego, utratę prawa do udziału w sprawowaniu wymiaru 
sprawiedliwości oraz do pełnienia funkcji w organach i instytucjach państwowych 
i samorządu terytorialnego lub zawodowego, jak również utratę posiadanego stopnia 

 
 
 
s. 13/146 
 
   
 
2025-04-09 
 
wojskowego i powrót do stopnia szeregowego; pozbawienie praw publicznych 
obejmuje ponadto utratę orderów, odznaczeń i tytułów honorowych oraz utratę 
zdolności do ich uzyskania w okresie trwania pozbawienia praw. 
§ 2. Sąd może orzec pozbawienie praw publicznych w razie skazania: 
- 1) na karę pozbawienia wolności na czas nie krótszy od lat 3 za przestępstwo 
popełnione w wyniku motywacji zasługującej na szczególne potępienie; 
- 2) za przestępstwa określone w art. 228 § 1 i 3–6, art. 229 § 1 i 3–5, art. 230 § 1, 
art. 230a § 1, art. 250a § 1 i 2, art. 271 § 3, art. 296a § 1, 2 i 4, art. 305 § 1–4 oraz 
art. 306b. 
§ 3. Sąd orzeka pozbawienie praw publicznych w razie skazania za przestępstwa 
określone w art. 130 § 1–5 lub 7–9.

***
## Art. 41. {#kk-art-41}

§ 1. Sąd może orzec zakaz zajmowania określonego stanowiska albo 
wykonywania określonego zawodu,  
jeżeli sprawca nadużył przy popełnieniu przestępstwa stanowiska lub 
wykonywanego zawodu albo okazał, że dalsze zajmowanie stanowiska lub 
wykonywanie zawodu zagraża istotnym dobrom chronionym prawem. 
§ 1a. Sąd orzeka zakaz zajmowania wszelkich lub określonych stanowisk, 
wykonywania wszelkich lub określonych zawodów albo działalności, związanych z 
wychowaniem, edukacją, leczeniem małoletnich lub z opieką nad nimi na czas 
określony albo dożywotnio w razie skazania:  
- 1) na karę pozbawienia wolności za umyślne przestępstwo przeciwko życiu lub 
zdrowiu na szkodę małoletniego; 
- 2) za przestępstwo przeciwko wolności seksualnej lub obyczajności na szkodę 
małoletniego. 
§ 1aa. Sąd orzeka zakaz: 
- 1) zajmowania wszelkich lub określonych stanowisk lub 
- 2) wykonywania wszelkich lub określonych zawodów, lub 
- 3) wykonywania wszelkiej lub określonej pracy na podstawie stosunku pracy, 
umowy agencyjnej, umowy zlecenia lub innej umowy o świadczenie usług, do 
której zgodnie z Kodeksem cywilnym stosuje się przepisy dotyczące zlecenia, 
lub umowy o dzieło 

 
 
 
s. 14/146 
 
   
 
2025-04-09 
 
– w organach i instytucjach państwowych i samorządu terytorialnego, a także 
w spółkach prawa handlowego, w których Skarb Państwa lub jednostka samorządu 
terytorialnego posiadają bezpośrednio lub pośrednio przez inne podmioty co najmniej 
10 % akcji lub udziałów, w razie skazania osoby pełniącej funkcję publiczną za 
przestępstwa określone w art. 228 § 1 i 3–6, art. 230 § 1, art. 230a § 1, art. 250a § 1 
i 2, art. 271 § 3, art. 296a § 1, 2 i 4, art. 305 § 1–4 oraz art. 306b. 
§ 1ab. W razie skazania innej osoby za przestępstwa określone w art. 229 § 1 
i 3–5, art. 230 § 1, art. 230a § 1, art. 250a § 1 i 2, art. 271 § 3, art. 296a § 1, 2 i 4, art. 
305 § 1–4 oraz art. 306b sąd może orzec zakaz, o którym mowa w § 1aa. 
§ 1b. Sąd orzeka dożywotnio zakaz, o którym mowa w § 1a i 1aa, w razie 
ponownego skazania sprawcy w warunkach określonych w tych przepisach. 
§ 2. Sąd może orzec zakaz prowadzenia określonej działalności gospodarczej 
w razie skazania za przestępstwo popełnione w związku z prowadzeniem takiej 
działalności, jeżeli dalsze jej prowadzenie zagraża istotnym dobrom chronionym 
prawem. 
Art. 41a. § 1. Sąd może orzec zakaz przebywania w określonych środowiskach 
lub miejscach, kontaktowania się z określonymi osobami, zbliżania się do określonych 
osób lub opuszczania określonego miejsca pobytu bez zgody sądu, jak również nakaz 
okresowego opuszczenia lokalu zajmowanego wspólnie z pokrzywdzonym, w razie 
skazania za przestępstwo przeciwko wolności seksualnej lub obyczajności na szkodę 
małoletniego lub inne przestępstwo przeciwko wolności oraz w razie skazania za 
umyślne przestępstwo z użyciem przemocy, w tym zwłaszcza przemocy wobec osoby 
najbliższej. Zakaz lub nakaz może być połączony z obowiązkiem zgłaszania się do 
Policji lub innego wyznaczonego organu w określonych odstępach czasu, a zakaz 
zbliżania się do określonych osób – również kontrolowany w systemie dozoru 
elektronicznego. 
§ 1a. Sąd na wniosek pokrzywdzonego orzeka zakaz przebywania w określonych 
środowiskach lub miejscach, kontaktowania się z określonymi osobami, zbliżania się 
do określonych osób lub opuszczania określonego miejsca pobytu bez zgody sądu, jak 
również nakaz okresowego opuszczenia lokalu zajmowanego wspólnie z 
pokrzywdzonym, w razie skazania za przestępstwo przeciwko wolności seksualnej lub 
obyczajności. Zakaz lub nakaz może być połączony z obowiązkiem zgłaszania się do 
Policji lub innego wyznaczonego organu w określonych odstępach czasu, a zakaz 

 
 
 
s. 15/146 
 
   
 
2025-04-09 
 
zbliżania się do pokrzywdzonego – również kontrolowany w systemie dozoru 
elektronicznego. 
§ 2. Sąd orzeka zakaz przebywania w określonych środowiskach lub miejscach, 
kontaktowania się z określonymi osobami, zbliżania się do określonych osób lub 
opuszczania określonego miejsca pobytu bez zgody sądu, jak również nakaz 
okresowego opuszczenia lokalu zajmowanego wspólnie z pokrzywdzonym, w razie 
skazania na karę pozbawienia wolności bez warunkowego zawieszenia jej wykonania 
za przestępstwo przeciwko wolności seksualnej lub obyczajności. Zakaz lub nakaz 
może być połączony z obowiązkiem zgłaszania się do Policji lub innego 
wyznaczonego organu w określonych odstępach czasu, a zakaz zbliżania się do 
określonych osób – również kontrolowany w systemie dozoru elektronicznego. 
§ 3. Sąd może orzec zakaz przebywania w określonych środowiskach lub 
miejscach, kontaktowania się z określonymi osobami, zbliżania się do określonych 
osób lub opuszczania określonego miejsca pobytu bez zgody sądu dożywotnio w razie 
ponownego skazania sprawcy w warunkach określonych w § 2. 
§ 3a. W razie orzeczenia nakazu okresowego opuszczenia lokalu zajmowanego 
wspólnie z pokrzywdzonym za przestępstwa określone w rozdziałach XXV i XXVI 
sąd orzeka na ten sam okres zakaz zbliżania się do pokrzywdzonego. 
§ 4. Orzekając zakaz zbliżania się do określonych osób, sąd wskazuje odległość 
od osób chronionych, którą skazany obowiązany jest zachować. 
§ 5. Orzekając nakaz okresowego opuszczenia lokalu zajmowanego wspólnie 
z pokrzywdzonym, sąd określa termin jego wykonania. 
§ 6. Zakaz kontaktowania się z określoną osobą obejmuje wszelkie czynności 
związane z próbą nawiązania kontaktu z osobą chronioną, w tym podejmowane przez 
skazanego 
za 
pośrednictwem 
innej 
osoby 
lub 
z 
wykorzystaniem 
sieci 
teleinformatycznej. 
Art. 41b. § 1. Sąd może orzec zakaz wstępu na imprezę masową, jeżeli 
przestępstwo zostało popełnione w związku z taką imprezą lub w razie skazania za 
występek o charakterze chuligańskim, a udział sprawcy w imprezach masowych 
zagraża dobrom chronionym prawem. Sąd orzeka zakaz wstępu na imprezę masową 
w wypadkach wskazanych w ustawie. 
§ 2. Zakaz wstępu na imprezę masową obejmuje wszelkie imprezy masowe na 
terytorium Rzeczypospolitej Polskiej oraz mecze piłki nożnej rozgrywane przez 

 
 
 
s. 16/146 
 
   
 
2025-04-09 
 
polską kadrę narodową lub polski klub sportowy poza terytorium Rzeczypospolitej 
Polskiej. 
§ 3. Orzekając zakaz wstępu na imprezę masową za czyn popełniony w związku 
z masową imprezą sportową, sąd może orzec obowiązek przebywania skazanego 
w czasie trwania niektórych imprez masowych objętych zakazem w miejscu stałego 
pobytu lub w innym wyznaczonym miejscu, z zastosowaniem systemu dozoru 
elektronicznego. 
§ 4. Sąd orzeka zakaz wstępu na imprezę masową i obowiązek określony w § 3, 
w razie ponownego skazania sprawcy za przestępstwo popełnione w związku 
z imprezą masową. 
§ 5. W szczególnie uzasadnionych wypadkach sąd może orzec, że po upływie 
okresu, na który orzeczono obowiązek określony w § 3, skazany będzie obowiązany 
do stawiennictwa w czasie trwania niektórych imprez masowych objętych zakazem 
w jednostce organizacyjnej Policji lub w miejscu określonym przez właściwego, ze 
względu na miejsce zamieszkania skazanego, komendanta powiatowego, rejonowego 
lub miejskiego Policji. 
§ 6. Łączny czas stosowania wobec skazanego obowiązków, określonych w § 3 
i 5, nie może przekroczyć okresu orzeczonego wobec skazanego zakazu wstępu na 
imprezę masową. 
§ 7. Jeżeli z okoliczności wynika, że wykonanie obowiązku określonego 
w § 3 jest niemożliwe lub jego orzeczenie jest oczywiście niecelowe, w miejsce tego 
obowiązku orzeka się obowiązek stawiennictwa skazanego w czasie trwania 
niektórych imprez masowych objętych zakazem w jednostce organizacyjnej Policji 
lub w miejscu określonym przez właściwego, ze względu na miejsce zamieszkania 
skazanego, komendanta powiatowego, rejonowego lub miejskiego Policji. 
§ 8. Nakładając obowiązek, o którym mowa w § 3, 5 lub 7, sąd określa imprezy 
masowe, w czasie trwania których obowiązek ten ma być wykonywany, wskazując 
w szczególności nazwy dyscyplin sportowych, nazwy klubów sportowych oraz zakres 
terytorialny imprez, których obowiązek dotyczy. 
§ 9. Obowiązki orzekane na podstawie § 3, 5 i 7 orzeka się w miesiącach i latach. 
Obowiązek, o którym mowa w § 3, orzeka się na okres nie krótszy niż 6 miesięcy i nie 
dłuższy niż 12 miesięcy, zaś obowiązek, o którym mowa w § 7, orzeka się na okres od 

 
 
 
s. 17/146 
 
   
 
2025-04-09 
 
6 miesięcy do lat 6, nieprzekraczający okresu, na jaki orzeczono zakaz wstępu na 
imprezę masową. 
Art. 41c. § 1. Zakaz wstępu do ośrodków gier i uczestnictwa w grach 
hazardowych nie obejmuje uczestnictwa w loteriach promocyjnych. 
§ 2. Sąd może orzec zakaz wstępu do ośrodków gier i uczestnictwa w grach 
hazardowych, w razie skazania za przestępstwo popełnione w związku z urządzaniem 
gier hazardowych lub udziałem w nich.

***
## Art. 42. {#kk-art-42}

§ 1. Sąd może orzec zakaz prowadzenia pojazdów określonego rodzaju 
w razie skazania osoby uczestniczącej w ruchu za przestępstwo przeciwko 
bezpieczeństwu w komunikacji, w szczególności jeżeli z okoliczności popełnionego 
przestępstwa wynika, że prowadzenie pojazdu przez tę osobę zagraża bezpieczeństwu 
w komunikacji. 
§ 1a. Sąd orzeka zakaz prowadzenia wszelkich pojazdów mechanicznych w razie 
skazania za przestępstwo określone w: 
- 1) art. 178b lub art. 180a; 
- 2) art. 244, jeżeli czyn sprawcy polegał na niezastosowaniu się do zakazu 
prowadzenia pojazdów mechanicznych. 
§ 2. Sąd orzeka, na okres nie krótszy niż 3 lata, zakaz prowadzenia wszelkich 
pojazdów albo pojazdów określonego rodzaju, jeżeli sprawca w czasie popełnienia 
przestępstwa wymienionego w § 1 był w stanie nietrzeźwości, pod wpływem środka 
odurzającego lub zbiegł z miejsca zdarzenia określonego w art. 173, art. 174 lub art. 
177 lub po takim zdarzeniu, a przed poddaniem go przez uprawniony organ badaniu 
w celu ustalenia zawartości alkoholu lub środka odurzającego w organizmie, spożywał 
alkohol lub zażywał środek odurzający. 
§ 3. Sąd orzeka zakaz prowadzenia wszelkich pojazdów mechanicznych 
dożywotnio w razie popełnienia przestępstwa określonego w art. 178a § 4 lub jeżeli 
sprawca w czasie popełnienia przestępstwa określonego w art. 173, którego 
następstwem jest śmierć innej osoby lub ciężki uszczerbek na jej zdrowiu, albo w 
czasie popełnienia przestępstwa określonego w art. 177 § 2 lub art. 355 § 2 był w stanie 
nietrzeźwości lub pod wpływem środka odurzającego lub zbiegł z miejsca zdarzenia, 
lub po takim zdarzeniu, a przed poddaniem go przez uprawniony organ badaniu w celu 
ustalenia zawartości alkoholu lub środka odurzającego w organizmie, spożywał 

 
 
 
s. 18/146 
 
   
 
2025-04-09 
 
alkohol lub zażywał środek odurzający, chyba że zachodzi wyjątkowy wypadek, 
uzasadniony szczególnymi okolicznościami. 
§ 4. Sąd orzeka zakaz prowadzenia wszelkich pojazdów mechanicznych 
dożywotnio w razie ponownego skazania osoby prowadzącej pojazd mechaniczny 
w warunkach określonych w § 3.

***
## Art. 43. {#kk-art-43}

§ 1. Jeżeli ustawa nie stanowi inaczej, pozbawienie praw publicznych 
oraz zakaz i nakaz wymienione w art. 39 pkt 2d i 2e orzeka się w latach, od roku do 
lat 10, zakazy wymienione w art. 39 pkt 2–2b i 3 orzeka się w latach, od roku do lat 
15, a zakaz wymieniony w art. 39 pkt 2c orzeka się w latach, od lat 2 do 6. 
§ 1a. Obowiązek, o którym mowa w art. 41a § 1 zdanie drugie i § 2 zdanie 
drugie, orzeka się w miesiącach, najkrócej na 3 miesiące, najdłużej na 12 miesięcy. 
§ 2. Pozbawienie 
praw 
publicznych, 
zakazy 
i nakaz 
obowiązują 
od 
uprawomocnienia się orzeczenia. 
§ 2a. Okres, na który orzeczono zakazy, nie biegnie w czasie odbywania kary 
pozbawienia wolności, chociażby orzeczonej za inne przestępstwo. 
§ 2b. Okres, na który orzeczono pozbawienie praw publicznych za dane 
przestępstwo, nie biegnie w czasie odbywania kary pozbawienia wolności za to 
przestępstwo. 
§ 3. (uchylony) 
Art. 43a. § 1. Odstępując od wymierzenia kary, a także w wypadkach 
wskazanych w ustawie, sąd może orzec świadczenie pieniężne wymienione 
w art. 39 pkt 7 na rzecz Funduszu Pomocy Pokrzywdzonym oraz Pomocy 
Postpenitencjarnej; wysokość tego świadczenia nie może przekroczyć 60 000 złotych. 
§ 2. W razie skazania sprawcy za przestępstwo określone w art. 164 § 1, art. 165 
§ 1, art. 165a § 1 lub 2, art. 171 § 1, 2 lub 3, art. 174 § 1, art. 178a § 1, art. 178b, art. 
179, art. 180, art. 200a § 1 lub 2, art. 200b, art. 202 § 4b lub 4c, art. 244, art. 255a § 1 
lub 2, art. 258 § 1, art. 263 § 2 sąd orzeka świadczenie pieniężne wymienione w art. 
39 pkt 7 na rzecz Funduszu Pomocy Pokrzywdzonym oraz Pomocy Postpenitencjarnej 
w wysokości co najmniej 5000 złotych, do wysokości określonej w § 1. 
§ 3. W razie skazania sprawcy za przestępstwo określone w art. 178a § 4, art. 202 
§ 3, 4 lub 4a, art. 258 § 2, 3 lub 4, art. 263 § 1 sąd orzeka świadczenie pieniężne 
wymienione w art. 39 pkt 7 na rzecz Funduszu Pomocy Pokrzywdzonym oraz Pomocy 

 
 
 
s. 19/146 
 
   
 
2025-04-09 
 
Postpenitencjarnej w wysokości co najmniej 10 000 złotych, do wysokości określonej 
w § 1. 
§ 4. W razie skazania za udział w bójce lub pobiciu, o których mowa w art. 158 
lub w art. 159, sąd orzeka, a jeżeli jednocześnie orzeka obowiązek lub nawiązkę na 
podstawie art. 46 § 1 lub 2 – może orzec, świadczenie pieniężne wymienione 
w art. 39 pkt 7 na rzecz Funduszu Pomocy Pokrzywdzonym oraz Pomocy 
Postpenitencjarnej w wysokości co najmniej 5000 złotych. 
Art. 43b. Sąd może orzec podanie wyroku do publicznej wiadomości 
w określony sposób, jeżeli uzna to za celowe, w szczególności ze względu na 
społeczne oddziaływanie skazania, o ile nie narusza to interesu pokrzywdzonego. 
Art. 43ba. § 1. Degradacja obejmuje utratę posiadanego stopnia wojskowego i 
powrót do stopnia szeregowego.  
§ 2. Sąd może orzec degradację w razie skazania za przestępstwo umyślne, jeżeli 
rodzaj czynu, sposób i okoliczności jego popełnienia pozwalają przyjąć, że sprawca 
utracił właściwości wymagane do posiadania stopnia wojskowego.  
Art. 43bb. Sąd może orzec degradację wobec osoby, która w czasie popełnienia 
czynu była żołnierzem, żołnierzem rezerwy lub żołnierzem w stanie spoczynku. 
Art. 43c. Sąd, uznając za celowe orzeczenie pozbawienia lub ograniczenia praw 
rodzicielskich lub opiekuńczych w razie popełnienia przestępstwa na szkodę 
małoletniego lub we współdziałaniu z nim, zawiadamia o tym właściwy sąd rodzinny. 
### Rozdział V a 
Przepadek i środki kompensacyjne

***
## Art. 44. {#kk-art-44}

§ 1. Sąd orzeka przepadek przedmiotów pochodzących bezpośrednio 
z przestępstwa. 
§ 2. Sąd może orzec, a w wypadkach wskazanych w ustawie orzeka, przepadek 
przedmiotów, które służyły lub były przeznaczone do popełnienia przestępstwa. 
§ 3. Jeżeli orzeczenie przepadku określonego w § 2 byłoby niewspółmierne do 
wagi popełnionego czynu, sąd zamiast przepadku może orzec nawiązkę na rzecz 
Skarbu Państwa. 
§ 4. Jeżeli orzeczenie przepadku określonego w § 1 lub 2 nie jest możliwe, sąd 
może orzec przepadek równowartości przedmiotów pochodzących bezpośrednio 

 
 
 
s. 20/146 
 
   
 
2025-04-09 
 
z przestępstwa lub przedmiotów, które służyły lub były przeznaczone do popełnienia 
przestępstwa. 
§ 5. Przepadku przedmiotów określonych w § 1 lub 2 nie orzeka się, jeżeli 
podlegają one zwrotowi pokrzywdzonemu lub innemu uprawnionemu podmiotowi. 
§ 6. W razie skazania za przestępstwo polegające na naruszeniu zakazu 
wytwarzania, posiadania, obrotu, przesyłania, przenoszenia lub przewozu określonych 
przedmiotów, sąd może orzec, a w wypadkach przewidzianych w ustawie orzeka, ich 
przepadek. 
§ 7. Jeżeli przedmioty wymienione w § 2 lub 6 nie stanowią własności sprawcy, 
ich przepadek można orzec tylko w wypadkach przewidzianych w ustawie; w razie 
współwłasności orzeka się przepadek udziału należącego do sprawcy lub przepadek 
równowartości tego udziału. 
§ 8. (uchylony) 
Art. 44a. § 1. W razie skazania za przestępstwo, z którego popełnienia sprawca 
osiągnął, chociażby pośrednio, korzyść majątkową znacznej wartości, sąd może orzec 
przepadek przedsiębiorstwa stanowiącego własność sprawcy albo jego równo-
wartości, jeżeli przedsiębiorstwo służyło do popełnienia tego przestępstwa lub ukrycia 
osiągniętej z niego korzyści. 
§ 2. W razie skazania za przestępstwo, z którego popełnienia sprawca osiągnął, 
chociażby pośrednio, korzyść majątkową znacznej wartości, sąd może orzec 
przepadek niestanowiącego własności sprawcy przedsiębiorstwa osoby fizycznej albo 
jego równowartości, jeżeli przedsiębiorstwo służyło do popełnienia tego przestępstwa 
lub ukrycia osiągniętej z niego korzyści, a jego właściciel chciał, aby przedsiębiorstwo 
służyło do popełnienia tego przestępstwa lub ukrycia osiągniętej z niego korzyści albo, 
przewidując taką możliwość, na to się godził. 
§ 3. W razie współwłasności przepadek, o którym mowa w § 1 i 2, orzeka się 
z uwzględnieniem woli i świadomości każdego ze współwłaścicieli i w ich granicach. 
§ 4. Przepadku, o którym mowa w § 1 i 2, nie orzeka się, jeżeli byłoby to 
niewspółmierne do wagi popełnionego przestępstwa, stopnia zawinienia oskarżonego 
lub motywacji i sposobu zachowania się właściciela przedsiębiorstwa. 
§ 5. Przepadku, o którym mowa w § 1 i 2, nie orzeka się, jeżeli szkoda 
wyrządzona przestępstwem lub wartość ukrytej korzyści nie jest znaczna wobec 
rozmiaru działalności przedsiębiorstwa. 

 
 
 
s. 21/146 
 
   
 
2025-04-09 
 
§ 6. Sąd może odstąpić od orzeczenia przepadku, o którym mowa w § 2, także 
w innych, szczególnie uzasadnionych przypadkach, kiedy byłby on niewspółmiernie 
dolegliwy dla właściciela przedsiębiorstwa. 
Art. 44b. § 1. W wypadkach wskazanych w ustawie sąd orzeka przepadek 
pojazdu mechanicznego prowadzonego przez sprawcę w ruchu lądowym. 
§ 2. Jeżeli w czasie popełnienia przestępstwa pojazd nie stanowił wyłącznej 
własności sprawcy albo po popełnieniu przestępstwa sprawca zbył, darował lub ukrył 
podlegający przepadkowi pojazd, orzeka się przepadek równowartości pojazdu. Za 
równowartość 
pojazdu 
uznaje 
się 
wartość 
pojazdu 
określoną 
w polisie 
ubezpieczeniowej na rok, w którym popełniono przestępstwo, a w razie braku polisy 
– średnią wartość rynkową pojazdu odpowiadającego, przy uwzględnieniu marki, 
modelu, roku produkcji, typu nadwozia, rodzaju napędu i silnika, pojemności lub 
mocy silnika oraz przybliżonego przebiegu, pojazdowi prowadzonemu przez sprawcę, 
ustaloną na podstawie dostępnych danych, bez powoływania w tym celu biegłego. 
§ 3. Jeżeli ustalenie średniej wartości rynkowej pojazdu odpowiadającego 
pojazdowi, o którym mowa w § 1, w sposób określony w § 2 nie jest możliwe ze 
względu na szczególne cechy tego pojazdu, zasięga się opinii biegłego. 
§ 4. Przepadku pojazdu mechanicznego oraz przepadku równowartości pojazdu 
określonego w § 2 nie orzeka się, jeżeli sprawca prowadził niestanowiący jego 
własności pojazd mechaniczny wykonując czynności zawodowe lub służbowe 
polegające na prowadzeniu pojazdu na rzecz pracodawcy. W takim wypadku sąd 
orzeka nawiązkę w wysokości co najmniej 5000 złotych na rzecz Funduszu Pomocy 
Pokrzywdzonym oraz Pomocy Postpenitencjarnej. 
§ 5. Przepadku pojazdu mechanicznego oraz przepadku równowartości pojazdu 
nie orzeka się, jeżeli orzeczenie przepadku pojazdu mechanicznego jest niemożliwe 
lub niecelowe z uwagi na jego utratę przez sprawcę, zniszczenie lub znaczne 
uszkodzenie.

***
## Art. 45. {#kk-art-45}

§ 1. Jeżeli sprawca osiągnął z popełnienia przestępstwa, chociażby 
pośrednio, 
korzyść 
majątkową 
niepodlegającą 
przepadkowi 
przedmiotów 
wymienionych w art. 44 § 1 lub 6, sąd orzeka przepadek takiej korzyści albo jej 
równowartości. Przepadku nie orzeka się w całości lub w części, jeżeli korzyść lub jej 
równowartość podlega zwrotowi pokrzywdzonemu lub innemu podmiotowi. 

 
 
 
s. 22/146 
 
   
 
2025-04-09 
 
§ 1a. Za korzyść majątkową osiągniętą z popełnienia przestępstwa uważa się 
także pożytki z rzeczy lub praw stanowiących tę korzyść. 
§ 2. W razie skazania za przestępstwo, z którego popełnienia została osiągnięta, 
chociażby pośrednio, korzyść majątkowa znacznej wartości, albo przestępstwo, 
z którego została lub mogła zostać osiągnięta, chociażby pośrednio, korzyść 
majątkowa, zagrożone karą pozbawienia wolności, której górna granica jest nie niższa 
niż 5 lat, lub popełnione w zorganizowanej grupie albo związku mających na celu 
popełnienie przestępstwa za korzyść uzyskaną z popełnienia przestępstwa uważa się 
mienie, które sprawca objął we władanie lub do którego uzyskał jakikolwiek tytuł 
w okresie 5 lat przed popełnieniem przestępstwa do chwili wydania chociażby 
nieprawomocnego wyroku, chyba że sprawca lub inna zainteresowana osoba 
przedstawi dowód przeciwny. 
§ 3. Jeżeli mienie stanowiące korzyść uzyskaną z popełnienia przestępstwa, 
o którym mowa w § 2, zostało przeniesione na osobę fizyczną, prawną lub jednostkę 
organizacyjną niemającą osobowości prawnej, faktycznie lub pod jakimkolwiek 
tytułem prawnym, uważa się, że rzeczy będące w samoistnym posiadaniu tej osoby 
lub jednostki oraz przysługujące jej prawa majątkowe należą do sprawcy, chyba że na 
podstawie okoliczności towarzyszących ich nabyciu nie można było przypuszczać, że 
mienie to, chociażby pośrednio, pochodziło z czynu zabronionego. 
§ 4. (uchylony) 
§ 5. W razie współwłasności orzeka się przepadek udziału należącego do 
sprawcy lub przepadek równowartości tego udziału. 
§ 6. (uchylony) 
Art. 45a. § 1. Sąd może orzec przepadek, jeżeli społeczna szkodliwość czynu 
jest znikoma, a także w razie warunkowego umorzenia postępowania lub 
stwierdzenia, że sprawca dopuścił się czynu zabronionego w stanie niepoczytalności, 
o której mowa w art. 31 § 1, albo jeżeli zachodzi okoliczność wyłączająca ukaranie 
sprawcy czynu zabronionego. 
§ 2. Jeżeli zebrane dowody wskazują, że w razie skazania zostałby orzeczony 
przepadek, sąd może go orzec także w razie śmierci sprawcy, umorzenia postępowania 
z powodu jego niewykrycia, a także w przypadku zawieszenia postępowania 
w sprawie, w której nie można ująć oskarżonego albo oskarżony nie może brać udziału 
w postępowaniu z powodu choroby psychicznej lub innej ciężkiej choroby. 

 
 
 
s. 23/146 
 
   
 
2025-04-09

***
## Art. 46. {#kk-art-46}

§ 1. W razie skazania sąd może orzec, a na wniosek pokrzywdzonego 
lub innej osoby uprawnionej orzeka, stosując przepisy prawa cywilnego, obowiązek 
naprawienia, w całości albo w części, wyrządzonej przestępstwem szkody lub 
zadośćuczynienia za doznaną krzywdę; przepisów prawa cywilnego o możliwości 
zasądzenia renty nie stosuje się. 
§ 2. Jeżeli orzeczenie obowiązku określonego w § 1 jest znacznie utrudnione, 
sąd może orzec zamiast tego obowiązku nawiązkę w wysokości do 200 000 złotych 
na rzecz pokrzywdzonego, a w razie jego śmierci w wyniku popełnionego przez 
skazanego przestępstwa nawiązkę na rzecz osoby najbliższej, której sytuacja życiowa 
wskutek śmierci pokrzywdzonego uległa znacznemu pogorszeniu. W razie gdy 
ustalono więcej niż jedną taką osobę, nawiązki orzeka się na rzecz każdej z nich. 
§ 3. Orzeczenie odszkodowania lub zadośćuczynienia na podstawie § 1 albo 
nawiązki na podstawie § 2 nie stoi na przeszkodzie dochodzeniu niezaspokojonej 
części roszczenia w drodze postępowania cywilnego.

***
## Art. 47. {#kk-art-47}

§ 1. W razie skazania sprawcy za umyślne przestępstwo przeciwko 
życiu lub zdrowiu albo za inne przestępstwo umyślne, którego skutkiem jest śmierć 
człowieka, ciężki uszczerbek na zdrowiu, naruszenie czynności narządu ciała lub 
rozstrój zdrowia, sąd może orzec nawiązkę na rzecz Funduszu Pomocy 
Pokrzywdzonym oraz Pomocy Postpenitencjarnej. 
§ 2. W razie skazania sprawcy za umyślne przestępstwo przeciwko środowisku 
sąd orzeka, a w wypadku skazania sprawcy za nieumyślne przestępstwo przeciwko 
środowisku sąd może orzec, nawiązkę w wysokości od 10 000 do 10 000 000 złotych 
na rzecz Narodowego Funduszu Ochrony Środowiska i Gospodarki Wodnej, o którym 
mowa w art. 400 ust. 1 ustawy z dnia 27 kwietnia 2001 r. – Prawo ochrony środowiska 
(Dz. U. z 2024 r. poz. 54, z późn. zm.2)). 
§ 2a. W przypadkach, o których mowa w art. 44a § 4–6, sąd może orzec 
nawiązkę w wysokości do 1 000 000 złotych na rzecz pokrzywdzonego lub Funduszu 
Pomocy Pokrzywdzonym oraz Pomocy Postpenitencjarnej. 
§ 3. W razie skazania sprawcy za przestępstwo określone w art. 173, art. 174, 
art. 177 lub w art. 355, jeżeli sprawca był w stanie nietrzeźwości lub pod wpływem 
- 2) Zmiany tekstu jednolitego wymienionej ustawy zostały ogłoszone w Dz. U. z 2024 r. poz. 834, 1089, 
1222, 1847, 1853, 1881, 1914, 1940 i 1946. 

 
 
 
s. 24/146 
 
   
 
2025-04-09 
 
środka odurzającego lub zbiegł z miejsca zdarzenia, sąd orzeka nawiązkę na rzecz 
pokrzywdzonego, a w razie jego śmierci w wyniku popełnionego przez skazanego 
przestępstwa nawiązkę na rzecz osoby najbliższej, której sytuacja życiowa wskutek 
śmierci pokrzywdzonego uległa znacznemu pogorszeniu. W razie gdy ustalono więcej 
niż jedną taką osobę, nawiązki orzeka się na rzecz każdej z nich. Jeśli ustalenie takiej 
osoby nie jest możliwe, sąd orzeka nawiązkę na rzecz Funduszu Pomocy 
Pokrzywdzonym oraz Pomocy Postpenitencjarnej. Sąd orzeka nawiązkę w wysokości 
co najmniej 10 000 złotych. 
§ 4. W szczególnie uzasadnionych okolicznościach, gdy wymierzona nawiązka 
powodowałaby dla sprawcy uszczerbek dla niezbędnego utrzymania siebie i rodziny 
lub gdy pokrzywdzony pojednał się ze sprawcą, sąd może ją wymierzyć w wysokości 
niższej niż wysokość wskazana w § 2 i 3. 
§ 5. Przepisu § 3 nie stosuje się, jeżeli sąd orzekł obowiązek naprawienia 
wyrządzonej przestępstwem szkody lub zadość- 
uczynienia za doznaną krzywdę w wysokości wyższej niż 10 000 złotych. 
Art. 47a. (uchylony)

***
## Art. 48. {#kk-art-48}

Nawiązkę orzeka się w wysokości do 100 000 złotych, chyba że ustawa 
stanowi inaczej.

***
## Art. 49. {#kk-art-49}

(uchylony) 
Art. 49a. (uchylony)

***
## Art. 50. {#kk-art-50}

(uchylony)

***
## Art. 51. {#kk-art-51}

(uchylony)

***
## Art. 52. {#kk-art-52}

(uchylony) 
### Rozdział VI Zasady wymiaru kary i środków karnych

***
## Art. 53. {#kk-art-53}

§ 1. Sąd wymierza karę według swojego uznania, w granicach 
przewidzianych w ustawie, uwzględniając stopień społecznej szkodliwości czynu, 
okoliczności obciążające i okoliczności łagodzące, cele kary w zakresie społecznego 
oddziaływania, a także cele zapobiegawcze, które ma ona osiągnąć w stosunku do 
skazanego. Dolegliwość kary nie może przekraczać stopnia winy. 

 
 
 
s. 25/146 
 
   
 
2025-04-09 
 
§ 2. Wymierzając karę, sąd uwzględnia w szczególności motywację i sposób 
zachowania się sprawcy, zwłaszcza w razie popełnienia przestępstwa na szkodę osoby 
nieporadnej ze względu na wiek lub stan zdrowia, popełnienie przestępstwa wspólnie 
z nieletnim, rodzaj i stopień naruszenia ciążących na sprawcy obowiązków, rodzaj 
i rozmiar ujemnych następstw przestępstwa, właściwości i warunki osobiste sprawcy, 
sposób życia przed popełnieniem przestępstwa i zachowanie się po jego popełnieniu, 
a zwłaszcza staranie o naprawienie szkody lub zadośćuczynienie w innej formie 
społecznemu poczuciu sprawiedliwości, a także zachowanie się pokrzywdzonego. 
§ 2a. Okoliczności obciążające stanowią w szczególności:  
- 1) uprzednia karalność za przestępstwo umyślne lub podobne przestępstwo 
nieumyślne; 
- 2) wykorzystanie bezradności, niepełnosprawności, choroby lub podeszłego wieku 
pokrzywdzonego;  
- 3) sposób działania prowadzący do poniżenia lub udręczenia pokrzywdzonego;  
- 4) popełnienie przestępstwa z premedytacją;  
- 5) popełnienie przestępstwa w wyniku motywacji zasługującej na szczególne 
potępienie;  
- 6) popełnienie przestępstwa motywowanego nienawiścią z powodu przynależności 
narodowej, etnicznej, rasowej, politycznej lub wyznaniowej ofiary albo z 
powodu jej bezwyznaniowości;  
- 7) działanie ze szczególnym okrucieństwem;  
- 8) popełnienie przestępstwa w stanie po spożyciu alkoholu lub środka 
odurzającego, jeżeli ten stan był czynnikiem prowadzącym do popełnienia 
przestępstwa lub istotnego zwiększenia jego skutków;  
- 9) popełnienie przestępstwa we współdziałaniu z nieletnim lub z wykorzystaniem 
jego udziału. 
§ 2b. Okoliczności łagodzące stanowią w szczególności:  
- 1) popełnienie przestępstwa w wyniku motywacji zasługującej na uwzględnienie; 
- 2) popełnienie przestępstwa pod wpływem gniewu, strachu lub wzburzenia, 
usprawiedliwionych okolicznościami zdarzenia; 
- 3) popełnienie przestępstwa w reakcji na nagłą sytuację, której prawidłowa ocena 
była istotnie utrudniona z uwagi na okoliczności osobiste, zakres wiedzy lub 
doświadczenia życiowego sprawcy; 

 
 
 
s. 26/146 
 
   
 
2025-04-09 
- 4) podjęcie działań zmierzających do zapobieżenia szkodzie lub krzywdzie, 
wynikającej z przestępstwa, albo do ograniczenia jej rozmiaru; 
- 5) pojednanie się z pokrzywdzonym; 
- 6) naprawienie szkody wyrządzonej przestępstwem lub zadośćuczynienie za 
krzywdę wynikłą z przestępstwa; 
- 7) popełnienie przestępstwa ze znacznym przyczynieniem się pokrzywdzonego; 
- 8) dobrowolne ujawnienie popełnionego przez siebie przestępstwa organowi 
powołanemu do ścigania przestępstw. 
§ 2c. Nie stanowi okoliczności, o której mowa w § 2a i 2b, okoliczność będąca 
znamieniem przestępstwa, które popełnił sprawca, chyba że wystąpiła ona ze 
szczególnie wysokim nasileniem. 
§ 2d. Nie stanowi okoliczności, o której mowa w § 2a, okoliczność niebędąca 
znamieniem przestępstwa, jeżeli stanowi podstawę zaostrzenia odpowiedzialności 
karnej zastosowanego wobec sprawcy. 
§ 2e. Nie stanowi okoliczności, o której mowa w § 2b, okoliczność niebędąca 
znamieniem przestępstwa, jeżeli stanowi podstawę złagodzenia odpowiedzialności 
karnej zastosowanego wobec sprawcy. 
§ 3. Wymierzając karę sąd bierze także pod uwagę pozytywne wyniki 
przeprowadzonej mediacji pomiędzy pokrzywdzonym a sprawcą albo ugodę 
pomiędzy nimi osiągniętą w postępowaniu przed sądem lub prokuratorem.

***
## Art. 54. {#kk-art-54}

§ 1. Wymierzając karę nieletniemu albo młodocianemu, sąd kieruje się 
przede wszystkim tym, aby sprawcę wychować. 
§ 2. Wobec sprawcy, który w czasie popełnienia przestępstwa nie ukończył 
18 lat, nie orzeka się kary dożywotniego pozbawienia wolności.

***
## Art. 55. {#kk-art-55}

Okoliczności wpływające na wymiar kary uwzględnia się tylko co do 
osoby, której dotyczą.

***
## Art. 56. {#kk-art-56}

Przepisy art. 53, art. 54 § 1 oraz art. 55 stosuje się odpowiednio do 
orzekania innych środków przewidzianych w tym kodeksie, z wyjątkiem obowiązku 
naprawienia wyrządzonej przestępstwem szkody lub zadośćuczynienia za doznaną 
krzywdę.

***
## Art. 57. {#kk-art-57}

§ 1. Jeżeli zachodzi kilka niezależnych od siebie podstaw do 
nadzwyczajnego złagodzenia albo obostrzenia kary, sąd może tylko jeden raz karę 

 
 
 
s. 27/146 
 
   
 
2025-04-09 
 
nadzwyczajnie złagodzić albo obostrzyć, uwzględniając przy określaniu wymiaru kary 
łącznie zbiegające się podstawy łagodzenia albo obostrzenia.  
§ 2. Jeżeli zbiegają się podstawy nadzwyczajnego złagodzenia i obostrzenia, sąd 
stosuje nadzwyczajne złagodzenie kary albo obostrzenie kary albo wymierza karę w 
granicach ustawowego zagrożenia.  
§ 3. W wypadkach, o których mowa w § 1 i 2, jeżeli zbiegają się podstawy 
nadzwyczajnego złagodzenia lub obostrzenia kary o charakterze obligatoryjnym i 
fakultatywnym, sąd stosuje podstawę o charakterze obligatoryjnym.  
§ 4. Przepisy § 1–3 w zakresie, w jakim odnoszą się do podstawy 
nadzwyczajnego złagodzenia, stosuje się odpowiednio do podstawy odstąpienia od 
wymierzenia kary.  
§ 5. Jeżeli zbiegają się podstawy nadzwyczajnego obostrzenia o charakterze 
obligatoryjnym oraz podstawy nadzwyczajnego złagodzenia określone w art. 60 § 3 
sąd stosuje nadzwyczajne złagodzenie kary.  
§ 6. Jeżeli zbiegają się podstawy nadzwyczajnego obostrzenia o charakterze 
obligatoryjnym oraz podstawy nadzwyczajnego złagodzenia określone w art. 60 § 4 
sąd może zastosować nadzwyczajne złagodzenie kary. 
§ 7. Jeżeli zbiegają się podstawy:  
- 1) nadzwyczajnego złagodzenia oraz odstąpienia od wymierzenia kary o 
charakterze obligatoryjnym albo zbiegają się podstawy nadzwyczajnego 
złagodzenia o charakterze fakultatywnym oraz odstąpienia od wymierzenia kary 
o charakterze obligatoryjnym – sąd odstępuje od wymierzenia kary; 
- 2) nadzwyczajnego złagodzenia o charakterze obligatoryjnym oraz odstąpienia od 
wymierzenia kary o charakterze fakultatywnym – sąd stosuje nadzwyczajne 
złagodzenie kary albo odstępuje od jej wymierzenia;  
- 3) nadzwyczajnego złagodzenia kary oraz odstąpienia od wymierzenia kary o 
charakterze fakultatywnym – sąd stosuje nadzwyczajne złagodzenie kary albo 
odstępuje od jej wymierzenia albo wymierza karę w granicach ustawowego 
zagrożenia. 
Art. 57a. § 1. Skazując za występek o charakterze chuligańskim, sąd wymierza 
karę przewidzianą za przypisane sprawcy przestępstwo w wysokości nie niższej od 
dolnej granicy ustawowego zagrożenia zwiększonego o połowę. 

 
 
 
s. 28/146 
 
   
 
2025-04-09 
 
§ 2. W wypadku 
określonym 
w § 1 sąd 
orzeka 
nawiązkę 
na 
rzecz 
pokrzywdzonego, chyba że orzeka obowiązek naprawienia szkody, obowiązek 
zadośćuczynienia za doznaną krzywdę lub nawiązkę na podstawie art. 46. Jeżeli 
pokrzywdzony nie został ustalony, sąd może orzec nawiązkę na rzecz Funduszu 
Pomocy Pokrzywdzonym oraz Pomocy Postpenitencjarnej. 
Art. 57b. Skazując za przestępstwo z zastosowaniem art. 12 § 1, sąd wymierza 
karę przewidzianą za przypisane sprawcy przestępstwo powyżej dolnej granicy 
ustawowego zagrożenia, a w wypadku grzywny lub kary ograniczenia wolności nie 
niższą od podwójnej dolnej granicy ustawowego zagrożenia – do podwójnej 
wysokości górnej granicy ustawowego zagrożenia.

***
## Art. 58. {#kk-art-58}

§ 1. Jeżeli ustawa przewiduje możliwość wyboru rodzaju kary, 
a przestępstwo jest zagrożone karą pozbawienia wolności nieprzekraczającą 5 lat, sąd 
orzeka karę pozbawienia wolności tylko wtedy, gdy inna kara lub środek karny nie 
może spełnić celów kary. 
§ 2. (uchylony) 
§ 2a. Kary ograniczenia wolności w postaci obowiązku, o którym mowa 
w art. 34 § 1a pkt 1, nie orzeka się, jeżeli stan zdrowia oskarżonego lub jego 
właściwości i warunki osobiste uzasadniają przekonanie, że oskarżony nie wykona 
tego obowiązku. 
§ 3. (uchylony) 
§ 4. (uchylony)

***
## Art. 59. {#kk-art-59}

Jeżeli przestępstwo jest zagrożone karą pozbawienia wolności 
nieprzekraczającą 3 lat albo karą łagodniejszego rodzaju i społeczna szkodliwość 
czynu nie jest znaczna, sąd może odstąpić od wymierzenia kary, jeżeli orzeka jedno-
cześnie środek karny, przepadek lub środek kompensacyjny, a cele kary zostaną w ten 
sposób spełnione. 
Art. 59a. (uchylony)

***
## Art. 60. {#kk-art-60}

§ 1. 
Sąd 
może 
zastosować 
nadzwyczajne 
złagodzenie 
kary 
w wypadkach przewidzianych w ustawie oraz w stosunku do młodocianego, jeżeli 
przemawiają za tym względy określone w art. 54 § 1. 

 
 
 
s. 29/146 
 
   
 
2025-04-09 
 
§ 2. Sąd 
może 
również 
zastosować 
nadzwyczajne 
złagodzenie 
kary 
w szczególnie uzasadnionych wypadkach, kiedy nawet najniższa kara przewidziana za 
przestępstwo byłaby niewspółmiernie surowa, w szczególności: 
- 1) jeżeli pokrzywdzony pojednał się ze sprawcą, szkoda została naprawiona albo 
pokrzywdzony i sprawca uzgodnili sposób naprawienia szkody, 
- 2) ze względu na postawę sprawcy, zwłaszcza gdy czynił starania o naprawienie 
szkody lub o jej zapobieżenie, 
- 3) jeżeli sprawca przestępstwa nieumyślnego lub jego najbliższy poniósł poważny 
uszczerbek w związku z popełnionym przestępstwem. 
§ 3. Na wniosek prokuratora sąd stosuje nadzwyczajne złagodzenie kary, a nawet 
może warunkowo zawiesić jej wykonanie w stosunku do sprawcy współdziałającego 
z innymi osobami w popełnieniu przestępstwa, jeżeli ujawni on wobec organu 
powołanego do ścigania przestępstw informacje dotyczące osób uczestniczących w 
popełnieniu przestępstwa oraz istotne okoliczności jego popełnienia. 
§ 4. Na wniosek prokuratora sąd może zastosować nadzwyczajne złagodzenie 
kary, a nawet warunkowo zawiesić jej wykonanie w stosunku do sprawcy 
przestępstwa, który, niezależnie od wyjaśnień złożonych w swojej sprawie, ujawnił 
przed organem ścigania i przedstawił istotne okoliczności, nieznane dotychczas temu 
organowi, przestępstwa zagrożonego karą powyżej 5 lat pozbawienia wolności. 
§ 5. W wypadkach określonych w § 3 i 4 sąd, wymierzając karę pozbawienia 
wolności do lat 5, może warunkowo zawiesić jej wykonanie na okres próby wynoszący 
do 10 lat, jeżeli uzna, że pomimo niewykonania kary sprawca nie popełni ponownie 
przestępstwa; przepisu art. 69 § 1 nie stosuje się, a przepisy art. 71–76 stosuje się 
odpowiednio. 
§ 6. Nadzwyczajne złagodzenie kary polega na wymierzeniu kary poniżej dolnej 
granicy ustawowego zagrożenia, kary łagodniejszego rodzaju albo na odstąpieniu od 
wymierzenia kary i orzeczeniu środka karnego, środka kompensacyjnego lub 
przepadku według następujących zasad: 
- 1) (uchylony) 
- 2) jeżeli czyn stanowi zbrodnię, sąd wymierza karę pozbawienia wolności nie 
niższą od jednej trzeciej dolnej granicy ustawowego zagrożenia, 

 
 
 
s. 30/146 
 
   
 
2025-04-09 
- 3) jeżeli czyn stanowi występek, przy czym dolną granicą ustawowego zagrożenia 
jest kara pozbawienia wolności nie niższa od roku, sąd wymierza grzywnę, karę 
ograniczenia wolności albo pozbawienia wolności, 
- 4) jeżeli czyn stanowi występek, przy czym dolną granicą ustawowego zagrożenia 
jest kara pozbawienia wolności niższa od roku, a górną – kara pozbawienia 
wolności nie niższa od lat 3, sąd wymierza grzywnę albo karę ograniczenia 
wolności, 
- 5) jeżeli czyn stanowi występek, przy czym górną granicą ustawowego zagrożenia 
jest kara pozbawienia wolności nieprzekraczająca 2 lat, sąd odstępuje od 
wymierzenia kary i orzeka środek karny wymieniony w art. 39 pkt 2–3, 7 lub 8, 
środek kompensacyjny lub przepadek; przepisu art. 61 § 2 nie stosuje się. 
§ 7. Jeżeli czyn jest zagrożony karą pozbawienia wolności oraz karą ograniczenia 
wolności lub grzywną, stosuje się odpowiednio przepis § 6. 
§ 7a. Jeżeli czyn nie jest zagrożony karą pozbawienia wolności, stosuje się 
odpowiednio przepis § 6 pkt 5. 
§ 8. (uchylony) 
Art. 60a. (uchylony)

***
## Art. 61. {#kk-art-61}

§ 1. Sąd może odstąpić od wymierzenia kary w wypadkach 
przewidzianych w ustawie oraz w wypadku określonym w art. 60 § 3, zwłaszcza gdy 
rola sprawcy w popełnieniu przestępstwa była podrzędna, a przekazane informacje 
przyczyniły się do zapobieżenia popełnieniu innego przestępstwa. 
§ 2. Odstępując od wymierzenia kary, sąd może również odstąpić od 
wymierzenia środka karnego, nawiązki na rzecz Skarbu Państwa oraz przepadku, 
chociażby jego orzeczenie było obowiązkowe.

***
## Art. 62. {#kk-art-62}

Orzekając karę pozbawienia wolności, sąd może określić rodzaj i typ 
zakładu karnego, w którym skazany ma odbywać karę, a także orzec system 
terapeutyczny jej wykonania.

***
## Art. 63. {#kk-art-63}

§ 1. Na poczet orzeczonej kary zalicza się okres rzeczywistego 
pozbawienia wolności w sprawie, zaokrąglając w górę do pełnego dnia, przy czym 
jeden dzień rzeczywistego pozbawienia wolności równa się jednemu dniowi kary 
pozbawienia wolności, dwóm dniom kary ograniczenia wolności lub dwóm dziennym 
stawkom grzywny. 

 
 
 
s. 31/146 
 
   
 
2025-04-09 
 
§ 2. Zaliczając okres rzeczywistego pozbawienia wolności na poczet orzeczonej 
grzywny określonej kwotowo, przyjmuje się, że jeden dzień pozbawienia wolności 
odpowiada kwocie równej dwukrotności stawki dziennej ustalonej zgodnie 
z art. 33 § 3. 
§ 3. Na poczet orzeczonych środków karnych, o których mowa w art. 39 pkt 2–
3, zalicza się okres rzeczywistego stosowania odpowiadających im rodzajowo 
środków zapobiegawczych. 
§ 4. Na poczet orzeczonego środka karnego, o którym mowa w art. 39 pkt 3, 
zalicza się okres zatrzymania prawa jazdy lub innego odpowiedniego dokumentu. 
§ 5. Za dzień w rozumieniu § 1 i 2 przyjmuje się okres 24 godzin liczony od 
chwili rzeczywistego pozbawienia wolności. 
### Rozdział VII Powrót do przestępstwa

***
## Art. 64. {#kk-art-64}

§ 1. Jeżeli sprawca skazany za przestępstwo umyślne na karę 
pozbawienia wolności popełnia w ciągu 5 lat po odbyciu co najmniej 6 miesięcy kary 
umyślne przestępstwo podobne do przestępstwa, za które był już skazany, sąd 
wymierza karę przewidzianą za przypisane przestępstwo w wysokości powyżej dolnej 
granicy ustawowego zagrożenia, a może ją wymierzyć w wysokości do górnej granicy 
ustawowego zagrożenia zwiększonego o połowę. 
§ 2. Jeżeli sprawca uprzednio skazany w warunkach określonych w § 1 lub art. 
64a, który odbył łącznie co najmniej rok kary pozbawienia wolności i w ciągu 5 lat po 
odbyciu w całości lub części ostatniej kary popełnia ponownie umyślne przestępstwo 
przeciwko życiu lub zdrowiu, przestępstwo zgwałcenia, rozboju, kradzieży z 
włamaniem lub inne przestępstwo przeciwko mieniu popełnione z użyciem przemocy 
lub groźbą jej użycia, sąd wymierza karę pozbawienia wolności przewidzianą za 
przypisane przestępstwo w wysokości od dolnej granicy ustawowego zagrożenia 
zwiększonego o połowę do górnej granicy ustawowego zagrożenia zwiększonego o 
połowę. 
§ 3. Przewidziane w § 1 lub 2 podwyższenie górnego ustawowego zagrożenia 
nie dotyczy zbrodni. 
Art. 64a. Jeżeli sprawca w ciągu 5 lat po odbyciu co najmniej 6 miesięcy kary 
pozbawienia wolności orzeczonej za zbrodnię zabójstwa w związku ze zgwałceniem 

 
 
 
s. 32/146 
 
   
 
2025-04-09 
 
lub za przestępstwo przeciwko wolności seksualnej zagrożone karą pozbawienia 
wolności, której górna granica wynosi co najmniej 8 lat, popełnia ponownie taką 
zbrodnię lub takie przestępstwo, sąd wymierza karę pozbawienia wolności 
przewidzianą za przypisane przestępstwo w wysokości od dolnej granicy ustawowego 
zagrożenia zwiększonego o połowę do górnej granicy ustawowego zagrożenia 
zwiększonego o połowę. Podwyższenie górnego ustawowego zagrożenia nie dotyczy 
zbrodni.

***
## Art. 65. {#kk-art-65}

§ 1. Przepisy dotyczące wymiaru kary, środków karnych oraz środków 
związanych z poddaniem sprawcy próbie, przewidziane wobec sprawcy określonego 
w art. 64 § 2, stosuje się także do sprawcy, który z popełnienia przestępstwa uczynił 
sobie stałe źródło dochodu lub popełnia przestępstwo działając w zorganizowanej 
grupie albo związku mających na celu popełnienie przestępstwa oraz wobec sprawcy 
przestępstwa o charakterze terrorystycznym. 
§ 2. Do sprawcy przestępstwa z art. 258 mają odpowiednie zastosowanie 
przepisy dotyczące sprawcy określonego w art. 64 § 2, z wyjątkiem przewidzianego 
w tym przepisie zaostrzenia kary. 
### Rozdział VIII Środki związane z poddaniem sprawcy próbie

***
## Art. 66. {#kk-art-66}

§ 1. Sąd może warunkowo umorzyć postępowanie karne, jeżeli wina 
i społeczna szkodliwość czynu nie są znaczne, okoliczności jego popełnienia nie 
budzą wątpliwości, a postawa sprawcy niekaranego za przestępstwo umyślne, jego 
właściwości i warunki osobiste oraz dotychczasowy sposób życia uzasadniają 
przypuszczenie, że pomimo umorzenia postępowania będzie przestrzegał porządku 
prawnego, w szczególności nie popełni przestępstwa. 
§ 2. Warunkowego umorzenia nie stosuje się do sprawcy przestępstwa 
zagrożonego karą przekraczającą 5 lat pozbawienia wolności.

***
## Art. 67. {#kk-art-67}

§ 1. Warunkowe umorzenie następuje na okres próby, który wynosi od 
roku do 3 lat i biegnie od uprawomocnienia się orzeczenia. 
§ 2. Umarzając warunkowo postępowanie karne, sąd może w okresie próby 
oddać sprawcę pod dozór kuratora lub osoby godnej zaufania, stowarzyszenia, 
instytucji albo organizacji społecznej, do której działalności należy troska o 
wychowanie, zapobieganie demoralizacji lub pomoc skazanym. 

 
 
 
s. 33/146 
 
   
 
2025-04-09 
 
§ 3. Umarzając warunkowo postępowanie karne, sąd nakłada na sprawcę 
obowiązek naprawienia szkody w całości albo w części, a w miarę możliwości 
również obowiązek zadośćuczynienia za doznaną krzywdę, albo zamiast tych 
obowiązków orzeka nawiązkę; sąd może nałożyć na sprawcę obowiązki wymienione 
w art. 72 § 1 pkt 1–3, 5–6b, 7a lub 7b, a ponadto orzec świadczenie pieniężne 
wymienione w art. 39 pkt 7 lub zakaz prowadzenia pojazdów, wymieniony w art. 39 
pkt 3, do lat 2. Przepisy art. 72 § 1a i 1b stosuje się odpowiednio. 
§ 4. Przepis art. 74 stosuje się odpowiednio.

***
## Art. 68. {#kk-art-68}

§ 1. Sąd podejmuje postępowanie karne, jeżeli sprawca w okresie próby 
popełnił przestępstwo umyślne, za które został prawomocnie skazany. 
§ 2. Sąd może podjąć postępowanie karne, jeżeli sprawca w okresie próby rażąco 
narusza porządek prawny, w szczególności gdy popełnił inne niż określone 
w § 1 przestępstwo, jeżeli uchyla się od dozoru, wykonania nałożonego obowiązku 
lub orzeczonego środka karnego, środka kompensacyjnego lub przepadku albo nie 
wykonuje zawartej z pokrzywdzonym ugody. 
§ 2a. Sąd podejmuje postępowanie karne, jeżeli okoliczności, o których mowa 
w § 2, zaistnieją po udzieleniu sprawcy  
pisemnego upomnienia przez sądowego kuratora zawodowego, chyba że 
przemawiają przeciwko temu szczególne względy. 
§ 3. Sąd może podjąć postępowanie karne, jeżeli sprawca po wydaniu orzeczenia 
o warunkowym umorzeniu postępowania, lecz przed jego uprawomocnieniem się, 
rażąco narusza porządek prawny, a w szczególności gdy w tym czasie popełnił 
przestępstwo. 
§ 4. Warunkowo umorzonego postępowania nie można podjąć później niż 
w ciągu 6 miesięcy od zakończenia okresu próby.

***
## Art. 69. {#kk-art-69}

§ 1. Sąd może warunkowo zawiesić wykonanie kary pozbawienia 
wolności orzeczonej w wymiarze nieprzekraczającym roku, jeżeli sprawca w czasie 
popełnienia przestępstwa nie był skazany na karę pozbawienia wolności i jest to 
wystarczające dla osiągnięcia wobec niego celów kary, a w szczególności 
zapobieżenia powrotowi do przestępstwa. 

 
 
 
s. 34/146 
 
   
 
2025-04-09 
 
§ 2. Zawieszając wykonanie kary, sąd bierze pod uwagę przede wszystkim 
postawę sprawcy, jego właściwości i warunki osobiste, dotychczasowy sposób życia 
oraz zachowanie się po popełnieniu przestępstwa. 
§ 3. (uchylony) 
§ 4. Wobec sprawcy występku o charakterze chuligańskim oraz sprawcy 
przestępstwa określonego w art. 178a § 4 sąd może warunkowo zawiesić wykonanie 
kary jedynie w szczególnie uzasadnionych wypadkach.

***
## Art. 70. {#kk-art-70}

§ 1. Zawieszenie wykonania kary następuje na okres próby, który 
wynosi od roku do 3 lat i biegnie od uprawomocnienia się wyroku. 
§ 2. W wypadku zawieszenia wykonania kary wobec sprawcy młodocianego 
oraz sprawcy, który popełnił przestępstwo z użyciem przemocy na szkodę osoby 
wspólnie zamieszkującej, okres próby wynosi od 2 do 5 lat.

***
## Art. 71. {#kk-art-71}

§ 1. Zawieszając wykonanie kary, sąd może orzec grzywnę, jeżeli jej 
wymierzenie obok kary pozbawienia wolności na innej podstawie nie jest możliwe. 
§ 2. W razie zarządzenia wykonania kary grzywna orzeczona na podstawie 
§ 1 nie podlega wykonaniu; kara pozbawienia wolności ulega skróceniu o okres 
odpowiadający połowie liczby uiszczonych stawek dziennych grzywny z zaokrąg-
leniem w górę do pełnego dnia.

***
## Art. 72. {#kk-art-72}

§ 1. Zawieszając wykonanie kary, sąd zobowiązuje, a jeżeli orzeka 
środek karny, może zobowiązać skazanego do: 
- 1) informowania sądu lub kuratora o przebiegu okresu próby, 
- 2) przeproszenia pokrzywdzonego, 
- 3) wykonywania ciążącego na nim obowiązku łożenia na utrzymanie innej osoby, 
- 4) wykonywania pracy zarobkowej, do nauki lub przygotowania się do zawodu, 
- 5) powstrzymania się od nadużywania alkoholu lub używania innych środków 
odurzających, 
- 6) poddania się terapii uzależnień, 
6a) poddania się terapii, w szczególności psychoterapii lub psychoedukacji, 
6b) uczestnictwa w oddziaływaniach korekcyjno-edukacyjnych, 
- 7) powstrzymania się od przebywania w określonych środowiskach lub miejscach, 
7a) powstrzymania się od kontaktowania się z pokrzywdzonym lub innymi osobami 
w określony sposób lub zbliżania się do pokrzywdzonego lub innych osób, 

 
 
 
s. 35/146 
 
   
 
2025-04-09 
 
7b) opuszczenia lokalu zajmowanego wspólnie z pokrzywdzonym, 
- 8) innego stosownego postępowania w okresie próby, które może zapobiec 
popełnieniu ponownie przestępstwa 
– przy czym orzeka się przynajmniej jeden z obowiązków. 
§ 1a. Nakładając obowiązek wymieniony w § 1 pkt 7a, sąd wskazuje minimalną 
odległość od osób chronionych, którą skazany obowiązany jest zachować. 
§ 1b. Nakładając na sprawcę przestępstwa popełnionego z użyciem przemocy 
lub groźby bezprawnej wobec osoby najbliższej obowiązek wymieniony w § 1 pkt 7b, 
sąd określa sposób kontaktu skazanego z pokrzywdzonym. 
§ 2. Sąd może orzec świadczenie pieniężne wymienione w art. 39 pkt 7 albo 
zobowiązać skazanego do naprawienia wyrządzonej przestępstwem szkody w całości 
albo w części, chyba że orzekł środek kompensacyjny.

***
## Art. 73. {#kk-art-73}

§ 1. Zawieszając wykonanie kary, sąd może w okresie próby oddać 
skazanego pod dozór kuratora lub osoby godnej zaufania, stowarzyszenia, instytucji 
albo organizacji społecznej, do której działalności należy troska o wychowanie, 
zapobieganie demoralizacji lub pomoc skazanym. 
§ 2. Dozór jest obowiązkowy wobec młodocianego sprawcy przestępstwa 
umyślnego, sprawcy określonego w art. 64 § 2 lub art. 64a, a także wobec sprawcy 
przestępstwa popełnionego w związku z zaburzeniami preferencji seksualnych oraz 
sprawcy, który popełnił przestępstwo z użyciem przemocy na szkodę osoby wspólnie 
zamieszkującej.

***
## Art. 74. {#kk-art-74}

§ 1. Czas i sposób wykonania nałożonych obowiązków wymienionych 
w art. 72 sąd 
określa 
po 
wysłuchaniu 
skazanego; 
nałożenie 
obowiązków 
wymienionych w art. 72 § 1 pkt 6 i 6a wymaga nadto zgody skazanego. 
§ 2. Jeżeli względy wychowawcze za tym przemawiają, sąd, wobec skazanego 
na karę z warunkowym zawieszeniem jej wykonania, może w okresie próby 
ustanawiać, rozszerzać lub zmieniać obowiązki wymienione w art. 72 § 1 pkt 3–8 albo 
od 
wykonania 
nałożonych 
obowiązków 
zwolnić, 
z wyjątkiem 
obowiązku 
wymienionego w art. 72 § 2, jak również oddać skazanego pod dozór albo od dozoru 
zwolnić. 
§ 2a. Zwolnienie od dozoru może nastąpić także, jeżeli sprawowanie dozoru jest 
niemożliwe albo znacznie utrudnione z przyczyn niezawinionych przez skazanego. 

 
 
 
s. 36/146 
 
   
 
2025-04-09 
 
§ 3. W przypadku gdy skazany został oddany pod dozór lub zobowiązany do 
wykonywania obowiązków w okresie próby, wniosek o określenie czasu i sposobu 
wykonania nałożonych obowiązków może złożyć również sądowy kurator zawodowy, 
a także osoba godna zaufania lub przedstawiciel stowarzyszenia, instytucji albo 
organizacji społecznej, o której mowa w art. 73 § 1.

***
## Art. 75. {#kk-art-75}

§ 1. Sąd zarządza wykonanie kary, jeżeli skazany w okresie próby 
popełnił podobne przestępstwo umyślne, za które orzeczono prawomocnie karę 
pozbawienia wolności bez warunkowego zawieszenia jej wykonania. 
§ 1a. Sąd zarządza wykonanie kary jeżeli skazany za przestępstwo popełnione 
z użyciem przemocy lub groźby bezprawnej wobec osoby najbliższej lub innej osoby 
małoletniej zamieszkujących wspólnie ze sprawcą w okresie próby rażąco narusza 
porządek prawny, ponownie używając przemocy lub groźby bezprawnej wobec osoby 
najbliższej lub innej osoby małoletniej zamieszkujących wspólnie ze sprawcą. 
§ 2. Sąd może zarządzić wykonanie kary, jeżeli skazany w okresie próby rażąco 
narusza porządek prawny, w szczególności gdy popełnił inne przestępstwo niż 
określone w § 1, albo jeżeli uchyla się od uiszczenia grzywny, od dozoru, wykonania 
nałożonych 
obowiązków 
lub 
orzeczonych 
środków 
karnych, 
środków 
kompensacyjnych lub przepadku. 
§ 2a. Sąd zarządza wykonanie kary, jeżeli okoliczności, o których mowa w § 2, 
zaistnieją po udzieleniu skazanemu pisemnego upomnienia przez sądowego kuratora 
zawodowego, chyba że przemawiają przeciwko temu szczególne względy. 
§ 3. Sąd może zarządzić wykonanie kary, jeżeli skazany po wydaniu wyroku, 
lecz przed jego uprawomocnieniem się, rażąco narusza porządek prawny, 
a w szczególności gdy w tym czasie popełnił przestępstwo. 
§ 3a. Zarządzając wykonanie kary w wypadkach, o których mowa w § 2 i 3, sąd 
może, uwzględniając dotychczasowy przebieg próby, a w szczególności wykonanie 
nałożonych obowiązków, skrócić orzeczoną karę, nie więcej jednak niż o połowę. 
§ 4. Zarządzenie wykonania kary nie może nastąpić później niż w ciągu roku od 
zakończenia okresu próby. 
§ 5. (uchylony) 
Art. 75a. (uchylony) 

 
 
 
s. 37/146 
 
   
 
2025-04-09

***
## Art. 76. {#kk-art-76}

§ 1. Skazanie ulega zatarciu z mocy prawa z upływem roku od 
zakończenia okresu próby. 
§ 1a. (uchylony) 
§ 1b. W wypadku, o którym mowa w § 1, przepis art. 108 stosuje się. 
§ 2. Jeżeli wobec skazanego orzeczono grzywnę, środek karny, przepadek lub 
środek kompensacyjny, zatarcie skazania nie może nastąpić przed ich wykonaniem, 
darowaniem albo przedawnieniem ich wykonania. Zatarcie skazania nie może nastąpić 
również przed wykonaniem środka zabezpieczającego.

***
## Art. 77. {#kk-art-77}

§ 1. Skazanego na karę pozbawienia wolności sąd może warunkowo 
zwolnić z odbycia reszty kary tylko wówczas, gdy jego postawa, właściwości 
i warunki osobiste, okoliczności popełnienia przestępstwa oraz zachowanie po jego 
popełnieniu i w czasie odbywania kary uzasadniają przekonanie, że skazany po 
zwolnieniu będzie stosował się do orzeczonego środka karnego lub zabezpieczającego 
i przestrzegał 
porządku prawnego, w szczególności 
nie popełni ponownie 
przestępstwa. 
§ 2. W szczególnie uzasadnionych wypadkach sąd, wymierzając karę 
wymienioną w art. 32 pkt 3 lub 5, może wyznaczyć surowsze ograniczenia do 
skorzystania przez skazanego z warunkowego zwolnienia niż przewidziane w art. 78. 
§ 3. Wymierzając karę dożywotniego pozbawienia wolności sprawcy za czyn 
popełniony przez niego po prawomocnym skazaniu za przestępstwo przeciwko życiu 
i zdrowiu, wolności, wolności seksualnej, bezpieczeństwu powszechnemu lub za 
przestępstwo o charakterze terrorystycznym na karę dożywotniego pozbawienia 
wolności albo karę pozbawienia wolności na czas nie krótszy niż 20 lat, sąd może 
orzec zakaz warunkowego zwolnienia.  
§ 4. Wymierzając karę dożywotniego pozbawienia wolności, sąd może orzec 
zakaz warunkowego zwolnienia sprawcy, jeżeli charakter i okoliczności czynu oraz 
właściwości osobiste sprawcy wskazują, iż jego pozostawanie na wolności spowoduje 
trwałe niebezpieczeństwo dla życia, zdrowia, wolności lub wolności seksualnej innych 
osób.

***
## Art. 78. {#kk-art-78}

§ 1. Skazanego można warunkowo zwolnić po odbyciu co najmniej 
połowy kary, a jeżeli wymierzono karę pozbawienia wolności na czas nie krótszy niż 
25 lat – po odbyciu co najmniej 15 lat kary.  

 
 
 
s. 38/146 
 
   
 
2025-04-09 
 
§ 2. Skazanego określonego w art. 64 § 1 można warunkowo zwolnić po 
odbyciu dwóch trzecich kary, natomiast skazanego określonego w art. 64 § 2 lub 
art. 64a oraz skazanego, wobec którego wydano prawomocne postanowienie 
stwierdzające, że bezprawnie utrudniał wykonanie kary pozbawienia wolności, po 
odbyciu trzech czwartych kary. 
§ 3. Skazanego na karę dożywotniego pozbawienia wolności można warunkowo 
zwolnić po odbyciu 30 lat kary.

***
## Art. 79. {#kk-art-79}

§ 1. Przepisy art. 78 § 1 i 2 stosuje się odpowiednio do sumy dwóch lub 
więcej niepodlegających łączeniu kar pozbawienia wolności, które skazany ma odbyć 
kolejno. Przepis art. 78 § 2 stosuje się, jeżeli chociażby jedno z przestępstw 
popełniono w warunkach określonych w art. 64 lub art. 64a lub wobec skazanego 
wydano prawomocne postanowienie stwierdzające, że bezprawnie utrudniał 
wykonanie kary pozbawienia wolności. 
§ 2. Skazanego można, niezależnie od warunków określonych w art. 78 § 1 lub 
2, zwolnić warunkowo po odbyciu 25 lat pozbawienia wolności.  
§ 3. Przepis art. 78 § 3 stosuje się odpowiednio, jeżeli chociażby jedna z kar, 
które skazany ma odbyć kolejno, jest karą dożywotniego pozbawienia wolności.

***
## Art. 80. {#kk-art-80}

§ 1. W razie warunkowego zwolnienia czas pozostały do odbycia kary 
stanowi okres próby, który jednak nie może być krótszy niż 2 lata ani dłuższy niż 5 lat. 
§ 2. Jeżeli skazanym jest osoba określona w art. 64 § 2 lub art. 64a, okres próby 
nie może być krótszy niż 3 lata. 
§ 2a. W razie warunkowego zwolnienia z kary pozbawienia wolności w 
wymiarze 25 lat lub surowszym okres próby wynosi 10 lat. 
§ 3. W razie warunkowego zwolnienia z kary dożywotniego pozbawienia 
wolności okres próby trwa dożywotnio.

***
## Art. 81. {#kk-art-81}

W razie odwołania warunkowego zwolnienia ponowne warunkowe 
zwolnienie nie może nastąpić przed odbyciem, po ponownym osadzeniu, przynajmniej 
roku kary pozbawienia wolności, a w wypadku kary dożywotniego pozbawienia 
wolności przed odbyciem przynajmniej 5 lat kary.

***
## Art. 82. {#kk-art-82}

§ 1. Jeżeli w okresie próby i w ciągu 6 miesięcy od jej zakończenia nie 
odwołano warunkowego zwolnienia, karę uważa się za odbytą z chwilą warunkowego 
zwolnienia. 

 
 
 
s. 39/146 
 
   
 
2025-04-09 
 
§ 2. W wypadku objęcia wyrokiem łącznym kary, z której odbywania skazany 
został warunkowo zwolniony, na poczet orzeczonej kary łącznej zalicza się jedynie 
okres faktycznego odbywania kary.

***
## Art. 83. {#kk-art-83}

Skazanego na karę ograniczenia wolności, który odbył przynajmniej 
połowę orzeczonej kary, przy czym przestrzegał porządku prawnego, jak również 
wykonał nałożone na niego obowiązki, orzeczone środki karne, środki kompensacyjne 
i przepadek, sąd może zwolnić od reszty kary, uznając ją za wykonaną.

***
## Art. 84. {#kk-art-84}

§ 1. Sąd może po upływie połowy okresu, na który orzeczono środki 
karne wymienione w art. 39 pkt 1–3, uznać je za wykonane, jeżeli skazany 
przestrzegał porządku prawnego, a środek karny był w stosunku do niego 
wykonywany przynajmniej przez rok. 
§ 2. Przepisu § 1 nie stosuje się, jeżeli środki karne wymienione w art. 39 pkt 2, 
2a i 3 orzeczono na podstawie art. 41 § 1a albo art. 42 § 2. 
§ 2a. Jeżeli środek karny orzeczony został dożywotnio, sąd może uznać go za 
wykonany, jeżeli skazany przestrzegał porządku prawnego i nie zachodzi obawa 
ponownego popełnienia przestępstwa podobnego do tego, za które orzeczono środek 
karny, a środek karny był w stosunku do skazanego wykonywany przynajmniej przez 
15 lat. 
§ 3. Sąd może zwolnić skazanego z obowiązku orzeczonego na podstawie 
art. 41b § 5 lub 7 po upływie połowy okresu, na który go orzeczono, jeżeli obowiązek 
był stosowany przynajmniej przez rok, a zachowanie skazanego wskazuje, że dalsze 
stosowanie obowiązku nie jest niezbędne do spełnienia celów środka karnego. 
Art. 84a. (uchylony) 
### Rozdział IX Zbieg przestępstw oraz łączenie kar i środków karnych

***
## Art. 85. {#kk-art-85}

§ 1. Jeżeli sprawca popełnił dwa lub więcej przestępstw, zanim zapadł 
pierwszy wyrok, chociażby nieprawomocny, co do któregokolwiek z tych przestępstw 
i wymierzono za nie kary tego samego rodzaju albo inne podlegające łączeniu, sąd 
orzeka karę łączną, biorąc za podstawę kary z osobna wymierzone za zbiegające się 
przestępstwa. 

 
 
 
s. 40/146 
 
   
 
2025-04-09 
 
§ 2. Karą łączną nie obejmuje się kar orzeczonych wyrokami, o których mowa 
w art. 114a. 
Art. 85a. Orzekając karę łączną, sąd bierze pod uwagę przede wszystkim cele 
kary w zakresie społecznego oddziaływania, a także cele zapobiegawcze, które ma ona 
osiągnąć w stosunku do skazanego.

***
## Art. 86. {#kk-art-86}

§ 1. Sąd wymierza karę łączną w granicach powyżej najwyższej z kar 
wymierzonych za poszczególne przestępstwa do ich sumy, nie przekraczając jednak 
810 stawek dziennych grzywny, 2 lat ograniczenia wolności albo 30 lat pozbawienia 
wolności. Jeżeli najwyższą z kar wymierzonych za poszczególne przestępstwa jest 
kara 810 stawek dziennych grzywny, 2 lat ograniczenia wolności albo 30 lat 
pozbawienia wolności, orzeka się tę karę jako karę łączną. Karę pozbawienia wolności 
wymierza się w miesiącach i latach. 
§ 1a. (uchylony) 
§ 2. Wymierzając karę łączną grzywny, sąd określa na nowo wysokość stawki 
dziennej, kierując się wskazaniami określonymi w art. 33 § 3; wysokość stawki 
dziennej nie może jednak przekraczać najwyższej ustalonej poprzednio. 
§ 2a. Jeżeli chociażby jedna z podlegających łączeniu grzywien jest wymierzona 
kwotowo, karę łączną grzywny wymierza się kwotowo. 
§ 2b. Jeżeli chociażby jedna z podlegających łączeniu grzywien została 
orzeczona na podstawie przepisu przewidującego wyższą górną granicę ustawowego 
zagrożenia tą karą niż określona w art. 33 § 1, sąd wymierza karę łączną grzywny w 
granicach powyżej najwyższej z kar tego rodzaju wymierzonych za poszczególne 
przestępstwa do ich sumy, nie przekraczając jednak 4500 stawek dziennych grzywny. 
Jeżeli najwyższa z podlegających łączeniu grzywien orzeczona została w wymiarze 
4500 stawek dziennych lub wyższym, sąd orzeka tę karę jako karę łączną grzywny. 
§ 3. Wymierzając karę łączną ograniczenia wolności, sąd określa na nowo 
obowiązki lub wymiar potrącenia, o których mowa w art. 34 § 1a, a także może 
nałożyć na sprawcę obowiązki wymienione w art. 72 § 1 pkt 2–7a, jak również orzec 
świadczenie pieniężne wymienione w art. 39 pkt 7. 
§ 4. (uchylony) 

 
 
 
s. 41/146 
 
   
 
2025-04-09

***
## Art. 87. {#kk-art-87}

§ 1.3) W razie skazania za zbiegające się przestępstwa na kary 
pozbawienia wolności i ograniczenia wolności sąd wymierza karę łączną pozbawienia 
wolności, przyjmując, że miesiąc ograniczenia wolności równa się 15 dniom 
pozbawienia wolności. 
§ 2. Jeżeli za zbiegające się przestępstwa wymierzono kary pozbawienia 
wolności oraz ograniczenia wolności i kara łączna pozbawienia wolności nie 
przekroczyłaby 6 miesięcy, a kara łączna ograniczenia wolności – 2 lat, sąd może 
orzec te kary łączne jednocześnie, jeżeli cele kary zostaną w ten sposób spełnione.

***
## Art. 88. {#kk-art-88}

Jeżeli najsurowszą karą orzeczoną za jedno ze zbiegających się 
przestępstw jest kara dożywotniego pozbawienia wolności, orzeka się tę karę jako karę 
łączną; w wypadku zbiegu dwóch lub więcej kar pozbawienia wolności w wymiarze 
przynajmniej 25 lat sąd może orzec jako karę łączną karę dożywotniego pozbawienia 
wolności.

***
## Art. 89. {#kk-art-89}

§ 1. W razie skazania za zbiegające się przestępstwa na kary 
pozbawienia wolności z warunkowym zawieszeniem i bez warunkowego zawieszenia 
ich wykonania sąd może warunkowo zawiesić wykonanie kary łącznej w wymiarze 
nieprzekraczającym roku, jeżeli sprawca w czasie popełnienia każdego z tych 
przestępstw nie był skazany na karę pozbawienia wolności i jest to wystarczające do 
osiągnięcia wobec niego celów kary, a w szczególności zapobieżenia powrotowi do 
przestępstwa. 
§ 1a. W razie skazania za zbiegające się przestępstwa na kary pozbawienia 
wolności z warunkowym zawieszeniem ich wykonania sąd może w wyroku łącznym 
orzec karę łączną pozbawienia wolności bez warunkowego zawieszenia jej 
wykonania. 
§ 1b. Sąd orzeka karę łączną pozbawienia wolności bez warunkowego 
zawieszenia jej wykonania, przyjmując, że miesiąc kary pozbawienia wolności 
z warunkowym zawieszeniem jej wykonania równa się 15 dniom kary pozbawienia 
wolności bez warunkowego zawieszenia jej wykonania. 
§ 2. (uchylony) 
- 3) Utracił moc z dniem 18 czerwca 2019 r. w zakresie, w jakim nakłada na sąd obowiązek połączenia kar 
pozbawienia wolności i ograniczenia wolności oraz wymierzenia kary łącznej pozbawienia wolności 
po dokonaniu zamiany kary ograniczenia wolności na karę pozbawienia wolności, na podstawie 
wyroku Trybunału Konstytucyjnego z dnia 11 czerwca 2019 r. sygn. akt P 20/17 (Dz. U. poz. 1135). 

 
 
 
s. 42/146 
 
   
 
2025-04-09 
 
§ 3. (uchylony) 
Art. 89a. § 1. Jeżeli chociażby jedną z kar podlegających łączeniu jest kara 
pozbawienia wolności z warunkowym zawieszeniem jej wykonania orzeczona na 
podstawie art. 60 § 5, a kara ta nie podlega łączeniu z surowszą karą pozbawienia 
wolności, sąd może wymierzyć karę łączną pozbawienia wolności w wymiarze 
równym karze pozbawienia wolności z warunkowym zawieszeniem jej wykonania 
orzeczonej na podstawie art. 60 § 5, o ile jednocześnie stosuje warunkowe 
zawieszenie wykonania kary łącznej. 
§ 2. Orzekając karę łączną pozbawienia wolności z warunkowym zawieszeniem 
jej wykonania, sąd może orzec grzywnę określoną w art. 71 § 1, chociażby jej nie 
orzeczono za pozostające w zbiegu przestępstwa. 
§ 3. W razie zbiegu orzeczeń o okresach próby sąd orzeka okres próby oraz 
związane z nim obowiązki na nowo. W razie zbiegu orzeczeń, o którym mowa w § 1, 
okres próby może wynosić do 10 lat.

***
## Art. 90. {#kk-art-90}

§ 1. Środki karne, przepadek, środki kompensacyjne, środki 
zabezpieczające oraz dozór stosuje się, chociażby orzeczono je tylko co do jednego ze 
zbiegających się przestępstw. 
§ 2. W razie orzeczenia za zbiegające się przestępstwa pozbawienia praw 
publicznych, zakazów lub obowiązku tego samego rodzaju, sąd stosuje odpowiednio 
przepisy o karze łącznej.

***
## Art. 91. {#kk-art-91}

§ 1. 
Jeżeli 
sprawca 
popełnia 
w krótkich 
odstępach 
czasu, 
z wykorzystaniem takiej samej sposobności, dwa lub więcej przestępstw, zanim 
zapadł pierwszy wyrok, chociażby nieprawomocny, co do któregokolwiek z tych 
przestępstw, sąd orzeka jedną karę określoną w przepisie stanowiącym podstawę jej 
wymiaru dla każdego z tych przestępstw, w wysokości do górnej granicy ustawowego 
zagrożenia zwiększonego o połowę. 
§ 2. Jeżeli sprawca w warunkach określonych w art. 85 § 1 popełnia dwa lub 
więcej ciągów przestępstw określonych w § 1 lub ciąg przestępstw oraz inne 
przestępstwo, sąd orzeka karę łączną, stosując odpowiednio przepisy tego rozdziału. 
§ 3. Jeżeli sprawca został skazany dwoma lub więcej wyrokami za przestępstwa 
należące do ciągu przestępstw określonego w § 1, orzeczona kara łączna nie może 
przekroczyć górnej granicy ustawowego zagrożenia zwiększonego o połowę, 

 
 
 
s. 43/146 
 
   
 
2025-04-09 
 
przewidzianego w przepisie stanowiącym podstawę wymiaru kary dla każdego z tych 
przestępstw. 
Art. 91a. Wydaniu wyroku łącznego nie stoi na przeszkodzie, że poszczególne 
kary wymierzone za należące do ciągu przestępstw lub zbiegające się przestępstwa 
zostały już w całości albo w części wykonane. Przepis art. 71 § 2 stosuje się 
odpowiednio.

***
## Art. 92. {#kk-art-92}

(uchylony) 
Art. 92a. (uchylony) 
### Rozdział X Środki zabezpieczające

***
## Art. 93. {#kk-art-93}

(uchylony) 
Art. 93a. § 1. Środkami zabezpieczającymi są: 
- 1) elektroniczna kontrola miejsca pobytu; 
- 2) terapia; 
- 3) terapia uzależnień; 
- 4) pobyt w zakładzie psychiatrycznym. 
§ 2. Jeżeli ustawa tak stanowi, tytułem środka zabezpieczającego można orzec 
nakaz i zakazy określone w art. 39 pkt 2–3. 
Art. 93b. § 1. Sąd może orzec środek zabezpieczający, gdy jest to konieczne, aby 
zapobiec ponownemu popełnieniu przez sprawcę czynu zabronionego, a inne środki 
prawne określone w tym kodeksie lub orzeczone na podstawie innych ustaw nie są 
wystarczające. Środek zabezpieczający, o którym mowa w art. 93a § 1 pkt 4, można 
orzec jedynie, aby zapobiec ponownemu popełnieniu przez sprawcę czynu 
zabronionego o znacznej społecznej szkodliwości. 
§ 2. Sąd uchyla środek zabezpieczający, gdy dalsze jego stosowanie nie jest już 
konieczne. 
§ 3. Środek zabezpieczający i sposób jego wykonywania powinien być 
odpowiedni do stopnia społecznej szkodliwości czynu zabronionego, który sprawca 
może popełnić, oraz prawdopodobieństwa jego popełnienia, a także uwzględniać 
potrzeby i postępy w terapii lub terapii uzależnień. Sąd może zmienić orzeczony 
wobec sprawcy środek zabezpieczający lub sposób jego wykonywania, jeżeli 

 
 
 
s. 44/146 
 
   
 
2025-04-09 
 
poprzednio orzeczony środek stał się nieodpowiedni lub jego wykonywanie nie jest 
możliwe. 
§ 4. Wobec tego samego sprawcy można orzec więcej niż jeden środek 
zabezpieczający; przepisy § 1 i 3 stosuje się, biorąc pod uwagę wszystkie orzekane 
środki zabezpieczające. 
§ 5. Sąd orzeka pobyt w zakładzie psychiatrycznym tylko wtedy, gdy ustawa tak 
stanowi. 
Art. 93c. Środki zabezpieczające można orzec wobec sprawcy: 
- 1) co do którego umorzono postępowanie o czyn zabroniony popełniony w stanie 
niepoczytalności określonej w art. 31 § 1; 
- 2) w razie skazania za przestępstwo popełnione w stanie ograniczonej 
poczytalności określonej w art. 31 § 2; 
- 3) w razie skazania za przestępstwo określone w art. 148, art. 156, art. 197, art. 198, 
art. 199 § 2 lub art. 200 § 1, 3 lub 4, popełnione w związku z zaburzeniem 
preferencji seksualnych; 
- 4) w razie skazania na karę pozbawienia wolności bez warunkowego jej 
zawieszenia za umyślne przestępstwo określone w rozdziale XIX, XXIII, XXV 
lub XXVI, popełnione w związku z zaburzeniem osobowości o takim 
charakterze lub nasileniu, że zachodzi co najmniej wysokie prawdopodobieństwo 
popełnienia czynu zabronionego z użyciem przemocy lub groźbą jej użycia; 
- 5) w razie skazania za przestępstwo popełnione w związku z uzależnieniem od 
alkoholu, środka odurzającego lub innego podobnie działającego środka. 
Art. 93d. § 1. Czasu stosowania środka zabezpieczającego nie określa się z góry. 
§ 2. Uchylając 
środek 
zabezpieczający 
w postaci 
pobytu 
w zakładzie 
psychiatrycznym, sąd może orzec jeden lub więcej ze środków zabezpieczających, 
o których mowa w art. 93a § 1 pkt 1–3. 
§ 3. Sąd ustala potrzebę i możliwości wykonania orzeczonego środka 
zabezpieczającego nie wcześniej niż na 6 miesięcy przed przewidywanym 
warunkowym zwolnieniem lub odbyciem kary pozbawienia wolności. 
§ 4. Jeżeli wobec sprawcy wykonywana jest kara pozbawienia wolności, środki 
zabezpieczające, o których mowa w art. 93a § 1 pkt 1–3, można orzec również do 
czasu wykonania tej kary, jednak nie wcześniej niż na 6 miesięcy przed 

 
 
 
s. 45/146 
 
   
 
2025-04-09 
 
przewidywanym warunkowym zwolnieniem lub odbyciem kary pozbawienia 
wolności. 
§ 5. Jeżeli sprawca został skazany na karę pozbawienia wolności bez 
warunkowego zawieszenia jej wykonania lub karę dożywotniego pozbawienia 
wolności, orzeczony środek zabezpieczający stosuje się po odbyciu kary lub 
warunkowym zwolnieniu, chyba że ustawa stanowi inaczej. 
§ 6. Jeżeli zachowanie sprawcy po uchyleniu środka zabezpieczającego 
wskazuje, że zachodzi konieczność stosowania środków zabezpieczających, sąd, nie 
później niż w ciągu 3 lat od uchylenia środka, może ponownie orzec ten sam środek 
zabezpieczający lub inny środek, o którym mowa w art. 93a § 1 pkt 1–3. 
Art. 93e. Sprawca, wobec którego orzeczono elektroniczną kontrolę miejsca 
pobytu, ma obowiązek poddania się nieprzerwanej kontroli miejsca swojego pobytu 
sprawowanej za pomocą urządzeń technicznych, w tym noszonego nadajnika. 
Art. 93f. § 1. Sprawca, wobec którego orzeczono terapię, ma obowiązek 
stawiennictwa we wskazanej przez sąd placówce w terminach wyznaczonych przez 
lekarza psychiatrę, seksuologa lub terapeutę i poddania się terapii farmakologicznej 
zmierzającej do osłabienia popędu seksualnego, psychoterapii lub psychoedukacji 
w celu poprawy jego funkcjonowania w społeczeństwie. 
§ 2. Sprawca, wobec którego orzeczono terapię uzależnień, ma obowiązek 
stawiennictwa we wskazanej przez sąd placówce leczenia odwykowego w terminach 
wyznaczonych przez lekarza i poddania się leczeniu uzależnienia od alkoholu, środka 
odurzającego lub innego podobnie działającego środka. 
Art. 93g. § 1. Sąd orzeka pobyt w odpowiednim zakładzie psychiatrycznym 
wobec 
sprawcy 
określonego 
w art. 93c 
pkt 1, 
jeżeli 
istnieje 
wysokie 
prawdopodobieństwo, że popełni on ponownie czyn zabroniony o znacznej społecznej 
szkodliwości w związku z chorobą psychiczną lub upośledzeniem umysłowym. 
§ 2. Skazując sprawcę określonego w art. 93c pkt 2 na karę pozbawienia 
wolności bez warunkowego zawieszenia jej wykonania lub karę dożywotniego 
pozbawienia wolności, sąd orzeka pobyt w odpowiednim zakładzie psychiatrycznym, 
jeżeli istnieje wysokie prawdopodobieństwo, że popełni on czyn zabroniony o 
znacznej społecznej szkodliwości w związku z chorobą psychiczną lub upośledzeniem 
umysłowym. 

 
 
 
s. 46/146 
 
   
 
2025-04-09 
 
§ 3. Skazując sprawcę określonego w art. 93c pkt 3 na karę pozbawienia 
wolności bez warunkowego zawieszenia jej wykonania lub karę dożywotniego 
pozbawienia wolności, sąd orzeka pobyt w odpowiednim zakładzie psychiatrycznym, 
jeżeli istnieje wysokie prawdopodobieństwo, że skazany popełni przestępstwo 
przeciwko życiu, zdrowiu lub wolności seksualnej w związku z zaburzeniem 
preferencji seksualnych.

***
## Art. 94. {#kk-art-94}

(uchylony)

***
## Art. 95. {#kk-art-95}

(uchylony) 
Art. 95a. (uchylony)

***
## Art. 96. {#kk-art-96}

(uchylony)

***
## Art. 97. {#kk-art-97}

(uchylony)

***
## Art. 98. {#kk-art-98}

(uchylony)

***
## Art. 99. {#kk-art-99}

§ 1. Jeżeli sprawca dopuścił się czynu zabronionego w stanie 
niepoczytalności określonej w art. 31 § 1, sąd może orzec tytułem środka 
zabezpieczającego nakaz lub zakazy wymienione w art. 39 pkt 2–3. 
§ 2. Zakazy wymienione w art. 39 pkt 2–3 orzeka się bez określenia czasu ich 
obowiązywania; sąd uchyla je, gdy ustały przyczyny ich orzeczenia.

***
## Art. 100. {#kk-art-100}

(uchylony) 
### Rozdział XI Przedawnienie

***
## Art. 101. {#kk-art-101}

§ 1. Karalność przestępstwa ustaje, jeżeli od czasu jego popełnienia 
upłynęło lat: 
- 1) 40 – gdy czyn stanowi zbrodnię zabójstwa; 
- 2) 20 – gdy czyn stanowi inną zbrodnię; 
2a) 15 – gdy czyn stanowi występek zagrożony karą pozbawienia wolności 
przekraczającą 5 lat; 
- 3) 10 – gdy czyn stanowi występek zagrożony karą pozbawienia wolności 
przekraczającą 3 lata; 
- 4) 5 – gdy chodzi o pozostałe występki. 
- 5) (uchylony) 

 
 
 
s. 47/146 
 
   
 
2025-04-09 
 
§ 2. Karalność przestępstwa ściganego z oskarżenia prywatnego ustaje 
z upływem roku od czasu, gdy pokrzywdzony dowiedział się o osobie sprawcy 
przestępstwa, nie później jednak niż z upływem 3 lat od czasu jego popełnienia. 
§ 3. Jeżeli dokonanie przestępstwa zależy od nastąpienia określonego w ustawie 
skutku, bieg przedawnienia rozpoczyna się od czasu, gdy skutek nastąpił. 
§ 3a. W przypadku przestępstwa popełnionego w czasie dłuższym niż jeden 
dzień bieg przedawnienia rozpoczyna się z upływem ostatniego dnia, w którym 
sprawca swoim zachowaniem wypełniał znamiona przestępstwa. 
§ 4. W przypadku przestępstw: 
- 1) przeciwko życiu i zdrowiu, popełnionych na szkodę małoletniego, zagrożonych 
karą, której górna granica przekracza 5 lat pozbawienia wolności, 
- 2) określonych w rozdziale XXV, popełnionych na szkodę małoletniego, albo gdy 
treści pornograficzne obejmują udział małoletniego, 
- 3) określonych w art. 156a i art. 191b, popełnionych na szkodę małoletniego 
– przedawnienie karalności przestępstwa nie może nastąpić przed ukończeniem przez 
niego 40. roku życia.

***
## Art. 102. {#kk-art-102}

§ 1. Jeżeli 
w okresie, 
o którym 
mowa 
w art. 101, 
wszczęto 
postępowanie, karalność przestępstw określonych w art. 101 § 1 ustaje z upływem 
10 lat, a w pozostałych wypadkach – z upływem 5 lat od zakończenia tego okresu. 
§ 2. Jeżeli w toku wszczętego postępowania powzięto uzasadnione podejrzenie 
popełnienia innego przestępstwa, karalność tego przestępstwa ulega przedłużeniu w 
sposób określony w § 1 z dniem, w którym podjęto pierwszą czynność procesową 
zmierzającą do ustalenia, czy zostało ono popełnione.

***
## Art. 103. {#kk-art-103}

§ 1. Nie można wykonać kary, jeżeli od uprawomocnienia się wyroku 
skazującego upłynęło lat: 
- 1) 30 – w razie skazania na karę pozbawienia wolności przekraczającą 5 lat albo 
karę surowszą; 
- 2) 15 – w razie skazania na karę pozbawienia wolności nieprzekraczającą 5 lat; 
- 3) 10 – w razie skazania na inną karę. 
§ 2. Przepis § 1 pkt 3 stosuje się odpowiednio do środków karnych, środków 
kompensacyjnych oraz przepadku. 

 
 
 
s. 48/146 
 
   
 
2025-04-09

***
## Art. 104. {#kk-art-104}

§ 1. Przedawnienie nie biegnie, jeżeli przepis ustawy nie pozwala na 
wszczęcie lub dalsze prowadzenie postępowania karnego; nie dotyczy to jednak braku 
wniosku albo oskarżenia prywatnego. 
§ 2. (uchylony)

***
## Art. 105. {#kk-art-105}

Przepisów art. 101–103 nie stosuje się do:  
- 1) zbrodni przeciwko pokojowi, ludzkości i przestępstw wojennych; 
- 2) umyślnego przestępstwa: zabójstwa, ciężkiego uszkodzenia ciała, ciężkiego 
uszczerbku na zdrowiu lub pozbawienia wolności łączonego ze szczególnym 
udręczeniem, popełnionego przez funkcjonariusza publicznego w związku z 
pełnieniem obowiązków służbowych; 
- 3) przestępstw określonych w art. 197 § 4 lub 5, popełnionych na szkodę 
małoletniego poniżej 15 lat; 
- 4) przestępstw określonych w art. 148 § 2 pkt 2 lub § 3, popełnionych w związku 
ze zgwałceniem małoletniego poniżej 15 lat lub w związku ze zgwałceniem ze 
szczególnym okrucieństwem; 
- 5) przestępstw określonych w art. 197 § 4 lub 5, jeżeli sprawca działał ze 
szczególnym okrucieństwem; 
- 6) przestępstwa określonego w art. 156 § 1 i art. 197 § 4 w związku z art. 11 § 2. 
### Rozdział XII Zatarcie skazania

***
## Art. 106. {#kk-art-106}

Z chwilą zatarcia skazania uważa się je za niebyłe; wpis o skazaniu 
usuwa się z rejestru skazanych. 
Art. 106a. Nie podlega zatarciu skazanie na karę pozbawienia wolności bez 
warunkowego zawieszenia jej wykonania za przestępstwo przeciwko wolności 
seksualnej i obyczajności, jeżeli pokrzywdzony był małoletnim poniżej lat 15.

***
## Art. 107. {#kk-art-107}

§ 1. W razie skazania na karę pozbawienia wolności wymienioną w art. 
32 pkt 3 zatarcie skazania następuje z mocy prawa z upływem 10 lat od wykonania 
lub darowania kary albo od przedawnienia jej wykonania. 
§ 2. Sąd może na wniosek skazanego zarządzić zatarcie skazania już po upływie 
5 lat, jeżeli skazany w tym okresie przestrzegał porządku prawnego, a wymierzona 
kara pozbawienia wolności nie przekraczała 3 lat. 

 
 
 
s. 49/146 
 
   
 
2025-04-09 
 
§ 3. W razie skazania na karę dożywotniego pozbawienia wolności zatarcie 
skazania następuje z mocy prawa z upływem 10 lat od darowania kary albo od 
przedawnienia jej wykonania. 
§ 4. W razie skazania na karę ograniczenia wolności zatarcie skazania następuje 
z mocy prawa z upływem 3 lat od wykonania lub darowania kary albo od 
przedawnienia jej wykonania. 
§ 4a. W razie skazania na grzywnę zatarcie skazania następuje z mocy prawa 
z upływem roku od wykonania lub darowania kary albo od przedawnienia jej 
wykonania. 
§ 5. W razie odstąpienia od wymierzenia kary, zatarcie skazania następuje 
z mocy prawa z upływem roku od wydania prawomocnego orzeczenia. 
§ 6. Jeżeli orzeczono środek karny, przepadek lub środek kompensacyjny, 
zatarcie skazania nie może nastąpić przed jego wykonaniem, darowaniem albo 
przedawnieniem jego wykonania. Zatarcie skazania nie może nastąpić również przed 
wykonaniem środka zabezpieczającego. 
Art. 107a. (uchylony)

***
## Art. 108. {#kk-art-108}

Jeżeli sprawcę skazano za dwa lub więcej nie pozostających w zbiegu 
przestępstw, jak również jeżeli skazany po rozpoczęciu, lecz przed upływem, okresu 
wymaganego do zatarcia skazania ponownie popełnił przestępstwo, dopuszczalne jest 
tylko jednoczesne zatarcie wszystkich skazań. 
### Rozdział XIII Odpowiedzialność za przestępstwa popełnione za granicą

***
## Art. 109. {#kk-art-109}

Ustawę karną polską stosuje się do obywatela polskiego, który popełnił 
przestępstwo za granicą.

***
## Art. 110. {#kk-art-110}

§ 1. Ustawę karną polską stosuje się do cudzoziemca, który popełnił za 
granicą czyn zabroniony skierowany przeciwko interesom Rzeczypospolitej Polskiej, 
obywatela polskiego, polskiej osoby prawnej lub polskiej jednostki organizacyjnej 
niemającej osobowości prawnej oraz do cudzoziemca, który popełnił za granicą 
przestępstwo o charakterze terrorystycznym. 
§ 2. Ustawę karną polską stosuje się w razie popełnienia przez cudzoziemca za 
granicą czynu zabronionego innego niż wymieniony w § 1, jeżeli czyn zabroniony jest 

 
 
 
s. 50/146 
 
   
 
2025-04-09 
 
w ustawie karnej polskiej zagrożony karą przekraczającą 2 lata pozbawienia wolności, 
a sprawca przebywa na terytorium Rzeczypospolitej Polskiej i nie postanowiono go 
wydać.

***
## Art. 111. {#kk-art-111}

§ 1. Warunkiem odpowiedzialności za czyn popełniony za granicą jest 
uznanie takiego czynu za przestępstwo również przez ustawę obowiązującą w miejscu 
jego popełnienia. 
§ 2. Jeżeli zachodzą różnice między ustawą polską a ustawą obowiązującą 
w miejscu popełnienia czynu, stosując ustawę polską, sąd może uwzględnić te różnice 
na korzyść sprawcy. 
§ 3. Warunek przewidziany w § 1 nie ma zastosowania do polskiego 
funkcjonariusza publicznego, który pełniąc służbę za granicą popełnił tam 
przestępstwo w związku z wykonywaniem swoich funkcji, ani do osoby, która 
popełniła przestępstwo w miejscu nie podlegającym żadnej władzy państwowej.

***
## Art. 112. {#kk-art-112}

Niezależnie od przepisów obowiązujących w miejscu popełnienia 
czynu zabronionego, ustawę karną polską stosuje się do obywatela polskiego oraz 
cudzoziemca w razie popełnienia: 
- 1) przestępstwa przeciwko bezpieczeństwu wewnętrznemu lub zewnętrznemu 
Rzeczypospolitej Polskiej; 
1a) (utracił moc)4) 
- 2) przestępstwa przeciwko polskim urzędom lub funkcjonariuszom publicznym 
oraz przestępstwa wyłudzenia poświadczenia nieprawdy od polskiego 
funkcjonariusza publicznego lub innej osoby uprawnionej na podstawie prawa 
polskiego do wystawienia dokumentu; 
- 3) przestępstwa przeciwko istotnym polskim interesom gospodarczym; 
- 4) przestępstwa fałszywych zeznań, złożenia fałszywego oświadczenia, opinii lub 
tłumaczenia, posłużenia się dokumentem stwierdzającym tożsamość innej osoby, 
poświadczającym nieprawdę lub fałszywym – wobec urzędu polskiego; 
- 5) przestępstwa, z którego została osiągnięta, chociażby pośrednio, korzyść 
majątkowa na terytorium Rzeczypospolitej Polskiej. 
- 4) Z dniem 30 września 2008 r. na podstawie wyroku Trybunału Konstytucyjnego z dnia 19 września 
2008 r. sygn. akt K 5/07 (Dz. U. poz. 1080). 

 
 
 
s. 51/146 
 
   
 
2025-04-09 
 
Art. 112a. Niezależnie od przepisów obowiązujących w miejscu popełnienia 
czynu zabronionego, ustawę karną polską stosuje się do obywatela polskiego oraz 
cudzoziemca w razie popełnienia przestępstwa przy użyciu systemu informatycznego, 
systemu teleinformatycznego lub sieci teleinformatycznej, jeżeli czyn ten na 
terytorium Rzeczypospolitej Polskiej wywołał lub mógł wywołać skutek naruszający 
interes państwa w zakresie ochrony niepodległości, integralności terytorialnej, 
bezpieczeństwa zewnętrznego i wewnętrznego, obronności, polityki zagranicznej, 
pozycji międzynarodowej lub potencjału naukowego lub gospodarczego.

***
## Art. 113. {#kk-art-113}

Niezależnie od przepisów obowiązujących w miejscu popełnienia 
przestępstwa, ustawę karną polską stosuje się do obywatela polskiego oraz 
cudzoziemca, którego nie postanowiono wydać, w razie popełnienia przez niego za 
granicą przestępstwa, do którego ścigania Rzeczpospolita Polska jest zobowiązana na 
mocy umowy międzynarodowej, lub przestępstwa określonego w Rzymskim Statucie 
Międzynarodowego Trybunału Karnego, sporządzonym w Rzymie dnia 17 lipca 
1998 r. (Dz. U. z 2003 r. poz. 708 oraz z 2018 r. poz. 1753).

***
## Art. 114. {#kk-art-114}

§ 1. Orzeczenie zapadłe za granicą nie stanowi przeszkody do 
wszczęcia lub prowadzenia postępowania karnego o ten sam czyn zabroniony przed 
sądem polskim. 
§ 2. Sąd zalicza na poczet orzeczonej kary okres rzeczywistego pozbawienia 
wolności za granicą oraz wykonywaną tam karę, uwzględniając różnice zachodzące 
między tymi karami. 
§ 3. Przepisu § 1 nie stosuje się: 
- 1) jeżeli wyrok skazujący zapadły za granicą został przejęty do wykonania na 
terytorium Rzeczypospolitej Polskiej, jak również wtedy, gdy orzeczenie zapadłe 
za granicą dotyczy przestępstwa, w związku z którym nastąpiło przekazanie 
ścigania lub wydanie sprawcy z terytorium Rzeczypospolitej Polskiej; 
- 2) do orzeczeń międzynarodowych trybunałów karnych działających na podstawie 
wiążącego Rzeczpospolitą Polską prawa międzynarodowego; 
- 3) do prawomocnych orzeczeń sądów lub innych organów państw obcych 
kończących postępowanie karne, jeżeli wynika to z wiążącej Rzeczpospolitą 
Polską umowy międzynarodowej. 

 
 
 
s. 52/146 
 
   
 
2025-04-09 
 
§ 4. Jeżeli nastąpiło przejęcie obywatela polskiego, skazanego prawomocnie 
przez sąd obcego państwa, do wykonania wyroku na terytorium Rzeczypospolitej 
Polskiej, sąd określa według polskiego prawa kwalifikację prawną czynu oraz 
podlegającą wykonaniu karę lub inny środek przewidziany w tej ustawie; podstawę 
określenia kary lub środka podlegającego wykonaniu stanowi wyrok wydany przez 
sąd państwa obcego, kara grożąca za taki czyn w polskim prawie, okres rzeczywistego 
pozbawienia wolności za granicą oraz wykonana tam kara lub inny środek, 
z uwzględnieniem różnic na korzyść skazanego. 
Art. 114a. § 1. Wyrokiem skazującym jest również prawomocne orzeczenie 
skazujące za popełnienie przestępstwa wydane przez sąd właściwy w sprawach 
karnych w państwie członkowskim Unii Europejskiej, chyba że według ustawy karnej 
polskiej czyn nie stanowi przestępstwa, sprawca nie podlega karze albo orzeczono karę 
nieznaną ustawie. 
§ 2. W razie skazania przez sąd, o którym mowa w § 1, w sprawach: 
- 1) stosowania nowej ustawy karnej, która weszła w życie po wydaniu wyroku 
skazującego, 
- 2) zatarcia skazania 
– stosuje się ustawę obowiązującą w miejscu skazania. Przepisu art. 108 nie stosuje 
się. 
§ 3. Przepisu § 1 nie stosuje się, jeżeli informacje uzyskane z rejestru karnego 
lub od sądu państwa członkowskiego Unii Europejskiej nie są wystarczające do 
ustalenia skazania albo orzeczona kara podlega darowaniu w państwie, w którym 
nastąpiło skazanie. 
### Rozdział XIV Objaśnienie wyrażeń ustawowych

***
## Art. 115. {#kk-art-115}

§ 1. Czynem zabronionym jest zachowanie o znamionach określonych 
w ustawie karnej. 
§ 2. Przy ocenie stopnia społecznej szkodliwości czynu sąd bierze pod uwagę 
rodzaj i charakter naruszonego lub zagrożonego dobra, rozmiary wyrządzonej lub 
grożącej szkody, sposób i okoliczności popełnienia czynu, wagę naruszonych przez 
sprawcę obowiązków, jak również postać zamiaru, motywację sprawcy, rodzaj 
naruszonych reguł ostrożności i stopień ich naruszenia. 

 
 
 
s. 53/146 
 
   
 
2025-04-09 
 
§ 3. Przestępstwami podobnymi są przestępstwa należące do tego samego 
rodzaju; przestępstwa z zastosowaniem przemocy lub groźby jej użycia albo 
przestępstwa popełnione w celu osiągnięcia korzyści majątkowej uważa się za 
przestępstwa podobne. 
§ 4. Korzyścią majątkową lub osobistą jest korzyść zarówno dla siebie, jak i dla 
kogo innego. 
§ 5. Mieniem znacznej wartości jest mienie, którego wartość w czasie 
popełnienia czynu zabronionego przekracza 200 000 złotych. 
§ 6. Mieniem wielkiej wartości jest mienie, którego wartość w czasie popełnienia 
czynu zabronionego przekracza 1 000 000 złotych. 
§ 7. Przepis § 5 stosuje się odpowiednio do określenia „znaczna szkoda” oraz 
określenia „wartość lub łączna wartość jest znaczna”. 
§ 7a. Przepis § 6 stosuje się odpowiednio do określenia „szkoda w wielkich 
rozmiarach”. 
§ 8. (uchylony) 
§ 9. Rzeczą ruchomą lub przedmiotem jest także polski albo obcy pieniądz lub 
inny środek płatniczy, środek pieniężny zapisany na rachunku oraz dokument 
uprawniający do otrzymania sumy pieniężnej albo zawierający obowiązek wypłaty 
kapitału, odsetek, udziału w zyskach, albo stwierdzenie uczestnictwa w spółce. 
§ 9a. Kradzieżą szczególnie zuchwałą jest:  
- 1) kradzież, której sprawca swoim zachowaniem wykazuje postawę lekceważącą 
lub wyzywającą wobec posiadacza rzeczy ruchomej lub innych osób lub używa 
przemocy innego rodzaju niż przemoc wobec osoby w celu zawładnięcia tą 
rzeczą;  
- 2) kradzież rzeczy ruchomej znajdującej się bezpośrednio na osobie lub w 
noszonym przez nią ubraniu albo przenoszonej lub przemieszczanej przez tę 
osobę w warunkach bezpośredniego kontaktu lub znajdującej się w przedmiotach 
przenoszonych lub przemieszczanych w takich warunkach. 
§ 10. Młodocianym 
jest 
sprawca, 
który 
w chwili 
popełnienia 
czynu 
zabronionego nie ukończył 21 lat i w czasie orzekania w pierwszej instancji 24 lat. 
§ 11. Osobą najbliższą jest małżonek, wstępny, zstępny, rodzeństwo, 
powinowaty w tej samej linii lub stopniu, osoba pozostająca w stosunku 
przysposobienia oraz jej małżonek, a także osoba pozostająca we wspólnym pożyciu. 

 
 
 
s. 54/146 
 
   
 
2025-04-09 
 
§ 12. Groźbą bezprawną jest zarówno groźba, o której mowa w art. 190, jak 
i groźba spowodowania postępowania karnego lub innego postępowania, w którym 
może zostać nałożona administracyjna kara pieniężna, jak również rozgłoszenia 
wiadomości uwłaczającej czci zagrożonego lub jego osoby najbliższej; nie stanowi 
groźby zapowiedź spowodowania postępowania karnego lub innego postępowania, 
w którym może zostać nałożona administracyjna kara pieniężna, jeżeli ma ona jedynie 
na celu ochronę prawa naruszonego przestępstwem lub zachowaniem zagrożonym 
administracyjną karą pieniężną. 
§ 13. Funkcjonariuszem publicznym jest: 
- 1) Prezydent Rzeczypospolitej Polskiej; 
- 2) poseł, senator, radny; 
2a) poseł do Parlamentu Europejskiego; 
- 3) sędzia, ławnik, prokurator, funkcjonariusz finansowego organu postępowania 
przygotowawczego lub organu nadrzędnego nad finansowym organem 
postępowania przygotowawczego, notariusz, komornik, kurator sądowy, syndyk, 
nadzorca sądowy i zarządca, osoba orzekająca w organach dyscyplinarnych 
działających na podstawie ustawy; 
- 4) osoba 
będąca 
pracownikiem 
administracji 
rządowej, 
innego 
organu 
państwowego lub samorządu terytorialnego, chyba że pełni wyłącznie czynności 
usługowe, a także inna osoba w zakresie, w którym uprawniona jest do 
wydawania decyzji administracyjnych; 
- 5) osoba będąca pracownikiem organu kontroli państwowej lub organu kontroli 
samorządu terytorialnego, chyba że pełni wyłącznie czynności usługowe; 
- 6) osoba zajmująca kierownicze stanowisko w innej instytucji państwowej; 
- 7) funkcjonariusz organu powołanego do ochrony bezpieczeństwa publicznego albo 
funkcjonariusz Służby Więziennej; 
- 8) osoba pełniąca czynną służbę wojskową, z wyjątkiem terytorialnej służby 
wojskowej pełnionej dyspozycyjnie; 
- 9) pracownik międzynarodowego trybunału karnego, chyba że pełni wyłącznie 
czynności usługowe; 
- 10) inspektor Inspekcji Wodnej. 
§ 14. Dokumentem jest każdy przedmiot lub inny zapisany nośnik informacji, 
z którym jest związane określone prawo, albo który ze względu na zawartą w nim treść 

 
 
 
s. 55/146 
 
   
 
2025-04-09 
 
stanowi dowód prawa, stosunku prawnego lub okoliczności mającej znaczenie 
prawne. 
§ 14a. Fakturą jest dokument, o którym mowa w art. 2 pkt 31 ustawy z dnia 
11 marca 2004 r. o podatku od towarów i usług (Dz. U. z 2024 r. poz. 361, 852, 1473, 
1721 i 1911 oraz z 2025 r. poz. 222). 
§ 15. W rozumieniu tego kodeksu za statek wodny uważa się także stałą 
platformę umieszczoną na szelfie kontynentalnym. 
§ 16. Stan nietrzeźwości w rozumieniu tego kodeksu zachodzi, gdy: 
- 1) zawartość alkoholu we krwi przekracza 0,5 promila albo prowadzi do stężenia 
przekraczającego tę wartość lub 
- 2) zawartość alkoholu w 1 dm3 wydychanego powietrza przekracza 0,25 mg albo 
prowadzi do stężenia przekraczającego tę wartość. 
§ 17. Żołnierzem jest osoba pełniąca czynną służbę wojskową, z wyjątkiem 
terytorialnej służby wojskowej pełnionej dyspozycyjnie. 
§ 18. Rozkazem jest polecenie określonego działania lub zaniechania wydane 
służbowo żołnierzowi przez przełożonego lub uprawnionego żołnierza starszego 
stopniem. 
§ 19. Osobą pełniącą funkcję publiczną jest funkcjonariusz publiczny, członek 
organu samorządowego, osoba zatrudniona w jednostce organizacyjnej dysponującej 
środkami publicznymi, chyba że wykonuje wyłącznie czynności usługowe, a także 
inna osoba, której uprawnienia i obowiązki w zakresie działalności publicznej są 
określone lub uznane przez ustawę lub wiążącą Rzeczpospolitą Polską umowę 
międzynarodową. 
§ 20. Przestępstwem o charakterze terrorystycznym jest czyn zabroniony 
zagrożony karą pozbawienia wolności, której górna granica wynosi co najmniej 5 lat, 
popełniony w celu: 
- 1) poważnego zastraszenia wielu osób, 
- 2) zmuszenia organu władzy publicznej Rzeczypospolitej Polskiej lub innego 
państwa albo organu organizacji międzynarodowej do podjęcia lub zaniechania 
określonych czynności, 
- 3) wywołania poważnych zakłóceń w ustroju lub gospodarce Rzeczypospolitej 
Polskiej, innego państwa lub organizacji międzynarodowej 
– a także groźba popełnienia takiego czynu. 

 
 
 
s. 56/146 
 
   
 
2025-04-09 
 
§ 21. Występkiem o charakterze chuligańskim jest występek polegający na 
umyślnym zamachu na zdrowie, na wolność, na cześć lub nietykalność cielesną, na 
bezpieczeństwo powszechne, na działalność instytucji państwowych lub samorządu 
terytorialnego, na porządek publiczny, albo na umyślnym niszczeniu, uszkodzeniu lub 
czynieniu niezdatną do użytku cudzej rzeczy, jeżeli sprawca działa publicznie i bez 
powodu albo z oczywiście błahego powodu, okazując przez to rażące lekceważenie 
porządku prawnego. 
§ 22. Handlem ludźmi jest werbowanie, transport, dostarczanie, przekazywanie, 
przechowywanie lub przyjmowanie osoby z zastosowaniem: 
- 1) przemocy lub groźby bezprawnej, 
- 2) uprowadzenia, 
- 3) podstępu, 
- 4) wprowadzenia w błąd albo wyzyskania błędu lub niezdolności do należytego 
pojmowania przedsiębranego działania, 
- 5) nadużycia stosunku zależności, wykorzystania krytycznego położenia lub stanu 
bezradności, 
- 6) udzielenia albo przyjęcia korzyści majątkowej lub osobistej albo jej obietnicy 
osobie sprawującej opiekę lub nadzór nad inną osobą 
– w celu jej wykorzystania, nawet za jej zgodą, w szczególności w prostytucji, 
pornografii lub innych formach seksualnego wykorzystania, w pracy lub usługach 
o charakterze przymusowym, w żebractwie, w niewolnictwie lub innych formach 
wykorzystania poniżających godność człowieka albo w celu pozyskania komórek, 
tkanek lub narządów wbrew przepisom ustawy. Jeżeli zachowanie sprawcy dotyczy 
małoletniego, stanowi ono handel ludźmi, nawet gdy nie zostały użyte metody lub 
środki wymienione w pkt 1–6. 
§ 22a. Adopcją jest nabycie władzy rodzicielskiej nad dzieckiem przez inną 
osobę niż ta, od której dziecko pochodzi. 
§ 23. Niewolnictwo jest stanem zależności, w którym człowiek jest traktowany 
jak przedmiot własności. 
§ 24. Przy ocenie rozmiaru działalności przedsiębiorstwa sąd bierze pod uwagę 
wartość przedsiębiorstwa. 
§ 25. Przez koszty inne niż odsetki należy rozumieć:  

 
 
 
s. 57/146 
 
   
 
2025-04-09 
- 1) marże, prowizje lub opłaty związane z przygotowaniem umowy, z której wynika 
udzielenie świadczenia pieniężnego, lub umowy związanej z udzieleniem tego 
świadczenia lub obsługą tych umów albo inne tego rodzaju koszty,  
- 2) opłaty związane z odroczeniem terminu zwrotu udzielonego świadczenia 
pieniężnego, jego nieterminową spłatą albo inne tego rodzaju koszty,  
- 3) koszty usług dodatkowych, w szczególności koszty ubezpieczeń, koszty 
związane z ustanowieniem zabezpieczenia zwrotu świadczenia pieniężnego, 
koszty pozyskiwania informacji związanych z udzielaniem świadczenia 
pieniężnego, w przypadku gdy ich poniesienie jest niezbędne do zawarcia umów, 
o których mowa w pkt 1,  
- 4) wynagrodzenie osoby, która reprezentowała osobę udzielającą świadczenia 
pieniężnego przy zawarciu umów, o których mowa w pkt 1, lub za której 
pośrednictwem udzielający świadczenia zawarł te umowy lub udzielił tego 
świadczenia, bezpośrednio ponoszone przez osobę, na rzecz której udzielono 
świadczenia  
– z wyłączeniem opłat notarialnych oraz danin o charakterze publicznoprawnym, które 
strony umów, o których mowa w pkt 1, są zobowiązane ponieść w związku z 
zawarciem tych umów. 
### Rozdział XV Stosunek do ustaw szczególnych

***
## Art. 116. {#kk-art-116}

Przepisy części ogólnej tego kodeksu stosuje się do innych ustaw 
przewidujących odpowiedzialność karną, chyba że ustawy te wyraźnie wyłączają ich 
zastosowanie.

