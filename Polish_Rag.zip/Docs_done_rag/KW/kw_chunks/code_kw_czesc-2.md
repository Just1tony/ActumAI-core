---
id: code.kw.part2
title: Kodeks wykroczeń — CZĘŚĆ SZCZEGÓLNA
short: KW
dz_u: Dz.U. 1971 Nr 12 poz. 114 (t.j. 2025 poz. 734)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '49'
  last: '166'
source_pdf: D19710114Lj.pdf
chunking:
  strategy: by-article
  anchor_pattern: '### Art. {n}. {#kw-art-{n}}'
  hierarchy:
  - CZĘŚĆ
  - Rozdział
  - Art.
---

# CZĘŚĆ SZCZEGÓLNA

### Art. 49. {#kw-art-49}

§ 1. Kto w miejscu publicznym demonstracyjnie okazuje lekceważenie 
Narodowi Polskiemu, Rzeczypospolitej Polskiej lub jej konstytucyjnym organom, 
podlega karze aresztu albo grzywny. 
§ 2. Tej samej karze podlega, kto narusza przepisy o godle, barwach i hymnie 
Rzeczypospolitej Polskiej.

***
### Art. 49a. {#kw-art-49a}

§ 1. Kto wbrew przepisom przekracza granicę Rzeczypospolitej 
Polskiej, podlega karze grzywny. 
§ 2. Usiłowanie i pomocnictwo są karalne.

***
### Art. 50. {#kw-art-50}

Kto nie opuszcza zbiegowiska publicznego pomimo wezwania 
właściwego organu, 
podlega karze aresztu albo grzywny.

***
### Art. 50a. {#kw-art-50a}

§ 1. Kto w miejscu publicznym posiada nóż, maczetę lub inny 
podobnie niebezpieczny przedmiot, a okoliczności jego posiadania wskazują na 
zamiar użycia go w celu popełnienia przestępstwa, 
podlega karze aresztu, ograniczenia wolności albo grzywny nie niższej niż 
3000 zł. 
§ 1a. Tej samej karze podlega, kto będąc uczestnikiem przejazdu zorganizowanej 
grupy uczestników masowej imprezy sportowej, posiada przedmioty określone w § 1 
lub wyroby pirotechniczne. 
§ 2. W razie popełnienia wykroczenia określonego w § 1 lub 1a orzeka się 
przepadek przedmiotów stanowiących przedmiot wykroczenia, choćby nie stanowiły 
własności sprawcy.

***
### Art. 51. {#kw-art-51}

§ 1. Kto krzykiem, hałasem, alarmem lub innym wybrykiem zakłóca 
spokój, porządek publiczny, spoczynek nocny albo wywołuje zgorszenie w miejscu 
publicznym, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 

 
 
 
s. 16/56 
 
 
 
2025-06-13 
 
§ 2. Jeżeli czyn określony w § 1 ma charakter chuligański lub sprawca dopuszcza 
się go, będąc pod wpływem alkoholu, środka odurzającego lub innej podobnie 
działającej substancji lub środka, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 3. Podżeganie i pomocnictwo są karalne.

***
### Art. 52. {#kw-art-52}

§ 1. Kto bierze udział w zgromadzeniu, posiadając przy sobie broń, 
materiały wybuchowe, wyroby pirotechniczne lub inne niebezpieczne materiały lub 
narzędzia 
– podlega karze aresztu do 14 dni, karze ograniczenia wolności albo karze grzywny. 
§ 2. Kto: 
1) 
przeszkadza lub usiłuje przeszkodzić w organizowaniu lub w przebiegu 
niezakazanego zgromadzenia, 
2) 
organizuje zgromadzenie bez wymaganego zawiadomienia lub przewodniczy 
takiemu zgromadzeniu lub zgromadzeniu zakazanemu, 
3) 
przewodniczy zgromadzeniu po rozwiązaniu go, 
4) 
bezprawnie zajmuje lub wzbrania się opuścić miejsce, którym inna osoba lub 
organizacja prawnie rozporządza jako organizator lub przewodniczący 
zgromadzenia 
– podlega karze ograniczenia wolności albo grzywny. 
§ 3. Kto: 
1) 
będąc przewodniczącym lub organizatorem zgromadzenia, umyślnie nie 
podejmuje środków niezbędnych dla zapewnienia zgodnego z przepisami prawa 
przebiegu zgromadzenia oraz zapobieżenia powstaniu szkód z winy uczestników 
zgromadzenia, 
2) 
nie podporządkowuje się żądaniom lub poleceniom przewodniczącego 
zgromadzenia lub jego organizatora, o których mowa w ustawie z dnia 24 lipca 
2015 r. – Prawo o zgromadzeniach (Dz. U. z 2022 r. poz. 1389), 
3) 
wzbrania się opuścić miejsce zgromadzenia po jego rozwiązaniu 
– podlega karze grzywny. 
§ 4. Podżeganie i pomocnictwo są karalne.

***
### Art. 52a. {#kw-art-52a}

Kto: 
1) 
publicznie nawołuje do popełnienia przestępstwa lub przestępstwa skarbowego, 

 
 
 
s. 17/56 
 
 
 
2025-06-13 
 
2) 
publicznie nawołuje do przeciwdziałania przemocą aktowi stanowiącemu źródło 
powszechnie obowiązującego prawa Rzeczypospolitej Polskiej, 
3) 
publicznie pochwala popełnienie przestępstwa, 
jeżeli zasięg czynu albo jego skutki nie były znaczne 
– podlega karze aresztu, ograniczenia wolności albo grzywny.

***
### Art. 52b. {#kw-art-52b}

Kto zużywa olej opałowy do celów napędowych, podlega karze 
grzywny do 500 zł.

***
### Art. 53. {#kw-art-53}

(uchylony)

***
### Art. 54. {#kw-art-54}

Kto wykracza przeciwko wydanym z upoważnienia ustawy przepisom 
porządkowym o zachowaniu się w miejscach publicznych, 
podlega karze grzywny do 500 złotych albo karze nagany.

***
### Art. 55. {#kw-art-55}

Kto kąpie się w miejscu, w którym jest to zabronione, 
podlega karze grzywny do 250 złotych albo karze nagany.

***
### Art. 56. {#kw-art-56}

§ 1. Kto bez wymaganego zgłoszenia zbiórki publicznej lub niezgodnie 
ze zgłoszeniem zbiórki publicznej organizuje lub przeprowadza publiczną zbiórkę 
ofiar, 
podlega karze grzywny. 
§ 2. Podżeganie i pomocnictwo są karalne. 
§ 3. Można orzec przepadek przedmiotów uzyskanych ze zbiórki publicznej 
przeprowadzonej niezgodnie ze zgłoszeniem, orzeka się zaś ich przepadek, gdy 
zbiórkę publiczną przeprowadzono bez zgłoszenia. 
§ 4. Można orzec przepadek przedmiotów uzyskanych z czynu określonego 
w § 1 także wtedy, gdy zostały one przekazane przez sprawcę innej osobie lub 
instytucji, jak i przepadek pieniędzy uzyskanych za zebrane ofiary w naturze i rzeczy 
nabytych za uzyskane ze zbiórki publicznej pieniądze. 
§ 5. Przedmioty, co do których orzeczono przepadek, należy przekazać instytucji 
pomocy społecznej lub instytucji kultury.

***
### Art. 57. {#kw-art-57}

§ 1. Kto: 
1) 
organizuje lub przeprowadza zbiórkę ofiar na uiszczenie grzywny orzeczonej za 
przestępstwo, przestępstwo skarbowe, wykroczenie lub wykroczenie skarbowe, 
świadczenia pieniężnego, przepadku przedmiotów stanowiących kwotę 

 
 
 
s. 18/56 
 
 
 
2025-06-13 
 
pieniężną, równowartości przepadku przedmiotów lub przedsiębiorstwa, 
przepadku korzyści majątkowej stanowiącej kwotę pieniężną, równowartości 
przepadku korzyści majątkowej, odszkodowania, zadośćuczynienia, nawiązki, 
podlegającej zwrotowi korzyści majątkowej stanowiącej kwotę pieniężną albo 
równowartości podlegającej zwrotowi korzyści majątkowej lub na poręczenie 
majątkowe lub zabezpieczenie majątkowe, 
2) 
nie będąc osobą najbliższą dla skazanego lub ukaranego uiszcza za niego 
grzywnę, świadczenie pieniężne, kwotę pieniężną stanowiącą przedmiot 
przepadku, równowartość przepadku przedmiotów lub przedsiębiorstwa, kwotę 
pieniężną stanowiącą przedmiot przepadku korzyści majątkowej, równowartość 
przepadku korzyści majątkowej, nawiązkę, podlegającą zwrotowi korzyść 
majątkową stanowiącą kwotę pieniężną albo równowartość podlegającej 
zwrotowi korzyści majątkowej lub uiszcza odszkodowanie lub zadośćuczynienie 
lub ofiarowuje mu albo osobie dla niego najbliższej pieniądze na ten cel 
– podlega karze aresztu albo grzywny. 
§ 2. Podżeganie i pomocnictwo są karalne. 
§ 3. Przepadkowi podlegają: 
1) 
zebrane ofiary lub pieniądze uzyskane za zebrane ofiary w naturze, o których 
mowa w § 1 pkt 1; 
2) 
pieniądze wpłacone na poczet należności lub ofiarowane na cel, o których mowa 
w § 1 pkt 2. 
§ 4. Przedmioty, co do których orzeczono przepadek, należy przekazać instytucji 
pomocy społecznej lub instytucji kulturalno-oświatowej.

***
### Art. 58. {#kw-art-58}

§ 1. Kto, mając środki egzystencji lub będąc zdolny do pracy, żebrze 
w miejscu publicznym, 
podlega karze ograniczenia wolności, grzywny do 1500 złotych albo karze 
nagany. 
§ 2. Kto żebrze w miejscu publicznym w sposób natarczywy lub oszukańczy, 
podlega karze aresztu albo ograniczenia wolności.

***
### Art. 59. {#kw-art-59}

(uchylony)

***
### Art. 60. {#kw-art-60}

(uchylony) 

 
 
 
s. 19/56 
 
 
 
2025-06-13

***
### Art. 601. {#kw-art-601}

§ 1. Kto wykonuje działalność gospodarczą bez wymaganego 
zgłoszenia do ewidencji działalności gospodarczej, wpisu do rejestru działalności 
regulowanej lub bez wymaganej koncesji albo zezwolenia, podlega karze ograniczenia 
wolności albo grzywny. 
§ 2. Tej samej karze podlega, kto nie dopełnia obowiązku zgłaszania do 
ewidencji działalności gospodarczej zmian danych objętych wpisem. 
§ 3. Kto będąc przedsiębiorcą wprowadza do obrotu towar bez wymaganych 
oznaczeń, podlega karze grzywny. 
§ 4. Kto: 
1) 
wykonuje odpłatnie zadania przewodnika górskiego bez uprawnień wymaganych 
dla określonego obszaru górskiego, 
1a) prowadzi szkolenie dla kandydatów na przewodników górskich bez 
wymaganego wpisu do rejestru organizatorów szkoleń, 
2) 
świadcząc usługi hotelarskie używa nazw rodzajowych lub określenia kategorii 
obiektów hotelarskich bez decyzji lub niezgodnie z decyzją, 
2a) świadcząc usługi hotelarskie, używa oznaczeń, które mogą wprowadzić klientów 
w błąd co do rodzaju lub kategorii obiektu hotelarskiego, 
3) 
wbrew obowiązkowi świadczy usługi hotelarskie w obiekcie niezgłoszonym do 
ewidencji, 
4) 
świadczy usługi hotelarskie wbrew decyzji nakazującej wstrzymanie ich 
świadczenia, 
5) 
nie zawiadamia organu prowadzącego rejestr organizatorów turystyki i 
przedsiębiorców ułatwiających nabywanie powiązanych usług turystycznych o 
zawieszeniu wykonywania działalności w terminie 7 dni od dnia tego zawie-
szenia 
– podlega karze ograniczenia wolności albo grzywny. 
§ 5. (uchylony) 
§ 6. (uchylony)  
§ 7. (uchylony)

***
### Art. 602. {#kw-art-602}

(uchylony) 

 
 
 
s. 20/56 
 
 
 
2025-06-13

***
### Art. 603. {#kw-art-603}

§ 1. Kto prowadzi sprzedaż na terenie należącym do gminy lub 
będącym w jej zarządzie poza miejscem do tego wyznaczonym przez właściwe organy 
gminy, 
podlega karze grzywny. 
§ 2. W razie popełnienia wykroczenia, określonego w § 1, można orzec 
przepadek towarów przeznaczonych do sprzedaży, choćby nie stanowiły własności 
sprawcy.

***
### Art. 61. {#kw-art-61}

§ 1. Kto przywłaszcza sobie stanowisko, tytuł lub stopień albo 
publicznie używa lub nosi odznaczenie, odznakę, strój lub mundur, do których nie ma 
prawa, 
podlega karze grzywny do 1000 złotych albo karze nagany. 
§ 2. Kto ustanawia, wytwarza, rozpowszechnia publicznie, używa lub nosi: 
godło, chorągiew albo inną odznakę lub mundur, co do których został wydany zakaz, 
albo odznakę lub mundur organizacji prawnie nieistniejącej, albo odznakę lub mundur, 
na których ustanowienie lub noszenie nie uzyskano wymaganego zezwolenia, 
podlega karze aresztu albo grzywny. 
§ 3. W razie popełnienia wykroczenia określonego w § 1 można orzec, a w razie 
popełnienia wykroczenia określonego w § 2 orzeka się przepadek wymienionych 
w tych przepisach przedmiotów, jak również innych przedmiotów służących do 
popełnienia wykroczenia, takich jak pieczęcie, stemple, papier firmowy lub bilety 
wizytowe, choćby nie stanowiły własności sprawcy.

***
### Art. 62. {#kw-art-62}

(uchylony)

***
### Art. 63. {#kw-art-63}

§ 1. Kto bez złożenia pisemnego wniosku o dokonanie wpisu do rejestru 
przedsiębiorców telekomunikacyjnych wykonuje działalność telekomunikacyjną, 
podlega karze aresztu, ograniczenia wolności lub grzywny. 
§ 2. (uchylony) 
§ 3. Kto wprowadza do obrotu urządzenia radiowe i telekomunikacyjne 
urządzenia końcowe podlegające obowiązkowej ocenie zgodności z zasadniczymi 
wymaganiami, nieposiadające wymaganego znaku zgodności, 
podlega karze grzywny. 
§ 4. (uchylony) 

 
 
 
s. 21/56 
 
 
 
2025-06-13

***
### Art. 63a. {#kw-art-63a}

§ 1. Kto umieszcza w miejscu publicznym do tego nieprzeznaczonym 
ogłoszenie, plakat, afisz, apel, ulotkę, napis lub rysunek albo wystawia je na widok 
publiczny w innym miejscu bez zgody zarządzającego tym miejscem, 
podlega karze ograniczenia wolności albo grzywny. 
§ 1a. Podżeganie i pomocnictwo są karalne. 
§ 2. W razie popełnienia wykroczenia można orzec przepadek przedmiotów 
służących lub przeznaczonych do popełnienia wykroczenia, choćby nie stanowiły 
własności sprawcy, oraz nawiązkę w wysokości do 1500 złotych lub obowiązek 
przywrócenia do stanu poprzedniego.

***
### Art. 63b. {#kw-art-63b}

§ 1. Kto umieszcza reklamę, o której mowa w art. 4 pkt 23 ustawy 
z dnia 21 marca 1985 r. o drogach publicznych (Dz. U. z 2024 r. poz. 320 i 1222 oraz 
z 2025 r. poz. 641) z naruszeniem warunków jej sytuowania określonych w art. 42a tej 
ustawy, o gabarytach większych niż dopuszczalne lub wykonane z wyrobów innych 
niż dopuszczalne, 
podlega karze ograniczenia wolności albo grzywny. 
§ 2. Podżeganie i pomocnictwo są karalne.  
§ 3. W razie popełnienia wykroczenia można orzec przepadek przedmiotów 
służących lub przeznaczonych do popełnienia wykroczenia, choćby nie stanowiły 
własności sprawcy, lub obowiązek przywrócenia do stanu poprzedniego.

***
### Art. 64. {#kw-art-64}

(uchylony) 

## Rozdział IX: Wykroczenia przeciwko instytucjom państwowym, samorządowym
i społecznym

***
### Art. 65. {#kw-art-65}

§ 1. Kto umyślnie wprowadza w błąd organ państwowy lub instytucję 
upoważnioną z mocy ustawy do legitymowania: 
1) 
co do tożsamości własnej lub innej osoby, 
2) 
co do swego obywatelstwa, zawodu, miejsca zatrudnienia lub zamieszkania, 
podlega karze ograniczenia wolności albo grzywny. 
§ 2. Tej samej karze podlega, kto wbrew obowiązkowi nie udziela właściwemu 
organowi państwowemu lub instytucji, upoważnionej z mocy ustawy do 
legitymowania, wiadomości lub dokumentów co do okoliczności wymienionych 
w § 1. 

 
 
 
s. 22/56 
 
 
 
2025-06-13

***
### Art. 65a. {#kw-art-65a}

Kto, nie stosując się do poleceń określonego zachowania się 
wydawanych na podstawie prawa przez funkcjonariusza Policji, Żandarmerii 
Wojskowej, Straży Granicznej lub innego organu ochrony bezpieczeństwa lub 
porządku publicznego, umyślnie uniemożliwia lub istotnie utrudnia wykonanie 
czynności służbowej, 
podlega karze aresztu, ograniczenia wolności albo grzywny.

***
### Art. 66. {#kw-art-66}

§ 1. Kto: 
1) 
chcąc wywołać niepotrzebną czynność, fałszywą informacją lub w inny sposób 
wprowadza w błąd instytucję użyteczności publicznej albo organ ochrony 
bezpieczeństwa, porządku publicznego lub zdrowia, 
2) 
umyślnie, bez uzasadnionej przyczyny, blokuje telefoniczny numer alarmowy, 
utrudniając prawidłowe funkcjonowanie centrum powiadamiania ratunkowego 
– podlega karze aresztu, ograniczenia wolności albo grzywny do 1500 zł. 
§ 2. Jeżeli wykroczenie spowodowało niepotrzebną czynność, można orzec 
nawiązkę do wysokości 1000 złotych.

***
### Art. 66a. {#kw-art-66a}

Osoba, wobec której wykonuje się karę, środek karny lub środek 
zabezpieczający, w systemie dozoru elektronicznego, albo osoba chroniona, która 
umyślnie dopuszcza do zniszczenia, uszkodzenia, uczynienia niezdatnym do użytku 
nadajnika, rejestratora stacjonarnego lub przenośnego stanowiących środki techniczne 
służące do wykonywania dozoru elektronicznego, podlega karze aresztu, ograniczenia 
wolności albo grzywny.

***
### Art. 66b. {#kw-art-66b}

§ 1. Kto nie stosuje się do wydanego przez: 
1) 
Policję, na podstawie art. 15aa ust. 1 ustawy z dnia 6 kwietnia 1990 r. o Policji 
(Dz. U. z 2025 r. poz. 636), albo Żandarmerię Wojskową, na podstawie art. 18a 
ust. 1 ustawy z dnia 24 sierpnia 2001 r. o Żandarmerii Wojskowej i wojskowych 
organach 
porządkowych 
(Dz. U. 
z 2025 r. 
poz. 12 
i 
179), 
nakazu 
natychmiastowego opuszczenia wspólnie zajmowanego mieszkania i jego 
bezpośredniego otoczenia i zakazu zbliżania się do wspólnie zajmowanego 
mieszkania i jego bezpośredniego otoczenia, 
2) 
Policję, na podstawie art. 15aaa ust. 2 ustawy z dnia 6 kwietnia 1990 r. o Policji, 
albo Żandarmerię Wojskową, na podstawie art. 18aa ust. 2 ustawy z dnia 
24 sierpnia 
2001 r. 
o Żandarmerii 
Wojskowej 
i wojskowych 
organach 

 
 
 
s. 23/56 
 
 
 
2025-06-13 
 
porządkowych, zakazu wstępu na teren szkoły, placówki oświatowej, 
opiekuńczej lub artystycznej, obiektu sportowego lub miejsca pracy, 
i przebywania na tym terenie, gdy osoba doznająca przemocy domowej 
przebywa na ich terenie, 
3) 
sąd postanowienia o udzieleniu zabezpieczenia przez: 
a) 
przedłużenie obowiązywania nakazu i zakazu lub zakazów, o których mowa 
w pkt 1 i 2, 
b) 
zobowiązanie osoby stosującej przemoc domową do opuszczenia wspólnie 
zajmowanego mieszkania i jego bezpośredniego otoczenia lub wydanie 
zakazu zbliżania się do wspólnie zajmowanego mieszkania i jego 
bezpośredniego otoczenia, lub zakazu wstępu na teren szkoły, placówki 
oświatowej, opiekuńczej lub artystycznej, lub obiektu sportowego, do 
których uczęszcza osoba doznająca przemocy domowej, miejsca pracy lub 
innego miejsca, w którym zwykle lub regularnie przebywa osoba doznająca 
przemocy domowej, i przebywania na tym terenie, o których mowa 
w art. 11a ust. 1 i art. 11aa ust. 4 ustawy z dnia 29 lipca 2005 r. 
o przeciwdziałaniu przemocy domowej (Dz. U. z 2024 r. poz. 1673), 
4) 
sąd postanowienia o zobowiązaniu osoby stosującej przemoc domową do 
opuszczenia wspólnie zajmowanego mieszkania i jego bezpośredniego otoczenia 
lub o zakazie zbliżania się do wspólnie zajmowanego mieszkania i jego 
bezpośredniego otoczenia, lub o zakazie wstępu na teren szkoły, placówki 
oświatowej, opiekuńczej lub artystycznej, lub obiektu sportowego, do których 
uczęszcza osoba doznająca przemocy domowej, miejsca pracy lub innego 
miejsca, w którym zwykle lub regularnie przebywa osoba doznająca przemocy 
domowej, i przebywania na tym terenie, o których mowa w art. 11a ust. 1 
i art. 11aa ust. 4 ustawy z dnia 29 lipca 2005 r. o przeciwdziałaniu przemocy 
domowej 
– podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 2. Tej samej karze podlega, kto umyślnie nie stosuje się do wydanego przez: 
1) 
Policję, na podstawie art. 15aaa ust. 1 ustawy z dnia 6 kwietnia 1990 r. o Policji, 
albo Żandarmerię Wojskową, na podstawie art. 18aa ust. 1 ustawy z dnia 
24 sierpnia 
2001 r. 
o Żandarmerii 
Wojskowej 
i wojskowych 
organach 
porządkowych, zakazu zbliżania się do osoby doznającej przemocy domowej na 

 
 
 
s. 24/56 
 
 
 
2025-06-13 
 
wyrażoną w metrach odległość lub zakazu kontaktowania się z osobą doznającą 
przemocy domowej; 
2) 
sąd postanowienia o udzieleniu zabezpieczenia przez: 
a) 
przedłużenie obowiązywania zakazów, o których mowa w pkt 1, 
b) 
wydanie zakazu zbliżania się do osoby doznającej przemocy domowej na 
wyrażoną w metrach odległość lub zakazu kontaktowania się z osobą 
doznającą przemocy domowej, o których mowa w art. 11aa ust. 1 i 2 ustawy 
z dnia 29 lipca 2005 r. o przeciwdziałaniu przemocy domowej; 
3) 
sąd postanowienia o zakazie zbliżania się do osoby doznającej przemocy 
domowej na wyrażoną w metrach odległość lub o zakazie kontaktowania się 
z osobą doznającą przemocy domowej, o których mowa w art. 11aa ust. 1 i 2 
ustawy z dnia 29 lipca 2005 r. o przeciwdziałaniu przemocy domowej.

***
### Art. 66c. {#kw-art-66c}

Kto uporczywie nie stosuje się do obowiązków określonych 
w art. 4 ust. 6 ustawy z dnia 29 lipca 2005 r. o przeciwdziałaniu przemocy domowej, 
podlega karze ograniczenia wolności albo grzywny.

***
### Art. 67. {#kw-art-67}

§ 1. Kto umyślnie uszkadza lub usuwa ogłoszenie wystawione 
publicznie przez instytucję państwową, samorządową albo organizację społeczną lub 
też w inny sposób umyślnie uniemożliwia zaznajomienie się z takim ogłoszeniem, 
podlega karze aresztu albo grzywny. 
§ 2. Kto umyślnie uszkadza lub usuwa ogłoszenie, afisz lub plakat wystawiony 
publicznie przez instytucję artystyczną, rozrywkową lub sportową albo w inny sposób 
umyślnie uniemożliwia zaznajomienie się z takim ogłoszeniem, afiszem lub plakatem, 
podlega karze grzywny do 1000 złotych albo karze nagany.

***
### Art. 68. {#kw-art-68}

§ 1. Kto bez właściwego zamówienia wyrabia pieczęć, godło lub znak 
instytucji państwowej, samorządowej albo organizacji społecznej lub też taką pieczęć, 
godło lub znak wydaje osobie nieupoważnionej do odbioru, 
podlega karze grzywny. 
§ 2. Tej samej karze podlega, kto bezprawnie posiada, zamawia lub nabywa taką 
pieczęć. 
§ 3. W razie popełnienia wykroczenia określonego w § 1 lub 2 pieczęć, godło lub 
znak podlegają przepadkowi. 

 
 
 
s. 25/56 
 
 
 
2025-06-13

***
### Art. 69. {#kw-art-69}

Kto umyślnie niszczy, uszkadza, usuwa lub w inny sposób czyni 
bezskutecznymi znaki umieszczone przez organ państwowy w celu stwierdzenia 
tożsamości przedmiotu, zamknięcia go lub poddania rozporządzeniu władzy, 
podlega karze aresztu, grzywny albo karze nagany. 

## Rozdział X: Wykroczenia przeciwko bezpieczeństwu osób i mienia

***
### Art. 70. {#kw-art-70}

§ 1. Kto, będąc niezdolny do czynności, której nieumiejętne wykonanie 
może wywołać niebezpieczeństwo dla życia lub zdrowia człowieka, taką czynność 
przedsiębierze albo kto porucza ją osobie do jej wykonania niezdolnej lub wbrew 
obowiązkowi nadzoru dopuszcza do wykonania takiej czynności przez osobę 
niezdolną, 
podlega karze aresztu albo grzywny. 
§ 2. Tej samej karze podlega, kto wbrew obowiązkowi zachowania trzeźwości 
znajduje się w stanie po użyciu alkoholu, środka odurzającego lub innej podobnie 
działającej substancji lub środka i podejmuje w tym stanie czynności zawodowe lub 
służbowe. 
§ 3. W razie popełnienia wykroczenia określonego w § 1 lub 2, można orzec 
podanie orzeczenia do publicznej wiadomości w szczególny sposób.

***
### Art. 71. {#kw-art-71}

Kto przez wadliwe wykonanie urządzeń lub uczynienie ich niezdatnymi 
do funkcjonowania zgodnie z przeznaczeniem albo przez niewłaściwe ich 
użytkowanie lub samowolne uruchomienie wywołuje stan niebezpieczny dla życia lub 
zdrowia człowieka, 
podlega karze aresztu albo grzywny.

***
### Art. 72. {#kw-art-72}

Kto wbrew swemu obowiązkowi nie dokonuje odpowiedniego 
zabezpieczenia miejsca niebezpiecznego dla życia lub zdrowia człowieka, 
podlega karze aresztu albo grzywny.

***
### Art. 73. {#kw-art-73}

Kto wbrew swemu obowiązkowi nie zawiadamia odpowiedniego 
organu lub osoby o wiadomym mu niebezpieczeństwie grożącym życiu lub zdrowiu 
człowieka albo mieniu w znacznych rozmiarach, 
podlega karze aresztu albo grzywny. 

 
 
 
s. 26/56 
 
 
 
2025-06-13

***
### Art. 74. {#kw-art-74}

§ 1. Kto niszczy, uszkadza, usuwa lub czyni nieczytelnymi znaki lub 
napisy ostrzegające o grożącym niebezpieczeństwie dla życia lub zdrowia człowieka 
albo ogrodzenie lub inne urządzenie zapobiegające takiemu niebezpieczeństwu, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 2. W razie popełnienia wykroczenia można orzec obowiązek zapłaty 
równowartości zniszczonego lub uszkodzonego przedmiotu albo obowiązek 
przywrócenia do stanu poprzedniego, a także orzec podanie orzeczenia o ukaraniu do 
publicznej wiadomości w szczególny sposób.

***
### Art. 75. {#kw-art-75}

§ 1. Kto bez zachowania należytej ostrożności wystawia lub wywiesza 
ciężkie przedmioty albo nimi rzuca, wylewa płyny, wyrzuca nieczystości albo 
doprowadza do wypadania takich przedmiotów lub wylewania się płynów, 
podlega karze grzywny do 500 złotych albo karze nagany. 
§ 2. Jeżeli sprawca dopuszcza się czynu określonego w § 1 ze złośliwości lub 
swawoli, 
podlega karze ograniczenia wolności albo grzywny.

***
### Art. 76. {#kw-art-76}

Kto rzuca kamieniami lub innymi przedmiotami w pojazd mechaniczny 
będący w ruchu, 
podlega karze aresztu, ograniczenia wolności albo grzywny.

***
### Art. 77. {#kw-art-77}

§ 1. Kto nie zachowuje zwykłych lub nakazanych środków ostrożności 
przy trzymaniu zwierzęcia, 
podlega karze ograniczenia wolności, grzywny do 1000 złotych albo karze 
nagany. 
§ 2. Kto dopuszcza się czynu określonego w § 1 przy trzymaniu zwierzęcia, które 
swoim zachowaniem stwarza niebezpieczeństwo dla życia lub zdrowia człowieka, 
podlega karze ograniczenia wolności, grzywny albo karze nagany.

***
### Art. 78. {#kw-art-78}

Kto przez drażnienie lub płoszenie doprowadza zwierzę do tego, że staje 
się niebezpieczne, 
podlega karze ograniczenia wolności, grzywny do 1000 złotych albo karze 
nagany.

***
### Art. 79. {#kw-art-79}

§ 1. Kto wbrew swemu obowiązkowi zaniecha oświetlenia miejsc 
dostępnych dla publiczności, 
podlega karze grzywny do 250 złotych albo karze nagany. 

 
 
 
s. 27/56 
 
 
 
2025-06-13 
 
§ 2. Kto ze złośliwości lub swawoli oświetlenie takie gasi, 
podlega karze grzywny do 500 złotych.

***
### Art. 80. {#kw-art-80}

§ 1. Kto: 
1) 
przejeżdża pojazdem lub konno albo przepędza zwierzę gospodarskie przez wał 
przeciwpowodziowy w miejscu do tego nieprzeznaczonym lub przejeżdża 
pojazdem innym niż rower lub konno albo przepędza zwierzę gospodarskie 
wzdłuż po wale przeciwpowodziowym, na którym nie ma drogi o dostatecznie 
mocnej nawierzchni, 
2) 
orze lub bronuje ziemię na wale przeciwpowodziowym albo obok wału 
w odległości mniejszej niż 3 m od stopy wału, 
3) 
rozkopuje wał przeciwpowodziowy, wbija słup lub osadza znak albo zasadza 
drzewo lub krzew na wale, 
4) 
kopie studnię, sadzawkę, dół lub rów obok wału przeciwpowodziowego 
w odległości mniejszej niż 50 m od stopy wału, 
5) 
pasie na wale przeciwpowodziowym zwierzę gospodarskie, 
6) 
uszkadza umocnienie na wale przeciwpowodziowym, 
podlega karze grzywny albo karze nagany. 
§ 2. Tej samej karze podlega, kto narusza inne niż określone w § 1 ograniczenia 
w użytkowaniu wałów przeciwpowodziowych, wprowadzone przez właściwy organ 
administracji państwowej lub samorządowej. 
§ 3. W razie popełnienia wykroczenia można orzec obowiązek przywrócenia do 
stanu poprzedniego.

***
### Art. 81. {#kw-art-81}

Kto niszczy lub uszkadza urządzenia służące do ochrony brzegów wód 
morskich lub śródlądowych, a w szczególności wszelkie umocnienia lub roślinność 
ochronną, 
podlega karze grzywny do 1000 złotych albo karze nagany.

***
### Art. 82. {#kw-art-82}

§ 1. Kto dokonuje czynności, które mogą spowodować pożar, jego 
rozprzestrzenianie się, utrudnienie prowadzenia działania ratowniczego lub ewakuacji, 
polegających na: 
1) 
niedozwolonym używaniu otwartego ognia, paleniu tytoniu i stosowaniu innych 
czynników mogących zainicjować zapłon materiałów palnych, 

 
 
 
s. 28/56 
 
 
 
2025-06-13 
 
2) 
wykonywaniu prac niebezpiecznych pod względem pożarowym bez ich 
wymaganego zabezpieczenia, 
3) 
używaniu instalacji, urządzeń i narzędzi niepoddanych wymaganej kontroli lub 
niesprawnych technicznie albo użytkowaniu ich w sposób niezgodny 
z przeznaczeniem lub warunkami określonymi przez producenta, jeżeli może się 
to przyczynić do powstania pożaru, wybuchu lub rozprzestrzeniania ognia, 
4) 
napełnianiu gazem płynnym butli na stacjach paliw, stacjach gazu płynnego 
i w innych obiektach nieprzeznaczonych do tego celu, 
5) 
nieprzestrzeganiu zasad bezpieczeństwa przy używaniu lub przechowywaniu 
materiałów niebezpiecznych pożarowo, w tym gazu płynnego w butlach, 
6) 
garażowaniu 
pojazdu 
silnikowego 
w obiektach 
i pomieszczeniach 
nieprzeznaczonych do tego celu z nieopróżnionym zbiornikiem paliwa 
i nieodłączonym na stałe zasilaniem akumulatorowym, 
7) 
składowaniu materiałów palnych na drogach komunikacji ogólnej służących 
ewakuacji lub umieszczaniu przedmiotów na tych drogach w sposób 
zmniejszający ich szerokość albo wysokość poniżej wymaganych wartości, 
8) 
składowaniu materiałów palnych na nieużytkowych poddaszach lub na drogach 
komunikacji ogólnej w piwnicach, 
9) 
składowaniu materiałów palnych pod ścianami obiektu bądź przy granicy działki, 
w sposób naruszający zasady bezpieczeństwa pożarowego, 
10) uniemożliwianiu lub ograniczaniu dostępu do urządzeń przeciwpożarowych, 
gaśnic, urządzeń uruchamiających instalacje gaśnicze i sterujących takimi 
instalacjami oraz innymi instalacjami wpływającymi na stan bezpieczeństwa 
pożarowego obiektu, wyłączników i tablic rozdzielczych prądu elektrycznego, 
kurków głównej instalacji gazowej, a także wyjść ewakuacyjnych oraz okien dla 
ekip ratowniczych, 
11) uniemożliwianiu lub ograniczaniu dostępu do źródeł wody do celów 
przeciwpożarowych, 
podlega karze aresztu, grzywny albo karze nagany. 
§ 2. Kto, 
będąc 
obowiązany 
na 
podstawie 
przepisów 
o ochronie 
przeciwpożarowej do zapewnienia warunków ochrony przeciwpożarowej obiektu lub 
terenu, nie dopełnia obowiązków polegających na: 

 
 
 
s. 29/56 
 
 
 
2025-06-13 
 
1) 
zapewnieniu osobom przebywającym w obiekcie lub na terenie odpowiednich 
warunków ewakuacji, 
2) 
wyposażaniu obiektu lub terenu w urządzenia przeciwpożarowe i gaśnice, 
3) 
utrzymywaniu urządzeń przeciwpożarowych i gaśnic w stanie pełnej sprawności 
technicznej i funkcjonalnej, 
4) 
umieszczeniu w widocznych miejscach instrukcji postępowania na wypadek 
pożaru wraz z wykazem telefonów alarmowych oraz wymaganych informacji, 
5) 
oznakowaniu obiektu odpowiednimi znakami bezpieczeństwa, 
6) 
utrzymywaniu dróg pożarowych w stanie umożliwiającym wykorzystanie tych 
dróg przez pojazdy jednostek ochrony przeciwpożarowej, 
7) 
zapewnieniu usuwania zanieczyszczeń z przewodów dymowych i spalinowych, 
8) 
zachowaniu pasa ochronnego o szerokości minimum 2 m i nawierzchni 
z materiałów niepalnych lub gruntowej oczyszczonej, wokół placów 
składowych, składowisk przy obiektach oraz przy obiektach tymczasowych 
o konstrukcji palnej, 
9) 
przestrzeganiu zasad zabezpieczenia przeciwpożarowego podczas zbioru, 
transportu lub składowania palnych płodów rolnych, 
10) zapobieganiu powstawaniu i rozprzestrzenianiu się pożarów w lesie poprzez 
wykonywanie wymaganych zabiegów ochronnych, 
podlega karze aresztu, grzywny albo karze nagany. 
§ 3. Kto na terenie lasu, na terenach śródleśnych, na obszarze łąk, torfowisk 
i wrzosowisk, jak również w odległości do 100 m od nich roznieca ogień poza 
miejscami wyznaczonymi do tego celu albo pali tytoń, z wyjątkiem miejsc na drogach 
utwardzonych i miejsc wyznaczonych do pobytu ludzi, 
podlega karze aresztu, ograniczenia wolności, grzywny albo karze nagany. 
§ 3a. W razie popełnienia wykroczenia określonego w § 3 można orzec 
obowiązek przywrócenia do stanu poprzedniego. 
§ 4. Kto wypala trawy, słomę lub pozostałości roślinne na polach w odległości 
mniejszej niż 100 m od zabudowań, lasów, zboża na pniu i miejsc ustawienia stert lub 
stogów bądź w sposób powodujący zakłócenia w ruchu drogowym, a także bez 
zapewnienia stałego nadzoru miejsca wypalania, 
podlega karze aresztu, grzywny albo karze nagany. 
§ 5. Kto w inny sposób nieostrożnie obchodzi się z ogniem, 

 
 
 
s. 30/56 
 
 
 
2025-06-13 
 
podlega karze aresztu, grzywny albo karze nagany. 
§ 6. Kto zostawia małoletniego do lat 7 w okolicznościach, w których istnieje 
prawdopodobieństwo wzniecenia przez niego pożaru, 
podlega karze grzywny albo karze nagany.

***
### Art. 82a. {#kw-art-82a}

§ 1. Kto w razie powstania pożaru nie dopełnia obowiązku określonego 
w przepisach o ochronie przeciwpożarowej oraz Państwowej Straży Pożarnej 
w postaci: 
1) 
niezwłocznego zawiadomienia osób znajdujących się w strefie zagrożenia oraz: 
centrum powiadamiania ratunkowego lub jednostki ochrony przeciwpożarowej 
albo Policji bądź wójta albo sołtysa, 
2) 
podporządkowania się zarządzeniu kierującego działaniem ratowniczym, 
3) 
udzielenia niezbędnej pomocy kierującemu działaniem ratowniczym, na jego 
żądanie, 
podlega karze aresztu, grzywny albo karze nagany. 
§ 2. Tej samej karze podlega, kto utrudnia prowadzenie działań ratowniczych, 
a w szczególności utrudnia dojazd do obiektów zagrożonych jednostkom ochrony 
przeciwpożarowej, prowadzącym działania ratownicze. 
§ 3. Kto uniemożliwia lub utrudnia przeprowadzenie czynności kontrolno-
-rozpoznawczych z zakresu ochrony przeciw-pożarowej przez uprawnionego strażaka 
Państwowej Straży Pożarnej, 
podlega karze aresztu, ograniczenia wolności albo grzywny.

***
### Art. 82b. {#kw-art-82b}

Kto: 
1) 
będąc właścicielem, użytkownikiem wieczystym albo zarządcą obiektu 
zbiorowej ochrony, nie dopełnia obowiązków określonych w art. 96 ust. 1 pkt 1 
i 2 ustawy z dnia 5 grudnia 2024 r. o ochronie ludności i obronie cywilnej 
(Dz. U. poz. 1907), w zakresie utrzymania lub udostępnienia obiektu zbiorowej 
ochrony do użycia, 
2) 
nie wykonuje nakazu przystosowania, udostępnienia nieruchomości albo 
wykonania miejsc doraźnego schronienia, o których mowa w art. 102 ust. 2 
ustawy z dnia 5 grudnia 2024 r. o ochronie ludności i obronie cywilnej, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 

 
 
 
s. 31/56 
 
 
 
2025-06-13

***
### Art. 83. {#kw-art-83}

§ 1. Kto nieostrożnie obchodzi się z materiałami wybuchowymi, łatwo 
zapalnymi lub substancjami promieniotwórczymi albo wykracza przeciwko przepisom 
o wyrobie, sprzedaży, przechowywaniu, używaniu lub przewożeniu takich 
materiałów, 
podlega karze aresztu, grzywny albo karze nagany. 
§ 2. W razie popełnienia wykroczenia można orzec przepadek przedmiotów 
stanowiących przedmiot wykroczenia. 

## Rozdział XI: Wykroczenia przeciwko bezpieczeństwu i porządkowi w komunikacji

***
### Art. 84. {#kw-art-84}

Kto wbrew obowiązkowi nie oznacza w sposób odpowiadający 
wymaganiom i łatwo dostrzegalny, zarówno w dzień, jak i w porze nocnej, 
jakiejkolwiek przeszkody w ruchu drogowym, urządzenia lub przedmiotu 
znajdujących się na drodze lub też miejsca prowadzonych robót, jeżeli to może 
zagrozić bezpieczeństwu ruchu albo utrudnić ruch na drodze, 
podlega karze aresztu albo grzywny.

***
### Art. 85. {#kw-art-85}

§ 1. Kto samowolnie ustawia, niszczy, uszkadza, usuwa, włącza lub 
wyłącza znak, sygnał, urządzenie ostrzegawcze lub zabezpieczające albo zmienia ich 
położenie, zasłania je lub czyni niewidocznymi, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 2. Tej samej karze podlega, kto samowolnie niszczy, uszkadza, usuwa lub 
ustawia znak turystyczny. 
§ 3. W razie popełnienia wykroczenia określonego w § 1 lub 2 można orzec 
obowiązek zapłaty równowartości zniszczonego lub uszkodzonego przedmiotu albo 
obowiązek przywrócenia do stanu poprzedniego.

***
### Art. 85a. {#kw-art-85a}

§ 1. Kto narusza przepisy dotyczące sposobu znakowania dróg 
wewnętrznych, podlega karze grzywny. 
§ 2. Tej samej karze za czyn określony w § 1 podlega ten, kto zlecił wadliwe 
dokonanie tej czynności.

***
### Art. 86. {#kw-art-86}

§ 1. Kto na drodze publicznej, w strefie zamieszkania lub strefie ruchu, 
nie zachowując należytej ostrożności, powoduje zagrożenie bezpieczeństwa w ruchu 
drogowym, 

 
 
 
s. 32/56 
 
 
 
2025-06-13 
 
podlega karze grzywny. 
§ 1a. Jeżeli 
następstwem 
wykroczenia, 
o którym 
mowa 
w § 1, 
jest 
spowodowanie naruszenia czynności narządu ciała lub rozstrój zdrowia innej osoby, 
sprawca 
podlega karze grzywny w wysokości nie niższej niż 1500 złotych. 
§ 2. Kto dopuszcza się wykroczenia określonego w § 1, znajdując się w stanie po 
użyciu alkoholu lub podobnie działającego środka, 
podlega karze aresztu, ograniczenia wolności albo grzywny w wysokości nie 
niższej niż 2500 złotych. 
§ 3. W razie 
popełnienia 
wykroczenia 
określonego 
w § 1 przez 
osobę 
prowadzącą pojazd można orzec zakaz prowadzenia pojazdów.

***
### Art. 86a. {#kw-art-86a}

Kto, kierując rowerem, hulajnogą elektryczną lub urządzeniem 
transportu osobistego albo poruszając się przy użyciu urządzenia wspomagającego 
ruch na drodze dla pieszych, nie porusza się z prędkością zbliżoną do prędkości 
pieszego lub nie ustępuje pierwszeństwa pieszemu, 
podlega karze grzywny albo karze nagany.

***
### Art. 86b. {#kw-art-86b}

§ 1. Kto na drodze publicznej, w strefie zamieszkania lub strefie ruchu, 
prowadząc pojazd mechaniczny: 
1) 
wbrew obowiązkowi nie ustępuje pierwszeństwa pieszemu, 
2) 
nie zatrzymuje pojazdu w celu umożliwienia przejścia przez jezdnię osobie 
niepełnosprawnej, używającej specjalnego znaku, lub osobie o widocznej 
ograniczonej sprawności ruchowej, 
3) 
wyprzedza pojazd na przejściu dla pieszych, na którym ruch nie jest kierowany, 
lub bezpośrednio przed tym przejściem, 
4) 
omija pojazd, który jechał w tym samym kierunku, lecz zatrzymał się w celu 
ustąpienia pierwszeństwa pieszemu, 
5) 
narusza zakaz jazdy wzdłuż po drodze dla pieszych lub przejściu dla pieszych, 
podlega karze grzywny nie niższej niż 1500 złotych. 
§ 2. Kto dopuszcza się wykroczenia określonego w § 1, prowadząc inny pojazd 
niż określony w tym przepisie, 
podlega karze grzywny albo karze nagany. 

 
 
 
s. 33/56 
 
 
 
2025-06-13 
 
§ 3. W razie popełnienia wykroczenia określonego w § 1 można orzec zakaz 
prowadzenia pojazdów, w szczególności, jeżeli sprawca wykroczenia spowodował 
zagrożenie bezpieczeństwa pieszego.

***
### Art. 87. {#kw-art-87}

§ 1. Kto, znajdując się w stanie po użyciu alkoholu lub podobnie 
działającego środka, prowadzi pojazd mechaniczny w ruchu lądowym, wodnym lub 
powietrznym, 
podlega karze aresztu albo grzywny nie niższej niż 2500 złotych. 
§ 1a. Tej samej karze podlega, kto, znajdując się w stanie nietrzeźwości lub pod 
wpływem podobnie działającego środka, prowadzi na drodze publicznej, w strefie 
zamieszkania lub w strefie ruchu inny pojazd niż określony w § 1. 
§ 2. Kto, znajdując się w stanie po użyciu alkoholu lub podobnie działającego 
środka, prowadzi na drodze publicznej, w strefie zamieszkania lub strefie ruchu inny 
pojazd niż określony w § 1, 
podlega karze aresztu albo karze grzywny nie niższej niż 1000 złotych. 
§ 3. W razie popełnienia wykroczenia określonego w § 1 orzeka się zakaz 
prowadzenia pojazdów. 
§ 4. W razie popełnienia wykroczenia określonego w § 1a lub 2 można orzec 
zakaz prowadzenia pojazdów innych niż określone w § 1.

***
### Art. 88. {#kw-art-88}

Kto na drodze publicznej, w strefie zamieszkania lub strefie ruchu 
prowadzi pojazd bez wymaganych przepisami świateł lub pozostawia pojazd bez 
wymaganego przepisami oświetlenia, 
podlega karze grzywny.

***
### Art. 89. {#kw-art-89}

Kto, mając obowiązek opieki lub nadzoru nad małoletnim do lat 7, 
dopuszcza do przebywania małoletniego na drodze publicznej lub na torach pojazdu 
szynowego, 
podlega karze grzywny albo karze nagany.

***
### Art. 90. {#kw-art-90}

§ 1. Kto tamuje lub utrudnia ruch na drodze publicznej, w strefie 
zamieszkania lub strefie ruchu, 
podlega karze grzywny do 500 złotych lub karze nagany. 
§ 2. Jeżeli wykroczenia, o którym mowa w § 1, dopuszcza się prowadzący 
pojazd mechaniczny, 
podlega karze grzywny nie niższej niż 500 złotych. 

 
 
 
s. 34/56 
 
 
 
2025-06-13

***
### Art. 91. {#kw-art-91}

Kto zanieczyszcza drogę publiczną lub na tej drodze pozostawia pojazd 
lub inny przedmiot albo zwierzę w okolicznościach, w których może to spowodować 
niebezpieczeństwo lub stanowić utrudnienie w ruchu drogowym, 
podlega karze grzywny do 1500 złotych albo karze nagany.

***
### Art. 92. {#kw-art-92}

§ 1. Kto nie stosuje się do znaku lub sygnału drogowego albo do sygnału 
lub polecenia osoby uprawnionej do kierowania ruchem lub do kontroli ruchu 
drogowego, 
podlega karze grzywny albo karze nagany. 
§ 2. Kto w celu uniknięcia kontroli nie stosuje się do sygnału osoby uprawnionej 
do kontroli ruchu drogowego, nakazującego zatrzymanie pojazdu, 
podlega karze aresztu albo grzywny. 
§ 3. W razie popełnienia wykroczenia określonego w § 2 można orzec zakaz 
prowadzenia pojazdów.

***
### Art. 92a. {#kw-art-92a}

§ 1. Kto, prowadząc pojazd, nie stosuje się do ograniczenia prędkości 
określonego ustawą lub znakiem drogowym, podlega karze grzywny. 
§ 2. Kto, prowadząc pojazd mechaniczny, nie stosuje się do ograniczenia 
prędkości określonego ustawą lub znakiem drogowym, przekraczając je o ponad 
30 km/h, 
podlega karze grzywny nie niższej niż 800 złotych.

***
### Art. 92b. {#kw-art-92b}

Kto, prowadząc pojazd mechaniczny, nie stosuje się do zakazu 
wyprzedzania określonego ustawą lub znakiem drogowym, 
podlega karze grzywny nie niższej niż 1000 złotych.

***
### Art. 93. {#kw-art-93}

§ 1. Prowadzący pojazd, który, uczestnicząc w wypadku drogowym, nie 
udziela niezwłocznej pomocy ofierze wypadku, 
podlega karze aresztu albo grzywny. 
§ 2. W razie popełnienia wykroczenia o którym mowa w § 1 orzeka się zakaz 
prowadzenia pojazdów.

***
### Art. 94. {#kw-art-94}

§ 1. Kto na drodze publicznej, w strefie zamieszkania lub strefie ruchu 
prowadzi pojazd mechaniczny, nie mając do tego uprawnienia, 
podlega karze aresztu, ograniczenia wolności albo grzywny nie niższej niż 
1500 złotych. 

 
 
 
s. 35/56 
 
 
 
2025-06-13 
 
§ 1a. Kto na drodze publicznej, w strefie zamieszkania lub strefie ruchu prowadzi 
pojazd inny niż mechaniczny, nie mając do tego uprawnienia, 
podlega karze nagany albo karze grzywny do 1500 złotych. 
§ 2. Tej samej karze podlega, kto prowadzi na drodze publicznej, w strefie 
zamieszkania lub strefie ruchu pojazd pomimo braku dopuszczenia pojazdu do ruchu. 
§ 3. W razie popełnienia wykroczenia, o którym mowa w § 1, orzeka się zakaz 
prowadzenia pojazdów.

***
### Art. 95. {#kw-art-95}

§ 1. Kto prowadzi na drodze publicznej, w strefie zamieszkania lub 
strefie ruchu pojazd, nie mając przy sobie wymaganych dokumentów, 
podlega karze grzywny do 250 złotych albo karze nagany. 
§ 2. Tej samej karze podlega, kto na drodze publicznej, w strefie zamieszkania 
lub strefie ruchu prowadzi pojazd mechaniczny pomimo upływu okresu ważności 
tymczasowego elektronicznego prawa jazdy, o którym mowa w art. 4 ust. 1a ustawy 
z dnia 5 stycznia 2011 r. o kierujących pojazdami (Dz. U. z 2024 r. poz. 1210 i 1544), 
a przed wydaniem prawa jazdy.

***
### Art. 95a. {#kw-art-95a}

Kto posługuje się dowodem rejestracyjnym zawierającym dane 
o spełnieniu przez pojazd wymagań technicznych określonych w przepisach ustawy 
z dnia 11 marca 2004 r. o podatku od towarów i usług (Dz. U. z 2024 r. poz. 361, 852, 
1473, 1721 i 1911 oraz z 2025 r. poz. 222) niezgodne ze stanem faktycznym, podlega 
karze grzywny do 500 zł.

***
### Art. 96. {#kw-art-96}

§ 1. Właściciel, posiadacz, użytkownik lub prowadzący pojazd, który na 
drodze publicznej, w strefie zamieszkania lub strefie ruchu dopuszcza: 
1) 
do prowadzenia pojazdu osobę niemającą sprawności fizycznej lub psychicznej 
w stopniu umożliwiającym należyte prowadzenie pojazdu, 
2) 
do prowadzenia pojazdu osobę niemającą wymaganych uprawnień, 
3) 
do prowadzenia pojazdu osobę znajdującą się w stanie po użyciu alkoholu lub 
podobnie działającego środka, 
4) 
pojazd do jazdy pomimo braku wymaganych dokumentów stwierdzających 
dopuszczenie pojazdu do ruchu, 
5) 
pojazd do jazdy, pomimo że pojazd nie jest należycie zaopatrzony w wymagane 
urządzenia i przyrządy albo pomimo że nie nadają się one do spełnienia swego 
przeznaczenia, 

 
 
 
s. 36/56 
 
 
 
2025-06-13 
 
6) 
do korzystania z pojazdu samochodowego w sposób niezgodny z jego 
przeznaczeniem, 
podlega karze grzywny. 
§ 2. Tej samej karze za czyny określone w § 1 pkt 1, 3–6 oraz za nieumyślne 
dopuszczenie do prowadzenia pojazdu na drodze publicznej przez osobę niemającą 
wymaganych uprawnień podlega dyspozytor pojazdu lub osoba, do której 
obowiązków należą jego czynności, a jeżeli takiej osoby nie wyznaczono – kierownik 
jednostki dysponującej pojazdem. 
§ 3. Tej samej karze podlega, kto wbrew obowiązkowi nie wskaże na żądanie 
uprawnionego organu, komu powierzył pojazd do kierowania lub używania 
w oznaczonym czasie.

***
### Art. 96a. {#kw-art-96a}

§ 1. Kto, nie będąc do tego uprawnionym, posiada w pojeździe 
urządzenia stanowiące obowiązkowe wyposażenie pojazdu uprzywilejowanego 
w ruchu, wysyłające sygnały świetlne w postaci niebieskich lub czerwonych świateł 
błyskowych albo sygnał dźwiękowy o zmiennym tonie, a także elementy oznakowania 
w postaci napisów, 
podlega karze grzywny. 
§ 2. Kto, nie będąc do tego uprawnionym, używa w pojeździe sygnałów 
świetlnych w postaci niebieskich lub czerwonych świateł błyskowych albo sygnału 
dźwiękowego o zmiennym tonie, 
podlega karze aresztu do 14 dni albo grzywny. 
§ 3. Urządzenia lub elementy oznakowania, o których mowa w § 1 i 2, podlegają 
przepadkowi, choćby nie stanowiły własności sprawcy.

***
### Art. 96b. {#kw-art-96b}

Kto, nie będąc do tego uprawnionym, posługuje się kartą parkingową, 
o której mowa w art. 8 ustawy z dnia 20 czerwca 1997 r. – Prawo o ruchu drogowym 
(Dz. U. z 2024 r. poz. 1251), 
podlega karze grzywny do 2000 złotych.

***
### Art. 96c. {#kw-art-96c}

Kto nie przestrzega zakazu wjazdu do strefy czystego transportu 
podlega karze grzywny do 500 złotych.

***
### Art. 96d. {#kw-art-96d}

Kto, działając w imieniu podmiotu uprawnionego, o którym mowa w 
art. 80s ust. 2 ustawy z dnia 20 czerwca 1997 r. – Prawo o ruchu drogowym, 
przekazuje osobie nieuprawnionej blankiet profesjonalnego dowodu rejestracyjnego 

 
 
 
s. 37/56 
 
 
 
2025-06-13 
 
lub profesjonalny dowód rejestracyjny, lub profesjonalną tablicę rejestracyjną, 
podlega karze grzywny.

***
### Art. 97. {#kw-art-97}

Uczestnik ruchu lub inna osoba znajdująca się na drodze publicznej, 
w strefie zamieszkania lub strefie ruchu, a także właściciel lub posiadacz pojazdu, 
który wykracza przeciwko innym przepisom ustawy z dnia 20 czerwca 1997 r. – 
Prawo o ruchu drogowym lub przepisom wydanym na jej podstawie, 
podlega karze grzywny do 3000 złotych albo karze nagany.

***
### Art. 97a. {#kw-art-97a}

Uczestnik ruchu lub inna osoba znajdująca się na drodze publicznej, 
w strefie zamieszkania lub strefie ruchu, a także kierujący pojazdem, który narusza 
zakaz: 
1) 
objeżdżania opuszczonych zapór lub półzapór na przejeździe kolejowym, 
wjeżdżania na przejazd, jeśli opuszczanie zapór lub półzapór zostało rozpoczęte 
lub podnoszenie ich nie zostało zakończone, oraz wejścia lub wjazdu na przejazd 
kolejowy za sygnalizator lub za inne urządzenie nadające sygnały, przy sygnale 
czerwonym, czerwonym migającym lub dwóch na przemian migających 
sygnałach czerwonych, 
2) 
wjeżdżania na przejazd kolejowy, jeśli po jego drugiej stronie nie ma miejsca do 
kontynuowania jazdy, 
podlega karze aresztu, ograniczenia wolności albo grzywny w wysokości nie niższej 
niż 2000 złotych.

***
### Art. 98. {#kw-art-98}

Kto, prowadząc pojazd poza drogą publiczną, strefą zamieszkania lub 
strefą ruchu, nie zachowuje należytej ostrożności, czym zagraża bezpieczeństwu innej 
osoby, 
podlega karze grzywny albo karze nagany.

***
### Art. 99. {#kw-art-99}

§ 1. Kto: 
1) 
(uchylony) 
2) 
niszczy lub uszkadza drogę publiczną lub drogę w strefie zamieszkania, 
przynależności lub urządzenia drogowe, 
3) 
usuwa lub niszczy zasłony odśnieżne, 
4) 
(uchylony) 
podlega karze grzywny albo karze nagany. 

 
 
 
s. 38/56 
 
 
 
2025-06-13 
 
§ 2. Tej samej karze podlega, kto przy zadrzewianiu lub zakrzewianiu albo przy 
prowadzeniu robót ziemnych nie zachowuje przepisowej odległości od linii 
kolejowych.

***
### Art. 100. {#kw-art-100}

Kto: 
1) 
zaorywa lub w inny sposób zwęża pas drogowy lub pas przydrożny, 
2) 
włóczy po drodze publicznej lub porzuca na niej przedmioty albo używa 
pojazdów niszczących nawierzchnię drogi, 
3) 
uszkadza rowy, skarpy nasypów lub wykopów albo samowolnie rozkopuje drogę 
publiczną, 
4) 
wypasa zwierzę gospodarskie w pasie drogowym, 
podlega karze grzywny do 1000 złotych albo karze nagany.

***
### Art. 101. {#kw-art-101}

Kto uchyla się od obowiązku oczyszczania i usuwania z odcinków 
dróg publicznych o twardej nawierzchni, przechodzących przez obszary o zabudowie 
ciągłej lub skupionej poza miastami i osiedlami, błota, kurzu, śniegu lub lodu, 
podlega karze grzywny do 1000 złotych albo karze nagany.

***
### Art. 102. {#kw-art-102}

Kto uchyla się od obowiązku utrzymania w należytym stanie zjazdów 
z dróg publicznych do przyległych nieruchomości, 
podlega karze grzywny do 1000 złotych albo karze nagany.

***
### Art. 103. {#kw-art-103}

Kto bez ważnej przyczyny uchyla się od nałożonego obowiązku 
świadczeń osobistych lub rzeczowych, mających na celu zwalczanie zagrożenia 
przerwania komunikacji na skutek zasp śnieżnych, powodzi lub usuwisk, albo 
wykonuje te świadczenia nienależycie, 
podlega karze grzywny albo karze nagany.

***
### Art. 103a. {#kw-art-103a}

(uchylony) 

## Rozdział XII: Wykroczenia przeciwko osobie

***
### Art. 104. {#kw-art-104}

Kto skłania do żebrania małoletniego lub osobę bezradną albo 
pozostającą w stosunku zależności od niego lub oddaną pod jego opiekę, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 

 
 
 
s. 39/56 
 
 
 
2025-06-13

***
### Art. 105. {#kw-art-105}

§ 1. Kto przez rażące naruszenie obowiązków wynikających z władzy 
rodzicielskiej dopuszcza do popełnienia przez nieletniego czynu zabronionego przez 
ustawę jako przestępstwo, w tym i przestępstwo skarbowe, wykroczenie lub 
wykroczenie skarbowe i wskazującego na demoralizację nieletniego, 
podlega karze grzywny albo karze nagany. 
§ 2. Jeżeli czyn określony w § 1 popełnia osoba, pod której nadzór 
odpowiedzialny oddano nieletniego, 
podlega karze ograniczenia wolności, grzywny albo karze nagany. 
§ 3. W wypadkach określonych w § 1 i 2, jeżeli nieletni czynem swym wyrządził 
szkodę, można orzec nawiązkę do wysokości 1000 złotych.

***
### Art. 106. {#kw-art-106}

Kto, mając obowiązek opieki lub nadzoru nad małoletnim do lat 7 albo 
nad inną osobą niezdolną rozpoznać lub obronić się przed niebezpieczeństwem, 
dopuszcza do jej przebywania w okolicznościach niebezpiecznych dla zdrowia 
człowieka, 
podlega karze grzywny albo karze nagany.

***
### Art. 107. {#kw-art-107}

Kto w celu dokuczenia innej osobie złośliwie wprowadza ją w błąd lub 
w inny sposób złośliwie niepokoi, 
podlega karze ograniczenia wolności, grzywny albo karze nagany.

***
### Art. 107a. {#kw-art-107a}

§ 1. Kto, włączając się bez uprawnienia w transmisję danych 
prowadzoną przy użyciu systemu teleinformatycznego, umyślnie udaremnia lub 
utrudnia użytkownikowi tego systemu przekazywanie lub odbiór informacji, 
podlega karze ograniczenia wolności albo grzywny nie niższej niż 1000 złotych. 
§ 2. Jeżeli sprawca czynu określonego w § 1 używa słów powszechnie uznanych 
za obelżywe lub w inny sposób dopuszcza się nieobyczajnego wybryku, podlega karze 
aresztu, ograniczenia wolności albo karze grzywny nie niższej niż 3000 złotych.

***
### Art. 108. {#kw-art-108}

Kto szczuje psem człowieka, 
podlega karze ograniczenia wolności, grzywny albo karze nagany. 

## Rozdział XIII: Wykroczenia przeciwko zdrowiu

***
### Art. 109. {#kw-art-109}

§ 1. Kto: 
1) 
zanieczyszcza wodę przeznaczoną do spożycia przez ludzi, lub 

 
 
 
s. 40/56 
 
 
 
2025-06-13 
 
2) 
dostarcza wodę przeznaczoną do spożycia przez ludzi, nie spełniając wymagań 
określonych w przepisach o zbiorowym zaopatrzeniu w wodę i zbiorowym 
odprowadzaniu ścieków, lub 
3) 
nie będąc do tego uprawnionym, dostarcza wodę przeznaczoną do spożycia przez 
ludzi w myśl przepisów o zbiorowym zaopatrzeniu w wodę i zbiorowym 
odprowadzaniu ścieków, 
podlega karze grzywny albo karze nagany. 
§ 2. Kto zanieczyszcza wodę służącą do pojenia zwierząt, znajdującą się poza 
urządzeniami przeznaczonymi do zaopatrywania ludności w wodę, 
podlega karze grzywny do 1500 złotych albo karze nagany. 
§ 3. Tej samej karze podlega, kto umyślnie zanieczyszcza wodę w pływalni, 
kąpielisku lub w innym obiekcie o podobnym przeznaczeniu lub dostarcza do tych 
obiektów wodę niespełniającą wymagań określonych w przepisach o zbiorowym 
zaopatrzeniu w wodę i zbiorowym odprowadzaniu ścieków.

***
### Art. 110. {#kw-art-110}

Kto zatrudnia przy pracy, przy wykonywaniu której istnieje możliwość 
przeniesienia zakażenia na inne osoby, osobę, która ze względu na stan zdrowia 
potwierdzony aktualnymi badaniami dla celów sanitarno-epidemiologicznych, 
w rozumieniu przepisów o zapobieganiu oraz zwalczaniu zakażeń i chorób zakaźnych 
u ludzi, nie może być zatrudniona przy tego rodzaju pracy lub której stan zdrowia 
utrudnia utrzymanie higieny osobistej, 
podlega karze grzywny.

***
### Art. 111. {#kw-art-111}

§ 1. Kto nie dopełnia obowiązku zapewnienia należytego stanu 
sanitarnego, zwłaszcza w zakresie utrzymania czystości oraz używania przez 
pracowników wymaganego ubioru: 
1) 
w zakładzie produkującym lub wprowadzającym do obrotu środki spożywcze, 
2) 
w miejscu uzyskiwania mleka, 
podlega karze grzywny. 
§ 2. Tej samej karze podlega, kto nie zachowuje należytej czystości w produkcji 
lub w obrocie środkami spożywczymi.

***
### Art. 112. {#kw-art-112}

(uchylony)

***
### Art. 113. {#kw-art-113}

Kto nie zachowuje należytej czystości przy świadczeniu usług 
w zakładach 
żywienia 
zbiorowego, 
w kąpieliskach, 
zakładach 
fryzjerskich, 

 
 
 
s. 41/56 
 
 
 
2025-06-13 
 
kosmetycznych, pralniczych lub noclegowych albo kto dopuszcza do takich czynności 
osobę dotkniętą chorobą zakaźną, 
podlega karze grzywny.

***
### Art. 114. {#kw-art-114}

Kto odmawia udzielenia organowi służby zdrowia wyjaśnień 
mogących mieć znaczenie dla wykrycia gruźlicy, choroby wenerycznej lub innej 
choroby zakaźnej lub źródła zakażenia albo dla zapobiegania szerzeniu się takich 
chorób, 
podlega karze grzywny albo karze nagany.

***
### Art. 115. {#kw-art-115}

§ 1. Kto, pomimo zastosowania środków egzekucji administracyjnej, 
nie poddaje się obowiązkowemu szczepieniu ochronnemu przeciwko gruźlicy lub 
innej chorobie zakaźnej albo obowiązkowemu badaniu stanu zdrowia, mającemu na 
celu wykrycie lub leczenie gruźlicy, choroby wenerycznej lub innej choroby zakaźnej, 
podlega karze grzywny do 1500 złotych albo karze nagany. 
§ 2. Tej samej karze podlega, kto, sprawując pieczę nad osobą małoletnią lub 
bezradną, pomimo zastosowania środków egzekucji administracyjnej, nie poddaje jej 
określonemu w § 1 szczepieniu ochronnemu lub badaniu.

***
### Art. 116. {#kw-art-116}

§ 1. Kto, wiedząc o tym, że:  
1) 
jest chory na gruźlicę, chorobę weneryczną lub inną chorobę zakaźną albo 
podejrzany o tę chorobę,  
2) 
styka się z chorym na chorobę określoną w pkt 1 lub z podejrzanym o to, że jest 
chory na gruźlicę lub inną chorobę zakaźną,  
3) 
jest nosicielem choroby określonej w pkt 1 lub podejrzanym o nosicielstwo 
– nie przestrzega zakazu, nakazu, ograniczenia lub obowiązku, określonego w 
przepisach o zapobieganiu oraz zwalczaniu zakażeń i chorób zakaźnych u ludzi lub w 
przepisach o Państwowej Inspekcji Sanitarnej lub nie przestrzega decyzji wydanej na 
podstawie tych przepisów przez organy inspekcji sanitarnej, 
podlega karze grzywny albo karze nagany. 
§ 1a. Kto nie przestrzega zakazu, nakazu, ograniczenia lub obowiązku, 
określonego w przepisach o zapobieganiu oraz zwalczaniu zakażeń i chorób 
zakaźnych u ludzi, 
podlega karze grzywny albo karze nagany. 

 
 
 
s. 42/56 
 
 
 
2025-06-13 
 
§ 2. Tej samej karze podlega, kto, sprawując pieczę nad osobą małoletnią lub 
bezradną, nie dopełnia obowiązku spowodowania, aby osoba ta zastosowała się do 
zakazu, nakazu, ograniczenia, obowiązku lub decyzji, o których mowa w § 1 i 1a.

***
### Art. 117. {#kw-art-117}

§ 1. Kto, mając obowiązek utrzymania czystości i porządku w obrębie 
nieruchomości, nie wykonuje swoich obowiązków lub nie stosuje się do wskazań 
i nakazów wydanych przez właściwe organy w celu zabezpieczenia należytego stanu 
sanitarnego i zwalczania chorób zakaźnych, 
podlega karze grzywny do 1500 złotych albo karze nagany. 
§ 2. Tej samej karze podlega przewoźnik obowiązany do zapewnienia 
podróżnym odpowiednich warunków higieny, który nie utrzymuje środka transportu 
we właściwym stanie sanitarnym.

***
### Art. 118. {#kw-art-118}

§ 1. Kto: 
1) 
dokonuje uboju zwierzęcia bez wymaganego zezwolenia lub niezgodnie 
z warunkami określonymi w tym zezwoleniu, 
2) 
usuwa części zwierzęcia przed wykonaniem wymaganego badania po uboju, 
3) 
nie poddaje mięsa badaniu, jeżeli takie badanie jest wymagane 
– podlega karze grzywny. 
§ 2. Kto wprowadza do obrotu mięso: 
1) 
bez wymaganego oznakowania i świadectwa, 
2) 
warunkowo zdatne do spożycia lub niezdatne do spożycia, wbrew określonemu 
sposobowi jego wykorzystania 
– podlega karze aresztu albo grzywny. 
§ 3. W razie popełnienia wykroczenia określonego w § 1 i 2, można orzec 
przepadek mięsa, chociażby nie stanowiło własności sprawcy wykroczenia. 

## Rozdział XIV: Wykroczenia przeciwko mieniu

***
### Art. 119. {#kw-art-119}

§ 1. Kto kradnie lub przywłaszcza sobie cudzą rzecz ruchomą, jeżeli 
jej wartość nie przekracza 800 złotych, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 2. Usiłowanie, podżeganie i pomocnictwo są karalne. 
§ 3. Jeżeli sprawca czynu określonego w § 1 dopuścił się go na szkodę osoby 
najbliższej, ściganie następuje na żądanie pokrzywdzonego. 

 
 
 
s. 43/56 
 
 
 
2025-06-13 
 
§ 4. W razie popełnienia wykroczenia określonego w § 1, można orzec 
obowiązek zapłaty równowartości ukradzionego lub przywłaszczonego mienia, jeżeli 
szkoda nie została naprawiona.

***
### Art. 120. {#kw-art-120}

§ 1. Kto w celu przywłaszczenia dopuszcza się wyrębu drzewa w lesie 
albo kradnie lub przywłaszcza sobie z lasu drzewo wyrąbane lub powalone, jeżeli 
wartość drzewa nie przekracza 800 złotych, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 2. Usiłowanie oraz podżeganie i pomocnictwo są karalne. 
§ 3. W razie popełnienia wykroczenia określonego w § 1 orzeka się nawiązkę 
w wysokości podwójnej wartości wyrąbanego, ukradzionego lub przywłaszczonego 
drzewa, a ponadto, jeżeli ukradzione lub przywłaszczone drzewo nie zostało odebrane, 
orzeka się obowiązek zapłaty jego równowartości.

***
### Art. 121. {#kw-art-121}

§ 1. Kto, pomimo nieuiszczenia dwukrotnie nałożonej na niego kary 
pieniężnej określonej w taryfie, po raz trzeci w ciągu roku bez zamiaru uiszczenia 
należności wyłudza przejazd koleją lub innym środkiem lokomocji, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 2. Tej samej karze podlega, kto bez zamiaru uiszczenia należności wyłudza 
pożywienie lub napój w zakładzie żywienia zbiorowego, przejazd środkiem lokomocji 
należącym do przedsiębiorstwa niedysponującego karami pieniężnymi określonymi 
w taryfie, wstęp na imprezę artystyczną, rozrywkową lub sportową, działanie 
automatu lub inne podobne świadczenie, o którym wie, że jest płatne. 
§ 3. W razie 
popełnienia 
wykroczenia 
określonego 
w § 2 można 
orzec 
obowiązek zapłaty równowartości wyłudzonego mienia.

***
### Art. 122. {#kw-art-122}

§ 1. Kto nabywa mienie, wiedząc o tym, że pochodzi ono z kradzieży 
lub z przywłaszczenia, lub pomaga do jego zbycia albo w celu osiągnięcia korzyści 
majątkowej mienie to przyjmuje lub pomaga do jego ukrycia, jeżeli wartość mienia 
nie przekracza 800 złotych, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 2. Kto nabywa mienie, o którym na podstawie towarzyszących okoliczności 
powinien i może przypuszczać, że zostało uzyskane za pomocą kradzieży lub 
przywłaszczenia, lub pomaga do jego zbycia albo w celu osiągnięcia korzyści 

 
 
 
s. 44/56 
 
 
 
2025-06-13 
 
majątkowej mienie to przyjmuje lub pomaga do jego ukrycia, jeżeli wartość mienia 
nie przekracza 800 złotych, 
podlega karze grzywny albo karze nagany. 
§ 3. Usiłowanie wykroczenia określonego w § 1 oraz podżeganie do niego 
i pomocnictwo są karalne.

***
### Art. 123. {#kw-art-123}

§ 1. Kto z nienależącego do niego ogrodu bezprawnie zabiera 
w nieznacznej ilości owoce, warzywa lub kwiaty, 
podlega karze grzywny do 250 złotych albo karze nagany. 
§ 2. Ściganie następuje na żądanie pokrzywdzonego. 
§ 3. W razie popełnienia wykroczenia można orzec nawiązkę do wysokości 
50 złotych.

***
### Art. 124. {#kw-art-124}

§ 1. Kto cudzą rzecz umyślnie niszczy, uszkadza lub czyni niezdatną 
do użytku, jeżeli szkoda nie przekracza 800 złotych, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 2. Usiłowanie, podżeganie i pomocnictwo są karalne. 
§ 3. Ściganie następuje na żądanie pokrzywdzonego. 
§ 4. W razie popełnienia wykroczenia można orzec obowiązek zapłaty 
równowartości wyrządzonej szkody lub obowiązek przywrócenia do stanu 
poprzedniego.

***
### Art. 125. {#kw-art-125}

Kto w ciągu dwóch tygodni od dnia znalezienia cudzej rzeczy albo 
przybłąkania się cudzego zwierzęcia nie zawiadomi o tym organu Policji lub innego 
organu państwowego albo w inny właściwy sposób nie poszukuje posiadacza, 
podlega karze grzywny do 500 złotych albo karze nagany.

***
### Art. 126. {#kw-art-126}

§ 1. Kto zabiera w celu przywłaszczenia, przywłaszcza sobie albo 
umyślnie niszczy lub uszkadza cudzą rzecz przedstawiającą wartość niemajątkową, 
podlega karze grzywny albo karze nagany. 
§ 2. Ściganie następuje na żądanie pokrzywdzonego.

***
### Art. 127. {#kw-art-127}

§ 1. Kto samowolnie używa cudzej rzeczy ruchomej, 
podlega karze grzywny albo nagany. 
§ 2. Ściganie następuje na żądanie pokrzywdzonego. 

 
 
 
s. 45/56 
 
 
 
2025-06-13

***
### Art. 128. {#kw-art-128}

§ 1. Kto w celu osiągnięcia korzyści majątkowej urządza grę 
hazardową albo użycza do niej środków lub pomieszczenia, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 2. Pieniądze i inne przedmioty służące do gry podlegają przepadkowi, choćby 
nie stanowiły własności sprawcy.

***
### Art. 129. {#kw-art-129}

§ 1. Kto: 
1) 
wyrabia, posiada lub nabywa wytrychy, jeżeli nie trudni się zawodem, w którym 
są one potrzebne, 
2) 
dostarcza wytrychów osobie nietrudniącej się takim zawodem, 
3) 
wyrabia, posiada lub nabywa klucze do cudzego domu, mieszkania lub innego 
pomieszczenia albo schowania bez zezwolenia osoby uprawnionej lub organu 
administracji, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 2. Tej samej karze podlega, kto wyrabia, posiada lub nabywa narzędzia 
przeznaczone do dokonywania kradzieży albo kto dostarcza takich narzędzi innym 
osobom. 
§ 3. Wytrychy, klucze lub narzędzia podlegają przepadkowi, choćby nie 
stanowiły własności sprawcy.

***
### Art. 130. {#kw-art-130}

§ 1. Przepisów art. 119, art. 122 i art. 124 nie stosuje się: 
1) 
(uchylony) 
2) 
jeżeli przedmiotem czynu jest broń, amunicja, materiały lub przyrządy 
wybuchowe. 
§ 2. Przepisu art. 119 nie stosuje się, jeżeli sprawca popełnia kradzież w sposób 
szczególnie zuchwały lub z włamaniem. 
§ 3. Przepisów art. 119 i 120 nie stosuje się, jeżeli sprawca używa gwałtu na 
osobie albo grozi jego natychmiastowym użyciem, aby utrzymać się w posiadaniu 
zabranego mienia, a gdy chodzi o zabranie innej osobie mienia w celu przy-
właszczenia, także wtedy, gdy sprawca doprowadza człowieka do stanu 
nieprzytomności lub bezbronności. 
§ 4. (uchylony)

***
### Art. 131. {#kw-art-131}

Przepisy art. 119, 122 i 124 stosuje się również w razie popełnienia 
wykroczenia za granicą. 

 
 
 
s. 46/56 
 
 
 
2025-06-13 
 

## Rozdział XV: Wykroczenia przeciwko interesom konsumentów

***
### Art. 132. {#kw-art-132}

(uchylony)

***
### Art. 133. {#kw-art-133}

§ 1. Kto nabywa w celu odprzedaży z zyskiem bilety wstępu na 
imprezy artystyczne, rozrywkowe lub sportowe albo kto bilety takie sprzedaje 
z zyskiem, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 2. Usiłowanie oraz podżeganie i pomocnictwo są karalne.

***
### Art. 134. {#kw-art-134}

§ 1. Kto przy sprzedaży towaru lub świadczeniu usług oszukuje 
nabywcę co do ilości, wagi, miary, gatunku, rodzaju lub ceny, jeżeli nabywca poniósł 
lub mógł ponieść szkodę nieprzekraczającą 100 złotych, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 2. Tej samej karze podlega, kto przy nabyciu produktów rolnych lub 
hodowlanych oszukuje dostawcę co do ilości, wagi, miary, gatunku lub ceny, jeżeli 
dostawca poniósł lub mógł ponieść szkodę nieprzekraczającą 100 złotych. 
§ 3. Usiłowanie wykroczenia określonego w § 1 lub 2 oraz podżeganie 
i pomocnictwo są karalne.

***
### Art. 135. {#kw-art-135}

Kto, zajmując się sprzedażą towarów w przedsiębiorstwie handlu 
detalicznego lub w przedsiębiorstwie gastronomicznym, ukrywa przed nabywcą towar 
przeznaczony do sprzedaży lub umyślnie bez uzasadnionej przyczyny odmawia 
sprzedaży takiego towaru, 
podlega karze grzywny.

***
### Art. 136. {#kw-art-136}

§ 1. Kto z towarów przeznaczonych do sprzedaży umyślnie usuwa 
utrwalone na nich oznaczenie określające ich cenę, termin przydatności do spożycia 
lub datę produkcji, jakość lub ilość nominalną, gatunek lub pochodzenie, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 2. Kto przeznacza do sprzedaży towary z usuniętym trwałym oznaczeniem ich 
ceny, terminu przydatności do spożycia lub daty produkcji, jakości, gatunku lub 
pochodzenia albo towary niewłaściwie oznaczone, 
podlega karze ograniczenia wolności albo grzywny do 1500 złotych. 

 
 
 
s. 47/56 
 
 
 
2025-06-13 
 
§ 3. Usiłowanie wykroczenia określonego w § 1 oraz podżeganie do niego 
i pomocnictwo są karalne.

***
### Art. 137. {#kw-art-137}

§ 1. (uchylony) 
§ 2. Kierownik punktu sprzedaży detalicznej lub zakładu gastronomicznego, 
który nie ma faktur albo innych dowodów dostawy lub przyjęcia na towary 
przechowywane w punkcie sprzedaży detalicznej lub zakładzie gastronomicznym, 
podlega karze aresztu albo grzywny.

***
### Art. 138. {#kw-art-138}

1) Kto, zajmując się zawodowo świadczeniem usług, żąda i pobiera za 
świadczenie zapłatę wyższą od obowiązującej albo umyślnie bez uzasadnionej 
przyczyny odmawia świadczenia, do którego jest obowiązany, 
podlega karze grzywny.

***
### Art. 138a. {#kw-art-138a}

(uchylony) 
 [

***
### Art. 138b. {#kw-art-138b}

§ 1. Kto, będąc zobowiązany na mocy orzeczenia sądu do 
zaniechania wykorzystywania lub do odwołania zalecenia stosowania ogólnych 
warunków umów albo wzoru umowy, nie stosuje się do tego obowiązku, zawierając 
w umowie niedozwolone postanowienia umowne, podlega karze grzywny. 
§ 2. Jeżeli orzeczenie sądu, o którym mowa w § 1, dotyczy przedsiębiorcy 
niebędącego osobą fizyczną, odpowiedzialność przewidzianą w § 1 ponosi osoba 
kierująca przedsiębiorstwem lub osoba upoważniona do zawierania umów 
z konsumentami.]

***
### Art. 138c. {#kw-art-138c}

§ 1. Kto w zakresie działalności swojego przedsiębiorstwa zawiera 
z konsumentem umowę o kredyt konsumencki z rażącym naruszeniem wymagań 
dotyczących informacji przekazywanych konsumentowi przed zawarciem umowy lub 
treści umowy albo z pominięciem obowiązku doręczenia jej dokumentu, 
podlega karze grzywny. 
§ 1a. Tej samej karze podlega, kto zawierając z konsumentem umowę o kredyt 
konsumencki nie dopełnia obowiązku oceny zdolności kredytowej. 
§ 2. Kto w reklamach dotyczących kredytu konsumenckiego zawierających dane 
dotyczące kosztu kredytu konsumenckiego, nie podaje: 
 
1) Utracił moc z dniem 4 lipca 2019 r. w części zawierającej słowa „albo umyślnie bez uzasadnionej 
przyczyny odmawia świadczenia, do którego jest obowiązany”, na podstawie wyroku Trybunału 
Konstytucyjnego z dnia 26 czerwca 2019 r. sygn. akt K 16/17 (Dz. U. poz. 1238). 
Przepis uchylający 
art. 138b wejdzie w 
życie 
z 
dn. 
18.04.2026 r. (Dz. 
U. z 2015 r. poz. 
1634). 

 
 
 
s. 48/56 
 
 
 
2025-06-13 
 
1) 
stopy oprocentowania kredytu wraz z wyodrębnieniem opłat uwzględnianych 
w całkowitym koszcie kredytu, 
2) 
całkowitej kwoty kredytu, 
3) 
rzeczywistej rocznej stopy oprocentowania, 
podlega karze grzywny. 
§ 3. Kto przyjmuje od konsumenta czek niezawierający zastrzeżenia „nie na 
zlecenie” lub innego równoznacznego w celu spełnienia lub zabezpieczenia 
świadczenia wynikającego z umowy o kredyt konsumencki, podlega karze grzywny. 
§ 3a. Kto przyjmuje od konsumenta weksel niezawierający zastrzeżenia „nie na 
zlecenie” lub innego równoznacznego w celu spełnienia lub zabezpieczenia 
świadczenia wynikającego z umowy zawartej z konsumentem, podlega karze 
grzywny. 
§ 4. Jeżeli 
przedsiębiorcą 
jest 
podmiot 
niebędący 
osobą 
fizyczną, 
odpowiedzialność przewidzianą w przepisach § 1–3a ponosi osoba kierująca 
przedsiębiorstwem lub osoba upoważniona do zawierania umów z konsumentami.

***
### Art. 138d. {#kw-art-138d}

§ 1. Kto, podejmując zadania przewodnika górskiego na określonym 
obszarze górskim wprowadza w błąd co do posiadanych uprawnień, podlega karze 
ograniczenia wolności albo grzywny. 
§ 2. Tej samej karze podlega organizator turystyki lub przedsiębiorca ułatwiający 
nabywanie powiązanych usług turystycznych, który wprowadza podróżnych w błąd 
co do uprawnień osób, którym powierza wykonywanie zadań przewodnika górskiego.

***
### Art. 139. {#kw-art-139}

(uchylony)

***
### Art. 139a. {#kw-art-139a}

§ 1. Kto w zakresie działalności swojego przedsiębiorstwa: 
1) 
zawiera z konsumentem umowę timeshare, umowę o długoterminowy produkt 
wakacyjny, 
umowę 
pośrednictwa 
w odsprzedaży 
timeshare 
lub 
długoterminowego produktu 
wakacyjnego, lub umowę o uczestnictwo 
w systemie wymiany, bez zachowania właściwych wymogów, dotyczących jej 
treści lub formy, 
2) 
żąda 
od 
konsumenta, 
z którym 
zawarł 
umowę 
timeshare, 
umowę 
o długoterminowy produkt wakacyjny lub umowę o uczestnictwo w systemie 
wymiany, świadczenia przed upływem określonego w ustawie terminu do 

 
 
 
s. 49/56 
 
 
 
2025-06-13 
 
odstąpienia od umowy, lub świadczenie takie przed upływem tego terminu od 
konsumenta przyjmuje, 
3) 
żąda od konsumenta, z którym zawarł umowę pośrednictwa w odsprzedaży 
timeshare lub długoterminowego produktu wakacyjnego, świadczenia przed 
rozwiązaniem umowy lub przed doprowadzeniem do nabycia lub zbycia przez 
konsumenta praw z umowy timeshare lub z umowy o długoterminowy produkt 
wakacyjny, lub świadczenie takie przed rozwiązaniem umowy lub przed 
doprowadzeniem do nabycia lub zbycia przez konsumenta praw z umowy 
timeshare lub z umowy o długoterminowy produkt wakacyjny od konsumenta 
przyjmuje, 
4) 
żąda od konsumenta, z którym zawarł umowę przedwstępną, zobowiązującą do 
zawarcia umowy timeshare, umowy o długoterminowy produkt wakacyjny, 
umowy pośrednictwa w odsprzedaży timeshare lub długoterminowego produktu 
wakacyjnego, lub umowy o uczestnictwo w systemie wymiany, świadczenia 
określonego w umowie przedwstępnej przed upływem terminu do odstąpienia od 
umowy przedwstępnej, lub świadczenie takie przed upływem tego terminu od 
konsumenta przyjmuje 
– podlega karze ograniczenia wolności albo grzywny. 
§ 2. Kto zawierając umowę timeshare sprzecznie z treścią nabywanego prawa 
oświadcza, że przedmiotem umowy jest własność 
– podlega karze grzywny. 
§ 3. Kto w zakresie działalności swojego przedsiębiorstwa, po upływie 
określonego w ustawie terminu do odstąpienia od umowy timeshare, umowy 
o długoterminowy produkt wakacyjny, umowy pośrednictwa w odsprzedaży 
timeshare lub długoterminowego produktu wakacyjnego lub umowy o uczestnictwo 
w systemie wymiany, nie przekazuje konsumentowi informacji wymaganych ustawą 
– podlega karze grzywny. 
§ 4. Karze określonej w § 3 podlega również ten, kto w zakresie działalności 
swojego przedsiębiorstwa, po upływie określonego w ustawie terminu do odstąpienia 
od umowy przedwstępnej, zobowiązującej do zawarcia umowy timeshare, umowy 
o długoterminowy produkt wakacyjny, umowy pośrednictwa w odsprzedaży 
timeshare lub długoterminowego produktu wakacyjnego, lub umowy o uczestnictwo 
w systemie wymiany, nie przekazuje konsumentowi informacji wymaganych ustawą. 

 
 
 
s. 50/56 
 
 
 
2025-06-13

***
### Art. 139b. {#kw-art-139b}

Kto w zakresie działalności swojego przedsiębiorstwa zawierając 
umowę z konsumentem nie spełnia wymagań dotyczących udzielenia informacji lub 
wydania dokumentu, przewidzianych w przepisach ustawy z dnia 30 maja 2014 r. 
o prawach konsumenta (Dz. U. z 2024 r. poz. 1796), podlega karze grzywny.

***
### Art. 139c. {#kw-art-139c}

§ 1. Kto w zakresie działalności swojego przedsiębiorstwa przyjmuje 
od konsumenta płatność przed upływem terminu do odstąpienia od umowy zawartej 
na odległość lub poza lokalem przedsiębiorstwa, w przypadkach określonych 
w art. 17a ustawy z dnia 30 maja 2014 r. o prawach konsumenta, podlega karze 
grzywny. 
§ 2. Jeżeli 
przedsiębiorcą 
jest 
podmiot 
niebędący 
osobą 
fizyczną, 
odpowiedzialność przewidzianą w § 1 ponosi osoba kierująca przedsiębiorstwem lub 
osoba upoważniona do zawierania umów z konsumentami. 

## Rozdział XVI: Wykroczenia przeciwko obyczajności publicznej

***
### Art. 140. {#kw-art-140}

Kto publicznie dopuszcza się nieobyczajnego wybryku, 
podlega karze aresztu, ograniczenia wolności, grzywny do 1500 złotych albo 
karze nagany.

***
### Art. 141. {#kw-art-141}

Kto w miejscu publicznym umieszcza nieprzyzwoite ogłoszenie, napis 
lub rysunek albo używa słów nieprzyzwoitych, 
podlega karze ograniczenia wolności, grzywny do 1500 złotych albo karze 
nagany.

***
### Art. 142. {#kw-art-142}

Kto natarczywie, narzucając się lub w inny naruszający porządek 
publiczny sposób, proponuje innej osobie dokonanie z nią czynu nierządnego, mając 
na celu uzyskanie korzyści materialnej, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 

## Rozdział XVII: Wykroczenia przeciwko urządzeniom użytku publicznego

***
### Art. 143. {#kw-art-143}

§ 1. Kto ze złośliwości lub swawoli utrudnia lub uniemożliwia 
korzystanie z urządzeń przeznaczonych do użytku publicznego, a w szczególności 
uszkadza lub usuwa przyrząd alarmowy, instalację oświetleniową, zegar, automat, 

 
 
 
s. 51/56 
 
 
 
2025-06-13 
 
telefon, oznaczenie nazwy miejscowości, ulicy, placu lub nieruchomości, urządzenie 
służące do utrzymania czystości lub ławkę, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 2. W razie popełnienia wykroczenia można orzec obowiązek zapłaty 
równowartości wyrządzonej szkody albo obowiązek przywrócenia do stanu 
poprzedniego.

***
### Art. 144. {#kw-art-144}

§ 1. Kto na terenach przeznaczonych do użytku publicznego niszczy 
lub uszkadza roślinność lub też dopuszcza do niszczenia roślinności przez zwierzęta 
znajdujące się pod jego nadzorem albo na terenach przeznaczonych do użytku 
publicznego depcze trawnik lub zieleniec w miejscach innych niż wyznaczone dla 
celów rekreacji przez właściwego zarządcę terenu, 
podlega karze grzywny do 1000 złotych albo karze nagany. 
§ 2. Kto usuwa, niszczy lub uszkadza drzewa lub krzewy stanowiące 
zadrzewienie przydrożne lub ochronne albo żywopłot przydrożny, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 3. W razie popełnienia wykroczenia określonego w § 1 lub 2 można orzec 
nawiązkę do wysokości 500 złotych.

***
### Art. 145. {#kw-art-145}

§ 1. Kto zanieczyszcza lub zaśmieca obszar kolejowy lub miejsca 
dostępne dla publiczności, a w szczególności drogę, ulicę, plac, ogród, trawnik lub 
zieleniec, 
podlega karze grzywny nie niższej niż 500 złotych. 
§ 2. Usiłowanie wykroczenia określonego w § 1 oraz podżeganie do niego 
i pomocnictwo są karalne. 
§ 3. W razie 
popełnienia 
wykroczenia 
określonego 
w § 1 można 
orzec 
obowiązek przywrócenia do stanu poprzedniego. 

## Rozdział XVIII: Wykroczenia przeciwko obowiązkowi ewidencji

***
### Art. 146. {#kw-art-146}

§ 1. Kto nie dopełnia w terminie obowiązku zgłoszenia w urzędzie 
stanu cywilnego faktu urodzenia lub zgonu, 
podlega karze grzywny do 250 złotych albo karze nagany. 
§ 2. Sprawca nie podlega odpowiedzialności, jeżeli pomimo niedokonania 
zgłoszenia akt stanu cywilnego został sporządzony we właściwym czasie. 

 
 
 
s. 52/56 
 
 
 
2025-06-13

***
### Art. 147. {#kw-art-147}

(uchylony)

***
### Art. 147a. {#kw-art-147a}

§ 1. Kto wykonuje działalność leczniczą lub prowadzi zakład 
leczniczy dla zwierząt bez wymaganego wpisu do rejestru lub ewidencji, 
podlega karze aresztu, ograniczenia wolności albo grzywny. 
§ 2. Tej samej karze podlega ten, kto podaje do wiadomości publicznej 
informacje o zakresie i rodzajach udzielanych świadczeń zdrowotnych lub usług 
z zakresu medycyny weterynaryjnej mające formę i treść reklamy. 

## Rozdział XIX: Szkodnictwo leśne, polne i ogrodowe

***
### Art. 148. {#kw-art-148}

§ 1. Kto: 
1) 
dokonuje w nienależącym do niego lesie wyrębu gałęzi, korzeni lub krzewów, 
niszczy je lub uszkadza albo karczuje pniaki, 
2) 
zabiera z nienależącego do niego lasu wyrąbane gałęzie, korzenie lub krzewy 
albo wykarczowane pniaki, 
podlega karze grzywny. 
§ 2. Jeżeli czyn godzi w mienie osoby najbliższej, ściganie następuje na żądanie 
pokrzywdzonego. 
§ 3. W razie popełnienia wykroczenia można orzec nawiązkę do wysokości 
500 złotych.

***
### Art. 149. {#kw-art-149}

Kto nabywa gałęzie, korzenie, krzewy lub pniaki wiedząc o tym, że 
pochodzą one z wykroczenia określonego w art. 148, lub pomaga do ich zbycia albo 
w celu osiągnięcia korzyści majątkowej przyjmuje je lub pomaga do ich ukrycia, 
podlega karze grzywny.

***
### Art. 150. {#kw-art-150}

§ 1. Kto uszkadza nienależący do niego ogród warzywny, owocowy 
lub kwiatowy, drzewo owocowe lub krzew owocowy, 
podlega karze ograniczenia wolności albo grzywny do 1500 złotych. 
§ 2. Ściganie następuje na żądanie pokrzywdzonego. 
§ 3. W razie popełnienia wykroczenia orzeka się nawiązkę do wysokości 
1500 złotych. 

 
 
 
s. 53/56 
 
 
 
2025-06-13

***
### Art. 151. {#kw-art-151}

§ 1. Kto pasie zwierzęta gospodarskie na nienależących do niego 
gruntach leśnych lub rolnych albo przez takie grunty w miejscach, w których jest to 
zabronione, przechodzi, przejeżdża lub przegania zwierzęta gospodarskie, 
podlega karze grzywny do 500 złotych albo karze nagany. 
§ 2. Jeżeli grunt jest zaorany, zasiany lub obsadzony, znajduje się w stanie 
sztucznego zalesienia, naturalnego odnowienia lub stanowi młodnik leśny do lat 20, 
sprawca 
podlega karze grzywny. 
§ 3. Karze określonej w § 2 podlega również ten, kto przejeżdża lub przegania 
zwierzęta gospodarskie przez wodę zamkniętą i zarybioną. 
§ 4. Ściganie następuje na żądanie pokrzywdzonego. 
§ 5. W razie popełnienia wykroczenia określonego w § 1, 2 lub 3 można orzec 
nawiązkę do wysokości 1500 złotych.

***
### Art. 152. {#kw-art-152}

§ 1. Kto niszczy lub użytkuje kosodrzewinę znajdującą się na 
siedliskach naturalnych w górach lub na torfowiskach, 
podlega karze grzywny do 1000 złotych albo karze nagany. 
§ 2. W razie popełnienia wykroczenia można orzec nawiązkę do wysokości 
500 złotych.

***
### Art. 153. {#kw-art-153}

§ 1. Kto w nienależącym do niego lesie: 
1) 
wydobywa żywicę lub sok brzozowy, obrywa szyszki, zdziera korę, nacina 
drzewo lub w inny sposób je uszkadza, 
2) 
zbiera mech lub ściółkę, 
3) 
zbiera gałęzie, korę, wióry, trawę, wrzos, szyszki lub zioła albo zdziera darń, 
4) 
zbiera grzyby lub owoce leśne w miejscach, w których jest to zabronione, albo 
sposobem niedozwolonym, 
podlega karze grzywny do 250 złotych albo karze nagany. 
§ 2. Jeżeli czyn godzi w mienie osoby najbliższej, ściganie następuje na żądanie 
pokrzywdzonego.

***
### Art. 154. {#kw-art-154}

§ 1. Kto na nienależącym do niego gruncie leśnym lub rolnym: 
1) 
wydobywa piasek, margiel, żwir, glinę lub torf, 
2) 
niszczy lub uszkadza urządzenia służące do utrzymania zwierząt lub ptaków, 
3) 
(uchylony) 

 
 
 
s. 54/56 
 
 
 
2025-06-13 
 
4) 
kopie dół lub rów, 
podlega karze grzywny do 1000 złotych albo karze nagany. 
§ 2. Kto na nienależący do niego grunt polny wyrzuca kamienie, odpady, złom 
lub padlinę niebędące odpadami lub inne nieczystości, 
podlega karze grzywny nie niższej niż 500 złotych. 
§ 2a. Usiłowanie wykroczenia określonego w § 2 oraz podżeganie do niego 
i pomocnictwo są karalne. 
§ 2b. W razie popełnienia wykroczenia określonego w § 2 można orzec 
obowiązek przywrócenia do stanu poprzedniego. 
§ 3. Jeżeli czyn godzi w mienie osoby najbliższej, ściganie następuje na żądanie 
pokrzywdzonego.

***
### Art. 155. {#kw-art-155}

§ 1. Kto na gruncie leśnym lub rolnym niszczy lub uszkadza urządzenia 
melioracyjne, 
podlega karze grzywny. 
§ 2. W razie popełnienia wykroczenia można orzec obowiązek zapłaty 
równowartości wyrządzonej szkody lub obowiązek przywrócenia do stanu 
poprzedniego.

***
### Art. 156. {#kw-art-156}

§ 1. Kto na nienależącym do niego gruncie leśnym lub rolnym niszczy 
zasiewy, sadzonki lub trawę, 
podlega karze grzywny do 500 złotych albo karze nagany. 
§ 2. Jeżeli czyn godzi w mienie osoby najbliższej, ściganie następuje na żądanie 
pokrzywdzonego. 
§ 3. W razie popełnienia wykroczenia można orzec nawiązkę do wysokości 
500 złotych.

***
### Art. 157. {#kw-art-157}

§ 1. Kto wbrew żądaniu osoby uprawnionej nie opuszcza lasu, pola, 
ogrodu, pastwiska, łąki lub grobli, 
podlega karze grzywny do 500 złotych lub karze nagany. 
§ 2. Ściganie następuje na żądanie pokrzywdzonego.

***
### Art. 158. {#kw-art-158}

§ 1. Właściciel lub posiadacz lasu, który dokonuje wyrębu drzewa 
w należącym do niego lesie albo w inny sposób pozyskuje z tego lasu drewno 
niezgodnie z planem urządzenia lasu, uproszczonym planem urządzenia lasu lub 

 
 
 
s. 55/56 
 
 
 
2025-06-13 
 
decyzją określającą zadania z zakresu gospodarki leśnej albo bez wymaganego 
pozwolenia, 
podlega karze grzywny. 
§ 2. W razie popełnienia wykroczenia określonego w § 1 orzeka się przepadek 
pozyskanego drewna.

***
### Art. 159. {#kw-art-159}

Kto, wbrew ciążącemu na nim obowiązkowi w zakresie ochrony 
lasów, nie wykonuje zabiegów zapobiegających, wykrywających i zwalczających 
nadmiernie pojawiające się i rozprzestrzeniające się organizmy szkodliwe, 
podlega karze grzywny.

***
### Art. 160. {#kw-art-160}

§ 1. Kto, działając bez wymaganego zezwolenia, zmienia las na uprawę 
rolną, 
podlega karze grzywny. 
§ 2. W razie 
popełnienia 
wykroczenia 
określonego 
w § 1 można 
orzec 
obowiązek przywrócenia do stanu poprzedniego.

***
### Art. 161. {#kw-art-161}

Kto, nie będąc do tego uprawniony albo bez zgody właściciela lub 
posiadacza lasu, wjeżdża pojazdem silnikowym, zaprzęgowym lub motorowerem do 
nienależącego do niego lasu w miejscu, w którym jest to niedozwolone, albo 
pozostawia taki pojazd w lesie w miejscu do tego nieprzeznaczonym, 
podlega karze grzywny.

***
### Art. 162. {#kw-art-162}

§ 1. Kto w lasach zanieczyszcza glebę lub wodę albo wyrzuca do lasu 
kamienie, odpady, złom lub padlinę niebędące odpadami lub inne nieczystości, albo 
w inny sposób zaśmieca las, 
podlega karze ograniczenia wolności albo grzywny nie niższej niż 500 złotych. 
§ 2. Jeżeli czyn sprawcy polega na zakopywaniu, zatapianiu, odprowadzaniu 
do gruntu w lasach lub w inny sposób składowaniu w lesie odpadów, sprawca 
podlega karze aresztu, ograniczenia wolności albo grzywny nie niższej niż 
1000 złotych. 
§ 3. Usiłowanie wykroczenia określonego w § 1 lub 2 oraz podżeganie do niego 
i pomocnictwo są karalne. 
§ 4. W razie popełnienia wykroczenia określonego w § 1 lub 2 można orzec 
obowiązek przywrócenia do stanu poprzedniego.

***
### Art. 163. {#kw-art-163}

Kto w lesie rozgarnia ściółkę i niszczy grzyby lub grzybnię, 

 
 
 
s. 56/56 
 
 
 
2025-06-13 
 
podlega karze grzywny albo karze nagany.

***
### Art. 164. {#kw-art-164}

Kto wybiera jaja lub pisklęta, niszczy lęgowiska lub gniazda ptasie 
albo niszczy legowiska, nory lub mrowiska znajdujące się w lesie albo na 
nienależącym do niego gruncie rolnym, 
podlega karze grzywny albo karze nagany.

***
### Art. 165. {#kw-art-165}

Kto w lesie, w sposób złośliwy, płoszy albo ściga, chwyta, rani lub 
zabija dziko żyjące zwierzę, poza czynnościami związanymi z polowaniem lub 
ochroną lasów, jeżeli czyn z mocy innego przepisu nie jest zagrożony karą surowszą, 
podlega karze grzywny albo karze nagany.

***
### Art. 166. {#kw-art-166}

Kto w lesie puszcza luzem psa, poza czynnościami związanymi: 
1) 
z polowaniem, 
2) 
ze szkoleniem psów będących zwierzętami wykorzystywanymi do celów 
specjalnych w rozumieniu art. 4 pkt 20 ustawy z dnia 21 sierpnia 1997 r. 
o ochronie zwierząt (Dz. U. z 2023 r. poz. 1580), albo ich udziałem w akcji 
ratowniczej, w działaniach poszukiwawczych lub w działaniach związanych 
z ochroną granicy państwowej lub zapewnieniem bezpieczeństwa i porządku 
publicznego, 
3) 
ze szkoleniem psów ratowniczych albo ich udziałem w akcji ratowniczej 
prowadzonej przez podmioty uprawnione do wykonywania ratownictwa na 
podstawie przepisów odrębnych, 
podlega karze grzywny albo karze nagany.

