---
id: code.kw.part1
title: Kodeks wykroczeń — CZĘŚĆ OGÓLNA
short: KW
dz_u: Dz.U. 1971 Nr 12 poz. 114 (t.j. 2025 poz. 734)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '1'
  last: '48'
source_pdf: D19710114Lj.pdf
chunking:
  strategy: by-article
  anchor_pattern: '### Art. {n}. {#kw-art-{n}}'
  hierarchy:
  - CZĘŚĆ
  - Rozdział
  - Art.
---

# CZĘŚĆ OGÓLNA

### Art. 1. {#kw-art-1}

§ 1. Odpowiedzialności za wykroczenie podlega ten tylko, kto popełnia 
czyn społecznie szkodliwy, zabroniony przez ustawę obowiązującą w czasie jego 
popełnienia pod groźbą kary aresztu, ograniczenia wolności, grzywny do 5000 złotych 
lub nagany. 
§ 2. Nie popełnia wykroczenia sprawca czynu zabronionego, jeżeli nie można 
mu przypisać winy w czasie czynu.

***
### Art. 2. {#kw-art-2}

§ 1. Jeżeli w czasie orzekania obowiązuje ustawa inna niż w czasie 
popełnienia wykroczenia, stosuje się ustawę nową, jednakże należy stosować ustawę 
obowiązującą poprzednio, jeżeli jest względniejsza dla sprawcy. 
§ 2. Jeżeli według nowej ustawy czyn objęty orzeczeniem nie jest już zabroniony 
pod groźbą kary, ukaranie uważa się za niebyłe.

***
### Art. 2a. {#kw-art-2a}

§ 1. Jeżeli według nowej ustawy czyn objęty prawomocnym wyrokiem 
skazującym za przestępstwo na karę pozbawienia wolności stanowi wykroczenie, 
orzeczona kara podlegająca wykonaniu ulega zamianie na karę aresztu w wysokości 
równej górnej granicy ustawowego zagrożenia za taki czyn, a jeżeli ustawa nie 
przewiduje za ten czyn kary aresztu, na karę ograniczenia wolności, a jeżeli ustawa 
nie przewiduje za ten czyn kary ograniczenia wolności – na karę grzywny, przyjmując 
Opracowano na 
podstawie: 
t.j. 

poz. 734. 

 
 
 
s. 2/56 
 
 
 
2025-06-13 
 
jeden dzień pozbawienia wolności za równoważny grzywnie w kwocie od 10 do 
250 złotych i nie przekraczając górnej granicy tego rodzaju kary przewidzianej za ten 
czyn. 
§ 2. Jeżeli według nowej ustawy czyn objęty prawomocnym wyrokiem 
skazującym za przestępstwo na grzywnę lub karę ograniczenia wolności stanowi 
wykroczenie, orzeczone kary ulegają zamianie tylko wówczas, gdy kara grzywny lub 
ograniczenia wolności podlegająca wykonaniu przekroczyłaby górną granicę 
ustawowego zagrożenia przewidzianą za ten czyn. Wówczas orzeczoną karę grzywny 
lub ograniczenia wolności zamienia się na karę w wysokości górnej granicy 
ustawowego zagrożenia przewidzianej za dany czyn. Jeżeli za dany czyn nie jest 
przewidziana kara ograniczenia wolności, orzeczoną karę ograniczenia wolności 
zamienia się na karę grzywny, przy czym miesiąc ograniczenia wolności przyjmuje 
się za równoważny grzywnie od 100 do 2500 złotych nieprzekraczającej górnej 
granicy ustawowego zagrożenia za ten czyn. 
§ 3. Jeżeli według nowej ustawy czyn objęty prawomocnym wyrokiem 
skazującym za przestępstwo stanowi wykroczenie, orzeczone środki karne, środki 
kompensacyjne, 
środki 
związane 
z poddaniem 
sprawcy 
próbie, 
środki 
zabezpieczające, o których mowa w art. 93a Kodeksu karnego, oraz przepadek 
podlegają wykonaniu na podstawie przepisów dotychczasowych. 
§ 4. Jeżeli według nowej ustawy czyn objęty prawomocnym wyrokiem 
skazującym na karę pozbawienia wolności za przestępstwo stanowi wykroczenie 
i kara ta była podstawą orzeczenia kary łącznej, kara łączna traci moc. Jeżeli według 
nowej ustawy czyn objęty prawomocnym wyrokiem skazującym na karę ograniczenia 
wolności albo grzywny stanowi wykroczenie i kary te były podstawą orzeczenia kary 
łącznej, kara łączna traci moc tylko w razie wydania postanowienia w wypadku, 
o którym mowa w § 2. W razie potrzeby sąd wydaje wyrok łączny. 
§ 5. Przepisów § 1–4 nie stosuje się, jeżeli ich zastosowanie powoduje skutki 
prawne mniej korzystne dla sprawcy niż stosowanie ustawy obowiązującej 
poprzednio.

***
### Art. 3. {#kw-art-3}

§ 1. Na zasadach określonych w niniejszej ustawie odpowiada ten, kto 
popełnił wykroczenie na terytorium Rzeczypospolitej Polskiej, jak również na polskim 
statku wodnym lub powietrznym. 

 
 
 
s. 3/56 
 
 
 
2025-06-13 
 
§ 2. Odpowiedzialność za wykroczenie popełnione za granicą zachodzi tylko 
wtedy, gdy przepis szczególny taką odpowiedzialność przewiduje.

***
### Art. 4. {#kw-art-4}

§ 1. Wykroczenie uważa się za popełnione w czasie, w którym sprawca 
działał lub zaniechał działania, do którego był obowiązany. 
§ 2. Wykroczenie uważa się za popełnione na miejscu, gdzie sprawca działał lub 
zaniechał działania, do którego był obowiązany, albo gdzie skutek nastąpił lub miał 
nastąpić.

***
### Art. 5. {#kw-art-5}

Wykroczenie można popełnić zarówno umyślnie, jak i nieumyślnie, 
chyba że ustawa przewiduje odpowiedzialność tylko za wykroczenie umyślne.

***
### Art. 6. {#kw-art-6}

§ 1. Wykroczenie umyślne zachodzi wtedy, gdy sprawca ma zamiar 
popełnienia czynu zabronionego, to jest chce go popełnić albo przewidując możliwość 
jego popełnienia na to się godzi. 
§ 2. Wykroczenie nieumyślne zachodzi, jeżeli sprawca nie mając zamiaru jego 
popełnienia, popełnia je jednak na skutek niezachowania ostrożności wymaganej 
w danych okolicznościach, mimo że możliwość popełnienia tego czynu przewidywał 
albo mógł przewidzieć.

***
### Art. 7. {#kw-art-7}

§ 1. Nieświadomość tego, że czyn jest zagrożony karą, nie wyłącza 
odpowiedzialności, chyba że nieświadomość była usprawiedliwiona. 
§ 2. Nie popełnia wykroczenia umyślnego, kto pozostaje w błędzie co do 
okoliczności stanowiącej znamię czynu zabronionego.

***
### Art. 8. {#kw-art-8}

Na zasadach określonych w niniejszej ustawie odpowiada ten, kto 
popełnia czyn zabroniony po ukończeniu lat 17.

***
### Art. 9. {#kw-art-9}

§ 1. Jeżeli czyn wyczerpuje znamiona wykroczeń określonych w dwóch 
lub więcej przepisach ustawy, stosuje się przepis przewidujący najsurowszą karę, co 
nie stoi na przeszkodzie orzeczeniu środków karnych na podstawie innych 
naruszonych przepisów. 
§ 2. Jeżeli jednocześnie orzeka się o ukaraniu za dwa lub więcej wykroczeń, 
wymierza się łącznie karę w granicach zagrożenia określonych w przepisie 
przewidującym najsurowszą karę, co nie stoi na przeszkodzie orzeczeniu środków 
karnych na podstawie innych naruszonych przepisów. 

 
 
 
s. 4/56 
 
 
 
2025-06-13

***
### Art. 10. {#kw-art-10}

§ 1. Jeżeli czyn będący wykroczeniem wyczerpuje zarazem znamiona 
przestępstwa, orzeka się za przestępstwo i za wykroczenie, z tym że jeżeli orzeczono 
za przestępstwo i za wykroczenie karę lub środek karny tego samego rodzaju, 
wykonuje się surowszą karę lub środek karny. W razie uprzedniego wykonania 
łagodniejszej kary lub środka karnego zalicza się je na poczet surowszych. 
§ 2. Przy zaliczaniu kar przyjmuje się jeden dzień aresztu za równoważny 
jednemu dniowi pozbawienia wolności, dwóm dniom ograniczenia wolności oraz 
grzywnie w kwocie od 20 do 150 złotych. 
§ 3. Karę aresztu orzeczoną za wykroczenie uważa się za karę tego samego 
rodzaju co kara pozbawienia wolności orzeczona za przestępstwo. 
§ 4. Zaliczeniu, o którym mowa w § 1, nie podlegają środki karne w postaci: 
1) 
nawiązki, jeżeli za wykroczenie i za przestępstwo orzeczono je na rzecz różnych 
podmiotów; 
2) 
obowiązku naprawienia szkody, jeżeli za wykroczenie i za przestępstwo 
orzeczono je w związku z różnym rodzajem szkód.

***
### Art. 10a. {#kw-art-10a}

§ 1. Jeżeli czyn będący wykroczeniem, za które wymierzono karę lub 
środek karny, stanowi, wspólnie z innym czynem lub czynami, ze względu na łączną 
wartość mienia przestępstwo, za które wymierzono karę lub środek karny tego samego 
rodzaju, wykonuje się surowszą karę lub środek karny. Przepisy art. 10 § 1 zdanie 
drugie oraz § 2–4 stosuje się odpowiednio. 
§ 2. W wypadku dwóch lub więcej czynów będących wykroczeniami, o których 
mowa w § 1, za karę lub środek karny wymierzony za wykroczenie w rozumieniu § 1 
uznaje się sumę kar lub środków karnych wymierzonych za te wykroczenia.

***
### Art. 11. {#kw-art-11}

§ 1. Odpowiada za usiłowanie, kto w zamiarze popełnienia czynu 
zabronionego swoim zachowaniem bezpośrednio zmierza do jego dokonania, które 
jednak nie następuje. 
§ 2. Odpowiedzialność za usiłowanie zachodzi, gdy ustawa tak stanowi. 
§ 3. Karę za usiłowanie wymierza się w granicach zagrożenia przewidzianego 
dla danego wykroczenia. 
§ 4. Nie podlega karze za usiłowanie, kto dobrowolnie odstąpił od czynu lub 
zapobiegł skutkowi stanowiącemu znamię czynu zabronionego. 

 
 
 
s. 5/56 
 
 
 
2025-06-13

***
### Art. 12. {#kw-art-12}

Odpowiada za podżeganie, kto chcąc, aby inna osoba dokonała czynu 
zabronionego, nakłania ją do tego.

***
### Art. 13. {#kw-art-13}

Odpowiada za pomocnictwo, kto w zamiarze, aby inna osoba dokonała 
czynu zabronionego, swoim zachowaniem ułatwia jego popełnienie, w szczególności 
dostarczając narzędzie, środek przewozu, udzielając rady lub informacji; odpowiada 
za pomocnictwo także ten, kto wbrew prawnemu, szczególnemu obowiązkowi 
niedopuszczenia do popełnienia czynu zabronionego swoim zaniechaniem ułatwia 
innej osobie jego popełnienie.

***
### Art. 14. {#kw-art-14}

§ 1. Odpowiedzialność za podżeganie i pomocnictwo zachodzi wtedy, 
gdy ustawa tak stanowi i tylko w razie dokonania przez sprawcę czynu zabronionego. 
§ 2. Każdy ze współdziałających w popełnieniu czynu zabronionego odpowiada 
w granicach swojej umyślności lub nieumyślności, niezależnie od odpowiedzialności 
pozostałych współdziałających. 
§ 3. Karę za podżeganie lub za pomocnictwo wymierza się w granicach 
zagrożenia przewidzianego dla danego wykroczenia.

***
### Art. 15. {#kw-art-15}

Nie popełnia wykroczenia, kto w obronie koniecznej odpiera 
bezpośredni bezprawny zamach na jakiekolwiek dobro chronione prawem.

***
### Art. 16. {#kw-art-16}

§ 1. Nie popełnia wykroczenia, kto działa w celu uchylenia 
bezpośredniego niebezpieczeństwa grożącego dobru chronionemu prawem, jeżeli 
niebezpieczeństwa nie można inaczej uniknąć, a dobro poświęcone nie przedstawia 
wartości oczywiście większej niż dobro ratowane. 
§ 2. Przepisu § 1 nie stosuje się, gdy sprawca poświęca dobro, które ma 
szczególny obowiązek chronić nawet z narażeniem się na niebezpieczeństwa osobiste.

***
### Art. 17. {#kw-art-17}

§ 1. Nie popełnia wykroczenia, kto, z powodu choroby psychicznej, 
upośledzenia umysłowego lub innego zakłócenia czynności psychicznych, nie mógł 
w czasie czynu rozpoznać jego znaczenia lub pokierować swoim postępowaniem. 
§ 2. Jeżeli w czasie popełnienia wykroczenia zdolność rozpoznawania znaczenia 
czynu lub kierowania postępowaniem była w znacznym stopniu ograniczona, można 
odstąpić od wymierzenia kary lub środka karnego. 
§ 3. Przepisów § 1 i 2 nie stosuje się, gdy sprawca wykroczenia wprawił się 
w stan nietrzeźwości lub odurzenia powodujący wyłączenie lub ograniczenie 
poczytalności, które przewidywał albo mógł przewidzieć. 

 
 
 
s. 6/56 
 
 
 
2025-06-13 
 

## Rozdział II: Kary, środki karne i zasady ich wymiaru

***
### Art. 18. {#kw-art-18}

Karami są: 
1) 
areszt; 
2) 
ograniczenie wolności; 
3) 
grzywna; 
4) 
nagana.

***
### Art. 19. {#kw-art-19}

Kara aresztu trwa najkrócej 5, najdłużej 30 dni; wymierza się ją 
w dniach.

***
### Art. 20. {#kw-art-20}

§ 1. Kara ograniczenia wolności trwa 1 miesiąc. 
§ 2. W czasie odbywania kary ograniczenia wolności ukarany: 
1) 
nie może bez zgody sądu zmieniać miejsca stałego pobytu; 
2) 
jest obowiązany do wykonywania nieodpłatnej kontrolowanej pracy na cele 
społeczne; 
3) 
ma obowiązek udzielania wyjaśnień dotyczących przebiegu odbywania kary.

***
### Art. 21. {#kw-art-21}

§ 1. Obowiązek określony w art. 20 § 2 pkt 2 polega na wykonywaniu 
nieodpłatnej kontrolowanej pracy na cele społeczne w odpowiednim zakładzie pracy, 
placówce służby zdrowia, opieki społecznej, organizacji lub instytucji niosącej pomoc 
charytatywną lub na rzecz społeczności lokalnej w wymiarze od 20 do 40 godzin. 
§ 2. W stosunku do osoby zatrudnionej organ orzekający, zamiast obowiązku 
określonego w § 1, może orzec potrącenie od 10 do 25 % wynagrodzenia za pracę na 
rzecz Skarbu Państwa albo na cel społeczny wskazany przez organ orzekający; 
w okresie odbywania kary ukarany nie może rozwiązać bez zgody sądu stosunku 
pracy. 
§ 3. (uchylony)

***
### Art. 22. {#kw-art-22}

Wymierzając karę ograniczenia wolności, organ orzekający może 
zobowiązać ukaranego do: 
1) 
naprawienia w całości albo w części szkody wyrządzonej wykroczeniem; 
2) 
przeproszenia pokrzywdzonego.

***
### Art. 23. {#kw-art-23}

§ 1. Jeżeli ukarany uchyla się od odbywania kary ograniczenia wolności 
lub wykonania nałożonych na niego obowiązków, a także w przypadku gdy ukarany 

 
 
 
s. 7/56 
 
 
 
2025-06-13 
 
wykonał część kary ograniczenia wolności, sąd zarządza wykonanie zastępczej kary 
aresztu w wymiarze odpowiadającym karze ograniczenia wolności pozostałej do 
wykonania, przyjmując, że jeden dzień zastępczej kary aresztu jest równoważny dwóm 
dniom kary ograniczenia wolności. 
§ 2. Na postanowienie w przedmiocie zarządzenia wykonania zastępczej kary 
aresztu przysługuje zażalenie.

***
### Art. 24. {#kw-art-24}

§ 1. Grzywnę wymierza się w wysokości od 20 do 5000 złotych, chyba 
że ustawa stanowi inaczej. 
§ 1a. Za wykroczenia określone w art. 86 § 1, 1a i 2, art. 86b § 1, art. 87 § 1, 
art. 92 § 1 i 2, art. 92a § 2, art. 92b, art. 93 § 1, art. 94 § 1, art. 96 § 3 lub art. 97a 
grzywnę wymierza się w wysokości do 30 000 złotych. 
§ 2. Jeżeli za wykroczenie popełnione w celu osiągnięcia korzyści majątkowej 
wymierzono karę aresztu, orzeka się obok tej kary również grzywnę, chyba że 
orzeczenie grzywny nie byłoby celowe. 
§ 3. Wymierzając grzywnę, bierze się pod uwagę dochody sprawcy, jego 
warunki osobiste i rodzinne, stosunki majątkowe i możliwości zarobkowe.

***
### Art. 25. {#kw-art-25}

§ 1. Jeżeli egzekucja grzywny okazała się bezskuteczna lub 
z okoliczności sprawy wynika, że byłaby ona bezskuteczna, sąd może zamienić 
grzywnę na pracę społecznie użyteczną, określając czas jej trwania. Praca społecznie 
użyteczna trwa najkrócej tydzień, najdłużej 2 miesiące. Przepisy art. 20 § 2 i art. 21 
§ 1 stosuje się odpowiednio. 
§ 2. Jeżeli egzekucja grzywny okazała się bezskuteczna lub z okoliczności 
sprawy wynika, że byłaby ona bezskuteczna, sąd zarządza wykonanie zastępczej kary 
aresztu, gdy: 
1) 
ukarany oświadczy, że nie wyraża zgody na podjęcie pracy społecznie użytecznej 
zamienionej na podstawie § 1 albo uchyla się od jej wykonania, lub 
2) 
zamiana grzywny na pracę społecznie użyteczną jest niemożliwa lub niecelowa. 
§ 3. Zarządzając wykonanie zastępczej kary aresztu sąd przyjmuje, że jeden 
dzień zastępczej kary aresztu jest równoważny grzywnie od 20 do 150 złotych; kara 
zastępcza nie może przekroczyć 30 dni aresztu. 
§ 4. Na postanowienie w przedmiocie kar zastępczych, o których mowa w § 1 
i 2, przysługuje zażalenie. 

 
 
 
s. 8/56 
 
 
 
2025-06-13

***
### Art. 26. {#kw-art-26}

Nie można wymierzyć kary aresztu lub zastępczej kary aresztu, jeżeli 
warunki osobiste sprawcy uniemożliwiają odbycie tej kary.

***
### Art. 27. {#kw-art-27}

§ 1. Od zastępczej kary aresztu lub wykonywania pracy, o której mowa 
w art. 25 § 1, sprawca może być uwolniony w każdym czasie przez wpłacenie kwoty 
pieniężnej przypadającej jeszcze do uiszczenia. 
§ 2. Jeżeli grzywna została uiszczona w części, karę zastępczą zmniejsza się 
w sposób odpowiadający stosunkowi kwoty zapłaconej w wysokości grzywny.

***
### Art. 28. {#kw-art-28}

§ 1. Środkami karnymi są: 
1) 
zakaz prowadzenia pojazdów; 
2) 
przepadek przedmiotów; 
3) 
nawiązka; 
4) 
obowiązek naprawienia szkody; 
5) 
podanie orzeczenia o ukaraniu do publicznej wiadomości w szczególny sposób; 
6) 
inne środki karne określone przez ustawę. 
§ 2. Środki karne można orzec, jeżeli są one przewidziane w przepisie 
szczególnym, a orzeka się je, jeżeli przepis szczególny tak stanowi. 
§ 3. Przepadek przedmiotów można orzec, choćby zachodziła okoliczność 
wyłączająca ukaranie sprawcy. 
§ 4. Obowiązek naprawienia szkody orzeka się w sposób określony w przepisie 
szczególnym.

***
### Art. 29. {#kw-art-29}

§ 1. Zakaz prowadzenia pojazdów wymierza się w miesiącach lub 
latach, na okres od 6 miesięcy do 3 lat. 
§ 2. Orzekając zakaz prowadzenia pojazdów określa się rodzaj pojazdu, którego 
zakaz dotyczy. 
§ 3. Zakaz, o którym mowa w § 1, obowiązuje od uprawomocnienia się 
orzeczenia. 
§ 4. Na poczet zakazu prowadzenia pojazdów zalicza się okres zatrzymania 
prawa jazdy lub innego dokumentu uprawniającego do prowadzenia pojazdu.

***
### Art. 30. {#kw-art-30}

§ 1. Przepadek przedmiotów obejmuje narzędzia lub inne przedmioty, 
które służyły lub były przeznaczone do popełnienia wykroczenia, a jeżeli przepis 
szczególny tak stanowi – także przedmioty pochodzące bezpośrednio lub pośrednio 
z wykroczenia. 

 
 
 
s. 9/56 
 
 
 
2025-06-13 
 
§ 2. Przepadek przedmiotów niebędących własnością sprawcy wykroczenia 
można orzec tylko wtedy, gdy przepis szczególny tak stanowi. 
§ 3. Przepadek 
przedmiotów 
następuje 
z chwilą 
uprawomocnienia 
się 
orzeczenia. 
§ 4. Przedmioty objęte przepadkiem przechodzą na własność Skarbu Państwa, 
chyba że ustawa stanowi inaczej. 
§ 5. Przepadku nie orzeka się, jeżeli byłoby to niewspółmierne do wagi 
popełnionego wykroczenia, chyba że chodzi o przedmiot pochodzący bezpośrednio 
z wykroczenia.

***
### Art. 31. {#kw-art-31}

§ 1. Podanie orzeczenia o ukaraniu do publicznej wiadomości 
w szczególny sposób orzeka się wtedy, gdy może to mieć znaczenie wychowawcze. 
§ 2. Środek karny określony w § 1 polega na ogłoszeniu orzeczenia w zakładzie 
pracy, w uczelni, w miejscu zamieszkania ukaranego, w innym właściwym miejscu 
lub w inny stosowny sposób. Ogłoszenie może nastąpić na koszt ukaranego.

***
### Art. 32. {#kw-art-32}

Nawiązkę orzeka się na rzecz pokrzywdzonego w wypadkach 
przewidzianych w przepisach szczególnych.

***
### Art. 33. {#kw-art-33}

§ 1. Organ orzekający wymierza karę według swojego uznania, 
w granicach przewidzianych przez ustawę za dane wykroczenie, oceniając stopień 
społecznej szkodliwości czynu i biorąc pod uwagę cele kary w zakresie społecznego 
oddziaływania oraz cele zapobiegawcze i wychowawcze, które ma ona osiągnąć 
w stosunku do ukaranego. 
§ 2. Wymierzając karę, organ orzekający bierze pod uwagę w szczególności 
rodzaj i rozmiar szkody wyrządzonej wykroczeniem, stopień winy, pobudki, sposób 
działania, stosunek do pokrzywdzonego, jak również właściwości, warunki osobiste 
i majątkowe sprawcy, jego stosunki rodzinne, sposób życia przed popełnieniem 
i zachowanie się po popełnieniu wykroczenia. 
§ 3. Jako okoliczności łagodzące uwzględnia się w szczególności: 
1) 
działanie sprawcy wykroczenia pod wpływem ciężkich warunków rodzinnych 
lub osobistych; 
2) 
działanie sprawcy wykroczenia pod wpływem silnego wzburzenia wywołanego 
krzywdzącym stosunkiem do niego lub do innych osób; 
3) 
działanie z pobudek zasługujących na uwzględnienie; 

 
 
 
s. 10/56 
 
 
 
2025-06-13 
 
4) 
prowadzenie przez sprawcę nienagannego życia przed popełnieniem 
wykroczenia i wyróżnianie się spełnianiem obowiązków, zwłaszcza w zakresie 
pracy; 
5) 
przyczynienie się lub staranie się sprawcy o przyczynienie się do usunięcia 
szkodliwych następstw swego czynu. 
§ 4. Jako okoliczności obciążające uwzględnia się w szczególności: 
1) 
(uchylony) 
2) 
działanie sprawcy w celu osiągnięcia bezprawnej korzyści majątkowej; 
3) 
działanie w sposób zasługujący na szczególne potępienie; 
4) 
(uchylony) 
5) 
uprzednie ukaranie sprawcy za podobne przestępstwo lub wykroczenie; 
6) 
chuligański charakter wykroczenia; 
7) 
działanie pod wpływem alkoholu, środka odurzającego lub innej podobnie 
działającej substancji lub środka; 
8) 
popełnienie wykroczenia na szkodę osoby bezradnej lub osoby, której sprawca 
powinien okazać szczególne względy; 
9) 
popełnienie wykroczenia we współdziałaniu z małoletnim. 
§ 5. Przepisy § 1–4 stosuje się odpowiednio do środków karnych.

***
### Art. 34. {#kw-art-34}

Okoliczności wpływające na wymiar kary i środka karnego uwzględnia 
się tylko co do osoby, której dotyczą.

***
### Art. 35. {#kw-art-35}

Jeżeli ustawa daje możność wyboru między aresztem a inną karą, areszt 
można orzec tylko wtedy, gdy czyn popełniono umyślnie, a zarazem za orzeczeniem 
kary aresztu przemawia waga czynu lub okoliczności sprawy świadczą 
o demoralizacji sprawcy albo sposób jego działania zasługuje na szczególne 
potępienie.

***
### Art. 36. {#kw-art-36}

§ 1. Naganę można orzec wtedy, gdy ze względu na charakter 
i okoliczności czynu lub właściwości i warunki osobiste sprawcy należy przypuszczać, 
że zastosowanie tej kary jest wystarczające do wdrożenia go do poszanowania prawa 
i zasad współżycia społecznego. 
§ 2. Nie można orzec nagany za wykroczenie o charakterze chuligańskim.

***
### Art. 37. {#kw-art-37}

Jeżeli wykroczeniem o charakterze chuligańskim została wyrządzona 
szkoda, można orzec nawiązkę do wysokości 1000 złotych na rzecz pokrzywdzonego 

 
 
 
s. 11/56 
 
 
 
2025-06-13 
 
albo na rzecz Polskiego Czerwonego Krzyża lub na inny cel społeczny wskazany przez 
organ orzekający.

***
### Art. 37a. {#kw-art-37a}

(uchylony)

***
### Art. 38. {#kw-art-38}

§ 1. Ukaranemu co najmniej dwukrotnie za podobne wykroczenia 
umyślne, który w ciągu dwóch lat od ostatniego ukarania popełnia ponownie podobne 
wykroczenie umyślne, można wymierzyć karę aresztu, choćby było zagrożone karą 
łagodniejszą. 
§ 2. Kierującemu pojazdem mechanicznym ukaranemu za wykroczenie 
określone w art. 86 § 1a i 2, art. 86b § 1, art. 87 § 1 art. 92 § 2, art. 92a § 2, art. 92b, 
art. 94 § 1 albo art. 97a, który w ciągu dwóch lat od ostatniego prawomocnego 
ukarania popełnia to samo wykroczenie wymierza się karę grzywny w wysokości nie 
niższej niż dwukrotność dolnej granicy ustawowego zagrożenia.

***
### Art. 39. {#kw-art-39}

§ 1. W wypadkach zasługujących na szczególne uwzględnienie można 
– biorąc pod uwagę charakter i okoliczności czynu lub właściwości i warunki osobiste 
sprawcy – zastosować nadzwyczajne złagodzenie kary albo odstąpić od wymierzenia 
kary lub środka karnego. 
§ 2. Nadzwyczajne złagodzenie polega na wymierzeniu kary poniżej dolnej 
granicy ustawowego zagrożenia albo kary łagodniejszego rodzaju. 
§ 3. (uchylony) 
§ 4. W razie odstąpienia od wymierzenia kary można zastosować do sprawcy 
środek oddziaływania społecznego, mający na celu przywrócenie naruszonego 
porządku prawnego lub naprawienie wyrządzonej krzywdy, polegający zwłaszcza na 
przeproszeniu pokrzywdzonego, uroczystym zapewnieniu niepopełniania więcej 
takiego czynu albo zobowiązania sprawcy do przywrócenia stanu poprzedniego. 

## Rozdział III: Zastosowanie środków oddziaływania wychowawczego

***
### Art. 40. {#kw-art-40}

(uchylony)

***
### Art. 41. {#kw-art-41}

W stosunku do sprawcy czynu można poprzestać na zastosowaniu 
pouczenia, zwróceniu uwagi, ostrzeżeniu lub na zastosowaniu innych środków 
oddziaływania wychowawczego. 

 
 
 
s. 12/56 
 
 
 
2025-06-13 
 

## Rozdział IV: Warunkowe zawieszenie wykonania kary aresztu

***
### Art. 42. {#kw-art-42}

§ 1. Wykonanie kary aresztu można warunkowo zawiesić, jeżeli ze 
względu na okoliczności popełnienia wykroczenia, właściwości i warunki osobiste 
sprawcy oraz jego zachowanie się po popełnieniu wykroczenia należy przypuszczać, 
że pomimo niewykonania kary nie popełni on nowego podobnego przestępstwa lub 
wykroczenia. 
§ 2. Warunkowe zawieszenie wykonania kary następuje na okres próby, który 
nie może być krótszy niż 6 miesięcy i nie może przekroczyć roku. Okres próby biegnie 
od uprawomocnienia się orzeczenia. 
§ 3. Jeżeli wykroczeniem została wyrządzona szkoda w mieniu, warunkowe 
zawieszenie wykonania kary może być orzeczone tylko wtedy, gdy szkoda została 
w całości naprawiona.

***
### Art. 43. {#kw-art-43}

Warunkowego zawieszenia wykonania kary nie stosuje się do sprawcy, 
który: 
1) 
w ciągu 2 lat przed popełnieniem wykroczenia był już karany za podobne 
przestępstwo lub wykroczenie albo 
2) 
popełnił wykroczenie o charakterze chuligańskim 
– chyba że ze względu na wyjątkowe okoliczności organ orzekający uzna zawieszenie 
wykonania kary za celowe.

***
### Art. 44. {#kw-art-44}

§ 1. Sąd, który orzekł karę aresztu zarządza wykonanie kary, jeżeli 
ukarany w okresie próby popełnił podobne do poprzedniego przestępstwo lub 
wykroczenie. 
§ 2. Sąd, który orzekł karę aresztu może zarządzić wykonanie kary, jeżeli 
ukarany w okresie próby popełnił inne przestępstwo lub wykroczenie niż wymienione 
w § 1. 
§ 3. Jeżeli w okresie próby i w ciągu dalszych 2 miesięcy nie zarządzono 
wykonania kary, ukaranie uważa się za niebyłe. 
§ 4. Na postanowienie w przedmiocie zarządzenia wykonania kary aresztu 
przysługuje zażalenie. 

 
 
 
s. 13/56 
 
 
 
2025-06-13 
 

## Rozdział V: Przedawnienie orzekania, wykonania kary oraz zatarcie ukarania

***
### Art. 45. {#kw-art-45}

§ 1. Karalność wykroczenia ustaje, jeżeli od czasu jego popełnienia 
upłynął rok; jeżeli w tym okresie wszczęto postępowanie, karalność wykroczenia 
ustaje z upływem 2 lat od zakończenia tego okresu. 
§ 2. W razie uchylenia prawomocnego rozstrzygnięcia, przedawnienie biegnie 
od daty uchylenia rozstrzygnięcia. 
§ 2a. W wypadku wszczęcia postępowania mediacyjnego czasu jego trwania nie 
wlicza się do okresu przedawnienia. 
§ 3. Orzeczona kara lub środek karny nie podlega wykonaniu, jeżeli od daty 
uprawomocnienia się rozstrzygnięcia upłynęły 3 lata.

***
### Art. 46. {#kw-art-46}

§ 1. Ukaranie uważa się za niebyłe po upływie 2 lat od wykonania, 
darowania lub przedawnienia wykonania kary. 
§ 2. Jeżeli ukarany przed upływem okresu przewidzianego w § 1 popełnił nowe 
wykroczenie, za które wymierzono mu karę aresztu, ograniczenia wolności lub 
grzywny, ukaranie za oba wykroczenia uważa się za niebyłe po upływie 2 lat od 
wykonania, darowania albo od przedawnienia wykonania kary za nowe wykroczenie. 
§ 3. Jeżeli orzeczono środek karny, uznanie ukarania za niebyłe nie może 
nastąpić przed jego wykonaniem, darowaniem albo przedawnieniem wykonania. 

## Rozdział VI: Wyjaśnienie wyrażeń ustawowych

***
### Art. 47. {#kw-art-47}

§ 1. Czynem zabronionym jest zachowanie o znamionach określonych 
w ustawie karnej. 
§ 2. Przestępstwami i wykroczeniami podobnymi są przestępstwa i wykroczenia 
należące do tego samego rodzaju; przestępstwa i wykroczenia z zastosowaniem 
przemocy lub groźby jej użycia albo przestępstwa i wykroczenia popełnione w celu 
osiągnięcia korzyści majątkowej uważa się za przestępstwa i wykroczenia podobne. 
§ 3. Osobą najbliższą jest małżonek, wstępny, zstępny, rodzeństwo, powinowaty 
w tej samej linii lub stopniu, osoba pozostająca w stosunku przysposobienia oraz jej 
małżonek, a także osoba pozostająca we wspólnym pożyciu. 

 
 
 
s. 14/56 
 
 
 
2025-06-13 
 
§ 4. Instytucją 
państwową, 
samorządową 
lub 
społeczną 
jest 
również 
przedsiębiorstwo, w którym Skarb Państwa lub jednostka samorządu terytorialnego 
jest udziałowcem, spółdzielnia, związek zawodowy, inna organizacja społeczna lub 
jednostka wojskowa. 
§ 5. Charakter chuligański mają wykroczenia polegające na umyślnym godzeniu 
w porządek lub spokój publiczny albo umyślnym niszczeniu lub uszkadzaniu mienia, 
jeżeli sprawca działał publicznie oraz w rozumieniu powszechnym bez powodu lub 
z oczywiście błahego powodu, okazując przez to rażące lekceważenie podstawowych 
zasad porządku prawnego. 
§ 6. Przy ocenie stopnia społecznej szkodliwości czynu bierze się pod uwagę 
rodzaj i charakter naruszonego dobra, rozmiary wyrządzonej lub grożącej szkody, 
sposób i okoliczności popełnienia czynu, wagę naruszonych przez sprawcę 
obowiązków, jak również postać zamiaru, motywację sprawcy, rodzaj naruszonych 
reguł ostrożności i stopień ich naruszenia. 
§ 7. Rzeczą ruchomą lub przedmiotem jest także polski albo obcy pieniądz lub 
inny środek płatniczy oraz dokument uprawniający do otrzymania sumy pieniężnej 
albo zawierający obowiązek wypłaty kapitału, odsetek, udziału w zyskach albo 
stwierdzenie uczestnictwa w spółce. 
§ 8. Dokumentem jest każdy przedmiot lub inny zapisany nośnik informacji, 
z którym jest związane określone prawo, albo który ze względu na zawartą w nim treść 
stanowi 
dowód 
prawa, 
stosunku 
prawnego 
lub 
okoliczności 
mającej 
znaczenie prawne. 
§ 9. (uchylony) 

## Rozdział VII: Stosunek do ustaw szczególnych

***
### Art. 48. {#kw-art-48}

Przepisy części ogólnej Kodeksu wykroczeń stosuje się do wykroczeń 
przewidzianych w innych ustawach, jeżeli ustawy te nie zawierają przepisów 
odmiennych. 

 
 
 
s. 15/56 
 
 
 
2025-06-13

