---
id: code.kp.dzial.trzynasty
title: "Kodeks pracy — Dział TRZYNASTY (Odpowiedzialność za wykroczenia przeciwko prawom pracownika)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1974 nr 24 poz. 141"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KP — Dział TRZYNASTY"]
tags: ["KP","Kodeks pracy","Dział TRZYNASTY","PL"]
source_pdf: "D19740141Lj.pdf"
articles: "Art. 281–283"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kp-trzynasty-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks pracy — Dział TRZYNASTY: Odpowiedzialność za wykroczenia przeciwko prawom pracownika

Odpowiedzialność za wykroczenia przeciwko prawom pracownika 
(oznaczenie oraz tytuł rozdziału I – uchylone)
***
## Art. 281. {#kp-trzynasty-art-281}

**§ 1.** Kto, będąc pracodawcą lub działając w jego imieniu: 
- 1) zawiera umowę cywilnoprawną w warunkach, w których zgodnie z art. 22 
§ 1 powinna być zawarta umowa o pracę, 
1a) nie zawiadamia właściwego okręgowego inspektora pracy, w formie pisemnej 
lub elektronicznej, o zawarciu umowy o pracę, o której mowa w art. 251 § 4 
pkt 4, wraz ze wskazaniem przyczyn zawarcia takiej umowy, w terminie 5 dni 
roboczych od dnia jej zawarcia, 
- 2) nie potwierdza na piśmie zawartej z pracownikiem umowy o pracę przed 
dopuszczeniem go do pracy, 
2a) nie informuje pracownika w terminie o warunkach jego zatrudnienia, 
naruszając w sposób rażący przepisy art. 29 § 3, 32 i 33 oraz art. 291 § 2 i 4, 
2b) nie udziela pracownikowi w terminie w postaci papierowej lub elektronicznej 
odpowiedzi na wniosek lub nie informuje o przyczynie odmowy 
uwzględnienia wniosku, o których mowa w art. 293 § 3, 
- 3) wypowiada 
lub 
rozwiązuje 
z pracownikiem 
stosunek 
pracy 
bez 
wypowiedzenia, naruszając w sposób rażący przepisy prawa pracy, 
- 4) stosuje wobec pracowników inne kary niż przewidziane w przepisach prawa 
pracy o odpowiedzialności porządkowej pracowników, 
- 5) narusza przepisy o czasie pracy lub przepisy o uprawnieniach pracowników 
związanych z rodzicielstwem i zatrudnianiu młodocianych, 
5a) narusza przepisy o elastycznej organizacji pracy, o której mowa w art. 1881, 
5b) narusza przepisy o urlopie opiekuńczym, o którym mowa w art. 1731–1733, 
5c) narusza przepisy dotyczące uwzględnienia wniosków, o których mowa 
w art. 1421 i art. 6719 § 6 i 7, 
- 16) Na podstawie art. 4 pkt 5 ustawy z dnia 18 kwietnia 1985 r. o rozpoznawaniu przez sądy spraw 
z zakresu prawa pracy i ubezpieczeń społecznych (Dz. U. poz. 85), która weszła w życie z dniem 
1 lipca 1985 r., dział dwunasty nie obejmuje art. 266–280. 

 
 
 
s. 187/195 
 
2025-08-06 
 
5d) narusza przepisy dotyczące pokrywania przez pracodawcę kosztów szkoleń, 
o którym mowa w art. 9413, 
- 6) nie prowadzi dokumentacji pracowniczej, 
6a) nie przechowuje dokumentacji pracowniczej przez okres, o którym mowa w 
art. 94 pkt 9b, art. 945 § 2 i art. 946 pkt 2, albo przez dłuższy okres, jeżeli 
wynika on z odrębnych przepisów, 
- 7) pozostawia 
dokumentację 
pracowniczą 
w 
warunkach 
grożących 
uszkodzeniem lub zniszczeniem 
– podlega karze grzywny od 1000 zł do 30 000 zł. 
**§ 2.** Jeżeli pracownik, o którym mowa w § 1 pkt 2, jest osobą, o której mowa 
w art. 2 ust. 1 pkt 4 ustawy z dnia 6 grudnia 2018 r. o Krajowym Rejestrze 
Zadłużonych (Dz. U. z 2021 r. poz. 1909), pracodawca lub osoba działająca w jego 
imieniu podlega karze grzywny od 1500 zł do 45 000 zł.

***
## Art. 282. {#kp-trzynasty-art-282}

**§ 1.** Kto, wbrew obowiązkowi: 
- 1) nie wypłaca w ustalonym terminie wynagrodzenia za pracę lub innego 
świadczenia przysługującego pracownikowi albo uprawnionemu do tego 
świadczenia członkowi rodziny pracownika, wysokość tego wynagrodzenia 
lub świadczenia bezpodstawnie obniża albo dokonuje bezpodstawnych 
potrąceń, 
- 2) nie udziela przysługującego pracownikowi urlopu wypoczynkowego lub 
bezpodstawnie obniża wymiar tego urlopu, 
- 3) nie wydaje pracownikowi w terminie świadectwa pracy, 
podlega karze grzywny od 1000 zł do 30 000 zł. 
**§ 2.** Tej samej karze podlega, kto wbrew obowiązkowi nie wykonuje 
podlegającego wykonaniu orzeczenia sądu pracy lub ugody zawartej przed komisją 
pojednawczą lub sądem pracy. 
**§ 3.** Kto wbrew obowiązkowi wypłaca wynagrodzenie wyższe niż wynikające 
z zawartej umowy o pracę, bez dokonania potrąceń na zaspokojenie świadczeń 
alimentacyjnych, pracownikowi będącemu osobą, o której mowa w art. 2 ust. 1 
pkt 4 ustawy z dnia 6 grudnia 2018 r. o Krajowym Rejestrze Zadłużonych, podlega 
karze grzywny od 1500 zł do 45 000 zł. 

 
 
 
s. 188/195 
 
2025-08-06

***
## Art. 283. {#kp-trzynasty-art-283}

**§ 1.** Kto, będąc odpowiedzialnym za stan bezpieczeństwa i higieny 
pracy albo kierując pracownikami lub innymi osobami fizycznymi, nie przestrzega 
przepisów lub zasad bezpieczeństwa i higieny pracy, podlega karze grzywny od 
1000 zł do 30 000 zł. 
**§ 2.** Tej samej karze podlega, kto: 
- 1) (uchylony) 
- 2) wbrew obowiązkowi nie zapewnia, aby budowa lub przebudowa obiektu 
budowlanego albo jego części, w których przewiduje się pomieszczenia 
pracy, była wykonywana na podstawie projektów uwzględniających 
wymagania bezpieczeństwa i higieny pracy; 
- 3) wbrew obowiązkowi wyposaża stanowiska pracy w maszyny i inne 
urządzenia techniczne, które nie spełniają wymagań dotyczących oceny 
zgodności; 
- 4) wbrew obowiązkowi dostarcza pracownikowi środki ochrony indywidualnej, 
które nie spełniają wymagań dotyczących oceny zgodności; 
- 5) wbrew obowiązkowi stosuje: 
  - a) materiały i procesy technologiczne bez uprzedniego ustalenia stopnia ich 
szkodliwości dla zdrowia pracowników i bez podjęcia odpowiednich 
środków profilaktycznych, 
  - b) substancje chemiczne i ich mieszaniny nieoznakowane w sposób 
widoczny i umożliwiający ich identyfikację, 
  - c) substancje 
niebezpieczne, 
mieszaniny 
niebezpieczne, 
substancje 
stwarzające zagrożenie lub mieszaniny stwarzające zagrożenie 
nieposiadające 
kart 
charakterystyki, 
a także 
opakowań 
zabezpieczających przed ich szkodliwym działaniem, pożarem lub 
wybuchem; 
- 6) wbrew obowiązkowi nie zawiadamia właściwego okręgowego inspektora 
pracy, prokuratora lub innego właściwego organu o śmiertelnym, ciężkim lub 
zbiorowym wypadku przy pracy oraz o każdym innym wypadku, który 
wywołał wymienione skutki, mającym związek z pracą, jeżeli może być 
uznany za wypadek przy pracy, nie zgłasza choroby zawodowej albo 
podejrzenia o taką chorobę, nie ujawnia wypadku przy pracy lub choroby 

 
 
 
s. 189/195 
 
2025-08-06 
 
zawodowej, albo przedstawia niezgodne z prawdą informacje, dowody lub 
dokumenty dotyczące takich wypadków i chorób; 
- 7) nie wykonuje w wyznaczonym terminie podlegającego wykonaniu nakazu 
organu Państwowej Inspekcji Pracy; 
- 8) utrudnia działalność organu Państwowej Inspekcji Pracy, w szczególności 
uniemożliwia prowadzenie wizytacji zakładu pracy lub nie udziela informacji 
niezbędnych do wykonywania jej zadań; 
- 9) bez zezwolenia właściwego inspektora pracy dopuszcza do wykonywania 
pracy lub innych zajęć zarobkowych przez dziecko do ukończenia przez nie 
16 roku życia. 
## Rozdział II (zawierający art. 284–2901 – uchylony)

