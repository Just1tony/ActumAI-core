---
id: code.kp.dzial.pierwszy
title: "Kodeks pracy — Dział PIERWSZY (Przepisy ogólne)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1974 nr 24 poz. 141"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KP — Dział PIERWSZY"]
tags: ["KP","Kodeks pracy","Dział PIERWSZY","PL"]
source_pdf: "D19740141Lj.pdf"
articles: "Art. 1–185"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kp-pierwszy-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks pracy — Dział PIERWSZY: Przepisy ogólne

Przepisy ogólne 
## Rozdział I Przepisy wstępne
***
## Art. 1. {#kp-pierwszy-art-1}

Kodeks 
pracy 
określa 
prawa 
i obowiązki 
pracowników 
i pracodawców.

***
## Art. 2. {#kp-pierwszy-art-2}

Pracownikiem jest osoba zatrudniona na podstawie umowy o pracę, 
powołania, wyboru, mianowania lub spółdzielczej umowy o pracę.

***
## Art. 3. {#kp-pierwszy-art-3}

Pracodawcą jest jednostka organizacyjna, choćby nie posiadała 
osobowości prawnej, a także osoba fizyczna, jeżeli zatrudniają one pracowników. 
- 26) dyrektywy 2000/43/WE z dnia 29 czerwca 2000 r. wprowadzającej w życie zasadę równego 
traktowania osób bez względu na pochodzenie rasowe lub etniczne (Dz. Urz. WE L 180 
z 19.07.2000),  
- 27) dyrektywy 2000/54/WE z dnia 18 września 2000 r. w sprawie ochrony pracowników przed 
ryzykiem związanym z narażeniem na działanie czynników biologicznych w miejscu pracy 
(siódma dyrektywa szczegółowa w rozumieniu art. 16 ust. 1 dyrektywy 89/391/EWG) 
(Dz. Urz. WE L 262 z 17.10.2000), 
- 28) dyrektywy 2000/78/WE z dnia 27 listopada 2000 r. ustanawiającej ogólne warunki ramowe 
równego traktowania w zakresie zatrudnienia i pracy (Dz. Urz. WE L 303 z 02.12.2000), 
- 29) dyrektywy 2002/44/WE z dnia 25 czerwca 2002 r. w sprawie minimalnych wymagań 
w zakresie ochrony zdrowia i bezpieczeństwa dotyczących narażenia pracowników na 
ryzyko spowodowane czynnikami fizycznymi (wibracji) (szesnasta dyrektywa szczegółowa 
w rozumieniu art. 16 ust. 1 dyrektywy 89/391/EWG) (Dz. Urz. WE L 177 z 06.07.2002), 
- 30) dyrektywy 2003/10/WE z dnia 6 lutego 2003 r. w sprawie minimalnych wymagań w zakresie 
ochrony zdrowia i bezpieczeństwa dotyczących narażenia pracowników na ryzyko 
spowodowane czynnikami fizycznymi (hałasem) (siedemnasta dyrektywa szczegółowa 
w rozumieniu art. 16 ust. 1 dyrektywy 89/391/EWG) (Dz. Urz. WE L 42 z 15.02.2003), 
- 31) dyrektywy 2010/18/UE z dnia 8 marca 2010 r. w sprawie wdrożenia zmienionego 
porozumienia 
ramowego 
dotyczącego 
urlopu 
rodzicielskiego 
zawartego 
przez 
BUSINESSEUROPE, UEAPME, CEEP i ETUC oraz uchylającej dyrektywę 96/34/WE 
(Dz. Urz. UE L 68 z 18.03.2010, str. 13), 
- 32) dyrektywy Parlamentu Europejskiego i Rady (UE) 2019/1152 z dnia 20 czerwca 2019 r. 
w sprawie przejrzystych i przewidywalnych warunków pracy w Unii Europejskiej (Dz. Urz. 
UE L 186 z 11.07.2019, str. 105), 
- 33) dyrektywy Parlamentu Europejskiego i Rady (UE) 2019/1158 z dnia 20 czerwca 2019 r. 
w sprawie równowagi między życiem zawodowym a prywatnym rodziców i opiekunów oraz 
uchylającej dyrektywę Rady 2010/18/UE (Dz. Urz. UE L 188 z 12.07.2019, str. 79), 
- 34) dyrektywy Parlamentu Europejskiego i Rady (UE) 2022/431 z dnia 9 marca 2022 r. 
zmieniającej dyrektywę 2004/37/WE w sprawie ochrony pracowników przed zagrożeniem 
dotyczącym narażenia na działanie czynników rakotwórczych lub mutagenów podczas pracy 
(Dz. Urz. UE L 88 z 16.03.2022, str. 1 oraz Dz. Urz. UE L 2023/90090 z 14.11.2023). 
Dane dotyczące ogłoszenia aktów prawa Unii Europejskiej, zamieszczone w niniejszej 
ustawie – z dniem uzyskania przez Rzeczpospolitą Polską członkostwa w Unii Europejskiej – 
dotyczą ogłoszenia tych aktów w Dzienniku Urzędowym Unii Europejskiej – wydanie specjalne. 

 
 
 
s. 4/195 
 
2025-08-06

***
## Art. 31. {#kp-pierwszy-art-31}

**§ 1.** Za pracodawcę będącego jednostką organizacyjną czynności 
w sprawach z zakresu prawa pracy dokonuje osoba lub organ zarządzający tą 
jednostką albo inna wyznaczona do tego osoba. 
**§ 2.** Przepis § 1 stosuje się odpowiednio do pracodawcy będącego osobą 
fizyczną, jeżeli nie dokonuje on osobiście czynności, o których mowa w tym 
przepisie.

***
## Art. 4. {#kp-pierwszy-art-4}

(uchylony)

***
## Art. 5. {#kp-pierwszy-art-5}

Jeżeli stosunek pracy określonej kategorii pracowników regulują 
przepisy szczególne, przepisy kodeksu stosuje się w zakresie nieuregulowanym 
tymi przepisami.

***
## Art. 6. {#kp-pierwszy-art-6}

(uchylony)

***
## Art. 7. {#kp-pierwszy-art-7}

(uchylony)

***
## Art. 8. {#kp-pierwszy-art-8}

Nie można czynić ze swego prawa użytku, który byłby sprzeczny ze 
społeczno-gospodarczym przeznaczeniem tego prawa lub zasadami współżycia 
społecznego. Takie działanie lub zaniechanie uprawnionego nie jest uważane za 
wykonywanie prawa i nie korzysta z ochrony.

***
## Art. 9. {#kp-pierwszy-art-9}

**§ 1.** Ilekroć w Kodeksie pracy jest mowa o prawie pracy, rozumie się 
przez to przepisy Kodeksu pracy oraz przepisy innych ustaw i aktów 
wykonawczych, określające prawa i obowiązki pracowników i pracodawców, 
a także postanowienia układów zbiorowych pracy i innych opartych na ustawie 
porozumień zbiorowych, regulaminów i statutów określających prawa i obowiązki 
stron stosunku pracy. 
**§ 2.** Postanowienia układów zbiorowych pracy i porozumień zbiorowych oraz 
regulaminów i statutów nie mogą być mniej korzystne dla pracowników niż 
przepisy Kodeksu pracy oraz innych ustaw i aktów wykonawczych. 
**§ 3.** Postanowienia regulaminów i statutów nie mogą być mniej korzystne dla 
pracowników niż postanowienia układów zbiorowych pracy i porozumień 
zbiorowych. 
**§ 4.** Postanowienia układów zbiorowych pracy i innych opartych na ustawie 
porozumień zbiorowych, regulaminów oraz statutów określających prawa 

 
 
 
s. 5/195 
 
2025-08-06 
 
i obowiązki stron stosunku pracy, naruszające zasadę równego traktowania w 
zatrudnieniu, nie obowiązują.

***
## Art. 91. {#kp-pierwszy-art-91}

**§ 1.** Jeżeli jest to uzasadnione sytuacją finansową pracodawcy, może 
być zawarte porozumienie o zawieszeniu stosowania w całości lub w części 
przepisów prawa pracy, określających prawa i obowiązki stron stosunku pracy; nie 
dotyczy to przepisów Kodeksu pracy oraz przepisów innych ustaw i aktów 
wykonawczych. 
**§ 2.** Porozumienie, 
o którym 
mowa 
w § 1, 
zawiera 
pracodawca 
i reprezentująca pracowników organizacja związkowa, a jeżeli pracodawca nie jest 
objęty działaniem takiej organizacji, porozumienie zawiera pracodawca i 
przedstawicielstwo 
pracowników 
wyłonione 
w trybie 
przyjętym 
u tego 
pracodawcy. 
**§ 3.** Zawieszenie stosowania przepisów prawa pracy nie może trwać dłużej 
niż przez okres 3 lat. Przepis art. 24127 § 3 stosuje się odpowiednio. 
**§ 4.** Pracodawca 
przekazuje 
porozumienie 
właściwemu 
okręgowemu 
inspektorowi pracy. 
**§ 5.** Przepisy § 1–4 nie naruszają przepisów art. 24127. 
## Rozdział II Podstawowe zasady prawa pracy

***
## Art. 10. {#kp-pierwszy-art-10}

**§ 1.** Każdy ma prawo do swobodnie wybranej pracy. Nikomu, 
z wyjątkiem przypadków określonych w ustawie, nie można zabronić 
wykonywania zawodu. 
**§ 2.** Państwo określa minimalną wysokość wynagrodzenia za pracę. 
**§ 3.** Państwo prowadzi politykę zmierzającą do pełnego produktywnego 
zatrudnienia.

***
## Art. 11. {#kp-pierwszy-art-11}

Nawiązanie stosunku pracy oraz ustalenie warunków pracy i płacy, 
bez względu na podstawę prawną tego stosunku, wymaga zgodnego oświadczenia 
woli pracodawcy i pracownika.

***
## Art. 111. {#kp-pierwszy-art-111}

Pracodawca jest obowiązany szanować godność i inne dobra 
osobiste pracownika. 

 
 
 
s. 6/195 
 
2025-08-06

***
## Art. 112. {#kp-pierwszy-art-112}

Pracownicy mają równe prawa z tytułu jednakowego wypełniania 
takich samych obowiązków; dotyczy to w szczególności równego traktowania 
mężczyzn i kobiet w zatrudnieniu.

***
## Art. 113. {#kp-pierwszy-art-113}

Jakakolwiek dyskryminacja w zatrudnieniu, bezpośrednia lub 
pośrednia, w szczególności ze względu na płeć, wiek, niepełnosprawność, rasę, 
religię, 
narodowość, 
przekonania 
polityczne, 
przynależność 
związkową, 
pochodzenie etniczne, wyznanie, orientację seksualną, zatrudnienie na czas 
określony lub nieokreślony, zatrudnienie w pełnym lub w niepełnym wymiarze 
czasu pracy – jest niedopuszczalna.

***
## Art. 12. {#kp-pierwszy-art-12}

(uchylony)

***
## Art. 13. {#kp-pierwszy-art-13}

Pracownik ma prawo do godziwego wynagrodzenia za pracę. 
Warunki realizacji tego prawa określają przepisy prawa pracy oraz polityka 
państwa w dziedzinie płac, w szczególności poprzez ustalanie minimalnego 
wynagrodzenia za pracę.

***
## Art. 14. {#kp-pierwszy-art-14}

Pracownik ma prawo do wypoczynku, który zapewniają przepisy 
o czasie pracy, dniach wolnych od pracy oraz o urlopach wypoczynkowych.

***
## Art. 15. {#kp-pierwszy-art-15}

Pracodawca jest obowiązany zapewnić pracownikom bezpieczne 
i higieniczne warunki pracy.

***
## Art. 16. {#kp-pierwszy-art-16}

Pracodawca, stosownie do możliwości i warunków, zaspokaja 
bytowe, socjalne i kulturalne potrzeby pracowników.

***
## Art. 17. {#kp-pierwszy-art-17}

Pracodawca jest obowiązany ułatwiać pracownikom podnoszenie 
kwalifikacji zawodowych.

***
## Art. 18. {#kp-pierwszy-art-18}

**§ 1.** Postanowienia umów o pracę oraz innych aktów, na których 
podstawie powstaje stosunek pracy, nie mogą być mniej korzystne dla pracownika 
niż przepisy prawa pracy. 
**§ 2.** Postanowienia umów i aktów, o których mowa w § 1, mniej korzystne dla 
pracownika niż przepisy prawa pracy są nieważne; zamiast nich stosuje się 
odpowiednie przepisy prawa pracy. 
**§ 3.** Postanowienia umów o pracę i innych aktów, na podstawie których 
powstaje stosunek pracy, naruszające zasadę równego traktowania w zatrudnieniu 
są nieważne. Zamiast takich postanowień stosuje się odpowiednie przepisy prawa 

 
 
 
s. 7/195 
 
2025-08-06 
 
pracy, a w razie braku takich przepisów – postanowienia te należy zastąpić 
odpowiednimi postanowieniami niemającymi charakteru dyskryminacyjnego.

***
## Art. 181. {#kp-pierwszy-art-181}

**§ 1.** Pracownicy i pracodawcy, w celu reprezentacji i obrony swoich 
praw i interesów, mają prawo tworzyć organizacje i przystępować do tych 
organizacji. 
**§ 2.** Zasady tworzenia i działania organizacji, o których mowa w § 1, określa 
ustawa o związkach zawodowych, ustawa o organizacjach pracodawców oraz inne 
przepisy prawa.

***
## Art. 182. {#kp-pierwszy-art-182}

Pracownicy uczestniczą w zarządzaniu zakładem pracy w zakresie 
i na zasadach określonych w odrębnych przepisach.

***
## Art. 183. {#kp-pierwszy-art-183}

Pracodawcy oraz organy administracji są obowiązani tworzyć 
warunki umożliwiające korzystanie z uprawnień określonych w przepisach, 
o których mowa w art. 181 i 182. 
## Rozdział II a 
Równe traktowanie w zatrudnieniu 
Art. 183a. § 1. Pracownicy powinni być równo traktowani w zakresie 
nawiązania i rozwiązania stosunku pracy, warunków zatrudnienia, awansowania 
oraz dostępu do szkolenia w celu podnoszenia kwalifikacji zawodowych, w 
szczególności bez względu na płeć, wiek, niepełnosprawność, rasę, religię, 
narodowość, przekonania polityczne, przynależność związkową, pochodzenie 
etniczne, wyznanie, orientację seksualną, zatrudnienie na czas określony lub 
nieokreślony, zatrudnienie w pełnym lub w niepełnym wymiarze czasu pracy. 
**§ 2.** Równe traktowanie w zatrudnieniu oznacza niedyskryminowanie 
w jakikolwiek sposób, bezpośrednio lub pośrednio, z przyczyn określonych w § 1. 
**§ 3.** Dyskryminowanie bezpośrednie istnieje wtedy, gdy pracownik z jednej 
lub z kilku przyczyn określonych w § 1 był, jest lub mógłby być traktowany 
w porównywalnej sytuacji mniej korzystnie niż inni pracownicy. 
**§ 4.** Dyskryminowanie pośrednie istnieje wtedy, gdy na skutek pozornie 
neutralnego postanowienia, zastosowanego kryterium lub podjętego działania 
występują lub mogłyby wystąpić niekorzystne dysproporcje albo szczególnie 
niekorzystna sytuacja w zakresie nawiązania i rozwiązania stosunku pracy, 

 
 
 
s. 8/195 
 
2025-08-06 
 
warunków zatrudnienia, awansowania oraz dostępu do szkolenia w celu 
podnoszenia kwalifikacji zawodowych wobec wszystkich lub znacznej liczby 
pracowników należących do grupy wyróżnionej ze względu na jedną lub kilka 
przyczyn określonych w § 1, chyba że postanowienie, kryterium lub działanie jest 
obiektywnie uzasadnione ze względu na zgodny z prawem cel, który ma być 
osiągnięty, a środki służące osiągnięciu tego celu są właściwe i konieczne. 
**§ 5.** Przejawem dyskryminowania w rozumieniu § 2 jest także: 
- 1) działanie polegające na zachęcaniu innej osoby do naruszenia zasady równego 
traktowania w zatrudnieniu lub nakazaniu jej naruszenia tej zasady; 
- 2) niepożądane zachowanie, którego celem lub skutkiem jest naruszenie 
godności pracownika i stworzenie wobec niego zastraszającej, wrogiej, 
poniżającej, upokarzającej lub uwłaczającej atmosfery (molestowanie). 
**§ 6.** Dyskryminowaniem ze względu na płeć jest także każde niepożądane 
zachowanie o charakterze seksualnym lub odnoszące się do płci pracownika, 
którego celem lub skutkiem jest naruszenie godności pracownika, w szczególności 
stworzenie wobec niego zastraszającej, wrogiej, poniżającej, upokarzającej lub 
uwłaczającej atmosfery; na zachowanie to mogą się składać fizyczne, werbalne lub 
pozawerbalne elementy (molestowanie seksualne). 
**§ 7.** Podporządkowanie 
się 
przez 
pracownika 
molestowaniu 
lub 
molestowaniu 
seksualnemu, 
a także 
podjęcie 
przez 
niego 
działań 
przeciwstawiających się molestowaniu lub molestowaniu seksualnemu nie może 
powodować jakichkolwiek negatywnych konsekwencji wobec pracownika. 
Art. 183b. § 1. Za naruszenie zasady równego traktowania w zatrudnieniu, 
z zastrzeżeniem § 2–4, uważa się różnicowanie przez pracodawcę sytuacji 
pracownika z jednej lub kilku przyczyn określonych w art. 183a § 1, którego 
skutkiem jest w szczególności: 
- 1) odmowa nawiązania lub rozwiązanie stosunku pracy, 
- 2) niekorzystne ukształtowanie wynagrodzenia za pracę lub innych warunków 
zatrudnienia albo pominięcie przy awansowaniu lub przyznawaniu innych 
świadczeń związanych z pracą, 
- 3) pominięcie przy typowaniu do udziału w szkoleniach podnoszących 
kwalifikacje zawodowe 
– chyba że pracodawca udowodni, że kierował się obiektywnymi powodami. 

 
 
 
s. 9/195 
 
2025-08-06 
**§ 2.** Zasady równego traktowania w zatrudnieniu nie naruszają działania, 
proporcjonalne do osiągnięcia zgodnego z prawem celu różnicowania sytuacji 
pracownika, polegające na: 
- 1) niezatrudnianiu pracownika z jednej lub kilku przyczyn określonych 
w art. 183a § 1, jeżeli rodzaj pracy lub warunki jej wykonywania powodują, że 
przyczyna lub przyczyny wymienione w tym przepisie są rzeczywistym i 
decydującym wymaganiem zawodowym stawianym pracownikowi; 
- 2) wypowiedzeniu pracownikowi warunków zatrudnienia w zakresie wymiaru 
czasu pracy, jeżeli jest to uzasadnione przyczynami niedotyczącymi 
pracowników bez powoływania się na inną przyczynę lub inne przyczyny 
wymienione w art. 183a § 1; 
- 3) stosowaniu środków, które różnicują sytuację prawną pracownika, ze względu 
na ochronę rodzicielstwa lub niepełnosprawność; 
- 4) stosowaniu kryterium stażu pracy przy ustalaniu warunków zatrudniania 
i zwalniania pracowników, zasad wynagradzania i awansowania oraz dostępu 
do szkolenia w celu podnoszenia kwalifikacji zawodowych, co uzasadnia 
odmienne traktowanie pracowników ze względu na wiek. 
**§ 3.** Nie stanowią naruszenia zasady równego traktowania w zatrudnieniu 
działania podejmowane przez określony czas, zmierzające do wyrównywania szans 
wszystkich lub znacznej liczby pracowników wyróżnionych z jednej lub kilku 
przyczyn określonych w art. 183a § 1, przez zmniejszenie na korzyść takich 
pracowników faktycznych nierówności, w zakresie określonym w tym przepisie. 
**§ 4.** Nie stanowi naruszenia zasady równego traktowania ograniczanie przez 
kościoły i inne związki wyznaniowe, a także organizacje, których etyka opiera się 
na religii, wyznaniu lub światopoglądzie, dostępu do zatrudnienia, ze względu na 
religię, wyznanie lub światopogląd jeżeli rodzaj lub charakter wykonywania 
działalności przez kościoły i inne związki wyznaniowe, a także organizacje 
powoduje, że religia, wyznanie lub światopogląd są rzeczywistym i decydującym 
wymaganiem zawodowym stawianym pracownikowi, proporcjonalnym do 
osiągnięcia zgodnego z prawem celu zróżnicowania sytuacji tej osoby; dotyczy to 
również wymagania od zatrudnionych działania w dobrej wierze i lojalności wobec 
etyki kościoła, innego związku wyznaniowego oraz organizacji, których etyka 
opiera się na religii, wyznaniu lub światopoglądzie. 

 
 
 
s. 10/195 
 
2025-08-06 
 
Art. 183c. § 1. Pracownicy mają prawo do jednakowego wynagrodzenia za 
jednakową pracę lub za pracę o jednakowej wartości. 
**§ 2.** Wynagrodzenie, o którym mowa w § 1, obejmuje wszystkie składniki 
wynagrodzenia, bez względu na ich nazwę i charakter, a także inne świadczenia 
związane z pracą, przyznawane pracownikom w formie pieniężnej lub w innej 
formie niż pieniężna. 
**§ 3.** Pracami o jednakowej wartości są prace, których wykonywanie wymaga 
od pracowników porównywalnych kwalifikacji zawodowych, potwierdzonych 
dokumentami 
przewidzianymi 
w odrębnych 
przepisach 
lub 
praktyką 
i 
doświadczeniem 
zawodowym, 
a także 
porównywalnej 
odpowiedzialności 
i wysiłku. 
<Art. 183ca. § 1. Osoba ubiegająca się o zatrudnienie na danym 
stanowisku otrzymuje od pracodawcy informację o: 
- 1) wynagrodzeniu, o którym mowa w art. 183c § 2, jego początkowej 
wysokości lub jego przedziale – opartym na obiektywnych, neutralnych 
kryteriach, w szczególności pod względem płci, oraz 
- 2) odpowiednich postanowieniach układu zbiorowego pracy lub regulaminu 
wynagradzania – w przypadku gdy pracodawca jest objęty układem 
zbiorowym pracy lub obowiązuje u niego regulamin wynagradzania. 
**§ 2.** Informacje, o których mowa w § 1, pracodawca przekazuje 
z wyprzedzeniem umożliwiającym zapoznanie się z tymi informacjami, 
w postaci papierowej lub elektronicznej, osobie ubiegającej się o zatrudnienie, 
zapewniając świadome i przejrzyste negocjacje: 
- 1) w ogłoszeniu o naborze na stanowisko; 
- 2) przed rozmową kwalifikacyjną – jeżeli pracodawca nie ogłosił naboru na 
stanowisko albo nie przekazał tych informacji w ogłoszeniu, o którym 
mowa w pkt 1; 
- 3) przed nawiązaniem stosunku pracy – jeżeli pracodawca nie ogłosił 
naboru na stanowisko albo nie przekazał tych informacji w ogłoszeniu, 
o którym mowa w pkt 1, albo przed rozmową kwalifikacyjną. 
**§ 3.** Pracodawca zapewnia, aby ogłoszenia o naborze na stanowisko oraz 
nazwy stanowisk były neutralne pod względem płci, a proces rekrutacyjny 
przebiegał w sposób niedyskryminujący.>  
Dodany art. 183ca 
wejdzie w życie z 
dn. 24.12.2025 r. 
(Dz. U. z 2025 r. 
poz. 807). 

 
 
 
s. 11/195 
 
2025-08-06 
 
Art. 183d. Osoba, wobec której pracodawca naruszył zasadę równego 
traktowania w zatrudnieniu, ma prawo do odszkodowania w wysokości nie niższej 
niż minimalne wynagrodzenie za pracę, ustalane na podstawie odrębnych 
przepisów. 
Art. 183e. § 1. Skorzystanie przez pracownika z uprawnień przysługujących 
z tytułu naruszenia przepisów prawa pracy, w tym zasady równego traktowania 
w zatrudnieniu, nie może być podstawą jakiegokolwiek niekorzystnego 
traktowania pracownika, a także nie może powodować jakichkolwiek negatywnych 
konsekwencji dla pracownika, zwłaszcza nie może stanowić przyczyny 
uzasadniającej wypowiedzenie stosunku pracy lub jego rozwiązanie bez 
wypowiedzenia przez pracodawcę. 
**§ 2.** Przepis § 1 stosuje się odpowiednio do pracownika, który udzielił 
w jakiejkolwiek formie wsparcia pracownikowi korzystającemu z uprawnień 
przysługujących z tytułu naruszenia przepisów prawa pracy, w tym zasady 
równego traktowania w zatrudnieniu. 
**§ 3.** Pracownik, o którym mowa w § 1 i 2, którego prawa zostały naruszone 
przez pracodawcę, ma prawo do odszkodowania w wysokości nie niższej niż 
minimalne wynagrodzenie za pracę, ustalane na podstawie odrębnych przepisów. 
## Rozdział II b 
Nadzór i kontrola przestrzegania prawa pracy

***
## Art. 184. {#kp-pierwszy-art-184}

**§ 1.** Nadzór i kontrolę przestrzegania prawa pracy, w tym przepisów 
i zasad bezpieczeństwa i higieny pracy, sprawuje Państwowa Inspekcja Pracy. 
**§ 2.** Nadzór i kontrolę przestrzegania zasad, przepisów higieny pracy 
i warunków środowiska pracy sprawuje Państwowa Inspekcja Sanitarna. 
**§ 3.** Organizację i zakres działania inspekcji, o których mowa w § 1 i 2, 
określają odrębne przepisy.

***
## Art. 185. {#kp-pierwszy-art-185}

**§ 1.** Społeczną kontrolę przestrzegania prawa pracy, w tym 
przepisów i zasad bezpieczeństwa i higieny pracy, sprawuje społeczna inspekcja 
pracy. 
**§ 2.** Organizację, zadania i uprawnienia społecznej inspekcji pracy oraz 
zasady jej współdziałania z Państwową Inspekcją Pracy i innymi państwowymi 
organami nadzoru i kontroli określają odrębne przepisy. 

 
 
 
s. 12/195 
 
2025-08-06 
## Rozdział III (zawierający art. 19–21 – uchylony)

