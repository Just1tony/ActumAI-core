---
id: code.kp.dzial.czternastya
title: "Kodeks pracy — Dział CZTERNASTYA ((zawierający art. 2951 i art. 2952 – uchylony))"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1974 nr 24 poz. 141"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KP — Dział CZTERNASTYA"]
tags: ["KP","Kodeks pracy","Dział CZTERNASTYA","PL"]
source_pdf: "D19740141Lj.pdf"
articles: "Art. 296–3045"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kp-czternastya-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks pracy — Dział CZTERNASTYA: (zawierający art. 2951 i art. 2952 – uchylony)

(zawierający art. 2951 i art. 2952 – uchylony) 
DZIAŁ PIĘTNASTY 
Przepisy końcowe
***
## Art. 296. {#kp-czternastya-art-296}

(uchylony)

***
## Art. 297. {#kp-czternastya-art-297}

Minister 
Pracy 
i Polityki 
Socjalnej8) 
określi 
w drodze 
rozporządzenia: 
- 1) sposób ustalania wynagrodzenia: 
  - a) przysługującego w okresie niewykonywania pracy, 
  - b) stanowiącego podstawę ustalania wysokości kar pieniężnych, potrąceń, 
odszkodowań, 
odpraw 
pośmiertnych 
lub 
innych 
należności 
przewidzianych w Kodeksie pracy; 
- 2) sposób ustalania wysokości dodatków wyrównawczych do wynagrodzenia.

***
## Art. 298. {#kp-czternastya-art-298}

(uchylony)

***
## Art. 2981. {#kp-czternastya-art-2981}

Minister właściwy do spraw pracy w porozumieniu z ministrem 
właściwym do spraw informatyzacji określi, w drodze rozporządzenia: 
- 1) zakres, sposób i warunki prowadzenia, przechowywania oraz zmiany postaci 
dokumentacji pracowniczej, z uwzględnieniem wymagań dotyczących 
dokumentacji w postaci elektronicznej w zakresie organizacji jej 
przetwarzania i przenoszenia pomiędzy systemami teleinformatycznymi, 
- 2) sposób i tryb doręczania informacji lub zawiadomienia o możliwości odbioru 
dokumentacji pracowniczej w przypadku upływu okresu jej przechowywania 
oraz poprzedniej postaci tej dokumentacji w przypadku zmiany postaci jej 
prowadzenia i przechowywania, a także sposób odbioru dokumentacji 
pracowniczej, 
- 3) sposób wydawania kopii całości lub części dokumentacji pracowniczej 
pracownikowi, byłemu pracownikowi lub osobom, o których mowa w art. 949 
§ 3 
– uwzględniając konieczność rzetelnego prowadzenia dokumentacji pracowniczej, 
zapewnienia 
realizacji 
prawa 
dostępu 
do 
tej 
dokumentacji, 
potrzebę 
przechowywania dokumentacji pracowniczej w sposób gwarantujący zachowanie 

 
 
 
s. 192/195 
 
2025-08-06 
 
jej poufności, integralności, kompletności oraz dostępności, w warunkach 
niegrożących jej uszkodzeniem lub zniszczeniem.

***
## Art. 2982. {#kp-czternastya-art-2982}

Minister 
Pracy 
i Polityki 
Socjalnej8) 
określi, 
w drodze 
rozporządzenia, sposób usprawiedliwiania nieobecności w pracy oraz zakres 
przysługujących pracownikom zwolnień od pracy, a także przypadki, w których za 
czas nieobecności lub zwolnienia pracownik zachowuje prawo do wynagrodzenia.

***
## Art. 2983. {#kp-czternastya-art-2983}

(uchylony)

***
## Art. 299. {#kp-czternastya-art-299}

(uchylony)

***
## Art. 300. {#kp-czternastya-art-300}

W sprawach nieunormowanych przepisami prawa pracy do 
stosunku pracy stosuje się odpowiednio przepisy Kodeksu cywilnego, jeżeli nie są 
one sprzeczne z zasadami prawa pracy.

***
## Art. 301. {#kp-czternastya-art-301}

**§ 1.** Szczególne uprawnienia związane ze stosunkiem pracy osób 
powołanych do czynnej służby wojskowej i zwolnionych z tej służby normują 
przepisy ustawy z dnia 11 marca 2022 r. o obronie Ojczyzny (Dz. U. z 2024 r. 
poz. 248, z późn. zm.17)). 
**§ 2.** Okres czynnej służby wojskowej wlicza się do okresu zatrudnienia 
w zakresie i na zasadach przewidzianych w przepisach, o których mowa w § 1.

***
## Art. 302. {#kp-czternastya-art-302}

Do okresu zatrudnienia wlicza się okres służby w Policji, Urzędzie 
Ochrony Państwa, Agencji Bezpieczeństwa Wewnętrznego, Agencji Wywiadu, 
Służbie Kontrwywiadu Wojskowego, Służbie Wywiadu Wojskowego, Centralnym 
Biurze Antykorupcyjnym, Biurze Ochrony Rządu, Służbie Ochrony Państwa, 
Służbie Więziennej, Straży Granicznej i Państwowej Straży Pożarnej w zakresie i 
na zasadach przewidzianych odrębnymi przepisami.

***
## Art. 303. {#kp-czternastya-art-303}

**§ 1.** Rada Ministrów określi w drodze rozporządzenia zakres 
stosowania przepisów prawa pracy do osób wykonujących pracę nakładczą, ze 
zmianami wynikającymi z odmiennych warunków wykonywania tej pracy. 
**§ 2.** Rada Ministrów może określić, w drodze rozporządzenia, zakres 
stosowania przepisów prawa pracy do osób stale wykonujących pracę na innej 
- 17) Zmiany tekstu jednolitego wymienionej ustawy zostały ogłoszone w Dz. U. z 2024 r. poz. 834, 
1089, 1222, 1248, 1585, 1871 i 1907 oraz z 2025 r. poz. 39. 

 
 
 
s. 193/195 
 
2025-08-06 
 
podstawie niż stosunek pracy lub umowa o pracę nakładczą, ze zmianami 
wynikającymi z odmiennych warunków wykonywania tej pracy.

***
## Art. 304. {#kp-czternastya-art-304}

**§ 1.** Pracodawca 
jest 
obowiązany 
zapewnić 
bezpieczne 
i higieniczne warunki pracy, o których mowa w art. 207 § 2, osobom fizycznym 
wykonującym pracę na innej podstawie niż stosunek pracy w zakładzie pracy lub 
w miejscu wyznaczonym przez pracodawcę, a także osobom prowadzącym 
w zakładzie pracy lub w miejscu wyznaczonym przez pracodawcę na własny 
rachunek działalność gospodarczą. 
**§ 2.** Pracodawca jest obowiązany zapewnić bezpieczne i higieniczne warunki 
zajęć odbywanych na terenie zakładu pracy przez studentów i uczniów niebędących 
jego pracownikami. 
**§ 3.** Obowiązki określone w art. 207 § 2 stosuje się odpowiednio do 
przedsiębiorców niebędących pracodawcami, organizujących pracę wykonywaną 
przez osoby fizyczne: 
- 1) na innej podstawie niż stosunek pracy; 
- 2) prowadzące na własny rachunek działalność gospodarczą. 
**§ 4.** W razie prowadzenia prac w miejscu, do którego mają dostęp osoby 
niebiorące 
udziału 
w procesie 
pracy, 
pracodawca 
jest 
obowiązany 
zastosować środki niezbędne do zapewnienia ochrony życia i zdrowia tym osobom. 
**§ 5.** Minister Obrony Narodowej – w stosunku do żołnierzy w czynnej służbie 
wojskowej oraz żołnierzy pełniących służbę w aktywnej rezerwie i w pasywnej 
rezerwie, a Minister Sprawiedliwości – w stosunku do osób przebywających 
w zakładach karnych, okręgowych ośrodkach wychowawczych, zakładach 
poprawczych lub w schroniskach dla nieletnich, w porozumieniu z ministrem 
właściwym do spraw pracy, określą, w drodze rozporządzeń, zakres stosowania do 
tych osób przepisów działu dziesiątego w razie wykonywania określonych zadań 
lub prac na terenie zakładu pracy lub w miejscu wyznaczonym przez pracodawcę, 
mając na uwadze bezpieczeństwo wykonywania tych zadań lub prac.

***
## Art. 3041. {#kp-czternastya-art-3041}

Obowiązki, o których mowa w art. 211, w zakresie określonym 
przez pracodawcę lub inny podmiot organizujący pracę, ciążą również na osobach 
fizycznych wykonujących pracę na innej podstawie niż stosunek pracy w zakładzie 
pracy lub w miejscu wyznaczonym przez pracodawcę lub inny podmiot 

 
 
 
s. 194/195 
 
2025-08-06 
 
organizujący pracę, a także na osobach prowadzących na własny rachunek 
działalność gospodarczą, w zakładzie pracy lub w miejscu wyznaczonym przez 
pracodawcę lub inny podmiot organizujący pracę.

***
## Art. 3042. {#kp-czternastya-art-3042}

Do 
członków 
rolniczych 
spółdzielni 
produkcyjnych 
i współpracujących z nimi członków ich rodzin oraz członków spółdzielni kółek 
rolniczych (usług rolniczych) stosuje się odpowiednio art. 208 § 1, art. 213 § 2, 
art. 217 § 2, art. 218, art. 220 § 1 i art. 221 § 1–3.

***
## Art. 3043. {#kp-czternastya-art-3043}

Do osób fizycznych prowadzących na własny rachunek działalność 
gospodarczą stosuje się odpowiednio art. 208 § 1.

***
## Art. 3044. {#kp-czternastya-art-3044}

Pracodawca jest obowiązany przydzielać niezbędną odzież 
roboczą i środki ochrony indywidualnej osobom wykonującym krótkotrwałe prace 
albo czynności inspekcyjne, w czasie których ich własna odzież może ulec 
zniszczeniu lub znacznemu zabrudzeniu, a także ze względu na bezpieczeństwo 
wykonywania tych prac lub czynności.

***
## Art. 3045. {#kp-czternastya-art-3045}

**§ 1.** Wykonywanie pracy lub innych zajęć zarobkowych przez 
dziecko do ukończenia przez nie 16 roku życia jest dozwolone wyłącznie na rzecz 
podmiotu prowadzącego działalność kulturalną, artystyczną, sportową lub 
reklamową i wymaga uprzedniej zgody przedstawiciela ustawowego lub opiekuna 
tego dziecka, a także zezwolenia właściwego inspektora pracy. 
**§ 2.** Właściwy inspektor pracy wydaje zezwolenie, o którym mowa w § 1, na 
wniosek podmiotu określonego w tym przepisie. 
**§ 3.** Właściwy inspektor pracy odmawia wydania zezwolenia, jeżeli 
wykonywanie pracy lub innych zajęć zarobkowych w zakresie przewidzianym 
w § 1: 
- 1) powoduje zagrożenie dla życia, zdrowia i rozwoju psychofizycznego dziecka; 
- 2) zagraża wypełnianiu obowiązku szkolnego przez dziecko. 
**§ 4.** Podmiot, o którym mowa w § 1, dołącza do wniosku o wydanie 
zezwolenia: 
- 1) pisemną zgodę przedstawiciela ustawowego lub opiekuna dziecka na 
wykonywanie przez dziecko pracy lub innych zajęć zarobkowych; 

 
 
 
s. 195/195 
 
2025-08-06 
- 2) opinię 
poradni 
psychologiczno-pedagogicznej 
dotyczącą 
braku 
przeciwwskazań do wykonywania przez dziecko pracy lub innych zajęć 
zarobkowych; 
- 3) orzeczenie lekarza stwierdzające brak przeciwwskazań do wykonywania 
przez dziecko pracy lub innych zajęć zarobkowych; 
- 4) jeżeli dziecko podlega obowiązkowi szkolnemu – opinię dyrektora szkoły, do 
której dziecko uczęszcza, dotyczącą możliwości wypełniania przez dziecko 
tego obowiązku w czasie wykonywania przez nie pracy lub innych zajęć 
zarobkowych. 
**§ 5.** Zezwolenie, o którym mowa w § 1, powinno zawierać: 
- 1) dane osobowe dziecka i jego przedstawiciela ustawowego lub opiekuna; 
- 2) oznaczenie podmiotu prowadzącego działalność w zakresie przewidzianym 
w § 1; 
- 3) określenie rodzaju pracy lub innych zajęć zarobkowych, które może 
wykonywać dziecko; 
- 4) określenie dopuszczalnego okresu wykonywania przez dziecko pracy lub 
innych zajęć zarobkowych; 
- 5) określenie dopuszczalnego dobowego wymiaru czasu pracy lub innych zajęć 
zarobkowych; 
- 6) inne niezbędne ustalenia, wymagane ze względu na dobro dziecka lub rodzaj, 
charakter albo warunki wykonywania pracy lub innych zajęć zarobkowych 
przez dziecko. 
**§ 6.** Na wniosek przedstawiciela ustawowego lub opiekuna dziecka właściwy 
inspektor pracy cofa wydane zezwolenie. 
**§ 7.** Właściwy inspektor pracy cofa wydane zezwolenie z urzędu, jeżeli 
stwierdzi, że warunki pracy dziecka nie odpowiadają warunkom określonym 
w wydanym zezwoleniu.

***
## Art. 305. {#kp-czternastya-art-305}

(uchylony)

