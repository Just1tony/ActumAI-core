---
id: code.kp.dzial.drugi
title: "Kodeks pracy — Dział DRUGI (Stosunek pracy)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1974 nr 24 poz. 141"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KP — Dział DRUGI"]
tags: ["KP","Kodeks pracy","Dział DRUGI","PL"]
source_pdf: "D19740141Lj.pdf"
articles: "Art. 22–6734"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kp-drugi-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks pracy — Dział DRUGI: Stosunek pracy

Stosunek pracy 
## Rozdział I Przepisy ogólne
***
## Art. 22. {#kp-drugi-art-22}

**§ 1.** Przez nawiązanie stosunku pracy pracownik zobowiązuje się do 
wykonywania pracy określonego rodzaju na rzecz pracodawcy i pod jego 
kierownictwem oraz w miejscu i czasie wyznaczonym przez pracodawcę, 
a pracodawca – do zatrudniania pracownika za wynagrodzeniem. 
**§ 11.** Zatrudnienie w warunkach określonych w § 1 jest zatrudnieniem na 
podstawie stosunku pracy, bez względu na nazwę zawartej przez strony umowy. 
**§ 12.** Nie 
jest 
dopuszczalne 
zastąpienie 
umowy 
o pracę 
umową 
cywilnoprawną przy zachowaniu warunków wykonywania pracy, określonych 
w § 1. 
**§ 2.** Pracownikiem może być osoba, która ukończyła 18 lat. Na warunkach 
określonych w dziale dziewiątym pracownikiem może być również osoba, która nie 
ukończyła 18 lat. 
**§ 3.** Osoba ograniczona w zdolności do czynności prawnych może bez zgody 
przedstawiciela ustawowego nawiązać stosunek pracy oraz dokonywać czynności 
prawnych, które dotyczą tego stosunku. Jednakże gdy stosunek pracy sprzeciwia 
się dobru tej osoby, przedstawiciel ustawowy za zezwoleniem sądu opiekuńczego 
może stosunek pracy rozwiązać.

***
## Art. 221. {#kp-drugi-art-221}

**§ 1.** Pracodawca żąda od osoby ubiegającej się o zatrudnienie 
podania danych osobowych obejmujących: 
- 1) imię (imiona) i nazwisko; 
- 2) datę urodzenia; 
- 3) dane kontaktowe wskazane przez taką osobę; 
- 4) wykształcenie; 
- 5) kwalifikacje zawodowe; 
[6) przebieg dotychczasowego zatrudnienia.]  
Nowe brzmienie 
pkt 6 w § 1 w art. 

wejdzie 
w 
życie 
z 
dn. 
24.12.2025 r. (Dz. 
U. z 2025 r. poz. 
807). 

 
 
 
s. 13/195 
 
2025-08-06 
 
<6) przebieg dotychczasowego zatrudnienia, z wyłączeniem informacji 
o wynagrodzeniu w obecnym stosunku pracy oraz w poprzednich 
stosunkach pracy.>  
**§ 2.** Pracodawca żąda podania danych osobowych, o których mowa w § 1 pkt 
4–6, gdy jest to niezbędne do wykonywania pracy określonego rodzaju lub na 
określonym stanowisku. 
**§ 3.** Pracodawca żąda od pracownika podania dodatkowo danych osobowych 
obejmujących: 
- 1) adres zamieszkania; 
- 2) numer PESEL, a w przypadku jego braku – rodzaj i numer dokumentu 
potwierdzającego tożsamość; 
- 3) inne dane osobowe pracownika, a także dane osobowe dzieci pracownika i 
innych członków jego najbliższej rodziny, jeżeli podanie takich danych jest 
konieczne ze względu na korzystanie przez pracownika ze szczególnych 
uprawnień przewidzianych w prawie pracy; 
- 4) wykształcenie i przebieg dotychczasowego zatrudnienia, jeżeli nie istniała 
podstawa do ich żądania od osoby ubiegającej się o zatrudnienie; 
- 5) numer rachunku płatniczego, jeżeli pracownik nie złożył wniosku o wypłatę 
wynagrodzenia do rąk własnych. 
**§ 4.** Pracodawca żąda podania innych danych osobowych niż określone w § 1 
i 3, gdy jest to niezbędne do zrealizowania uprawnienia lub spełnienia obowiązku 
wynikającego z przepisu prawa. 
**§ 5.** Udostępnienie pracodawcy danych osobowych następuje w formie 
oświadczenia 
osoby, 
której 
dane 
dotyczą. 
Pracodawca 
może 
żądać 
udokumentowania danych osobowych osób, o których mowa w § 1 i 3, w zakresie 
niezbędnym do ich potwierdzenia. 
Art. 221a. § 1. Zgoda osoby ubiegającej się o zatrudnienie lub pracownika 
może stanowić podstawę przetwarzania przez pracodawcę innych danych 
osobowych niż wymienione w art. 221 § 1 i 3, z wyjątkiem danych osobowych, o 
których mowa w art. 10 rozporządzenia Parlamentu Europejskiego i Rady (UE) 
2016/679 z dnia 27 kwietnia 2016 r. w sprawie ochrony osób fizycznych w związku 
z przetwarzaniem danych osobowych i w sprawie swobodnego przepływu takich 
danych oraz uchylenia dyrektywy 95/46/WE (ogólne rozporządzenie o ochronie 

 
 
 
s. 14/195 
 
2025-08-06 
 
danych) (Dz. Urz. UE L 119 z 04.05.2016, str. 1, z późn. zm.2)), zwanego dalej 
„rozporządzeniem 2016/679”. 
**§ 2.** Brak zgody, o której mowa w § 1, lub jej wycofanie, nie może być 
podstawą niekorzystnego traktowania osoby ubiegającej się o zatrudnienie lub 
pracownika, a także nie może powodować wobec nich jakichkolwiek negatywnych 
konsekwencji, zwłaszcza nie może stanowić przyczyny uzasadniającej odmowę 
zatrudnienia, wypowiedzenie umowy o pracę lub jej rozwiązanie bez 
wypowiedzenia przez pracodawcę. 
**§ 3.** Przetwarzanie, o którym mowa w § 1, dotyczy danych osobowych 
udostępnianych przez osobę ubiegającą się o zatrudnienie lub pracownika na 
wniosek pracodawcy lub danych osobowych przekazanych pracodawcy z 
inicjatywy osoby ubiegającej się o zatrudnienie lub pracownika. 
Art. 221b. § 1. Zgoda osoby ubiegającej się o zatrudnienie lub pracownika 
może stanowić podstawę przetwarzania przez pracodawcę danych osobowych, o 
których mowa w art. 9 ust. 1 rozporządzenia 2016/679, wyłącznie w przypadku, 
gdy przekazanie tych danych osobowych następuje z inicjatywy osoby ubiegającej 
się o zatrudnienie lub pracownika. Przepis art. 221a § 2 stosuje się odpowiednio. 
**§ 2.** Przetwarzanie danych biometrycznych pracownika jest dopuszczalne 
także wtedy, gdy podanie takich danych jest niezbędne ze względu na kontrolę 
dostępu do szczególnie ważnych informacji, których ujawnienie może narazić 
pracodawcę na szkodę, lub dostępu do pomieszczeń wymagających szczególnej 
ochrony. 
**§ 3.** Do przetwarzania danych osobowych, o których mowa w § 1, mogą być 
dopuszczone 
wyłącznie 
osoby 
posiadające 
pisemne 
upoważnienie 
do 
przetwarzania takich danych wydane przez pracodawcę. Osoby dopuszczone do 
przetwarzania takich danych są obowiązane do zachowania ich w tajemnicy. 
Art. 221c. § 1. Jeżeli jest to niezbędne do zapewnienia ochrony życia 
i zdrowia pracowników lub innych osób lub ochrony mienia, pracodawca może 
wprowadzić kontrolę trzeźwości pracowników. 
- 2) Zmiana wymienionego rozporządzenia została ogłoszona w Dz. Urz. UE L 127 z 23.05.2018, 
str. 2. 

 
 
 
s. 15/195 
 
2025-08-06 
**§ 2.** Kontrola trzeźwości nie może naruszać godności oraz innych dóbr 
osobistych pracownika. 
**§ 3.** Kontrola trzeźwości jest przeprowadzana przez pracodawcę w sposób 
ustalony zgodnie z § 10, uwzględniający wymagania wynikające z przepisów 
wydanych na podstawie art. 221g. 
**§ 4.** Kontrola 
trzeźwości 
obejmuje 
badanie 
przy 
użyciu 
metod 
niewymagających badania laboratoryjnego za pomocą urządzenia posiadającego 
ważny dokument potwierdzający jego kalibrację lub wzorcowanie. 
**§ 5.** Badanie, o którym mowa w § 4, polega na stwierdzeniu braku obecności 
alkoholu w organizmie pracownika albo obecności alkoholu wskazującej na stan 
po użyciu alkoholu albo stan nietrzeźwości w rozumieniu art. 46 ust. 2 albo 3 
ustawy 
z dnia 
26 października 
1982 r. 
o wychowaniu 
w trzeźwości 
i przeciwdziałaniu alkoholizmowi (Dz. U. z 2023 r. poz. 2151). Za równoznaczne 
ze stwierdzeniem braku obecności alkoholu w organizmie pracownika uznaje się 
przypadki, w których zawartość alkoholu nie osiąga lub nie prowadzi do 
osiągnięcia wartości właściwych dla stanu po użyciu alkoholu. 
**§ 6.** Pracodawca przetwarza informacje o dacie, godzinie i minucie badania, 
o którym mowa w § 4, oraz jego wyniku wskazującym na stan po użyciu alkoholu 
albo stan nietrzeźwości wyłącznie w przypadku, gdy jest to niezbędne do 
zapewnienia ochrony dóbr, o których mowa w § 1, i przechowuje te informacje 
w aktach osobowych pracownika przez okres nieprzekraczający roku od dnia ich 
zebrania. 
**§ 7.** W przypadku zastosowania kary upomnienia, kary nagany lub kary 
pieniężnej pracodawca przechowuje informacje, o których mowa w § 6, w aktach 
osobowych pracownika do czasu uznania kary za niebyłą zgodnie z art. 113. 
**§ 8.** W przypadku, w którym informacje, o których mowa w § 6, mogą 
stanowić lub stanowią dowód w postępowaniu prowadzonym na podstawie prawa, 
a pracodawca jest stroną tego postępowania lub powziął wiadomość o wytoczeniu 
powództwa lub wszczęciu postępowania, okres, o którym mowa w § 6, ulega 
przedłużeniu do czasu prawomocnego zakończenia postępowania. 
**§ 9.** Po upływie okresów, o których mowa w § 6, 7 lub 8, informacje, 
o których mowa w § 6, podlegają usunięciu. 

 
 
 
s. 16/195 
 
2025-08-06 
**§ 10.** Wprowadzenie kontroli trzeźwości, grupę lub grupy pracowników 
objętych kontrolą trzeźwości i sposób przeprowadzania kontroli trzeźwości, w tym 
rodzaj urządzenia wykorzystywanego do kontroli, czas i częstotliwość jej 
przeprowadzania, ustala się w układzie zbiorowym pracy lub w regulaminie pracy 
albo w obwieszczeniu, jeżeli pracodawca nie jest objęty układem zbiorowym pracy 
lub nie jest obowiązany do ustalenia regulaminu pracy. 
**§ 11.** O wprowadzeniu kontroli trzeźwości, o którym mowa w § 10, 
pracodawca informuje pracowników w sposób przyjęty u danego pracodawcy nie 
później niż 2 tygodnie przed rozpoczęciem jej przeprowadzania. 
**§ 12.** W związku z zatrudnieniem pracownika objętego kontrolą trzeźwości 
pracodawca przekazuje temu pracownikowi przed dopuszczeniem go do pracy 
informacje, o których mowa w § 10, w postaci papierowej lub elektronicznej. 
Art. 221d. § 1. Pracodawca nie dopuszcza pracownika do pracy, jeżeli 
kontrola trzeźwości wykaże obecność alkoholu w organizmie pracownika 
wskazującą na stan po użyciu alkoholu albo stan nietrzeźwości w rozumieniu 
art. 46 ust. 2 albo 3 ustawy z dnia 26 października 1982 r. o wychowaniu 
w trzeźwości i przeciwdziałaniu alkoholizmowi albo zachodzi uzasadnione 
podejrzenie, że pracownik stawił się do pracy w stanie po użyciu alkoholu albo 
w stanie nietrzeźwości lub spożywał alkohol w czasie pracy. 
**§ 2.** Informację dotyczącą podstawy niedopuszczenia pracownika do pracy 
przekazuje się pracownikowi do wiadomości. 
**§ 3.** Na żądanie pracodawcy lub pracownika niedopuszczonego do pracy 
badanie stanu trzeźwości pracownika przeprowadza uprawniony organ powołany 
do ochrony porządku publicznego. 
**§ 4.** Organ, o którym mowa w § 3, przeprowadza badanie stanu trzeźwości 
pracownika przy użyciu metod niewymagających badania laboratoryjnego. 
**§ 5.** Organ, o którym mowa w § 3, zleca przeprowadzenie badania krwi, 
jeżeli: 
- 1) nie ma możliwości przeprowadzenia badania metodą, o której mowa w § 4; 
- 2) pracownik niedopuszczony do pracy odmawia poddania się badaniu metodą, 
o której mowa w § 4; 
- 3) pracownik niedopuszczony do pracy żąda przeprowadzenia badania krwi 
pomimo przeprowadzenia badania metodą, o której mowa w § 4; 

 
 
 
s. 17/195 
 
2025-08-06 
- 4) stan pracownika niedopuszczonego do pracy uniemożliwia przeprowadzenie 
badania metodą, o której mowa w § 4; 
- 5) nie ma możliwości wskazania stężenia alkoholu z powodu przekroczenia 
zakresu pomiarowego urządzenia wykorzystywanego do pomiaru. 
**§ 6.** Badania, o których mowa w § 4 i 5, przeprowadza się z poszanowaniem 
godności i intymności pracownika. 
**§ 7.** Zabiegu pobrania krwi dokonuje osoba posiadająca odpowiednie 
kwalifikacje zawodowe. 
**§ 8.** W przypadku gdy wynik badania nie wskazuje na stan po użyciu alkoholu 
albo stan nietrzeźwości pracownika, okres niedopuszczenia pracownika do pracy 
jest okresem usprawiedliwionej nieobecności w pracy, za który pracownik 
zachowuje prawo do wynagrodzenia. 
**§ 9.** Przebieg badań, o których mowa w § 4 i 5, dokumentuje się 
z uwzględnieniem: 
- 1) daty, godziny i minuty oraz miejsca przeprowadzenia badania; 
- 2) wyniku badania; 
- 3) danych osobowych pracownika: 
  - a) imienia i nazwiska, 
  - b) numeru PESEL, a jeżeli nie posiada – serii i numeru dokumentu 
potwierdzającego tożsamość pracownika, 
  - c) daty urodzenia, płci, wzrostu, masy ciała, informacji o chorobach, na 
jakie pracownik choruje, oraz podpisu pracownika – jeżeli dane te 
pozyskano w związku z przeprowadzanym badaniem; 
- 4) imienia i nazwiska oraz podpisu osoby przeprowadzającej badanie; 
- 5) imienia, nazwiska, stanowiska i podpisu osoby przeprowadzającej pobranie 
próbek materiału biologicznego do badań; 
- 6) imienia i nazwiska oraz podpisu osoby, w obecności której przeprowadzono 
badanie; 
- 7) informacji o objawach lub okolicznościach uzasadniających przeprowadzenie 
badania oraz dacie i godzinie ich stwierdzenia; 
- 8) innych informacji niezbędnych do oceny wiarygodności i poprawności 
badania; 

 
 
 
s. 18/195 
 
2025-08-06 
- 9) w przypadku odstąpienia od pobrania próbek krwi – informacji o przyczynie 
odstąpienia. 
**§ 10.** Organ przeprowadzający badanie, o którym mowa w § 3, przekazuje 
pracodawcy i pracownikowi niedopuszczonemu do pracy informację w formie 
pisemnej, obejmującą imię i nazwisko osoby badanej oraz jej numer PESEL, 
a w przypadku jego braku – serię i numer dokumentu potwierdzającego tożsamość, 
datę, godzinę oraz minutę przeprowadzonego badania, a także jego wynik. 
W przypadku przeprowadzenia kilku pomiarów organ przeprowadzający badanie 
przekazuje informację o czasie przeprowadzenia pomiarów i wyniku każdego 
z nich. 
**§ 11.** Do przetwarzania informacji, o której mowa w § 10, stosuje się 
odpowiednio art. 221c § 6–9. 
Art. 221e. § 1. Jeżeli jest to niezbędne do zapewnienia ochrony życia 
i zdrowia pracowników lub innych osób lub ochrony mienia, pracodawca może 
wprowadzić kontrolę pracowników na obecność w ich organizmach środków 
działających podobnie do alkoholu. 
**§ 2.** Przepisy art. 221c § 2–12 stosuje się odpowiednio. 
Art. 221f. § 1. Pracodawca nie dopuszcza pracownika do pracy, jeżeli 
kontrola, o której mowa w art. 221e § 1, wykaże obecność w organizmie 
pracownika środka działającego podobnie do alkoholu albo zachodzi uzasadnione 
podejrzenie, że pracownik stawił się do pracy w stanie po użyciu takiego środka lub 
zażywał taki środek w czasie pracy. 
**§ 2.** Przepisy art. 221d § 2–4, 7, 8, 10 i 11 stosuje się odpowiednio. 
**§ 3.** Uprawniony organ powołany do ochrony porządku publicznego zleca 
przeprowadzenie badania krwi lub moczu, jeżeli: 
- 1) nie ma możliwości przeprowadzenia badania metodą niewymagającą badania 
laboratoryjnego; 
- 2) pracownik niedopuszczony do pracy odmawia poddania się badaniu metodą 
niewymagającą badania laboratoryjnego; 
- 3) pracownik niedopuszczony do pracy żąda przeprowadzenia badania krwi lub 
moczu pomimo przeprowadzenia badania metodą niewymagającą badania 
laboratoryjnego; 

 
 
 
s. 19/195 
 
2025-08-06 
- 4) stan pracownika niedopuszczonego do pracy uniemożliwia przeprowadzenie 
badania metodą niewymagającą badania laboratoryjnego. 
**§ 4.** Badanie przy użyciu metod niewymagających badania laboratoryjnego 
oraz badanie, o którym mowa w § 3, przeprowadza się z poszanowaniem godności 
i intymności pracownika. 
**§ 5.** Czynności związane z pobraniem moczu do badania, o którym mowa 
w § 3, odbywają się w obecności osoby posiadającej odpowiednie kwalifikacje 
zawodowe do przeprowadzania badania moczu, tej samej płci co pracownik, od 
którego pobiera się mocz. 
**§ 6.** Przebieg badania przeprowadzonego przez uprawniony organ powołany 
do ochrony porządku publicznego przy użyciu metod niewymagających badania 
laboratoryjnego oraz badania, o którym mowa w § 3, dokumentuje się 
z uwzględnieniem: 
- 1) daty, godziny i minuty oraz miejsca przeprowadzenia badania; 
- 2) wyniku badania; 
- 3) danych osobowych pracownika: 
  - a) imienia i nazwiska, 
  - b) numeru PESEL, a jeżeli nie posiada – serii i numeru dokumentu 
potwierdzającego tożsamość pracownika, 
  - c) daty urodzenia, informacji o chorobach, na jakie pracownik choruje, oraz 
podpisu pracownika 
– jeżeli dane te pozyskano w związku 
z przeprowadzanym badaniem; 
- 4) imienia i nazwiska oraz podpisu osoby przeprowadzającej badanie; 
- 5) imienia, nazwiska, stanowiska i podpisu osoby przeprowadzającej pobranie 
próbek materiału biologicznego do badań; 
- 6) imienia i nazwiska oraz podpisu osoby, w obecności której przeprowadzono 
badanie; 
- 7) informacji o objawach lub okolicznościach uzasadniających przeprowadzenie 
badania oraz dacie i godzinie ich stwierdzenia; 
- 8) innych informacji niezbędnych do oceny wiarygodności i poprawności 
badania; 
- 9) w przypadku odstąpienia od pobrania próbek krwi lub moczu – informacji 
o przyczynie odstąpienia. 

 
 
 
s. 20/195 
 
2025-08-06 
 
Art. 221g. Minister właściwy do spraw zdrowia w porozumieniu z ministrem 
właściwym do spraw wewnętrznych oraz ministrem właściwym do spraw pracy 
określi, w drodze rozporządzenia: 
- 1) warunki 
i metody 
przeprowadzania 
badań 
na 
obecność 
alkoholu 
w organizmie pracownika oraz badań na obecność w organizmie pracownika 
środków działających podobnie do alkoholu przez pracodawcę oraz przez 
uprawniony organ powołany do ochrony porządku publicznego lub zlecanych 
przez ten organ, 
- 2) sposób dokumentowania badań przeprowadzanych lub zlecanych przez 
uprawniony organ powołany do ochrony porządku publicznego, 
- 3) wykaz środków działających podobnie do alkoholu 
– mając na uwadze metodykę przeprowadzania takich badań, konieczność 
zapewnienia ochrony życia i zdrowia pracowników lub innych osób lub ochrony 
mienia, a także konieczność sprawnego przeprowadzania badań i zagwarantowania 
wiarygodności wyników badania krwi i moczu przy jednoczesnym poszanowaniu 
godności oraz innych dóbr osobistych pracownika i zasad ochrony danych 
osobowych. 
Art. 221h. Przepisy art. 221c–221f oraz przepisy wydane na podstawie art. 221g 
stosuje się odpowiednio do pracodawców organizujących pracę wykonywaną przez 
osoby fizyczne na innej podstawie niż stosunek pracy oraz osoby fizyczne 
prowadzące na własny rachunek działalność gospodarczą, a także do osób 
fizycznych wykonujących pracę na innej podstawie niż stosunek pracy oraz osób 
fizycznych prowadzących na własny rachunek działalność gospodarczą, których 
praca jest organizowana przez tych pracodawców.

***
## Art. 222. {#kp-drugi-art-222}

**§ 1.** Jeżeli jest to niezbędne do zapewnienia bezpieczeństwa 
pracowników lub ochrony mienia lub kontroli produkcji lub zachowania w 
tajemnicy informacji, których ujawnienie mogłoby narazić pracodawcę na szkodę, 
pracodawca może wprowadzić szczególny nadzór nad terenem zakładu pracy lub 
terenem wokół zakładu pracy w postaci środków technicznych umożliwiających 
rejestrację obrazu (monitoring). 
**§ 11.** Monitoring nie obejmuje pomieszczeń udostępnianych zakładowej 
organizacji związkowej. 

 
 
 
s. 21/195 
 
2025-08-06 
**§ 2.** Monitoring nie obejmuje pomieszczeń sanitarnych, szatni, stołówek oraz 
palarni, chyba że stosowanie monitoringu w tych pomieszczeniach jest niezbędne 
do realizacji celu określonego w § 1 i nie naruszy to godności oraz innych dóbr 
osobistych pracownika, w szczególności poprzez zastosowanie technik 
uniemożliwiających rozpoznanie przebywających w tych pomieszczeniach osób. 
Monitoring pomieszczeń sanitarnych wymaga uzyskania uprzedniej zgody 
zakładowej organizacji związkowej, a jeżeli u pracodawcy nie działa zakładowa 
organizacja związkowa – uprzedniej zgody przedstawicieli pracowników 
wybranych w trybie przyjętym u danego pracodawcy. 
**§ 3.** Nagrania obrazu pracodawca przetwarza wyłącznie do celów, dla których 
zostały zebrane, i przechowuje przez okres nieprzekraczający 3 miesięcy od dnia 
nagrania. 
**§ 4.** W przypadku, w którym nagrania obrazu stanowią dowód w 
postępowaniu prowadzonym na podstawie prawa lub pracodawca powziął 
wiadomość, iż mogą one stanowić dowód w postępowaniu, termin określony w § 3 
ulega przedłużeniu do czasu prawomocnego zakończenia postępowania. 
**§ 5.** Po upływie okresów, o których mowa w § 3 lub 4, uzyskane w wyniku 
monitoringu nagrania obrazu zawierające dane osobowe podlegają zniszczeniu, o 
ile przepisy odrębne nie stanowią inaczej. 
**§ 6.** Cele, zakres oraz sposób zastosowania monitoringu ustala się w układzie 
zbiorowym pracy lub w regulaminie pracy albo w obwieszczeniu, jeżeli 
pracodawca nie jest objęty układem zbiorowym pracy lub nie jest obowiązany do 
ustalenia regulaminu pracy. 
**§ 7.** Pracodawca informuje pracowników o wprowadzeniu monitoringu, w 
sposób przyjęty u danego pracodawcy, nie później niż 2 tygodnie przed jego 
uruchomieniem. 
**§ 8.** Pracodawca przed dopuszczeniem pracownika do pracy przekazuje mu 
na piśmie informacje, o których mowa w § 6. 
**§ 9.** W przypadku wprowadzenia monitoringu pracodawca oznacza 
pomieszczenia i teren monitorowany w sposób widoczny i czytelny, za pomocą 
odpowiednich znaków lub ogłoszeń dźwiękowych, nie później niż jeden dzień 
przed jego uruchomieniem.  

 
 
 
s. 22/195 
 
2025-08-06 
**§ 10.** Przepis § 9 nie narusza przepisów art. 12 i art. 13 rozporządzenia 
2016/679.

***
## Art. 223. {#kp-drugi-art-223}

**§ 1.** Jeżeli jest to niezbędne do zapewnienia organizacji pracy 
umożliwiającej pełne wykorzystanie czasu pracy oraz właściwego użytkowania 
udostępnionych pracownikowi narzędzi pracy, pracodawca może wprowadzić 
kontrolę służbowej poczty elektronicznej pracownika (monitoring poczty 
elektronicznej). 
**§ 2.** Monitoring poczty elektronicznej nie może naruszać tajemnicy 
korespondencji oraz innych dóbr osobistych pracownika. 
**§ 3.** Przepisy art. 222 § 6–10 stosuje się odpowiednio. 
**§ 4.** Przepisy § 1–3 stosuje się odpowiednio do innych form monitoringu niż 
określone w § 1, jeśli ich zastosowanie jest konieczne do realizacji celów 
określonych w § 1.

***
## Art. 23. {#kp-drugi-art-23}

(uchylony)

***
## Art. 231. {#kp-drugi-art-231}

- 3) § 1. W razie przejścia zakładu pracy lub jego części na innego 
pracodawcę staje się on z mocy prawa stroną w dotychczasowych stosunkach 
pracy, z zastrzeżeniem przepisów § 5. 
**§ 2.** Za zobowiązania wynikające ze stosunku pracy, powstałe przed 
przejściem części zakładu pracy na innego pracodawcę, dotychczasowy i nowy 
pracodawca odpowiadają solidarnie. 
**§ 3.** Jeżeli u pracodawców, o których mowa w § 1, nie działają zakładowe 
organizacje związkowe, dotychczasowy i nowy pracodawca informują na piśmie 
swoich pracowników o przewidywanym terminie przejścia zakładu pracy lub jego 
części na innego pracodawcę, jego przyczynach, prawnych, ekonomicznych oraz 
socjalnych skutkach dla pracowników, a także zamierzonych działaniach 
dotyczących warunków zatrudnienia pracowników, w szczególności warunków 
pracy, płacy i przekwalifikowania; przekazanie informacji powinno nastąpić co 
- 3) Uznany za niezgodny z Konstytucją Rzeczypospolitej Polskiej z dniem 25 kwietnia 2005 r. 
w zakresie, w jakim pomija współodpowiedzialność Skarbu Państwa za zobowiązania wynikające 
ze stosunku pracy powstałe przed przekształceniem statio fisci Skarbu Państwa – zakładu opieki 
zdrowotnej w samodzielny publiczny zakład opieki zdrowotnej, na podstawie wyroku Trybunału 
Konstytucyjnego z dnia 4 kwietnia 2005 r. sygn. akt SK 7/03 (Dz. U. poz. 610). 

 
 
 
s. 23/195 
 
2025-08-06 
 
najmniej na 30 dni przed przewidywanym terminem przejścia zakładu pracy lub 
jego części na innego pracodawcę. 
**§ 4.** W terminie 2 miesięcy od przejścia zakładu pracy lub jego części na 
innego pracodawcę, pracownik może bez wypowiedzenia, za siedmiodniowym 
uprzedzeniem, rozwiązać stosunek pracy. Rozwiązanie stosunku pracy w tym 
trybie powoduje dla pracownika skutki, jakie przepisy prawa pracy wiążą 
z rozwiązaniem stosunku pracy przez pracodawcę za wypowiedzeniem. 
**§ 5.** Pracodawca, z dniem przejęcia zakładu pracy lub jego części, jest 
obowiązany 
zaproponować 
nowe 
warunki 
pracy 
i płacy 
pracownikom 
świadczącym dotychczas pracę na innej podstawie niż umowa o pracę oraz wskazać 
termin, nie krótszy niż 7 dni, do którego pracownicy mogą złożyć oświadczenie 
o przyjęciu lub odmowie przyjęcia proponowanych warunków. W razie 
nieuzgodnienia nowych warunków pracy i płacy dotychczasowy stosunek pracy 
rozwiązuje się z upływem okresu równego okresowi wypowiedzenia, liczonego od 
dnia, w którym pracownik złożył oświadczenie o odmowie przyjęcia 
proponowanych warunków, lub od dnia, do którego mógł złożyć takie 
oświadczenie. Przepis § 4 zdanie drugie stosuje się odpowiednio. 
**§ 6.** Przejście zakładu pracy lub jego części na innego pracodawcę nie może 
stanowić przyczyny uzasadniającej wypowiedzenie przez pracodawcę stosunku 
pracy. 
Art. 231a. § 1. Jeżeli jest to uzasadnione sytuacją finansową pracodawcy, 
nieobjętego układem zbiorowym pracy lub zatrudniającego mniej niż 
20 pracowników, może być zawarte porozumienie o stosowaniu mniej korzystnych 
warunków zatrudnienia pracowników niż wynikające z umów o pracę zawartych 
z tymi pracownikami, w zakresie i przez czas ustalone w porozumieniu. 
**§ 2.** Przepisy art. 91 § 1–4 stosuje się odpowiednio.

***
## Art. 232. {#kp-drugi-art-232}

Jeżeli przepisy prawa pracy przewidują współdziałanie pracodawcy 
z zakładową organizacją związkową w indywidualnych sprawach ze stosunku 
pracy, pracodawca ma obowiązek współdziałać w takich sprawach z zakładową 
organizacją związkową reprezentującą pracownika z tytułu jego członkostwa 
w związku zawodowym albo wyrażenia zgody na obronę praw pracownika 
niezrzeszonego w związku – zgodnie z ustawą o związkach zawodowych. 

 
 
 
s. 24/195 
 
2025-08-06

***
## Art. 24. {#kp-drugi-art-24}

(uchylony) 
## Rozdział II Umowa o pracę 
Oddział 1 
Zawarcie umowy o pracę

***
## Art. 25. {#kp-drugi-art-25}

**§ 1.** Umowę o pracę zawiera się na okres próbny, na czas określony 
albo na czas nieokreślony. 
**§ 2.** Umowę o pracę na okres próbny zawiera się na okres nieprzekraczający 
3 miesięcy, z zastrzeżeniem § 21–23, w celu sprawdzenia kwalifikacji pracownika 
i możliwości jego zatrudnienia w celu wykonywania określonego rodzaju pracy. 
**§ 21.** Strony mogą uzgodnić w umowie o pracę na okres próbny, że umowę tę 
przedłuża się o czas urlopu, a także o czas innej usprawiedliwionej nieobecności 
pracownika w pracy, jeżeli wystąpią takie nieobecności. 
**§ 22.** Umowę o pracę na okres próbny zawiera się na okres nieprzekraczający: 
- 1) 1 miesiąca – w przypadku zamiaru zawarcia umowy o pracę na czas określony 
krótszy niż 6 miesięcy; 
- 2) 2 miesięcy – w przypadku zamiaru zawarcia umowy o pracę na czas 
określony wynoszący co najmniej 6 miesięcy i krótszy niż 12 miesięcy. 
**§ 23.** Strony mogą jednokrotnie wydłużyć w umowie o pracę na okres próbny 
okresy, o których mowa w § 22, nie więcej jednak niż o 1 miesiąc, jeżeli jest to 
uzasadnione rodzajem pracy. 
**§ 3.** Ponowne zawarcie umowy o pracę na okres próbny z tym samym 
pracownikiem jest dopuszczalne, jeżeli pracownik ma być zatrudniony w celu 
wykonywania innego rodzaju pracy.

***
## Art. 251. {#kp-drugi-art-251}

**§ 1.** Okres zatrudnienia na podstawie umowy o pracę na czas 
określony, a także łączny okres zatrudnienia na podstawie umów o pracę na czas 
określony zawieranych między tymi samymi stronami stosunku pracy, nie może 
przekraczać 33 miesięcy, a łączna liczba tych umów nie może przekraczać trzech. 
**§ 2.** Uzgodnienie między stronami w trakcie trwania umowy o pracę na czas 
określony dłuższego okresu wykonywania pracy na podstawie tej umowy uważa 

 
 
 
s. 25/195 
 
2025-08-06 
 
się za zawarcie, od dnia następującego po dniu, w którym miało nastąpić jej 
rozwiązanie, nowej umowy o pracę na czas określony w rozumieniu § 1. 
**§ 3.** Jeżeli okres zatrudnienia na podstawie umowy o pracę na czas określony 
jest dłuższy niż okres, o którym mowa w § 1, lub jeżeli liczba zawartych umów jest 
większa niż liczba umów określona w tym przepisie, uważa się, że pracownik, 
odpowiednio od dnia następującego po upływie okresu, o którym mowa w § 1, lub 
od dnia zawarcia czwartej umowy o pracę na czas określony, jest zatrudniony na 
podstawie umowy o pracę na czas nieokreślony. 
**§ 4.** Przepisu § 1 nie stosuje się do umów o pracę zawartych na czas 
określony: 
- 1) w celu zastępstwa pracownika w czasie jego usprawiedliwionej nieobecności 
w pracy, 
- 2) w celu wykonywania pracy o charakterze dorywczym lub sezonowym, 
- 3) w celu wykonywania pracy przez okres kadencji, 
- 4) w przypadku gdy pracodawca wskaże obiektywne przyczyny leżące po jego 
stronie 
– jeżeli ich zawarcie w danym przypadku służy zaspokojeniu rzeczywistego 
okresowego zapotrzebowania i jest niezbędne w tym zakresie w świetle wszystkich 
okoliczności zawarcia umowy. 
**§ 41.** Przepisów § 1 i 3 nie stosuje się w przypadku przedłużenia umowy o 
pracę do dnia porodu zgodnie z art. 177 § 3. 
**§ 5.** Pracodawca zawiadamia właściwego okręgowego inspektora pracy, 
w formie pisemnej lub elektronicznej, o zawarciu umowy o pracę, o której mowa 
w § 4 pkt 4, wraz ze wskazaniem przyczyn zawarcia takiej umowy, w terminie 
5 dni roboczych od dnia jej zawarcia.

***
## Art. 26. {#kp-drugi-art-26}

Stosunek pracy nawiązuje się w dniu określonym w umowie jako 
dzień rozpoczęcia pracy.

***
## Art. 261. {#kp-drugi-art-261}

**§ 1.** Pracodawca nie może zakazać pracownikowi jednoczesnego 
pozostawania w stosunku pracy z innym pracodawcą lub jednoczesnego 
pozostawania w stosunku prawnym będącym podstawą świadczenia pracy innym 
niż stosunek pracy. 
**§ 2.** Przepisu § 1 nie stosuje się: 

 
 
 
s. 26/195 
 
2025-08-06 
- 1) w przypadku określonym w art. 1011 § 1; 
- 2) jeżeli odrębne przepisy stanowią inaczej.

***
## Art. 27. {#kp-drugi-art-27}

(uchylony)

***
## Art. 28. {#kp-drugi-art-28}

(uchylony)

***
## Art. 29. {#kp-drugi-art-29}

**§ 1.** Umowa o pracę określa strony umowy, adres siedziby 
pracodawcy, 
a w przypadku 
pracodawcy 
będącego 
osobą 
fizyczną 
nieposiadającego siedziby – adres zamieszkania, a także rodzaj umowy, datę jej 
zawarcia oraz warunki pracy i płacy, w szczególności: 
- 1) rodzaj pracy; 
- 2) miejsce lub miejsca wykonywania pracy; 
- 3) wynagrodzenie za pracę odpowiadające rodzajowi pracy, ze wskazaniem 
składników wynagrodzenia; 
- 4) wymiar czasu pracy; 
- 5) dzień rozpoczęcia pracy; 
- 6) w przypadku umowy o pracę na okres próbny: 
  - a) czas jej trwania lub dzień jej zakończenia oraz, gdy strony tak uzgodnią, 
postanowienie o przedłużeniu umowy o czas urlopu, a także o czas innej 
usprawiedliwionej nieobecności pracownika w pracy, jeżeli wystąpią 
takie nieobecności, 
  - b) okres, na który strony mają zamiar zawrzeć umowę o pracę na czas 
określony w przypadku, o którym mowa w art. 25 § 22, a także 
postanowienie o wydłużeniu umowy w przypadku, o którym mowa 
w art. 25 § 23; 
- 7) w przypadku umowy o pracę na czas określony – czas jej trwania lub dzień jej 
zakończenia. 
**§ 11.** W przypadku zawarcia umowy o pracę na czas określony w celu, 
o którym mowa w art. 251 § 4 pkt 1–3, lub w przypadku, o którym mowa w art. 251 
§ 4 pkt 4, w umowie określa się ten cel lub okoliczności tego przypadku, przez 
zamieszczenie informacji o obiektywnych przyczynach uzasadniających zawarcie 
takiej umowy. 
**§ 2.** Umowę o pracę zawiera się na piśmie. Jeżeli umowa o pracę nie została 
zawarta z zachowaniem formy pisemnej, pracodawca przed dopuszczeniem 

 
 
 
s. 27/195 
 
2025-08-06 
 
pracownika do pracy potwierdza pracownikowi na piśmie ustalenia co do stron 
umowy, rodzaju umowy oraz jej warunków. 
**§ 3.** Pracodawca 
informuje 
pracownika 
w postaci 
papierowej 
lub 
elektronicznej: 
- 1) nie później niż w terminie 7 dni od dnia dopuszczenia pracownika do pracy, 
co najmniej o: 
  - a) obowiązującej pracownika dobowej i tygodniowej normie czasu pracy, 
  - b) obowiązującym pracownika dobowym i tygodniowym wymiarze czasu 
pracy, 
  - c) przysługujących pracownikowi przerwach w pracy, 
  - d) przysługującym pracownikowi dobowym i tygodniowym odpoczynku, 
  - e) zasadach 
dotyczących 
pracy 
w godzinach 
nadliczbowych 
i rekompensaty za nią, 
  - f) w przypadku pracy zmianowej – zasadach dotyczących przechodzenia ze 
zmiany na zmianę, 
  - g) w przypadku kilku miejsc wykonywania pracy – zasadach dotyczących 
przemieszczania się między miejscami wykonywania pracy, 
  - h) innych 
niż 
uzgodnione 
w umowie 
o pracę 
przysługujących 
pracownikowi 
składnikach 
wynagrodzenia 
oraz 
świadczeniach 
pieniężnych lub rzeczowych, 
  - i) wymiarze 
przysługującego 
pracownikowi 
płatnego 
urlopu, 
w szczególności urlopu wypoczynkowego lub, jeżeli nie jest możliwe 
jego określenie w dacie przekazywania pracownikowi tej informacji, 
o zasadach jego ustalania i przyznawania, 
  - j) obowiązujących 
zasadach 
rozwiązania 
stosunku 
pracy, 
w tym 
o wymogach formalnych, długości okresów wypowiedzenia oraz 
terminie odwołania się do sądu pracy lub, jeżeli nie jest możliwe 
określenie długości okresów wypowiedzenia w dacie przekazywania 
pracownikowi tej informacji, sposobie ustalania takich okresów 
wypowiedzenia, 
  - k) prawie pracownika do szkoleń, jeżeli pracodawca je zapewnia, 
w szczególności 
o ogólnych 
zasadach 
polityki 
szkoleniowej 
pracodawcy, 

 
 
 
s. 28/195 
 
2025-08-06 
  - l) układzie zbiorowym pracy lub innym porozumieniu zbiorowym, którym 
pracownik 
jest 
objęty, 
a w przypadku 
zawarcia 
porozumienia 
zbiorowego poza zakładem pracy przez wspólne organy lub instytucje – 
nazwie takich organów lub instytucji, 
  - m) w przypadku gdy pracodawca nie ustalił regulaminu pracy – terminie, 
miejscu, czasie i częstotliwości wypłacania wynagrodzenia za pracę, 
porze nocnej oraz 
przyjętym 
u danego 
pracodawcy sposobie 
potwierdzania przez pracowników przybycia i obecności w pracy oraz 
usprawiedliwiania nieobecności w pracy; 
- 2) nie później niż w terminie 30 dni od dnia dopuszczenia pracownika do pracy, 
o nazwie instytucji zabezpieczenia społecznego, do których wpływają składki 
na ubezpieczenia społeczne związane ze stosunkiem pracy oraz informacje na 
temat ochrony związanej z zabezpieczeniem społecznym, zapewnianej przez 
pracodawcę; nie dotyczy to przypadku, w którym pracownik dokonuje 
wyboru instytucji zabezpieczenia społecznego. 
**§ 31.** Poinformowanie pracownika o warunkach zatrudnienia, o których mowa 
w § 3 pkt 1 lit. a–f, h–k i pkt 2, może nastąpić przez wskazanie w postaci 
papierowej lub elektronicznej odpowiednich przepisów prawa pracy oraz prawa 
ubezpieczeń społecznych. 
**§ 32.** Pracodawca 
informuje 
pracownika 
w postaci 
papierowej 
lub 
elektronicznej o zmianie adresu swojej siedziby, a w przypadku pracodawcy 
będącego osobą fizyczną nieposiadającego siedziby – adresu zamieszkania, nie 
później niż w terminie 7 dni od dnia zmiany adresu. 
**§ 33.** Pracodawca 
informuje 
pracownika 
w postaci 
papierowej 
lub 
elektronicznej o zmianie warunków zatrudnienia, o których mowa w § 3, a także 
o objęciu pracownika układem zbiorowym pracy lub innym porozumieniem 
zbiorowym niezwłocznie, nie później jednak niż w dniu, w którym taka zmiana ma 
zastosowanie do pracownika. Nie dotyczy to przypadku, w którym zmiana 
warunków zatrudnienia wynika ze zmiany przepisów prawa pracy oraz prawa 
ubezpieczeń społecznych, jeżeli przepisy te zostały wskazane w informacji 
przekazanej pracownikowi. 
**§ 34.** Informacje, o których mowa w § 3–33, pracodawca może przekazać 
pracownikowi w postaci elektronicznej, jeżeli będą dostępne dla pracownika 

 
 
 
s. 29/195 
 
2025-08-06 
 
z możliwością ich wydrukowania oraz przechowywania, a pracodawca zachowa 
dowód ich przekazania lub otrzymania przez pracownika. 
**§ 4.** Zmiana warunków umowy o pracę wymaga formy pisemnej. 
**§ 5.** Przepisy § 1–4 stosuje się odpowiednio do stosunków pracy nawiązanych 
na innej podstawie niż umowa o pracę.

***
## Art. 291. {#kp-drugi-art-291}

**§ 1.** (uchylony) 
**§ 2.** Przed wyjazdem pracownika do pracy lub w celu wykonania zadania 
służbowego poza granicami kraju na okres przekraczający 4 kolejne tygodnie 
pracodawca przekazuje pracownikowi niezależnie od informacji, o których mowa 
w art. 29 § 3, informacje w postaci papierowej lub elektronicznej o: 
- 1) państwie lub państwach, w których praca lub zadanie służbowe poza 
granicami kraju mają być wykonywane; 
- 2) przewidywanym czasie trwania pracy lub zadania służbowego poza granicami 
kraju; 
- 3) walucie, w której będzie wypłacane pracownikowi wynagrodzenie w czasie 
wykonywania pracy lub zadania służbowego poza granicami kraju; 
- 4) świadczeniach pieniężnych lub rzeczowych związanych z wykonywaniem 
pracy lub zadania służbowego poza granicami kraju, jeżeli takie świadczenia 
przewidują przepisy prawa pracy lub wynika to z umowy o pracę; 
- 5) zapewnieniu lub braku zapewnienia powrotu pracownika do kraju; 
- 6) warunkach powrotu pracownika do kraju – w przypadku zapewnienia takiego 
powrotu. 
**§ 3.** Poinformowanie pracownika o warunku zatrudnienia, o którym mowa 
w § 2 pkt 3, może nastąpić przez wskazanie w postaci papierowej lub 
elektronicznej odpowiednich przepisów prawa pracy. 
**§ 4.** Pracodawca 
informuje 
pracownika 
w postaci 
papierowej 
lub 
elektronicznej o zmianie warunków zatrudnienia, o których mowa w § 2, 
niezwłocznie, nie później jednak niż w dniu, w którym taka zmiana ma 
zastosowanie do pracownika. Nie dotyczy to przypadku, w którym zmiana 
warunków zatrudnienia wynika ze zmiany przepisów prawa pracy, jeżeli przepisy 
te zostały wskazane w informacji przekazanej pracownikowi. 
**§ 5.** (uchylony) 

 
 
 
s. 30/195 
 
2025-08-06 
**§ 51.** Do informacji, o których mowa w § 2 i 3, przepis art. 29 § 34 stosuje się 
odpowiednio. 
**§ 6.** Przepisy § 2–4 i 51 stosuje się odpowiednio do stosunków pracy 
nawiązanych na innej podstawie niż umowa o pracę.

***
## Art. 292. {#kp-drugi-art-292}

**§ 1.** Zawarcie z pracownikiem umowy o pracę przewidującej 
zatrudnienie w niepełnym wymiarze czasu pracy nie może powodować ustalenia 
jego warunków pracy i płacy w sposób mniej korzystny w stosunku do 
pracowników wykonujących taką samą lub podobną pracę w pełnym wymiarze 
czasu pracy, z uwzględnieniem jednak proporcjonalności wynagrodzenia za pracę 
i innych świadczeń związanych z pracą, do wymiaru czasu pracy pracownika. 
**§ 2.** (uchylony)

***
## Art. 293. {#kp-drugi-art-293}

**§ 1.** Pracownik zatrudniony u danego pracodawcy co najmniej 
6 miesięcy może raz w roku kalendarzowym wystąpić do pracodawcy 
z wnioskiem, złożonym w postaci papierowej lub elektronicznej, o zmianę rodzaju 
umowy o pracę na umowę o pracę na czas nieokreślony lub o bardziej 
przewidywalne i bezpieczne warunki pracy, w tym polegające na zmianie rodzaju 
pracy lub zatrudnieniu w pełnym wymiarze czasu pracy. Nie dotyczy to pracownika 
zatrudnionego na podstawie umowy o pracę na okres próbny. Do okresu 
zatrudnienia pracownika u danego pracodawcy wlicza się pracownikowi okres 
zatrudnienia u poprzedniego pracodawcy, jeżeli zmiana pracodawcy nastąpiła na 
zasadach określonych w art. 231, a także w innych przypadkach, gdy z mocy 
odrębnych przepisów nowy pracodawca jest następcą prawnym w stosunkach 
pracy nawiązanych przez pracodawcę poprzednio zatrudniającego tego 
pracownika. 
**§ 2.** Pracodawca powinien, w miarę możliwości, uwzględnić wniosek 
pracownika, o którym mowa w § 1. 
**§ 3.** Pracodawca 
udziela 
pracownikowi 
w postaci 
papierowej 
lub 
elektronicznej odpowiedzi na wniosek, o którym mowa w § 1, biorąc pod uwagę 
potrzeby pracodawcy i pracownika, nie później niż w terminie 1 miesiąca od dnia 
otrzymania wniosku; w razie nieuwzględnienia wniosku pracodawca informuje 
pracownika o przyczynie odmowy. 

 
 
 
s. 31/195 
 
2025-08-06

***
## Art. 294. {#kp-drugi-art-294}

**§ 1.** Przyczyny uzasadniającej wypowiedzenie umowy o pracę lub 
jej rozwiązanie bez wypowiedzenia przez pracodawcę, przyczyny uzasadniającej 
przygotowanie do wypowiedzenia lub rozwiązania umowy bez wypowiedzenia 
albo 
przyczyny 
zastosowania 
działania 
mającego 
skutek 
równoważny 
z rozwiązaniem umowy o pracę nie może stanowić: 
- 1) wystąpienie przez pracownika z wnioskiem, o którym mowa w art. 293 § 1; 
- 2) jednoczesne pozostawanie w stosunku pracy z innym pracodawcą lub 
jednoczesne pozostawanie w stosunku prawnym będącym podstawą 
świadczenia pracy innym niż stosunek pracy, chyba że ograniczenia w tym 
zakresie wynikają z odrębnych przepisów albo zachodzi przypadek określony 
w art. 1011 § 1; 
- 3) dochodzenie przez pracownika udzielenia informacji, o których mowa 
w art. 29 § 3, 32 i 33 oraz art. 291 § 2 i 4; 
- 4) skorzystanie z praw, o których mowa w art. 9413. 
**§ 2.** Pracodawca udowodni, że przy rozwiązywaniu umowy o pracę lub 
zastosowaniu działania mającego skutek równoważny z rozwiązaniem umowy 
o pracę kierował się powodami innymi niż wskazane w § 1. 
**§ 3.** Jeżeli pracownik uważa, że przyczyną rozwiązania umowy o pracę na 
okres próbny za wypowiedzeniem albo zastosowania działania mającego skutek 
równoważny z rozwiązaniem umowy o pracę było jednoczesne pozostawanie 
w stosunku pracy z innym pracodawcą lub jednoczesne pozostawanie w stosunku 
prawnym innym niż stosunek pracy, lub dochodzenie udzielenia informacji, 
o których mowa w art. 29 § 3, 32 i 33 oraz art. 291 § 2 i 4, lub skorzystanie z praw, 
o których mowa w art. 9413, może, w terminie 7 dni od dnia złożenia oświadczenia 
woli pracodawcy o rozwiązaniu umowy o pracę na okres próbny za 
wypowiedzeniem albo zastosowania działania mającego skutek równoważny 
z rozwiązaniem umowy o pracę, złożyć do pracodawcy wniosek w postaci 
papierowej lub elektronicznej o wskazanie przyczyny uzasadniającej to 
rozwiązanie umowy o pracę albo zastosowanie działania. 
**§ 4.** Pracodawca udziela pracownikowi odpowiedzi na wniosek, o którym 
mowa w § 3, w postaci papierowej lub elektronicznej w terminie 7 dni od dnia 
złożenia przez pracownika wniosku. 

 
 
 
s. 32/195 
 
2025-08-06 
 
Oddział 2 
Przepisy ogólne o rozwiązaniu umowy o pracę

***
## Art. 30. {#kp-drugi-art-30}

**§ 1.** Umowa o pracę rozwiązuje się: 
- 1) na mocy porozumienia stron; 
- 2) przez oświadczenie jednej ze stron z zachowaniem okresu wypowiedzenia 
(rozwiązanie umowy o pracę za wypowiedzeniem); 
- 3) przez oświadczenie jednej ze stron bez zachowania okresu wypowiedzenia 
(rozwiązanie umowy o pracę bez wypowiedzenia); 
- 4) z upływem czasu, na który była zawarta. 
- 5) (uchylony) 
**§ 2.** Umowa o pracę na okres próbny rozwiązuje się z upływem tego okresu, 
a przed jego upływem może być rozwiązana za wypowiedzeniem. 
**§ 21.** Okres wypowiedzenia umowy o pracę obejmujący tydzień lub miesiąc 
albo ich wielokrotność kończy się odpowiednio w sobotę lub w ostatnim dniu 
miesiąca. 
**§ 3.** Oświadczenie każdej ze stron o wypowiedzeniu lub rozwiązaniu umowy 
o pracę bez wypowiedzenia powinno nastąpić na piśmie. 
**§ 4.** W oświadczeniu pracodawcy o wypowiedzeniu umowy o pracę zawartej 
na czas określony lub umowy o pracę zawartej na czas nieokreślony lub 
o rozwiązaniu umowy o pracę bez wypowiedzenia powinna być wskazana 
przyczyna uzasadniająca wypowiedzenie lub rozwiązanie umowy. 
**§ 5.** W oświadczeniu pracodawcy o wypowiedzeniu umowy o pracę lub jej 
rozwiązaniu 
bez 
wypowiedzenia 
powinno 
być 
zawarte 
pouczenie 
o przysługującym pracownikowi prawie odwołania do sądu pracy.

***
## Art. 31. {#kp-drugi-art-31}

(uchylony) 
Oddział 3 
Rozwiązanie umowy o pracę za wypowiedzeniem

***
## Art. 32. {#kp-drugi-art-32}

**§ 1.** Każda ze stron może rozwiązać umowę o pracę za 
wypowiedzeniem. 
**§ 2.** Rozwiązanie 
umowy 
o pracę 
następuje 
z upływem 
okresu 
wypowiedzenia. 

 
 
 
s. 33/195 
 
2025-08-06

***
## Art. 33. {#kp-drugi-art-33}

(uchylony)

***
## Art. 331. {#kp-drugi-art-331}

(uchylony)

***
## Art. 34. {#kp-drugi-art-34}

Okres wypowiedzenia umowy o pracę zawartej na okres próbny 
wynosi: 
- 1) 3 dni robocze, jeżeli okres próbny nie przekracza 2 tygodni; 
- 2) 1 tydzień, jeżeli okres próbny jest dłuższy niż 2 tygodnie; 
- 3) 2 tygodnie, jeżeli okres próbny wynosi 3 miesiące.

***
## Art. 35. {#kp-drugi-art-35}

(uchylony)

***
## Art. 36. {#kp-drugi-art-36}

**§ 1.** Okres wypowiedzenia umowy o pracę zawartej na czas 
nieokreślony i umowy o pracę zawartej na czas określony jest uzależniony od 
okresu zatrudnienia u danego pracodawcy i wynosi: 
- 1) 2 tygodnie, jeżeli pracownik był zatrudniony krócej niż 6 miesięcy; 
- 2) 1 miesiąc, jeżeli pracownik był zatrudniony co najmniej 6 miesięcy; 
- 3) 3 miesiące, jeżeli pracownik był zatrudniony co najmniej 3 lata. 
**§ 11.** Do okresu zatrudnienia, o którym mowa w § 1, wlicza się pracownikowi 
okres zatrudnienia u poprzedniego pracodawcy, jeżeli zmiana pracodawcy 
nastąpiła na zasadach określonych w art. 231, a także w innych przypadkach, gdy 
z mocy odrębnych przepisów nowy pracodawca jest następcą prawnym 
w stosunkach pracy nawiązanych przez pracodawcę poprzednio zatrudniającego 
tego pracownika. 
**§ 2.** (uchylony) 
**§ 3.** (uchylony) 
**§ 4.** (uchylony) 
**§ 5.** Jeżeli 
pracownik 
jest 
zatrudniony 
na 
stanowisku 
związanym 
z odpowiedzialnością materialną za powierzone mienie, strony mogą ustalić 
w umowie o pracę, że w przypadku, o którym mowa w § 1 pkt 1, okres 
wypowiedzenia wynosi 1 miesiąc, a w przypadku, o którym mowa w § 1 pkt 2 – 
3 miesiące. 
**§ 6.** Strony mogą po dokonaniu wypowiedzenia umowy o pracę przez jedną 
z nich ustalić wcześniejszy termin rozwiązania umowy; ustalenie takie nie zmienia 
trybu rozwiązania umowy o pracę. 

 
 
 
s. 34/195 
 
2025-08-06

***
## Art. 361. {#kp-drugi-art-361}

**§ 1.** Jeżeli wypowiedzenie pracownikowi umowy o pracę zawartej 
na czas nieokreślony lub umowy o pracę zawartej na czas określony następuje 
z powodu ogłoszenia upadłości lub likwidacji pracodawcy albo z innych przyczyn 
niedotyczących pracowników, pracodawca może, w celu wcześniejszego 
rozwiązania umowy o pracę, skrócić okres trzymiesięcznego wypowiedzenia, 
najwyżej jednak do 1 miesiąca. W takim przypadku pracownikowi przysługuje 
odszkodowanie w wysokości wynagrodzenia za pozostałą część okresu 
wypowiedzenia. 
**§ 2.** Okres, za który przysługuje odszkodowanie, wlicza się pracownikowi 
pozostającemu w tym okresie bez pracy do okresu zatrudnienia.

***
## Art. 362. {#kp-drugi-art-362}

W związku z wypowiedzeniem umowy o pracę pracodawca może 
zwolnić pracownika z obowiązku świadczenia pracy do upływu okresu 
wypowiedzenia. W okresie tego zwolnienia pracownik zachowuje prawo do 
wynagrodzenia.

***
## Art. 37. {#kp-drugi-art-37}

**§ 1.** W okresie co najmniej dwutygodniowego wypowiedzenia 
umowy o pracę dokonanego przez pracodawcę pracownikowi przysługuje 
zwolnienie na poszukiwanie pracy, z zachowaniem prawa do wynagrodzenia. 
**§ 2.** Wymiar zwolnienia wynosi: 
- 1) 2 dni 
robocze 
– 
w okresie 
dwutygodniowego 
i jednomiesięcznego 
wypowiedzenia; 
- 2) 3 dni robocze – w okresie trzymiesięcznego wypowiedzenia, także 
w przypadku jego skrócenia na podstawie art. 361 § 1.

***
## Art. 38. {#kp-drugi-art-38}

**§ 1.** O zamiarze wypowiedzenia pracownikowi umowy o pracę 
zawartej na czas określony lub umowy o pracę zawartej na czas nieokreślony 
pracodawca zawiadamia na piśmie reprezentującą pracownika zakładową 
organizację związkową, podając przyczynę uzasadniającą rozwiązanie umowy. 
**§ 2.** Jeżeli zakładowa organizacja związkowa uważa, że wypowiedzenie 
byłoby nieuzasadnione, może w ciągu 5 dni od otrzymania zawiadomienia zgłosić 
na piśmie pracodawcy umotywowane zastrzeżenia. 
**§ 3.** (uchylony) 
**§ 4.** (uchylony) 

 
 
 
s. 35/195 
 
2025-08-06 
**§ 5.** Po rozpatrzeniu stanowiska organizacji związkowej, a także w razie 
niezajęcia przez nią stanowiska w ustalonym terminie, pracodawca podejmuje 
decyzję w sprawie wypowiedzenia.

***
## Art. 39. {#kp-drugi-art-39}

Pracodawca nie może wypowiedzieć umowy o pracę pracownikowi, 
któremu brakuje nie więcej niż 4 lata do osiągnięcia wieku emerytalnego, jeżeli 
okres zatrudnienia umożliwia mu uzyskanie prawa do emerytury z osiągnięciem 
tego wieku.

***
## Art. 40. {#kp-drugi-art-40}

Przepisu art. 39 nie stosuje się w razie uzyskania przez pracownika 
prawa do renty z tytułu całkowitej niezdolności do pracy.

***
## Art. 41. {#kp-drugi-art-41}

Pracodawca nie może wypowiedzieć umowy o pracę w czasie urlopu 
pracownika, a także w czasie innej usprawiedliwionej nieobecności pracownika 
w pracy, jeżeli nie upłynął jeszcze okres uprawniający do rozwiązania umowy 
o pracę bez wypowiedzenia.

***
## Art. 411. {#kp-drugi-art-411}

**§ 1.** W razie ogłoszenia upadłości lub likwidacji pracodawcy, nie 
stosuje się przepisów art. 38, 39 i 41, ani przepisów szczególnych dotyczących 
ochrony pracowników przed wypowiedzeniem lub rozwiązaniem umowy o pracę. 
**§ 2.** (uchylony) 
**§ 3.** (uchylony) 
**§ 4.** (uchylony)

***
## Art. 42. {#kp-drugi-art-42}

**§ 1.** Przepisy o wypowiedzeniu umowy o pracę stosuje się 
odpowiednio do wypowiedzenia wynikających z umowy warunków pracy i płacy. 
**§ 2.** Wypowiedzenie warunków pracy lub płacy uważa się za dokonane, jeżeli 
pracownikowi zaproponowano na piśmie nowe warunki. 
**§ 3.** W razie odmowy przyjęcia przez pracownika zaproponowanych 
warunków pracy lub płacy, umowa o pracę rozwiązuje się z upływem okresu 
dokonanego wypowiedzenia. Jeżeli pracownik przed upływem połowy okresu 
wypowiedzenia nie złoży oświadczenia o odmowie przyjęcia zaproponowanych 
warunków, uważa się, że wyraził zgodę na te warunki; pismo pracodawcy 
wypowiadające warunki pracy lub płacy powinno zawierać pouczenie w tej 
sprawie. W razie braku takiego pouczenia, pracownik może do końca okresu 
wypowiedzenia złożyć oświadczenie o odmowie przyjęcia zaproponowanych 
warunków. 

 
 
 
s. 36/195 
 
2025-08-06 
**§ 4.** Wypowiedzenie dotychczasowych warunków pracy lub płacy nie jest 
wymagane w razie powierzenia pracownikowi, w przypadkach uzasadnionych 
potrzebami pracodawcy, innej pracy niż określona w umowie o pracę na okres 
nieprzekraczający 3 miesięcy w roku kalendarzowym, jeżeli nie powoduje to 
obniżenia wynagrodzenia i odpowiada kwalifikacjom pracownika.

***
## Art. 43. {#kp-drugi-art-43}

Pracodawca może wypowiedzieć warunki pracy lub płacy 
pracownikowi, o którym mowa w art. 39, jeżeli wypowiedzenie stało się konieczne 
ze względu na: 
- 1) wprowadzenie 
nowych 
zasad 
wynagradzania 
dotyczących 
ogółu 
pracowników zatrudnionych u danego pracodawcy lub tej ich grupy, do której 
pracownik należy; 
- 2) stwierdzoną orzeczeniem lekarskim utratę zdolności do wykonywania 
dotychczasowej pracy albo niezawinioną przez pracownika utratę uprawnień 
koniecznych do jej wykonywania. 
Oddział 4 
Uprawnienia pracownika w razie nieuzasadnionego lub niezgodnego 
z prawem  
wypowiedzenia umowy o pracę przez pracodawcę

***
## Art. 44. {#kp-drugi-art-44}

Pracownik może wnieść odwołanie od wypowiedzenia umowy 
o pracę do sądu pracy, o którym mowa w dziale dwunastym.

***
## Art. 45. {#kp-drugi-art-45}

**§ 1.** W razie ustalenia, że wypowiedzenie umowy o pracę zawartej na 
czas określony lub umowy o pracę zawartej na czas nieokreślony jest 
nieuzasadnione lub narusza przepisy o wypowiadaniu umów o pracę, sąd pracy – 
stosownie do żądania pracownika – orzeka o bezskuteczności wypowiedzenia, 
a jeżeli umowa uległa już rozwiązaniu – o przywróceniu pracownika do pracy na 
poprzednich warunkach albo o odszkodowaniu. 
**§ 2.** Sąd pracy może nie uwzględnić żądania pracownika uznania 
wypowiedzenia za bezskuteczne lub przywrócenia do pracy, jeżeli ustali, że 
uwzględnienie takiego żądania jest niemożliwe lub niecelowe; w takim przypadku 
sąd pracy orzeka o odszkodowaniu. Jeżeli przed wydaniem orzeczenia upłynął 
termin, do którego umowa o pracę zawarta na czas określony miała trwać, lub jeżeli 

 
 
 
s. 37/195 
 
2025-08-06 
 
przywrócenie do pracy byłoby niewskazane ze względu na krótki okres, jaki 
pozostał do upływu tego terminu, pracownikowi przysługuje wyłącznie 
odszkodowanie. 
**§ 3.** Przepisu § 2 zdanie pierwsze nie stosuje się do pracowników, o których 
mowa w art. 39 i 177, oraz w przepisach szczególnych dotyczących ochrony 
pracowników przed wypowiedzeniem lub rozwiązaniem umowy o pracę, chyba że 
uwzględnienie żądania pracownika przywrócenia do pracy jest niemożliwe 
z przyczyn określonych w art. 411; w takim przypadku sąd pracy orzeka 
o odszkodowaniu.

***
## Art. 46. {#kp-drugi-art-46}

(uchylony)

***
## Art. 47. {#kp-drugi-art-47}

Pracownikowi, który podjął pracę w wyniku przywrócenia do pracy, 
przysługuje wynagrodzenie za czas pozostawania bez pracy, nie więcej jednak niż 
za 2 miesiące, a gdy okres wypowiedzenia wynosił 3 miesiące – nie więcej niż za 
1 miesiąc. Jeżeli umowę o pracę rozwiązano z pracownikiem, o którym mowa 
w art. 39, 
albo 
z pracownicą 
w okresie 
ciąży 
oraz 
w okresie 
urlopu 
macierzyńskiego lub od dnia złożenia przez pracownika wniosku o udzielenie 
urlopu macierzyńskiego albo jego części – do dnia zakończenia tego urlopu, 
wynagrodzenie przysługuje za cały czas pozostawania bez pracy. Dotyczy to także 
przypadku, gdy rozwiązanie umowy o pracę podlega ograniczeniu z mocy przepisu 
szczególnego.

***
## Art. 471. {#kp-drugi-art-471}

Odszkodowanie, 
o którym 
mowa 
w art. 45, 
przysługuje 
w wysokości wynagrodzenia za okres od 2 tygodni do 3 miesięcy, nie niższej 
jednak od wynagrodzenia za okres wypowiedzenia. W przypadku wypowiedzenia 
umowy o pracę zawartej na czas określony, której termin, do którego umowa ta 
miała trwać, określony w umowie upłynął przed wydaniem orzeczenia przez sąd 
pracy, lub gdy przywrócenie do pracy byłoby niewskazane ze względu na krótki 
okres, jaki pozostał do upływu tego terminu, odszkodowanie przysługuje 
w wysokości wynagrodzenia za czas, do upływu którego umowa miała trwać, nie 
więcej jednak niż za okres 3 miesięcy.

***
## Art. 48. {#kp-drugi-art-48}

**§ 1.** Pracodawca 
może 
odmówić 
ponownego 
zatrudnienia 
pracownika, jeżeli w ciągu 7 dni od przywrócenia do pracy nie zgłosił on gotowości 

 
 
 
s. 38/195 
 
2025-08-06 
 
niezwłocznego podjęcia pracy, chyba że przekroczenie terminu nastąpiło 
z przyczyn niezależnych od pracownika. 
**§ 2.** Pracownik, który przed przywróceniem do pracy podjął zatrudnienie 
u innego pracodawcy, może bez wypowiedzenia, za trzydniowym uprzedzeniem, 
rozwiązać umowę o pracę z tym pracodawcą w ciągu 7 dni od przywrócenia do 
pracy. Rozwiązanie umowy w tym trybie pociąga za sobą skutki, jakie przepisy 
prawa 
wiążą 
z rozwiązaniem 
umowy 
o pracę 
przez 
pracodawcę 
za 
wypowiedzeniem.

***
## Art. 49. {#kp-drugi-art-49}

W razie zastosowania okresu wypowiedzenia krótszego niż 
wymagany, umowa o pracę rozwiązuje się z upływem okresu wymaganego, 
a pracownikowi przysługuje wynagrodzenie do czasu rozwiązania umowy.

***
## Art. 50. {#kp-drugi-art-50}

**§ 1.** Jeżeli wypowiedzenie umowy o pracę zawartej na okres próbny 
nastąpiło z naruszeniem przepisów o wypowiadaniu tych umów, pracownikowi 
przysługuje wyłącznie odszkodowanie. Odszkodowanie przysługuje w wysokości 
wynagrodzenia za czas, do upływu którego umowa miała trwać. 
**§ 2.** (uchylony) 
**§ 3.** (uchylony) 
**§ 4.** (uchylony) 
**§ 5.** (uchylony)

***
## Art. 51. {#kp-drugi-art-51}

**§ 1.** Pracownikowi, który podjął pracę w wyniku przywrócenia do 
pracy, wlicza się do okresu zatrudnienia okres pozostawania bez pracy, za który 
przyznano wynagrodzenie. Okresu pozostawania bez pracy, za który nie przyznano 
wynagrodzenia, nie uważa się za przerwę w zatrudnieniu, pociągającą za sobą 
utratę uprawnień uzależnionych od nieprzerwanego zatrudnienia. 
**§ 2.** Pracownikowi, któremu przyznano odszkodowanie, wlicza się do okresu 
zatrudnienia okres pozostawania bez pracy, odpowiadający okresowi, za który 
przyznano odszkodowanie. 
Oddział 5 
Rozwiązanie umowy o pracę bez wypowiedzenia

***
## Art. 52. {#kp-drugi-art-52}

**§ 1.** Pracodawca może rozwiązać umowę o pracę bez wypowiedzenia 
z winy pracownika w razie: 

 
 
 
s. 39/195 
 
2025-08-06 
- 1) ciężkiego naruszenia przez pracownika podstawowych obowiązków 
pracowniczych; 
- 2) popełnienia przez pracownika w czasie trwania umowy o pracę przestępstwa, 
które uniemożliwia dalsze zatrudnianie go na zajmowanym stanowisku, jeżeli 
przestępstwo jest oczywiste lub zostało stwierdzone prawomocnym 
wyrokiem; 
- 3) zawinionej przez pracownika utraty uprawnień koniecznych do wykonywania 
pracy na zajmowanym stanowisku. 
**§ 2.** Rozwiązanie umowy o pracę bez wypowiedzenia z winy pracownika nie 
może nastąpić po upływie 1 miesiąca od uzyskania przez pracodawcę wiadomości 
o okoliczności uzasadniającej rozwiązanie umowy. 
**§ 3.** Pracodawca podejmuje decyzję w sprawie rozwiązania umowy po 
zasięgnięciu 
opinii 
reprezentującej 
pracownika 
zakładowej 
organizacji 
związkowej, którą zawiadamia o przyczynie uzasadniającej rozwiązanie umowy. 
W razie zastrzeżeń co do zasadności rozwiązania umowy zakładowa organizacja 
związkowa wyraża swoją opinię niezwłocznie, nie później jednak niż w ciągu 
3 dni. 
**§ 4.** (uchylony)

***
## Art. 53. {#kp-drugi-art-53}

**§ 1.** Pracodawca 
może 
rozwiązać 
umowę 
o pracę 
bez 
wypowiedzenia: 
- 1) jeżeli niezdolność pracownika do pracy wskutek choroby trwa: 
  - a) dłużej niż 3 miesiące – gdy pracownik był zatrudniony u danego 
pracodawcy krócej niż 6 miesięcy, 
  - b) dłużej niż łączny okres pobierania z tego tytułu wynagrodzenia i zasiłku 
oraz pobierania świadczenia rehabilitacyjnego przez pierwsze 3 miesiące 
– gdy pracownik był zatrudniony u danego pracodawcy co najmniej 
6 miesięcy lub jeżeli niezdolność do pracy została spowodowana 
wypadkiem przy pracy albo chorobą zawodową; 
- 2) w razie usprawiedliwionej nieobecności pracownika w pracy z innych 
przyczyn niż wymienione w pkt 1, trwającej dłużej niż 1 miesiąc. 
**§ 2.** Rozwiązanie umowy o pracę bez wypowiedzenia nie może nastąpić 
w razie nieobecności pracownika w pracy z powodu sprawowania opieki nad 
dzieckiem – w okresie pobierania z tego tytułu zasiłku, a w przypadku 

 
 
 
s. 40/195 
 
2025-08-06 
 
odosobnienia pracownika ze względu na chorobę zakaźną – w okresie pobierania 
z tego tytułu wynagrodzenia i zasiłku. 
**§ 3.** Rozwiązanie umowy o pracę bez wypowiedzenia nie może nastąpić po 
stawieniu się pracownika do pracy w związku z ustaniem przyczyny nieobecności. 
**§ 4.** Przepisy art. 36 § 11 i art. 52 § 3 stosuje się odpowiednio. 
**§ 5.** Pracodawca powinien w miarę możliwości ponownie zatrudnić 
pracownika, który w okresie 6 miesięcy od rozwiązania umowy o pracę bez 
wypowiedzenia, z przyczyn wymienionych w § 1 i 2, zgłosi swój powrót do pracy 
niezwłocznie po ustaniu tych przyczyn.

***
## Art. 54. {#kp-drugi-art-54}

(uchylony)

***
## Art. 55. {#kp-drugi-art-55}

**§ 1.** Pracownik może rozwiązać umowę o pracę bez wypowiedzenia, 
jeżeli zostanie wydane orzeczenie lekarskie stwierdzające szkodliwy wpływ 
wykonywanej pracy na zdrowie pracownika, a pracodawca nie przeniesie go 
w terminie wskazanym w orzeczeniu lekarskim do innej pracy, odpowiedniej ze 
względu na stan jego zdrowia i kwalifikacje zawodowe. 
**§ 11.** Pracownik może rozwiązać umowę o pracę w trybie określonym 
w § 1 także wtedy, gdy pracodawca dopuścił się ciężkiego naruszenia 
podstawowych obowiązków wobec pracownika; w takim przypadku pracownikowi 
przysługuje odszkodowanie w wysokości wynagrodzenia za okres wypowiedzenia. 
W przypadku rozwiązania umowy o pracę zawartej na czas określony 
odszkodowanie przysługuje w wysokości wynagrodzenia za czas, do którego 
umowa miała trwać, nie więcej jednak niż za okres wypowiedzenia. 
**§ 2.** Oświadczenie 
pracownika 
o rozwiązaniu 
umowy 
o pracę 
bez 
wypowiedzenia powinno nastąpić na piśmie, z podaniem przyczyny uzasadniającej 
rozwiązanie umowy. Przepis art. 52 § 2 stosuje się odpowiednio. 
**§ 3.** Rozwiązanie umowy o pracę z przyczyn określonych w § 1 i 11 pociąga 
za sobą skutki, jakie przepisy prawa wiążą z rozwiązaniem umowy przez 
pracodawcę za wypowiedzeniem. 

 
 
 
s. 41/195 
 
2025-08-06 
 
Oddział 6 
Uprawnienia pracownika w razie niezgodnego z prawem rozwiązania przez 
pracodawcę  
umowy o pracę bez wypowiedzenia

***
## Art. 56. {#kp-drugi-art-56}

**§ 1.** Pracownikowi, z którym rozwiązano umowę o pracę bez 
wypowiedzenia z naruszeniem przepisów o rozwiązywaniu umów o pracę w tym 
trybie, przysługuje roszczenie o przywrócenie do pracy na poprzednich warunkach 
albo o odszkodowanie. O przywróceniu do pracy lub odszkodowaniu orzeka sąd 
pracy. 
**§ 2.** Przepisy art. 45 § 2 i 3 stosuje się odpowiednio.

***
## Art. 57. {#kp-drugi-art-57}

**§ 1.** Pracownikowi, który podjął pracę w wyniku przywrócenia do 
pracy, przysługuje wynagrodzenie za czas pozostawania bez pracy, nie więcej 
jednak niż za 3 miesiące i nie mniej niż za 1 miesiąc. 
**§ 2.** Jeżeli umowę o pracę rozwiązano z pracownikiem, o którym mowa 
w art. 39, 
albo 
z pracownicą 
w okresie 
ciąży 
oraz 
w okresie 
urlopu 
macierzyńskiego lub od dnia złożenia przez pracownika wniosku o udzielenie 
urlopu macierzyńskiego albo jego części – do dnia zakończenia tego urlopu, 
wynagrodzenie przysługuje za cały czas pozostawania bez pracy. Dotyczy to także 
przypadku, gdy rozwiązanie umowy o pracę podlega ograniczeniu z mocy przepisu 
szczególnego. 
**§ 3.** (uchylony) 
**§ 4.** Przepisy art. 48 i 51 § 1 stosuje się odpowiednio.

***
## Art. 58. {#kp-drugi-art-58}

Odszkodowanie, o którym mowa w art. 56, przysługuje w wysokości 
wynagrodzenia za okres wypowiedzenia. W przypadku rozwiązania umowy 
o pracę zawartej na czas określony odszkodowanie przysługuje w wysokości 
wynagrodzenia za czas, do którego umowa miała trwać, nie więcej jednak niż za 
okres wypowiedzenia.

***
## Art. 59. {#kp-drugi-art-59}

W razie rozwiązania przez pracodawcę umowy o pracę zawartej na 
czas określony z naruszeniem przepisów o rozwiązywaniu umów o pracę bez 
wypowiedzenia pracownikowi przysługuje wyłącznie odszkodowanie, jeżeli 
upłynął już termin, do którego umowa miała trwać, lub gdy przywrócenie do pracy 

 
 
 
s. 42/195 
 
2025-08-06 
 
byłoby niewskazane ze względu na krótki okres, jaki pozostał do upływu tego 
terminu. W tym przypadku odszkodowanie przysługuje w wysokości określonej 
w art. 58.

***
## Art. 60. {#kp-drugi-art-60}

Jeżeli 
pracodawca 
rozwiązał 
umowę 
o pracę 
w okresie 
wypowiedzenia z naruszeniem przepisów o rozwiązywaniu umów o pracę bez 
wypowiedzenia, 
pracownikowi 
przysługuje 
wyłącznie 
odszkodowanie. 
Odszkodowanie przysługuje w wysokości wynagrodzenia za czas do upływu 
okresu wypowiedzenia.

***
## Art. 61. {#kp-drugi-art-61}

Do pracownika, któremu przyznano odszkodowanie na podstawie 
przepisów niniejszego oddziału, stosuje się odpowiednio przepis art. 51 § 2. 
Oddział 6a 
Uprawnienia pracodawcy w razie nieuzasadnionego rozwiązania przez 
pracownika umowy o pracę bez wypowiedzenia

***
## Art. 611. {#kp-drugi-art-611}

W razie nieuzasadnionego rozwiązania przez pracownika umowy 
o pracę bez wypowiedzenia na podstawie art. 55 § 11, pracodawcy przysługuje 
roszczenie o odszkodowanie. O odszkodowaniu orzeka sąd pracy.

***
## Art. 612. {#kp-drugi-art-612}

**§ 1.** Odszkodowanie, o którym mowa w art. 611, przysługuje 
w wysokości wynagrodzenia pracownika za okres wypowiedzenia. W przypadku 
rozwiązania umowy o pracę zawartej na czas określony, odszkodowanie 
przysługuje w wysokości wynagrodzenia za czas, do którego umowa miała trwać, 
nie więcej jednak niż za okres wypowiedzenia. 
**§ 2.** W razie orzeczenia przez sąd pracy o odszkodowaniu, przepisu art. 55 
§ 3 nie stosuje się.

***
## Art. 62. {#kp-drugi-art-62}

(uchylony) 
Oddział 7 
Wygaśnięcie umowy o pracę

***
## Art. 63. {#kp-drugi-art-63}

Umowa o pracę wygasa w przypadkach określonych w kodeksie oraz 
w przepisach szczególnych.

***
## Art. 631. {#kp-drugi-art-631}

**§ 1.** Z dniem śmierci pracownika stosunek pracy wygasa. 

 
 
 
s. 43/195 
 
2025-08-06 
**§ 2.** Prawa majątkowe ze stosunku pracy przechodzą po śmierci pracownika, 
w równych częściach, na małżonka oraz inne osoby spełniające warunki wymagane 
do uzyskania renty rodzinnej w myśl przepisów o emeryturach i rentach 
z Funduszu Ubezpieczeń Społecznych. W razie braku takich osób prawa te 
wchodzą do spadku.

***
## Art. 632. {#kp-drugi-art-632}

**§ 1.** Z dniem śmierci pracodawcy umowy o pracę z pracownikami 
wygasają, z zastrzeżeniem § 3–11. 
**§ 2.** Pracownikowi, którego umowa o pracę wygasła z przyczyn określonych 
w § 1, przysługuje odszkodowanie w wysokości wynagrodzenia za okres 
wypowiedzenia. 
**§ 3.** Przepis § 1 nie ma zastosowania w przypadku: 
- 1) przejęcia pracownika przez nowego pracodawcę na zasadach określonych w 
art. 231; 
- 2) ustanowienia zarządu sukcesyjnego z chwilą śmierci pracodawcy, zgodnie z 
ustawą z dnia 5 lipca 2018 r. o zarządzie sukcesyjnym przedsiębiorstwem 
osoby fizycznej i innych ułatwieniach związanych z sukcesją przedsiębiorstw 
(Dz. U. z 2021 r. poz. 170), zwanej dalej „ustawą o zarządzie sukcesyjnym”. 
**§ 4.** W przypadku, o którym mowa w § 3 pkt 2, umowa o pracę z 
pracownikiem wygasa z dniem wygaśnięcia zarządu sukcesyjnego, chyba że przed 
tym dniem nastąpiło przejęcie pracownika przez nowego pracodawcę na zasadach 
określonych w art. 231. 
**§ 5.** W przypadku gdy zgodnie z ustawą o zarządzie sukcesyjnym nie 
ustanowiono zarządu sukcesyjnego z chwilą śmierci pracodawcy, umowa o pracę 
wygasa z upływem 30 dni od dnia śmierci pracodawcy, chyba że przed upływem 
tego terminu osoba, o której mowa w art. 14 ustawy o zarządzie sukcesyjnym, albo 
zarządca sukcesyjny uzgodni z pracownikiem, na mocy pisemnego porozumienia 
stron, że stosunek pracy będzie kontynuowany na dotychczasowych zasadach: 
- 1) do dnia ustanowienia zarządu sukcesyjnego albo wygaśnięcia uprawnienia do 
powołania zarządcy sukcesyjnego – jeżeli porozumienie z pracownikiem 
zawiera osoba, o której mowa w art. 14 ustawy o zarządzie sukcesyjnym; 
- 2) do dnia wygaśnięcia zarządu sukcesyjnego – jeżeli porozumienie z 
pracownikiem zawiera zarządca sukcesyjny. 

 
 
 
s. 44/195 
 
2025-08-06 
**§ 6.** Strony porozumienia, o którym mowa w § 5, mogą także uzgodnić 
wcześniejszy termin rozwiązania umowy o pracę. 
**§ 7.** W przypadku gdy zgodnie z ustawą o zarządzie sukcesyjnym nie 
ustanowiono zarządu sukcesyjnego z chwilą śmierci pracodawcy, umowa o pracę 
na czas określony rozwiązuje się z upływem czasu, na który została zawarta, jeżeli 
termin jej rozwiązania przypada przed upływem 30 dni od dnia śmierci 
pracodawcy, chyba że strony uzgodnią wcześniejszy termin rozwiązania umowy. 
Jeżeli termin rozwiązania umowy o pracę na czas określony przypada po upływie 
30 dni od dnia śmierci pracodawcy umowa o pracę wygasa z dniem wygaśnięcia 
zarządu sukcesyjnego albo wygaśnięcia uprawnienia do powołania zarządcy 
sukcesyjnego, chyba że wcześniej rozwiąże się z upływem czasu, na który została 
zawarta, albo strony uzgodnią wcześniejszy termin rozwiązania umowy. 
**§ 8.** Okres od dnia śmierci pracodawcy do dnia wygaśnięcia umowy o pracę 
albo dokonania uzgodnienia zgodnie z § 5 i 6, albo rozwiązania umowy o pracę 
zgodnie z § 7 jest okresem usprawiedliwionej nieobecności w pracy, za który 
pracownik nie zachowuje prawa do wynagrodzenia. 
**§ 9.** W okresie, o którym mowa w § 8, osoba, o której mowa w art. 14 ustawy 
o zarządzie sukcesyjnym, a jeżeli został ustanowiony zarząd sukcesyjny – zarządca 
sukcesyjny, może polecić pracownikowi wykonywanie pracy zgodnej z jego 
umową o pracę, określając okres wykonywania pracy przez pracownika i wymiar 
czasu pracy. 
**§ 10.** Jeżeli zgodnie z ustawą o zarządzie sukcesyjnym nie ustanowiono 
zarządu sukcesyjnego, w przypadku uzgodnienia, o którym mowa w § 5 pkt 1, 
umowy o pracę wygasają z dniem wygaśnięcia uprawnienia do powołania zarządcy 
sukcesyjnego, chyba że strony uzgodniły wcześniejszy termin rozwiązania umowy 
o pracę. 
**§ 11.** Jeżeli zgodnie z ustawą o zarządzie sukcesyjnym ustanowiono zarząd 
sukcesyjny, w przypadku uzgodnienia, o którym mowa w § 5 pkt 1, umowy o pracę 
wygasają z dniem wygaśnięcia zarządu sukcesyjnego, chyba że wcześniej nastąpiło 
przejęcie pracownika przez nowego pracodawcę na zasadach określonych w art. 
231. 
**§ 12.** W razie ponownego zatrudniania pracowników w tej samej grupie 
zawodowej zarządca sukcesyjny zatrudnia na poprzednich warunkach pracownika, 

 
 
 
s. 45/195 
 
2025-08-06 
 
którego umowa o pracę wygasła z powodu śmierci pracodawcy, jeżeli pracownik 
ten zgłosi zamiar podjęcia zatrudnienia w ciągu miesiąca od dnia ustanowienia 
zarządu sukcesyjnego.

***
## Art. 64. {#kp-drugi-art-64}

(uchylony)

***
## Art. 65. {#kp-drugi-art-65}

(uchylony)

***
## Art. 66. {#kp-drugi-art-66}

**§ 1.** Umowa o pracę wygasa z upływem 3 miesięcy nieobecności 
pracownika w pracy z powodu tymczasowego aresztowania, chyba że pracodawca 
rozwiązał wcześniej bez wypowiedzenia umowę o pracę z winy pracownika. 
**§ 2.** Pracodawca, 
pomimo 
wygaśnięcia 
umowy 
o pracę 
z powodu 
tymczasowego aresztowania, jest obowiązany ponownie zatrudnić pracownika, 
jeżeli postępowanie karne zostało umorzone lub gdy zapadł wyrok uniewinniający, 
a pracownik zgłosił swój powrót do pracy w ciągu 7 dni od uprawomocnienia się 
orzeczenia. Przepisy art. 48 stosuje się odpowiednio. 
**§ 3.** Przepisów § 2 nie stosuje się w przypadku, gdy postępowanie karne 
umorzono z powodu przedawnienia albo amnestii, a także w razie warunkowego 
umorzenia postępowania.

***
## Art. 67. {#kp-drugi-art-67}

W razie naruszenia przez pracodawcę przepisów niniejszego 
oddziału, pracownikowi przysługuje prawo odwołania do sądu pracy. W zakresie 
roszczeń stosuje się odpowiednio przepisy oddziału 6 niniejszego rozdziału. 
## Rozdział II a 
(zawierający art. 671–674 – uchylony) 
## Rozdział II b 
(zawierający art. 675–6717 – uchylony) 
## Rozdział IIc Praca zdalna

***
## Art. 6718. {#kp-drugi-art-6718}

Praca może być wykonywana całkowicie lub częściowo w miejscu 
wskazanym przez pracownika i każdorazowo uzgodnionym z pracodawcą, w tym 
pod adresem zamieszkania pracownika, w szczególności z wykorzystaniem 
środków bezpośredniego porozumiewania się na odległość (praca zdalna). 

 
 
 
s. 46/195 
 
2025-08-06

***
## Art. 6719. {#kp-drugi-art-6719}

**§ 1.** Uzgodnienie między stronami umowy o pracę dotyczące 
wykonywania pracy zdalnej przez pracownika może nastąpić: 
- 1) przy zawieraniu umowy o pracę albo 
- 2) w trakcie zatrudnienia. 
**§ 2.** W przypadku, o którym mowa w § 1 pkt 2, uzgodnienie może być 
dokonane z inicjatywy pracodawcy albo na wniosek pracownika złożony w postaci 
papierowej lub elektronicznej. Przepisu art. 29 § 4 nie stosuje się. 
**§ 3.** Praca zdalna może być wykonywana na polecenie pracodawcy: 
- 1) w okresie obowiązywania stanu nadzwyczajnego, stanu zagrożenia 
epidemicznego albo stanu epidemii oraz w okresie 3 miesięcy po ich 
odwołaniu lub 
- 2) w okresie, w którym zapewnienie przez pracodawcę bezpiecznych 
i higienicznych warunków pracy w dotychczasowym miejscu pracy 
pracownika nie jest czasowo możliwe z powodu działania siły wyższej 
– jeżeli pracownik złoży bezpośrednio przed wydaniem polecenia oświadczenie 
w postaci papierowej lub elektronicznej, że posiada warunki lokalowe i techniczne 
do wykonywania pracy zdalnej. 
**§ 4.** Pracodawca może w każdym czasie cofnąć polecenie wykonywania 
pracy zdalnej, o którym mowa w § 3, z co najmniej dwudniowym uprzedzeniem. 
**§ 5.** W przypadku 
zmiany 
warunków 
lokalowych 
i technicznych 
uniemożliwiającej wykonywanie pracy zdalnej pracownik informuje o tym 
niezwłocznie pracodawcę. W takim przypadku pracodawca niezwłocznie cofa 
polecenie wykonywania pracy zdalnej. 
**§ 6.** Pracodawca jest obowiązany uwzględnić wniosek pracownika, o którym 
mowa w art. 1421 § 1 pkt 2 i 3, pracownicy w ciąży, pracownika wychowującego 
dziecko do ukończenia przez nie 4. roku życia, a także pracownika sprawującego 
opiekę nad innym członkiem najbliższej rodziny lub inną osobą pozostającą we 
wspólnym 
gospodarstwie 
domowym, 
posiadającymi 
orzeczenie 
o niepełnosprawności albo orzeczenie o znacznym stopniu niepełnosprawności, 
o wykonywanie pracy zdalnej, chyba że nie jest to możliwe ze względu na 
organizację pracy lub rodzaj pracy wykonywanej przez pracownika. O przyczynie 
odmowy uwzględnienia wniosku pracodawca informuje pracownika w postaci 

 
 
 
s. 47/195 
 
2025-08-06 
 
papierowej lub elektronicznej w terminie 7 dni roboczych od dnia złożenia wniosku 
przez pracownika. 
**§ 7.** Przepis 
§ 6 stosuje 
się 
do 
pracowników, 
o których 
mowa 
w art. 1421 § 1 pkt 2 i 3, również po ukończeniu przez dziecko 18. roku życia.

***
## Art. 6720. {#kp-drugi-art-6720}

**§ 1.** Zasady 
wykonywania 
pracy 
zdalnej 
określa 
się 
w porozumieniu zawieranym między pracodawcą i zakładową organizacją 
związkową, a w przypadku gdy u pracodawcy działa więcej niż jedna zakładowa 
organizacja 
związkowa 
– 
w porozumieniu 
między 
pracodawcą 
a tymi 
organizacjami. 
**§ 2.** Jeżeli nie jest możliwe uzgodnienie treści porozumienia z wszystkimi 
zakładowymi 
organizacjami 
związkowymi, 
pracodawca 
uzgadnia 
treść 
porozumienia z organizacjami związkowymi reprezentatywnymi w rozumieniu 
art. 253 ust. 1 lub 2 ustawy o związkach zawodowych, z których każda zrzesza co 
najmniej 5 % pracowników zatrudnionych u pracodawcy. 
**§ 3.** Jeżeli w terminie 30 dni od dnia przedstawienia projektu porozumienia 
przez pracodawcę nie dojdzie do zawarcia porozumienia zgodnie z § 1 albo 2, 
pracodawca określa zasady wykonywania pracy zdalnej w regulaminie, 
uwzględniając ustalenia podjęte z zakładowymi organizacjami związkowymi 
w toku uzgadniania porozumienia. 
**§ 4.** Jeżeli u danego pracodawcy nie działają zakładowe organizacje 
związkowe, pracodawca określa zasady wykonywania pracy zdalnej w regulaminie 
po konsultacji z przedstawicielami pracowników wyłonionymi w trybie przyjętym 
u danego pracodawcy. 
**§ 5.** Wykonywanie pracy zdalnej jest dopuszczalne także w przypadku, gdy 
nie zostało zawarte porozumienie, o którym mowa w § 1 albo 2, albo nie został 
wydany regulamin, o którym mowa w § 3 albo 4. W takim przypadku pracodawca 
określa 
zasady 
wykonywania 
pracy 
zdalnej 
odpowiednio 
w poleceniu 
wykonywania pracy zdalnej, o którym mowa w art. 6719 § 3, albo w porozumieniu 
zawartym z pracownikiem. 
**§ 6.** W porozumieniu, o którym mowa w § 1 i 2, oraz regulaminie, o którym 
mowa w § 3 i 4, określa się w szczególności: 
- 1) grupę lub grupy pracowników, którzy mogą być objęci pracą zdalną; 

 
 
 
s. 48/195 
 
2025-08-06 
- 2) zasady 
pokrywania 
przez 
pracodawcę 
kosztów, 
o których 
mowa 
w art. 6724 § 1 pkt 2 lub 3; 
- 3) zasady ustalania ekwiwalentu pieniężnego, o którym mowa w art. 6724 § 3, 
lub ryczałtu, o którym mowa w art. 6724 § 4; 
- 4) zasady porozumiewania się pracodawcy i pracownika wykonującego pracę 
zdalną, w tym sposób potwierdzania obecności na stanowisku pracy przez 
pracownika wykonującego pracę zdalną; 
- 5) zasady kontroli wykonywania pracy przez pracownika wykonującego pracę 
zdalną; 
- 6) zasady kontroli w zakresie bezpieczeństwa i higieny pracy; 
- 7) zasady kontroli przestrzegania wymogów w zakresie bezpieczeństwa 
i ochrony informacji, w tym procedur ochrony danych osobowych; 
- 8) zasady instalacji, inwentaryzacji, konserwacji, aktualizacji oprogramowania 
i serwisu powierzonych pracownikowi narzędzi pracy, w tym urządzeń 
technicznych. 
**§ 7.** Do polecenia, o którym mowa w art. 6719 § 3, oraz porozumienia, 
o którym mowa w § 5 zdanie drugie, stosuje się odpowiednio § 6 pkt 2–8.

***
## Art. 6721. {#kp-drugi-art-6721}

**§ 1.** W przypadku wykonywania pracy zdalnej na podstawie 
art. 6719 § 1 pkt 1 informacja, o której mowa w art. 29 § 3, obejmuje dodatkowo co 
najmniej: 
- 1) określenie jednostki organizacyjnej pracodawcy, w której strukturze znajduje 
się stanowisko pracy pracownika wykonującego pracę zdalną; 
- 2) wskazanie osoby lub organu, o których mowa w art. 31, odpowiedzialnych za 
współpracę z pracownikiem wykonującym pracę zdalną oraz upoważnionych 
do przeprowadzania kontroli w miejscu wykonywania pracy zdalnej. 
**§ 2.** W przypadku wykonywania pracy zdalnej na podstawie art. 6719 § 1 pkt 2 
oraz § 3 pracodawca przekazuje pracownikowi informacje określone w § 1, 
w postaci papierowej lub elektronicznej, najpóźniej w dniu rozpoczęcia przez niego 
wykonywania pracy zdalnej.

***
## Art. 6722. {#kp-drugi-art-6722}

**§ 1.** W przypadku 
podjęcia 
pracy 
zdalnej 
zgodnie 
z art. 6719 § 1 pkt 2 każda ze stron umowy o pracę może wystąpić z wiążącym 
wnioskiem, złożonym w postaci papierowej lub elektronicznej, o zaprzestanie 

 
 
 
s. 49/195 
 
2025-08-06 
 
wykonywania pracy zdalnej i przywrócenie poprzednich warunków wykonywania 
pracy. Strony ustalają termin przywrócenia poprzednich warunków wykonywania 
pracy, nie dłuższy niż 30 dni od dnia otrzymania wniosku. W razie braku 
porozumienia przywrócenie poprzednich warunków wykonywania pracy następuje 
w dniu następującym po upływie 30 dni od dnia otrzymania wniosku. 
**§ 2.** Pracodawca nie może wystąpić z wiążącym wnioskiem o zaprzestanie 
wykonywania pracy zdalnej i przywrócenie poprzednich warunków wykonywania 
pracy przez pracownika, o którym mowa w art. 6719 § 6 i 7, chyba że dalsze 
wykonywanie pracy zdalnej nie jest możliwe ze względu na organizację pracy lub 
rodzaj pracy wykonywanej przez pracownika.

***
## Art. 6723. {#kp-drugi-art-6723}

Odmowa wyrażenia przez pracownika zgody na zmianę warunków 
wykonywania pracy w przypadku określonym w art. 6719 § 1 pkt 2, wystąpienie 
z wnioskiem o wykonywanie pracy zdalnej przez pracownika, o którym mowa 
w art. 6719 § 6 i 7, a także zaprzestanie wykonywania pracy zdalnej na zasadach 
określonych 
w art. 6722 nie 
mogą 
stanowić 
przyczyny 
uzasadniającej 
wypowiedzenie przez pracodawcę umowy o pracę.

***
## Art. 6724. {#kp-drugi-art-6724}

**§ 1.** Pracodawca jest obowiązany: 
- 1) zapewnić pracownikowi wykonującemu pracę zdalną materiały i narzędzia 
pracy, w tym urządzenia techniczne, niezbędne do wykonywania pracy 
zdalnej; 
- 2) zapewnić pracownikowi wykonującemu pracę zdalną instalację, serwis, 
konserwację narzędzi pracy, w tym urządzeń technicznych, niezbędnych do 
wykonywania pracy zdalnej lub pokryć niezbędne koszty związane 
z instalacją, serwisem, eksploatacją i konserwacją narzędzi pracy, w tym 
urządzeń technicznych, niezbędnych do wykonywania pracy zdalnej, a także 
pokryć koszty energii elektrycznej oraz usług telekomunikacyjnych 
niezbędnych do wykonywania pracy zdalnej; 
- 3) pokryć inne koszty niż koszty określone w pkt 2 bezpośrednio związane 
z wykonywaniem pracy zdalnej, jeżeli zwrot takich kosztów został określony 
w porozumieniu, o którym mowa w art. 6720 § 1 i 2, regulaminie, o którym 
mowa w art. 6720 § 3 i 4, poleceniu, o którym mowa w art. 6719 § 3, albo 
porozumieniu, o którym mowa w art. 6720 § 5 zdanie drugie; 

 
 
 
s. 50/195 
 
2025-08-06 
- 4) zapewnić pracownikowi wykonującemu pracę zdalną szkolenia i pomoc 
techniczną niezbędne do wykonywania tej pracy. 
**§ 2.** Strony mogą ustalić zasady wykorzystywania przez pracownika 
wykonującego pracę zdalną materiałów i narzędzi pracy, w tym urządzeń 
technicznych, niezbędnych do wykonywania pracy zdalnej, niezapewnionych przez 
pracodawcę, spełniających wymagania określone w rozdziale IV działu 
dziesiątego. 
**§ 3.** W przypadku, o którym mowa w § 2, pracownikowi wykonującemu 
pracę zdalną przysługuje ekwiwalent pieniężny w wysokości 
ustalonej 
z pracodawcą. 
**§ 4.** Obowiązek pokrycia kosztów, o których mowa w § 1 pkt 2 i 3, albo 
wypłaty ekwiwalentu, o którym mowa w § 3, może być zastąpiony obowiązkiem 
wypłaty ryczałtu, którego wysokość odpowiada przewidywanym kosztom 
ponoszonym przez pracownika w związku z wykonywaniem pracy zdalnej. 
**§ 5.** Przy ustalaniu wysokości ekwiwalentu albo ryczałtu bierze się pod uwagę 
w szczególności normy zużycia materiałów i narzędzi pracy, w tym urządzeń 
technicznych, ich udokumentowane ceny rynkowe oraz ilość materiału 
wykorzystanego na potrzeby pracodawcy i ceny rynkowe tego materiału, a także 
normy zużycia energii elektrycznej oraz koszty usług telekomunikacyjnych.

***
## Art. 6725. {#kp-drugi-art-6725}

Zapewnienie pracownikowi wykonującemu pracę zdalną przez 
pracodawcę materiałów i narzędzi pracy, w tym urządzeń technicznych, 
niezbędnych do wykonywania pracy zdalnej, pokrycie kosztów związanych 
z wykonywaniem pracy zdalnej przez pracownika i wypłata ekwiwalentu 
pieniężnego lub ryczałtu nie stanowią przychodu w rozumieniu przepisów ustawy 
z dnia 26 lipca 1991 r. o podatku dochodowym od osób fizycznych (Dz. U. 
z 2024 r. poz. 226, z późn. zm.4)).

***
## Art. 6726. {#kp-drugi-art-6726}

**§ 1.** Na potrzeby wykonywania pracy zdalnej pracodawca określa 
procedury ochrony danych osobowych oraz przeprowadza, w miarę potrzeby, 
instruktaż i szkolenie w tym zakresie. 
- 4) Zmiany tekstu jednolitego wymienionej ustawy zostały ogłoszone w Dz. U. z 2024 r. poz. 232, 
854, 858, 859, 863, 1572, 1585, 1593, 1615 i 1635. 

 
 
 
s. 51/195 
 
2025-08-06 
**§ 2.** Pracownik wykonujący pracę zdalną potwierdza w postaci papierowej 
lub elektronicznej zapoznanie się z procedurami, o których mowa w § 1, oraz jest 
obowiązany do ich przestrzegania.

***
## Art. 6727. {#kp-drugi-art-6727}

Pracownik wykonujący pracę zdalną i pracodawca przekazują 
informacje niezbędne do wzajemnego porozumiewania się za pomocą środków 
bezpośredniego porozumiewania się na odległość lub w inny sposób uzgodniony 
z pracodawcą.

***
## Art. 6728. {#kp-drugi-art-6728}

**§ 1.** Pracodawca ma prawo przeprowadzać kontrolę wykonywania 
pracy zdalnej przez pracownika, kontrolę w zakresie bezpieczeństwa i higieny 
pracy lub kontrolę przestrzegania wymogów w zakresie bezpieczeństwa i ochrony 
informacji, w tym procedur ochrony danych osobowych, na zasadach określonych 
w porozumieniu, o którym mowa w art. 6720 § 1 i 2, regulaminie, o którym mowa 
w art. 6720 § 3 i 4, poleceniu, o którym mowa w art. 6719 § 3, albo w porozumieniu, 
o którym mowa w art. 6720 § 5 zdanie drugie. Kontrolę przeprowadza się 
w porozumieniu 
z pracownikiem 
w miejscu 
wykonywania 
pracy 
zdalnej 
w godzinach pracy pracownika. 
**§ 2.** Pracodawca dostosowuje sposób przeprowadzania kontroli do miejsca 
wykonywania pracy zdalnej i jej rodzaju. Wykonywanie czynności kontrolnych nie 
może naruszać prywatności pracownika wykonującego pracę zdalną i innych osób 
ani utrudniać korzystania z pomieszczeń domowych w sposób zgodny z ich 
przeznaczeniem. 
**§ 3.** Jeżeli pracodawca w trakcie kontroli pracy zdalnej, o której mowa 
w art. 6719 § 1 pkt 2, stwierdzi uchybienia w przestrzeganiu przepisów i zasad 
w zakresie bezpieczeństwa i higieny pracy określonych w informacji, o której 
mowa w art. 6731 § 5, lub w przestrzeganiu wymogów w zakresie bezpieczeństwa 
i ochrony informacji, w tym procedur ochrony danych osobowych, zobowiązuje 
pracownika do usunięcia stwierdzonych uchybień we wskazanym terminie albo 
cofa zgodę na wykonywanie pracy zdalnej przez tego pracownika. W przypadku 
wycofania zgody na wykonywanie pracy zdalnej pracownik rozpoczyna pracę 
w dotychczasowym miejscu pracy w terminie określonym przez pracodawcę.

***
## Art. 6729. {#kp-drugi-art-6729}

**§ 1.** Pracownik wykonujący pracę zdalną nie może być traktowany 
mniej korzystnie w zakresie nawiązania i rozwiązania stosunku pracy, warunków 

 
 
 
s. 52/195 
 
2025-08-06 
 
zatrudnienia, awansowania oraz dostępu do szkolenia w celu podnoszenia 
kwalifikacji zawodowych niż inni pracownicy zatrudnieni przy takiej samej lub 
podobnej 
pracy, 
z uwzględnieniem odrębności 
związanych z warunkami 
wykonywania pracy zdalnej. 
**§ 2.** Pracownik nie może być w jakikolwiek sposób dyskryminowany 
z powodu wykonywania pracy zdalnej, jak również z powodu odmowy 
wykonywania takiej pracy.

***
## Art. 6730. {#kp-drugi-art-6730}

Pracodawca umożliwia pracownikowi wykonującemu pracę zdalną 
przebywanie na terenie zakładu pracy, kontaktowanie się z innymi pracownikami 
oraz korzystanie z pomieszczeń i urządzeń pracodawcy, zakładowych obiektów 
socjalnych i prowadzonej działalności socjalnej – na zasadach przyjętych dla ogółu 
pracowników.

***
## Art. 6731. {#kp-drugi-art-6731}

**§ 1.** Pracodawca realizuje w stosunku do pracownika w czasie 
wykonywania przez niego pracy zdalnej obowiązki w zakresie wynikającym 
z rodzaju i warunków wykonywanej pracy określone w dziale dziesiątym, 
z wyłączeniem obowiązków określonych w art. 208 § 1, art. 2091, art. 212 pkt 1 
i 4, art. 213, art. 214, art. 232 i art. 233. 
**§ 2.** W przypadku, o którym mowa w art. 6719 § 1 pkt 1, szkolenie wstępne 
w dziedzinie bezpieczeństwa i higieny pracy osoby przyjmowanej do pracy na 
stanowisko administracyjno-biurowe może być przeprowadzone w całości za 
pośrednictwem środków komunikacji elektronicznej. Pracownik potwierdza 
w postaci papierowej lub elektronicznej ukończenie szkolenia. 
**§ 3.** W przypadku wykonywania przez pracownika pracy zdalnej przepisu 
art. 2373 § 22 nie stosuje się. 
**§ 4.** Praca zdalna nie obejmuje prac: 
- 1) szczególnie niebezpiecznych; 
- 2) w wyniku których następuje przekroczenie dopuszczalnych norm czynników 
fizycznych określonych dla pomieszczeń mieszkalnych; 
- 3) z czynnikami chemicznymi stwarzającymi zagrożenie, o których mowa 
w przepisach 
w sprawie 
bezpieczeństwa 
i higieny 
pracy 
związanej 
z występowaniem czynników chemicznych w miejscu pracy; 

 
 
 
s. 53/195 
 
2025-08-06 
- 4) związanych ze stosowaniem lub wydzielaniem się szkodliwych czynników 
biologicznych, substancji radioaktywnych oraz innych substancji lub 
mieszanin wydzielających uciążliwe zapachy; 
- 5) powodujących intensywne brudzenie. 
**§ 5.** Przy ocenie ryzyka zawodowego pracownika wykonującego pracę zdalną 
uwzględnia się w szczególności wpływ tej pracy na wzrok, układ mięśniowo-
-szkieletowy oraz uwarunkowania psychospołeczne tej pracy. Na podstawie 
wyników tej oceny pracodawca opracowuje informację zawierającą: 
- 1) zasady i sposoby właściwej organizacji stanowiska pracy zdalnej, 
z uwzględnieniem wymagań ergonomii; 
- 2) zasady bezpiecznego i higienicznego wykonywania pracy zdalnej; 
- 3) czynności do wykonania po zakończeniu wykonywania pracy zdalnej; 
- 4) zasady postępowania w sytuacjach awaryjnych stwarzających zagrożenie dla 
życia lub zdrowia ludzkiego. 
Pracodawca może sporządzić uniwersalną ocenę ryzyka zawodowego dla 
poszczególnych grup stanowisk pracy zdalnej. 
**§ 6.** Przed dopuszczeniem do wykonywania pracy zdalnej pracownik 
potwierdza w oświadczeniu składanym w postaci papierowej lub elektronicznej 
zapoznanie się z przygotowaną przez pracodawcę oceną ryzyka zawodowego oraz 
informacją zawierającą zasady bezpiecznego i higienicznego wykonywania pracy 
zdalnej oraz zobowiązuje się do ich przestrzegania. 
**§ 7.** Dopuszczenie pracownika do wykonywania pracy zdalnej jest 
uzależnione od złożenia przez pracownika oświadczenia w postaci papierowej lub 
elektronicznej, zawierającego potwierdzenie, że na stanowisku pracy zdalnej 
w miejscu wskazanym przez pracownika i uzgodnionym z pracodawcą są 
zapewnione bezpieczne i higieniczne warunki tej pracy. 
**§ 8.** Pracownik organizuje stanowisko pracy zdalnej, uwzględniając 
wymagania ergonomii. 
**§ 9.** W razie wypadku przy pracy zdalnej art. 234 oraz przepisy wydane na 
podstawie art. 237 § 1 pkt 1 i 2 stosuje się odpowiednio. 
**§ 10.** Oględzin miejsca wypadku dokonuje się po zgłoszeniu wypadku przy 
pracy zdalnej, w terminie uzgodnionym przez pracownika albo jego domownika, 
w przypadku gdy pracownik ze względu na stan zdrowia nie jest w stanie uzgodnić 

 
 
 
s. 54/195 
 
2025-08-06 
 
tego terminu, i członków zespołu powypadkowego. Zespół powypadkowy może 
odstąpić od dokonywania oględzin miejsca wypadku przy pracy zdalnej, jeżeli 
uzna, że okoliczności i przyczyny wypadku nie budzą jego wątpliwości.

***
## Art. 6732. {#kp-drugi-art-6732}

W przypadku wykonywania pracy zdalnej wnioski pracownika, dla 
których przepisy kodeksu lub innych ustaw lub aktów wykonawczych, 
określających prawa i obowiązki z zakresu prawa pracy, wymagają formy 
pisemnej, mogą być złożone w postaci papierowej lub elektronicznej.

***
## Art. 6733. {#kp-drugi-art-6733}

**§ 1.** Praca zdalna może być wykonywana okazjonalnie, na wniosek 
pracownika złożony w postaci papierowej lub elektronicznej, w wymiarze 
nieprzekraczającym 24 dni w roku kalendarzowym. 
**§ 2.** Do pracy zdalnej, o której mowa w § 1, nie stosuje się przepisów 
art. 6719–6724 oraz art. 6731 § 3. 
**§ 3.** Kontrola wykonywania pracy zdalnej, o której mowa w § 1, kontrola 
w zakresie bezpieczeństwa i higieny pracy lub kontrola przestrzegania wymogów 
w zakresie bezpieczeństwa i ochrony informacji, w tym procedur ochrony danych 
osobowych, odbywa się na zasadach ustalonych z pracownikiem.

***
## Art. 6734. {#kp-drugi-art-6734}

Przepisy niniejszego rozdziału stosuje się także do stosunków pracy 
nawiązanych na innej podstawie niż umowa o pracę. 
## Rozdział III Stosunek pracy na podstawie powołania, wyboru, mianowania oraz 
spółdzielczej umowy o pracę 
Oddział 1 
Stosunek pracy na podstawie powołania

***
## Art. 68. {#kp-drugi-art-68}

**§ 1.** Stosunek pracy nawiązuje się na podstawie powołania 
w przypadkach określonych w odrębnych przepisach. 
**§ 11.** Stosunek pracy, o którym mowa w § 1, nawiązuje się na czas 
nieokreślony, a jeżeli na podstawie przepisów szczególnych pracownik został 
powołany na czas określony, stosunek pracy nawiązuje się na okres objęty 
powołaniem. 
**§ 2.** (uchylony) 

 
 
 
s. 55/195 
 
2025-08-06

***
## Art. 681. {#kp-drugi-art-681}

Powołanie może być poprzedzone konkursem, choćby przepisy 
szczególne nie przewidywały wymogu wyłonienia kandydata na stanowisko 
wyłącznie w wyniku konkursu.

***
## Art. 682. {#kp-drugi-art-682}

**§ 1.** Stosunek pracy na podstawie powołania nawiązuje się 
w terminie określonym w powołaniu, a jeżeli termin ten nie został określony – 
w dniu doręczenia powołania, chyba że przepisy szczególne stanowią inaczej. 
**§ 2.** Powołanie powinno być dokonane na piśmie.

***
## Art. 683. {#kp-drugi-art-683}

Jeżeli pracownik powołany na stanowisko w wyniku konkursu 
pozostaje w stosunku pracy z innym pracodawcą i obowiązuje go trzymiesięczny 
okres wypowiedzenia, może on rozwiązać ten stosunek za jednomiesięcznym 
wypowiedzeniem. Rozwiązanie stosunku pracy w tym trybie pociąga za sobą 
skutki, jakie przepisy prawa pracy wiążą z rozwiązaniem umowy o pracę przez 
pracodawcę za wypowiedzeniem.

***
## Art. 69. {#kp-drugi-art-69}

Jeżeli przepisy niniejszego oddziału nie stanowią inaczej, do 
stosunku pracy na podstawie powołania stosuje się przepisy dotyczące umowy 
o pracę na czas nieokreślony, z wyłączeniem przepisów regulujących: 
- 1) tryb postępowania przy rozwiązywaniu umów o pracę; 
- 2) rozpatrywanie sporów ze stosunku pracy w części dotyczącej orzekania: 
  - a) o bezskuteczności wypowiedzeń, 
  - b) (uchylona) 
  - c) o przywracaniu do pracy.

***
## Art. 70. {#kp-drugi-art-70}

**§ 1.** Pracownik zatrudniony na podstawie powołania może być 
w każdym czasie – niezwłocznie lub w określonym terminie – odwołany ze 
stanowiska przez organ, który go powołał. Dotyczy to również pracownika, który 
na podstawie przepisów szczególnych został powołany na stanowisko na czas 
określony. 
**§ 11.** Odwołanie powinno być dokonane na piśmie. 
**§ 12.** Stosunek pracy z pracownikiem odwołanym ze stanowiska rozwiązuje 
się na zasadach określonych w przepisach niniejszego oddziału, chyba że przepisy 
szczególne stanowią inaczej. 

 
 
 
s. 56/195 
 
2025-08-06 
**§ 2.** Odwołanie jest równoznaczne z wypowiedzeniem umowy o pracę. 
W okresie wypowiedzenia pracownik ma prawo do wynagrodzenia w wysokości 
przysługującej przed odwołaniem. 
**§ 3.** Odwołanie jest równoznaczne z rozwiązaniem umowy o pracę bez 
wypowiedzenia, jeżeli nastąpiło z przyczyn, o których mowa w art. 52 lub 53.

***
## Art. 71. {#kp-drugi-art-71}

Na wniosek lub za zgodą pracownika pracodawca może zatrudnić go 
w okresie wypowiedzenia przy innej pracy, odpowiedniej ze względu na jego 
kwalifikacje zawodowe, a po upływie okresu wypowiedzenia zatrudnić na uzgod-
nionych przez strony warunkach pracy i płacy.

***
## Art. 72. {#kp-drugi-art-72}

**§ 1.** Jeżeli odwołanie nastąpiło w okresie usprawiedliwionej 
nieobecności w pracy, bieg wypowiedzenia rozpoczyna się po upływie tego okresu. 
Jeżeli jednak usprawiedliwiona nieobecność trwa dłużej niż okres przewidziany 
w art. 53 § 1 i 2, organ, który pracownika powołał, może rozwiązać stosunek pracy 
bez wypowiedzenia. 
**§ 2.** W razie odwołania pracownicy w okresie ciąży, organ odwołujący jest 
obowiązany zapewnić jej inną pracę, odpowiednią ze względu na jej kwalifikacje 
zawodowe, przy czym przez okres równy okresowi wypowiedzenia pracownica ma 
prawo do wynagrodzenia w wysokości przysługującej przed odwołaniem. Jeżeli 
jednak pracownica nie wyrazi zgody na podjęcie innej pracy, stosunek pracy ulega 
rozwiązaniu z upływem okresu równego okresowi wypowiedzenia, którego bieg 
rozpoczyna się od dnia zaproponowania na piśmie innej pracy. 
**§ 3.** Przepis § 2 stosuje się odpowiednio w razie odwołania pracownika, 
któremu brakuje nie więcej niż 2 lata do nabycia prawa do emerytury z Funduszu 
Ubezpieczeń Społecznych. 
**§ 4.** W razie naruszenia przepisów § 1–3, pracownikowi przysługuje prawo 
odwołania do sądu pracy. 
Oddział 2 
Stosunek pracy na podstawie wyboru

***
## Art. 73. {#kp-drugi-art-73}

**§ 1.** Nawiązanie stosunku pracy następuje na podstawie wyboru, 
jeżeli z wyboru wynika obowiązek wykonywania pracy w charakterze pracownika. 
**§ 2.** Stosunek pracy z wyboru rozwiązuje się z wygaśnięciem mandatu. 

 
 
 
s. 57/195 
 
2025-08-06

***
## Art. 74. {#kp-drugi-art-74}

Pracownik pozostający w związku z wyborem na urlopie bezpłatnym 
ma prawo powrotu do pracy u pracodawcy, który zatrudniał go w chwili wyboru, 
na stanowisko równorzędne pod względem wynagrodzenia z poprzednio 
zajmowanym, jeżeli zgłosi swój powrót w ciągu 7 dni od rozwiązania stosunku 
pracy z wyboru. Niedotrzymanie tego warunku powoduje wygaśnięcie stosunku 
pracy, chyba że nastąpiło z przyczyn niezależnych od pracownika.

***
## Art. 75. {#kp-drugi-art-75}

Pracownikowi, który nie pozostawał w związku z wyborem na 
urlopie bezpłatnym, przysługuje odprawa w wysokości jednomiesięcznego 
wynagrodzenia. 
Oddział 3 
Stosunek pracy na podstawie mianowania

***
## Art. 76. {#kp-drugi-art-76}

Stosunek 
pracy 
nawiązuje 
się 
na 
podstawie 
mianowania 
w przypadkach określonych w odrębnych przepisach. 
Oddział 4 
Stosunek pracy na podstawie spółdzielczej umowy o pracę

***
## Art. 77. {#kp-drugi-art-77}

**§ 1.** Stosunek pracy między spółdzielnią pracy a jej członkiem 
nawiązuje się przez spółdzielczą umowę o pracę. 
**§ 2.** Stosunek pracy na podstawie spółdzielczej umowy o pracę reguluje 
ustawa – Prawo spółdzielcze, a w zakresie nieuregulowanym odmiennie tą ustawą 
stosuje się odpowiednio przepisy Kodeksu pracy.

