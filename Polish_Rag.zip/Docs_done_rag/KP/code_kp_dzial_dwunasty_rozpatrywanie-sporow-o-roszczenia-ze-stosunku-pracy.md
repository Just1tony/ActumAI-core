---
id: code.kp.dzial.dwunasty
title: "Kodeks pracy — Dział DWUNASTY (Rozpatrywanie sporów o roszczenia ze stosunku pracy)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1974 nr 24 poz. 141"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KP — Dział DWUNASTY"]
tags: ["KP","Kodeks pracy","Dział DWUNASTY","PL"]
source_pdf: "D19740141Lj.pdf"
articles: "Art. 242–265"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kp-dwunasty-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks pracy — Dział DWUNASTY: Rozpatrywanie sporów o roszczenia ze stosunku pracy

Rozpatrywanie sporów o roszczenia ze stosunku pracy 
## Rozdział I Przepisy ogólne
***
## Art. 242. {#kp-dwunasty-art-242}

**§ 1.** Pracownik może dochodzić swych roszczeń ze stosunku pracy 
na drodze sądowej. 
**§ 2.** Przed skierowaniem sprawy na drogę sądową pracownik może żądać 
wszczęcia postępowania pojednawczego przed komisją pojednawczą.

***
## Art. 243. {#kp-dwunasty-art-243}

Pracodawca 
i pracownik 
powinni 
dążyć 
do 
polubownego 
załatwienia sporu ze stosunku pracy. 
## Rozdział II Postępowanie pojednawcze

***
## Art. 244. {#kp-dwunasty-art-244}

**§ 1.** W celu polubownego załatwiania sporów o roszczenia 
pracowników ze stosunku pracy mogą być powoływane komisje pojednawcze. 
**§ 2.** (uchylony) 
**§ 3.** Komisję pojednawczą powołują wspólnie pracodawca i zakładowa 
organizacja związkowa, a jeżeli u danego pracodawcy nie działa zakładowa 
organizacja związkowa – pracodawca, po uzyskaniu pozytywnej opinii 
pracowników. 

 
 
 
s. 183/195 
 
2025-08-06 
**§ 4.** (uchylony)

***
## Art. 245. {#kp-dwunasty-art-245}

W trybie przewidzianym w art. 244 § 3 ustala się: 
- 1) zasady i tryb powoływania komisji; 
- 2) czas trwania kadencji; 
- 3) liczbę członków komisji.

***
## Art. 246. {#kp-dwunasty-art-246}

Członkiem komisji pojednawczej nie może być: 
- 1) osoba zarządzająca, w imieniu pracodawcy, zakładem pracy; 
- 2) główny księgowy; 
- 3) radca prawny; 
- 4) osoba prowadząca sprawy osobowe, zatrudnienia i płac.

***
## Art. 247. {#kp-dwunasty-art-247}

Komisja pojednawcza wybiera ze swego grona przewodniczącego 
komisji oraz jego zastępców i ustala regulamin postępowania pojednawczego.

***
## Art. 248. {#kp-dwunasty-art-248}

**§ 1.** Komisja pojednawcza wszczyna postępowanie na wniosek 
pracownika zgłoszony na piśmie lub ustnie do protokołu. Na wniosku stwierdza się 
datę jego wpływu. 
**§ 2.** Zgłoszenie przez pracownika wniosku do komisji pojednawczej przerywa 
bieg terminów, o których mowa w art. 264.

***
## Art. 249. {#kp-dwunasty-art-249}

Komisja pojednawcza przeprowadza postępowanie pojednawcze 
w zespołach składających się co najmniej z 3 członków tej komisji.

***
## Art. 250. {#kp-dwunasty-art-250}

(uchylony)

***
## Art. 251. {#kp-dwunasty-art-251}

**§ 1.** Komisja pojednawcza powinna dążyć, aby załatwienie sprawy 
w drodze ugody nastąpiło w terminie 14 dni od dnia złożenia wniosku. Termin 
zakończenia postępowania przed komisją pojednawczą stwierdza się w protokole 
posiedzenia zespołu. 
**§ 2.** W sprawach dotyczących rozwiązania, wygaśnięcia lub nawiązania 
stosunku pracy, o których mowa w art. 264, wniosek do komisji pojednawczej 
wnosi się przed upływem terminów określonych w tym przepisie. 
**§ 3.** W sprawach, o których mowa w § 2, postępowanie pojednawcze kończy 
się z mocy prawa z upływem 14 dni od dnia złożenia wniosku przez pracownika, 
a w innych sprawach – z upływem 30 dni od dnia złożenia wniosku. 

 
 
 
s. 184/195 
 
2025-08-06

***
## Art. 252. {#kp-dwunasty-art-252}

Ugodę zawartą przed komisją pojednawczą wpisuje się do 
protokołu posiedzenia zespołu. Protokół podpisują strony i członkowie zespołu.

***
## Art. 253. {#kp-dwunasty-art-253}

Niedopuszczalne jest zawarcie ugody, która byłaby sprzeczna 
z prawem lub zasadami współżycia społecznego.

***
## Art. 254. {#kp-dwunasty-art-254}

Jeżeli postępowanie przed komisją pojednawczą nie doprowadziło 
do zawarcia ugody, komisja na żądanie pracownika, zgłoszone w terminie 14 dni 
od dnia zakończenia postępowania pojednawczego, przekazuje niezwłocznie 
sprawę sądowi pracy. Wniosek pracownika o polubowne załatwienie sprawy przez 
komisję pojednawczą zastępuje pozew. Pracownik zamiast zgłoszenia tego żądania 
może wnieść pozew do sądu pracy na zasadach ogólnych.

***
## Art. 255. {#kp-dwunasty-art-255}

**§ 1.** W razie niewykonania ugody przez pracodawcę podlega ona 
wykonaniu w trybie przepisów Kodeksu postępowania cywilnego, po nadaniu jej 
przez sąd pracy klauzuli wykonalności. 
**§ 2.** Sąd pracy odmówi nadania klauzuli wykonalności, jeżeli ze złożonych 
akt komisji wynika, że ugoda jest sprzeczna z prawem lub zasadami współżycia 
społecznego. Nie wyklucza to możliwości dochodzenia ustalenia niezgodności 
ugody z prawem lub zasadami współżycia społecznego na zasadach ogólnych.

***
## Art. 256. {#kp-dwunasty-art-256}

Pracownik może wystąpić do sądu pracy w terminie 30 dni od dnia 
zawarcia ugody z żądaniem uznania jej za bezskuteczną, jeżeli uważa, że ugoda 
narusza jego słuszny interes. Jednakże w sprawach, o których mowa w art. 251 § 2, 
z żądaniem takim pracownik może wystąpić tylko przed upływem 14 dni od dnia 
zawarcia ugody.

***
## Art. 257. {#kp-dwunasty-art-257}

Sprawowanie obowiązków członka komisji pojednawczej jest 
funkcją społeczną. Jednakże członek komisji pojednawczej zachowuje prawo do 
wynagrodzenia za czas nieprzepracowany w związku z udziałem w pracach 
komisji.

***
## Art. 258. {#kp-dwunasty-art-258}

**§ 1.** Pracodawca jest obowiązany zapewnić komisji pojednawczej 
warunki lokalowe oraz środki techniczne umożliwiające właściwe jej 
funkcjonowanie. 
**§ 2.** Wydatki związane z działalnością komisji pojednawczej ponosi 
pracodawca. 
Wydatki 
te 
obejmują 
również 
równowartość 
utraconego 

 
 
 
s. 185/195 
 
2025-08-06 
 
wynagrodzenia za czas nieprzepracowany przez pracownika w związku z udziałem 
w postępowaniu pojednawczym.

***
## Art. 259. {#kp-dwunasty-art-259}

(uchylony)

***
## Art. 260. {#kp-dwunasty-art-260}

(uchylony)

***
## Art. 261. {#kp-dwunasty-art-261}

(uchylony) 
## Rozdział III Sądy pracy

***
## Art. 262. {#kp-dwunasty-art-262}

**§ 1.** Spory o roszczenia ze stosunku pracy rozstrzygają sądy 
powszechne, zwane „sądami pracy”. 
**§ 2.** Nie podlegają właściwości sądów pracy spory dotyczące: 
- 1) ustanawiania nowych warunków pracy i płacy; 
- 2) stosowania norm pracy. 
- 3) (uchylony) 
**§ 3.** Zasady tworzenia sądów pracy, organizację i tryb postępowania przed 
tymi sądami regulują odrębne przepisy.

***
## Art. 263. {#kp-dwunasty-art-263}

(uchylony)

***
## Art. 264. {#kp-dwunasty-art-264}

**§ 1.** Odwołanie od wypowiedzenia umowy o pracę wnosi się do sądu 
pracy w ciągu 21 dni od dnia doręczenia pisma wypowiadającego umowę o pracę. 
**§ 2.** Żądanie przywrócenia do pracy lub odszkodowania wnosi się do sądu 
pracy w ciągu 21 dni od dnia doręczenia zawiadomienia o rozwiązaniu umowy o 
pracę bez wypowiedzenia lub od dnia wygaśnięcia umowy o pracę. 
**§ 3.** Żądanie nawiązania umowy o pracę wnosi się do sądu pracy w ciągu 21 
dni od dnia doręczenia zawiadomienia o odmowie przyjęcia do pracy.

***
## Art. 265. {#kp-dwunasty-art-265}

**§ 1.** Jeżeli pracownik nie dokonał – bez swojej winy – w terminie 
czynności, o których mowa w art. 97 § 21 i w art. 264, sąd pracy na jego wniosek 
postanowi przywrócenie uchybionego terminu. 
**§ 2.** Wniosek o przywrócenie terminu wnosi się do sądu pracy w ciągu 7 dni 
od dnia ustania przyczyny uchybienia terminu. We wniosku należy 
uprawdopodobnić okoliczności uzasadniające przywrócenie terminu. 

 
 
 
s. 186/195 
 
2025-08-06 
 
Art. 266–280.16)

