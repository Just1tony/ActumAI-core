---
id: code.kp.dzial.czternasty
title: "Kodeks pracy — Dział CZTERNASTY (Przedawnienie roszczeń)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1974 nr 24 poz. 141"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KP — Dział CZTERNASTY"]
tags: ["KP","Kodeks pracy","Dział CZTERNASTY","PL"]
source_pdf: "D19740141Lj.pdf"
articles: "Art. 291–2931"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kp-czternasty-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks pracy — Dział CZTERNASTY: Przedawnienie roszczeń

Przedawnienie roszczeń
***
## Art. 291. {#kp-czternasty-art-291}

**§ 1.** Roszczenia ze stosunku pracy ulegają przedawnieniu 
z upływem 3 lat od dnia, w którym roszczenie stało się wymagalne. 
**§ 2.** Jednakże roszczenia pracodawcy o naprawienie szkody, wyrządzonej 
przez pracownika wskutek niewykonania lub nienależytego wykonania 
obowiązków pracowniczych, ulegają przedawnieniu z upływem 1 roku od dnia, 
w którym pracodawca powziął wiadomość o wyrządzeniu przez pracownika 
szkody, nie później jednak niż z upływem 3 lat od jej wyrządzenia. 
**§ 21.** Przepis § 2 stosuje się także do roszczenia pracodawcy, o którym mowa 
w art. 611 oraz w art. 1011 § 2. 
**§ 3.** Jeżeli pracownik umyślnie wyrządził szkodę, do przedawnienia 
roszczenia o naprawienie tej szkody stosuje się przepisy Kodeksu cywilnego. 
**§ 4.** Terminy przedawnienia nie mogą być skracane ani przedłużane przez 
czynność prawną. 
**§ 5.** Roszczenie stwierdzone prawomocnym orzeczeniem organu powołanego 
do rozstrzygania sporów, jak również roszczenie stwierdzone ugodą zawartą 
w trybie określonym w kodeksie przed takim organem, ulega przedawnieniu 
z upływem 10 lat od dnia uprawomocnienia się orzeczenia lub zawarcia ugody. 

 
 
 
s. 190/195 
 
2025-08-06

***
## Art. 292. {#kp-czternasty-art-292}

Po upływie terminu przedawnienia roszczenia ze stosunku pracy 
ten, przeciwko komu przysługuje roszczenie, może uchylić się od jego 
zaspokojenia, chyba że zrzeka się korzystania z zarzutu przedawnienia. Zrzeczenie 
się zarzutu przedawnienia dokonane przed upływem terminu przedawnienia jest 
nieważne.

***
## Art. 293. {#kp-czternasty-art-293}

Bieg przedawnienia nie rozpoczyna się, a rozpoczęty ulega 
zawieszeniu na czas trwania przeszkody, gdy z powodu siły wyższej uprawniony 
nie może dochodzić przysługujących mu roszczeń przed właściwym organem 
powołanym do rozstrzygania sporów.

***
## Art. 2931. {#kp-czternasty-art-2931}

Bieg przedawnienia roszczenia o urlop wypoczynkowy nie 
rozpoczyna się, a rozpoczęty ulega zawieszeniu na czas korzystania z urlopu 
wychowawczego.

***
## Art. 294. {#kp-czternasty-art-294}

Przedawnienie względem osoby, która nie ma pełnej zdolności do 
czynności prawnych albo co do której istnieje podstawa do jej całkowitego 
ubezwłasnowolnienia, nie może skończyć się wcześniej niż z upływem 2 lat od dnia 
ustanowienia dla niej przedstawiciela ustawowego albo od dnia ustania przyczyny 
jego ustanowienia. Jeżeli termin przedawnienia wynosi 1 rok, jego bieg liczy się od 
dnia ustanowienia przedstawiciela ustawowego albo od dnia, w którym ustała 
przyczyna jego ustanowienia.

***
## Art. 295. {#kp-czternasty-art-295}

**§ 1.** Bieg przedawnienia przerywa się: 
- 1) przez każdą czynność przed właściwym organem powołanym do 
rozstrzygania 
sporów 
lub 
egzekwowania 
roszczeń 
przedsięwziętą 
bezpośrednio w celu dochodzenia lub ustalenia albo zaspokojenia lub 
zabezpieczenia roszczenia; 
- 2) przez uznanie roszczenia. 
**§ 2.** Po każdym przerwaniu przedawnienia biegnie ono na nowo. Jeżeli 
przerwa biegu przedawnienia nastąpiła wskutek jednej z przyczyn przewidzianych 
w § 1 pkt 1, przedawnienie nie biegnie na nowo, dopóki postępowanie wszczęte 
w celu dochodzenia lub ustalenia albo zaspokojenia lub zabezpieczenia roszczenia 
nie zostanie zakończone. 

 
 
 
s. 191/195 
 
2025-08-06

