---
id: code.kp.dzial.jedenasty
title: "Kodeks pracy — Dział JEDENASTY (Układy zbiorowe pracy)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1974 nr 24 poz. 141"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KP — Dział JEDENASTY"]
tags: ["KP","Kodeks pracy","Dział JEDENASTY","PL"]
source_pdf: "D19740141Lj.pdf"
articles: "Art. 238–24130"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kp-jedenasty-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks pracy — Dział JEDENASTY: Układy zbiorowe pracy

Układy zbiorowe pracy 
## Rozdział I Przepisy ogólne
***
## Art. 238. {#kp-jedenasty-art-238}

**§ 1.** Ilekroć w przepisach działu jest mowa o: 

 
 
 
s. 169/195 
 
2025-08-06 
- 1) ponadzakładowej organizacji związkowej – należy przez to rozumieć 
organizację związkową będącą ogólnokrajowym związkiem zawodowym, 
zrzeszeniem (federacją) związków zawodowych lub ogólnokrajową 
organizacją międzyzwiązkową (konfederacją); 
- 2) organizacji związkowej reprezentującej pracowników – należy przez to 
rozumieć organizację związkową zrzeszającą pracowników, dla których układ 
jest zawierany. Dotyczy to również zrzeszenia (federacji) związków 
zawodowych, w skład którego wchodzą te organizacje związkowe, a także 
ogólnokrajowej organizacji międzyzwiązkowej (konfederacji) zrzeszającej 
takie organizacje związkowe lub zrzeszenia (federacje) związków 
zawodowych. 
**§ 2.** Przepisy rozdziału odnoszące się do: 
- 1) układu – stosuje się odpowiednio do układu ponadzakładowego i układu 
zakładowego; 
- 2) pracodawców – stosuje się odpowiednio do pracodawcy.

***
## Art. 239. {#kp-jedenasty-art-239}

**§ 1.** Układ zawiera się dla wszystkich pracowników zatrudnionych 
przez pracodawców objętych jego postanowieniami, chyba że strony w układzie 
postanowią inaczej. 
**§ 2.** Układem mogą być objęci emeryci i renciści. 
**§ 3.** Układu nie zawiera się dla: 
- 1) członków korpusu służby cywilnej; 
- 2) pracowników 
urzędów 
państwowych 
zatrudnionych 
na 
podstawie 
mianowania i powołania; 
- 3) pracowników samorządowych zatrudnionych na podstawie wyboru, 
mianowania i powołania w: 
  - a) urzędach marszałkowskich, 
  - b) starostwach powiatowych, 
  - c) urzędach gminy, 
  - d) biurach (ich odpowiednikach) związków jednostek samorządu 
terytorialnego, 
  - e) biurach (ich odpowiednikach) jednostek administracyjnych jednostek 
samorządu terytorialnego; 
- 4) sędziów, asesorów sądowych i prokuratorów. 

 
 
 
s. 170/195 
 
2025-08-06

***
## Art. 240. {#kp-jedenasty-art-240}

**§ 1.** Układ określa: 
- 1) warunki, jakim powinna odpowiadać treść stosunku pracy, z zastrzeżeniem 
§ 3; 
- 2) wzajemne zobowiązania stron układu, w tym dotyczące stosowania układu 
i przestrzegania jego postanowień. 
**§ 2.** Układ może określać inne sprawy poza wymienionymi w § 1, 
nieuregulowane w przepisach prawa pracy w sposób bezwzględnie obowiązujący. 
**§ 3.** Układ nie może naruszać praw osób trzecich. 
**§ 4.** Zawarcie układu dla pracowników zatrudnionych w jednostkach 
budżetowych oraz samorządowych zakładach budżetowych może nastąpić 
wyłącznie w ramach środków finansowych będących w ich dyspozycji, w tym 
wynagrodzeń określonych na podstawie odrębnych przepisów. 
**§ 5.** Wniosek o zarejestrowanie układu zawartego dla pracowników 
zatrudnionych w jednostkach budżetowych oraz samorządowych zakładach 
budżetowych powinien zawierać oświadczenie organu, który utworzył dany 
podmiot lub przejął funkcje takiego organu, o spełnieniu wymogu, o którym mowa 
w § 4.

***
## Art. 241. {#kp-jedenasty-art-241}

(uchylony)

***
## Art. 2411. {#kp-jedenasty-art-2411}

Strony, określając wzajemne zobowiązania przy stosowaniu 
układu, mogą w szczególności ustalić: 
- 1) sposób publikacji układu i rozpowszechniania jego treści; 
- 2) tryb dokonywania okresowych ocen funkcjonowania układu; 
- 3) tryb wyjaśniania treści postanowień układu oraz rozstrzygania sporów między 
stronami w tym zakresie. 
- 4) (uchylony)

***
## Art. 2412. {#kp-jedenasty-art-2412}

**§ 1.** Zawarcie układu następuje w drodze rokowań. 
**§ 2.** Podmiot występujący z inicjatywą zawarcia układu jest obowiązany 
powiadomić o tym każdą organizację związkową reprezentującą pracowników, dla 
których ma być zawarty układ, w celu wspólnego prowadzenia rokowań przez 
wszystkie organizacje związkowe. 
**§ 3.** Strona uprawniona do zawarcia układu nie może odmówić żądaniu 
drugiej strony podjęcia rokowań: 

 
 
 
s. 171/195 
 
2025-08-06 
- 1) w celu zawarcia układu dla pracowników nieobjętych układem; 
- 2) w celu zmiany układu uzasadnionej istotną zmianą sytuacji ekonomicznej 
bądź finansowej pracodawców lub pogorszeniem się sytuacji materialnej 
pracowników; 
- 3) jeżeli żądanie zostało zgłoszone nie wcześniej niż 60 dni przed upływem 
okresu, na jaki układ został zawarty, albo po dniu wypowiedzenia układu.

***
## Art. 2413. {#kp-jedenasty-art-2413}

**§ 1.** Każda ze stron jest obowiązana prowadzić rokowania w dobrej 
wierze i z poszanowaniem słusznych interesów drugiej strony. Oznacza to 
w szczególności: 
- 1) uwzględnianie postulatów organizacji związkowej uzasadnionych sytuacją 
ekonomiczną pracodawców; 
- 2) powstrzymywanie się od wysuwania postulatów, których realizacja w sposób 
oczywisty przekracza możliwości finansowe pracodawców; 
- 3) poszanowanie interesów pracowników nieobjętych układem. 
**§ 2.** Strony układu mogą określić tryb rozstrzygania kwestii spornych 
związanych z przedmiotem rokowań lub innych spornych zagadnień, które mogą 
wyłonić się w trakcie tych rokowań. W takim przypadku nie mają zastosowania 
przepisy o rozwiązywaniu sporów zbiorowych, chyba że strony postanowią o ich 
stosowaniu w określonym zakresie.

***
## Art. 2414. {#kp-jedenasty-art-2414}

**§ 1.** Pracodawca jest obowiązany udzielić przedstawicielom 
związków zawodowych prowadzącym rokowania informacji o swojej sytuacji 
ekonomicznej w zakresie objętym rokowaniami i niezbędnym do prowadzenia 
odpowiedzialnych rokowań. Obowiązek ten dotyczy w szczególności informacji 
objętych sprawozdawczością Głównego Urzędu Statystycznego. 
**§ 2.** Przedstawiciele związków zawodowych są obowiązani do nieujawniania 
uzyskanych od pracodawcy informacji, stanowiących tajemnicę przedsiębiorstwa 
w rozumieniu przepisów o zwalczaniu nieuczciwej konkurencji. 
**§ 3.** Na żądanie każdej ze stron może być powołany ekspert, którego zadaniem 
jest przedstawienie opinii w sprawach związanych z przedmiotem rokowań. Koszty 
ekspertyzy pokrywa strona, która żądała powołania eksperta, chyba że strony 
postanowią inaczej. 

 
 
 
s. 172/195 
 
2025-08-06 
**§ 4.** Przepisy 
§ 1–3 nie 
naruszają 
przepisów 
o ochronie 
informacji 
niejawnych.

***
## Art. 2415. {#kp-jedenasty-art-2415}

**§ 1.** Układ zawiera się w formie pisemnej na czas nieokreślony lub 
na czas określony. 
**§ 2.** W układzie ustala się zakres jego obowiązywania oraz wskazuje siedziby 
stron układu. 
**§ 3.** Przed upływem terminu obowiązywania układu zawartego na czas 
określony strony mogą przedłużyć jego obowiązywanie na czas określony lub 
uznać układ za zawarty na czas nieokreślony.

***
## Art. 2416. {#kp-jedenasty-art-2416}

**§ 1.** Treść postanowień układu wyjaśniają wspólnie jego strony. 
**§ 2.** Wyjaśnienia treści postanowień układu, dokonane wspólnie przez strony 
układu, wiążą także strony, które zawarły porozumienie o stosowaniu tego układu. 
Wyjaśnienia udostępnia się stronom porozumienia.

***
## Art. 2417. {#kp-jedenasty-art-2417}

**§ 1.** Układ rozwiązuje się: 
- 1) na podstawie zgodnego oświadczenia stron; 
- 2) z upływem okresu, na który został zawarty; 
- 3) z upływem okresu wypowiedzenia dokonanego przez jedną ze stron. 
**§ 2.** Oświadczenie stron o rozwiązaniu układu oraz wypowiedzenie układu 
następuje w formie pisemnej. 
**§ 3.** Okres wypowiedzenia układu wynosi trzy miesiące kalendarzowe, chyba 
że strony w układzie postanowią inaczej. 
**§ 4.** (utracił moc)15) 
**§ 5.** (uchylony)

***
## Art. 2418. {#kp-jedenasty-art-2418}

**§ 1.** W okresie jednego roku od dnia przejścia zakładu pracy lub 
jego części na nowego pracodawcę do pracowników stosuje się postanowienia 
układu, którym byli objęci przed przejściem zakładu pracy lub jego części na 
nowego pracodawcę, chyba że odrębne przepisy stanowią inaczej. Postanowienia 
tego układu stosuje się w brzmieniu obowiązującym w dniu przejścia zakładu pracy 
lub jego części na nowego pracodawcę. Pracodawca może stosować do tych 
pracowników korzystniejsze warunki niż wynikające z dotychczasowego układu. 
- 15) Z dniem 26 listopada 2002 r. na podstawie wyroku Trybunału Konstytucyjnego z dnia 18 listopada 
2002 r. sygn. akt K. 37/01 (Dz. U. poz. 1660). 

 
 
 
s. 173/195 
 
2025-08-06 
**§ 2.** Po upływie okresu stosowania dotychczasowego układu wynikające 
z tego układu warunki umów o pracę lub innych aktów stanowiących podstawę 
nawiązania stosunku pracy stosuje się do upływu okresu wypowiedzenia tych 
warunków. Przepis art. 24113 § 2 zdanie drugie stosuje się. 
**§ 3.** Jeżeli w przypadkach, o których mowa w § 1, nowy pracodawca 
przejmuje również inne osoby objęte układem obowiązującym u dotychczasowego 
pracodawcy, stosuje postanowienia układu dotyczące tych osób przez okres 
jednego roku od dnia przejęcia. 
**§ 4.** Jeżeli pracownicy przed ich przejęciem byli objęci układem 
ponadzakładowym, obowiązującym u nowego pracodawcy, przepisy § 1–3 stosuje 
się do układu zakładowego.

***
## Art. 2419. {#kp-jedenasty-art-2419}

**§ 1.** Zmiany do układu wprowadza się w drodze protokołów 
dodatkowych. Do protokołów dodatkowych stosuje się odpowiednio przepisy 
dotyczące układu. 
**§ 2.** Jeżeli układ został zawarty przez więcej niż jedną organizację 
związkową, przez okres jego obowiązywania wszelkie czynności dotyczące tego 
układu podejmują organizacje związkowe, które go zawarły, z zastrzeżeniem § 3 
i 4. 
**§ 3.** Strony układu mogą wyrazić zgodę, aby w prawa i obowiązki strony 
wstąpiła organizacja związkowa, która nie zawarła układu. 
**§ 4.** Organizacja związkowa, która po zawarciu układu stała się 
reprezentatywna na podstawie art. 252 ust. 1 lub art. 253 ust. 1 ustawy o związkach 
zawodowych, może wstąpić w prawa i obowiązki strony układu, składając w tym 
celu oświadczenie stronom tego układu. Do zakładowej organizacji związkowej 
stosuje się odpowiednio art. 253 ust. 3–6 ustawy o związkach zawodowych, a w 
celu stwierdzenia reprezentatywności – art. 251 ust. 2–12 ustawy o związkach 
zawodowych. 
**§ 5.** Informacja o wstąpieniu organizacji związkowej w prawa i obowiązki 
strony układu podlega zgłoszeniu do rejestru układów.

***
## Art. 24110. {#kp-jedenasty-art-24110}

**§ 1.** Strony uprawnione do zawarcia układu mogą zawrzeć 
porozumienie o stosowaniu w całości lub w części układu, którego nie są stronami. 
Do porozumienia stosuje się odpowiednio przepisy dotyczące układu. 

 
 
 
s. 174/195 
 
2025-08-06 
**§ 2.** Organ rejestrujący porozumienie, o którym mowa w § 1, powiadamia 
strony układu o rejestracji tego porozumienia. 
**§ 3.** Zmiana postanowień układu przez strony, które zawarły ten układ, nie 
powoduje zmian w treści porozumienia, o którym mowa w § 1.

***
## Art. 24111. {#kp-jedenasty-art-24111}

**§ 1.** Układ podlega wpisowi do rejestru prowadzonego dla: 
- 1) układów ponadzakładowych przez ministra właściwego do spraw pracy; 
- 2) układów zakładowych przez właściwego okręgowego inspektora pracy. 
**§ 2.** Układ zawarty zgodnie z prawem podlega rejestracji w ciągu: 
- 1) trzech miesięcy – w odniesieniu do układu ponadzakładowego, 
- 2) jednego miesiąca – w odniesieniu do układu zakładowego 
– od dnia złożenia wniosku w tej sprawie przez jedną ze stron układu. 
**§ 3.** Jeżeli postanowienia układu są niezgodne z prawem, organ uprawniony 
do jego rejestracji może: 
- 1) za zgodą stron układu wpisać układ do rejestru bez tych postanowień; 
- 2) wezwać strony układu do dokonania w układzie odpowiednich zmian 
w terminie 14 dni. 
**§ 4.** Jeżeli strony układu nie wyrażą zgody na wpisanie układu do rejestru bez 
postanowień niezgodnych z prawem lub nie dokonają w terminie odpowiednich 
zmian w układzie, organ uprawniony do rejestracji układu odmawia jego rejestracji. 
**§ 5.** W ciągu 30 dni od dnia zawiadomienia o odmowie rejestracji przysługuje 
odwołanie: 
- 1) stronom układu ponadzakładowego – do Sądu Okręgowego – Sądu Pracy 
i Ubezpieczeń Społecznych w Warszawie; 
- 2) stronom układu zakładowego – do właściwego dla siedziby pracodawcy sądu 
rejonowego – sądu pracy. 
Sąd rozpoznaje sprawę w trybie przepisów Kodeksu postępowania cywilnego 
o postępowaniu nieprocesowym. 
**§ 51.** Osoba mająca interes prawny może, w terminie 90 dni od dnia 
zarejestrowania układu, wystąpić do organu, który układ zarejestrował, 
z zastrzeżeniem, że został on zawarty z naruszeniem przepisów o zawieraniu 
układów zbiorowych pracy. Zastrzeżenie powinno być złożone na piśmie 
i zawierać uzasadnienie. 

 
 
 
s. 175/195 
 
2025-08-06 
**§ 52.** Organ rejestrujący w ciągu 14 dni po otrzymaniu zastrzeżenia, o którym 
mowa w § 51, wzywa strony układu do przedstawienia dokumentów i złożenia 
wyjaśnień niezbędnych do rozpatrzenia zastrzeżenia. 
**§ 53.** W razie stwierdzenia, że układ został zawarty z naruszeniem przepisów 
o zawieraniu układów zbiorowych pracy, organ rejestrujący wzywa strony układu 
do usunięcia tych nieprawidłowości, chyba że ich usunięcie nie jest możliwe. 
**§ 54.** W razie gdy: 
- 1) strony układu nie przedstawią w wyznaczonym terminie, nie krótszym niż 
30 dni, dokumentów i wyjaśnień, o których mowa w § 52, lub 
- 2) strony układu w wyznaczonym terminie, nie krótszym niż 30 dni, nie usuną 
nieprawidłowości, o której mowa w § 53, lub usunięcie tej nieprawidłowości 
nie jest możliwe, 
organ rejestrujący wykreśla układ z rejestru układów. Przepis § 5 stosuje się 
odpowiednio. 
**§ 55.** Warunki umów o pracę lub innych aktów stanowiących podstawę 
nawiązania stosunku pracy, wynikające z układu wykreślonego z rejestru układów, 
obowiązują do upływu okresu wypowiedzenia tych warunków. Przepis art. 24113 
§ 2 zdanie drugie stosuje się. 
**§ 6.** Minister właściwy do spraw pracy w celu zapewnienia jednolitych zasad 
rejestracji układów zbiorowych pracy i prowadzenia rejestru tych układów określi, 
w drodze rozporządzenia, tryb postępowania w sprawie rejestracji układów 
zbiorowych pracy, w szczególności warunki składania wniosków o wpis do rejestru 
układów i o rejestrację układu, zakres informacji objętych tymi wnioskami oraz 
dokumenty dołączane do wniosków, skutki niezachowania wymogów dotyczących 
formy i treści wniosków, jak również tryb wykreślenia układu z rejestru, a także 
sposób prowadzenia rejestru układów i akt rejestrowych oraz wzory klauzul 
rejestracyjnych i kart rejestrowych.

***
## Art. 24112. {#kp-jedenasty-art-24112}

**§ 1.** Układ wchodzi w życie w terminie w nim określonym, nie 
wcześniej jednak niż z dniem zarejestrowania. 
**§ 2.** Pracodawca jest obowiązany: 
- 1) zawiadomić pracowników o wejściu układu w życie, o zmianach dotyczących 
układu oraz o wypowiedzeniu i rozwiązaniu układu; 

 
 
 
s. 176/195 
 
2025-08-06 
- 2) dostarczyć zakładowej organizacji związkowej niezbędną liczbę egzemplarzy 
układu; 
- 3) na żądanie pracownika udostępnić do wglądu tekst układu i wyjaśnić jego 
treść.

***
## Art. 24113. {#kp-jedenasty-art-24113}

**§ 1.** Korzystniejsze postanowienia układu, z dniem jego wejścia 
w życie, zastępują z mocy prawa wynikające z dotychczasowych przepisów prawa 
pracy warunki umowy o pracę lub innego aktu stanowiącego podstawę nawiązania 
stosunku pracy. 
**§ 2.** Postanowienia układu mniej korzystne dla pracowników wprowadza się 
w drodze wypowiedzenia pracownikom dotychczasowych warunków umowy 
o pracę lub innego aktu stanowiącego podstawę nawiązania stosunku pracy. Przy 
wypowiedzeniu dotychczasowych warunków umowy o pracę lub innego aktu 
stanowiącego podstawę nawiązania stosunku pracy nie mają zastosowania przepisy 
ograniczające dopuszczalność wypowiadania warunków takiej umowy lub aktu. 
## Rozdział II Ponadzakładowy układ zbiorowy pracy

***
## Art. 24114. {#kp-jedenasty-art-24114}

**§ 1.** Ponadzakładowy układ zbiorowy pracy, zwany dalej 
„układem ponadzakładowym”, zawierają: 
- 1) ze strony pracowników właściwy statutowo organ ponadzakładowej 
organizacji związkowej; 
- 2) ze strony pracodawców właściwy statutowo organ organizacji pracodawców 
– w imieniu zrzeszonych w tej organizacji pracodawców. 
**§ 2.** (uchylony) 
**§ 3.** (uchylony) 
Art. 24114a. § 1. W razie gdy ponadzakładowa organizacja związkowa 
reprezentująca pracowników, dla których ma być zawarty układ ponadzakładowy, 
wchodzi w skład zrzeszenia (federacji) związków zawodowych lub ogólnokrajowej 
organizacji 
międzyzwiązkowej 
(konfederacji), 
do 
zawarcia 
układu 
jest 
upoważniona, z zastrzeżeniem § 2, wyłącznie ta ponadzakładowa organizacja 
związkowa. 
**§ 2.** Ogólnokrajowa 
organizacja 
międzyzwiązkowa 
(konfederacja) 
uczestniczy w rokowaniach i zawiera układ ponadzakładowy w miejsce 

 
 
 
s. 177/195 
 
2025-08-06 
 
wchodzących w jej skład ponadzakładowych organizacji związkowych, 
reprezentujących pracowników, dla których układ ten ma być zawarty i które 
uzyskały reprezentatywność na podstawie art. 252 ust. 3 ustawy o związkach 
zawodowych, w razie skierowania do niej umotywowanego pisemnego wniosku w 
tej sprawie przez organizację pracodawców prowadzącą rokowania w sprawie 
zawarcia tego układu lub co najmniej jedną z pozostałych ponadzakładowych 
organizacji związkowych prowadzących rokowania w sprawie zawarcia tego 
układu. Organizacja, do której skierowano wniosek, nie może odmówić 
przystąpienia do rokowań; odmowa skutkuje pozbawieniem reprezentatywności 
dla potrzeb określonego układu ponadzakładowego wszystkich organizacji, w 
miejsce których powinna wstąpić organizacja, do której skierowany został wniosek. 
**§ 3.** W razie gdy organizacja pracodawców zrzeszająca pracodawców, którzy 
mają być objęci układem ponadzakładowym, wchodzi w skład federacji lub 
konfederacji, prawo do zawarcia układu przysługuje organizacji, w której 
pracodawcy są bezpośrednio zrzeszeni.

***
## Art. 24115. {#kp-jedenasty-art-24115}

Prawo 
wystąpienia 
z inicjatywą 
zawarcia 
układu 
ponadzakładowego przysługuje: 
- 1) organizacji pracodawców uprawnionej do zawarcia układu ze strony 
pracodawców; 
- 2) każdej 
ponadzakładowej 
organizacji 
związkowej 
reprezentującej 
pracowników, dla których ma być zawarty układ.

***
## Art. 24116. {#kp-jedenasty-art-24116}

**§ 1.** Jeżeli pracowników, dla których ma być zawarty układ 
ponadzakładowy, reprezentuje więcej niż jedna organizacja związkowa, rokowania 
w celu zawarcia układu prowadzi ich wspólna reprezentacja lub działające 
wspólnie poszczególne organizacje związkowe. 
**§ 2.** Jeżeli w terminie wyznaczonym przez podmiot występujący z inicjatywą 
zawarcia układu ponadzakładowego, nie krótszym niż 30 dni od dnia zgłoszenia 
inicjatywy zawarcia układu, nie wszystkie organizacje związkowe przystąpią 
do rokowań w trybie określonym w § 1, do prowadzenia rokowań są uprawnione 
organizacje związkowe, które przystąpiły do rokowań. Rokowania te są 
prowadzone w trybie określonym w § 1. 

 
 
 
s. 178/195 
 
2025-08-06 
**§ 3.** Warunkiem prowadzenia rokowań, o których mowa w § 2, jest 
uczestniczenie w nich co najmniej jednej reprezentatywnej ponadzakładowej 
organizacji związkowej w rozumieniu art. 252 ust. 1 ustawy o związkach 
zawodowych. 
**§ 4.** Jeżeli przed zawarciem układu zostanie utworzona ponadzakładowa 
organizacja związkowa, ma ona prawo przystąpić do rokowań. 
**§ 5.** Układ ponadzakładowy zawierają wszystkie organizacje związkowe, 
które prowadziły rokowania nad tym układem, bądź co najmniej wszystkie 
reprezentatywne organizacje związkowe, w rozumieniu art. 252 ust. 1 ustawy o 
związkach zawodowych, uczestniczące w rokowaniach.

***
## Art. 24117. {#kp-jedenasty-art-24117}

(uchylony)

***
## Art. 24118. {#kp-jedenasty-art-24118}

**§ 1.** Na 
wspólny 
wniosek 
organizacji 
pracodawców 
i ponadzakładowych 
organizacji 
związkowych, 
które 
zawarły 
układ 
ponadzakładowy, minister właściwy do spraw pracy może – gdy wymaga tego 
ważny interes społeczny – rozszerzyć, w drodze rozporządzenia, stosowanie tego 
układu w całości lub w części na pracowników zatrudnionych u pracodawcy 
nieobjętego żadnym układem ponadzakładowym, prowadzącego działalność 
gospodarczą taką samą lub zbliżoną do działalności pracodawców objętych tym 
układem, ustalonej na podstawie odrębnych przepisów dotyczących klasyfikacji 
działalności, po zasięgnięciu opinii tego pracodawcy lub wskazanej przez niego 
organizacji pracodawców oraz zakładowej organizacji związkowej, o ile taka działa 
u pracodawcy. 
**§ 2.** Wniosek o rozszerzenie stosowania układu ponadzakładowego powinien 
wskazywać nazwę pracodawcy i jego siedzibę, a także uzasadnienie potrzeby 
rozszerzenia stosowania układu ponadzakładowego oraz zawierać informacje 
i dokumenty niezbędne do stwierdzenia wymogów, o których mowa w § 1. 
**§ 3.** (uchylony) 
**§ 4.** Rozszerzenie stosowania układu ponadzakładowego obowiązuje nie 
dłużej niż do czasu objęcia pracodawcy innym układem ponadzakładowym. 
**§ 5.** Do wniosku o uchylenie rozszerzenia stosowania układu stosuje się 
odpowiednio przepisy § 1 i 2 oraz art. 2418 § 2. 

 
 
 
s. 179/195 
 
2025-08-06

***
## Art. 24119. {#kp-jedenasty-art-24119}

**§ 1.** W razie połączenia lub podziału organizacji związkowej lub 
organizacji pracodawców, która zawarła układ ponadzakładowy, jej prawa 
i obowiązki przechodzą na organizację powstałą w wyniku połączenia lub 
podziału. 
**§ 2.** W razie 
rozwiązania 
organizacji 
pracodawców 
lub 
wszystkich 
organizacji związkowych, będących stroną układu ponadzakładowego, pracodawca 
może odstąpić od stosowania układu ponadzakładowego w całości lub w części po 
upływie okresu co najmniej równego okresowi wypowiedzenia układu, składając 
stosowne oświadczenie na piśmie pozostałej stronie tego układu. Przepis art. 2418 
§ 2 stosuje się odpowiednio. 
**§ 3.** (uchylony) 
**§ 4.** Informacje dotyczące spraw, o których mowa w § 1 i 2, podlegają 
zgłoszeniu do rejestru układów.

***
## Art. 24120. {#kp-jedenasty-art-24120}

(uchylony)

***
## Art. 24121. {#kp-jedenasty-art-24121}

(uchylony) 
## Rozdział III Zakładowy układ zbiorowy pracy

***
## Art. 24122. {#kp-jedenasty-art-24122}

(uchylony)

***
## Art. 24123. {#kp-jedenasty-art-24123}

Zakładowy układ zbiorowy pracy, zwany dalej „układem 
zakładowym”, zawiera pracodawca i zakładowa organizacja związkowa.

***
## Art. 24124. {#kp-jedenasty-art-24124}

Prawo wystąpienia z inicjatywą zawarcia układu zakładowego 
przysługuje: 
- 1) pracodawcy; 
- 2) każdej zakładowej organizacji związkowej.

***
## Art. 24125. {#kp-jedenasty-art-24125}

**§ 1.** Jeżeli pracowników, dla których ma być zawarty układ 
zakładowy, reprezentuje więcej niż jedna organizacja związkowa, rokowania 
w celu zawarcia układu prowadzi ich wspólna reprezentacja lub działające 
wspólnie poszczególne organizacje związkowe. 
**§ 2.** Jeżeli w terminie wyznaczonym przez podmiot występujący z inicjatywą 
zawarcia układu zakładowego, nie krótszym niż 30 dni od dnia zgłoszenia 
inicjatywy zawarcia układu, nie wszystkie organizacje związkowe przystąpią do 

 
 
 
s. 180/195 
 
2025-08-06 
 
rokowań w trybie określonym w § 1, do prowadzenia rokowań są uprawnione 
organizacje związkowe, które przystąpiły do rokowań. Rokowania te są 
prowadzone w trybie określonym w § 1. 
**§ 3.** Warunkiem prowadzenia rokowań, o których mowa w § 2, jest 
uczestniczenie w nich co najmniej jednej reprezentatywnej zakładowej organizacji 
związkowej w rozumieniu art. 253 ust. 1 lub 2 ustawy o związkach zawodowych. 
**§ 4.** Jeżeli przed zawarciem układu zostanie utworzona zakładowa 
organizacja związkowa, ma ona prawo przystąpić do rokowań. 
**§ 5.** Układ zakładowy zawierają wszystkie organizacje związkowe, które 
prowadziły rokowania nad tym układem, bądź przynajmniej wszystkie 
reprezentatywne organizacje związkowe, w rozumieniu art. 253 ust. 1 lub 2 ustawy 
o związkach zawodowych, uczestniczące w rokowaniach. 
Art. 24125a. (uchylony)

***
## Art. 24126. {#kp-jedenasty-art-24126}

**§ 1.** Postanowienia układu zakładowego nie mogą być mniej 
korzystne dla pracowników niż postanowienia obejmującego ich układu 
ponadzakładowego. 
**§ 2.** Układ zakładowy nie może określać warunków wynagradzania 
pracowników 
zarządzających 
w imieniu 
pracodawcy 
zakładem 
pracy, 
w rozumieniu art. 128 § 2 pkt 2, oraz osób zarządzających zakładem pracy na innej 
podstawie niż stosunek pracy.

***
## Art. 24127. {#kp-jedenasty-art-24127}

**§ 1.** Ze względu na sytuację finansową pracodawcy strony układu 
zakładowego mogą zawrzeć porozumienie o zawieszeniu stosowania u danego 
pracodawcy, w całości lub w części, tego układu oraz układu ponadzakładowego 
bądź jednego z nich, na okres nie dłuższy niż 3 lata. W razie gdy u pracodawcy 
obowiązuje jedynie układ ponadzakładowy, porozumienie o zawieszeniu 
stosowania tego układu lub niektórych jego postanowień mogą zawrzeć strony 
uprawnione do zawarcia układu zakładowego. 
**§ 2.** Porozumienie, o którym mowa w § 1, podlega zgłoszeniu do rejestru 
odpowiednio układów zakładowych lub układów ponadzakładowych. Ponadto 
informację 
o zawieszeniu 
stosowania 
układu 
ponadzakładowego 
strony 
porozumienia przekazują stronom tego układu. 

 
 
 
s. 181/195 
 
2025-08-06 
**§ 3.** W zakresie i przez czas określony w porozumieniu, o którym mowa 
w § 1, nie stosuje się z mocy prawa wynikających z układu ponadzakładowego oraz 
z układu zakładowego warunków umów o pracę i innych aktów stanowiących 
podstawę nawiązania stosunku pracy.

***
## Art. 24128. {#kp-jedenasty-art-24128}

**§ 1.** Układ zakładowy może obejmować więcej niż jednego 
pracodawcę, jeżeli pracodawcy ci wchodzą w skład tej samej osoby prawnej. 
**§ 2.** Rokowania nad zawarciem układu zakładowego prowadzą: 
- 1) właściwy organ osoby prawnej, o której mowa w § 1, oraz 
- 2) wszystkie zakładowe organizacje związkowe działające u pracodawców, 
z zastrzeżeniem § 3. 
**§ 3.** Jeżeli zakładowe organizacje związkowe należą do tego samego związku, 
federacji lub konfederacji, do prowadzenia rokowań w ich imieniu jest uprawniony 
organ wskazany przez ten związek, federację lub konfederację. 
**§ 4.** Jeżeli w terminie wyznaczonym przez podmiot występujący z inicjatywą 
zawarcia układu zakładowego, nie krótszym niż 30 dni od dnia zgłoszenia 
inicjatywy zawarcia układu, nie wszystkie organizacje związkowe przystąpią do 
rokowań, do prowadzenia rokowań są uprawnione organizacje związkowe, które 
do nich przystąpiły, pod warunkiem uczestniczenia w tych rokowaniach wszystkich 
organów, o których mowa w § 3, wskazanych przez ponadzakładowe organizacje 
związkowe 
reprezentujące 
pracowników 
zatrudnionych 
u 
pracodawców 
wchodzących w skład osoby prawnej, reprezentatywne w rozumieniu art. 252 ust. 1 
pkt 1 i 2 oraz ust. 3 ustawy o związkach zawodowych. 
**§ 5.** Układ zakładowy zawierają wszystkie organizacje związkowe, które 
prowadziły rokowania nad tym układem, bądź co najmniej wszystkie organy, o 
których mowa w § 3, wskazane przez ponadzakładowe organizacje związkowe 
reprezentujące pracowników zatrudnionych u pracodawców wchodzących w skład 
osoby prawnej, reprezentatywne w rozumieniu art. 252 ust. 1 pkt 1 i 2 oraz ust. 3 
ustawy o związkach zawodowych. 
**§ 6.** Przepisy § 1–5 stosuje się odpowiednio do jednostki nieposiadającej 
osobowości prawnej, w skład której wchodzi więcej niż jeden pracodawca.

***
## Art. 24129. {#kp-jedenasty-art-24129}

**§ 1.** (uchylony) 

 
 
 
s. 182/195 
 
2025-08-06 
**§ 2.** W razie połączenia zakładowych organizacji związkowych, z których 
choćby jedna zawarła układ zakładowy, jej prawa i obowiązki przechodzą na 
organizację powstałą w wyniku połączenia. 
**§ 3.** W razie rozwiązania wszystkich organizacji związkowych, które zawarły 
układ zakładowy, pracodawca może odstąpić od stosowania tego układu w całości 
lub w części po upływie okresu co najmniej równego okresowi wypowiedzenia 
układu. Przepis art. 2418 § 2 stosuje się odpowiednio. 
**§ 4.** (uchylony) 
**§ 5.** (uchylony)

***
## Art. 24130. {#kp-jedenasty-art-24130}

Przepisy rozdziału stosuje się odpowiednio do międzyzakładowej 
organizacji związkowej działającej u pracodawcy.

