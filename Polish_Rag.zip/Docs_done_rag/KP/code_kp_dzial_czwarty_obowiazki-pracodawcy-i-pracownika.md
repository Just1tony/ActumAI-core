---
id: code.kp.dzial.czwarty
title: "Kodeks pracy — Dział CZWARTY (Obowiązki pracodawcy i pracownika)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1974 nr 24 poz. 141"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KP — Dział CZWARTY"]
tags: ["KP","Kodeks pracy","Dział CZWARTY","PL"]
source_pdf: "D19740141Lj.pdf"
articles: "Art. 94–23715"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kp-czwarty-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks pracy — Dział CZWARTY: Obowiązki pracodawcy i pracownika

Obowiązki pracodawcy i pracownika 
## Rozdział I Obowiązki pracodawcy
***
## Art. 94. {#kp-czwarty-art-94}

Pracodawca jest obowiązany w szczególności: 
- 1) zaznajamiać pracowników podejmujących pracę z zakresem ich obowiązków, 
sposobem wykonywania pracy na wyznaczonych stanowiskach oraz ich 
podstawowymi uprawnieniami; 
1a) informować pracowników o warunkach ich zatrudnienia, o których mowa 
w art. 29 § 3, 32 i 33 lub w art. 291 § 2 i 4; 

 
 
 
s. 68/195 
 
2025-08-06 
- 2) organizować pracę w sposób zapewniający pełne wykorzystanie czasu pracy, 
jak również osiąganie przez pracowników, przy wykorzystaniu ich uzdolnień 
i kwalifikacji, wysokiej wydajności i należytej jakości pracy; 
2a) organizować pracę w sposób zapewniający zmniejszenie uciążliwości pracy, 
zwłaszcza pracy monotonnej i pracy w ustalonym z góry tempie; 
2b) przeciwdziałać dyskryminacji w zatrudnieniu, w szczególności ze względu na 
płeć, wiek, niepełnosprawność, rasę, religię, narodowość, przekonania 
polityczne, przynależność związkową, pochodzenie etniczne, wyznanie, 
orientację seksualną, a także ze względu na zatrudnienie na czas określony lub 
nieokreślony albo w pełnym lub w niepełnym wymiarze czasu pracy; 
- 3) (uchylony) 
- 4) zapewniać bezpieczne i higieniczne warunki pracy oraz prowadzić 
systematyczne szkolenie pracowników w zakresie bezpieczeństwa i higieny 
pracy; 
- 5) terminowo i prawidłowo wypłacać wynagrodzenie; 
- 6) ułatwiać pracownikom podnoszenie kwalifikacji zawodowych; 
- 7) stwarzać pracownikom podejmującym zatrudnienie po ukończeniu szkoły 
prowadzącej kształcenie zawodowe lub szkoły wyższej warunki sprzyjające 
przystosowaniu się do należytego wykonywania pracy; 
- 8) zaspokajać w miarę posiadanych środków socjalne potrzeby pracowników; 
- 9) stosować obiektywne i sprawiedliwe kryteria oceny pracowników oraz 
wyników ich pracy; 
9a) prowadzić i przechowywać w postaci papierowej lub elektronicznej 
dokumentację w sprawach związanych ze stosunkiem pracy oraz akta 
osobowe pracowników (dokumentacja pracownicza); 
9b) przechowywać 
dokumentację 
pracowniczą 
w 
sposób 
gwarantujący 
zachowanie jej poufności, integralności, kompletności oraz dostępności, w 
warunkach niegrożących uszkodzeniem lub zniszczeniem przez okres 
zatrudnienia, a także przez okres 10 lat, licząc od końca roku kalendarzowego, 
w którym stosunek pracy uległ rozwiązaniu lub wygasł, chyba że odrębne 
przepisy 
przewidują 
dłuższy 
okres 
przechowywania 
dokumentacji 
pracowniczej; 
- 10) wpływać na kształtowanie w zakładzie pracy zasad współżycia społecznego. 

 
 
 
s. 69/195 
 
2025-08-06

***
## Art. 941. {#kp-czwarty-art-941}

Pracodawca udostępnia pracownikom tekst przepisów dotyczących 
równego 
traktowania 
w zatrudnieniu 
w formie 
pisemnej 
informacji 
rozpowszechnionej na terenie zakładu pracy lub zapewnia pracownikom dostęp do 
tych przepisów w inny sposób przyjęty u danego pracodawcy.

***
## Art. 942. {#kp-czwarty-art-942}

Pracodawca jest obowiązany informować pracowników w sposób 
przyjęty u danego pracodawcy o: 
- 1) możliwości zatrudnienia w pełnym lub w niepełnym wymiarze czasu pracy; 
- 2) możliwości awansu; 
- 3) wolnych stanowiskach pracy.

***
## Art. 943. {#kp-czwarty-art-943}

**§ 1.** Pracodawca jest obowiązany przeciwdziałać mobbingowi. 
**§ 2.** Mobbing oznacza działania lub zachowania dotyczące pracownika lub 
skierowane przeciwko pracownikowi, polegające na uporczywym i długotrwałym 
nękaniu lub zastraszaniu pracownika, wywołujące u niego zaniżoną ocenę 
przydatności zawodowej, powodujące lub mające na celu poniżenie lub 
ośmieszenie pracownika, izolowanie go lub wyeliminowanie z zespołu 
współpracowników. 
**§ 3.** Pracownik, u którego mobbing wywołał rozstrój zdrowia, może 
dochodzić od pracodawcy odpowiedniej sumy tytułem zadośćuczynienia 
pieniężnego za doznaną krzywdę. 
**§ 4.** Pracownik, który doznał mobbingu lub wskutek mobbingu rozwiązał 
umowę o pracę, ma prawo dochodzić od pracodawcy odszkodowania w wysokości 
nie niższej niż minimalne wynagrodzenie za pracę, ustalane na podstawie 
odrębnych przepisów. 
**§ 5.** Oświadczenie pracownika o rozwiązaniu umowy o pracę powinno 
nastąpić na piśmie z podaniem przyczyny, o której mowa w § 2, uzasadniającej 
rozwiązanie umowy.

***
## Art. 944. {#kp-czwarty-art-944}

Jeżeli przechowywana dokumentacja pracownicza może stanowić 
lub stanowi dowód w postępowaniu, a pracodawca: 
- 1) jest stroną tego postępowania – przechowuje dokumentację pracowniczą do 
czasu jego prawomocnego zakończenia, nie krócej jednak niż do upływu 
okresu, o którym mowa w art. 94 pkt 9b; art. 947 stosuje się odpowiednio; 

 
 
 
s. 70/195 
 
2025-08-06 
- 2) powziął wiadomość o wytoczeniu powództwa lub wszczęciu postępowania – 
okres przechowywania dokumentacji pracowniczej, o którym mowa w art. 94 
pkt 9b, przedłuża się o 12 miesięcy, po upływie których pracodawca 
zawiadamia, w postaci papierowej lub elektronicznej, byłego pracownika o 
możliwości odbioru tej dokumentacji w terminie 30 dni od dnia otrzymania 
zawiadomienia oraz, w przypadku jej nieodebrania, o zniszczeniu 
dokumentacji pracowniczej; art. 947 stosuje się odpowiednio.

***
## Art. 945. {#kp-czwarty-art-945}

**§ 1.** W przypadku ponownego nawiązania stosunku pracy z tym 
samym pracownikiem w okresie, o którym mowa w art. 94 pkt 9b, pracodawca 
kontynuuje prowadzenie dla tego pracownika dotychczasowej dokumentacji 
pracowniczej. 
**§ 2.** W przypadku, o którym mowa w § 1, okres przechowywania 
dokumentacji pracowniczej liczy się od końca roku kalendarzowego, w którym 
kończący się najpóźniej stosunek pracy rozwiązał się lub wygasł.

***
## Art. 946. {#kp-czwarty-art-946}

W przypadku rozwiązania lub wygaśnięcia stosunku pracy 
pracodawca wraz ze świadectwem pracy wydaje pracownikowi w postaci 
papierowej lub elektronicznej informację o: 
- 1) okresie przechowywania dokumentacji pracowniczej, o którym mowa w art. 
94 pkt 9b lub w art. 945 § 2; 
- 2) możliwości odbioru przez pracownika dokumentacji pracowniczej do końca 
miesiąca kalendarzowego następującego po upływie okresu przechowywania 
dokumentacji pracowniczej, o którym mowa w art. 94 pkt 9b lub w art. 945 § 
2; 
- 3) zniszczeniu dokumentacji pracowniczej w przypadku jej nieodebrania w 
okresie, o którym mowa w pkt 2.

***
## Art. 947. {#kp-czwarty-art-947}

**§ 1.** Pracodawca niszczy dokumentację pracowniczą w sposób 
uniemożliwiający odtworzenie jej treści, w terminie do 12 miesięcy po upływie 
okresu przeznaczonego na odbiór dokumentacji pracowniczej, o którym mowa 
w art. 946 pkt 2. 
**§ 2.** W terminie, o którym mowa w § 1, do czasu zniszczenia, pracodawca 
może wydać dokumentację pracowniczą byłemu pracownikowi. 

 
 
 
s. 71/195 
 
2025-08-06

***
## Art. 948. {#kp-czwarty-art-948}

**§ 1.** Pracodawca może zmieniać postać, w której prowadzi i 
przechowuje dokumentację pracowniczą. 
**§ 2.** Zmiana postaci dokumentacji pracowniczej z papierowej na elektroniczną 
następuje przez sporządzenie odwzorowania cyfrowego, w szczególności skanu, i 
opatrzenie go kwalifikowanym podpisem elektronicznym lub kwalifikowaną 
pieczęcią 
elektroniczną 
pracodawcy 
lub 
kwalifikowanym 
podpisem 
elektronicznym upoważnionej przez pracodawcę osoby, potwierdzającym 
zgodność odwzorowania cyfrowego z dokumentem papierowym. 
**§ 3.** Zmiana postaci dokumentacji pracowniczej z elektronicznej na papierową 
następuje przez sporządzenie wydruku i opatrzenie go podpisem pracodawcy lub 
osoby przez niego upoważnionej, potwierdzającym zgodność wydruku 
z dokumentem elektronicznym.

***
## Art. 949. {#kp-czwarty-art-949}

**§ 1.** Pracodawca informuje pracowników w sposób przyjęty u 
danego pracodawcy o: 
- 1) zmianie postaci prowadzenia i przechowywania dokumentacji pracowniczej; 
- 2) możliwości odbioru poprzedniej postaci dokumentacji pracowniczej w 
terminie 30 dni od dnia przekazania informacji, o której mowa w pkt 1. 
**§ 2.** Pracodawca zawiadamia w postaci papierowej lub elektronicznej byłego 
pracownika o możliwości odbioru poprzedniej postaci dokumentacji pracowniczej 
w terminie 30 dni od dnia zawiadomienia. 
**§ 3.** W przypadku śmierci pracownika lub byłego pracownika prawo odbioru 
poprzedniej postaci dokumentacji pracowniczej przysługuje następującym 
członkom rodziny: 
- 1) dzieciom 
własnym, 
dzieciom 
drugiego 
małżonka 
oraz 
dzieciom 
przysposobionym; 
- 2) przyjętym na wychowanie i utrzymanie przed osiągnięciem pełnoletności 
wnukom, rodzeństwu i innym dzieciom, z wyłączeniem dzieci przyjętych na 
wychowanie i utrzymanie w ramach rodziny zastępczej lub rodzinnego domu 
dziecka; 
- 3) małżonkowi (wdowie i wdowcowi); 
- 4) rodzicom, w tym ojczymowi i macosze oraz osobom przysposabiającym. 

 
 
 
s. 72/195 
 
2025-08-06

***
## Art. 9410. {#kp-czwarty-art-9410}

W przypadku nieodebrania poprzedniej postaci dokumentacji 
pracowniczej zgodnie z art. 949, pracodawca może zniszczyć poprzednią postać 
takiej dokumentacji.

***
## Art. 9411. {#kp-czwarty-art-9411}

Dokumentacja pracownicza prowadzona i przechowywana w 
postaci elektronicznej jest równoważna z dokumentacją pracowniczą prowadzoną 
i przechowywaną w postaci papierowej.

***
## Art. 9412. {#kp-czwarty-art-9412}

Pracodawca wydaje kopię całości lub części dokumentacji 
pracowniczej na wniosek: 
- 1) pracownika lub byłego pracownika albo 
- 2) osób, o których mowa w art. 949 § 3, w przypadku śmierci pracownika lub 
byłego pracownika 
– złożony w postaci papierowej lub elektronicznej.

***
## Art. 9413. {#kp-czwarty-art-9413}

Jeżeli 
obowiązek 
pracodawcy 
przeprowadzenia 
szkoleń 
pracowników niezbędnych do wykonywania określonego rodzaju pracy lub pracy 
na określonym stanowisku wynika z postanowień układu zbiorowego pracy lub 
innego porozumienia zbiorowego, lub z regulaminu, lub przepisów prawa, lub 
umowy o pracę oraz w przypadku szkoleń odbywanych przez pracownika na 
podstawie polecenia przełożonego, szkolenia takie odbywają się na koszt 
pracodawcy oraz, w miarę możliwości, w godzinach pracy pracownika. Czas 
szkolenia odbywanego poza normalnymi godzinami pracy pracownika wlicza się 
do czasu pracy.

***
## Art. 95. {#kp-czwarty-art-95}

(uchylony)

***
## Art. 96. {#kp-czwarty-art-96}

(uchylony)

***
## Art. 97. {#kp-czwarty-art-97}

**§ 1.** W związku z rozwiązaniem lub wygaśnięciem stosunku pracy 
pracodawca jest obowiązany wydać pracownikowi świadectwo pracy w dniu, 
w którym następuje ustanie stosunku pracy, jeżeli nie zamierza nawiązać z nim 
kolejnego stosunku pracy w ciągu 7 dni od dnia rozwiązania lub wygaśnięcia 
poprzedniego stosunku pracy. Jeżeli z przyczyn obiektywnych wydanie 
świadectwa pracy pracownikowi albo osobie przez niego upoważnionej w tym 
terminie nie jest możliwe, pracodawca w ciągu 7 dni od dnia upływu tego terminu 
przesyła świadectwo pracy pracownikowi lub tej osobie za pośrednictwem 

 
 
 
s. 73/195 
 
2025-08-06 
 
operatora pocztowego w rozumieniu ustawy z dnia 23 listopada 2012 r. – Prawo 
pocztowe (Dz. U. z 2023 r. poz. 1640 oraz z 2024 r. poz. 467, 1222 i 1717) albo 
doręcza je w inny sposób. Świadectwo pracy dotyczy okresu lub okresów 
zatrudnienia, za które dotychczas nie wydano świadectwa pracy. 
**§ 11.** W przypadku nawiązania z tym samym pracownikiem kolejnego 
stosunku pracy w ciągu 7 dni od dnia rozwiązania lub wygaśnięcia poprzedniego 
stosunku pracy, pracodawca jest obowiązany wydać pracownikowi świadectwo 
pracy wyłącznie na jego wniosek, złożony w postaci papierowej lub elektronicznej; 
wniosek może być złożony w każdym czasie i dotyczyć wydania świadectwa pracy 
dotyczącego poprzedniego okresu zatrudnienia albo wszystkich okresów 
zatrudnienia, za które dotychczas nie wydano świadectwa pracy. 
**§ 12.** W przypadku, o którym mowa w § 11, pracodawca jest obowiązany 
wydać pracownikowi świadectwo pracy w ciągu 7 dni od dnia złożenia wniosku. 
**§ 13.** Wydanie świadectwa pracy nie może być uzależnione od uprzedniego 
rozliczenia się pracownika z pracodawcą. 
**§ 2.** W świadectwie pracy należy podać informacje dotyczące okresu i rodzaju 
wykonywanej pracy, zajmowanych stanowisk, trybu rozwiązania albo okoliczności 
wygaśnięcia stosunku pracy, a także inne informacje niezbędne do ustalenia 
uprawnień pracowniczych i uprawnień z ubezpieczenia społecznego. Ponadto 
w świadectwie pracy zamieszcza się wzmiankę o zajęciu wynagrodzenia za pracę 
w myśl przepisów o postępowaniu egzekucyjnym. Na żądanie pracownika 
w świadectwie pracy należy podać także informację o wysokości i składnikach 
wynagrodzenia oraz o uzyskanych kwalifikacjach. 
**§ 21.** Pracownik może w ciągu 14 dni od otrzymania świadectwa pracy 
wystąpić z wnioskiem do pracodawcy o sprostowanie świadectwa pracy. W razie 
nieuwzględnienia wniosku pracownikowi przysługuje, w ciągu 14 dni od 
zawiadomienia o odmowie sprostowania świadectwa pracy, prawo wystąpienia 
z żądaniem jego sprostowania do sądu pracy. W przypadku niezawiadomienia 
przez pracodawcę o odmowie sprostowania świadectwa pracy, żądanie 
sprostowania świadectwa pracy wnosi się do sądu pracy. 
**§ 3.** Jeżeli z orzeczenia sądu pracy wynika, że rozwiązanie z pracownikiem 
umowy o pracę bez wypowiedzenia z jego winy nastąpiło z naruszeniem przepisów 

 
 
 
s. 74/195 
 
2025-08-06 
 
o rozwiązywaniu w tym trybie umów o pracę, pracodawca jest obowiązany zamieś-
cić w świadectwie pracy informację, że rozwiązanie umowy o pracę nastąpiło za 
wypowiedzeniem dokonanym przez pracodawcę. 
**§ 4.** Minister właściwy do spraw pracy określi, w drodze rozporządzenia, 
szczegółową treść świadectwa pracy, sposób i tryb jego wydawania, prostowania i 
uzupełniania oraz pomocniczy wzór świadectwa pracy, biorąc pod uwagę 
konieczność zapewnienia właściwej realizacji celów, jakim służą informacje 
zawarte w świadectwie pracy.

***
## Art. 971. {#kp-czwarty-art-971}

**§ 1.** W przypadku niewydania przez pracodawcę świadectwa pracy 
pracownikowi przysługuje prawo wystąpienia do sądu pracy z żądaniem 
zobowiązania pracodawcy do wydania świadectwa pracy. 
**§ 2.** Jeżeli pracodawca nie istnieje albo z innych przyczyn wytoczenie 
przeciwko niemu powództwa o zobowiązanie pracodawcy do wydania świadectwa 
pracy jest niemożliwe, pracownikowi przysługuje prawo wystąpienia do sądu pracy 
z żądaniem ustalenia uprawnienia do otrzymania świadectwa pracy. 
**§ 3.** Z żądaniem, o którym mowa w § 1 i 2, można wystąpić w każdym czasie 
przed upływem terminu przedawnienia. 
**§ 4.** Przepisy § 1–3 stosuje się odpowiednio do żądania sprostowania 
świadectwa pracy.

***
## Art. 98. {#kp-czwarty-art-98}

(uchylony)

***
## Art. 99. {#kp-czwarty-art-99}

**§ 1.** Pracownikowi przysługuje roszczenie o naprawienie szkody 
wyrządzonej przez pracodawcę wskutek niewydania w terminie lub wydania 
niewłaściwego świadectwa pracy. 
**§ 2.** Odszkodowanie, o którym mowa w § 1, przysługuje w wysokości 
wynagrodzenia za czas pozostawania bez pracy z tego powodu, nie dłuższy jednak 
niż 6 tygodni. 
**§ 3.** (uchylony) 
**§ 4.** Orzeczenie o odszkodowaniu w związku z wydaniem niewłaściwego 
świadectwa pracy stanowi podstawę do zmiany tego świadectwa. 

 
 
 
s. 75/195 
 
2025-08-06 
## Rozdział II Obowiązki pracownika

***
## Art. 100. {#kp-czwarty-art-100}

**§ 1.** Pracownik jest obowiązany wykonywać pracę sumiennie 
i starannie oraz stosować się do poleceń przełożonych, które dotyczą pracy, jeżeli 
nie są one sprzeczne z przepisami prawa lub umową o pracę. 
**§ 2.** Pracownik jest obowiązany w szczególności: 
- 1) przestrzegać czasu pracy ustalonego w zakładzie pracy; 
- 2) przestrzegać regulaminu pracy i ustalonego w zakładzie pracy porządku; 
- 3) przestrzegać przepisów oraz zasad bezpieczeństwa i higieny pracy, a także 
przepisów przeciwpożarowych; 
- 4) dbać o dobro zakładu pracy, chronić jego mienie oraz zachować w tajemnicy 
informacje, których ujawnienie mogłoby narazić pracodawcę na szkodę; 
- 5) przestrzegać tajemnicy określonej w odrębnych przepisach; 
- 6) przestrzegać w zakładzie pracy zasad współżycia społecznego.

***
## Art. 101. {#kp-czwarty-art-101}

(uchylony) 
## Rozdział II a 
Zakaz konkurencji

***
## Art. 1011. {#kp-czwarty-art-1011}

**§ 1.** W zakresie określonym w odrębnej umowie, pracownik nie 
może prowadzić działalności konkurencyjnej wobec pracodawcy ani też świadczyć 
pracy w ramach stosunku pracy lub na innej podstawie na rzecz podmiotu 
prowadzącego taką działalność (zakaz konkurencji). 
**§ 2.** Pracodawca, który poniósł szkodę wskutek naruszenia przez pracownika 
zakazu konkurencji przewidzianego w umowie, może dochodzić od pracownika 
wyrównania tej szkody na zasadach określonych w przepisach rozdziału I w dziale 
piątym.

***
## Art. 1012. {#kp-czwarty-art-1012}

**§ 1.** Przepis art. 1011 § 1 stosuje się odpowiednio, gdy pracodawca 
i pracownik mający dostęp do szczególnie ważnych informacji, których ujawnienie 
mogłoby narazić pracodawcę na szkodę, zawierają umowę o zakazie konkurencji 
po ustaniu stosunku pracy. W umowie określa się także okres obowiązywania 
zakazu konkurencji oraz wysokość odszkodowania należnego pracownikowi od 
pracodawcy, z zastrzeżeniem przepisów § 2 i 3. 

 
 
 
s. 76/195 
 
2025-08-06 
**§ 2.** Zakaz konkurencji, o którym mowa w § 1, przestaje obowiązywać przed 
upływem terminu, na jaki została zawarta umowa przewidziana w tym przepisie, 
w razie ustania przyczyn uzasadniających taki zakaz lub niewywiązywania się 
pracodawcy z obowiązku wypłaty odszkodowania. 
**§ 3.** Odszkodowanie, o którym mowa w § 1, nie może być niższe od 25 % 
wynagrodzenia otrzymanego przez pracownika przed ustaniem stosunku pracy 
przez okres odpowiadający okresowi obowiązywania zakazu konkurencji; 
odszkodowanie może być wypłacane w miesięcznych ratach. W razie sporu 
o odszkodowaniu orzeka sąd pracy.

***
## Art. 1013. {#kp-czwarty-art-1013}

Umowy, o których mowa w art. 1011 § 1 i w art. 1012 § 1, 
wymagają pod rygorem nieważności formy pisemnej.

***
## Art. 1014. {#kp-czwarty-art-1014}

Przepisy 
rozdziału 
nie 
naruszają 
zakazu 
konkurencji 
przewidzianego w odrębnych przepisach. 
## Rozdział III Kwalifikacje zawodowe pracowników

***
## Art. 102. {#kp-czwarty-art-102}

Kwalifikacje zawodowe pracowników wymagane do wykonywania 
pracy określonego rodzaju lub na określonym stanowisku mogą być ustalane 
w przepisach 
prawa 
pracy 
przewidzianych 
w art. 771–773, 
w zakresie 
nieuregulowanym w przepisach szczególnych.

***
## Art. 103. {#kp-czwarty-art-103}

(utracił moc)5)

***
## Art. 1031. {#kp-czwarty-art-1031}

**§ 1.** Przez podnoszenie kwalifikacji zawodowych rozumie się 
zdobywanie lub uzupełnianie wiedzy i umiejętności przez pracownika, z inicjatywy 
pracodawcy albo za jego zgodą. 
**§ 2.** Pracownikowi podnoszącemu kwalifikacje zawodowe przysługują: 
- 1) urlop szkoleniowy; 
- 2) zwolnienie z całości lub części dnia pracy, na czas niezbędny, by punktualnie 
przybyć na obowiązkowe zajęcia oraz na czas ich trwania. 
**§ 3.** Za czas urlopu szkoleniowego oraz za czas zwolnienia z całości lub części 
dnia pracy pracownik zachowuje prawo do wynagrodzenia. 
- 5) Z dniem 11 kwietnia 2010 r. na podstawie wyroku Trybunału Konstytucyjnego z dnia 31 marca 
2009 r. sygn. akt K 28/08 (Dz. U. poz. 485). 

 
 
 
s. 77/195 
 
2025-08-06

***
## Art. 1032. {#kp-czwarty-art-1032}

**§ 1.** Urlop szkoleniowy, o którym mowa w art. 1031 § 2 pkt 1, 
przysługuje w wymiarze: 
- 1) 6 dni – dla pracownika przystępującego do egzaminów eksternistycznych; 
- 2) 6 dni – dla pracownika przystępującego do egzaminu maturalnego; 
- 3) 6 dni – dla pracownika przystępującego do egzaminu potwierdzającego 
kwalifikacje w zawodzie lub egzaminu zawodowego; 
- 4) 21 dni w ostatnim roku studiów – na przygotowanie pracy dyplomowej oraz 
przygotowanie się i przystąpienie do egzaminu dyplomowego. 
**§ 2.** Urlopu szkoleniowego udziela się w dni, które są dla pracownika dniami 
pracy, zgodnie z obowiązującym go rozkładem czasu pracy.

***
## Art. 1033. {#kp-czwarty-art-1033}

Pracodawca 
może 
przyznać 
pracownikowi 
podnoszącemu 
kwalifikacje zawodowe dodatkowe świadczenia, w szczególności pokryć opłaty za 
kształcenie, przejazd, podręczniki i zakwaterowanie.

***
## Art. 1034. {#kp-czwarty-art-1034}

**§ 1.** Pracodawca 
zawiera 
z pracownikiem 
podnoszącym 
kwalifikacje zawodowe umowę określającą wzajemne prawa i obowiązki stron. 
Umowę zawiera się na piśmie. 
**§ 2.** Umowa, o której mowa w § 1, nie może zawierać postanowień mniej 
korzystnych dla pracownika niż przepisy niniejszego rozdziału. 
**§ 3.** Nie ma obowiązku zawarcia umowy, o której mowa w § 1, jeżeli 
pracodawca nie zamierza zobowiązać pracownika do pozostawania w zatrudnieniu 
po ukończeniu podnoszenia kwalifikacji zawodowych.

***
## Art. 1035. {#kp-czwarty-art-1035}

Pracownik podnoszący kwalifikacje zawodowe: 
- 1) który bez uzasadnionych przyczyn nie podejmie podnoszenia kwalifikacji 
zawodowych albo przerwie podnoszenie tych kwalifikacji, 
- 2) z którym pracodawca rozwiąże stosunek pracy bez wypowiedzenia z jego 
winy, w trakcie podnoszenia kwalifikacji zawodowych lub po jego 
ukończeniu, w terminie określonym w umowie, o której mowa w art. 1034, 
nie dłuższym niż 3 lata, 
- 3) który 
w okresie 
wskazanym 
w pkt 2 rozwiąże 
stosunek 
pracy 
za 
wypowiedzeniem, z wyjątkiem wypowiedzenia umowy o pracę z przyczyn 
określonych w art. 943, 

 
 
 
s. 78/195 
 
2025-08-06 
- 4) który w okresie wskazanym 
w pkt 2 rozwiąże stosunek pracy bez 
wypowiedzenia na podstawie art. 55 lub art. 943, mimo braku przyczyn 
określonych w tych przepisach 
– jest obowiązany do zwrotu kosztów poniesionych przez pracodawcę na ten cel 
z tytułu dodatkowych świadczeń, w wysokości proporcjonalnej do okresu 
zatrudnienia po ukończeniu podnoszenia kwalifikacji zawodowych lub okresu 
zatrudnienia w czasie ich podnoszenia.

***
## Art. 1036. {#kp-czwarty-art-1036}

Pracownikowi zdobywającemu lub uzupełniającemu wiedzę 
i umiejętności na zasadach innych, niż określone w art. 1031–1035, mogą być 
przyznane: 
- 1) zwolnienie z całości lub części dnia pracy bez zachowania prawa do 
wynagrodzenia, 
- 2) urlop bezpłatny 
– w wymiarze ustalonym w porozumieniu zawieranym między pracodawcą 
i pracownikiem. 
## Rozdział IV Regulamin pracy

***
## Art. 104. {#kp-czwarty-art-104}

**§ 1.** Regulamin pracy ustala organizację i porządek w procesie 
pracy oraz związane z tym prawa i obowiązki pracodawcy i pracowników. 
**§ 11.** Pracodawca zatrudniający co najmniej 50 pracowników wprowadza 
regulamin pracy, chyba że w zakresie przewidzianym w § 1 obowiązują 
postanowienia układu zbiorowego pracy. 
**§ 2.** Pracodawca zatrudniający mniej niż 50 pracowników może wprowadzić 
regulamin pracy, chyba że w zakresie przewidzianym w § 1 obowiązują 
postanowienia układu zbiorowego pracy. 
**§ 3.** Pracodawca zatrudniający co najmniej 20 i mniej niż 50 pracowników 
wprowadza regulamin pracy, jeżeli zakładowa organizacja związkowa wystąpi z 
wnioskiem o jego wprowadzenie, chyba że w zakresie przewidzianym w § 1 
obowiązują postanowienia układu zbiorowego pracy.

***
## Art. 1041. {#kp-czwarty-art-1041}

**§ 1.** Regulamin pracy, określając prawa i obowiązki pracodawcy 
i pracowników związane z porządkiem w zakładzie pracy, powinien ustalać 
w szczególności: 

 
 
 
s. 79/195 
 
2025-08-06 
- 1) organizację pracy, warunki przebywania na terenie zakładu pracy w czasie 
pracy i po jej zakończeniu, wyposażenie pracowników w narzędzia 
i materiały, a także w odzież i obuwie robocze oraz w środki ochrony 
indywidualnej i higieny osobistej; 
- 2) systemy i rozkłady czasu pracy oraz przyjęte okresy rozliczeniowe czasu 
pracy; 
- 3) (uchylony) 
- 4) porę nocną; 
- 5) termin, miejsce, czas i częstotliwość wypłaty wynagrodzenia; 
- 6) wykazy prac wzbronionych pracownikom młodocianym oraz kobietom; 
- 7) rodzaje prac i wykaz stanowisk pracy dozwolonych pracownikom 
młodocianym w celu odbywania przygotowania zawodowego; 
7a) wykaz lekkich prac dozwolonych pracownikom młodocianym zatrudnionym 
w innym celu niż przygotowanie zawodowe; 
- 8) obowiązki dotyczące bezpieczeństwa i higieny pracy oraz ochrony 
przeciwpożarowej, w tym także sposób informowania pracowników o ryzyku 
zawodowym, które wiąże się z wykonywaną pracą; 
- 9) przyjęty u danego pracodawcy sposób potwierdzania przez pracowników 
przybycia i obecności w pracy oraz usprawiedliwiania nieobecności w pracy. 
**§ 2.** Regulamin pracy powinien zawierać informacje o karach stosowanych 
zgodnie z art. 108 z tytułu odpowiedzialności porządkowej pracowników.

***
## Art. 1042. {#kp-czwarty-art-1042}

**§ 1.** Regulamin 
pracy 
ustala 
pracodawca 
w uzgodnieniu 
z zakładową organizacją związkową. 
**§ 2.** W razie nieuzgodnienia treści regulaminu pracy z zakładową organizacją 
związkową w ustalonym przez strony terminie, a także w przypadku, gdy u danego 
pracodawcy nie działa zakładowa organizacja związkowa, regulamin pracy ustala 
pracodawca.

***
## Art. 1043. {#kp-czwarty-art-1043}

**§ 1.** Regulamin pracy wchodzi w życie po upływie 2 tygodni od 
dnia podania go do wiadomości pracowników, w sposób przyjęty u danego 
pracodawcy. 
**§ 2.** Pracodawca jest obowiązany zapoznać pracownika z treścią regulaminu 
pracy przed dopuszczeniem go do pracy. 

 
 
 
s. 80/195 
 
2025-08-06

***
## Art. 1044. {#kp-czwarty-art-1044}

(uchylony) 
## Rozdział V Nagrody i wyróżnienia

***
## Art. 105. {#kp-czwarty-art-105}

Pracownikom, którzy przez wzorowe wypełnianie swoich 
obowiązków, przejawianie inicjatywy w pracy i podnoszenie jej wydajności oraz 
jakości przyczyniają się szczególnie do wykonywania zadań zakładu, mogą być 
przyznawane nagrody i wyróżnienia. Odpis zawiadomienia o przyznaniu nagrody 
lub wyróżnienia składa się do akt osobowych pracownika.

***
## Art. 106. {#kp-czwarty-art-106}

(uchylony)

***
## Art. 107. {#kp-czwarty-art-107}

(uchylony) 
## Rozdział VI Odpowiedzialność porządkowa pracowników

***
## Art. 108. {#kp-czwarty-art-108}

**§ 1.** Za nieprzestrzeganie przez pracownika ustalonej organizacji 
i porządku w procesie pracy, przepisów bezpieczeństwa i higieny pracy, przepisów 
przeciwpożarowych, a także przyjętego sposobu potwierdzania przybycia 
i obecności w pracy oraz usprawiedliwiania nieobecności w pracy, pracodawca 
może stosować: 
- 1) karę upomnienia; 
- 2) karę nagany. 
**§ 2.** Za nieprzestrzeganie przez pracownika przepisów bezpieczeństwa 
i higieny pracy lub przepisów przeciwpożarowych, opuszczenie pracy bez 
usprawiedliwienia, stawienie się do pracy w stanie nietrzeźwości albo w stanie po 
użyciu alkoholu lub środka działającego podobnie do alkoholu lub spożywanie 
alkoholu lub zażywanie środka działającego podobnie do alkoholu w czasie pracy 
– pracodawca może również stosować karę pieniężną. 
**§ 3.** Kara pieniężna za jedno przekroczenie, jak i za każdy dzień 
nieusprawiedliwionej nieobecności, nie może być wyższa od jednodniowego 
wynagrodzenia pracownika, a łącznie kary pieniężne nie mogą przewyższać 
dziesiątej części wynagrodzenia przypadającego pracownikowi do wypłaty, po 
dokonaniu potrąceń, o których mowa w art. 87 § 1 pkt 1–3. 

 
 
 
s. 81/195 
 
2025-08-06 
**§ 4.** Wpływy z kar pieniężnych przeznacza się na poprawę warunków 
bezpieczeństwa i higieny pracy.

***
## Art. 109. {#kp-czwarty-art-109}

**§ 1.** Kara nie może być zastosowana po upływie 2 tygodni od 
powzięcia wiadomości o naruszeniu obowiązku pracowniczego i po upływie 
3 miesięcy od dopuszczenia się tego naruszenia. 
**§ 2.** Kara może być zastosowana tylko po uprzednim wysłuchaniu 
pracownika. 
**§ 3.** Jeżeli z powodu nieobecności w zakładzie pracy pracownik nie może być 
wysłuchany, bieg dwutygodniowego terminu przewidzianego w § 1 nie rozpoczyna 
się, a rozpoczęty ulega zawieszeniu do dnia stawienia się pracownika do pracy.

***
## Art. 110. {#kp-czwarty-art-110}

O zastosowanej karze pracodawca zawiadamia pracownika na 
piśmie, wskazując rodzaj naruszenia obowiązków pracowniczych i datę 
dopuszczenia się przez pracownika tego naruszenia oraz informując go o prawie 
zgłoszenia sprzeciwu i terminie jego wniesienia. Odpis zawiadomienia składa się 
do akt osobowych pracownika.

***
## Art. 111. {#kp-czwarty-art-111}

Przy stosowaniu kary bierze się pod uwagę w szczególności rodzaj 
naruszenia obowiązków pracowniczych, stopień winy pracownika i jego 
dotychczasowy stosunek do pracy.

***
## Art. 112. {#kp-czwarty-art-112}

**§ 1.** Jeżeli zastosowanie kary nastąpiło z naruszeniem przepisów 
prawa, pracownik może w ciągu 7 dni od dnia zawiadomienia go o ukaraniu wnieść 
sprzeciw. O uwzględnieniu lub odrzuceniu sprzeciwu decyduje pracodawca po 
rozpatrzeniu stanowiska reprezentującej pracownika zakładowej organizacji 
związkowej. Nieodrzucenie sprzeciwu w ciągu 14 dni od dnia jego wniesienia jest 
równoznaczne z uwzględnieniem sprzeciwu. 
**§ 2.** Pracownik, który wniósł sprzeciw, może w ciągu 14 dni od dnia 
zawiadomienia o odrzuceniu tego sprzeciwu wystąpić do sądu pracy o uchylenie 
zastosowanej wobec niego kary. 
**§ 3.** W razie uwzględnienia sprzeciwu wobec zastosowanej kary pieniężnej 
lub uchylenia tej kary przez sąd pracy, pracodawca jest obowiązany zwrócić 
pracownikowi równowartość kwoty tej kary.

***
## Art. 113. {#kp-czwarty-art-113}

**§ 1.** Karę uważa się za niebyłą, a odpis zawiadomienia o ukaraniu 
usuwa z akt osobowych pracownika po roku nienagannej pracy. Pracodawca może, 

 
 
 
s. 82/195 
 
2025-08-06 
 
z własnej inicjatywy lub na wniosek reprezentującej pracownika zakładowej 
organizacji związkowej, uznać karę za niebyłą przed upływem tego terminu. 
**§ 2.** Przepis § 1 zdanie pierwsze stosuje się odpowiednio w razie 
uwzględnienia sprzeciwu przez pracodawcę albo wydania przez sąd pracy 
orzeczenia o uchyleniu kary.

***
## Art. 1131. {#kp-czwarty-art-1131}

(uchylony) 
DZIAŁ PIĄTY 
Odpowiedzialność materialna pracowników 
## Rozdział I Odpowiedzialność pracownika za szkodę wyrządzoną pracodawcy

***
## Art. 114. {#kp-czwarty-art-114}

Pracownik, który wskutek niewykonania lub nienależytego 
wykonania obowiązków pracowniczych ze swej winy wyrządził pracodawcy 
szkodę, ponosi odpowiedzialność materialną według zasad określonych 
w przepisach niniejszego rozdziału.

***
## Art. 115. {#kp-czwarty-art-115}

Pracownik ponosi odpowiedzialność za szkodę w granicach 
rzeczywistej straty poniesionej przez pracodawcę i tylko za normalne następstwa 
działania lub zaniechania, z którego wynikła szkoda.

***
## Art. 116. {#kp-czwarty-art-116}

Pracodawca jest obowiązany wykazać okoliczności uzasadniające 
odpowiedzialność pracownika oraz wysokość powstałej szkody.

***
## Art. 117. {#kp-czwarty-art-117}

**§ 1.** Pracownik nie ponosi odpowiedzialności za szkodę w takim 
zakresie, w jakim pracodawca lub inna osoba przyczyniły się do jej powstania albo 
zwiększenia. 
**§ 2.** Pracownik nie ponosi ryzyka związanego z działalnością pracodawcy, 
a w szczególności nie odpowiada za szkodę wynikłą w związku z działaniem 
w granicach dopuszczalnego ryzyka. 
**§ 3.** (uchylony)

***
## Art. 118. {#kp-czwarty-art-118}

W razie wyrządzenia szkody przez kilku pracowników każdy z nich 
ponosi odpowiedzialność za część szkody stosownie do przyczynienia się do niej 
i stopnia winy. Jeżeli nie jest możliwe ustalenie stopnia winy i przyczynienia się 

 
 
 
s. 83/195 
 
2025-08-06 
 
poszczególnych pracowników do powstania szkody, odpowiadają oni w częściach 
równych.

***
## Art. 119. {#kp-czwarty-art-119}

Odszkodowanie ustala się w wysokości wyrządzonej szkody, 
jednak nie może ono przewyższać kwoty trzymiesięcznego wynagrodzenia 
przysługującego pracownikowi w dniu wyrządzenia szkody.

***
## Art. 120. {#kp-czwarty-art-120}

**§ 1.** W razie wyrządzenia przez pracownika przy wykonywaniu 
przez niego obowiązków pracowniczych szkody osobie trzeciej, zobowiązany do 
naprawienia szkody jest wyłącznie pracodawca. 
**§ 2.** Wobec pracodawcy, który naprawił szkodę wyrządzoną osobie trzeciej, 
pracownik ponosi odpowiedzialność przewidzianą w przepisach niniejszego 
rozdziału.

***
## Art. 121. {#kp-czwarty-art-121}

**§ 1.** Jeżeli naprawienie szkody następuje na podstawie ugody 
pomiędzy pracodawcą i pracownikiem, wysokość odszkodowania może być 
obniżona, przy uwzględnieniu wszystkich okoliczności sprawy, a w szczególności 
stopnia winy pracownika i jego stosunku do obowiązków pracowniczych. 
**§ 2.** Przy uwzględnieniu okoliczności wymienionych w § 1 wysokość 
odszkodowania może być także obniżona przez sąd pracy; dotyczy to również 
przypadku, gdy naprawienie szkody następuje na podstawie ugody sądowej.

***
## Art. 1211. {#kp-czwarty-art-1211}

**§ 1.** W razie niewykonania ugody przez pracownika, podlega ona 
wykonaniu w trybie przepisów Kodeksu postępowania cywilnego, po nadaniu jej 
klauzuli wykonalności przez sąd pracy. 
**§ 2.** Sąd pracy odmówi nadania klauzuli wykonalności ugodzie, jeżeli ustali, 
że jest ona sprzeczna z prawem lub zasadami współżycia społecznego.

***
## Art. 122. {#kp-czwarty-art-122}

Jeżeli pracownik umyślnie wyrządził szkodę, jest obowiązany do jej 
naprawienia w pełnej wysokości.

***
## Art. 123. {#kp-czwarty-art-123}

(uchylony) 
## Rozdział II Odpowiedzialność za mienie powierzone pracownikowi

***
## Art. 124. {#kp-czwarty-art-124}

**§ 1.** Pracownik, któremu powierzono z obowiązkiem zwrotu albo 
do wyliczenia się: 

 
 
 
s. 84/195 
 
2025-08-06 
- 1) pieniądze, papiery wartościowe lub kosztowności, 
- 2) narzędzia i instrumenty lub podobne przedmioty, a także środki ochrony 
indywidualnej oraz odzież i obuwie robocze, 
odpowiada w pełnej wysokości za szkodę powstałą w tym mieniu. 
**§ 2.** Pracownik odpowiada w pełnej wysokości również za szkodę w mieniu 
innym niż wymienione w § 1, powierzonym mu z obowiązkiem zwrotu albo do 
wyliczenia się. 
**§ 3.** Od odpowiedzialności określonej w § 1 i 2 pracownik może się uwolnić, 
jeżeli wykaże, że szkoda powstała z przyczyn od niego niezależnych, 
a w szczególności wskutek niezapewnienia przez pracodawcę warunków 
umożliwiających zabezpieczenie powierzonego mienia.

***
## Art. 125. {#kp-czwarty-art-125}

**§ 1.** Na zasadach określonych w art. 124 pracownicy mogą przyjąć 
wspólną odpowiedzialność materialną za mienie powierzone im łącznie 
z obowiązkiem wyliczenia się. Podstawą łącznego powierzenia mienia jest umowa 
o współodpowiedzialności materialnej, zawarta przez pracowników z pracodawcą 
na piśmie pod rygorem nieważności. 
**§ 2.** Pracownicy 
ponoszący 
wspólną 
odpowiedzialność 
materialną 
odpowiadają w częściach określonych w umowie. Jednakże w razie ustalenia, że 
szkoda w całości lub w części została spowodowana przez niektórych 
pracowników, za całość szkody lub za stosowną jej część odpowiadają tylko 
sprawcy szkody.

***
## Art. 126. {#kp-czwarty-art-126}

**§ 1.** Rada Ministrów określi w drodze rozporządzenia zakres 
i szczegółowe zasady stosowania przepisów art. 125 oraz tryb łącznego 
powierzania mienia. 
**§ 2.** Rada Ministrów, w drodze rozporządzenia, może określić warunki 
odpowiedzialności za szkodę w mieniu, o którym mowa w art. 124 § 2 i w art. 125: 
- 1) w ograniczonej wysokości, ustalonej tym rozporządzeniem; 
- 2) na zasadach przewidzianych w art. 114–116 i 118.

***
## Art. 127. {#kp-czwarty-art-127}

Do odpowiedzialności określonej w art. 124–126 stosuje się 
odpowiednio przepisy art. 117, 121, 1211 i 122. 

 
 
 
s. 85/195 
 
2025-08-06 
 
DZIAŁ SZÓSTY 
Czas pracy 
## Rozdział I Przepisy ogólne

***
## Art. 128. {#kp-czwarty-art-128}

**§ 1.** Czasem pracy jest czas, w którym pracownik pozostaje 
w dyspozycji pracodawcy w zakładzie pracy lub w innym miejscu wyznaczonym 
do wykonywania pracy. 
**§ 2.** Ilekroć w przepisach działu jest mowa o: 
- 1) pracy zmianowej – należy przez to rozumieć wykonywanie pracy według 
ustalonego rozkładu czasu pracy przewidującego zmianę pory wykonywania 
pracy przez poszczególnych pracowników po upływie określonej liczby 
godzin, dni lub tygodni; 
- 2) pracownikach zarządzających w imieniu pracodawcy zakładem pracy – 
należy przez to rozumieć pracowników kierujących jednoosobowo zakładem 
pracy i ich zastępców lub pracowników wchodzących w skład kolegialnego 
organu zarządzającego zakładem pracy oraz głównych księgowych. 
**§ 3.** Do celów rozliczania czasu pracy pracownika: 
- 1) przez dobę – należy rozumieć 24 kolejne godziny, poczynając od godziny, 
w której pracownik rozpoczyna pracę zgodnie z obowiązującym go 
rozkładem czasu pracy; 
- 2) przez tydzień – należy rozumieć 7 kolejnych dni kalendarzowych, poczynając 
od pierwszego dnia okresu rozliczeniowego. 
## Rozdział II Normy i ogólny wymiar czasu pracy

***
## Art. 129. {#kp-czwarty-art-129}

**§ 1.** Czas pracy nie może przekraczać 8 godzin na dobę i przeciętnie 
40 godzin w przeciętnie pięciodniowym tygodniu pracy w przyjętym okresie 
rozliczeniowym nieprzekraczającym 4 miesięcy, z zastrzeżeniem art. 135–138, 
143 i 144. 
**§ 2.** W każdym systemie czasu pracy, jeżeli jest to uzasadnione przyczynami 
obiektywnymi lub technicznymi lub dotyczącymi organizacji pracy, okres 
rozliczeniowy może być przedłużony, nie więcej jednak niż do 12 miesięcy, przy 

 
 
 
s. 86/195 
 
2025-08-06 
 
zachowaniu ogólnych zasad dotyczących ochrony bezpieczeństwa i zdrowia 
pracowników. 
**§ 3.** Rozkład czasu pracy danego pracownika może być sporządzony – 
w formie pisemnej lub elektronicznej – na okres krótszy niż okres rozliczeniowy, 
obejmujący jednak co najmniej 1 miesiąc. Pracodawca przekazuje pracownikowi 
rozkład czasu pracy co najmniej na 1 tydzień przed rozpoczęciem pracy w okresie, 
na który został sporządzony ten rozkład. 
**§ 4.** Pracodawca nie ma obowiązku sporządzania rozkładu czasu pracy, jeżeli: 
- 1) rozkład czasu pracy pracownika wynika z prawa pracy, obwieszczenia, 
o którym mowa w art. 150 § 1, albo z umowy o pracę; 
- 2) w porozumieniu z pracownikiem ustali czas niezbędny do wykonania 
powierzonych zadań, uwzględniając wymiar czasu pracy wynikający z norm 
określonych w § 1; w takim przypadku rozkład czasu pracy ustala pracownik; 
- 3) na pisemny wniosek pracownika stosuje do niego rozkłady czasu pracy, 
o których mowa w art. 1401; 
- 4) na pisemny wniosek pracownika ustali mu indywidualny rozkład czasu pracy. 
**§ 5.** Jeżeli w danym miesiącu, ze względu na rozkład czasu pracy w przyjętym 
okresie rozliczeniowym, pracownik nie ma obowiązku wykonywania pracy, 
przysługuje mu wynagrodzenie w wysokości nie niższej niż minimalne 
wynagrodzenie za pracę ustalane na podstawie odrębnych przepisów; w przypadku 
pracownika zatrudnionego w niepełnym wymiarze czasu pracy wysokość tego 
wynagrodzenia ustala się proporcjonalnie do tego wymiaru czasu pracy.

***
## Art. 130. {#kp-czwarty-art-130}

**§ 1.** Obowiązujący pracownika wymiar czasu pracy w przyjętym 
okresie rozliczeniowym, ustalany zgodnie z art. 129 § 1, oblicza się: 
- 1) mnożąc 40 godzin przez liczbę tygodni przypadających w okresie 
rozliczeniowym, a następnie 
- 2) dodając do otrzymanej liczby godzin iloczyn 8 godzin i liczby dni pozostałych 
do końca okresu rozliczeniowego, przypadających od poniedziałku do piątku. 
**§ 2.** Każde święto występujące w okresie rozliczeniowym i przypadające 
w innym dniu niż niedziela obniża wymiar czasu pracy o 8 godzin. 

 
 
 
s. 87/195 
 
2025-08-06 
**§ 21.** (utracił moc)6) 
**§ 3.** Wymiar czasu pracy pracownika w okresie rozliczeniowym, ustalony 
zgodnie z art. 129 § 1, ulega w tym okresie obniżeniu o liczbę godzin 
usprawiedliwionej nieobecności w pracy, przypadających do przepracowania 
w czasie tej nieobecności, zgodnie z przyjętym rozkładem czasu pracy.

***
## Art. 131. {#kp-czwarty-art-131}

**§ 1.** Tygodniowy czas pracy łącznie z godzinami nadliczbowymi 
nie może przekraczać przeciętnie 48 godzin w przyjętym okresie rozliczeniowym. 
**§ 2.** Ograniczenie 
przewidziane 
w § 1 nie 
dotyczy 
pracowników 
zarządzających w imieniu pracodawcy zakładem pracy. 
## Rozdział III Okresy odpoczynku

***
## Art. 132. {#kp-czwarty-art-132}

**§ 1.** Pracownikowi przysługuje w każdej dobie prawo do co 
najmniej 11 godzin nieprzerwanego odpoczynku, z zastrzeżeniem § 3 oraz art. 136 
§ 2 i art. 137. 
**§ 2.** Przepis § 1 nie dotyczy: 
- 1) pracowników zarządzających w imieniu pracodawcy zakładem pracy; 
- 2) przypadków konieczności prowadzenia akcji ratowniczej w celu ochrony 
życia lub zdrowia ludzkiego, ochrony mienia lub środowiska albo usunięcia 
awarii. 
**§ 3.** W przypadkach określonych w § 2 pracownikowi przysługuje, w okresie 
rozliczeniowym, równoważny okres odpoczynku.

***
## Art. 133. {#kp-czwarty-art-133}

**§ 1.** Pracownikowi przysługuje w każdym tygodniu prawo do co 
najmniej 35 godzin nieprzerwanego odpoczynku, obejmującego co najmniej 
11 godzin nieprzerwanego odpoczynku dobowego. 
**§ 2.** W przypadkach określonych w art. 132 § 2 oraz w przypadku zmiany 
pory wykonywania pracy przez pracownika w związku z jego przejściem na inną 
zmianę, zgodnie z ustalonym rozkładem czasu pracy, tygodniowy nieprzerwany 
odpoczynek może obejmować mniejszą liczbę godzin, nie może być jednak krótszy 
niż 24 godziny. 
- 6) Z dniem 8 października 2012 r. na podstawie wyroku Trybunału Konstytucyjnego z dnia 
2 października 2012 r. sygn. akt K 27/11 (Dz. U. poz. 1110). 

 
 
 
s. 88/195 
 
2025-08-06 
**§ 3.** Odpoczynek, o którym mowa w § 1 i 2, powinien przypadać w niedzielę. 
Niedziela obejmuje 24 kolejne godziny, poczynając od godziny 600 w tym dniu, 
chyba że u danego pracodawcy została ustalona inna godzina. 
**§ 4.** W przypadkach dozwolonej pracy w niedzielę odpoczynek, o którym 
mowa w § 1 i 2, może przypadać w innym dniu niż niedziela.

***
## Art. 134. {#kp-czwarty-art-134}

**§ 1.** Jeżeli dobowy wymiar czasu pracy pracownika: 
- 1) wynosi co najmniej 6 godzin – pracownik ma prawo do przerwy w pracy 
trwającej co najmniej 15 minut; 
- 2) jest dłuższy niż 9 godzin – pracownik ma prawo do dodatkowej przerwy 
w pracy trwającej co najmniej 15 minut; 
- 3) jest dłuższy niż 16 godzin – pracownik ma prawo do kolejnej przerwy w pracy 
trwającej co najmniej 15 minut. 
**§ 2.** Przerwy, o których mowa w § 1, wlicza się do czasu pracy. 
## Rozdział IV Systemy i rozkłady czasu pracy

***
## Art. 135. {#kp-czwarty-art-135}

**§ 1.** Jeżeli jest to uzasadnione rodzajem pracy lub jej organizacją, 
może być stosowany system równoważnego czasu pracy, w którym jest 
dopuszczalne przedłużenie dobowego wymiaru czasu pracy, nie więcej jednak niż 
do 12 godzin, w okresie rozliczeniowym nieprzekraczającym 1 miesiąca. 
Przedłużony dobowy wymiar czasu pracy jest równoważony krótszym dobowym 
wymiarem czasu pracy w niektórych dniach lub dniami wolnymi od pracy. 
**§ 2.** W szczególnie uzasadnionych przypadkach okres 
rozliczeniowy, 
o którym mowa w § 1, może być przedłużony, nie więcej jednak niż do 3 miesięcy. 
**§ 3.** Przy 
pracach 
uzależnionych 
od 
pory 
roku 
lub 
warunków 
atmosferycznych okres rozliczeniowy, o którym mowa w § 1, może być 
przedłużony, nie więcej jednak niż do 4 miesięcy.

***
## Art. 136. {#kp-czwarty-art-136}

**§ 1.** Przy pracach polegających na dozorze urządzeń lub związanych 
z częściowym pozostawaniem w pogotowiu do pracy może być stosowany system 
równoważnego czasu pracy, w którym jest dopuszczalne przedłużenie dobowego 
wymiaru czasu pracy, nie więcej jednak niż do 16 godzin, w okresie 
rozliczeniowym nieprzekraczającym 1 miesiąca. 

 
 
 
s. 89/195 
 
2025-08-06 
**§ 2.** W systemie czasu pracy, o którym mowa w § 1, pracownikowi 
przysługuje, 
bezpośrednio 
po 
każdym 
okresie 
wykonywania 
pracy 
w przedłużonym dobowym wymiarze czasu pracy, odpoczynek przez czas 
odpowiadający co najmniej liczbie przepracowanych godzin, niezależnie od 
odpoczynku przewidzianego w art. 133.

***
## Art. 137. {#kp-czwarty-art-137}

Do pracowników zatrudnionych przy pilnowaniu mienia lub 
ochronie osób, a także pracowników zakładowych straży pożarnych i zakładowych 
służb ratowniczych może być stosowany system równoważnego czasu pracy, 
w którym jest dopuszczalne przedłużenie dobowego wymiaru czasu pracy do 
24 godzin, w okresie rozliczeniowym nieprzekraczającym 1 miesiąca. Przepisy 
art. 135 § 2 i 3 oraz art. 136 § 2 stosuje się odpowiednio.

***
## Art. 138. {#kp-czwarty-art-138}

**§ 1.** Przy pracach, które ze względu na technologię produkcji nie 
mogą być wstrzymane (praca w ruchu ciągłym), może być stosowany system czasu 
pracy, w którym jest dopuszczalne przedłużenie czasu pracy do 43 godzin 
przeciętnie na tydzień w okresie rozliczeniowym nieprzekraczającym 4 tygodni, 
a jednego dnia w niektórych tygodniach w tym okresie dobowy wymiar czasu 
pracy może być przedłużony do 12 godzin. Za każdą godzinę pracy powyżej 
8 godzin na dobę w dniu wykonywania pracy w przedłużonym wymiarze czasu 
pracy pracownikowi przysługuje dodatek do wynagrodzenia, o którym mowa 
w art. 1511 § 1 pkt 1. 
**§ 2.** Przepis § 1 stosuje się także w przypadku, gdy praca nie może być 
wstrzymana ze względu na konieczność ciągłego zaspokajania potrzeb ludności. 
**§ 3.** W przypadkach określonych w § 1 i 2 obowiązujący pracownika wymiar 
czasu pracy w przyjętym okresie rozliczeniowym oblicza się: 
- 1) mnożąc 8 godzin przez liczbę dni kalendarzowych przypadających w okresie 
rozliczeniowym, z wyłączeniem niedziel, świąt oraz dni wolnych od pracy 
wynikających z rozkładu czasu pracy w przeciętnie pięciodniowym tygodniu 
pracy, a następnie 
- 2) dodając do otrzymanej liczby liczbę godzin odpowiadającą przedłużonemu 
u danego pracodawcy tygodniowemu wymiarowi czasu pracy. 

 
 
 
s. 90/195 
 
2025-08-06 
**§ 4.** Liczba godzin odpowiadająca przedłużonemu u danego pracodawcy 
tygodniowemu wymiarowi czasu pracy nie może przekraczać 4 godzin na każdy 
tydzień okresu rozliczeniowego, w którym następuje przedłużenie czasu pracy. 
**§ 5.** Przepisy art. 130 § 2 zdanie drugie i § 3 stosuje się odpowiednio.

***
## Art. 139. {#kp-czwarty-art-139}

**§ 1.** Jeżeli jest to uzasadnione rodzajem pracy lub jej organizacją, 
może być stosowany system przerywanego czasu pracy według z góry ustalonego 
rozkładu przewidującego nie więcej niż jedną przerwę w pracy w ciągu doby, 
trwającą nie dłużej niż 5 godzin. Przerwy nie wlicza się do czasu pracy, jednakże 
za czas tej przerwy pracownikowi przysługuje prawo do wynagrodzenia 
w wysokości połowy wynagrodzenia należnego za czas przestoju. 
**§ 2.** Systemu przerywanego czasu pracy nie stosuje się do pracownika 
objętego systemem czasu pracy, o którym mowa w art. 135–138, 143 i 144. 
**§ 3.** System przerywanego czasu pracy wprowadza się w układzie zbiorowym 
pracy lub w porozumieniu z zakładową organizacją związkową, a jeżeli u danego 
pracodawcy nie działa zakładowa organizacja związkowa – w porozumieniu 
z przedstawicielami pracowników wyłonionymi w trybie przyjętym u tego 
pracodawcy, z zastrzeżeniem § 4. 
**§ 4.** U pracodawcy będącego osobą fizyczną, prowadzącego działalność 
w zakresie rolnictwa i hodowli, u którego nie działa zakładowa organizacja 
związkowa, system przerywanego czasu pracy może być stosowany na podstawie 
umowy o pracę. Pracownikowi przysługuje wynagrodzenie za czas przerwy, 
o której mowa w § 1, jeżeli wynika to z umowy o pracę. 
**§ 5.** Jeżeli nie jest możliwe uzgodnienie treści porozumienia, o którym mowa 
w § 3, ze wszystkimi zakładowymi organizacjami związkowymi, pracodawca 
uzgadnia treść porozumienia z organizacjami związkowymi reprezentatywnymi 
w rozumieniu art. 253 ust. 1 lub 2 ustawy o związkach zawodowych, z których 
każda zrzesza co najmniej 5 % pracowników zatrudnionych u pracodawcy.

***
## Art. 140. {#kp-czwarty-art-140}

W przypadkach uzasadnionych rodzajem pracy lub jej organizacją 
albo miejscem wykonywania pracy może być stosowany system zadaniowego 
czasu pracy. Pracodawca, po porozumieniu z pracownikiem, ustala czas niezbędny 
do wykonania powierzonych zadań, uwzględniając wymiar czasu pracy 
wynikający z norm określonych w art. 129. 

 
 
 
s. 91/195 
 
2025-08-06

***
## Art. 1401. {#kp-czwarty-art-1401}

**§ 1.** Rozkład czasu pracy może przewidywać różne godziny 
rozpoczynania pracy w dniach, które zgodnie z tym rozkładem są dla pracowników 
dniami pracy. 
**§ 2.** Rozkład czasu pracy może przewidywać przedział czasu, w którym 
pracownik decyduje o godzinie rozpoczęcia pracy w dniu, który zgodnie z tym 
rozkładem jest dla pracownika dniem pracy. 
**§ 3.** Wykonywanie pracy zgodnie z rozkładami czasu pracy, o których mowa 
w § 1 i 2, nie może naruszać prawa pracownika do odpoczynku, o którym mowa 
w art. 132 i 133. 
**§ 4.** W rozkładach czasu pracy, o których mowa w § 1 i 2, ponowne 
wykonywanie pracy w tej samej dobie nie stanowi pracy w godzinach 
nadliczbowych.

***
## Art. 141. {#kp-czwarty-art-141}

**§ 1.** Pracodawca może wprowadzić jedną przerwę w pracy 
niewliczaną do czasu pracy, w wymiarze nieprzekraczającym 60 minut, 
przeznaczoną na spożycie posiłku lub załatwienie spraw osobistych. 
**§ 2.** Przerwę w pracy, o której mowa w § 1, wprowadza się w układzie 
zbiorowym pracy lub regulaminie pracy albo w umowie o pracę, jeżeli pracodawca 
nie jest objęty układem zbiorowym pracy lub nie jest obowiązany do ustalenia 
regulaminu pracy.

***
## Art. 142. {#kp-czwarty-art-142}

Na pisemny wniosek pracownika pracodawca może ustalić 
indywidualny rozkład jego czasu pracy w ramach systemu czasu pracy, którym 
pracownik jest objęty.

***
## Art. 1421. {#kp-czwarty-art-1421}

**§ 1.** Pracodawca jest obowiązany uwzględnić wniosek: 
- 1) pracownika – małżonka albo pracownika – rodzica dziecka w fazie 
prenatalnej, w przypadku ciąży powikłanej, 
- 2) pracownika – rodzica dziecka posiadającego zaświadczenie, o którym mowa 
w art. 4 ust. 3 ustawy z dnia 4 listopada 2016 r. o wsparciu kobiet w ciąży i 
rodzin „Za życiem” (Dz. U. z 2024 r. poz. 1829), 
- 3) pracownika – rodzica:  
  - a) dziecka legitymującego się orzeczeniem o niepełnosprawności albo 
orzeczeniem 
o 
umiarkowanym 
lub 
znacznym 
stopniu 

 
 
 
s. 92/195 
 
2025-08-06 
 
niepełnosprawności określonym w przepisach o rehabilitacji zawodowej 
i społecznej oraz zatrudnianiu osób niepełnosprawnych oraz 
  - b) dziecka posiadającego odpowiednio opinię o potrzebie wczesnego 
wspomagania rozwoju dziecka, orzeczenie o potrzebie kształcenia 
specjalnego 
lub 
orzeczenie 
o 
potrzebie 
zajęć 
rewalidacyjno-
wychowawczych, o których mowa w przepisach ustawy z dnia 14 
grudnia 2016 r. – Prawo oświatowe (Dz. U. z 2024 r. poz. 737, 854, 1562, 
1635 i 1933) 
– o wykonywanie pracy w systemie czasu pracy, o którym mowa w art. 139, lub 
rozkładzie czasu pracy, o którym mowa w art. 1401 albo w art. 142, złożony w 
postaci papierowej lub elektronicznej. 
**§ 2.** Pracodawca może odmówić uwzględnienia wniosku, o którym mowa w 
§ 1, jeżeli jego uwzględnienie nie jest możliwe ze względu na organizację pracy lub 
rodzaj pracy wykonywanej przez pracownika. O przyczynie odmowy 
uwzględnienia wniosku pracodawca informuje pracownika w postaci papierowej 
lub elektronicznej. 
**§ 3.** Przepisy § 1 i 2 stosuje się do pracowników, o których mowa w § 1 pkt 2 
i 3, również po ukończeniu przez dziecko 18 roku życia.

***
## Art. 143. {#kp-czwarty-art-143}

Na pisemny wniosek pracownika może być do niego stosowany 
system skróconego tygodnia pracy. W tym systemie jest dopuszczalne 
wykonywanie pracy przez pracownika przez mniej niż 5 dni w ciągu tygodnia, przy 
równoczesnym przedłużeniu dobowego wymiaru czasu pracy, nie więcej niż do 
12 godzin, w okresie rozliczeniowym nieprzekraczającym 1 miesiąca.

***
## Art. 144. {#kp-czwarty-art-144}

Na pisemny wniosek pracownika może być do niego stosowany 
system czasu pracy, w którym praca jest świadczona wyłącznie w piątki, soboty, 
niedziele i święta. W tym systemie jest dopuszczalne przedłużenie dobowego 
wymiaru czasu pracy, nie więcej jednak niż do 12 godzin, w okresie 
rozliczeniowym nieprzekraczającym 1 miesiąca.

***
## Art. 145. {#kp-czwarty-art-145}

**§ 1.** Skrócenie czasu pracy poniżej norm określonych w art. 129 
§ 1 dla pracowników zatrudnionych w warunkach szczególnie uciążliwych lub 
szczególnie szkodliwych dla zdrowia może polegać na ustanowieniu przerw 
w pracy wliczanych do czasu pracy albo na obniżeniu tych norm, a w przypadku 

 
 
 
s. 93/195 
 
2025-08-06 
 
pracy monotonnej lub pracy w ustalonym z góry tempie polega na wprowadzeniu 
przerw w pracy wliczanych do czasu pracy. 
**§ 2.** Wykaz prac, o których mowa w § 1, ustala pracodawca po konsultacji 
z pracownikami lub ich przedstawicielami w trybie i na zasadach określonych 
w art. 23711a i art. 23713a oraz po zasięgnięciu opinii lekarza sprawującego 
profilaktyczną opiekę zdrowotną nad pracownikami.

***
## Art. 146. {#kp-czwarty-art-146}

Praca zmianowa jest dopuszczalna bez względu na stosowany 
system czasu pracy.

***
## Art. 147. {#kp-czwarty-art-147}

W każdym systemie czasu pracy, jeżeli przewiduje on rozkład czasu 
pracy obejmujący pracę w niedziele i święta, pracownikom zapewnia się łączną 
liczbę dni wolnych od pracy w przyjętym okresie rozliczeniowym odpowiadającą 
co najmniej liczbie niedziel, świąt oraz dni wolnych od pracy w przeciętnie 
pięciodniowym tygodniu pracy przypadających w tym okresie.

***
## Art. 148. {#kp-czwarty-art-148}

W systemach i rozkładach czasu pracy, o których mowa w art. 135–
138, 143 i 144, czas pracy: 
- 1) pracowników zatrudnionych na stanowiskach pracy, na których występują 
przekroczenia najwyższych dopuszczalnych stężeń lub natężeń czynników 
szkodliwych dla zdrowia, 
- 2) pracownic w ciąży, 
- 3) pracowników opiekujących się dzieckiem do ukończenia przez nie 4 roku 
życia, bez ich zgody 
– nie może przekraczać 8 godzin. Pracownik zachowuje prawo do wynagrodzenia 
za czas nieprzepracowany w związku ze zmniejszeniem z tego powodu wymiaru 
jego czasu pracy.

***
## Art. 1481. {#kp-czwarty-art-1481}

**§ 1.** Pracownikowi przysługuje w ciągu roku kalendarzowego 
zwolnienie od pracy, w wymiarze 2 dni albo 16 godzin, z powodu działania siły 
wyższej w pilnych sprawach rodzinnych spowodowanych chorobą lub wypadkiem, 
jeżeli jest niezbędna natychmiastowa obecność pracownika. W okresie tego 
zwolnienia od pracy pracownik zachowuje prawo do wynagrodzenia w wysokości 
połowy wynagrodzenia. 

 
 
 
s. 94/195 
 
2025-08-06 
**§ 2.** O sposobie wykorzystania w danym roku kalendarzowym zwolnienia od 
pracy, o którym mowa w § 1, decyduje pracownik w pierwszym wniosku 
o udzielenie takiego zwolnienia złożonym w danym roku kalendarzowym. 
**§ 3.** Pracodawca jest obowiązany udzielić zwolnienia od pracy, o którym 
mowa w § 1, na wniosek zgłoszony przez pracownika najpóźniej w dniu 
korzystania z tego zwolnienia. 
**§ 4.** Zwolnienie od pracy, o którym mowa w § 1, udzielane w wymiarze 
godzinowym, dla pracownika zatrudnionego w niepełnym wymiarze czasu pracy 
ustala się proporcjonalnie do wymiaru czasu pracy tego pracownika. Niepełną 
godzinę zwolnienia od pracy zaokrągla się w górę do pełnej godziny. 
**§ 5.** Przepis § 1 w zakresie zwolnienia od pracy udzielanego w wymiarze 
godzinowym stosuje się odpowiednio do pracownika, dla którego dobowa norma 
czasu pracy, wynikająca z odrębnych przepisów, jest niższa niż 8 godzin. 
**§ 6.** Do pracownika, o którym mowa w § 1, stosuje się odpowiednio art. 1864.

***
## Art. 149. {#kp-czwarty-art-149}

**§ 1.** Pracodawca prowadzi ewidencję czasu pracy pracownika do 
celów prawidłowego ustalenia jego wynagrodzenia i innych świadczeń związanych 
z pracą. Pracodawca udostępnia tę ewidencję pracownikowi, na jego żądanie. 
**§ 2.** W stosunku do pracowników objętych systemem zadaniowego czasu 
pracy, pracowników zarządzających w imieniu pracodawcy zakładem pracy oraz 
pracowników otrzymujących ryczałt za godziny nadliczbowe lub za pracę w porze 
nocnej nie ewidencjonuje się godzin pracy.

***
## Art. 150. {#kp-czwarty-art-150}

**§ 1.** Systemy i rozkłady czasu pracy oraz przyjęte okresy 
rozliczeniowe czasu pracy ustala się w układzie zbiorowym pracy lub 
w regulaminie pracy albo w obwieszczeniu, jeżeli pracodawca nie jest objęty 
układem zbiorowym pracy lub nie jest obowiązany do ustalenia regulaminu pracy, 
z zastrzeżeniem § 2–5 oraz art. 139 § 3 i 4. 
**§ 2.** Pracodawca, u którego nie działa zakładowa organizacja związkowa, 
a także pracodawca, u którego zakładowa organizacja związkowa nie wyraża zgody 
na ustalenie lub zmianę systemów i rozkładów czasu pracy oraz okresów roz-
liczeniowych czasu pracy, może stosować okres rozliczeniowy czasu pracy, 
o którym mowa w art. 135 § 2 i 3 – po uprzednim zawiadomieniu właściwego 
okręgowego inspektora pracy. 

 
 
 
s. 95/195 
 
2025-08-06 
**§ 3.** Przedłużenie okresu rozliczeniowego czasu pracy zgodnie z art. 129 § 2 
oraz rozkłady czasu pracy, o których mowa w art. 1401, ustala się: 
- 1) w układzie zbiorowym pracy lub w porozumieniu z zakładowymi 
organizacjami związkowymi; jeżeli nie jest możliwe uzgodnienie treści 
porozumienia ze wszystkimi zakładowymi organizacjami związkowymi, 
pracodawca uzgadnia treść porozumienia z organizacjami związkowymi 
reprezentatywnymi w rozumieniu art. 253 ust. 1 lub 2 ustawy o związkach 
zawodowych, z których każda zrzesza co najmniej 5 % pracowników 
zatrudnionych u pracodawcy, albo 
- 2) w 
porozumieniu 
zawieranym 
z przedstawicielami 
pracowników, 
wyłonionymi w trybie przyjętym u danego pracodawcy – jeżeli u pracodawcy 
nie działają zakładowe organizacje związkowe. 
**§ 4.** Pracodawca przekazuje kopię porozumienia w sprawie przedłużenia 
okresu rozliczeniowego czasu pracy, o którym mowa w § 3, właściwemu 
okręgowemu inspektorowi pracy w terminie 5 dni roboczych od dnia zawarcia 
porozumienia. 
**§ 5.** Rozkłady czasu pracy, o których mowa w art. 1401, mogą być także 
stosowane na pisemny wniosek pracownika, niezależnie od ustalenia takich 
rozkładów czasu pracy w trybie określonym w § 3. 
**§ 6.** Zastosowanie do pracownika systemów czasu pracy, o których mowa 
w art. 143 i 144, następuje na podstawie umowy o pracę. 
**§ 7.** Do obwieszczenia, o którym mowa w § 1, stosuje się odpowiednio 
art. 1043. 
## Rozdział V Praca w godzinach nadliczbowych

***
## Art. 151. {#kp-czwarty-art-151}

**§ 1.** Praca wykonywana ponad obowiązujące pracownika normy 
czasu pracy, a także praca wykonywana ponad przedłużony dobowy wymiar czasu 
pracy, wynikający z obowiązującego pracownika systemu i rozkładu czasu pracy, 
stanowi pracę w godzinach nadliczbowych. Praca w godzinach nadliczbowych jest 
dopuszczalna w razie: 
- 1) konieczności prowadzenia akcji ratowniczej w celu ochrony życia lub 
zdrowia ludzkiego, ochrony mienia lub środowiska albo usunięcia awarii; 

 
 
 
s. 96/195 
 
2025-08-06 
- 2) szczególnych potrzeb pracodawcy. 
**§ 2.** Przepisu § 1 pkt 2 nie stosuje się do pracowników zatrudnionych na 
stanowiskach 
pracy, 
na 
których 
występują 
przekroczenia 
najwyższych 
dopuszczalnych stężeń lub natężeń czynników szkodliwych dla zdrowia. 
**§ 21.** Nie stanowi pracy w godzinach nadliczbowych czas odpracowania 
zwolnienia od pracy, udzielonego pracownikowi, na jego pisemny wniosek, w celu 
załatwienia spraw osobistych. Odpracowanie zwolnienia od pracy nie może 
naruszać prawa pracownika do odpoczynku, o którym mowa w art. 132 i 133. 
**§ 3.** Liczba 
godzin 
nadliczbowych 
przepracowanych 
w związku 
z okolicznościami 
określonymi 
w § 1 
pkt 2 nie 
może 
przekroczyć 
dla 
poszczególnego pracownika 150 godzin w roku kalendarzowym. 
**§ 4.** W układzie zbiorowym pracy lub w regulaminie pracy albo w umowie 
o pracę, jeżeli pracodawca nie jest objęty układem zbiorowym pracy lub nie jest 
obowiązany do ustalenia regulaminu pracy, jest dopuszczalne ustalenie innej liczby 
godzin nadliczbowych w roku kalendarzowym niż określona w § 3. 
**§ 5.** Strony ustalają w umowie o pracę dopuszczalną liczbę godzin pracy 
ponad określony w umowie wymiar czasu pracy pracownika zatrudnionego 
w niepełnym wymiarze czasu pracy, których przekroczenie uprawnia pracownika, 
oprócz normalnego wynagrodzenia, do dodatku do wynagrodzenia, o którym mowa 
w art. 1511 § 1.

***
## Art. 1511. {#kp-czwarty-art-1511}

**§ 1.** Za pracę w godzinach nadliczbowych, oprócz normalnego 
wynagrodzenia, przysługuje dodatek w wysokości: 
- 1) 100 % 
wynagrodzenia 
– 
za 
pracę 
w godzinach 
nadliczbowych 
przypadających: 
  - a) w nocy, 
  - b) w niedziele i święta niebędące dla pracownika dniami pracy, zgodnie 
z obowiązującym go rozkładem czasu pracy, 
  - c) w dniu wolnym od pracy udzielonym pracownikowi w zamian za pracę 
w niedzielę lub w święto, zgodnie z obowiązującym go rozkładem czasu 
pracy; 
- 2) 50 % wynagrodzenia – za pracę w godzinach nadliczbowych przypadających 
w każdym innym dniu niż określony w pkt 1. 

 
 
 
s. 97/195 
 
2025-08-06 
**§ 2.** Dodatek w wysokości określonej w § 1 pkt 1 przysługuje także za każdą 
godzinę pracy nadliczbowej z tytułu przekroczenia przeciętnej tygodniowej normy 
czasu pracy w przyjętym okresie rozliczeniowym, chyba że przekroczenie tej 
normy nastąpiło w wyniku pracy w godzinach nadliczbowych, za które 
pracownikowi przysługuje prawo do dodatku w wysokości określonej w § 1. 
**§ 3.** Wynagrodzenie stanowiące podstawę obliczania dodatku, o którym 
mowa w § 1, obejmuje wynagrodzenie pracownika wynikające z jego osobistego 
zaszeregowania określonego stawką godzinową lub miesięczną, a jeżeli taki 
składnik wynagrodzenia nie został wyodrębniony przy określaniu warunków 
wynagradzania – 60 % wynagrodzenia. 
**§ 4.** W stosunku do pracowników wykonujących stale pracę poza zakładem 
pracy wynagrodzenie wraz z dodatkiem, o którym mowa w § 1, może być 
zastąpione ryczałtem, którego wysokość powinna odpowiadać przewidywanemu 
wymiarowi pracy w godzinach nadliczbowych.

***
## Art. 1512. {#kp-czwarty-art-1512}

**§ 1.** W zamian za czas przepracowany w godzinach nadliczbowych 
pracodawca, na pisemny wniosek pracownika, może udzielić mu w tym samym 
wymiarze czasu wolnego od pracy. 
**§ 2.** Udzielenie czasu wolnego w zamian za czas przepracowany w godzinach 
nadliczbowych może nastąpić także bez wniosku pracownika. W takim przypadku 
pracodawca udziela czasu wolnego od pracy, najpóźniej do końca okresu roz-
liczeniowego, w wymiarze o połowę wyższym niż liczba przepracowanych godzin 
nadliczbowych, jednakże nie może to spowodować obniżenia wynagrodzenia 
należnego pracownikowi za pełny miesięczny wymiar czasu pracy. 
**§ 3.** W przypadkach określonych w § 1 i 2 pracownikowi nie przysługuje 
dodatek za pracę w godzinach nadliczbowych.

***
## Art. 1513. {#kp-czwarty-art-1513}

Pracownikowi, który ze względu na okoliczności przewidziane 
w art. 151 § 1 wykonywał pracę w dniu wolnym od pracy wynikającym z rozkładu 
czasu pracy w przeciętnie pięciodniowym tygodniu pracy, przysługuje w zamian 
inny dzień wolny od pracy udzielony pracownikowi do końca okresu 
rozliczeniowego, w terminie z nim uzgodnionym.

***
## Art. 1514. {#kp-czwarty-art-1514}

**§ 1.** Pracownicy zarządzający w imieniu pracodawcy zakładem 
pracy i kierownicy wyodrębnionych komórek organizacyjnych wykonują, w razie 

 
 
 
s. 98/195 
 
2025-08-06 
 
konieczności, pracę poza normalnymi godzinami pracy bez prawa do 
wynagrodzenia oraz dodatku z tytułu pracy w godzinach nadliczbowych, 
z zastrzeżeniem § 2. 
**§ 2.** Kierownikom wyodrębnionych komórek organizacyjnych za pracę 
w godzinach nadliczbowych przypadających w niedzielę i święto przysługuje 
prawo do wynagrodzenia oraz dodatku z tytułu pracy w godzinach nadliczbowych 
w wysokości określonej w art. 1511 § 1, jeżeli w zamian za pracę w takim dniu nie 
otrzymali innego dnia wolnego od pracy.

***
## Art. 1515. {#kp-czwarty-art-1515}

**§ 1.** Pracodawca może zobowiązać pracownika do pozostawania 
poza normalnymi godzinami pracy w gotowości do wykonywania pracy 
wynikającej z umowy o pracę w zakładzie pracy lub w innym miejscu 
wyznaczonym przez pracodawcę (dyżur). 
**§ 2.** Czasu dyżuru nie wlicza się do czasu pracy, jeżeli podczas dyżuru 
pracownik nie wykonywał pracy. Czas pełnienia dyżuru nie może naruszać prawa 
pracownika do odpoczynku, o którym mowa w art. 132 i 133. 
**§ 3.** Za czas dyżuru, z wyjątkiem dyżuru pełnionego w domu, pracownikowi 
przysługuje czas wolny od pracy w wymiarze odpowiadającym długości dyżuru, 
a w razie braku możliwości udzielenia czasu wolnego – wynagrodzenie wynikające 
z jego osobistego zaszeregowania, określonego stawką godzinową lub miesięczną, 
a jeżeli taki składnik wynagrodzenia nie został wyodrębniony przy określaniu 
warunków wynagradzania – 60 % wynagrodzenia. 
**§ 4.** Przepisu § 2 zdanie drugie oraz § 3 nie stosuje się do pracowników 
zarządzających w imieniu pracodawcy zakładem pracy.

***
## Art. 1516. {#kp-czwarty-art-1516}

**§ 1.** W razie ustania stosunku pracy przed upływem okresu 
rozliczeniowego pracownikowi przysługuje, oprócz normalnego wynagrodzenia, 
prawo do dodatku, o którym mowa w art. 1511 § 1, jeżeli w okresie od początku 
okresu rozliczeniowego do dnia ustania stosunku pracy pracował w wymiarze 
godzin przekraczającym normy czasu pracy, o których mowa w art. 129. 
**§ 2.** Przepis § 1 stosuje się odpowiednio w razie nawiązania stosunku pracy 
w trakcie okresu rozliczeniowego. 

 
 
 
s. 99/195 
 
2025-08-06 
## Rozdział VI Praca w porze nocnej

***
## Art. 1517. {#kp-czwarty-art-1517}

**§ 1.** Pora nocna obejmuje 8 godzin między godzinami 2100 a 700. 
**§ 2.** Pracownik, którego rozkład czasu pracy obejmuje w każdej dobie co 
najmniej 3 godziny pracy w porze nocnej lub którego co najmniej 1/4 czasu pracy 
w okresie rozliczeniowym przypada na porę nocną, jest pracującym w nocy. 
**§ 3.** Czas pracy pracującego w nocy nie może przekraczać 8 godzin na dobę, 
jeżeli wykonuje prace szczególnie niebezpieczne albo związane z dużym 
wysiłkiem fizycznym lub umysłowym. 
**§ 4.** Wykaz prac, o których mowa w § 3, określa pracodawca w porozumieniu 
z zakładową organizacją związkową, a jeżeli u pracodawcy nie działa zakładowa 
organizacja związkowa – z przedstawicielami pracowników wybranymi w trybie 
przyjętym u danego pracodawcy, oraz po zasięgnięciu opinii lekarza sprawującego 
profilaktyczną opiekę zdrowotną nad pracownikami, uwzględniając konieczność 
zapewnienia bezpieczeństwa pracy i ochrony zdrowia pracowników. 
**§ 5.** Przepis § 3 nie dotyczy: 
- 1) pracowników zarządzających w imieniu pracodawcy zakładem pracy; 
- 2) przypadków konieczności prowadzenia akcji ratowniczej w celu ochrony 
życia lub zdrowia ludzkiego, ochrony mienia lub środowiska albo usunięcia 
awarii. 
**§ 6.** Na pisemny wniosek pracownika, o którym mowa w § 2, pracodawca 
informuje właściwego okręgowego inspektora pracy o zatrudnianiu pracowników 
pracujących w nocy.

***
## Art. 1518. {#kp-czwarty-art-1518}

**§ 1.** Pracownikowi wykonującemu pracę w porze nocnej 
przysługuje dodatek do wynagrodzenia za każdą godzinę pracy w porze nocnej 
w wysokości 20 % stawki godzinowej wynikającej z minimalnego wynagrodzenia 
za pracę, ustalanego na podstawie odrębnych przepisów. 
**§ 2.** W stosunku do pracowników wykonujących pracę w porze nocnej stale 
poza zakładem pracy dodatek, o którym mowa w § 1, może być zastąpiony 
ryczałtem, którego wysokość odpowiada przewidywanemu wymiarowi pracy 
w porze nocnej. 

 
 
 
s. 100/195 
 
2025-08-06 
## Rozdział VII Praca w niedziele i święta

***
## Art. 1519. {#kp-czwarty-art-1519}

**§ 1.** Dniami wolnymi od pracy są niedziele i święta określone 
w przepisach o dniach wolnych od pracy. 
**§ 2.** Za pracę w niedzielę i święto, w przypadkach, o których mowa w art. 
15110, uważa się pracę wykonywaną między godziną 600 w tym dniu a godziną 600 
w następnym dniu, chyba że u danego pracodawcy została ustalona inna godzina. 
Art. 1519a. (uchylony) 
Art. 1519b. Ograniczenia w wykonywaniu pracy w placówkach handlowych 
w niedziele i święta oraz w sobotę bezpośrednio poprzedzającą pierwszy dzień 
Wielkiej Nocy określają przepisy ustawy z dnia 10 stycznia 2018 r. o ograniczeniu 
handlu w niedziele i święta oraz w niektóre inne dni (Dz. U. z 2024 r. poz. 449 
i 1965).

***
## Art. 15110. {#kp-czwarty-art-15110}

Praca w niedziele i święta jest dozwolona: 
- 1) w razie konieczności prowadzenia akcji ratowniczej w celu ochrony życia lub 
zdrowia ludzkiego, ochrony mienia lub środowiska albo usunięcia awarii; 
- 2) w ruchu ciągłym; 
- 3) przy pracy zmianowej; 
- 4) przy niezbędnych remontach; 
- 5) w transporcie i w komunikacji; 
- 6) w zakładowych strażach pożarnych i w zakładowych służbach ratowniczych; 
- 7) przy pilnowaniu mienia lub ochronie osób; 
- 8) w rolnictwie i hodowli; 
- 9) przy wykonywaniu prac koniecznych ze względu na ich użyteczność 
społeczną i codzienne potrzeby ludności, w szczególności w: 
  - a) (uchylona) 
  - b) zakładach świadczących usługi dla ludności, 
  - c) gastronomii, 
  - d) zakładach hotelarskich, 
  - e) jednostkach gospodarki komunalnej, 

 
 
 
s. 101/195 
 
2025-08-06 
  - f) zakładach opieki zdrowotnej7) i innych placówkach służby zdrowia 
przeznaczonych dla osób, których stan zdrowia wymaga całodobowych 
lub całodziennych świadczeń zdrowotnych, 
  - g) jednostkach organizacyjnych pomocy społecznej oraz jednostkach 
organizacyjnych wspierania rodziny i systemu pieczy zastępczej 
zapewniających całodobową opiekę, 
  - h) zakładach prowadzących działalność w zakresie kultury, oświaty, 
turystyki i wypoczynku; 
- 10) w stosunku do pracowników zatrudnionych w systemie czasu pracy, 
w którym praca jest świadczona wyłącznie w piątki, soboty, niedziele 
i święta; 
- 11) przy wykonywaniu prac: 
  - a) polegających na świadczeniu usług z wykorzystaniem środków 
komunikacji elektronicznej w rozumieniu przepisów o świadczeniu 
usług 
drogą 
elektroniczną 
lub 
urządzeń 
telekomunikacyjnych 
w rozumieniu przepisów prawa komunikacji elektronicznej, odbieranych 
poza terytorium Rzeczypospolitej Polskiej, jeżeli zgodnie z przepisami 
obowiązującymi odbiorcę usługi, dni, o których mowa w art. 1519 § 1, są 
u niego dniami pracy, 
  - b) zapewniających możliwość świadczenia usług, o których mowa w lit. a.

***
## Art. 15111. {#kp-czwarty-art-15111}

**§ 1.** Pracownikowi wykonującemu pracę w niedziele i święta, w 
przypadkach, o których mowa w art. 15110 pkt 1–9 i 11 oraz w przepisach ustawy, 
o której mowa w art. 1519b, pracodawca jest obowiązany zapewnić inny dzień 
wolny od pracy: 
- 1) w zamian za pracę w niedzielę – w okresie 6 dni kalendarzowych 
poprzedzających lub następujących po takiej niedzieli; 
- 2) w zamian za pracę w święto – w ciągu okresu rozliczeniowego. 
**§ 2.** Jeżeli nie jest możliwe wykorzystanie w terminie wskazanym w § 1 
pkt 1 dnia wolnego od pracy w zamian za pracę w niedzielę, pracownikowi 
przysługuje dzień wolny od pracy do końca okresu rozliczeniowego, a w razie 
- 7) Obecnie zakładach leczniczych podmiotów leczniczych, na podstawie art. 40 ustawy z dnia 
10 czerwca 2016 r. o zmianie ustawy o działalności leczniczej oraz niektórych innych ustaw 
(Dz. U. poz. 960), która weszła w życie z dniem 15 lipca 2016 r. 

 
 
 
s. 102/195 
 
2025-08-06 
 
braku możliwości udzielenia dnia wolnego od pracy w tym terminie – dodatek do 
wynagrodzenia w wysokości określonej w art. 1511 § 1 pkt 1, za każdą godzinę 
pracy w niedzielę. 
**§ 3.** Jeżeli nie jest możliwe wykorzystanie w terminie wskazanym w § 1 
pkt 2 dnia wolnego od pracy w zamian za pracę w święto, pracownikowi 
przysługuje dodatek do wynagrodzenia w wysokości określonej w art. 1511 § 1 
pkt 1, za każdą godzinę pracy w święto. 
**§ 4.** Do pracy w święto przypadające w niedzielę stosuje się przepisy 
dotyczące pracy w niedzielę.

***
## Art. 15112. {#kp-czwarty-art-15112}

Pracownik pracujący w niedziele powinien korzystać co najmniej 
raz na 4 tygodnie z niedzieli wolnej od pracy. Nie dotyczy to pracownika 
zatrudnionego w systemie czasu pracy, o którym mowa w art. 144. 
DZIAŁ SIÓDMY 
Urlopy pracownicze 
## Rozdział I Urlopy wypoczynkowe

***
## Art. 152. {#kp-czwarty-art-152}

**§ 1.** Pracownikowi 
przysługuje 
prawo 
do 
corocznego, 
nieprzerwanego, płatnego urlopu wypoczynkowego, zwanego dalej „urlopem”. 
**§ 2.** Pracownik nie może zrzec się prawa do urlopu.

***
## Art. 153. {#kp-czwarty-art-153}

**§ 1.** Pracownik podejmujący pracę po raz pierwszy, w roku 
kalendarzowym, w którym podjął pracę, uzyskuje prawo do urlopu z upływem 
każdego miesiąca pracy, w wymiarze 1/12 wymiaru urlopu przysługującego mu po 
przepracowaniu roku. 
**§ 2.** Prawo do kolejnych urlopów pracownik nabywa w każdym następnym 
roku kalendarzowym.

***
## Art. 154. {#kp-czwarty-art-154}

**§ 1.** Wymiar urlopu wynosi: 
- 1) 20 dni – jeżeli pracownik jest zatrudniony krócej niż 10 lat; 
- 2) 26 dni – jeżeli pracownik jest zatrudniony co najmniej 10 lat. 
**§ 2.** Wymiar urlopu dla pracownika zatrudnionego w niepełnym wymiarze 
czasu pracy ustala się proporcjonalnie do wymiaru czasu pracy tego pracownika, 

 
 
 
s. 103/195 
 
2025-08-06 
 
biorąc za podstawę wymiar urlopu określony w § 1; niepełny dzień urlopu zaokrąg-
la się w górę do pełnego dnia. 
**§ 3.** Wymiar urlopu w danym roku kalendarzowym, ustalony na podstawie § 1 
i 2, nie może przekroczyć wymiaru określonego w § 1.

***
## Art. 1541. {#kp-czwarty-art-1541}

**§ 1.** Do okresu zatrudnienia, od którego zależy prawo do urlopu 
i wymiar urlopu, wlicza się okresy poprzedniego zatrudnienia, bez względu na 
przerwy w zatrudnieniu oraz sposób ustania stosunku pracy. 
**§ 2.** W przypadku jednoczesnego pozostawania w dwóch lub więcej 
stosunkach pracy wliczeniu podlega także okres poprzedniego niezakończonego 
zatrudnienia w części przypadającej przed nawiązaniem drugiego lub kolejnego 
stosunku pracy.

***
## Art. 1542. {#kp-czwarty-art-1542}

**§ 1.** Urlopu udziela się w dni, które są dla pracownika dniami 
pracy, zgodnie z obowiązującym go rozkładem czasu pracy, w wymiarze 
godzinowym, odpowiadającym dobowemu wymiarowi czasu pracy pracownika 
w danym dniu, z zastrzeżeniem § 4. 
**§ 2.** Przy udzielaniu urlopu zgodnie z § 1, jeden dzień urlopu odpowiada 
8 godzinom pracy. 
**§ 3.** Przepis § 1 i 2 stosuje się odpowiednio do pracownika, dla którego 
dobowa norma czasu pracy, wynikająca z odrębnych przepisów, jest niższa niż 
8 godzin. 
**§ 4.** Udzielenie pracownikowi urlopu w dniu pracy w wymiarze godzinowym 
odpowiadającym części dobowego wymiaru czasu pracy jest dopuszczalne jedynie 
w przypadku, gdy część urlopu pozostała do wykorzystania jest niższa niż pełny 
dobowy wymiar czasu pracy pracownika w dniu, na który ma być udzielony urlop.

***
## Art. 155. {#kp-czwarty-art-155}

**§ 1.** Do okresu pracy, od którego zależy wymiar urlopu, wlicza się 
z tytułu ukończenia: 
- 1) zasadniczej lub innej równorzędnej szkoły zawodowej – przewidziany 
programem nauczania czas trwania nauki, nie więcej jednak niż 3 lata, 
- 2) średniej szkoły zawodowej – przewidziany programem nauczania czas 
trwania nauki, nie więcej jednak niż 5 lat, 
- 3) średniej szkoły zawodowej dla absolwentów zasadniczych (równorzędnych) 
szkół zawodowych – 5 lat, 

 
 
 
s. 104/195 
 
2025-08-06 
- 4) średniej szkoły ogólnokształcącej – 4 lata, 
- 5) szkoły policealnej – 6 lat, 
- 6) szkoły wyższej – 8 lat. 
Okresy nauki, o których mowa w pkt 1–6, nie podlegają sumowaniu. 
**§ 2.** Jeżeli pracownik pobierał naukę w czasie zatrudnienia, do okresu pracy, 
od którego zależy wymiar urlopu, wlicza się bądź okres zatrudnienia, w którym 
była pobierana nauka, bądź okres nauki, zależnie od tego, co jest korzystniejsze dla 
pracownika.

***
## Art. 1551. {#kp-czwarty-art-1551}

**§ 1.** W roku kalendarzowym, w którym ustaje stosunek pracy 
z pracownikiem uprawnionym do kolejnego urlopu, pracownikowi przysługuje 
urlop: 
- 1) u dotychczasowego pracodawcy – w wymiarze proporcjonalnym do okresu 
przepracowanego u tego pracodawcy w roku ustania stosunku pracy, chyba że 
przed ustaniem tego stosunku pracownik wykorzystał urlop w przysługującym 
mu lub w wyższym wymiarze; 
- 2) u kolejnego pracodawcy – w wymiarze: 
  - a) proporcjonalnym do okresu pozostałego do końca danego roku 
kalendarzowego – w razie zatrudnienia na czas nie krótszy niż do końca 
danego roku kalendarzowego, 
  - b) proporcjonalnym do okresu zatrudnienia w danym roku kalendarzowym 
– w razie zatrudnienia na czas krótszy niż do końca danego roku 
kalendarzowego, 
z zastrzeżeniem § 2. 
**§ 2.** Pracownikowi, który przed ustaniem stosunku pracy w ciągu roku 
kalendarzowego wykorzystał urlop w wymiarze wyższym niż wynikający z § 1 
pkt 1, przysługuje u kolejnego pracodawcy urlop w odpowiednio niższym 
wymiarze; łączny wymiar urlopu w roku kalendarzowym nie może być jednak 
niższy niż wynikający z okresu przepracowanego w tym roku u wszystkich 
pracodawców. 
**§ 21.** Przepis § 1 pkt 2 stosuje się odpowiednio do pracownika podejmującego 
pracę u kolejnego pracodawcy w ciągu innego roku kalendarzowego niż rok, 
w którym ustał jego stosunek pracy z poprzednim pracodawcą. 
**§ 3.** (uchylony) 

 
 
 
s. 105/195 
 
2025-08-06

***
## Art. 1552. {#kp-czwarty-art-1552}

**§ 1.** Przepis art. 1551 § 1 pkt 2 stosuje się odpowiednio do 
pracownika powracającego do pracy u dotychczasowego pracodawcy w ciągu roku 
kalendarzowego po trwającym co najmniej 1 miesiąc okresie: 
- 1) urlopu bezpłatnego; 
- 2) urlopu wychowawczego; 
- 3) pełnienia zasadniczej służby wojskowej, pełnienia terytorialnej służby 
wojskowej rotacyjnie, pełnienia służby w aktywnej rezerwie w dniach tej 
służby, odbywania ćwiczeń wojskowych w ramach pasywnej rezerwy albo 
pełnienia służby zastępczej; 
- 4) tymczasowego aresztowania; 
- 5) odbywania kary pozbawienia wolności; 
- 6) nieusprawiedliwionej nieobecności w pracy. 
**§ 2.** Jeżeli okres, o którym mowa w § 1 pkt 1 i 3–6, przypada po nabyciu przez 
pracownika prawa do urlopu w danym roku kalendarzowym, wymiar urlopu 
pracownika powracającego do pracy w ciągu tego samego roku kalendarzowego 
ulega proporcjonalnemu obniżeniu, chyba że przed rozpoczęciem tego okresu 
pracownik wykorzystał urlop w przysługującym mu lub w wyższym wymiarze. 
Art. 1552a. § 1. Przy ustalaniu wymiaru urlopu na podstawie art. 1551 
i 1552 kalendarzowy 
miesiąc 
pracy 
odpowiada 
1/12 wymiaru 
urlopu 
przysługującego pracownikowi zgodnie z art. 154 § 1 i 2. 
**§ 2.** Niepełny kalendarzowy miesiąc pracy zaokrągla się w górę do pełnego 
miesiąca. 
**§ 3.** Jeżeli 
ustanie 
stosunku 
pracy 
u dotychczasowego 
pracodawcy 
i nawiązanie takiego stosunku u kolejnego pracodawcy następuje w tym samym 
miesiącu 
kalendarzowym, 
zaokrąglenia 
do 
pełnego 
miesiąca 
dokonuje 
dotychczasowy pracodawca.

***
## Art. 1553. {#kp-czwarty-art-1553}

**§ 1.** Przy ustalaniu wymiaru urlopu na podstawie art. 1551 
i 1552 niepełny dzień urlopu zaokrągla się w górę do pełnego dnia. 
**§ 2.** Wymiar urlopu należny pracownikowi w danym roku kalendarzowym nie 
może przekroczyć wymiaru wynikającego z art. 154 § 1 i 2.

***
## Art. 156. {#kp-czwarty-art-156}

(uchylony)

***
## Art. 157. {#kp-czwarty-art-157}

(uchylony) 

 
 
 
s. 106/195 
 
2025-08-06

***
## Art. 158. {#kp-czwarty-art-158}

Pracownikowi, który wykorzystał urlop za dany rok kalendarzowy, 
a następnie uzyskał w ciągu tego roku prawo do urlopu w wyższym wymiarze, 
przysługuje urlop uzupełniający.

***
## Art. 159. {#kp-czwarty-art-159}

(uchylony)

***
## Art. 160. {#kp-czwarty-art-160}

(uchylony)

***
## Art. 161. {#kp-czwarty-art-161}

Pracodawca jest obowiązany udzielić pracownikowi urlopu w tym 
roku kalendarzowym, w którym pracownik uzyskał do niego prawo.

***
## Art. 162. {#kp-czwarty-art-162}

Na wniosek pracownika urlop może być podzielony na części. 
W takim jednak przypadku co najmniej jedna część wypoczynku powinna trwać 
nie mniej niż 14 kolejnych dni kalendarzowych.

***
## Art. 163. {#kp-czwarty-art-163}

**§ 1.** Urlopy powinny być udzielane zgodnie z planem urlopów. Plan 
urlopów ustala pracodawca, biorąc pod uwagę wnioski pracowników i konieczność 
zapewnienia normalnego toku pracy. Planem urlopów nie obejmuje się części 
urlopu udzielanego pracownikowi zgodnie z art. 1672. 
**§ 11.** Pracodawca nie ustala planu urlopów, jeżeli zakładowa organizacja 
związkowa wyraziła na to zgodę; dotyczy to także pracodawcy, u którego nie działa 
zakładowa organizacja związkowa. W takich przypadkach pracodawca ustala 
termin urlopu po porozumieniu z pracownikiem. Przepis § 1 zdanie drugie i trzecie 
stosuje się odpowiednio. 
**§ 2.** Plan urlopów podaje się do wiadomości pracowników w sposób przyjęty 
u danego pracodawcy. 
**§ 3.** Na wniosek pracownicy udziela się jej urlopu bezpośrednio po urlopie 
macierzyńskim; dotyczy to także pracownika – ojca wychowującego dziecko lub 
pracownika – innego członka najbliższej rodziny, o którym mowa w art. 1751 pkt 3, 
który korzysta z urlopu macierzyńskiego.

***
## Art. 164. {#kp-czwarty-art-164}

**§ 1.** Przesunięcie terminu urlopu może nastąpić na wniosek 
pracownika umotywowany ważnymi przyczynami. 
**§ 2.** Przesunięcie terminu urlopu jest także dopuszczalne z powodu 
szczególnych potrzeb pracodawcy, jeżeli nieobecność pracownika spowodowałaby 
poważne zakłócenia toku pracy. 

 
 
 
s. 107/195 
 
2025-08-06

***
## Art. 165. {#kp-czwarty-art-165}

Jeżeli pracownik nie może rozpocząć urlopu w ustalonym terminie 
z przyczyn 
usprawiedliwiających 
nieobecność 
w pracy, 
a w szczególności 
z powodu: 
- 1) czasowej niezdolności do pracy wskutek choroby, 
- 2) odosobnienia w związku z chorobą zakaźną, 
- 3) powołania na ćwiczenia wojskowe w ramach pasywnej rezerwy, stawienia się 
do pełnienia terytorialnej służby wojskowej rotacyjnie albo stawienia się do 
pełnienia służby w aktywnej rezerwie, na czas do 3 miesięcy, 
- 4) urlopu macierzyńskiego, 
pracodawca jest obowiązany przesunąć urlop na termin późniejszy.

***
## Art. 166. {#kp-czwarty-art-166}

Część urlopu niewykorzystaną z powodu: 
- 1) czasowej niezdolności do pracy wskutek choroby, 
- 2) odosobnienia w związku z chorobą zakaźną, 
- 3) odbywania ćwiczeń wojskowych w ramach pasywnej rezerwy, pełnienia 
terytorialnej służby wojskowej rotacyjnie albo pełnienia służby w aktywnej 
rezerwie, przez czas do 3 miesięcy, 
- 4) urlopu macierzyńskiego 
pracodawca jest obowiązany udzielić w terminie późniejszym.

***
## Art. 167. {#kp-czwarty-art-167}

**§ 1.** Pracodawca może odwołać pracownika z urlopu tylko 
wówczas, gdy jego obecności w zakładzie wymagają okoliczności nieprzewidziane 
w chwili rozpoczynania urlopu. 
**§ 2.** Pracodawca jest obowiązany pokryć koszty poniesione przez pracownika 
w bezpośrednim związku z odwołaniem go z urlopu.

***
## Art. 1671. {#kp-czwarty-art-1671}

W okresie wypowiedzenia umowy o pracę pracownik jest 
obowiązany wykorzystać przysługujący mu urlop, jeżeli w tym okresie pracodawca 
udzieli mu urlopu. W takim przypadku wymiar udzielonego urlopu, z wyłączeniem 
urlopu zaległego, nie może przekraczać wymiaru wynikającego z przepisów 
art. 1551.

***
## Art. 1672. {#kp-czwarty-art-1672}

Pracodawca jest obowiązany udzielić na żądanie pracownika 
i w terminie przez niego wskazanym nie więcej niż 4 dni urlopu w każdym roku 
kalendarzowym. Pracownik zgłasza żądanie udzielenia urlopu najpóźniej w dniu 
rozpoczęcia urlopu. 

 
 
 
s. 108/195 
 
2025-08-06

***
## Art. 1673. {#kp-czwarty-art-1673}

Łączny wymiar urlopu wykorzystanego przez pracownika na 
zasadach i w trybie określonych w art. 1672 nie może przekroczyć w roku 
kalendarzowym 4 dni, niezależnie od liczby pracodawców, z którymi pracownik 
pozostaje w danym roku w kolejnych stosunkach pracy.

***
## Art. 168. {#kp-czwarty-art-168}

Urlopu 
niewykorzystanego 
w terminie 
ustalonym 
zgodnie 
z art. 163 należy pracownikowi udzielić najpóźniej do dnia 30 września następnego 
roku kalendarzowego; nie dotyczy to części urlopu udzielanego zgodnie z art. 1672.

***
## Art. 169. {#kp-czwarty-art-169}

(uchylony)

***
## Art. 170. {#kp-czwarty-art-170}

(uchylony)

***
## Art. 171. {#kp-czwarty-art-171}

**§ 1.** W przypadku niewykorzystania przysługującego urlopu 
w całości lub w części z powodu rozwiązania lub wygaśnięcia stosunku pracy 
pracownikowi przysługuje ekwiwalent pieniężny. 
**§ 2.** (uchylony) 
**§ 3.** Pracodawca nie ma obowiązku wypłacenia ekwiwalentu pieniężnego, 
o którym mowa w § 1, w przypadku gdy strony postanowią o wykorzystaniu urlopu 
w czasie pozostawania pracownika w stosunku pracy na podstawie kolejnej umowy 
o pracę zawartej z tym samym pracodawcą bezpośrednio po rozwiązaniu lub 
wygaśnięciu poprzedniej umowy o pracę z tym pracodawcą.

***
## Art. 172. {#kp-czwarty-art-172}

Za czas urlopu pracownikowi przysługuje wynagrodzenie, jakie by 
otrzymał, gdyby w tym czasie pracował. Zmienne składniki wynagrodzenia mogą 
być obliczane na podstawie przeciętnego wynagrodzenia z okresu 3 miesięcy 
poprzedzających miesiąc rozpoczęcia urlopu; w przypadkach znacznego wahania 
wysokości wynagrodzenia okres ten może być przedłużony do 12 miesięcy.

***
## Art. 1721. {#kp-czwarty-art-1721}

**§ 1.** Jeżeli pracodawca na podstawie odrębnych przepisów jest 
obowiązany objąć pracownika ubezpieczeniem gwarantującym mu otrzymanie 
świadczenia pieniężnego za czas urlopu, pracownikowi nie przysługuje 
wynagrodzenie przewidziane w art. 172 lub ekwiwalent pieniężny, o którym mowa 
w art. 171. 
**§ 2.** Jeżeli świadczenie pieniężne za czas urlopu, o którym mowa w § 1, jest 
niższe od wynagrodzenia przewidzianego w art. 172 lub od ekwiwalentu 

 
 
 
s. 109/195 
 
2025-08-06 
 
pieniężnego, o którym mowa w art. 171, pracodawca jest obowiązany wypłacić 
pracownikowi kwotę stanowiącą różnicę między tymi należnościami.

***
## Art. 173. {#kp-czwarty-art-173}

Minister 
Pracy 
i Polityki 
Socjalnej8) 
określi, 
w drodze 
rozporządzenia, szczegółowe zasady udzielania urlopu wypoczynkowego, 
ustalania i wypłacania wynagrodzenia za czas urlopu oraz ekwiwalentu 
pieniężnego za urlop. 
## Rozdział I a 
Urlop opiekuńczy

***
## Art. 1731. {#kp-czwarty-art-1731}

**§ 1.** Pracownikowi przysługuje w ciągu roku kalendarzowego 
urlop opiekuńczy, w wymiarze 5 dni, w celu zapewnienia osobistej opieki lub 
wsparcia osobie będącej członkiem rodziny lub zamieszkującej w tym samym 
gospodarstwie domowym, która wymaga opieki lub wsparcia z poważnych 
względów medycznych. 
**§ 2.** Za członka rodziny, o którym mowa w § 1, uważa się syna, córkę, matkę, 
ojca lub małżonka. 
**§ 3.** Urlopu, o którym mowa w § 1, udziela się w dni, które są dla pracownika 
dniami pracy, zgodnie z obowiązującym go rozkładem czasu pracy. 
**§ 4.** Urlopu, o którym mowa w § 1, udziela się na wniosek pracownika 
złożony w postaci papierowej lub elektronicznej w terminie nie krótszym niż 
1 dzień przed rozpoczęciem korzystania z tego urlopu. 
**§ 5.** We wniosku wskazuje się imię i nazwisko osoby, która wymaga opieki 
lub wsparcia z poważnych względów medycznych, przyczynę konieczności 
zapewnienia osobistej opieki lub wsparcia przez pracownika oraz w przypadku 
członka rodziny ‒ stopień pokrewieństwa z pracownikiem lub w przypadku osoby 
niebędącej członkiem rodziny ‒ adres zamieszkania tej osoby.

***
## Art. 1732. {#kp-czwarty-art-1732}

Okres urlopu opiekuńczego wlicza się do okresu zatrudnienia, od 
którego zależą uprawnienia pracownicze. 
- 8) Obecnie minister właściwy do spraw pracy, na podstawie art. 4 ust. 1, art. 5 pkt 16 oraz art. 21 
ustawy z dnia 4 września 1997 r. o działach administracji rządowej (Dz. U. z 2024 r. poz. 1370 
i 1907), która weszła w życie z dniem 1 kwietnia 1999 r. 

 
 
 
s. 110/195 
 
2025-08-06

***
## Art. 1733. {#kp-czwarty-art-1733}

Do pracownika, o którym mowa w art. 1731 § 1, stosuje się 
odpowiednio przepisy art. 177 § 1, 11, 4 i 41, art. 1864 i art. 1881. 
## Rozdział II Urlopy bezpłatne

***
## Art. 174. {#kp-czwarty-art-174}

**§ 1.** Na pisemny wniosek pracownika pracodawca może udzielić mu 
urlopu bezpłatnego. 
**§ 2.** Okresu urlopu bezpłatnego nie wlicza się do okresu pracy, od którego 
zależą uprawnienia pracownicze. 
**§ 3.** Przy udzielaniu urlopu bezpłatnego, dłuższego niż 3 miesiące, strony 
mogą przewidzieć dopuszczalność odwołania pracownika z urlopu z ważnych 
przyczyn. 
**§ 4.** Przepisów § 2 i 3 nie stosuje się w przypadkach uregulowanych 
odmiennie przepisami szczególnymi.

***
## Art. 1741. {#kp-czwarty-art-1741}

**§ 1.** Za zgodą pracownika, wyrażoną na piśmie, pracodawca może 
udzielić pracownikowi urlopu bezpłatnego w celu wykonywania pracy u innego 
pracodawcy przez okres ustalony w zawartym w tej sprawie porozumieniu między 
pracodawcami. 
**§ 2.** Okres urlopu bezpłatnego, o którym mowa w § 1, wlicza się do okresu 
pracy, od którego zależą uprawnienia pracownicze u dotychczasowego 
pracodawcy.

***
## Art. 175. {#kp-czwarty-art-175}

(uchylony) 
DZIAŁ ÓSMY 
Uprawnienia pracowników związane z rodzicielstwem

***
## Art. 1751. {#kp-czwarty-art-1751}

Ilekroć w przepisach działu jest mowa o: 
- 1) ubezpieczonej – matce dziecka – należy przez to rozumieć matkę dziecka 
niebędącą pracownicą, objętą ubezpieczeniem społecznym w razie choroby 
i macierzyństwa, określonym w ustawie z dnia 13 października 1998 r. 
o systemie ubezpieczeń społecznych (Dz. U. z 2024 r. poz. 497, 863, 1243 i 
1615); 
- 2) ubezpieczonym – ojcu dziecka – należy przez to rozumieć ojca dziecka 
niebędącego pracownikiem, objętego ubezpieczeniem społecznym w razie 

 
 
 
s. 111/195 
 
2025-08-06 
 
choroby i macierzyństwa, określonym w ustawie z dnia 13 października 
1998 r. o systemie ubezpieczeń społecznych; 
- 3) pracowniku – innym członku najbliższej rodziny – należy przez to rozumieć 
będącego pracownikiem, innego niż pracownik – ojciec wychowujący 
dziecko, członka najbliższej rodziny, o którym mowa w art. 29 ust. 5 ustawy 
z dnia 25 czerwca 1999 r. o świadczeniach pieniężnych z ubezpieczenia 
społecznego w razie choroby i macierzyństwa (Dz. U. z 2023 r. poz. 2780 
oraz z 2024 r. poz. 1871); 
- 4) ubezpieczonym – innym członku najbliższej rodziny – należy przez to 
rozumieć niebędącego pracownikiem, innego niż ubezpieczony – ojciec 
dziecka, ubezpieczonego członka najbliższej rodziny, o którym mowa 
w art. 29 ust. 5 ustawy z dnia 25 czerwca 1999 r. o świadczeniach 
pieniężnych z ubezpieczenia społecznego w razie choroby i macierzyństwa.

***
## Art. 176. {#kp-czwarty-art-176}

**§ 1.** Kobiety w ciąży i kobiety karmiące dziecko piersią nie mogą 
wykonywać prac uciążliwych, niebezpiecznych lub szkodliwych dla zdrowia, 
mogących mieć niekorzystny wpływ na ich zdrowie, przebieg ciąży lub karmienie 
dziecka piersią. 
**§ 2.** Rada Ministrów określi, w drodze rozporządzenia, wykaz prac, o których 
mowa w § 1, obejmujący prace: 
- 1) związane z nadmiernym wysiłkiem fizycznym, w tym ręcznym transportem 
ciężarów, 
- 2) mogące mieć niekorzystny wpływ ze względu na sposób i warunki ich 
wykonywania, z uwzględnieniem rodzajów czynników występujących 
w środowisku pracy i poziomu ich występowania 
‒ kierując się aktualną wiedzą na temat wpływu warunków wykonywania pracy 
i czynników występujących w środowisku pracy na zdrowie kobiet, przebieg ciąży 
lub karmienie dziecka piersią.

***
## Art. 177. {#kp-czwarty-art-177}

**§ 1.** W okresie ciąży oraz w okresie urlopu macierzyńskiego, 
a także od dnia złożenia przez pracownicę lub pracownika wniosku o udzielenie 
urlopu macierzyńskiego albo jego części, urlopu na warunkach urlopu 
macierzyńskiego albo jego części, uzupełniającego urlopu macierzyńskiego, urlopu 

 
 
 
s. 112/195 
 
2025-08-06 
 
ojcowskiego albo jego części, urlopu rodzicielskiego albo jego części – do dnia 
zakończenia tego urlopu pracodawca nie może: 
- 1) prowadzić 
przygotowań 
do 
wypowiedzenia 
lub 
rozwiązania 
bez 
wypowiedzenia stosunku pracy z tą pracownicą lub tym pracownikiem; 
- 2) wypowiedzieć ani rozwiązać stosunku pracy z tą pracownicą lub tym 
pracownikiem, chyba że zachodzą przyczyny uzasadniające rozwiązanie 
umowy bez wypowiedzenia z ich winy i reprezentująca tę pracownicę lub 
tego pracownika zakładowa organizacja związkowa wyraziła zgodę na 
rozwiązanie umowy. 
**§ 11.** W przypadku złożenia wniosku, o którym mowa w § 1, wcześniej niż 
w terminach określonych w art. 180 § 9, art. 1802 § 4, art. 1821d § 1, art. 1823 § 2 
oraz art. 183 § 6 zakaz, o którym mowa w § 1, zaczyna obowiązywać na: 
- 1) 14 dni przed rozpoczęciem korzystania z części urlopu macierzyńskiego oraz 
części urlopu na warunkach urlopu macierzyńskiego; 
- 2) 21 dni 
przed 
rozpoczęciem 
korzystania 
z uzupełniającego 
urlopu 
macierzyńskiego oraz urlopu rodzicielskiego albo jego części; 
- 3) 7 dni przed rozpoczęciem korzystania z urlopu ojcowskiego albo jego części. 
**§ 2.** (uchylony) 
**§ 3.** Umowa o pracę zawarta na czas określony albo na okres próbny 
przekraczający jeden miesiąc, która uległaby rozwiązaniu po upływie trzeciego 
miesiąca ciąży, ulega przedłużeniu do dnia porodu. 
**§ 31.** Przepisu § 3 nie stosuje się do umowy o pracę na czas określony zawartej 
w celu zastępstwa pracownika w czasie jego usprawiedliwionej nieobecności 
w pracy. 
**§ 4.** Rozwiązanie przez pracodawcę umowy o pracę za wypowiedzeniem 
w okresie ciąży oraz w okresie urlopu macierzyńskiego, a także od dnia złożenia 
przez pracownicę lub pracownika wniosku o udzielenie urlopu macierzyńskiego 
albo jego części, urlopu na warunkach urlopu macierzyńskiego albo jego części, 
uzupełniającego urlopu macierzyńskiego, urlopu ojcowskiego albo jego części, 
urlopu rodzicielskiego albo jego części – do dnia zakończenia tego urlopu może 
nastąpić tylko w razie ogłoszenia upadłości lub likwidacji pracodawcy. Pracodawca 
jest obowiązany uzgodnić termin rozwiązania umowy o pracę z zakładową 
organizacją związkową reprezentującą tę pracownicę lub tego pracownika. 

 
 
 
s. 113/195 
 
2025-08-06 
 
W przypadku niemożności zapewnienia w tym okresie pracownicy lub 
pracownikowi innego zatrudnienia przysługują im świadczenia określone 
w odrębnych przepisach. Okres pobierania tych świadczeń wlicza się do okresu 
zatrudnienia, od którego zależą uprawnienia pracownicze. 
**§ 41.** Istnienie przyczyn, o których mowa w § 1 pkt 2 i § 4, udowodni 
pracodawca. 
**§ 5.** (uchylony)

***
## Art. 178. {#kp-czwarty-art-178}

**§ 1.** Pracownicy w ciąży nie wolno zatrudniać w godzinach 
nadliczbowych ani w porze nocnej. Pracownicy w ciąży nie wolno bez jej zgody 
delegować poza stałe miejsce pracy ani zatrudniać w systemie czasu pracy, 
o którym mowa w art. 139. 
**§ 2.** Pracownika wychowującego dziecko do ukończenia przez nie 8 roku 
życia nie wolno bez jego zgody zatrudniać w godzinach nadliczbowych, w porze 
nocnej, w systemie czasu pracy, o którym mowa w art. 139, oraz delegować poza 
stałe miejsce pracy.

***
## Art. 1781. {#kp-czwarty-art-1781}

Pracodawca zatrudniający pracownicę w porze nocnej jest 
obowiązany na okres jej ciąży zmienić rozkład czasu pracy w sposób 
umożliwiający wykonywanie pracy poza porą nocną, a jeżeli jest to niemożliwe lub 
niecelowe, przenieść pracownicę do innej pracy, której wykonywanie nie wymaga 
pracy w porze nocnej; w razie braku takich możliwości pracodawca jest 
obowiązany zwolnić pracownicę na czas niezbędny z obowiązku świadczenia 
pracy. Przepisy art. 179 § 4–6 stosuje się odpowiednio.

***
## Art. 179. {#kp-czwarty-art-179}

**§ 1.** Pracodawca zatrudniający pracownicę w ciąży lub karmiącą 
dziecko piersią przy pracy wymienionej w przepisach wydanych na podstawie 
art. 176 § 2, wzbronionej takiej pracownicy bez względu na stopień narażenia na 
czynniki szkodliwe dla zdrowia lub niebezpieczne, jest obowiązany przenieść 
pracownicę do innej pracy, a jeżeli jest to niemożliwe, zwolnić ją na czas niezbędny 
z obowiązku świadczenia pracy. 
**§ 2.** Pracodawca zatrudniający pracownicę w ciąży lub karmiącą dziecko 
piersią przy pozostałych pracach wymienionych w przepisach wydanych na 
podstawie art. 176 § 2 jest obowiązany dostosować warunki pracy do wymagań 
określonych w tych przepisach lub tak ograniczyć czas pracy, aby wyeliminować 

 
 
 
s. 114/195 
 
2025-08-06 
 
zagrożenia dla zdrowia lub bezpieczeństwa pracownicy. Jeżeli dostosowanie 
warunków pracy na dotychczasowym stanowisku pracy lub skrócenie czasu pracy 
jest niemożliwe lub niecelowe, pracodawca jest obowiązany przenieść pracownicę 
do innej pracy, a w razie braku takiej możliwości zwolnić pracownicę na czas 
niezbędny z obowiązku świadczenia pracy. 
**§ 3.** Przepis § 2 stosuje się odpowiednio do pracodawcy w przypadku, gdy 
przeciwwskazania zdrowotne do wykonywania dotychczasowej pracy przez 
pracownicę w ciąży lub karmiącą dziecko piersią wynikają z orzeczenia 
lekarskiego. 
**§ 4.** W razie gdy zmiana warunków pracy na dotychczas zajmowanym 
stanowisku pracy, skrócenie czasu pracy lub przeniesienie pracownicy do innej 
pracy powoduje obniżenie wynagrodzenia, pracownicy przysługuje dodatek 
wyrównawczy. 
**§ 5.** Pracownica w okresie zwolnienia z obowiązku świadczenia pracy 
zachowuje prawo do dotychczasowego wynagrodzenia. 
**§ 6.** Po ustaniu przyczyn uzasadniających przeniesienie pracownicy do innej 
pracy, skrócenie jej czasu pracy lub zwolnienie z obowiązku świadczenia pracy, 
pracodawca jest obowiązany zatrudnić pracownicę przy pracy i w wymiarze czasu 
pracy określonych w umowie o pracę. 
**§ 7.** Minister właściwy do spraw zdrowia określi, w drodze rozporządzenia, 
sposób 
i tryb 
wydawania 
zaświadczeń 
lekarskich 
stwierdzających 
przeciwwskazania zdrowotne do wykonywania dotychczasowej pracy przez 
pracownicę w ciąży lub karmiącą dziecko piersią, uwzględniając zagrożenia dla jej 
zdrowia lub bezpieczeństwa występujące w środowisku pracy.

***
## Art. 1791. {#kp-czwarty-art-1791}

(uchylony)

***
## Art. 1792. {#kp-czwarty-art-1792}

(uchylony)

***
## Art. 1793. {#kp-czwarty-art-1793}

(uchylony)

***
## Art. 1794. {#kp-czwarty-art-1794}

(uchylony)

***
## Art. 1795. {#kp-czwarty-art-1795}

(uchylony)

***
## Art. 180. {#kp-czwarty-art-180}

**§ 1.** Pracownicy przysługuje urlop macierzyński w wymiarze: 
- 1) 20 tygodni – w przypadku urodzenia jednego dziecka przy jednym porodzie; 

 
 
 
s. 115/195 
 
2025-08-06 
- 2) 31 tygodni – w przypadku urodzenia dwojga dzieci przy jednym porodzie; 
- 3) 33 tygodni – w przypadku urodzenia trojga dzieci przy jednym porodzie; 
- 4) 35 tygodni – w przypadku urodzenia czworga dzieci przy jednym porodzie; 
- 5) 37 tygodni – w przypadku urodzenia pięciorga i więcej dzieci przy jednym 
porodzie. 
**§ 2.** Przed przewidywaną datą porodu pracownica może wykorzystać nie 
więcej niż 6 tygodni urlopu macierzyńskiego. 
**§ 3.** Po porodzie przysługuje urlop macierzyński niewykorzystany przed 
porodem aż do wyczerpania wymiaru, o którym mowa w § 1. 
**§ 4.** Pracownica, po wykorzystaniu po porodzie co najmniej 14 tygodni urlopu 
macierzyńskiego, ma prawo zrezygnować z pozostałej części tego urlopu 
i powrócić do pracy, jeżeli: 
- 1) pozostałą część urlopu macierzyńskiego wykorzysta pracownik – ojciec 
wychowujący dziecko; 
- 2) przez okres odpowiadający okresowi, który pozostał do końca urlopu 
macierzyńskiego, osobistą opiekę nad dzieckiem będzie sprawował 
ubezpieczony – ojciec dziecka, który w celu sprawowania tej opieki przerwał 
działalność zarobkową. 
**§ 5.** Pracownikowi – ojcu wychowującemu dziecko przysługuje, w przypadku 
rezygnacji 
przez 
ubezpieczoną 
– 
matkę 
dziecka 
z pobierania 
zasiłku 
macierzyńskiego po wykorzystaniu przez nią tego zasiłku za okres co najmniej 
14 tygodni po porodzie, prawo do części urlopu macierzyńskiego przypadającej po 
dniu rezygnacji przez ubezpieczoną – matkę dziecka z pobierania zasiłku 
macierzyńskiego. 
**§ 6.** Pracownica 
legitymująca 
się 
orzeczeniem 
o niezdolności 
do 
samodzielnej egzystencji, po wykorzystaniu po porodzie co najmniej 8 tygodni 
urlopu macierzyńskiego, ma prawo zrezygnować z pozostałej części tego urlopu, 
jeżeli: 
- 1) pozostałą część urlopu macierzyńskiego wykorzysta pracownik – ojciec 
wychowujący dziecko albo pracownik – inny członek najbliższej rodziny; 
- 2) przez okres odpowiadający okresowi, który pozostał do końca urlopu 
macierzyńskiego, osobistą opiekę nad dzieckiem będzie sprawował 
ubezpieczony – ojciec dziecka albo ubezpieczony – inny członek najbliższej 

 
 
 
s. 116/195 
 
2025-08-06 
 
rodziny, który w celu sprawowania tej opieki przerwał działalność 
zarobkową. 
**§ 7.** Pracownikowi – ojcu wychowującemu dziecko albo pracownikowi – 
innemu członkowi najbliższej rodziny przysługuje, w przypadku rezygnacji przez 
ubezpieczoną – matkę dziecka, legitymującą się orzeczeniem o niezdolności do 
samodzielnej egzystencji, z pobierania zasiłku macierzyńskiego po wykorzystaniu 
przez nią tego zasiłku za okres co najmniej 8 tygodni po porodzie, prawo do części 
urlopu macierzyńskiego przypadającej po dniu rezygnacji przez ubezpieczoną – 
matkę dziecka z pobierania zasiłku macierzyńskiego. 
**§ 8.** W przypadkach, o których mowa w § 4 i 6, pracownica składa 
pracodawcy wniosek w postaci papierowej lub elektronicznej w sprawie rezygnacji 
z korzystania z części urlopu macierzyńskiego w terminie nie krótszym niż 7 dni 
przed przystąpieniem do pracy. Do wniosku dołącza się dokumenty określone 
w przepisach wydanych na podstawie art. 1868a. Pracodawca jest obowiązany 
uwzględnić wniosek pracownicy. 
**§ 9.** Części urlopu macierzyńskiego, o której mowa w § 4 pkt 1, § 5, § 6 pkt 1 
i § 7, pracodawca udziela, odpowiednio, pracownikowi – ojcu wychowującemu 
dziecko albo pracownikowi – innemu członkowi najbliższej rodziny, na wniosek 
w postaci papierowej lub elektronicznej składany w terminie nie krótszym niż 
14 dni przed rozpoczęciem korzystania z części urlopu. Do wniosku dołącza się 
dokumenty określone w przepisach wydanych na podstawie art. 1868a. Pracodawca 
jest obowiązany uwzględnić wniosek pracownika – ojca wychowującego dziecko 
albo pracownika – innego członka najbliższej rodziny. 
**§ 10.** Pracownica, która przebywa w szpitalu albo innym zakładzie 
leczniczym podmiotu leczniczego wykonującego działalność leczniczą w rodzaju 
stacjonarne i całodobowe świadczenia zdrowotne ze względu na stan zdrowia 
uniemożliwiający jej sprawowanie osobistej opieki nad dzieckiem, po 
wykorzystaniu po porodzie co najmniej 8 tygodni urlopu macierzyńskiego, może 
przerwać urlop macierzyński na okres pobytu w tym szpitalu albo zakładzie 
leczniczym, jeżeli: 
- 1) część urlopu macierzyńskiego za ten okres wykorzysta pracownik – ojciec 
wychowujący dziecko albo pracownik – inny członek najbliższej rodziny; 

 
 
 
s. 117/195 
 
2025-08-06 
- 2) osobistą opiekę nad dzieckiem w tym okresie będzie sprawował ubezpieczony 
– ojciec dziecka albo ubezpieczony – inny członek najbliższej rodziny, który 
w celu sprawowania tej opieki przerwał działalność zarobkową. 
**§ 11.** Pracownikowi – ojcu wychowującemu dziecko albo pracownikowi – 
innemu członkowi najbliższej rodziny przysługuje, w przypadku przerwania przez 
ubezpieczoną – matkę dziecka pobierania zasiłku macierzyńskiego po 
wykorzystaniu przez nią tego zasiłku za okres co najmniej 8 tygodni po porodzie, 
prawo do części urlopu macierzyńskiego odpowiadającej okresowi, w którym 
ubezpieczona – matka dziecka przebywa w szpitalu albo innym zakładzie 
leczniczym podmiotu leczniczego wykonującego działalność leczniczą w rodzaju 
stacjonarne i całodobowe świadczenia zdrowotne ze względu na stan zdrowia 
uniemożliwiający jej sprawowanie osobistej opieki nad dzieckiem. 
**§ 12.** W przypadku zgonu pracownicy w czasie urlopu macierzyńskiego albo 
ubezpieczonej – matki dziecka w czasie pobierania zasiłku macierzyńskiego za 
okres odpowiadający okresowi tego urlopu, pracownikowi – ojcu wychowującemu 
dziecko albo pracownikowi – innemu członkowi najbliższej rodziny, przysługuje 
prawo do części urlopu macierzyńskiego przypadającej po dniu zgonu pracownicy 
albo ubezpieczonej – matki dziecka. 
**§ 13.** W przypadku porzucenia dziecka przez pracownicę w czasie urlopu 
macierzyńskiego albo ubezpieczoną – matkę dziecka w czasie pobierania zasiłku 
macierzyńskiego za okres odpowiadający okresowi tego urlopu, pracownikowi – 
ojcu wychowującemu dziecko albo pracownikowi – innemu członkowi najbliższej 
rodziny, przysługuje prawo do części urlopu macierzyńskiego przypadającej po 
dniu porzucenia dziecka, nie wcześniej jednak niż po wykorzystaniu przez: 
- 1) pracownicę, po porodzie, co najmniej 8 tygodni urlopu macierzyńskiego; 
- 2) ubezpieczoną – matkę dziecka, zasiłku macierzyńskiego za okres co najmniej 
8 tygodni po porodzie. 
**§ 14.** Łączny wymiar urlopu macierzyńskiego oraz urlopu macierzyńskiego 
i okresu pobierania zasiłku macierzyńskiego za okres odpowiadający okresowi tego 
urlopu w okolicznościach, o których mowa w § 4–7 i § 10–13, nie może 
przekroczyć wymiaru urlopu macierzyńskiego, o którym mowa w § 1. 
**§ 15.** W przypadku: 

 
 
 
s. 118/195 
 
2025-08-06 
- 1) zgonu matki dziecka nieobjętej ubezpieczeniem społecznym w razie choroby 
i macierzyństwa, określonym w ustawie z dnia 13 października 1998 r. 
o systemie ubezpieczeń społecznych, albo nieposiadającej tytułu do objęcia 
takim ubezpieczeniem, 
- 2) porzucenia dziecka przez matkę nieobjętą ubezpieczeniem, o którym mowa 
w pkt 1, albo nieposiadającą tytułu do objęcia takim ubezpieczeniem, 
- 3) niemożności sprawowania osobistej opieki nad dzieckiem przez matkę 
nieobjętą ubezpieczeniem, o którym mowa w pkt 1, albo nieposiadającą tytułu 
do 
objęcia 
takim 
ubezpieczeniem, 
legitymującą 
się 
orzeczeniem 
o niezdolności do samodzielnej egzystencji 
– pracownikowi – ojcu wychowującemu dziecko albo pracownikowi – innemu 
członkowi najbliższej rodziny przysługuje prawo do części urlopu macierzyńskiego 
przypadającej po dniu zgonu matki dziecka, porzucenia przez nią dziecka albo 
powstania niezdolności do samodzielnej egzystencji. 
**§ 16.** W okolicznościach, o których mowa w § 10 pkt 1 i § 11–13 i 15, części 
urlopu macierzyńskiego udziela się na wniosek składany w postaci papierowej lub 
elektronicznej przez pracownika – ojca wychowującego dziecko albo pracownika 
– innego członka najbliższej rodziny. Do wniosku dołącza się dokumenty określone 
w przepisach wydanych na podstawie art. 1868a. Pracodawca jest obowiązany 
uwzględnić wniosek pracownika – ojca wychowującego dziecko albo pracownika 
– innego członka najbliższej rodziny. 
**§ 17.** W przypadku podjęcia przez matkę dziecka nieposiadającą tytułu do 
objęcia ubezpieczeniem społecznym w razie choroby i macierzyństwa, określonym 
w ustawie z dnia 13 października 1998 r. o systemie ubezpieczeń społecznych, 
zatrudnienia w wymiarze nie niższym niż połowa pełnego wymiaru czasu pracy, 
pracownikowi – ojcu wychowującemu dziecko przysługuje, w okresie trwania 
zatrudnienia matki dziecka, prawo do części urlopu macierzyńskiego przypadającej 
od dnia podjęcia zatrudnienia przez matkę dziecka aż do wyczerpania wymiaru, 
o którym mowa w § 1. Przepis § 9 stosuje się odpowiednio.

***
## Art. 1801. {#kp-czwarty-art-1801}

**§ 1.** W razie urodzenia martwego dziecka lub zgonu dziecka przed 
upływem 8 tygodni życia, pracownicy przysługuje urlop macierzyński w wymiarze 
8 tygodni po porodzie, nie krócej jednak niż przez okres 7 dni od dnia zgonu 
dziecka. Pracownicy, która urodziła więcej niż jedno dziecko przy jednym 

 
 
 
s. 119/195 
 
2025-08-06 
 
porodzie, przysługuje w takim przypadku urlop macierzyński w wymiarze 
stosownym do liczby dzieci pozostałych przy życiu. 
**§ 2.** W przypadku zgonu dziecka po upływie 8 tygodni życia, pracownica 
zachowuje prawo do urlopu macierzyńskiego przez okres 7 dni od dnia zgonu 
dziecka. Pracownicy, która urodziła więcej niż jedno dziecko przy jednym 
porodzie, przysługuje w takim przypadku urlop macierzyński w wymiarze 
stosownym do liczby dzieci pozostałych przy życiu, nie krócej jednak niż przez 
okres 7 dni od dnia zgonu dziecka.

***
## Art. 1802. {#kp-czwarty-art-1802}

**§ 1.** Pracownica albo pracownik – ojciec wychowujący dziecko ma 
prawo bezpośrednio po wykorzystaniu urlopu macierzyńskiego do uzupełniającego 
urlopu macierzyńskiego – w przypadku urodzenia dziecka: 
- 1) przed ukończeniem 28. tygodnia ciąży lub z masą urodzeniową nie większą 
niż 1000 g – w wymiarze tygodnia uzupełniającego urlopu macierzyńskiego 
za każdy tydzień pobytu dziecka w szpitalu do upływu 15. tygodnia 
po porodzie; 
- 2) po ukończeniu 28. tygodnia ciąży i przed ukończeniem 37. tygodnia ciąży 
i z masą urodzeniową większą niż 1000 g – w wymiarze tygodnia 
uzupełniającego urlopu macierzyńskiego za każdy tydzień pobytu dziecka 
w szpitalu do upływu 8. tygodnia po porodzie; 
- 3) po ukończeniu 37. tygodnia ciąży i jego pobytu w szpitalu, pod warunkiem że 
pobyt dziecka w szpitalu po porodzie będzie wynosił co najmniej 2 kolejne 
dni, przy czym pierwszy z tych dni będzie przypadał w okresie od 5. do 28. 
dnia po porodzie – w wymiarze tygodnia uzupełniającego urlopu 
macierzyńskiego za każdy tydzień pobytu dziecka w szpitalu w okresie od 5. 
dnia do upływu 8. tygodnia po porodzie. 
**§ 2.** W przypadku urodzenia więcej niż jednego dziecka przy jednym porodzie 
przy ustalaniu wymiaru uzupełniającego urlopu macierzyńskiego należy 
uwzględnić wagę dziecka o najniższej masie urodzeniowej oraz okres pobytu 
w szpitalu dziecka najdłużej hospitalizowanego. 
**§ 3.** Przy ustalaniu wymiaru uzupełniającego urlopu macierzyńskiego okresy 
pobytu dziecka w szpitalu do upływu odpowiednio 8. albo 15. tygodnia po porodzie 
sumuje się. Niepełny tydzień zaokrągla się w górę do pełnego tygodnia. 

 
 
 
s. 120/195 
 
2025-08-06 
**§ 4.** Uzupełniający urlop macierzyński jest udzielany jednorazowo na 
wniosek składany w postaci papierowej lub elektronicznej przez pracownicę albo 
pracownika – ojca wychowującego dziecko w terminie nie krótszym niż 21 dni 
przed zakończeniem korzystania z urlopu macierzyńskiego. Pracodawca jest 
obowiązany uwzględnić wniosek. 
**§ 5.** Do wniosku dołącza się zaświadczenie wydane przez szpital, w którym 
przebywało dziecko, oraz dokumenty określone w przepisach wydanych na 
podstawie art. 1868a. Zaświadczenie zawiera informacje o okresie pobytu dziecka 
w szpitalu oraz o urodzeniu dziecka: 
- 1) przed ukończeniem 28. tygodnia ciąży lub z masą urodzeniową nie większą 
niż 1000 g; 
- 2) po ukończeniu 28. tygodnia ciąży i przed ukończeniem 37. tygodnia ciąży 
i z masą urodzeniową większą niż 1000 g; 
- 3) po ukończeniu 37. tygodnia ciąży. 
**§ 6.** We wniosku o udzielenie uzupełniającego urlopu macierzyńskiego 
określa się termin zakończenia urlopu macierzyńskiego. 
**§ 7.** Do uzupełniającego urlopu macierzyńskiego przepisy art. 45 § 3, art. 47, 
art. 57 § 2, art. 163 § 3, art. 165 pkt 4, art. 166 pkt 4, art. 180 § 6–17, art. 1801 § 2, 
art. 182 zdanie pierwsze i art. 1831 § 1 stosuje się odpowiednio.

***
## Art. 181. {#kp-czwarty-art-181}

W razie urodzenia dziecka wymagającego opieki szpitalnej 
pracownica, która wykorzystała po porodzie 8 tygodni urlopu macierzyńskiego, 
pozostałą część tego urlopu może wykorzystać w terminie późniejszym, po wyjściu 
dziecka ze szpitala.

***
## Art. 182. {#kp-czwarty-art-182}

W przypadku 
porzucenia 
dziecka 
przez 
pracownicę 
lub 
umieszczenia dziecka, na podstawie orzeczenia sądu, w pieczy zastępczej, 
w zakładzie opiekuńczo-leczniczym, w zakładzie pielęgnacyjno-opiekuńczym albo 
w zakładzie rehabilitacji leczniczej, pracownicy nie przysługuje część urlopu 
macierzyńskiego przypadająca po dniu porzucenia dziecka albo umieszczenia 
dziecka w pieczy zastępczej, w zakładzie opiekuńczo-leczniczym, w zakładzie 
pielęgnacyjno-opiekuńczym albo w zakładzie rehabilitacji leczniczej. Jednakże 
urlop macierzyński po porodzie nie może wynosić mniej niż 8 tygodni.

***
## Art. 1821. {#kp-czwarty-art-1821}

(uchylony) 

 
 
 
s. 121/195 
 
2025-08-06 
 
Art. 1821a. § 1. Pracownicy – rodzice dziecka mają prawo do urlopu 
rodzicielskiego w celu sprawowania opieki nad dzieckiem w wymiarze do: 
- 1) 41 tygodni – w przypadku, o którym mowa w art. 180 § 1 pkt 1; 
- 2) 43 tygodni – w przypadkach, o których mowa w art. 180 § 1 pkt 2–5. 
**§ 2.** Pracownicy – rodzice dziecka posiadającego zaświadczenie, o którym 
mowa w art. 4 ust. 3 ustawy z dnia 4 listopada 2016 r. o wsparciu kobiet w ciąży 
i rodzin „Za życiem”, mają prawo do urlopu rodzicielskiego w celu sprawowania 
opieki nad tym dzieckiem w wymiarze do: 
- 1) 65 tygodni – w przypadku, o którym mowa w art. 180 § 1 pkt 1; 
- 2) 67 tygodni – w przypadkach, o których mowa w art. 180 § 1 pkt 2–5. 
**§ 3.** Urlop rodzicielski w wymiarze, o którym mowa w § 1 i 2, przysługuje 
łącznie obojgu pracownikom – rodzicom dziecka. 
**§ 4.** Każdemu z pracowników – rodziców dziecka przysługuje wyłączne 
prawo do 9 tygodni urlopu rodzicielskiego z wymiaru urlopu określonego w § 1 i 2. 
Prawa tego nie można przenieść na drugiego z pracowników – rodziców dziecka. 
**§ 5.** Skorzystanie z urlopu rodzicielskiego w wymiarze co najmniej 9 tygodni 
oznacza wykorzystanie przez pracownika – rodzica dziecka urlopu, o którym mowa 
w § 4. 
**§ 6.** Z urlopu rodzicielskiego mogą jednocześnie korzystać oboje pracownicy 
– rodzice dziecka. W takim przypadku łączny wymiar urlopu rodzicielskiego nie 
może przekraczać wymiaru, o którym mowa w § 1 albo 2. 
**§ 7.** W okresie pobierania przez jednego z rodziców dziecka zasiłku 
macierzyńskiego za okres odpowiadający okresowi urlopu rodzicielskiego drugi 
rodzic może korzystać z urlopu rodzicielskiego. W takim przypadku łączny wymiar 
urlopu rodzicielskiego i okresu pobierania zasiłku macierzyńskiego za okres 
odpowiadający okresowi urlopu rodzicielskiego nie może przekraczać wymiaru, 
o którym mowa w § 1 albo 2. 
Art. 1821b. (uchylony) 
Art. 1821c. Urlop rodzicielski jest udzielany jednorazowo albo nie więcej niż 
w 5 częściach nie później niż do zakończenia roku kalendarzowego, w którym 
dziecko kończy 6 rok życia. 

 
 
 
s. 122/195 
 
2025-08-06 
 
Art. 1821d. § 1. Urlop rodzicielski jest udzielany na wniosek w postaci 
papierowej lub elektronicznej składany przez pracownika – rodzica dziecka 
w terminie nie krótszym niż 21 dni przed rozpoczęciem korzystania z urlopu. Do 
wniosku dołącza się dokumenty określone w przepisach wydanych na podstawie 
art. 1868a. Pracodawca jest obowiązany uwzględnić wniosek pracownika. 
**§ 2.** Liczbę części urlopu ustala się w oparciu o liczbę złożonych wniosków 
o udzielenie urlopu. W liczbie wykorzystanych części urlopu uwzględnia się także 
liczbę wniosków o zasiłek macierzyński za okres odpowiadający okresowi urlopu 
rodzicielskiego albo jego części, złożonych przez ubezpieczoną – matkę dziecka 
lub ubezpieczonego – ojca dziecka. 
**§ 3.** Pracownik może zrezygnować z korzystania z urlopu rodzicielskiego 
w każdym czasie za zgodą pracodawcy i powrócić do pracy. 
Art. 1821e. § 1. Pracownik może łączyć korzystanie z urlopu rodzicielskiego 
z wykonywaniem pracy u pracodawcy udzielającego tego urlopu w wymiarze nie 
wyższym niż połowa pełnego wymiaru czasu pracy. W takim przypadku urlopu 
rodzicielskiego udziela się na pozostałą część wymiaru czasu pracy. 
**§ 2.** W przypadku, o którym mowa w § 1, podjęcie pracy następuje na 
wniosek w postaci papierowej lub elektronicznej składany przez pracownika 
w terminie nie krótszym niż 21 dni przed rozpoczęciem wykonywania pracy. 
Pracodawca jest obowiązany uwzględnić wniosek pracownika, chyba że nie jest to 
możliwe ze względu na organizację pracy lub rodzaj pracy wykonywanej przez 
pracownika. O przyczynie odmowy uwzględnienia wniosku pracodawca informuje 
pracownika w postaci papierowej lub elektronicznej w terminie 7 dni od dnia 
otrzymania wniosku. 
Art. 1821f. § 1. W przypadku łączenia przez pracownika – rodzica dziecka 
korzystania z urlopu rodzicielskiego z wykonywaniem pracy u pracodawcy 
udzielającego tego urlopu wymiar urlopu rodzicielskiego ulega wydłużeniu 
proporcjonalnie do wymiaru czasu pracy wykonywanej przez pracownika w trakcie 
korzystania z urlopu lub jego części, nie dłużej jednak niż do: 
- 1) 82 tygodni – w przypadku, o którym mowa w art. 180 § 1 pkt 1; 
- 2) 86 tygodni – w przypadkach, o których mowa w art. 180 § 1 pkt 2–5. 

 
 
 
s. 123/195 
 
2025-08-06 
**§ 11.** W przypadku 
łączenia 
przez 
pracownika 
– 
rodzica 
dziecka 
posiadającego zaświadczenie, o którym mowa w art. 4 ust. 3 ustawy z dnia 
4 listopada 2016 r. o wsparciu kobiet w ciąży i rodzin „Za życiem”, korzystania 
z urlopu rodzicielskiego z wykonywaniem pracy u pracodawcy udzielającego tego 
urlopu wymiar urlopu rodzicielskiego ulega wydłużeniu proporcjonalnie do 
wymiaru czasu pracy wykonywanej przez pracownika – rodzica dziecka w trakcie 
korzystania z urlopu lub jego części, nie dłużej jednak niż do: 
- 1) 130 tygodni – w przypadku, o którym mowa w art. 180 § 1 pkt 1; 
- 2) 134 tygodni – w przypadkach, o których mowa w art. 180 § 1 pkt 2–5. 
**§ 2.** Okres, o który urlop rodzicielski ulega wydłużeniu, stanowi iloczyn 
liczby tygodni, przez jaką pracownik łączy korzystanie z urlopu rodzicielskiego 
z wykonywaniem pracy u pracodawcy udzielającego tego urlopu i wymiaru czasu 
pracy 
wykonywanej 
przez 
pracownika 
w trakcie 
korzystania 
z urlopu 
rodzicielskiego. 
**§ 3.** W przypadku gdy łączenie korzystania z urlopu z wykonywaniem pracy, 
o którym mowa w § 1 albo § 11, odbywa się przez część urlopu rodzicielskiego, 
proporcjonalne 
wydłużenie 
wymiaru 
tego 
urlopu, 
następuje 
wyłącznie 
w odniesieniu do tej części urlopu rodzicielskiego. 
**§ 4.** W przypadku gdy powstała w wyniku wydłużenia wymiaru urlopu 
rodzicielskiego część urlopu rodzicielskiego nie odpowiada wielokrotności 
tygodnia, jest ona udzielana w dniach. Przy udzielaniu urlopu niepełny dzień 
pomija się. 
**§ 5.** Część urlopu rodzicielskiego, o którą urlop został proporcjonalnie 
wydłużony zgodnie z § 1–4, wydłuża część urlopu rodzicielskiego, podczas której 
pracownik łączył korzystanie z urlopu z wykonywaniem pracy w niepełnym 
wymiarze czasu pracy u pracodawcy udzielającego urlopu. 
**§ 6.** We wniosku, o którym mowa w art. 1821e § 2, pracownik określa sposób 
wykorzystania 
części 
urlopu 
rodzicielskiego, 
o którą 
urlop 
zostanie 
proporcjonalnie wydłużony. 
**§ 7.** W przypadku gdy pracownik zamierza łączyć korzystanie z części urlopu 
rodzicielskiego powstałej w wyniku proporcjonalnego wydłużenia tego urlopu, 
obliczonej zgodnie z § 2, z wykonywaniem pracy w niepełnym wymiarze czasu 
pracy, wymiar tej części urlopu oblicza się dzieląc długość części urlopu powstałej 

 
 
 
s. 124/195 
 
2025-08-06 
 
w wyniku proporcjonalnego wydłużenia przez różnicę liczby 1 i wymiaru czasu 
pracy, w jakim pracownik zamierza łączyć korzystanie z tej części urlopu 
z wykonywaniem pracy. Przepis § 4 stosuje się odpowiednio. 
Art. 1821g. Do urlopu rodzicielskiego stosuje się odpowiednio przepisy 
art. 45 § 3, art. 47, art. 57 § 2, art. 163 § 3, art. 165 pkt 4, art. 166 pkt 4, art. 180 
§ 6–17, art. 1801 § 2, art. 181, art. 182 zdanie pierwsze i art. 1831 § 1.

***
## Art. 1822. {#kp-czwarty-art-1822}

(uchylony)

***
## Art. 1823. {#kp-czwarty-art-1823}

**§ 1.** W celu sprawowania opieki nad dzieckiem pracownik – ojciec 
ma prawo do urlopu ojcowskiego w wymiarze do 2 tygodni, nie dłużej jednak niż 
do: 
- 1) ukończenia przez dziecko 12 miesiąca życia albo 
- 2) upływu 
12 miesięcy 
od 
dnia 
uprawomocnienia 
się 
postanowienia 
orzekającego przysposobienie dziecka i nie dłużej niż do ukończenia przez 
dziecko 14 roku życia. 
**§ 11.** Urlop ojcowski może być wykorzystany jednorazowo albo nie więcej niż 
w 2 częściach, z których żadna nie może być krótsza niż tydzień. 
**§ 2.** Urlop ojcowski jest udzielany na wniosek w postaci papierowej lub 
elektronicznej składany przez pracownika – ojca w terminie nie krótszym niż 7 dni 
przed rozpoczęciem korzystania z urlopu. Do wniosku dołącza się dokumenty 
określone w przepisach wydanych na podstawie art. 1868a. Pracodawca jest 
obowiązany uwzględnić wniosek pracownika. 
**§ 3.** Do urlopu ojcowskiego stosuje się odpowiednio przepisy art. 45 § 3, 
art. 47, art. 57 § 2, art. 163 § 3, art. 165 pkt 4, art. 166 pkt 4, art. 181 i art. 1831 § 1.

***
## Art. 1824. {#kp-czwarty-art-1824}

(uchylony)

***
## Art. 183. {#kp-czwarty-art-183}

**§ 1.** Pracownik, który przyjął dziecko na wychowanie jako rodzina 
zastępcza, z wyjątkiem rodziny zastępczej zawodowej, ma prawo do urlopu na 
warunkach urlopu macierzyńskiego w wymiarze: 
- 1) 20 tygodni – w przypadku przyjęcia jednego dziecka, 
- 2) 31 tygodni – w przypadku jednoczesnego przyjęcia dwojga dzieci, 
- 3) 33 tygodni – w przypadku jednoczesnego przyjęcia trojga dzieci, 
- 4) 35 tygodni – w przypadku jednoczesnego przyjęcia czworga dzieci, 
- 5) 37 tygodni – w przypadku jednoczesnego przyjęcia pięciorga i więcej dzieci 

 
 
 
s. 125/195 
 
2025-08-06 
 
– nie dłużej jednak niż do ukończenia przez dziecko 7 roku życia, a w przypadku 
dziecka, wobec którego podjęto decyzję o odroczeniu obowiązku szkolnego, nie 
dłużej niż do ukończenia przez nie 10 roku życia. 
**§ 11.** Pracownik, który przyjął dziecko na wychowanie i wystąpił do sądu 
opiekuńczego z wnioskiem o wszczęcie postępowania w sprawie przysposobienia 
dziecka, ma prawo do urlopu na warunkach urlopu macierzyńskiego w wymiarze: 
- 1) 20 tygodni – w przypadku przyjęcia jednego dziecka, 
- 2) 31 tygodni – w przypadku jednoczesnego przyjęcia dwojga dzieci, 
- 3) 33 tygodni – w przypadku jednoczesnego przyjęcia trojga dzieci, 
- 4) 35 tygodni – w przypadku jednoczesnego przyjęcia czworga dzieci, 
- 5) 37 tygodni – w przypadku jednoczesnego przyjęcia pięciorga i więcej dzieci 
– nie dłużej jednak niż do ukończenia przez dziecko 14 roku życia. 
**§ 2.** Do urlopu na warunkach urlopu macierzyńskiego przepisy art. 45 § 3, 
art. 47, art. 57 § 2, art. 163 § 3, art. 165 pkt 4, art. 166 pkt 4, art. 180 § 4–17, 
art. 1801 § 2 i art. 181 stosuje się odpowiednio. 
**§ 3.** Pracownik, o którym mowa w § 1, który przyjął dziecko w wieku do 
7 roku życia, a w przypadku dziecka, wobec którego podjęto decyzję o odroczeniu 
obowiązku szkolnego, do 10 roku życia, oraz pracownik, o którym mowa w § 11, 
który przyjął dziecko w wieku do 14 roku życia ‒ ma prawo do 9 tygodni urlopu na 
warunkach urlopu macierzyńskiego. 
**§ 31.** Pracownik, o którym mowa w § 1 albo § 11, ma prawo do 
uzupełniającego urlopu macierzyńskiego na zasadach określonych w art. 1802, 
jeżeli pobyt dziecka w szpitalu miał miejsce po przyjęciu dziecka na wychowanie. 
**§ 4.** Pracownicy, którzy przyjęli dziecko na wychowanie jako rodzina 
zastępcza, z wyjątkiem rodziny zastępczej zawodowej, mają prawo do urlopu 
rodzicielskiego w celu sprawowania opieki nad tym dzieckiem w wymiarze do: 
- 1) 41 tygodni – w przypadku, o którym mowa w § 1 pkt 1; 
- 2) 43 tygodni – w przypadkach, o których mowa w § 1 pkt 2–5; 
- 3) 38 tygodni – w przypadku, o którym mowa w § 3. 
**§ 41.** Pracownicy, którzy przyjęli dziecko na wychowanie i wystąpili do sądu 
opiekuńczego z wnioskiem o wszczęcie postępowania w sprawie przysposobienia 
dziecka, mają prawo do urlopu rodzicielskiego w celu sprawowania opieki nad tym 
dzieckiem w wymiarze do: 

 
 
 
s. 126/195 
 
2025-08-06 
- 1) 41 tygodni – w przypadku, o którym mowa w § 11 pkt 1, 
- 2) 43 tygodni – w przypadkach, o których mowa w § 11 pkt 2–5 
– nie dłużej jednak niż do ukończenia przez dziecko 14 roku życia. 
**§ 42.** Pracownicy, o których mowa w § 3, którzy przyjęli na wychowanie 
dziecko w wieku do ukończenia 14 roku życia, mają prawo do 38 tygodni urlopu 
rodzicielskiego. 
**§ 43.** Pracownicy, o których mowa w § 4, w przypadku dziecka posiadającego 
zaświadczenie, o którym mowa w art. 4 ust. 3 ustawy z dnia 4 listopada 2016 r. 
o wsparciu kobiet w ciąży i rodzin „Za życiem”, mają prawo do urlopu 
rodzicielskiego w celu sprawowania opieki nad tym dzieckiem w wymiarze do: 
- 1) 65 tygodni – w przypadku, o którym mowa w § 1 pkt 1; 
- 2) 67 tygodni – w przypadkach, o których mowa w § 1 pkt 2–5; 
- 3) 62 tygodni – w przypadku, o którym mowa w § 3. 
**§ 44.** Pracownicy, 
o których 
mowa 
w § 41, 
w przypadku 
dziecka 
posiadającego zaświadczenie, o którym mowa w art. 4 ust. 3 ustawy z dnia 
4 listopada 2016 r. o wsparciu kobiet w ciąży i rodzin „Za życiem”, mają prawo do 
urlopu rodzicielskiego w celu sprawowania opieki nad tym dzieckiem w wymiarze 
do: 
- 1) 65 tygodni – w przypadku, o którym mowa w § 11 pkt 1, 
- 2) 67 tygodni – w przypadkach, o których mowa w § 11 pkt 2–5 
– nie dłużej jednak niż do ukończenia przez dziecko 14 roku życia. 
**§ 45.** Pracownicy, o których mowa w § 3, którzy przyjęli na wychowanie 
dziecko w wieku do ukończenia 14 roku życia, w przypadku dziecka posiadającego 
zaświadczenie, o którym mowa w art. 4 ust. 3 ustawy z dnia 4 listopada 2016 r. 
o wsparciu kobiet w ciąży i rodzin „Za życiem”, mają prawo do 62 tygodni urlopu 
rodzicielskiego. 
**§ 46.** Urlop rodzicielski jest udzielany jednorazowo albo nie więcej niż 
w 5 częściach. 
**§ 5.** Do urlopu rodzicielskiego stosuje się odpowiednio przepisy art. 1821a 
§ 3–7 i art. 1821c–1821g. 
**§ 6.** Urlop na warunkach urlopu macierzyńskiego jest udzielany na wniosek 
w postaci papierowej lub elektronicznej składany przez pracownika w terminie 
7 dni od dnia przyjęcia dziecka na wychowanie jako rodzina zastępcza albo 

 
 
 
s. 127/195 
 
2025-08-06 
 
przyjęcia dziecka na wychowanie i wystąpienia do sądu opiekuńczego z wnioskiem 
o wszczęcie postępowania w sprawie przysposobienia dziecka. Urlop rozpoczyna 
się w terminie określonym we wniosku pracownika, jednak nie później niż 21 dni 
od dnia odpowiednio przyjęcia dziecka na wychowanie jako rodzina zastępcza albo 
przyjęcia dziecka na wychowanie i wystąpienia do sądu opiekuńczego z wnioskiem 
o wszczęcie postępowania w sprawie przysposobienia dziecka. Do wniosku 
dołącza się dokumenty określone w przepisach wydanych na podstawie art. 1868a. 
Pracodawca jest obowiązany uwzględnić wniosek pracownika. 
**§ 7.** Pracownik, który korzysta lub korzystał z urlopu na warunkach urlopu 
macierzyńskiego w związku z przyjęciem dziecka na wychowanie jako rodzina 
zastępcza, a następnie wystąpił do sądu opiekuńczego z wnioskiem o wszczęcie 
postępowania w sprawie przysposobienia dziecka, ma prawo do urlopu na 
warunkach urlopu macierzyńskiego w związku z wystąpieniem do sądu 
opiekuńczego z wnioskiem o wszczęcie postępowania w sprawie przysposobienia 
dziecka w wymiarze określonym w § 11 obniżonym o wykorzystany urlop na 
warunkach urlopu macierzyńskiego w związku z przyjęciem dziecka na 
wychowanie jako rodzina zastępcza. 
**§ 8.** Pracownik, który korzysta lub korzystał z urlopu rodzicielskiego 
w związku z przyjęciem dziecka na wychowanie jako rodzina zastępcza, 
a następnie wystąpił do sądu opiekuńczego z wnioskiem o wszczęcie postępowania 
w sprawie przysposobienia dziecka, ma prawo do urlopu rodzicielskiego 
w związku z wystąpieniem do sądu opiekuńczego z wnioskiem o wszczęcie 
postępowania w sprawie przysposobienia dziecka w wymiarze określonym w § 41 
albo 42 albo § 44 albo 45, obniżonym o wykorzystany urlop rodzicielski w związku 
z przyjęciem dziecka na wychowanie jako rodzina zastępcza.

***
## Art. 1831. {#kp-czwarty-art-1831}

**§ 1.** Przy udzielaniu urlopu macierzyńskiego i urlopu na 
warunkach urlopu macierzyńskiego tydzień urlopu odpowiada 7 dniom 
kalendarzowym. 
**§ 2.** Jeżeli pracownica nie korzysta z urlopu macierzyńskiego przed 
przewidywaną datą porodu, pierwszym dniem urlopu macierzyńskiego jest dzień 
porodu.

***
## Art. 1832. {#kp-czwarty-art-1832}

(uchylony) 

 
 
 
s. 128/195 
 
2025-08-06

***
## Art. 184. {#kp-czwarty-art-184}

Za okres urlopu macierzyńskiego, urlopu na warunkach urlopu 
macierzyńskiego, uzupełniającego urlopu macierzyńskiego, urlopu rodzicielskiego 
oraz urlopu ojcowskiego przysługuje zasiłek macierzyński na zasadach 
określonych w ustawie z dnia 25 czerwca 1999 r. o świadczeniach pieniężnych 
z ubezpieczenia społecznego w razie choroby i macierzyństwa.

***
## Art. 185. {#kp-czwarty-art-185}

**§ 1.** Stan ciąży powinien być stwierdzony świadectwem lekarskim. 
**§ 2.** Pracodawca jest obowiązany udzielać pracownicy ciężarnej zwolnień od 
pracy na zalecone przez lekarza badania lekarskie przeprowadzane w związku 
z ciążą, jeżeli badania te nie mogą być przeprowadzone poza godzinami pracy. 
Za czas nieobecności w pracy z tego powodu pracownica zachowuje prawo do 
wynagrodzenia.

***
## Art. 186. {#kp-czwarty-art-186}

**§ 1.** Pracownik zatrudniony co najmniej 6 miesięcy ma prawo do 
urlopu wychowawczego w celu sprawowania osobistej opieki nad dzieckiem. Do 
sześciomiesięcznego okresu 
zatrudnienia wlicza się poprzednie okresy 
zatrudnienia. 
**§ 2.** Wymiar urlopu wychowawczego wynosi do 36 miesięcy. Urlop jest 
udzielany na okres nie dłuższy niż do zakończenia roku kalendarzowego, w którym 
dziecko kończy 6 rok życia. 
**§ 3.** Jeżeli 
z powodu 
stanu 
zdrowia 
potwierdzonego 
orzeczeniem 
o niepełnosprawności lub stopniu niepełnosprawności dziecko wymaga osobistej 
opieki pracownika, niezależnie od urlopu, o którym mowa w § 2, może być 
udzielony urlop wychowawczy w wymiarze do 36 miesięcy, jednak na okres nie 
dłuższy niż do ukończenia przez dziecko 18 roku życia. 
**§ 31.** Urlopy w wymiarach, o których mowa w § 2 i 3, przysługują łącznie 
obojgu rodzicom lub opiekunom dziecka. 
**§ 4.** Każdemu z rodziców lub opiekunów dziecka przysługuje wyłączne 
prawo do jednego miesiąca urlopu wychowawczego z wymiaru urlopu określonego 
w § 2 i 3. Prawa tego nie można przenieść na drugiego z rodziców lub opiekunów 
dziecka. 
**§ 5.** Skorzystanie z urlopu wychowawczego w wymiarze co najmniej jednego 
miesiąca oznacza wykorzystanie przez rodzica lub opiekuna dziecka urlopu, 
o którym mowa w § 4. 

 
 
 
s. 129/195 
 
2025-08-06 
**§ 6.** Z urlopu wychowawczego mogą jednocześnie korzystać oboje rodzice 
lub 
opiekunowie dziecka. W takim 
przypadku łączny wymiar urlopu 
wychowawczego nie może przekraczać wymiaru, o którym mowa w § 2 i 3. 
**§ 7.** Urlop wychowawczy jest udzielany na wniosek w postaci papierowej lub 
elektronicznej składany przez pracownika w terminie nie krótszym niż 21 dni przed 
rozpoczęciem korzystania z urlopu. Do wniosku dołącza się dokumenty określone 
w przepisach wydanych na podstawie art. 1868a. Pracodawca jest obowiązany 
uwzględnić wniosek pracownika. Pracownik może wycofać wniosek o udzielenie 
urlopu wychowawczego nie później niż na 7 dni przed rozpoczęciem korzystania 
z urlopu, składając pracodawcy w postaci papierowej lub elektronicznej 
oświadczenie w tej sprawie. 
**§ 71.** Jeżeli wniosek, o którym mowa w § 7, został złożony bez zachowania 
terminu pracodawca udziela urlopu wychowawczego nie później niż z dniem 
upływu 21 dni od dnia złożenia wniosku. 
**§ 8.** Urlop wychowawczy jest udzielany nie więcej niż w 5 częściach. Liczbę 
części urlopu ustala się w oparciu o liczbę złożonych wniosków o udzielenie 
urlopu. 
**§ 9.** Rodzic dziecka ma prawo do urlopu wychowawczego w wymiarze do 
36 miesięcy, jeżeli: 
- 1) drugi rodzic dziecka nie żyje, 
- 2) drugiemu rodzicowi dziecka nie przysługuje władza rodzicielska, 
- 3) drugi rodzic dziecka został pozbawiony władzy rodzicielskiej albo taka 
władza uległa ograniczeniu lub zawieszeniu. 
Przepisy § 1, § 2 zdanie drugie, § 3, 7 i 8 stosuje się. 
**§ 10.** Jeżeli dziecko pozostaje pod opieką jednego opiekuna przysługuje mu 
urlop wychowawczy w wymiarze do 36 miesięcy. Przepisy § 1, § 2 zdanie drugie, 
§ 3, 7, 71 i 8 stosuje się.

***
## Art. 1861. {#kp-czwarty-art-1861}

(uchylony)

***
## Art. 1862. {#kp-czwarty-art-1862}

**§ 1.** W czasie urlopu wychowawczego pracownik ma prawo podjąć 
pracę zarobkową u dotychczasowego lub innego pracodawcy albo inną działalność, 
a także naukę lub szkolenie, jeżeli nie wyłącza to możliwości sprawowania 
osobistej opieki nad dzieckiem. 

 
 
 
s. 130/195 
 
2025-08-06 
**§ 2.** W razie ustalenia, że pracownik trwale zaprzestał sprawowania osobistej 
opieki nad dzieckiem, pracodawca wzywa pracownika do stawienia się do pracy 
w terminie przez siebie wskazanym, nie później jednak niż w ciągu 30 dni od dnia 
powzięcia takiej wiadomości i nie wcześniej niż po upływie 3 dni od dnia 
wezwania. 
**§ 3.** (uchylony)

***
## Art. 1863. {#kp-czwarty-art-1863}

Pracownik może zrezygnować z urlopu wychowawczego: 
- 1) w każdym czasie – za zgodą pracodawcy; 
- 2) po uprzednim zawiadomieniu pracodawcy – najpóźniej na 30 dni przed 
terminem zamierzonego podjęcia pracy.

***
## Art. 1864. {#kp-czwarty-art-1864}

Pracodawca dopuszcza pracownika po zakończeniu urlopu 
macierzyńskiego, urlopu na warunkach urlopu macierzyńskiego, uzupełniającego 
urlopu macierzyńskiego, urlopu rodzicielskiego, urlopu ojcowskiego oraz urlopu 
wychowawczego do pracy na dotychczasowym stanowisku, a jeżeli nie jest to 
możliwe – na stanowisku równorzędnym z zajmowanym przed rozpoczęciem 
urlopu na warunkach nie mniej korzystnych od tych, które obowiązywałyby, gdyby 
pracownik nie korzystał z urlopu.

***
## Art. 1865. {#kp-czwarty-art-1865}

Okres urlopu wychowawczego, w dniu jego zakończenia, wlicza 
się do okresu zatrudnienia, od którego zależą uprawnienia pracownicze.

***
## Art. 1866. {#kp-czwarty-art-1866}

(uchylony)

***
## Art. 1867. {#kp-czwarty-art-1867}

**§ 1.** Pracownik uprawniony do urlopu wychowawczego może 
złożyć pracodawcy wniosek w postaci papierowej lub elektronicznej o obniżenie 
jego wymiaru czasu pracy do wymiaru nie niższego niż połowa pełnego wymiaru 
czasu pracy w okresie, w którym mógłby korzystać z takiego urlopu. Pracodawca 
jest obowiązany uwzględnić wniosek pracownika. 
**§ 2.** Wniosek, o którym mowa w § 1, składa się na 21 dni przed rozpoczęciem 
wykonywania pracy w obniżonym wymiarze czasu pracy. Do wniosku dołącza się 
dokumenty określone w przepisach wydanych na podstawie art. 1868a. Jeżeli 
wniosek został złożony bez zachowania terminu, pracodawca obniża wymiar czasu 
pracy nie później niż z upływem 21 dni od dnia złożenia wniosku. 
**§ 3.** W przypadku 
skorzystania 
przez 
pracownika 
z części 
urlopu 
wychowawczego pracownik ten może korzystać z obniżonego wymiaru czasu 

 
 
 
s. 131/195 
 
2025-08-06 
 
pracy, o którym mowa w § 1, przez okres odpowiadający pozostałemu do 
wykorzystania wymiarowi urlopu wychowawczego, nie dłużej jednak niż do 
zakończenia roku kalendarzowego, w którym dziecko kończy 6 rok życia. 
**§ 4.** Korzystanie z obniżonego wymiaru czasu pracy, o którym mowa w § 1, 
nie obniża wymiaru urlopu wychowawczego.

***
## Art. 1868. {#kp-czwarty-art-1868}

**§ 1.** Pracodawca nie może wypowiedzieć ani rozwiązać umowy 
o pracę w okresie od dnia złożenia przez pracownika uprawnionego do urlopu 
wychowawczego wniosku o: 
- 1) udzielenie urlopu wychowawczego – do dnia zakończenia tego urlopu; 
- 2) obniżenie wymiaru czasu pracy – do dnia powrotu do nieobniżonego wymiaru 
czasu pracy, nie dłużej jednak niż przez łączny okres 12 miesięcy. 
**§ 2.** W przypadkach, o których mowa w § 1, rozwiązanie przez pracodawcę 
umowy jest dopuszczalne tylko w razie ogłoszenia upadłości lub likwidacji 
pracodawcy, a także gdy zachodzą przyczyny uzasadniające rozwiązanie umowy 
o pracę bez wypowiedzenia z winy pracownika. 
**§ 3.** W przypadku złożenia przez pracownika wniosku, o którym mowa w § 1, 
wcześniej niż 21 dni przed rozpoczęciem korzystania z urlopu wychowawczego 
albo obniżonego wymiaru czasu pracy, zakaz, o którym mowa w § 1, zaczyna 
obowiązywać na 21 dni przed rozpoczęciem korzystania z urlopu albo obniżonego 
wymiaru czasu pracy. 
**§ 4.** W przypadku złożenia przez pracownika wniosku, o którym mowa w § 1, 
po dokonaniu czynności zmierzającej do rozwiązania umowy o pracę, umowa 
rozwiązuje się w terminie wynikającym z tej czynności. 
Art. 1868a. Minister 
właściwy 
do 
spraw 
pracy 
określi, 
w drodze 
rozporządzenia: 
- 1) treść wniosku o udzielenie części urlopu macierzyńskiego, urlopu na 
warunkach urlopu macierzyńskiego lub jego części, uzupełniającego urlopu 
macierzyńskiego, urlopu rodzicielskiego lub jego części i urlopu ojcowskiego 
lub jego części, 
- 2) dokumenty dołączane do wniosków, o których mowa w pkt 1, 
- 3) treść wniosku w sprawie rezygnacji z części urlopu macierzyńskiego i części 
urlopu na warunkach urlopu macierzyńskiego, 

 
 
 
s. 132/195 
 
2025-08-06 
- 4) dokumenty dołączane do wniosków, o których mowa w pkt 3, 
- 5) treść wniosku o łączenie korzystania z urlopu rodzicielskiego lub jego części 
z wykonywaniem pracy u pracodawcy udzielającego takiego urlopu, 
- 6) treść wniosku o udzielenie urlopu wychowawczego lub jego części, 
- 7) dokumenty dołączane do wniosku, o którym mowa w pkt 6, 
- 8) treść wniosku o obniżenie wymiaru czasu pracy pracownika uprawnionego do 
urlopu wychowawczego, 
- 9) dokumenty dołączane do wniosku, o którym mowa w pkt 8 
– biorąc pod uwagę potrzebę zapewnienia prawidłowej realizacji uprawnień 
pracowników do urlopów związanych z rodzicielstwem i obniżenia wymiaru czasu 
pracy oraz zapewnienia właściwej organizacji czasu pracy.

***
## Art. 187. {#kp-czwarty-art-187}

**§ 1.** Pracownica karmiąca dziecko piersią ma prawo do dwóch 
półgodzinnych przerw w pracy wliczanych do czasu pracy. Pracownica karmiąca 
więcej niż jedno dziecko ma prawo do dwóch przerw w pracy, po 45 minut każda. 
Przerwy na karmienie mogą być na wniosek pracownicy udzielane łącznie. 
**§ 2.** Pracownicy zatrudnionej przez czas krótszy niż 4 godziny dziennie 
przerwy na karmienie nie przysługują. Jeżeli czas pracy pracownicy nie przekracza 
6 godzin dziennie, przysługuje jej jedna przerwa na karmienie.

***
## Art. 188. {#kp-czwarty-art-188}

**§ 1.** Pracownikowi wychowującemu przynajmniej jedno dziecko 
w wieku do 14 lat przysługuje w ciągu roku kalendarzowego zwolnienie od pracy 
w wymiarze 16 godzin albo 2 dni, z zachowaniem prawa do wynagrodzenia. 
**§ 2.** O sposobie wykorzystania w danym roku kalendarzowym zwolnienia, 
o którym mowa w § 1, decyduje pracownik w pierwszym wniosku składanym 
w postaci papierowej lub elektronicznej o udzielenie takiego zwolnienia w danym 
roku kalendarzowym. 
**§ 3.** Zwolnienie od pracy, o którym mowa w § 1, udzielane w wymiarze 
godzinowym, dla pracownika zatrudnionego w niepełnym wymiarze czasu pracy 
ustala się proporcjonalnie do wymiaru czasu pracy tego pracownika. Niepełną 
godzinę zwolnienia od pracy zaokrągla się w górę do pełnej godziny. 
**§ 4.** Przepisy § 1 i 3 w zakresie zwolnienia od pracy udzielanego w wymiarze 
godzinowym stosuje się odpowiednio do pracownika, dla którego dobowa norma 
czasu pracy, wynikająca z odrębnych przepisów, jest niższa niż 8 godzin. 

 
 
 
s. 133/195 
 
2025-08-06

***
## Art. 1881. {#kp-czwarty-art-1881}

**§ 1.** Pracownik wychowujący dziecko, do ukończenia przez nie 
8 roku życia, może złożyć wniosek w postaci papierowej lub elektronicznej 
o zastosowanie do niego elastycznej organizacji pracy. Wniosek składa się 
w terminie nie krótszym niż 21 dni przed planowanym rozpoczęciem korzystania 
z elastycznej organizacji pracy. 
**§ 2.** Za elastyczną organizację pracy, o której mowa w § 1, uważa się pracę 
zdalną, system czasu pracy, o którym mowa w art. 139, art. 143 i art. 144, rozkłady 
czasu pracy, o których mowa w art. 1401 lub art. 142, oraz obniżenie wymiaru 
czasu pracy. 
**§ 3.** We wniosku wskazuje się: 
- 1) imię i nazwisko oraz datę urodzenia dziecka; 
- 2) przyczynę konieczności skorzystania z elastycznej organizacji pracy; 
- 3) termin rozpoczęcia i zakończenia korzystania z elastycznej organizacji pracy; 
- 4) rodzaj elastycznej organizacji pracy, z której pracownik planuje korzystać. 
**§ 4.** Pracodawca rozpatruje wniosek, uwzględniając potrzeby pracownika, 
w tym termin oraz przyczynę konieczności korzystania z elastycznej organizacji 
pracy, a także potrzeby i możliwości pracodawcy, w tym konieczność zapewnienia 
normalnego toku pracy, organizację pracy lub rodzaj pracy wykonywanej przez 
pracownika. 
**§ 5.** Pracodawca 
informuje 
pracownika 
w postaci 
papierowej 
lub 
elektronicznej o uwzględnieniu wniosku albo o przyczynie odmowy uwzględnienia 
wniosku, albo o innym możliwym terminie zastosowania elastycznej organizacji 
pracy niż wskazany we wniosku, w terminie 7 dni od dnia otrzymania wniosku. 
**§ 6.** Pracownik korzystający z elastycznej organizacji pracy, o której mowa 
w § 1, może w każdym czasie złożyć wniosek w postaci papierowej lub 
elektronicznej o powrót do poprzedniej organizacji pracy przed upływem terminu, 
o którym mowa w § 3 pkt 3, gdy uzasadnia to zmiana okoliczności będąca 
podstawą do korzystania przez pracownika z elastycznej organizacji pracy. 
Pracodawca, po rozpatrzeniu wniosku, z uwzględnieniem okoliczności, o których 
mowa w § 4, informuje pracownika w postaci papierowej lub elektronicznej 
o uwzględnieniu albo przyczynie odmowy uwzględnienia wniosku, albo 
o możliwym terminie powrotu do pracy, w terminie 7 dni od dnia otrzymania 
wniosku. 

 
 
 
s. 134/195 
 
2025-08-06 
**§ 7.** Złożenie przez pracownika wniosku, o którym mowa w § 1, nie może 
stanowić przyczyny uzasadniającej wypowiedzenie umowy o pracę lub jej 
rozwiązanie bez wypowiedzenia przez pracodawcę i przyczyny uzasadniającej 
prowadzenie przygotowania do wypowiedzenia lub rozwiązania stosunku pracy 
bez wypowiedzenia. 
**§ 8.** Pracodawca udowodni, że przy rozwiązywaniu umowy o pracę kierował 
się powodem innym niż wskazany w § 7.

***
## Art. 189. {#kp-czwarty-art-189}

Prawo do zasiłku za czas nieobecności w pracy z powodu 
konieczności sprawowania osobistej opieki nad dzieckiem regulują odrębne 
przepisy.

***
## Art. 1891. {#kp-czwarty-art-1891}

Jeżeli oboje rodzice lub opiekunowie dziecka są zatrudnieni, 
z uprawnień określonych w art. 148 pkt 3, art. 178 § 2, art. 1867 § 1 i art. 188 może 
korzystać jedno z nich. 
DZIAŁ DZIEWIĄTY 
Zatrudnianie młodocianych 
## Rozdział I Przepisy ogólne

***
## Art. 190. {#kp-czwarty-art-190}

**§ 1.** Młodocianym w rozumieniu kodeksu jest osoba, która 
ukończyła 15 lat, a nie przekroczyła 18 lat. 
**§ 2.** Zabronione jest zatrudnianie osoby, która nie ukończyła 15 lat, z 
zastrzeżeniem art. 191 § 21–23.

***
## Art. 191. {#kp-czwarty-art-191}

**§ 1.** Wolno zatrudniać tylko tych młodocianych, którzy: 
- 1) ukończyli co najmniej ośmioletnią szkołę podstawową; 
- 2) przedstawią świadectwo lekarskie stwierdzające, że praca danego rodzaju nie 
zagraża ich zdrowiu. 
**§ 2.** Młodociany nieposiadający kwalifikacji zawodowych może być 
zatrudniony tylko w celu przygotowania zawodowego. 
**§ 21.** Osoba, która ukończyła ośmioletnią szkołą podstawową, niemająca 15 
lat, może być zatrudniona na zasadach określonych dla młodocianych w roku 
kalendarzowym, w którym kończy 15 lat.  

 
 
 
s. 135/195 
 
2025-08-06 
**§ 22.** Osoba, która ukończyła ośmioletnią szkołę podstawową, niemająca 15 
lat, z wyjątkiem osoby, o której mowa w § 21, może być zatrudniona na zasadach 
określonych dla młodocianych w celu przygotowania zawodowego w formie nauki 
zawodu. 
**§ 23.** Osoba, która nie ukończyła ośmioletniej szkoły podstawowej, niemająca 
15 lat, może być zatrudniona na zasadach określonych dla młodocianych w celu 
przygotowania zawodowego w formie przyuczenia do wykonywania określonej 
pracy. 
**§ 24.** Zawarcie umowy o pracę w celu przygotowania zawodowego z osobą, o 
której mowa w § 22 i § 23, jest dopuszczalne w przypadku wyrażenia na to zgody 
przez przedstawiciela ustawowego lub opiekuna prawnego tej osoby oraz uzyskania 
pozytywnej opinii poradni psychologiczno-pedagogicznej. 
**§ 25.** W przypadku osoby, o której mowa w § 23, wymagane jest również 
uzyskanie zezwolenia dyrektora ośmioletniej szkoły podstawowej, w której 
obwodzie mieszka ta osoba, na spełnianie obowiązku szkolnego poza szkołą. 
**§ 26.** Z osobą, która ukończyła 15 lat i nie ukończyła ośmioletniej szkoły 
podstawowej, może być, na wniosek jej przedstawiciela ustawowego lub opiekuna, 
zawarta umowa o pracę w celu przygotowania zawodowego odbywanego w formie 
przyuczenia do wykonywania określonej pracy, jeżeli: 
- 1) została ona przyjęta do oddziału przysposabiającego do pracy utworzonego w 
ośmioletniej szkole podstawowej albo 
- 2) uzyskała zezwolenie dyrektora ośmioletniej szkoły podstawowej, w której 
obwodzie mieszka, na spełnianie obowiązku szkolnego poza szkołą oraz 
uzyskała pozytywną opinię poradni psychologiczno-pedagogicznej. 
**§ 27.** Z osobą, która ukończyła 15 lat i nie ukończyła ośmioletniej szkoły 
podstawowej, spełniającą obowiązek szkolny poza szkołą, może być, po 
ukończeniu przez nią przygotowania zawodowego w formie przyuczenia do 
wykonywania określonej pracy, zawarta umowa o pracę w celu przygotowania 
zawodowego w formie nauki zawodu. Przepis § 26 pkt 2 stosuje się odpowiednio. 
**§ 3.** Rada Ministrów określi w drodze rozporządzenia zasady i warunki 
odbywania przygotowania zawodowego oraz zasady wynagradzania młodocianych 
w tym okresie. 
**§ 4.** (uchylony) 

 
 
 
s. 136/195 
 
2025-08-06 
**§ 5.** (uchylony)

***
## Art. 1911. {#kp-czwarty-art-1911}

Osoba, która ukończyła 18 lat w trakcie nauki w ośmioletniej szkole 
podstawowej, może być zatrudniona na zasadach określonych dla młodocianych w 
roku kalendarzowym, w którym ukończyła tę szkołę.

***
## Art. 192. {#kp-czwarty-art-192}

Pracodawca jest obowiązany zapewnić młodocianym pracownikom 
opiekę i pomoc, niezbędną dla ich przystosowania się do właściwego wykonywania 
pracy.

***
## Art. 193. {#kp-czwarty-art-193}

Pracodawca jest obowiązany prowadzić ewidencję pracowników 
młodocianych. 
## Rozdział II Zawieranie i rozwiązywanie umów o pracę w celu przygotowania 
zawodowego

***
## Art. 194. {#kp-czwarty-art-194}

Do zawierania i rozwiązywania z młodocianymi umów o pracę 
w celu przygotowania zawodowego mają zastosowanie przepisy kodeksu 
dotyczące umów o pracę na czas nieokreślony ze zmianami przewidzianymi 
w art. 195 i 196.

***
## Art. 195. {#kp-czwarty-art-195}

**§ 1.** Umowa o pracę w celu przygotowania zawodowego powinna 
określać w szczególności: 
- 1) rodzaj przygotowania zawodowego (nauka zawodu lub przyuczenie do 
wykonywania określonej pracy); 
- 2) czas trwania i miejsce odbywania przygotowania zawodowego; 
- 3) sposób dokształcania teoretycznego; 
- 4) wysokość wynagrodzenia. 
**§ 2.** Rada Ministrów może w drodze rozporządzenia określić przypadki, 
w których jest dopuszczalne zawieranie na czas określony umów o pracę w celu 
przygotowania zawodowego.

***
## Art. 196. {#kp-czwarty-art-196}

Rozwiązanie za wypowiedzeniem umowy o pracę zawartej w celu 
przygotowania zawodowego dopuszczalne jest tylko w razie: 
- 1) niewypełniania przez młodocianego obowiązków wynikających z umowy 
o pracę lub obowiązku dokształcania się, pomimo stosowania wobec niego 
środków wychowawczych; 

 
 
 
s. 137/195 
 
2025-08-06 
- 2) ogłoszenia upadłości lub likwidacji pracodawcy; 
- 3) reorganizacji zakładu pracy uniemożliwiającej kontynuowanie przygotowania 
zawodowego; 
- 4) stwierdzenia nieprzydatności młodocianego do pracy, w zakresie której 
odbywa przygotowanie zawodowe. 
## Rozdział III Dokształcanie

***
## Art. 197. {#kp-czwarty-art-197}

**§ 1.** Pracownik młodociany jest obowiązany dokształcać się do 
ukończenia 18 lat. 
**§ 2.** W szczególności pracownik młodociany jest obowiązany: 
- 1) do dokształcania się w zakresie ośmioletniej szkoły podstawowej, jeżeli 
szkoły takiej nie ukończył; 
- 2) do dokształcania się w zakresie szkoły ponadpodstawowej lub w formach 
pozaszkolnych.

***
## Art. 198. {#kp-czwarty-art-198}

Pracodawca jest obowiązany zwolnić młodocianego od pracy na 
czas potrzebny do wzięcia udziału w zajęciach szkoleniowych w związku 
z dokształcaniem się.

***
## Art. 199. {#kp-czwarty-art-199}

Jeżeli młodociany nie ukończył przygotowania zawodowego przed 
osiągnięciem 18 lat, obowiązek dokształcania się, stosownie do przepisów art. 197, 
może być przedłużony do czasu ukończenia przygotowania zawodowego.

***
## Art. 200. {#kp-czwarty-art-200}

Minister Pracy i Polityki Socjalnej8) w porozumieniu z Ministrem 
Edukacji Narodowej9) może w drodze rozporządzenia określić przypadki, 
w których wyjątkowo jest dopuszczalne zwolnienie młodocianych od obowiązku 
dokształcania się. 
## Rozdział III a 
Zatrudnianie młodocianych w innym celu niż przygotowanie zawodowe

***
## Art. 2001. {#kp-czwarty-art-2001}

**§ 1.** Młodociany może być zatrudniony na podstawie umowy 
o pracę przy wykonywaniu lekkich prac. 
- 9) Obecnie ministrem właściwym do spraw oświaty i wychowania, na podstawie art. 4 ust. 1, art. 
5 pkt 15 oraz art. 20 ustawy, o której mowa w odnośniku 8. 

 
 
 
s. 138/195 
 
2025-08-06 
**§ 2.** Praca lekka nie może powodować zagrożenia dla życia, zdrowia 
i rozwoju psychofizycznego młodocianego, a także nie może utrudniać 
młodocianemu wypełniania obowiązku szkolnego. 
**§ 3.** Wykaz lekkich prac określa pracodawca po uzyskaniu zgody lekarza 
wykonującego zadania służby medycyny pracy. Wykaz ten wymaga zatwierdzenia 
przez właściwego inspektora pracy. Wykaz lekkich prac nie może zawierać prac 
wzbronionych młodocianym, określonych w przepisach wydanych na podstawie 
art. 204. 
**§ 4.** Wykaz 
lekkich 
prac 
ustala 
pracodawca 
w regulaminie 
pracy. 
Pracodawca, który nie ma obowiązku wydania regulaminu, ustala wykaz lekkich 
prac w osobnym akcie. 
**§ 5.** Pracodawca jest obowiązany zapoznać młodocianego z wykazem lekkich 
prac przed dopuszczeniem go do pracy.

***
## Art. 2002. {#kp-czwarty-art-2002}

**§ 1.** Pracodawca 
ustala 
wymiar 
i rozkład 
czasu 
pracy 
młodocianego zatrudnionego przy lekkiej pracy, uwzględniając tygodniową liczbę 
godzin nauki wynikającą z programu nauczania, a także z rozkładu zajęć szkolnych 
młodocianego. 
**§ 2.** Tygodniowy wymiar czasu pracy młodocianego w okresie odbywania 
zajęć szkolnych nie może przekraczać 12 godzin. W dniu uczestniczenia 
w zajęciach szkolnych wymiar czasu pracy młodocianego nie może przekraczać 
2 godzin. 
**§ 3.** Wymiar czasu pracy młodocianego w okresie ferii szkolnych nie może 
przekraczać 7 godzin na dobę i 35 godzin w tygodniu. Dobowy wymiar czasu pracy 
młodocianego w wieku do 16 lat nie może jednak przekraczać 6 godzin. 
**§ 4.** Wymiar czasu pracy określony w § 2 i 3 obowiązuje także w przypadku, 
gdy młodociany jest zatrudniony u więcej niż jednego pracodawcy. Przed 
nawiązaniem stosunku pracy pracodawca ma obowiązek uzyskania od 
młodocianego oświadczenia o zatrudnieniu albo o niepozostawaniu w zatrudnieniu 
u innego pracodawcy. 

 
 
 
s. 139/195 
 
2025-08-06 
## Rozdział IV Szczególna ochrona zdrowia

***
## Art. 201. {#kp-czwarty-art-201}

**§ 1.** Młodociany podlega wstępnym badaniom lekarskim przed 
przyjęciem do pracy oraz badaniom okresowym i kontrolnym w czasie 
zatrudnienia. 
**§ 2.** Jeżeli lekarz orzeknie, że dana praca zagraża zdrowiu młodocianego, 
pracodawca jest obowiązany zmienić rodzaj pracy, a gdy nie ma takiej możliwości, 
niezwłocznie rozwiązać umowę o pracę i wypłacić odszkodowanie w wysokości 
wynagrodzenia za okres wypowiedzenia. Przepis art. 51 § 2 stosuje się 
odpowiednio. 
**§ 3.** Pracodawca 
jest 
obowiązany 
przekazać 
informacje 
o ryzyku 
zawodowym, które wiąże się z pracą wykonywaną przez młodocianego, oraz 
o zasadach ochrony przed zagrożeniami również przedstawicielowi ustawowemu 
młodocianego.

***
## Art. 202. {#kp-czwarty-art-202}

**§ 1.** Czas pracy młodocianego w wieku do 16 lat nie może 
przekraczać 6 godzin na dobę. 
**§ 2.** Czas pracy młodocianego w wieku powyżej 16 lat nie może przekraczać 
8 godzin na dobę. 
**§ 3.** Do czasu pracy młodocianego wlicza się czas nauki w wymiarze 
wynikającym z obowiązkowego programu zajęć szkolnych, bez względu na to, czy 
odbywa się ona w godzinach pracy. 
**§ 31.** Jeżeli dobowy wymiar czasu pracy młodocianego jest dłuższy niż 
4,5 godziny, pracodawca jest obowiązany wprowadzić przerwę w pracy trwającą 
nieprzerwanie 30 minut, wliczaną do czasu pracy. 
**§ 4.** (uchylony)

***
## Art. 203. {#kp-czwarty-art-203}

**§ 1.** Młodocianego 
nie 
wolno 
zatrudniać 
w godzinach 
nadliczbowych ani w porze nocnej. 
**§ 11.** Pora nocna dla młodocianego przypada pomiędzy godzinami 2200 a 600. 
W przypadkach określonych w art. 191 § 21–23 i § 26 pora nocna przypada 
pomiędzy godzinami 2000 a 600. 
**§ 2.** Przerwa w pracy młodocianego obejmująca porę nocną powinna trwać 
nieprzerwanie nie mniej niż 14 godzin. 

 
 
 
s. 140/195 
 
2025-08-06 
**§ 3.** Młodocianemu przysługuje w każdym tygodniu prawo do co najmniej 
48 godzin nieprzerwanego odpoczynku, który powinien obejmować niedzielę.

***
## Art. 204. {#kp-czwarty-art-204}

**§ 1.** Nie 
wolno 
zatrudniać 
młodocianych 
przy 
pracach 
wzbronionych, których wykaz ustala w drodze rozporządzenia Rada Ministrów. 
**§ 2.** (uchylony) 
**§ 3.** Rada Ministrów, w drodze rozporządzenia, może zezwolić na 
zatrudnianie młodocianych w wieku powyżej 16 lat przy niektórych rodzajach prac 
wzbronionych, jeżeli jest to potrzebne do odbycia przygotowania zawodowego, 
określając jednocześnie warunki zapewniające szczególną ochronę zdrowia 
młodocianych zatrudnionych przy tych pracach. 
## Rozdział V Urlopy wypoczynkowe

***
## Art. 205. {#kp-czwarty-art-205}

**§ 1.** Młodociany uzyskuje z upływem 6 miesięcy od rozpoczęcia 
pierwszej pracy prawo do urlopu w wymiarze 12 dni roboczych. 
**§ 2.** Z upływem roku pracy młodociany uzyskuje prawo do urlopu 
w wymiarze 26 dni roboczych. Jednakże w roku kalendarzowym, w którym kończy 
on 18 lat, ma prawo do urlopu w wymiarze 20 dni roboczych, jeżeli prawo do 
urlopu uzyskał przed ukończeniem 18 lat. 
**§ 3.** Młodocianemu uczęszczającemu do szkoły należy udzielić urlopu 
w okresie ferii szkolnych. Młodocianemu, który nie nabył prawa do urlopu, 
o którym mowa w § 1 i 2, pracodawca może, na jego wniosek, udzielić zaliczkowo 
urlopu w okresie ferii szkolnych. 
**§ 4.** Pracodawca jest obowiązany na wniosek młodocianego, ucznia szkoły dla 
pracujących, udzielić mu w okresie  
ferii szkolnych urlopu bezpłatnego w wymiarze nieprzekraczającym łącznie 
z urlopem wypoczynkowym 2 miesięcy. Okres urlopu bezpłatnego wlicza się do 
okresu pracy, od którego zależą uprawnienia pracownicze. 
**§ 5.** W sprawach nieuregulowanych przepisami niniejszego rozdziału do 
urlopów przysługujących młodocianym stosuje się przepisy działu siódmego. 

 
 
 
s. 141/195 
 
2025-08-06 
## Rozdział VI Rzemieślnicze przygotowanie zawodowe

***
## Art. 206. {#kp-czwarty-art-206}

Przepisy art. 190–205 stosuje się odpowiednio do młodocianych 
zatrudnionych na podstawie umowy o przygotowanie zawodowe u pracodawców 
będących rzemieślnikami. 
DZIAŁ DZIESIĄTY 
Bezpieczeństwo i higiena pracy 
## Rozdział I Podstawowe obowiązki pracodawcy

***
## Art. 207. {#kp-czwarty-art-207}

**§ 1.** Pracodawca ponosi odpowiedzialność za stan bezpieczeństwa 
i higieny pracy w zakładzie pracy. Na zakres odpowiedzialności pracodawcy nie 
wpływają obowiązki pracowników w dziedzinie bezpieczeństwa i higieny pracy 
oraz powierzenie wykonywania zadań służby bezpieczeństwa i higieny pracy 
specjalistom spoza zakładu pracy, o których mowa w art. 23711 § 2. 
**§ 2.** Pracodawca jest obowiązany chronić zdrowie i życie pracowników przez 
zapewnienie bezpiecznych i higienicznych warunków pracy przy odpowiednim 
wykorzystaniu osiągnięć nauki i techniki. W szczególności pracodawca jest 
obowiązany: 
- 1) organizować pracę w sposób zapewniający bezpieczne i higieniczne warunki 
pracy; 
- 2) zapewniać przestrzeganie w zakładzie pracy przepisów oraz zasad 
bezpieczeństwa i higieny pracy, wydawać polecenia usunięcia uchybień 
w tym zakresie oraz kontrolować wykonanie tych poleceń; 
- 3) reagować na potrzeby w zakresie zapewnienia bezpieczeństwa i higieny pracy 
oraz dostosowywać środki podejmowane w celu doskonalenia istniejącego 
poziomu ochrony zdrowia i życia pracowników, biorąc pod uwagę 
zmieniające się warunki wykonywania pracy; 
- 4) zapewnić rozwój spójnej polityki zapobiegającej wypadkom przy pracy 
i chorobom 
zawodowym 
uwzględniającej 
zagadnienia 
techniczne, 
organizację pracy, warunki pracy, stosunki społeczne oraz wpływ czynników 
środowiska pracy; 

 
 
 
s. 142/195 
 
2025-08-06 
- 5) uwzględniać ochronę zdrowia młodocianych, pracownic w ciąży lub 
karmiących dziecko piersią oraz pracowników niepełnosprawnych w ramach 
podejmowanych działań profilaktycznych; 
- 6) zapewniać wykonanie nakazów, wystąpień, decyzji i zarządzeń wydawanych 
przez organy nadzoru nad warunkami pracy; 
- 7) zapewniać wykonanie zaleceń społecznego inspektora pracy. 
**§ 21.** Koszty 
działań 
podejmowanych 
przez 
pracodawcę 
w zakresie 
bezpieczeństwa i higieny pracy w żaden sposób nie mogą obciążać pracowników. 
**§ 3.** Pracodawca oraz osoba kierująca pracownikami są obowiązani znać, 
w zakresie niezbędnym do wykonywania ciążących na nich obowiązków, przepisy 
o ochronie pracy, w tym przepisy oraz zasady bezpieczeństwa i higieny pracy.

***
## Art. 2071. {#kp-czwarty-art-2071}

**§ 1.** Pracodawca jest obowiązany przekazywać pracownikom 
informacje o: 
- 1) zagrożeniach dla zdrowia i życia występujących w zakładzie pracy, na po-
szczególnych stanowiskach pracy i przy wykonywanych pracach, w tym 
o zasadach postępowania w przypadku awarii i innych sytuacji zagrażających 
zdrowiu i życiu pracowników; 
- 2) działaniach 
ochronnych 
i zapobiegawczych 
podjętych 
w celu 
wyeliminowania lub ograniczenia zagrożeń, o których mowa w pkt 1; 
- 3) pracownikach wyznaczonych do: 
  - a) udzielania pierwszej pomocy, 
  - b) wykonywania działań w zakresie zwalczania pożarów i ewakuacji 
pracowników. 
**§ 2.** Informacja o pracownikach, o których mowa w § 1 pkt 3, obejmuje: 
- 1) imię i nazwisko; 
- 2) miejsce wykonywania pracy; 
- 3) numer telefonu służbowego lub innego środka komunikacji elektronicznej.

***
## Art. 208. {#kp-czwarty-art-208}

**§ 1.** W razie gdy jednocześnie w tym samym miejscu wykonują 
pracę pracownicy zatrudnieni przez różnych pracodawców, pracodawcy ci mają 
obowiązek: 
- 1) współpracować ze sobą; 

 
 
 
s. 143/195 
 
2025-08-06 
- 2) wyznaczyć koordynatora sprawującego nadzór nad bezpieczeństwem 
i higieną pracy wszystkich pracowników zatrudnionych w tym samym 
miejscu; 
- 3) ustalić zasady współdziałania uwzględniające sposoby postępowania 
w przypadku wystąpienia zagrożeń dla zdrowia lub życia pracowników; 
- 4) informować siebie nawzajem oraz pracowników lub ich przedstawicieli 
o działaniach 
w zakresie 
zapobiegania 
zagrożeniom 
zawodowym 
występującym podczas wykonywanych przez nich prac. 
**§ 2.** Wyznaczenie koordynatora, o którym mowa w § 1, nie zwalnia 
poszczególnych pracodawców z obowiązku zapewnienia bezpieczeństwa i higieny 
pracy zatrudnionym przez nich pracownikom. 
**§ 3.** Pracodawca, na którego terenie wykonują prace pracownicy zatrudnieni 
przez różnych pracodawców, jest obowiązany dostarczać tym pracodawcom, 
w celu przekazania pracownikom, informacje, o których mowa w art. 2071.

***
## Art. 209. {#kp-czwarty-art-209}

(uchylony)

***
## Art. 2091. {#kp-czwarty-art-2091}

**§ 1.** Pracodawca jest obowiązany: 
- 1) zapewnić środki niezbędne do udzielania pierwszej pomocy w nagłych 
wypadkach, zwalczania pożarów i ewakuacji pracowników; 
- 2) wyznaczyć pracowników do: 
  - a) udzielania pierwszej pomocy, 
  - b) wykonywania działań w zakresie zwalczania pożarów i ewakuacji 
pracowników; 
- 3) zapewnić łączność ze służbami zewnętrznymi wyspecjalizowanymi 
w szczególności w zakresie udzielania pierwszej pomocy w nagłych 
wypadkach, ratownictwa medycznego oraz ochrony przeciwpożarowej. 
**§ 2.** Działania, o których mowa w § 1, powinny być dostosowane do rodzaju 
i zakresu prowadzonej działalności, liczby zatrudnionych pracowników i innych 
osób przebywających na terenie zakładu pracy oraz rodzaju i poziomu 
występujących zagrożeń. 
**§ 3.** Liczba pracowników, o których mowa w § 1 pkt 2, ich szkolenie oraz 
wyposażenie powinny uwzględniać rodzaj i poziom występujących zagrożeń. 

 
 
 
s. 144/195 
 
2025-08-06 
**§ 4.** W przypadku zatrudniania przez pracodawcę wyłącznie pracowników 
młodocianych lub niepełnosprawnych – działania, o których mowa w § 1 pkt 2, 
może wykonywać sam pracodawca. Przepis § 3 stosuje się odpowiednio.

***
## Art. 2092. {#kp-czwarty-art-2092}

**§ 1.** W przypadku możliwości wystąpienia zagrożenia dla zdrowia 
lub życia pracodawca jest obowiązany: 
- 1) niezwłocznie poinformować pracowników o tych zagrożeniach oraz podjąć 
działania w celu zapewnienia im odpowiedniej ochrony; 
- 2) niezwłocznie 
dostarczyć 
pracownikom 
instrukcje 
umożliwiające, 
w przypadku wystąpienia bezpośredniego zagrożenia, przerwanie pracy 
i oddalenie się z miejsca zagrożenia w miejsce bezpieczne. 
**§ 2.** W razie wystąpienia bezpośredniego zagrożenia dla zdrowia lub życia 
pracodawca jest obowiązany: 
- 1) wstrzymać pracę i wydać pracownikom polecenie oddalenia się w miejsce 
bezpieczne; 
- 2) do czasu usunięcia zagrożenia nie wydawać polecenia wznowienia pracy.

***
## Art. 2093. {#kp-czwarty-art-2093}

**§ 1.** Pracodawca jest obowiązany umożliwić pracownikom, 
w przypadku wystąpienia bezpośredniego zagrożenia dla ich zdrowia lub życia albo 
dla zdrowia lub życia innych osób, podjęcie działań w celu uniknięcia 
niebezpieczeństwa – nawet bez porozumienia z przełożonym – na miarę ich wiedzy 
i dostępnych środków technicznych. 
**§ 2.** Pracownicy, którzy podjęli działania, o których mowa w § 1, nie mogą 
ponosić jakichkolwiek niekorzystnych konsekwencji tych działań, pod warunkiem 
że nie zaniedbali swoich obowiązków. 
## Rozdział II Prawa i obowiązki pracownika

***
## Art. 210. {#kp-czwarty-art-210}

**§ 1.** W razie gdy warunki pracy nie odpowiadają przepisom 
bezpieczeństwa i higieny pracy i stwarzają bezpośrednie zagrożenie dla zdrowia 
lub życia pracownika albo gdy wykonywana przez niego praca grozi takim 
niebezpieczeństwem innym osobom, pracownik ma prawo powstrzymać się od 
wykonywania pracy, zawiadamiając o tym niezwłocznie przełożonego. 

 
 
 
s. 145/195 
 
2025-08-06 
**§ 2.** Jeżeli powstrzymanie się od wykonywania pracy nie usuwa zagrożenia, 
o którym mowa w § 1, pracownik ma prawo oddalić się z miejsca zagrożenia, 
zawiadamiając o tym niezwłocznie przełożonego. 
**§ 21.** Pracownik nie może ponosić jakichkolwiek niekorzystnych dla niego 
konsekwencji z powodu powstrzymania się od pracy lub oddalenia się z miejsca 
zagrożenia w przypadkach, o których mowa w § 1 i 2. 
**§ 3.** Za czas powstrzymania się od wykonywania pracy lub oddalenia się 
z miejsca zagrożenia w przypadkach, o których mowa w § 1 i 2, pracownik 
zachowuje prawo do wynagrodzenia. 
**§ 4.** Pracownik ma prawo, po uprzednim zawiadomieniu przełożonego, 
powstrzymać się od wykonywania pracy wymagającej szczególnej sprawności 
psychofizycznej w przypadku, gdy jego stan psychofizyczny nie zapewnia 
bezpiecznego wykonywania pracy i stwarza zagrożenie dla innych osób. 
**§ 5.** Przepisy § 1, 2 i 4 nie dotyczą pracownika, którego obowiązkiem 
pracowniczym jest ratowanie życia ludzkiego lub mienia. 
**§ 6.** Minister Pracy i Polityki Socjalnej8) w porozumieniu z Ministrem 
Zdrowia i Opieki Społecznej10) określi, w drodze rozporządzenia, rodzaje prac 
wymagających szczególnej sprawności psychofizycznej.

***
## Art. 211. {#kp-czwarty-art-211}

Przestrzeganie przepisów i zasad bezpieczeństwa i higieny pracy 
jest podstawowym obowiązkiem pracownika. W szczególności pracownik jest 
obowiązany: 
- 1) znać przepisy i zasady bezpieczeństwa i higieny pracy, brać udział 
w szkoleniu i instruktażu z tego zakresu oraz poddawać się wymaganym 
egzaminom sprawdzającym; 
- 2) wykonywać pracę w sposób zgodny z przepisami i zasadami bezpieczeństwa 
i higieny pracy oraz stosować się do wydawanych w tym zakresie poleceń 
i wskazówek przełożonych; 
- 3) dbać o należyty stan maszyn, urządzeń, narzędzi i sprzętu oraz o porządek 
i ład w miejscu pracy; 
- 10) Obecnie ministrem właściwym do spraw zdrowia, na podstawie art. 4 ust. 1, art. 5 pkt 28 oraz art. 33 
ustawy, o której mowa w odnośniku 8. 

 
 
 
s. 146/195 
 
2025-08-06 
- 4) stosować środki ochrony zbiorowej, a także używać przydzielonych środków 
ochrony indywidualnej oraz odzieży i obuwia roboczego, zgodnie z ich 
przeznaczeniem; 
- 5) poddawać się wstępnym, okresowym i kontrolnym oraz innym zaleconym 
badaniom lekarskim i stosować się do wskazań lekarskich; 
- 6) niezwłocznie zawiadomić przełożonego o zauważonym w zakładzie pracy 
wypadku albo zagrożeniu życia lub zdrowia ludzkiego oraz ostrzec 
współpracowników, a także inne osoby znajdujące się w rejonie zagrożenia, 
o grożącym im niebezpieczeństwie; 
- 7) współdziałać z pracodawcą i przełożonymi w wypełnianiu obowiązków 
dotyczących bezpieczeństwa i higieny pracy.

***
## Art. 212. {#kp-czwarty-art-212}

Osoba kierująca pracownikami jest obowiązana: 
- 1) organizować 
stanowiska 
pracy 
zgodnie 
z przepisami 
i zasadami 
bezpieczeństwa i higieny pracy; 
- 2) dbać o sprawność środków ochrony indywidualnej oraz ich stosowanie 
zgodnie z przeznaczeniem; 
- 3) organizować, 
przygotowywać 
i prowadzić 
prace, 
uwzględniając 
zabezpieczenie pracowników przed wypadkami przy pracy, chorobami 
zawodowymi i innymi chorobami związanymi z warunkami środowiska 
pracy; 
- 4) dbać o bezpieczny i higieniczny stan pomieszczeń pracy i wyposażenia 
technicznego, a także o sprawność środków ochrony zbiorowej i ich 
stosowanie zgodnie z przeznaczeniem; 
- 5) egzekwować 
przestrzeganie 
przez 
pracowników 
przepisów 
i zasad 
bezpieczeństwa i higieny pracy; 
- 6) zapewniać wykonanie zaleceń lekarza sprawującego opiekę zdrowotną nad 
pracownikami. 
## Rozdział III Obiekty budowlane i pomieszczenia pracy

***
## Art. 213. {#kp-czwarty-art-213}

**§ 1.** Pracodawca jest obowiązany zapewniać, aby budowa lub 
przebudowa obiektu budowlanego, w którym przewiduje się pomieszczenia pracy, 

 
 
 
s. 147/195 
 
2025-08-06 
 
była wykonywana na podstawie projektów uwzględniających wymagania 
bezpieczeństwa i higieny pracy. 
**§ 2.** Obiekt budowlany, w którym znajdują się pomieszczenia pracy, powinien 
spełniać wymagania dotyczące bezpieczeństwa i higieny pracy. 
**§ 3.** Przebudowa obiektu budowlanego, w którym znajdują się pomieszczenia 
pracy, powinna uwzględniać poprawę warunków bezpieczeństwa i higieny pracy. 
**§ 4.** Przepisy § 1–3 stosuje się odpowiednio w przypadku, gdy budowa lub 
przebudowa dotyczy części obiektu budowlanego, w której znajdują się 
pomieszczenia pracy.

***
## Art. 214. {#kp-czwarty-art-214}

**§ 1.** Pracodawca jest obowiązany zapewniać pomieszczenia pracy 
odpowiednie do rodzaju wykonywanych prac i liczby zatrudnionych pracowników. 
**§ 2.** Pracodawca 
jest 
obowiązany 
utrzymywać 
obiekty 
budowlane 
i znajdujące się w nich pomieszczenia pracy, a także tereny i urządzenia z nimi 
związane w stanie zapewniającym bezpieczne i higieniczne warunki pracy. 
## Rozdział IV Maszyny i inne urządzenia techniczne

***
## Art. 215. {#kp-czwarty-art-215}

Pracodawca jest obowiązany zapewnić, aby stosowane maszyny 
i inne urządzenia techniczne: 
- 1) zapewniały bezpieczne i higieniczne warunki pracy, w szczególności 
zabezpieczały pracownika przed urazami, działaniem niebezpiecznych 
substancji chemicznych, porażeniem prądem elektrycznym, nadmiernym 
hałasem, 
działaniem 
drgań 
mechanicznych 
i promieniowania 
oraz 
szkodliwym i niebezpiecznym działaniem innych czynników środowiska 
pracy; 
- 2) uwzględniały zasady ergonomii.

***
## Art. 216. {#kp-czwarty-art-216}

**§ 1.** Pracodawca 
wyposaża 
w odpowiednie 
zabezpieczenia 
maszyny i inne urządzenia techniczne, które nie spełniają wymagań określonych 
w art. 215. 
**§ 2.** W przypadku gdy konstrukcja zabezpieczenia jest uzależniona od 
warunków lokalnych, wyposażenie maszyny lub innego urządzenia technicznego 
w odpowiednie zabezpieczenia należy do obowiązków pracodawcy. 

 
 
 
s. 148/195 
 
2025-08-06

***
## Art. 217. {#kp-czwarty-art-217}

Niedopuszczalne jest wyposażanie stanowisk pracy w maszyny 
i inne urządzenia techniczne, które nie spełniają wymagań dotyczących oceny 
zgodności określonych w odrębnych przepisach.

***
## Art. 218. {#kp-czwarty-art-218}

Przepisy art. 215 i 217 stosuje się odpowiednio do narzędzi pracy.

***
## Art. 219. {#kp-czwarty-art-219}

Przepisy art. 215 i 217 nie naruszają wymagań określonych 
przepisami dotyczącymi maszyn i innych urządzeń technicznych: 
- 1) będących środkami transportu kolejowego, samochodowego, morskiego, 
wodnego śródlądowego i lotniczego; 
- 2) podlegających przepisom o dozorze technicznym; 
- 3) podlegających przepisom Prawa geologicznego i górniczego; 
- 4) podlegających 
przepisom 
obowiązującym 
w jednostkach 
podległych 
Ministrowi Obrony Narodowej oraz ministrowi właściwemu do spraw 
wewnętrznych; 
- 5) podlegających przepisom Prawa atomowego. 
## Rozdział V Czynniki oraz procesy pracy stwarzające szczególne zagrożenie dla zdrowia 
lub życia

***
## Art. 220. {#kp-czwarty-art-220}

**§ 1.** Niedopuszczalne jest stosowanie materiałów i procesów 
technologicznych bez uprzedniego ustalenia stopnia ich szkodliwości dla zdrowia 
pracowników i podjęcia odpowiednich środków profilaktycznych. 
**§ 2.** Minister Zdrowia i Opieki Społecznej11) w porozumieniu z Ministrem 
Pracy i Polityki Socjalnej12) oraz właściwymi ministrami określi, w drodze 
rozporządzenia: 
- 1) wykaz jednostek upoważnionych do przeprowadzania badań materiałów 
i procesów technologicznych w celu ustalenia stopnia ich szkodliwości dla 
zdrowia oraz zakres tych badań; 
- 2) zakaz albo ograniczenie stosowania, obrotu lub transportu materiałów 
i procesów technologicznych ze względu na ich szkodliwość dla zdrowia albo 
- 11) Obecnie minister właściwy do spraw zdrowia, na podstawie art. 4 ust. 1, art. 5 pkt 28 oraz art. 33 
ustawy, o której mowa w odnośniku 8. 
- 12) Obecnie ministrem właściwym do spraw pracy, na podstawie art. 4 ust. 1, art. 5 pkt 16 oraz art. 21 
ustawy, o której mowa w odnośniku 8. 

 
 
 
s. 149/195 
 
2025-08-06 
 
uzależnienie ich stosowania, obrotu lub transportu od przestrzegania 
określonych warunków. 
**§ 3.** Przepisy § 2 nie dotyczą substancji chemicznych i ich mieszanin.

***
## Art. 221. {#kp-czwarty-art-221}

**§ 1.** Niedopuszczalne jest stosowanie substancji chemicznych i ich 
mieszanin nieoznakowanych w sposób widoczny, umożliwiający ich identyfikację. 
**§ 2.** Niedopuszczalne jest stosowanie substancji niebezpiecznej, mieszaniny 
niebezpiecznej, substancji stwarzającej zagrożenie lub mieszaniny stwarzającej 
zagrożenie bez posiadania aktualnego spisu tych substancji i mieszanin oraz kart 
charakterystyki, a także opakowań zabezpieczających przed ich szkodliwym 
działaniem, pożarem lub wybuchem. 
**§ 3.** Stosowanie substancji niebezpiecznej, mieszaniny niebezpiecznej, 
substancji stwarzającej zagrożenie lub mieszaniny stwarzającej zagrożenie jest 
dopuszczalne 
pod 
warunkiem 
zastosowania 
środków 
zapewniających 
pracownikom ochronę ich zdrowia i życia. 
**§ 4.** Zasady klasyfikacji substancji chemicznych i ich mieszanin pod 
względem zagrożeń dla zdrowia lub życia, wykaz substancji chemicznych 
niebezpiecznych, wymagania dotyczące kart charakterystyki oraz sposób ich 
oznakowania określają odrębne przepisy. 
**§ 5.** (uchylony)

***
## Art. 222. {#kp-czwarty-art-222}

**§ 1.** W razie zatrudniania pracownika w warunkach narażenia na 
działanie substancji chemicznych, ich mieszanin, czynników lub procesów 
technologicznych o działaniu rakotwórczym, mutagennym lub reprotoksycznym, 
pracodawca zastępuje te substancje chemiczne, ich mieszaniny, czynniki lub 
procesy technologiczne mniej szkodliwymi dla zdrowia lub stosuje inne dostępne 
środki ograniczające stopień tego narażenia, przy odpowiednim wykorzystaniu 
osiągnięć nauki i techniki.  
**§ 2.** Pracodawca rejestruje wszystkie rodzaje prac w kontakcie z substancjami 
chemicznymi, ich mieszaninami, czynnikami lub procesami technologicznymi o 
działaniu rakotwórczym, mutagennym lub reprotoksycznym, określonymi w 
wykazie, o którym mowa w § 3, a także prowadzi rejestr pracowników 
zatrudnionych przy tych pracach.  

 
 
 
s. 150/195 
 
2025-08-06 
**§ 3.** Minister właściwy do spraw zdrowia w porozumieniu z ministrem 
właściwym do spraw pracy określi, w drodze rozporządzenia:  
- 1) wykaz substancji chemicznych, ich mieszanin, czynników lub procesów 
technologicznych 
o 
działaniu 
rakotwórczym, 
mutagennym 
lub 
reprotoksycznym i sposób ich rejestrowania,  
- 2) sposób prowadzenia rejestru prac, których wykonywanie powoduje 
konieczność pozostawania w kontakcie z substancjami chemicznymi, ich 
mieszaninami, czynnikami lub procesami technologicznymi o działaniu 
rakotwórczym, mutagennym lub reprotoksycznym,  
- 3) sposób prowadzenia rejestru pracowników zatrudnionych przy pracach, o 
których mowa w pkt 2,  
- 4) wzory dokumentów dotyczących poziomu narażenia pracowników na 
substancje chemiczne, ich mieszaniny, czynniki lub procesy technologiczne o 
działaniu rakotwórczym, mutagennym lub reprotoksycznym oraz sposób 
przechowywania i przekazywania tych dokumentów do podmiotów 
właściwych do rozpoznawania lub stwierdzania chorób zawodowych, 
- 5) szczegółowe 
warunki 
ochrony 
pracowników 
przed 
zagrożeniami 
spowodowanymi przez substancje chemiczne, ich mieszaniny, czynniki lub 
procesy technologiczne o działaniu rakotwórczym, mutagennym lub 
reprotoksycznym,  
- 6) warunki i sposób monitorowania stanu zdrowia pracowników zatrudnionych 
przy pracach, których wykonywanie powoduje konieczność pozostawania w 
kontakcie z substancjami chemicznymi, ich mieszaninami, czynnikami lub 
procesami technologicznymi o działaniu rakotwórczym, mutagennym lub 
reprotoksycznym  
– uwzględniając zróżnicowane właściwości substancji chemicznych, ich 
mieszanin, czynników lub procesów technologicznych o działaniu rakotwórczym, 
mutagennym lub reprotoksycznym, ich zastosowanie oraz konieczność podjęcia 
niezbędnych środków zabezpieczających przed zagrożeniami wynikającymi z ich 
stosowania.

***
## Art. 2221. {#kp-czwarty-art-2221}

**§ 1.** W razie zatrudniania pracownika w warunkach narażenia na 
działanie szkodliwych czynników biologicznych pracodawca stosuje wszelkie 
dostępne środki eliminujące narażenie, a jeżeli jest to niemożliwe – ograniczające 

 
 
 
s. 151/195 
 
2025-08-06 
 
stopień tego narażenia, przy odpowiednim wykorzystaniu osiągnięć nauki 
i techniki. 
**§ 2.** Pracodawca prowadzi rejestr prac narażających pracowników na 
działanie szkodliwych czynników biologicznych oraz rejestr pracowników 
zatrudnionych przy takich pracach. 
**§ 3.** Minister właściwy do spraw zdrowia, w porozumieniu z ministrem 
właściwym do spraw pracy, uwzględniając zróżnicowane działanie czynników 
biologicznych na organizm człowieka oraz konieczność podjęcia niezbędnych 
środków zabezpieczających przed zagrożeniami wynikającymi z wykonywania 
pracy w warunkach narażenia na działanie czynników biologicznych, określi, 
w drodze rozporządzenia: 
- 1) klasyfikację i wykaz szkodliwych czynników biologicznych; 
- 2) wykaz 
prac 
narażających 
pracowników 
na 
działanie 
czynników 
biologicznych; 
- 3) szczegółowe 
warunki 
ochrony 
pracowników 
przed 
zagrożeniami 
spowodowanymi przez szkodliwe czynniki biologiczne, w tym rodzaje 
środków niezbędnych do zapewnienia ochrony zdrowia i życia pracowników 
narażonych na działanie tych czynników, zakres stosowania tych środków 
oraz 
warunki 
i sposób 
monitorowania 
stanu 
zdrowia 
narażonych 
pracowników; 
- 4) sposób prowadzenia rejestrów prac i pracowników, o których mowa w § 2, 
oraz sposób przechowywania i przekazywania tych rejestrów do podmiotów 
właściwych do rozpoznawania lub stwierdzania chorób zawodowych.

***
## Art. 223. {#kp-czwarty-art-223}

**§ 1.** Pracodawca jest obowiązany chronić pracowników przed 
promieniowaniem jonizującym, pochodzącym ze źródeł sztucznych i naturalnych, 
występujących w środowisku pracy. 
**§ 2.** Dawka 
promieniowania 
jonizującego 
pochodzącego 
ze 
źródeł 
naturalnych, otrzymywana przez pracownika przy pracy w warunkach narażenia na 
to promieniowanie, nie może przekraczać dawek granicznych, określonych 
w odrębnych przepisach dla sztucznych źródeł promieniowania jonizującego. 

 
 
 
s. 152/195 
 
2025-08-06

***
## Art. 224. {#kp-czwarty-art-224}

**§ 1.** Pracodawca prowadzący działalność, która stwarza możliwość 
wystąpienia nagłego niebezpieczeństwa dla zdrowia lub życia pracowników, jest 
obowiązany podejmować działania zapobiegające takiemu niebezpieczeństwu. 
**§ 2.** W przypadku, o którym mowa w § 1, pracodawca jest obowiązany 
zapewnić: 
- 1) odpowiednie do rodzaju niebezpieczeństwa urządzenia i sprzęt ratowniczy 
oraz ich obsługę przez osoby należycie przeszkolone; 
- 2) udzielenie pierwszej pomocy poszkodowanym. 
**§ 3.** Przepisy § 1 i 2 nie naruszają wymagań, określonych w odrębnych 
przepisach, dotyczących katastrof i innych nadzwyczajnych zagrożeń.

***
## Art. 225. {#kp-czwarty-art-225}

**§ 1.** Pracodawca jest obowiązany zapewnić, aby prace, przy których 
istnieje możliwość wystąpienia szczególnego zagrożenia dla zdrowia lub życia 
ludzkiego, były wykonywane przez co najmniej dwie osoby, w celu zapewnienia 
asekuracji. 
**§ 2.** Wykaz prac, o których mowa w § 1, ustala pracodawca po konsultacji 
z pracownikami lub ich przedstawicielami, uwzględniając przepisy wydane na 
podstawie art. 23715. 
## Rozdział VI Profilaktyczna ochrona zdrowia

***
## Art. 226. {#kp-czwarty-art-226}

Pracodawca: 
- 1) ocenia i dokumentuje ryzyko zawodowe związane z wykonywaną pracą oraz 
stosuje niezbędne środki profilaktyczne zmniejszające ryzyko; 
- 2) informuje 
pracowników 
o ryzyku 
zawodowym, 
które 
wiąże 
się 
z wykonywaną pracą, oraz o zasadach ochrony przed zagrożeniami.

***
## Art. 227. {#kp-czwarty-art-227}

**§ 1.** Pracodawca jest obowiązany stosować środki zapobiegające 
chorobom zawodowym i innym chorobom związanym z wykonywaną pracą, 
w szczególności: 
- 1) utrzymywać w stanie stałej sprawności urządzenia ograniczające lub 
eliminujące szkodliwe dla zdrowia czynniki środowiska pracy oraz urządzenia 
służące do pomiarów tych czynników; 

 
 
 
s. 153/195 
 
2025-08-06 
- 2) przeprowadzać, na swój koszt, badania i pomiary czynników szkodliwych dla 
zdrowia, rejestrować i przechowywać wyniki tych badań i pomiarów oraz 
udostępniać je pracownikom. 
**§ 2.** Minister właściwy do spraw zdrowia, uwzględniając zróżnicowane 
działanie na organizm człowieka czynników szkodliwych występujących 
w środowisku 
pracy 
oraz 
konieczność 
podjęcia 
niezbędnych 
środków 
zabezpieczających przed ich działaniem, określi, w drodze rozporządzenia: 
- 1) tryb, metody, rodzaj i częstotliwość wykonywania badań i pomiarów, 
o których mowa w § 1 pkt 2; 
- 2) przypadki, w których jest konieczne prowadzenie pomiarów ciągłych; 
- 3) wymagania, jakie powinny spełniać laboratoria wykonujące badania 
i pomiary; 
- 4) sposób rejestrowania i przechowywania wyników tych badań i pomiarów; 
- 5) wzory dokumentów oraz sposób udostępniania wyników badań i pomiarów 
pracownikom.

***
## Art. 228. {#kp-czwarty-art-228}

**§ 1.** Prezes Rady Ministrów powoła, w drodze rozporządzenia, 
Międzyresortową Komisję do Spraw Najwyższych Dopuszczalnych Stężeń 
i Natężeń Czynników Szkodliwych dla Zdrowia w Środowisku Pracy, określi jej 
uprawnienia oraz sposób wykonywania zadań. 
**§ 2.** Do zadań Komisji, o której mowa w § 1, należy: 
- 1) przedkładanie Ministrowi Pracy i Polityki Socjalnej13) wniosków dotyczących 
wartości 
najwyższych 
dopuszczalnych 
stężeń 
i natężeń 
czynników 
szkodliwych dla zdrowia w środowisku pracy – do celów określonych w § 3; 
- 2) inicjowanie prac badawczych niezbędnych do realizacji zadań, o których 
mowa w pkt 1. 
**§ 3.** Minister Pracy i Polityki Socjalnej8) w porozumieniu z Ministrem 
Zdrowia i Opieki Społecznej10) określi, w drodze rozporządzenia, wykaz 
najwyższych dopuszczalnych stężeń i natężeń czynników szkodliwych dla zdrowia 
w środowisku pracy. 
- 13) Obecnie ministrowi właściwemu do spraw pracy, na podstawie art. 4 ust. 1, art. 5 pkt 16 oraz art. 21 
ustawy, o której mowa w odnośniku 8. 

 
 
 
s. 154/195 
 
2025-08-06

***
## Art. 229. {#kp-czwarty-art-229}

**§ 1.** Wstępnym 
badaniom 
lekarskim, 
z zastrzeżeniem 
§ 11, 
podlegają: 
- 1) osoby przyjmowane do pracy; 
- 2) pracownicy młodociani przenoszeni na inne stanowiska pracy i inni 
pracownicy przenoszeni na stanowiska pracy, na których występują czynniki 
szkodliwe dla zdrowia lub warunki uciążliwe. 
**§ 11.** Wstępnym badaniom lekarskim nie podlegają osoby: 
- 1) przyjmowane ponownie do pracy u tego samego pracodawcy na to samo 
stanowisko lub na stanowisko o takich samych warunkach pracy w ciągu 
30 dni po rozwiązaniu lub wygaśnięciu poprzedniego stosunku pracy z tym 
pracodawcą; 
- 2) przyjmowane do pracy u innego pracodawcy na dane stanowisko w ciągu 30 
dni po rozwiązaniu lub wygaśnięciu poprzedniego stosunku pracy, jeżeli 
posiadają aktualne orzeczenie lekarskie stwierdzające brak przeciwwskazań 
do pracy w warunkach pracy opisanych w skierowaniu na badania lekarskie i 
pracodawca ten stwierdzi, że warunki te odpowiadają warunkom 
występującym na danym stanowisku pracy, z wyłączeniem osób 
przyjmowanych do wykonywania prac szczególnie niebezpiecznych. 
**§ 12.** Przepis § 11 pkt 2 stosuje się odpowiednio w przypadku przyjmowania 
do pracy osoby pozostającej jednocześnie w stosunku pracy z innym pracodawcą. 
**§ 13.** Pracodawca żąda od osoby, o której mowa w § 11 pkt 2 oraz w § 12, 
aktualnego orzeczenia lekarskiego stwierdzającego brak przeciwwskazań do pracy 
na danym stanowisku oraz skierowania na badania będące podstawą wydania tego 
orzeczenia. 
**§ 2.** Pracownik podlega okresowym badaniom lekarskim. W przypadku 
niezdolności do pracy trwającej dłużej niż 30 dni, spowodowanej chorobą, 
pracownik podlega ponadto kontrolnym badaniom lekarskim w celu ustalenia 
zdolności do wykonywania pracy na dotychczasowym stanowisku. 
**§ 3.** Okresowe i kontrolne badania lekarskie przeprowadza się w miarę 
możliwości w godzinach pracy. Za czas niewykonywania pracy w związku 
z przeprowadzanymi badaniami pracownik zachowuje prawo do wynagrodzenia, 
a w razie przejazdu na te badania do innej miejscowości przysługują mu należności 

 
 
 
s. 155/195 
 
2025-08-06 
 
na pokrycie kosztów przejazdu według zasad obowiązujących przy podróżach 
służbowych. 
**§ 4.** Pracodawca nie może dopuścić do pracy pracownika bez aktualnego 
orzeczenia lekarskiego stwierdzającego brak przeciwwskazań do pracy na 
określonym stanowisku w warunkach pracy opisanych w skierowaniu na badania 
lekarskie. 
§ 4a. Wstępne, okresowe i kontrolne badania lekarskie przeprowadza się na 
podstawie skierowania wydanego przez pracodawcę. 
**§ 5.** Pracodawca zatrudniający pracowników w warunkach narażenia na 
działanie substancji i czynników rakotwórczych lub pyłów zwłókniających jest 
obowiązany zapewnić tym pracownikom okresowe badania lekarskie także: 
- 1) po zaprzestaniu pracy w kontakcie z tymi substancjami, czynnikami lub 
pyłami; 
- 2) po rozwiązaniu stosunku pracy, jeżeli zainteresowana osoba zgłosi wniosek 
o objęcie takimi badaniami. 
**§ 6.** Badania, o których mowa w § 1, 2 i 5, są przeprowadzane na koszt 
pracodawcy, z zastrzeżeniem § 61. Pracodawca ponosi ponadto inne koszty 
profilaktycznej opieki zdrowotnej nad pracownikami, niezbędnej z uwagi na 
warunki pracy. 
**§ 61.** W przypadku gdy pracownik skierowany na wstępne, okresowe albo 
kontrolne badania lekarskie spełnia warunki objęcia programem zdrowotnym lub 
programem polityki zdrowotnej, lekarz przeprowadzający wstępne, okresowe albo 
kontrolne badania lekarskie kieruje pracownika, za jego zgodą, do udziału 
w programie zdrowotnym lub programie polityki zdrowotnej. Jeżeli pracownik 
wykona wstępne, okresowe albo kontrolne badania lekarskie zgodnie z programem 
zdrowotnym lub programem polityki zdrowotnej, badania te są finansowane na 
zasadach określonych w programie zdrowotnym lub programie polityki 
zdrowotnej. 
**§ 62.** Jeżeli zakres badań określonych w programie zdrowotnym lub 
programie polityki zdrowotnej nie odpowiada pełnemu zakresowi badań 
wymaganych w celu wydania orzeczenia lekarskiego dotyczącego przeciwwskazań 
do pracy na określonym stanowisku w warunkach pracy opisanych w skierowaniu, 
o którym mowa w § 4a, określonych w przepisach wydanych na podstawie § 8, 

 
 
 
s. 156/195 
 
2025-08-06 
 
lekarz przeprowadzający wstępne, okresowe albo kontrolne badania lekarskie 
wydaje pracownikowi również skierowanie na przeprowadzenie pozostałych badań 
wynikających z tych przepisów. 
**§ 63.** Lekarz wydaje orzeczenie lekarskie stwierdzające brak przeciwwskazań 
do pracy w warunkach pracy opisanych w skierowaniu, o którym mowa w § 4a, 
wyłącznie na podstawie wyników badań, których zakres odpowiada zakresowi 
badań określonych w przepisach wydanych na podstawie § 8. 
**§ 64.** Minister właściwy do spraw zdrowia ogłasza, w drodze obwieszczenia, 
wykaz 
programów 
zdrowotnych 
lub 
programów 
polityki 
zdrowotnej 
realizowanych przez ministra właściwego do spraw zdrowia lub Narodowy 
Fundusz Zdrowia, które uwzględnia lekarz w ramach przeprowadzania badania 
wstępnego, badania okresowego albo badania kontrolnego pracownika. 
**§ 65.** Do przeprowadzania badań w zakresie wskazanym w programie 
zdrowotnym lub programie polityki zdrowotnej stosuje się § 3. 
**§ 7.** Pracodawca przechowuje orzeczenia wydane na podstawie badań 
lekarskich, o których mowa w § 1, 2 i 5, orzeczenia i skierowania uzyskane na 
podstawie § 13 oraz skierowania, o których mowa w § 4a. 
**§ 71.** W przypadku stwierdzenia, że warunki określone w skierowaniu, o 
którym mowa w § 13, nie odpowiadają warunkom występującym na danym 
stanowisku pracy, pracodawca zwraca osobie przyjmowanej do pracy to 
skierowanie oraz orzeczenie lekarskie wydane w wyniku tego skierowania. 
**§ 8.** Minister właściwy do spraw zdrowia w porozumieniu z ministrem 
właściwym do spraw pracy określi, w drodze rozporządzenia: 
- 1) tryb i zakres badań lekarskich, o których mowa w § 1, 2 i 5, oraz częstotliwość 
badań okresowych, a także sposób dokumentowania i kontroli badań 
lekarskich, 
- 2) tryb 
wydawania 
i przechowywania 
orzeczeń 
lekarskich 
do 
celów 
przewidzianych w niniejszej ustawie i w przepisach wydanych na jej 
podstawie, 
- 3) zakres informacji objętych skierowaniem na badania lekarskie i orzeczeniem 
lekarskim, a także wzory tych dokumentów, 
- 4) zakres profilaktycznej opieki zdrowotnej, o której mowa w § 6 zdanie drugie, 

 
 
 
s. 157/195 
 
2025-08-06 
- 5) dodatkowe wymagania kwalifikacyjne, jakie powinni spełniać lekarze 
przeprowadzający badania, o których mowa w § 1, 2 i 5, oraz sprawujący 
profilaktyczną opiekę zdrowotną, o której mowa w § 6 zdanie drugie 
– uwzględniając 
konieczność 
zapewnienia 
prawidłowego 
przebiegu 
i kompleksowości badań lekarskich, o których mowa w § 1, 2 i 5, profilaktycznej 
opieki zdrowotnej, o której mowa w § 6 zdanie drugie, a także informacji 
umożliwiających porównanie warunków pracy u pracodawcy oraz ochrony danych 
osobowych osób poddanych badaniom.

***
## Art. 230. {#kp-czwarty-art-230}

**§ 1.** W razie stwierdzenia u pracownika objawów wskazujących na 
powstawanie choroby zawodowej, pracodawca jest obowiązany, na podstawie 
orzeczenia lekarskiego, w terminie i na czas określony w tym orzeczeniu, przenieść 
pracownika do innej pracy nienarażającej go na działanie czynnika, który wywołał 
te objawy. 
**§ 2.** Jeżeli przeniesienie do innej pracy powoduje obniżenie wynagrodzenia, 
pracownikowi przysługuje dodatek wyrównawczy przez okres nieprzekraczający 
6 miesięcy.

***
## Art. 231. {#kp-czwarty-art-231}

Pracodawca, na podstawie orzeczenia lekarskiego, przenosi do 
odpowiedniej pracy pracownika, który stał się niezdolny do wykonywania 
dotychczasowej pracy wskutek wypadku przy pracy lub choroby zawodowej i nie 
został uznany za niezdolnego do pracy w rozumieniu przepisów o emeryturach 
i rentach z Funduszu Ubezpieczeń Społecznych. Przepis art. 230 § 2 stosuje się 
odpowiednio.

***
## Art. 232. {#kp-czwarty-art-232}

Pracodawca jest obowiązany zapewnić pracownikom zatrudnionym 
w warunkach szczególnie uciążliwych, nieodpłatnie, odpowiednie posiłki i napoje, 
jeżeli jest to niezbędne ze względów profilaktycznych. Rada Ministrów określi, 
w drodze rozporządzenia, rodzaje tych posiłków i napojów oraz wymagania, jakie 
powinny spełniać, a także przypadki i warunki ich wydawania.

***
## Art. 233. {#kp-czwarty-art-233}

Pracodawca jest obowiązany zapewnić pracownikom odpowiednie 
urządzenia higieniczno-sanitarne oraz dostarczyć niezbędne środki higieny 
osobistej. 

 
 
 
s. 158/195 
 
2025-08-06 
## Rozdział VII Wypadki przy pracy i choroby zawodowe

***
## Art. 234. {#kp-czwarty-art-234}

**§ 1.** W razie wypadku przy pracy pracodawca jest obowiązany 
podjąć niezbędne działania eliminujące lub ograniczające zagrożenie, zapewnić 
udzielenie 
pierwszej 
pomocy 
osobom 
poszkodowanym 
i ustalenie 
w przewidzianym trybie okoliczności i przyczyn wypadku oraz zastosować 
odpowiednie środki zapobiegające podobnym wypadkom. 
**§ 2.** Pracodawca jest obowiązany niezwłocznie zawiadomić właściwego 
okręgowego inspektora pracy i prokuratora o śmiertelnym, ciężkim lub zbiorowym 
wypadku przy pracy oraz o każdym innym wypadku, który wywołał wymienione 
skutki, mającym związek z pracą, jeżeli może być uznany za wypadek przy pracy. 
**§ 3.** Pracodawca jest obowiązany prowadzić rejestr wypadków przy pracy. 
**§ 31.** Pracodawca jest obowiązany przechowywać protokół ustalenia 
okoliczności i przyczyn wypadku przy pracy wraz z pozostałą dokumentacją 
powypadkową przez 10 lat. 
**§ 4.** Koszty związane z ustalaniem okoliczności i przyczyn wypadków przy 
pracy ponosi pracodawca.

***
## Art. 235. {#kp-czwarty-art-235}

**§ 1.** Pracodawca jest obowiązany niezwłocznie zgłosić właściwemu 
państwowemu inspektorowi sanitarnemu i właściwemu okręgowemu inspektorowi 
pracy każdy przypadek podejrzenia choroby zawodowej. 
**§ 2.** Obowiązek, o którym mowa w § 1, dotyczy także lekarza podmiotu 
właściwego do rozpoznania choroby zawodowej, o którym mowa w przepisach 
wydanych na podstawie art. 237 § 1 pkt 6. 
**§ 21.** W każdym przypadku podejrzenia choroby zawodowej: 
- 1) lekarz, 
- 2) lekarz dentysta, który podczas wykonywania zawodu powziął takie 
podejrzenie u pacjenta 
– kieruje na badania w celu wydania orzeczenia o rozpoznaniu choroby zawodowej 
albo o braku podstaw do jej rozpoznania. 
**§ 22.** Zgłoszenia podejrzenia choroby zawodowej może również dokonać 
pracownik lub były pracownik, który podejrzewa, że występujące u niego objawy 
mogą wskazywać na taką chorobę, przy czym pracownik aktualnie zatrudniony 

 
 
 
s. 159/195 
 
2025-08-06 
 
zgłasza podejrzenie za pośrednictwem lekarza sprawującego nad nim 
profilaktyczną opiekę zdrowotną. 
**§ 3.** W razie rozpoznania u pracownika choroby zawodowej, pracodawca jest 
obowiązany: 
- 1) ustalić przyczyny powstania choroby zawodowej oraz charakter i rozmiar 
zagrożenia tą chorobą, działając w porozumieniu z właściwym państwowym 
inspektorem sanitarnym; 
- 2) przystąpić niezwłocznie do usunięcia czynników powodujących powstanie 
choroby zawodowej i zastosować inne niezbędne środki zapobiegawcze; 
- 3) zapewnić realizację zaleceń lekarskich. 
**§ 4.** Pracodawca jest obowiązany prowadzić rejestr obejmujący przypadki 
stwierdzonych chorób zawodowych i podejrzeń o takie choroby. 
**§ 5.** Pracodawca przesyła zawiadomienie o skutkach choroby zawodowej do 
instytutu medycyny pracy wskazanego w przepisach wydanych na podstawie 
art. 237 § 11 oraz do właściwego państwowego inspektora sanitarnego.

***
## Art. 2351. {#kp-czwarty-art-2351}

Za chorobę zawodową uważa się chorobę, wymienioną w wykazie 
chorób zawodowych, jeżeli w wyniku oceny warunków pracy można stwierdzić 
bezspornie lub z wysokim prawdopodobieństwem, że została ona spowodowana 
działaniem czynników szkodliwych dla zdrowia występujących w środowisku 
pracy albo w związku ze sposobem wykonywania pracy, zwanych „narażeniem 
zawodowym”.

***
## Art. 2352. {#kp-czwarty-art-2352}

Rozpoznanie choroby zawodowej u pracownika lub byłego 
pracownika może nastąpić w okresie jego zatrudnienia w narażeniu zawodowym 
albo po zakończeniu pracy w takim narażeniu, pod warunkiem wystąpienia 
udokumentowanych objawów chorobowych w okresie ustalonym w wykazie 
chorób zawodowych.

***
## Art. 236. {#kp-czwarty-art-236}

Pracodawca jest obowiązany systematycznie analizować przyczyny 
wypadków przy pracy, chorób zawodowych i innych chorób związanych 
z warunkami środowiska pracy i na podstawie wyników tych analiz stosować właś-
ciwe środki zapobiegawcze.

***
## Art. 237. {#kp-czwarty-art-237}

**§ 1.** Rada Ministrów określi w drodze rozporządzenia: 

 
 
 
s. 160/195 
 
2025-08-06 
- 1) sposób i tryb postępowania przy ustalaniu okoliczności i przyczyn wypadków 
przy pracy oraz sposób ich dokumentowania, a także zakres informacji 
zamieszczanych w rejestrze wypadków przy pracy, 
- 2) skład zespołu powypadkowego, 
- 3) wykaz chorób zawodowych, 
- 4) okres, w którym wystąpienie udokumentowanych objawów chorobowych 
upoważnia do rozpoznania choroby zawodowej pomimo wcześniejszego 
zakończenia pracy w narażeniu zawodowym, 
- 5) sposób i tryb postępowania dotyczący zgłaszania podejrzenia, rozpoznawania 
i stwierdzania chorób zawodowych, 
- 6) podmioty właściwe w sprawie rozpoznawania chorób zawodowych 
– uwzględniając aktualną wiedzę w zakresie patogenezy i epidemiologii chorób 
powodowanych 
przez 
czynniki 
szkodliwe 
dla 
człowieka 
występujące 
w środowisku pracy oraz kierując się koniecznością zapobiegania występowaniu 
wypadków przy pracy i chorób zawodowych. 
**§ 11.** Rada Ministrów wskaże w drodze rozporządzenia instytut medycyny 
pracy, do którego pracodawca przesyła zawiadomienie o skutkach choroby 
zawodowej oraz termin, w którym ma ono być przesłane, mając na uwadze 
specjalizację instytutu oraz rodzaj prowadzonych w nim badań. 
**§ 2.** Minister właściwy do spraw pracy określi, w drodze rozporządzenia, 
wzór protokołu ustalenia okoliczności i przyczyn wypadku przy pracy zawierający 
dane dotyczące poszkodowanego, składu zespołu powypadkowego, wypadku i jego 
skutków, stwierdzenie, że wypadek jest lub nie jest wypadkiem przy pracy, oraz 
wnioski i zalecane środki profilaktyczne, a także pouczenie dla stron postępowania 
powypadkowego. 
**§ 3.** Minister właściwy do spraw pracy określi, w drodze rozporządzenia, 
wzór statystycznej karty wypadku przy pracy, uwzględniając dane dotyczące 
pracodawcy, poszkodowanego, wypadku przy pracy, a także jego skutków oraz 
sposób i terminy jej sporządzania i przekazywania do właściwego urzędu 
statystycznego. 
**§ 4.** Minister właściwy do spraw zdrowia określi, w drodze rozporządzenia: 
- 1) sposób dokumentowania chorób zawodowych i skutków tych chorób, a także 
prowadzenia rejestrów chorób zawodowych, uwzględniając w szczególności 

 
 
 
s. 161/195 
 
2025-08-06 
 
wzory dokumentów stosowanych w postępowaniu dotyczącym tych chorób 
oraz dane objęte rejestrem. 
- 2) (uchylony)

***
## Art. 2371. {#kp-czwarty-art-2371}

**§ 1.** Pracownikowi, który uległ wypadkowi przy pracy lub 
zachorował na chorobę zawodową określoną w wykazie, o którym mowa 
w art. 237 § 1 pkt 3, przysługują świadczenia z ubezpieczenia społecznego, 
określone w odrębnych przepisach. 
**§ 2.** Pracownikowi, który uległ wypadkowi przy pracy, przysługuje od 
pracodawcy odszkodowanie za utratę lub uszkodzenie w związku z wypadkiem 
przedmiotów osobistego użytku oraz przedmiotów niezbędnych do wykonywania 
pracy, z wyjątkiem utraty lub uszkodzenia pojazdów samochodowych oraz 
wartości pieniężnych. 
## Rozdział VIII Szkolenie

***
## Art. 2372. {#kp-czwarty-art-2372}

Minister Edukacji Narodowej14) jest obowiązany zapewnić 
uwzględnianie problematyki bezpieczeństwa i higieny pracy oraz ergonomii 
w programach nauczania w szkołach, po uzgodnieniu zakresu tej problematyki 
z Ministrem Pracy i Polityki Socjalnej12).

***
## Art. 2373. {#kp-czwarty-art-2373}

**§ 1.** Nie wolno dopuścić pracownika do pracy, do której 
wykonywania nie posiada on wymaganych kwalifikacji lub potrzebnych 
umiejętności, 
a także 
dostatecznej 
znajomości 
przepisów 
oraz 
zasad 
bezpieczeństwa i higieny pracy. 
**§ 2.** Pracodawca jest obowiązany zapewnić przeszkolenie pracownika 
w zakresie bezpieczeństwa i higieny pracy przed dopuszczeniem go do pracy oraz 
prowadzenie okresowych szkoleń w tym zakresie. Szkolenie pracownika przed 
dopuszczeniem do pracy nie jest wymagane w przypadku podjęcia przez niego 
pracy na tym samym stanowisku pracy, które zajmował u danego pracodawcy 
bezpośrednio przed nawiązaniem z tym pracodawcą kolejnej umowy o pracę. 
- 14) Obecnie minister właściwy do spraw oświaty i wychowania, na podstawie art. 4 ust. 1, art. 5 pkt 
15 oraz art. 20 ustawy, o której mowa w odnośniku 8. 

 
 
 
s. 162/195 
 
2025-08-06 
**§ 21.** Pracodawca 
jest 
obowiązany 
odbyć 
szkolenie 
w dziedzinie 
bezpieczeństwa i higieny pracy w zakresie niezbędnym do wykonywania ciążących 
na nim obowiązków. Szkolenie to powinno być okresowo powtarzane. 
**§ 22.** Szkolenie okresowe pracownika, o którym mowa w § 2, nie jest 
wymagane w przypadku pracownika na stanowisku administracyjno-biurowym, 
gdy rodzaj przeważającej działalności pracodawcy w rozumieniu przepisów o 
statystyce publicznej znajduje się w grupie działalności, dla której ustalono nie 
wyższą niż trzecia kategorię ryzyka w rozumieniu przepisów o ubezpieczeniu 
społecznym z tytułu wypadków przy pracy i chorób zawodowych, chyba że z oceny 
ryzyka, o której mowa w art. 226 pkt 1, wynika, że jest to konieczne. 
**§ 23.** W przypadku gdy rodzaj przeważającej działalności pracodawcy w 
rozumieniu przepisów o statystyce publicznej znajdzie się w grupie działalności, 
dla której zostanie ustalona wyższa niż trzecia kategoria ryzyka w rozumieniu 
przepisów o ubezpieczeniu społecznym z tytułu wypadków przy pracy i chorób 
zawodowych, pracodawca jest obowiązany przeprowadzić szkolenie okresowe 
pracownika, o którym mowa w § 22, w zakresie bezpieczeństwa i higieny pracy, 
w terminie nie dłuższym niż 6 miesięcy, licząc od dnia ustalenia wyższej kategorii 
ryzyka. 
**§ 24.** Przepis § 23 stosuje się odpowiednio, gdy z dokonanej oceny ryzyka, o 
której mowa w art. 226 pkt 1, wynika, że przeprowadzenie szkolenia okresowego 
pracownika, o którym mowa w § 22, stało się konieczne. Szkolenie okresowe 
przeprowadza się w terminie nie dłuższym niż 6 miesięcy, licząc od dnia dokonania 
oceny ryzyka. 
**§ 3.** Szkolenia, o których mowa w § 2, odbywają się w czasie pracy i na koszt 
pracodawcy.

***
## Art. 2374. {#kp-czwarty-art-2374}

**§ 1.** Pracodawca jest obowiązany zaznajamiać pracowników 
z przepisami 
i zasadami 
bezpieczeństwa 
i higieny 
pracy 
dotyczącymi 
wykonywanych przez nich prac. 
**§ 2.** Pracodawca 
jest 
obowiązany 
wydawać 
szczegółowe 
instrukcje 
i wskazówki dotyczące bezpieczeństwa i higieny pracy na stanowiskach pracy. 
**§ 3.** Pracownik jest obowiązany potwierdzić na piśmie zapoznanie się 
z przepisami oraz zasadami bezpieczeństwa i higieny pracy. 

 
 
 
s. 163/195 
 
2025-08-06

***
## Art. 2375. {#kp-czwarty-art-2375}

Minister 
właściwy 
do 
spraw 
pracy 
określi, 
w drodze 
rozporządzenia, szczegółowe zasady szkolenia w dziedzinie bezpieczeństwa 
i higieny pracy, zakres tego szkolenia, wymagania dotyczące treści i realizacji 
programów szkolenia, sposób dokumentowania szkolenia oraz przypadki, 
w których pracodawcy lub pracownicy mogą być zwolnieni z określonych 
rodzajów szkolenia. 
## Rozdział IX Środki ochrony indywidualnej oraz odzież i obuwie robocze

***
## Art. 2376. {#kp-czwarty-art-2376}

**§ 1.** Pracodawca jest obowiązany dostarczyć pracownikowi 
nieodpłatnie środki ochrony indywidualnej zabezpieczające przed działaniem 
niebezpiecznych 
i szkodliwych 
dla 
zdrowia 
czynników 
występujących 
w środowisku pracy oraz informować go o sposobach posługiwania się tymi 
środkami. 
**§ 2.** (uchylony) 
**§ 3.** Pracodawca jest obowiązany dostarczać pracownikowi środki ochrony 
indywidualnej, które spełniają wymagania dotyczące oceny zgodności określone 
w odrębnych przepisach.

***
## Art. 2377. {#kp-czwarty-art-2377}

**§ 1.** Pracodawca jest obowiązany dostarczyć pracownikowi 
nieodpłatnie odzież i obuwie robocze, spełniające wymagania określone 
w Polskich Normach: 
- 1) jeżeli odzież własna pracownika może ulec zniszczeniu lub znacznemu 
zabrudzeniu; 
- 2) ze względu na wymagania technologiczne, sanitarne lub bezpieczeństwa 
i higieny pracy. 
**§ 2.** Pracodawca może ustalić stanowiska, na których dopuszcza się używanie 
przez pracowników, za ich zgodą, własnej odzieży i obuwia roboczego, 
spełniających wymagania bezpieczeństwa i higieny pracy. 
**§ 3.** Przepis § 2 nie dotyczy stanowisk, na których są wykonywane prace 
związane z bezpośrednią obsługą maszyn i innych urządzeń technicznych albo 
prace powodujące intensywne brudzenie lub skażenie odzieży i obuwia roboczego 
środkami chemicznymi lub promieniotwórczymi albo materiałami biologicznie 
zakaźnymi. 

 
 
 
s. 164/195 
 
2025-08-06 
**§ 4.** Pracownikowi używającemu własnej odzieży i obuwia roboczego, 
zgodnie z § 2, pracodawca wypłaca ekwiwalent pieniężny w wysokości 
uwzględniającej ich aktualne ceny.

***
## Art. 2378. {#kp-czwarty-art-2378}

**§ 1.** Pracodawca ustala rodzaje środków ochrony indywidualnej 
oraz odzieży i obuwia roboczego, których stosowanie na określonych stanowiskach 
jest niezbędne w związku z art. 2376 § 1 i art. 2377 § 1, oraz przewidywane okresy 
użytkowania odzieży i obuwia roboczego. 
**§ 2.** Środki ochrony indywidualnej oraz odzież i obuwie robocze, o których 
mowa w art. 2376 § 1 i art. 2377 § 1, stanowią własność pracodawcy.

***
## Art. 2379. {#kp-czwarty-art-2379}

**§ 1.** Pracodawca nie może dopuścić pracownika do pracy bez 
środków ochrony indywidualnej oraz odzieży i obuwia roboczego, przewidzianych 
do stosowania na danym stanowisku pracy. 
**§ 2.** Pracodawca jest obowiązany zapewnić, aby stosowane środki ochrony 
indywidualnej oraz odzież i obuwie robocze posiadały właściwości ochronne 
i użytkowe, oraz zapewnić odpowiednio ich pranie, konserwację, naprawę, 
odpylanie i odkażanie. 
**§ 3.** Jeżeli pracodawca nie może zapewnić prania odzieży roboczej, czynności 
te mogą być wykonywane przez pracownika, pod warunkiem wypłacania przez 
pracodawcę ekwiwalentu pieniężnego w wysokości kosztów poniesionych przez 
pracownika.

***
## Art. 23710. {#kp-czwarty-art-23710}

**§ 1.** Pracodawca jest obowiązany zapewnić, aby środki ochrony 
indywidualnej oraz odzież i obuwie robocze, które w wyniku stosowania 
w procesie pracy uległy skażeniu środkami chemicznymi lub promieniotwórczymi 
albo materiałami biologicznie zakaźnymi, były przechowywane wyłącznie 
w miejscu przez niego wyznaczonym. 
**§ 2.** Powierzanie pracownikowi prania, konserwacji, odpylania i odkażania 
przedmiotów, o których mowa w § 1, jest niedopuszczalne. 
## Rozdział X Służba bezpieczeństwa i higieny pracy

***
## Art. 23711. {#kp-czwarty-art-23711}

**§ 1.** Pracodawca zatrudniający więcej niż 100 pracowników 
tworzy służbę bezpieczeństwa i higieny pracy, zwaną dalej „służbą bhp”, pełniącą 

 
 
 
s. 165/195 
 
2025-08-06 
 
funkcje doradcze i kontrolne w zakresie bezpieczeństwa i higieny pracy, zaś 
pracodawca zatrudniający do 100 pracowników powierza wykonywanie zadań 
służby bhp pracownikowi zatrudnionemu przy innej pracy. Pracodawca 
posiadający ukończone szkolenie niezbędne do wykonywania zadań służby bhp 
może sam wykonywać zadania tej służby, jeżeli: 
- 1) zatrudnia do 10 pracowników albo 
- 2) zatrudnia do 50 pracowników i jest zakwalifikowany do grupy działalności, 
dla której ustalono nie wyższą niż trzecia kategorię ryzyka w rozumieniu 
przepisów o ubezpieczeniu społecznym z tytułu wypadków przy pracy i 
chorób zawodowych. 
**§ 2.** Pracodawca – w przypadku braku kompetentnych pracowników – może 
powierzyć wykonywanie zadań służby bhp specjalistom spoza zakładu pracy. 
Pracownik służby bhp oraz pracownik zatrudniony przy innej pracy, któremu 
powierzono wykonywanie zadań służby bhp, o którym mowa w § 1, a także 
specjalista spoza zakładu pracy powinni spełniać wymagania kwalifikacyjne 
niezbędne do wykonywania zadań służby bhp oraz ukończyć szkolenie 
w dziedzinie bezpieczeństwa i higieny pracy dla pracowników tej służby. 
**§ 3.** Pracownik służby bhp oraz pracownik zatrudniony przy innej pracy, 
któremu powierzono wykonywanie zadań tej służby, nie mogą ponosić 
jakichkolwiek niekorzystnych dla nich następstw z powodu wykonywania zadań 
i uprawnień służby bhp. 
**§ 4.** Właściwy inspektor pracy może nakazać utworzenie służby bhp, albo 
zwiększenie liczby pracowników tej służby, jeżeli jest to uzasadnione 
stwierdzonymi zagrożeniami zawodowymi. 
**§ 5.** Rada Ministrów określi, w drodze rozporządzenia: 
- 1) szczegółowy zakres działania, uprawnienia, organizację, liczebność 
i podporządkowanie służby bhp; 
- 2) kwalifikacje wymagane do wykonywania zadań służby bhp. 

 
 
 
s. 166/195 
 
2025-08-06 
## Rozdział XI Konsultacje w zakresie bezpieczeństwa i higieny pracy oraz komisja 
bezpieczeństwa i higieny pracy 
Art. 23711a. § 1. 
Pracodawca 
konsultuje 
z pracownikami 
lub 
ich 
przedstawicielami wszystkie działania związane z bezpieczeństwem i higieną 
pracy, w szczególności dotyczące: 
- 1) zmian w organizacji pracy i wyposażeniu stanowisk pracy, wprowadzania 
nowych procesów technologicznych oraz substancji chemicznych i ich 
mieszanin, jeżeli mogą one stwarzać zagrożenie dla zdrowia lub życia 
pracowników; 
- 2) oceny ryzyka zawodowego występującego przy wykonywaniu określonych 
prac oraz informowania pracowników o tym ryzyku; 
- 3) tworzenia służby bhp lub powierzania wykonywania zadań tej służby innym 
osobom oraz wyznaczania pracowników do udzielania pierwszej pomocy, 
a także wykonywania działań w zakresie zwalczania pożarów i ewakuacji 
pracowników; 
- 4) przydzielania pracownikom środków ochrony indywidualnej oraz odzieży 
i obuwia roboczego; 
- 5) szkolenia pracowników w dziedzinie bezpieczeństwa i higieny pracy. 
**§ 2.** Pracownicy lub ich przedstawiciele mogą przedstawiać pracodawcy 
wnioski w sprawie eliminacji lub ograniczenia zagrożeń zawodowych. 
**§ 3.** Pracodawca zapewnia odpowiednie warunki do przeprowadzania 
konsultacji, a zwłaszcza zapewnia, aby odbywały się w godzinach pracy. Za czas 
nieprzepracowany w związku z udziałem w konsultacjach pracownicy lub ich 
przedstawiciele zachowują prawo do wynagrodzenia. 
**§ 4.** Na umotywowany wniosek pracowników lub ich przedstawicieli 
dotyczący spraw zagrożenia zdrowia i życia pracowników inspektorzy pracy 
Państwowej Inspekcji Pracy przeprowadzają kontrole oraz stosują środki prawne 
przewidziane w przepisach o Państwowej Inspekcji Pracy. 
**§ 5.** U pracodawcy, u którego została powołana komisja bezpieczeństwa 
i higieny pracy – konsultacje, o których mowa w § 1, mogą być prowadzone 

 
 
 
s. 167/195 
 
2025-08-06 
 
w ramach tej komisji, natomiast uprawnienia, o których mowa w § 2 i 4, 
przysługują pracownikom lub ich przedstawicielom wchodzącym w skład komisji. 
**§ 6.** Pracownicy lub ich przedstawiciele nie mogą ponosić jakichkolwiek 
niekorzystnych dla nich konsekwencji z tytułu działalności, o której mowa w § 1, 
2 i 4. Dotyczy to również pracowników lub ich przedstawicieli, o których mowa 
w § 5.

***
## Art. 23712. {#kp-czwarty-art-23712}

**§ 1.** Pracodawca zatrudniający więcej niż 250 pracowników 
powołuje komisję bezpieczeństwa i higieny pracy, zwaną dalej „komisją bhp”, jako 
swój organ doradczy i opiniodawczy. W skład komisji bhp wchodzą w równej 
liczbie przedstawiciele pracodawcy, w tym pracownicy służby bhp i lekarz 
sprawujący 
profilaktyczną 
opiekę 
zdrowotną 
nad 
pracownikami, 
oraz 
przedstawiciele pracowników, w tym społeczny inspektor pracy. 
**§ 2.** Przewodniczącym komisji bhp jest pracodawca lub osoba przez niego 
upoważniona, a wiceprzewodniczącym – społeczny inspektor pracy lub 
przedstawiciel pracowników.

***
## Art. 23713. {#kp-czwarty-art-23713}

**§ 1.** Zadaniem komisji bhp jest dokonywanie przeglądu warunków 
pracy, okresowej oceny stanu bezpieczeństwa i higieny pracy, opiniowanie 
podejmowanych przez pracodawcę środków zapobiegających wypadkom przy 
pracy i chorobom zawodowym, formułowanie wniosków dotyczących poprawy 
warunków pracy oraz współdziałanie z pracodawcą w realizacji jego obowiązków 
w zakresie bezpieczeństwa i higieny pracy. 
**§ 2.** Posiedzenia komisji bhp odbywają się w godzinach pracy, nie rzadziej niż 
raz na kwartał. Za czas nieprzepracowany w związku z udziałem w posiedzeniach 
komisji bhp pracownik zachowuje prawo do wynagrodzenia. 
**§ 3.** Komisja bhp w związku z wykonywaniem zadań wymienionych 
w § 1 korzysta z ekspertyz lub opinii specjalistów spoza zakładu pracy 
w przypadkach uzgodnionych z pracodawcą i na jego koszt. 
Art. 23713a. Przedstawiciele pracowników, o których mowa w art. 23711a 
i art. 23712, są wybierani przez zakładowe organizacje związkowe, a jeżeli 
u pracodawcy takie organizacje nie działają – przez pracowników, w trybie 
przyjętym w zakładzie pracy. 

 
 
 
s. 168/195 
 
2025-08-06 
## Rozdział XII Obowiązki organów sprawujących nadzór nad przedsiębiorstwami lub 
innymi jednostkami organizacyjnymi państwowymi albo samorządowymi

***
## Art. 23714. {#kp-czwarty-art-23714}

Organy sprawujące nadzór nad przedsiębiorstwami lub innymi 
jednostkami organizacyjnymi państwowymi albo samorządowymi są obowiązane 
podejmować działania na rzecz kształtowania bezpiecznych i higienicznych 
warunków pracy, w szczególności: 
- 1) udzielać przedsiębiorstwom i jednostkom organizacyjnym pomocy przy 
wykonywaniu zadań z zakresu bezpieczeństwa i higieny pracy; 
- 2) dokonywać, co najmniej raz w roku, oceny stanu bezpieczeństwa i higieny 
pracy w przedsiębiorstwach i jednostkach organizacyjnych oraz określać 
kierunki poprawy tego stanu; 
- 3) w miarę potrzeb i możliwości – inicjować i prowadzić badania naukowe 
dotyczące bezpieczeństwa i higieny pracy. 
## Rozdział XIII Przepisy bezpieczeństwa i higieny pracy dotyczące wykonywania prac 
w różnych gałęziach pracy

***
## Art. 23715. {#kp-czwarty-art-23715}

**§ 1.** Minister Pracy i Polityki Socjalnej8) w porozumieniu 
z Ministrem Zdrowia i Opieki Społecznej10) określi, w drodze rozporządzenia, 
ogólnie obowiązujące przepisy bezpieczeństwa i higieny pracy dotyczące prac 
wykonywanych w różnych gałęziach pracy. 
**§ 2.** Ministrowie właściwi dla określonych gałęzi pracy lub rodzajów prac 
w porozumieniu z Ministrem Pracy i Polityki Socjalnej12) oraz Ministrem Zdrowia 
i Opieki Społecznej10) określą, w drodze rozporządzenia, przepisy bezpieczeństwa 
i higieny pracy dotyczące tych gałęzi lub prac.

