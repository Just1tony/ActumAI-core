---
id: code.kp.dzial.trzeci
title: "Kodeks pracy — Dział TRZECI (Wynagrodzenie za pracę i inne świadczenia)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1974 nr 24 poz. 141"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KP — Dział TRZECI"]
tags: ["KP","Kodeks pracy","Dział TRZECI","PL"]
source_pdf: "D19740141Lj.pdf"
articles: "Art. 78–921"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kp-trzeci-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks pracy — Dział TRZECI: Wynagrodzenie za pracę i inne świadczenia

Wynagrodzenie za pracę i inne świadczenia 
## Rozdział I Ustalanie wynagrodzenia za pracę i innych świadczeń związanych z pracą
***
## Art. 771. {#kp-trzeci-art-771}

Warunki wynagradzania za pracę i przyznawania innych świadczeń 
związanych z pracą ustalają układy zbiorowe pracy, zgodnie z przepisami działu 
jedenastego, z zastrzeżeniem przepisów art. 772–775.

***
## Art. 772. {#kp-trzeci-art-772}

**§ 1.** Pracodawca zatrudniający co najmniej 50 pracowników, 
nieobjętych zakładowym układem zbiorowym pracy ani ponadzakładowym 

 
 
 
s. 58/195 
 
2025-08-06 
 
układem zbiorowym pracy odpowiadającym wymaganiom określonym w § 3, 
ustala warunki wynagradzania za pracę w regulaminie wynagradzania. 
**§ 11.** Pracodawca zatrudniający mniej niż 50 pracowników, nieobjętych 
zakładowym układem zbiorowym pracy ani ponadzakładowym układem 
zbiorowym pracy odpowiadającym wymaganiom określonym w § 3, może ustalić 
warunki wynagradzania za pracę w regulaminie wynagradzania. 
**§ 12.** Pracodawca zatrudniający co najmniej 20 i mniej niż 50 pracowników, 
nieobjętych zakładowym układem zbiorowym pracy ani ponadzakładowym 
układem zbiorowym pracy odpowiadającym wymaganiom określonym w § 3, 
ustala warunki wynagradzania za pracę w regulaminie wynagradzania, jeżeli 
zakładowa organizacja związkowa wystąpi z wnioskiem o jego ustalenie. 
**§ 2.** W regulaminie wynagradzania pracodawca może ustalić także inne 
świadczenia związane z pracą i zasady ich przyznawania. 
**§ 3.** Regulamin wynagradzania obowiązuje do czasu objęcia pracowników 
zakładowym układem zbiorowym pracy lub ponadzakładowym układem 
zbiorowym pracy ustalającym warunki wynagradzania za pracę oraz przyznawania 
innych świadczeń związanych z pracą w zakresie i w sposób umożliwiający 
określanie, na jego podstawie, indywidualnych warunków umów o pracę. 
**§ 4.** Regulamin 
wynagradzania 
ustala 
pracodawca. 
Jeżeli 
u danego 
pracodawcy działa zakładowa organizacja związkowa, pracodawca uzgadnia z nią 
regulamin wynagradzania. 
**§ 5.** Do regulaminu wynagradzania stosuje się odpowiednio przepisy art. 239 
§ 3, art. 24112 § 2, art. 24113 oraz art. 24126 § 2. 
**§ 6.** Regulamin wynagradzania wchodzi w życie po upływie dwóch tygodni 
od dnia podania go do wiadomości pracowników, w sposób przyjęty u danego 
pracodawcy.

***
## Art. 773. {#kp-trzeci-art-773}

**§ 1.** Warunki wynagradzania za pracę i przyznawania innych 
świadczeń związanych z pracą dla pracowników zatrudnionych w państwowych 
jednostkach sfery budżetowej, jeżeli nie są oni objęci układem zbiorowym pracy, 
określi, w drodze rozporządzenia – w zakresie niezastrzeżonym w innych ustawach 
do właściwości innych organów – minister właściwy do spraw pracy na wniosek 
właściwego ministra. 

 
 
 
s. 59/195 
 
2025-08-06 
**§ 2.** Z dniem wejścia w życie układu zbiorowego pracy do pracowników 
państwowych jednostek sfery budżetowej objętych tym układem nie mają 
zastosowania przepisy rozporządzenia, o którym mowa w § 1. 
**§ 3.** Rozporządzenie, o którym mowa w § 1, powinno w szczególności 
określać warunki ustalania i wypłacania: 
- 1) wynagrodzenia zasadniczego pracowników; 
- 2) innych, poza wynagrodzeniem zasadniczym, składników uzasadnionych 
zwłaszcza szczególnymi właściwościami lub warunkami wykonywanej pracy, 
kwalifikacjami zawodowymi pracowników, z tym że wysokość składnika 
wynagrodzenia, którego przyznanie uwarunkowane będzie długością 
przepracowanego okresu, o ile taki składnik zostanie określony, nie może 
przekroczyć 20 % wynagrodzenia zasadniczego; 
- 3) innych świadczeń związanych z pracą, w tym takich, które mogą być 
uzależnione 
od 
okresów 
przepracowanych 
przez 
pracownika; 
w szczególności może to dotyczyć nagrody jubileuszowej i jednorazowej 
odprawy pieniężnej przysługującej pracownikowi, którego stosunek pracy 
ustał w związku z przejściem na rentę z tytułu niezdolności do pracy lub 
emeryturę.

***
## Art. 774. {#kp-trzeci-art-774}

(uchylony)

***
## Art. 775. {#kp-trzeci-art-775}

**§ 1.** Pracownikowi wykonującemu na polecenie pracodawcy 
zadanie służbowe poza miejscowością, w której znajduje się siedziba pracodawcy, 
lub poza stałym miejscem pracy przysługują należności na pokrycie kosztów 
związanych z podróżą służbową. 
**§ 2.** Minister właściwy do spraw pracy określi, w drodze rozporządzenia, 
wysokość oraz warunki ustalania należności przysługujących pracownikowi, 
zatrudnionemu w państwowej lub samorządowej jednostce sfery budżetowej, 
z tytułu podróży służbowej na obszarze kraju oraz poza granicami kraju. 
Rozporządzenie 
powinno 
w szczególności 
określać 
wysokość 
diet, 
z uwzględnieniem czasu trwania podróży, a w przypadku podróży poza granicami 
kraju – walutę, w jakiej będzie ustalana dieta i limit na nocleg w poszczególnych 
państwach, a także warunki zwrotu kosztów przejazdów, noclegów i innych 
wydatków. 

 
 
 
s. 60/195 
 
2025-08-06 
**§ 3.** Warunki 
wypłacania 
należności 
z tytułu 
podróży 
służbowej 
pracownikowi zatrudnionemu u innego pracodawcy niż wymieniony w § 2 określa 
się w układzie zbiorowym pracy lub w regulaminie wynagradzania albo w umowie 
o pracę, jeżeli pracodawca nie jest objęty układem zbiorowym pracy lub nie jest 
obowiązany do ustalenia regulaminu wynagradzania. 
**§ 4.** Postanowienia układu zbiorowego pracy, regulaminu wynagradzania lub 
umowy o pracę nie mogą ustalać diety za dobę podróży służbowej na obszarze kraju 
oraz poza granicami kraju w wysokości niższej niż dieta z tytułu podróży służbowej 
na obszarze kraju określona dla pracownika, o którym mowa w § 2. 
**§ 5.** W przypadku gdy układ zbiorowy pracy, regulamin wynagradzania lub 
umowa o pracę nie zawiera postanowień, o których mowa w § 3, pracownikowi 
przysługują należności na pokrycie kosztów podróży służbowej odpowiednio 
według przepisów, o których mowa w § 2. 
## Rozdział I a 
Wynagrodzenie za pracę

***
## Art. 78. {#kp-trzeci-art-78}

**§ 1.** Wynagrodzenie za pracę powinno być tak ustalone, aby 
odpowiadało w szczególności rodzajowi wykonywanej pracy i kwalifikacjom 
wymaganym przy jej wykonywaniu, a także uwzględniało ilość i jakość 
świadczonej pracy. 
**§ 2.** W celu określenia wynagrodzenia za pracę ustala się, w trybie 
przewidzianym w art. 771–773, wysokość oraz zasady przyznawania pracownikom 
stawek wynagrodzenia za pracę określonego rodzaju lub na określonym 
stanowisku, a także innych (dodatkowych) składników wynagrodzenia, jeżeli 
zostały one przewidziane z tytułu wykonywania określonej pracy.

***
## Art. 79. {#kp-trzeci-art-79}

(uchylony)

***
## Art. 80. {#kp-trzeci-art-80}

Wynagrodzenie przysługuje za pracę wykonaną. Za czas 
niewykonywania pracy pracownik zachowuje prawo do wynagrodzenia tylko 
wówczas, gdy przepisy prawa pracy tak stanowią.

***
## Art. 81. {#kp-trzeci-art-81}

**§ 1.** Pracownikowi za czas niewykonywania pracy, jeżeli był gotów 
do jej wykonywania, a doznał przeszkód z przyczyn dotyczących pracodawcy, 
przysługuje wynagrodzenie wynikające z jego osobistego zaszeregowania, 

 
 
 
s. 61/195 
 
2025-08-06 
 
określonego stawką godzinową lub miesięczną, a jeżeli taki składnik 
wynagrodzenia nie został wyodrębniony przy określaniu warunków wynagradzania 
– 60 % wynagrodzenia. W każdym przypadku wynagrodzenie to nie może być 
jednak niższe od wysokości minimalnego wynagrodzenia za pracę, ustalanego na 
podstawie odrębnych przepisów. 
**§ 2.** Wynagrodzenie, o którym mowa w § 1, przysługuje pracownikowi za 
czas niezawinionego przez niego przestoju. Jeżeli przestój nastąpił z winy 
pracownika, wynagrodzenie nie przysługuje. 
**§ 3.** Pracodawca może na czas przestoju powierzyć pracownikowi inną 
odpowiednią pracę, za której wykonanie przysługuje wynagrodzenie przewidziane 
za tę pracę, nie niższe jednak od wynagrodzenia ustalonego zgodnie z § 1. Jeżeli 
przestój nastąpił z winy pracownika, przysługuje wyłącznie wynagrodzenie 
przewidziane za wykonaną pracę. 
**§ 4.** Wynagrodzenie 
za 
czas 
przestoju 
spowodowanego 
warunkami 
atmosferycznymi przysługuje pracownikowi zatrudnionemu przy pracach 
uzależnionych od tych warunków, jeżeli przepisy prawa pracy tak stanowią. 
W razie powierzenia pracownikowi na czas takiego przestoju innej pracy, 
przysługuje mu wynagrodzenie przewidziane za wykonaną pracę, chyba że 
przepisy prawa pracy przewidują stosowanie zasad określonych w § 3.

***
## Art. 82. {#kp-trzeci-art-82}

**§ 1.** Za wadliwe wykonanie z winy pracownika produktów lub usług 
wynagrodzenie nie przysługuje. Jeżeli wskutek wadliwie wykonanej pracy z winy 
pracownika nastąpiło obniżenie jakości produktu lub usługi, wynagrodzenie ulega 
odpowiedniemu zmniejszeniu. 
**§ 2.** Jeżeli wadliwość produktu lub usługi została usunięta przez pracownika, 
przysługuje mu wynagrodzenie odpowiednie do jakości produktu lub usługi, z tym 
że za czas pracy przy usuwaniu wady wynagrodzenie nie przysługuje.

***
## Art. 83. {#kp-trzeci-art-83}

**§ 1.** Normy pracy, stanowiące miernik nakładu pracy, jej wydajności 
i jakości, mogą być stosowane, jeżeli jest to uzasadnione rodzajem pracy. 
**§ 2.** Normy pracy są ustalane z uwzględnieniem osiągniętego poziomu 
techniki i organizacji pracy. Normy pracy mogą być zmieniane w miarę wdrażania 
technicznych i organizacyjnych usprawnień zapewniających wzrost wydajności 
pracy. 

 
 
 
s. 62/195 
 
2025-08-06 
**§ 3.** Przekraczanie norm pracy nie stanowi podstawy do ich zmiany, jeżeli jest 
ono wynikiem zwiększonego osobistego wkładu pracy pracownika lub jego 
sprawności zawodowej. 
**§ 4.** O zmianie normy pracy pracownicy powinni być zawiadomieni co 
najmniej na 2 tygodnie przed wprowadzeniem nowej normy. 
## Rozdział II Ochrona wynagrodzenia za pracę

***
## Art. 84. {#kp-trzeci-art-84}

Pracownik nie może zrzec się prawa do wynagrodzenia ani przenieść 
tego prawa na inną osobę.

***
## Art. 85. {#kp-trzeci-art-85}

**§ 1.** Wypłaty wynagrodzenia za pracę dokonuje się co najmniej raz 
w miesiącu, w stałym i ustalonym z góry terminie. 
**§ 2.** Wynagrodzenie za pracę płatne raz w miesiącu wypłaca się z dołu, 
niezwłocznie po ustaleniu jego pełnej wysokości, nie później jednak niż w ciągu 
pierwszych 10 dni następnego miesiąca kalendarzowego. 
**§ 3.** Jeżeli ustalony dzień wypłaty wynagrodzenia za pracę jest dniem wolnym 
od pracy, wynagrodzenie wypłaca się w dniu poprzedzającym. 
**§ 4.** Składniki wynagrodzenia za pracę, przysługujące pracownikowi za 
okresy dłuższe niż jeden miesiąc, wypłaca się z dołu w terminach określonych 
w przepisach prawa pracy. 
**§ 5.** Pracodawca, na żądanie pracownika, jest obowiązany udostępnić do 
wglądu dokumenty, na których podstawie zostało obliczone jego wynagrodzenie.

***
## Art. 86. {#kp-trzeci-art-86}

**§ 1.** Pracodawca jest obowiązany wypłacać wynagrodzenie 
w miejscu, terminie i czasie określonych w regulaminie pracy lub w innych 
przepisach prawa pracy. 
**§ 2.** Wypłaty wynagrodzenia dokonuje się w formie pieniężnej; częściowe 
spełnienie wynagrodzenia w innej formie niż pieniężna jest dopuszczalne tylko 
wówczas, gdy przewidują to ustawowe przepisy prawa pracy lub układ zbiorowy 
pracy. 
**§ 3.** Wypłata wynagrodzenia jest dokonywana na wskazany przez pracownika 
rachunek płatniczy, chyba że pracownik złożył w postaci papierowej lub 
elektronicznej wniosek o wypłatę wynagrodzenia do rąk własnych. 

 
 
 
s. 63/195 
 
2025-08-06

***
## Art. 87. {#kp-trzeci-art-87}

**§ 1.** Z wynagrodzenia za pracę – po odliczeniu składek na 
ubezpieczenia społeczne, zaliczki na podatek 
dochodowy od osób fizycznych oraz wpłat dokonywanych do pracowniczego 
planu kapitałowego, w rozumieniu ustawy z dnia 4 października 2018 r. o 
pracowniczych planach kapitałowych (Dz. U. z 2024 r. poz. 427), jeżeli pracownik 
nie zrezygnował z ich dokonywania – podlegają potrąceniu tylko następujące 
należności: 
- 1) sumy egzekwowane na mocy tytułów wykonawczych na zaspokojenie 
świadczeń alimentacyjnych; 
- 2) sumy egzekwowane na mocy tytułów wykonawczych na pokrycie należności 
innych niż świadczenia alimentacyjne; 
- 3) zaliczki pieniężne udzielone pracownikowi; 
- 4) kary pieniężne przewidziane w art. 108. 
**§ 2.** Potrąceń dokonuje się w kolejności podanej w § 1. 
**§ 3.** Potrącenia mogą być dokonywane w następujących granicach: 
- 1) w razie egzekucji świadczeń alimentacyjnych – do wysokości trzech piątych 
wynagrodzenia; 
- 2) w razie egzekucji innych należności lub potrącania zaliczek pieniężnych – do 
wysokości połowy wynagrodzenia. 
**§ 4.** Potrącenia, o których mowa w § 1 pkt 2 i 3, nie mogą w sumie 
przekraczać połowy wynagrodzenia, a łącznie z potrąceniami, o których mowa 
w § 1 pkt 1 – trzech piątych wynagrodzenia. Niezależnie od tych potrąceń kary 
pieniężne potrąca się w granicach określonych w art. 108. 
**§ 5.** Nagroda z zakładowego funduszu nagród, dodatkowe wynagrodzenie 
roczne oraz należności przysługujące pracownikom z tytułu udziału w zysku lub 
w nadwyżce bilansowej podlegają egzekucji na zaspokojenie świadczeń 
alimentacyjnych do pełnej wysokości. 
**§ 6.** (uchylony) 
**§ 7.** Z wynagrodzenia za pracę odlicza się, w pełnej wysokości, kwoty 
wypłacone w poprzednim terminie płatności za okres nieobecności w pracy, za 
który pracownik nie zachowuje prawa do wynagrodzenia. 

 
 
 
s. 64/195 
 
2025-08-06 
**§ 8.** Potrąceń należności z wynagrodzenia pracownika w miesiącu, w którym 
są wypłacane składniki wynagrodzenia za okresy dłuższe niż 1 miesiąc, dokonuje 
się od łącznej kwoty wynagrodzenia uwzględniającej te składniki wynagrodzenia.

***
## Art. 871. {#kp-trzeci-art-871}

**§ 1.** Wolna od potrąceń jest kwota wynagrodzenia za pracę 
w wysokości: 
- 1) minimalnego wynagrodzenia za pracę, ustalanego na podstawie odrębnych 
przepisów, przysługującego pracownikom zatrudnionym w pełnym wymiarze 
czasu pracy, po odliczeniu składek na ubezpieczenia społeczne, zaliczki na 
podatek dochodowy od osób fizycznych oraz wpłat dokonywanych do 
pracowniczego planu kapitałowego, jeżeli pracownik nie zrezygnował z ich 
dokonywania – przy potrącaniu sum egzekwowanych na mocy tytułów 
wykonawczych na pokrycie należności innych niż świadczenia alimentacyjne; 
- 2) 75 % wynagrodzenia określonego w pkt 1 – przy potrącaniu zaliczek 
pieniężnych udzielonych pracownikowi; 
- 3) 90 % wynagrodzenia określonego w pkt 1 – przy potrącaniu kar pieniężnych 
przewidzianych w art. 108. 
**§ 2.** Jeżeli pracownik jest zatrudniony w niepełnym wymiarze czasu pracy, 
kwoty określone w § 1 ulegają zmniejszeniu proporcjonalnie do wymiaru czasu 
pracy.

***
## Art. 88. {#kp-trzeci-art-88}

**§ 1.** Przy zachowaniu zasad określonych w art. 87 potrąceń na 
zaspokojenie świadczeń alimentacyjnych pracodawca dokonuje również bez 
postępowania egzekucyjnego, z wyjątkiem przypadków gdy: 
- 1) świadczenia alimentacyjne mają być potrącane na rzecz kilku wierzycieli, 
a łączna suma, która może być potrącona, nie wystarcza na pełne pokrycie 
wszystkich należności alimentacyjnych; 
- 2) wynagrodzenie za pracę zostało zajęte w trybie egzekucji sądowej lub 
administracyjnej. 
**§ 2.** Potrąceń, o których mowa w § 1, pracodawca dokonuje na wniosek 
wierzyciela na podstawie przedłożonego przez niego tytułu wykonawczego.

***
## Art. 89. {#kp-trzeci-art-89}

(uchylony) 

 
 
 
s. 65/195 
 
2025-08-06

***
## Art. 90. {#kp-trzeci-art-90}

W sprawach 
nieunormowanych 
w art. 87 
i 88 stosuje 
się 
odpowiednio przepisy Kodeksu postępowania cywilnego i przepisy o egzekucji 
administracyjnej świadczeń pieniężnych.

***
## Art. 91. {#kp-trzeci-art-91}

**§ 1.** Należności inne niż wymienione w art. 87 § 1 i 7 mogą być 
potrącane z wynagrodzenia pracownika tylko za jego zgodą wyrażoną na piśmie. 
**§ 2.** W przypadkach określonych w § 1 wolna od potrąceń jest kwota 
wynagrodzenia za pracę w wysokości: 
- 1) określonej w art. 871 § 1 pkt 1 – przy potrącaniu należności na rzecz 
pracodawcy; 
- 2) 80 % kwoty określonej w art. 871 § 1 pkt 1 – przy potrącaniu innych 
należności niż określone w pkt 1. 
## Rozdział III Świadczenia przysługujące w okresie czasowej niezdolności do pracy

***
## Art. 92. {#kp-trzeci-art-92}

**§ 1.** Za czas niezdolności pracownika do pracy wskutek: 
- 1) choroby lub odosobnienia w związku z chorobą zakaźną – trwającej łącznie 
do 33 dni w ciągu roku kalendarzowego, a w przypadku pracownika, który 
ukończył 50 rok życia – trwającej łącznie do 14 dni w ciągu roku 
kalendarzowego – pracownik zachowuje prawo do 80 % wynagrodzenia, 
chyba że obowiązujące u danego pracodawcy przepisy prawa pracy 
przewidują wyższe wynagrodzenie z tego tytułu; 
- 2) wypadku w drodze do pracy lub z pracy albo choroby przypadającej w czasie 
ciąży – w okresie wskazanym w pkt 1 – pracownik zachowuje prawo do 
100 % wynagrodzenia; 
- 3) poddania się niezbędnym badaniom lekarskim przewidzianym dla 
kandydatów na dawców komórek, tkanek i narządów oraz poddania się 
zabiegowi pobrania komórek, tkanek i narządów – w okresie wskazanym 
w pkt 1 – pracownik zachowuje prawo do 100 % wynagrodzenia. 
**§ 11.** (uchylony) 
**§ 2.** Wynagrodzenie, o którym mowa w § 1, oblicza się według zasad 
obowiązujących przy ustalaniu podstawy wymiaru zasiłku chorobowego i wypłaca 
za każdy dzień niezdolności do pracy, nie wyłączając dni wolnych od pracy. 
**§ 3.** Wynagrodzenie, o którym mowa w § 1: 

 
 
 
s. 66/195 
 
2025-08-06 
- 1) nie ulega obniżeniu w przypadku ograniczenia podstawy wymiaru zasiłku 
chorobowego; 
- 2) nie przysługuje w przypadkach, w których pracownik nie ma prawa do zasiłku 
chorobowego. 
**§ 4.** Za czas niezdolności do pracy, o której mowa w § 1, trwającej łącznie 
dłużej niż 33 dni w ciągu roku kalendarzowego, a w przypadku pracownika, który 
ukończył 50 rok życia, trwającej łącznie dłużej niż 14 dni w ciągu roku 
kalendarzowego, pracownikowi przysługuje zasiłek chorobowy na zasadach 
określonych w odrębnych przepisach. 
**§ 5.** Przepisy § 1 pkt 1 i § 4 w części dotyczącej pracownika, który ukończył 
50 rok życia, dotyczą niezdolności pracownika do pracy przypadającej po roku 
kalendarzowym, w którym pracownik ukończył 50 rok życia. 
## Rozdział III a 
Odprawa rentowa lub emerytalna

***
## Art. 921. {#kp-trzeci-art-921}

**§ 1.** Pracownikowi spełniającemu warunki uprawniające do renty 
z tytułu niezdolności do pracy lub emerytury, którego stosunek pracy ustał 
w związku z przejściem na rentę lub emeryturę, przysługuje odprawa pieniężna w 
wysokości jednomiesięcznego wynagrodzenia. 
**§ 2.** Pracownik, który otrzymał odprawę, nie może ponownie nabyć do niej 
prawa. 
## Rozdział IV Odprawa pośmiertna

***
## Art. 93. {#kp-trzeci-art-93}

**§ 1.** W razie śmierci pracownika w czasie trwania stosunku pracy lub 
w czasie pobierania po jego rozwiązaniu zasiłku z tytułu niezdolności do pracy 
wskutek choroby, rodzinie przysługuje od pracodawcy odprawa pośmiertna. 
**§ 2.** Wysokość odprawy, o której mowa w § 1, jest uzależniona od okresu 
zatrudnienia pracownika u danego pracodawcy i wynosi: 
- 1) jednomiesięczne wynagrodzenie, jeżeli pracownik był zatrudniony krócej niż 
10 lat; 
- 2) trzymiesięczne wynagrodzenie, jeżeli pracownik był zatrudniony co najmniej 
10 lat; 

 
 
 
s. 67/195 
 
2025-08-06 
- 3) sześciomiesięczne wynagrodzenie, jeżeli pracownik był zatrudniony co 
najmniej 15 lat. 
**§ 3.** Przepis art. 36 § 11 stosuje się odpowiednio. 
**§ 4.** Odprawa pośmiertna przysługuje następującym członkom rodziny 
pracownika: 
- 1) małżonkowi; 
- 2) innym członkom rodziny spełniającym warunki wymagane do uzyskania 
renty rodzinnej w myśl przepisów o emeryturach i rentach z Funduszu 
Ubezpieczeń Społecznych. 
**§ 5.** Odprawę pośmiertną dzieli się w częściach równych pomiędzy 
wszystkich uprawnionych członków rodziny. 
**§ 6.** Jeżeli po zmarłym pracowniku pozostał tylko jeden członek rodziny 
uprawniony do odprawy pośmiertnej, przysługuje mu odprawa w wysokości 
połowy odpowiedniej kwoty określonej w § 2. 
**§ 7.** Odprawa pośmiertna nie przysługuje członkom rodziny, o których mowa 
w § 4, jeżeli pracodawca ubezpieczył pracownika na życie, a odszkodowanie 
wypłacone przez instytucję ubezpieczeniową jest nie niższe niż odprawa 
pośmiertna przysługująca zgodnie z § 2 i 6. Jeżeli odszkodowanie jest niższe od 
odprawy pośmiertnej, pracodawca jest obowiązany wypłacić rodzinie kwotę 
stanowiącą różnicę między tymi świadczeniami.

