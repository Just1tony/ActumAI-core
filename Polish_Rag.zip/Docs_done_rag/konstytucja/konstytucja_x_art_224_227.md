---
{
  "id": "konstytucja-rp-rozdzial-x-art-224-227",
  "title": "Konstytucja RP — Rozdział X: FINANSE PUBLICZNE (art. 224–227)",
  "source": "Dziennik Ustaw 1997 Nr 78 poz. 483 (tekst jednolity z późn. zm.)",
  "consolidation_date": "2015-01-07",
  "chapter": "Rozdział X — FINANSE PUBLICZNE",
  "articles": [
    224,
    225,
    226,
    227
  ],
  "anchors": [
    "art-224",
    "art-225",
    "art-226",
    "art-227"
  ],
  "version": 1
}
---

#### Art. 224 {#art-224}

1. Prezydent Rzeczyp ospolitej podpisuje w ciągu 7 dni ustawę 
budżetową albo ustawę o prowizorium budżetowym przedstawioną przez Marszałka 
Sejmu. Do ustawy budżetowej i ustawy o prowizorium budżetowym nie stosuje się 
przepisu art. 122 ust. 5.  
2. W przypadku zwrócenia się Prezy denta Rzeczypospolitej do Trybunału 
Konstytucyjnego w sprawie zgodności z Konstytucją ustawy budżetowej albo ustawy 
o prowizorium budżetowym przed jej podpisaniem, Trybunał orzeka w tej sprawie 
nie później niż w ciągu 2 miesięcy od dnia złożenia wniosku w Trybunale.

#### Art. 225 {#art-225}

Jeżeli w ciągu 4 miesięcy od dnia przedłożenia Sejmowi projektu 
ustawy budżetowej nie zostanie ona przedstawiona Prezydentowi Rzeczypospolitej do podpisu, Prezydent Rzeczypospolitej może w ciągu 14 dni zarządzić skrócenie 
kadencji Sejm u.

#### Art. 226 {#art-226}

1. Rada Ministrów w ciągu 5 miesięcy od zakończenia roku 
budżetowego przedkłada Sejmowi sprawozdanie z wykonania ustawy budżetowej 
wraz z informacją o stanie zadłużenia państwa.  
2. Sejm rozpatruje przedłożone sprawozdanie i po zapoznaniu się z  opinią 
Najwyższej Izby Kontroli podejmuje, w ciągu 90 dni od dnia przedłożenia Sejmowi sprawozdania, uchwałę o udzieleniu lub o odmowie udzielenia Radzie Ministrów 
absolutorium.

#### Art. 227 {#art-227}

1. Centralnym bankiem państwa jest Narodowy Bank Polski. 
Przysługuj e mu wyłączne prawo emisji pieniądza oraz ustalania i realizowania 
polityki pieniężnej. Narodowy Bank Polski odpowiada za wartość polskiego 
pieniądza.  
2. Organami Narodowego Banku Polskiego są: Prezes Narodowego Banku 
Polskiego, Rada Polityki Pieniężnej or az Zarząd Narodowego Banku Polskiego. 
3. Prezes Narodowego Banku Polskiego jest powoływany przez Sejm na 
wniosek Prezydenta Rzeczypospolitej na 6 lat.  
©Kancelaria Sejmu   s. 50/56 
2015- 01-07 4. Prezes Narodowego Banku  Polskiego nie może należeć do partii politycznej, 
związku zawodowego ani prowa dzić działalności publicznej nie dającej się pogodzić 
z godnością jego urzędu.  
5. W skład Rady Polityki Pieniężnej wchodzą Prezes Narodowego 
Banku Polskiego jako przewodniczący oraz osoby wyróżniające się wiedzą z zakresu 
finansów, powoływane na 6 lat, w r ównej liczbie przez Prezydenta Rzeczypospolitej, 
Sejm i Senat.  
6. Rada Polityki Pieniężnej ustala corocznie założenia polityki pieniężnej i 
przedkłada je do wiadomości Sejmowi równocześnie z przedłożeniem przez 
Radę Ministrów projektu ustawy budżetowej. Ra da Polityki Pieniężnej, w ciągu 5 
miesięcy od zakończenia roku budżetowego, składa Sejmowi sprawozdanie z 
wykonania założeń polityki pieniężnej.  
7. Organizację i zasady działania Narodowego Banku Polskiego oraz 
szczegółowe zasady powoływania i odwoływania jego organów określa ustawa.
