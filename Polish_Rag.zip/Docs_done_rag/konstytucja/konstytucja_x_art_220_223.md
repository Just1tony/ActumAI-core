---
{
  "id": "konstytucja-rp-rozdzial-x-art-220-223",
  "title": "Konstytucja RP — Rozdział X: FINANSE PUBLICZNE (art. 220–223)",
  "source": "Dziennik Ustaw 1997 Nr 78 poz. 483 (tekst jednolity z późn. zm.)",
  "consolidation_date": "2015-01-07",
  "chapter": "Rozdział X — FINANSE PUBLICZNE",
  "articles": [
    220,
    221,
    222,
    223
  ],
  "anchors": [
    "art-220",
    "art-221",
    "art-222",
    "art-223"
  ],
  "version": 1
}
---

#### Art. 220 {#art-220}

1. Zwiększenie wydatków lub ograniczenie dochodów planowanych 
przez Radę Ministrów nie może powodować ustalenia przez Sejm większego deficytu budżetowego niż przewidziany w projekcie usta wy budżetowej.  
2. Ustawa budżetowa nie może przewidywać pokrywania deficytu 
budżetowego przez zaciąganie zobowiązania w centralnym banku państwa.

#### Art. 221 {#art-221}

Inicjatywa ustawodawcza w zakresie ustawy budżetowej, ustawy o 
prowizorium budżetowym, zmiany ustawy  budżetowej, ustawy o zaciąganiu długu 
publicznego oraz ustawy o udzielaniu gwarancji finansowych przez państwo przysługuje wyłącznie Radzie Ministrów.  
©Kancelaria Sejmu   s. 49/56 
2015- 01-07

#### Art. 222 {#art-222}

Rada Ministrów przedkłada Sejmowi najpóźniej na 3 miesiące przed 
rozpoczęciem roku budżetowego projekt ustawy budżetowej na rok następny. W 
wyjątkowych przypadkach możliwe jest późniejsze przedłożenie projektu.

#### Art. 223 {#art-223}

Senat może uchwalić poprawki do ustawy budżetowej w ciągu 20 dni 
od dnia przekazania jej Senatowi.
