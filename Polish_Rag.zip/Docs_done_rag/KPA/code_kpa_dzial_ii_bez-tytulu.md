---
id: code.kpa.dzial.ii
title: "Kodeks postępowania administracyjnego — Dział II (—)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1960 nr 30 poz. 168"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KPA — Dział II"]
tags: ["KPA","Kodeks postępowania administracyjnego","Dział II","PL"]
source_pdf: "D19600168Lj.pdf"
articles: "Art. 61–163g"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpa-ii-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks postępowania administracyjnego — Dział II: —

Postępowanie 
Rozdział 1 
Wszczęcie postępowania
***
## Art. 61. {#kpa-ii-art-61}

**§ 1.** Postępowanie administracyjne wszczyna się na żądanie strony lub 
z urzędu. 
**§ 2.** Organ administracji publicznej może ze względu na szczególnie ważny 
interes strony wszcząć z urzędu postępowanie także w sprawie, w której przepis prawa 
wymaga wniosku strony. Organ obowiązany jest uzyskać na to zgodę strony w toku 
postępowania, a w razie nieuzyskania zgody – postępowanie umorzyć. 
**§ 3.** Datą wszczęcia postępowania na żądanie strony jest dzień doręczenia 
żądania organowi administracji publicznej. 
**§ 3a.** Datą wszczęcia postępowania na żądanie strony wniesione drogą 
elektroniczną jest dzień wystawienia dowodu otrzymania, o którym mowa w art. 41 
ustawy z dnia 18 listopada 2020 r. o doręczeniach elektronicznych. 
**§ 4.** O wszczęciu postępowania z urzędu lub na żądanie jednej ze stron należy 
zawiadomić wszystkie osoby będące stronami w sprawie. 
**§ 5.** Organ administracji publicznej przekazuje informacje, o których mowa 
w art. 13 ust. 1 i 2 rozporządzenia 2016/679, przy pierwszej czynności skierowanej do 
strony, chyba że strona posiada te informacje, a ich zakres lub treść nie uległy zmianie.

***
## Art. 61a. {#kpa-ii-art-61a}

**§ 1.** Gdy żądanie, o którym mowa w art. 61, zostało wniesione przez 
osobę niebędącą stroną lub z innych uzasadnionych przyczyn postępowanie nie może 
być wszczęte, organ administracji publicznej wydaje postanowienie o odmowie 
wszczęcia postępowania. Przepis art. 61 § 5 stosuje się odpowiednio. 
**§ 2.** Na postanowienie, o którym mowa w § 1, służy zażalenie.

***
## Art. 62. {#kpa-ii-art-62}

W sprawach, w których prawa lub obowiązki stron wynikają z tego 
samego stanu faktycznego oraz z tej samej podstawy prawnej i w których właściwy 

 
 
 
s. 27/89 
 
2025-08-27 
 
jest ten sam organ administracji publicznej, można wszcząć i prowadzić jedno 
postępowanie dotyczące więcej niż jednej strony.

***
## Art. 63. {#kpa-ii-art-63}

**§ 1.** Podania (żądania, wyjaśnienia, odwołania, zażalenia) wnosi się na 
piśmie, za pomocą telefaksu lub ustnie do protokołu. Podania utrwalone w postaci 
elektronicznej wnosi się na adres do doręczeń elektronicznych lub za pośrednictwem 
konta w systemie teleinformatycznym organu administracji publicznej. Jeżeli przepisy 
odrębne nie stanowią inaczej, podania wniesione na adres poczty elektronicznej 
organu administracji publicznej pozostawia się bez rozpoznania. 
**§ 2.** Podanie powinno zawierać co najmniej wskazanie osoby, od której pochodzi, 
jej adres, również w przypadku złożenia podania w postaci elektronicznej, i żądanie 
oraz czynić zadość innym wymaganiom ustalonym w przepisach szczególnych. 
**§ 3.** Podanie wniesione na piśmie albo ustnie do protokołu powinno być 
podpisane przez wnoszącego, a protokół ponadto przez pracownika, który go 
sporządził. Gdy podanie wnosi osoba, która nie może lub nie umie złożyć podpisu, 
podanie lub protokół podpisuje za nią inna osoba przez nią upoważniona, czyniąc 
o tym wzmiankę obok podpisu. 
**§ 3a.** Podanie wniesione na adres do doręczeń elektronicznych lub za 
pośrednictwem konta w systemie teleinformatycznym organu administracji publicznej 
zawiera dane w ustalonym formacie, zawartym we wzorze podania określonym 
w odrębnych przepisach, jeżeli te przepisy nakazują wnoszenie podań według 
określonego wzoru. 
**§ 3b.** (uchylony) 
**§ 4.** Organ administracji publicznej jest obowiązany potwierdzić wniesienie 
podania, jeżeli wnoszący tego zażąda.  
**§ 5.** (uchylony)

***
## Art. 64. {#kpa-ii-art-64}

**§ 1.** Jeżeli w podaniu nie wskazano adresu wnoszącego i nie ma 
możności ustalenia tego adresu na podstawie posiadanych danych, podanie pozostawia 
się bez rozpoznania. 
**§ 2.** Jeżeli podanie nie spełnia innych wymagań ustalonych w przepisach prawa, 
należy wezwać wnoszącego do usunięcia braków w wyznaczonym terminie, nie 
krótszym niż siedem dni, z pouczeniem, że nieusunięcie tych braków spowoduje 
pozostawienie podania bez rozpoznania. 

 
 
 
s. 28/89 
 
2025-08-27

***
## Art. 65. {#kpa-ii-art-65}

**§ 1.** Jeżeli organ administracji publicznej, do którego podanie 
wniesiono, jest niewłaściwy w sprawie, niezwłocznie przekazuje je do organu 
właściwego, zawiadamiając jednocześnie o tym wnoszącego podanie. Zawiadomienie 
o przekazaniu powinno zawierać uzasadnienie. 
**§ 1a.** Zawiadomienie o przekazaniu sprawy zawiera również informacje, 
o których mowa w art. 13 ust. 1 i 2 rozporządzenia 2016/679, w zakresie danych 
przetwarzanych przez organ przekazujący, chyba że wnoszący podanie posiada te 
informacje, a ich zakres lub treść nie uległy zmianie. 
**§ 2.** Podanie wniesione do organu niewłaściwego przed upływem przepisanego 
terminu uważa się za wniesione z zachowaniem terminu.

***
## Art. 66. {#kpa-ii-art-66}

**§ 1.** Jeżeli podanie dotyczy kilku spraw podlegających załatwieniu przez 
różne organy, organ administracji publicznej, do którego podanie wniesiono, uczyni 
przedmiotem rozpoznania sprawy należące do jego właściwości. Równocześnie 
zawiadomi wnoszącego podanie, że w sprawach innych powinien wnieść odrębne 
podanie do właściwego organu, i poinformuje go o treści § 2. Do zawiadomienia 
stosuje się odpowiednio przepis art. 65 § 1a. 
**§ 2.** Odrębne podanie złożone zgodnie z zawiadomieniem, o którym mowa 
w § 1, w terminie czternastu dni od daty doręczenia zawiadomienia uważa się za 
złożone w dniu wniesienia pierwszego podania. 
**§ 3.** Jeżeli podanie wniesiono do organu niewłaściwego, a organu właściwego 
nie można ustalić na podstawie danych podania, albo gdy z podania wynika, że 
właściwym w sprawie jest sąd powszechny, organ, do którego podanie wniesiono, 
zwraca je wnoszącemu. Zwrot podania następuje w drodze postanowienia, na które 
służy zażalenie. 
**§ 4.** Organ nie może jednak zwrócić podania z tej przyczyny, że właściwym 
w sprawie jest sąd powszechny, jeżeli w tej sprawie sąd uznał się już za niewłaściwy. 
Rozdział 2 
Metryki, protokoły i adnotacje

***
## Art. 66a. {#kpa-ii-art-66a}

**§ 1.** W aktach sprawy zakłada się metrykę sprawy. 
**§ 2.** W treści metryki sprawy wskazuje się wszystkie osoby, które uczestniczyły 
w podejmowaniu czynności w postępowaniu administracyjnym oraz określa się 

 
 
 
s. 29/89 
 
2025-08-27 
 
wszystkie podejmowane przez te osoby czynności wraz z odpowiednim odesłaniem 
do dokumentów określających te czynności. 
**§ 3.** Metryka sprawy, wraz z dokumentami do których odsyła, stanowi 
obowiązkową część akt sprawy i jest na bieżąco aktualizowana. 
**§ 4.** Minister właściwy do spraw administracji publicznej określa, w drodze 
rozporządzenia, wzór i sposób prowadzenia metryki sprawy, uwzględniając treść 
i formę metryki określoną w § 1 i 2 oraz obowiązek bieżącej aktualizacji metryki, 
a także, aby w oparciu o treść metryki było możliwe ustalenie treści czynności 
w postępowaniu administracyjnym podejmowanych w sprawie przez poszczególne 
osoby. 
**§ 5.** Minister właściwy do spraw administracji publicznej określa, w drodze 
rozporządzenia, rodzaje spraw, w których obowiązek prowadzenia metryki sprawy 
jest wyłączony ze względu na nieproporcjonalność nakładu środków koniecznych do 
prowadzenia metryki w stosunku do prostego i powtarzalnego charakteru tych spraw.

***
## Art. 67. {#kpa-ii-art-67}

**§ 1.** Organ administracji publicznej sporządza zwięzły protokół z każdej 
czynności postępowania, mającej istotne znaczenie dla rozstrzygnięcia sprawy, chyba 
że czynność została w inny sposób utrwalona na piśmie. 
**§ 2.** W szczególności sporządza się protokół: 
- 1) przyjęcia wniesionego ustnie podania; 
- 2) przesłuchania strony, świadka i biegłego; 
- 3) oględzin i ekspertyz dokonywanych przy udziale przedstawiciela organu 
administracji publicznej; 
- 4) rozprawy; 
- 5) ustnego ogłoszenia decyzji i postanowienia.

***
## Art. 68. {#kpa-ii-art-68}

**§ 1.** Protokół sporządza się tak, aby z niego wynikało, kto, kiedy, gdzie 
i jakich czynności dokonał, kto i w jakim charakterze był przy tym obecny, co i w jaki 
sposób w wyniku tych czynności ustalono i jakie uwagi zgłosiły obecne osoby. 
**§ 2.** Protokół odczytuje się wszystkim osobom obecnym, biorącym udział 
w czynności urzędowej, które powinny następnie protokół podpisać. Odmowę lub 
brak podpisu którejkolwiek osoby należy omówić w protokole.

***
## Art. 69. {#kpa-ii-art-69}

**§ 1.** Protokół przesłuchania powinien być odczytany i przedstawiony do 
podpisu osobie zeznającej niezwłocznie po złożeniu zeznania. 

 
 
 
s. 30/89 
 
2025-08-27 
**§ 2.** W protokołach przesłuchania osoby, która złożyła zeznanie w języku 
obcym, należy podać w przekładzie na język polski treść złożonego zeznania oraz 
wskazać osobę i adres tłumacza, który dokonał przekładu; tłumacz ten powinien 
podpisać protokół przesłuchania.

***
## Art. 70. {#kpa-ii-art-70}

Organ administracji publicznej może zezwolić na dołączenie do 
protokołu zeznania na piśmie, podpisanego przez zeznającego, oraz innych 
dokumentów mających znaczenie dla sprawy.

***
## Art. 71. {#kpa-ii-art-71}

Skreśleń i poprawek w protokole należy tak dokonywać, aby wyrazy 
skreślone i poprawione były czytelne. Skreślenia i poprawki powinny być stwierdzone 
w protokole przed jego podpisaniem.

***
## Art. 72. {#kpa-ii-art-72}

**§ 1.** Czynności organu administracji publicznej, z których nie sporządza 
się protokołu, a które mają znaczenie dla sprawy lub toku postępowania, utrwala się 
w aktach w formie adnotacji podpisanej przez pracownika, który dokonał tych 
czynności. 
**§ 2.** (uchylony) 
Rozdział 3 
Udostępnianie akt

***
## Art. 73. {#kpa-ii-art-73}

**§ 1.** Strona ma prawo wglądu w akta sprawy, sporządzania z nich 
notatek, kopii lub odpisów. Prawo to przysługuje również po zakończeniu 
postępowania. 
**§ 1a.** Czynności określone w § 1 są dokonywane w lokalu organu administracji 
publicznej w obecności pracownika tego organu. 
**§ 1b.** Wgląd w akta sprawy w przypadku, o którym mowa w art. 236 § 2, 
następuje z pominięciem danych osobowych osoby składającej skargę. 
**§ 2.** Strona może żądać uwierzytelnienia odpisów lub kopii akt sprawy lub 
wydania jej z akt sprawy uwierzytelnionych odpisów, o ile jest to uzasadnione 
ważnym interesem strony. 
**§ 3.** Organ administracji publicznej może zapewnić stronie dokonanie czynności, 
o których mowa w § 1, w swoim systemie teleinformatycznym, po uwierzytelnieniu 
strony w sposób określony w art. 20a ust. 1 albo 2 ustawy z dnia 17 lutego 2005 r. o 
informatyzacji działalności podmiotów realizujących zadania publiczne. 

 
 
 
s. 31/89 
 
2025-08-27

***
## Art. 74. {#kpa-ii-art-74}

**§ 1.** Przepisu art. 73 nie stosuje się do akt sprawy zawierających 
informacje niejawne o klauzuli tajności „tajne” lub „ściśle tajne”, a także do innych 
akt, które organ administracji publicznej wyłączy ze względu na ważny interes 
państwowy. 
**§ 2.** Odmowa umożliwienia stronie przeglądania akt sprawy, sporządzania z nich 
notatek, kopii i odpisów, uwierzytelnienia takich kopii i odpisów lub wydania 
uwierzytelnionych odpisów następuje w drodze postanowienia, na które służy 
zażalenie.

***
## Art. 74a. {#kpa-ii-art-74a}

Przepis art. 73 § 1 nie narusza prawa osoby, której dane dotyczą, do 
skorzystania z uprawnień wynikających z art. 15 rozporządzenia 2016/679. 
Rozdział 4 
Dowody

***
## Art. 75. {#kpa-ii-art-75}

**§ 1.** Jako dowód należy dopuścić wszystko, co może przyczynić się do 
wyjaśnienia sprawy, a nie jest sprzeczne z prawem. W szczególności dowodem mogą 
być dokumenty, zeznania świadków, opinie biegłych oraz oględziny. 
**§ 2.** Jeżeli przepis prawa nie wymaga urzędowego potwierdzenia określonych 
faktów lub stanu prawnego w drodze zaświadczenia właściwego organu administracji, 
organ administracji publicznej odbiera od strony, na jej wniosek, oświadczenie 
złożone pod rygorem odpowiedzialności za fałszywe zeznania. Przepis art. 83 
§ 3 stosuje się odpowiednio.

***
## Art. 76. {#kpa-ii-art-76}

**§ 1.** Dokumenty urzędowe sporządzone w przepisanej formie przez 
powołane do tego organy państwowe w ich zakresie działania stanowią dowód tego, 
co zostało w nich urzędowo stwierdzone. 
**§ 2.** Przepis § 1 stosuje się odpowiednio do dokumentów urzędowych 
sporządzanych przez organy jednostek organizacyjnych lub podmioty, w zakresie 
poruczonych im z mocy prawa lub porozumienia spraw wymienionych w art. 1 pkt 1 
i 4. 
**§ 3.** Przepisy § 1 i 2 nie wyłączają możliwości przeprowadzenia dowodu 
przeciwko treści dokumentów wymienionych w tych przepisach.

***
## Art. 76a. {#kpa-ii-art-76a}

**§ 1.** Jeżeli dokument znajduje się w aktach organu lub podmiotu, 
o którym mowa w art. 76 § 1 lub 2, wystarczy przedstawić urzędowo poświadczony 

 
 
 
s. 32/89 
 
2025-08-27 
 
przez ten organ lub podmiot odpis lub wyciąg z dokumentu. Organ administracji 
publicznej zażąda udzielenia odpisu lub wyciągu, jeżeli strona sama uzyskać ich nie 
może. Gdy organ uzna za konieczne przejrzenie oryginału dokumentu, może wystąpić 
o jego dostarczenie. 
**§ 2.** Zamiast oryginału dokumentu strona może złożyć odpis dokumentu, jeżeli 
jego zgodność z oryginałem została poświadczona przez notariusza albo przez 
występującego w sprawie pełnomocnika strony będącego adwokatem, radcą 
prawnym, rzecznikiem patentowym lub doradcą podatkowym. 
**§ 2a.** Jeżeli odpis dokumentu został sporządzony na piśmie utrwalonym w 
postaci elektronicznej, poświadczenia jego zgodności z oryginałem, o którym mowa 
w § 2, dokonuje się przy użyciu kwalifikowanego podpisu elektronicznego, podpisu 
zaufanego lub podpisu osobistego. Odpisy dokumentów poświadczane elektronicznie 
sporządzane są w formatach danych określonych w przepisach wydanych na 
podstawie art. 18 pkt 1 ustawy z dnia 17 lutego 2005 r. o informatyzacji działalności 
podmiotów realizujących zadania publiczne. 
**§ 2b.** Upoważniony pracownik organu prowadzącego postępowanie, któremu 
został okazany oryginał dokumentu wraz z odpisem, na żądanie strony, poświadcza 
zgodność odpisu dokumentu z oryginałem. Poświadczenie obejmuje podpis 
pracownika, datę i oznaczenie miejsca sporządzenia poświadczenia, a na żądanie 
strony, również godzinę sporządzenia poświadczenia. Jeżeli dokument zawiera cechy 
szczególne 
(dopiski, 
poprawki 
lub 
uszkodzenia), 
należy 
stwierdzić 
to 
w poświadczeniu. 
**§ 3.** Zawarte w odpisie dokumentu poświadczenie zgodności z oryginałem przez 
występującego w sprawie pełnomocnika strony będącego adwokatem, radcą 
prawnym, rzecznikiem patentowym lub doradcą podatkowym albo przez 
upoważnionego pracownika organu prowadzącego postępowanie ma charakter 
dokumentu urzędowego. 
**§ 4.** Jeżeli jest to uzasadnione okolicznościami sprawy, organ administracji 
publicznej zażąda od strony składającej odpis dokumentu, o którym mowa w § 2, 
przedłożenia oryginału tego dokumentu.

***
## Art. 77. {#kpa-ii-art-77}

**§ 1.** Organ administracji publicznej jest obowiązany w sposób 
wyczerpujący zebrać i rozpatrzyć cały materiał dowodowy. 

 
 
 
s. 33/89 
 
2025-08-27 
**§ 2.** Organ może w każdym stadium postępowania zmienić, uzupełnić lub 
uchylić swoje postanowienie dotyczące przeprowadzenia dowodu. 
**§ 3.** Organ przeprowadzający postępowanie na wezwanie organu właściwego do 
załatwienia sprawy (art. 52) może z urzędu lub na wniosek strony przesłuchać również 
nowych świadków i biegłych na okoliczności będące przedmiotem tego postępowania. 
**§ 4.** Fakty powszechnie znane oraz fakty znane organowi z urzędu nie wymagają 
dowodu. Fakty znane organowi z urzędu należy zakomunikować stronie.

***
## Art. 78. {#kpa-ii-art-78}

**§ 1.** Żądanie strony dotyczące przeprowadzenia dowodu należy 
uwzględnić, jeżeli przedmiotem dowodu jest okoliczność mająca znaczenie dla 
sprawy. 
**§ 2.** Organ administracji publicznej może nie uwzględnić żądania (§ 1), które nie 
zostało zgłoszone w toku przeprowadzania dowodów lub w czasie rozprawy, jeżeli 
żądanie to dotyczy okoliczności już stwierdzonych innymi dowodami, chyba że mają 
one znaczenie dla sprawy.

***
## Art. 79. {#kpa-ii-art-79}

**§ 1.** Strona powinna być zawiadomiona o miejscu i terminie 
przeprowadzenia dowodu ze świadków, biegłych lub oględzin przynajmniej na siedem 
dni przed terminem. 
**§ 2.** Strona ma prawo brać udział w przeprowadzeniu dowodu, może zadawać 
pytania świadkom, biegłym i stronom oraz składać wyjaśnienia.

***
## Art. 79a. {#kpa-ii-art-79a}

**§ 1.** W postępowaniu wszczętym na żądanie strony, informując o 
możliwości wypowiedzenia się co do zebranych dowodów i materiałów oraz 
zgłoszonych żądań, organ administracji publicznej jest obowiązany do wskazania 
przesłanek zależnych od strony, które nie zostały na dzień wysłania informacji 
spełnione lub wykazane, co może skutkować wydaniem decyzji niezgodnej z 
żądaniem strony. Przepisy art. 10 § 2 i 3 stosuje się. 
**§ 2.** W terminie wyznaczonym na wypowiedzenie się co do zebranych dowodów 
i materiałów oraz zgłoszonych żądań, strona może przedłożyć dodatkowe dowody 
celem wykazania spełnienia przesłanek, o których mowa w § 1.

***
## Art. 80. {#kpa-ii-art-80}

Organ administracji publicznej ocenia na podstawie całokształtu 
materiału dowodowego, czy dana okoliczność została udowodniona. 

 
 
 
s. 34/89 
 
2025-08-27

***
## Art. 81. {#kpa-ii-art-81}

Okoliczność faktyczna może być uznana za udowodnioną, jeżeli strona 
miała możność wypowiedzenia się co do przeprowadzonych dowodów, chyba że 
zachodzą okoliczności, o których mowa w art. 10 § 2.

***
## Art. 81a. {#kpa-ii-art-81a}

**§ 1.** Jeżeli przedmiotem postępowania administracyjnego jest 
nałożenie na stronę obowiązku bądź ograniczenie lub odebranie stronie uprawnienia, 
a w tym zakresie pozostają niedające się usunąć wątpliwości co do stanu faktycznego, 
wątpliwości te są rozstrzygane na korzyść strony. 
**§ 2.** Przepisu § 1 nie stosuje się: 
- 1) jeżeli w sprawie uczestniczą strony o spornych interesach lub wynik 
postępowania ma bezpośredni wpływ na interesy osób trzecich; 
- 2) jeżeli przepisy odrębne wymagają od strony wykazania określonych faktów; 
- 3) jeżeli wymaga tego ważny interes publiczny, w tym istotne interesy państwa, a 
w szczególności jego bezpieczeństwa, obronności lub porządku publicznego; 
- 4) w sprawach osobowych funkcjonariuszy oraz żołnierzy zawodowych.

***
## Art. 82. {#kpa-ii-art-82}

Świadkami nie mogą być: 
- 1) osoby niezdolne do spostrzegania lub komunikowania swych spostrzeżeń; 
- 2) osoby obowiązane do zachowania w tajemnicy informacji niejawnych na 
okoliczności objęte tajemnicą, jeżeli nie zostały w trybie określonym 
obowiązującymi przepisami zwolnione od obowiązku zachowania tej tajemnicy; 
- 3) duchowni co do faktów objętych tajemnicą spowiedzi.

***
## Art. 83. {#kpa-ii-art-83}

**§ 1.** Nikt nie ma prawa odmówić zeznań w charakterze świadka, 
z wyjątkiem małżonka strony, wstępnych, zstępnych i rodzeństwa strony oraz jej 
powinowatych pierwszego stopnia, jak również osób pozostających ze stroną 
w stosunku przysposobienia, opieki lub kurateli. Prawo odmowy zeznań trwa także po 
ustaniu małżeństwa, przysposobienia, opieki lub kurateli. 
**§ 2.** Świadek może odmówić odpowiedzi na pytania, gdy odpowiedź mogłaby 
narazić jego lub jego bliskich wymienionych w § 1 na odpowiedzialność karną, hańbę 
lub bezpośrednią szkodę majątkową albo spowodować naruszenie obowiązku 
zachowania prawnie chronionej tajemnicy zawodowej. 
**§ 3.** Przed odebraniem zeznania organ administracji publicznej uprzedza świadka 
o prawie odmowy zeznań i odpowiedzi na pytania oraz o odpowiedzialności za 
fałszywe zeznania. 

 
 
 
s. 35/89 
 
2025-08-27 
**§ 4.** Mediator nie może być przesłuchany w charakterze świadka co do faktów, o 
których dowiedział się w związku z prowadzeniem mediacji, chyba że uczestnicy 
mediacji zwolnią go od obowiązku zachowania tajemnicy mediacji.

***
## Art. 84. {#kpa-ii-art-84}

**§ 1.** Gdy w sprawie wymagane są wiadomości specjalne, organ 
administracji publicznej może zwrócić się do biegłego lub biegłych o wydanie opinii. 
**§ 2.** Biegły podlega wyłączeniu na zasadach i w trybie określonym w art. 24. 
Poza tym do biegłych stosuje się przepisy dotyczące przesłuchania świadków.

***
## Art. 85. {#kpa-ii-art-85}

**§ 1.** Organ 
administracji 
publicznej 
może 
w razie 
potrzeby 
przeprowadzić oględziny. 
**§ 2.** Jeżeli przedmiot oględzin znajduje się u osób trzecich, osoby te są 
obowiązane na wezwanie organu do okazania przedmiotu oględzin.

***
## Art. 86. {#kpa-ii-art-86}

Jeżeli po wyczerpaniu środków dowodowych lub z powodu ich braku 
pozostały niewyjaśnione fakty istotne dla rozstrzygnięcia sprawy, organ administracji 
publicznej dla ich wyjaśnienia może przesłuchać stronę. Do przesłuchania stron 
stosuje się przepisy dotyczące świadków, z wyłączeniem przepisów o środkach 
przymusu.

***
## Art. 87. {#kpa-ii-art-87}

Organ kolegialny, właściwy do wydania decyzji w sprawie, może zlecić 
przeprowadzenie postępowania dowodowego lub jego części jednemu ze swych 
członków lub pracowników, jeżeli szczególne przepisy temu się nie sprzeciwiają.

***
## Art. 88. {#kpa-ii-art-88}

**§ 1.** Kto, będąc obowiązany do osobistego stawienia się (art. 51), mimo 
prawidłowego wezwania nie stawił się bez uzasadnionej przyczyny jako świadek lub 
biegły albo bezzasadnie odmówił złożenia zeznania, wydania opinii, okazania 
przedmiotu oględzin albo udziału w innej czynności urzędowej, może być ukarany 
przez organ przeprowadzający dowód grzywną do 50 zł, a w razie ponownego 
niezastosowania się do wezwania – grzywną do 200 zł. Na postanowienie o ukaraniu 
grzywną służy zażalenie. 
**§ 2.** Organ, który nałożył karę grzywny, może na wniosek ukaranego, złożony 
w ciągu siedmiu dni od daty otrzymania zawiadomienia o ukaraniu, uznać za 
usprawiedliwioną nieobecność lub odmowę zeznania, wydania opinii albo okazania 
przedmiotu oględzin i zwolnić od kary grzywny. Na odmowę zwolnienia od kary służy 
zażalenie. 

 
 
 
s. 36/89 
 
2025-08-27 
**§ 3.** Ukaranie grzywną nie wyklucza możności zastosowania do opornego 
świadka środków przymusu przewidzianych w przepisach szczególnych.

***
## Art. 88a. {#kpa-ii-art-88a}

W razie uchybienia przez żołnierza w czynnej służbie wojskowej, z 
wyjątkiem terytorialnej służby wojskowej pełnionej dyspozycyjnie, obowiązkom, o 
których mowa w art. 88 § 1, organ przeprowadzający dowód, zamiast wymierzyć 
żołnierzowi karę grzywny, występuje do dowódcy jednostki wojskowej, w której 
żołnierz ten pełni służbę, z wnioskiem o pociągnięcie go do odpowiedzialności 
dyscyplinarnej. 
Rozdział 5 
Rozprawa

***
## Art. 89. {#kpa-ii-art-89}

**§ 1.** Organ administracji publicznej przeprowadzi, z urzędu lub na 
wniosek strony, w toku postępowania rozprawę, w każdym przypadku gdy zapewni to 
przyspieszenie lub uproszczenie postępowania lub gdy wymaga tego przepis prawa. 
**§ 2.** Organ powinien przeprowadzić rozprawę, gdy zachodzi potrzeba 
uzgodnienia interesów stron oraz gdy jest to potrzebne dla wyjaśnienia sprawy przy 
udziale świadków lub biegłych albo w drodze oględzin.

***
## Art. 90. {#kpa-ii-art-90}

**§ 1.** Organ administracji publicznej podejmuje przed rozprawą 
czynności niezbędne do jej przeprowadzenia. 
**§ 2.** W szczególności organ wzywa: 
- 1) strony do złożenia przed rozprawą wyjaśnień, dokumentów i innych dowodów 
i do stawienia się na rozprawę osobiście lub przez przedstawicieli albo 
pełnomocników; 
- 2) świadków i biegłych do stawienia się na rozprawę. 
**§ 3.** Ponadto organ zawiadamia o rozprawie państwowe i samorządowe 
jednostki organizacyjne, organizacje społeczne, a także inne osoby, jeżeli ich udział 
w rozprawie jest uzasadniony ze względu na jej przedmiot. W tym przypadku organ 
wzywa je do wzięcia udziału w rozprawie albo do złożenia przed rozprawą 
oświadczenia i dowodów dla jego poparcia.

***
## Art. 91. {#kpa-ii-art-91}

**§ 1.** W wezwaniu na rozprawę określa się termin, miejsce i przedmiot 
rozprawy. 

 
 
 
s. 37/89 
 
2025-08-27 
**§ 2.** Stronom, świadkom, biegłym oraz państwowym i samorządowym 
jednostkom organizacyjnym, organizacjom i innym osobom, wezwanym do udziału 
w rozprawie, doręcza się wezwanie na piśmie. 
**§ 3.** Jeżeli zachodzi prawdopodobieństwo, że oprócz wezwanych stron, 
uczestniczących w postępowaniu, mogą być jeszcze w sprawie inne strony, nieznane 
organowi administracji publicznej, należy ponadto o terminie, miejscu i przedmiocie 
rozprawy ogłosić w formie publicznego obwieszczenia, w innej formie publicznego 
ogłoszenia zwyczajowo przyjętej w danej miejscowości lub przez udostępnienie 
zawiadomienia w Biuletynie Informacji Publicznej na stronie podmiotowej 
właściwego organu administracji publicznej.

***
## Art. 92. {#kpa-ii-art-92}

Termin rozprawy powinien być tak wyznaczony, aby doręczenie 
wezwań oraz ogłoszenie o rozprawie nastąpiły przynajmniej na siedem dni przed 
rozprawą.

***
## Art. 93. {#kpa-ii-art-93}

Rozprawą kieruje wyznaczony do przeprowadzenia rozprawy 
pracownik tego organu administracji publicznej, przed którym toczy się postępowanie. 
Gdy postępowanie toczy się przed organem kolegialnym, rozprawą kieruje 
przewodniczący albo wyznaczony członek organu kolegialnego.

***
## Art. 93a. {#kpa-ii-art-93a}

Osoba pozbawiona wolności, która przebywa w zakładzie karnym lub 
areszcie śledczym, może brać udział w rozprawie przy użyciu urządzeń technicznych 
umożliwiających jej przeprowadzenie na odległość i tam dokonywać czynności. 
W miejscu przebywania osoby pozbawionej wolności w czynnościach bierze udział 
przedstawiciel administracji zakładu karnego lub aresztu śledczego oraz może wziąć 
udział pełnomocnik, jeżeli został ustanowiony, i tłumacz, jeżeli osoba pozbawiona 
wolności włada niedostatecznie językiem polskim.

***
## Art. 94. {#kpa-ii-art-94}

**§ 1.** Nieobecność na rozprawie stron należycie wezwanych na rozprawę 
nie stanowi przeszkody do jej przeprowadzenia. 
**§ 2.** Kierujący rozprawą odroczy ją, jeżeli stwierdzi poważne nieprawidłowości 
w wezwaniu stron na rozprawę, jeżeli niestawienie się strony zostało spowodowane 
przeszkodą trudną do przezwyciężenia, a także z innej ważnej przyczyny.

***
## Art. 95. {#kpa-ii-art-95}

**§ 1.** Na rozprawie strony mogą składać wyjaśnienia, zgłaszać żądania, 
propozycje i zarzuty oraz przedstawiać dowody na ich poparcie. Ponadto strony mogą 
wypowiadać się co do wyników postępowania dowodowego. 

 
 
 
s. 38/89 
 
2025-08-27 
**§ 2.** Kierujący rozprawą może uchylić zadawane świadkom, biegłym i stronom 
pytania, jeżeli nie mają one istotnego znaczenia dla sprawy. Jednakże na żądanie 
strony należy zamieścić w protokole osnowę treści uchylonego pytania.

***
## Art. 96. {#kpa-ii-art-96}

Za niewłaściwe zachowanie się w czasie rozprawy strony, świadkowie, 
biegli i inne osoby uczestniczące w rozprawie mogą być, po uprzednim ostrzeżeniu, 
wydalone z miejsca rozprawy przez kierującego rozprawą oraz ukarane grzywną do 
100 zł. Na postanowienie o ukaraniu grzywną służy zażalenie. 
Rozdział 5a 
Mediacja

***
## Art. 96a. {#kpa-ii-art-96a}

**§ 1.** W toku postępowania może być przeprowadzona mediacja, jeżeli 
pozwala na to charakter sprawy. 
**§ 1a.** Sprawą, której charakter pozwala na przeprowadzenie mediacji, jest 
w szczególności sprawa rozstrzygana w ramach uznania administracyjnego lub 
dotycząca: 
- 1) koncesji albo zezwolenia na prowadzenie działalności gospodarczej, albo wpisu 
do rejestru działalności regulowanej; 
- 2) budownictwa i architektury; 
- 3) zagospodarowania przestrzennego; 
- 4) ochrony środowiska i przyrody; 
- 5) nieruchomości; 
- 6) rolnictwa; 
- 7) leśnictwa; 
- 8) rybołówstwa; 
- 9) własności przemysłowej. 
**§ 1b.** Organ administracji publicznej jest obowiązany sporządzić i utrwalić 
w aktach sprawy adnotację zawierającą informację, czy: 
- 1) charakter sprawy pozwala na przeprowadzenie mediacji oraz 
- 2) zachodzą 
okoliczności 
odstąpienia 
od 
zawiadomienia 
o możliwości 
przeprowadzenia 
mediacji, 
mimo 
że 
charakter 
sprawy 
pozwala 
na 
przeprowadzenie mediacji.  
**§ 2.** Mediacja jest dobrowolna. 
 

 
 
 
s. 39/89 
 
2025-08-27 
**§ 3.** Celem mediacji jest wyjaśnienie i rozważenie okoliczności faktycznych i 
prawnych sprawy oraz dokonanie ustaleń dotyczących jej załatwienia w granicach 
obowiązującego prawa, w tym przez wydanie decyzji lub zawarcie ugody. 
**§ 4.** Uczestnikami mediacji mogą być: 
- 1) organ prowadzący postępowanie oraz strona lub strony tego postępowania albo 
- 2) strony postępowania.

***
## Art. 96b. {#kpa-ii-art-96b}

**§ 1.** Organ administracji publicznej, z urzędu lub na wniosek strony, 
zawiadamia strony oraz organ, o którym mowa w art. 106 § 1, w przypadku gdy ten 
organ nie zajął stanowiska, o możliwości przeprowadzenia mediacji.  Zawiadomienia 
o możliwości przeprowadzenia mediacji można dokonywać więcej niż raz oraz na 
każdym etapie postępowania.  
**§ 2.** We wniosku strona może wskazać mediatora. 
**§ 3.** W zawiadomieniu o możliwości przeprowadzenia mediacji organ 
administracji publicznej zwraca się do stron o: 
- 1) wyrażenie zgody na przeprowadzenie mediacji, 
- 2) wybranie mediatora 
– w terminie czternastu dni od dnia doręczenia zawiadomienia. 
**§ 4.** Zawiadomienie o możliwości przeprowadzenia mediacji zawiera pouczenie 
o zasadach, 
korzyściach 
i kosztach 
mediacji 
oraz 
możliwości 
ponawiania 
zawiadomienia na każdym etapie postępowania.   
**§ 5.** Organ administracji publicznej odstępuje od zawiadomienia o możliwości 
przeprowadzenia mediacji, jeżeli z okoliczności faktycznych i prawnych wynika, że: 
- 1) sprawa powinna być załatwiona niezwłocznie, w tym jeżeli wymaga tego ważny 
interes publiczny, lub 
- 2) przeprowadzenie mediacji zmierzałoby jedynie do przedłużenia postępowania.

***
## Art. 96c. {#kpa-ii-art-96c}

Mediacji nie przeprowadza się w przypadku niewyrażenia zgody na 
przeprowadzenie mediacji w terminie, o którym mowa w art. 96b § 3.

***
## Art. 96d. {#kpa-ii-art-96d}

**§ 1.** Jeżeli uczestnicy mediacji wyrazili zgodę na przeprowadzenie 
mediacji, organ administracji publicznej wydaje postanowienie o skierowaniu sprawy 
do mediacji. Postanowienie doręcza się stronom oraz organowi, o którym mowa w art. 
106 § 1. 

 
 
 
s. 40/89 
 
2025-08-27 
**§ 2.** W postanowieniu o skierowaniu sprawy do mediacji wskazuje się mediatora 
wybranego przez uczestników mediacji, a jeżeli uczestnicy mediacji nie wybrali 
mediatora, wskazuje się mediatora wybranego przez organ administracji publicznej, 
posiadającego odpowiednią wiedzę i umiejętności w zakresie prowadzenia mediacji w 
sprawach danego rodzaju.

***
## Art. 96e. {#kpa-ii-art-96e}

**§ 1.** Organ administracji publicznej, kierując sprawę do mediacji, 
odracza rozpatrzenie sprawy na okres do dwóch miesięcy. 
**§ 2.** Na zgodny wniosek uczestników mediacji lub z innych ważnych powodów 
termin określony w § 1 może zostać przedłużony, nie dłużej jednak niż o miesiąc. 
**§ 3.** W przypadku nieosiągnięcia celów mediacji określonych w art. 96a § 3 w 
terminie, o którym mowa w § 1 albo 2, organ administracji publicznej wydaje 
postanowienie o zakończeniu mediacji i załatwia sprawę.

***
## Art. 96f. {#kpa-ii-art-96f}

**§ 1.** Mediatorem może być osoba fizyczna, która posiada pełną 
zdolność do czynności prawnych i korzysta z pełni praw publicznych, w szczególności 
mediator wpisany na listę stałych mediatorów lub do wykazu instytucji i osób 
uprawnionych do prowadzenia postępowania mediacyjnego, prowadzonych przez 
prezesa sądu okręgowego, lub na listę prowadzoną przez organizację pozarządową lub 
uczelnię, o której informację przekazano prezesowi sądu okręgowego. 
**§ 2.** W przypadku gdy organ prowadzący postępowanie jest uczestnikiem 
mediacji, mediatorem może być wyłącznie osoba wpisana na listę stałych mediatorów 
lub do wykazu instytucji i osób uprawnionych do prowadzenia postępowania 
mediacyjnego, prowadzonych przez prezesa sądu okręgowego, lub mediator wpisany 
na listę prowadzoną przez organizację pozarządową lub uczelnię, o której informację 
przekazano prezesowi sądu okręgowego. 
**§ 3.** Mediatorem nie może być pracownik organu administracji publicznej, przed 
którym toczy się postępowanie w sprawie.

***
## Art. 96g. {#kpa-ii-art-96g}

**§ 1.** Mediator powinien zachować bezstronność przy prowadzeniu 
mediacji i niezwłocznie ujawnić okoliczności, które mogłyby wzbudzić wątpliwość co 
do jego bezstronności, w tym odpowiednio okoliczności, o których mowa w art. 24 § 
1 i 2. 

 
 
 
s. 41/89 
 
2025-08-27 
**§ 2.** Mediator odmawia przeprowadzenia mediacji w przypadku wątpliwości co 
do jego bezstronności i niezwłocznie zawiadamia o tym uczestników mediacji oraz 
organ administracji publicznej, jeżeli nie jest on uczestnikiem mediacji.

***
## Art. 96h. {#kpa-ii-art-96h}

Organ administracji publicznej niezwłocznie przekazuje mediatorowi 
dane kontaktowe uczestników mediacji oraz ich pełnomocników, w szczególności 
numery telefonów i adresy poczty elektronicznej, jeżeli je posiada.

***
## Art. 96i. {#kpa-ii-art-96i}

Mediator zapoznaje się z aktami sprawy i ma prawo sporządzania z nich 
notatek, kopii lub odpisów, chyba że uczestnik mediacji w terminie siedmiu dni od 
dnia ogłoszenia lub doręczenia postanowienia o skierowaniu sprawy do mediacji nie 
wyrazi zgody na zapoznanie się mediatora z aktami.

***
## Art. 96j. {#kpa-ii-art-96j}

**§ 1.** Mediacja nie jest jawna. 
**§ 2.** Mediator, uczestnicy mediacji i inne osoby biorące udział w mediacji są 
obowiązani zachować w tajemnicy wszelkie fakty, o których dowiedzieli się w 
związku z prowadzeniem mediacji, chyba że uczestnicy mediacji postanowią inaczej. 
**§ 3.** Propozycje ugodowe, ujawnione fakty lub oświadczenia złożone w toku 
mediacji nie mogą być wykorzystywane po jej zakończeniu, z wyjątkiem ustaleń 
zawartych w protokole z przebiegu mediacji.

***
## Art. 96k. {#kpa-ii-art-96k}

Mediator prowadzi mediację, dążąc do polubownego rozwiązania 
sporu, w tym przez wspieranie uczestników mediacji w formułowaniu przez nich 
propozycji ugodowych.

***
## Art. 96l. {#kpa-ii-art-96l}

**§ 1.** Mediator ma prawo do wynagrodzenia i zwrotu wydatków 
związanych z przeprowadzeniem mediacji, chyba że wyraził zgodę na prowadzenie 
mediacji bez wynagrodzenia. 
**§ 2.** Koszty wynagrodzenia i zwrotu wydatków związanych z przeprowadzeniem 
mediacji pokrywa organ administracji publicznej, a w sprawach, w których może być 
zawarta ugoda – strony w równych częściach, chyba że postanowią one inaczej. 
**§ 3.** Koszty mediacji są pokrywane niezwłocznie po jej zakończeniu.

***
## Art. 96m. {#kpa-ii-art-96m}

**§ 1.** Mediator sporządza protokół z przebiegu mediacji. 
**§ 2.** Protokół z przebiegu mediacji zawiera: 
- 1) czas i miejsce przeprowadzenia mediacji; 
- 2) imiona i nazwiska (nazwy) oraz adresy (siedziby) uczestników mediacji; 

 
 
 
s. 42/89 
 
2025-08-27 
- 3) imię i nazwisko oraz adres mediatora; 
- 4) dokonane ustalenia co do sposobu załatwienia sprawy; 
- 5) podpis mediatora oraz uczestników mediacji, a jeżeli którykolwiek z 
uczestników mediacji nie może podpisać protokołu, wzmiankę o przyczynie 
braku podpisu. 
**§ 3.** Mediator niezwłocznie przedkłada protokół z przebiegu mediacji organowi 
administracji publicznej w celu włączenia go do akt sprawy i doręcza odpis tego 
protokołu uczestnikom mediacji.

***
## Art. 96n. {#kpa-ii-art-96n}

**§ 1.** Jeżeli w wyniku mediacji zostaną dokonane ustalenia dotyczące 
załatwienia sprawy w granicach obowiązującego prawa, organ administracji 
publicznej załatwia sprawę zgodnie z tymi ustaleniami, zawartymi w protokole 
z przebiegu mediacji. 
**§ 2.** Do akt postępowania nie włącza się dokumentów i innych materiałów, które 
nie znajdują się w aktach postępowania, ujawnionych w toku mediacji przez jej 
uczestników, jeżeli te dokumenty i materiały nie stanowią podstawy do załatwienia 
sprawy zgodnie z ustaleniami zawartymi w protokole z przebiegu mediacji. 
Rozdział 6 
Zawieszenie postępowania

***
## Art. 97. {#kpa-ii-art-97}

**§ 1.** Organ administracji publicznej zawiesza postępowanie: 
- 1) w razie śmierci strony lub jednej ze stron, jeżeli wezwanie spadkobierców 
zmarłej strony albo zarządcy sukcesyjnego do udziału w postępowaniu nie jest 
możliwe i nie zachodzą okoliczności, o których mowa w art. 30 § 5, a postępo-
wanie nie podlega umorzeniu jako bezprzedmiotowe (art. 105); 
- 2) w razie śmierci przedstawiciela ustawowego strony; 
- 3) w razie utraty przez stronę lub przez jej ustawowego przedstawiciela zdolności 
do czynności prawnych; 
3a) w razie wygaśnięcia zarządu sukcesyjnego, gdy postępowanie toczyło się 
z udziałem zarządcy sukcesyjnego, jeżeli wezwanie spadkobierców zmarłego do 
udziału w postępowaniu nie jest możliwe i nie zachodzą okoliczności, o których 
mowa w art. 30 § 5, a postępowanie nie podlega umorzeniu jako 
bezprzedmiotowe (art. 105); 

 
 
 
s. 43/89 
 
2025-08-27 
- 4) gdy 
rozpatrzenie 
sprawy 
i wydanie 
decyzji 
zależy 
od 
uprzedniego 
rozstrzygnięcia zagadnienia wstępnego przez inny organ lub sąd; 
- 5) na wniosek Bankowego Funduszu Gwarancyjnego, w przypadku gdy stroną 
postępowania jest podmiot w restrukturyzacji, o którym mowa w art. 2 pkt 44 
ustawy z dnia 10 czerwca 2016 r. o Bankowym Funduszu Gwarancyjnym, 
systemie gwarantowania depozytów oraz przymusowej restrukturyzacji (Dz. U. 
z 2022 r. poz. 2253 oraz z 2023 r. poz. 825, 1705, 1784 i 1843). 
**§ 2.** Gdy ustąpią przyczyny uzasadniające zawieszenie postępowania, o których 
mowa w § 1 pkt 1–4, organ administracji publicznej podejmie postępowanie z urzędu 
lub na żądanie strony. 
**§ 3.** Organ administracji publicznej podejmie postępowanie, o którym mowa w 
§ 1 pkt 5, na wniosek Bankowego Funduszu Gwarancyjnego. 
**§ 4.** Jeżeli w okresie trzech lat od daty zawieszenia postępowania, wszczętego na 
żądanie strony, nie ustąpią przyczyny uzasadniające zawieszenie postępowania, 
o których mowa w § 1 pkt 1–3a, organ administracji publicznej może wydać decyzję 
o umorzeniu postępowania, o ile nie sprzeciwiają się temu pozostałe strony oraz nie 
zagraża to interesowi społecznemu. 
**§ 5.** Organ administracji publicznej, przed wydaniem decyzji o umorzeniu 
postępowania, wyznacza pozostałym stronom postępowania, innym niż wymienione 
w § 1 pkt 1–3a, siedmiodniowy termin na wniesienie sprzeciwu, licząc od dnia 
doręczenia pisma o możliwości wniesienia sprzeciwu w sprawie wydania decyzji 
o umorzeniu postępowania, o której mowa w § 4. 
**§ 6.** Organ 
administracji 
publicznej 
nie 
wydaje 
decyzji 
o umorzeniu 
postępowania w przypadku wniesienia sprzeciwu w terminie, o którym mowa w § 5, 
przez pozostałe strony postępowania, inne niż wymienione w § 1 pkt 1–3a, albo przez 
jedną z tych stron. 
**§ 7.** Decyzję o umorzeniu postępowania, o której mowa w § 4, pozostawia się 
w aktach sprawy ze skutkiem doręczenia stronom postępowania, o których mowa 
w § 1 pkt 1–3a.

***
## Art. 98. {#kpa-ii-art-98}

**§ 1.** Organ administracji publicznej może zawiesić postępowanie, jeżeli 
wystąpi o to strona, na której żądanie postępowanie zostało wszczęte, a nie 
sprzeciwiają się temu inne strony oraz nie zagraża to interesowi społecznemu. 

 
 
 
s. 44/89 
 
2025-08-27 
**§ 2.** Jeżeli w okresie trzech lat od daty zawieszenia postępowania żadna ze stron 
nie zwróci się o podjęcie postępowania, żądanie wszczęcia postępowania uważa się za 
wycofane.

***
## Art. 99. {#kpa-ii-art-99}

Organ administracji publicznej, który z przyczyny określonej w art. 97 
§ 1 pkt 1–3a zawiesił postępowanie wszczęte z urzędu, poczyni równocześnie 
niezbędne kroki w celu usunięcia przeszkody do dalszego prowadzenia postępowania. 
Tak samo postąpi organ w razie zawieszenia z tej samej przyczyny postępowania 
wszczętego na żądanie strony, jeżeli interes społeczny przemawia za załatwieniem 
sprawy.

***
## Art. 100. {#kpa-ii-art-100}

**§ 1.** Organ administracji publicznej, który zawiesił postępowanie 
z przyczyny określonej w art. 97 § 1 pkt 4, wystąpi równocześnie do właściwego 
organu lub sądu o rozstrzygnięcie zagadnienia wstępnego albo wezwie stronę do 
wystąpienia o to w oznaczonym terminie, chyba że strona wykaże, że już zwróciła się 
w tej sprawie do właściwego organu lub sądu. 
**§ 2.** Jeżeli zawieszenie postępowania z przyczyny określonej w art. 97 § 1 
pkt 4 mogłoby spowodować niebezpieczeństwo dla życia lub zdrowia ludzkiego albo 
poważną szkodę dla interesu społecznego, organ administracji publicznej załatwi 
sprawę, rozstrzygając zagadnienie wstępne we własnym zakresie. 
**§ 3.** Przepis § 2 stosuje się także wówczas, gdy strona mimo wezwania (§ 1) nie 
wystąpiła 
o rozstrzygnięcie 
zagadnienia 
wstępnego 
albo 
gdy 
zawieszenie 
postępowania mogłoby spowodować niepowetowaną szkodę dla strony. W tym 
ostatnim przypadku organ może uzależnić załatwienie sprawy od złożenia przez stronę 
stosownego zabezpieczenia.

***
## Art. 101. {#kpa-ii-art-101}

**§ 1.** O postanowieniu 
w sprawie 
zawieszenia 
albo 
podjęcia 
postępowania organ administracji publicznej zawiadamia strony. 
**§ 2.** W przypadku zawieszenia postępowania na żądanie strony lub jednej ze 
stron (art. 98 § 1) organ pouczy je o treści przepisu art. 98 § 2. 
**§ 3.** Na postanowienie w sprawie zawieszenia postępowania albo odmowy 
podjęcia zawieszonego postępowania służy stronie zażalenie.

***
## Art. 102. {#kpa-ii-art-102}

W czasie zawieszenia postępowania organ administracji publicznej 
może podejmować czynności niezbędne w celu zapobieżenia niebezpieczeństwu dla 
życia lub zdrowia ludzkiego albo poważnym szkodom dla interesu społecznego. 

 
 
 
s. 45/89 
 
2025-08-27

***
## Art. 103. {#kpa-ii-art-103}

Zawieszenie postępowania wstrzymuje bieg terminów przewidzianych 
w kodeksie. 
Rozdział 7 
Decyzje

***
## Art. 104. {#kpa-ii-art-104}

**§ 1.** Organ administracji publicznej załatwia sprawę przez wydanie 
decyzji, chyba że przepisy kodeksu stanowią inaczej. 
**§ 2.** Decyzje rozstrzygają sprawę co do jej istoty w całości lub w części albo 
w inny sposób kończą sprawę w danej instancji.

***
## Art. 105. {#kpa-ii-art-105}

**§ 1.** Gdy postępowanie z jakiejkolwiek przyczyny stało się 
bezprzedmiotowe w całości albo w części, organ administracji publicznej wydaje 
decyzję o umorzeniu postępowania odpowiednio w całości albo w części. 
**§ 2.** Organ administracji publicznej może umorzyć postępowanie, jeżeli wystąpi 
o to strona, na której żądanie postępowanie zostało wszczęte, a nie sprzeciwiają się 
temu inne strony oraz gdy nie jest to sprzeczne z interesem społecznym.

***
## Art. 106. {#kpa-ii-art-106}

**§ 1.** Jeżeli przepis prawa uzależnia wydanie decyzji od zajęcia 
stanowiska przez inny organ (wyrażenia opinii lub zgody albo wyrażenia stanowiska 
w innej formie), decyzję wydaje się po zajęciu stanowiska przez ten organ. 
**§ 2.** Organ załatwiający sprawę, zwracając się do innego organu o zajęcie 
stanowiska, zawiadamia o tym stronę. 
**§ 3.** Organ, do którego zwrócono się o zajęcie stanowiska, obowiązany jest 
przedstawić je niezwłocznie, jednak nie później niż w terminie dwóch tygodni od dnia 
doręczenia mu żądania, chyba że przepis prawa przewiduje inny termin. 
**§ 4.** Organ obowiązany do zajęcia stanowiska może w razie potrzeby 
przeprowadzić postępowanie wyjaśniające. 
**§ 5.** Zajęcie stanowiska przez ten organ następuje w drodze postanowienia, na 
które służy stronie zażalenie. 
**§ 6.** W przypadku niezajęcia stanowiska w terminie określonym w § 3 stosuje się 
przepisy art. 36–38, przy czym organ obowiązany do zajęcia stanowiska niezwłocznie 
informuje organ załatwiający sprawę o wniesieniu ponaglenia.

***
## Art. 106a. {#kpa-ii-art-106a}

**§ 1.** Organ załatwiający sprawę może, z urzędu albo na wniosek 
strony lub organu, do którego zwrócono się o zajęcie stanowiska, zwołać posiedzenie, 

 
 
 
s. 46/89 
 
2025-08-27 
 
jeżeli przyczyni się to do przyspieszenia zajęcia stanowiska (posiedzenie w trybie 
współdziałania). 
**§ 2.** Organ załatwiający sprawę może zwołać posiedzenie w trybie 
współdziałania przed upływem terminu do zajęcia stanowiska, określonego w art. 106 
§ 3, a jeżeli przepis prawa przewiduje inny termin, przed upływem tego terminu, tylko 
na wniosek organu, do którego zwrócono się o zajęcie stanowiska. 
**§ 3.** Organ załatwiający sprawę może wezwać strony na posiedzenie w trybie 
współdziałania. Przepisy art. 90–96 stosuje się odpowiednio. 
**§ 4.** Zwołanie posiedzenia w trybie współdziałania nie zwalnia z obowiązku 
rozpatrzenia ponaglenia, o którym mowa w art. 106 § 6. Postanowienie, o którym 
mowa w art. 106 § 5, może zostać wpisane do protokołu posiedzenia w trybie 
współdziałania.

***
## Art. 107. {#kpa-ii-art-107}

**§ 1.** Decyzja zawiera: 
- 1) oznaczenie organu administracji publicznej; 
- 2) datę wydania; 
- 3) oznaczenie strony lub stron; 
- 4) powołanie podstawy prawnej; 
- 5) rozstrzygnięcie; 
- 6) uzasadnienie faktyczne i prawne; 
- 7) pouczenie, czy i w jakim trybie służy od niej odwołanie oraz o prawie do 
zrzeczenia się odwołania i skutkach zrzeczenia się odwołania; 
- 8) podpis z podaniem imienia i nazwiska oraz stanowiska służbowego pracownika 
organu upoważnionego do wydania decyzji; 
- 9) w przypadku decyzji, w stosunku do której może być wniesione powództwo do 
sądu powszechnego, sprzeciw od decyzji lub skarga do sądu administracyjnego 
– pouczenie o dopuszczalności wniesienia powództwa, sprzeciwu od decyzji lub 
skargi oraz wysokości opłaty od powództwa lub wpisu od skargi lub sprzeciwu 
od decyzji, jeżeli mają one charakter stały, albo podstawie do wyliczenia opłaty 
lub wpisu o charakterze stosunkowym, a także możliwości ubiegania się przez 
stronę o zwolnienie od kosztów albo przyznanie prawa pomocy. 
**§ 2.** Przepisy szczególne mogą określać także inne składniki, które powinna 
zawierać decyzja. 

 
 
 
s. 47/89 
 
2025-08-27 
**§ 3.** Uzasadnienie faktyczne decyzji powinno w szczególności zawierać 
wskazanie faktów, które organ uznał za udowodnione, dowodów, na których się oparł, 
oraz przyczyn, z powodu których innym dowodom odmówił wiarygodności i mocy 
dowodowej, zaś uzasadnienie prawne – wyjaśnienie podstawy prawnej decyzji, 
z przytoczeniem przepisów prawa. 
**§ 4.** Można odstąpić od uzasadnienia decyzji, gdy uwzględnia ona w całości 
żądanie strony; nie dotyczy to jednak decyzji rozstrzygających sporne interesy stron 
oraz decyzji wydanych na skutek odwołania. 
**§ 5.** Organ może odstąpić od uzasadnienia decyzji również w przypadkach, 
w których 
z dotychczasowych 
przepisów 
ustawowych 
wynikała 
możliwość 
zaniechania lub ograniczenia uzasadnienia ze względu na interes bezpieczeństwa 
Państwa lub porządek publiczny.

***
## Art. 108. {#kpa-ii-art-108}

**§ 1.** Decyzji, od której służy odwołanie, może być nadany rygor 
natychmiastowej wykonalności, gdy jest to niezbędne ze względu na ochronę zdrowia 
lub życia ludzkiego albo dla zabezpieczenia gospodarstwa narodowego przed ciężkimi 
stratami bądź też ze względu na inny interes społeczny lub wyjątkowo ważny interes 
strony. W tym ostatnim przypadku organ administracji publicznej może w drodze 
postanowienia zażądać od strony stosownego zabezpieczenia. 
**§ 2.** Rygor natychmiastowej wykonalności może być nadany decyzji również po 
jej wydaniu. W tym przypadku organ wydaje postanowienie, na które służy stronie 
zażalenie.

***
## Art. 109. {#kpa-ii-art-109}

**§ 1.** Decyzję doręcza się stronom na piśmie. 
**§ 2.** W przypadkach wymienionych w art. 14 § 2 decyzja może być stronom 
ogłoszona ustnie. 
**§ 3.** Załączniki do decyzji wydanej w postaci papierowej mogą być doręczone na 
innym trwałym nośniku informacji za zgodą strony wyrażoną na piśmie albo ustnie do 
protokołu. 
**§ 4.** Przez trwały nośnik informacji rozumie się każdy nośnik informacji 
umożliwiający przechowywanie przez czas niezbędny, wynikający z charakteru 
informacji oraz celu ich sporządzenia lub przekazania, zawartych na nim informacji 
w sposób uniemożliwiający ich zmianę lub pozwalający na odtworzenie informacji 
w wersji i formie, w jakiej zostały sporządzone lub przekazane.  

 
 
 
s. 48/89 
 
2025-08-27

***
## Art. 110. {#kpa-ii-art-110}

**§ 1.** Organ administracji publicznej, który wydał decyzję, jest nią 
związany od chwili jej doręczenia lub ogłoszenia, o ile kodeks nie stanowi inaczej. 
**§ 2.** Organ administracji publicznej, w przypadku milczącego załatwienia 
sprawy, jest związany wydanym w tym trybie rozstrzygnięciem od dnia następującego 
po dniu, w którym upływa termin przewidziany na wydanie decyzji lub postanowienia 
kończącego postępowanie albo wniesienie sprzeciwu, o ile kodeks nie stanowi inaczej.

***
## Art. 111. {#kpa-ii-art-111}

**§ 1.** Strona może w terminie czternastu dni od dnia doręczenia lub 
ogłoszenia decyzji zażądać jej uzupełnienia co do rozstrzygnięcia bądź co do prawa 
odwołania, wniesienia w stosunku do decyzji powództwa do sądu powszechnego lub 
skargi do sądu administracyjnego albo sprostowania zamieszczonego w decyzji 
pouczenia w tych kwestiach. 
**§ 1a.** Organ administracji publicznej, który wydał decyzję, może ją uzupełnić lub 
sprostować z urzędu w zakresie, o którym mowa w § 1, w terminie czternastu dni od 
dnia doręczenia lub ogłoszenia decyzji. 
**§ 1b.** Uzupełnienie lub odmowa uzupełnienia decyzji następuje w formie 
postanowienia. 
**§ 2.** W przypadku wydania postanowienia, o którym mowa w § 1b, termin dla 
strony do wniesienia odwołania, powództwa lub skargi biegnie od dnia jego 
doręczenia lub ogłoszenia.

***
## Art. 112. {#kpa-ii-art-112}

Błędne pouczenie w decyzji co do prawa odwołania lub skutków 
zrzeczenia się odwołania albo wniesienia powództwa do sądu powszechnego lub 
skargi do sądu administracyjnego nie może szkodzić stronie, która zastosowała się do 
tego pouczenia.

***
## Art. 113. {#kpa-ii-art-113}

**§ 1.** Organ administracji publicznej może z urzędu lub na żądanie 
strony prostować w drodze postanowienia błędy pisarskie i rachunkowe oraz inne 
oczywiste omyłki w wydanych przez ten organ decyzjach. 
**§ 2.** Organ, który wydał decyzję, wyjaśnia w drodze postanowienia na żądanie 
organu egzekucyjnego lub strony wątpliwości co do treści decyzji. 
**§ 3.** Na postanowienie w sprawie sprostowania i wyjaśnienia służy zażalenie. 

 
 
 
s. 49/89 
 
2025-08-27 
 
Rozdział 8 
Ugoda

***
## Art. 114. {#kpa-ii-art-114}

W sprawie, w której toczy się postępowanie administracyjne, strony 
mogą zawrzeć ugodę, jeżeli charakter sprawy na to pozwala i nie sprzeciwiają się temu 
przepisy szczególne.

***
## Art. 115. {#kpa-ii-art-115}

Ugoda może być zawarta przed organem administracji publicznej, 
przed którym toczy się postępowanie w pierwszej instancji lub postępowanie 
odwoławcze, do czasu wydania przez organ decyzji w sprawie.

***
## Art. 116. {#kpa-ii-art-116}

**§ 1.** Organ administracji publicznej odroczy wydanie decyzji i 
wyznaczy stronom termin do zawarcia ugody, jeżeli istnieją przesłanki do jej zawarcia, 
pouczając strony o trybie i skutkach zawarcia ugody. 
**§ 2.** W przypadku zawiadomienia przez jedną ze stron o odstąpieniu od zamiaru 
zawarcia ugody lub niedotrzymania przez strony terminu wyznaczonego w myśl § 1, 
organ administracji publicznej załatwia sprawę w drodze decyzji.

***
## Art. 117. {#kpa-ii-art-117}

**§ 1.** Ugodę sporządza upoważniony pracownik organu administracji 
publicznej na piśmie, na podstawie zgodnych oświadczeń stron. 
**§ 1a.** Ugoda zawiera: 
- 1) oznaczenie organu administracji publicznej, przed którym ugoda została zawarta, 
i stron postępowania; 
- 2) datę sporządzenia ugody; 
- 3) przedmiot i treść ugody; 
- 4) podpisy stron oraz podpis upoważnionego pracownika organu administracji 
publicznej z podaniem imienia, nazwiska i stanowiska służbowego. 
**§ 2.** Przed podpisaniem ugody upoważniony pracownik organu administracji 
publicznej odczytuje stronom jej treść, chyba że ugoda została zawarta z 
wykorzystaniem środków komunikacji elektronicznej. Ugodę włącza się do akt 
sprawy.

***
## Art. 118. {#kpa-ii-art-118}

**§ 1.** Ugoda wymaga zatwierdzenia przez organ administracji 
publicznej, przed którym została zawarta. 
**§ 2.** Jeżeli ugoda dotyczy kwestii, których rozstrzygnięcie wymaga zajęcia 
stanowiska przez inny organ, stosuje się odpowiednio przepis art. 106. 

 
 
 
s. 50/89 
 
2025-08-27 
**§ 3.** Organ administracji publicznej odmówi zatwierdzenia ugody zawartej 
z naruszeniem prawa, nieuwzględniającej stanowiska organu, o którym mowa w § 2, 
albo naruszającej interes społeczny bądź słuszny interes stron.

***
## Art. 119. {#kpa-ii-art-119}

**§ 1.** Zatwierdzenie bądź odmowa zatwierdzenia ugody następuje 
w drodze postanowienia, na które służy zażalenie; postanowienie w tej sprawie 
powinno być wydane w ciągu siedmiu dni od dnia zawarcia ugody. 
**§ 2.** W przypadku 
gdy 
ugoda 
zawarta 
została 
w toku 
postępowania 
odwoławczego, z dniem, w którym stało się ostateczne postanowienie zatwierdzające 
ugodę, traci moc decyzja organu pierwszej instancji, o czym zamieszcza się wzmiankę 
w tym postanowieniu. 
**§ 3.** Łącznie z postanowieniem zatwierdzającym ugodę doręcza się stronom 
ugodę albo jej odpis.

***
## Art. 120. {#kpa-ii-art-120}

**§ 1.** Ugoda staje się wykonalna z dniem, w którym postanowienie o jej 
zatwierdzeniu stało się ostateczne. 
**§ 2.** (uchylony)

***
## Art. 121. {#kpa-ii-art-121}

Zatwierdzona ugoda wywiera takie same skutki, jak decyzja wydana 
w toku postępowania administracyjnego.

***
## Art. 121a. {#kpa-ii-art-121a}

Do ugody zawartej przed mediatorem przepisy art. 117–121 stosuje 
się odpowiednio.

***
## Art. 122. {#kpa-ii-art-122}

W sprawach nieuregulowanych w niniejszym rozdziale do ugody 
i postanowienia w sprawie jej zatwierdzenia lub odmowy zatwierdzenia stosuje się 
odpowiednio przepisy dotyczące decyzji. 
Rozdział 8a 
Milczące załatwienie sprawy

***
## Art. 122a. {#kpa-ii-art-122a}

**§ 1.** Sprawa może być załatwiona milcząco, jeżeli przepis szczególny 
tak stanowi. 
**§ 2.** Sprawę uznaje się za załatwioną milcząco w sposób w całości 
uwzględniający żądanie strony, jeżeli w terminie miesiąca od dnia doręczenia żądania 
strony właściwemu organowi administracji publicznej albo innym terminie 
określonym w przepisie szczególnym organ ten: 

 
 
 
s. 51/89 
 
2025-08-27 
- 1) nie wyda decyzji lub postanowienia kończącego postępowanie w sprawie 
(milczące zakończenie postępowania) albo 
- 2) nie wniesie sprzeciwu w drodze decyzji (milcząca zgoda).

***
## Art. 122b. {#kpa-ii-art-122b}

Za dzień 
wydania decyzji lub 
postanowienia kończącego 
postępowanie w sprawie, o której mowa w art. 122a § 2 pkt 1, albo wniesienia 
sprzeciwu, o którym mowa w art. 122a § 2 pkt 2, uznaje się dzień: 
- 1) nadania sprzeciwu, decyzji lub postanowienia kończącego postępowanie w 
sprawie za pokwitowaniem przez operatora pocztowego w rozumieniu ustawy z 
dnia 23 listopada 2012 r. – Prawo pocztowe albo 
- 2) doręczenia za pokwitowaniem sprzeciwu, decyzji lub postanowienia kończącego 
postępowanie w sprawie przez pracowników organu administracji publicznej lub 
inne upoważnione osoby, albo 
- 3) wprowadzenia sprzeciwu, decyzji lub postanowienia kończącego postępowanie 
w sprawie do systemu teleinformatycznego w przypadku, o którym mowa w art. 
391.

***
## Art. 122c. {#kpa-ii-art-122c}

**§ 1.** Milczące załatwienie sprawy następuje w dniu następującym po 
dniu, w którym upływa termin przewidziany do wydania decyzji lub postanowienia 
kończącego postępowanie w sprawie albo wniesienia sprzeciwu. W przypadku gdy 
organ przed upływem terminu do załatwienia sprawy zawiadomi stronę o braku 
sprzeciwu, milczące załatwienie sprawy następuje w dniu doręczenia tego 
zawiadomienia. 
**§ 2.** Jeżeli podanie nie spełnia wymagań wskazanych w przepisach lub jest 
konieczne doprecyzowanie treści żądania, stosuje się przepis art. 64. Termin, o którym 
mowa w art. 122a § 2, biegnie od dnia uzupełnienia braków lub doprecyzowania treści 
żądania. 
**§ 3.** Jeżeli w sprawie, która może być załatwiona milcząco, organ odwoławczy 
wydał decyzję na podstawie art. 138 § 2, termin, o którym mowa w art. 122a § 2, 
biegnie od dnia doręczenia organowi pierwszej instancji akt sprawy wraz z tą decyzją.

***
## Art. 122d. {#kpa-ii-art-122d}

**§ 1.** Do spraw załatwianych milcząco nie stosuje się przepisów art. 
10 i art. 79a. 
**§ 2.** Zawieszenie postępowania administracyjnego wstrzymuje bieg terminu, o 
którym mowa w art. 122a § 2. 

 
 
 
s. 52/89 
 
2025-08-27

***
## Art. 122e. {#kpa-ii-art-122e}

W aktach sprawy zamieszcza się adnotację o milczącym załatwieniu 
sprawy, wskazując treść rozstrzygnięcia oraz jego podstawę prawną.

***
## Art. 122f. {#kpa-ii-art-122f}

**§ 1.** Na wniosek strony organ administracji publicznej, w drodze 
postanowienia, wydaje zaświadczenie o milczącym załatwieniu sprawy albo odmawia 
wydania takiego zaświadczenia. 
**§ 2.** Na postanowienie, o którym mowa w § 1, przysługuje zażalenie. 
**§ 3.** Zaświadczenie o milczącym załatwieniu sprawy zawiera: 
- 1) oznaczenie organu administracji publicznej i strony lub stron postępowania; 
- 2) datę wydania zaświadczenia o milczącym załatwieniu sprawy; 
- 3) powołanie podstawy prawnej; 
- 4) treść rozstrzygnięcia sprawy załatwionej milcząco; 
- 5) datę milczącego załatwienia sprawy; 
- 6) pouczenie o możliwości wniesienia zażalenia; 
- 7) podpis z podaniem imienia i nazwiska oraz stanowiska służbowego pracownika 
organu upoważnionego do wydania zaświadczenia. 
**§ 4.** Zaświadczenie o milczącym załatwieniu sprawy doręcza się wszystkim 
stronom w sprawie załatwionej milcząco. 
**§ 5.** W zakresie nieuregulowanym w § 1–4 do zaświadczenia o milczącym 
załatwieniu sprawy stosuje się przepisy działu VII.

***
## Art. 122g. {#kpa-ii-art-122g}

Do spraw załatwionych milcząco przepisy rozdziałów 12 i 13 w 
dziale II stosuje się odpowiednio. Przyjmuje się, że skutek wydania decyzji ostatecznej 
powstał w terminie czternastu dni od dnia upływu terminu, o którym mowa w art. 122c 
**§ 1.** 

***
## Art. 122h. {#kpa-ii-art-122h}

**§ 1.** W sprawach załatwianych milcząco organ administracji 
publicznej udostępnia informacje, o których mowa w art. 13 ust. 1 i 2 rozporządzenia 
2016/679, w Biuletynie Informacji Publicznej na swojej stronie podmiotowej, 
na swojej stronie internetowej oraz w widocznym miejscu w swojej siedzibie. 
**§ 2.** Przekazanie informacji, o których mowa w art. 13 ust. 1 i 2 rozporządzenia 
2016/679, w sposób określony w § 1, nie zwalnia organu administracji publicznej 
z obowiązku ich przekazania przy pierwszej czynności skierowanej do strony. 

 
 
 
s. 53/89 
 
2025-08-27 
 
Rozdział 9 
Postanowienia

***
## Art. 123. {#kpa-ii-art-123}

**§ 1.** W toku postępowania organ administracji publicznej wydaje 
postanowienia. 
**§ 2.** Postanowienia dotyczą poszczególnych kwestii wynikających w toku 
postępowania, lecz nie rozstrzygają o istocie sprawy, chyba że przepisy kodeksu 
stanowią inaczej.

***
## Art. 124. {#kpa-ii-art-124}

**§ 1.** Postanowienie powinno zawierać: 
- 1) oznaczenie organu administracji publicznej; 
- 2) datę jego wydania; 
- 3) oznaczenie strony lub stron albo innych osób biorących udział w postępowaniu; 
- 4) powołanie podstawy prawnej; 
- 5) treść rozstrzygnięcia; 
- 6) pouczenie, czy i w jakim trybie służy: 
  - a) na nie zażalenie lub skarga do sądu administracyjnego, 
  - b) od niego sprzeciw; 
- 7) podpis z podaniem imienia i nazwiska oraz stanowiska służbowego osoby 
upoważnionej do wydania postanowienia. 
**§ 2.** Postanowienie powinno zawierać uzasadnienie faktyczne i prawne, jeżeli 
służy na nie zażalenie lub skarga do sądu administracyjnego lub służy od niego 
sprzeciw oraz gdy zostało wydane na skutek zażalenia na postanowienie.

***
## Art. 125. {#kpa-ii-art-125}

**§ 1.** Postanowienie, na które służy zażalenie lub skarga do sądu 
administracyjnego, oraz postanowienie, od którego służy sprzeciw, doręcza się na 
piśmie.   
**§ 2.** W przypadkach wymienionych w art. 14 § 2 postanowienia mogą być 
stronom ogłaszane ustnie. 
**§ 3.** Postanowienie, na które służy skarga do sądu administracyjnego, oraz 
postanowienie, od którego służy sprzeciw, doręcza się stronie wraz z pouczeniem 
o dopuszczalności wniesienia skargi albo sprzeciwu oraz uzasadnieniem faktycznym 
i prawnym.

***
## Art. 126. {#kpa-ii-art-126}

Do postanowień stosuje się odpowiednio przepisy art. 105, art. 107 
§ 2–5 oraz art. 109–113, a do postanowień, od których przysługuje zażalenie, oraz do 

 
 
 
s. 54/89 
 
2025-08-27 
 
postanowień określonych w art. 134 – również art. 145–152 oraz art. 156–159, z tym 
że zamiast decyzji, o której mowa w art. 151 § 1 i art. 158 § 1, wydaje się 
postanowienie. 
Rozdział 10 
Odwołania

***
## Art. 127. {#kpa-ii-art-127}

**§ 1.** Od decyzji wydanej w pierwszej instancji służy stronie odwołanie 
tylko do jednej instancji. 
**§ 1a.** Decyzja wydana w pierwszej instancji, od której uzasadnienia organ 
odstąpił z powodu uwzględnienia w całości żądania strony, jest ostateczna. 
**§ 2.** Właściwy do rozpatrzenia odwołania jest organ administracji publicznej 
wyższego stopnia, chyba że ustawa przewiduje inny organ odwoławczy. 
**§ 3.** Od decyzji wydanej w pierwszej instancji przez ministra lub samorządowe 
kolegium odwoławcze nie służy odwołanie, jednakże strona niezadowolona z decyzji 
może zwrócić się do tego organu z wnioskiem o ponowne rozpatrzenie sprawy; do 
wniosku tego stosuje się odpowiednio przepisy dotyczące odwołań od decyzji. 
**§ 4.** (uchylony)

***
## Art. 127a. {#kpa-ii-art-127a}

**§ 1.** Przed upływem terminu do wniesienia odwołania strona może 
zrzec się prawa do wniesienia odwołania wobec organu administracji publicznej, który 
wydał decyzję. 
**§ 2.** Z dniem doręczenia organowi administracji publicznej oświadczenia o 
zrzeczeniu się prawa do wniesienia odwołania przez ostatnią ze stron postępowania, 
decyzja staje się ostateczna i prawomocna.

***
## Art. 128. {#kpa-ii-art-128}

Odwołanie nie wymaga szczegółowego uzasadnienia. Wystarczy, 
jeżeli z odwołania wynika, że strona nie jest zadowolona z wydanej decyzji. Przepisy 
szczególne mogą ustalać inne wymogi co do treści odwołania.

***
## Art. 129. {#kpa-ii-art-129}

**§ 1.** Odwołanie wnosi się do właściwego organu odwoławczego za 
pośrednictwem organu, który wydał decyzję. 
**§ 2.** Odwołanie wnosi się w terminie czternastu dni od dnia doręczenia decyzji 
stronie, a gdy decyzja została ogłoszona ustnie – od dnia jej ogłoszenia stronie. 
**§ 3.** Przepisy szczególne mogą przewidywać inne terminy do wniesienia 
odwołania. 

 
 
 
s. 55/89 
 
2025-08-27

***
## Art. 130. {#kpa-ii-art-130}

**§ 1.** Przed upływem terminu do wniesienia odwołania decyzja nie 
ulega wykonaniu. 
**§ 2.** Wniesienie odwołania w terminie wstrzymuje wykonanie decyzji. 
**§ 3.** Przepisów § 1 i 2 nie stosuje się w przypadkach, gdy: 
- 1) decyzji został nadany rygor natychmiastowej wykonalności (art. 108); 
- 2) decyzja podlega natychmiastowemu wykonaniu z mocy ustawy. 
**§ 4.** Decyzja podlega wykonaniu przed upływem terminu do wniesienia 
odwołania, jeżeli jest zgodna z żądaniem wszystkich stron lub jeżeli wszystkie strony 
zrzekły się prawa do wniesienia odwołania.

***
## Art. 131. {#kpa-ii-art-131}

O wniesieniu odwołania organ administracji publicznej, który wydał 
decyzję, zawiadomi strony.

***
## Art. 132. {#kpa-ii-art-132}

**§ 1.** Jeżeli odwołanie wniosły wszystkie strony, a organ administracji 
publicznej, który wydał decyzję, uzna, że to odwołanie zasługuje w całości na 
uwzględnienie, może wydać nową decyzję, w której uchyli zaskarżoną decyzję 
w całości albo w części i w tym zakresie orzeka co do istoty sprawy albo uchyli tę 
decyzję i umorzy postępowanie w całości albo w części. 
**§ 2.** Przepis § 1 stosuje się także w przypadku, gdy odwołanie wniosła jedna ze 
stron, a pozostałe strony wyraziły zgodę na wydanie nowej decyzji.  
**§ 3.** Od nowej decyzji służy stronom odwołanie.

***
## Art. 133. {#kpa-ii-art-133}

Organ administracji publicznej, który wydał decyzję, obowiązany jest 
przesłać odwołanie wraz z aktami sprawy organowi odwoławczemu w terminie 
siedmiu dni od dnia, w którym otrzymał odwołanie, jeżeli w tym terminie nie wydał 
nowej decyzji w myśl art. 132.

***
## Art. 134. {#kpa-ii-art-134}

Organ 
odwoławczy 
stwierdza 
w drodze 
postanowienia 
niedopuszczalność odwołania oraz uchybienie terminu do wniesienia odwołania. 
Postanowienie w tej sprawie jest ostateczne.

***
## Art. 135. {#kpa-ii-art-135}

Organ odwoławczy może w uzasadnionych przypadkach wstrzymać 
natychmiastowe wykonanie decyzji.

***
## Art. 136. {#kpa-ii-art-136}

**§ 1.** Organ odwoławczy może przeprowadzić na żądanie strony lub 
z urzędu dodatkowe postępowanie w celu uzupełnienia dowodów i materiałów 

 
 
 
s. 56/89 
 
2025-08-27 
 
w sprawie albo zlecić przeprowadzenie tego postępowania organowi, który wydał 
decyzję. 
**§ 2.** Jeżeli decyzja została wydana z naruszeniem przepisów postępowania, a 
konieczny do wyjaśnienia zakres sprawy ma istotny wpływ na jej rozstrzygnięcie, na 
zgodny wniosek wszystkich stron zawarty w odwołaniu, organ odwoławczy 
przeprowadza postępowanie wyjaśniające w zakresie niezbędnym do rozstrzygnięcia 
sprawy. Jeżeli przyczyni się to do przyspieszenia postępowania, organ odwoławczy 
może zlecić przeprowadzenie określonych czynności postępowania wyjaśniającego 
organowi, który wydał decyzję. 
**§ 3.** Przepis § 2 stosuje się także w przypadku, gdy jedna ze stron zawarła w 
odwołaniu wniosek o przeprowadzenie przez organ odwoławczy postępowania 
wyjaśniającego w zakresie niezbędnym do rozstrzygnięcia sprawy, a pozostałe strony 
wyraziły na to zgodę w terminie czternastu dni od dnia doręczenia im zawiadomienia 
o wniesieniu odwołania, zawierającego wniosek o przeprowadzenie przez organ 
odwoławczy postępowania wyjaśniającego w zakresie niezbędnym do rozstrzygnięcia 
sprawy. 
**§ 4.** Przepisów § 2 i 3 nie stosuje się, jeżeli przeprowadzenie przez organ 
odwoławczy postępowania wyjaśniającego w zakresie niezbędnym do rozstrzygnięcia 
sprawy byłoby nadmiernie utrudnione.

***
## Art. 137. {#kpa-ii-art-137}

Strona może cofnąć odwołanie przed wydaniem decyzji przez organ 
odwoławczy. Organ odwoławczy nie uwzględni jednak cofnięcia odwołania, jeżeli 
prowadziłoby to do utrzymania w mocy decyzji naruszającej prawo lub interes 
społeczny.

***
## Art. 138. {#kpa-ii-art-138}

**§ 1.** Organ odwoławczy wydaje decyzję, w której: 
- 1) utrzymuje w mocy zaskarżoną decyzję albo 
- 2) uchyla zaskarżoną decyzję w całości albo w części i w tym zakresie orzeka co do 
istoty sprawy albo uchylając tę decyzję – umarza postępowanie pierwszej 
instancji w całości albo w części, albo 
- 3) umarza postępowanie odwoławcze. 
**§ 2.** Organ odwoławczy może uchylić zaskarżoną decyzję w całości i przekazać 
sprawę do ponownego rozpatrzenia organowi pierwszej instancji, gdy decyzja ta 
została wydana z naruszeniem przepisów postępowania, a konieczny do wyjaśnienia 

 
 
 
s. 57/89 
 
2025-08-27 
 
zakres sprawy ma istotny wpływ na jej rozstrzygnięcie. Przekazując sprawę, organ ten 
powinien wskazać, jakie okoliczności należy wziąć pod uwagę przy ponownym 
rozpatrzeniu sprawy. 
**§ 2a.** Jeżeli organ pierwszej instancji dokonał w zaskarżonej decyzji błędnej 
wykładni przepisów prawa, które mogą znaleźć zastosowanie w sprawie, w decyzji, o 
której mowa w § 2, organ odwoławczy określa także wytyczne w zakresie wykładni 
tych przepisów. 
**§ 2b.** Przepisu § 2 nie stosuje się w przypadkach, o których mowa w art. 136 § 2 
lub 3. Organ odwoławczy po przeprowadzeniu postępowania wyjaśniającego w 
zakresie niezbędnym do rozstrzygnięcia sprawy wydaje decyzję, o której mowa w § 1 
albo 4. 
**§ 3.** (uchylony) 
**§ 4.** Jeżeli przepisy przewidują wydanie decyzji na blankiecie urzędowym, 
a istnieją podstawy do zmiany zaskarżonej decyzji, organ odwoławczy uchyla decyzję 
i zobowiązuje organ pierwszej instancji do wydania decyzji o określonej treści.

***
## Art. 139. {#kpa-ii-art-139}

Organ odwoławczy nie może wydać decyzji na niekorzyść strony 
odwołującej się, chyba że zaskarżona decyzja rażąco narusza prawo lub rażąco narusza 
interes społeczny.

***
## Art. 139a. {#kpa-ii-art-139a}

**§ 1.** W przypadkach, o których mowa w art. 138 § 2 i 2a, przy 
ponownym rozpatrzeniu sprawy organ pierwszej instancji jest obowiązany wziąć pod 
uwagę okoliczności wskazane przez organ odwoławczy oraz jest związany 
wytycznymi tego organu określonymi w decyzji uchylającej zaskarżoną decyzję 
w całości i przekazującej sprawę do ponownego rozpatrzenia, chyba że przy 
ponownym rozpatrzeniu sprawy przepisy prawa, na podstawie których organ 
pierwszej instancji rozstrzygnął sprawę, uległy zmianie. 
**§ 2.** Organ odwoławczy przy rozpatrywaniu odwołania wniesionego od decyzji 
organu pierwszej instancji wydanej po ponownym rozpatrzeniu sprawy, w przypadku 
stwierdzenia naruszenia obowiązku, o którym mowa w § 1, przez organ pierwszej 
instancji polegającego na odstąpieniu od: 
- 1) wskazanych przez organ odwoławczy okoliczności, które należy wziąć pod 
uwagę przy ponownym rozpatrzeniu sprawy, o których mowa w art. 138 § 2 
zdanie drugie, lub 

 
 
 
s. 58/89 
 
2025-08-27 
- 2) określonych przez organ odwoławczy wytycznych w zakresie wykładni 
przepisów prawa, które mogą znaleźć zastosowanie w sprawie, o których mowa 
w art. 138 § 2a 
– może zarządzić wyjaśnienie przez organ pierwszej instancji przyczyn naruszenia 
tego obowiązku, a w razie potrzeby – także podjęcie środków zapobiegających 
naruszeniu tego obowiązku w przyszłości.

***
## Art. 140. {#kpa-ii-art-140}

W sprawach nieuregulowanych w art. 136–139 w postępowaniu przed 
organami odwoławczymi mają odpowiednie zastosowanie przepisy o postępowaniu 
przed organami pierwszej instancji. 
Rozdział 11 
Zażalenia

***
## Art. 141. {#kpa-ii-art-141}

**§ 1.** Na wydane w toku postępowania postanowienia służy stronie 
zażalenie, gdy kodeks tak stanowi. 
**§ 2.** Zażalenia wnosi się w terminie siedmiu dni od dnia doręczenia 
postanowienia stronie, a gdy postanowienie zostało ogłoszone ustnie – od dnia jego 
ogłoszenia stronie.

***
## Art. 142. {#kpa-ii-art-142}

Postanowienie, na które nie służy zażalenie, strona może zaskarżyć 
tylko w odwołaniu od decyzji.

***
## Art. 143. {#kpa-ii-art-143}

Wniesienie zażalenia nie wstrzymuje wykonania postanowienia, 
jednakże organ administracji publicznej, który wydał postanowienie, może wstrzymać 
jego wykonanie, gdy uzna to za uzasadnione.

***
## Art. 144. {#kpa-ii-art-144}

W sprawach nieuregulowanych w niniejszym rozdziale do zażaleń 
mają odpowiednie zastosowanie przepisy dotyczące odwołań. 
Rozdział 12 
Wznowienie postępowania

***
## Art. 145. {#kpa-ii-art-145}

**§ 1.** W sprawie zakończonej decyzją ostateczną wznawia się 
postępowanie, jeżeli: 
- 1) dowody, na których podstawie ustalono istotne dla sprawy okoliczności 
faktyczne, okazały się fałszywe; 
- 2) decyzja wydana została w wyniku przestępstwa; 

 
 
 
s. 59/89 
 
2025-08-27 
- 3) decyzja wydana została przez pracownika lub organ administracji publicznej, 
który podlega wyłączeniu stosownie do art. 24, 25 i 27; 
- 4) strona bez własnej winy nie brała udziału w postępowaniu; 
- 5) wyjdą na jaw istotne dla sprawy nowe okoliczności faktyczne lub nowe dowody 
istniejące w dniu wydania decyzji, nieznane organowi, który wydał decyzję; 
- 6) decyzja wydana została bez uzyskania wymaganego prawem stanowiska innego 
organu; 
- 7) zagadnienie wstępne zostało rozstrzygnięte przez właściwy organ lub sąd 
odmiennie od oceny przyjętej przy wydaniu decyzji (art. 100 § 2); 
- 8) decyzja została wydana w oparciu o inną decyzję lub orzeczenie sądu, które 
zostało następnie uchylone lub zmienione. 
**§ 2.** Z przyczyn określonych w § 1 pkt 1 i 2 postępowanie może być wznowione 
również przed stwierdzeniem sfałszowania dowodu lub popełnienia przestępstwa 
orzeczeniem sądu lub innego organu, jeżeli sfałszowanie dowodu lub popełnienie 
przestępstwa jest oczywiste, a wznowienie postępowania jest niezbędne dla uniknięcia 
niebezpieczeństwa dla życia lub zdrowia ludzkiego albo poważnej szkody dla interesu 
społecznego. 
**§ 3.** Z przyczyn określonych w § 1 pkt 1 i 2 można wznowić postępowanie także 
w przypadku, gdy postępowanie przed sądem lub innym organem nie może być 
wszczęte na skutek upływu czasu lub z innych przyczyn określonych w przepisach 
prawa.

***
## Art. 145a. {#kpa-ii-art-145a}

**§ 1.** Można żądać wznowienia postępowania również w przypadku, 
gdy 
Trybunał 
Konstytucyjny 
orzekł 
o niezgodności 
aktu 
normatywnego 
z Konstytucją, umową międzynarodową lub z ustawą, na podstawie którego została 
wydana decyzja. 
**§ 2.** W sytuacji określonej w § 1 skargę o wznowienie wnosi się w terminie 
jednego miesiąca od dnia wejścia w życie orzeczenia Trybunału Konstytucyjnego. 
Art. 145aa. § 1. Można żądać wznowienia postępowania również w przypadku, 
gdy zostało wydane orzeczenie Trybunału Sprawiedliwości Unii Europejskiej, które 
ma wpływ na treść wydanej decyzji.  
**§ 2.** W sytuacji określonej w § 1 skargę o wznowienie wnosi się w terminie 
jednego miesiąca od dnia publikacji sentencji orzeczenia Trybunału Sprawiedliwości 
Unii Europejskiej w Dzienniku Urzędowym Unii Europejskiej. 

 
 
 
s. 60/89 
 
2025-08-27

***
## Art. 145b. {#kpa-ii-art-145b}

**§ 1.** Można żądać wznowienia postępowania również w przypadku, 
gdy zostało wydane orzeczenie sądu stwierdzające naruszenie zasady równego 
traktowania, zgodnie z ustawą z dnia 3 grudnia 2010 r. o wdrożeniu niektórych 
przepisów Unii Europejskiej w zakresie równego traktowania (Dz. U. z 2023 r. poz. 
970), jeżeli naruszenie tej zasady miało wpływ na rozstrzygnięcie sprawy zakończonej 
decyzją ostateczną. 
**§ 2.** W sytuacji określonej w § 1 skargę o wznowienie wnosi się w terminie 
jednego miesiąca od dnia uprawomocnienia się orzeczenia sądu.

***
## Art. 146. {#kpa-ii-art-146}

**§ 1.** Uchylenie decyzji z przyczyn określonych w art. 145 § 1 pkt 1 i 2 
nie może nastąpić, jeżeli od dnia doręczenia lub ogłoszenia decyzji upłynęło dziesięć 
lat, zaś z przyczyn określonych w art. 145 § 1 pkt 3–8 oraz w art. 145a–145b, jeżeli od 
dnia doręczenia lub ogłoszenia decyzji upłynęło pięć lat. 
**§ 2.** Nie uchyla się decyzji także w przypadku, jeżeli w wyniku wznowienia 
postępowania mogłaby zapaść wyłącznie decyzja odpowiadająca w swej istocie 
decyzji dotychczasowej.

***
## Art. 147. {#kpa-ii-art-147}

Wznowienie postępowania następuje z urzędu lub na żądanie strony. 
Wznowienie postępowania z przyczyny określonej w art. 145 § 1 pkt 4 oraz art. 145a–
145b następuje tylko na żądanie strony.

***
## Art. 148. {#kpa-ii-art-148}

**§ 1.** Podanie o wznowienie postępowania wnosi się do organu 
administracji publicznej, który wydał w sprawie decyzję w pierwszej instancji, 
w terminie jednego miesiąca od dnia, w którym strona dowiedziała się o okoliczności 
stanowiącej podstawę do wznowienia postępowania. 
**§ 2.** Termin do złożenia podania o wznowienie postępowania z przyczyny 
określonej w art. 145 § 1 pkt 4 biegnie od dnia, w którym strona dowiedziała się 
o decyzji.

***
## Art. 149. {#kpa-ii-art-149}

**§ 1.** Wznowienie postępowania następuje w drodze postanowienia. 
**§ 2.** Postanowienie stanowi podstawę do przeprowadzenia przez właściwy organ 
postępowania co do przyczyn wznowienia oraz co do rozstrzygnięcia istoty sprawy. 
**§ 3.** Odmowa wznowienia postępowania następuje w drodze postanowienia. 
**§ 4.** Na postanowienie, o którym mowa w § 3, służy zażalenie. 

 
 
 
s. 61/89 
 
2025-08-27

***
## Art. 150. {#kpa-ii-art-150}

**§ 1.** Organem administracji publicznej właściwym w sprawach 
wymienionych w art. 149 jest organ, który wydał w sprawie decyzję w ostatniej 
instancji. 
**§ 2.** Jeżeli przyczyną wznowienia postępowania jest działalność organu 
wymienionego w § 1, o wznowieniu postępowania rozstrzyga organ wyższego 
stopnia, który równocześnie wyznacza organ właściwy w sprawach wymienionych 
w art. 149 § 2. 
**§ 3.** Przepis § 2 nie dotyczy przypadków, gdy decyzję w ostatniej instancji wydał 
minister, a w sprawach należących do zadań jednostek samorządu terytorialnego – 
samorządowe kolegium odwoławcze.

***
## Art. 151. {#kpa-ii-art-151}

**§ 1.** Organ administracji publicznej, o którym mowa w art. 150, po 
przeprowadzeniu postępowania określonego w art. 149 § 2 wydaje decyzję, w której: 
- 1) odmawia uchylenia decyzji dotychczasowej, gdy stwierdzi brak podstaw do jej 
uchylenia na podstawie art. 145 § 1, art. 145a, art. 145aa lub art. 145b, albo 
- 2) uchyla decyzję dotychczasową, gdy stwierdzi istnienie podstaw do jej uchylenia 
na podstawie art. 145 § 1, art. 145a, art. 145aa lub art. 145b, i wydaje nową 
decyzję rozstrzygającą o istocie sprawy. 
**§ 2.** W przypadku gdy w wyniku wznowienia postępowania nie można uchylić 
decyzji na skutek okoliczności, o których mowa w art. 146, organ administracji 
publicznej ograniczy się do stwierdzenia wydania zaskarżonej decyzji z naruszeniem 
prawa oraz wskazania okoliczności, z powodu których nie uchylił tej decyzji. 
**§ 3.** W sprawach, o których mowa w § 1, przepisów o milczącym załatwieniu 
sprawy nie stosuje się.

***
## Art. 152. {#kpa-ii-art-152}

**§ 1.** Organ administracji publicznej właściwy w sprawie wznowienia 
postępowania wstrzyma z urzędu lub na żądanie strony wykonanie decyzji, jeżeli 
okoliczności sprawy wskazują na prawdopodobieństwo uchylenia decyzji w wyniku 
wznowienia postępowania. 
**§ 2.** Na postanowienie w sprawie wstrzymania wykonania decyzji służy stronie 
zażalenie, chyba że postanowienie wydał minister lub samorządowe kolegium 
odwoławcze.

***
## Art. 153. {#kpa-ii-art-153}

(uchylony) 

 
 
 
s. 62/89 
 
2025-08-27 
 
Rozdział 13 
Uchylenie, zmiana oraz stwierdzenie nieważności decyzji

***
## Art. 154. {#kpa-ii-art-154}

**§ 1.** Decyzja ostateczna, na mocy której żadna ze stron nie nabyła 
prawa, może być w każdym czasie uchylona lub zmieniona przez organ administracji 
publicznej, który ją wydał, jeżeli przemawia za tym interes społeczny lub słuszny 
interes strony. 
**§ 2.** W przypadkach określonych w § 1 właściwy organ wydaje decyzję 
w sprawie uchylenia lub zmiany dotychczasowej decyzji. 
**§ 3.** (uchylony)

***
## Art. 155. {#kpa-ii-art-155}

Decyzja ostateczna, na mocy której strona nabyła prawo, może być 
w każdym czasie za zgodą strony uchylona lub zmieniona przez organ administracji 
publicznej, który ją wydał, jeżeli przepisy szczególne nie sprzeciwiają się uchyleniu 
lub zmianie takiej decyzji i przemawia za tym interes społeczny lub słuszny interes 
strony; przepis art. 154 § 2 stosuje się odpowiednio.

***
## Art. 155a. {#kpa-ii-art-155a}

W sprawach, o których mowa w art. 154 i art. 155, przepisów o 
milczącym załatwieniu sprawy nie stosuje się.

***
## Art. 156. {#kpa-ii-art-156}

**§ 1.** Organ administracji publicznej stwierdza nieważność decyzji, 
która: 
- 1) wydana została z naruszeniem przepisów o właściwości; 
- 2) wydana została bez podstawy prawnej lub z rażącym naruszeniem prawa; 
- 3) dotyczy sprawy już poprzednio rozstrzygniętej inną decyzją ostateczną albo 
sprawy, którą załatwiono milcząco; 
- 4) została skierowana do osoby niebędącej stroną w sprawie; 
- 5) była niewykonalna w dniu jej wydania i jej niewykonalność ma charakter trwały; 
- 6) w razie jej wykonania wywołałaby czyn zagrożony karą; 
- 7) zawiera wadę powodującą jej nieważność z mocy prawa. 
**§ 2.** Nie stwierdza się nieważności decyzji z przyczyn wymienionych w § 1, 
jeżeli od dnia jej doręczenia lub ogłoszenia upłynęło dziesięć lat, a także gdy decyzja 
wywołała nieodwracalne skutki prawne. 

 
 
 
s. 63/89 
 
2025-08-27

***
## Art. 157. {#kpa-ii-art-157}

**§ 1.** Właściwy do stwierdzenia nieważności decyzji w przypadkach 
wymienionych w art. 156 jest organ wyższego stopnia, a gdy decyzja wydana została 
przez ministra lub samorządowe kolegium odwoławcze – ten organ. 
**§ 2.** Postępowanie w sprawie stwierdzenia nieważności decyzji wszczyna się na 
żądanie strony lub z urzędu. 
**§ 3.** (uchylony)

***
## Art. 158. {#kpa-ii-art-158}

**§ 1.** Rozstrzygnięcie w sprawie stwierdzenia nieważności decyzji 
następuje w drodze decyzji. Przepisów o milczącym załatwieniu sprawy nie stosuje 
się. 
**§ 2.** Jeżeli nie można stwierdzić nieważności decyzji na skutek okoliczności, 
o których mowa w art. 156 § 2, organ administracji publicznej ograniczy się do 
stwierdzenia wydania zaskarżonej decyzji z naruszeniem prawa oraz wskazania 
okoliczności, z powodu których nie stwierdził nieważności decyzji. 
**§ 3.** Jeżeli od dnia doręczenia lub ogłoszenia decyzji, o której mowa 
w art. 156 § 2, upłynęło trzydzieści lat, nie wszczyna się postępowania w sprawie 
stwierdzenia nieważności decyzji.

***
## Art. 159. {#kpa-ii-art-159}

**§ 1.** Organ administracji publicznej, właściwy w sprawie stwierdzenia 
nieważności decyzji, wstrzyma z urzędu lub na żądanie strony wykonanie decyzji, 
jeżeli zachodzi prawdopodobieństwo, że jest ona dotknięta jedną z wad wymienionych 
w art. 156 § 1. 
**§ 2.** Na postanowienie o wstrzymaniu wykonania decyzji służy stronie zażalenie.

***
## Art. 160. {#kpa-ii-art-160}

(uchylony)

***
## Art. 161. {#kpa-ii-art-161}

**§ 1.** Minister może uchylić lub zmienić w niezbędnym zakresie każdą 
decyzję ostateczną, jeżeli w inny sposób nie można usunąć stanu zagrażającego życiu 
lub zdrowiu ludzkiemu albo zapobiec poważnym szkodom dla gospodarki narodowej 
lub dla ważnych interesów Państwa. 
**§ 2.** Uprawnienia określone w § 1 w stosunku do decyzji wydanych przez organy 
jednostek samorządu terytorialnego w sprawach należących do zadań z zakresu 
administracji rządowej przysługują również wojewodzie. 
**§ 3.** Stronie, która poniosła szkodę na skutek uchylenia lub zmiany decyzji, służy 
roszczenie o odszkodowanie za poniesioną rzeczywistą szkodę od organu, który 

 
 
 
s. 64/89 
 
2025-08-27 
 
uchylił lub zmienił tę decyzję; organ ten, w drodze decyzji, orzeka również 
o odszkodowaniu. 
**§ 4.** Roszczenie o odszkodowanie przedawnia się z upływem trzech lat od dnia, 
w którym stała się ostateczna decyzja uchylająca lub zmieniająca decyzję. 
**§ 5.** (uchylony)

***
## Art. 162. {#kpa-ii-art-162}

**§ 1.** Organ administracji publicznej, który wydał decyzję w pierwszej 
instancji, stwierdza jej wygaśnięcie, jeżeli decyzja: 
- 1) stała się bezprzedmiotowa, a stwierdzenie wygaśnięcia takiej decyzji nakazuje 
przepis prawa albo gdy leży to w interesie społecznym lub w interesie strony; 
- 2) została wydana z zastrzeżeniem dopełnienia przez stronę określonego warunku, 
a strona nie dopełniła tego warunku. 
**§ 2.** Organ administracji publicznej, o którym mowa w § 1, uchyli decyzję, jeżeli 
została ona wydana z zastrzeżeniem dopełnienia określonych czynności, a strona nie 
dopełniła tych czynności w wyznaczonym terminie. 
**§ 3.** Organ stwierdza wygaśnięcie decyzji lub uchyla decyzję na podstawie 
przepisów § 1 i 2 w drodze decyzji.

***
## Art. 163. {#kpa-ii-art-163}

Organ administracji publicznej może uchylić lub zmienić decyzję, na 
mocy której strona nabyła prawo, także w innych przypadkach oraz na innych 
zasadach niż określone w niniejszym rozdziale, o ile przewidują to przepisy 
szczególne.

***
## Art. 163a. {#kpa-ii-art-163a}

W sprawach, o których mowa w art. 161–163, przepisów o milczącym 
załatwieniu sprawy nie stosuje się. 
Rozdział 14 
Postępowanie uproszczone

***
## Art. 163b. {#kpa-ii-art-163b}

**§ 1.** Organ administracji publicznej załatwia sprawę w postępowaniu 
uproszczonym, jeżeli przepis szczególny tak stanowi. 
**§ 2.** Postępowanie uproszczone może dotyczyć interesu prawnego lub 
obowiązku tylko jednej strony, jeżeli przepis szczególny nie stanowi inaczej. Przepisu 
art. 62 nie stosuje się. 

 
 
 
s. 65/89 
 
2025-08-27 
**§ 3.** W sprawie rozpoznawanej w postępowaniu uproszczonym stosuje się 
przepisy o milczącym załatwieniu sprawy, chyba że przepis szczególny stanowi 
inaczej.

***
## Art. 163c. {#kpa-ii-art-163c}

**§ 1.** W postępowaniu uproszczonym strona może wnieść podanie z 
wykorzystaniem urzędowego formularza, w którym wskazuje okoliczności mające 
znaczenie dla sprawy oraz przedstawia dowody wraz z żądaniem wszczęcia 
postępowania. 
**§ 2.** Urzędowy formularz zawiera pouczenie o treści § 4. 
**§ 3.** (uchylony) 
**§ 4.** W sprawie wszczętej na skutek podania złożonego z wykorzystaniem 
urzędowego formularza nie jest dopuszczalne późniejsze zgłaszanie przez stronę 
nowych żądań.

***
## Art. 163d. {#kpa-ii-art-163d}

Jeżeli uwzględnienie nowych okoliczności powołanych przez stronę 
w toku postępowania jest istotne dla wyniku tego postępowania, a ich uwzględnienie 
doprowadzi do jego przedłużenia, organ administracji publicznej w dalszym ciągu 
prowadzi postępowanie z pominięciem przepisów niniejszego rozdziału, o czym 
niezwłocznie informuje stronę.

***
## Art. 163e. {#kpa-ii-art-163e}

**§ 1.** Postępowanie dowodowe jest ograniczone do dowodów 
zgłoszonych przez stronę, łącznie z żądaniem wszczęcia postępowania, oraz dowodów 
możliwych do ustalenia na podstawie danych, którymi dysponuje organ prowadzący 
postępowanie. 
**§ 2.** W sprawach rozpoznawanych w postępowaniu uproszczonym nie stosuje się 
przepisu art. 81.

***
## Art. 163f. {#kpa-ii-art-163f}

Uzasadnienie decyzji wydanej w postępowaniu uproszczonym może 
ograniczać się do wskazania faktów, które organ administracji publicznej uznał za 
udowodnione, oraz przytoczenia przepisów prawa stanowiących podstawę prawną 
decyzji.

***
## Art. 163g. {#kpa-ii-art-163g}

Postanowienia wydane w postępowaniu uproszczonym można 
zaskarżyć tylko w odwołaniu od decyzji, z wyjątkiem postanowień wydanych po 
wydaniu decyzji, postanowień o zawieszeniu lub odmowie podjęcia zawieszonego 
postępowania oraz postanowień, w odniesieniu do których możliwość ich zaskarżenia 
przewidują przepisy szczególne. 

 
 
 
s. 66/89 
 
2025-08-27

