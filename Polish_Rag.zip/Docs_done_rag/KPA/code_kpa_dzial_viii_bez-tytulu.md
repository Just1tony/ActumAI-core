---
id: code.kpa.dzial.viii
title: "Kodeks postępowania administracyjnego — Dział VIII (—)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1960 nr 30 poz. 168"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KPA — Dział VIII"]
tags: ["KPA","Kodeks postępowania administracyjnego","Dział VIII","PL"]
source_pdf: "D19600168Lj.pdf"
articles: "Art. 221–260g"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpa-viii-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks postępowania administracyjnego — Dział VIII: —

Skargi i wnioski 
Rozdział 1 
Postanowienia ogólne
***
## Art. 221. {#kpa-viii-art-221}

**§ 1.** Zagwarantowane każdemu w Konstytucji Rzeczypospolitej 
Polskiej prawo składania skarg i wniosków do organów państwowych, organów 
jednostek 
samorządu 
terytorialnego, 
organów 
samorządowych 
jednostek 
organizacyjnych oraz do organizacji i instytucji społecznych realizowane jest na 
zasadach określonych przepisami niniejszego działu. 
**§ 2.** Skargi i wnioski mogą być składane do organizacji i instytucji społecznych 
w związku z wykonywanymi przez nie zadaniami zleconymi z zakresu administracji 
publicznej. 
**§ 3.** Skargi i wnioski można składać w interesie publicznym, własnym lub innej 
osoby za jej zgodą.

***
## Art. 222. {#kpa-viii-art-222}

O tym, czy pismo jest skargą albo wnioskiem, decyduje treść pisma, 
a nie jego forma zewnętrzna.

***
## Art. 223. {#kpa-viii-art-223}

**§ 1.** Organy państwowe, organy samorządu terytorialnego i inne 
organy samorządowe oraz organy organizacji społecznych – rozpatrują oraz załatwiają 
skargi i wnioski w ramach swojej właściwości. 
**§ 2.** Pracownik organu państwowego, pracownik samorządowy oraz organu 
organizacji społecznej, winny niewłaściwego i nieterminowego załatwiania skarg 
i wniosków, podlega odpowiedzialności porządkowej lub dyscyplinarnej albo innej 
odpowiedzialności przewidzianej w przepisach prawa. 

 
 
 
s. 78/89 
 
2025-08-27

***
## Art. 224. {#kpa-viii-art-224}

Ilekroć w przepisach niniejszego działu jest mowa o organach 
państwowych – rozumie się przez to także organy przedsiębiorstw państwowych 
i innych państwowych jednostek organizacyjnych.

***
## Art. 225. {#kpa-viii-art-225}

**§ 1.** Nikt nie może być narażony na jakikolwiek uszczerbek lub zarzut 
z powodu złożenia skargi lub wniosku albo z powodu dostarczenia materiału do 
publikacji o znamionach skargi lub wniosku, jeżeli działał w granicach prawem 
dozwolonych. 
**§ 2.** Organy państwowe, organy jednostek samorządu terytorialnego i inne 
organy samorządowe oraz organy organizacji społecznych są obowiązane 
przeciwdziałać hamowaniu krytyki i innym działaniom ograniczającym prawo do 
składania skarg i wniosków lub dostarczania informacji – do publikacji – 
o znamionach skargi lub wniosku.

***
## Art. 226. {#kpa-viii-art-226}

Rada 
Ministrów 
wyda, 
w drodze 
rozporządzenia, 
przepisy 
o organizacji przyjmowania i rozpatrywania skarg i wniosków.

***
## Art. 226a. {#kpa-viii-art-226a}

Organy właściwe w sprawach skarg i wniosków przekazują 
informacje, o których mowa w art. 13 ust. 1 i 2 rozporządzenia 2016/679, skarżącemu 
lub wnioskodawcy przy pierwszej czynności skierowanej do tych osób. 
Rozdział 2 
Skargi

***
## Art. 227. {#kpa-viii-art-227}

Przedmiotem skargi może być w szczególności zaniedbanie lub 
nienależyte wykonywanie zadań przez właściwe organy albo przez ich pracowników, 
naruszenie praworządności lub interesów skarżących, a także przewlekłe lub 
biurokratyczne załatwianie spraw.

***
## Art. 228. {#kpa-viii-art-228}

Skargi składa się do organów właściwych do ich rozpatrzenia.

***
## Art. 229. {#kpa-viii-art-229}

Jeżeli przepisy szczególne nie określają innych organów właściwych 
do rozpatrywania skarg, jest organem właściwym do rozpatrzenia skargi dotyczącej 
zadań lub działalności: 
- 1) rady gminy, rady powiatu i sejmiku województwa – wojewoda, a w zakresie 
spraw finansowych – regionalna izba obrachunkowa; 
- 2) organów wykonawczych jednostek samorządu terytorialnego oraz kierowników 
powiatowych służb, inspekcji, straży i innych jednostek organizacyjnych 

 
 
 
s. 79/89 
 
2025-08-27 
 
w sprawach należących do zadań zleconych z zakresu administracji rządowej – 
wojewoda lub organ wyższego stopnia; 
- 3) wójta (burmistrza lub prezydenta miasta) i kierowników gminnych jednostek 
organizacyjnych, z wyjątkiem spraw określonych w pkt 2 – rada gminy; 
- 4) zarządu powiatu oraz starosty, a także kierowników powiatowych służb, 
inspekcji, straży i innych jednostek organizacyjnych, z wyjątkiem spraw 
określonych w pkt 2 – rada powiatu; 
- 5) zarządu i marszałka województwa, z wyjątkiem spraw określonych w pkt 2 – 
sejmik województwa; 
- 6) wojewody w sprawach podlegających rozpatrzeniu według kodeksu – właściwy 
minister, a w innych sprawach – Prezes Rady Ministrów; 
- 7) innego organu administracji rządowej, organu przedsiębiorstwa państwowego 
lub innej państwowej jednostki organizacyjnej – organ wyższego stopnia lub 
sprawujący bezpośredni nadzór; 
- 8) ministra – Prezes Rady Ministrów; 
8a) konsula – minister właściwy do spraw zagranicznych; 
- 9) organu centralnego i jego kierownika – organ, któremu podlega.

***
## Art. 230. {#kpa-viii-art-230}

Do rozpatrzenia skargi dotyczącej zadań i działalności organizacji 
społecznej właściwy jest organ bezpośrednio wyższego stopnia tej organizacji, 
a w stosunku do organu naczelnego organizacji – Prezes Rady Ministrów lub właściwi 
ministrowie sprawujący nadzór nad działalnością tej organizacji.

***
## Art. 231. {#kpa-viii-art-231}

**§ 1.** Jeżeli organ, który otrzymał skargę, nie jest właściwy do jej 
rozpatrzenia, obowiązany jest niezwłocznie, nie później jednak niż w terminie siedmiu 
dni, przekazać ją właściwemu organowi, zawiadamiając równocześnie o tym 
skarżącego, albo wskazać mu właściwy organ. 
**§ 2.** Informacje, o których mowa w art. 13 ust. 1 i 2 rozporządzenia 2016/679, 
w zakresie danych przetwarzanych przez organ przekazujący skargę, dołącza się do 
zawiadomienia o przekazaniu skargi.

***
## Art. 232. {#kpa-viii-art-232}

**§ 1.** Organ właściwy do rozpatrzenia skargi może ją przekazać do 
załatwienia organowi niższego stopnia, o ile skarga nie zawiera zarzutów dotyczących 
działalności tego organu. 

 
 
 
s. 80/89 
 
2025-08-27 
**§ 2.** Skargę na pracownika można przekazać do załatwienia również jego 
przełożonemu służbowemu, z obowiązkiem zawiadomienia organu właściwego do 
rozpatrzenia skargi o sposobie jej załatwienia. 
**§ 3.** O przekazaniu skargi zawiadamia się równocześnie skarżącego.

***
## Art. 233. {#kpa-viii-art-233}

Skarga w sprawie indywidualnej, która nie była i nie jest przedmiotem 
postępowania administracyjnego, powoduje wszczęcie postępowania, jeżeli została 
złożona przez stronę. Jeżeli skarga taka pochodzi od innej osoby, może spowodować 
wszczęcie postępowania administracyjnego z urzędu, chyba że przepisy wymagają do 
wszczęcia postępowania żądania strony.

***
## Art. 234. {#kpa-viii-art-234}

W sprawie, w której toczy się postępowanie administracyjne: 
- 1) skarga złożona przez stronę podlega rozpatrzeniu w toku postępowania, zgodnie 
z przepisami kodeksu; 
- 2) skarga pochodząca od innych osób stanowi materiał, który organ prowadzący 
postępowanie powinien rozpatrzyć z urzędu.

***
## Art. 235. {#kpa-viii-art-235}

**§ 1.** Skargę w sprawie, w której wydano decyzję ostateczną, uważa się 
zależnie od jej treści za żądanie wznowienia postępowania, stwierdzenia nieważności 
decyzji albo jej uchylenia lub zmiany, które może być uwzględnione, z zastrzeżeniem 
art. 16 § 1 zdanie drugie. 
**§ 2.** (uchylony)

***
## Art. 236. {#kpa-viii-art-236}

**§ 1.** W przypadkach określonych w art. 233 i 234 organem właściwym 
do rozpatrzenia skargi jest organ uprawniony do wszczęcia postępowania lub organ, 
przed którym toczy się postępowanie, a w przypadkach określonych w art. 235 – 
organ właściwy do wznowienia postępowania, stwierdzenia nieważności decyzji albo 
do jej uchylenia lub zmiany. 
**§ 2.** W przypadku wszczęcia albo wznowienia postępowania, stwierdzenia 
nieważności decyzji, jej uchylenia albo zmiany na skutek skargi, o której mowa 
w art. 233 zdanie drugie, art. 234 pkt 2 lub art. 235, w stosunku do strony i uczestnika 
postępowania przepisu art. 15 ust. 1 lit. g rozporządzenia 2016/679 nie stosuje się. 
**§ 3.** Na każdym etapie postępowania, o którym mowa w § 2, skarżący może 
zezwolić organowi na udostępnienie swoich danych stronie postępowania.

***
## Art. 237. {#kpa-viii-art-237}

**§ 1.** Organ właściwy do załatwienia skargi powinien załatwić skargę 
bez zbędnej zwłoki, nie później jednak niż w ciągu miesiąca. 

 
 
 
s. 81/89 
 
2025-08-27 
**§ 2.** Posłowie na Sejm, senatorowie i radni, którzy wnieśli skargę we własnym 
imieniu albo przekazali do załatwienia skargę innej osoby, powinni być zawiadomieni 
o sposobie załatwienia skargi, a gdy jej załatwienie wymaga zebrania dowodów, 
informacji lub wyjaśnień – także o stanie rozpatrzenia skargi, najpóźniej w terminie 
czternastu dni od dnia jej wniesienia albo przekazania. 
**§ 3.** O sposobie załatwienia skargi zawiadamia się skarżącego. 
**§ 4.** W razie niezałatwienia skargi w terminie określonym w § 1 stosuje się 
przepisy art. 36–38.

***
## Art. 238. {#kpa-viii-art-238}

**§ 1.** Zawiadomienie o sposobie załatwienia skargi powinno zawierać: 
oznaczenie organu, od którego pochodzi, wskazanie, w jaki sposób skarga została 
załatwiona, oraz podpis z podaniem imienia, nazwiska i stanowiska służbowego osoby 
upoważnionej do załatwienia skargi. Zawiadomienie o odmownym załatwieniu skargi 
powinno zawierać ponadto uzasadnienie faktyczne i prawne oraz pouczenie o treści 
art. 239. 
**§ 2.** W zawiadomieniu, o którym mowa w § 1, w jednostkach organizacyjnych 
resortu obrony narodowej, Agencji Bezpieczeństwa Wewnętrznego, Agencji 
Wywiadu, Służby Kontrwywiadu Wojskowego, Służby Wywiadu Wojskowego oraz 
Centralnego Biura Antykorupcyjnego można pominąć imię i nazwisko osoby 
upoważnionej do załatwienia skargi.

***
## Art. 239. {#kpa-viii-art-239}

**§ 1.** W przypadku gdy skarga, w wyniku jej rozpatrzenia, została 
uznana za bezzasadną i jej bezzasadność wykazano w odpowiedzi na skargę, 
a skarżący ponowił skargę bez wskazania nowych okoliczności – organ właściwy do 
jej rozpatrzenia może podtrzymać swoje poprzednie stanowisko z odpowiednią 
adnotacją w aktach sprawy – bez zawiadamiania skarżącego. 
**§ 2.** (uchylony)

***
## Art. 240. {#kpa-viii-art-240}

Gdy skarga dotyczy sprawy, która nie podlega rozpatrzeniu według 
przepisów kodeksu (art. 3 § 1 i 2) albo nie należy do właściwości organów 
administracji publicznej, przepisy art. 233–239 stosuje się odpowiednio, z 
zastrzeżeniem, że w miejsce pozostałych przepisów kodeksu stosuje się przepisy 
postępowania właściwego dla danej sprawy. 

 
 
 
s. 82/89 
 
2025-08-27 
 
Rozdział 3 
Wnioski

***
## Art. 241. {#kpa-viii-art-241}

Przedmiotem wniosku mogą być w szczególności sprawy ulepszenia 
organizacji, wzmocnienia praworządności, usprawnienia pracy i zapobiegania 
nadużyciom, ochrony własności, lepszego zaspokajania potrzeb ludności.

***
## Art. 242. {#kpa-viii-art-242}

**§ 1.** Wnioski składa się do organów właściwych ze względu na 
przedmiot wniosku. 
**§ 2.** Wnioski w sprawach dotyczących zadań organizacji społecznych składa się 
do organów tych organizacji.

***
## Art. 243. {#kpa-viii-art-243}

Jeżeli organ, który otrzymał wniosek, nie jest właściwy do jego 
rozpatrzenia, obowiązany jest w ciągu siedmiu dni przekazać go właściwemu 
organowi. O przekazaniu wniosku zawiadamia się równocześnie wnioskodawcę.

***
## Art. 244. {#kpa-viii-art-244}

**§ 1.** W sprawie terminu załatwiania wniosków stosuje się przepis 
art. 237 § 1. 
**§ 2.** O sposobie 
załatwienia 
wniosku 
zawiadamia 
się 
równocześnie 
wnioskodawcę.

***
## Art. 245. {#kpa-viii-art-245}

W razie niemożności załatwienia wniosku w terminie określonym 
w art. 244 właściwy 
organ 
obowiązany 
jest 
w tym 
terminie 
zawiadomić 
wnioskodawcę o czynnościach podjętych w celu rozpatrzenia wniosku oraz o 
przewidywanym terminie załatwienia wniosku.

***
## Art. 246. {#kpa-viii-art-246}

**§ 1.** Wnioskodawcy niezadowolonemu ze sposobu załatwienia 
wniosku służy prawo wniesienia skargi w trybie określonym w rozdziale 2 niniejszego 
działu. 
**§ 2.** Wnioskodawcy służy prawo wniesienia skargi w przypadku niezałatwienia 
wniosku w terminie określonym w art. 244 albo wskazanym w zawiadomieniu (art. 
245).

***
## Art. 247. {#kpa-viii-art-247}

Do wniosków stosuje się odpowiednio przepisy art. 230, 237 § 2 
i art. 238. 

 
 
 
s. 83/89 
 
2025-08-27 
 
Rozdział 4 
Udział prasy i organizacji społecznych

***
## Art. 248. {#kpa-viii-art-248}

**§ 1.** Skargi i wnioski przekazane przez redakcje prasowe, radiowe 
i telewizyjne do organów właściwych w myśl art. 228–230 i 242 podlegają 
rozpatrzeniu i załatwieniu w trybie określonym w przepisach rozdziałów 2 i 3 
niniejszego działu. 
**§ 2.** Właściwy 
organ 
zawiadamia 
w przepisanym 
terminie 
o sposobie 
załatwienia skargi lub wniosku albo o ich przekazaniu innemu organowi w celu 
załatwienia również redakcję, jeżeli zażądała takiego zawiadomienia.

***
## Art. 249. {#kpa-viii-art-249}

Przepis art. 248 stosuje się odpowiednio do skarg i wniosków 
przekazanych przez organizacje społeczne do organów właściwych w myśl art. 228–
230 oraz art. 242.

***
## Art. 250. {#kpa-viii-art-250}

(uchylony)

***
## Art. 251. {#kpa-viii-art-251}

Przepisy art. 237 § 4 oraz art. 245 i 246 stosuje się odpowiednio do 
redakcji prasowej, która opublikowała i przesłała do właściwego organu administracji 
publicznej artykuł, notatkę lub inną wiadomość, w trybie przewidzianym 
w niniejszym rozdziale.

***
## Art. 252. {#kpa-viii-art-252}

(uchylony) 
Rozdział 5 
Przyjmowanie skarg i wniosków

***
## Art. 253. {#kpa-viii-art-253}

**§ 1.** Organy państwowe, organy samorządu terytorialnego i inne 
organy samorządowe oraz organy organizacji społecznych obowiązane są przyjmować 
obywateli w sprawach skarg i wniosków w ustalonych przez siebie dniach 
i godzinach. 
**§ 2.** Kierownicy organów wymienionych w § 1 lub wyznaczeni przez nich 
zastępcy obowiązani są przyjmować obywateli w sprawach skarg i wniosków co 
najmniej raz w tygodniu. 
**§ 3.** Dni i godziny przyjęć powinny być dostosowane do potrzeb ludności, przy 
czym przynajmniej raz w tygodniu przyjęcia powinny się odbywać w ustalonym dniu 
po godzinach pracy. 

 
 
 
s. 84/89 
 
2025-08-27 
**§ 4.** Informacja o dniach i godzinach przyjęć powinna być wywieszona na 
widocznym 
miejscu 
w siedzibie 
danej 
jednostki 
organizacyjnej 
oraz 
w podporządkowanych jej jednostkach organizacyjnych. 
**§ 5.** Prezes Rady Ministrów lub właściwy minister oraz naczelny organ 
organizacji społecznej mogą ustalać sposób, dni i godziny przyjmowania obywateli 
w sprawach skarg i wniosków przez podporządkowane im organy i jednostki 
organizacyjne.

***
## Art. 254. {#kpa-viii-art-254}

Skargi i wnioski składane i przekazywane do organów państwowych, 
organów samorządu terytorialnego i innych organów samorządowych i organów 
organizacji społecznych oraz związane z nimi pisma i inne dokumenty rejestruje się 
i przechowuje w sposób ułatwiający kontrolę przebiegu i terminów załatwiania 
poszczególnych skarg i wniosków.

***
## Art. 255. {#kpa-viii-art-255}

(uchylony)

***
## Art. 256. {#kpa-viii-art-256}

Pracownik, który otrzymał skargę dotyczącą jego działalności, 
obowiązany jest przekazać ją niezwłocznie swojemu przełożonemu służbowemu. 
Rozdział 6 
Nadzór i kontrola

***
## Art. 257. {#kpa-viii-art-257}

Zwierzchni nadzór nad przyjmowaniem i załatwianiem skarg 
i wniosków składanych do sądów sprawuje Krajowa Rada Sądownictwa, a do innych 
organów i jednostek organizacyjnych – Prezes Rady Ministrów.

***
## Art. 258. {#kpa-viii-art-258}

**§ 1.** Nadzór i kontrolę nad przyjmowaniem i załatwianiem skarg 
i wniosków sprawują: 
- 1) ministrowie – gdy chodzi o skargi załatwiane przez ministerstwa i inne jednostki 
organizacyjne bezpośrednio podległe ministrowi; 
- 2) właściwi rzeczowo ministrowie we współdziałaniu z ministrem właściwym do 
spraw administracji publicznej – gdy chodzi o skargi załatwiane przez organy 
administracji rządowej; 
- 3) terenowe organy administracji rządowej – gdy chodzi o skargi załatwiane przez 
jednostki organizacyjne nadzorowane przez te organy; 

 
 
 
s. 85/89 
 
2025-08-27 
- 4) organy wyższego stopnia oraz właściwe organy naczelne – gdy chodzi o skargi 
załatwiane przez pozostałe organy państwowe i organy państwowych jednostek 
organizacyjnych; 
- 5) Prezes Rady Ministrów i wojewodowie – gdy chodzi o skargi załatwiane przez 
organy jednostek samorządu terytorialnego oraz samorządowe jednostki 
organizacyjne. 
**§ 2.** Nadzór i kontrolę nad przyjmowaniem i załatwianiem skarg i wniosków 
w organach organizacji społecznych sprawują statutowe organy nadzorcze tych 
organizacji oraz organy wyższego stopnia, zaś w organach naczelnych tych 
organizacji – organ administracji rządowej sprawujący nadzór nad działalnością danej 
organizacji.

***
## Art. 259. {#kpa-viii-art-259}

**§ 1.** Organy, o których mowa w art. 258, dokonują okresowo, nie 
rzadziej niż raz na dwa lata, ocen przyjmowania i załatwiania skarg i wniosków przez 
organy i jednostki organizacyjne poddane ich nadzorowi. 
**§ 2.** (uchylony) 
**§ 3.** W wyniku przeprowadzonych kontroli oraz ocen organy wymienione 
w § 1 dążą do usunięcia przyczyn skarg oraz do pełnego wykorzystania wniosków 
w celu polepszenia działalności poszczególnych organów i innych państwowych 
jednostek organizacyjnych.

***
## Art. 260. {#kpa-viii-art-260}

(uchylony) 
A 
Europejska współpraca administracyjna

***
## Art. 260a. {#kpa-viii-art-260a}

**§ 1.** Organy administracji publicznej udzielają pomocy organom 
innych państw członkowskich Unii Europejskiej oraz organom administracji Unii 
Europejskiej, jeżeli przepisy prawa Unii Europejskiej tak stanowią i na zasadach 
określonych w tych przepisach. 
**§ 2.** Organ administracji publicznej udziela pomocy z urzędu albo na wniosek. 
Pomoc ta obejmuje w szczególności udostępnianie informacji o okolicznościach 
faktycznych i prawnych oraz wykonywanie czynności procesowych w ramach 
pomocy prawnej. 

 
 
 
s. 86/89 
 
2025-08-27 
**§ 3.** Właściwość organów w przedmiocie udzielenia pomocy ustala się na 
podstawie przepisów kodeksu, jeżeli przepisy prawa Unii Europejskiej nie stanowią 
inaczej. 
**§ 4.** Organ administracji publicznej udzielający pomocy zawiadamia o udzieleniu 
pomocy podmiot, którego pomoc dotyczy, jeżeli przepisy szczególne nie stanowią 
inaczej.

***
## Art. 260b. {#kpa-viii-art-260b}

**§ 1.** Wniosek o udzielenie pomocy podlega rozpatrzeniu, jeżeli 
zawiera uzasadnienie i został sporządzony w języku urzędowym Unii Europejskiej. 
**§ 2.** Jeżeli wniosek zawiera braki formalne, organ administracji publicznej 
wzywa organ wnioskujący do ich uzupełnienia w terminie czternastu dni od dnia 
doręczenia wezwania. 
**§ 3.** Jeżeli organ wnioskujący nie uzupełni w terminie braków formalnych lub 
brak jest podstaw prawnych do udzielenia pomocy, wniosek o udzielenie pomocy nie 
podlega rozpatrzeniu i jest zwracany organowi wnioskującemu. 
**§ 4.** Rozpatrzenie wniosku następuje w terminie wynikającym z przepisów prawa 
Unii Europejskiej, a jeżeli brak jest takiego terminu – bez zbędnej zwłoki.

***
## Art. 260c. {#kpa-viii-art-260c}

**§ 1.** Organy administracji publicznej zwracają się o pomoc do 
organów innych państw członkowskich Unii Europejskiej oraz organów administracji 
Unii Europejskiej, jeżeli przepisy prawa Unii Europejskiej tak stanowią i na zasadach 
określonych w tych przepisach. 
**§ 2.** Wniosek o udzielenie pomocy zawiera uzasadnienie. Jeżeli wniosek jest 
kierowany do organów administracji Unii Europejskiej, sporządza się go w języku 
urzędowym Unii Europejskiej, a jeżeli jest kierowany do organów innego państwa 
członkowskiego Unii Europejskiej, tłumaczy się go na język uzgodniony przez 
zainteresowane organy.

***
## Art. 260d. {#kpa-viii-art-260d}

Informacje 
między 
organami 
administracji 
publicznej 
są 
przekazywane w szczególności drogą elektroniczną.

***
## Art. 260e. {#kpa-viii-art-260e}

Zasady ponoszenia kosztów udzielenia pomocy regulują przepisy 
prawa Unii Europejskiej. W przypadku braku takich przepisów organ administracji 
publicznej ponosi koszty swojego działania.

***
## Art. 260f. {#kpa-viii-art-260f}

Przepisy niniejszego działu stosuje się także w odniesieniu do 
organów państw członkowskich Europejskiego Porozumienia o Wolnym Handlu 

 
 
 
s. 87/89 
 
2025-08-27 
 
(EFTA) – stron umowy o Europejskim Obszarze Gospodarczym oraz Konfederacji 
Szwajcarskiej, jeżeli przepisy prawa Unii Europejskiej znajdują zastosowanie do tych 
państw.

***
## Art. 260g. {#kpa-viii-art-260g}

Przepisów niniejszego działu nie stosuje się, jeżeli przepisy prawa 
Unii Europejskiej lub przepisy szczególne dotyczące europejskiej współpracy 
administracyjnej stanowią inaczej.

