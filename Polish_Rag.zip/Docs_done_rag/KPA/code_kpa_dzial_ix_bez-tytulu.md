---
id: code.kpa.dzial.ix
title: "Kodeks postępowania administracyjnego — Dział IX (—)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1960 nr 30 poz. 168"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KPA — Dział IX"]
tags: ["KPA","Kodeks postępowania administracyjnego","Dział IX","PL"]
source_pdf: "D19600168Lj.pdf"
articles: "Art. 261–267"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpa-ix-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks postępowania administracyjnego — Dział IX: —

Opłaty i koszty postępowania
***
## Art. 261. {#kpa-ix-art-261}

**§ 1.** Jeżeli strona nie wpłaciła należności tytułem opłat i kosztów 
postępowania, które zgodnie z przepisami powinny być uiszczone z góry, organ 
administracji publicznej prowadzący postępowanie wyznaczy jej termin do wniesienia 
tych należności. Termin ten nie może być krótszy niż siedem dni, a dłuższy niż 
czternaście dni. 
**§ 2.** Jeżeli w wyznaczonym terminie należności nie zostaną uiszczone, podanie 
podlega zwrotowi lub czynność uzależniona od opłaty zostanie zaniechana. 
**§ 3.** Na postanowienie w sprawie zwrotu podania służy zażalenie. 
**§ 4.** Organ powinien jednak załatwić podanie mimo nieuiszczenia należności: 
- 1) jeżeli za niezwłocznym załatwieniem przemawiają względy społeczne lub 
wzgląd na ważny interes strony; 
- 2) jeżeli wniesienie podania stanowi czynność, dla której jest ustanowiony termin 
zawity; 
- 3) jeżeli podanie wniosła osoba zamieszkała za granicą.

***
## Art. 262. {#kpa-ix-art-262}

**§ 1.** Stronę obciążają te koszty postępowania, które: 
- 1) wynikły z winy strony; 
- 2) zostały poniesione w interesie lub na żądanie strony, a nie wynikają 
z ustawowego obowiązku organów prowadzących postępowanie. 
**§ 2.** W uzasadnionych przypadkach organ administracji publicznej może zażądać 
od strony złożenia zaliczki w określonej wysokości na pokrycie kosztów 
postępowania.

***
## Art. 263. {#kpa-ix-art-263}

**§ 1.** Do kosztów postępowania zalicza się koszty podróży i inne 
należności świadków i biegłych oraz stron w przypadkach przewidzianych w art. 56, 

 
 
 
s. 88/89 
 
2025-08-27 
 
koszty spowodowane oględzinami na miejscu, koszty doręczenia stronom pism 
urzędowych, a także koszty mediacji. 
**§ 2.** Organ administracji publicznej może zaliczyć do kosztów postępowania 
także inne koszty bezpośrednio związane z rozstrzygnięciem sprawy.

***
## Art. 263a. {#kpa-ix-art-263a}

Minister właściwy do spraw administracji publicznej określi, w 
drodze rozporządzenia, wysokość wynagrodzenia mediatora za prowadzenie 
postępowania mediacyjnego oraz wydatki mediatora podlegające zwrotowi, biorąc 
pod uwagę rodzaj sprawy oraz sprawny przebieg mediacji, a także niezbędne wydatki 
związane z prowadzeniem mediacji.

***
## Art. 264. {#kpa-ix-art-264}

**§ 1.** Jednocześnie z wydaniem decyzji organ administracji publicznej 
ustali w drodze postanowienia wysokość kosztów postępowania, osoby zobowiązane 
do ich poniesienia oraz termin i sposób ich uiszczenia. 
**§ 1a.** Jeżeli w sprawie została przeprowadzona mediacja, organ administracji 
publicznej, niezwłocznie po doręczeniu protokołu z przebiegu mediacji, wydaje 
postanowienie w sprawie ustalenia wysokości kosztów mediacji. 
**§ 2.** Na postanowienie w sprawie kosztów postępowania osobie zobowiązanej do 
ich poniesienia służy zażalenie.

***
## Art. 265. {#kpa-ix-art-265}

Wszelkie nieuiszczone w terminie opłaty i koszty postępowania oraz 
inne należności wynikłe z tego postępowania podlegają ściągnięciu w trybie 
przepisów o egzekucji administracyjnej świadczeń pieniężnych.

***
## Art. 266. {#kpa-ix-art-266}

Pracownik organu administracji publicznej winny błędnego wezwania 
strony (art. 56 § 1) obowiązany jest do zwrotu wynikłych stąd kosztów. Orzekanie 
i ściąganie należności od tego pracownika następuje w trybie administracyjnym.

***
## Art. 267. {#kpa-ix-art-267}

W razie niewątpliwej niemożności poniesienia przez stronę opłat, 
kosztów i należności związanych z tokiem postępowania organ administracji 
publicznej może ją zwolnić w całości lub w części od ponoszenia tych opłat, kosztów 
i należności. Zwolnienie od opłat skarbowych następuje z zachowaniem przepisów 
o tych opłatach.

