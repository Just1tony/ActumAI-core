---
id: code.kpa.dzial.vii
title: "Kodeks postępowania administracyjnego — Dział VII (—)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1960 nr 30 poz. 168"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KPA — Dział VII"]
tags: ["KPA","Kodeks postępowania administracyjnego","Dział VII","PL"]
source_pdf: "D19600168Lj.pdf"
articles: "Art. 217–220"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpa-vii-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks postępowania administracyjnego — Dział VII: —

Wydawanie zaświadczeń
***
## Art. 217. {#kpa-vii-art-217}

**§ 1.** Organ administracji publicznej wydaje zaświadczenie na żądanie 
osoby ubiegającej się o zaświadczenie. 
**§ 2.** Zaświadczenie wydaje się, jeżeli: 
- 1) urzędowego potwierdzenia określonych faktów lub stanu prawnego wymaga 
przepis prawa; 
- 2) osoba ubiega się o zaświadczenie ze względu na swój interes prawny 
w urzędowym potwierdzeniu określonych faktów lub stanu prawnego. 
**§ 3.** Zaświadczenie powinno być wydane bez zbędnej zwłoki, nie później jednak 
niż w terminie siedmiu dni. 
**§ 4.** (uchylony)

***
## Art. 217a. {#kpa-vii-art-217a}

Organ administracji publicznej przekazuje informacje, o których 
mowa w art. 13 ust. 1 i 2 rozporządzenia 2016/679, przy pierwszej czynności 
skierowanej do strony, chyba że strona posiada te informacje, a ich zakres lub treść nie 
uległy zmianie.

***
## Art. 218. {#kpa-vii-art-218}

**§ 1.** W przypadkach, o których mowa w art. 217 § 2 pkt 2, organ 
administracji publicznej obowiązany jest wydać zaświadczenie, gdy chodzi 
o potwierdzenie faktów albo stanu prawnego, wynikających z prowadzonej przez ten 
organ ewidencji, rejestrów bądź z innych danych znajdujących się w jego posiadaniu. 
**§ 2.** Organ administracji publicznej, przed wydaniem zaświadczenia, może 
przeprowadzić w koniecznym zakresie postępowanie wyjaśniające. 

 
 
 
s. 76/89 
 
2025-08-27

***
## Art. 219. {#kpa-vii-art-219}

Odmowa wydania zaświadczenia bądź zaświadczenia o treści żądanej 
przez osobę ubiegającą się o nie następuje w drodze postanowienia, na które służy 
zażalenie.

***
## Art. 220. {#kpa-vii-art-220}

**§ 1.** Organ administracji publicznej nie może żądać zaświadczenia ani 
oświadczenia na potwierdzenie faktów lub stanu prawnego, jeżeli: 
- 1) znane są one organowi z urzędu; 
- 2) możliwe są do ustalenia przez organ na podstawie: 
  - a) posiadanych przez niego ewidencji, rejestrów lub innych danych, 
  - b) rejestrów publicznych posiadanych przez inne podmioty publiczne, do 
których organ ma dostęp w drodze elektronicznej na zasadach określonych 
w przepisach ustawy z dnia 17 lutego 2005 r. o informatyzacji działalności 
podmiotów realizujących zadania publiczne, 
  - c) wymiany informacji z innym podmiotem publicznym na zasadach 
określonych w przepisach o informatyzacji działalności podmiotów 
realizujących zadania publiczne, 
  - d) przedstawionych przez zainteresowanego do wglądu dokumentów 
urzędowych (dowodu osobistego, dowodów rejestracyjnych i innych). 
**§ 2.** Organ administracji publicznej żądający od strony lub innego uczestnika 
postępowania zaświadczenia albo oświadczenia na potwierdzenie faktów lub stanu 
prawnego jest obowiązany wskazać przepis prawa wymagający urzędowego 
potwierdzenia tych faktów lub stanu prawnego w drodze zaświadczenia albo 
oświadczenia. 
**§ 3.** Jeżeli strona lub inny uczestnik postępowania nie może uzyskać utrwalonego 
w postaci elektronicznej zaświadczenia wymaganego do potwierdzenia faktów lub 
stanu prawnego lub innego dokumentu wydanego przez podmiot publiczny w 
rozumieniu ustawy z dnia 17 lutego 2005 r. o informatyzacji działalności podmiotów 
realizujących zadania publiczne, jak również potwierdzenia uiszczenia opłat i kosztów 
postępowania, strona lub inny uczestnik postępowania może złożyć elektroniczną 
kopię takiego dokumentu, po uwierzytelnieniu jej przez wnoszącego, przy użyciu 
kwalifikowanego podpisu elektronicznego podpisu zaufanego albo podpisu 
osobistego. 
**§ 4.** Organ administracji publicznej może żądać przedłożenia oryginału 
zaświadczenia, innego dokumentu lub potwierdzenia uiszczenia opłat i kosztów 

 
 
 
s. 77/89 
 
2025-08-27 
 
postępowania, o których mowa w § 3, o ile złożona kopia nie pozwala na weryfikację 
autentyczności oraz integralności lub jeżeli jest to uzasadnione innymi 
okolicznościami sprawy. 
**§ 5.** Strona lub inny uczestnik postępowania przechowują zaświadczenie, inny 
dokument lub potwierdzenie uiszczenia opłat i kosztów postępowania, o których 
mowa w § 3, do dnia, w którym decyzja kończąca postępowanie stała się ostateczna.

