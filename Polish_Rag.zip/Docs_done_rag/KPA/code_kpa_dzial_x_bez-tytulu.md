---
id: code.kpa.dzial.x
title: "Kodeks postępowania administracyjnego — Dział X (—)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1960 nr 30 poz. 168"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KPA — Dział X"]
tags: ["KPA","Kodeks postępowania administracyjnego","Dział X","PL"]
source_pdf: "D19600168Lj.pdf"
articles: "Art. 268–269"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpa-x-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks postępowania administracyjnego — Dział X: —

Przepisy końcowe
***
## Art. 268. {#kpa-x-art-268}

(uchylony) 

 
 
 
s. 89/89 
 
2025-08-27

***
## Art. 268a. {#kpa-x-art-268a}

Organ administracji publicznej może upoważniać, na piśmie 
utrwalonym w postaci papierowej lub elektronicznej, pracowników obsługujących ten 
organ do załatwiania spraw w jego imieniu w ustalonym zakresie, a w szczególności 
do wydawania decyzji administracyjnych, postanowień, zaświadczeń, a także do 
poświadczania za zgodność odpisów dokumentów przedstawionych przez stronę na 
potrzeby prowadzonych postępowań z oryginałem.

***
## Art. 269. {#kpa-x-art-269}

Decyzje określone w innych przepisach prawnych jako prawomocne 
uważa się za ostateczne, chyba że z przepisów tych wynika, iż dotyczą one takiej 
decyzji, która została utrzymana w mocy w postępowaniu sądowym bądź też nie 
została zaskarżona w tym postępowaniu z powodu upływu terminu do wniesienia 
skargi.

