---
id: code.kpa.dzial.iv
title: "Kodeks postępowania administracyjnego — Dział IV (—)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1960 nr 30 poz. 168"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KPA — Dział IV"]
tags: ["KPA","Kodeks postępowania administracyjnego","Dział IV","PL"]
source_pdf: "D19600168Lj.pdf"
articles: "Art. 182–189l"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpa-iv-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks postępowania administracyjnego — Dział IV: —

Udział prokuratora
***
## Art. 182. {#kpa-iv-art-182}

Prokuratorowi służy prawo zwrócenia się do właściwego organu 
administracji publicznej o wszczęcie postępowania w celu usunięcia stanu 
niezgodnego z prawem.

***
## Art. 183. {#kpa-iv-art-183}

**§ 1.** Prokuratorowi służy prawo udziału w każdym stadium 
postępowania w celu zapewnienia, aby postępowanie i rozstrzygnięcie sprawy było 
zgodne z prawem. 
**§ 2.** Organ administracji publicznej zawiadamia prokuratora o wszczęciu 
postępowania oraz o toczącym się postępowaniu w każdym przypadku, gdy uzna 
udział prokuratora w postępowaniu za potrzebny.

***
## Art. 184. {#kpa-iv-art-184}

**§ 1.** Prokuratorowi służy prawo wniesienia sprzeciwu od decyzji 
ostatecznej, jeżeli przepisy kodeksu lub przepisy szczególne przewidują wznowienie 
postępowania, stwierdzenie nieważności decyzji albo jej uchylenie lub zmianę. 
**§ 2.** Prokurator wnosi sprzeciw do organu właściwego do wznowienia 
postępowania, stwierdzenia nieważności decyzji albo jej uchylenia lub zmiany. 

 
 
 
s. 67/89 
 
2025-08-27 
**§ 3.** Sprzeciw od decyzji wydanej przez ministra wnosi Prokurator Generalny. 
**§ 4.** Jeżeli podstawą sprzeciwu jest naruszenie przepisu art. 145 § 1 pkt 4, 
wniesienie sprzeciwu wymaga zgody strony.

***
## Art. 185. {#kpa-iv-art-185}

**§ 1.** Sprzeciw prokuratora powinien być rozpatrzony i załatwiony 
w terminie trzydziestu dni od daty jego wniesienia. 
**§ 2.** W razie niezałatwienia sprzeciwu w terminie określonym w § 1 mają 
odpowiednie zastosowanie przepisy art. 36–38.

***
## Art. 186. {#kpa-iv-art-186}

W przypadku wniesienia sprzeciwu przez prokuratora właściwy organ 
administracji publicznej wszczyna w sprawie postępowanie z urzędu, zawiadamiając 
o tym strony.

***
## Art. 187. {#kpa-iv-art-187}

W przypadku 
wniesienia 
przez 
prokuratora 
sprzeciwu 
organ 
administracji publicznej, do którego sprzeciw wniesiono, obowiązany jest 
niezwłocznie rozpatrzyć, czy zachodzi potrzeba wstrzymania wykonania decyzji do 
chwili załatwienia sprzeciwu.

***
## Art. 188. {#kpa-iv-art-188}

Prokuratorowi, który bierze udział w postępowaniu w przypadkach 
określonych w art. 182–184, służą prawa strony.

***
## Art. 189. {#kpa-iv-art-189}

Prokurator, który wniósł skargę na decyzję organu administracji 
publicznej do sądu administracyjnego, nie może z tych samych przyczyn wnieść 
sprzeciwu. 
A 
Administracyjne kary pieniężne

***
## Art. 189a. {#kpa-iv-art-189a}

**§ 1.** W sprawach nakładania lub wymierzania administracyjnej kary 
pieniężnej lub udzielania ulg w jej wykonaniu stosuje się przepisy niniejszego działu. 
**§ 2.** W przypadku uregulowania w przepisach odrębnych: 
- 1) przesłanek wymiaru administracyjnej kary pieniężnej, 
- 2) odstąpienia od nałożenia administracyjnej kary pieniężnej lub udzielenia 
pouczenia, 
- 3) terminów przedawnienia nakładania administracyjnej kary pieniężnej, 
- 4) terminów przedawnienia egzekucji administracyjnej kary pieniężnej, 
- 5) odsetek od zaległej administracyjnej kary pieniężnej, 
- 6) udzielania ulg w wykonaniu administracyjnej kary pieniężnej 

 
 
 
s. 68/89 
 
2025-08-27 
 
– przepisów niniejszego działu w tym zakresie nie stosuje się. 
**§ 3.** W sprawach nakładania lub wymierzania przez organ administracji 
publicznej kar na podstawie przepisów o postępowaniu w sprawach o wykroczenia, 
odpowiedzialności dyscyplinarnej, porządkowej lub z tytułu naruszenia dyscypliny 
finansów publicznych, przepisów niniejszego działu nie stosuje się.

***
## Art. 189b. {#kpa-iv-art-189b}

Przez administracyjną karę pieniężną rozumie się określoną w 
ustawie sankcję o charakterze pieniężnym, nakładaną przez organ administracji 
publicznej, w drodze decyzji, w następstwie naruszenia prawa polegającego na nie-
dopełnieniu obowiązku albo naruszeniu zakazu ciążącego na osobie fizycznej, osobie 
prawnej albo jednostce organizacyjnej nieposiadającej osobowości prawnej.

***
## Art. 189c. {#kpa-iv-art-189c}

Jeżeli w czasie wydawania decyzji w sprawie administracyjnej kary 
pieniężnej obowiązuje ustawa inna niż w czasie naruszenia prawa, w następstwie 
którego ma być nałożona kara, stosuje się ustawę nową, jednakże należy stosować 
ustawę obowiązującą poprzednio, jeżeli jest ona względniejsza dla strony.

***
## Art. 189d. {#kpa-iv-art-189d}

Wymierzając administracyjną karę pieniężną, organ administracji 
publicznej bierze pod uwagę: 
- 1) wagę i okoliczności naruszenia prawa, w szczególności potrzebę ochrony życia 
lub zdrowia, ochrony mienia w znacznych rozmiarach lub ochrony ważnego 
interesu publicznego lub wyjątkowo ważnego interesu strony oraz czas trwania 
tego naruszenia; 
- 2) częstotliwość niedopełniania w przeszłości obowiązku albo naruszania zakazu 
tego samego rodzaju co niedopełnienie obowiązku albo naruszenie zakazu, w 
następstwie którego ma być nałożona kara; 
- 3) uprzednie ukaranie za to samo zachowanie za przestępstwo, przestępstwo 
skarbowe, wykroczenie lub wykroczenie skarbowe; 
- 4) stopień przyczynienia się strony, na którą jest nakładana administracyjna kara 
pieniężna, do powstania naruszenia prawa; 
- 5) działania podjęte przez stronę dobrowolnie w celu uniknięcia skutków naruszenia 
prawa; 
- 6) wysokość korzyści, którą strona osiągnęła, lub straty, której uniknęła; 
- 7) w przypadku osoby fizycznej – warunki osobiste strony, na którą administracyjna 
kara pieniężna jest nakładana. 

 
 
 
s. 69/89 
 
2025-08-27

***
## Art. 189e. {#kpa-iv-art-189e}

W przypadku gdy do naruszenia prawa doszło wskutek działania siły 
wyższej, strona nie podlega ukaraniu.

***
## Art. 189f. {#kpa-iv-art-189f}

**§ 1.** Organ administracji publicznej, w drodze decyzji, odstępuje od 
nałożenia administracyjnej kary pieniężnej i poprzestaje na pouczeniu, jeżeli: 
- 1) waga naruszenia prawa jest znikoma, a strona zaprzestała naruszania prawa lub 
- 2) za to samo zachowanie prawomocną decyzją na stronę została uprzednio 
nałożona administracyjna kara pieniężna przez inny uprawniony organ 
administracji publicznej lub strona została prawomocnie ukarana za wykroczenie 
lub wykroczenie skarbowe, lub prawomocnie skazana za przestępstwo lub 
przestępstwo skarbowe i uprzednia kara spełnia cele, dla których miałaby być 
nałożona administracyjna kara pieniężna. 
**§ 2.** W przypadkach innych niż wymienione w § 1, jeżeli pozwoli to na spełnienie 
celów, dla których miałaby być nałożona administracyjna kara pieniężna, organ 
administracji publicznej, w drodze postanowienia, może wyznaczyć stronie termin do 
przedstawienia dowodów potwierdzających: 
- 1) usunięcie naruszenia prawa lub 
- 2) powiadomienie właściwych podmiotów o stwierdzonym naruszeniu prawa, 
określając termin i sposób powiadomienia. 
**§ 3.** Organ administracji publicznej w przypadkach, o których mowa w § 2, 
odstępuje od nałożenia administracyjnej kary pieniężnej i poprzestaje na pouczeniu, 
jeżeli strona przedstawiła dowody, potwierdzające wykonanie postanowienia.

***
## Art. 189g. {#kpa-iv-art-189g}

**§ 1.** Administracyjna kara pieniężna nie może zostać nałożona, jeżeli 
upłynęło pięć lat od dnia naruszenia prawa albo wystąpienia skutków naruszenia 
prawa. 
**§ 2.** Przepisu § 1 nie stosuje się do spraw, w przypadku których przepisy odrębne 
przewidują termin, po upływie którego nie można wszcząć postępowania w sprawie 
nałożenia administracyjnej kary pieniężnej lub stwierdzenia naruszenia prawa, w 
następstwie którego może być nałożona administracyjna kara pieniężna. 
**§ 3.** Administracyjna kara pieniężna nie podlega egzekucji, jeżeli upłynęło pięć 
lat od dnia, w którym kara powinna być wykonana.

***
## Art. 189h. {#kpa-iv-art-189h}

**§ 1.** Bieg terminu przedawnienia nałożenia administracyjnej kary 
pieniężnej przerywa ogłoszenie upadłości strony. 

 
 
 
s. 70/89 
 
2025-08-27 
**§ 2.** Po przerwaniu biegu terminu przedawnienia nałożenia administracyjnej kary 
pieniężnej biegnie on na nowo od dnia następującego po dniu uprawomocnienia się 
postanowienia o zakończeniu lub umorzeniu postępowania upadłościowego. 
**§ 3.** Jeżeli ogłoszenie upadłości strony nastąpiło przed rozpoczęciem biegu 
terminu przedawnienia nałożenia administracyjnej kary pieniężnej, bieg tego terminu 
rozpoczyna się od dnia następującego po dniu uprawomocnienia się postanowienia o 
zakończeniu lub umorzeniu postępowania upadłościowego. 
**§ 4.** Bieg terminu przedawnienia nałożenia administracyjnej kary pieniężnej nie 
rozpoczyna się, a rozpoczęty ulega zawieszeniu z dniem: 
- 1) wniesienia środka zaskarżenia od decyzji w przedmiocie administracyjnej kary 
pieniężnej do sądu administracyjnego albo sądu powszechnego, albo skargi 
kasacyjnej od prawomocnego orzeczenia w przedmiocie administracyjnej kary 
pieniężnej; 
- 2) wniesienia żądania ustalenia przez sąd powszechny istnienia lub nieistnienia 
stosunku prawnego lub prawa; 
- 3) doręczenia zarządzenia zabezpieczenia w trybie przepisów o postępowaniu 
egzekucyjnym w administracji, jeżeli przepisy odrębne przewidują możliwość 
zarządzenia zabezpieczenia; 
- 4) wydania 
postanowienia 
o zawieszeniu 
postępowania 
na 
podstawie 
art. 97 § 1 pkt 2–4.  
**§ 5.** Termin przedawnienia nałożenia administracyjnej kary pieniężnej 
rozpoczyna się, a po zawieszeniu biegnie dalej, od dnia następującego po dniu: 
- 1) uprawomocnienia 
się 
orzeczenia 
sądu 
administracyjnego 
albo 
sądu 
powszechnego właściwego do rozpoznania odwołania od decyzji w przedmiocie 
administracyjnej kary pieniężnej, albo odmowy przyjęcia skargi kasacyjnej do 
rozpoznania przez Sąd Najwyższy, oddalenia skargi kasacyjnej, albo uchylenia 
przez Sąd Najwyższy zaskarżonego wyroku i orzeczenia co do istoty sprawy; 
- 2) uprawomocnienia się orzeczenia lub ogłoszenia prawomocnego orzeczenia sądu 
powszechnego w sprawie ustalenia istnienia lub nieistnienia stosunku prawnego 
lub prawa; 
- 3) zakończenia 
postępowania 
zabezpieczającego 
w 
trybie 
przepisów 
o 
postępowaniu egzekucyjnym w administracji; 
- 4) podjęcia postępowania w przypadku, o którym mowa w art. 97 § 2. 

 
 
 
s. 71/89 
 
2025-08-27

***
## Art. 189i. {#kpa-iv-art-189i}

**§ 1.** Zaległą administracyjną karą pieniężną jest kara niezapłacona 
w terminie 14 dni od dnia, w którym decyzja w sprawie administracyjnej kary 
pieniężnej stała się ostateczna, a jeżeli przepisy szczególne wskazują inny termin 
zapłaty administracyjnej kary pieniężnej – zaległą administracyjną karą pieniężną jest 
kara niezapłacona w tym terminie. 
**§ 2.** Od zaległej administracyjnej kary pieniężnej nalicza się odsetki za zwłokę w 
wysokości określonej jak dla zaległości podatkowych, chyba że przepisy odrębne 
stanowią inaczej.

***
## Art. 189j. {#kpa-iv-art-189j}

**§ 1.** Bieg terminu przedawnienia egzekucji administracyjnej kary 
pieniężnej przerywa ogłoszenie upadłości strony. 
**§ 2.** Po przerwaniu biegu terminu przedawnienia egzekucji administracyjnej kary 
pieniężnej biegnie on na nowo od dnia następującego po dniu uprawomocnienia się 
postanowienia o zakończeniu lub umorzeniu postępowania upadłościowego. 
**§ 3.** Jeżeli ogłoszenie upadłości strony nastąpiło przed rozpoczęciem biegu 
terminu przedawnienia egzekucji administracyjnej kary pieniężnej, bieg tego terminu 
rozpoczyna się od dnia następującego po dniu uprawomocnienia się postanowienia 
o zakończeniu lub umorzeniu postępowania upadłościowego. 
**§ 4.** Bieg terminu przedawnienia egzekucji administracyjnej kary pieniężnej nie 
rozpoczyna się, a rozpoczęty ulega przerwaniu z dniem: 
- 1) zastosowania 
środka 
egzekucyjnego, 
o 
którym 
zobowiązany 
został 
zawiadomiony; 
- 2) doręczenia zarządzenia zabezpieczenia w trybie przepisów o postępowaniu 
egzekucyjnym w administracji. 
**§ 5.** Bieg terminu przedawnienia egzekucji administracyjnej kary pieniężnej 
rozpoczyna się, a po przerwaniu biegnie na nowo, od dnia następującego po dniu, w 
którym: 
- 1) zastosowano środek egzekucyjny, o którym zobowiązany został zawiadomiony; 
- 2) doręczono zarządzenie zabezpieczenia w trybie przepisów o postępowaniu 
egzekucyjnym w administracji.

***
## Art. 189k. {#kpa-iv-art-189k}

**§ 1.** Organ administracji publicznej, który nałożył administracyjną 
karę pieniężną, na wniosek strony, w przypadkach uzasadnionych ważnym interesem 

 
 
 
s. 72/89 
 
2025-08-27 
 
publicznym lub ważnym interesem strony, może udzielić ulg w wykonaniu 
administracyjnej kary pieniężnej przez: 
- 1) odroczenie terminu zapłaty lub rozłożenie na raty zapłaty administracyjnej kary 
pieniężnej;   
- 2) odroczenie terminu zapłaty lub rozłożenie na raty zapłaty zaległej 
administracyjnej kary pieniężnej wraz z odsetkami za zwłokę;   
- 3) umorzenie administracyjnej kary pieniężnej w całości lub części; 
- 4) umorzenie odsetek za zwłokę w całości lub części. 
**§ 2.** W przypadku umorzenia zaległej administracyjnej kary pieniężnej 
umorzeniu podlegają także odsetki za zwłokę w całości lub takiej części, w jakiej 
została umorzona zaległa administracyjna kara pieniężna. 
 2a. Od zaległej administracyjnej kary pieniężnej, której termin zapłaty został 
odroczony lub zapłata została rozłożona na raty, odsetki za zwłokę są naliczane do 
dnia wniesienia wniosku strony o odroczenie terminu jej zapłaty lub rozłożenie zapłaty 
na raty, włącznie z tym dniem. 
**§ 2b.** Jeżeli decyzja o odmowie odroczenia terminu zapłaty lub rozłożenia na raty 
zapłaty administracyjnej kary pieniężnej została doręczona stronie: 
- 1) przed upływem dwóch miesięcy od dnia wniesienia wniosku o jej odroczenie lub 
rozłożenie na raty, odsetki za zwłokę są naliczane, począwszy od dnia 
następującego po dniu upływu terminu zapłaty administracyjnej kary pieniężnej; 
- 2) po upływie dwóch miesięcy od dnia wniesienia wniosku o jej odroczenie lub 
rozłożenie na raty, dalsze odsetki za zwłokę są naliczane z wyłączeniem okresu 
od dnia następującego po dniu wniesienia wniosku do dnia doręczenia tej decyzji, 
włącznie z tym dniem. 
**§ 2c.** W razie niedotrzymania terminu zapłaty odroczonej administracyjnej kary 
pieniężnej lub terminu zapłaty którejkolwiek z rat, na jakie została rozłożona 
administracyjna kara pieniężna, z mocy prawa następuje wygaśnięcie decyzji o: 
- 1) odroczeniu terminu zapłaty administracyjnej kary pieniężnej – w całości; 
- 2) rozłożeniu na raty zapłaty administracyjnej kary pieniężnej – w części dotyczącej 
raty niezapłaconej w terminie zapłaty. 
**§ 2d.** W razie niedotrzymania terminu zapłaty trzech z rat, na jakie została 
rozłożona administracyjna kara pieniężna, z mocy prawa następuje wygaśnięcie 

 
 
 
s. 73/89 
 
2025-08-27 
 
decyzji o rozłożeniu na raty zapłaty administracyjnej kary pieniężnej w zakresie 
wszystkich niezapłaconych rat. 
**§ 2e.** W przypadkach, o których mowa w § 2c i 2d, odsetki za zwłokę są 
naliczane od dnia wniesienia wniosku strony o odroczenie lub rozłożenie na raty 
zapłaty administracyjnej kary pieniężnej, włącznie z tym dniem. 
**§ 2f.** Przepisy § 2b–2e stosuje się odpowiednio do odroczonej lub rozłożonej na 
raty zapłaty zaległej administracyjnej kary pieniężnej.  
**§ 3.** Właściwy organ, na wniosek strony prowadzącej działalność gospodarczą, 
może udzielać określonych w § 1 ulg w wykonaniu administracyjnej kary pieniężnej, 
które: 
- 1) nie stanowią pomocy publicznej; 
- 2) stanowią pomoc de minimis albo pomoc de minimis w rolnictwie lub 
rybołówstwie – w zakresie i na zasadach określonych w bezpośrednio 
obowiązujących przepisach prawa Unii Europejskiej dotyczących pomocy w 
ramach zasady de minimis; 
- 3) stanowią pomoc publiczną: 
  - a) mającą na celu naprawienie szkód spowodowanych klęskami żywiołowymi 
lub innymi zdarzeniami nadzwyczajnymi, 
  - b) mającą na celu zaradzenie poważnym zaburzeniom w gospodarce, 
  - c) zgodną z zasadami rynku wewnętrznego Unii Europejskiej, której 
dopuszczalność została określona przez właściwe organy Unii Europejskiej, 
udzielaną na przeznaczenie inne niż wymienione w lit. a i b. 
**§ 4.** W przypadku pomocy publicznej określonej w § 3 pkt 3 lit. a i b ulgi, o 
których mowa w § 3 pkt 2, mogą być udzielane, jeżeli w przepisach odrębnych zostały 
określone szczegółowe warunki udzielania tej pomocy, zapewniające jej zgodność z 
zasadami rynku wewnętrznego Unii Europejskiej. 
**§ 4a.** Do pomocy publicznej, o której mowa w § 3 pkt 3 lit. c, przeznaczonej na 
restrukturyzację, stosuje się: 
- 1) w zakresie warunków udzielania tej pomocy: 
  - a) w przypadku przedsiębiorcy, wobec którego jest prowadzone postępowanie 
restrukturyzacyjne – przepisy ustawy z dnia 15 maja 2015 r. – Prawo 
restrukturyzacyjne (Dz. U. z 2022 r. poz. 2309 oraz z 2023 r. poz. 1723 i 
1860), 

 
 
 
s. 74/89 
 
2025-08-27 
  - b) w przypadku przedsiębiorcy, wobec którego nie jest prowadzone 
postępowanie restrukturyzacyjne – przepisy ustawy z dnia 16 lipca 2020 r. 
o udzielaniu pomocy publicznej w celu ratowania lub restrukturyzacji 
przedsiębiorców (Dz. U. poz. 1298); 
- 2) w zakresie trybu udzielania tej pomocy – przepisy ustawy z dnia 16 lipca 2020 r. 
o udzielaniu pomocy publicznej w celu ratowania lub restrukturyzacji 
przedsiębiorców. 
**§ 5.** Rada Ministrów może określić, w drodze rozporządzenia, inne niż 
restrukturyzacja przeznaczenie pomocy, o której mowa w § 3 pkt 3 lit. c, udzielanej w 
formie ulg w wykonaniu administracyjnej kary pieniężnej oraz warunki i tryb 
udzielania tych ulg, mając na uwadze dopuszczalność i warunki udzielania pomocy 
państwa określone przez właściwe organy Unii Europejskiej.

***
## Art. 189l. {#kpa-iv-art-189l}

**§ 1.** Organ administracji publicznej, który nałożył administracyjną 
karę pieniężną, może z urzędu udzielić ulg w wykonaniu administracyjnej kary 
pieniężnej, o których mowa w art. 189k § 1 pkt 3 i 4, jeżeli: 
- 1) zachodzi uzasadnione przypuszczenie, że egzekucja zaległej administracyjnej 
kary pieniężnej będzie bezskuteczna z powodu braku majątku lub źródła 
dochodu zobowiązanego, z których jest możliwe wyegzekwowanie środków 
pieniężnych przewyższających koszty egzekucyjne; 
- 2) zaległa administracyjna kara pieniężna nie została zaspokojona w zakończonym 
postępowaniu likwidacyjnym lub upadłościowym; 
- 3) wysokość zaległej administracyjnej kary pieniężnej nie przekracza pięciokrotnej 
wysokości kosztów upomnienia, o którym mowa w ustawie z dnia 17 czerwca 
1966 r. o postępowaniu egzekucyjnym w administracji (Dz. U. z 2025 r. 
poz. 132 i 620). 
**§ 2.** Przepis art. 189k § 2 stosuje się odpowiednio. 
**§ 3.** W przypadku, o którym mowa w § 1 pkt 2, decyzję o udzieleniu ulgi 
w wykonaniu administracyjnej kary pieniężnej pozostawia się w aktach sprawy ze 
skutkiem doręczenia. 
**§ 4.** W przypadku, o którym mowa w § 1 pkt 2, właściwy organ może umorzyć 
zaległą administracyjną karę pieniężną, jeżeli umorzenie: 
- 1) nie będzie stanowiło pomocy publicznej lub 

 
 
 
s. 75/89 
 
2025-08-27 
- 2) będzie stanowiło pomoc udzielaną zgodnie z warunkami dopuszczalności 
pomocy de minimis albo pomocy de minimis w rolnictwie lub rybołówstwie – 
w zakresie i na zasadach określonych w bezpośrednio obowiązujących 
przepisach prawa Unii Europejskiej dotyczących pomocy w ramach zasady de 
minimis.

