---
id: code.kpa.dzial.i
title: Kodeks postępowania administracyjnego — Dział I (—)
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: Dz.U. 1960 nr 30 poz. 168
status: obowiązujący
last_consolidated: '2025-01-01'
aliases:
- KPA — Dział I
tags:
- KPA
- Kodeks postępowania administracyjnego
- Dział I
- PL
source_pdf: D19600168Lj.pdf
articles: Art. 1–60
chunking:
  strategy: by-article
  article_anchor_pattern: '## Art. {n}. {#kpa-i-art-{n}}'
  separators: '***'
  hierarchy:
  - Dział
  - Rozdział
  - Oddział
---

# Kodeks postępowania administracyjnego — Dział I: —

Przepisy ogólne 
Rozdział 1 
Zakres obowiązywania
***
## Art. 1. {#kpa-i-art-1}

Kodeks postępowania administracyjnego normuje: 
- 1) postępowanie przed organami administracji publicznej w należących do 
właściwości tych organów sprawach indywidualnych rozstrzyganych w drodze 
decyzji administracyjnych albo załatwianych milcząco; 
- 2) postępowanie przed innymi organami państwowymi oraz przed innymi 
podmiotami, gdy są one powołane z mocy prawa lub na podstawie porozumień 
do załatwiania spraw określonych w pkt 1; 
- 3) postępowanie w sprawach rozstrzygania sporów o właściwość między organami 
jednostek samorządu terytorialnego i organami administracji rządowej oraz 
między organami i podmiotami, o których mowa w pkt 2; 
- 4) postępowanie w sprawach wydawania zaświadczeń; 
- 5) nakładanie lub wymierzanie administracyjnych kar pieniężnych lub udzielanie 
ulg w ich wykonaniu;  
- 6) tryb europejskiej współpracy administracyjnej.

***
## Art. 2. {#kpa-i-art-2}

Kodeks postępowania administracyjnego normuje ponadto postępowanie 
w sprawie skarg i wniosków (Dział VIII) przed organami państwowymi, organami 
jednostek samorządu terytorialnego oraz przed organami organizacji społecznych. 
Opracowano na 
podstawie: 
t.j. 
Dz. U. z 2024 r. 
poz. 572, z 2025 r. 
poz. 769. 

 
 
 
s. 2/89 
 
2025-08-27

***
## Art. 2a. {#kpa-i-art-2a}

**§ 1.** Kodeks postępowania administracyjnego normuje również sposób 
wykonywania obowiązku, o którym mowa w art. 13 ust. 1 i 2 rozporządzenia 
Parlamentu Europejskiego i Rady (UE) 2016/679 z dnia 27 kwietnia 2016 r. w sprawie 
ochrony osób fizycznych w związku z przetwarzaniem danych osobowych 
i w sprawie swobodnego przepływu takich danych oraz uchylenia dyrektywy 
95/46/WE (ogólne rozporządzenie o ochronie danych) (Dz. Urz. UE L 119 
z 04.05.2016, str. 1, z późn. zm.1)), zwanego dalej „rozporządzeniem 2016/679”, w 
postępowaniach wymienionych w art. 1 i art. 2. 
**§ 2.** Wykonywanie 
obowiązku, 
o którym 
mowa 
w art. 13 ust. 1 
i 2 rozporządzenia 2016/679, odbywa się niezależnie od obowiązków organów 
administracji 
publicznej 
przewidzianych 
w Kodeksie 
postępowania 
administracyjnego i nie wpływa na tok i wynik postępowania. 
**§ 3.** Wystąpienie z żądaniem, o którym mowa w art. 18 ust. 1 rozporządzenia 
2016/679, nie wpływa na tok i wynik postępowania.

***
## Art. 3. {#kpa-i-art-3}

**§ 1.** Przepisów Kodeksu postępowania administracyjnego nie stosuje się 
do: 
- 1) postępowania w sprawach karnych skarbowych; 
- 2) spraw uregulowanych w ustawie z dnia 29 sierpnia 1997 r. – Ordynacja 
podatkowa (Dz. U. z 2023 r. poz. 2383 i 2760), z wyjątkiem przepisów działów 
IV i VIII. 
**§ 2.** Przepisów Kodeksu postępowania administracyjnego nie stosuje się również 
do postępowania w sprawach: 
- 1) (uchylony) 
- 2) (uchylony) 
- 3) (uchylony) 
- 4) należących do właściwości polskich przedstawicielstw dyplomatycznych 
i urzędów konsularnych, 
o ile przepisy szczególne nie stanowią inaczej. 
**§ 3.** Przepisów Kodeksu postępowania administracyjnego nie stosuje się także do 
postępowania w sprawach wynikających z: 
- 1) Zmiana wymienionego rozporządzenia została ogłoszona w Dz. Urz. UE L 127 z 23.05.2018, str. 2. 

 
 
 
s. 3/89 
 
2025-08-27 
- 1) nadrzędności i podległości organizacyjnej w stosunkach między organami 
państwowymi i innymi państwowymi jednostkami organizacyjnymi, 
- 2) podległości służbowej pracowników organów i jednostek organizacyjnych 
wymienionych w pkt 1, 
o ile przepisy szczególne nie stanowią inaczej. 
**§ 4.** Do postępowania w sprawach wymienionych w § 1, 2 i 3 pkt 2 stosuje się 
jednak przepisy działu VIII. 
**§ 5.** Rada Ministrów w drodze rozporządzenia może rozciągnąć przepisy 
Kodeksu postępowania administracyjnego w całości lub w części na postępowania 
w sprawach wymienionych w § 2.

***
## Art. 4. {#kpa-i-art-4}

Kodeks postępowania administracyjnego nie narusza szczególnych 
uprawnień wynikających z immunitetu dyplomatycznego i konsularnego oraz umów 
i zwyczajów międzynarodowych.

***
## Art. 5. {#kpa-i-art-5}

**§ 1.** Jeżeli przepis prawa powołuje się ogólnie na przepisy 
o postępowaniu administracyjnym, rozumie się przez to przepisy Kodeksu 
postępowania administracyjnego. 
**§ 2.** Ilekroć w przepisach Kodeksu postępowania administracyjnego jest mowa 
o: 
- 1) kodeksie – rozumie się przez to Kodeks postępowania administracyjnego; 
- 2) (uchylony) 
- 3) organach administracji publicznej – rozumie się przez to ministrów, centralne 
organy administracji rządowej, wojewodów, działające w ich lub we własnym 
imieniu inne terenowe organy administracji rządowej (zespolonej i nie-
zespolonej), organy jednostek samorządu terytorialnego oraz organy i podmioty 
wymienione w art. 1 pkt 2; 
- 4) ministrach – rozumie się przez to Prezesa i wiceprezesa Rady Ministrów 
pełniących funkcję ministra kierującego określonym działem administracji 
rządowej, ministrów kierujących określonym działem administracji rządowej, 
przewodniczących 
komitetów 
wchodzących 
w skład 
Rady 
Ministrów, 
kierowników centralnych urzędów administracji rządowej podległych, 
podporządkowanych lub nadzorowanych przez Prezesa Rady Ministrów lub 

 
 
 
s. 4/89 
 
2025-08-27 
 
właściwego ministra, a także kierowników innych równorzędnych urzędów 
państwowych załatwiających sprawy, o których mowa w art. 1 pkt 1 i 4; 
- 5) organizacjach społecznych – rozumie się przez to organizacje zawodowe, 
samorządowe, spółdzielcze i inne organizacje społeczne; 
- 6) organach jednostek samorządu terytorialnego – rozumie się przez to organy 
gminy, powiatu, województwa, związków gmin, związków powiatów, wójta, 
burmistrza (prezydenta miasta), starostę, marszałka województwa oraz 
kierowników służb, inspekcji i straży działających w imieniu wójta, burmistrza 
(prezydenta miasta), starosty lub marszałka województwa, a ponadto 
samorządowe kolegia odwoławcze. 
Rozdział 2 
Zasady ogólne

***
## Art. 6. {#kpa-i-art-6}

Organy administracji publicznej działają na podstawie przepisów prawa.

***
## Art. 7. {#kpa-i-art-7}

W toku postępowania organy administracji publicznej stoją na straży 
praworządności, z urzędu lub na wniosek stron podejmują wszelkie czynności 
niezbędne do dokładnego wyjaśnienia stanu faktycznego oraz do załatwienia sprawy, 
mając na względzie interes społeczny i słuszny interes obywateli.

***
## Art. 7a. {#kpa-i-art-7a}

**§ 1.** Jeżeli przedmiotem postępowania administracyjnego jest nałożenie 
na stronę obowiązku bądź ograniczenie lub odebranie stronie uprawnienia, a w sprawie 
pozostają wątpliwości co do treści normy prawnej, wątpliwości te są rozstrzygane na 
korzyść strony, chyba że sprzeciwiają się temu sporne interesy stron albo interesy osób 
trzecich, na które wynik postępowania ma bezpośredni wpływ. 
**§ 2.** Przepisu § 1 nie stosuje się: 
- 1) jeżeli wymaga tego ważny interes publiczny, w tym istotne interesy państwa, a 
w szczególności jego bezpieczeństwa, obronności lub porządku publicznego; 
- 2) w sprawach osobowych funkcjonariuszy oraz żołnierzy zawodowych.

***
## Art. 7b. {#kpa-i-art-7b}

W toku postępowania organy administracji publicznej współdziałają ze 
sobą w zakresie niezbędnym do dokładnego wyjaśnienia stanu faktycznego i 
prawnego sprawy, mając na względzie interes społeczny i słuszny interes obywateli 
oraz sprawność postępowania, przy pomocy środków adekwatnych do charakteru, 
okoliczności i stopnia złożoności sprawy. 

 
 
 
s. 5/89 
 
2025-08-27

***
## Art. 8. {#kpa-i-art-8}

**§ 1.** Organy administracji publicznej prowadzą postępowanie w sposób 
budzący zaufanie jego uczestników do władzy publicznej, kierując się zasadami 
proporcjonalności, bezstronności i równego traktowania. 
**§ 2.** Organy administracji publicznej bez uzasadnionej przyczyny nie odstępują 
od utrwalonej praktyki rozstrzygania spraw w takim samym stanie faktycznym i 
prawnym.

***
## Art. 9. {#kpa-i-art-9}

Organy administracji publicznej są obowiązane do należytego 
i wyczerpującego informowania stron o okolicznościach faktycznych i prawnych, 
które mogą mieć wpływ na ustalenie ich praw i obowiązków będących przedmiotem 
postępowania administracyjnego. Organy czuwają nad tym, aby strony i inne osoby 
uczestniczące w postępowaniu nie poniosły szkody z powodu nieznajomości prawa, 
i w tym celu udzielają im niezbędnych wyjaśnień i wskazówek.

***
## Art. 10. {#kpa-i-art-10}

**§ 1.** Organy administracji publicznej obowiązane są zapewnić stronom 
czynny udział w każdym stadium postępowania, a przed wydaniem decyzji umożliwić 
im wypowiedzenie się co do zebranych dowodów i materiałów oraz zgłoszonych 
żądań. 
**§ 2.** Organy administracji publicznej mogą odstąpić od zasady określonej 
w § 1 tylko w przypadkach, gdy załatwienie sprawy nie cierpi zwłoki ze względu na 
niebezpieczeństwo dla życia lub zdrowia ludzkiego albo ze względu na grożącą 
niepowetowaną szkodę materialną. 
**§ 3.** Organ administracji publicznej obowiązany jest utrwalić w aktach sprawy, 
w drodze adnotacji, przyczyny odstąpienia od zasady określonej w § 1.

***
## Art. 11. {#kpa-i-art-11}

Organy administracji publicznej powinny wyjaśniać stronom zasadność 
przesłanek, którymi kierują się przy załatwieniu sprawy, aby w ten sposób w miarę 
możności doprowadzić do wykonania przez strony decyzji bez potrzeby stosowania 
środków przymusu.

***
## Art. 12. {#kpa-i-art-12}

**§ 1.** Organy administracji publicznej powinny działać w sprawie 
wnikliwie i szybko, posługując się możliwie najprostszymi środkami prowadzącymi 
do jej załatwienia. 
**§ 2.** Sprawy, które nie wymagają zbierania dowodów, informacji lub wyjaśnień, 
powinny być załatwione niezwłocznie. 

 
 
 
s. 6/89 
 
2025-08-27

***
## Art. 13. {#kpa-i-art-13}

**§ 1.** Organy administracji publicznej w sprawach, których charakter na 
to pozwala, dążą do polubownego rozstrzygania kwestii spornych oraz ustalania praw 
i obowiązków będących przedmiotem postępowania w należących do ich właściwości 
sprawach, w szczególności przez podejmowanie czynności: 
- 1) skłaniających strony do zawarcia ugody, w sprawach, w których uczestniczą 
strony o spornych interesach; 
- 2) niezbędnych do przeprowadzenia mediacji. 
**§ 2.** Organy administracji publicznej podejmują wszystkie uzasadnione na 
danym etapie postępowania czynności umożliwiające przeprowadzenie mediacji lub 
zawarcie ugody, a w szczególności udzielają wyjaśnień o możliwościach i korzyściach 
polubownego załatwienia sprawy.

***
## Art. 14. {#kpa-i-art-14}

**§ 1.** (uchylony) 
**§ 1a.** Sprawy należy prowadzić i załatwiać na piśmie utrwalonym w postaci 
papierowej lub elektronicznej. Pisma utrwalone w postaci papierowej opatruje się 
podpisem własnoręcznym. Pisma utrwalone w postaci elektronicznej opatruje się 
kwalifikowanym podpisem elektronicznym, podpisem zaufanym albo podpisem 
osobistym lub kwalifikowaną pieczęcią elektroniczną organu administracji publicznej 
ze wskazaniem w treści pisma osoby opatrującej pismo pieczęcią.  
**§ 1b.** Sprawy mogą być załatwiane z wykorzystaniem pism generowanych 
automatycznie i opatrzonych kwalifikowaną pieczęcią elektroniczną organu 
administracji publicznej. W przypadku pism generowanych automatycznie przepisów 
o konieczności opatrzenia pisma podpisem pracownika organu administracji 
publicznej nie stosuje się.  
**§ 1c.** Sprawy mogą być załatwiane z wykorzystaniem usług online 
udostępnianych przez organy administracji publicznej po uwierzytelnieniu strony lub 
innego uczestnika postępowania w sposób określony w art. 20a ust. 1 albo 2 ustawy z 
dnia 17 lutego 2005 r. o informatyzacji działalności podmiotów realizujących zadania 
publiczne (Dz. U. z 2024 r. poz. 307).  
**§ 1d.** Pisma kierowane do organów administracji publicznej mogą być 
sporządzane na piśmie utrwalonym w postaci papierowej lub elektronicznej. Do 
opatrywania ich podpisami i pieczęciami stosuje się przepisy § 1a i 1b. 
**§ 2.** Sprawy mogą być załatwiane ustnie, telefonicznie, za pomocą środków 
komunikacji elektronicznej w rozumieniu art. 2 pkt 5 ustawy z dnia 18 lipca 2002 r. o 

 
 
 
s. 7/89 
 
2025-08-27 
 
świadczeniu usług drogą elektroniczną (Dz. U. z 2020 r. poz. 344) lub za pomocą 
innych środków łączności, gdy przemawia za tym interes strony, a przepis prawny nie 
stoi temu na przeszkodzie. Treść oraz istotne motywy takiego załatwienia powinny 
być utrwalone w aktach w formie protokołu lub podpisanej przez stronę adnotacji.

***
## Art. 14a. {#kpa-i-art-14a}

Organy administracji publicznej umożliwiają stronom ocenę działania 
urzędów kierowanych przez te organy, w tym pracowników tych urzędów.

***
## Art. 15. {#kpa-i-art-15}

Postępowanie administracyjne jest dwuinstancyjne, chyba że przepis 
szczególny stanowi inaczej.

***
## Art. 16. {#kpa-i-art-16}

**§ 1.** Decyzje, od których nie służy odwołanie w administracyjnym toku 
instancji lub wniosek o ponowne rozpatrzenie sprawy, są ostateczne. Uchylenie lub 
zmiana takich decyzji, stwierdzenie ich nieważności oraz wznowienie postępowania 
może nastąpić tylko w przypadkach przewidzianych w kodeksie lub ustawach 
szczególnych. 
**§ 2.** Decyzje mogą być zaskarżane do sądu administracyjnego z powodu ich 
niezgodności z prawem, na zasadach i w trybie określonych w odrębnych ustawach. 
**§ 3.** Decyzje ostateczne, których nie można zaskarżyć do sądu, są prawomocne. 
Rozdział 3 
Organy wyższego stopnia i organy naczelne

***
## Art. 17. {#kpa-i-art-17}

Organami wyższego stopnia w rozumieniu kodeksu są: 
- 1) w stosunku do organów jednostek samorządu terytorialnego – samorządowe 
kolegia odwoławcze, chyba że ustawy szczególne stanowią inaczej; 
- 2) w stosunku do wojewodów – właściwi w sprawie ministrowie; 
- 3) w stosunku do organów administracji publicznej innych niż określone w pkt 1 
i 2 – odpowiednie organy nadrzędne lub właściwi ministrowie, a w razie ich 
braku – organy państwowe sprawujące nadzór nad ich działalnością; 
- 4) w stosunku do organów organizacji społecznych – odpowiednie organy 
wyższego stopnia tych organizacji, a w razie ich braku – organ państwowy 
sprawujący nadzór nad ich działalnością.

***
## Art. 18. {#kpa-i-art-18}

Organami naczelnymi w rozumieniu kodeksu są: 
- 1) w stosunku do organów administracji rządowej, organów jednostek samorządu 
terytorialnego, z wyjątkiem samorządowych kolegiów odwoławczych, oraz 

 
 
 
s. 8/89 
 
2025-08-27 
 
organów państwowych i samorządowych jednostek organizacyjnych – Prezes 
Rady Ministrów lub właściwi ministrowie; 
- 2) w stosunku do organów państwowych innych niż określone w pkt 1 – 
odpowiednie organy o ogólnokrajowym zasięgu działania; 
- 3) w stosunku do organów organizacji społecznych – naczelne organy tych 
organizacji, a w razie braku takiego organu – Prezes Rady Ministrów lub 
właściwi ministrowie sprawujący zwierzchni nadzór nad ich działalnością. 
Rozdział 4 
Właściwość organów

***
## Art. 19. {#kpa-i-art-19}

Organy administracji publicznej przestrzegają z urzędu swojej 
właściwości rzeczowej i miejscowej.

***
## Art. 20. {#kpa-i-art-20}

Właściwość rzeczową organu administracji publicznej ustala się według 
przepisów o zakresie jego działania.

***
## Art. 21. {#kpa-i-art-21}

**§ 1.** Właściwość miejscową organu administracji publicznej ustala się: 
- 1) w sprawach dotyczących nieruchomości – według miejsca jej położenia; jeżeli 
nieruchomość położona jest na obszarze właściwości dwóch lub więcej organów, 
orzekanie należy do organu, na którego obszarze znajduje się większa część 
nieruchomości; 
- 2) w sprawach dotyczących prowadzenia zakładu pracy – według miejsca, 
w którym zakład pracy jest, był lub ma być prowadzony; 
- 3) w innych sprawach – według miejsca zamieszkania (siedziby) w kraju, a w braku 
zamieszkania w kraju – według miejsca pobytu strony lub jednej ze stron; jeżeli 
żadna ze stron nie ma w kraju zamieszkania (siedziby) lub pobytu – według 
miejsca ostatniego ich zamieszkania (siedziby) lub pobytu w kraju. 
**§ 2.** Jeżeli nie można ustalić właściwości miejscowej w sposób wskazany w § 1, 
sprawa należy do organu właściwego dla miejsca, w którym nastąpiło zdarzenie 
powodujące wszczęcie postępowania, albo w razie braku ustalenia takiego miejsca – 
do organu właściwego dla obszaru dzielnicy Śródmieście w m.st. Warszawie.

***
## Art. 22. {#kpa-i-art-22}

**§ 1.** Spory o właściwość rozstrzygają: 

 
 
 
s. 9/89 
 
2025-08-27 
- 1) między organami jednostek samorządu terytorialnego, z wyjątkiem przypadków 
określonych w pkt 2–4 – wspólny dla nich organ wyższego stopnia, a w razie 
braku takiego organu – sąd administracyjny; 
- 2) między kierownikami służb, inspekcji i straży administracji zespolonej tego 
samego powiatu, działających w imieniu własnym lub w imieniu starosty – 
starosta; 
- 3) między 
organami 
administracji 
zespolonej 
w jednym 
województwie 
niewymienionymi w pkt 2 – wojewoda; 
- 4) między 
organami 
jednostek 
samorządu 
terytorialnego 
w różnych 
województwach w sprawach należących do zadań z zakresu administracji 
rządowej – minister właściwy do spraw administracji publicznej; 
- 5) (uchylony) 
- 6) między wojewodami oraz organami administracji zespolonej w różnych 
województwach – minister właściwy do spraw administracji publicznej; 
- 7) między wojewodą a organami administracji niezespolonej – minister właściwy 
do spraw administracji publicznej po porozumieniu z organem sprawującym 
nadzór nad organem pozostającym w sporze z wojewodą; 
- 8) między organami administracji publicznej innymi niż wymienione w pkt 1–4, 6 
i 7 – wspólny dla nich organ wyższego stopnia, a w razie braku takiego organu – 
minister właściwy do spraw administracji publicznej; 
- 9) między organami administracji publicznej, gdy jednym z nich jest minister – 
Prezes Rady Ministrów. 
**§ 2.** Spory kompetencyjne między organami jednostek samorządu terytorialnego 
a organami administracji rządowej rozstrzyga sąd administracyjny. 
**§ 3.** Z wnioskiem o rozpatrzenie sporu przez sąd administracyjny może 
wystąpić: 
- 1) strona; 
- 2) organ jednostki samorządu terytorialnego lub inny organ administracji 
publicznej, pozostające w sporze; 
- 3) minister właściwy do spraw administracji publicznej; 
- 4) minister właściwy do spraw sprawiedliwości, Prokurator Generalny; 
- 5) Rzecznik Praw Obywatelskich. 

 
 
 
s. 10/89 
 
2025-08-27

***
## Art. 23. {#kpa-i-art-23}

Do czasu rozstrzygnięcia sporu o właściwość organ administracji 
publicznej, na którego obszarze wynikła sprawa, podejmuje tylko czynności 
niecierpiące zwłoki ze względu na interes społeczny lub słuszny interes obywateli 
i zawiadamia o tym organ właściwy do rozstrzygnięcia sporu. 
Rozdział 5 
Wyłączenie pracownika oraz organu

***
## Art. 24. {#kpa-i-art-24}

**§ 1.** Pracownik organu administracji publicznej podlega wyłączeniu od 
udziału w postępowaniu w sprawie: 
- 1) w której jest stroną albo pozostaje z jedną ze stron w takim stosunku prawnym, 
że wynik sprawy może mieć wpływ na jego prawa lub obowiązki; 
- 2) swego małżonka oraz krewnych i powinowatych do drugiego stopnia; 
- 3) osoby związanej z nim z tytułu przysposobienia, opieki lub kurateli; 
- 4) w której był świadkiem lub biegłym albo był lub jest przedstawicielem jednej ze 
stron, albo w której przedstawicielem strony jest jedna z osób wymienionych 
w pkt 2 i 3; 
- 5) w której brał udział w wydaniu zaskarżonej decyzji; 
- 6) z powodu której wszczęto przeciw niemu dochodzenie służbowe, postępowanie 
dyscyplinarne lub karne; 
- 7) w której jedną ze stron jest osoba pozostająca wobec niego w stosunku 
nadrzędności służbowej. 
**§ 2.** Powody wyłączenia pracownika od udziału w postępowaniu trwają także po 
ustaniu małżeństwa (§ 1 pkt 2), przysposobienia, opieki lub kurateli (§ 1 pkt 3). 
**§ 3.** Bezpośredni przełożony pracownika jest obowiązany na jego żądanie lub na 
żądanie strony albo z urzędu wyłączyć go od udziału w postępowaniu, jeżeli zostanie 
uprawdopodobnione istnienie okoliczności niewymienionych w § 1, które mogą 
wywołać wątpliwość co do bezstronności pracownika. 
**§ 4.** Wyłączony pracownik powinien podejmować tylko czynności niecierpiące 
zwłoki ze względu na interes społeczny lub ważny interes stron.

***
## Art. 25. {#kpa-i-art-25}

**§ 1.** Organ administracji publicznej podlega wyłączeniu od załatwienia 
sprawy dotyczącej interesów majątkowych: 
- 1) jego kierownika lub osób pozostających z tym kierownikiem w stosunkach 
określonych w art. 24 § 1 pkt 2 i 3; 

 
 
 
s. 11/89 
 
2025-08-27 
- 2) osoby zajmującej stanowisko kierownicze w organie bezpośrednio wyższego 
stopnia lub osób pozostających z nim w stosunkach określonych w art. 24 § 1 
pkt 2 i 3. 
**§ 2.** Przepis art. 24 § 4 stosuje się odpowiednio.

***
## Art. 26. {#kpa-i-art-26}

**§ 1.** W przypadku wyłączenia pracownika (art. 24) jego bezpośredni 
przełożony wyznacza innego pracownika do prowadzenia sprawy. 
**§ 2.** W przypadku wyłączenia organu sprawę załatwia: 
- 1) w okolicznościach przewidzianych w art. 25 § 1 pkt 1 – organ wyższego stopnia 
nad organem załatwiającym sprawę; 
- 2) w okolicznościach przewidzianych w art. 25 § 1 pkt 2 – organ wyższego stopnia 
nad organem, w którym osoba wymieniona w tym przepisie zajmuje stanowisko 
kierownicze. 
Organ wyższego stopnia może do załatwienia sprawy wyznaczyć inny podległy sobie 
organ. W razie gdy osobą wymienioną w art. 25 § 1 pkt 2 jest minister albo prezes 
samorządowego kolegium odwoławczego, organ właściwy do załatwienia sprawy 
wyznacza Prezes Rady Ministrów. 
**§ 3.** Jeżeli wskutek wyłączenia pracowników organu administracji publicznej 
organ ten stał się niezdolny do załatwienia sprawy, stosuje się odpowiednio § 2.

***
## Art. 27. {#kpa-i-art-27}

**§ 1.** Członek organu kolegialnego podlega wyłączeniu w przypadkach 
określonych w art. 24 § 1. O wyłączeniu tego członka w przypadkach określonych 
w art. 24 § 3 postanawia przewodniczący organu kolegialnego lub organu wyższego 
stopnia na wniosek strony, członka organu kolegialnego albo z urzędu. 
**§ 1a.** Członek samorządowego kolegium odwoławczego podlega wyłączeniu od 
udziału w postępowaniu w sprawie wniosku o ponowne rozpatrzenie sprawy, jeżeli 
brał udział w wydaniu decyzji objętej wnioskiem. 
**§ 2.** Jeżeli wskutek wyłączenia członków organu kolegialnego organ ten stał się 
niezdolny do podjęcia uchwały z braku wymaganego quorum, stosuje się odpowiednio 
przepisy art. 26 § 2. 
**§ 3.** Jeżeli samorządowe kolegium odwoławcze wskutek wyłączenia jego 
członków nie może załatwić sprawy, minister właściwy do spraw administracji 
publicznej, w drodze postanowienia, wyznacza inne samorządowe kolegium 
odwoławcze. 

 
 
 
s. 12/89 
 
2025-08-27

***
## Art. 27a. {#kpa-i-art-27a}

(uchylony) 
Rozdział 6 
Strona

***
## Art. 28. {#kpa-i-art-28}

Stroną jest każdy, czyjego interesu prawnego lub obowiązku dotyczy 
postępowanie albo kto żąda czynności organu ze względu na swój interes prawny lub 
obowiązek.

***
## Art. 29. {#kpa-i-art-29}

Stronami mogą być osoby fizyczne i osoby prawne, a gdy chodzi 
o państwowe i samorządowe jednostki organizacyjne i organizacje społeczne – 
również jednostki nieposiadające osobowości prawnej.

***
## Art. 30. {#kpa-i-art-30}

**§ 1.** Zdolność prawną i zdolność do czynności prawnych stron ocenia 
się według przepisów prawa cywilnego, o ile przepisy szczególne nie stanowią 
inaczej. 
**§ 2.** Osoby fizyczne nieposiadające zdolności do czynności prawnych działają 
przez swych ustawowych przedstawicieli. 
**§ 3.** Strony niebędące osobami fizycznymi działają przez swych ustawowych lub 
statutowych przedstawicieli. 
**§ 4.** W sprawach dotyczących praw zbywalnych lub dziedzicznych w razie 
zbycia prawa lub śmierci strony w toku postępowania na miejsce dotychczasowej 
strony wstępują jej następcy prawni. 
**§ 4a.** W sprawach dotyczących praw zbywalnych lub dziedzicznych, 
wynikających z prowadzenia przedsiębiorstwa strony, w razie jej śmierci w toku 
postępowania, jeżeli został ustanowiony zarząd sukcesyjny przedsiębiorstwem strony, 
na jej miejsce wstępuje zarządca sukcesyjny. W przypadku wygaśnięcia zarządu 
sukcesyjnego do postępowania toczącego się z udziałem zarządcy sukcesyjnego na 
jego miejsce wstępują następcy prawni zmarłego. 
**§ 5.** W sprawach dotyczących spadków nieobjętych jako strony działają osoby 
sprawujące zarząd majątkiem masy spadkowej, a w ich braku – kurator wyznaczony 
przez sąd na wniosek organu administracji publicznej.

***
## Art. 31. {#kpa-i-art-31}

**§ 1.** Organizacja społeczna może w sprawie dotyczącej innej osoby 
występować z żądaniem: 
- 1) wszczęcia postępowania, 

 
 
 
s. 13/89 
 
2025-08-27 
- 2) dopuszczenia jej do udziału w postępowaniu, 
jeżeli jest to uzasadnione celami statutowymi tej organizacji i gdy przemawia za tym 
interes społeczny. 
**§ 1a.** Organizacja społeczna, o której mowa w § 1, może brać udział w 
postępowaniu w imieniu i na rzecz pracownika delegowanego na terytorium RP lub z 
terytorium RP albo pracodawcy delegującego pracownika na terytorium RP lub 
z terytorium RP – za zgodą strony w imieniu i na rzecz której występuje w 
postępowaniu. 
**§ 2.** Organ administracji publicznej, uznając żądanie organizacji społecznej za 
uzasadnione, postanawia o wszczęciu postępowania z urzędu lub o dopuszczeniu 
organizacji do udziału w postępowaniu. Na postanowienie o odmowie wszczęcia 
postępowania lub dopuszczenia do udziału w postępowaniu organizacji społecznej 
służy zażalenie. 
**§ 3.** Organizacja społeczna uczestniczy w postępowaniu na prawach strony. 
**§ 4.** Organ administracji publicznej, wszczynając postępowanie w sprawie 
dotyczącej innej osoby, zawiadamia o tym organizację społeczną, jeżeli uzna, że może 
ona być zainteresowana udziałem w tym postępowaniu ze względu na swoje cele 
statutowe, i gdy przemawia za tym interes społeczny. 
**§ 5.** Organizacja społeczna, która nie uczestniczy w postępowaniu na prawach 
strony, może za zgodą organu administracji publicznej przedstawić temu organowi 
swój pogląd w sprawie, wyrażony w uchwale lub oświadczeniu jej organu 
statutowego. 
**§ 6.** (uchylony)

***
## Art. 32. {#kpa-i-art-32}

Strona może działać przez pełnomocnika, chyba że charakter czynności 
wymaga jej osobistego działania.

***
## Art. 33. {#kpa-i-art-33}

**§ 1.** Pełnomocnikiem strony może być osoba fizyczna posiadająca 
zdolność do czynności prawnych. 
**§ 2.** Pełnomocnictwo powinno być udzielone na piśmie lub zgłoszone do 
protokołu. 
**§ 2a.** (uchylony) 
**§ 3.** Pełnomocnik dołącza do akt oryginał lub urzędowo poświadczony odpis 
pełnomocnictwa. Adwokat, radca prawny, rzecznik patentowy, a także doradca 

 
 
 
s. 14/89 
 
2025-08-27 
 
podatkowy mogą sami uwierzytelnić odpis udzielonego im pełnomocnictwa oraz 
odpisy innych dokumentów wykazujących ich umocowanie. Organ administracji 
publicznej może w razie wątpliwości zażądać urzędowego poświadczenia podpisu 
strony. 
**§ 3a.** (uchylony) 
**§ 4.** W sprawach mniejszej wagi organ administracji publicznej może nie żądać 
pełnomocnictwa, jeśli pełnomocnikiem jest członek najbliższej rodziny lub domownik 
strony, a nie ma wątpliwości co do istnienia i zakresu upoważnienia do występowania 
w imieniu strony.

***
## Art. 34. {#kpa-i-art-34}

**§ 1.** Organ administracji publicznej wystąpi do sądu z wnioskiem 
o wyznaczenie przedstawiciela dla osoby nieobecnej lub niezdolnej do czynności 
prawnych, o ile przedstawiciel nie został już wyznaczony. 
**§ 2.** W przypadku konieczności podjęcia czynności niecierpiącej zwłoki organ 
administracji 
publicznej 
wyznacza 
dla 
osoby 
nieobecnej 
przedstawiciela 
uprawnionego do działania w postępowaniu do czasu wyznaczenia dla niej 
przedstawiciela przez sąd. 
Rozdział 7 
Załatwianie spraw

***
## Art. 35. {#kpa-i-art-35}

**§ 1.** Organy administracji publicznej obowiązane są załatwiać sprawy 
bez zbędnej zwłoki. 
**§ 2.** Niezwłocznie powinny być załatwiane sprawy, które mogą być rozpatrzone 
w oparciu o dowody przedstawione przez stronę łącznie z żądaniem wszczęcia 
postępowania lub w oparciu o fakty i dowody powszechnie znane albo znane z urzędu 
organowi, przed którym toczy się postępowanie, bądź możliwe do ustalenia na 
podstawie danych, którymi rozporządza ten organ. 
**§ 3.** Załatwienie sprawy wymagającej postępowania wyjaśniającego powinno 
nastąpić nie później niż w ciągu miesiąca, a sprawy szczególnie skomplikowanej – nie 
później niż w ciągu dwóch miesięcy od dnia wszczęcia postępowania, zaś 
w postępowaniu odwoławczym – w ciągu miesiąca od dnia otrzymania odwołania. 
**§ 3a.** Załatwienie sprawy w postępowaniu uproszczonym powinno nastąpić 
niezwłocznie, nie później niż w terminie miesiąca od dnia wszczęcia postępowania. 
**§ 4.** Przepisy szczególne mogą określać inne terminy niż określone w § 3 i 3a. 

 
 
 
s. 15/89 
 
2025-08-27 
**§ 5.** Do terminów określonych w przepisach poprzedzających nie wlicza się 
terminów przewidzianych w przepisach prawa dla dokonania określonych czynności, 
okresów doręczania z wykorzystaniem publicznej usługi hybrydowej, o której mowa 
w art. 2 pkt 7 ustawy z dnia 18 listopada 2020 r. o doręczeniach elektronicznych (Dz. 
U. z 2023 r. poz. 285, 1860 i 2699), okresów zawieszenia postępowania, okresu 
trwania mediacji oraz okresów opóźnień spowodowanych z winy strony albo przyczyn 
niezależnych od organu.

***
## Art. 36. {#kpa-i-art-36}

**§ 1.** O każdym przypadku niezałatwienia sprawy w terminie organ 
administracji publicznej jest obowiązany zawiadomić strony, podając przyczyny 
zwłoki, wskazując nowy termin załatwienia sprawy oraz pouczając o prawie do 
wniesienia ponaglenia. 
**§ 2.** Ten sam obowiązek ciąży na organie administracji publicznej również 
w przypadku zwłoki w załatwieniu sprawy z przyczyn niezależnych od organu.

***
## Art. 37. {#kpa-i-art-37}

**§ 1.** Stronie służy prawo do wniesienia ponaglenia, jeżeli: 
- 1) nie załatwiono sprawy w terminie określonym w art. 35 lub przepisach 
szczególnych ani w terminie wskazanym zgodnie z art. 36 § 1 (bezczynność); 
- 2) postępowanie jest prowadzone dłużej niż jest to niezbędne do załatwienia sprawy 
(przewlekłość). 
**§ 2.** Ponaglenie zawiera uzasadnienie. 
**§ 3.** Ponaglenie wnosi się: 
- 1) do organu wyższego stopnia za pośrednictwem organu prowadzącego 
postępowanie; 
- 2) do organu prowadzącego postępowanie – jeżeli nie ma organu wyższego stopnia. 
**§ 3a.** Jeżeli ponaglenie zostało wniesione przed upływem terminu określonego w 
art. 35 albo przepisach szczególnych, organ prowadzący postępowanie pozostawia 
ponaglenie bez rozpoznania. Przepisów § 4–8 nie stosuje się. 
**§ 4.** Organ prowadzący postępowanie jest obowiązany przekazać ponaglenie 
organowi wyższego stopnia bez zbędnej zwłoki, nie później niż w terminie siedmiu 
dni od dnia jego otrzymania. Organ przekazuje ponaglenie wraz z niezbędnymi 
odpisami akt sprawy. Przekazując ponaglenie, organ jest obowiązany ustosunkować 
się do niego. 

 
 
 
s. 16/89 
 
2025-08-27 
**§ 5.** Organ, o którym mowa w § 3, rozpatruje ponaglenie w terminie siedmiu dni 
od dnia jego otrzymania. 
**§ 6.** Organ rozpatrujący ponaglenie wydaje postanowienie, w którym: 
- 1) wskazuje, czy organ rozpatrujący sprawę dopuścił się bezczynności lub 
przewlekłego prowadzenia postępowania, stwierdzając jednocześnie, czy miało 
ono miejsce z rażącym naruszeniem prawa; 
- 2) w przypadku stwierdzenia bezczynności lub przewlekłości: 
  - a) zobowiązuje organ rozpatrujący sprawę do załatwienia sprawy, 
wyznaczając termin do jej załatwienia, jeżeli postępowanie jest 
niezakończone, 
  - b) zarządza wyjaśnienie przyczyn i ustalenie osób winnych bezczynności lub 
przewlekłości, a w razie potrzeby także podjęcie środków zapobiegających 
bezczynności lub przewlekłości w przyszłości. 
**§ 7.** Organ rozpatrujący ponaglenie może z urzędu zmienić postanowienie, o 
którym mowa w § 6, wyznaczając dłuższy termin zakończenia postępowania, jeżeli 
wyjdą na jaw istotne dla sprawy nowe okoliczności faktyczne lub nowe dowody, 
wymagające dłuższego postępowania, nieznane w momencie wyznaczania terminu. 
**§ 8.** W przypadku, o którym mowa w § 3 pkt 2, przepisów § 4, 6 i 7 nie stosuje 
się. W przypadku stwierdzenia bezczynności lub przewlekłości organ prowadzący 
postępowanie niezwłocznie załatwia sprawę oraz zarządza wyjaśnienie przyczyn i 
ustalenie osób winnych bezczynności lub przewlekłości, a w razie potrzeby także 
podjęcie środków zapobiegających bezczynności lub przewlekłości w przyszłości.

***
## Art. 38. {#kpa-i-art-38}

Pracownik organu administracji publicznej podlega odpowiedzialności 
porządkowej lub dyscyplinarnej albo innej odpowiedzialności przewidzianej w 
przepisach prawa, jeżeli z nieuzasadnionych przyczyn nie załatwił sprawy w terminie 
lub prowadził postępowanie dłużej niż było to niezbędne do załatwienia sprawy. 
Rozdział 8 
Doręczenia

***
## Art. 39. {#kpa-i-art-39}

**§ 1.** Organ administracji publicznej doręcza pisma na adres do doręczeń 
elektronicznych, o którym mowa w art. 2 pkt 1 ustawy z dnia 18 listopada 2020 r. o 
doręczeniach elektronicznych, zwany dalej „adresem do doręczeń elektronicznych”, 

 
 
 
s. 17/89 
 
2025-08-27 
 
chyba że doręczenie następuje na konto w systemie teleinformatycznym organu albo 
w siedzibie organu. 
**§ 2.** W przypadku braku możliwości doręczenia w sposób, o którym mowa w § 
1, organ administracji publicznej doręcza pisma za pokwitowaniem:  
- 1) przez operatora wyznaczonego z wykorzystaniem publicznej usługi hybrydowej, 
o której mowa w art. 2 pkt 7 ustawy z dnia 18 listopada 2020 r. o doręczeniach 
elektronicznych, albo  
- 2) przez swoich pracowników lub przez inne upoważnione osoby lub organy.  
**§ 3.** W przypadku braku możliwości doręczenia w sposób, o którym mowa w § 
1 i § 2 pkt 1, organ administracji publicznej doręcza pisma:  
- 1) przesyłką rejestrowaną, o której mowa w art. 3 pkt 23 ustawy z dnia 23 listopada 
2012 r. – Prawo pocztowe (Dz. U. z 2023 r. poz. 1640), albo  
- 2) przez swoich pracowników lub przez inne upoważnione osoby lub organy. 
**§ 4.** W przypadku doręczenia decyzji, której organ administracji publicznej nadał 
rygor natychmiastowej wykonalności, albo decyzji, która podlega natychmiastowemu 
wykonaniu z mocy ustawy, w sprawach osobowych funkcjonariuszy oraz żołnierzy 
zawodowych albo jeżeli wymaga tego ważny interes publiczny, w szczególności 
bezpieczeństwo państwa, obronność lub porządek publiczny, organ administracji 
publicznej może doręczyć decyzję w sposób określony w § 3. Przepisów § 1 i § 2 pkt 
1 nie stosuje się.

***
## Art. 391. {#kpa-i-art-391}

W przypadku doręczenia w sposób, o którym mowa w art. 39 § 1, pisma 
doręcza się stronie lub innemu uczestnikowi postępowania na:  
- 1) adres do doręczeń elektronicznych wpisany do bazy adresów elektronicznych, o 
której mowa w art. 25 ustawy z dnia 18 listopada 2020 r. o doręczeniach 
elektronicznych, zwanej dalej „bazą adresów elektronicznych”, a w przypadku 
pełnomocnika – na adres do doręczeń elektronicznych wskazany w podaniu, albo  
- 2) adres do doręczeń elektronicznych powiązany z kwalifikowaną usługą 
rejestrowanego doręczenia elektronicznego, za pomocą której wniesiono 
podanie, jeżeli adres do doręczeń elektronicznych strony lub innego uczestnika 
postępowania nie został wpisany do bazy adresów elektronicznych.

***
## Art. 392. {#kpa-i-art-392}

(uchylony) 

 
 
 
s. 18/89 
 
2025-08-27

***
## Art. 393. {#kpa-i-art-393}

**§ 1.** W przypadku pism wydanych przez organ administracji publicznej 
w postaci elektronicznej przy wykorzystaniu systemu teleinformatycznego, które 
zostały opatrzone kwalifikowanym podpisem elektronicznym, podpisem zaufanym 
albo podpisem osobistym, zaawansowaną pieczęcią elektroniczną albo kwalifikowaną 
pieczęcią elektroniczną, doręczenie może polegać na doręczeniu wydruku pisma 
uzyskanego z tego systemu odzwierciedlającego treść tego pisma. 
**§ 2.** Wydruk pisma, o którym mowa w § 1, zawiera:  
- 1) informację, że pismo zostało wydane w postaci elektronicznej i podpisane 
kwalifikowanym podpisem elektronicznym, podpisem zaufanym albo podpisem 
osobistym, ze wskazaniem imienia i nazwiska oraz stanowiska służbowego 
osoby, która je podpisała, albo opatrzone zaawansowaną pieczęcią elektroniczną 
albo kwalifikowaną pieczęcią elektroniczną;  
- 2) identyfikator tego pisma, nadawany przez system teleinformatyczny, za pomocą 
którego pismo zostało wydane.  
**§ 3.** Wydruk pisma, o którym mowa w § 1, może zawierać mechanicznie 
odtwarzany podpis osoby, która podpisała pismo.  
**§ 4.** Wydruk pisma, o którym mowa w § 1, stanowi dowód tego, co zostało 
stwierdzone w piśmie wydanym w postaci elektronicznej.

***
## Art. 394. {#kpa-i-art-394}

W przypadku doręczenia w sposób, o którym mowa w art. 39 § 1, do 
ustalenia dnia doręczenia korespondencji stosuje się przepis art. 42 ustawy z dnia 18 
listopada 2020 r. o doręczeniach elektronicznych.

***
## Art. 40. {#kpa-i-art-40}

**§ 1.** Pisma doręcza się stronie, a gdy strona działa przez przedstawiciela 
– temu przedstawicielowi. 
**§ 2.** Jeżeli strona ustanowiła pełnomocnika, pisma doręcza się pełnomocnikowi. 
Jeżeli ustanowiono kilku pełnomocników, doręcza się pisma tylko jednemu 
pełnomocnikowi. Strona może wskazać takiego pełnomocnika. 
**§ 3.** W sprawie wszczętej na skutek podania złożonego przez dwie lub więcej 
stron pisma doręcza się wszystkim stronom, chyba że w podaniu wskazały jedną jako 
upoważnioną do odbioru pism. 
**§ 4.** Strona, która nie ma miejsca zamieszkania lub zwykłego pobytu albo 
siedziby w Rzeczypospolitej Polskiej, innym państwie członkowskim Unii 
Europejskiej, Konfederacji Szwajcarskiej albo państwie członkowskim Europejskiego 
Porozumienia o Wolnym Handlu (EFTA) – stronie umowy o Europejskim Obszarze 

 
 
 
s. 19/89 
 
2025-08-27 
 
Gospodarczym, jeżeli nie ustanowiła pełnomocnika do prowadzenia sprawy 
zamieszkałego w Rzeczypospolitej Polskiej i nie działa za pośrednictwem konsula 
Rzeczypospolitej Polskiej, jest obowiązana wskazać w Rzeczypospolitej Polskiej 
pełnomocnika do doręczeń, chyba że doręczenie następuje usługą rejestrowanego 
doręczenia elektronicznego. 
**§ 5.** W razie niewskazania pełnomocnika do doręczeń przeznaczone dla tej 
strony pisma pozostawia się w aktach sprawy ze skutkiem doręczenia. Stronę należy 
o tym pouczyć przy pierwszym doręczeniu. Strona powinna być również pouczona 
o możliwości złożenia odpowiedzi na pismo wszczynające postępowanie i wyjaśnień 
na piśmie oraz o tym, kto może być ustanowiony pełnomocnikiem.

***
## Art. 41. {#kpa-i-art-41}

**§ 1.** W toku 
postępowania 
strony 
oraz 
ich 
przedstawiciele 
i pełnomocnicy mają obowiązek zawiadomić organ administracji publicznej o każdej 
zmianie swojego adresu. 
**§ 2.** W razie zaniedbania obowiązku określonego w § 1 doręczenie pisma pod 
dotychczasowym adresem ma skutek prawny.

***
## Art. 42. {#kpa-i-art-42}

**§ 1.** Pisma doręcza się osobom fizycznym w ich mieszkaniu lub miejscu 
pracy albo na adres do korespondencji wskazany w bazie adresów elektronicznych. 
**§ 2.** Pisma mogą być doręczane również w lokalu organu administracji 
publicznej, jeżeli przepisy szczególne nie stanowią inaczej. 
**§ 3.** W razie niemożności doręczenia pisma w sposób określony w § 1 i 2, 
a także w razie koniecznej potrzeby, pisma doręcza się w każdym miejscu, gdzie się 
adresata zastanie.

***
## Art. 43. {#kpa-i-art-43}

W przypadku 
nieobecności 
adresata 
pismo 
doręcza 
się, 
za 
pokwitowaniem, dorosłemu domownikowi, sąsiadowi lub dozorcy domu, jeżeli osoby 
te podjęły się oddania pisma adresatowi. O doręczeniu pisma sąsiadowi lub dozorcy 
zawiadamia się adresata, umieszczając zawiadomienie w oddawczej skrzynce 
pocztowej lub, gdy to nie jest możliwe, w drzwiach mieszkania.

***
## Art. 44. {#kpa-i-art-44}

**§ 1.** W razie niemożności doręczenia pisma w sposób wskazany 
w art. 42 i 43: 
- 1) operator pocztowy w rozumieniu ustawy z dnia 23 listopada 2012 r. – Prawo 
pocztowe przechowuje pismo przez okres 14 dni w swojej placówce pocztowej 
– w przypadku doręczania pisma przez operatora pocztowego; 

 
 
 
s. 20/89 
 
2025-08-27 
- 2) pismo składa się na okres czternastu dni w urzędzie właściwej gminy (miasta) – 
w przypadku doręczania pisma przez pracownika urzędu gminy (miasta) lub 
upoważnioną osobę lub organ. 
**§ 2.** Zawiadomienie o pozostawieniu pisma wraz z informacją o możliwości jego 
odbioru w terminie siedmiu dni, licząc od dnia pozostawienia zawiadomienia 
w miejscu określonym w § 1, umieszcza się w oddawczej skrzynce pocztowej lub, gdy 
nie jest to możliwe, na drzwiach mieszkania adresata, jego biura lub innego 
pomieszczenia, w którym adresat wykonuje swoje czynności zawodowe, bądź 
w widocznym miejscu przy wejściu na posesję adresata. 
**§ 3.** W przypadku niepodjęcia przesyłki w terminie, o którym mowa w § 2, 
pozostawia się powtórne zawiadomienie o możliwości odbioru przesyłki w terminie 
nie dłuższym niż czternaście dni od daty pierwszego zawiadomienia. 
**§ 4.** Doręczenie uważa się za dokonane z upływem ostatniego dnia okresu, 
o którym mowa w § 1, a pismo pozostawia się w aktach sprawy.

***
## Art. 45. {#kpa-i-art-45}

Jednostkom organizacyjnym i organizacjom społecznym doręcza się 
pisma w lokalu ich siedziby do rąk osób uprawnionych do odbioru pism. Przepis 
art. 44 stosuje się odpowiednio.

***
## Art. 45a. {#kpa-i-art-45a}

**§ 1.** W przypadku braku możliwości doręczenia pisma w sposób 
wskazany w art. 45 z tego powodu, że podany przez jednostkę organizacyjną lub 
organizację społeczną adres jej siedziby nie istnieje, został wykreślony z rejestru lub 
jest niezgodny z odpowiednim rejestrem i nie można ustalić adresu siedziby, pismo 
doręcza się osobie fizycznej upoważnionej do reprezentowania adresata. 
**§ 2.** W przypadku gdy reprezentacja ma charakter łączny z innymi osobami 
fizycznymi, pismo doręcza się wszystkim osobom upoważnionym do reprezentowania 
adresata. Doręczenie uważa się za dokonane z chwilą najwcześniejszego doręczenia 
pisma osobie fizycznej upoważnionej do reprezentowania adresata. 
**§ 3.** Jeżeli w przypadku określonym w § 1 lub 2 nie jest możliwe ustalenie adresu 
osoby fizycznej upoważnionej do reprezentowania adresata, pismo pozostawia się 
w aktach sprawy ze skutkiem doręczenia. 
**§ 4.** Uznanie doręczenia, o którym mowa w § 3, za dokonane następuje z dniem 
sporządzenia przez organ administracji publicznej adnotacji o niemożności ustalenia 
adresu osoby fizycznej upoważnionej do reprezentowania adresata. 

 
 
 
s. 21/89 
 
2025-08-27 
**§ 5.** Organ administracji publicznej jest obowiązany niezwłocznie sporządzić 
i utrwalić w aktach sprawy adnotację, o której mowa w § 4.

***
## Art. 46. {#kpa-i-art-46}

**§ 1.** Odbierający pismo potwierdza doręczenie mu pisma swoim 
podpisem ze wskazaniem daty doręczenia. 
**§ 2.** Jeżeli odbierający pismo uchyla się od potwierdzenia doręczenia lub nie 
może tego uczynić, doręczający sam stwierdza datę doręczenia oraz wskazuje osobę, 
która odebrała pismo, i przyczynę braku jej podpisu. 
**§ 3.** (uchylony) 
**§ 4.** (uchylony)  
**§ 5.** (uchylony)  
**§ 6.** (uchylony)  
**§ 7.** (uchylony)  
**§ 8.** (uchylony)  
**§ 9.** (uchylony)  
**§ 10.** (uchylony)

***
## Art. 47. {#kpa-i-art-47}

**§ 1.** Jeżeli adresat odmawia przyjęcia pisma przesłanego mu przez 
operatora pocztowego w rozumieniu ustawy z dnia 23 listopada 2012 r. – Prawo 
pocztowe lub inny organ albo w inny sposób, pismo zwraca się nadawcy z adnotacją 
o odmowie jego przyjęcia i datą odmowy. Pismo wraz z adnotacją włącza się do akt 
sprawy. 
**§ 2.** W przypadkach, o których mowa w § 1, uznaje się, że pismo doręczone 
zostało w dniu odmowy jego przyjęcia przez adresata.

***
## Art. 48. {#kpa-i-art-48}

**§ 1.** Pisma skierowane do osób nieznanych z miejsca pobytu, dla 
których sąd nie wyznaczył przedstawiciela, doręcza się przedstawicielowi 
ustanowionemu w myśl art. 34. 
**§ 2.** Pisma kierowane do osób korzystających ze szczególnych uprawnień 
wynikających z immunitetu dyplomatycznego lub konsularnego doręcza się w sposób 
przewidziany 
w przepisach 
szczególnych, 
w umowach 
i zwyczajach 
międzynarodowych.

***
## Art. 49. {#kpa-i-art-49}

**§ 1.** Jeżeli przepis szczególny tak stanowi, zawiadomienie stron o 
decyzjach i innych czynnościach organu administracji publicznej może nastąpić w 
formie publicznego obwieszczenia, w innej formie publicznego ogłoszenia 

 
 
 
s. 22/89 
 
2025-08-27 
 
zwyczajowo przyjętej w danej miejscowości lub przez udostępnienie pisma w 
Biuletynie Informacji Publicznej na stronie podmiotowej właściwego organu 
administracji publicznej. 
**§ 2.** Dzień, w którym nastąpiło publiczne obwieszczenie, inne publiczne 
ogłoszenie lub udostępnienie pisma w Biuletynie Informacji Publicznej wskazuje się 
w treści tego obwieszczenia, ogłoszenia lub w Biuletynie Informacji Publicznej. 
Zawiadomienie uważa się za dokonane po upływie czternastu dni od dnia, w którym 
nastąpiło publiczne obwieszczenie, inne publiczne ogłoszenie lub udostępnienie pisma 
w Biuletynie Informacji Publicznej.

***
## Art. 49a. {#kpa-i-art-49a}

Poza przypadkami, o których mowa w art. 49, organ może dokonywać 
zawiadomienia o decyzjach i innych czynnościach organu administracji publicznej w 
formie, o której mowa w art. 49 § 1, jeżeli w postępowaniu bierze udział więcej niż 
dwadzieścia stron. Jeżeli przepis szczególny nie stanowi inaczej, zawiadomienie jest 
w takim przypadku skuteczne wobec stron, które zostały na piśmie uprzedzone o 
zamiarze zawiadamiania ich w określony sposób. Do zawiadomienia stosuje się 
przepis art. 49 § 2.

***
## Art. 49b. {#kpa-i-art-49b}

**§ 1.** W przypadku zawiadomienia strony zgodnie z art. 49 § 1 lub art. 
49a o decyzji lub postanowieniu, które podlega zaskarżeniu, na wniosek strony, organ, 
który wydał decyzję lub postanowienie, niezwłocznie, nie później niż w terminie 
trzech dni od dnia otrzymania wniosku, udostępnia stronie odpis decyzji lub 
postanowienia w sposób i formie określonych we wniosku, chyba że środki 
techniczne, którymi dysponuje organ, nie umożliwiają udostępnienia w taki sposób 
lub takiej formie. 
**§ 2.** Jeżeli decyzja lub postanowienie, o których mowa w § 1, nie mogą być 
udostępnione stronie w sposób lub formie określonych we wniosku, organ powiadamia 
o tym stronę i wskazuje, w jaki sposób lub jakiej formie odpis decyzji lub 
postanowienia może być niezwłocznie udostępniony. 
Rozdział 9 
Wezwania

***
## Art. 50. {#kpa-i-art-50}

**§ 1.** Organ administracji publicznej może wzywać osoby do udziału 
w podejmowanych czynnościach i do złożenia wyjaśnień lub zeznań osobiście, przez 

 
 
 
s. 23/89 
 
2025-08-27 
 
pełnomocnika, na piśmie, jeżeli jest to niezbędne dla rozstrzygnięcia sprawy lub dla 
wykonywania czynności urzędowych. 
**§ 2.** Organ obowiązany jest dołożyć starań, aby zadośćuczynienie wezwaniu nie 
było uciążliwe. 
**§ 3.** W przypadkach, w których osoba wezwana nie może stawić się z powodu 
choroby, kalectwa lub innej niedającej się pokonać przeszkody, organ może dokonać 
określonej czynności lub przyjąć wyjaśnienie albo przesłuchać osobę wezwaną 
w miejscu jej pobytu, jeżeli pozwalają na to okoliczności, w jakich znajduje się ta 
osoba.

***
## Art. 51. {#kpa-i-art-51}

**§ 1.** Do osobistego stawienia się wezwany jest obowiązany tylko 
w obrębie gminy lub miasta, w którym zamieszkuje albo przebywa. 
**§ 2.** Obowiązek osobistego stawiennictwa dotyczy również wezwanego, 
zamieszkałego lub przebywającego w sąsiedniej gminie albo mieście.

***
## Art. 52. {#kpa-i-art-52}

W toku postępowania organ administracji publicznej zwraca się do 
właściwego terenowego organu administracji rządowej lub organu samorządu 
terytorialnego o wezwanie osoby zamieszkałej lub przebywającej w danej gminie lub 
mieście do złożenia wyjaśnień lub zeznań albo do dokonania innych czynności, 
związanych z toczącym się postępowaniem. Organ prowadzący postępowanie 
oznaczy zarazem okoliczności będące przedmiotem wyjaśnień lub zeznań albo 
czynności, jakie mają być dokonane.

***
## Art. 53. {#kpa-i-art-53}

Przepisów art. 51 i 52 nie stosuje się w przypadkach, w których 
charakter sprawy lub czynności wymaga dokonania czynności przed organem 
administracji publicznej prowadzącym postępowanie.

***
## Art. 54. {#kpa-i-art-54}

**§ 1.** W wezwaniu należy wskazać: 
- 1) nazwę i adres organu wzywającego; 
- 2) imię i nazwisko wzywanego; 
- 3) w jakiej sprawie oraz w jakim charakterze i w jakim celu zostaje wezwany; 
- 4) czy wezwany powinien się stawić osobiście lub przez pełnomocnika, czy też 
może złożyć wyjaśnienie lub zeznanie na piśmie; 
- 5) termin, do którego żądanie powinno być spełnione, albo dzień, godzinę i miejsce 
stawienia się wezwanego lub jego pełnomocnika; 
- 6) skutki prawne niezastosowania się do wezwania. 

 
 
 
s. 24/89 
 
2025-08-27 
**§ 1a.** W wezwaniu 
zawiera 
się 
również 
informacje, 
o których 
mowa 
w art. 13 ust. 1 i 2 rozporządzenia 2016/679, chyba że wezwany posiada te 
informacje, a ich zakres lub treść nie uległy zmianie. 
**§ 2.** Wezwanie powinno być opatrzone podpisem pracownika organu 
wzywającego, z podaniem imienia, nazwiska i stanowiska służbowego podpisującego.

***
## Art. 55. {#kpa-i-art-55}

**§ 1.** W sprawach niecierpiących zwłoki wezwania można dokonać 
również telefonicznie albo przy użyciu innych środków łączności, z podaniem danych 
wymienionych w art. 54 § 1 oraz imienia, nazwiska i stanowiska służbowego 
pracownika organu wzywającego. 
**§ 2.** Wezwanie dokonane w sposób określony w § 1 powoduje skutki prawne 
tylko wtedy, gdy nie ma wątpliwości, że dotarło do adresata we właściwej treści 
i w odpowiednim terminie.

***
## Art. 56. {#kpa-i-art-56}

**§ 1.** Osobie, która stawiła się na wezwanie, przyznaje się koszty podróży 
i inne należności ustalone zgodnie z przepisami zawartymi w dziale 2 tytułu III ustawy 
z dnia 28 lipca 2005 r. o kosztach sądowych w sprawach cywilnych (Dz. U. z 2023 r. 
poz. 1144, 1532 i 1860). Dotyczy to również kosztów osobistego stawiennictwa stron, 
gdy postępowanie zostało wszczęte z urzędu albo gdy strona bez swojej winy została 
błędnie wezwana do stawienia się. 
**§ 2.** Żądanie przyznania należności należy zgłosić organowi administracji 
publicznej, przed którym toczy się postępowanie, przed wydaniem decyzji, pod 
rygorem utraty roszczenia. 
Rozdział 10 
Terminy

***
## Art. 57. {#kpa-i-art-57}

**§ 1.** Jeżeli początkiem terminu określonego w dniach jest pewne 
zdarzenie, przy obliczaniu tego terminu nie uwzględnia się dnia, w którym zdarzenie 
nastąpiło. Upływ ostatniego z wyznaczonej liczby dni uważa się za koniec terminu. 
**§ 2.** Terminy określone w tygodniach kończą się z upływem tego dnia 
w ostatnim tygodniu, który nazwą odpowiada początkowemu dniowi terminu. 
**§ 3.** Terminy określone w miesiącach kończą się z upływem tego dnia 
w ostatnim miesiącu, który odpowiada początkowemu dniowi terminu, a gdyby 
takiego dnia w ostatnim miesiącu nie było – w ostatnim dniu tego miesiąca. 

 
 
 
s. 25/89 
 
2025-08-27 
**§ 3a.** Terminy określone w latach kończą się z upływem tego dnia w ostatnim 
roku, który odpowiada początkowemu dniowi terminu, a gdyby takiego dnia w 
ostatnim roku nie było – w dniu poprzedzającym bezpośrednio ten dzień. 
**§ 4.** Jeżeli koniec terminu do wykonania czynności przypada na dzień uznany 
ustawowo za wolny od pracy lub na sobotę, termin upływa następnego dnia, który nie 
jest dniem wolnym od pracy ani sobotą. 
**§ 5.** Termin uważa się za zachowany, jeżeli przed jego upływem pismo zostało: 
- 1) wysłane na adres do doręczeń elektronicznych organu administracji publicznej, 
a nadawca otrzymał dowód otrzymania, o którym mowa w art. 41 ustawy z dnia 
18 listopada 2020 r. o doręczeniach elektronicznych; 
- 2) nadane w polskiej placówce pocztowej operatora wyznaczonego w rozumieniu 
ustawy z dnia 23 listopada 2012 r. – Prawo pocztowe albo placówce pocztowej 
operatora świadczącego pocztowe usługi powszechne w innym państwie 
członkowskim Unii Europejskiej, Konfederacji Szwajcarskiej albo państwie 
członkowskim Europejskiego Porozumienia o Wolnym Handlu (EFTA) – stronie 
umowy o Europejskim Obszarze Gospodarczym; 
- 3) złożone w polskim urzędzie konsularnym; 
- 4) złożone przez żołnierza w dowództwie jednostki wojskowej; 
- 5) złożone przez członka załogi statku morskiego kapitanowi statku; 
- 6) złożone przez osobę pozbawioną wolności w administracji zakładu karnego.

***
## Art. 58. {#kpa-i-art-58}

**§ 1.** W razie uchybienia terminu należy przywrócić termin na prośbę 
zainteresowanego, jeżeli uprawdopodobni, że uchybienie nastąpiło bez jego winy. 
**§ 2.** Prośbę o przywrócenie terminu należy wnieść w ciągu siedmiu dni od dnia 
ustania przyczyny uchybienia terminu. Jednocześnie z wniesieniem prośby należy 
dopełnić czynności, dla której określony był termin. 
**§ 3.** Przywrócenie terminu do złożenia prośby przewidzianej w § 2 jest 
niedopuszczalne.

***
## Art. 59. {#kpa-i-art-59}

**§ 1.** O przywróceniu terminu postanawia właściwy w sprawie organ 
administracji publicznej. Od postanowienia o odmowie przywrócenia terminu służy 
zażalenie. 
**§ 2.** O przywróceniu terminu do wniesienia odwołania lub zażalenia postanawia 
ostatecznie organ właściwy do rozpatrzenia odwołania lub zażalenia. 

 
 
 
s. 26/89 
 
2025-08-27

***
## Art. 60. {#kpa-i-art-60}

Przed rozpatrzeniem prośby o przywrócenie terminu do wniesienia 
odwołania lub zażalenia organ administracji publicznej na żądanie strony może 
wstrzymać wykonanie decyzji lub postanowienia.

