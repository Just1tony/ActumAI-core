---
id: code.kpa.dzial.iii
title: "Kodeks postępowania administracyjnego — Dział III (—)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1960 nr 30 poz. 168"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KPA — Dział III"]
tags: ["KPA","Kodeks postępowania administracyjnego","Dział III","PL"]
source_pdf: "D19600168Lj.pdf"
articles: "Art. 180–181"
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpa-iii-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks postępowania administracyjnego — Dział III: —

Przepisy szczególne w sprawach ubezpieczeń społecznych 
Art. 164–179. (uchylone)
***
## Art. 180. {#kpa-iii-art-180}

**§ 1.** W sprawach z zakresu ubezpieczeń społecznych stosuje się 
przepisy kodeksu, chyba że przepisy dotyczące ubezpieczeń ustalają odmienne zasady 
postępowania w tych sprawach. 
**§ 2.** Przez sprawy z zakresu ubezpieczeń społecznych rozumie się sprawy 
wynikające 
z przepisów 
o ubezpieczeniach 
społecznych, 
o zaopatrzeniach 
emerytalnych i rentowych, o funduszu alimentacyjnym, a także sprawy wynikające z 
przepisów o innych świadczeniach wypłacanych z funduszów przeznaczonych na 
ubezpieczenia społeczne.

***
## Art. 181. {#kpa-iii-art-181}

Organy odwoławcze właściwe w sprawach z zakresu ubezpieczeń 
społecznych określają przepisy odrębne; do postępowania przed tymi organami stosuje 
się odpowiednio przepis art. 180 § 1.

