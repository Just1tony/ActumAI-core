---
id: code.kpa.dzial.v
title: "Kodeks postępowania administracyjnego — Dział V (—)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1960 nr 30 poz. 168"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KPA — Dział V"]
tags: ["KPA","Kodeks postępowania administracyjnego","Dział V","PL"]
source_pdf: "D19600168Lj.pdf"
articles: ""
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpa-v-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks postępowania administracyjnego — Dział V: —

(uchylony)
