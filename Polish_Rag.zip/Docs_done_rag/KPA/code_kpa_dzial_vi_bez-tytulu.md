---
id: code.kpa.dzial.vi
title: "Kodeks postępowania administracyjnego — Dział VI (—)"
category: code
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 1960 nr 30 poz. 168"
status: "obowiązujący"
last_consolidated: "2025-01-01"
aliases: ["KPA — Dział VI"]
tags: ["KPA","Kodeks postępowania administracyjnego","Dział VI","PL"]
source_pdf: "D19600168Lj.pdf"
articles: ""
chunking:
  strategy: "by-article"
  article_anchor_pattern: "## Art. {n}. {#kpa-vi-art-{n}}"
  separators: "***"
  hierarchy: ["Dział","Rozdział","Oddział"]
---

# Kodeks postępowania administracyjnego — Dział VI: —

(uchylony)
