---
id: act.policja.ch8
title: Ustawa o Policji — Rozdział 7
dz_u: Dz.U. 1990 Nr 30 poz. 179 (t.j. 2025 poz. 636, 718)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '58'
  last: '87'
source_pdf: D19900179Lj (1).pdf
chunking:
  strategy: by-article
  anchor_pattern: '## Art. {n}. {#policja-art-{n}}'
  hierarchy:
  - Rozdział
  - Art.
---

# Rozdział 7
 
## Art. 58. {#policja-art-58}

1. Policjant jest obowiązany dochować obowiązków wynikających z 
roty złożonego ślubowania. 
2. Policjant obowiązany jest odmówić wykonania rozkazu lub polecenia 
przełożonego, a także polecenia prokuratora, organu administracji państwowej lub 
samorządu terytorialnego, jeśli wykonanie rozkazu lub polecenia łączyłoby się z 
popełnieniem przestępstwa. 
3. O odmowie wykonania rozkazu lub polecenia, o których mowa w ust. 2, 
policjant powinien zameldować Komendantowi Głównemu Policji z pominięciem 
drogi służbowej. 

 
 
 
s. 163/274 
 
2025-07-03

***
## Art. 59. {#policja-art-59}

1. Przełożony policjanta niebędącego w stanie wykonać polecenia sądu 
lub prokuratora w wyznaczonym terminie lub zakresie, o którym mowa w art. 14 ust. 
2, jest obowiązany wystąpić z wnioskiem o przedłużenie terminu, zmianę lub 
uchylenie polecenia. 
2. 
W 
przypadku 
nieusprawiedliwionego 
niewykonania 
polecenia 
w 
wyznaczonym terminie lub zakresie, na żądanie sądu lub prokuratora przełożony 
policjanta wszczyna przeciwko niemu postępowanie dyscyplinarne. O wyniku tego 
postępowania zawiadamia się odpowiednio sąd lub prokuratora.

***
## Art. 60. {#policja-art-60}

1. Policjant w czasie służby jest obowiązany do noszenia przepisowego 
munduru i wyposażenia. 
2. Komendant Główny Policji określa przypadki, w których policjant w czasie 
wykonywania obowiązków służbowych nie ma obowiązku noszenia munduru.

***
## Art. 61. {#policja-art-61}

1. W przypadkach przewidzianych w art. 60 ust. 2 policjant, wykonując 
czynności dochodzeniowo-śledcze, a także czynności określone w art. 14 ust. 2 i art. 
15 ust. 1 pkt 2–4, obowiązany jest okazać legitymację służbową w taki sposób, aby 
zainteresowany miał możliwość odczytać i zanotować numer i organ, który wydał 
legitymację, oraz nazwisko policjanta. 
2. Przy wykonywaniu innych czynności administracyjno-porządkowych 
nieumundurowany policjant obowiązany jest na żądanie obywatela okazać 
legitymację służbową lub znak identyfikacyjny w sposób określony w ust. 1.

***
## Art. 61a. {#policja-art-61a}

1. Policjant jest obowiązany utrzymywać sprawność fizyczną 
zapewniającą wykonywanie przez niego zadań służbowych, w szczególności przez 
udział w zajęciach i sprawdzianach ze sprawności fizycznej policjantów oraz udział 
w doskonaleniu zawodowym. 
2. Sprawność fizyczną, o której mowa w ust. 1, ocenia się na podstawie wyników 
testu sprawności fizycznej policjantów. 
3. Za równoznaczne z zaliczeniem testu sprawności fizycznej policjantów, 
w roku przeprowadzania tego testu, uważa się test zrealizowany zgodnie ze sposobem 
i kryteriami oceniania sprawności fizycznej policjanta określonymi w przepisach 
wydanych na podstawie ust. 6, w ramach szkolenia, o którym mowa w art. 34 ust. 8 
pkt 1, lub doskonalenia, o którym mowa w art. 34h ust. 2 pkt 1 lub ust. 3, albo 
przedsięwzięcia realizowanego w Policji, w zakresie którego niezbędne było 
zaliczenie testu sprawności fizycznej. 

 
 
 
s. 164/274 
 
2025-07-03 
 
4. Policjanta zwalnia się z testu sprawności fizycznej policjantów oraz z zajęć 
i sprawdzianów ze sprawności fizycznej policjantów na czas: 
1) 
oddelegowania do wykonywania zadań służbowych poza Policją, a także 
delegowania do pełnienia służby poza granicami państwa w kontyngencie 
policyjnym; 
2) 
zwolnienia z obowiązku wykonywania zadań służbowych udzielonego na 
zasadach określonych w przepisach o związkach zawodowych. 
5. W sprawach zwolnienia policjanta z testu sprawności fizycznej policjantów 
oraz z zajęć i sprawdzianów ze sprawności fizycznej policjantów właściwy jest 
przełożony, o którym mowa w art. 32 ust. 1. 
6. Komendant Główny Policji określi, w drodze zarządzenia: 
1) 
zakres i sposób przeprowadzania testu sprawności fizycznej policjantów 
z uwzględnieniem charakteru wykonywanych zadań służbowych; 
2) 
organizację testu sprawności fizycznej policjantów; 
3) 
tryb i terminy przeprowadzania testu sprawności fizycznej policjantów; 
4) 
sposób i kryteria oceniania sprawności fizycznej policjanta w teście sprawności 
fizycznej policjantów; 
5) 
wymagania dla przeprowadzającego test sprawności fizycznej policjantów; 
6) 
sposób dokumentowania testu sprawności fizycznej policjantów oraz wzory 
dokumentów w tych sprawach; 
7) 
sposób sprawowania nadzoru nad przebiegiem testu sprawności fizycznej 
policjantów. 
7. Komendant Główny Policji określi, w drodze zarządzenia: 
1) 
rodzaje zajęć i sprawdzianów ze sprawności fizycznej policjantów; 
2) 
zakres i sposób przeprowadzania zajęć i sprawdzianów ze sprawności fizycznej 
policjantów; 
3) 
organizację zajęć i sprawdzianów ze sprawności fizycznej policjantów; 
4) 
tryb i terminy przeprowadzania zajęć i sprawdzianów ze sprawności fizycznej 
policjantów; 
5) 
sposób i kryteria oceniania policjanta podczas sprawdzianów ze sprawności 
fizycznej policjantów; 
6) 
wymagania dla prowadzącego zajęcia i sprawdziany ze sprawności fizycznej 
policjantów; 

 
 
 
s. 165/274 
 
2025-07-03 
 
7) 
sposób dokumentowania zajęć i sprawdzianów ze sprawności fizycznej 
policjantów; 
8) 
zadania jednostek organizacyjnych Policji w zakresie realizacji zajęć 
i sprawdzianów ze sprawności fizycznej policjantów; 
9) 
sposób sprawowania nadzoru nad przebiegiem zajęć i sprawdzianów ze 
sprawności fizycznej policjantów.

***
## Art. 61b. {#policja-art-61b}

1. Policjant jest 
obowiązany nabywać i utrzymywać poziom 
umiejętności posługiwania się bronią palną zapewniający wykonywanie przez niego 
zadań służbowych, w szczególności przez udział w zajęciach i sprawdzianach 
z wyszkolenia strzeleckiego policjantów. 
2. Policjanta zwalnia się z zajęć i sprawdzianów z wyszkolenia strzeleckiego 
policjantów na czas: 
1) 
oddelegowania do wykonywania zadań służbowych poza Policją, a także 
delegowania do pełnienia służby poza granicami państwa w kontyngencie 
policyjnym; 
2) 
zwolnienia z obowiązku wykonywania zadań służbowych udzielonego na 
zasadach określonych w przepisach o związkach zawodowych. 
3. W sprawach zwolnienia policjanta z zajęć i sprawdzianów z wyszkolenia 
strzeleckiego policjantów właściwy jest przełożony, o którym mowa w art. 32 ust. 1. 
4. Komendant Główny Policji określi, w drodze zarządzenia: 
1) 
zakres 
i sposób 
przeprowadzania 
zajęć 
i sprawdzianów 
z wyszkolenia 
strzeleckiego policjantów z uwzględnieniem charakteru wykonywanych zadań 
służbowych oraz: 
a) 
rodzaje celów strzeleckich, 
b) 
podstawowe postawy strzeleckie, 
c) 
podstawowe rodzaje chwytów broni; 
2) 
organizację zajęć i sprawdzianów z wyszkolenia strzeleckiego policjantów; 
3) 
tryb 
i terminy 
przeprowadzania 
zajęć 
i sprawdzianów 
z wyszkolenia 
strzeleckiego policjantów; 
4) 
sposób 
i kryteria 
oceniania 
policjanta 
podczas 
zajęć 
i sprawdzianów 
z wyszkolenia strzeleckiego policjantów; 
5) 
wymagania dla prowadzącego zajęcia i sprawdziany z wyszkolenia strzeleckiego 
policjantów; 

 
 
 
s. 166/274 
 
2025-07-03 
 
6) 
obowiązki uczestników zajęć i sprawdzianów z wyszkolenia strzeleckiego 
policjantów; 
7) 
sposób dokumentowania zajęć i sprawdzianów z wyszkolenia strzeleckiego 
policjantów oraz wzory dokumentów w tych sprawach; 
8) 
sposób sprawowania nadzoru nad przebiegiem zajęć i sprawdzianów 
z wyszkolenia strzeleckiego policjantów.

***
## Art. 61c. {#policja-art-61c}

1. Przełożony ma obowiązek niedopuszczenia podległego mu 
policjanta do służby w przypadku: 
1) 
stawienia się przez niego do służby w stanie po użyciu alkoholu albo w stanie 
nietrzeźwości w rozumieniu art. 46 ust. 2 albo 3 ustawy z dnia 26 października 
1982 r. o wychowaniu w trzeźwości i przeciwdziałaniu alkoholizmowi (Dz. U. 
z 2023 r. poz. 2151), lub po użyciu podobnie działającego środka, pełnienia jej 
w takim stanie, spożywania alkoholu lub używania podobnie działającego środka 
w czasie służby albo 
2) 
uzasadnionego podejrzenia, że zachodzą okoliczności, o których mowa w pkt 1. 
2. W przypadku gdy niedopuszczenie policjanta do służby, o którym mowa 
w ust. 1, dotyczy kierownika jednostki organizacyjnej Policji, obowiązki związane 
z niedopuszczeniem go do służby realizuje jego przełożony. 
3. Przełożony, który nie dopuścił podległego mu policjanta do służby, informuje 
policjanta o okolicznościach stanowiących podstawę niedopuszczenia go do służby. 
4. W celu weryfikacji istnienia przesłanek uzasadniających niedopuszczenie 
policjanta do służby kierownik jednostki organizacyjnej Policji wobec podległych 
policjantów lub osoba przez niego upoważniona, przełożony policjanta lub policjant 
służby spraw wewnętrznych, zwani dalej „zarządzającym badania”, są uprawnieni do 
wydania polecenia poddania się przez policjanta badaniu na zawartość w organizmie 
alkoholu lub badaniu na obecność w organizmie innego podobnie działającego środka. 
5. Policjant służby spraw wewnętrznych w celu umożliwienia realizacji 
obowiązku, o którym mowa w ust. 1 lub 2, bezpośrednio przed wydaniem polecenia, 
o którym mowa w ust. 4, o zamiarze wydania takiego polecenia zawiadamia 
przełożonego policjanta, a w przypadku kierownika jednostki organizacyjnej Policji – 
jego przełożonego. 
6. Policjant ma obowiązek poddać się badaniu, o którym mowa w ust. 4, oraz 
umożliwić jego przeprowadzenie. 

 
 
 
s. 167/274 
 
2025-07-03 
 
7. Badanie, o którym mowa w ust. 4, może obejmować odpowiednio przy 
badaniu na zawartość w organizmie: 
1) 
alkoholu – badanie wydychanego powietrza lub badanie krwi; 
2) 
środka działającego podobnie do alkoholu – badanie: 
a) 
śliny, 
b) 
krwi, 
c) 
moczu, 
d) 
potu. 
8. Badanie krwi, o którym mowa w ust. 7 pkt 1, przeprowadza się, jeżeli: 
1) 
policjant odmawia poddania się badaniu wydychanego powietrza; 
2) 
policjant, pomimo przeprowadzenia badania wydychanego powietrza, żąda 
badania krwi; 
3) 
stan policjanta, w szczególności wynikający ze spożycia alkoholu, choroby 
układu oddechowego lub innych przyczyn, uniemożliwia przeprowadzenie 
badania wydychanego powietrza; 
4) 
wystąpił brak wskazania stężenia alkoholu w wydychanym powietrzu 
spowodowany 
przekroczeniem 
zakresu 
pomiarowego 
urządzenia 
wykorzystywanego do pomiaru. 
9. Badania, o których mowa w ust. 7 pkt 2 lit. b lub c, przeprowadza się, jeżeli: 
1) 
policjant odmawia poddania się badaniu, o którym mowa w ust. 7 pkt 2 lit. a lub 
d; 
2) 
policjant, 
pomimo 
przeprowadzenia 
badania, 
o którym 
mowa 
w ust. 7 pkt 2 lit. a lub d, żąda badania krwi lub moczu; 
3) 
stan policjanta uniemożliwia przeprowadzenie badania, o którym mowa 
w ust. 7 pkt 2 lit. a lub d. 
10. Czynności związane z pobraniem materiału biologicznego do badań, 
o których mowa w ust. 4: 
1) 
odbywają się w miejscu i w warunkach zapewniających poszanowanie godności 
i intymności policjanta, od którego pobiera się materiał do badań; 
2) 
w postaci krwi – są przeprowadzane przez osobę posiadającą odpowiednie 
kwalifikacje zawodowe; 
3) 
w postaci moczu lub potu – odbywają się w obecności osoby tej samej płci co 
policjant, od którego pobiera się materiał biologiczny do badań: 
a) 
o której mowa w pkt 2, 

 
 
 
s. 168/274 
 
2025-07-03 
 
b) 
wskazanej przez zarządzającego badania – w przypadku braku możliwości 
zapewnienia obecności osoby, o której mowa w pkt 2. 
11. W przypadku powzięcia uzasadnionego podejrzenia, że pobranie krwi może 
spowodować zagrożenie życia lub zdrowia policjanta, decyzję o przeprowadzeniu 
badania krwi podejmuje lekarz. 
12. W przypadku poddania policjanta badaniu w celu, o którym mowa w ust. 4, 
niedopuszczenie do służby trwa do czasu uzyskania wyniku badania wykluczającego 
w odniesieniu do policjanta poddanego badaniu: 
1) 
stan nietrzeźwości albo stan po użyciu alkoholu lub 
2) 
obecność w organizmie środka działającego podobnie do alkoholu 
– nie dłużej jednak niż do końca służby wynikającego z obowiązującego rozkładu 
czasu służby. 
13. W przypadku niedopuszczenia policjanta do służby, o którym mowa w ust. 1, 
do uposażenia policjanta za ten okres stosuje się odpowiednio przepisy art. 121f ust. 1 
i 4 oraz art. 126 ust. 1–3. 
14. Przebieg 
badań, 
o których 
mowa 
w ust. 4, 
dokumentuje 
się 
z uwzględnieniem: 
1) 
daty, godziny i minuty oraz miejsca przeprowadzenia badania; 
2) 
wyniku badania; 
3) 
stopnia, imienia i nazwiska, stanowiska oraz podpisu zarządzającego badania; 
4) 
danych osobowych policjanta: 
a) 
stopnia, imienia i nazwiska oraz stanowiska, 
b) 
numeru identyfikacyjnego policjanta, 
c) 
daty urodzenia, informacji o chorobach, na jakie choruje policjant, oraz 
podpisu 
policjanta 
– 
jeżeli 
dane 
te 
pozyskano 
w związku 
z przeprowadzanym badaniem; 
5) 
imienia, nazwiska i podpisu osoby przeprowadzającej badanie; 
6) 
imienia, nazwiska, stanowiska i podpisu osoby przeprowadzającej pobranie 
próbek materiału biologicznego do badań; 
7) 
imienia, nazwiska i podpisu osoby, w obecności której przeprowadzano badanie; 
8) 
informacji o objawach lub okolicznościach uzasadniających przeprowadzenie 
badania oraz dacie, godzinie i minucie ich stwierdzenia; 
9) 
innych informacji niezbędnych do oceny wiarygodności i poprawności badania; 

 
 
 
s. 169/274 
 
2025-07-03 
 
10) w przypadku odstąpienia od pobrania próbek krwi – informacji o przyczynie 
odstąpienia. 
15. W przypadku badań, o których mowa w ust. 7 pkt 1, poza danymi, o których 
mowa w ust. 14 pkt 4, dokumentacja obejmuje również następujące dane osobowe 
policjanta: płeć, wzrost, masę ciała – jeżeli dane te pozyskano w związku 
z przeprowadzanym badaniem. 
16. Dokumentację zawierającą wyniki badań przekazuje się niezwłocznie 
zarządzającemu badania. Policjant służby spraw wewnętrznych niezwłocznie 
przekazuje dokumentację zawierającą wyniki badań przełożonemu, o którym mowa 
w art. 32 ust. 1. 
17. Minister właściwy do spraw wewnętrznych w porozumieniu z ministrem 
właściwym do spraw zdrowia określi, w drodze rozporządzenia: 
1) 
warunki i metody przeprowadzania badań, o których mowa w ust. 4, 
2) 
sposób dokumentowania badań, o których mowa w ust. 4, w tym wzory 
protokołów z przeprowadzonych badań, 
3) 
wykaz środków działających podobnie do alkoholu 
– mając na uwadze potrzebę sprawnego pobrania materiału do badań, sprawnego 
i prawidłowego przeprowadzania badań oraz zagwarantowania wiarygodności ich 
wyników, a także metodykę przeprowadzania takich badań oraz skutki oddziaływania 
środków działających podobnie do alkoholu na organizm i zapewniając poszanowanie 
godności policjanta i zasad ochrony danych osobowych.

***
## Art. 62. {#policja-art-62}

1. Policjant nie może podejmować zajęcia zarobkowego poza służbą bez 
pisemnej zgody przełożonego ani wykonywać czynności lub zajęć sprzecznych z 
obowiązkami wynikającymi z ustawy lub podważających zaufanie do Policji. 
2. Policjant jest obowiązany złożyć oświadczenie o swoim stanie majątkowym, 
w tym o majątku objętym małżeńską wspólnością majątkową, przy nawiązywaniu lub 
rozwiązywaniu stosunku służbowego lub stosunku pracy, corocznie oraz na żądanie 
przełożonego właściwego w sprawach osobowych. Oświadczenie to powinno 
zawierać informacje o źródłach i wysokości uzyskanych przychodów, posiadanych 
zasobach pieniężnych, nieruchomościach, udziałach i akcjach w spółkach prawa 
handlowego, a ponadto o nabytym przez tę osobę albo jej małżonka od Skarbu 
Państwa, innej państwowej osoby prawnej, gminy, związku międzygminnego, 
powiatu, 
związku 
powiatów, 
związku 
powiatowo-gminnego 
lub 
związku 

 
 
 
s. 170/274 
 
2025-07-03 
 
metropolitalnego mieniu, które podlegało zbyciu w drodze przetargu. Oświadczenie 
to powinno również zawierać dane dotyczące prowadzenia działalności gospodarczej 
oraz pełnienia funkcji w spółkach prawa handlowego lub spółdzielniach, z wyjątkiem 
funkcji w radzie nadzorczej spółdzielni mieszkaniowej. 
3. Oświadczenie o stanie majątkowym coroczne składa się do dnia 31 marca 
według stanu na dzień 31 grudnia roku poprzedniego. 
4. Przełożeni właściwi w sprawach osobowych lub osoby przez nich 
upoważnione, w celu przeprowadzenia analizy zgodności ze stanem faktycznym 
złożonych oświadczeń o stanie majątkowym, mają prawo wglądu do ich treści i 
przetwarzania danych w nich zawartych. 
4a. Inspektor Nadzoru Wewnętrznego w celu przeprowadzenia analizy 
złożonych oświadczeń o stanie majątkowym ma prawo wglądu do ich treści i 
przetwarzania danych w nich zawartych. 
5. Informacje zawarte w oświadczeniu o stanie majątkowym stanowią tajemnicę 
prawnie chronioną i podlegają ochronie przewidzianej dla informacji niejawnych o 
klauzuli tajności „zastrzeżone” określonej w przepisach o ochronie informacji 
niejawnych, chyba że policjant, który złożył oświadczenie, wyraził pisemną zgodę na 
ich ujawnienie, z zastrzeżeniem ust. 7. 
6. Oświadczenie o stanie majątkowym przechowuje się przez 10 lat. 
7. Informacje zawarte w oświadczeniach o stanie majątkowym osób pełniących 
funkcje organów Policji są publikowane, bez ich zgody, na właściwych stronach 
Biuletynu Informacji Publicznej, z wyłączeniem danych dotyczących daty i miejsca 
urodzenia, numeru PESEL, miejsca zamieszkania i położenia nieruchomości. 
8. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
tryb postępowania w sprawach oświadczeń o stanie majątkowym, sposób analizy ich 
zgodności ze stanem faktycznym, a także wzór oświadczenia o stanie majątkowym 
oraz tryb publikowania oświadczeń, o których mowa w ust. 7, uwzględniając zakres 
danych objętych oświadczeniem o stanie majątkowym.

***
## Art. 62a. {#policja-art-62a}

Policjant jest obowiązany poinformować przełożonego właściwego w 
sprawach osobowych o podjęciu przez małżonka lub osoby pozostające z nim we 
wspólnym gospodarstwie domowym zatrudnienia lub innych czynności zarobkowych 
w podmiotach świadczących usługi detektywistyczne lub ochrony osób i mienia oraz 
o objęciu w nich akcji lub udziałów, a także o fakcie bycia wykonawcą w rozumieniu 

 
 
 
s. 171/274 
 
2025-07-03 
 
ustawy z dnia 11 września 2019 r. – Prawo zamówień publicznych (Dz. U. z 2024 r. 
poz. 1320) na rzecz organów i jednostek nadzorowanych i podległych ministrowi 
właściwemu do spraw wewnętrznych, w terminie 14 dni od dnia powzięcia informacji 
o tym zdarzeniu.

***
## Art. 63. {#policja-art-63}

1. Policjant nie może być członkiem partii politycznej. 
2. Z chwilą przyjęcia policjanta do służby ustaje jego dotychczasowe 
członkostwo w partii politycznej. 
3. Policjant jest obowiązany poinformować przełożonego o przynależności do 
stowarzyszeń krajowych działających poza służbą. 
4. Przynależność do organizacji lub stowarzyszeń zagranicznych albo 
międzynarodowych wymaga zezwolenia Komendanta Głównego Policji lub 
upoważnionego przez niego przełożonego.

***
## Art. 64. {#policja-art-64}

Policjant jest obowiązany powiadomić swojego bezpośredniego 
przełożonego o planowanym wyjeździe zagranicznym, poza obszar Unii Europejskiej, 
na więcej niż 3 dni.

***
## Art. 65. {#policja-art-65}

(uchylony)

***
## Art. 66. {#policja-art-66}

1. Policjant podczas lub w związku z pełnieniem obowiązków 
służbowych korzysta z ochrony przewidzianej w Kodeksie karnym dla 
funkcjonariuszy publicznych. 
2. Z ochrony przewidzianej w Kodeksie karnym dla funkcjonariuszy publicznych 
podczas lub w związku z pełnieniem obowiązków służbowych korzysta również 
policjant, który poza czasem służby działa na rzecz: 
1) 
zapobieżenia zagrożeniu dla życia lub zdrowia ludzkiego; 
2) 
przywrócenia bezpieczeństwa i porządku publicznego; 
3) 
ujęcia sprawcy czynu zabronionego.

***
## Art. 66a. {#policja-art-66a}

1. Policjantowi przysługuje zwrot kosztów poniesionych na ochronę 
prawną, jeżeli wszczęte przeciwko niemu postępowanie karne o przestępstwo 
popełnione w związku z wykonywaniem czynności służbowych zostanie zakończone 
prawomocnym orzeczeniem o umorzeniu postępowania z powodu braku ustawowych 
znamion czynu zabronionego lub niepopełnienia przestępstwa albo wyrokiem 
uniewinniającym. 

 
 
 
s. 172/274 
 
2025-07-03 
 
2. Zwrot kosztów poniesionych na ochronę prawną następuje ze środków 
budżetowych Policji, na wniosek policjanta, w wysokości faktycznie poniesionych 
kosztów, nie wyższej niż czterokrotność przeciętnego uposażenia policjantów, o 
którym mowa w art. 99 ust. 3, obowiązującego w roku poprzedzającym dzień złożenia 
wniosku. 
3. W szczególnie uzasadnionych przypadkach, kierując się dobrem służby, 
Komendant Główny Policji może zapewnić policjantowi, przeciwko któremu 
wszczęto postępowanie karne o przestępstwo popełnione w związku z wykonywaniem 
czynności służbowych, ochronę prawną jeszcze przed zakończeniem tego 
postępowania. Przepis ust. 2 stosuje się odpowiednio. Poniesione przez Policję koszty 
ochrony prawnej nie podlegają zwrotowi przez policjanta, niezależnie od wyniku 
postępowania karnego.

***
## Art. 66b. {#policja-art-66b}

1. Policjantowi pokrzywdzonemu przestępstwem, o którym mowa w 
art. 222, art. 223 lub art. 226 Kodeksu karnego, w związku z wykonywaniem 
czynności służbowych przysługuje, na jego wniosek, bezpłatna ochrona prawna 
w postępowaniu karnym, w którym uczestniczy w charakterze pokrzywdzonego lub 
oskarżyciela posiłkowego. 
2. Ochronę prawną, o której mowa w ust. 1, zapewnia jednostka organizacyjna 
Policji, w której policjant pokrzywdzony przestępstwem pełni służbę, a jeżeli 
jednostka ta nie ma zapewnionej obsługi prawnej realizowanej przez radców prawnych 
lub adwokatów, ochronę prawną zapewnia właściwa miejscowo komenda 
wojewódzka Policji albo Komenda Stołeczna Policji. 
3. W przypadku braku możliwości zapewniania ochrony prawnej przez jednostkę 
organizacyjną Policji, o której mowa w ust. 2, policjantowi przysługuje zwrot kosztów 
ochrony prawnej, o której mowa w ust. 1, w wysokości faktycznie poniesionych 
kosztów, nie wyższej niż czterokrotność przeciętnego uposażenia policjantów, o 
którym mowa w art. 99 ust. 3, obowiązującego w roku poprzedzającym dzień złożenia 
wniosku. 
4. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
tryb postępowania oraz sposób dokumentowania przez policjanta kosztów 
poniesionych na ochronę prawną w przypadkach, o których mowa w ust. 3 oraz w art. 
66a ust. 1 i 3, a także podmioty właściwe w sprawie zwrotu kosztów ochrony prawnej, 
o których mowa w ust. 3 i w art. 66a ust. 2, kierując się koniecznością korzystania 

 
 
 
s. 173/274 
 
2025-07-03 
 
przez policjanta z ochrony prawnej na wysokim poziomie, a także szybkiego zwrotu 
kosztów poniesionych przez policjanta na ochronę prawną.

***
## Art. 66c. {#policja-art-66c}

Ochrona prawna, o której mowa w art. 66a i art. 66b, przysługuje 
również policjantowi oddelegowanemu do wykonywania zadań służbowych poza 
Policję, na jego wniosek, w przypadku gdy postępowanie karne, o którym mowa w art. 
66a ust. 1 lub art. 66b ust. 1, zostało wszczęte w związku z wykonywaniem przez niego 
czynności służbowych w ramach podjętej interwencji w znaczeniu, o którym mowa w 
art. 15 ust. 7c.

***
## Art. 67. {#policja-art-67}

1. Policjanci mogą zrzeszać się w związkach zawodowych, z tym że nie 
przysługuje im prawo do strajku. 
2. Przepisy ustawy z dnia 23 maja 1991 r. o związkach zawodowych (Dz. U. z 
2025 r. poz. 440) stosuje się odpowiednio, z tym że: 
1) 
określone w przepisach prawa uprawnienia w sprawach indywidualnych 
przysługują zakładowej organizacji związkowej, jeżeli jej członkiem jest co 
najmniej jeden policjant inny niż ten, którego w danej sprawie reprezentuje 
zakładowa organizacja związkowa; 
2) 
uprawnienie, o którym mowa w art. 19 ustawy z dnia 23 maja 1991 r. o związkach 
zawodowych, przysługuje związkowi zawodowemu, którego terytorialny zakres 
działania obejmuje co najmniej obszar terytorialnego działania komendanta 
wojewódzkiego Policji; 
3) 
policjant może być członkiem międzyzakładowej organizacji związkowej, której 
zakresem działania objęte są wyłącznie jednostki organizacyjne Policji. 
3. W przypadku realizacji określonych w przepisach prawa uprawnień w 
sprawach indywidualnych zakładowa organizacja związkowa niezwłocznie informuje 
właściwego komendanta Policji o spełnieniu warunku, o którym mowa w ust. 2 pkt 1. 
4. Związek zawodowy, o którym mowa w ust. 2 pkt 2, mający zamiar korzystać 
z uprawnienia, o którym mowa w art. 19 ustawy z dnia 23 maja 1991 r. o związkach 
zawodowych, informuje o tym zamiarze Komendanta Głównego Policji. 
5. Szczegółowe zasady współdziałania związku zawodowego z ministrem 
właściwym do spraw wewnętrznych, Komendantem Głównym Policji oraz 
właściwymi komendantami Policji określa statut tego związku zarejestrowany w 
sądzie lub porozumienie zawarte z ministrem właściwym do spraw wewnętrznych lub 
właściwym komendantem Policji. 

 
 
 
s. 174/274 
 
2025-07-03 
 
6. Policjant pełniący służbę na stanowisku, dla którego ustawa przewiduje 
powołanie, a także policjant mianowany na stanowisko dyrektora komórki 
organizacyjnej, zastępcy dyrektora komórki organizacyjnej albo naczelnika, nie może 
pełnić funkcji w związkach zawodowych oraz nie podlega ochronie, o której mowa w 
art. 32 ustawy z dnia 23 maja 1991 r. o związkach zawodowych.

***
## Art. 68. {#policja-art-68}

(uchylony)

***
## Art. 69. {#policja-art-69}

(uchylony)

***
## Art. 69a. {#policja-art-69a}

1. Jeżeli policjant zwolniony ze służby nie spełnia warunków do 
nabycia prawa do emerytury policyjnej lub policyjnej renty inwalidzkiej, od 
uposażenia wypłaconego policjantowi po dniu 31 grudnia 1998 r. do dnia zwolnienia 
ze służby, od którego nie odprowadzono składki na ubezpieczenia emerytalne i 
rentowe, przekazuje się do Zakładu Ubezpieczeń Społecznych składki za ten okres 
przewidziane w ustawie z dnia 13 października 1998 r. o systemie ubezpieczeń 
społecznych. 
2. Przez uposażenie stanowiące podstawę wymiaru składek na ubezpieczenia 
emerytalne i rentowe, o którym mowa w ust. 1, rozumie się: 
1) 
kwotę najniższego wynagrodzenia ustalaną na podstawie odrębnych przepisów – 
za okres służby kandydackiej przed dniem 1 stycznia 2003 r.; 
2) 
kwotę minimalnego wynagrodzenia za pracę obowiązującego w grudniu roku 
poprzedniego, ustalonego na podstawie odrębnych przepisów – za okres służby 
kandydackiej po dniu 31 grudnia 2002 r.; 
3) 
uposażenie zasadnicze, dodatki do uposażenia, nagrody roczne i uznaniowe oraz 
dodatkowe wynagrodzenie wypłacane na podstawie art. 112, odpowiednio 
przeliczone zgodnie z art. 110 ustawy, o której mowa w ust. 1 – za pozostałe 
okresy służby. 
3. Składki przekazuje się również w przypadku, gdy policjant spełnia jedynie 
warunki do nabycia prawa do policyjnej renty inwalidzkiej. Przekazanie składek 
następuje na wniosek policjanta. 
4. Składki podlegają waloryzacji wskaźnikiem waloryzacji składek określonym 
na podstawie ustawy z dnia 17 grudnia 1998 r. o emeryturach i rentach z Funduszu 
Ubezpieczeń Społecznych. 

 
 
 
s. 175/274 
 
2025-07-03 
 
5. Przy obliczaniu kwoty należnych składek, waloryzowanych na podstawie ust. 
4, stosuje się odpowiednio art. 19 ust. 1 i art. 22 ust. 1 pkt 1 i 2 ustawy o systemie 
ubezpieczeń społecznych. 
6. Przepisy ust. 1–5 stosuje się również do funkcjonariusza, który pozostawał w 
służbie przed dniem 2 stycznia 1999 r., jeżeli po zwolnieniu ze służby, pomimo 
spełnienia warunków do nabycia prawa do emerytury policyjnej, zgłosił wniosek 
o przyznanie emerytury z tytułu podlegania ubezpieczeniom społecznym. 
7. W przypadku, o którym mowa w ust. 6, kwotę należnych, zwaloryzowanych 
składek przekazuje się niezwłocznie na podstawie zawiadomienia przez Zakład 
Ubezpieczeń Społecznych o ustaleniu funkcjonariuszowi prawa do emerytury 
przewidzianej w przepisach, o których mowa w ust. 4. 
8. Kwota należnych, zwaloryzowanych składek stanowi przychody Funduszu 
Ubezpieczeń Społecznych. 
9. Minister właściwy do spraw wewnętrznych, w porozumieniu z ministrem 
właściwym do spraw zabezpieczenia społecznego, określi, w drodze rozporządzenia, 
tryb i terminy przekazywania do Zakładu Ubezpieczeń Społecznych składek, 
o których mowa w ust. 1, 3, 4 i 7, oraz jednostki do tego właściwe, mając na uwadze 
konieczność zapewnienia prawidłowego i niezwłocznego wykonywania czynności 
związanych z przekazywaniem tych składek.

***
## Art. 70. {#policja-art-70}

1. Policjant otrzymuje bezpłatne umundurowanie. 
2. Minister właściwy do spraw wewnętrznych, w porozumieniu z ministrem 
właściwym do spraw finansów publicznych, określi, w drodze rozporządzenia, 
wysokość i warunki przyznawania równoważnika pieniężnego w zamian za 
umundurowanie, uwzględniając: 
1) 
elementy umundurowania stanowiące podstawę do określenia wysokości 
równoważnika; 
2) 
sposób ustalania wysokości równoważnika; 
3) 
tryb i przypadki przyznawania, zwrotu i zawieszania wypłaty równoważnika; 
4) 
terminy wypłacania lub zwrotu równoważnika.

***
## Art. 71. {#policja-art-71}

1. Jednostki i komórki organizacyjne Policji oraz policjanci otrzymują 
wyposażenie niezbędne do wykonywania czynności służbowych. 
2. Normy wyposażenia, o którym mowa w ust. 1, szczegółowe zasady jego 
przyznawania i użytkowania określa  

 
 
 
s. 176/274 
 
2025-07-03 
 
Komendant Główny Policji.

***
## Art. 71a. {#policja-art-71a}

1. Za stan bezpieczeństwa i higieny służby w stosunku do podległych 
policjantów odpowiadają Komendant Główny Policji, Komendant CBŚP, Komendant 
BSWP, Komendant CBZC, Dyrektor CLKP, komendanci wojewódzcy Policji, 
Komendant Stołeczny Policji, komendanci powiatowi (miejscy) Policji, komendanci 
rejonowi Policji, Komendant-Rektor Akademii Policji w Szczytnie i komendanci 
szkół policyjnych. 
2. W przypadku 
policjantów 
odbywających 
szkolenia 
zawodowe 
lub 
doskonalenie zawodowe centralne w Policji za stan bezpieczeństwa i higieny służby 
odpowiadają Komendant-Rektor Akademii Policji w Szczytnie, komendanci szkół 
policyjnych i kierownik ośrodka szkolenia, realizując obowiązki, o których mowa 
w art. 207 § 2 pkt 1–6, art. 2071, art. 2091 § 1–3, art. 2092, art. 214, art. 215, art. 2374 
i art. 2376 ustawy z dnia 26 czerwca 1974 r. – Kodeks pracy, zwanej dalej „Kodeksem 
pracy”. 
3. Za pracodawcę, w rozumieniu przepisów działu dziesiątego Kodeksu pracy, a 
także przepisów wykonawczych wydanych na jego podstawie, w stosunku do 
podległych policjantów uważa się przełożonych wymienionych w ust. 1. 
4. Za osobę kierującą pracownikami, w rozumieniu przepisów działu dziesiątego 
Kodeksu pracy, a także przepisów wykonawczych wydanych na jego podstawie, 
uważa się policjanta pełniącego służbę lub wykonującego obowiązki na stanowisku 
kierowniczym. 
5. Policjant jest obowiązany do przestrzegania przepisów i zasad bezpieczeństwa 
i higieny służby. 
6. W sprawach bezpieczeństwa i higieny służby stosuje się odpowiednio przepisy 
działu dziesiątego Kodeksu pracy, a także przepisy wykonawcze wydane na jego 
podstawie, z wyłączeniem przepisów art. 207 § 2 pkt 7, art. 2091 § 4, art. 228 § 1 i 2, 
art. 229 § 1–12, 4a i 8 w zakresie niedotyczącym wskazówek metodycznych w sprawie 
przeprowadzania badań profilaktycznych pracowników oraz dokumentowania i 
kontroli badań okresowych i kontrolnych, art. 230 § 2, art. 232, art. 234 § 1–31, art. 
235–2352, art. 237–2372, art. 2377 § 1 pkt 1 i § 2–4, art. 2378 § 1, art. 2379 § 3, art. 
23711 § 4 oraz art. 23711a § 4. 

 
 
 
s. 177/274 
 
2025-07-03 
 
7. Przepisów art. 2092, art. 2093, art. 210 § 1–5 i art. 226 oraz przepisów 
wykonawczych wydanych na podstawie art. 210 § 6 Kodeksu pracy nie stosuje się do 
wykonywanych przez policjanta zadań określonych w: 
1) 
art. 1 ust. 2 pkt 1–4 oraz 6; 
2) 
art. 1 ust. 2 pkt 7 i ust. 3, jeżeli charakter tych działań ma związek z zadaniami 
określonymi w pkt 1. 
8. W czasie wykonywania zadań, o których mowa w art. 1 ust. 2 pkt 1 i 3a, w 
okolicznościach uzasadnionych stanem wyższej konieczności, policjant służby 
kontrterrorystycznej może odstąpić od przestrzegania przepisów oraz zasad 
bezpieczeństwa i higieny służby, z zachowaniem dostępnych w danych warunkach 
zabezpieczeń, jeżeli w jego ocenie, dokonanej w miejscu i czasie wykonywania 
zadania, istnieje prawdopodobieństwo uratowania życia ludzkiego lub odwrócenia 
zagrożenia godzącego w bezpieczeństwo państwa. 
9. Za przygotowanie i zapewnienie właściwych warunków bezpieczeństwa 
i higieny służby w trakcie realizacji szkolenia zawodowego lub doskonalenia 
zawodowego, w szczególności prowadzonych z użyciem środków przymusu 
bezpośredniego, środków ochrony indywidualnej lub broni palnej, odpowiedzialni są 
odpowiednio: Komendant Główny Policji, Komendant CBŚP, Komendant BSWP, 
Komendant CBZC, Dyrektor CLKP, komendanci wojewódzcy Policji, Komendant 
Stołeczny Policji, komendanci powiatowi (miejscy) Policji, komendanci rejonowi 
Policji, Komendant-Rektor Akademii Policji w Szczytnie i komendanci szkół 
policyjnych. 
10. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
szczegółowe warunki bezpieczeństwa i higieny służby w trakcie realizacji szkolenia 
lub doskonalenia, o których mowa w ust. 9, oraz szczegółowe warunki uczestnictwa 
w tym szkoleniu lub doskonaleniu, uwzględniając konieczność właściwego ich 
przygotowania oraz właściwość i specyfikę służby w Policji.

***
## Art. 71b. {#policja-art-71b}

1. W celu ustalenia zdolności do wykonywania zadań na zajmowanym 
stanowisku służbowym policjant jest obowiązany poddać się badaniom okresowym 
lub kontrolnym w terminie wskazanym w skierowaniu na takie badanie. 
2. Skierowanie na badanie okresowe lub kontrolne zawiera w szczególności imię 
i nazwisko, numer PESEL, adres zamieszkania, stanowisko służbowe policjanta 
kierowanego na badanie oraz opis warunków pełnienia służby występujących na 

 
 
 
s. 178/274 
 
2025-07-03 
 
zajmowanym stanowisku służbowym, w tym czynników szkodliwych lub 
uciążliwych, o których mowa w przepisach wykonawczych wydanych na podstawie 
art. 229 § 8 Kodeksu pracy, i innych wynikających z warunków pełnienia służby. 
3. Na pierwsze badanie okresowe policjant jest kierowany w terminie 3 lat od 
dnia przyjęcia do służby. 
4. Rodzaj, zakres i częstotliwość badań okresowych są uzależnione od rodzaju 
pełnionej służby i wieku policjanta. 
5. Lekarz przeprowadzający badanie okresowe lub kontrolne, w celu 
uwzględnienia wszystkich czynników szkodliwych lub uciążliwych i innych 
wynikających z warunków pełnienia służby wskazanych w skierowaniu na badanie, 
może poszerzyć jego zakres o dodatkowe badania lekarskie, konsultacje u lekarzy 
specjalistów lub badania diagnostyczne, a także wyznaczyć termin następnego badania 
okresowego krótszy niż określony w przepisach wykonawczych wydanych na 
podstawie ust. 18, jeżeli stwierdzi, że jest to niezbędne dla ustalenia zdolności do 
wykonywania zadań na zajmowanym stanowisku służbowym. Badania i konsultacje 
stanowią część badania okresowego lub kontrolnego. 
6. W przypadku, o którym mowa w ust. 5, lekarz wykorzystuje wskazówki 
metodyczne w sprawie przeprowadzania badań profilaktycznych pracowników 
określone w przepisach wykonawczych wydanych na podstawie art. 229 § 8 Kodeksu 
pracy. 
7. Policjanta kieruje się na badanie okresowe w przypadku przeniesienia go na 
stanowisko służbowe, na którym występują czynniki szkodliwe lub uciążliwe i inne 
wynikające z warunków pełnienia służby, inne niż występujące na dotychczas 
zajmowanym stanowisku służbowym, z uwzględnieniem terminu określonego w ust. 
3. 
8. Badania okresowe i kontrolne są wykonywane na podstawie skierowania na 
badanie wystawionego przez: 
1) 
przełożonych, o których mowa w art. 71a ust. 1, lub upoważnione przez nich 
osoby; 
2) 
ministra właściwego do spraw wewnętrznych lub upoważnioną przez niego 
osobę w stosunku do Komendanta Głównego Policji, I Zastępcy Komendanta 
Głównego Policji oraz zastępców Komendanta Głównego Policji. 
9. Skierowanie na badanie: 
1) 
kontrolne – wystawia się najpóźniej w dniu zgłoszenia się policjanta do służby, 

 
 
 
s. 179/274 
 
2025-07-03 
 
2) 
okresowe – wystawia się nie później niż w terminie 30 dni przed upływem 
ważności orzeczenia lekarskiego 
– w 3 egzemplarzach, z których jeden przeznaczony jest dla policjanta kierowanego 
na badanie. 
10. Badania okresowe i kontrolne kończą się orzeczeniem lekarskim 
stwierdzającym: 
1) 
brak przeciwwskazań zdrowotnych do służby na określonym stanowisku 
służbowym, 
2) 
istnienie przeciwwskazań zdrowotnych do służby na określonym stanowisku 
służbowym 
– w warunkach służby opisanych w skierowaniu na badanie. 
11. Od orzeczenia lekarskiego policjantowi i przełożonym, o których mowa w 
art. 71a ust. 1, przysługuje odwołanie w terminie 7 dni od dnia otrzymania orzeczenia. 
12. Odwołanie od orzeczenia lekarskiego wraz z uzasadnieniem wnosi się na 
piśmie za pośrednictwem lekarza, który wydał to orzeczenie, do: 
1) 
wojewódzkiego ośrodka medycyny pracy właściwego ze względu na miejsce 
pełnienia służby policjanta; 
2) 
instytutu badawczego w dziedzinie medycyny pracy lub Uniwersyteckiego 
Centrum Medycyny Morskiej i Tropikalnej w Gdyni, jeżeli odwołanie dotyczy 
orzeczenia lekarskiego wydanego przez lekarza zatrudnionego w wojewódzkim 
ośrodku medycyny pracy. 
13. Lekarz, za którego pośrednictwem jest składane odwołanie, w terminie 7 dni 
od dnia otrzymania odwołania wraz z uzasadnieniem przekazuje je wraz z 
dokumentacją stanowiącą podstawę wydanego orzeczenia lekarskiego do właściwego 
podmiotu, o którym mowa w ust. 12. 
14. Badanie w trybie odwołania przeprowadza w terminie 14 dni od dnia 
otrzymania odwołania właściwy podmiot, o którym mowa w ust. 12. 
15. Orzeczenie lekarskie wydane w trybie odwołania jest ostateczne. 
16. Badania okresowe i kontrolne podlegają dokumentowaniu i kontroli w sposób 
określony w przepisach wykonawczych wydanych na podstawie art. 229 § 8 Kodeksu 
pracy. 
17. Kontrolę badań okresowych i kontrolnych wykonują podmioty, o których 
mowa w ust. 12. 
18. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia: 

 
 
 
s. 180/274 
 
2025-07-03 
 
1) 
rodzaj, zakres i częstotliwość badań okresowych, uwzględniając rodzaj pełnionej 
służby i wiek policjanta; 
2) 
wzór skierowania na badanie okresowe lub kontrolne, uwzględniając 
konieczność zamieszczenia w tym wzorze informacji niezbędnych do 
jednoznacznego ustalenia zakresu badań; 
3) 
wzór orzeczenia lekarskiego, uwzględniając jednolitość informacji znajdujących 
się w orzeczeniu.

***
## Art. 71c. {#policja-art-71c}

1. Policjant w dziedzinie bezpieczeństwa i higieny służby podlega 
następującym szkoleniom: 
1) 
wstępnemu ogólnemu; 
2) 
wstępnemu na stanowisku służby; 
3) 
okresowemu. 
2. Szkoleniu wstępnemu ogólnemu podlega wyłącznie policjant nowo przyjęty 
do służby w Policji. 
3. Szkoleniu wstępnemu na stanowisku służby podlega policjant w przypadku 
zmiany: 
1) 
jednostki organizacyjnej Policji; 
2) 
stanowiska służbowego, w związku z którym zmieniają się czynniki szkodliwe 
lub uciążliwe, lub inne czynniki wynikające z warunków pełnienia służby. 
4. Ukończenie 
szkolenia 
zawodowego, 
o którym 
mowa 
w art. 34 ust. 8 pkt 1 lit. a, jest równoznaczne z odbyciem pierwszego szkolenia 
wstępnego na stanowisku służby. 
5. Szkoleniu okresowemu podlega policjant oraz policjant pełniący służbę na 
stanowisku kierowniczym – nie rzadziej niż raz na 5 lat, a w przypadku służby na 
stanowisku służbowym, na którym występują warunki szczególnie uciążliwe lub 
szkodliwe dla zdrowia – nie rzadziej niż raz na 3 lata. 
6. Szkolenie okresowe przełożonego, o którym mowa w art. 71a ust. 1, oraz 
policjanta pełniącego służbę na stanowisku kierowniczym zawiera tematykę z zakresu 
bezpieczeństwa i higieny służby oraz bezpieczeństwa i higieny pracy.

***
## Art. 71d. {#policja-art-71d}

W przypadku policjantów delegowanych do czasowego pełnienia 
służby w innej jednostce organizacyjnej Policji lub w innej miejscowości przełożony 
w jednostce, do której policjant został delegowany, realizuje w stosunku do niego 
zadania, o których mowa w art. 71a–71c. 

 
 
 
s. 181/274 
 
2025-07-03

***
## Art. 71e. {#policja-art-71e}

1. W przypadku wystąpienia lub możliwości wystąpienia na stanowisku 
służbowym szkodliwego biologicznego czynnika chorobotwórczego, przeciw 
któremu jest dostępna szczepionka, policjant może poddać się szczepieniom 
ochronnym, o których mowa w ustawie z dnia 5 grudnia 2008 r. o zapobieganiu oraz 
zwalczaniu zakażeń i chorób zakaźnych u ludzi (Dz. U. z 2024 r. poz. 924 i 1897) oraz 
przepisach wykonawczych wydanych na jej podstawie.  
2. (uchylony)

***
## Art. 72. {#policja-art-72}

1. Policjantowi w czasie pełnienia służby przysługuje bezpłatnie 
wyżywienie w naturze, jeżeli rodzaj i warunki służby lub właściwości lub miejsce jej 
pełnienia uzasadniają przyznanie wyżywienia w naturze, albo świadczenie pieniężne 
w zamian za wyżywienie. 
2. Wyżywienie w naturze przysługuje policjantowi: 
1) 
pełniącemu służbę w systemie skoszarowanym; 
2) 
biorącemu udział w szkoleniach lub ćwiczeniach z zakresu systemu obronnego 
kraju, działań antyterrorystycznych lub zarządzania kryzysowego, jeżeli trwają 
one w sposób ciągły powyżej 8 godzin; 
3) 
biorącemu udział w akcjach ochrony porządku publicznego, zapobiegania 
skutkom klęsk żywiołowych lub usuwania ich skutków oraz w działaniach 
porządkowych podczas akcji ratowniczych przy likwidacji skutków klęsk 
żywiołowych, trwających ponad 8 godzin, a w przypadku akcji w miejscu stałego 
pełnienia służby – w warunkach powodujących konieczność pełnienia służby 
przez okres powyżej 10 godzin; 
4) 
który w przypadku zaistnienia poważnego zagrożenia porządku publicznego 
bierze bezpośredni udział w działaniach porządkowych lub wchodzi w skład sił 
wyznaczonych do tych działań i przebywa na terenie objętym tymi działaniami; 
5) 
w innych uzasadnionych przypadkach. 
3. Wyżywienie w naturze przysługuje policjantowi na podstawie normy 
wyżywienia, którą stanowi wartość energetyczna, odżywcza i pieniężna produktów 
żywnościowych przysługujących policjantowi w określonych przypadkach. W razie 
zwiększonego zapotrzebowania na wartość energetyczną i odżywczą ze względu na 
rodzaj i warunki służby lub właściwości lub miejsce jej pełnienia norma może zostać 
uzupełniona. 

 
 
 
s. 182/274 
 
2025-07-03 
 
4. Normy wyżywienia mogą być realizowane w formie suchego prowiantu, 
gotowych pakietów żywnościowych, lub posiłków sporządzanych przez zewnętrzne 
podmioty gastronomiczne, w sytuacji gdy zorganizowanie wyżywienia w postaci 
posiłków sporządzanych w punktach żywienia Policji nie jest możliwe albo gdy rodzaj 
i warunki pełnionej służby wymagają tego rodzaju wyżywienia. W przypadku 
realizacji wyżywienia w formie gotowych pakietów żywnościowych lub w formie 
posiłków sporządzanych przez zewnętrzne podmioty gastronomiczne normę 
wyżywienia podwyższa się o koszty zapewnienia wyżywienia. 
5. W przypadku wyżywienia w naturze należy się kierować zasadami 
racjonalnego żywienia, w granicach obowiązujących wartości energetycznych, 
odżywczych 
i 
pieniężnych 
produktów 
żywnościowych 
określonych 
dla 
poszczególnych norm wyżywienia. 
6. Policjant otrzymuje świadczenie pieniężne w zamian za wyżywienie w 
przypadku: 
1) 
pełnienia w okresie od dnia 1 listopada do dnia 31 marca służby na wolnym 
powietrzu przez co najmniej 4 godziny dziennie albo 
2) 
gdy rodzaj i warunki pełnienia służby lub względy techniczne lub organizacyjne 
uniemożliwiają korzystanie z wyżywienia przysługującego temu policjantowi w 
naturze, albo 
3) 
braku możliwości zapewnienia policjantowi bezpłatnego wyżywienia w naturze 
z powodów zdrowotnych, udokumentowanych zaświadczeniem lekarskim. 
7. Świadczenie pieniężne w zamian za wyżywienie podwyższa się: 
1) 
gdy rodzaj i warunki pełnienia służby lub względy techniczne lub organizacyjne 
uniemożliwiają 
korzystanie 
z wyżywienia 
przysługującego 
w naturze 
policjantowi: 
a) 
który jest studentem, na podstawie skierowania przełożonego, o którym 
mowa w art. 32 ust. 1, albo słuchaczem Akademii Policji w Szczytnie lub 
słuchaczem szkoły policyjnej lub ośrodka szkolenia na szkoleniu 
zawodowym albo doskonaleniu zawodowym centralnym, realizowanym 
w systemie stacjonarnym, 
b) 
który uczestniczy w doskonaleniu zawodowym centralnym odbywającym 
się w jednostkach organizacyjnych Policji, o którym mowa w art. 34h 
ust. 3, realizowanym w systemie stacjonarnym, 
c) 
w służbie kandydackiej; 

 
 
 
s. 183/274 
 
2025-07-03 
 
2) 
w służbie kandydackiej przebywającemu na urlopie lub pełnodobowej 
przepustce; 
3) 
w przypadku skierowania policjanta zaliczonego do personelu latającego do 
wykonywania lotów poza miejsce stałej dyslokacji na czas powyżej 8 godzin. 
8. Policjant, któremu przysługuje wyżywienie w naturze lub świadczenie 
pieniężne w zamian za wyżywienie z kilku tytułów, otrzymuje wyżywienie w naturze 
albo świadczenie pieniężne w zamian za wyżywienie tylko z jednego tytułu według 
najkorzystniejszej dla niego normy wyżywienia, z wyłączeniem przypadków, w 
których policjant uczestniczy w uroczystym posiłku organizowanym w punkcie 
żywienia Policji. 
9. Policjantowi, który zrezygnował z przysługującego mu wyżywienia w naturze, 
nie przysługuje świadczenie pieniężne w zamian za wyżywienie ani dieta na pokrycie 
zwiększonych kosztów wyżywienia, z wyjątkiem rezygnacji z wyżywienia w naturze 
z powodów zdrowotnych, udokumentowanych zaświadczeniem lekarskim w sytuacji 
braku możliwości zapewnienia policjantowi bezpłatnie wyżywienia w naturze. 
10. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia: 
1) 
rodzaje norm wyżywienia oraz ich wartość pieniężną, 
2) 
średnie wartości energetyczne i odżywcze produktów żywnościowych objętych 
poszczególnymi normami, 
3) 
przypadki przyznawania poszczególnych norm wyżywienia, 
4) 
przypadki, w których normy wyżywienia mogą zostać uzupełnione, oraz wartość 
pieniężną uzupełnienia, 
5) 
wartości świadczenia pieniężnego w zamian za wyżywienie oraz wymiar jego 
podwyższania, a także jednostkę organizacyjną Policji właściwą do jego 
wypłacania i terminy jego wypłaty 
– uwzględniając zasady racjonalnego żywienia, adekwatność środków finansowych 
służących zapewnieniu policjantom wyżywienia w naturze względem realnej wartości 
wyżywienia, przyporządkowanie norm wyżywienia do przypadków, w których 
policjantowi przysługuje wyżywienie w naturze, wskazanych w ust. 2, rozróżnienie 
przypadków wypłacania świadczenia pieniężnego w zamian za wyżywienie oraz 
mając na względzie właściwe warunki pełnienia służby.

***
## Art. 72a. {#policja-art-72a}

Napoje w naturze, w ilości zaspokajającej potrzeby policjanta, 
przysługują w czasie pełnienia służby, w przypadkach i na warunkach określonych w 

 
 
 
s. 184/274 
 
2025-07-03 
 
art. 232 ustawy z dnia 26 czerwca 1974 r. – Kodeks pracy oraz w przepisach 
wykonawczych wydanych na jego podstawie.

***
## Art. 73. {#policja-art-73}

1. Policjantowi i członkom jego rodziny przysługuje raz w roku prawo 
przejazdu na koszt właściwego organu Policji środkami publicznego transportu 
zbiorowego do jednej z obranych przez siebie miejscowości w kraju i z powrotem. 
2. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
warunki korzystania przez policjanta z prawa, o którym mowa w ust. 1, uwzględniając 
sposób rozliczania kosztów przejazdu. 
3. W razie niewykorzystania przysługującego przejazdu osoba uprawniona 
otrzymuje zryczałtowany równoważnik pieniężny. 
4. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
warunki przyznania równoważnika pieniężnego, o którym mowa w ust. 3, 
uwzględniając 
sposób 
ustalania 
wysokości 
równoważnika 
i 
rozliczania 
niewykorzystanego przez policjanta przejazdu. 
5. Zwrot kosztów przejazdu lub zryczałtowany równoważnik pieniężny, o 
których mowa w ust. 1 i 3, nie przysługują policjantowi w roku kalendarzowym, w 
którym wykupiono uprawnienia do bezpłatnych przejazdów środkami publicznego 
transportu zbiorowego na podstawie odrębnych przepisów. 
6. Osobom, o których mowa w ust. 1, mogą być przyznawane także inne 
świadczenia socjalne i bytowe. 
7. Minister właściwy do spraw wewnętrznych, w porozumieniu z ministrem 
właściwym do spraw zabezpieczenia społecznego, określi, w drodze rozporządzenia, 
rodzaj i zakres świadczeń, o których mowa w ust. 6, uwzględniając warunki 
korzystania z tych świadczeń, sposób ich realizacji, a w przypadku świadczeń 
finansowych – ich wysokość, sposób obliczania, terminy rozliczeń oraz terminy 
wypłaty.

***
## Art. 74. {#policja-art-74}

(uchylony)

***
## Art. 75. {#policja-art-75}

(pominięty)

***
## Art. 76. {#policja-art-76}

(pominięty)

***
## Art. 77. {#policja-art-77}

1. Za członków rodziny policjanta uprawnionych do świadczeń 
przewidzianych w art. 73, 75 i 76 uważa się małżonka i dzieci. 

 
 
 
s. 185/274 
 
2025-07-03 
 
2. Za dzieci uważa się dzieci własne, dzieci małżonka, dzieci przysposobione i 
dzieci przyjęte na wychowanie, które: 
1) 
nie przekroczyły 18 roku życia, a w razie uczęszczania do szkoły – 24 lat albo 25 
lat, jeżeli odbywają studia w szkole wyższej, a ukończenie 24 lat przypada na 
ostatni lub przedostatni rok studiów, albo 
2) 
stały się inwalidami I 7) lub II grupy 8) przed osiągnięciem wieku określonego w 
pkt 1.

***
## Art. 78. {#policja-art-78}

Okres służby policjanta traktuje się jako pracę w szczególnym 
charakterze w rozumieniu przepisów o zaopatrzeniu emerytalnym pracowników i ich 
rodzin 9).

***
## Art. 79. {#policja-art-79}

1. Policjantowi przysługują uprawnienia pracownika związane 
z rodzicielstwem określone w Kodeksie pracy, z wyjątkiem art. 1867 i art. 1881, jeżeli 
przepisy niniejszej ustawy nie stanowią inaczej. 
2. Jeżeli oboje rodzice lub opiekunowie są policjantami albo jedno z nich jest 
policjantem, a drugie pozostaje w stosunku pracy, z uprawnień, o których mowa 
w ust. 1, może korzystać jedno z nich.

***
## Art. 79a. {#policja-art-79a}

Jeżeli zachodzi konieczność zastępstwa policjanta w czasie jego 
nieobecności w służbie w związku z przebywaniem na urlopie macierzyńskim, urlopie 
na warunkach urlopu macierzyńskiego, uzupełniającym urlopie macierzyńskim, 
urlopie ojcowskim, urlopie rodzicielskim lub urlopie wychowawczym, można w tym 
celu zatrudnić pracownika na podstawie umowy o pracę na czas określony, 
obejmujący czas tej nieobecności.

***
## Art. 80. {#policja-art-80}

1. Policjantowi, który po zwolnieniu ze służby w Policji podjął pracę, 
okres tej służby wlicza się do okresu zatrudnienia w zakresie wszelkich uprawnień 
wynikających z prawa pracy. 
2. (uchylony) 
 
7) Obecnie całkowicie niezdolnymi do pracy oraz niezdolnymi do samodzielnej egzystencji, na 
podstawie art. 10 ust. 2 pkt 1 ustawy z dnia 28 czerwca 1996 r. o zmianie niektórych ustaw 
o zaopatrzeniu emerytalnym i o ubezpieczeniu społecznym (Dz. U. poz. 461), która weszła w życie 
z dniem 1 września 1997 r. 
8) Obecnie całkowicie niezdolnymi do pracy, na podstawie art. 10 ust. 2 pkt 2 ustawy, o której mowa 
w odnośniku 7. 
9) Obecnie przepisów o emeryturach i rentach z Funduszu Ubezpieczeń Społecznych, na podstawie 
art. 192 ustawy z dnia 17 grudnia 1998 r. o emeryturach i rentach z Funduszu Ubezpieczeń 
Społecznych (Dz. U. z 2024 r. poz. 1631 i 1674), która weszła w życie z dniem 1 stycznia 1999 r. 

 
 
 
s. 186/274 
 
2025-07-03 
 
3. (uchylony) 
4. Przepisu ust. 1 nie stosuje się do policjanta zwolnionego ze służby na 
podstawie art. 41 ust. 1 pkt 3, 4 i 4a.

***
## Art. 81. {#policja-art-81}

1. Minister właściwy do spraw wewnętrznych określi, w drodze 
rozporządzenia, szczegółowe prawa i obowiązki oraz przebieg służby policjantów, 
uwzględniając właściwości i specyfikę służby w jednostkach organizacyjnych Policji, 
tryb nawiązywania, zmiany i rozwiązywania stosunku służbowego policjanta, zadania 
kierowników komórek organizacyjnych właściwych w sprawach osobowych, treść 
rozkazów personalnych o mianowaniu policjanta na dane stanowisko służbowe lub o 
zwolnieniu policjanta ze służby, tryb wydawania świadectwa służby i opinii o służbie 
policjanta, ich wzory, termin żądania sprostowania świadectwa i opinii oraz termin 
dokonania takiego sprostowania. 
2. Sposób pełnienia służby policjantów określają zarządzenia, regulaminy i 
rozkazy Komendanta Głównego Policji.

***
## Art. 82. {#policja-art-82}

1. Policjantowi przysługuje prawo do corocznego płatnego urlopu 
wypoczynkowego w wymiarze 26 dni roboczych. 
2. Policjant uzyskuje prawo do pierwszego urlopu z upływem 6 miesięcy służby 
w wymiarze połowy urlopu przysługującego po roku służby. 
3. Prawo do urlopu w pełnym wymiarze policjant nabywa z upływem roku 
służby. Do tego urlopu wlicza się urlop, o którym mowa w ust. 2.

***
## Art. 83. {#policja-art-83}

1. Policjanta można odwołać z urlopu wypoczynkowego z ważnych 
względów służbowych, a także wstrzymać udzielenie mu urlopu w całości lub w 
części. Termin urlopu może być także przesunięty na wniosek policjanta, 
umotywowany ważnymi względami. 
2. Policjantowi odwołanemu z urlopu przysługuje zwrot kosztów przejazdu 
według norm ustalonych w przepisach o należnościach służbowych w przypadkach 
przeniesienia lub oddelegowania, jak również innych kosztów. 
2a. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
tryb zwrotu kosztów przejazdu i innych poniesionych kosztów przysługujących 
policjantowi w razie odwołania z urlopu, z uwzględnieniem norm określonych dla 
przenoszonych lub delegowanych policjantów, udokumentowanych opłat dokonanych 
przez policjanta, a które nie zostały wykorzystane w związku z odwołaniem z urlopu, 

 
 
 
s. 187/274 
 
2025-07-03 
 
jak również opłat poniesionych na członków rodziny, o których mowa w art. 77, jeżeli 
odwołanie policjanta z urlopu spowodowało także ich powrót. 
3. Odwołanie policjanta z urlopu ze względów służbowych wymaga zgody 
przełożonego. 
4. Policjantowi, który nie wykorzystał urlopu w danym roku kalendarzowym, 
urlopu tego należy udzielić w ciągu pierwszych 3 miesięcy następnego roku.

***
## Art. 83a. {#policja-art-83a}

1. Policjantowi posiadającemu status weterana poszkodowanego 
przysługuje prawo do corocznego płatnego dodatkowego urlopu wypoczynkowego w 
wymiarze 5 dni roboczych. 
2. Prawo do urlopu, o którym mowa w ust. 1, nie przysługuje policjantowi 
posiadającemu status weterana poszkodowanego uprawnionemu do urlopu 
wypoczynkowego i urlopów dodatkowych, z wyłączeniem urlopu dodatkowego z 
tytułu pełnienia służby w warunkach szczególnie uciążliwych lub szkodliwych dla 
zdrowia, w wymiarze przekraczającym 26 dni roboczych. 
3. Prawo do pierwszego urlopu, o którym mowa w ust. 1, powstaje z dniem, w 
którym decyzja administracyjna o przyznaniu statusu weterana poszkodowanego stała 
się ostateczna, przy czym realizacja tego prawa może nastąpić nie wcześniej niż z 
dniem przedstawienia przez policjanta tej decyzji przełożonemu, o którym mowa w 
art. 32 ust. 1. 
4. Urlop, o którym mowa w ust. 1, wykorzystuje się w całości w roku 
kalendarzowym, w którym policjant ma do niego prawo, w terminie uzgodnionym z 
przełożonym policjanta. 
5. W zakresie nieuregulowanym w ustawie do urlopu, o którym mowa w ust. 1, 
stosuje się odpowiednio przepisy wydane na podstawie art. 86.

***
## Art. 84. {#policja-art-84}

Minister właściwy do spraw wewnętrznych może, w drodze 
rozporządzenia, wprowadzić płatne urlopy dodatkowe w wymiarze do 13 dni 
roboczych rocznie dla policjantów, którzy pełnią służbę w warunkach szczególnie 
uciążliwych lub szkodliwych dla zdrowia albo osiągnęli określony wiek lub staż 
służby, albo gdy jest to uzasadnione szczególnymi właściwościami służby.

***
## Art. 85. {#policja-art-85}

Policjantowi można udzielić płatnego urlopu zdrowotnego lub 
okolicznościowego, a także urlopu bezpłatnego z ważnych przyczyn.

***
## Art. 86. {#policja-art-86}

Minister właściwy do spraw wewnętrznych określi, w drodze 
rozporządzenia, szczegółowe zasady przyznawania policjantom urlopów, tryb 

 
 
 
s. 188/274 
 
2025-07-03 
 
postępowania w tych sprawach oraz wymiar urlopów, o których mowa w art. 84 i 85, 
uwzględniając okres służby, wiek policjanta, przypadki warunków szczególnie 
uciążliwych i szkodliwych dla zdrowia oraz stopnie szkodliwości wpływające na 
wymiar urlopu dodatkowego.

***
## Art. 86a. {#policja-art-86a}

1. Policjantowi przysługuje prawo do urlopu opiekuńczego 
w wymiarze 5 dni w roku kalendarzowym w celu zapewnienia osobistej opieki lub 
wsparcia osobie będącej członkiem rodziny lub zamieszkującej w tym samym 
gospodarstwie domowym, która wymaga opieki lub wsparcia z poważnych względów 
medycznych. 
2. Przy udzielaniu urlopu, o którym mowa w ust. 1, stosuje się odpowiednio 
przepisy rozdziału Ia działu siódmego Kodeksu pracy. 
3. Za czas urlopu opiekuńczego policjant nie zachowuje prawa do uposażenia.

***
## Art. 87. {#policja-art-87}

1. Policjantowi, który wzorowo wykonuje obowiązki, przejawia 
inicjatywę w służbie i doskonali kwalifikacje zawodowe, mogą być udzielane 
wyróżnienia: 
1) 
pochwała; 
2) 
krótkoterminowy dodatkowy urlop wypoczynkowy w wymiarze do 10 dni 
roboczych; 
3) 
przyznanie odznaki resortowej; 
4) 
przedterminowe mianowanie na wyższy stopień policyjny. 
2. Wyróżnienia udziela policjantowi uprawniony przełożony, o którym mowa w 
art. 32 ust. 1. 
3. Wyróżnienia nie udziela się policjantowi: 
1) 
ukaranemu karą dyscyplinarną, przed jej zatarciem; 
2) 
skazanemu wyrokiem sądu lub w stosunku do którego postępowanie karne 
zostało warunkowo umorzone, przez okres roku od dnia uprawomocnienia się 
orzeczenia. 
4. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
szczegółowy 
tryb 
postępowania 
przy 
udzielaniu 
wyróżnień 
policjantom, 
uwzględniając zakres uprawnień przełożonych do udzielania wyróżnień oraz formę 
udzielania wyróżnień. 

 
 
 
s. 189/274 
 
2025-07-03

