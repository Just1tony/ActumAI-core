---
id: act.policja.ch3
title: Ustawa o Policji — Rozdział 3
dz_u: Dz.U. 1990 Nr 30 poz. 179 (t.j. 2025 poz. 636, 718)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '14'
  last: '22'
source_pdf: D19900179Lj (1).pdf
chunking:
  strategy: by-article
  anchor_pattern: '## Art. {n}. {#policja-art-{n}}'
  hierarchy:
  - Rozdział
  - Art.
---

# Rozdział 3
 
## Art. 14. {#policja-art-14}

1. W granicach swych zadań Policja wykonuje czynności: 
operacyjno-rozpoznawcze, dochodzeniowo-śledcze i administracyjno-porządkowe w 
celu: 
1) 
rozpoznawania, 
zapobiegania 
i 
wykrywania 
przestępstw, 
przestępstw 
skarbowych i wykroczeń; 
2) 
poszukiwania osób ukrywających się przed organami ścigania lub wymiaru 
sprawiedliwości, zwanych dalej „osobami poszukiwanymi”; 
3) 
poszukiwania osób, które na skutek wystąpienia zdarzenia uniemożliwiającego 
ustalenie miejsca ich pobytu należy odnaleźć w celu zapewnienia ochrony ich 
życia, zdrowia lub wolności, zwanych dalej „osobami zaginionymi”. 
2. Policja wykonuje również czynności na polecenie sądu, prokuratora, organów 
administracji państwowej i samorządu terytorialnego w zakresie, w jakim obowiązek 
ten został określony w odrębnych ustawach. 
3. Policjanci w toku wykonywania czynności służbowych mają obowiązek 
respektowania godności ludzkiej oraz przestrzegania i ochrony praw człowieka. 
4. Policja w celu realizacji ustawowych zadań może korzystać z danych o osobie, 
w tym również w formie zapisu elektronicznego, uzyskanych przez inne organy, 
służby 
i 
instytucje 
państwowe 
w 
wyniku 
wykonywania 
czynności 
operacyjno-rozpoznawczych oraz przetwarzać je w rozumieniu ustawy z dnia 14 
grudnia 2018 r. o ochronie danych osobowych przetwarzanych w związku z 
zapobieganiem i zwalczaniem przestępczości (Dz. U. z 2023 r. poz. 1206), bez wiedzy 
i zgody osoby, której dane te dotyczą. 
5. Administrator danych, o których mowa w ust. 4, jest obowiązany udostępnić 
dane osobowe policjantowi wskazanemu w imiennym upoważnieniu Komendanta 
Głównego Policji, Komendanta CBŚP, Komendanta BSWP, Komendanta CBZC, 
komendantów wojewódzkich Policji lub uprawnionego policjanta, po okazaniu tego 
upoważnienia oraz legitymacji służbowej. Fakt udostępnienia tych danych podlega 
ochronie na podstawie ustawy z dnia 5 sierpnia 2010 r. o ochronie informacji 
niejawnych. 

 
 
 
s. 24/274 
 
2025-07-03 
 
5a. Policja może, w zakresie koniecznym do wykonywania jej ustawowych 
zadań, korzystać z informacji kryminalnej zgromadzonej w Krajowym Centrum 
Informacji Kryminalnych. 
5b. W celu wykonywania zadań w zakresie kontroli ruchu drogowego, o których 
mowa w art. 129 ustawy z dnia 20 czerwca 1997 r. – Prawo o ruchu drogowym (Dz. 
U. z 2024 r. poz. 1251), Policja może prowadzić wyszukiwania informacji za 
pośrednictwem Krajowego Punktu Kontaktowego, na zasadach określonych w art. 
80k–80r tej ustawy. 
5c. W celu realizacji zadań, o których mowa w art. 1 ust. 2 pkt 1, 2 i 3a–4a, 
Policja może używać psów służbowych lub koni służbowych. 
6. Prezes Rady Ministrów określi, w drodze rozporządzenia: 
1) 
zakres, warunki i tryb przekazywania Policji informacji o osobie, uzyskanych 
przez 
organy 
uprawnione 
do 
wykonywania 
czynności 
operacyjno-rozpoznawczych 
w 
czasie 
wykonywania 
tych 
czynności, 
uwzględniając możliwość odmowy przekazywania informacji lub ograniczenia 
zakresu tych informacji ze względu na uniemożliwienie realizacji zadań 
ustawowych tych organów lub ujawnienie danych osoby niebędącej 
funkcjonariuszem tych organów, oraz sposób przekazywania informacji na 
wniosek, w tym przy wykorzystaniu urządzeń i systemów teleinformatycznych; 
2) 
wzór upoważnienia, o którym mowa w ust. 5, uwzględniając dane niezbędne do 
zidentyfikowania upoważnionego policjanta oraz konieczność określenia 
terminu ważności upoważnienia. 
7. (uchylony)

***
## Art. 14a. {#policja-art-14a}

Minister właściwy do spraw wewnętrznych, z zachowaniem przepisów 
o ochronie informacji niejawnych, podejmuje decyzję o objęciu przez Policję ochroną 
obiektów, o których mowa w art. 1 ust. 2 pkt 4a, oraz o zakresie realizowanych wobec 
nich działań.

***
## Art. 14b. {#policja-art-14b}

Minister właściwy do spraw wewnętrznych, uwzględniając 
konieczność zapewnienia bezpieczeństwa i porządku publicznego podczas 
przewożenia osób pojazdem, może polecić Policji pilotowanie przejazdu tego pojazdu.

***
## Art. 15. {#policja-art-15}

1. Policjanci wykonując czynności, o których mowa w art. 14, mają 
prawo: 
1) 
legitymowania osób w celu ustalenia ich tożsamości; 

 
 
 
s. 25/274 
 
2025-07-03 
 
2) 
zatrzymywania osób w trybie i przypadkach określonych w przepisach Kodeksu 
postępowania karnego i innych ustaw; 
2a)  zatrzymywania osób pozbawionych wolności, które:  
a) 
dokonały ucieczki z aresztu śledczego, zakładu karnego, ze strzeżonego 
ośrodka lub z aresztu dla cudzoziemców,  
b) 
dokonały ucieczki w trakcie konwojowania lub zatrudnienia, 
c) 
na podstawie zezwolenia właściwego organu opuściły areszt śledczy albo 
zakład karny i nie powróciły do niego w wyznaczonym terminie, 
korzystając z zezwolenia na czasowe opuszczenie aresztu śledczego lub 
zakładu karnego lub z przerwy w odbywaniu kary pozbawienia wolności;  
3) 
zatrzymywania osób stwarzających w sposób oczywisty bezpośrednie 
zagrożenie dla życia lub zdrowia ludzkiego, a także dla mienia; 
3a) pobierania od osób odcisków linii papilarnych lub wymazu ze śluzówki 
policzków: 
a) 
w trybie i przypadkach określonych w przepisach Kodeksu postępowania 
karnego oraz ustawy z dnia 22 listopada 2013 r. o postępowaniu wobec osób 
z zaburzeniami psychicznymi stwarzających zagrożenie życia, zdrowia lub 
wolności seksualnej innych osób (Dz. U. z 2022 r. poz. 1689), 
b) 
w celu identyfikacji osób o nieustalonej tożsamości oraz osób usiłujących 
ukryć swoją tożsamość, jeżeli ustalenie tożsamości w inny sposób nie jest 
możliwe, 
c) 
za ich zgodą – w celu identyfikacji osób zaginionych lub zwłok ludzkich o 
nieustalonej tożsamości, 
d) 
w celu identyfikacji lub wykrywania sprawców przestępstw – na zasadach 
określonych w niniejszej ustawie; 
3b) pobierania odcisków linii papilarnych lub materiału biologicznego ze zwłok 
ludzkich o nieustalonej tożsamości; 
4) 
przeszukiwania osób i pomieszczeń w trybie i przypadkach określonych w 
przepisach Kodeksu postępowania karnego i innych ustaw; 
4a) obserwowania i rejestrowania przy użyciu środków technicznych obrazu z 
pomieszczeń przeznaczonych dla osób zatrzymanych lub doprowadzonych w 
celu wytrzeźwienia, policyjnych izb dziecka, pokoi przejściowych oraz tym-
czasowych pomieszczeń przejściowych; 

 
 
 
s. 26/274 
 
2025-07-03 
 
5) 
dokonywania kontroli osobistej, a także przeglądania zawartości bagaży i 
sprawdzania ładunków w portach i na dworcach oraz w środkach transportu 
lądowego, powietrznego i wodnego: 
a) 
w 
razie 
istnienia 
uzasadnionego 
podejrzenia 
popełnienia 
czynu 
zabronionego pod groźbą kary lub 
b) 
w celu znalezienia: 
– 
broni lub innych niebezpiecznych przedmiotów mogących służyć do 
popełnienia czynu zabronionego pod groźbą kary lub 
– 
przedmiotów, których posiadanie jest zabronione, lub mogących 
stanowić dowód w postępowaniu prowadzonym w związku z realizacją 
zadań, o których mowa w art. 1 ust. 2 pkt 1, 2, 3a, 4, 4a, 6 i 7, oraz 
przepisów innych ustaw określających zadania Policji lub 
– 
przedmiotów podlegających przepadkowi w przypadku uzasadnionego 
przypuszczenia posiadania przez osobę broni lub takich przedmiotów 
lub uzasadnionego przypuszczenia ich użycia do popełnienia czynu 
zabronionego pod groźbą kary 
– na zasadach i w sposób określony w art. 15d i art. 15e; 
5a) obserwowania i rejestrowania przy użyciu środków technicznych obrazu zdarzeń 
w miejscach publicznych, a w przypadku czynności operacyjno-rozpoznawczych 
i administracyjno-porządkowych podejmowanych na podstawie ustawy – także i 
dźwięku towarzyszącego tym zdarzeniom; 
5b) obserwowania i rejestrowania przy użyciu środków technicznych obrazu lub 
dźwięku w trakcie interwencji w miejscach innych niż publiczne, podczas 
prowadzenia działań kontrterrorystycznych oraz wspierania działań jednostek 
organizacyjnych Policji przez służbę kontrterrorystyczną w warunkach 
szczególnego zagrożenia lub wymagających użycia specjalistycznych sił i 
środków oraz specjalistycznej taktyki działań, a także w policyjnych środkach 
transportu; 
6) 
żądania niezbędnej pomocy od instytucji państwowych, organów administracji 
rządowej i samorządu terytorialnego oraz przedsiębiorców prowadzących 
działalność w zakresie użyteczności publicznej; wymienione instytucje, organy 
i przedsiębiorcy są obowiązani, w zakresie swojego działania, do udzielenia tej 
pomocy, w zakresie obowiązujących przepisów prawa; 

 
 
 
s. 27/274 
 
2025-07-03 
 
7) 
zwracania się o niezbędną pomoc do innych przedsiębiorców i organizacji 
społecznych, jak również zwracania się w nagłych wypadkach do każdej osoby 
o udzielenie doraźnej pomocy, w ramach obowiązujących przepisów prawa; 
8) 
(uchylony) 
9) 
dokonywania sprawdzenia prewencyjnego w celu ochrony przed bezprawnymi 
zamachami na życie lub zdrowie osób lub mienie lub w celu ochrony przed 
nieuprawnionymi działaniami skutkującymi zagrożeniem życia lub zdrowia lub 
bezpieczeństwa i porządku publicznego lub: 
a) 
zapobiegania zdarzeniom o charakterze terrorystycznym – osób w związku 
z ich dostępem na teren obiektów lub obszarów ochranianych przez Policję 
lub w związku z zabezpieczeniem przez Policję imprez masowych lub zgro-
madzeń, bagaży lub przedmiotów posiadanych przez te osoby, a także 
środków transportu lądowego, powietrznego lub wodnego lub pojazdów, 
którymi się poruszają w związku z dostępem do tych obiektów lub 
obszarów, 
b) 
znalezienia i odebrania przedmiotów, których użycie ze względu na ich 
właściwości może spowodować zagrożenie życia lub zdrowia lub 
bezpieczeństwa przeprowadzonych czynności osób: 
– 
doprowadzanych przez Policję na polecenie lub zarządzenie 
uprawnionego organu lub w związku z realizacją czynności 
określonych przepisami prawa lub osób w stanie nietrzeźwości 
doprowadzanych przez Policję w celu wytrzeźwienia do siedziby 
jednostki organizacyjnej Policji lub innego miejsca określonego 
przepisami prawa lub wskazanego przez uprawniony organ, na 
polecenie lub zarządzenie którego dokonuje się doprowadzenia, w tym 
osób doprowadzanych umieszczonych w jednostkach organizacyjnych 
Policji w pomieszczeniach dla osób zatrzymanych lub doprowadzonych 
w celu wytrzeźwienia, 
– 
zatrzymywanych w przypadkach określonych w ust. 1 pkt 2–3, osób 
zatrzymanych, przyjmowanych do jednostek organizacyjnych Policji do 
pomieszczeń dla osób zatrzymanych lub doprowadzonych w celu 
wytrzeźwienia, pokoi przejściowych, tymczasowych pomieszczeń 
przejściowych lub policyjnych izb dziecka lub umieszczanych w tych 
pomieszczeniach, 

 
 
 
s. 28/274 
 
2025-07-03 
 
– 
pozbawionych wolności, w tym przebywających w zakładach karnych, 
aresztach śledczych, zakładach poprawczych, schroniskach dla 
nieletnich, policyjnych izbach dziecka lub innych ośrodkach dla 
nieletnich, a także osób skazanych lub tymczasowo aresztowanych 
przekazywanych na podstawie umów międzynarodowych, podczas 
wykonywania w stosunku do tych osób przez Policję, na polecenie sądu 
lub prokuratora, czynności polegających na przemieszczaniu tych osób 
w związku z wykonywaniem czynności procesowych lub innych 
czynności określonych przez sąd lub prokuratora; 
10) wydawania osobom poleceń określonego zachowania się w granicach 
niezbędnych do wykonywania czynności określonych w pkt 1–5 lub 9 lub 
wykonywania innych czynności służbowych podejmowanych w zakresie i w celu 
realizacji ustawowych zadań Policji lub w granicach niezbędnych do ochrony 
przed zatarciem śladów przy zabezpieczaniu miejsca zdarzenia lub w celu 
uniknięcia bezpośredniego zagrożenia bezpieczeństwa osób lub mienia, gdy jest 
to niezbędne do sprawnej realizacji zadań Policji albo uniknięcia zatarcia śladów 
przestępstwa lub wykroczenia. 
2. Osobie zatrzymanej na podstawie ust. 1 pkt 3 przysługują uprawnienia 
przewidziane dla osoby zatrzymanej w Kodeksie postępowania karnego. 
3. Zatrzymanie osoby może być zastosowane tylko wówczas, gdy inne środki 
okazały się bezcelowe lub nieskuteczne. 
4. Osoba zatrzymana, o której mowa w ust. 1 pkt 3, może być okazywana, 
fotografowana lub daktyloskopowana tylko wtedy, gdy jej tożsamości nie można 
ustalić w inny sposób. 
5. Osobę zatrzymaną należy niezwłocznie poddać – w razie uzasadnionej 
potrzeby – badaniu lekarskiemu lub udzielić jej pierwszej pomocy medycznej. 
6. Czynności wymienione w ust. 1 powinny być wykonywane w sposób możliwie 
najmniej naruszający dobra osobiste osoby, wobec której zostają podjęte. 
7. Na sposób prowadzenia czynności, o których mowa w ust. 1 pkt 1–4a, 5a–7 i 
10, przysługuje zażalenie do właściwego miejscowo prokuratora. 
7a. Osoba zatrzymana może zostać umieszczona w pomieszczeniu jednostki 
organizacyjnej Policji lub pomieszczeniu jednostki organizacyjnej Straży Granicznej 
przeznaczonym dla osób zatrzymanych. 

 
 
 
s. 29/274 
 
2025-07-03 
 
7b. Pomieszczenia dla osób zatrzymanych lub doprowadzonych w celu 
wytrzeźwienia, pokoje przejściowe oraz tymczasowe pomieszczenia przejściowe 
mogą tworzyć i znosić komendanci wojewódzcy Policji oraz Komendant Stołeczny 
Policji. 
7c. Użyte w ust. 1 pkt 5b określenie interwencja oznacza włączenie się policjanta 
lub policjantów w tok zdarzenia mogącego naruszać normy prawne i podjęcie działań 
zmierzających do ustalenia charakteru, rodzaju i okoliczności powstałego zdarzenia 
oraz przedsięwzięć ukierunkowanych na przywrócenie naruszonego porządku 
prawnego. 
8. Rada Ministrów określi, w drodze rozporządzenia, sposób postępowania przy 
wykonywaniu uprawnień, o których mowa w ust. 1 pkt 1, 2a, 3, pkt 3a lit. b–d, pkt 3b, 
5a–7, 9 i 10, wzory dokumentów stosowanych w tych sprawach oraz w odniesieniu do 
ust. 1 pkt 5b również sposób przechowywania, odtwarzania i kopiowania zapisów 
obrazu i dźwięku, mając na względzie zapewnienie skuteczności działań 
podejmowanych przez Policję, poszanowanie praw osób, wobec których działania te 
są podejmowane oraz konieczność właściwego zabezpieczenia utrwalonego obrazu i 
dźwięku przed utratą, zniekształceniem, a także zapewnienie ochrony praw osób, 
których wizerunek został utrwalony. 
8a. (uchylony) 
8b. (uchylony) 
9. Minister właściwy do spraw wewnętrznych, w porozumieniu z ministrem 
właściwym 
do 
spraw 
zdrowia, 
określi, 
w drodze 
rozporządzenia, 
tryb 
przeprowadzania badań lekarskich, o których mowa w ust. 5, uwzględniając przypadki 
uzasadniające potrzebę niezwłocznego udzielenia osobie zatrzymanej pierwszej 
pomocy medycznej lub potrzebę poddania jej niezbędnym badaniom lekarskim, czas 
i organizację tych badań oraz sposób ich dokumentowania. 
10. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia: 
1) 
warunki, 
jakim 
powinny 
odpowiadać 
pomieszczenia 
w 
jednostkach 
organizacyjnych Policji dla osób zatrzymanych lub doprowadzonych w celu 
wytrzeźwienia, zakres prowadzonej dokumentacji oraz wzory dokumentów 
wchodzących w jej skład, 
2) 
warunki, jakim powinny odpowiadać pokoje przejściowe w jednostkach 
organizacyjnych Policji, w których można umieścić osoby zatrzymane lub 
doprowadzone na czas wykonania czynności służbowych, oczekiwania na 

 
 
 
s. 30/274 
 
2025-07-03 
 
przewóz do pomieszczenia dla osób zatrzymanych lub doprowadzonych w celu 
wytrzeźwienia albo do policyjnej izby dziecka lub doprowadzenie do jednostki 
penitencjarnej, 
3) 
warunki, jakim powinny odpowiadać tymczasowe pomieszczenia przejściowe, 
które mogą być tworzone poza jednostkami organizacyjnymi Policji, w których 
można umieścić osoby zatrzymane lub doprowadzone w związku z naruszeniem 
porządku prawnego, na czas niezbędny do podjęcia decyzji co do dalszego 
zakresu i charakteru realizowanych wobec tych osób czynności służbowych, 
4) 
warunki, jakim powinny odpowiadać policyjne izby dziecka, 
5) 
regulamin pobytu osób w pomieszczeniach, pokojach i izbach, o których mowa 
w ust. 1 pkt 4a, uwzględniając ich lokalizację, wyposażenie, warunki techniczne 
pomieszczeń i niezbędne części składowe, 
6) 
sposób przechowywania i niszczenia zapisów obrazu z pomieszczeń, pokoi i izb, 
o których mowa w ust. 1 pkt 4a, oraz udostępniania ich uprawnionym podmiotom 
oraz warunki właściwego zabezpieczenia utrwalonego obrazu przed utratą, 
zniekształceniem lub nieuprawnionym ujawnieniem 
– kierując się potrzebą zapewnienia skuteczności działań podejmowanych przez 
Policję oraz potrzebą zapewnienia poszanowania praw osób, wobec których działania 
te są podejmowane. 
11. Zgromadzone zapisy obrazu z pomieszczeń, izb i pokoi, o których mowa w 
ust. 1 pkt 4a, niezawierające dowodów pozwalających na wszczęcie postępowania 
karnego 
albo 
postępowania 
w 
sprawach 
o 
wykroczenia, 
postępowania 
dyscyplinarnego lub mogących być wykorzystanymi w postępowaniu w ramach 
czynności wyjaśniających albo dowodów mających znaczenie dla toczących się takich 
postępowań, Policja przechowuje przez okres co najmniej 30 dni, nie dłużej jednak niż 
60 dni od dnia zarejestrowania, a następnie je niszczy.

***
## Art. 15a. {#policja-art-15a}

1. Policjant ma prawo zatrzymania, w trybie określonym w art. 15, 
osoby stosującej przemoc domową w rozumieniu przepisów ustawy z dnia 29 lipca 
2005 r. o przeciwdziałaniu przemocy domowej (Dz. U. z 2024 r. poz. 1673), zwanej 
dalej „ustawą o przeciwdziałaniu przemocy domowej”, stwarzającej bezpośrednie 
zagrożenie dla życia lub zdrowia ludzkiego. 

 
 
 
s. 31/274 
 
2025-07-03 
 
2. Policjant w celu stwierdzenia zasadności zatrzymania ocenia ryzyko 
bezpośredniego zagrożenia dla życia lub zdrowia ludzkiego, odrębnie dla osoby 
dorosłej i dziecka, biorąc pod uwagę w szczególności: 
1) 
akty fizycznej przemocy domowej; 
2) 
wiek osoby doznającej przemocy domowej; 
3) 
stosowanie przemocy domowej wobec kobiety w ciąży; 
4) 
niepełnosprawność w rozumieniu art. 2 pkt 10 ustawy z dnia 27 sierpnia 1997 r. 
o 
rehabilitacji 
zawodowej 
i 
społecznej 
oraz 
zatrudnianiu 
osób 
niepełnosprawnych (Dz. U. z 2024 r. poz. 44, 858, 1089, 1165, 1494 i 1961) 
osoby doznającej przemocy domowej; 
5) 
zależność osoby doznającej przemocy domowej od osoby stosującej tę przemoc 
ze względu na stan zdrowia lub jej zaburzenia psychiczne; 
6) 
zaburzenia psychiczne osoby, o której mowa w ust. 1; 
7) 
stan osoby, o której mowa w ust. 1, podczas interwencji związany z użyciem, 
nadużywaniem lub uzależnieniem od alkoholu, środków odurzających lub 
substancji psychotropowych, środków zastępczych lub nowych substancji 
psychoaktywnych; 
8) 
kierowanie przez osobę, o której mowa w ust. 1, gróźb użycia przemocy ze 
skutkiem bezpośredniego zagrożenia życia lub zdrowia; 
9) 
dostęp osoby, o której mowa w ust. 1, do niebezpiecznego narzędzia lub broni; 
10) informacje 
o 
dotychczas 
stosowanej 
przemocy 
lub 
prowadzonych 
postępowaniach wobec osoby, o której mowa w ust. 1, w związku z użyciem 
przemocy; 
11) informacje od osób, o których mowa w art. 9c ust. 1 pkt 1 ustawy o 
przeciwdziałaniu przemocy domowej, dotyczące ich obaw o własne życie lub 
zdrowie, w tym związanych z nasileniem aktów przemocy domowej; 
12) informacje o próbach targnięcia się na własne życie lub życie osób wspólnie 
zamieszkujących przez osobę, o której mowa w ust. 1, w związku ze 
stosowaniem przemocy; 
13) informacje o próbach targnięcia się na własne życie przez osobę doznającą 
przemocy domowej w związku ze stosowaniem tej przemocy. 
3. Oceny ryzyka, o której mowa w ust. 2, dokonuje się w kwestionariuszu 
szacowania ryzyka zagrożenia życia lub zdrowia ludzkiego dołączanym do protokołu 
zatrzymania. 

 
 
 
s. 32/274 
 
2025-07-03 
 
4. Policja niezwłocznie zawiadamia o dokonaniu zatrzymania prokuratora 
i właściwy miejscowo zespół interdyscyplinarny, o którym mowa w ustawie 
o przeciwdziałaniu przemocy domowej, a gdy w mieszkaniu zamieszkują osoby 
małoletnie – także właściwy miejscowo sąd opiekuńczy. 
5. W przypadkach, o których mowa w art. 18 ust. 5 ustawy z dnia 24 sierpnia 
2001 r. o Żandarmerii Wojskowej i wojskowych organach porządkowych (Dz. U. 
z 2025 r. poz. 12 i 179), o dokonaniu zatrzymania żołnierza pełniącego czynną służbę 
wojskową Policja niezwłocznie zawiadamia właściwą miejscowo jednostkę 
organizacyjną Żandarmerii Wojskowej.

***
## Art. 15aa. {#policja-art-15aa}

1. Policjant ma prawo wydać wobec osoby stosującej przemoc 
domową w rozumieniu przepisów ustawy o przeciwdziałaniu przemocy domowej, 
stwarzającej zagrożenie dla życia lub zdrowia osoby doznającej tej przemocy, nakaz 
natychmiastowego 
opuszczenia 
wspólnie 
zajmowanego 
mieszkania 
i jego 
bezpośredniego otoczenia i zakaz zbliżania się do wspólnie zajmowanego mieszkania 
i jego bezpośredniego otoczenia, zwany dalej „nakazem i zakazem”. 
2. (uchylony) 
3. (uchylony)  
4. (uchylony)  
5. Policjant w nakazie i zakazie wskazuje obszar lub odległość od wspólnie 
zajmowanego mieszkania, którą osoba stosująca przemoc domową jest obowiązana 
zachować. 
6. Przepis ust. 1 stosuje się do każdego lokalu służącego zaspokajaniu bieżących 
potrzeb mieszkaniowych. 
7. W przypadku wydania wobec osoby stosującej przemoc domową nakazu i 
zakazu, zakazu zbliżania, zakazu kontaktowania lub zakazu wstępu przepisy art. 9f 
i art. 9g ustawy z dnia 29 lipca 2005 r. o przeciwdziałaniu przemocy domowej stosuje 
się odpowiednio.

***
## Art. 15aaa. {#policja-art-15aaa}

1. Policjant ma prawo wydać wobec osoby stosującej przemoc 
domową w rozumieniu przepisów ustawy o przeciwdziałaniu przemocy domowej, 
stwarzającej zagrożenie dla życia lub zdrowia osoby doznającej tej przemocy, zakaz 
zbliżania się do tej osoby na wyrażoną w metrach odległość, zwany dalej „zakazem 
zbliżania”, lub zakaz kontaktowania się z osobą doznającą przemocy domowej, zwany 
dalej „zakazem kontaktowania”. 

 
 
 
s. 33/274 
 
2025-07-03 
 
2. Jeżeli osoba doznająca przemocy domowej uczęszcza do szkoły, placówki 
oświatowej, opiekuńczej lub artystycznej, uprawia sport lub pracuje, policjant ma 
prawo wydać wobec osoby stosującej przemoc domową, stwarzającej zagrożenie dla 
życia lub zdrowia osoby doznającej tej przemocy, zakaz wstępu na teren szkoły, 
placówki oświatowej, opiekuńczej lub artystycznej, obiektu sportowego lub miejsca 
pracy, i przebywania na tym terenie, zwany dalej „zakazem wstępu”, chyba że osoba 
stosująca przemoc jest tam zatrudniona lub pobiera naukę.

***
## Art. 15aab. {#policja-art-15aab}

1. Nakaz i zakaz, zakaz zbliżania, zakaz kontaktowania lub zakaz 
wstępu mogą być stosowane łącznie. 
2. Nakaz i zakaz, zakaz zbliżania, zakaz kontaktowania oraz zakaz wstępu są 
natychmiast wykonalne. 
3. Jeżeli po wydaniu nakazu i zakazu wystąpią okoliczności uzasadniające 
wydanie zakazu zbliżania, zakazu kontaktowania lub zakazu wstępu, dzień 
zakończenia ich obowiązywania musi odpowiadać dniowi, w którym upływa termin 
stosowania nakazu i zakazu. 
4. Policjant w celu stwierdzenia zasadności wydania nakazu i zakazu, zakazu 
zbliżania, zakazu kontaktowania lub zakazu wstępu stosuje odpowiednio przepisy 
art. 15a ust. 2 i 3.

***
## Art. 15ab. {#policja-art-15ab}

1. Policjant wydaje nakaz i zakaz, zakaz zbliżania, zakaz 
kontaktowania lub zakaz wstępu: 
1) 
podczas interwencji podjętej we wspólnie zajmowanym mieszkaniu lub jego 
bezpośrednim otoczeniu lub 
2) 
w związku z powzięciem informacji o stosowaniu przemocy domowej, w 
szczególności zgłoszenia przez: 
a) 
osobę doznającą przemocy domowej lub 
b) 
kuratora sądowego lub pracownika jednostki organizacyjnej pomocy 
społecznej, w związku z wykonywaniem ustawowych obowiązków. 
2. W przypadku zatrzymania osoby stosującej przemoc domową nakaz i zakaz, 
zakaz zbliżania, zakaz kontaktowania lub zakaz wstępu mogą być wydane 
bezpośrednio po jej zwolnieniu. W przypadku sporządzenia kwestionariusza 
szacowania ryzyka zagrożenia życia lub zdrowia ludzkiego na podstawie art. 15a ust. 
3 kolejnego kwestionariusza nie sporządza się. 

 
 
 
s. 34/274 
 
2025-07-03 
 
3. Policja wykonuje czynności niezwłocznie w związku z powzięciem 
informacji, o której mowa w ust. 1 pkt 2. 
4. Osobę zgłaszającą przemoc domową przesłuchuje się w charakterze świadka, 
po pouczeniu o treści art. 233 Kodeksu karnego, na okoliczności wskazane 
w zgłoszeniu, o ile to możliwe, na miejscu zdarzenia. Policja w celu ustalenia, czy 
zachodzą przesłanki, o których mowa w art. 15aa ust. 1 lub art. 15aaa, oraz w celu 
wskazania obszaru, który osoba stosująca przemoc domową ma opuścić i na którym 
nie może przebywać, odległości od wspólnie zajmowanego mieszkania, którą osoba 
stosująca przemoc domową jest obowiązana zachować, lub ustalenia w metrach 
odległości, którą osoba stosująca przemoc domową jest obowiązana zachować od 
osoby doznającej tej przemocy, może przesłuchać w charakterze świadków również 
inne osoby, w szczególności wszystkie doznające tej przemocy osoby pełnoletnie 
wspólnie zajmujące mieszkanie. Policja, dokonując wskazanych ustaleń, uwzględnia 
w protokole przesłuchania zaistnienie okoliczności zagrożenia życia lub zdrowia 
ludzkiego. 
5. Do przesłuchania stosuje się odpowiednio przepisy Kodeksu postępowania 
cywilnego. 
5a. W przypadku gdy zachodzi obawa, że obecność osoby stosującej przemoc 
domową będzie oddziaływać krępująco na świadka lub wywierać negatywny wpływ 
na jego stan psychiczny, policjant może nakazać tej osobie, aby na czas przesłuchania 
świadka opuściła miejsce przesłuchania. 
6. Osobę małoletnią można przesłuchać tylko wówczas, gdy jej zeznania mogą 
mieć istotne znaczenie dla sprawy, w szczególności gdy jest jedynym świadkiem 
zdarzenia, a brak jest innych dowodów, i wyłącznie w odpowiednio przystosowanych 
pomieszczeniach, o których mowa w przepisach Kodeksu postępowania karnego. 
7. Przesłuchanie osoby małoletniej, o której mowa w ust. 6, przeprowadza sąd 
opiekuńczy miejsca jej pobytu na wniosek Policji. Przesłuchanie odbywa się z 
udziałem prokuratora oraz biegłego psychologa, przy czym osoba pełnoletnia 
wskazana przez małoletniego ma prawo być obecna przy przesłuchaniu, o ile nie 
ogranicza to swobody wypowiedzi przesłuchiwanego małoletniego. W przesłuchaniu 
nie bierze udziału osoba stosująca przemoc domową. Z czynności przesłuchania osoby 
małoletniej sporządza się protokół i nagranie obrazu i dźwięku. 
8. Jeżeli małoletni został już przesłuchany na okoliczność stosowania przemocy 
domowej w innej sprawie, sąd po zapoznaniu się z tymi zeznaniami ocenia, czy 

 
 
 
s. 35/274 
 
2025-07-03 
 
zachodzi potrzeba przesłuchania małoletniego w związku z treścią wniosku Policji. W 
przypadku odstąpienia od przesłuchania sąd przekazuje Policji protokoły 
dotychczasowych przesłuchań małoletniego. 
9. Policjant, przed wydaniem nakazu i zakazu, zakazu zbliżania, zakazu 
kontaktowania lub zakazu wstępu, wysłuchuje osobę stosującą przemoc domową, o ile 
nie utrudni to ich natychmiastowego wydania. Policja może również dokonywać 
innych czynności w celu ustalenia, czy zachodzą okoliczności wskazane w art. 15aa 
ust. 1 lub art. 15aaa. 
10. Nakaz i zakaz, zakaz zbliżania, zakaz kontaktowania lub zakaz wstępu mogą 
być wydane również w przypadku nieobecności we wspólnie zajmowanym 
mieszkaniu lub jego bezpośrednim otoczeniu osoby stosującej przemoc domową 
podczas wykonywania czynności przez Policję. 
11. Policja, przed wydaniem nakazu i zakazu, zakazu zbliżania, zakazu 
kontaktowania lub zakazu wstępu, ma prawo zażądać dodatkowych informacji od 
innych instytucji lub organów w celu ustalenia, czy zachodzą okoliczności wskazane 
w art. 15aa ust. 1 lub art. 15aaa. 
12. Jeżeli zachodzą przesłanki zatrzymania, o którym mowa w art. 15a ust. 1, lub 
wydania nakazu i zakazu, zakazu zbliżania, zakazu kontaktowania lub zakazu wstępu, 
a wobec osoby stosującej przemoc domową wykonywana jest kara pozbawienia 
wolności w systemie dozoru elektronicznego, policjant dokonuje zatrzymania takiej 
osoby i bezzwłocznie przekazuje ją do dyspozycji sądu właściwego do orzekania 
w przedmiocie uchylenia zezwolenia na odbywanie kary w systemie dozoru 
elektronicznego. Sąd orzeka w ciągu 48 godzin od chwili zatrzymania.

***
## Art. 15ac. {#policja-art-15ac}

1. Nakaz i zakaz, zakaz zbliżania, zakaz kontaktowania oraz zakaz 
wstępu zawierają w szczególności: 
1) 
datę, czas i miejsce przeprowadzenia czynności; 
2) 
podstawę prawną ich wydania; 
3) 
treść nakazu i zakazu, zakazu zbliżania, zakazu kontaktowania lub zakazu 
wstępu; 
4) 
dane policjantów przeprowadzających czynność; 
5) 
dane osoby stosującej przemoc domową; 
6) 
dane osoby doznającej przemocy domowej; 
7) 
uzasadnienie, w którym wskazuje się podstawy faktyczne ich wydania; 

 
 
 
s. 36/274 
 
2025-07-03 
 
8) 
pouczenia, w tym o trybie, formie i sposobie wnoszenia zażalenia. 
2. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
wzór nakazu i zakazu, zakazu zbliżania, zakazu kontaktowania oraz zakazu wstępu, 
sposób wykonywania i dokumentowania czynności związanych z wydaniem nakazu 
i zakazu, zakazu zbliżania, zakazu kontaktowania oraz zakazu wstępu i wzór 
kwestionariusza szacowania ryzyka zagrożenia życia lub zdrowia ludzkiego służący 
stwierdzeniu zasadności zatrzymania, o którym mowa w art. 15a ust. 1, lub wydania 
nakazu i zakazu, zakazu zbliżania, zakazu kontaktowania lub zakazu wstępu, mając na 
względzie potrzebę zawarcia niezbędnych pouczeń w nakazie i zakazie, zakazie 
zbliżania, zakazie kontaktowania oraz zakazie wstępu, a także sprawnego 
sporządzania dokumentacji oraz konieczność natychmiastowej i skutecznej ochrony 
osób doznających przemocy domowej.

***
## Art. 15ad. {#policja-art-15ad}

1. Policjant doręcza odpis nakazu i zakazu, zakazu zbliżania, zakazu 
kontaktowania lub zakazu wstępu niezwłocznie po ich wydaniu osobie stosującej 
przemoc domową oraz osobie doznającej tej przemocy. 
1a. W razie niemożności doręczenia osobie stosującej przemoc domową, 
zamieszkującej wspólnie z osobą doznającą tej przemocy, odpisu nakazu i zakazu, 
zakazu zbliżania, zakazu kontaktowania lub zakazu wstępu, w sposób określony 
w ust. 1, odpis należy złożyć we właściwej jednostce organizacyjnej Policji, 
umieszczając zawiadomienie o ich wydaniu na drzwiach wspólnie zajmowanego 
mieszkania, 
ze 
wskazaniem 
przyczyny 
umieszczenia 
zawiadomienia 
oraz 
wskazaniem, gdzie i kiedy pismo pozostawiono. Doręczenie uważa się za dokonane 
z chwilą umieszczenia zawiadomienia na drzwiach wspólnie zajmowanego 
mieszkania. 
1b. W przypadku wydania zakazu zbliżania, zakazu kontaktowania lub zakazu 
wstępu, gdy osoba stosująca przemoc domową nie zamieszkuje wspólnie z osobą 
doznającą tej przemocy, zawiadomienie o ich wydaniu umieszcza się niezwłocznie na 
drzwiach mieszkania osoby doznającej przemocy domowej. Policja w terminie 
24 godzin od chwili wydania zakazów, o których mowa w zdaniu pierwszym, doręcza 
osobie stosującej przemoc domową ich odpisy w miejscu jej zamieszkania lub innym 
miejscu, w którym osoba ta przebywa lub ją zastano. Doręczenie uważa się za 
dokonane z chwilą doręczenia osobie stosującej przemoc domową odpisu zakazu 

 
 
 
s. 37/274 
 
2025-07-03 
 
zbliżania, zakazu kontaktowania lub zakazu wstępu. Przepis art. 138 Kodeksu 
postępowania cywilnego stosuje się odpowiednio. 
1c. W razie ustalenia miejsca zamieszkania lub pobytu osoby stosującej przemoc 
domową niezamieszkującej wspólnie z osobą doznającą tej przemocy i niemożności 
doręczenia jej odpisu zakazu zbliżania, zakazu kontaktowania lub zakazu wstępu, 
przepis ust. 1a stosuje się odpowiednio, z zastrzeżeniem że zawiadomienie o ich 
wydaniu umieszcza się na drzwiach mieszkania osoby stosującej przemoc domową. 
Doręczenie uważa się za dokonane z chwilą umieszczenia zawiadomienia na drzwiach 
mieszkania osoby stosującej przemoc domową. 
1d. W razie niemożności doręczenia osobie stosującej przemoc domową 
niezamieszkującej wspólnie z osobą doznającą tej przemocy odpisu zakazu zbliżania, 
zakazu kontaktowania lub zakazu wstępu, w sposób określony w ust. 1b i 1c, 
doręczenie uważa się za dokonane z chwilą umieszczenia zawiadomienia o ich 
wydaniu na drzwiach mieszkania osoby doznającej przemocy domowej. 
1e. W nakazie i zakazie, zakazie zbliżania, zakazie kontaktowania i zakazie 
wstępu dokonuje się wzmianki o niemożności doręczenia ich odpisów, wskazując jej 
przyczynę oraz datę i godzinę pozostawienia zawiadomienia, o którym mowa 
w ust. 1a–1c. 
2. Jeżeli osoba stosująca przemoc domową odmawia przyjęcia nakazu i zakazu, 
zakazu zbliżania, zakazu kontaktowania lub zakazu wstępu, doręczenie uważa się za 
dokonane. W takim przypadku policjant dokonuje adnotacji o odmowie ich przyjęcia 
na oryginale nakazu i zakazu, zakazu zbliżania, zakazu kontaktowania lub zakazu 
wstępu. 
3. Zawiadomienie, o którym mowa w ust. 1a–1c, zawiera imię i nazwisko osoby 
stosującej przemoc domową oraz wezwanie do niezwłocznego kontaktu z właściwą 
jednostką organizacyjną Policji, a ponadto dostępne po otwarciu zawiadomienia 
informacje o wydaniu nakazu i zakazu, zakazu zbliżania, zakazu kontaktowania lub 
zakazu wstępu, podstawie prawnej, miejscu i terminie ich odebrania, a także zasadach 
zabrania ze wspólnie zajmowanego mieszkania i z jego bezpośredniego otoczenia 
przedmiotów osobistego użytku i przedmiotów niezbędnych do wykonywania 
osobistej pracy zarobkowej lub zwierząt domowych będących własnością osoby 
stosującej przemoc domową niezbędnych do codziennego funkcjonowania lub pracy 
zarobkowej. 

 
 
 
s. 38/274 
 
2025-07-03 
 
4. Policja niezwłocznie doręcza prokuratorowi odpis nakazu i zakazu, zakazu 
zbliżania, zakazu kontaktowania lub zakazu wstępu oraz zawiadamia właściwy 
miejscowo zespół interdyscyplinarny, o którym mowa w ustawie o przeciwdziałaniu 
przemocy domowej, a gdy w mieszkaniu zamieszkują osoby małoletnie lub osobą 
doznającą przemocy domowej jest osoba małoletnia – także właściwy miejscowo sąd 
opiekuńczy. W przypadku wydania zakazu wstępu Policja niezwłocznie zawiadamia 
o tym fakcie dyrektora szkoły, placówki oświatowej, opiekuńczej lub artystycznej, do 
której uczęszcza osoba doznająca przemocy domowej, osobę zarządzającą obiektem 
sportowym, do którego uczęszcza osoba doznająca przemocy domowej, lub 
pracodawcę osoby doznającej przemocy domowej. 
4a. W przypadkach, o których mowa w art. 18ab ust. 1 ustawy z dnia 24 sierpnia 
2001 r. o Żandarmerii Wojskowej i wojskowych organach porządkowych, o wydaniu 
wobec żołnierza pełniącego czynną służbę wojskową nakazu i zakazu, zakazu 
zbliżania, zakazu kontaktowania lub zakazu wstępu, Policja niezwłocznie zawiadamia 
właściwą jednostkę organizacyjną Żandarmerii Wojskowej. 
5. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
wzór zawiadomienia, o którym mowa w ust. 1a–1c, umieszczanego na drzwiach 
mieszkania w razie niemożności doręczenia odpisu nakazu i zakazu, zakazu zbliżania, 
zakazu kontaktowania lub zakazu wstępu, mając na uwadze konieczność zrozumienia 
zawiadomienia również przez osoby niekorzystające z profesjonalnej pomocy 
prawnej.

***
## Art. 15ae. {#policja-art-15ae}

1. Czynność opuszczenia wspólnie zajmowanego mieszkania i jego 
bezpośredniego otoczenia przez osobę stosującą przemoc domową, wobec której 
wydano nakaz i zakaz, wymaga sporządzenia protokołu, który podpisują pełnoletnie 
osoby uczestniczące w czynności. 
2. Protokół zawiera: 
1) 
datę, czas, miejsce oraz podstawę prawną przeprowadzenia czynności; 
2) 
dane 
policjantów 
przeprowadzających 
czynność 
oraz 
osób 
w 
niej 
uczestniczących; 
3) 
oznaczenie czynności oraz jej przebieg; 
4) 
wzmiankę o wydaniu nakazu i zakazu; 
5) 
oświadczenia osób uczestniczących w czynności oraz policjantów; 

 
 
 
s. 39/274 
 
2025-07-03 
 
6) 
wzmiankę o udzieleniu pouczeń oraz udzielonych informacjach, o których mowa 
w art. 15ag i art. 15ah; 
7) 
w miarę potrzeby stwierdzenie innych okoliczności dotyczących przebiegu 
czynności, w szczególności wskazanie zabranych ze wspólnie zajmowanego 
mieszkania i z jego bezpośredniego otoczenia przedmiotów osobistego użytku 
i przedmiotów niezbędnych do wykonywania osobistej pracy zarobkowej lub 
zwierząt domowych będących własnością osoby stosującej przemoc domową 
niezbędnych do codziennego funkcjonowania lub pracy zarobkowej oraz opis 
pozostawionego mienia, które według twierdzeń osoby stosującej przemoc 
domową, wobec której wydano nakaz i zakaz, stanowi jej własność. 
3. Jeżeli osoba uczestnicząca w czynności odmawia podpisu lub nie może go 
złożyć, policjant dokonujący czynności zaznacza przyczynę braku podpisu. 
4. Osoba stosująca przemoc domową, wobec której wydano nakaz i zakaz, ma 
prawo zabrać ze wspólnie zajmowanego mieszkania i z jego bezpośredniego otoczenia 
przedmioty osobistego użytku i przedmioty niezbędne do wykonywania osobistej 
pracy zarobkowej lub zwierzęta domowe będące jej własnością niezbędne do 
codziennego funkcjonowania lub pracy zarobkowej. W przypadku sprzeciwu osoby 
doznającej przemocy domowej te przedmioty lub zwierzęta domowe pozostawia się 
we wspólnie zajmowanym mieszkaniu lub w jego bezpośrednim otoczeniu. 
Dochodzenie roszczeń z tego tytułu odbywa się na zasadach określonych w Kodeksie 
cywilnym. 
5. Jeżeli w okresie obowiązywania nakazu i zakazu zajdzie potrzeba zabrania 
przez osobę stosującą przemoc domową ze wspólnie zajmowanego mieszkania i z jego 
bezpośredniego otoczenia mienia stanowiącego jej własność, w szczególności 
niezabranych uprzednio przedmiotów osobistego użytku i przedmiotów niezbędnych 
do wykonywania osobistej pracy zarobkowej lub zwierząt domowych będących jej 
własnością niezbędnych do codziennego funkcjonowania lub pracy zarobkowej, może 
się to odbyć jeden raz, wyłącznie w obecności policjanta, po wcześniejszym 
uzgodnieniu terminu z osobą doznającą przemocy domowej. Osoba doznająca 
przemocy domowej ma prawo brać udział w tej czynności lub upoważnić do udziału 
w niej inną osobę. 
6. Osoba stosująca przemoc domową, wobec której wydano nakaz i zakaz, ma 
obowiązek pozostawić klucze do wspólnie zajmowanego mieszkania i pomieszczeń 
jego bezpośredniego otoczenia w tym mieszkaniu. 

 
 
 
s. 40/274 
 
2025-07-03 
 
7. Jeżeli w związku z wydaniem nakazu i zakazu zachodzi potrzeba 
zabezpieczenia zwierząt stanowiących mienie osoby stosującej przemoc domową, 
wobec której wydano nakaz i zakaz, stosuje się odpowiednio przepis art. 7 ustawy 
z dnia 21 sierpnia 1997 r. o ochronie zwierząt (Dz. U. z 2023 r. poz. 1580). 
8. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
wzór protokołu czynności opuszczenia wspólnie zajmowanego mieszkania i jego 
bezpośredniego otoczenia, w związku z wydaniem nakazu i zakazu, mając na uwadze 
prawidłowe udokumentowanie przeprowadzanej czynności.

***
## Art. 15af. {#policja-art-15af}

1. Osoba stosująca przemoc domową, wobec której wydano nakaz i 
zakaz, zakaz zbliżania, zakaz kontaktowania lub zakaz wstępu, jest obowiązana 
wskazać jednostce organizacyjnej Policji, której policjant wydał ten nakaz i zakaz, 
zakaz zbliżania, zakaz kontaktowania lub zakaz wstępu, adres miejsca pobytu, a także, 
o ile to możliwe, numer telefonu, pod którym będzie dostępna, oraz poinformować tę 
jednostkę Policji o każdej zmianie adresu lub numeru. 
2. Osobę stosującą przemoc domową, wobec której wydano nakaz i zakaz, zakaz 
zbliżania, zakaz kontaktowania lub zakaz wstępu, należy pouczyć, że jeżeli zmieni 
miejsce pobytu, nie będzie dostępna pod wskazanym przez siebie numerem telefonu, 
nie zawiadamiając o tym jednostki organizacyjnej Policji, o której mowa w ust. 1, na 
skutek czego nie odbierze korespondencji pod wskazanym adresem lub nie stawi się 
we wskazanej jednostce organizacyjnej Policji w celu jej odbioru w ciągu 24 godzin 
od pozostawienia zawiadomienia o korespondencji, korespondencja zostanie uznana 
za doręczoną z upływem tego terminu, chyba że miejsce pobytu tej osoby jest Policji 
znane. 
3. Niedoręczenie korespondencji wymaga udokumentowania ze wskazaniem 
przyczyny niedoręczenia. 
4. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
wzór zawiadomienia osoby stosującej przemoc domową, wobec której został wydany 
nakaz i zakaz, zakaz zbliżania, zakaz kontaktowania lub zakaz wstępu, 
pozostawianego w razie niemożności doręczenia jej korespondencji, mając na uwadze 
konieczność zrozumienia zawiadomienia również przez osoby niekorzystające 
z profesjonalnej pomocy prawnej. 

 
 
 
s. 41/274 
 
2025-07-03

***
## Art. 15ag. {#policja-art-15ag}

1. Policjant, w przypadku wydania nakazu i zakazu, zakazu zbliżania, 
zakazu kontaktowania lub zakazu wstępu, informuje osobę doznającą przemocy 
domowej o: 
1) 
możliwości i sposobie złożenia żądania, aby sąd zobowiązał osobę stosującą 
przemoc domową do opuszczenia wspólnie zajmowanego mieszkania i jego 
bezpośredniego otoczenia, wydał zakaz zbliżania się do wspólnie zajmowanego 
mieszkania i jego bezpośredniego otoczenia, zakaz zbliżania się do osoby 
doznającej przemocy domowej, zakaz kontaktowania się z osobą doznającą 
przemocy domowej lub zakaz wstępu na teren szkoły, placówki oświatowej, 
opiekuńczej lub artystycznej, lub obiektu sportowego, do których uczęszcza 
osoba doznająca przemocy domowej, miejsca pracy lub innego miejsca, 
w którym zwykle lub regularnie przebywa osoba doznająca przemocy domowej, 
i przebywania na tym terenie, o których mowa w przepisach ustawy 
o przeciwdziałaniu przemocy domowej; 
2) 
obowiązku wszczęcia przez organy ścigania, niezależnie od wydanego nakazu i 
zakazu, zakazu zbliżania, zakazu kontaktowania lub zakazu wstępu, 
postępowania karnego w związku z popełnieniem ściganego z urzędu 
przestępstwa z użyciem przemocy i możliwości stosowania w toku pro-
wadzonego postępowania środków zapobiegawczych, o których mowa w 
przepisach Kodeksu postępowania karnego; 
3) 
możliwości uzyskania wsparcia we właściwym miejscowo ośrodku pomocy 
społecznej, specjalistycznym ośrodku wsparcia dla osób doznających przemocy 
domowej i innych placówkach świadczących pomoc osobom doznającym 
przemocy domowej; 
4) 
całodobowym ogólnopolskim telefonie dla osób doznających przemocy 
domowej; 
5) 
możliwości uzyskania pomocy udzielanej przez podmioty, które otrzymały 
dotacje z Funduszu Pomocy Pokrzywdzonym oraz Pomocy Postpenitencjarnej, 
o którym mowa w przepisach Kodeksu karnego wykonawczego, oraz danych 
teleadresowych, najbliższych miejscowo dla osoby doznającej przemocy 
domowej, siedzib tych podmiotów i innych niezbędnych danych kontaktowych 
tych podmiotów. 
2. Policjant, w przypadku wydania nakazu i zakazu, zakazu zbliżania, zakazu 
kontaktowania lub zakazu wstępu, informuje osobę doznającą przemocy domowej 

 
 
 
s. 42/274 
 
2025-07-03 
 
o możliwości przekazania jej danych osobowych najbliższemu miejscowo 
podmiotowi, o którym mowa w ust. 1 pkt 5, w celu udzielenia pomocy, chyba że 
osoba ta nie wyrazi na to zgody. 
3. Policjant, w przypadku wydania nakazu i zakazu, zakazu zbliżania, zakazu 
kontaktowania lub zakazu wstępu, poucza osobę stosującą przemoc domową o 
przekazaniu jej danych właściwemu ze względu na miejsce jej pobytu Powiatowemu 
Centrum Pomocy Rodzinie w celu podjęcia działań pozostających we właściwości 
powiatu na podstawie przepisów ustawy o przeciwdziałaniu przemocy domowej, 
chyba że osoba ta nie wyrazi zgody.

***
## Art. 15ah. {#policja-art-15ah}

Policjant, w przypadku wydania nakazu i zakazu, zakazu zbliżania, 
zakazu kontaktowania lub zakazu wstępu, poucza osobę stosującą przemoc domową 
o przyczynach ich wydania, o możliwości i sposobie złożenia zażalenia, a także, 
w przypadku wydania nakazu i zakazu – informuje o danych teleadresowych 
właściwych miejscowo placówek zapewniających miejsca noclegowe oraz placówek 
prowadzących programy korekcyjno-edukacyjne dla osób stosujących przemoc 
domową lub programy psychologiczno-terapeutyczne dla osób stosujących przemoc 
domową.

***
## Art. 15ai. {#policja-art-15ai}

1. W okresie obowiązywania nakazu i zakazu, zakazu zbliżania, 
zakazu kontaktowania lub zakazu wstępu Policja przynajmniej trzykrotnie sprawdza, 
czy nakaz i zakaz, zakaz zbliżania, zakaz kontaktowania lub zakaz wstępu nie są 
naruszane, i podejmuje niezbędne czynności. Pierwsze sprawdzenie odbywa się 
następnego dnia po wydaniu nakazu i zakazu, zakazu zbliżania, zakazu kontaktowania 
lub zakazu wstępu. 
2. Czynności 
sprawdzenia 
Policja 
podejmuje 
również 
na 
podstawie 
postanowienia 
sądu 
o udzieleniu 
zabezpieczenia 
w sprawach 
z zakresu 
przeciwdziałania przemocy domowej, w tym postanowienia, którym nakaz i zakaz, 
zakaz zbliżania, zakaz kontaktowania lub zakaz wstępu zostały przedłużone.

***
## Art. 15aj. {#policja-art-15aj}

1. Osobie, wobec której wydano nakaz i zakaz, zakaz zbliżania, zakaz 
kontaktowania lub zakaz wstępu, oraz prokuratorowi przysługuje zażalenie do sądu 
rejonowego, do którego należy rozpoznawanie spraw z zakresu przeciwdziałania 
przemocy domowej. Zażalenie wnosi się w terminie 3 dni od dnia doręczenia nakazu 
i zakazu, zakazu zbliżania, zakazu kontaktowania lub zakazu wstępu, o czym należy 
osobę stosującą przemoc domową pouczyć przy doręczeniu. W zażaleniu można 

 
 
 
s. 43/274 
 
2025-07-03 
 
domagać się zbadania prawidłowości prowadzenia czynności, zasadności oraz 
legalności wydanego nakazu i zakazu, zakazu zbliżania, zakazu kontaktowania lub 
zakazu wstępu. W zakresie nieuregulowanym do zażalenia stosuje się odpowiednio 
przepisy Kodeksu postępowania cywilnego o postępowaniu nieprocesowym, z tym że 
nie stosuje się przepisu art. 3731 tego Kodeksu. 
1a. Zażalenie wnosi się do sądu rejonowego właściwego ze względu na miejsce 
położenia wspólnie zajmowanego mieszkania. W przypadku gdy osoba stosująca 
przemoc domową, wobec której wydano zakaz zbliżania, zakaz kontaktowania lub 
zakaz wstępu, nie mieszka wspólnie z osobą doznającą tej przemocy, zażalenie wnosi 
się do sądu rejonowego właściwego ze względu na miejsce zamieszkania osoby 
doznającej przemocy domowej. 
2. Sąd rozpoznaje zażalenie w składzie jednego sędziego niezwłocznie, nie 
później jednak niż w terminie 3 dni od dnia jego wpływu do sądu. Uczestnikami 
postępowania są organ, który wydał nakaz i zakaz, zakaz zbliżania, zakaz 
kontaktowania lub zakaz wstępu, osoba, wobec której zostały one wydane, oraz 
prokurator, jeżeli złożył zażalenie. 
3. Sąd uchyla zaskarżony nakaz i zakaz, zakaz zbliżania, zakaz kontaktowania 
lub zakaz wstępu w przypadku stwierdzenia jego bezzasadności lub nielegalności, 
o czym niezwłocznie zawiadamia osobę, wobec której zostały one wydane, osobę 
doznającą przemocy domowej, prokuratora, właściwą jednostkę organizacyjną Policji 
oraz zespół interdyscyplinarny, o którym mowa w ustawie o przeciwdziałaniu 
przemocy domowej, a gdy czynności podejmował sąd opiekuńczy – także ten sąd. 
3a. Jeżeli jest to niezbędne dla zapewnienia szybkości postępowania, sąd może 
dokonywać doręczeń przez Policję. Do doręczeń stosuje się odpowiednio przepis 
art. 5606 Kodeksu postępowania cywilnego. 
4. W przypadku stwierdzenia bezzasadności, nielegalności lub nieprawidłowości 
nakazu i zakazu, zakazu zbliżania, zakazu kontaktowania lub zakazu wstępu sąd 
zawiadamia o tym przełożonego policjanta, który wydał nakaz i zakaz, zakaz 
zbliżania, zakaz kontaktowania lub zakaz wstępu.

***
## Art. 15ak. {#policja-art-15ak}

1. Nakaz i zakaz, zakaz zbliżania, zakaz kontaktowania i zakaz 
wstępu tracą moc po upływie 14 dni od dnia ich wydania, chyba że sąd udzielił 
zabezpieczenia, którym zostały one przedłużone. Przy obliczaniu terminu nie 

 
 
 
s. 44/274 
 
2025-07-03 
 
uwzględnia się dnia, w którym nakaz i zakaz, zakaz zbliżania, zakaz kontaktowania 
lub zakaz wstępu zostały wydane. 
2. Nakaz i zakaz, zakaz zbliżania, zakaz kontaktowania i zakaz wstępu tracą 
także moc, w przypadku gdy po ich wydaniu wobec osoby stosującej przemoc 
domową zastosowano środek zapobiegawczy w postaci tymczasowego aresztowania. 
3. W przypadku, o którym mowa w ust. 2, prokurator niezwłocznie zawiadamia 
osobę doznającą przemocy domowej oraz właściwą jednostkę organizacyjną Policji.

***
## Art. 15b. {#policja-art-15b}

Informacje uzyskane podczas realizacji czynności, o których mowa w 
art. 15 ust. 1 pkt 5a i 5b, w tym dane osobowe niezawierające dowodów pozwalających 
na wszczęcie postępowania karnego albo postępowania w sprawach o wykroczenia, 
postępowania dyscyplinarnego lub mogących być wykorzystanymi w postępowaniu w 
ramach czynności wyjaśniających albo dowodów mających znaczenie dla toczących 
się takich postępowań, Policja przechowuje przez okres co najmniej 30 dni, nie dłużej 
jednak niż 60 dni od dnia zarejestrowania, a następnie je niszczy. W przypadku 
czynności operacyjno-rozpoznawczych terminy, o których mowa w zdaniu 
pierwszym, są liczone od dnia zakończenia realizacji tych czynności.

***
## Art. 15c. {#policja-art-15c}

W przypadkach, o których mowa w art. 15 ust. 1 pkt 5b, z wyłączeniem 
działań kontrterrorystycznych oraz wspierania działań jednostek organizacyjnych 
Policji przez służbę kontrterrorystyczną w warunkach szczególnego zagrożenia lub 
wymagających użycia specjalistycznych sił i środków oraz specjalistycznej taktyki 
działań, funkcjonariusz Policji w miarę możliwości uprzedza osobę, wobec której 
podejmuje czynności, o rejestrowaniu obrazu lub dźwięku.

***
## Art. 15d. {#policja-art-15d}

1. Kontrola osobista polega na sprawdzeniu: 
1) 
zawartości odzieży i obuwia osoby poddawanej kontroli osobistej, zwanej dalej 
„osobą kontrolowaną” i przedmiotów, które znajdują się na jej ciele, bez 
odsłaniania przykrytej odzieżą powierzchni ciała; 
2) 
zawartości podręcznego bagażu oraz innych przedmiotów, które posiada przy 
sobie osoba kontrolowana; 
3) 
zawartości odzieży i obuwia osoby kontrolowanej i przedmiotów, które znajdują 
się na jej ciele, z odsłonięciem przykrytych odzieżą powierzchni ciała w celu oraz 
w zakresie niezbędnym do odebrania broni lub przedmiotów, o których mowa w 
art. 15 ust. 1 pkt 5, w przypadku gdy ujawniono ich posiadanie przez osobę 
kontrolowaną podczas sprawdzenia, o którym mowa w pkt 1 lub 2 i gdy do ich 

 
 
 
s. 45/274 
 
2025-07-03 
 
odebrania nie jest wystarczające zastosowanie czynności określonych w pkt 1 i 
2; 
4) 
jamy ustnej, nosa, uszu oraz włosów osoby kontrolowanej; 
5) 
miejsc intymnych osoby kontrolowanej, w szczególnie uzasadnionych 
przypadkach. 
2. Policjant dokonuje kontroli osobistej w sposób możliwie najmniej naruszający 
dobra osobiste osoby kontrolowanej oraz w zakresie niezbędnym w danych 
okolicznościach do zrealizowania celu dokonywanej kontroli. Podczas sprawdzenia, o 
którym mowa w ust. 1 pkt 3 i 5, osoba kontrolowana powinna być częściowo ubrana. 
Policjant najpierw sprawdza część odzieży, a przed sprawdzeniem kolejnej części 
umożliwia osobie kontrolowanej włożenie odzieży już sprawdzonej. 
3. Sprawdzenia, o którym mowa w ust. 1 pkt 1–3, można dokonać wzrokowo, 
manualnie lub z wykorzystaniem psa służbowego lub środków technicznych 
niezbędnych do wykrywania materiałów i urządzeń, których posiadanie jest 
zabronione, w szczególności broni, materiałów wybuchowych, środków odurzających, 
substancji psychotropowych i ich prekursorów, a sprawdzenia, o którym mowa w ust. 
1 pkt 4 i 5 – wzrokowo lub manualnie. 
4. Policjant dokonujący kontroli osobistej: 
1) 
przystępując do czynności związanych z kontrolą osobistą podaje swój stopień, 
imię i nazwisko w sposób umożliwiający odnotowanie tych danych, a policjant 
nieumundurowany, na żądanie osoby kontrolowanej, okazuje również 
legitymację służbową w taki sposób, aby osoba kontrolowana miała możliwość 
odczytać i zanotować numer i organ, który wydał legitymację oraz nazwisko 
policjanta; 
2) 
podaje podstawę prawną i przyczynę podjęcia kontroli osobistej; 
3) 
legitymuje osobę kontrolowaną oraz inne osoby, jeżeli uczestniczą w czynności; 
4) 
może wezwać osobę kontrolowaną do dobrowolnego wydania przez nią broni lub 
innych niebezpiecznych przedmiotów mogących służyć do popełnienia czynu 
zabronionego pod groźbą kary lub przedmiotów mogących stanowić dowód w 
postępowaniu prowadzonym w związku z realizacją zadań, o których mowa w 
art. 15 ust. 1 pkt 5, lub podlegających przepadkowi oraz może żądać opróżnienia 
przez osobę kontrolowaną kieszeni, innych części odzieży lub przedmiotów 
znajdujących się na ciele osoby kontrolowanej lub przez nią posiadanych, jak 

 
 
 
s. 46/274 
 
2025-07-03 
 
również może żądać przyjęcia przez osobę kontrolowaną odpowiedniej pozycji 
ciała w sposób umożliwiający sprawdzenie miejsc intymnych; 
5) 
odbiera osobie kontrolowanej broń lub inne niebezpieczne przedmioty mogące 
służyć do popełnienia czynu zabronionego pod groźbą kary albo przedmioty, 
których posiadanie jest zabronione lub przedmioty mogące stanowić dowód 
w postępowaniu prowadzonym w związku z realizacją zadań, o których mowa w 
art. 15 ust. 1 pkt 5, lub podlegające przepadkowi; 
6) 
sprawdza, czy informacje o osobie kontrolowanej, przedmiotach lub 
dokumentach posiadanych przez tę osobę są przetwarzane w zbiorach danych 
prowadzonych przez Policję lub w dostępnych Policji krajowych i 
międzynarodowych systemach informacyjnych, w których przetwarza się 
informacje, w tym dane osobowe, o osobach podejrzanych o popełnienie 
przestępstw, osobach zaginionych lub osobach poszukiwanych w związku z 
ochroną bezpieczeństwa i porządku publicznego lub w których przetwarza się 
informacje o skradzionych lub utraconych dokumentach lub przedmiotach, w 
celu ich odnalezienia; 
7) 
pobiera niezbędne dane osobowe osoby kontrolowanej lub innych osób, jeżeli 
uczestniczą w czynności, oraz dane dotyczące posiadanych przez osobę 
kontrolowaną dokumentów i podlegających sprawdzeniu przedmiotów, w tym 
dane związane z tymi przedmiotami lub utrwalone na tych dokumentach; 
8) 
może odstąpić od wykonywania czynności, o których mowa w pkt 1 i 3, w 
przypadku gdy czynności te zostały wykonane przez policjanta bezpośrednio 
przed przystąpieniem do dokonania kontroli osobistej w ramach realizacji innych 
uprawnień określonych w art. 15, w szczególności w związku z legitymowaniem 
osoby. 
5. Kontroli osobistej dokonuje policjant tej samej płci, co osoba kontrolowana w 
miejscu niedostępnym w czasie wykonywania kontroli dla osób postronnych. 
6. W przypadku gdy kontrola osobista musi być dokonana niezwłocznie, w 
szczególności ze względu na okoliczności mogące stanowić zagrożenie życia lub 
zdrowia ludzkiego lub mienia, może jej dokonać policjant płci odmiennej niż osoba 
kontrolowana, także w miejscu niespełniającym warunku, o którym mowa w ust. 5, w 
sposób możliwie najmniej naruszający dobra osobiste osoby kontrolowanej. 
7. Podczas kontroli osobistej może być obecna osoba przybrana przez 
dokonującego czynności, a w przypadku gdy nie uniemożliwi to przeprowadzenia 

 
 
 
s. 47/274 
 
2025-07-03 
 
kontroli osobistej albo nie utrudni jej przeprowadzenia w istotny sposób, podczas 
kontroli osobistej może być obecna także osoba wskazana przez osobę kontrolowaną. 
8. Osoba kontrolowana jest obowiązana umożliwić policjantom dokonanie 
czynności, o których mowa w ust. 1. 
9. Po zakończeniu kontroli osobistej policjant poucza osobę kontrolowaną o 
prawie do złożenia zażalenia, o którym mowa w ust. 11, oraz o prawie do żądania 
sporządzenia protokołu z kontroli osobistej. 
10. Z kontroli osobistej sporządza się protokół w przypadku, gdy osoba 
kontrolowana zgłosiła takie żądanie bezpośrednio po jej dokonaniu oraz w przypadku, 
gdy w toku kontroli znaleziono broń lub przedmioty, o których mowa w art. 15 ust. 1 
pkt 5. Protokół zawiera w szczególności: 
1) 
oznaczenie czynności, podstawy prawnej i przyczyny jej podjęcia, jej miejsca 
oraz danych osoby kontrolowanej i osób uczestniczących w kontroli osobistej, 
obejmujących w szczególności imię, nazwisko, numer PESEL lub datę urodzenia 
oraz rodzaj i cechy identyfikacyjne dokumentu, na podstawie którego ustalono 
tożsamość osoby; 
2) 
datę i godzinę rozpoczęcia i zakończenia czynności; 
3) 
dane policjanta dokonującego czynności obejmujące stopień, imię, nazwisko 
oraz nazwę jednostki organizacyjnej Policji, w której pełni służbę; 
4) 
nazwę jednostki organizacyjnej Policji, właściwej ze względu na miejsce 
dokonania kontroli osobistej; 
5) 
przebieg czynności, oświadczenia i wnioski jej uczestników; 
6) 
spis znalezionych i odebranych przedmiotów oraz w miarę potrzeby ich opis; 
7) 
pouczenie osoby kontrolowanej o jej prawach; 
8) 
w miarę potrzeby stwierdzenie innych okoliczności dotyczących przebiegu 
czynności. 
11. Osobie kontrolowanej przysługuje zażalenie do sądu rejonowego właściwego 
ze względu na miejsce dokonania kontroli osobistej, w terminie 7 dni od dnia jej 
dokonania, w celu zbadania zasadności, legalności oraz prawidłowości jej dokonania. 
Do zażalenia stosuje się odpowiednio przepisy rozdziału 50 Kodeksu postępowania 
karnego. 
12. 
W 
przypadku 
stwierdzenia 
bezzasadności, 
nielegalności 
lub 
nieprawidłowości dokonania kontroli osobistej, sąd zawiadamia o tym prokuratora i 

 
 
 
s. 48/274 
 
2025-07-03 
 
kierownika jednostki organizacyjnej Policji nadrzędnej nad jednostką organizacyjną 
Policji, w której pełni służbę policjant, który dokonał kontroli osobistej. 
13. W przypadku gdy w toku kontroli osobistej nie znaleziono broni lub 
przedmiotów, o których mowa w art. 15 ust. 1 pkt 5, lub w przypadku gdy osoba 
kontrolowana nie zgłosiła żądania sporządzenia protokołu z kontroli, kontrolę osobistą 
dokumentuje się w dokumentacji służbowej, określając datę, czas, miejsce i przyczynę 
jej dokonania, dane osób w niej uczestniczących oraz rodzaj i wynik czynności, a także 
informację o pouczeniu osoby kontrolowanej, o którym mowa w ust. 9. 
14. W przypadku gdy przedmioty ujawnione w wyniku czynności, o których 
mowa w ust. 1, stwarzają niebezpieczeństwo dla życia, zdrowia lub mienia, policjant, 
w granicach dostępnych środków, niezwłocznie podejmuje czynności ochronne, a w 
szczególności zabezpiecza miejsce zagrożone przed dostępem osób postronnych oraz 
powiadamia dyżurnego właściwej miejscowo jednostki organizacyjnej Policji o 
konieczności zarządzenia działań usuwających to niebezpieczeństwo. 
15. Zażalenie, o którym mowa w ust. 11, składa się za pośrednictwem jednostki 
organizacyjnej Policji właściwej według miejsca dokonania kontroli osobistej. 
Jednostka organizacyjna Policji, o której mowa w zdaniu pierwszym, niezwłocznie 
przekazuje zażalenie do sądu rejonowego.

***
## Art. 15e. {#policja-art-15e}

1. Przeglądanie zawartości bagaży lub sprawdzanie ładunków w 
portach i na dworcach oraz w środkach transportu lądowego, powietrznego i wodnego 
polega na: 
1) 
wzrokowej i manualnej kontroli zawartości bagaży lub ładunków, w tym 
manualnym sprawdzeniu ładunków, elementów konstrukcyjnych bagaży oraz 
znajdujących się w nich przedmiotów; 
2) 
sprawdzeniu bagaży i ładunków z wykorzystaniem psa służbowego lub z 
wykorzystaniem środków technicznych niezbędnych do wykrywania materiałów 
i urządzeń zabronionych, w szczególności broni, materiałów wybuchowych, 
środków odurzających, substancji psychotropowych i ich prekursorów. 
2. Czynności, o których mowa w ust. 1, wykonuje się w obecności posiadacza 
bagaży lub ładunków, a w przypadku gdy nie można ustalić posiadacza bagaży lub 
ładunków lub w przypadku jego nieobecności – w obecności przedstawiciela 
przewoźnika, spedytora lub agenta morskiego. 

 
 
 
s. 49/274 
 
2025-07-03 
 
3. W przypadku bagaży lub ładunków przyjętych do przewozu, czynności, o 
których mowa w ust. 1, wykonuje się wyłącznie w obecności przedstawiciela 
przewoźnika, spedytora lub agenta morskiego. 
4. W przypadku braku możliwości zapewnienia natychmiastowej obecności 
osób, o których mowa w ust. 2, policjant może wykonać czynności określone w ust. 1 
bez ich obecności, jeżeli z posiadanych informacji wynika, że zwłoka może 
spowodować zagrożenie życia lub zdrowia ludzkiego lub mienia, albo gdy istnieje 
uzasadniona obawa zniszczenia bądź utracenia przedmiotów mogących stanowić 
dowód w postępowaniu prowadzonym w związku z realizacją zadań, o których mowa 
w art. 15 ust. 1 pkt 5, lub podlegających przepadkowi. 
5. Policjant w związku z realizacją czynności, o których mowa w ust. 1, ma prawo 
żądania udostępnienia bagaży lub przewożonych ładunków, w tym otwarcia bagażnika 
oraz udostępnienia przestrzeni bagażowej w środkach komunikacji do przejrzenia, 
wyjęcia przewożonych bagaży lub ładunków oraz otwarcia i pokazania ich zawartości. 
6. Osoby, o których mowa w ust. 2, są obowiązane udostępnić policjantowi bagaż 
lub ładunek do przejrzenia lub sprawdzenia, w tym wykonać czynności, o których 
mowa w ust. 5. 
7. Czynności, o których mowa w ust. 1, wykonuje się w miarę możliwości w 
sposób niepowodujący uszkodzenia przeglądanych bagaży lub ładunków. 
8. Przy dokonywaniu czynności, o których mowa w ust. 1, przepisy art. 15d ust. 
4 i 14 stosuje się odpowiednio. 
9. Policjant po zakończeniu wykonywania czynności, o których mowa w ust. 1, 
poucza posiadacza bagaży lub ładunków lub przedstawiciela przewoźnika, spedytora 
lub agenta morskiego, w obecności którego dokonano tych czynności, o prawie do 
złożenia zażalenia, o którym mowa w ust. 11, oraz o prawie do żądania sporządzenia 
protokołu z dokonanych czynności. 
10. Z dokonania czynności, o których mowa w ust. 1, sporządza się protokół w 
przypadku, gdy posiadacz bagaży lub ładunków lub przedstawiciel przewoźnika, 
spedytora lub agenta morskiego, w obecności którego dokonano tych czynności, 
zgłosił takie żądanie bezpośrednio po dokonaniu tych czynności oraz w przypadku, 
gdy w toku czynności znaleziono broń lub przedmioty, o których mowa w art. 15 ust. 
1 pkt 5. Do sporządzenia protokołu stosuje się odpowiednio przepis art. 15d ust. 10 
zdanie drugie. 

 
 
 
s. 50/274 
 
2025-07-03 
 
11. Posiadaczowi bagaży lub ładunków lub przedstawicielowi przewoźnika, 
spedytora lub agenta morskiego, w obecności którego dokonano czynności 
określonych w ust. 1, przysługuje zażalenie do sądu rejonowego właściwego ze 
względu na miejsce dokonania czynności, w terminie 7 dni od dnia jej dokonania, w 
celu zbadania zasadności, legalności oraz prawidłowości jej dokonania. Do zażalenia 
stosuje się odpowiednio przepisy rozdziału 50 Kodeksu postępowania karnego. 
W przypadku stwierdzenia bezzasadności, nielegalności lub nieprawidłowości 
dokonania czynności przepis art. 15d ust. 12 stosuje się odpowiednio. 
12. W przypadku gdy w toku czynności, o których mowa w ust. 1, nie znaleziono 
broni lub przedmiotów, o których mowa w art. 15 ust. 1 pkt 5, lub gdy posiadacz 
bagaży lub ładunków lub przedstawiciel przewoźnika, spedytora lub agenta 
morskiego, w obecności którego dokonano tych czynności, nie zażądał sporządzenia 
protokołu, czynności dokumentuje się w dokumentacji służbowej, określając datę, 
czas, miejsce i przyczynę ich dokonania, dane osób w nich uczestniczących oraz rodzaj 
i wynik czynności, a także informację o pouczeniu osoby, o którym mowa w ust. 9. 
13. Zażalenie, o którym mowa w ust. 11, składa się za pośrednictwem jednostki 
organizacyjnej Policji właściwej według miejsca dokonania czynności określonych w 
ust. 1. Jednostka organizacyjna Policji, o której mowa w zdaniu pierwszym, 
niezwłocznie przekazuje zażalenie do sądu rejonowego.

***
## Art. 15f. {#policja-art-15f}

Minister właściwy do spraw wewnętrznych określi, w drodze 
rozporządzenia, sposób: 
1) 
sporządzania dokumentów, o których mowa w art. 15d ust. 10 i 13 oraz art. 15e 
ust. 10 i 12, a także wzory protokołów, o których mowa w art. 15d ust. 9 i art. 
15e ust. 9, z uwzględnieniem informacji niezbędnych do udokumentowania 
podstaw prawnych, celu i zakresu dokonanej kontroli osobistej, przeglądania 
zawartości bagaży i sprawdzania ładunków w portach i na dworcach oraz w 
środkach transportu lądowego, powietrznego i wodnego oraz z uwzględnieniem 
niezbędnych 
danych 
osobowych 
osób 
objętych 
tymi 
czynnościami, 
uczestniczących w tych czynnościach oraz dokonujących tych czynności, a także 
informacji niezbędnych do ustalenia przebiegu i wyniku tych czynności; 
2) 
postępowania w jednostkach organizacyjnych Policji ze złożonym zażaleniem, o 
którym mowa w art. 15d i art. 15e, celem nadania mu biegu, a także sposób 

 
 
 
s. 51/274 
 
2025-07-03 
 
postępowania z protokołami i dokumentacją służbową sporządzonymi w wyniku 
dokonania tych czynności.

***
## Art. 15g. {#policja-art-15g}

1. Sprawdzenie prewencyjne, o którym mowa w art. 15 ust. 1 pkt 9, 
polega na manualnym sprawdzeniu osoby, zawartości jej odzieży oraz przedmiotów 
znajdujących się na jej ciele lub przez nią posiadanych, sprawdzeniu za pomocą 
środków technicznych niezbędnych do wykrywania materiałów i urządzeń 
niebezpiecznych lub których posiadanie jest zabronione, w szczególności broni, 
materiałów wybuchowych, środków odurzających, substancji psychotropowych i ich 
prekursorów, sprawdzeniu biochemicznym, lub z wykorzystaniem psa służbowego w 
zakresie niezbędnym do realizacji celu podejmowanych czynności w danych 
okolicznościach oraz w sposób możliwie najmniej naruszający dobra osobiste osoby, 
wobec której czynności są wykonywane. 
2. W przypadku gdy w stosunku do osób, o których mowa w art. 15 ust. 1 pkt 9 
lit. a, osób doprowadzonych w związku z realizacją czynności określonych przepisami 
prawa lub osób doprowadzanych przez Policję w celu wytrzeźwienia, o których mowa 
w art. 15 ust. 1 pkt 9 lit. b tiret pierwsze, zaistniały przesłanki, o których mowa w art. 
15 ust. 1 pkt 5, dokonuje się kontroli osobistej na zasadach i w sposób określony w 
art. 15d. 
3. W stosunku do osób zatrzymanych, doprowadzanych lub konwojowanych, 
sprawdzenie prewencyjne, o którym mowa w art. 15 ust. 1 pkt 9, może polegać 
również na: 
1) 
żądaniu zdjęcia przez osobę odzieży i obuwia, 
2) 
zdjęciu osobie odzieży i obuwia w przypadku niewykonania żądania, o którym 
mowa w pkt 1, 
3) 
dokonaniu oględzin ciała tych osób oraz sprawdzeniu zdjętej odzieży i obuwia, 
w tym z wykorzystaniem środków, o których mowa w ust. 1, 
4) 
żądaniu wydania oraz oddania do depozytu, lub w celu zajęcia lub 
zabezpieczenia: 
a) 
środków płatniczych i przedmiotów wartościowych, dokumentów 
tożsamości, środków łączności oraz urządzeń technicznych służących do 
rejestrowania i odtwarzania informacji, 
b) 
przedmiotów, które mogą stanowić zagrożenie życia lub zdrowia lub 
bezpieczeństwa osoby poddanej sprawdzeniu prewencyjnemu lub innych 

 
 
 
s. 52/274 
 
2025-07-03 
 
osób albo bezpieczeństwa przeprowadzanych czynności, w tym broni lub 
innych niebezpiecznych przedmiotów mogących służyć do popełnienia 
przestępstwa lub wykroczenia lub przedmiotów mogących stanowić dowód 
w postępowaniu prowadzonym w związku z realizacją zadań, o których 
mowa w art. 15 ust. 1 pkt 5, lub podlegających przepadkowi, 
c) 
przedmiotów, które mogą stanowić zagrożenie dla porządku lub 
bezpieczeństwa osoby znajdującej się w pomieszczeniu dla osób 
zatrzymanych lub doprowadzonych w celu wytrzeźwienia, w pokoju 
przejściowym, w tymczasowym pomieszczeniu przejściowym lub w 
policyjnej izbie dziecka, w szczególności przedmiotów posiadających ostre 
krawędzie lub zakończenie, środków służących do obezwładniania, 
dopuszczonych 
do 
obrotu 
produktów 
leczniczych, 
produktów 
zawierających 
alkohol, 
sznurowadeł, 
pasków, 
szalików, 
zapałek, 
zapalniczek lub innych przedmiotów, których wymiary lub ilość naruszają 
ustalony porządek bądź bezpieczeństwo pobytu w pomieszczeniu dla osób 
zatrzymanych lub doprowadzonych w celu wytrzeźwienia, w pokoju 
przejściowym, w tymczasowym pomieszczeniu przejściowym lub w 
policyjnej izbie dziecka, 
5) 
odebraniu przedmiotów, o których mowa w pkt 4, oraz ich przyjęciu do depozytu, 
zabezpieczeniu lub zajęciu 
– w szczególności gdy czynności te przeprowadza się w przypadku zatrzymywania 
osoby zgodnie z art. 15 ust. 1 pkt 2–3, umieszczania osoby w jednostce organizacyjnej 
Policji w pomieszczeniu dla osób zatrzymanych lub doprowadzonych w celu 
wytrzeźwienia, 
w 
pokoju 
przejściowym, 
w 
tymczasowym 
pomieszczeniu 
przejściowym lub w policyjnej izbie dziecka, przejmowania osoby w związku z 
wykonywanymi czynnościami przez Policję, a także po zakończeniu widzenia lub 
innej czynności związanej z kontaktem osoby zatrzymanej, konwojowanej lub 
doprowadzonej z innymi osobami lub po każdorazowej utracie kontaktu wzrokowego 
z osobą konwojowaną lub doprowadzaną. 
4. Czynności, o których mowa w ust. 3 pkt 1–3, wykonuje się w sposób 
umożliwiający osobie pozostawienie części odzieży na ciele, a po sprawdzeniu zdjętej 
odzieży – jej włożenie przed zdjęciem pozostałej niesprawdzonej części odzieży oraz 
w warunkach zapewniających poszanowanie jej intymności. 

 
 
 
s. 53/274 
 
2025-07-03 
 
5. Do sprawdzenia prewencyjnego, o którym mowa w art. 15 ust. 1 pkt 9, 
przepisy art. 15d ust. 5, 6 i 14 stosuje się odpowiednio. 
6. W przypadku gdy w toku sprawdzenia prewencyjnego osób zatrzymanych, 
doprowadzonych lub konwojowanych, o którym mowa w art. 15 ust. 1 pkt 9 lit. b, 
ujawniono broń lub przedmioty, o których mowa w art. 15 ust. 1 pkt 5, sprawdzenie 
to traktuje się jako kontrolę osobistą oraz stosuje się odpowiednio przepisy art. 15d. 
7. Osobie, o której mowa w art. 15 ust. 1 pkt 9 lit. b: 
1) 
umieszczonej w jednostce organizacyjnej Policji w pomieszczeniu dla osób 
zatrzymanych lub doprowadzonych w celu wytrzeźwienia, w pokoju 
przejściowym, w tymczasowym pomieszczeniu przejściowym lub w policyjnej 
izbie dziecka, która ukończyła 18 lat i upoważniła pisemnie wskazaną przez 
siebie osobę do odbioru przedmiotów w miejscu ich zdeponowania umożliwia 
się rozporządzanie przekazanymi do depozytu przedmiotami, o których mowa w 
ust. 3 pkt 4 lit. a i c, z wyjątkiem przekazania tych przedmiotów osobie 
zatrzymanej, osobie konwojowanej lub doprowadzanej oraz korzystania z tych 
przedmiotów i ich posiadania przez te osoby, a także z wyjątkiem przedmiotów, 
które zostały zatrzymane lub zajęte w drodze zabezpieczenia bądź egzekucji 
administracyjnej; 
2) 
zwalnianej z pomieszczenia dla osób zatrzymanych lub doprowadzonych w celu 
wytrzeźwienia z pokoju przejściowego, z tymczasowego pomieszczenia 
przejściowego lub z policyjnej izby dziecka wydaje się przedmioty przyjęte do 
depozytu, z wyjątkiem przedmiotów, które zostały zatrzymane lub zajęte w 
drodze 
zabezpieczenia, 
podlegających 
przepadkowi 
bądź 
egzekucji 
administracyjnej. 
8. W przypadku zwalniania osoby z pomieszczenia dla osób zatrzymanych lub 
doprowadzonych w celu wytrzeźwienia, z pokoju przejściowego, z tymczasowego 
pomieszczenia przejściowego lub z policyjnej izby dziecka w celu jej przekazania do 
wykonania czynności procesowych lub innych czynności określonych przez sąd lub 
prokuratora, środki, dokumenty tożsamości, urządzenia techniczne i przedmioty, o 
których mowa w ust. 3 pkt 4 lit. a i c, z wyjątkiem sznurowadeł, paska i szalika, 
przejmuje na czas doprowadzenia lub konwoju policjant realizujący doprowadzenie 
lub konwój. 
9. Osobie, o której mowa w art. 15 ust. 1 pkt 9 lit. a, odmawiającej poddania się 
sprawdzeniu prewencyjnemu, o którym mowa w art. 15 ust. 1 pkt 9, można odmówić 

 
 
 
s. 54/274 
 
2025-07-03 
 
wstępu na teren obiektów lub obszarów ochranianych przez Policję lub na imprezę 
masową zabezpieczaną przez Policję, jak również uniemożliwić udział w 
zgromadzeniu.

***
## Art. 16. {#policja-art-16}

1. W przypadkach, o których mowa w art. 11 ustawy z dnia 24 maja 
2013 r. o środkach przymusu bezpośredniego i broni palnej (Dz. U. z 2024 r. poz. 383 
i 1248 oraz z 2025 r. poz. 179), policjanci mogą użyć środków przymusu 
bezpośredniego, o których mowa w art. 12 ust. 1 pkt 1–13 i 17–21 tej ustawy, lub 
wykorzystać te środki. 
2. W przypadkach, o których mowa w art. 45 pkt 1–3 i pkt 4 lit. a i b oraz w art. 
47 ustawy z dnia 24 maja 2013 r. o środkach przymusu bezpośredniego i broni palnej, 
policjanci mogą użyć broni palnej lub ją wykorzystać. 
3. Użycie i wykorzystanie środków przymusu bezpośredniego i broni palnej oraz 
dokumentowanie tego użycia i wykorzystania odbywa się na zasadach określonych w 
ustawie z dnia 24 maja 2013 r. o środkach przymusu bezpośredniego i broni palnej.

***
## Art. 16a. {#policja-art-16a}

Wobec nieletniego doprowadzonego do policyjnej izby dziecka, w 
przypadkach, o których mowa w art. 11 pkt 1–3, 8 i 10–14 ustawy z dnia 24 maja 2013 
r. o środkach przymusu bezpośredniego i broni palnej, policjanci mogą użyć środka 
przymusu bezpośredniego, o którym mowa w art. 12 ust. 1 pkt 1, pkt 2 lit. a i b, pkt 3, 
4, 6, 7, pkt 12 lit. a i pkt 13 tej ustawy.

***
## Art. 17. {#policja-art-17}

(uchylony)

***
## Art. 18. {#policja-art-18}

1. W razie zagrożenia bezpieczeństwa publicznego lub zakłócenia 
porządku publicznego, zwłaszcza poprzez sprowadzenie: 
1) 
niebezpieczeństwa powszechnego dla życia, zdrowia lub wolności obywateli, 
2) 
bezpośredniego zagrożenia dla mienia w znacznych rozmiarach, 
3) 
bezpośredniego zagrożenia obiektów lub urządzeń ważnych dla bezpieczeństwa 
lub obronności państwa, siedzib centralnych organów państwowych albo 
wymiaru sprawiedliwości, obiektów gospodarki lub kultury narodowej oraz 
przedstawicielstw dyplomatycznych i urzędów konsularnych państw obcych 
albo organizacji międzynarodowych, a także obiektów dozorowanych przez 
uzbrojoną formację ochronną utworzoną na podstawie odrębnych przepisów, 
4) 
zagrożenia przestępstwem o charakterze terrorystycznym mogącym skutkować 
niebezpieczeństwem dla życia lub zdrowia uczestników wydarzeń o charakterze 

 
 
 
s. 55/274 
 
2025-07-03 
 
kulturalnym, sportowym lub religijnym, w tym zgromadzeń lub imprez 
masowych 
– jeżeli użycie oddziałów lub pododdziałów Policji okaże się lub może okazać się 
niewystarczające, do pomocy oddziałom i pododdziałom Policji mogą być użyte 
oddziały i pododdziały Sił Zbrojnych Rzeczypospolitej Polskiej, zwane dalej  
„Siłami Zbrojnymi”. 
2. (uchylony) 
3. Użycie Sił Zbrojnych, w przypadkach o których mowa w ust. 1, następuje na 
podstawie postanowienia Prezydenta Rzeczypospolitej Polskiej wydanego na wniosek 
Prezesa Rady Ministrów. 
4. Pomoc, o której mowa w ust. 1, może być udzielona również w formie 
prowadzonego samodzielnie przez oddziały i pododdziały Sił Zbrojnych 
przeciwdziałania zagrożeniu, w przypadku gdy oddziały i pododdziały Policji nie 
dysponują możliwościami skutecznego przeciwdziałania tym zagrożeniom. 
5. W przypadkach niecierpiących zwłoki decyzję o udzieleniu pomocy, o której 
mowa w ust. 1 i 4, podejmuje Minister Obrony Narodowej, na wniosek ministra 
właściwego do spraw wewnętrznych, określający zakres i formę pomocy, przekazując 
ją niezwłocznie Prezydentowi Rzeczypospolitej Polskiej i Prezesowi Rady Ministrów. 
5a. Wniosek lub decyzja, o których mowa w ust. 5, mogą być skutecznie 
przekazane także ustnie, telefonicznie, za pomocą środków komunikacji 
elektronicznej w rozumieniu art. 2 pkt 5 ustawy z dnia 18 lipca 2002 r. o świadczeniu 
usług drogą elektroniczną (Dz. U. z 2024 r. poz. 1513) lub za pomocą innych środków 
łączności, a ich treść oraz istotne motywy takiego załatwienia sprawy utrwala się w 
formie pisemnej w postaci papierowej. 
6. Prezydent Rzeczypospolitej Polskiej niezwłocznie wydaje postanowienie o 
zatwierdzeniu lub uchyleniu decyzji, o której mowa w ust. 5. 
7. Żołnierzom oddziałów i pododdziałów Sił Zbrojnych kierowanych do pomocy 
oddziałom i pododdziałom Policji przysługują w zakresie niezbędnym do 
wykonywania ich zadań, wobec wszystkich osób, uprawnienia policjantów określone 
w art. 15 i art. 16. Korzystanie z tych uprawnień następuje na zasadach i w trybie 
określonych dla policjantów. 
8. Rada Ministrów określi, w drodze rozporządzenia: 
1) 
szczegółowe warunki i sposób użycia oddziałów i pododdziałów Policji i Sił 
Zbrojnych; 

 
 
 
s. 56/274 
 
2025-07-03 
 
2) 
sposób koordynowania działań podejmowanych przez Policję i Siły Zbrojne w 
formie określonej w ust. 1 i 4; 
3) 
tryb wymiany informacji i sposób logistycznego wsparcia działań Policji 
prowadzonych z pomocą oddziałów i pododdziałów Sił Zbrojnych. 
9. Rozporządzenie, o którym mowa w ust. 8, powinno uwzględniać: 
1) 
stopień zagrożenia bezpieczeństwa publicznego lub zakłócenia porządku 
publicznego, w tym przestępstwem o charakterze terrorystycznym, oraz 
przewidywany rozwój sytuacji; 
2) 
zachowanie ciągłości dowodzenia, w tym oddziałami Sił Zbrojnych; 
3) 
ochronę wymienianych informacji oraz zakres wsparcia logistycznego Policji.

***
## Art. 18a. {#policja-art-18a}

1. W razie zagrożenia bezpieczeństwa i porządku publicznego, jeżeli 
siły Policji są niewystarczające lub mogą okazać się niewystarczające do wykonania 
ich zadań w zakresie ochrony bezpieczeństwa i porządku publicznego, Prezes Rady 
Ministrów, na wniosek ministra właściwego do spraw wewnętrznych uzgodniony z 
Ministrem Obrony Narodowej, może zarządzić użycie żołnierzy Żandarmerii 
Wojskowej do udzielenia pomocy Policji. 
2. W wypadku, o którym mowa w ust. 1, żołnierzom Żandarmerii Wojskowej 
przysługują, w zakresie niezbędnym do wykonania ich zadań, wobec wszystkich osób, 
uprawnienia policjantów określone w art. 15 i art. 16. Korzystanie z tych uprawnień 
następuje na zasadach i w trybie określonych dla policjantów.

***
## Art. 18b. {#policja-art-18b}

1. W razie zagrożenia bezpieczeństwa publicznego lub porządku 
publicznego, jeżeli użycie Policji okaże się niewystarczające lub może okazać się 
niewystarczające, minister właściwy do spraw wewnętrznych może zarządzić użycie 
funkcjonariuszy Straży Granicznej do udzielenia pomocy Policji. 
2. Pomoc, o której mowa w ust. 1, może zostać udzielona przez funkcjonariuszy 
Straży Granicznej również w formie samodzielnych działań. 
3. Funkcjonariuszom Straży Granicznej skierowanym do wykonywania zadań 
służbowych polegających na udzielaniu pomocy Policji przysługują, w zakresie 
niezbędnym do wykonywania zadań, uprawnienia policjantów określone w art. 15 ust. 
1 pkt 1–3 i 4–5a oraz art. 16. Korzystanie z tych uprawnień następuje na zasadach i w 
trybie określonych dla policjantów.

***
## Art. 18c. {#policja-art-18c}

1. W przypadkach, o których mowa w art. 18 ust. 1 niniejszej ustawy 
lub w art. 22 ust. 1 ustawy z dnia 10 czerwca 2016 r. o działaniach 

 
 
 
s. 57/274 
 
2025-07-03 
 
antyterrorystycznych, Komendant Główny Policji, Komendant CBŚP, Komendant 
CBZC lub komendant wojewódzki Policji może zarządzić zastosowanie przez Policję 
urządzeń uniemożliwiających telekomunikację na określonym obszarze, przez czas 
niezbędny do wyeliminowania zagrożenia lub jego skutków, z uwzględnieniem 
konieczności minimalizacji skutków braku możliwości korzystania z usług 
telekomunikacyjnych. 
2. O zastosowaniu urządzeń, o których mowa w ust. 1, Komendant Główny 
Policji, Komendant CBŚP, Komendant CBZC lub komendant wojewódzki Policji 
niezwłocznie informuje Prezesa Urzędu Komunikacji Elektronicznej.

***
## Art. 19. {#policja-art-19}

1. Przy wykonywaniu czynności operacyjno-rozpoznawczych, 
podejmowanych przez Policję w celu zapobieżenia, wykrycia, ustalenia sprawców, a 
także uzyskania i utrwalenia dowodów, ściganych z oskarżenia publicznego, 
umyślnych przestępstw: 
1) 
przeciwko życiu, określonych w art. 148–150 Kodeksu karnego, 
2) 
określonych w art. 134, art. 135 § 1, art. 136 § 1, art. 156 § 1 i 3, art. 156a, art. 
163 § 1 i 3, art. 164 § 1, art. 165 § 1 i 3, art. 166, art. 167, art. 173 § 1 i 3, art. 
189, art. 189a, art. 191b, art. 200a, art. 200b, art. 211a, art. 223, art. 224a, art. 228 
§ 1 i 3–6, art. 229 § 1 i 3–5, art. 230 § 1, art. 230a § 1, art. 231 § 2, art. 232, art. 
233 § 1, 1a, 4 i 6, art. 234, art. 235, art. 236 § 1, art. 238, art. 239 § 1, art. 240 § 
1, art. 245, art. 246, art. 252 § 1–3, art. 258, art. 267 § 1–4, art. 268a § 1 i 2, art. 
269, art. 269a, art. 269b § 1, art. 270a § 1 i 2, art. 271a § 1 i 2, art. 277a § 1, art. 
279 § 1, art. 280–282, art. 285 § 1, art. 286 § 1, art. 287 § 1, art. 296 § 1–3, art. 
296a § 1, 2 i 4, art. 299 § 1–6 oraz art. 310 § 1, 2 i 4 Kodeksu karnego, 
2a) określonych w art. 46 ust. 1, 2 i 4, art. 47 oraz art. 48 ust. 1 i 2 ustawy z dnia 25 
czerwca 2010 r. o sporcie (Dz. U. z 2024 r. poz. 1488 oraz z 2025 r. poz. 28), 
2b) określonych w art. 178–183 ustawy z dnia 29 lipca 2005 r. o obrocie 
instrumentami finansowymi (Dz. U. z 2024 r. poz. 722 i 1863 oraz z 2025 r. poz. 
146) oraz art. 99–100 ustawy z dnia 29 lipca 2005 r. o ofercie publicznej i 
warunkach wprowadzania instrumentów finansowych do zorganizowanego 
systemu obrotu oraz o spółkach publicznych (Dz. U. z 2024 r. poz. 620 i 1863 
oraz z 2025 r. poz. 146), 
3) 
przeciwko obrotowi gospodarczemu, określonych w art. 296–306 Kodeksu 
karnego, powodujących szkodę majątkową lub skierowanych przeciwko mieniu, 

 
 
 
s. 58/274 
 
2025-07-03 
 
jeżeli wysokość szkody lub wartość mienia przekracza pięćdziesięciokrotną 
wysokość najniższego wynagrodzenia za pracę określonego na podstawie 
odrębnych przepisów, 
3a) przeciwko wolności seksualnej i obyczajności, gdy pokrzywdzonym jest 
małoletni albo gdy treści pornograficzne, o których mowa w art. 202 Kodeksu 
karnego, obejmują udział małoletniego, 
3b) określonych w rozdziale 11 ustawy z dnia 23 lipca 2003 r. o ochronie zabytków 
i opiece nad zabytkami (Dz. U. z 2024 r. poz. 1292 i 1907), w rozdziale 5 ustawy 
z dnia 14 lipca 1983 r. o narodowym zasobie archiwalnym i archiwach (Dz. U. z 
2020 r. poz. 164), w rozdziale 5a ustawy z dnia 21 listopada 1996 r. o muzeach 
(Dz. U. z 2022 r. poz. 385), w rozdziale 11a ustawy z dnia 27 czerwca 1997 r. o 
bibliotekach (Dz. U. z 2022 r. poz. 2393) oraz w rozdziale 6 ustawy z dnia 
25 maja 2017 r. o restytucji narodowych dóbr kultury (Dz. U. z 2019 r. poz. 
1591), 
4) 
skarbowych, jeżeli wartość przedmiotu czynu lub uszczuplenie należności 
publicznoprawnej przekraczają pięćdziesięciokrotną wysokość najniższego 
wynagrodzenia za pracę określonego na podstawie odrębnych przepisów, 
4a) skarbowych, o których mowa w art. 107 § 1 Kodeksu karnego skarbowego, 
5) 
nielegalnego wytwarzania, posiadania lub obrotu bronią, amunicją, materiałami 
wybuchowymi, środkami odurzającymi, substancjami psychotropowymi, ich 
prekursorami lub nowymi substancjami psychoaktywnymi oraz materiałami 
jądrowymi i promieniotwórczymi, 
6) 
określonych w art. 8 ustawy z dnia 6 czerwca 1997 r. – Przepisy wprowadzające 
Kodeks karny (Dz. U. poz. 554 i 1083, z 1998 r. poz. 715, z 2009 r. poz. 1149 i 
1589, z 2010 r. poz. 626 oraz z 2022 r. poz. 2600), 
7) 
określonych w art. 43–46 ustawy z dnia 1 lipca 2005 r. o pobieraniu, 
przechowywaniu i przeszczepianiu komórek, tkanek i narządów (Dz. U. z 2023 
r. poz. 1185), 
8) 
ściganych na mocy umów międzynarodowych ratyfikowanych za uprzednią 
zgodą wyrażoną w ustawie, określonych w polskiej ustawie karnej, 
9) 
o których mowa w pkt 1–8 lub, o których mowa w art. 45 § 2 Kodeksu karnego 
albo art. 33 § 2 Kodeksu karnego skarbowego – w celu ujawnienia mienia 
zagrożonego przepadkiem w związku z tymi przestępstwami 

 
 
 
s. 59/274 
 
2025-07-03 
 
– gdy inne środki okazały się bezskuteczne albo będą nieprzydatne, sąd okręgowy 
może, w drodze postanowienia, zarządzić kontrolę operacyjną, na pisemny wniosek 
Komendanta Głównego Policji, Komendanta CBŚP, Komendanta BSWP albo 
Komendanta CBZC, złożony po uzyskaniu pisemnej zgody Pierwszego Zastępcy 
Prokuratora Generalnego Prokuratora Krajowego, albo na pisemny wniosek 
komendanta wojewódzkiego Policji, złożony po uzyskaniu pisemnej zgody 
prokuratora okręgowego właściwego ze względu na siedzibę składającego wniosek 
organu Policji. 
1a. Wniosek, o którym mowa w ust. 1, przedstawia się wraz z materiałami 
uzasadniającymi potrzebę zastosowania kontroli operacyjnej. 
2. Postanowienie, o którym mowa w ust. 1, wydaje sąd okręgowy właściwy 
miejscowo ze względu na siedzibę składającego wniosek organu Policji. 
3. W przypadkach niecierpiących zwłoki, jeżeli mogłoby to spowodować utratę 
informacji lub zatarcie albo zniszczenie dowodów przestępstwa, Komendant Główny 
Policji, Komendant CBŚP, Komendant BSWP, Komendant CBZC albo komendant 
wojewódzki Policji może zarządzić, po uzyskaniu pisemnej zgody właściwego 
prokuratora, o którym mowa w ust. 1, kontrolę operacyjną, zwracając się jednocześnie 
do właściwego miejscowo sądu okręgowego z wnioskiem o wydanie postanowienia w 
tej sprawie. W razie nieudzielenia przez sąd zgody w terminie 5 dni od dnia 
zarządzenia kontroli operacyjnej, organ zarządzający wstrzymuje kontrolę operacyjną 
oraz dokonuje protokolarnego, komisyjnego zniszczenia materiałów zgromadzonych 
podczas jej stosowania. 
4. (uchylony) 
5. W przypadku potrzeby zarządzenia kontroli operacyjnej wobec osoby 
podejrzanej lub oskarżonego, we wniosku organu Policji, o którym mowa w ust. 1, o 
zarządzenie kontroli operacyjnej zamieszcza się informację o toczącym się wobec tej 
osoby postępowaniu. 
6. Kontrola operacyjna prowadzona jest niejawnie i polega na: 
1) 
uzyskiwaniu i utrwalaniu treści rozmów prowadzonych przy użyciu środków 
technicznych, w tym za pomocą sieci telekomunikacyjnych; 
2) 
uzyskiwaniu i utrwalaniu obrazu lub dźwięku osób z pomieszczeń, środków 
transportu lub miejsc innych niż miejsca publiczne; 
3) 
uzyskiwaniu i utrwalaniu treści korespondencji, w tym korespondencji 
prowadzonej za pomocą środków komunikacji elektronicznej; 

 
 
 
s. 60/274 
 
2025-07-03 
 
4) 
uzyskiwaniu i utrwalaniu danych zawartych w informatycznych nośnikach 
danych, 
telekomunikacyjnych 
urządzeniach 
końcowych, 
systemach 
informatycznych i teleinformatycznych; 
5) 
uzyskiwaniu dostępu i kontroli zawartości przesyłek. 
6a. Kontroli operacyjnej nie stanowią czynności, o których mowa w ust. 6 pkt 2, 
polegające na uzyskiwaniu i utrwalaniu obrazu w pomieszczeniach, o których mowa 
w art. 15 ust. 1 pkt 4a. 
6b. Realizacja czynności, o których mowa w ust. 6a, nie wymaga zgody sądu. 
7. Wniosek organu Policji, o którym mowa w ust. 1, o zarządzenie przez sąd 
okręgowy kontroli operacyjnej powinien zawierać w szczególności: 
1) 
numer sprawy i jej kryptonim, jeżeli został jej nadany; 
2) 
opis przestępstwa z podaniem, w miarę możliwości, jego kwalifikacji prawnej; 
3) 
okoliczności uzasadniające potrzebę zastosowania kontroli operacyjnej, w tym 
stwierdzonej bezskuteczności lub nieprzydatności innych środków; 
4) 
dane osoby lub inne dane, pozwalające na jednoznaczne określenie podmiotu lub 
przedmiotu, wobec którego stosowana będzie kontrola operacyjna, ze 
wskazaniem miejsca lub sposobu jej stosowania; 
5) 
cel, czas i rodzaj prowadzonej kontroli operacyjnej, o której mowa w ust. 6. 
8. Kontrolę operacyjną zarządza się na okres nie dłuższy niż 3 miesiące. Sąd 
okręgowy może, na pisemny wniosek Komendanta Głównego Policji, Komendanta 
CBŚP, Komendanta BSWP, Komendanta CBZC albo komendanta wojewódzkiego 
Policji, złożony po uzyskaniu pisemnej zgody właściwego prokuratora, o którym 
mowa w ust. 1, na okres nie dłuższy niż kolejne 3 miesiące, wydać postanowienie o 
jednorazowym przedłużeniu kontroli operacyjnej, jeżeli nie ustały przyczyny tej 
kontroli. 
9. W uzasadnionych przypadkach, gdy podczas stosowania kontroli operacyjnej 
pojawią się nowe okoliczności istotne dla zapobieżenia lub wykrycia przestępstwa 
albo ustalenia sprawców i uzyskania dowodów przestępstwa, sąd okręgowy, 
na pisemny wniosek Komendanta Głównego Policji, złożony po uzyskaniu pisemnej 
zgody Pierwszego Zastępcy Prokuratora Generalnego Prokuratora Krajowego, może, 
również po upływie okresów, o których mowa w ust. 8, wydawać kolejne 
postanowienia o przedłużeniu kontroli operacyjnej na następujące po sobie okresy, 
których łączna długość nie może przekraczać 12 miesięcy. 

 
 
 
s. 61/274 
 
2025-07-03 
 
9a. Komendant Główny Policji, Komendant CBŚP, Komendant BSWP, 
Komendant CBZC albo komendant wojewódzki Policji może upoważnić swojego 
zastępcę do składania wniosków, o których mowa w ust. 1, 3, 8 i 9, lub do zarządzania 
kontroli operacyjnej w trybie ust. 3. 
10. Do wniosków, o których mowa w ust. 3, 8 i 9, stosuje się odpowiednio ust. 
1a i 7. Sąd przed wydaniem postanowienia, o którym mowa w ust. 1, 3, 8 i 9, zapoznaje 
się z materiałami uzasadniającymi wniosek, w szczególności zgromadzonymi podczas 
stosowania kontroli operacyjnej zarządzonej w tej sprawie. 
10a. Wnioski, postanowienia, pisemne zgody i zarządzenia, o których mowa w 
ust. 1, 3, 8 i 9, w odniesieniu do spraw realizowanych przez BSWP, Komendant BSWP 
przekazuje do wiadomości Inspektorowi Nadzoru Wewnętrznego. 
11. Wnioski, o których mowa w ust. 1, 3–5, 8 i 9, sąd okręgowy rozpoznaje 
jednoosobowo, przy czym czynności sądu związane z rozpoznawaniem tych 
wniosków 
powinny 
być 
realizowane 
w 
warunkach 
przewidzianych 
dla 
przekazywania, przechowywania i udostępniania informacji niejawnych oraz z 
odpowiednim zastosowaniem przepisów wydanych na podstawie art. 181 § 2 Kodeksu 
postępowania karnego. W posiedzeniu sądu może wziąć udział wyłącznie prokurator 
i przedstawiciel organu Policji wnioskującego o zarządzenie kontroli operacyjnej. 
12. Przedsiębiorca telekomunikacyjny, operator pocztowy oraz usługodawca 
świadczący usługi drogą elektroniczną są obowiązani do zapewnienia na własny koszt 
warunków technicznych i organizacyjnych umożliwiających prowadzenie przez 
Policję kontroli operacyjnej. 
12a. 
Usługodawca 
świadczący 
usługi 
drogą 
elektroniczną 
będący 
mikroprzedsiębiorcą lub małym przedsiębiorcą w rozumieniu przepisów ustawy z dnia 
6 marca 2018 r. – Prawo przedsiębiorców (Dz. U. z 2024 r. poz. 236, 1222 i 1871 oraz 
z 2025 r. poz. 222) zapewnia warunki techniczne i organizacyjne umożliwiające 
prowadzenie przez Policję kontroli operacyjnej stosownie do posiadanej 
infrastruktury. 
13. Kontrola operacyjna powinna być zakończona niezwłocznie po ustaniu 
przyczyn jej zarządzenia, najpóźniej jednak z upływem okresu, na który została 
wprowadzona. 
14. Organ Policji, o którym mowa w ust. 1, informuje właściwego prokuratora o 
wynikach kontroli operacyjnej po jej zakończeniu, a na jego żądanie również o 
przebiegu tej kontroli. 

 
 
 
s. 62/274 
 
2025-07-03 
 
15. W przypadku uzyskania dowodów pozwalających na wszczęcie 
postępowania karnego lub mających znaczenie dla toczącego się postępowania 
karnego Komendant Główny Policji, Komendant CBŚP, Komendant BSWP, 
Komendant CBZC albo komendant wojewódzki Policji przekazuje prokuratorowi, o 
którym mowa w ust. 1, wszystkie materiały zgromadzone podczas stosowania kontroli 
operacyjnej. W postępowaniu przed sądem, w odniesieniu do tych materiałów, stosuje 
się odpowiednio art. 393 § 1 zdanie pierwsze Kodeksu postępowania karnego. 
15a. (uchylony) 
15b. (uchylony) 
15c. (uchylony) 
15d. (uchylony) 
15e. (uchylony) 
15f. W przypadku, gdy materiały, o których mowa w ust. 15: 
1) 
zawierają informacje, o których mowa w art. 178 Kodeksu postępowania 
karnego, Komendant Główny Policji, Komendant CBŚP, Komendant BSWP, 
Komendant CBZC albo komendant wojewódzki Policji zarządza ich 
niezwłoczne, komisyjne i protokolarne zniszczenie; 
2) 
mogą zawierać informacje, o których mowa w art. 178a i art. 180 § 3 Kodeksu 
postępowania karnego, z wyłączeniem informacji o przestępstwach, o których 
mowa w art. 240 § 1 Kodeksu karnego, albo informacje stanowiące tajemnice 
związane z wykonywaniem zawodu lub funkcji, o których mowa w art. 180 § 2 
Kodeksu postępowania karnego, Komendant Główny Policji, Komendant CBŚP, 
Komendant BSWP, Komendant CBZC albo komendant wojewódzki Policji 
przekazuje prokuratorowi te materiały. 
15g. W przypadku, o którym mowa w ust. 15f pkt 2, prokurator niezwłocznie po 
otrzymaniu materiałów kieruje je do sądu, który zarządził kontrolę operacyjną albo 
wyraził na nią zgodę w trybie określonym w ust. 3, wraz z wnioskiem o: 
1) 
stwierdzenie, które z przekazanych materiałów zawierają informacje, o których 
mowa w ust. 15f pkt 2; 
2) 
dopuszczenie do wykorzystania w postępowaniu karnym materiałów 
zawierających informacje stanowiące tajemnice związane z wykonywaniem 
zawodu lub funkcji, o których mowa w art. 180 § 2 Kodeksu postępowania 
karnego, nieobjęte zakazami, określonymi w art. 178a i art. 180 § 3 Kodeksu 

 
 
 
s. 63/274 
 
2025-07-03 
 
postępowania karnego z wyłączeniem informacji o przestępstwach, o których 
mowa w art. 240 § 1 Kodeksu karnego. 
15h. Sąd, niezwłocznie po złożeniu wniosku przez prokuratora, wydaje 
postanowienie o dopuszczeniu do wykorzystania w postępowaniu karnym materiałów, 
o których mowa w ust. 15g pkt 2, gdy jest to niezbędne dla dobra wymiaru 
sprawiedliwości, a okoliczność nie może być ustalona na podstawie innego dowodu, 
a także zarządza niezwłoczne zniszczenie materiałów, których wykorzystanie w 
postępowaniu karnym jest niedopuszczalne. 
15i. Na postanowienie sądu w przedmiocie dopuszczenia do wykorzystania w 
postępowaniu karnym materiałów, o których mowa w ust. 15g pkt 2, prokuratorowi 
przysługuje zażalenie. Do zażalenia stosuje się odpowiednio przepisy Kodeksu 
postępowania karnego. 
15j. Organ Policji jest obowiązany do wykonania zarządzenia sądu o zniszczeniu 
materiałów, o którym mowa w ust. 15h, oraz niezwłocznego, komisyjnego i 
protokolarnego zniszczenia materiałów, których wykorzystanie w postępowaniu 
karnym jest niedopuszczalne. Organ Policji niezwłocznie informuje prokuratora, o 
którym mowa w ust. 15g, o zniszczeniu tych materiałów. 
16. Osobie, wobec której kontrola operacyjna była stosowana, nie udostępnia się 
materiałów zgromadzonych podczas trwania tej kontroli. Przepis nie narusza 
uprawnień wynikających z art. 321 Kodeksu postępowania karnego. 
16a. Sąd okręgowy, Pierwszy Zastępca Prokuratora Generalnego Prokurator 
Krajowy, prokurator okręgowy i organ Policji prowadzą rejestry postanowień, 
pisemnych zgód, wniosków i zarządzeń dotyczących kontroli operacyjnej. 
16b. Komendant Główny Policji prowadzi rejestr centralny wniosków i 
zarządzeń dotyczących kontroli operacyjnej prowadzonej przez organy Policji w 
zakresie przewidzianym dla prowadzonych przez nie rejestrów. 
16c. W komórkach organizacyjnych Policji wykonujących zarządzenia w 
sprawie kontroli operacyjnej można odrębnie rejestrować dane zawarte w 
dokumentacji z kontroli operacyjnej w zakresie przewidzianym dla prowadzonych 
przez organy Policji rejestrów, o których mowa w ust. 16a. 
16d. Rejestry, o których mowa w ust. 16a–16c, prowadzi się w formie 
elektronicznej, z zachowaniem przepisów o ochronie informacji niejawnych. 
17. Zgromadzone podczas stosowania kontroli operacyjnej materiały 
niezawierające dowodów pozwalających na wszczęcie postępowania karnego lub 

 
 
 
s. 64/274 
 
2025-07-03 
 
dowodów mających znaczenie dla toczącego się postępowania karnego podlegają 
niezwłocznemu, protokolarnemu i komisyjnemu zniszczeniu. Zniszczenie materiałów 
zarządza organ Policji, który wnioskował o zarządzenie kontroli operacyjnej. 
17a. O wydaniu i wykonaniu zarządzenia dotyczącego zniszczenia materiałów, 
o których mowa w ust. 17, organ Policji jest obowiązany do niezwłocznego 
poinformowania prokuratora, o którym mowa w ust. 1. 
18. (uchylony) 
19. (uchylony) 
20. Na postanowienia sądu, o których mowa w: 
1) 
ust. 1, 3, 8 i 9 – przysługuje zażalenie organowi Policji, który złożył wniosek o 
wydanie tego postanowienia; 
2) 
ust. 3 – przysługuje zażalenie właściwemu prokuratorowi, o którym mowa w ust. 
1. 
Do zażalenia stosuje się odpowiednio przepisy Kodeksu postępowania karnego. 
21. Minister właściwy do spraw wewnętrznych, w porozumieniu z Ministrem 
Sprawiedliwości, ministrem właściwym do spraw łączności oraz ministrem 
właściwym do spraw informatyzacji, określi, w drodze rozporządzenia, sposób 
sporządzania dokumentacji w związku z zarządzeniem kontroli operacyjnej, 
dokumentowania kontroli operacyjnej, przechowywania i przekazywania wniosków i 
zarządzeń, a także przechowywania, przekazywania oraz przetwarzania, kopiowania 
i niszczenia materiałów uzyskanych podczas tej kontroli, zakres 
danych 
gromadzonych w rejestrach, o których mowa w ust. 16a–16c, oraz wzory stosowanych 
druków i rejestrów, mając na względzie potrzebę zapewnienia niejawnego charakteru 
podejmowanych czynności i uzyskanych materiałów. 
22. Minister właściwy do spraw wewnętrznych przedstawia corocznie Sejmowi 
i Senatowi informację o działalności określonej w ust. 1–21, w tym informacje i dane, 
o których mowa w art. 20 ust. 3. Informacja powinna być przedstawiona Sejmowi i 
Senatowi do dnia 30 czerwca roku następnego po roku nią objętym.

***
## Art. 19a. {#policja-art-19a}

1. W sprawach o przestępstwa określone w art. 19 ust. 1 czynności 
operacyjno-rozpoznawcze zmierzające do sprawdzenia uzyskanych wcześniej 
wiarygodnych informacji o przestępstwie oraz ustalenia sprawców i uzyskania 
dowodów przestępstwa mogą polegać na dokonaniu w sposób niejawny nabycia, 
zbycia lub przejęcia przedmiotów pochodzących z przestępstwa, ulegających 

 
 
 
s. 65/274 
 
2025-07-03 
 
przepadkowi, albo których wytwarzanie, posiadanie, przewożenie lub którymi obrót 
są zabronione, a także przyjęciu lub wręczeniu korzyści majątkowej. 
2. Czynności operacyjno-rozpoznawcze, o których mowa w ust. 1, mogą polegać 
także na złożeniu propozycji nabycia, zbycia lub przejęcia przedmiotów 
pochodzących z przestępstwa, ulegających przepadkowi, albo których wytwarzanie, 
posiadanie, przewożenie lub którymi obrót są zabronione, a także przyjęcia lub 
wręczenia korzyści majątkowej. 
3. Komendant Główny Policji, Komendant CBŚP, Komendant BSWP, 
Komendant CBZC albo komendant wojewódzki Policji może zarządzić, na czas 
określony, czynności, o których mowa w ust. 1 i 2, po uzyskaniu pisemnej zgody 
prokuratora okręgowego właściwego ze względu na siedzibę organu Policji 
składającego wniosek, którego na bieżąco informuje o wynikach przeprowadzonych 
czynności. Prokurator może zarządzić zaniechanie czynności w każdym czasie. 
3a. Przed wydaniem pisemnej zgody prokurator zapoznaje się z materiałami 
uzasadniającymi przeprowadzenie czynności, o których mowa w ust. 1 i 2. 
4. Czynności, o których mowa w ust. 1 i 2, zarządza się na czas nie dłuższy niż 
3 miesiące. Komendant Główny Policji, Komendant CBŚP, Komendant BSWP, 
Komendant CBZC albo komendant wojewódzki Policji może, po uzyskaniu pisemnej 
zgody prokuratora, o którym mowa w ust. 3, jednorazowo przedłużyć stosowanie 
czynności na czas nie dłuższy niż kolejne 3 miesiące, jeżeli nie ustały przyczyny ich 
zarządzenia. Przepis ust. 3a stosuje się odpowiednio. 
5. W uzasadnionych przypadkach, gdy podczas stosowania czynności, o których 
mowa w ust. 1 i 2, pojawią się nowe okoliczności istotne dla sprawdzenia uzyskanych 
wcześniej wiarygodnych informacji o przestępstwie oraz ustalenia sprawców i 
uzyskania dowodów przestępstwa, Komendant Główny Policji, Komendant CBŚP, 
Komendant BSWP, Komendant CBZC albo komendant wojewódzki Policji może, po 
uzyskaniu pisemnej zgody prokuratora, o którym mowa w ust. 3, zarządzić 
kontynuowanie czynności przez czas oznaczony również po upływie okresów, o 
których mowa w ust. 4. Przepis ust. 3a stosuje się odpowiednio. 
5a. Zarządzenia, pisemne zgody i wnioski, o których mowa w ust. 3, 4 i 5 w 
odniesieniu do spraw realizowanych przez BSWP, Komendant BSWP przekazuje do 
wiadomości Inspektorowi Nadzoru Wewnętrznego. 
6. Czynności, o których mowa w ust. 1 i 2, mogą być niejawnie rejestrowane za 
pomocą urządzeń służących do rejestracji obrazu lub dźwięku. 

 
 
 
s. 66/274 
 
2025-07-03 
 
7. W przypadku uzyskania dowodów pozwalających na wszczęcie postępowania 
karnego lub mających znaczenie dla toczącego się postępowania karnego Komendant 
Główny Policji, Komendant CBŚP, Komendant BSWP, Komendant CBZC albo 
komendant wojewódzki Policji przekazuje prokuratorowi okręgowemu, o którym 
mowa w ust. 3, wszystkie materiały zgromadzone podczas stosowania czynności, o 
których mowa w ust. 1 i 2. W postępowaniu przed sądem, w odniesieniu do tych 
materiałów, stosuje się odpowiednio art. 393 § 1 zdanie pierwsze Kodeksu 
postępowania karnego. 
8. Zgromadzone podczas stosowania czynności, o których mowa w ust. 1 i 2, 
materiały niezawierające dowodów pozwalających na wszczęcie postępowania 
karnego lub dowodów mających znaczenie dla toczącego się postępowania karnego 
podlegają niezwłocznemu, protokolarnemu i komisyjnemu zniszczeniu. Zniszczenie 
materiałów zarządza organ Policji, który wnioskował o zarządzenie czynności. 
8a. O wydaniu i wykonaniu zarządzenia dotyczącego zniszczenia materiałów, o 
których mowa w ust. 8, organ Policji jest obowiązany do niezwłocznego 
poinformowania prokuratora, o którym mowa w ust. 3. 
9. Minister właściwy do spraw wewnętrznych, w porozumieniu z Ministrem 
Sprawiedliwości, określi, w drodze rozporządzenia, sposób przeprowadzania i 
dokumentowania czynności, o których mowa w ust. 1 i 2, a także przekazywania, 
przetwarzania i niszczenia materiałów uzyskanych podczas stosowania tych 
czynności, 
uwzględniając 
potrzebę 
zapewnienia 
niejawnego 
charakteru 
podejmowanych czynności i uzyskanych materiałów oraz wzory stosowanych druków 
i rejestrów.

***
## Art. 19b. {#policja-art-19b}

1. W celu udokumentowania przestępstw, o których mowa w art. 19 
ust. 1, albo ustalenia tożsamości osób uczestniczących w tych przestępstwach lub 
przejęcia przedmiotów przestępstwa Komendant Główny Policji, Komendant CBŚP, 
Komendant BSWP, Komendant CBZC albo komendant wojewódzki Policji może 
zarządzić niejawne nadzorowanie wytwarzania, przemieszczania, przechowywania i 
obrotu przedmiotami przestępstwa, jeżeli nie stworzy to zagrożenia dla życia lub 
zdrowia ludzkiego. 
2. O zarządzeniu, o którym mowa w ust. 1, zawiadamia się niezwłocznie 
prokuratora okręgowego, właściwego ze względu na siedzibę zarządzającego 

 
 
 
s. 67/274 
 
2025-07-03 
 
dokonanie czynności organu Policji. Prokurator może nakazać zaniechanie czynności 
w każdym czasie. 
2a. Zarządzenia, o których mowa w ust. 1, oraz informacja o nakazie zaniechania 
czynności, o którym mowa w ust. 2, w odniesieniu do spraw realizowanych przez 
BSWP, Komendant BSWP przekazuje do wiadomości Inspektora Nadzoru 
Wewnętrznego. 
3. Organ Policji, o którym mowa w ust. 1, bieżąco informuje prokuratora 
okręgowego o wynikach przeprowadzonych czynności. 
4. Stosownie do zarządzenia, o którym mowa w ust. 1, organy i instytucje 
publiczne oraz przedsiębiorcy są obowiązani dopuścić do dalszego przewozu przesyłki 
zawierające przedmioty przestępstwa w stanie nienaruszonym lub po ich usunięciu 
albo zastąpieniu w całości lub w części. 
5. W przypadku uzyskania dowodów pozwalających na wszczęcie postępowania 
karnego lub mających znaczenie dla toczącego się postępowania karnego Komendant 
Główny Policji, Komendant CBŚP, Komendant BSWP, Komendant CBZC albo 
komendant wojewódzki Policji przekazuje prokuratorowi, o którym mowa w ust. 2, 
wszystkie materiały zgromadzone podczas stosowania czynności, o których mowa w 
ust. 1. W postępowaniu przed sądem, w odniesieniu do tych materiałów, stosuje się 
odpowiednio art. 393 § 1 zdanie pierwsze Kodeksu postępowania karnego. 
6. Minister właściwy do spraw wewnętrznych, w porozumieniu z Ministrem 
Sprawiedliwości, określi, w drodze rozporządzenia, sposób przeprowadzania i 
dokumentowania czynności, o których mowa w ust. 1, uwzględniając potrzebę 
zapewnienia niejawnego charakteru podejmowanych czynności i uzyskanych 
materiałów oraz wzory stosowanych druków i rejestrów.

***
## Art. 20. {#policja-art-20}

1. W celu realizacji zadań ustawowych Policja jest uprawniona do 
przetwarzania informacji, w tym danych osobowych, z zachowaniem ograniczeń 
wynikających z art. 19. 
1a. Przetwarzanie oraz wymiana informacji, w tym danych osobowych, może 
dotyczyć danych osobowych, o których mowa w art. 14 ust. 1 ustawy z dnia 14 grudnia 
2018 r. o ochronie danych osobowych przetwarzanych w związku z zapobieganiem i 
zwalczaniem przestępczości, przy czym dane dotyczące wyników analizy kwasu 
deoksyrybonukleinowego (DNA) obejmują informacje wyłącznie o niekodującej 
części DNA. 

 
 
 
s. 68/274 
 
2025-07-03 
 
1aa.2) W celu realizacji zadań, o których mowa w art. 1 ust. 2, oraz w celu 
realizacji zadań wynikających z innych ustaw, jeżeli jest to niezbędne do 
jednoznacznej identyfikacji lub ustalenia tożsamości osoby, Policja jest 
uprawniona do korzystania z danych biometrycznych w postaci wizerunków 
twarzy lub danych daktyloskopijnych, do ich uzyskiwania oraz przetwarzania w 
zakresie identyfikacji lub weryfikacji tożsamości osoby, której dotyczą te zadania 
lub wykonywane czynności, o których mowa w art. 14 ust. 1 i 2, a także w zakresie 
niezbędnym do realizacji celów wykrywczych lub dowodowych, jeżeli zadania 
Policji dotyczą celów określonych w art. 1 pkt 1 ustawy z dnia 14 grudnia 2018 r. 
o ochronie danych osobowych przetwarzanych w związku z zapobieganiem i 
zwalczaniem przestępczości.  
1ab.3) W celu oraz w zakresie niezbędnym do realizacji ustawowych zadań 
Policja może korzystać z informacji oraz przetwarzać informacje, w tym dane 
osobowe, przetwarzane w systemach informacyjnych Unii Europejskiej, 
w szczególności w Systemie Wjazdu/Wyjazdu (EES), Wizowym Systemie 
Informacyjnym (VIS), Europejskim Systemie Informacji o Podróży oraz 
Zezwoleń na Podróż (ETIAS), Systemie Eurodac, Systemie Informacyjnym 
Schengen (SIS) oraz Europejskim systemie przekazywania informacji z rejestrów 
karnych o obywatelach państw trzecich (ECRIS-TCN), w tym za pomocą 
ustanowionych przepisami prawa Unii Europejskiej narzędzi interoperacyjności, 
takich jak europejski portal wyszukiwania, wspólny system porównywania 
danych biometrycznych, wspólne repozytorium danych umożliwiających 
identyfikację i detektor wielokrotnych tożsamości – w przypadkach określonych 
w przepisach prawa Unii Europejskiej i zgodnie z tymi przepisami. 
 
2) Dodany ust. 1aa w art. 20 wejdzie w życie z dniem określonym w decyzji Komisji Europejskiej, 
zgodnie z art. 66 ust. 1 rozporządzenia Parlamentu Europejskiego i Rady (UE) 2017/2226 z dnia 30 
listopada 2017 r. ustanawiającego system wjazdu/wyjazdu (EES) w celu rejestrowania danych 
dotyczących wjazdu i wyjazdu obywateli państw trzecich przekraczających granice zewnętrzne 
państw członkowskich i danych dotyczących odmowy wjazdu w odniesieniu do takich obywateli oraz 
określającego warunki dostępu do EES na potrzeby ochrony porządku publicznego i zmieniającego 
konwencję wykonawczą do układu z Schengen i rozporządzenia (WE) nr 767/2008 i (UE) nr 
1077/2011. 
3) Dodany ust. 1ab w art. 20 w części dotyczącej dostępu do systemu ECRIS-TCN wejdzie w życie z 
dniem określonym w decyzji Komisji Europejskiej zgodnie z art. 35 ust. 5 rozporządzenia 
Parlamentu Europejskiego i Rady (UE) 2019/816 z dnia 17 kwietnia 2019 r. ustanawiającego 
scentralizowany system służący do ustalania państw członkowskich posiadających informacje o 
wyrokach skazujących wydanych wobec obywateli państw trzecich i bezpaństwowców (ECRIS-
TCN) na potrzeby uzupełnienia europejskiego systemu przekazywania informacji z rejestrów 
karnych oraz zmieniającego rozporządzenie (UE) 2018/1726. 

 
 
 
s. 69/274 
 
2025-07-03 
 
1b. Uzyskiwanie informacji, w tym danych osobowych, może odbywać się z 
wykorzystaniem środków technicznych. 
1c. Policja jest uprawniona do przetwarzania informacji, w tym danych 
osobowych, w zakresie niezbędnym do realizacji zadań ustawowych lub 
wykonywania 
uprawnień 
związanych 
z 
prowadzeniem 
postępowań 
administracyjnych, realizacją czynności administracyjno-porządkowych oraz innych 
czynności, do przeprowadzania których funkcjonariusze Policji są uprawnieni na 
podstawie ustaw, w celach innych niż określone w art. 1 pkt 1 ustawy z dnia 14 grudnia 
2018 r. o ochronie danych osobowych przetwarzanych w związku z zapobieganiem i 
zwalczaniem przestępczości, w tym ma prawo przetwarzać dane osobowe, o których 
mowa w art. 9 i art. 10 rozporządzenia Parlamentu Europejskiego i Rady (UE) 
2016/679 z dnia 27 kwietnia 2016 r. w sprawie ochrony osób fizycznych w związku z 
przetwarzaniem danych osobowych i w sprawie swobodnego przepływu takich danych 
oraz uchylenia dyrektywy 95/46/WE (ogólne rozporządzenie o ochronie danych 
osobowych) (Dz. Urz. UE L 119 z 04.05.2016, str. 1, z późn. zm.4)), zwanego dalej 
„rozporządzeniem (UE) 2016/679”, z wyłączeniem danych dotyczących kodu 
genetycznego. 
1d. Policja w zakresie swojej właściwości przetwarza informacje, w tym dane 
osobowe, uzyskane ze zbiorów danych prowadzonych przez inne służby, instytucje 
państwowe oraz organy władzy publicznej. Przetwarzanie informacji, w tym danych 
osobowych, przez Policję może mieć charakter niejawny, odbywać się bez zgody i 
wiedzy, osoby której dane dotyczą, oraz z wykorzystaniem środków technicznych. 
Służby, instytucje państwowe oraz organy władzy publicznej są obowiązane do 
nieodpłatnego udostępnienia Policji informacji, w tym danych osobowych. W 
szczególności Policja jest uprawniona do uzyskiwania informacji, w tym danych 
osobowych: 
1) 
gromadzonych w administrowanych przez nich zbiorach danych lub rejestrach; 
2) 
uzyskanych przez te służby lub organy w wyniku wykonywania czynności 
operacyjno-rozpoznawczych, w tym prowadzonej kontroli operacyjnej. 
1e. Podmioty, o których mowa w ust. 1d, mogą wyrazić pisemną zgodę na 
udostępnianie 
danych 
zgromadzonych 
w zbiorach 
danych 
jednostkom 
organizacyjnym Policji w drodze teletransmisji, bez konieczności składania wniosku 
 
4) Zmiana wymienionego rozporządzenia została ogłoszona w Dz. Urz. UE L 127 z 23.05.2018, str. 2. 

 
 
 
s. 70/274 
 
2025-07-03 
 
pisemnie w postaci papierowej lub elektronicznej, jeżeli jednostki te spełniają łącznie 
następujące warunki: 
1) 
posiadają urządzenia umożliwiające odnotowanie w systemie, kto, kiedy, w 
jakim celu oraz jakie dane uzyskał; 
2) 
posiadają zabezpieczenia techniczne i organizacyjne uniemożliwiające 
wykorzystanie danych niezgodnie z celem ich uzyskania; 
3) 
jest to uzasadnione specyfiką lub zakresem wykonywanych zadań albo 
prowadzonej działalności. 
1f. Komendant Główny Policji, Komendant CBŚP, Komendant BSWP, 
Komendant CBZC, Dyrektor CLKP, komendanci wojewódzcy Policji, Komendant 
Stołeczny 
Policji, 
komendanci 
powiatowi 
(miejscy 
i rejonowi) 
Policji, 
Komendant-Rektor Akademii Policji w Szczytnie oraz komendanci szkół policyjnych 
są administratorami danych osobowych w stosunku do zbiorów danych osobowych 
utworzonych przez nich w celu realizacji zadań ustawowych. 
1g. Kierownicy jednostek organizacyjnych Policji, o których mowa w ust. 1f, 
mogą tworzyć lub likwidować w drodze decyzji systemy, zbiory danych lub zestawy 
zbiorów danych, inne niż określone w niniejszej ustawie, w których przetwarza się 
informacje, w tym dane osobowe, w celu realizacji przez Policję zadań ustawowych. 
1h. W przypadku likwidowania systemów, zbiorów danych lub zestawów 
zbiorów informacji, w tym danych osobowych, dokonuje tego komisja wyznaczana 
przez kierowników jednostek organizacyjnych Policji, o których mowa w ust. 1f, z 
czego sporządza się protokół. 
1i. Kierownicy jednostek organizacyjnych Policji, o których mowa w ust. 1f, 
prowadzą rejestr systemów, zbiorów danych lub zestawów zbiorów danych, w których 
przetwarza się informacje, w tym dane osobowe. 
1j. Przetwarzanie danych osobowych przez Policję w celach, o których mowa w 
art. 1 pkt 1 ustawy z dnia 14 grudnia 2018 r. o ochronie danych osobowych 
przetwarzanych w związku z zapobieganiem i zwalczaniem przestępczości, odbywa 
się na podstawie ustawy, prawa Unii Europejskiej oraz postanowień umów 
międzynarodowych. 
1k. W przypadku podejrzanych Policja pobiera wymazy ze śluzówki policzków 
oraz dane osobowe, o których mowa w art. 21a ust. 2 pkt 2 lit. b–h i art. 21h ust. 2 pkt 
2 i 3, w celach, o których mowa w art. 15 ust. 1 pkt 3a lit. d. 

 
 
 
s. 71/274 
 
2025-07-03 
 
1l. Policja pobiera odciski linii papilarnych lub wymazy ze śluzówki policzków 
od funkcjonariuszy i pracowników Policji wykonujących służbowe czynności 
związane z ujawnianiem, zabezpieczaniem lub badaniem śladów związanych 
z podejrzeniem popełnienia czynu zabronionego w celach wyeliminowania 
pozostawionych przez nich śladów. 
1m. Minister właściwy do spraw wewnętrznych określi, w drodze 
rozporządzenia, tryb pobierania odcisków linii papilarnych lub wymazów ze śluzówki 
policzków od funkcjonariuszy i pracowników Policji oraz sposób przeprowadzania i 
dokumentowania czynności związanych z ich pobieraniem, a także rodzaje służb 
policyjnych uprawnionych do korzystania ze zbiorów danych zawierających odciski 
linii papilarnych lub wymazy ze śluzówki policzków od funkcjonariuszy i 
pracowników Policji oraz sposób zabezpieczenia tych zbiorów uniemożliwiający 
identyfikację funkcjonariusza lub pracownika Policji, których dane dotyczą, przez 
osobę nieupoważnioną, uwzględniając konieczność wyeliminowania pozostawionych 
przez nich śladów. 
1n. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
wzory dokumentów obowiązujących przy przetwarzaniu danych, uwzględniając 
potrzebę ochrony danych przed nieuprawnionym dostępem i przesłanki zaniechania 
zbierania określonych rodzajów informacji, a w przypadku wymiany informacji – 
uwzględniając konieczność dostosowania się do wymogów określonych przez organy 
innych państw, zobowiązania międzynarodowe Rzeczypospolitej Polskiej lub przez 
Międzynarodową Organizację Policji Kryminalnej – Interpol. 
1o. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
wzory kart daktyloskopijnych, na których dane daktyloskopijne są pobierane przez 
upoważnione podmioty i przekazywane Komendantowi Głównemu Policji w celu 
przetwarzania w zbiorach danych daktyloskopijnych, oraz tryb i sposób ich 
przekazywania Komendantowi Głównemu Policji przez obowiązane do tego służby, 
instytucje państwowe oraz organy władzy publicznej – uwzględniając charakter 
realizowanych zadań i celów przeznaczenia danej karty daktyloskopijnej. 
2. (uchylony) 
2a. (uchylony) 
2aa. W celu realizacji zadań ustawowych Policja jest uprawniona do wymiany 
informacji, w tym danych osobowych, z organami ścigania państw członkowskich 
Unii Europejskiej i innych państw, agencjami Unii Europejskiej zajmującymi się 

 
 
 
s. 72/274 
 
2025-07-03 
 
zapobieganiem i zwalczaniem przestępczości, Międzynarodową Organizacją Policji 
Kryminalnej – Interpol oraz innymi organizacjami międzynarodowymi na zasadach i 
warunkach określonych w przepisach odrębnych, prawie Unii Europejskiej oraz 
umowach międzynarodowych. 
2ab. Policja jest uprawniona do przetwarzania i wymiany informacji, w tym 
danych osobowych osób ubiegających się o przyjęcie do pracy w agencjach Unii 
Europejskiej zajmujących się zapobieganiem lub zwalczaniem czynów zabronionych, 
międzynarodowych organach sądowniczych, międzynarodowych organach ścigania 
oraz w Międzynarodowej Organizacji Policji Kryminalnej – Interpol, za zgodą tych 
osób. Policja, przekazując wyniki przetwarzania, zastrzega, że nie udostępnia się ich 
osobie, której dane osobowe dotyczą. 
2ac. (uchylony) 
2ad. 
Policja 
może 
pobierać, 
uzyskiwać, 
gromadzić, 
przetwarzać 
i 
wykorzystywać informacje w celu realizacji zadań ustawowych, w tym dane osobowe, 
o następujących osobach, także bez ich wiedzy i zgody: 
1) 
wskazanych we wniosku złożonym na podstawie Konwencji dotyczącej 
cywilnych aspektów uprowadzenia dziecka za granicę, sporządzonej w Hadze 
dnia 25 października 1980 r. (Dz. U. z 1995 r. poz. 528 oraz z 1999 r. poz. 1085), 
zwanej dalej „konwencją haską z 1980 r.”, które uprowadziły osobę podlegającą 
władzy rodzicielskiej lub pozostającą pod opieką lub które osobę tę zatrzymały 
lub ją ukrywają; 
2) 
zobowiązanych postanowieniem sądu o odebraniu osoby podlegającej władzy 
rodzicielskiej lub pozostającej pod opieką do jego wykonania, w przypadkach 
gdy sąd lub inny uprawniony organ zwrócił się do Policji o ustalenie miejsca 
pobytu osoby podlegającej odebraniu na podstawie tego postanowienia; 
3) 
uprowadzonych lub zatrzymanych w rozumieniu konwencji haskiej z 1980 r. lub 
podlegających odebraniu na podstawie postanowienia, o którym mowa w pkt 2. 
2b. Informacje, o których mowa w ust. 1 i 2aa, mogą obejmować: 
1) 
dane osobowe, o których mowa w art. 14 ust. 1 ustawy z dnia 14 grudnia 2018 r. 
o ochronie danych osobowych przetwarzanych w związku z zapobieganiem i 
zwalczaniem przestępczości, z tym że dane dotyczące kodu genetycznego 
obejmują informacje wyłącznie o niekodującej części DNA; 
2) 
odciski linii papilarnych; 
3) 
zdjęcia, szkice i opisy wizerunku; 

 
 
 
s. 73/274 
 
2025-07-03 
 
4) 
cechy i znaki szczególne, pseudonimy; 
5) 
informacje o: 
a) 
miejscu zamieszkania lub pobytu, 
b) 
wykształceniu, zawodzie, miejscu i stanowisku pracy oraz sytuacji 
materialnej i stanie majątku, 
c) 
dokumentach i przedmiotach, którymi sprawca się posługuje, 
d) 
sposobie działania sprawcy, jego środowisku i kontaktach, 
e) 
sposobie zachowania się sprawcy wobec osób pokrzywdzonych. 
2ba. Zakres informacji o osobach, o których mowa w: 
1) 
ust. 2ad pkt 1 i 2 – obejmuje informacje, o których mowa w art. 20 ust. 2b, 
informacje o wniosku złożonym na podstawie konwencji haskiej z 1980 r. lub 
postanowieniu, o którym mowa w ust. 2ad pkt 2, lub o innych orzeczeniach 
dotyczących uprowadzenia, zatrzymania lub ukrywania osoby podlegającej 
władzy rodzicielskiej lub pozostającej pod opieką, a także dane osób, o których 
mowa w ust. 2ad pkt 3, i informacje o stopniu ich pokrewieństwa z tymi osobami; 
2) 
ust. 2ad pkt 3 – obejmuje informacje, o których mowa w art. 20 ust. 2b pkt 1–3 i 
pkt 5 lit. a, oraz informacje o numerach PESEL lub numerach dokumentów 
pozwalających na ustalenie tożsamości, dokumentach i przedmiotach 
dotyczących tych osób, stopniu ich pokrewieństwa z osobami, o których mowa 
w ust. 2ad pkt 1 i 2, dane osób, o których mowa w ust. 2ad pkt 1 i 2, a także 
informacje o wniosku złożonym na podstawie konwencji haskiej z 1980 r. lub 
postanowieniu, o którym mowa w ust. 2ad pkt 2, lub o innych orzeczeniach 
dotyczących uprowadzenia, zatrzymania lub ukrywania osoby podlegającej 
władzy rodzicielskiej lub pozostającej pod opieką oraz informacje o 
dyspozycjach dotyczących tych osób. 
2c. Danych osobowych, o których mowa w art. 14 ust. 1 ustawy z dnia 14 grudnia 
2018 r. o ochronie danych osobowych przetwarzanych w związku z zapobieganiem i 
zwalczaniem przestępczości, nie pobiera się, w przypadku gdy nie mają one 
przydatności wykrywczej, dowodowej lub identyfikacyjnej. 
3. Jeżeli jest to konieczne do skutecznego zapobieżenia przestępstwom, o których 
mowa w art. 19 ust. 1, lub ich wykrycia, ustalenia ich sprawców, uzyskania i 
utrwalenia dowodów, a także wykrycia i identyfikacji przedmiotów i innych korzyści 
majątkowych pochodzących z tych przestępstw albo ich równowartości, Policja może 
korzystać z informacji: 

 
 
 
s. 74/274 
 
2025-07-03 
 
1) 
stanowiących tajemnicę skarbową, przetwarzanych przez organy administracji 
rządowej i samorządu terytorialnego; 
2) 
stanowiących tajemnicę zawodową, o której mowa w art. 9e ustawy z dnia 5 
listopada 2009 r. o spółdzielczych kasach oszczędnościowo-kredytowych (Dz. 
U. z 2025 r. poz. 379); 
3) 
stanowiących tajemnicę bankową, o której mowa w ustawie z dnia 29 sierpnia 
1997 r. – Prawo bankowe (Dz. U. z 2024 r. poz. 1646, 1685 i 1863 oraz z 2025 
r. poz. 146 i 222); 
4) 
stanowiących dane indywidualne, o których mowa w art. 79 ust. 1 ustawy z dnia 
13 października 1998 r. o systemie ubezpieczeń społecznych (Dz. U. z 2025 r. 
poz. 350); 
5) 
stanowiących tajemnicę zawodową w rozumieniu ustawy z dnia 26 października 
2000 r. o giełdach towarowych (Dz. U. z 2024 r. poz. 910 i 1881); 
6) 
stanowiących tajemnicę zawodową w rozumieniu ustawy z dnia 27 maja 2004 r. 
o funduszach inwestycyjnych i zarządzaniu alternatywnymi funduszami 
inwestycyjnymi (Dz. U. z 2024 r. poz. 1034 i 1863 oraz z 2025 r. poz. 146); 
7) 
stanowiących tajemnicę zawodową w rozumieniu ustawy z dnia 29 lipca 2005 r. 
o obrocie instrumentami finansowymi; 
8) 
stanowiących tajemnicę w rozumieniu ustawy z dnia 11 września 2015 r. o 
działalności ubezpieczeniowej i reasekuracyjnej (Dz. U. z 2024 r. poz. 838, 1565 
i 1863 oraz z 2025 r. poz. 146); 
9) 
stanowiących tajemnicę w rozumieniu ustawy z dnia 28 sierpnia 1997 r. o 
organizacji i funkcjonowaniu funduszy emerytalnych (Dz. U. z 2024 r. poz. 
1113); 
10) stanowiących tajemnicę zawodową w rozumieniu ustawy z dnia 29 lipca 2005 r. 
o nadzorze nad rynkiem kapitałowym (Dz. U. z 2024 r. poz. 1161 i 1222 oraz z 
2025 r. poz. 146); 
11) stanowiących tajemnicę zawodową w rozumieniu ustawy z dnia 19 sierpnia 2011 
r. o usługach płatniczych (Dz. U. z 2024 r. poz. 30, 731 i 1222 oraz z 2025 r. poz. 
146); 
12) stanowiących tajemnicę zawodową w rozumieniu ustawy z dnia 7 lipca 2022 r. 
o finansowaniu społecznościowym dla przedsięwzięć gospodarczych i pomocy 
kredytobiorcom (Dz. U. z 2024 r. poz. 984 i 1863).  

 
 
 
s. 75/274 
 
2025-07-03 
 
4. Informacje i dane, o których mowa w ust. 3, oraz informacje związane z 
przekazywaniem tych informacji i danych podlegają ochronie przewidzianej w 
przepisach o ochronie informacji niejawnych i mogą być udostępniane jedynie 
policjantom prowadzącym czynności w danej sprawie i ich przełożonym, 
uprawnionym do sprawowania nadzoru nad prowadzonymi przez nich w tej sprawie 
czynnościami operacyjno-rozpoznawczymi. Akta zawierające te informacje i dane 
udostępnia się ponadto wyłącznie sądom i prokuratorom, jeżeli następuje to w celu 
ścigania karnego. Informacje i dane udostępnia się także organom ścigania państw 
członkowskich Unii Europejskiej, agencjom Unii Europejskiej zajmującym się 
zapobieganiem i zwalczaniem przestępczości oraz Międzynarodowej Organizacji 
Policji Kryminalnej – Interpol, jeżeli następuje to w celu ścigania karnego. 
5. Informacje i dane, o których mowa w ust. 3, udostępnia się nieodpłatnie na 
podstawie postanowienia wydanego na pisemny wniosek Komendanta Głównego 
Policji, Komendanta CBŚP, Komendanta BSWP, Komendanta CBZC albo 
komendanta wojewódzkiego Policji przez sąd okręgowy właściwy miejscowo ze 
względu na siedzibę wnioskującego organu. 
5a. Informacje i dane, o których mowa w ust. 3: 
1) 
dotyczące dokumentacji związanej z nadaniem NIP oraz aktualizowaniem 
danych zawartych w zgłoszeniach identyfikacyjnych, określonej w art. 13 ust. 1 
ustawy z dnia 13 października 1995 r. o zasadach ewidencji i identyfikacji 
podatników i płatników (Dz. U. z 2025 r. poz. 237), 
2) 
zawarte w aktach niezawierających informacji, o których mowa w art. 182 
ustawy z dnia 29 sierpnia 1997 r. – Ordynacja podatkowa (Dz. U. z 2025 r. poz. 
111), 
3) 
dotyczące zawarcia z osobą fizyczną, prawną lub jednostką organizacyjną 
nieposiadającą osobowości prawnej umowy o wykonywanie czynności, o 
których mowa w art. 5 ustawy z dnia 29 sierpnia 1997 r. – Prawo bankowe, lub 
czynności, o których mowa w art. 3 ustawy z dnia 5 listopada 2009 r. o 
spółdzielczych 
kasach 
oszczędnościowo-kredytowych, 
umożliwiające 
weryfikację zawarcia takich umów i czasu ich obowiązywania, a także dane 
teleadresowe umożliwiające nawiązanie kontaktu z tą osobą fizyczną, prawną lub 
jednostką organizacyjną nieposiadającą osobowości prawnej, 
4) 
dotyczące 
objęcia 
osoby 
fizycznej 
ubezpieczeniem 
społecznym 
i 
zwaloryzowanej wysokości składek na ubezpieczenie emerytalne osoby 

 
 
 
s. 76/274 
 
2025-07-03 
 
fizycznej, a także dane płatnika składek, o których mowa w art. 40, art. 45 i art. 
50 ustawy z dnia 13 października 1998 r. o systemie ubezpieczeń społecznych, 
5) 
niezbędne do ustalenia, czy osoba fizyczna lub prawna, a także podmiot 
nieposiadający osobowości prawnej dokonywała transakcji dotyczących 
towarów giełdowych, o których mowa w ustawie z dnia 26 października 2000 r. 
o giełdach towarowych, 
6) 
niezbędne do ustalenia, czy osoba fizyczna lub prawna, a także podmiot 
nieposiadający osobowości prawnej, jest uczestnikiem funduszu inwestycyjnego, 
o którym mowa w ustawie z dnia 27 maja 2004 r. o funduszach inwestycyjnych 
i zarządzaniu alternatywnymi funduszami inwestycyjnymi, 
7) 
dotyczące ustalenia, czy osoba fizyczna lub prawna, a także podmiot 
nieposiadający osobowości prawnej jest stroną umowy dotyczącej obrotu 
instrumentami finansowymi, o której mowa w ustawie z dnia 29 lipca 2005 r. o 
obrocie instrumentami finansowymi, 
8) 
dotyczące ustalenia, czy osoba fizyczna lub prawna, a także podmiot 
nieposiadający osobowości prawnej jest ubezpieczającym, ubezpieczonym lub 
uprawnionym z umowy ubezpieczenia w rozumieniu przepisów ustawy z dnia 11 
września 2015 r. o działalności ubezpieczeniowej i reasekuracyjnej, 
9) 
dotyczące zawarcia z osobą fizyczną, prawną lub jednostką organizacyjną 
nieposiadającą osobowości prawnej umowy o świadczenie usług płatniczych, o 
których mowa w art. 3 ustawy z dnia 19 sierpnia 2011 r. o usługach płatniczych, 
umożliwiające weryfikację zawarcia takich umów i czasu ich obowiązywania, a 
także dane teleadresowe umożliwiające nawiązanie kontaktu z tą osobą fizyczną, 
prawną lub jednostką organizacyjną nieposiadającą osobowości prawnej, 
10) dotyczące ustalenia, czy osoba fizyczna lub prawna, a także podmiot 
nieposiadający osobowości prawnej jest klientem usługi finansowania 
społecznościowego, o której mowa w art. 2 ust. 1 lit. a rozporządzenia 
Parlamentu Europejskiego i Rady (UE) 2020/1503 z dnia 7 października 2020 r. 
w sprawie europejskich dostawców usług finansowania społecznościowego dla 
przedsięwzięć gospodarczych oraz zmieniającego rozporządzenie (UE) 
2017/1129 i dyrektywę (UE) 2019/1937 (Dz. Urz. UE L 347 z 20.10.2020, str. 
1)  
– udostępnia się nieodpłatnie, w formie pisemnej lub za pomocą środków komunikacji 
elektronicznej, na wniosek Komendanta Głównego Policji, Komendanta CBŚP, 

 
 
 
s. 77/274 
 
2025-07-03 
 
Komendanta BSWP, Komendanta CBZC albo komendanta wojewódzkiego Policji lub 
upoważnionych przez nich pisemnie funkcjonariuszy. 
6. Wniosek, o którym mowa w ust. 5, powinien zawierać: 
1) 
numer sprawy i jej kryptonim, jeżeli został ustalony; 
2) 
opis przestępstwa z podaniem, w miarę możliwości, jego kwalifikacji prawnej; 
3) 
okoliczności uzasadniające potrzebę udostępnienia informacji i danych; 
4) 
wskazanie podmiotu, którego informacje i dane dotyczą; 
5) 
podmiot zobowiązany do udostępnienia informacji i danych; 
6) 
rodzaj i zakres informacji i danych. 
6a. Wniosek, o którym mowa w ust. 5a, powinien zawierać informacje określone 
w ust. 6 pkt 1, 2 i 4–6. 
7. Po rozpatrzeniu wniosku, o którym mowa w ust. 5, sąd, w drodze 
postanowienia, wyraża zgodę na udostępnienie informacji i danych wskazanego 
podmiotu, określając ich rodzaj i zakres, podmiot zobowiązany do ich udostępnienia 
oraz organ Policji uprawniony do zwrócenia się o przekazanie informacji i danych albo 
odmawia udzielenia zgody na udostępnienie informacji i danych. Przepis art. 19 ust. 
11 stosuje się odpowiednio. 
8. Na postanowienie sądu, o którym mowa w ust. 7, przysługuje zażalenie 
organowi Policji, wnioskującemu o wydanie postanowienia. 
9. Uprawniony przez sąd organ Policji pisemnie informuje podmiot zobowiązany 
do udostępnienia informacji i danych o rodzaju i zakresie informacji i danych, które 
mają być udostępnione, podmiocie, którego informacje i dane dotyczą, oraz o osobie 
policjanta upoważnionego do ich odbioru. 
10. W terminie do 90 dni od dnia przekazania informacji i danych, o których 
mowa w ust. 3, Policja, z zastrzeżeniem ust. 11 i 12, informuje podmiot, o którym 
mowa w ust. 6 pkt 4, o postanowieniu sądu wyrażającym zgodę na udostępnienie 
informacji i danych. 
11. Sąd, który wydał postanowienie o udostępnieniu informacji i danych, na 
wniosek Komendanta Głównego Policji, Komendanta CBŚP, Komendanta BSWP 
albo Komendanta CBZC, złożony po uzyskaniu pisemnej zgody Pierwszego Zastępcy 
Prokuratora Generalnego Prokuratora Krajowego, może zawiesić, w drodze 
postanowienia, na czas oznaczony, z możliwością dalszego przedłużania, obowiązek, 
o którym mowa w ust. 10, jeżeli zostanie uprawdopodobnione, że poinformowanie 
podmiotu, o którym mowa w ust. 6 pkt 4, może zaszkodzić wynikom podjętych 

 
 
 
s. 78/274 
 
2025-07-03 
 
czynności operacyjno-rozpoznawczych. Przepis art. 19 ust. 11 stosuje się 
odpowiednio. 
12. Jeżeli w okresie, o którym mowa w ust. 10 lub 11, zostało wszczęte 
postępowanie przygotowawcze, podmiot wskazany w ust. 6 pkt 4 jest powiadamiany 
o postanowieniu sądu o udostępnieniu informacji i danych przez prokuratora lub, na 
jego polecenie, przez Policję przed zamknięciem postępowania przygotowawczego 
albo niezwłocznie po jego umorzeniu. 
13. Jeżeli informacje i dane, o których mowa w ust. 3, nie dostarczyły podstaw 
do wszczęcia postępowania przygotowawczego, organ wnioskujący o wydanie 
postanowienia pisemnie zawiadamia o tym podmiot, który informacje i dane 
przekazał. 
14. Skarb Państwa ponosi odpowiedzialność za szkody wyrządzone naruszeniem 
przepisów ust. 4 na zasadach określonych w Kodeksie cywilnym. 
15. (uchylony) 
16. (uchylony)  
16a. (uchylony)  
17. (uchylony)  
17a. (uchylony) 
17b. (uchylony) 
17c. (uchylony) 
17d. (uchylony) 
18. (uchylony) 
19. (uchylony)

***
## Art. 20a. {#policja-art-20a}

1. W związku z wykonywaniem zadań wymienionych w art. 1 ust. 2 
Policja zapewnia ochronę form i metod realizacji zadań, informacji oraz własnych 
obiektów i danych identyfikujących policjantów. 
1a. Ochrona, o której mowa w ust. 1, może być realizowana przez obserwowanie 
i rejestrowanie wykonywanych zadań służbowych, obiektów Policji i policyjnych 
środków transportu. 
2. Przy wykonywaniu czynności operacyjno-rozpoznawczych policjanci mogą 
posługiwać się dokumentami publicznymi w rozumieniu ustawy z dnia 22 listopada 
2018 r. o dokumentach publicznych (Dz. U. z 2024 r. poz. 1669 i 1863) lub innymi 

 
 
 
s. 79/274 
 
2025-07-03 
 
dokumentami, które uniemożliwiają ustalenie danych identyfikujących policjanta oraz 
środków, którymi posługuje się przy wykonywaniu zadań służbowych. 
2a. Przy wykonywaniu czynności operacyjno-rozpoznawczych policjanci mogą 
posługiwać się środkami identyfikacji elektronicznej zawierającymi dane inne niż 
dane identyfikujące policjanta. 
3. W szczególnie uzasadnionych przypadkach przepisy ust. 2 i 2a mogą mieć 
zastosowanie do osób, o których mowa w art. 22 ust. 1. 
3a. Nie popełnia przestępstwa: 
1) 
kto poleca sporządzenie lub kieruje sporządzeniem dokumentów lub 
wydawaniem środków identyfikacji elektronicznej, o których mowa w ust. 2, 2a 
i 3; 
2) 
kto sporządza dokumenty lub wydaje środki identyfikacji elektronicznej, o 
których mowa w ust. 2, 2a i 3; 
3) 
kto udziela pomocy w sporządzeniu dokumentów lub wydawaniu środków 
identyfikacji elektronicznej, o których mowa w ust. 2, 2a i 3; 
4) 
policjant lub osoba wymieniona w ust. 3, jeżeli dokumentami lub środkami 
identyfikacji elektronicznej, o których mowa w ust. 2, 2a i 3, posługują się przy 
wykonywaniu czynności operacyjno-rozpoznawczych; 
5) 
kto wydaje środki identyfikacji elektronicznej, o których mowa w ust. 2a, 
policjantowi albo osobom, o których mowa w ust. 3, lub dopuszcza do 
uwierzytelnienia z wykorzystaniem takiego środka identyfikacji elektronicznej 
w swoim systemie identyfikacji elektronicznej. 
3b. Organy administracji rządowej i organy samorządu terytorialnego 
obowiązane są do udzielania Policji, w granicach swojej właściwości, niezbędnej 
pomocy w zakresie wydawania i zabezpieczania dokumentów, o których mowa w ust. 
2 i 3. 
4. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
szczegółowe zasady i tryb wydawania, posługiwania się, a także przechowywania 
dokumentów, o których mowa w ust. 2 i 3, uwzględniając rodzaje dokumentów i cel, 
w jakim są wydawane, organy i osoby uprawnione do wydawania, posługiwania się i 
przechowywania dokumentów, czas, na jaki wydawane są dokumenty, czynności 
zapewniające ochronę dokumentów oraz ich sposób przechowywania i ewidencji. 

 
 
 
s. 80/274 
 
2025-07-03

***
## Art. 20b. {#policja-art-20b}

1. Udzielenie informacji o prowadzonych czynnościach operacyjno-
-rozpoznawczych oraz o stosowanych środkach i metodach ich realizacji może 
nastąpić: 
1) 
w przypadku gdy istnieje uzasadnione podejrzenie popełnienia przestępstwa 
ściganego z oskarżenia publicznego w związku z wykonywaniem tych 
czynności; 
2) 
w związku ze współpracą prowadzoną z innymi organami, służbami lub 
instytucjami państwowymi uprawnionymi do wykonywania czynności 
operacyjno-rozpoznawczych, w tym także w związku z prowadzoną współpracą 
z organami i służbami innych państw w trybie i zakresie określonym w umowach 
i porozumieniach międzynarodowych. 
2. Udzielenie informacji o osobie, uzyskanych w czasie wykonywania czynności 
operacyjno-rozpoznawczych oraz w trybie, o którym mowa w art. 14 ust. 4, może 
nastąpić: 
1) 
na żądanie sądu lub prokuratora, a wykorzystanie tych informacji może nastąpić 
tylko w celu ścigania karnego; 
2) 
w przypadku gdy ustawa nakłada obowiązek udzielenia lub umożliwia udzielenie 
takich informacji określonemu organowi albo obowiązek taki wynika z umów 
lub porozumień międzynarodowych, a także w przypadku gdy zatajenie takiej 
informacji prowadziłoby do zagrożenia życia lub zdrowia innych osób. 
3. Udzielenie informacji o szczegółowych formach, zasadach i organizacji 
czynności operacyjno-rozpoznawczych może nastąpić w szczególnie uzasadnionych 
przypadkach. 
4. W przypadkach wymienionych w ust. 1 pkt 1, ust. 2 pkt 1 i ust. 3 udzielenie 
informacji następuje w trybie określonym w art. 20ba.

***
## Art. 20ba. {#policja-art-20ba}

1. Komendant Główny Policji może zezwalać: 
1) 
byłym i obecnym funkcjonariuszom i pracownikom Policji, z wyłączeniem 
przypadków, o których mowa w ust. 5, 
2) 
osobom oddelegowanym do Policji, w zakresie zadań realizowanych w okresie 
oddelegowania, 
3) 
osobom udzielającym funkcjonariuszom Policji pomocy w wykonywaniu 
czynności operacyjno-rozpoznawczych 

 
 
 
s. 81/274 
 
2025-07-03 
 
– na udzielenie wiadomości stanowiącej informację niejawną uprawnionemu 
podmiotowi. 
2. Zezwolenie, o którym mowa w ust. 1, nie dotyczy sytuacji, o których mowa w 
art. 19, art. 19a, art. 19b, art. 20b ust. 1 pkt 2 i ust. 2 pkt 2 oraz art. 20c, z wyjątkiem 
dokumentów i materiałów, które sąd okręgowy lub prokurator Biura Lustracyjnego 
lub oddziałowego biura lustracyjnego Instytutu Pamięci Narodowej – Komisji 
Ścigania Zbrodni przeciwko Narodowi Polskiemu uzna za niezbędne w związku z 
wykonywaniem ich zadań określonych w ustawie z dnia 18 października 2006 r. o 
ujawnianiu informacji o dokumentach organów bezpieczeństwa państwa z lat 1944–
1990 oraz treści tych dokumentów (Dz. U. z 2024 r. poz. 1632, 1897 i 1940) oraz 
ustawie z dnia 18 grudnia 1998 r. o Instytucie Pamięci Narodowej – Komisji Ścigania 
Zbrodni przeciwko Narodowi Polskiemu (Dz. U. z 2023 r. poz. 102). 
3. W razie odmowy zezwolenia na udzielenie wiadomości stanowiącej 
informację niejawną o klauzuli „tajne” lub „ściśle tajne” pomimo żądania prokuratora 
lub sądu, zgłoszonego w związku z postępowaniem karnym o zbrodnie przeciwko 
pokojowi, ludzkości i o przestępstwa wojenne lub o zbrodnię godzącą w życie ludzkie 
albo o występek przeciwko życiu i zdrowiu, gdy jego następstwem była śmierć 
człowieka – Komendant Główny Policji, na wniosek prokuratora lub sądu, 
przedstawia żądane dokumenty i materiały oraz wyjaśnienia ministrowi właściwemu 
do spraw wewnętrznych. Jeżeli minister właściwy do spraw wewnętrznych stwierdzi, 
że uwzględnienie żądania prokuratora lub sądu jest uzasadnione, Komendant Główny 
Policji jest obowiązany zezwolić na udostępnienie wnioskowanych informacji. 
4. W razie odmowy zezwolenia na udzielenie wiadomości stanowiącej 
informację niejawną przez ministra właściwego do spraw wewnętrznych stosuje się 
tryb określony w art. 9 ust. 3 ustawy z dnia 21 czerwca 1996 r. o szczególnych formach 
sprawowania nadzoru przez ministra właściwego do spraw wewnętrznych. 
5. W przypadku Komendanta Głównego Policji, Komendanta BSWP oraz ich 
zastępców, a także, w zakresie wynikającym z art. 11j ust. 1 pkt 1–3 ustawy z dnia 21 
czerwca 1996 r. o szczególnych formach sprawowania nadzoru przez ministra 
właściwego do spraw wewnętrznych, funkcjonariuszy BSWP, zezwolenia, o którym 
mowa w ust. 1, udziela minister właściwy do spraw wewnętrznych. Przepisy ust. 2 
stosuje się odpowiednio. 

 
 
 
s. 82/274 
 
2025-07-03

***
## Art. 20c. {#policja-art-20c}

1. W celu zapobiegania lub wykrywania przestępstw, przestępstw 
skarbowych albo w celu ratowania życia lub zdrowia ludzkiego bądź wsparcia działań 
poszukiwawczych lub ratowniczych, Policja może uzyskiwać dane niestanowiące 
treści odpowiednio, komunikatu elektronicznego przesyłanego w ramach świadczonej 
publicznie dostępnej usługi telekomunikacyjnej, przesyłki pocztowej albo przekazu w 
ramach usługi świadczonej drogą elektroniczną, określone w: 
1) 
art. 45 ust. 1 i art. 49 ustawy z dnia 12 lipca 2024 r. – Prawo komunikacji 
elektronicznej (Dz. U. poz. 1221), zwane dalej „danymi telekomunikacyjnymi”, 
2) 
art. 82 ust. 1 pkt 1 ustawy z dnia 23 listopada 2012 r. – Prawo pocztowe (Dz. U. 
z 2025 r. poz. 366), zwane dalej „danymi pocztowymi”, 
3) 
art. 18 ust. 1–5 ustawy z dnia 18 lipca 2002 r. o świadczeniu usług drogą 
elektroniczną, zwane dalej „danymi internetowymi” 
– oraz może je przetwarzać bez wiedzy i zgody osoby, której dotyczą. 
2. Przedsiębiorca telekomunikacyjny, operator pocztowy lub usługodawca 
świadczący usługi drogą elektroniczną udostępnia nieodpłatnie dane, o których mowa 
w ust. 1: 
1) 
policjantowi wskazanemu w pisemnym wniosku Komendanta Głównego Policji, 
Komendanta CBŚP, Komendanta BSWP, Komendanta CBZC, komendanta 
wojewódzkiego Policji albo osoby przez nich upoważnionej; 
2) 
na ustne żądanie policjanta posiadającego pisemne upoważnienie osób, o których 
mowa w pkt 1; 
3) 
za pośrednictwem sieci telekomunikacyjnej policjantowi posiadającemu pisemne 
upoważnienie osób, o których mowa w pkt 1. 
3. W przypadku, o którym mowa w ust. 2 pkt 3, udostępnianie danych, o których 
mowa w ust. 1, odbywa się bez udziału pracowników przedsiębiorcy 
telekomunikacyjnego, operatora pocztowego lub usługodawcy świadczącego usługi 
drogą elektroniczną lub przy niezbędnym ich udziale, jeżeli możliwość taka jest 
przewidziana w porozumieniu zawartym pomiędzy Komendantem Głównym Policji a 
tym podmiotem. 
4. Udostępnienie Policji danych, o których mowa w ust. 1, może nastąpić za 
pośrednictwem sieci telekomunikacyjnej, jeżeli: 
1) 
wykorzystywane sieci telekomunikacyjne zapewniają: 
a) 
możliwość ustalenia osoby uzyskującej dane, ich rodzaju oraz czasu, w 
którym zostały uzyskane, 

 
 
 
s. 83/274 
 
2025-07-03 
 
b) 
zabezpieczenie techniczne i organizacyjne uniemożliwiające osobie 
nieuprawnionej dostęp do danych; 
2) 
jest to uzasadnione specyfiką lub zakresem zadań wykonywanych przez 
jednostki organizacyjne Policji albo prowadzonych przez nie czynności. 
5. Komendant Główny Policji, Komendant CBŚP, Komendant BSWP, 
Komendant CBZC i komendant wojewódzki Policji prowadzą rejestry wystąpień o 
uzyskanie danych telekomunikacyjnych, pocztowych i internetowych zawierające 
informacje identyfikujące jednostkę organizacyjną Policji i funkcjonariusza Policji 
uzyskującego te dane, ich rodzaj, cel uzyskania oraz czas, w którym zostały uzyskane. 
Rejestry prowadzi się w formie elektronicznej, z zachowaniem przepisów o ochronie 
informacji niejawnych. 
6. Dane, o których mowa w ust. 1, które mają znaczenie dla postępowania 
karnego, Komendant Główny Policji, Komendant CBŚP, Komendant BSWP, 
Komendant CBZC albo komendant wojewódzki Policji przekazują prokuratorowi 
właściwemu miejscowo lub rzeczowo. Prokurator podejmuje decyzję o zakresie i 
sposobie wykorzystania przekazanych danych. 
6a. Komendant Główny Policji, Komendant CBŚP, Komendant BSWP, 
Komendant CBZC albo komendant wojewódzki (Stołeczny) Policji może upoważnić 
swojego zastępcę do realizacji czynności, o których mowa w ust. 6. 
7. Dane, o których mowa w ust. 1, które nie mają znaczenia dla postępowania 
karnego, podlegają niezwłocznemu, komisyjnemu i protokolarnemu zniszczeniu. 
8. Dane, o których mowa w ust. 1, pobiera się i udostępnia się także organom 
ścigania państw członkowskich Unii Europejskiej i innych państw, agencjom Unii 
Europejskiej zajmującymi się zapobieganiem i zwalczaniem przestępczości oraz 
Międzynarodowej Organizacji Policji Kryminalnej – Interpol na ich wniosek, jeżeli 
następuje to w celu wykrywania przestępstw oraz ścigania ich sprawców, ratowania 
życia lub zdrowia ludzkiego albo poszukiwania osób zaginionych.

***
## Art. 20ca. {#policja-art-20ca}

1. 
Kontrolę 
nad 
uzyskiwaniem 
przez 
Policję 
danych 
telekomunikacyjnych, pocztowych lub internetowych sprawuje sąd okręgowy 
właściwy dla siedziby organu Policji, któremu udostępniono te dane. 
2. Organ Policji, o którym mowa w ust. 1, przekazuje, z zachowaniem przepisów 
o ochronie informacji niejawnych, sądowi okręgowemu, o którym mowa w ust. 1, w 
okresach półrocznych, sprawozdanie obejmujące: 

 
 
 
s. 84/274 
 
2025-07-03 
 
1) 
liczbę 
przypadków 
pozyskania 
w 
okresie 
sprawozdawczym 
danych 
telekomunikacyjnych, pocztowych lub internetowych oraz rodzaj tych danych; 
2) 
kwalifikacje prawne czynów, w związku z zaistnieniem których wystąpiono o 
dane telekomunikacyjne, pocztowe lub internetowe, albo informacje o 
pozyskaniu danych w celu ratowania życia lub zdrowia ludzkiego bądź wsparcia 
działań poszukiwawczych lub ratowniczych. 
3. W ramach kontroli, o której mowa w ust. 1, sąd okręgowy może zapoznać się 
z materiałami uzasadniającymi udostępnienie Policji danych telekomunikacyjnych, 
pocztowych lub internetowych. 
4. Sąd okręgowy informuje organ Policji o wyniku kontroli w terminie 30 dni od 
jej zakończenia. 
5. Kontroli, o której mowa w ust. 1, nie podlega uzyskiwanie danych na 
podstawie art. 20cb ust. 1.

***
## Art. 20cb. {#policja-art-20cb}

1. W celu zapobiegania lub wykrywania przestępstw, przestępstw 
skarbowych albo w celu ratowania życia lub zdrowia ludzkiego bądź wsparcia działań 
poszukiwawczych lub ratowniczych, Policja może uzyskiwać dane: 
1) 
o których mowa w art. 43 ust. 1 pkt 1 lit. a tiret drugie ustawy z dnia 12 lipca 
2024 r. – Prawo komunikacji elektronicznej,  
2) 
o których mowa w art. 389 ustawy z dnia 12 lipca 2024 r. – Prawo komunikacji 
elektronicznej, 
3) 
w przypadku użytkownika, który nie jest osobą fizyczną numer zakończenia sieci 
oraz siedzibę lub miejsce wykonywania działalności gospodarczej, firmę lub 
nazwę i formę organizacyjną tego użytkownika, 
4) 
w przypadku stacjonarnej publicznej sieci telekomunikacyjnej – także nazwę 
miejscowości oraz ulicy, przy której znajduje się zakończenie sieci, udostępnione 
użytkownikowi 
– oraz może je przetwarzać bez wiedzy i zgody osoby, której dotyczą. 
2. Do udostępniania i przetwarzania danych, o których mowa w ust. 1, przepisy 
art. 20c ust. 2–8 stosuje się.

***
## Art. 20d. {#policja-art-20d}

(uchylony)

***
## Art. 20da. {#policja-art-20da}

1. W celu poszukiwania osób zaginionych Policja może uzyskiwać 
dane telekomunikacyjne, pocztowe i internetowe oraz może je przetwarzać bez wiedzy 
i zgody osoby, której dotyczą; przepisy art. 20c ust. 2–8 stosuje się. 

 
 
 
s. 85/274 
 
2025-07-03 
 
2. Materiały uzyskane w wyniku czynności określonych w ust. 1, które nie 
zawierają informacji mających znaczenie dla poszukiwania osób zaginionych, 
podlegają niezwłocznemu komisyjnemu i protokolarnemu zniszczeniu.

***
## Art. 20e. {#policja-art-20e}

1. Komendant Główny Policji prowadzi System Wspomagania 
Dowodzenia 
Policji, 
zwany 
dalej 
„SWD 
Policji”, 
będący 
systemem 
teleinformatycznym wspierającym: 
1) 
wykonywanie zadań ustawowych przez jednostki organizacyjne Policji; 
2) 
obsługę zgłoszeń alarmowych, o których mowa w ustawie z dnia 22 listopada 
2013 r. o systemie powiadamiania ratunkowego (Dz. U. z 2023 r. poz. 748 oraz 
z 2024 r. poz. 731 i 1222). 
2. Komendant Główny Policji zapewnia utrzymanie, rozbudowę oraz 
modyfikację SWD Policji. 
3. Utrzymanie, rozbudowa i modyfikacje SWD Policji są finansowane z budżetu 
państwa, z części, której dysponentem jest minister właściwy do spraw wewnętrznych. 
4. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
parametry funkcjonalne SWD Policji, sposób jego funkcjonowania w sytuacjach 
awaryjnych oraz sposób utrzymania, mając na uwadze potrzebę zapewnienia 
optymalnego poziomu współpracy między systemem teleinformatycznym systemu 
powiadamiania ratunkowego i SWD Policji.

***
## Art. 20f. {#policja-art-20f}

1. Policja może pobierać, uzyskiwać, gromadzić, przetwarzać i 
wykorzystywać w celu wykrywania i ścigania sprawców wykroczeń oraz przestępstw 
informacje, w tym dane osobowe, o sprawcach wykroczeń przeciwko mieniu 
określonych w art. 119 § 1, art. 120 § 1, art. 122 § 1 i 2 oraz art. 124 § 1 Kodeksu 
wykroczeń, osobach podejrzanych o ich popełnienie oraz obwinionych i ukaranych za 
te wykroczenia, także bez ich wiedzy i zgody. 
2. Informacje o osobach, o których mowa w ust. 1, obejmują: 
1) 
imiona, nazwiska lub pseudonimy; 
2) 
imiona i nazwiska rodowe rodziców; 
3) 
datę i miejsce urodzenia; 
4) 
oznaczenie i cechy identyfikacyjne dokumentu tożsamości; 
5) 
adres zamieszkania i adres pobytu; 
6) 
numer PESEL; 
7) 
obywatelstwo i płeć; 

 
 
 
s. 86/274 
 
2025-07-03 
 
8) 
źródła utrzymania, w tym miejsce zatrudnienia oraz, w miarę możności, dane o 
warunkach materialnych, rodzinnych i osobistych; 
9) 
czas i miejsce popełnienia czynu, opis czynu, w tym sposobu działania sprawcy 
czynu i okoliczności jego popełnienia; 
10) kwalifikację prawną czynu, wartość przedmiotu wykroczenia lub wysokość 
wyrządzonej szkody; 
11) datę i rodzaj czynności będącej podstawą wprowadzenia informacji do zbioru 
danych dotyczących sprawców wykroczeń oraz datę otrzymania informacji o 
wykroczeniu; 
12) oznaczenie jednostki organizacyjnej Policji wprowadzającej informacje do 
zbioru danych dotyczących sprawców wykroczeń; 
13) oznaczenie i numer sprawy; 
14) wskazanie zatrzymanych przedmiotów lub dokumentów wraz z ich 
oznaczeniem; 
15) informacje o zastosowanych środkach przymusu wobec osoby oraz o jej 
legitymowaniu; 
16) nazwę organu innego niż wymieniony w pkt 12, prowadzącego sprawę, a w 
przypadku przekazania sprawy innemu organowi – także jego nazwę i datę 
przekazania; 
17) określenie sposobu zakończenia czynności wyjaśniających; 
18) wskazanie, czy sprawa została przekazana do sądu w postępowaniu 
przyspieszonym lub z zastosowaniem art. 58 § 1 Kodeksu postępowania w 
sprawach o wykroczenia; 
19) datę skierowania wniosku o ukaranie do sądu; 
20) informacje 
o 
prawomocnych 
rozstrzygnięciach 
dotyczących 
czynu: 
orzeczeniach, zarządzeniach, mandatach karnych, obejmujących datę i treść 
rozstrzygnięcia, 
datę 
jego 
uprawomocnienia 
się 
oraz 
informacje 
o 
zastosowanych wobec sprawcy czynu środkach oddziaływania wychowawczego; 
21) informacje o uchyleniu prawomocnego rozstrzygnięcia, o którym mowa w pkt 
20. 
3. Policja może pobierać, uzyskiwać, gromadzić, przetwarzać i wykorzystywać 
w celu wykrywania i ścigania sprawców wykroczeń oraz przestępstw informacje, w 
tym dane osobowe, dotyczące pokrzywdzonego czynem, o którym mowa w ust. 1, 
także bez jego wiedzy i zgody, obejmujące w przypadku osoby fizycznej: imiona, 

 
 
 
s. 87/274 
 
2025-07-03 
 
nazwisko, numer PESEL i adres zamieszkania, a w przypadku podmiotu niebędącego 
osobą fizyczną – dane identyfikujące ten podmiot. 
4. Informacje, o których mowa w ust. 2 i 3, są gromadzone i przetwarzane w 
elektronicznym zbiorze danych dotyczącym sprawców wykroczeń, zwanym dalej 
„rejestrem wykroczeń”, prowadzonym w systemie teleinformatycznym przez 
Komendanta Głównego Policji, który jest ich administratorem w rozumieniu ustawy z 
dnia 14 grudnia 2018 r. o ochronie danych osobowych przetwarzanych w związku z 
zapobieganiem i zwalczaniem przestępczości. 
5. Organ uprawniony do prowadzenia czynności wyjaśniających w sprawach o 
wykroczenia przekazuje do rejestru wykroczeń informacje, o których mowa w ust. 2 i 
3, dotyczące wykroczeń wskazanych w ust. 1, pisemnie lub w sposób określony w ust. 
8 pkt 2. 
6. Informacje, o których mowa w ust. 2 pkt 20 i 21, przekazuje do rejestru 
wykroczeń, pisemnie lub w sposób określony w ust. 8 pkt 2, sąd lub organ, który wydał 
rozstrzygnięcie lub zastosował środki oddziaływania wychowawczego, niezwłocznie 
po zaistnieniu okoliczności, o których mowa w ust. 2 pkt 20 i 21. 
7. Informacje przetwarzane w rejestrze wykroczeń udostępnia się bezpłatnie: 
1) 
organom uprawnionym do prowadzenia czynności wyjaśniających w sprawach o 
wykroczenia oraz wykonywania czynności w celu zapobiegania wykroczeniom 
lub wykrywania wykroczeń oraz ich sprawców lub osobom przez nie 
upoważnionym w związku z prowadzonymi czynnościami wyjaśniającymi lub 
wykonywanymi czynnościami w zakresie wykrywania i ścigania wykroczeń; 
2) 
organom uprawnionym do prowadzenia postępowań karnych, postępowań w 
sprawach nieletnich lub wykonywania czynności w sprawach nieletnich w 
związku z prowadzonymi postępowaniami; 
3) 
innym organom lub podmiotom uprawnionym na podstawie przepisów 
odrębnych do otrzymania takich informacji w zakresie niezbędnym do realizacji 
ich zadań ustawowych. 
8. Udostępnienie informacji przetwarzanych w rejestrze wykroczeń następuje: 
1) 
na pisemny wniosek organów, osób lub podmiotów, o których mowa w ust. 7, 
zawierający dane umożliwiające wyszukanie informacji w rejestrze wykroczeń; 
2) 
w drodze teletransmisji danych – w przypadku organów, osób lub podmiotów, o 
których mowa w ust. 7, którym administrator nadał uprawnienia dostępu do 
rejestru wykroczeń oraz przetwarzania informacji w tym rejestrze, jeżeli jest 

 
 
 
s. 88/274 
 
2025-07-03 
 
zapewnione odnotowywanie w systemie, kto, kiedy, w jakim celu oraz jakie 
informacje uzyskał, a także zabezpieczenie techniczne i organizacyjne 
uniemożliwiające wykorzystanie informacji niezgodnie z celem ich uzyskania 
oraz jest to uzasadnione specyfiką lub zakresem wykonywania zadań albo 
prowadzonej działalności. 
9. Informacje przetwarzane w rejestrze wykroczeń udostępnia się na pisemny 
wniosek osobie, której dane osobowe dotyczą, wyłącznie w zakresie czynów 
stwierdzonych prawomocnym rozstrzygnięciem oraz w zakresie informacji, o których 
mowa w ust. 2 pkt 1–11, 13 i 20, a jeżeli udzielenie takich informacji utrudniałoby 
realizację ustawowych zadań Policji, w szczególności w zakresie wykrywania i 
ścigania sprawców wykroczeń oraz przestępstw, zakres udzielanych informacji można 
ograniczyć do informacji o liczbie odnotowanych w rejestrze czynów, ich kwalifikacji 
prawnej, dacie wprowadzenia informacji do rejestru, czasie i miejscu popełnienia 
czynu oraz, w miarę możliwości, informacji określonych w ust. 2 pkt 20. 
10. Czynności podejmowane przez administratora w zakresie realizacji 
wniosków złożonych przez osoby, których dane dotyczą, są wolne od opłat. Jeżeli 
wniosek osoby, której dane dotyczą, jest w sposób oczywisty nieuzasadniony ze 
względu na jego powtarzalność, administrator może: 
1) 
pobrać opłatę lub  
2) 
odmówić podjęcia działań w związku ze złożonym wnioskiem. 
11. Obowiązek wykazania, że wniosek osoby, której dane dotyczą, jest w sposób 
oczywisty nieuzasadniony, spoczywa na administratorze. 
12. Wysokość opłaty, o której mowa w ust. 10 pkt 1, wynosi 0,002 przeciętnego 
wynagrodzenia w poprzednim kwartale, począwszy od pierwszego dnia miesiąca 
następującego po miesiącu jego ogłoszenia przez Prezesa Głównego Urzędu 
Statystycznego w Dzienniku Urzędowym Rzeczypospolitej Polskiej „Monitor Polski” 
na podstawie art. 20 pkt 2 ustawy z dnia 17 grudnia 1998 r. o emeryturach i rentach z 
Funduszu Ubezpieczeń Społecznych (Dz. U. z 2024 r. poz. 1631 i 1674). 
13. Informacje o osobach, o których mowa w ust. 1, przetwarzane w rejestrze 
wykroczeń Policja przetwarza w celu realizacji innych ustawowych zadań niż 
określone w ust. 1, w zakresie niezbędnym do realizacji tych zadań. 
14. Organy Policji dokonują weryfikacji informacji o osobach, o których mowa 
w ust. 1, przetwarzanych w rejestrze wykroczeń po zakończeniu sprawy, w związku z 
którą informacje te zostały wprowadzone do rejestru wykroczeń, a ponadto nie 

 
 
 
s. 89/274 
 
2025-07-03 
 
rzadziej niż co 3 lata, licząc od dnia uzyskania lub pobrania informacji, usuwając 
zbędne dane. 
15. Dane osobowe osób, o których mowa w ust. 1, usuwa się z rejestru 
wykroczeń: 
1) 
po upływie 3 lat od dnia ich wprowadzenia do rejestru, chyba że przed upływem 
tego terminu do rejestru zostały wprowadzone dane o kolejnym czynie takiej 
osoby stanowiącym wykroczenie określone w ust. 1; 
2) 
przed upływem terminu wskazanego w pkt 1 – w razie uniewinnienia osoby, 
której dane dotyczą, odmowy wszczęcia wobec niej postępowania lub jego 
umorzenia prawomocnym orzeczeniem sądu lub śmierci tej osoby oraz w 
przypadku stwierdzenia przez uprawniony organ braku podstaw do pociągnięcia 
sprawcy do odpowiedzialności za wykroczenie, jeżeli nie zachodzi przesłanka 
dalszego przetwarzania danych osobowych dotyczących tej osoby w związku z 
innym czynem odnotowanym w rejestrze. 
16. Dane osobowe osób, o których mowa w ust. 3, usuwa się z rejestru wykroczeń 
wraz z usunięciem danych sprawcy czynu, którym zostały one pokrzywdzone. 
17. Usunięcia danych osobowych z rejestru wykroczeń dokonuje komisja 
powołana przez Komendanta Głównego Policji, która sporządza protokół z tych 
czynności. 
18. W celu zapewnienia gromadzenia i przetwarzania informacji, o których 
mowa w ust. 2 i 3, w rejestrze wykroczeń organy Policji lub osoby przez nie 
upoważnione mogą występować do organów uprawnionych do prowadzenia 
czynności wyjaśniających w sprawach o wykroczenia, prowadzących postępowania w 
sprawach o wykroczenia lub do innych organów lub podmiotów, które mogą posiadać 
lub przetwarzają informacje, o których mowa w ust. 2 i 3, z wnioskiem o przekazanie 
do rejestru wykroczeń posiadanych lub przetwarzanych przez nie informacji w 
zakresie określonym w tych przepisach. 
19. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia: 
1) 
sposoby przetwarzania informacji, o których mowa w ust. 2 i 3, w rejestrze 
wykroczeń, sposób i tryb prowadzenia rejestru wykroczeń, rodzaje służb 
policyjnych uprawnionych do korzystania z rejestru wykroczeń, właściwość 
jednostek organizacyjnych Policji do wprowadzania informacji do rejestru 
wykroczeń, czynności będące podstawą wprowadzania informacji do rejestru 
wykroczeń, zakres, cel i sposób kontroli dostępu do rejestru wykroczeń oraz 

 
 
 
s. 90/274 
 
2025-07-03 
 
nadzoru nad przetwarzaniem informacji oraz sposób weryfikacji przydatności i 
niezbędności informacji przetwarzanych w rejestrze wykroczeń w zakresie 
realizacji zadań Policji, uwzględniając potrzebę ochrony informacji przed 
nieuprawnionym dostępem do nich, zapewnienie sprawności wprowadzania 
informacji do rejestru wykroczeń oraz konieczność zapewnienia aktualizacji, 
kompletności i prawidłowości informacji przetwarzanych w rejestrze 
wykroczeń; 
2) 
sposób i tryb udzielania informacji o osobach na podstawie informacji 
przetwarzanych w rejestrze wykroczeń oraz wzór protokołu usunięcia danych 
osobowych z rejestru wykroczeń, wzór wniosku o udzielenie informacji 
przetwarzanych w rejestrze wykroczeń oraz wzór informacji o osobie, 
uwzględniając konieczność zapewnienia sprawnego udzielania informacji i 
potrzebę zabezpieczenia danych przed nieuprawnionym dostępem do nich.

***
## Art. 20g. {#policja-art-20g}

1. W związku z obsługą zadań, o których mowa w art. 20e ust. 1 pkt 1, 
Komendant Główny Policji przetwarza w SWD Policji informacje, w tym dane 
osobowe osób, których dane uzyskano w związku z realizacją zadań, o których mowa 
w art. 1 ust. 2 i 3, i w tym zakresie jest administratorem w rozumieniu przepisów o 
ochronie danych osobowych. 
2. W związku z obsługą zgłoszeń alarmowych, o których mowa w art. 20e ust. 1 
pkt 2, Komendant Główny Policji przetwarza w SWD Policji informacje, w tym dane 
osobowe osób określonych w ustawie z dnia 22 listopada 2013 r. o systemie 
powiadamiania ratunkowego, i w tym zakresie jest administratorem w rozumieniu 
przepisów o ochronie danych osobowych. 
3. Komendant Główny Policji przetwarza w SWD Policji informacje, w tym dane 
osobowe, w celu: 
1) 
ewidencjonowania i dokumentowania przyjmowanych zgłoszeń o zdarzeniach 
oraz podjętych interwencjach; 
2) 
zapewnienia właściwej reakcji Policji na zdarzenie; 
3) 
współdziałania Policji z centrami powiadamiania ratunkowego oraz innymi 
służbami ratowniczymi; 
4) 
zabezpieczania danych o źródłach dowodowych oraz prowadzenia analizy 
zagrożenia. 

 
 
 
s. 91/274 
 
2025-07-03 
 
4. Informacje, w tym dane osobowe, przetwarzane w SWD Policji usuwa się 
automatycznie po upływie 5 lat od ich rejestracji.

***
## Art. 21. {#policja-art-21}

(uchylony)

***
## Art. 21a. {#policja-art-21a}

1. Komendant Główny Policji prowadzi zbiór danych zawierający 
informacje o wynikach analizy kwasu deoksyrybonukleinowego (DNA), zwany dalej 
„zbiorem danych DNA”, którego jest administratorem w rozumieniu ustawy z dnia 14 
grudnia 2018 r. o ochronie danych osobowych przetwarzanych w związku z 
zapobieganiem i zwalczaniem przestępczości. 
2. W zbiorze danych DNA przetwarza się: 
1) 
informacje, w tym dane osobowe, o których mowa w ust. 1, w odniesieniu do: 
a) 
osób podejrzanych lub podejrzanych o popełnienie przestępstw ściganych z 
oskarżenia publicznego, 
b) 
nieletnich dopuszczających się czynów zabronionych przez ustawę jako 
przestępstwa ścigane z oskarżenia publicznego, 
c) 
osób stwarzających zagrożenie, o których mowa w ustawie z dnia 22 
listopada 2013 r. o postępowaniu wobec osób z zaburzeniami psychicznymi 
stwarzających zagrożenie życia, zdrowia lub wolności seksualnej innych 
osób (Dz. U. z 2022 r. poz. 1689), 
d) 
osób, o których mowa w art. 10 ust. 1 ustawy z dnia 10 czerwca 2016 r. o 
działaniach antyterrorystycznych, 
e) 
oskarżonych lub skazanych za popełnienie przestępstw ściganych z 
oskarżenia publicznego, 
f) 
osób o nieustalonej tożsamości oraz osób usiłujących ukryć swoją 
tożsamość, 
g) 
zwłok ludzkich o nieustalonej tożsamości, 
h) 
śladów nieznanych sprawców przestępstw, 
i) 
osób zaginionych, 
j) 
osób, o których mowa w art. 15 ust. 1 pkt 3a lit. c, 
k) 
osób, o których mowa w art. 20 ust. 1l; 
2) 
informacje, w tym dane osobowe osób, o których mowa w pkt 1 lit. a–e oraz i–
k, obejmują: 
a) 
wyniki analizy kwasu deoksyrybonukleinowego (DNA), 
b) 
imiona, nazwiska lub pseudonimy, 

 
 
 
s. 92/274 
 
2025-07-03 
 
c) 
imiona i nazwiska rodowe rodziców tych osób, 
d) 
datę i miejsce urodzenia, 
e) 
adres zamieszkania, 
f) 
numer PESEL, 
g) 
obywatelstwo i płeć, 
h) 
oznaczenie i cechy dokumentu tożsamości. 
3. W ramach zbioru danych DNA gromadzi się próbki pobrane od osoby albo ze 
zwłok ludzkich, w celu przeprowadzenia analizy kwasu deoksyrybonukleinowego 
(DNA), w postaci wymazów ze śluzówki policzków, krwi, cebulek włosów lub 
wydzielin, a w odniesieniu do zwłok ludzkich materiał biologiczny w postaci próbek 
z tkanek, zwane dalej „próbkami biologicznymi”.

***
## Art. 21b. {#policja-art-21b}

1. Informacje, w tym dane osobowe, o których mowa w art. 21a ust. 2 
pkt 1 lit. a–j, wprowadza się do zbioru danych DNA na podstawie zarządzenia: 
1) 
prowadzącego postępowanie przygotowawcze lub sądu – w przypadku analizy 
kwasu deoksyrybonukleinowego (DNA) przeprowadzonej w związku z: 
a) 
postępowaniem karnym, 
b) 
postępowaniem w sprawach nieletnich, 
c) 
postępowaniem określonym w ustawie z dnia 22 listopada 2013 r. o 
postępowaniu wobec osób z zaburzeniami psychicznymi stwarzających 
zagrożenie życia, zdrowia lub wolności seksualnej innych osób, 
d) 
postępowaniem wobec osób wymienionych w art. 10 ust. 1 ustawy z dnia 
10 czerwca 2016 r. o działaniach antyterrorystycznych, 
e) 
postępowaniem wobec osób skazanych; 
2) 
prowadzącego czynności – w przypadku osób o nieustalonej tożsamości, osób 
usiłujących ukryć swoją tożsamość, zwłok ludzkich o nieustalonej tożsamości, 
osób zaginionych oraz osób, o których mowa w art. 15 ust. 1 pkt 3a lit. c. 
2. Informacje, w tym dane osobowe, o których mowa w art. 21a ust. 2 pkt 1 lit. 
k, wprowadza się do zbioru danych DNA na podstawie wniosku właściwego 
miejscowo organu Policji, przed podjęciem przez policjantów i pracowników Policji 
pierwszych czynności służbowych związanych z ujawnianiem, zabezpieczaniem lub 
badaniem śladów związanych z podejrzeniem popełnienia czynu zabronionego.

***
## Art. 21c. {#policja-art-21c}

Informacje, w tym dane osobowe, przetwarzane w zbiorze danych 
DNA udostępnia się bezpłatnie organom prowadzącym postępowanie karne, 

 
 
 
s. 93/274 
 
2025-07-03 
 
postępowanie w sprawach nieletnich lub prowadzącym czynności wykrywcze lub 
identyfikacyjne.

***
## Art. 21d. {#policja-art-21d}

1. Informacje, w tym dane osobowe, o których mowa w art. 20 ust. 1l, 
są przetwarzane w zbiorze danych DNA w celu prowadzenia czynności wykrywczych 
lub identyfikacyjnych. 
2. Informacje, w tym dane osobowe, o których mowa w art. 21a ust. 2 pkt 1 lit. 
a–j, są przetwarzane w zbiorze danych DNA w celu prowadzenia czynności 
wykrywczych i eliminacyjnych.

***
## Art. 21e. {#policja-art-21e}

1. W weryfikacji, o której mowa w art. 16 ustawy z dnia 14 grudnia 
2018 r. o ochronie danych osobowych przetwarzanych w związku zapobieganiem i 
zwalczaniem przestępczości, uczestniczą jednostki organizacyjne Policji, służby, 
instytucje państwowe lub organy władzy publicznej, które przekazały informacje, w 
tym dane osobowe, do zbioru danych DNA. 
2. Informacje, w tym dane osobowe, usuwa się ze zbioru danych DNA, w 
przypadku gdy: 
1) 
zostało umorzone postępowanie z uwagi na to, że: 
a) 
czynu stanowiącego podstawę wprowadzenia danych osobowych do zbioru 
danych nie popełniono albo brak jest danych dostatecznie uzasadniających 
podejrzenie jego popełnienia, 
b) 
zdarzenie lub okoliczność, w związku z którymi wprowadzono dane 
osobowe do zbioru danych, nie ma znamion czynu zabronionego; 
2) 
osoba, której dane dotyczą: 
a) 
została uniewinniona prawomocnym wyrokiem sądu, 
b) 
ukończyła 100. rok życia, 
c) 
zmarła; 
3) 
tożsamość zwłok ludzkich została ustalona; 
4) 
utracą swoją przydatność eliminacyjną, jednakże nie dłużej niż po upływie 5 lat 
od dnia ustania stosunku służbowego lub pracy – w przypadku osób, o których 
mowa w art. 20 ust. 1l. 
3. Informacje, w tym dane osobowe osób, o których mowa w art. 21a ust. 2 pkt 
1 lit. h, usuwa się ze zbioru danych DNA, po upływie okresu przedawnienia karalności 
przestępstwa, na wniosek organu prowadzącego postępowanie karne. 

 
 
 
s. 94/274 
 
2025-07-03 
 
4. Informacje, w tym dane osobowe osób, o których mowa w art. 21a ust. 2 pkt 
1 lit. i oraz j, usuwa się ze zbioru danych DNA, w przypadku odnalezienia lub ustalenia 
miejsca pobytu osoby zaginionej lub po upływie 55 lat od dnia rozpoczęcia ich 
przetwarzania w zbiorze danych DNA. Informacje te, w tym dane osobowe, usuwa się 
na wniosek jednostki organizacyjnej, służby, instytucji państwowej lub organu władzy 
publicznej prowadzącej poszukiwanie lub osoby zaginionej. 
5. Usunięcia informacji, w tym danych osobowych osób, o których mowa w art. 
21a ust. 2 pkt 1 lit. a–g oraz i–k, ze zbioru danych DNA oraz zniszczenia próbek 
biologicznych dokonuje komisja powołana przez Komendanta Głównego Policji, 
sporządzając z tych czynności protokół.

***
## Art. 21f. {#policja-art-21f}

(uchylony)

***
## Art. 21g. {#policja-art-21g}

(uchylony)

***
## Art. 21h. {#policja-art-21h}

1. Komendant Główny Policji prowadzi następujące zbiory danych 
daktyloskopijnych, których jest administratorem w rozumieniu przepisów o ochronie 
danych osobowych: 
1) 
Centralną Registraturę Daktyloskopijną, w której są gromadzone karty 
daktyloskopijne i chejroskopijne zawierające odciski linii papilarnych osób, 
2) 
zbiór automatycznie przetwarzający dane daktyloskopijne, w którym są 
przetwarzane informacje, w tym dane osobowe, o odciskach linii papilarnych 
osób, niezidentyfikowanych śladach linii papilarnych z miejsc przestępstw oraz 
śladach linii papilarnych, które mogą pochodzić od osób zaginionych 
– zwane dalej „zbiorami danych daktyloskopijnych”. 
2. W zbiorach danych daktyloskopijnych są przetwarzane: 
1) 
informacje, w tym dane osobowe, dotyczące: 
a) 
osób podejrzanych lub podejrzanych o popełnienie przestępstw ściganych z 
oskarżenia publicznego, 
b) 
nieletnich dopuszczających się czynów zabronionych przez ustawę jako 
przestępstwa ścigane z oskarżenia publicznego, 
c) 
osób stwarzających zagrożenie, o których mowa w ustawie z dnia 22 
listopada 2013 r. o postępowaniu wobec osób z zaburzeniami psychicznymi 
stwarzających zagrożenie życia, zdrowia lub wolności seksualnej innych 
osób, 

 
 
 
s. 95/274 
 
2025-07-03 
 
d) 
osób, o których mowa w art. 10 ust. 1 ustawy z dnia 10 czerwca 2016 r. o 
działaniach antyterrorystycznych, 
e) 
oskarżonych lub skazanych za popełnienie przestępstw ściganych z 
oskarżenia publicznego, 
f) 
osób poszukiwanych, 
g) 
cudzoziemców, od których zostały pobrane odciski linii papilarnych w 
sytuacjach, o których mowa w art. 35 ust. 2, art. 324 pkt 1 i art. 394 ust. 3 
ustawy z dnia 12 grudnia 2013 r. o cudzoziemcach lub art. 30 ust. 1 pkt 3, 
art. 92 ust. 1 i art. 114 ust. 1 ustawy z dnia 13 czerwca 2003 r. o udzielaniu 
cudzoziemcom ochrony na terytorium Rzeczypospolitej Polskiej, lub art. 
73a ustawy z dnia 14 lipca 2006 r. o wjeździe na terytorium Rzeczy-
pospolitej Polskiej, pobycie oraz wyjeździe z tego terytorium obywateli 
państw członkowskich Unii Europejskiej i członków ich rodzin (Dz. U. z 
2024 r. poz. 633 i 1688), 
h) 
śladów linii papilarnych, które mogą pochodzić od osób zaginionych, 
i) 
niezidentyfikowanych śladów linii papilarnych z miejsc przestępstw, 
j) 
osób, o których mowa w art. 20 ust. 1l; 
2) 
informacje, w tym dane osobowe, przetwarzane w zbiorze danych, o którym 
mowa w ust. 1 pkt 1, obejmują: 
a) 
imiona, nazwiska lub pseudonimy, 
b) 
imiona i nazwiska rodowe rodziców tych osób, 
c) 
datę i miejsce urodzenia, 
d) 
oznaczenie i cechy identyfikacyjne dokumentu tożsamości, 
e) 
adres zamieszkania, 
f) 
numer PESEL, 
g) 
obywatelstwo i płeć, 
h) 
oznaczenie i numer sprawy, 
i) 
miejsce i powód daktyloskopowania, 
j) 
odciski linii papilarnych palców i dłoni; 
3) 
informacje, w tym dane osobowe, przetwarzane w zbiorze danych, o którym 
mowa w ust. 1 pkt 2, obejmujące: 
a) 
obrazy odcisków linii papilarnych, 
b) 
rok urodzenia, 
c) 
płeć, 

 
 
 
s. 96/274 
 
2025-07-03 
 
d) 
rodzaj rejestracji, 
e) 
datę wprowadzenia, 
f) 
jednostkę organizacyjną wprowadzającą; 
4) 
informacje, w tym dane osobowe, dotyczące niezidentyfikowanych śladów linii 
papilarnych z miejsc przestępstw obejmujące: 
a) 
obrazy śladów linii papilarnych, 
b) 
datę i miejsce zabezpieczenia, 
c) 
kategorię przestępstwa, 
d) 
jednostkę organizacyjną wprowadzającą, 
e) 
oznaczenie i numer sprawy; 
5) 
informacje, w tym dane osobowe, dotyczące śladów linii papilarnych, które mogą 
pochodzić od osób zaginionych, obejmujące: 
a) 
obrazy śladów linii papilarnych, 
b) 
datę i miejsce zabezpieczenia, 
c) 
kategorię zdarzenia, 
d) 
jednostkę organizacyjną wprowadzającą, 
e) 
oznaczenie i numer sprawy. 
3. W zbiorach danych daktyloskopijnych przetwarza się, z wyłączeniem 
przechowywania, informacje, w tym dane osobowe, dotyczące osób o nieustalonej 
tożsamości lub usiłujących ukryć swoją tożsamość oraz zwłok ludzkich o nieustalonej 
tożsamości, obejmujące: 
1) 
obrazy odcisków linii papilarnych; 
2) 
płeć; 
3) 
oznaczenie i numer sprawy.

***
## Art. 21i. {#policja-art-21i}

Informacje, w tym dane osobowe, wprowadza się do zbiorów danych 
daktyloskopijnych na podstawie wniosku organu prowadzącego postępowanie lub 
poszukiwanie osoby zaginionej.

***
## Art. 21j. {#policja-art-21j}

Informacje, w tym dane osobowe, przetwarzane w zbiorach danych 
daktyloskopijnych oraz uzyskane w wyniku ich przetwarzania są udzielane bezpłatnie 
organom prowadzącym: 
1) 
postępowanie karne; 
2) 
postępowanie w sprawach nieletnich; 
3) 
czynności wykrywcze lub identyfikacyjne; 

 
 
 
s. 97/274 
 
2025-07-03 
 
4) 
czynności związane z wprowadzaniem danych daktyloskopijnych do innych 
zbiorów danych na podstawie odrębnych przepisów.

***
## Art. 21k. {#policja-art-21k}

1. Informacje, w tym dane osobowe, o których mowa w art. 21h ust. 2 
pkt 1 lit. a–h, są przechowywane w zbiorach danych daktyloskopijnych w celu 
prowadzenia czynności identyfikacyjnych. 
2. Informacje, w tym dane osobowe, o których mowa w art. 21h ust. 2 pkt 1 lit. 
a–f, są przechowywane w zbiorach danych daktyloskopijnych i wykorzystywane w 
celu prowadzenia czynności wykrywczych. 
3. Informacje, w tym dane osobowe, o których mowa w art. 21h ust. 2 pkt 1 lit. 
j, są przetwarzane w zbiorach danych daktyloskopijnych w celu wyeliminowania, 
spośród wszystkich zebranych w toku prowadzonego postępowania, śladów 
pozostawionych przez osoby, o których mowa w art. 20 ust. 1l.

***
## Art. 21l. {#policja-art-21l}

1. W weryfikacji, o której mowa w art. 16 ustawy z dnia 14 grudnia 
2018 r. o ochronie danych osobowych przetwarzanych w związku z zapobieganiem i 
zwalczaniem przestępczości, uczestniczą jednostki organizacyjne Policji, służby, 
instytucje państwowe lub organy władzy publicznej, które przekazały informacje, w 
tym dane osobowe, do zbiorów danych daktyloskopijnych. 
2. Informacje, w tym dane osobowe, o których mowa w art. 21h ust. 2 pkt 1 lit. 
a–c, e i f, usuwa się ze zbiorów danych daktyloskopijnych, w przypadku gdy: 
1) 
zostało umorzone postępowanie z uwagi na to, że: 
a) 
czynu stanowiącego podstawę wprowadzenia danych osobowych do zbioru 
danych nie popełniono albo brak jest danych dostatecznie uzasadniających 
podejrzenie jego popełnienia, 
b) 
zdarzenie lub okoliczność, w związku z którymi wprowadzono dane 
osobowe do zbioru danych, nie ma znamion czynu zabronionego; 
2) 
osoba, której dane dotyczą: 
a) 
została uniewinniona prawomocnym wyrokiem sądu, 
b) 
ukończyła 100. rok życia, 
c) 
zmarła; 
3) 
utracą swoją przydatność eliminacyjną, jednakże nie dłużej niż po upływie 5 lat 
od dnia ustania stosunku służbowego lub pracy – w przypadku osób, o których 
mowa w art. 20 ust. 1l. 

 
 
 
s. 98/274 
 
2025-07-03 
 
3. Informacje, w tym dane osobowe, o których mowa w art. 21h ust. 2 pkt 1 lit. 
g, usuwa się ze zbiorów danych daktyloskopijnych, jeżeli osoba, której dane dotyczą: 
1) 
uzyskała obywatelstwo polskie; 
2) 
ukończyła 100. rok życia; 
3) 
zmarła. 
4. Informacje, w tym dane osobowe, o których mowa w art. 21h ust. 2 pkt 1, 
usuwa się ze zbiorów danych daktyloskopijnych po uzyskaniu wiarygodnej 
informacji.

***
## Art. 21m. {#policja-art-21m}

1. Informacje, w tym dane osobowe, o których mowa w art. 21h ust. 2 
pkt 1 lit. i, usuwa się ze zbiorów danych daktyloskopijnych po upływie okresu 
przedawnienia karalności przestępstwa, na wniosek organu prowadzącego 
postępowanie karne. 
2. Informacje, w tym dane osobowe, o których mowa w art. 21h ust. 2 pkt 1 lit. 
h, usuwa się ze zbiorów danych daktyloskopijnych, w przypadku odnalezienia lub 
ustalenia miejsca pobytu osoby zaginionej lub po upływie 55 lat od dnia rozpoczęcia 
ich przetwarzania w zbiorach danych daktyloskopijnych. Informacje te, w tym dane 
osobowe, usuwa się na wniosek jednostki organizacyjnej, służby, instytucji 
państwowej lub organu władzy publicznej prowadzącej poszukiwanie.

***
## Art. 21n. {#policja-art-21n}

Usunięcia informacji, w tym danych osobowych, ze zbioru danych 
daktyloskopijnych, w tym zniszczenia kart daktyloskopijnych i chejroskopijnych, 
dokonuje komisja powołana przez Komendanta Głównego Policji, sporządzając z tych 
czynności protokół.

***
## Art. 21na. {#policja-art-21na}

Zadania, o których mowa w art. 21a–21e oraz art. 21h–21n, 
Komendant Główny Policji realizuje przy pomocy CLKP.

***
## Art. 21nb. {#policja-art-21nb}

1. Komendant Główny Policji prowadzi Krajowy System 
Informacyjny Policji, zwany dalej „KSIP”, będący zestawem zbiorów danych, w 
którym przetwarza się informacje, w tym dane osobowe, w związku z realizacją zadań 
ustawowych. 
1a.5) W KSIP Policja może przetwarzać dane biometryczne w postaci:  
 
5) Dodane ust. 1a i 1b w art. 21nb wejdą w życie z dniem określonym w decyzji Komisji Europejskiej, 
zgodnie z art. 66 ust. 1 rozporządzenia Parlamentu Europejskiego i Rady (UE) 2017/2226 z dnia 30 
listopada 2017 r. ustanawiającego system wjazdu/wyjazdu (EES) w celu rejestrowania danych 
dotyczących wjazdu i wyjazdu obywateli państw trzecich przekraczających granice zewnętrzne 

 
 
 
s. 99/274 
 
2025-07-03 
 
1) 
wizerunków osób w celu realizacji zadań, o których mowa w art. 1 ust. 2, w 
zakresie celów identyfikacyjnych lub weryfikacji tożsamości osób, której 
dotyczą realizowane zadania lub wykonywane czynności, o których mowa w 
art. 14 ust. 1 i 2, oraz jeżeli zadania Policji dotyczą celów określonych w art. 
1 pkt 1 ustawy z dnia 14 grudnia 2018 r. o ochronie danych osobowych 
przetwarzanych w związku z zapobieganiem i zwalczaniem przestępczości, 
także w zakresie realizacji celów wykrywczych lub dowodowych;  
2) 
danych daktyloskopijnych w zakresie niezbędnym do powiązania 
informacji, w tym danych osobowych dotyczących osób lub śladów, o 
których mowa w art. 21h ust. 2 pkt 1, z danymi przetwarzanymi w zbiorach 
danych daktyloskopijnych, o których mowa w art. 21h w zakresie danych 
określonych w art. 21h ust. 2 pkt 2–5.  
1b.5) Dane osobowe zgromadzone w KSIP w celu realizacji zadań 
ustawowych, o których mowa w art. 1 ust. 1 i ust. 2 pkt 1–4, Policja przechowuje 
przez okres niezbędny do realizacji ustawowych zadań Policji. Organy Policji 
dokonują weryfikacji tych danych po zakończeniu sprawy, w ramach której dane 
te zostały wprowadzone do zbioru, a ponadto nie rzadziej niż co 10 lat od dnia 
uzyskania lub pobrania informacji usuwają zbędne dane. 
2. W odniesieniu do informacji, w tym danych osobowych, przetwarzanych w 
KSIP Komendant Główny Policji jest administratorem w rozumieniu przepisów o 
ochronie danych osobowych. 
3. Komendant Główny Policji zapewnia utrzymanie, rozbudowę oraz 
modyfikację KSIP. 
4. Utrzymanie, rozbudowa i modyfikacja KSIP są finansowane z budżetu 
państwa, z części, której dysponentem jest minister właściwy do spraw wewnętrznych.

***
## Art. 21o. {#policja-art-21o}

1. Komendant Główny Policji prowadzi policyjną mapę zagrożeń 
przestępstwami na tle seksualnym zawierającą aktualne informacje o miejscach 
szczególnego 
zagrożenia 
przestępstwami 
przeciwko 
wolności 
seksualnej, 
wymienionymi w rozdziale XXV Kodeksu karnego. 
 
państw członkowskich i danych dotyczących odmowy wjazdu w odniesieniu do takich obywateli 
oraz określającego warunki dostępu do EES na potrzeby ochrony porządku publicznego i 
zmieniającego konwencję wykonawczą do układu z Schengen i rozporządzenia (WE) nr 767/2008 
i (UE) nr 1077/2011. 
. 

 
 
 
s. 100/274 
 
2025-07-03 
 
2. Mapa zagrożeń przestępstwami na tle seksualnym jest udostępniana do 
wiadomości publicznej przez publikację na stronie internetowej Biuletynu Informacji 
Publicznej Komendy Głównej Policji. 
3. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
sposób prowadzenia mapy zagrożeń przestępstwami na tle seksualnym i tryb jej 
aktualizacji, uwzględniając potrzebę bieżącej analizy występowania zagrożeń 
przestępstwami, o których mowa w ust. 1, oraz ocenę ryzyka w konkretnych miejscach 
występowania tych zagrożeń.

***
## Art. 22. {#policja-art-22}

1. Policja przy wykonywaniu swych zadań może korzystać z pomocy 
osób niebędących policjantami. Zabronione jest ujawnianie danych o osobie 
udzielającej pomocy Policji, w zakresie czynności operacyjno-rozpoznawczych. 
1a. Udostępnienie danych o osobie, o której mowa w ust. 1, może nastąpić 
jedynie w przypadkach i trybie określonych w art. 20ba. 
1b. Dane o osobie, o której mowa w ust. 1, mogą być udostępnione, na żądanie 
prokuratora lub sądu, także w razie uzasadnionego podejrzenia popełnienia przez tę 
osobę przestępstwa ściganego z oskarżenia publicznego w związku z wykonywaniem 
czynności operacyjno-rozpoznawczych oraz w przypadku ujawnienia przez tę osobę 
faktu udzielania pomocy Policji w zakresie czynności operacyjno-rozpoznawczych; 
udostępnienie tych danych następuje w trybie określonym w art. 20ba. 
2. Za udzielenie pomocy, o której mowa w ust. 1, osobom niebędącym 
policjantami może być przyznane wynagrodzenie. 
2a. 
Koszty 
podejmowanych 
przez 
Policję 
czynności 
operacyjno-rozpoznawczych, w zakresie których ze względu na ochronę, o której 
mowa w art. 20a ust. 1–3, nie mogą być stosowane przepisy o finansach publicznych 
i rachunkowości, a także wynagrodzenia osób wymienionych w ust. 1, pokrywane są 
z tworzonego na ten cel funduszu operacyjnego. 
2b. Przepis ust. 2a stosuje się do kosztów związanych z podejmowanymi przez 
Policję czynnościami operacyjno-rozpoznawczymi, pokrywanych ze środków 
przekazanych przez państwa członkowskie i instytucje Unii Europejskiej, inne 
państwa oraz organizacje międzynarodowe na podstawie odrębnych przepisów. 
3. Minister właściwy do spraw wewnętrznych określi, w drodze zarządzenia, 
zasady tworzenia i gospodarowania funduszem operacyjnym. 

 
 
 
s. 101/274 
 
2025-07-03 
 
3a. Składniki rzeczowe majątku ruchomego nabyte ze środków funduszu 
operacyjnego, które utraciły przydatność do wykorzystania w czynnościach 
operacyjno-rozpoznawczych, mogą być wykorzystane do realizacji innych czynności 
Policji. 
4. Jeżeli w czasie korzystania i w związku z korzystaniem przez Policję z pomocy 
osób, o których mowa w ust. 1, osoby te utraciły życie lub poniosły uszczerbek na 
zdrowiu albo szkodę w mieniu, odszkodowanie przysługuje na zasadach i w trybie 
określonych w rozporządzeniu ministra właściwego do spraw wewnętrznych.

