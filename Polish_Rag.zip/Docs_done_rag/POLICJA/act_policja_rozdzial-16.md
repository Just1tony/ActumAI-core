---
id: act.policja.ch16
title: Ustawa o Policji — Rozdział 11
dz_u: Dz.U. 1990 Nr 30 poz. 179 (t.j. 2025 poz. 636, 718)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '146'
  last: '158'
source_pdf: D19900179Lj (1).pdf
chunking:
  strategy: by-article
  anchor_pattern: '## Art. {n}. {#policja-art-{n}}'
  hierarchy:
  - Rozdział
  - Art.
---

# Rozdział 11
 
## Art. 146. {#policja-art-146}

1. Z chwilą utworzenia Policji Milicja Obywatelska zostaje 
rozwiązana. 
2. (pominięty) 
3. (pominięty) 
4. (pominięty)

***
## Art. 147. {#policja-art-147}

1. Minister Spraw Wewnętrznych zorganizuje Policję w ciągu 3 
miesięcy od dnia wejścia w życie niniejszej ustawy. 
2. Z chwilą zorganizowania Policji likwidacji ulegają urzędy spraw 
wewnętrznych.

***
## Art. 148. {#policja-art-148}

(pominięty)

***
## Art. 149. {#policja-art-149}

1. Z chwilą rozwiązania Milicji Obywatelskiej jej funkcjonariusze stają 
się policjantami. 
2. Przepisu ust. 1 nie stosuje się do tych funkcjonariuszy Milicji Obywatelskiej, 
którzy do dnia 31 lipca 1989 r. byli funkcjonariuszami Służby Bezpieczeństwa. 
3. (pominięty)

***
## Art. 150. {#policja-art-150}

1. Dotychczasowi funkcjonariusze Milicji Obywatelskiej lub Służby 
Bezpieczeństwa, którzy podejmą służbę w Policji albo zostaną zatrudnieni w 
jednostkach organizacyjnych podległych Ministrowi Spraw Wewnętrznych, 
zachowują odpowiednio ciągłość służby lub zatrudnienia. 
2. (pominięty) 

 
 
 
s. 274/274 
 
2025-07-03

***
## Art. 151. {#policja-art-151}

1. Funkcjonariusze zwolnieni ze służby w Milicji Obywatelskiej, 
którzy nie podejmą służby lub pracy w jednostkach organizacyjnych podległych 
Ministrowi Spraw Wewnętrznych, zachowują uprawnienia przewidziane dla 
funkcjonariuszy zwolnionych ze służby na podstawie art. 41 ust. 2 pkt 5, chyba że 
nabyli uprawnienia do zwolnienia ze służby na korzystniejszych warunkach. 
2. (pominięty) 
3. (pominięty)

***
## Art. 152. {#policja-art-152}

Z chwilą wejścia w życie niniejszej ustawy ustaje członkostwo w 
partiach politycznych tych policjantów, którzy do takich organizacji dotąd należeli.

***
## Art. 153. {#policja-art-153}

Ilekroć w przepisach prawa jest mowa o „Milicji Obywatelskiej” i 
„funkcjonariuszach Milicji Obywatelskiej”, należy przez to rozumieć „Policję” i 
„policjantów”.

***
## Art. 154. {#policja-art-154}

(pominięty)

***
## Art. 155. {#policja-art-155}

(pominięty)

***
## Art. 156. {#policja-art-156}

(pominięty)

***
## Art. 157. {#policja-art-157}

1. Traci moc ustawa z dnia 31 lipca 1985 r. o służbie funkcjonariuszy 
Służby Bezpieczeństwa i Milicji Obywatelskiej Polskiej Rzeczypospolitej Ludowej 
(Dz. U. poz. 181 oraz z 1989 r. poz. 180 i 192), w części dotyczącej Milicji 
Obywatelskiej13). 
2. Do czasu wydania przepisów wykonawczych przewidzianych w ustawie 
pozostają w mocy przepisy dotychczasowe, jeśli nie są sprzeczne z niniejszą ustawą, 
nie dłużej jednak niż 1 rok. 
3. (pominięty)

***
## Art. 158. {#policja-art-158}

Ustawa wchodzi w życie z dniem ogłoszenia14). 
 
13) W pozostałym zakresie (w części dotyczącej Służby Bezpieczeństwa) uchylona przez art. 136 ust. 1 
ustawy z dnia 6 kwietnia 1990 r. o Urzędzie Ochrony Państwa (Dz. U. poz. 180), która weszła 
w życie z dniem 10 maja 1990 r. 
14) Ustawa została ogłoszona w dniu 10 maja 1990 r.

