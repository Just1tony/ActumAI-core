---
id: act.policja.ch13
title: Ustawa o Policji — Rozdział 10
dz_u: Dz.U. 1990 Nr 30 poz. 179 (t.j. 2025 poz. 636, 718)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: 145h
  last: 145i
source_pdf: D19900179Lj (1).pdf
chunking:
  strategy: by-article
  anchor_pattern: '## Art. {n}. {#policja-art-{n}}'
  hierarchy:
  - Rozdział
  - Art.
---

# Rozdział 10
b 
## Art. 145h. {#policja-art-145h}

Policjanci i pracownicy Policji są uprawnieni do wykonywania 
obowiązków służbowych na terytorium innego państwa członkowskiego Unii 
Europejskiej, w celu realizacji zadań: 
1) 
w formie wspólnych patroli lub innego rodzaju wspólnych operacji w celu 
ochrony 
porządku 
i 
bezpieczeństwa 
publicznego 
oraz 
zapobiegania 
przestępczości, o których mowa w art. 17 decyzji Rady 2008/615/WSiSW z dnia 
23 czerwca 2008 r. w sprawie intensyfikacji współpracy transgranicznej, 
szczególnie w zwalczaniu terroryzmu i przestępczości transgranicznej (Dz. Urz. 
UE L 210 z 06.08.2008, str. 1), zwanej dalej „decyzją Rady 2008/615/WSiSW”; 
2) 
w formie udzielania wsparcia w związku ze zgromadzeniami, imprezami 
masowymi lub podobnymi wydarzeniami, klęskami żywiołowymi oraz 
poważnymi wypadkami w celu ochrony porządku i bezpieczeństwa publicznego 

 
 
 
s. 259/274 
 
2025-07-03 
 
oraz zapobiegania przestępczości, o którym mowa w art. 18 decyzji Rady 
2008/615/WSiSW; 
3) 
w ramach udzielania pomocy przez specjalną jednostkę interwencyjną, o której 
mowa w decyzji Rady 2008/617/WSiSW z dnia 23 czerwca 2008 r. w sprawie 
usprawnienia współpracy pomiędzy specjalnymi jednostkami interwencyjnymi 
państw członkowskich Unii Europejskiej w sytuacjach kryzysowych (Dz. Urz. 
UE L 210 z 06.08.2008, str. 73).

***
## Art. 145i. {#policja-art-145i}

O wykonywaniu obowiązków służbowych przez policjantów lub 
pracowników Policji na terytorium innego państwa członkowskiego Unii 
Europejskiej, oraz określeniu warunków wykonywania tych obowiązków postanawia: 
1) 
Komendant Główny Policji – decyzją, w przypadku, o którym mowa w art. 145h 
pkt 1; 
2) 
minister właściwy do spraw wewnętrznych – zarządzeniem, w przypadkach, o 
których mowa w art. 145h pkt 2 i 3.

