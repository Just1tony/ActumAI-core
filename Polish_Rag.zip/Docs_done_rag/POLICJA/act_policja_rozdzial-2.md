---
id: act.policja.ch2
title: Ustawa o Policji — Rozdział 2
dz_u: Dz.U. 1990 Nr 30 poz. 179 (t.j. 2025 poz. 636, 718)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '4'
  last: 13b
source_pdf: D19900179Lj (1).pdf
chunking:
  strategy: by-article
  anchor_pattern: '## Art. {n}. {#policja-art-{n}}'
  hierarchy:
  - Rozdział
  - Art.
---

# Rozdział 2
 
## Art. 4. {#policja-art-4}

1. W Policji, z uwagi na zakres i charakter wykonywanych zadań, 
wyróżnia się następujące rodzaje służb: 
1) 
kryminalną; 
2) 
śledczą; 
3) 
spraw wewnętrznych; 
4) 
prewencyjną; 
5) 
kontrterrorystyczną; 
6) 
zwalczania cyberprzestępczości; 
7) 
wspomagającą. 
2. W skład Policji wchodzi policja sądowa. Szczegółowy zakres zadań i zasady 
organizacji policji sądowej określa, w drodze rozporządzenia, minister właściwy do 
spraw wewnętrznych, w porozumieniu z ministrem właściwym do spraw 
sprawiedliwości. 
3. W skład Policji wchodzą również: 
1) 
Akademia Policji w Szczytnie, ośrodki szkolenia i szkoły policyjne; 
2) 
wyodrębnione oddziały prewencji. 
3) 
(uchylony) 
3a. Organizację i zakres działania Akademii Policji w Szczytnie jako uczelni 
oraz tryb wyznaczania i odwoływania Komendanta-Rektora Akademii Policji 
w Szczytnie i osoby pełniącej w uczelni służb państwowych funkcję kierowniczą do 
spraw realizacji zadań uczelni jako jednostki organizacyjnej właściwej służby oraz 
tryb powierzania funkcji kierowniczych policjantom pełniącym służbę na 

 
 
 
s. 4/274 
 
2025-07-03 
 
stanowiskach nauczycieli akademickich reguluje ustawa z dnia 20 lipca 2018 r. – 
Prawo o szkolnictwie wyższym i nauce (Dz. U. z 2024 r. poz. 1571, 1871 i 1897). 
3b. (uchylony) 
4. Komendant Główny Policji, za zgodą ministra właściwego do spraw 
wewnętrznych, może powoływać, w uzasadnionych przypadkach, inne niż 
wymienione w ust. 1 rodzaje służb, określając ich właściwość terytorialną, organizację 
i zakres działania.

***
## Art. 4a. {#policja-art-4a}

(uchylony)

***
## Art. 5. {#policja-art-5}

1. Centralnym organem administracji rządowej, właściwym w sprawach 
ochrony bezpieczeństwa ludzi oraz utrzymania bezpieczeństwa i porządku 
publicznego, jest Komendant Główny Policji, podległy ministrowi właściwemu 
do spraw wewnętrznych. 
2. Komendant Główny Policji jest przełożonym wszystkich funkcjonariuszy 
Policji, zwanych dalej „policjantami”. 
3. Komendanta Głównego Policji powołuje i odwołuje Prezes Rady Ministrów 
na wniosek ministra właściwego do spraw wewnętrznych. 
4. Zastępców Komendanta Głównego Policji, w tym I Zastępcę, powołuje i 
odwołuje minister właściwy do spraw wewnętrznych na wniosek Komendanta 
Głównego Policji. 
5. W razie zwolnienia stanowiska Komendanta Głównego Policji, minister 
właściwy do spraw wewnętrznych, do czasu powołania nowego komendanta, 
powierza pełnienie obowiązków Komendanta Głównego Policji, na okres nie dłuższy 
niż 3 miesiące, jednemu z jego zastępców. 
6. W razie czasowej niemożności sprawowania funkcji przez Komendanta 
Głównego Policji, minister właściwy do spraw wewnętrznych, do czasu ustania 
przeszkody w sprawowaniu tej funkcji przez dotychczasowego komendanta, jednak 
na okres nie dłuższy niż 6 miesięcy, powierza pełnienie obowiązków Komendanta 
Głównego Policji jednemu z jego zastępców.

***
## Art. 5a. {#policja-art-5a}

1. Centralne Biuro Śledcze Policji, zwane dalej „CBŚP”, jest jednostką 
organizacyjną Policji służby śledczej realizującą na obszarze całego kraju zadania w 
zakresie rozpoznawania, zapobiegania i zwalczania przestępczości zorganizowanej. 

 
 
 
s. 5/274 
 
2025-07-03 
 
2. Komendant Centralnego Biura Śledczego Policji, zwany dalej „Komendantem 
CBŚP”, jest organem Policji podległym Komendantowi Głównemu Policji, kieruje 
CBŚP i jest przełożonym policjantów CBŚP. 
3. Siedzibą Komendanta CBŚP jest miasto stołeczne Warszawa. 
4. Komendanta CBŚP powołuje, spośród oficerów Policji, i odwołuje minister 
właściwy do spraw wewnętrznych na wniosek Komendanta Głównego Policji. 
5. Zastępców Komendanta CBŚP powołuje, spośród oficerów Policji, i odwołuje 
Komendant Główny Policji na wniosek Komendanta CBŚP. 
6. W razie zwolnienia stanowiska Komendanta CBŚP Komendant Główny 
Policji, do czasu powołania nowego komendanta, powierza pełnienie obowiązków 
Komendanta CBŚP, na okres nie dłuższy niż 6 miesięcy, jednemu z jego zastępców 
lub wyznaczonemu oficerowi Policji. 
7. W celu realizacji zadań określonych w ust. 1 Komendant CBŚP współdziała z 
innymi jednostkami organizacyjnymi Policji oraz właściwymi organami i 
instytucjami, w tym innych państw.

***
## Art. 5b. {#policja-art-5b}

1. Biuro Spraw Wewnętrznych Policji, zwane dalej „BSWP”, jest 
jednostką organizacyjną Policji służby spraw wewnętrznych realizującą na obszarze 
całego kraju zadania w zakresie rozpoznawania, zapobiegania i zwalczania 
przestępczości popełnianej przez policjantów i pracowników Policji oraz przestępstw 
przeciwko obrotowi gospodarczemu popełnianych na szkodę Policji, określonych w 
art. 296–306 Kodeksu karnego, a także wykrywania i ścigania sprawców tych 
przestępstw, a także – w zakresie zleconym przez Inspektora Nadzoru Wewnętrznego 
– funkcjonariuszy i pracowników Policji, Straży Granicznej i Służby Ochrony Państwa 
lub strażaków i pracowników Państwowej Straży Pożarnej. 
2. Komendant Biura Spraw Wewnętrznych Policji, zwany dalej „Komendantem 
BSWP”, jest organem Policji podległym Komendantowi Głównemu Policji, kieruje 
BSWP i jest przełożonym policjantów BSWP. 
3. Siedzibą Komendanta BSWP jest miasto stołeczne Warszawa. 
4. Komendanta BSWP powołuje, spośród oficerów Policji, i odwołuje minister 
właściwy do spraw wewnętrznych. 
5. Zastępców Komendanta BSWP powołuje, spośród oficerów Policji, i odwołuje 
minister właściwy do spraw wewnętrznych na wniosek Komendanta BSWP. 

 
 
 
s. 6/274 
 
2025-07-03 
 
6. W razie zwolnienia stanowiska Komendanta BSWP minister właściwy do 
spraw wewnętrznych, do czasu powołania nowego komendanta, powierza pełnienie 
obowiązków Komendanta BSWP, na okres nie dłuższy niż 6 miesięcy, jednemu z jego 
zastępców lub wyznaczonemu oficerowi spośród policjantów BSWP. 
7. W celu realizacji zadań określonych w ust. 1 Komendant BSWP współdziała 
z innymi jednostkami organizacyjnymi Policji oraz właściwymi organami i 
instytucjami, w tym innych państw. 
8. Komendant BSWP jest obowiązany niezwłocznie przedstawiać ministrowi 
właściwemu do spraw wewnętrznych, za pośrednictwem Inspektora Nadzoru 
Wewnętrznego, informacje i materiały mogące mieć istotne znaczenie dla 
sprawowania nadzoru, o którym mowa w art. 1b ustawy z dnia 21 czerwca 1996 r. o 
szczególnych formach sprawowania nadzoru przez ministra właściwego do spraw 
wewnętrznych (Dz. U. z 2024 r. poz. 309, 1222 i 1907 oraz z 2025 r. poz. 179). 
9. Minister właściwy do spraw wewnętrznych może w każdym czasie żądać 
informacji i materiałów z realizacji zadań przez Komendanta BSWP. 
10. Komendant BSWP przedstawia corocznie do dnia 31 stycznia ministrowi 
właściwemu do spraw wewnętrznych informację o działalności BSWP.

***
## Art. 5c. {#policja-art-5c}

1. Centralny Pododdział Kontrterrorystyczny Policji „BOA”, zwany 
dalej „BOA”, oraz samodzielne pododdziały kontrterrorystyczne Policji stanowią 
służbę 
kontrterrorystyczną, 
odpowiedzialną 
za 
prowadzenie 
działań 
kontrterrorystycznych oraz wspieranie działań jednostek organizacyjnych Policji w 
warunkach szczególnego zagrożenia lub wymagających użycia specjalistycznych sił i 
środków oraz specjalistycznej taktyki działania. 
2. BOA jest jednostką organizacyjną Policji podległą bezpośrednio 
Komendantowi Głównemu Policji, a obsługę czynności wspomagających BOA w 
zakresie organizacyjnym, kadrowym, logistycznym i technicznym zapewnia 
komenda, przy pomocy której Komendant Główny Policji wykonuje swoje zadania. 
3. Samodzielne pododdziały kontrterrorystyczne Policji podlegają bezpośrednio 
właściwym miejscowo komendantom wojewódzkim Policji lub Komendantowi 
Stołecznemu Policji, a obsługę czynności wspomagających te pododdziały w zakresie 
organizacyjnym, kadrowym, logistycznym i technicznym zapewniają komendy, przy 
których są te pododdziały umiejscowione. 

 
 
 
s. 7/274 
 
2025-07-03 
 
4. Dowódcę BOA powołuje, spośród oficerów służby kontrterrorystycznej, i 
odwołuje Komendant Główny Policji. 
5. 
Zastępców 
dowódcy 
BOA 
powołuje, 
spośród 
oficerów 
służby 
kontrterrorystycznej, i odwołuje Komendant Główny Policji na wniosek dowódcy 
BOA. 
6. Dowódcę samodzielnego pododdziału kontrterrorystycznego Policji powołuje, 
spośród oficerów służby kontrterrorystycznej, i odwołuje komendant wojewódzki 
Policji lub odpowiednio Komendant Stołeczny Policji po zasięgnięciu opinii dowódcy 
BOA. 
7. Zastępców dowódcy samodzielnych pododdziałów kontrterrorystycznych 
Policji powołuje, spośród oficerów służby kontrterrorystycznej, i odwołuje komendant 
wojewódzki Policji lub odpowiednio Komendant Stołeczny Policji na wniosek 
dowódcy samodzielnego pododdziału kontrterrorystycznego Policji. 
8. W razie zwolnienia stanowiska dowódcy BOA Komendant Główny Policji do 
czasu powołania nowego dowódcy powierza pełnienie obowiązków dowódcy BOA, 
na okres nie dłuższy niż 6 miesięcy, wyznaczonemu oficerowi służby 
kontrterrorystycznej. 
9. W celu realizacji działań, o których mowa w ust. 1, dowódca BOA oraz 
dowódcy samodzielnych pododdziałów kontrterrorystycznych Policji współdziałają z 
innymi jednostkami organizacyjnymi Policji oraz właściwymi instytucjami, w tym 
innych państw. 
10. W przypadku prowadzenia działań kontrterrorystycznych w rozumieniu art. 
2 pkt 2 ustawy z dnia 10 czerwca 2016 r. o działaniach antyterrorystycznych dowódca 
BOA kieruje do działań samodzielne pododdziały kontrterrorystyczne Policji oraz 
koordynuje przygotowanie i wykorzystanie ich sił i środków do realizacji tych działań. 
11. Kierujący działaniami antyterrorystycznymi, o którym mowa w art. 18 pkt 1 
ustawy z dnia 10 czerwca 2016 r. o działaniach antyterrorystycznych, powierza 
dowodzenie grupą kontrterrorystyczną policjantowi służby kontrterrorystycznej 
wskazanemu przez dowódcę BOA. 
12. W przypadku wystąpienia zdarzenia o charakterze terrorystycznym działania 
kontrterrorystyczne są realizowane przez BOA oraz samodzielne pododdziały 
kontrterrorystyczne Policji przed innymi działaniami. 

 
 
 
s. 8/274 
 
2025-07-03

***
## Art. 5d. {#policja-art-5d}

1. Centralne Biuro Zwalczania Cyberprzestępczości, zwane dalej 
„CBZC”, jest jednostką organizacyjną Policji służby zwalczania cyberprzestępczości, 
odpowiedzialną za realizację na obszarze całego kraju zadań w zakresie: 
1) 
rozpoznawania i zwalczania przestępstw popełnionych przy użyciu systemu 
informatycznego, systemu teleinformatycznego lub sieci teleinformatycznej oraz 
zapobiegania tym przestępstwom, a także wykrywania i ścigania sprawców tych 
przestępstw; 
2) 
wspierania w niezbędnym zakresie jednostek organizacyjnych Policji w 
rozpoznawaniu, zapobieganiu i zwalczaniu przestępstw, o których mowa w pkt 
1, a także wykrywaniu i ściganiu sprawców tych przestępstw. 
2. Komendant Centralnego Biura Zwalczania Cyberprzestępczości, zwany dalej 
„Komendantem CBZC”, jest organem Policji podległym Komendantowi Głównemu 
Policji, kieruje CBZC i jest przełożonym policjantów CBZC. 
3. Siedzibą Komendanta CBZC jest miasto stołeczne Warszawa. 
4. Komendanta CBZC powołuje, spośród oficerów Policji, i odwołuje minister 
właściwy do spraw wewnętrznych na wniosek Komendanta Głównego Policji. 
5. Zastępców Komendanta CBZC powołuje, spośród oficerów Policji, i odwołuje 
Komendant Główny Policji na wniosek Komendanta CBZC. 
6. W razie zwolnienia stanowiska Komendanta CBZC Komendant Główny 
Policji, do czasu powołania nowego komendanta, powierza pełnienie obowiązków 
Komendanta CBZC, na okres nie dłuższy niż 6 miesięcy, jednemu z jego zastępców 
lub wyznaczonemu oficerowi Policji. 
7. W celu realizacji zadań określonych w ust. 1 Komendant CBZC współdziała 
z innymi jednostkami organizacyjnymi Policji oraz właściwymi organami i 
instytucjami, w tym innych państw.

***
## Art. 5e. {#policja-art-5e}

1. Centralne Laboratorium Kryminalistyczne Policji, zwane dalej 
„CLKP”, jest jednostką organizacyjną Policji właściwą w zakresie kryminalistyki oraz 
technik kryminalistycznych stosowanych w procesie rozpoznawania, zapobiegania i 
zwalczania przestępczości oraz wykrywania i ścigania sprawców przestępstw. 
2. CLKP realizuje również zadania: 
1) 
w zakresie weryfikacji i poświadczenia, że strzelecka broń palna została 
pozbawiona cech użytkowych, oraz oznakowania strzeleckiej broni palnej 
pozbawionej cech użytkowych w rozumieniu ustawy z dnia 13 czerwca 2019 r. 

 
 
 
s. 9/274 
 
2025-07-03 
 
o wykonywaniu działalności gospodarczej w zakresie wytwarzania i obrotu 
materiałami wybuchowymi, bronią, amunicją oraz wyrobami i technologią o 
przeznaczeniu wojskowym lub policyjnym (Dz. U. z 2023 r. poz. 1743); 
2) 
Komendanta Głównego Policji w zakresie nadzoru merytorycznego nad 
funkcjonowaniem laboratoriów kryminalistycznych komend wojewódzkich 
Policji oraz Komendy Stołecznej Policji w odniesieniu do szkolenia i 
potwierdzania kompetencji personelu badawczego oraz określania standardów 
pracy stosowanych w tych laboratoriach. 
3. CLKP jest podmiotem określonym w art. 7 ust. 1 pkt 8 ustawy z dnia 20 lipca 
2018 r. – Prawo o szkolnictwie wyższym i nauce i prowadzi badania naukowe, o 
których mowa w art. 4 ust. 2 tej ustawy, i prace rozwojowe, o których mowa w art. 4 
ust. 3 tej ustawy, w zakresie, o którym mowa w ust. 1. 
4. Dyrektor Centralnego Laboratorium Kryminalistycznego Policji, zwany dalej 
„Dyrektorem CLKP”, jest organem Policji podległym Komendantowi Głównemu 
Policji, kieruje CLKP i jest przełożonym policjantów CLKP. 
5. Siedzibą Dyrektora CLKP jest miasto stołeczne Warszawa. 
6. Dyrektora CLKP powołuje spośród oficerów Policji i odwołuje minister 
właściwy do spraw wewnętrznych na wniosek Komendanta Głównego Policji. 
7. Zastępców Dyrektora CLKP powołuje spośród oficerów Policji i odwołuje 
Komendant Główny Policji na wniosek Dyrektora CLKP. 
8. W razie zwolnienia stanowiska Dyrektora CLKP Komendant Główny Policji 
do czasu powołania nowego dyrektora powierza pełnienie obowiązków Dyrektora 
CLKP, na okres nie dłuższy niż 6 miesięcy, jednemu z jego zastępców lub 
wyznaczonemu oficerowi spośród policjantów CLKP. 
9. W celu realizacji zadań określonych w ust. 1 Dyrektor CLKP współdziała z 
innymi jednostkami organizacyjnymi Policji oraz właściwymi organami i 
instytucjami, w tym innych państw. 
10. Minister właściwy do spraw wewnętrznych może, na wniosek Komendanta 
Głównego Policji, zobowiązać Dyrektora CLKP do zrealizowania dodatkowych 
czynności, jeżeli jest to niezbędne ze względu na potrzeby bezpieczeństwa i porządku 
publicznego lub jeżeli celem jest wykonanie zadań wynikających z obowiązujących 
Rzeczpospolitą Polską umów i zobowiązań międzynarodowych, uwzględniając 
kwalifikacje policjantów CLKP i pracowników zatrudnionych w CLKP oraz 
wyposażenie w specjalistyczny sprzęt laboratoryjny. 

 
 
 
s. 10/274 
 
2025-07-03

***
## Art. 6. {#policja-art-6}

1. Organami administracji rządowej na obszarze województwa w 
sprawach, o których mowa w art. 5 ust. 1, są: 
1) 
wojewoda przy pomocy komendanta wojewódzkiego Policji działającego w jego 
imieniu albo komendant wojewódzki Policji działający w imieniu własnym w 
sprawach: 
a) 
wykonywania czynności operacyjno-rozpoznawczych, dochodzeniowo-
-śledczych i czynności z zakresu ścigania wykroczeń, 
b) 
wydawania indywidualnych aktów administracyjnych, jeżeli ustawy tak 
stanowią; 
2) 
komendant powiatowy (miejski) Policji; 
3) 
komendant komisariatu Policji. 
2. Terytorialny zasięg działania organów, o których mowa w ust. 1 pkt 1 i 2, 
odpowiada zasadniczemu podziałowi administracyjnemu Państwa, z zastrzeżeniem 
ust. 3–5. 
3. Wyłącza się z terytorialnego zasięgu działania komendanta wojewódzkiego 
Policji właściwego dla województwa mazowieckiego obszar m.st. Warszawy oraz 
powiatów: grodziskiego, legionowskiego, mińskiego, nowodworskiego, otwockiego, 
piaseczyńskiego, pruszkowskiego, warszawskiego zachodniego i wołomińskiego. 
3a. W miastach będących siedzibą władz miasta na prawach powiatu i powiatu 
mającego siedzibę władz w tym mieście, można utworzyć komendę miejską Policji 
wykonującą zadania na obszarze tego miasta i powiatu. 
3b. Minister właściwy do spraw wewnętrznych, w drodze rozporządzenia, 
tworzy i znosi komendy miejskie Policji, o których mowa w ust. 3a, uwzględniając 
uwarunkowania administracyjno-geograficzne i demograficzne miasta i powiatu. 
4. Komendant Stołeczny Policji wykonuje na obszarze, o którym mowa w ust. 3, 
zadania i kompetencje odpowiadające zadaniom i kompetencjom komendanta 
wojewódzkiego Policji. 
4a. Na obszarze m.st. Warszawy zadania i kompetencje odpowiadające zadaniom 
i kompetencjom komendanta powiatowego (miejskiego) Policji wykonuje właściwy 
terytorialnie komendant rejonowy Policji. 
4b. Minister właściwy do spraw wewnętrznych określa, w drodze 
rozporządzenia, właściwość terytorialną komendantów rejonowych Policji, tworzy i 
znosi komendy rejonowe Policji oraz ustala ich nazwy. Właściwość terytorialna 
komendantów rejonowych Policji obejmuje obszar jednej dzielnicy lub kilku dzielnic. 

 
 
 
s. 11/274 
 
2025-07-03 
 
5. Komenda Stołeczna Policji stanowi aparat pomocniczy Komendanta 
Stołecznego Policji, wykonujący swoje zadania na obszarze, o którym mowa w ust. 3.

***
## Art. 6a. {#policja-art-6a}

1. W postępowaniu administracyjnym, w sprawach związanych z 
wykonywaniem zadań i kompetencji Policji, jeżeli ustawy nie stanowią inaczej, 
organem właściwym jest komendant powiatowy (miejski) Policji, a na obszarze 
m.st. Warszawy – komendant rejonowy Policji. 
2. W postępowaniu administracyjnym w sprawach, o których mowa w ust. 1, 
organami wyższego stopnia są: 
1) 
w stosunku do komendanta powiatowego (miejskiego) Policji – komendant 
wojewódzki Policji; 
1a) w stosunku do komendanta rejonowego Policji – Komendant Stołeczny Policji; 
2) 
w stosunku do komendanta wojewódzkiego Policji – Komendant Główny Policji.

***
## Art. 6b. {#policja-art-6b}

1. Komendanta wojewódzkiego Policji powołuje i odwołuje minister 
właściwy do spraw wewnętrznych na wniosek Komendanta Głównego Policji złożony 
po zasięgnięciu opinii wojewody. 
2. Komendanta Stołecznego Policji powołuje i odwołuje minister właściwy do 
spraw wewnętrznych na wniosek  
Komendanta Głównego Policji złożony po zasięgnięciu opinii wojewody oraz 
opinii Prezydenta m.st. Warszawy. 
3. Komendant Główny Policji, na wniosek komendanta wojewódzkiego lub 
odpowiednio Komendanta Stołecznego Policji, powołuje i odwołuje do trzech 
zastępców komendanta wojewódzkiego lub Komendanta Stołecznego Policji, w tym I 
zastępcę. 
4. Na stanowisko komendanta wojewódzkiego i Komendanta Stołecznego Policji 
oraz zastępców komendanta wojewódzkiego i Komendanta Stołecznego Policji 
powołuje się oficerów Policji, z wyjątkiem stanowisk zastępców do spraw służb 
wspomagających działalność Policji, na które można powołać także osoby niebędące 
policjantami. 
5. W razie zwolnienia stanowiska komendanta wojewódzkiego lub Komendanta 
Stołecznego Policji Komendant Główny Policji, do czasu powołania nowego 
komendanta, powierza pełnienie obowiązków komendanta wojewódzkiego albo 
Komendanta Stołecznego Policji, na okres nie dłuższy niż 6 miesięcy, jednemu z jego 
zastępców lub wyznaczonemu oficerowi. 

 
 
 
s. 12/274 
 
2025-07-03 
 
6. W przypadku nieotrzymania opinii, o których mowa w ust. 1 lub ust. 2, 
minister właściwy do spraw wewnętrznych, na wniosek Komendanta Głównego 
Policji, może powołać komendanta wojewódzkiego albo Komendanta Stołecznego 
Policji po upływie 14 dni od dnia przedstawienia wniosku o wydanie opinii.

***
## Art. 6c. {#policja-art-6c}

1. Komendanta powiatowego (miejskiego) Policji powołuje i odwołuje 
komendant wojewódzki Policji, po zasięgnięciu opinii starosty. Przepisu art. 35 ust. 3 
pkt 1 ustawy z dnia 5 czerwca 1998 r. o samorządzie powiatowym (Dz. U. z 2024 r. 
poz. 107 i 1907) nie stosuje się. 
2. Komendanta rejonowego Policji powołuje i odwołuje Komendant Stołeczny 
Policji, po zasięgnięciu opinii Prezydenta m.st. Warszawy. Przepisu art. 35 ust. 3 pkt 
1 ustawy z dnia 5 czerwca 1998 r. o samorządzie powiatowym nie stosuje się. 
3. Komendant wojewódzki Policji, na wniosek komendanta powiatowego 
(miejskiego) Policji, powołuje i odwołuje I zastępcę i pozostałych zastępców 
komendanta powiatowego (miejskiego) Policji. 
4. Komendant Stołeczny Policji, na wniosek komendanta rejonowego Policji, 
powołuje i odwołuje I zastępcę i pozostałych zastępców komendanta rejonowego 
Policji. 
5. Na stanowisko komendanta powiatowego (miejskiego) i komendanta 
rejonowego Policji oraz zastępcy komendanta powiatowego (miejskiego) i 
komendanta rejonowego Policji powołuje się oficerów Policji. 
6. W razie zwolnienia stanowiska komendanta powiatowego (miejskiego) Policji 
komendant wojewódzki Policji, do czasu powołania nowego komendanta, powierza 
pełnienie obowiązków komendanta powiatowego (miejskiego) Policji, na okres nie 
dłuższy niż 6 miesięcy, jednemu z jego zastępców lub wyznaczonemu oficerowi. 
7. W razie zwolnienia stanowiska komendanta rejonowego Policji Komendant 
Stołeczny Policji, do czasu powołania nowego komendanta, powierza pełnienie 
obowiązków komendanta rejonowego Policji, na okres nie dłuższy niż 6 miesięcy, 
jednemu z jego zastępców lub wyznaczonemu oficerowi. 
8. W przypadku nieotrzymania opinii, o których mowa w ust. 1 lub ust. 2, 
komendant wojewódzki albo Komendant Stołeczny Policji może powołać 
odpowiednio komendanta powiatowego (miejskiego) albo komendanta rejonowego 
Policji po upływie 14 dni od dnia przedstawienia wniosku o wydanie opinii. 

 
 
 
s. 13/274 
 
2025-07-03

***
## Art. 6d. {#policja-art-6d}

1. Komendanta komisariatu Policji powołuje i odwołuje komendant 
powiatowy (miejski) Policji po zasięgnięciu opinii właściwego terytorialnie wójta 
(burmistrza lub prezydenta miasta) lub wójtów. Opiniowanie to nie dotyczy 
komendanta komisariatu specjalistycznego. 
2. Zastępców komendanta komisariatu Policji powołuje i odwołuje komendant 
powiatowy (miejski) Policji na wniosek komendanta komisariatu Policji. 
3. Na stanowisko komendanta komisariatu Policji i zastępcy komendanta 
komisariatu Policji powołuje się oficerów lub aspirantów Policji. 
4. W razie zwolnienia stanowiska komendanta komisariatu Policji, komendant 
powiatowy (miejski) Policji, do czasu powołania nowego komendanta, powierza, po 
zasięgnięciu opinii wójta (burmistrza lub prezydenta miasta) lub wójtów, pełnienie 
obowiązków komendanta komisariatu Policji, na okres nie dłuższy niż 3 miesiące, 
jednemu z jego zastępców, a w razie braku zastępców – innemu policjantowi. 
5. W razie czasowej niemożności sprawowania funkcji przez komendanta 
komisariatu Policji, komendant powiatowy (miejski) Policji, do czasu ustania 
przeszkody w sprawowaniu tej funkcji przez dotychczasowego komendanta, powierza 
pełnienie obowiązków komendanta komisariatu Policji jednemu z jego zastępców, a 
w razie braku zastępców – innemu policjantowi. 
6. Na obszarze m.st. Warszawy przepisy ust. 1 i 3–5 stosuje się odpowiednio do 
powoływania i odwoływania komendanta komisariatu Policji przez komendanta 
rejonowego Policji, po zasięgnięciu opinii Prezydenta m.st. Warszawy. 
7. Na obszarze m.st. Warszawy przepisy ust. 2 i 3 stosuje się odpowiednio do 
powoływania zastępców komendanta komisariatu Policji przez komendanta 
rejonowego Policji. 
8. W przypadku nieotrzymania opinii, o której mowa w ust. 1 lub 6: 
1) 
komendant powiatowy (miejski) Policji może powołać komendanta komisariatu 
Policji po upływie 14 dni od dnia przedstawienia wniosku o wydanie opinii; 
2) 
komendant rejonowy Policji może powołać komendanta komisariatu Policji po 
upływie 21 dni od dnia przedstawienia wniosku o wydanie opinii.

***
## Art. 6da. {#policja-art-6da}

Policjant oraz osoba powoływana na stanowisko Komendanta CBŚP, 
zastępcy Komendanta CBŚP, Komendanta BSWP, zastępcy Komendanta BSWP, 
dowódcy BOA, zastępcy dowódcy BOA, dowódcy samodzielnego pododdziału 
kontrterrorystycznego Policji, zastępcy dowódcy samodzielnego pododdziału 

 
 
 
s. 14/274 
 
2025-07-03 
 
kontrterrorystycznego Policji, Komendanta CBZC, zastępcy Komendanta CBZC, 
Dyrektora CLKP, zastępcy Dyrektora CLKP, komendanta wojewódzkiego Policji, 
Komendanta Stołecznego Policji, zastępcy komendanta wojewódzkiego Policji, 
zastępcy Komendanta Stołecznego Policji, komendanta powiatowego (miejskiego) 
Policji, komendanta rejonowego Policji, zastępcy komendanta powiatowego 
(miejskiego) Policji, zastępcy komendanta rejonowego Policji, komendanta 
komisariatu Policji, zastępcy komendanta komisariatu Policji, komendanta 
komisariatu specjalistycznego Policji, a także mianowana na stanowisko dyrektora i 
zastępcy dyrektora komórki organizacyjnej oraz naczelnika mogą zostać poddani 
weryfikacji, o której mowa w art. 11a ust. 3 pkt 2 ustawy z dnia 21 czerwca 1996 r. o 
szczególnych formach sprawowania nadzoru przez ministra właściwego do spraw 
wewnętrznych. Weryfikacja, o której mowa w zdaniu pierwszym, może być 
prowadzona także wobec policjanta oraz osoby, którzy zajmują te stanowiska.

***
## Art. 6e. {#policja-art-6e}

1. Odwołać ze stanowiska Komendanta CBŚP, zastępcy Komendanta 
CBŚP, Komendanta BSWP, zastępcy Komendanta BSWP, dowódcy BOA, zastępcy 
dowódcy BOA, dowódcy samodzielnego pododdziału kontrterrorystycznego Policji, 
zastępcy dowódcy samodzielnego pododdziału kontrterrorystycznego Policji, 
Komendanta CBZC, zastępcy Komendanta CBZC, Dyrektora CLKP, zastępcy 
Dyrektora CLKP, komendanta wojewódzkiego Policji, Komendanta Stołecznego 
Policji, pełniącego obowiązki komendanta wojewódzkiego Policji albo Komendanta 
Stołecznego Policji, komendanta powiatowego (miejskiego) Policji, komendanta 
rejonowego Policji, zastępcy komendanta powiatowego (miejskiego) Policji, zastępcy 
komendanta rejonowego Policji, komendanta komisariatu Policji i zastępcy 
komendanta komisariatu Policji można w każdym czasie. 
2. W przypadku braku opinii, o których mowa w art. 6b ust. 1 i 2, art. 6c ust. 1 i 
2 oraz art. 6d ust. 1 i 6, organ uprawniony do powołania na stanowisko komendanta 
może odwołać odpowiednio komendantów: wojewódzkiego i Stołecznego, 
powiatowego (miejskiego), rejonowego lub komendanta komisariatu Policji po 
upływie 14 dni od dnia doręczenia wniosku o wydanie opinii. 
3. Policjanta odwołanego ze stanowiska przenosi się do dyspozycji przełożonego 
policjanta uprawnionego do odwołania ze stanowiska, z zastrzeżeniem że policjanta 
odwołanego ze stanowiska Komendanta CBŚP, Komendanta BSWP, dowódcy BOA, 
Komendanta CBZC, Dyrektora CLKP, komendanta wojewódzkiego Policji i 

 
 
 
s. 15/274 
 
2025-07-03 
 
Komendanta Stołecznego Policji przenosi się do dyspozycji Komendanta Głównego 
Policji. Policjant przez okres 6 miesięcy ma prawo do uposażenia w wysokości 
przysługującej przed odwołaniem.

***
## Art. 6f. {#policja-art-6f}

Komendant wojewódzki Policji oraz komendant powiatowy (miejski) 
Policji są przełożonymi policjantów na terenie swojego działania.

***
## Art. 6g. {#policja-art-6g}

Komendant Główny Policji, komendant wojewódzki Policji, komendant 
powiatowy (miejski) Policji wykonują swoje zadania przy pomocy podległych im 
komend, a komendant komisariatu Policji – przy pomocy komisariatu.

***
## Art. 6h. {#policja-art-6h}

(uchylony)

***
## Art. 6i. {#policja-art-6i}

Kierownicy jednostek organizacyjnych Policji są obowiązani 
współdziałać z Biurem Nadzoru Wewnętrznego w zakresie realizacji jego zadań, w 
szczególności: 
1) 
udostępniać, na wniosek Inspektora Nadzoru Wewnętrznego, niezbędne 
uzbrojenie, wyposażenie, urządzenia i środki techniczne; 
2) 
zapewniać warunki niezbędne do sprawnej realizacji zadań przez inspektorów 
Biura Nadzoru Wewnętrznego, w szczególności przez zapewnienie swobodnego 
wstępu na teren jednostki organizacyjnej Policji, niezwłocznego przedstawiania 
żądanych informacji i dokumentów, terminowego udzielania ustnych i 
pisemnych wyjaśnień, a także udostępnianie niezbędnych urządzeń technicznych 
i zapewnienie dostępu do Internetu oraz, w miarę możliwości, oddzielnego 
pomieszczenia z odpowiednim wyposażeniem; 
3) 
przekazywać dane policjantów objętych weryfikacją, o której mowa w art. 11a 
ust. 3 pkt 2 ustawy z dnia 21 czerwca 1996 r. o szczególnych formach 
sprawowania nadzoru przez ministra właściwego do spraw wewnętrznych, 
najpóźniej w terminie 14 dni przed planowanym: 
a) 
powołaniem na stanowiska komendantów i ich zastępców, dowódców 
jednostek organizacyjnych i ich zastępców, Dyrektora CLKP i jego 
zastępców, dyrektorów i ich zastępców oraz naczelników, 
b) 
oddelegowaniem do pełnienia służby lub wykonywaniem zadań poza 
granicami kraju na okres przekraczający 14 dni, z wyłączeniem 
oddelegowania do pełnienia służby poza granicami państwa w kontyngencie 
policyjnym, o którym mowa w art. 145a ust. 1 pkt 2 i 3, 

 
 
 
s. 16/274 
 
2025-07-03 
 
c) 
wystąpieniem o mianowanie na stopnie generalnego inspektora Policji i 
nadinspektora Policji, 
d) 
wystąpieniem o przedterminowe mianowanie w korpusie oficerów 
młodszych i starszych w Policji, 
e) 
wystąpieniem o wyróżnienie, na wniosek ministra właściwego do spraw 
wewnętrznych, orderami i odznaczeniami, o których mowa w ustawie z dnia 
16 października 1992 r. o orderach i odznaczeniach (Dz. U. z 2023 r. poz. 
2053), 
f) 
oddelegowaniem 
do 
wykonywania 
zadań 
w 
Biurze 
Nadzoru 
Wewnętrznego; 
4) 
udostępniać dokumentację z kontroli, o której mowa w art. 12 ust. 3 pkt 2 ustawy 
z dnia 5 sierpnia 2010 r. o ochronie informacji niejawnych (Dz. U. z 2024 r. poz. 
632 i 1222).

***
## Art. 7. {#policja-art-7}

1. Komendant Główny Policji określa: 
1) 
szczegółowe zasady organizacji i zakres działania komend, komisariatów i 
innych jednostek organizacyjnych Policji; 
2) 
metody i formy wykonywania zadań przez poszczególne służby policyjne, w 
zakresie nieobjętym innymi przepisami wydanymi na podstawie ustawy; 
3) 
(uchylony) 
4) 
(uchylony) 
4a) programy szkoleń zawodowych policjantów, program szkolenia dla policjantów 
w służbie kandydackiej oraz program szkolenia dla policjantów w służbie 
kontraktowej; 
4b) (uchylony) 
5) 
kryteria zdrowotne i użytkowe doboru psów i koni do realizacji zadań Policji, 
sposób szkolenia przewodników psów służbowych i kandydatów na 
przewodników psów służbowych oraz policjantów-jeźdźców i kandydatów na 
policjantów--jeźdźców oraz szkolenia psów służbowych i koni służbowych, tryb 
i sposób przekazywania psów służbowych i koni służbowych między 
jednostkami organizacyjnymi Policji, sposób prowadzenia ewidencji psów 
służbowych i ewidencji koni służbowych oraz tryb i sposób współpracy między 
jednostkami organizacyjnymi Policji w trakcie realizacji nadzoru nad sposobem 
sprawowania opieki nad psami służbowymi i końmi służbowymi; 

 
 
 
s. 17/274 
 
2025-07-03 
 
6) 
(uchylony) 
7) 
zasady etyki zawodowej policjantów, po zasięgnięciu opinii związków 
zawodowych; 
8) 
organizację, rzeczowy i miejscowy zakres działania oraz zasady współdziałania 
CBŚP z innymi jednostkami organizacyjnymi Policji; 
9) 
w uzgodnieniu z ministrem właściwym do spraw wewnętrznych, organizację, 
rzeczowy i miejscowy zakres działania oraz zasady współdziałania BSWP z 
innymi jednostkami organizacyjnymi Policji; 
10) organizację i zakres działania BOA oraz zasady współdziałania z innymi 
jednostkami organizacyjnymi Policji; 
11) strukturę 
organizacyjną 
i 
etatową 
samodzielnych 
pododdziałów 
kontrterrorystycznych Policji; 
12) szczegółowe warunki odbywania doskonalenia zawodowego dla służby 
kontrterrorystycznej; 
13) organizację i zakres działania oraz zasady współdziałania CBZC z innymi 
jednostkami organizacyjnymi Policji; 
14) organizację i zakres działania CLKP oraz zasady współdziałania z innymi 
jednostkami organizacyjnymi Policji. 
2. Komendant wojewódzki Policji określa właściwość terytorialną komisariatów 
Policji na terenie swojego działania. 
3. Komendant Główny Policji może tworzyć i likwidować ośrodki szkolenia i 
szkoły policyjne. 
4. Regulaminy komend, komisariatów i innych jednostek organizacyjnych Policji 
ustala właściwy dla nich komendant Policji w porozumieniu z właściwym 
przełożonym. Regulamin komendy wojewódzkiej Policji nie stanowi części regu-
laminu urzędu wojewódzkiego. 
5. Regulamin BSWP ustala minister właściwy do spraw wewnętrznych.

***
## Art. 8. {#policja-art-8}

1. Komendant wojewódzki Policji w porozumieniu z Komendantem 
Głównym Policji tworzy, w razie potrzeby, komisariat kolejowy, wodny, lotniczy lub 
inny komisariat specjalistyczny. Komendanci komisariatów specjalistycznych 
podlegają właściwemu terytorialnie komendantowi wojewódzkiemu Policji. 
2. Komendanta komisariatu specjalistycznego Policji powołuje i odwołuje 
komendant wojewódzki Policji. 

 
 
 
s. 18/274 
 
2025-07-03 
 
3. (uchylony)

***
## Art. 8a. {#policja-art-8a}

1. Komendant powiatowy (miejski) Policji może tworzyć rewiry 
dzielnicowych oraz posterunki Policji na zasadach określonych przez Komendanta 
Głównego Policji. 
2. Kierownika rewiru oraz kierownika posterunku Policji mianuje i zwalnia ze 
stanowiska komendant powiatowy (miejski) Policji, po zasięgnięciu opinii wójta 
(burmistrza lub prezydenta miasta), chyba że do wyrażenia opinii w tej sprawie 
upoważniony został organ wykonawczy jednostki pomocniczej gminy. 
3. Do zadań kierownika rewiru oraz kierownika posterunku Policji należy w 
szczególności: 
1) 
rozpoznawanie zagrożeń i przeciwdziałanie przyczynom ich powstawania; 
2) 
inicjowanie i organizowanie działań społeczności lokalnych mających na celu 
zapobieganie popełnianiu przestępstw i wykroczeń oraz innym zjawiskom 
kryminogennym; 
3) 
wykonywanie 
czynności 
administracyjno-porządkowych 
oraz 
innych 
niecierpiących zwłoki czynności związanych z zawiadomieniem o przestępstwie 
i zabezpieczeniem miejsca zdarzenia.

***
## Art. 9. {#policja-art-9}

(uchylony)

***
## Art. 10. {#policja-art-10}

1. Komendanci Policji, z zastrzeżeniem ust. 1a, składają roczne 
sprawozdania ze swojej działalności, a także informacje o stanie porządku i 
bezpieczeństwa 
publicznego 
właściwym 
wojewodom, 
starostom, 
wójtom 
(burmistrzom lub prezydentom miast), a także radom powiatu i radom gmin. W razie 
zagrożenia bezpieczeństwa publicznego lub zakłócenia porządku publicznego 
sprawozdania i informacje składa się tym organom niezwłocznie na każde ich żądanie. 
1a. Komendant Stołeczny Policji składa sprawozdanie, a także informacje, o 
których mowa w ust. 1, Wojewodzie Mazowieckiemu oraz, w zakresie dotyczącym 
działalności Policji na obszarze m.st. Warszawy, Prezydentowi m.st. Warszawy i 
Radzie m.st. Warszawy. Komendanci rejonowi Policji nie składają odrębnych 
sprawozdań. 
2. W zakresie wykrywania przestępstw i ścigania ich sprawców sprawozdania i 
informacje, o których mowa w ust. 1, mogą być przekazywane wyłącznie sądom i 
prokuratorom, na ich żądanie. 

 
 
 
s. 19/274 
 
2025-07-03 
 
3. Rada powiatu (miasta) oraz rada gminy na podstawie sprawozdań i informacji, 
o których mowa w ust. 1, może określić, w drodze uchwały, istotne dla wspólnoty 
samorządowej zagrożenia bezpieczeństwa i porządku publicznego. 
4. Uchwała, o której mowa w ust. 3, nie może dotyczyć wykonania konkretnej 
czynności służbowej ani określać sposobu wykonywania zadań przez Policję. 
5. Komendanci powiatowi (miejscy) Policji są obowiązani udostępniać komisji 
bezpieczeństwa i porządku, na żądanie jej przewodniczącego, dokumenty i informacje 
dotyczące pracy Policji na terenie powiatu, z wyjątkiem akt personalnych 
pracowników i funkcjonariuszy, materiałów operacyjno-rozpoznawczych lub 
dochodzeniowo-śledczych oraz akt w indywidualnych sprawach administracyjnych. 
6. Przepisu ust. 1 nie stosuje się do Komendanta CBŚP, Komendanta BSWP oraz 
Komendanta CBZC.

***
## Art. 11. {#policja-art-11}

1. Wójt (burmistrz, prezydent miasta) lub starosta może żądać od 
właściwego komendanta Policji przywrócenia stanu zgodnego z porządkiem prawnym 
lub podjęcia działań zapobiegających naruszeniu prawa, a także zmierzających do 
usunięcia zagrożenia bezpieczeństwa i porządku publicznego. 
2. Żądanie, o którym mowa w ust. 1, nie może dotyczyć czynności 
operacyjno-rozpoznawczych, dochodzeniowo-śledczych oraz czynności z zakresu 
ścigania wykroczeń. Żądanie to nie może dotyczyć wykonania konkretnej czynności 
służbowej ani określać sposobu wykonania zadania przez Policję. 
3. Wójt (burmistrz, prezydent miasta) lub starosta ponoszą wyłączną 
odpowiedzialność za treść żądania, o którym mowa w ust. 1. 
4. Żądanie, o którym mowa w ust. 1, przekazane ustnie wymaga potwierdzenia 
na piśmie. 
5. Właściwy komendant Policji niezwłocznie przedkłada sprawę komendantowi 
Policji wyższego stopnia, jeżeli nie jest w stanie wykonać żądania, o którym mowa w 
ust. 1. 
6. Żądanie, o którym mowa w ust. 1, naruszające prawo jest nieważne. O 
nieważności żądania stwierdza wojewoda. 
7. Przepisu ust. 1 nie stosuje się do Komendanta CBŚP, Komendanta BSWP oraz 
Komendanta CBZC.

***
## Art. 12. {#policja-art-12}

1. Minister właściwy do spraw wewnętrznych określa, w drodze 
rozporządzenia: 

 
 
 
s. 20/274 
 
2025-07-03 
 
1) 
uzbrojenie Policji; 
2) 
umundurowanie, dystynkcje i znaki identyfikacyjne policjantów; 
3) 
zasady i sposób noszenia umundurowania oraz orderów, odznaczeń, medali i 
odznak; 
4) 
normy umundurowania; 
5) 
wzór i tryb nadawania sztandaru jednostkom organizacyjnym Policji; 
6) 
wzór odznak policyjnych oraz szczegółowe zasady i tryb ich nadawania 
policjantom. 
2. Komendant Główny Policji określa zasady naliczeń etatowych w Policji, z 
zastrzeżeniem ust. 2a. 
2a. Minister właściwy do spraw wewnętrznych określa zasady naliczeń 
etatowych w BSWP.

***
## Art. 13. {#policja-art-13}

1. Koszty związane z funkcjonowaniem Policji są pokrywane z budżetu 
państwa. 
1a. (uchylony) 
1b. Koszty związane z podejmowanymi przez Policję czynnościami operacyjno-
-rozpoznawczymi mogą być pokrywane ze środków przekazanych przez państwa 
członkowskie 
i instytucje 
Unii 
Europejskiej 
oraz 
w ramach 
współpracy 
międzynarodowej przez inne państwa oraz organizacje międzynarodowe na podstawie 
odrębnych przepisów. 
2. Etaty Policji określa ustawa budżetowa. 
3. Jednostki samorządu terytorialnego, państwowe jednostki organizacyjne, 
stowarzyszenia, fundacje, banki oraz instytucje ubezpieczeniowe mogą uczestniczyć 
w pokrywaniu wydatków inwestycyjnych, modernizacyjnych lub remontowych oraz 
kosztów utrzymania i funkcjonowania jednostek organizacyjnych Policji, a także 
zakupu niezbędnych dla ich potrzeb towarów i usług. 
3a. (uchylony) 
3b. (uchylony) 
3c. (uchylony) 
4. Na wniosek rady powiatu lub rady gminy liczba etatów Policji w rewirach 
dzielnicowych i posterunkach Policji na terenie powiatu lub gminy może ulec 
zwiększeniu ponad liczbę ustaloną na zasadach określonych w art. 12 ust. 2, jeżeli 
organy te zapewnią pokrywanie kosztów utrzymania etatów Policji przez okres co 

 
 
 
s. 21/274 
 
2025-07-03 
 
najmniej 5 lat, na warunkach określonych w porozumieniu zawartym między organem 
powiatu lub gminy a właściwym komendantem wojewódzkim Policji i zatwierdzonym 
przez Komendanta Głównego Policji. 
4a. Rada powiatu lub rada gminy może przekazać, na warunkach określonych w 
porozumieniu zawartym między organem wykonawczym powiatu lub gminy a 
właściwym komendantem powiatowym (miejskim) Policji, środki finansowe 
stanowiące dochody własne powiatu lub gminy, dla Policji z przeznaczeniem na: 
1) 
rekompensatę pieniężną za czas służby przekraczający normę określoną w art. 33 
ust. 2, 
2) 
nagrodę za osiągnięcia w służbie, 
dla policjantów właściwych miejscowo komend powiatowych (miejskich) i 
komisariatów, którzy realizują zadania z zakresu służby prewencyjnej. 
4b. Porozumienie, o którym mowa w ust. 4a, określa w szczególności: 
1) 
rodzaje ustawowych zadań Policji, finansowanych na podstawie porozumienia: 
a) 
wykonywanych w czasie przekraczającym normę określoną w art. 33 ust. 2, 
b) 
za wykonywanie których może być przyznana nagroda za osiągnięcia w 
służbie; 
2) 
wysokość oraz tryb i terminy przekazywania środków finansowych, o których 
mowa w ust. 4a; 
3) 
sposób dokonywania oceny prawidłowości wykonania porozumienia. 
4c. Tworzy się Fundusz Wsparcia Policji, zwany dalej „Funduszem”, składający 
się z funduszy: centralnego, wojewódzkich i Szkół Policji. 
4d. Fundusz jest państwowym funduszem celowym. 
4e. Środki finansowe uzyskane przez Policję w trybie i na warunkach 
określonych w ust. 3 i 4a na podstawie umów i porozumień zawartych przez: 
1) 
Komendanta Głównego Policji – są przychodami funduszu centralnego; 
2) 
komendantów odpowiednio wojewódzkich lub Komendanta Stołecznego Policji 
albo podległych im komendantów powiatowych (miejskich, rejonowych) Policji 
– są przychodami wojewódzkich funduszy; 
3) 
Komendanta-Rektora Akademii Policji w Szczytnie oraz komendantów szkół 
policyjnych – są przychodami funduszu Szkół Policji. 
4f. Środki Funduszu są przeznaczone na: 

 
 
 
s. 22/274 
 
2025-07-03 
 
1) 
pokrywanie wydatków inwestycyjnych, modernizacyjnych lub remontowych 
oraz kosztów utrzymania i funkcjonowania jednostek organizacyjnych Policji, a 
także zakup niezbędnych na ich potrzeby towarów i usług; 
2) 
rekompensatę pieniężną dla policjantów za czas służby przekraczający normę 
określoną w art. 33 ust. 2; 
3) 
nagrody dla policjantów za osiągnięcia w służbie. 
4g. Środkami Funduszu dysponują: 
1) 
Komendant Główny Policji – w zakresie funduszu centralnego; 
2) 
odpowiednio komendanci wojewódzcy lub Komendant Stołeczny Policji – w 
zakresie funduszy wojewódzkich; 
3) 
Komendant-Rektor Akademii Policji w Szczytnie oraz komendanci szkół 
policyjnych – w zakresie funduszu Szkół Policji. 
4h. Komendant Główny Policji sporządza łączny plan finansowy i łączne 
sprawozdanie finansowe Funduszu. 
4ha. Zmiany kwot przychodów i kosztów lub dochodów i wydatków Funduszu 
ujętych w planie finansowym Funduszu dokonuje dysponent środków Funduszu. 
4hb. (uchylony) 
4hc. (uchylony) 
4i. Minister właściwy do spraw wewnętrznych w porozumieniu z ministrem 
właściwym do spraw finansów publicznych określi, w drodze rozporządzenia, 
szczegółowe zasady gospodarki finansowej Funduszu oraz tryb i terminy sporządzania 
jego planów i sprawozdań finansowych, uwzględniając postanowienia umów i 
porozumień oraz racjonalne gospodarowanie środkami. 
5. Minister właściwy do spraw wewnętrznych w porozumieniu z ministrem 
właściwym do spraw finansów publicznych określą, w drodze rozporządzenia, 
szczegółowe warunki porozumienia, o którym mowa w ust. 4.

***
## Art. 13a. {#policja-art-13a}

(uchylony)

***
## Art. 13b. {#policja-art-13b}

Dzień 24 lipca ustanawia się Świętem Policji. 

 
 
 
s. 23/274 
 
2025-07-03

