---
id: act.policja.ch14
title: Ustawa o Policji — Rozdział 10
dz_u: Dz.U. 1990 Nr 30 poz. 179 (t.j. 2025 poz. 636, 718)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: 145j
  last: 145k
source_pdf: D19900179Lj (1).pdf
chunking:
  strategy: by-article
  anchor_pattern: '## Art. {n}. {#policja-art-{n}}'
  hierarchy:
  - Rozdział
  - Art.
---

# Rozdział 10
c 
## Art. 145j. {#policja-art-145j}

1. Komendant Główny Policji wykonuje zadania: 
1) 
krajowego punktu kontaktowego do spraw wymiany danych o profilach DNA, o 
którym mowa w art. 6 ust. 1 decyzji Rady 2008/615/WSiSW; 
2) 
krajowego punktu kontaktowego do spraw wymiany danych daktyloskopijnych 
ze zautomatyzowanych systemów identyfikacji daktyloskopijnej, o którym 
mowa w art. 11 ust. 1 decyzji Rady 2008/615/WSiSW; 
3) 
krajowego punktu kontaktowego do spraw współpracy przy wymianie danych 
rejestracyjnych pojazdów, o którym mowa w art. 12 ust. 2 decyzji Rady 
2008/615/WSiSW; 
4) 
krajowego punktu kontaktowego do spraw wymiany danych osobowych i 
nieosobowych, o którym mowa w art. 15 decyzji Rady 2008/615/WSiSW; 
5) 
punktu kontaktowego, o którym mowa w art. 17 ust. 1 decyzji Rady 
2008/616/WSiSW w sprawie wdrożenia decyzji 2008/615/WSiSW w sprawie 
intensyfikacji współpracy transgranicznej, szczególnie w zwalczaniu terroryzmu 
i przestępczości transgranicznej (Dz. Urz. UE L 210 z 06.08.2008, str. 12); 

 
 
 
s. 260/274 
 
2025-07-03 
 
6) 
krajowego punktu kontaktowego, o którym mowa w art. 9 ust. 2 rozporządzenia 
Parlamentu Europejskiego i Rady (UE) nr 98/2013 z dnia 15 stycznia 2013 r. w 
sprawie wprowadzania do obrotu i używania prekursorów materiałów 
wybuchowych (Dz. Urz. UE L 39 z 09.02.2013, str. 1), zwanego dalej 
„rozporządzeniem (UE) nr 98/2013”; 
7) 
krajowego punktu dostępu do systemu Eurodac, o którym mowa w 
rozporządzeniu Parlamentu Europejskiego i Rady (UE) nr 603/2013 z dnia 26 
czerwca 2013 r. w sprawie ustanowienia systemu Eurodac do porównywania 
odcisków palców w celu skutecznego stosowania rozporządzenia (UE) nr 
604/2013 w sprawie ustanowienia kryteriów i mechanizmów ustalania państwa 
członkowskiego odpowiedzialnego za rozpatrzenie wniosku o udzielenie 
ochrony międzynarodowej złożonego w jednym z państw członkowskich przez 
obywatela państwa trzeciego lub bezpaństwowca oraz w sprawie występowania 
o porównanie z danymi Eurodac przez organy ścigania państw członkowskich i 
Europol na potrzeby ochrony porządku publicznego, oraz zmieniającym 
rozporządzenie (UE) nr 1077/2011 ustanawiające Europejską Agencję ds. 
Zarządzania Operacyjnego Wielkoskalowymi Systemami Informatycznymi w 
Przestrzeni 
Wolności, 
Bezpieczeństwa 
i 
Sprawiedliwości 
(wersja 
przekształcona) (Dz. Urz. UE L 180 z 29.06.2013, str. 1), zwanym dalej 
„rozporządzeniem (UE) 603/2013”. 
2. Do zadań krajowego punktu kontaktowego, o którym mowa w ust. 1 pkt 1, 
należy: 
1) 
udostępnianie punktom kontaktowym państw członkowskich Unii Europejskiej, 
do automatycznych przeszukań,  
danych referencyjnych obejmujących wyłącznie profile DNA ustalone na podstawie 
niekodującej części DNA oraz indywidualne oznaczenia identyfikacyjne ze 
zautomatyzowanego systemu gromadzenia i przetwarzania profili DNA, 
działającego w ramach zbioru danych DNA, o którym mowa w art. 21a, 
gromadzone w celach wykrywania sprawców przestępstw, ich ścigania, 
zapobiegania przestępczości lub jej zwalczania, z wyłączeniem danych, co do 
których uprawnione podmioty zastrzegły, że nie podlegają wymianie 
międzynarodowej; 
2) 
wykonywanie, na zlecenie podmiotów wymienionych w art. 1 ust. 2 ustawy z 
dnia 16 września 2011 r. o wymianie informacji z organami ścigania państw 

 
 
 
s. 261/274 
 
2025-07-03 
 
członkowskich Unii Europejskiej, państw trzecich, agencjami Unii Europejskiej 
oraz organizacjami międzynarodowymi, przeszukań w bazach danych DNA 
udostępnianych przez punkty kontaktowe do spraw wymiany danych o profilach 
DNA innych państw członkowskich Unii Europejskiej; 
2a) wykonywanie zautomatyzowanych, okresowych przeszukań baz danych 
udostępnianych przez punkty kontaktowe do spraw wymiany danych o profilach 
DNA innych państw członkowskich Unii Europejskiej; 
3) 
współpraca z punktem kontaktowym, o którym mowa w art. 4 ust. 1 ustawy z 
dnia 16 września 2011 r. o wymianie informacji z organami ścigania państw 
członkowskich Unii Europejskiej, państw trzecich, agencjami Unii Europejskiej 
oraz 
organizacjami 
międzynarodowymi, 
w 
zakresie 
udostępniania, 
przetwarzania i wymiany danych o profilach DNA. 
3. Do zadań krajowego punktu kontaktowego, o którym mowa w ust. 1 pkt 2, 
należy: 
1) 
udostępnianie punktom kontaktowym państw członkowskich Unii Europejskiej, 
do automatycznych przeszukań, danych referencyjnych obejmujących wyłącznie 
dane daktyloskopijne oraz indywidualne oznaczenia identyfikacyjne ze 
zautomatyzowanego systemu identyfikacji daktyloskopijnej, działającego w 
ramach Centralnej Registratury Daktyloskopijnej, zgromadzone w celach 
wykrywania sprawców przestępstw, ich ścigania, zapobiegania przestępczości 
lub jej zwalczania, z wyłączeniem danych, co do których uprawnione podmioty 
zastrzegły, że nie podlegają wymianie międzynarodowej; 
2) 
wykonywanie, na zlecenie podmiotów wymienionych w art. 1 ust. 2 ustawy z 
dnia 16 września 2011 r. o wymianie informacji z organami ścigania państw 
członkowskich Unii Europejskiej, państw trzecich, agencjami Unii Europejskiej 
oraz organizacjami międzynarodowymi, przeszukań w zautomatyzowanych 
systemach identyfikacji daktyloskopijnej udostępnianych przez punkty 
kontaktowe do spraw wymiany danych daktyloskopijnych innych państw 
członkowskich Unii Europejskiej; 
2a) wykonywanie zautomatyzowanych, okresowych przeszukań zbiorów danych 
udostępnianych przez punkty kontaktowe do spraw wymiany danych 
daktyloskopijnych innych państw członkowskich Unii Europejskiej; 
3) 
współpraca z punktem kontaktowym, o którym mowa w art. 4 ust. 1 ustawy z 
dnia 16 września 2011 r. o wymianie informacji z organami ścigania państw 

 
 
 
s. 262/274 
 
2025-07-03 
 
członkowskich Unii Europejskiej, państw trzecich, agencjami Unii Europejskiej 
oraz 
organizacjami 
międzynarodowymi, 
w 
zakresie 
udostępniania, 
przetwarzania i wymiany danych daktyloskopijnych. 
4. Do zadań krajowego punktu kontaktowego, o którym mowa w ust. 1 pkt 3, 
należy: 
1) 
udostępnianie, we współpracy z ministrem właściwym do spraw informatyzacji, 
punktom kontaktowym państw członkowskich Unii Europejskiej, do przeszukań, 
danych lub informacji zawartych w centralnej ewidencji pojazdów, o której 
mowa w art. 80a ustawy z dnia 20 czerwca 1997 r. – Prawo o ruchu drogowym, 
w celu wykrywania sprawców przestępstw oraz innych czynów zabronionych 
należących do jurysdykcji sądów lub prokuratury w tych państwach; 
2) 
wykonywanie, na zlecenie podmiotów wymienionych w art. 1 ust. 2 ustawy z 
dnia 16 września 2011 r. o wymianie informacji z organami ścigania państw 
członkowskich Unii Europejskiej, państw trzecich, agencjami Unii Europejskiej 
oraz organizacjami międzynarodowymi, przeszukań w bazach krajowych danych 
rejestracyjnych pojazdów udostępnianych przez punkty kontaktowe do spraw 
wymiany danych o pojazdach innych państw członkowskich Unii Europejskiej; 
3) 
współpraca z punktem kontaktowym, o którym mowa w art. 4 ust. 1 ustawy z 
dnia 16 września 2011 r. o wymianie informacji z organami ścigania państw 
członkowskich Unii Europejskiej, państw trzecich, agencjami Unii Europejskiej 
oraz organizacjami międzynarodowymi, oraz z ministrem właściwym do spraw 
informatyzacji w zakresie udostępniania, przetwarzania i wymiany danych o 
pojazdach. 
5. Do zadań krajowego punktu kontaktowego, o którym mowa w ust. 1 pkt 4, 
należy: 
1) 
przekazywanie punktom kontaktowym państw członkowskich Unii Europejskiej 
informacji, w tym danych osobowych, w związku z istotnymi wydarzeniami o 
skutkach transgranicznych, otrzymanych od właściwych organów krajowych, do 
których ustawowych zadań należy realizacja zadań w zakresie zapobiegania 
przestępczości oraz ochrony bezpieczeństwa i porządku publicznego; 
2) 
otrzymywanie od punktów kontaktowych państw członkowskich Unii 
Europejskiej informacji, o których mowa w pkt 1, oraz ich przekazywanie 
właściwym organom krajowym, do których ustawowych zadań należy realizacja 

 
 
 
s. 263/274 
 
2025-07-03 
 
zadań w zakresie zapobiegania przestępczości oraz ochrony bezpieczeństwa i 
porządku publicznego. 
5a. Do zadań krajowego punktu kontaktowego, o którym mowa w ust. 1 pkt 6, 
należy: 
1) 
obsługa ogólnopolskiego systemu zgłaszania podejrzanych transakcji lub prób 
dokonania takich transakcji, zniknięć i kradzieży znacznych ilości substancji 
wymienionych w załącznikach I i II do rozporządzenia (UE) nr 98/2013 lub 
w aktach delegowanych wydanych na podstawie art. 12 tego rozporządzenia oraz 
mieszanin lub substancji zawierających te substancje, o którym mowa w 
rozdziale 2 ustawy z dnia 13 kwietnia 2016 r. o bezpieczeństwie obrotu 
prekursorami materiałów wybuchowych (Dz. U. z 2019 r. poz. 994); 
2) 
zapewnienie odbierania połączeń telefonicznych oraz obsługa adresu poczty 
elektronicznej na potrzeby zgłaszania podejrzanych transakcji, o których mowa 
w pkt 1; 
3) 
prowadzenie ewidencji zgłoszeń podejrzanych transakcji lub prób dokonania 
takich transakcji, zniknięć i kradzieży znacznych ilości substancji wymienionych 
w załącznikach I i II do rozporządzenia (UE) nr 98/2013 lub w aktach 
delegowanych wydanych na podstawie art. 12 tego rozporządzenia oraz 
mieszanin lub substancji zawierających te substancje; 
4) 
korzystanie z systemu wczesnego ostrzegania Europolu w celu ułatwienia 
wykrywania sprawców przestępstw i ostrzeganie właściwych organów w innych 
państwach członkowskich Unii Europejskiej przed możliwymi zagrożeniami 
wynikającymi z możliwości użycia substancji, o których mowa w pkt 3, do 
nielegalnego wytwarzania materiałów wybuchowych; 
5) 
upowszechnianie wytycznych, o których mowa w art. 9 ust. 5 rozporządzenia 
(UE) nr 98/2013, w ramach współpracy między właściwymi organami i 
podmiotami gospodarczymi; 
6) 
wymiana informacji z właściwymi krajowymi punktami kontaktowymi innych 
państw członkowskich Unii Europejskiej, w szczególności za pomocą urządzeń 
teletransmisji danych, w celu zapobiegania przestępstwom o charakterze 
terrorystycznym. 
5b. Do zadań krajowego punktu dostępu do systemu Eurodac, o którym mowa w 
ust. 1 pkt 7, należy: 

 
 
 
s. 264/274 
 
2025-07-03 
 
1) 
przesyłanie do systemu Eurodac danych daktyloskopijnych wraz z właściwymi 
numerami referencyjnymi zgodnie z art. 24 ust. 1 rozporządzenia (UE) 603/2013; 
2) 
weryfikowanie wyników porównania zgodnie z art. 25 ust. 4 rozporządzenia 
(UE) 603/2013; 
3) 
komunikowanie się z systemem Eurodac zgodnie z art. 26 rozporządzenia (UE) 
603/2013; 
4) 
przekazywanie wyników porównania danych daktyloskopijnych z danymi 
Eurodac właściwym organom. 
6. Zadania, o których mowa w ust. 2, 3 i 5b, Komendant Główny Policji 
wykonuje przy pomocy CLKP.

***
## Art. 145k. {#policja-art-145k}

1. Komenda Główna Policji wykonuje zadania krajowego biura do 
spraw odzyskiwania mienia, o którym mowa w art. 1 ust. 1 decyzji Rady 
2007/845/WSiSW z dnia 6 grudnia 2007 r. dotyczącej współpracy pomiędzy biurami 
ds. odzyskiwania mienia w państwach członkowskich w dziedzinie wykrywania i 
identyfikacji korzyści pochodzących z przestępstwa lub innego mienia związanego z 
przestępstwem (Dz. Urz. UE L 332 z 18.12.2007, str. 103). 
2. Współpraca, w rozumieniu przepisów decyzji Rady 2007/845/WSiSW, 
między krajowym biurem do spraw odzyskiwania mienia, o którym mowa w ust. 1, a 
krajowymi biurami ds. odzyskiwania mienia innych państw członkowskich Unii 
Europejskiej, w szczególności w zakresie wymiany informacji w celu wykrywania i 
identyfikacji korzyści pochodzących z przestępstwa lub innego mienia związanego z 
przestępstwem, oraz w zakresie przetwarzania tych informacji, odbywa się na 
zasadach i warunkach określonych w ustawie z dnia 16 września 2011 r. o wymianie 
informacji z organami ścigania państw członkowskich Unii Europejskiej, państw 
trzecich, agencjami Unii Europejskiej oraz organizacjami międzynarodowymi.

