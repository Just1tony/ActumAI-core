---
id: act.policja.ch10
title: Ustawa o Policji — Rozdział 9
dz_u: Dz.U. 1990 Nr 30 poz. 179 (t.j. 2025 poz. 636, 718)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '99'
  last: '131'
source_pdf: D19900179Lj (1).pdf
chunking:
  strategy: by-article
  anchor_pattern: '## Art. {n}. {#policja-art-{n}}'
  hierarchy:
  - Rozdział
  - Art.
---

# Rozdział 9
 
## Art. 99. {#policja-art-99}

1. Prawo do uposażenia powstaje z dniem mianowania policjanta na 
stanowisko służbowe. 
2. Z tytułu służby policjant otrzymuje jedno uposażenie i inne świadczenia 
pieniężne określone w ustawie. 
3. Przeciętne uposażenie policjantów stanowi wielokrotność kwoty bazowej, 
której wysokość ustaloną według odrębnych zasad określa ustawa budżetowa. 
3a. Przez przeciętne uposażenie, o którym mowa w ust. 3, należy rozumieć 
uposażenie wraz z miesięczną równowartością nagrody rocznej. 
4. Wielokrotność kwoty bazowej, o której mowa w ust. 3, określa Rada 
Ministrów w drodze rozporządzenia.

***
## Art. 100. {#policja-art-100}

Uposażenie policjanta składa się z uposażenia zasadniczego i z 
dodatków do uposażenia.

***
## Art. 101. {#policja-art-101}

1. Wysokość uposażenia zasadniczego policjanta jest uzależniona od 
grupy zaszeregowania jego stanowiska służbowego oraz od posiadanej wysługi lat. 
2. Minister właściwy do spraw wewnętrznych, w porozumieniu z ministrem 
właściwym do spraw pracy, określi, w drodze rozporządzenia, szczegółowe zasady 
otrzymywania oraz wysokość uposażenia zasadniczego policjantów, uwzględniając 
grupy zaszeregowania i odpowiadające im stawki uposażenia, zaszeregowanie 
stanowisk służbowych do poszczególnych grup i odpowiadające im policyjne stopnie 
etatowe, warunki podwyższania tego uposażenia, a także sposób ustalania jego 
wzrostu z tytułu wysługi lat.

***
## Art. 102. {#policja-art-102}

Minister właściwy do spraw wewnętrznych określi, w drodze 
rozporządzenia, szczegółowe zasady ustalania wysługi lat, od której jest uzależniony 
wzrost uposażenia zasadniczego, uwzględniając rodzaje okresów służby, pracy i 
innych okresów podlegających zaliczeniu do wysługi, sposób jej dokumentowania 
oraz tryb postępowania w tych sprawach.

***
## Art. 103. {#policja-art-103}

1. Policjant przeniesiony na stanowisko służbowe zaszeregowane do 
niższej grupy uposażenia zasadniczego zachowuje prawo do stawki uposażenia 

 
 
 
s. 196/274 
 
2025-07-03 
 
pobieranego na poprzednio zajmowanym stanowisku, do czasu uzyskania wyższej 
stawki uposażenia według stanowiska służbowego. 
2. Minister właściwy do spraw wewnętrznych, w przypadkach szczególnie 
uzasadnionych, może zezwolić na zachowanie przez policjanta przeniesionego na 
stanowisko służbowe zaszeregowane do niższej grupy uposażenia zasadniczego prawa 
do zaszeregowania należnego na poprzednio zajmowanym stanowisku, z 
jednoczesnym zachowaniem stopnia związanego z tym stanowiskiem. 
3. Przepisu ust. 1 nie stosuje się do policjantów przeniesionych na niższe 
stanowisko służbowe na podstawie art. 38 ust. 1 lub ust. 2 pkt 2 i 3 oraz policjantów 
przeniesionych na własną prośbę.

***
## Art. 104. {#policja-art-104}

1. Policjantowi przysługuje dodatek za stopień w wysokości 
uzależnionej od posiadanego stopnia policyjnego. 
2. Policjantowi pełniącemu służbę lub obowiązki na stanowisku kierowniczym 
lub samodzielnym przysługuje dodatek funkcyjny. 
3. Na stanowiskach innych niż wymienione w ust. 2 policjant za należyte 
wykonywanie obowiązków służbowych może otrzymywać dodatek służbowy. 
4. Niezależnie od dodatków, o których mowa w ust. 1–3, policjantowi mogą być 
przyznawane dodatki do uposażenia uzasadnione szczególnymi właściwościami, 
kwalifikacjami, warunkami lub miejscem pełnienia służby. 
5. Dodatkami do uposażenia o charakterze stałym są dodatki ustalone w stawkach 
miesięcznych. 
6. Minister właściwy do spraw wewnętrznych, w porozumieniu z ministrem 
właściwym do spraw pracy, określi, w drodze rozporządzenia, szczegółowe zasady 
otrzymywania oraz wysokość dodatków do uposażenia, o których mowa w ust. 1–4, 
uwzględniając ich rodzaj i charakter, przesłanki przyznawania lub podwyższania na 
stałe lub na czas określony, warunki obniżania lub cofania oraz stanowiska 
uprawniające do dodatku funkcyjnego.

***
## Art. 105. {#policja-art-105}

1. Uposażenie i inne świadczenia oraz należności pieniężne są płatne 
bezpośrednio do rąk policjanta, z zastrzeżeniem ust. 5. 
2. Uposażenie zasadnicze i dodatki do uposażenia o charakterze stałym są płatne 
miesięcznie z góry w pierwszym dniu roboczym każdego miesiąca, z zastrzeżeniem 
ust. 3 i 5. 

 
 
 
s. 197/274 
 
2025-07-03 
 
3. Minister właściwy do spraw wewnętrznych może określić, w drodze 
rozporządzenia, inne terminy płatności dodatków do uposażenia o charakterze stałym, 
uwzględniając, które z nich są płatne miesięcznie z dołu. 
4. Terminy wypłaty innych świadczeń i należności pieniężnych oraz dodatków 
do uposażenia, niewymienionych w ust. 2, określają przepisy w sprawie warunków ich 
otrzymywania. 
5. Uposażenie i inne świadczenia oraz należności pieniężne mogą być wypłacane 
w formie bezgotówkowej, na warunkach ustalonych w pisemnym porozumieniu 
między płatnikiem i policjantem, nie wcześniej jednak niż w terminach, o których 
mowa w ust. 2–4.

***
## Art. 106. {#policja-art-106}

1. Zmiana uposażenia następuje z dniem zaistnienia okoliczności 
uzasadniających tę zmianę. 
2. Jeżeli prawo do uposażenia powstało lub zmiana uposażenia nastąpiła w ciągu 
miesiąca, uposażenie na czas do końca miesiąca oblicza się w wysokości 1/30 części 
miesięcznego uposażenia za każdy dzień, gdy przepisy szczególne nie stanowią 
inaczej. 
3. Prawo do uposażenia wygasa z ostatnim dniem miesiąca, w którym nastąpiło 
zwolnienie policjanta ze służby lub zaistniały inne okoliczności uzasadniające 
wygaśnięcie tego prawa.

***
## Art. 107. {#policja-art-107}

1. Roszczenia z tytułu prawa do uposażenia i innych świadczeń oraz 
należności pieniężnych ulegają przedawnieniu z upływem 3 lat od dnia, w którym 
roszczenie stało się wymagalne. 
2. Organ właściwy do rozpatrywania roszczeń może nie uwzględnić 
przedawnienia, jeżeli opóźnienie w dochodzeniu roszczenia jest usprawiedliwione 
wyjątkowymi okolicznościami. 
3. Bieg przedawnienia roszczenia z tytułu uposażenia i innych świadczeń oraz 
należności pieniężnych przerywa: 
1) 
każda czynność przed kierownikiem jednostki organizacyjnej podległej 
ministrowi właściwemu do spraw wewnętrznych, właściwym do rozpatrywania 
roszczeń, podjęta bezpośrednio w celu dochodzenia lub ustalenia albo 
zaspokojenia roszczenia; 
2) 
uznanie roszczenia.

***
## Art. 108. {#policja-art-108}

1. Policjantowi przysługują następujące świadczenia pieniężne: 

 
 
 
s. 198/274 
 
2025-07-03 
 
1) 
zasiłek na zagospodarowanie; 
2) 
nagrody oraz zapomogi; 
3) 
nagrody jubileuszowe; 
4) 
dodatkowe wynagrodzenie za wykonywanie zleconych zadań wykraczających 
poza obowiązki służbowe; 
4a) rekompensata pieniężna w zamian za czas służby przekraczający normę 
określoną w art. 33 ust. 2; 
5) 
należności za podróże służbowe i przeniesienia; 
5a) świadczenie motywacyjne; 
5b) świadczenie teleinformatyczne, o którym mowa w art. 5 ustawy z dnia 2 grudnia 
2021 r. o szczególnych zasadach wynagradzania osób realizujących zadania z 
zakresu cyberbezpieczeństwa (Dz. U. z 2024 r. poz. 1662), zwane dalej 
„świadczeniem teleinformatycznym”; 
5c) świadczenie związane z pełnieniem służby w CBZC; 
5d) świadczenie za długoletnią służbę; 
6) 
świadczenia związane ze zwolnieniem ze służby; 
7) 
świadczenie pieniężne w zamian za wyżywienie. 
1a. Policjanci mogą otrzymywać nagrody za osiągnięcia w służbie, ze środków 
finansowych, o których mowa w art. 13 ust. 4a. 
2. W razie śmierci policjanta lub członka jego rodziny, przysługują: 
1) 
zasiłek pogrzebowy; 
2) 
odprawa pośmiertna.

***
## Art. 109. {#policja-art-109}

1. Policjantowi, w związku z mianowaniem na stałe, przysługuje 
zasiłek na zagospodarowanie w wysokości jednomiesięcznego uposażenia 
zasadniczego wraz z dodatkami o charakterze stałym, należnymi w dniu mianowania 
na stałe. 
2. Zasiłek, o którym mowa w ust. 1, nie przysługuje policjantowi pełniącemu 
służbę w Policji po zwolnieniu z zawodowej służby wojskowej lub innej służby, w 
czasie której otrzymał taki zasiłek.

***
## Art. 110. {#policja-art-110}

1. Policjantowi za służbę pełnioną w danym roku kalendarzowym 
przysługuje nagroda roczna w wysokości 1/12 uposażenia otrzymanego w roku 
kalendarzowym, za który nagroda przysługuje. 
2. (uchylony) 

 
 
 
s. 199/274 
 
2025-07-03 
 
3. Nagroda roczna przysługuje, jeżeli policjant w danym roku kalendarzowym 
pełnił służbę przez okres co najmniej 6 miesięcy kalendarzowych. Okresy służby 
krótsze od miesiąca kalendarzowego sumuje się, przyjmując, że każde 30 dni służby 
stanowi pełny miesiąc kalendarzowy. 
3a. Do okresu, o którym mowa w ust. 3, nie zalicza się okresów niewykonywania 
zadań służbowych z następujących przyczyn: 
1) 
korzystania z urlopu bezpłatnego; 
2) 
przerw w wykonywaniu obowiązków służbowych, za które policjant nie 
zachował prawa do uposażenia, wymienionych w art. 126 ust. 1–3; 
3) 
zawieszenia w czynnościach służbowych albo tymczasowego aresztowania. 
3b. Przepisu ust. 3a pkt 3 nie stosuje się, jeżeli postępowanie karne w sprawie o 
przestępstwo lub przestępstwo skarbowe lub postępowanie dyscyplinarne, w sprawie 
o czyn pozostający w związku z aresztowaniem lub zawieszeniem w czynnościach 
służbowych zostało umorzone prawomocnym orzeczeniem bądź policjant został 
uniewinniony na podstawie prawomocnego wyroku lub orzeczenia o uniewinnieniu w 
postępowaniu dyscyplinarnym. 
3c. Umorzenie postępowania, o którym mowa w ust. 3b, nie dotyczy 
warunkowego umorzenia postępowania karnego lub postępowania w sprawie o 
przestępstwo skarbowe ani umorzenia tego postępowania z powodu przedawnienia lub 
amnestii. 
4. Warunku, o którym mowa w ust. 3, nie stosuje się przy ustalaniu uprawnień 
do nagrody rocznej za rok kalendarzowy, w którym policjant: 
1) 
korzystał z urlopu wychowawczego, urlopu macierzyńskiego, urlopu 
ojcowskiego, 
urlopu 
rodzicielskiego, 
urlopu 
na 
warunkach 
urlopu 
macierzyńskiego, uzupełniającego urlopu macierzyńskiego; 
1a) korzystał ze zwolnienia od wykonywania zajęć służbowych, z przyczyn, o 
których mowa w art. 185 § 2 lub art. 188 Kodeksu pracy; 
1b) korzystał ze zwolnienia od wykonywania zajęć służbowych w razie urodzenia się 
dziecka policjanta, zgodnie z przepisami wydanymi na podstawie art. 2982 
Kodeksu pracy; 
1c) korzystał ze zwolnienia od wykonywania zajęć służbowych z powodu 
konieczności osobistego sprawowania opieki nad dzieckiem, o którym mowa w 
art. 33 ust. 1 pkt 1 ustawy z dnia 25 czerwca 1999 r. o świadczeniach pieniężnych 

 
 
 
s. 200/274 
 
2025-07-03 
 
z ubezpieczenia społecznego w razie choroby i macierzyństwa (Dz. U. z 2023 r. 
poz. 2780 oraz z 2024 r. poz. 1871); 
2) 
został delegowany lub odwołany z delegowania bez prawa do uposażenia w 
przypadkach, o których mowa w art. 36 ust. 4 i art. 122a; 
3) 
został zwolniony ze służby w związku z nabyciem uprawnień do emerytury lub 
renty bądź na podstawie art. 41 ust. 2 pkt 6 i 7; 
4) 
zmarł lub został uznany za zaginionego. 
4a. Do uposażenia, o którym mowa w ust. 1, nie wlicza się uposażenia 
otrzymanego w okresie zawieszenia w czynnościach służbowych albo tymczasowego 
aresztowania. Przepisy ust. 3b i 3c stosuje się. 
5. Nagrodę roczną obniża się policjantowi, z zastrzeżeniem ust. 7, w przypadku: 
1) 
popełnienia przestępstwa lub przestępstwa skarbowego stwierdzonego 
prawomocnym orzeczeniem sądu; 
2) 
popełnienia przewinienia dyscyplinarnego, stwierdzonego w prawomocnie 
zakończonym postępowaniu dyscyplinarnym; 
3) 
otrzymania opinii służbowej, o której mowa w art. 38 ust. 2 pkt 2; 
4) 
otrzymania pierwszej lub kolejnej opinii służbowej, o której mowa w art. 38 ust. 
2 pkt 3. 
6. Obniżenie, o którym mowa w ust. 5, może nastąpić w granicach od 20 % do 
50 %. 
7. Nagroda roczna nie przysługuje policjantowi w przypadku: 
1) 
skazania prawomocnym wyrokiem sądu za przestępstwo lub przestępstwo 
skarbowe, o których mowa w art. 41 ust. 1 pkt 4; 
2) 
popełnienia przestępstwa lub przestępstwa skarbowego albo czynu, z powodu 
którego policjanta zwolniono ze służby na podstawie art. 41 ust. 1 pkt 4a i ust. 2 
pkt 2 i 8; 
3) 
popełnienia czynu, za który policjantowi wymierzono jedną z kar 
dyscyplinarnych, o których mowa w art. 134 pkt 3–7; 
4) 
zwolnienia ze służby na podstawie art. 41 ust. 1 pkt 2 i ust. 2 pkt 1. 
8. Obniżenie lub pozbawienie prawa do nagrody rocznej następuje za rok 
kalendarzowy, w którym policjant popełnił przestępstwo lub czyn, o których mowa w 
ust. 5 pkt 1 i 2, w art. 41 ust. 1 pkt 4 i 4a oraz ust. 2 pkt 2 i 8, a także w art. 134 pkt 3–
7, lub otrzymał opinię, o której mowa w art. 38 ust. 2 pkt 2 i 3, albo został zwolniony 

 
 
 
s. 201/274 
 
2025-07-03 
 
ze służby w przypadkach, o których mowa w art. 41 ust. 1 pkt 2 i ust. 2 pkt 1, a jeżeli 
nagroda została już wypłacona – za rok, w którym: 
1) 
postępowanie karne lub dyscyplinarne w tej sprawie zostało zakończone 
prawomocnym orzeczeniem lub 
2) 
policjant został zwolniony ze służby. 
8a. Okoliczności uzasadniające pozbawienie lub ograniczenie prawa do nagrody 
rocznej ustala się na podstawie orzeczeń i decyzji organów właściwych w sprawach 
karnych o przestępstwo lub przestępstwo skarbowe, w sprawach dyscyplinarnych oraz 
w sprawach dotyczących opiniowania policjantów, a także na podstawie dokumentacji 
prowadzonej w sprawach osobowych policjantów. 
8b. Przy obniżaniu nagrody rocznej uwzględnia się całokształt okoliczności 
sprawy, w szczególności charakter popełnionego przestępstwa, przestępstwa 
skarbowego lub przewinienia, jego skutki, rodzaj i wymiar orzeczonej kary oraz 
dotychczasowe wyniki policjanta w służbie. 
8c. Od decyzji przełożonego o przyznaniu, obniżeniu lub odmowie przyznania 
nagrody rocznej policjantowi służy odwołanie do wyższego przełożonego. 
9. Nagrodę roczną wypłaca się do dnia 31 marca roku kalendarzowego 
następującego po roku, za który przysługuje nagroda. 
10. Policjantowi zwalnianemu ze służby nagrodę roczną wypłaca się w terminie 
14 dni od dnia zwolnienia. 
11. W razie śmierci albo zaginięcia policjanta należną mu nagrodę roczną 
wypłaca się małżonkowi, a w dalszej kolejności dzieciom oraz rodzicom 
uprawnionym do renty rodzinnej. Przepis ust. 10 stosuje się odpowiednio. 
12. W przypadku pełnienia przez policjanta w roku kalendarzowym służby w 
różnych jednostkach organizacyjnych Policji nagrodę roczną przyznaje się i wypłaca 
w jednostce, która była w danym roku ostatnim miejscem pełnienia przez niego służby. 
13. Nagrody roczne przyznają przełożeni właściwi w sprawach mianowania 
policjantów na stanowiska służbowe, przenoszenia oraz zwalniania z tych stanowisk. 
14. Minister właściwy do spraw wewnętrznych przyznaje nagrody roczne 
Komendantowi Głównemu Policji oraz zastępcom Komendanta Głównego Policji. 
15. Komendant Główny Policji przyznaje nagrody roczne Komendantowi CBŚP, 
Komendantowi CBZC, Dyrektorowi CLKP, dowódcy BOA, komendantom 
wojewódzkim Policji, Komendantowi Stołecznemu Policji, komendantom szkół 
policyjnych i ich zastępcom oraz Komendantowi-Rektorowi Akademii Policji 

 
 
 
s. 202/274 
 
2025-07-03 
 
w Szczytnie i osobie pełniącej w uczelni służb państwowych funkcję kierowniczą do 
spraw realizacji zadań uczelni jako jednostki organizacyjnej właściwej służby. 
Komendantowi BSWP oraz jego zastępcom przyznaje nagrodę roczną, na wniosek 
Inspektora Nadzoru Wewnętrznego, minister właściwy do spraw wewnętrznych.

***
## Art. 110a. {#policja-art-110a}

1. Policjantowi, niezależnie od wyróżnień, o których mowa w art. 87 
ust. 1, mogą być przyznawane nagrody motywacyjne, w formie pieniężnej lub 
rzeczowej, za wzorowe wykonywanie zadań służbowych, wykazywane w służbie 
męstwo i inicjatywę oraz pełnienie służby w trudnych warunkach. 
Art. 87 ust. 3 stosuje 
się odpowiednio. 
2. Policjantowi mogą być przyznawane zapomogi, w formie pieniężnej lub 
rzeczowej, w przypadku indywidualnych zdarzeń losowych, klęski żywiołowej, 
choroby, śmierci członka rodziny oraz innych zdarzeń powodujących pogorszenie 
sytuacji materialnej policjanta i jego rodziny. 
3. Tworzy się w Policji fundusz nagród i zapomóg dla policjantów, z 
przeznaczeniem na nagrody i zapomogi, o których mowa w ust. 1 i 2.

***
## Art. 110b. {#policja-art-110b}

Minister właściwy do spraw wewnętrznych w porozumieniu z 
ministrem właściwym do spraw pracy oraz ministrem właściwym do spraw 
zabezpieczenia społecznego określi, w drodze rozporządzenia, szczegółowe warunki i 
tryb przyznawania policjantom nagród i zapomóg, o których mowa w art. 110a, tryb 
postępowania oraz przełożonych właściwych w zakresie przyznawania tych nagród i 
zapomóg, sposób tworzenia funduszu nagród i zapomóg dla policjantów, jednostki 
Policji, w których tworzy się fundusz nagród i zapomóg, a także sposoby ustalania i 
warunki zwiększania jego wysokości dla poszczególnych dysponentów, mając na 
względzie celową i racjonalną politykę w zakresie dysponowania środkami 
finansowymi.

***
## Art. 111. {#policja-art-111}

1. Policjantowi przysługują nagrody jubileuszowe w wysokości: 
po 20 latach służby – 75 %, 
po 25 latach służby – 100 %, 
po 30 latach służby – 150 %, 
po 35 latach służby – 200 %, 
po 40 latach służby – 300 % 
miesięcznego uposażenia zasadniczego, wraz z dodatkami o charakterze stałym. 

 
 
 
s. 203/274 
 
2025-07-03 
 
2. Minister właściwy do spraw wewnętrznych, w porozumieniu z ministrem 
właściwym do spraw pracy, określi, w drodze rozporządzenia, okresy wliczane do 
okresu służby, od którego zależy nabycie prawa do nagrody jubileuszowej, oraz tryb 
jej obliczania i wypłacania, uwzględniając okresy służby, pracy i nauki powodujące 
nabycie prawa do nagrody jubileuszowej, sposób dokumentowania tych okresów oraz 
postępowania w przypadku zbiegu prawa do kilku nagród, a także termin wypłacania 
nagrody.

***
## Art. 112. {#policja-art-112}

1. Za wykonywanie zleconych zadań wykraczających poza obowiązki 
służbowe policjant otrzymuje dodatkowe wynagrodzenie. 
2. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
warunki otrzymania dodatkowego wynagrodzenia, o którym mowa w ust. 1, 
uwzględniając rodzaje zadań zleconych, wysokość i sposób obliczania wynagrodzenia 
oraz tryb jego wypłacania. 
3. (uchylony)

***
## Art. 113. {#policja-art-113}

1. W razie przeniesienia policjanta do pełnienia służby w innej 
miejscowości albo delegowania go do czasowego pełnienia służby, policjantowi 
przysługują należności za podróże służbowe i przeniesienia. 
2. Minister właściwy do spraw wewnętrznych, w porozumieniu z ministrem 
właściwym do spraw pracy, określi, w drodze rozporządzenia, wysokość, warunki 
oraz tryb przyznawania należności, o których mowa w ust. 1, uwzględniając sposoby 
obliczania czasu podróży służbowej oraz rodzaje należności i sposoby ustalania ich 
wysokości oraz terminy i tryb wypłaty należności.

***
## Art. 114. {#policja-art-114}

1. Policjant zwalniany ze służby otrzymuje, z zastrzeżeniem ust. 2–4: 
1) 
odprawę; 
2) 
ekwiwalent pieniężny za niewykorzystane urlopy wypoczynkowe lub 
dodatkowe, z wyjątkiem urlopu, o którym mowa w art. 83a ust. 1; 
3) 
zwrot kosztów przejazdu policjanta i członków jego rodziny oraz przewozu 
urządzenia domowego do nowego miejsca zamieszkania w kraju, w zakresie i na 
zasadach obowiązujących przy przeniesieniach z urzędu. 
2. Świadczenia, o których mowa w ust. 1 pkt 3, przysługują policjantowi, jeżeli 
w dniu zwolnienia ze służby spełniał warunki do uzyskania świadczenia z zaopatrzenia 
emerytalnego. 

 
 
 
s. 204/274 
 
2025-07-03 
 
3. Policjant zwalniany ze służby na podstawie art. 41 ust. 1 pkt 3 i 4a oraz ust. 2 
pkt 8 otrzymuje 50 % odprawy oraz ekwiwalent pieniężny, o którym mowa w ust. 1 
pkt 2. 
4. Policjant zwalniany ze służby na podstawie art. 41 ust. 1 pkt 4 i ust. 2 pkt 2 
otrzymuje ekwiwalent pieniężny, o którym mowa w ust. 1 pkt 2. Komendant Główny 
Policji lub upoważniony przez niego przełożony może w przypadkach szczególnie 
uzasadnionych potrzeb rodziny policjanta przyznać mu nie więcej niż 50 % odprawy.

***
## Art. 115. {#policja-art-115}

1. Wysokość odprawy dla policjanta w służbie stałej równa się 
wysokości trzymiesięcznego uposażenia zasadniczego wraz z dodatkami o charakterze 
stałym, należnymi na ostatnio zajmowanym stanowisku służbowym. Odprawa ulega 
zwiększeniu o 20 % uposażenia zasadniczego wraz z dodatkami o charakterze stałym 
za każdy dalszy pełny rok wysługi ponad 5 lat nieprzerwanej służby aż do wysokości 
sześciomiesięcznego zasadniczego uposażenia wraz z dodatkami o charakterze 
stałym. Okres służby przekraczający 6 miesięcy liczy się jako pełny rok. 
2. Przy ustalaniu wysokości odprawy uwzględnia się również okresy 
nieprzerwanej zawodowej służby wojskowej, jeżeli bezpośrednio po zwolnieniu z tej 
służby żołnierz został przyjęty do służby w Policji i nie otrzymał odprawy z tytułu 
poprzednio pełnionej służby. 
3. Przepis ust. 2 stosuje się odpowiednio w przypadku podjęcia służby w Policji 
po zwolnieniu ze służby w innych służbach, w których przysługują świadczenia tego 
rodzaju. 
4. Wysokość odprawy dla policjanta w służbie przygotowawczej równa się 
wysokości jednomiesięcznego uposażenia zasadniczego wraz z dodatkami o 
charakterze stałym należnymi na ostatnio zajmowanym stanowisku służbowym.

***
## Art. 115a. {#policja-art-115a}

Ekwiwalent pieniężny za 1 dzień niewykorzystanego urlopu 
wypoczynkowego lub dodatkowego ustala się w wysokości 1/21 części miesięcznego 
uposażenia zasadniczego wraz z dodatkami o charakterze stałym należnego 
policjantowi na ostatnio zajmowanym stanowisku służbowym.

***
## Art. 116. {#policja-art-116}

1. W razie śmierci policjanta, pozostałej po nim rodzinie przysługuje 
odprawa pośmiertna w takiej wysokości, w jakiej przysługiwałaby temu policjantowi 
odprawa, gdyby był zwolniony ze służby, oraz świadczenia określone w art. 114 ust. 
1 pkt 2 i 3. W razie śmierci policjanta w służbie kontraktowej pozostającej po nim 
rodzinie 
przysługuje 
odprawa 
pośmiertna 
w wysokości 
jednomiesięcznego 

 
 
 
s. 205/274 
 
2025-07-03 
 
uposażenia zasadniczego wraz z dodatkami o charakterze stałym oraz świadczenia 
określone w art. 114 ust. 1 pkt 2 i 3. 
2. Świadczenia, o których mowa w ust. 1, przysługują małżonkowi policjanta, 
który pozostawał z nim we wspólności małżeńskiej, a w dalszej kolejności dzieciom 
oraz rodzicom, jeżeli w dniu śmierci policjanta spełniali warunki do uzyskania renty 
rodzinnej na podstawie przepisów o zaopatrzeniu emerytalnym funkcjonariuszy 
Policji, Agencji Bezpieczeństwa Wewnętrznego, Agencji Wywiadu, Służby 
Kontrwywiadu Wojskowego, Służby Wywiadu Wojskowego, Centralnego Biura 
Antykorupcyjnego, Straży Granicznej, Straży Marszałkowskiej, Biura Ochrony 
Rządu, Państwowej Straży Pożarnej, Służby Celno-Skarbowej i Służby Więziennej 
oraz ich rodzin. 
3. Przepisy ust. 1 i 2 stosuje się także do zaginionych policjantów. Zaginięcie 
policjanta oraz związek tego zaginięcia ze służbą stwierdza minister właściwy do 
spraw wewnętrznych.

***
## Art. 116a. {#policja-art-116a}

1. W przypadku policjanta, którego śmierć nastąpiła w związku ze 
służbą, każdemu z dzieci będących na jego utrzymaniu, które w dniu jego śmierci 
spełniały warunki do uzyskania renty rodzinnej, Komendant Główny Policji przyznaje 
pomoc finansową na kształcenie, ze środków przeznaczonych na ten cel w budżecie 
Policji. 
2. Pomoc finansowa, o której mowa w ust. 1, przysługuje uczniom i słuchaczom 
ponadpodstawowych szkół publicznych i niepublicznych oraz publicznych i 
niepublicznych szkół artystycznych realizujących kształcenie ogólne w zakresie 
szkoły ponadpodstawowej, a także słuchaczom kolegiów pracowników służb 
społecznych, oraz studentom szkół wyższych do czasu ukończenia kształcenia, nie 
dłużej jednak niż do ukończenia 25. roku życia. 
3. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
szczegółowe warunki i tryb przyznawania pomocy, o której mowa w ust. 1, 
uwzględniając tryb przyznawania i wysokość pomocy w zależności od poziomu 
kształcenia i rodzaju szkoły.

***
## Art. 117. {#policja-art-117}

1. Policjantowi w służbie stałej, zwolnionemu ze służby na podstawie 
art. 41 ust. 1 pkt 1 albo który nabył prawo do zaopatrzenia emerytalnego z tytułu 
osiągnięcia 30 lat wysługi emerytalnej i został zwolniony ze służby na podstawie 
art. 41 ust. 2 pkt 6 albo ust. 3, wypłaca się co miesiąc przez okres roku po zwolnieniu 

 
 
 
s. 206/274 
 
2025-07-03 
 
ze służby świadczenie pieniężne w wysokości odpowiadającej uposażeniu 
zasadniczemu wraz z dodatkami o charakterze stałym, pobieranymi na ostatnio 
zajmowanym stanowisku służbowym. 
2. Policjantowi uprawnionemu do świadczenia określonego w ust. 1, który nabył 
prawo do zaopatrzenia emerytalnego, przysługuje prawo wyboru jednego z tych 
świadczeń. 
3. Policjantowi zwolnionemu ze służby na podstawie art. 41 ust. 2 pkt 5 i 6, który 
z powodu nadal trwającej choroby nie może podjąć zatrudnienia, wypłaca się co 
miesiąc świadczenie pieniężne określone w ust. 1 przez okres choroby, nie dłużej 
jednak niż przez okres 3 miesięcy, chyba że wcześniej komisja lekarska wyda 
orzeczenie o inwalidztwie stanowiące podstawę do ustalenia prawa do renty 
inwalidzkiej.

***
## Art. 118. {#policja-art-118}

Odprawa, o której mowa w art. 114, oraz świadczenia określone w art. 
117 nie przysługują policjantowi, który bezpośrednio po zwolnieniu ze służby został 
przyjęty do zawodowej służby wojskowej lub do innej służby, w której przysługuje 
prawo do takich świadczeń.

***
## Art. 119. {#policja-art-119}

1. W razie śmierci policjanta, niezależnie od odprawy pośmiertnej, o 
której mowa w art. 116, przysługuje zasiłek pogrzebowy w wysokości: 
[1) 4000 zł, jeżeli koszty pogrzebu ponosi małżonek, dzieci, wnuki, rodzeństwo lub 
rodzice;]  
<1) 7000 zł, jeżeli koszty pogrzebu ponosi małżonek, dzieci, wnuki, rodzeństwo 
lub rodzice;>  
2) 
kosztów rzeczywiście poniesionych, najwyżej jednak do wysokości określonej w 
pkt 1, jeżeli koszty pogrzebu ponosi inna osoba. 
2. Jeżeli śmierć policjanta nastąpiła na skutek wypadku pozostającego w związku 
ze służbą, koszty pogrzebu pokrywa się ze środków Komendy Głównej Policji. 
Komendant Główny Policji może wyrazić zgodę na pokrycie kosztów pogrzebu 
policjanta zmarłego wskutek choroby pozostającej w związku ze służbą. 
3. W razie pokrycia kosztów pogrzebu policjanta ze środków Komendy Głównej 
Policji osobom wymienionym w ust. 1 pkt 1 przysługuje połowa zasiłku 
pogrzebowego.

***
## Art. 120. {#policja-art-120}

1. W razie śmierci członka rodziny, policjantowi przysługuje zasiłek 
pogrzebowy w wysokości: 
Nowe brzmienie 
pkt 1 w ust. 1 w 
art. 119 wejdzie 
w życie z dn. 
1.01.2026 r. (Dz. 
U. z 2025 r. poz. 
718). 

 
 
 
s. 207/274 
 
2025-07-03 
 
[1) 4000 zł – jeżeli koszty pogrzebu ponosi policjant;]  
<1) 7000 zł – jeżeli koszty pogrzebu ponosi policjant;>  
2) 
kosztów rzeczywiście poniesionych, najwyżej jednak do wysokości określonej w 
pkt 1 – jeżeli koszty pogrzebu ponosi inna osoba. 
2. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
warunki pokrywania kosztów pogrzebu policjanta ze środków właściwego organu 
Policji oraz określi członków rodziny, na których przysługuje zasiłek pogrzebowy, 
uwzględniając rodzaje wydatków pokrywanych w ramach kosztów pogrzebu i ich 
wysokość, przypadki oraz sposób ustalania wysokości oraz tryb wypłaty zasiłku 
pogrzebowego lub jego wyrównania z tytułu śmierci członka rodziny oraz dokumenty 
wymagane do ich wypłaty. 
3. (uchylony) 
<4. Zasiłek 
pogrzebowy, 
o którym 
mowa 
w ust. 1 pkt 1 
oraz 
art. 119 ust. 1 pkt 1, podlega zwiększeniu w terminach i na zasadach określonych 
w art. 80 ustawy z dnia 17 grudnia 1998 r. o emeryturach i rentach z Funduszu 
Ubezpieczeń Społecznych.>

***
## Art. 120a. {#policja-art-120a}

1. Policjantowi przyznaje się świadczenie motywacyjne po 
osiągnięciu: 
1) 
25 lat służby, ale nie więcej niż 28 lat i 6 miesięcy – w wysokości 1500 zł 
miesięcznie, albo 
2) 
28 lat i 6 miesięcy służby – w wysokości 2500 zł miesięcznie. 
2. Do stażu służby, o którym mowa w ust. 1, zalicza się okresy: 
1) 
służby w Policji; 
2) 
służby w Agencji Bezpieczeństwa Wewnętrznego, Agencji Wywiadu, Służbie 
Kontrwywiadu Wojskowego, Służbie Wywiadu Wojskowego, Centralnym 
Biurze Antykorupcyjnym, Straży Granicznej, Straży Marszałkowskiej, Służbie 
Ochrony Państwa, Państwowej Straży Pożarnej, Służbie Celnej, Służbie 
Celno-Skarbowej i Służbie Więziennej; 
3) 
traktowane jako równorzędne ze służbą, o której mowa w pkt 1 i 2, wymienione 
w art. 13 ustawy z dnia 18 lutego 1994 r. o zaopatrzeniu emerytalnym 
funkcjonariuszy Policji, Agencji Bezpieczeństwa Wewnętrznego, Agencji 
Wywiadu, Służby Kontrwywiadu Wojskowego, Służby Wywiadu Wojskowego, 
Centralnego 
Biura 
Antykorupcyjnego, 
Straży 
Granicznej, 
Straży 
Marszałkowskiej, Służby Ochrony Państwa, Państwowej Straży Pożarnej, 
Nowe brzmienie 
pkt 1 w ust. 1 i 
dodany ust. 4 w 
art. 120 wejdą w 
życie 
z 
dn. 
1.01.2026 r. (Dz. 
U. z 2025 r. poz. 
718). 

 
 
 
s. 208/274 
 
2025-07-03 
 
Służby Celno-Skarbowej i Służby Więziennej oraz ich rodzin (Dz. U. z 2024 r. 
poz. 1121, 1243, 1562 i 1871). 
3. Decyzję o przyznaniu lub odmowie przyznania świadczenia motywacyjnego 
przełożony, o którym mowa w art. 32 ust. 1, wydaje nie później niż w terminie 30 dni 
po osiągnięciu przez policjanta stażu służby, o którym mowa w ust. 1 pkt 1 lub 2. 
4. Przed wydaniem decyzji o przyznaniu świadczenia motywacyjnego policjant 
podlega opiniowaniu służbowemu na zasadach, o których mowa w art. 35, jeżeli od 
dnia wydania ostatniej opinii o tym policjancie upłynęły co najmniej 3 miesiące. 
5. Minister właściwy do spraw wewnętrznych przyznaje świadczenie 
motywacyjne Komendantowi Głównemu Policji i jego zastępcom oraz Komendantowi 
BSWP i jego zastępcom. 
6. Komendant 
Główny 
Policji 
przyznaje 
świadczenie 
motywacyjne 
Komendantowi CBŚP, Komendantowi CBZC, Dyrektorowi CLKP, dowódcy BOA, 
komendantom 
wojewódzkim 
Policji, 
Komendantowi 
Stołecznemu 
Policji, 
komendantom szkół policyjnych i ich zastępcom oraz Komendantowi-Rektorowi 
Akademii Policji w Szczytnie i osobie pełniącej w uczelni służb państwowych funkcję 
kierowniczą do spraw realizacji zadań uczelni jako jednostki organizacyjnej właściwej 
służby. Przepisy ust. 3 i 4 stosuje się odpowiednio. 
7. Świadczenia motywacyjnego nie przyznaje się policjantowi: 
1) 
który podczas ostatniego opiniowania służbowego otrzymał jedną z opinii 
służbowych, o których mowa w art. 38 ust. 2 pkt 2 albo 3 albo art. 41 ust. 1 pkt 
2 albo ust. 2 pkt 1 – przez okres jednego roku od dnia wydania ostatecznej opinii 
służbowej; 
2) 
przeciwko któremu wszczęto postępowanie karne w sprawie o przestępstwo 
umyślne ścigane z oskarżenia publicznego lub umyślne przestępstwo skarbowe 
lub postępowanie dyscyplinarne – do czasu prawomocnego zakończenia tego 
postępowania; 
3) 
ukaranemu karą dyscyplinarną – do czasu jej zatarcia; 
4) 
skazanemu wyrokiem sądu lub w stosunku do którego postępowanie karne 
zostało warunkowo umorzone – przez okres jednego roku od dnia 
uprawomocnienia się orzeczenia. 
8. Jeżeli po przyznaniu świadczenia motywacyjnego wystąpią okoliczności, o 
których mowa w ust. 7, niezwłocznie wydaje się decyzję stwierdzającą ustanie prawa 
do wypłaty tego świadczenia. 

 
 
 
s. 209/274 
 
2025-07-03 
 
9. Od decyzji o odmowie przyznania świadczenia motywacyjnego oraz od 
decyzji stwierdzającej ustanie prawa do wypłaty świadczenia motywacyjnego 
policjantowi przysługuje odwołanie do wyższego przełożonego w terminie 7 dni od 
dnia doręczenia decyzji. W przypadku decyzji wydanej przez ministra właściwego do 
spraw wewnętrznych lub Komendanta Głównego Policji przysługuje, w takim samym 
terminie, wniosek o ponowne rozpatrzenie sprawy. 
10. Świadczenia motywacyjnego nie wypłaca się za okres: 
1) 
korzystania z urlopu bezpłatnego, 
2) 
przerw w wykonywaniu obowiązków służbowych, za które policjant nie 
zachował prawa do uposażenia, wymienionych w art. 126 ust. 1–3, 
3) 
zawieszenia w czynnościach służbowych albo tymczasowego aresztowania, 
4) 
zwolnienia z zajęć służbowych, o którym mowa w art. 121b ust. 2 pkt 1 i 3–5, 
5) 
innej nieobecności trwającej co najmniej jeden miesiąc 
– proporcjonalnie do tego okresu. 
11. Świadczenie motywacyjne wypłaca się w każdym kolejnym miesiącu 
kalendarzowym, począwszy od miesiąca następującego po miesiącu, w którym 
wydano decyzję o przyznaniu świadczenia motywacyjnego. 
12. Świadczenie motywacyjne płatne jest z dołu do dziesiątego dnia miesiąca 
następującego po miesiącu, za który świadczenie motywacyjne przysługuje. 
13. Prawo do wypłaty świadczenia motywacyjnego ustaje w miesiącu, w którym 
decyzja, o której mowa w ust. 8, stała się ostateczna lub nastąpiło rozwiązanie 
stosunku służbowego w związku ze zwolnieniem policjanta ze służby, z jego śmiercią 
lub zaginięciem. Świadczenia motywacyjnego za ten miesiąc nie wypłaca się.

***
## Art. 120b. {#policja-art-120b}

1. Policjantowi wykonującemu zadania, o których mowa w art. 26, 
art. 42 ust. 1, art. 44 i art. 62 ustawy z dnia 5 lipca 2018 r. o krajowym systemie 
cyberbezpieczeństwa (Dz. U. z 2024 r. poz. 1077 i 1222), lub w zakresie zapewnienia 
cyberbezpieczeństwa w Policji przyznaje się na okres ich wykonywania świadczenie 
teleinformatyczne. 
2. Do ustalenia wysokości świadczenia teleinformatycznego, o którym mowa w 
ust. 1, stosuje się przepisy wydane na podstawie art. 8 ust. 1 ustawy z dnia 2 grudnia 
2021 r. o szczególnych zasadach wynagradzania osób realizujących zadania z zakresu 
cyberbezpieczeństwa. 

 
 
 
s. 210/274 
 
2025-07-03 
 
3. Decyzję o przyznaniu świadczenia teleinformatycznego przełożony, o którym 
mowa w art. 32 ust. 1, wydaje nie później niż w terminie 30 dni po rozpoczęciu przez 
policjanta wykonywania zadań, o których mowa w ust. 1. 
4. Przed wydaniem decyzji, o której mowa w ust. 3, policjant podlega 
opiniowaniu służbowemu na zasadach, o których mowa w art. 35, jeżeli od dnia 
wydania ostatniej opinii o tym policjancie upłynęły co najmniej 3 miesiące. 
5. Świadczenia teleinformatycznego nie przyznaje się w przypadkach, o których 
mowa w art. 120a ust. 7. Przepisy art. 120a ust. 8 i 9 stosuje się. 
6. Świadczenia teleinformatycznego nie wypłaca się w przypadkach, o których 
mowa w art. 120a ust. 10. 
7. Do wypłaty świadczenia teleinformatycznego stosuje się przepisy art. 120a 
ust. 11–13.

***
## Art. 120c. {#policja-art-120c}

1. Policjantowi pełniącemu służbę na stanowisku związanym z 
bezpośrednim rozpoznawaniem i zwalczaniem przestępstw popełnionych przy użyciu 
systemu informatycznego, systemu teleinformatycznego lub sieci teleinformatycznej 
oraz zapobieganiem tym przestępstwom, a także wykrywaniem i ściganiem sprawców 
tych przestępstw w CBZC oraz policjantowi nadzorującemu te czynności w CBZC 
przyznaje się świadczenie związane z pełnieniem służby w CBZC w miesięcznej 
wysokości nie niższej niż 70 % i nie wyższej niż 130 % przeciętnego uposażenia 
policjantów, o którym mowa w art. 99 ust. 3. 
2. Wysokość świadczenia, o którym mowa w ust. 1, uzależnia się od oceny 
wywiązywania się przez policjanta z obowiązków oraz realizacji zadań i czynności 
służbowych, ze szczególnym uwzględnieniem ich charakteru i zakresu, rodzaju 
i poziomu posiadanych przez tego policjanta kwalifikacji zawodowych. 
3. Decyzję o przyznaniu świadczenia, o którym mowa w ust. 1, oraz jego 
wysokości, na okres jednego roku, wydaje Komendant CBZC, a wobec Komendanta 
CBZC oraz jego zastępców – Komendant Główny Policji. 
4. Przed wydaniem decyzji, o której mowa w ust. 3, policjant podlega 
opiniowaniu służbowemu na zasadach, o których mowa w art. 35. 
5. Od decyzji, o której mowa w ust. 3, policjantowi przysługuje odwołanie do 
wyższego przełożonego w terminie 7 dni od dnia doręczenia decyzji. 
6. Komendant CBZC w przypadku: 
1) 
niewywiązywania się przez policjanta z realizacji zadań służbowych, 

 
 
 
s. 211/274 
 
2025-07-03 
 
2) 
znacznego obniżenia efektywności służby policjanta 
– obniża, w drodze decyzji, wysokość świadczenia, o którym mowa w ust. 1, przed 
upływem okresu, na który zostało przyznane. Przepis ust. 5 stosuje się odpowiednio. 
7. Komendant CBZC może podnieść, w drodze decyzji, wysokość świadczenia, 
o którym mowa w ust. 1, przed upływem okresu, na który zostało ono przyznane, jeżeli 
jest to uzasadnione charakterem i efektami bieżąco realizowanych zadań lub 
wykonywaniem przez funkcjonariusza czynności wykraczających poza zakres jego 
obowiązków służbowych. Przepis ust. 5 stosuje się odpowiednio. 
8. Świadczenia, o którym mowa w ust. 1, nie przyznaje się w przypadkach, o 
których mowa w art. 120a ust. 7. Przepisy art. 120a ust. 8 i 9 stosuje się. 
9. Świadczenia, o którym mowa w ust. 1, nie wypłaca się w przypadkach, o 
których mowa w art. 120a ust. 10. 
10. Do wypłaty świadczenia, o którym mowa w ust. 1, stosuje się przepisy art. 
120a ust. 11–13.

***
## Art. 120d. {#policja-art-120d}

1. Policjantowi przysługuje świadczenie za długoletnią służbę 
w wysokości 5 % należnego uposażenia zasadniczego po osiągnięciu 15 lat służby. 
2. Świadczenie, o którym mowa w ust. 1, zwiększa się o kwotę 1 % należnego 
uposażenia zasadniczego za każdy kolejny rozpoczęty rok służby, nie więcej jednak 
niż do wysokości 15 % po 25 latach służby, i wypłaca się do dnia rozwiązania 
stosunku służbowego w związku ze zwolnieniem policjanta ze służby, z jego śmiercią 
lub zaginięciem. 
3. Do świadczenia, o którym mowa w ust. 1, stosuje się odpowiednio przepisy 
art. 105 ust. 2 oraz art. 120a ust. 2.

***
## Art. 121. {#policja-art-121}

1. W razie urlopu, zwolnienia od zajęć służbowych oraz w okresie 
pozostawania bez przydziału służbowego policjant otrzymuje uposażenie zasadnicze, 
dodatki do uposażenia o charakterze stałym i inne należności pieniężne należne na 
ostatnio zajmowanym stanowisku służbowym – z uwzględnieniem powstałych w tym 
okresie zmian, mających wpływ na prawo do uposażenia i innych należności 
pieniężnych lub na ich wysokość. 
2. Minister właściwy do spraw wewnętrznych w porozumieniu z ministrem 
właściwym do spraw pracy może, w drodze rozporządzenia, ograniczyć w całości lub 
w części wypłatę niektórych dodatków do uposażenia w okresie urlopu okolicz-
nościowego albo pozostawania policjanta bez przydziału służbowego, uwzględniając 

 
 
 
s. 212/274 
 
2025-07-03 
 
rodzaje i wysokość dodatków, których wypłata podlega ograniczeniu w razie urlopu 
okolicznościowego albo pozostawania policjanta bez przydziału służbowego, a także 
właściwość organów w tych sprawach.

***
## Art. 121a. {#policja-art-121a}

1. Miesięczne uposażenie policjanta za okres ustalony przepisami 
Kodeksu pracy jako okres urlopu macierzyńskiego, okres urlopu na warunkach urlopu 
macierzyńskiego, okres uzupełniającego urlopu macierzyńskiego oraz okres urlopu 
ojcowskiego wynosi 100 % uposażenia, o którym mowa w art. 121 ust. 1. 
2. Miesięczne uposażenie policjanta za okres ustalony przepisami Kodeksu pracy 
jako okres urlopu rodzicielskiego wynosi 70 % miesięcznego uposażenia, o którym 
mowa w art. 121 ust. 1. 
3. Policjant – kobieta, nie później niż 21 dni po porodzie, może złożyć pisemny 
wniosek o wypłacenie jej uposażenia za okres odpowiadający okresowi urlopu 
macierzyńskiego i urlopu rodzicielskiego w pełnym wymiarze, z wyłączeniem okresu, 
o którym mowa w art. 1821a § 4 Kodeksu pracy, przysługującego ojcu dziecka, 
w wysokości 81,5 % uposażenia, o którym mowa w art. 121 ust. 1. 
4. Policjant, nie później niż 21 dni po przyjęciu dziecka na wychowanie 
i wystąpieniu do sądu opiekuńczego z wnioskiem o wszczęcie postępowania 
w sprawie przysposobienia dziecka albo po przyjęciu dziecka na wychowanie jako 
rodzina zastępcza, z wyjątkiem rodziny zastępczej zawodowej, może złożyć pisemny 
wniosek o wypłacenie mu uposażenia za okres odpowiadający okresowi urlopu na 
warunkach urlopu macierzyńskiego i urlopu rodzicielskiego w pełnym wymiarze, 
z wyłączeniem 
okresu, 
o którym 
mowa 
w art. 1821a 
§ 4 Kodeksu 
pracy, 
przysługującego drugiemu rodzicowi dziecka, w wysokości 81,5 % uposażenia, 
o którym mowa w art. 121 ust. 1. 
5. W przypadku złożenia wniosku, o którym mowa w ust. 3, policjant – kobieta 
może dzielić się z ojcem dziecka korzystaniem z uposażenia za okres odpowiadający 
okresowi urlopu rodzicielskiego albo jego części, z wyłączeniem okresu, o którym 
mowa w art. 1821a § 4 Kodeksu pracy. Przepis stosuje się odpowiednio do wniosku, 
o którym mowa w ust. 4. 
6. Uposażenie za okres odpowiadający okresowi urlopu rodzicielskiego w części 
przysługującej policjantowi – ojcu dziecka, o której mowa w art. 1821a § 4 Kodeksu 
pracy, wynosi 70 % uposażenia, o którym mowa w art. 121 ust. 1. 

 
 
 
s. 213/274 
 
2025-07-03 
 
7. W przypadku niewykorzystania przez policjanta ani jednego dnia urlopu 
rodzicielskiego w pierwszym roku życia dziecka uposażenie za okres urlopu 
rodzicielskiego przysługuje w wysokości 70 % miesięcznego uposażenia, o którym 
mowa w art. 121 ust. 1. 
8. W przypadku niewykorzystania ani jednego dnia urlopu rodzicielskiego 
w pierwszym roku życia dziecka, policjantowi przysługuje jednorazowe wyrównanie 
pobranego uposażenia za okres urlopu macierzyńskiego do wysokości 100 % 
miesięcznego uposażenia, o którym mowa w art. 121 ust. 1. 
9. Jednorazowe wyrównanie uposażenia, o którym mowa w ust. 8, następuje na 
wniosek policjanta. 
10. W przypadku gdy wysokość uposażenia policjanta, pomniejszonego 
o zaliczkę na podatek dochodowy od osób fizycznych, obliczonego zgodnie z ust. 1‒
4, jest niższa niż kwota świadczenia rodzicielskiego określonego w ustawie z dnia 
28 listopada 2003 r. o świadczeniach rodzinnych (Dz. U. z 2024 r. poz. 323, 858, 1615 
i 1871), kwotę uposażenia policjanta, pomniejszonego o zaliczkę na podatek 
dochodowy od osób fizycznych, podwyższa się do wysokości świadczenia 
rodzicielskiego.

***
## Art. 121b. {#policja-art-121b}

1. W okresie przebywania na zwolnieniu lekarskim policjant 
otrzymuje 80 % uposażenia. 
2. Zwolnienie lekarskie obejmuje okres, w którym policjant jest zwolniony od 
zajęć służbowych z powodu: 
1) 
choroby policjanta, w tym niemożności wykonywania zajęć służbowych z 
przyczyn określonych w art. 6 ust. 2 ustawy z dnia 25 czerwca 1999 r. o 
świadczeniach pieniężnych z ubezpieczenia społecznego w razie choroby i 
macierzyństwa; 
2) 
oddawania krwi lub jej składników w jednostkach organizacyjnych publicznej 
służby krwi lub z powodu okresowego badania lekarskiego dawców krwi; 
3) 
konieczności osobistego sprawowania opieki nad chorym dzieckiem własnym 
lub małżonka policjanta, dzieckiem przysposobionym, dzieckiem przyjętym na 
wychowanie i utrzymanie, do ukończenia przez nie 14. roku życia; 
4) 
konieczności osobistego sprawowania opieki nad chorym członkiem rodziny; za 
członków rodziny uważa się małżonka, rodziców, rodzica dziecka policjanta, 
ojczyma, macochę, teściów, dziadków, wnuki, rodzeństwo oraz dzieci w wieku 

 
 
 
s. 214/274 
 
2025-07-03 
 
powyżej 14 lat, jeżeli pozostają we wspólnym gospodarstwie domowym z 
policjantem w okresie sprawowania nad nimi opieki; 
5) 
konieczności osobistego sprawowania opieki nad dzieckiem własnym lub 
małżonka policjanta, dzieckiem przysposobionym, dzieckiem przyjętym na 
wychowanie i utrzymanie, do ukończenia przez nie 8. roku życia, w przypadku: 
a) 
nieprzewidzianego zamknięcia żłobka, klubu dziecięcego, przedszkola lub 
szkoły, do których dziecko uczęszcza, a także w przypadku choroby niani, 
z którą rodzice mają zawartą umowę uaktywniającą, o której mowa w art. 
50 ustawy z dnia 4 lutego 2011 r. o opiece nad dziećmi w wieku do lat 3 
(Dz. U. z 2024 r. poz. 338, 743 i 858), lub dziennego opiekuna, 
sprawujących opiekę nad dzieckiem, 
b) 
porodu lub choroby małżonka policjanta lub rodzica dziecka policjanta, 
stale opiekujących się dzieckiem, jeżeli poród lub choroba uniemożliwia 
temu małżonkowi lub rodzicowi sprawowanie opieki nad dzieckiem, 
c) 
pobytu małżonka policjanta lub rodzica dziecka policjanta, stale 
opiekujących się dzieckiem, w szpitalu lub innym zakładzie leczniczym 
podmiotu leczniczego wykonującego działalność leczniczą w rodzaju 
stacjonarne i całodobowe świadczenia zdrowotne. 
3. Zwolnienie od zajęć służbowych z powodu konieczności osobistego 
sprawowania opieki, o której mowa w ust. 2 pkt 3 i 5, przysługuje przez okres nie 
dłuższy niż 60 dni w roku kalendarzowym, a w przypadku, o którym mowa w ust. 2 
pkt 4 – przez okres nie dłuższy niż 14 dni w roku kalendarzowym, przy czym okresy 
te łącznie nie mogą przekroczyć 60 dni w roku kalendarzowym. 
4. Przepis ust. 3 stosuje się bez względu na liczbę dzieci i innych członków 
rodziny wymagających opieki. 
5. Jeżeli zwolnienie lekarskie obejmuje okres, w którym policjant jest zwolniony 
od zajęć służbowych z powodu: 
1) 
wypadku pozostającego w związku z pełnieniem służby, 
2) 
choroby powstałej w związku ze szczególnymi właściwościami lub warunkami 
służby, 
3) 
wypadku w drodze do miejsca pełnienia służby lub w drodze powrotnej ze 
służby, 
4) 
choroby przypadającej w czasie ciąży, 

 
 
 
s. 215/274 
 
2025-07-03 
 
5) 
poddania się niezbędnym badaniom lekarskim przewidzianym dla kandydatów 
na dawców komórek, tkanek i narządów oraz poddania się zabiegowi pobrania 
komórek, tkanek i narządów, 
6) 
oddania krwi lub jej składników w jednostkach organizacyjnych publicznej 
służby krwi lub z powodu badania lekarskiego dawców krwi, 
7) 
przebywania na obserwacji w podmiocie leczniczym w wyniku skierowania 
przez komisję lekarską, 
8) 
stwierdzenia zakażenia lub zachorowania na chorobę, o której mowa w 
przepisach o zapobieganiu oraz zwalczaniu zakażeń i chorób zakaźnych u ludzi, 
przy czym stwierdzone zakażenie lub zachorowanie powstało w związku z 
wykonywaniem zadań służbowych w okresie ogłoszenia stanu zagrożenia 
epidemicznego lub stanu epidemii z powodu tej choroby 
– zachowuje on prawo do 100 % uposażenia. 
6. Prawo do 100 % uposażenia przysługuje również wtedy, gdy policjant został 
zwolniony od zajęć służbowych: 
1) 
podczas oddelegowania do pełnienia służby poza granicami państwa w 
kontyngencie policyjnym, o którym mowa w art. 145a ust. 1 pkt 1–3; 
2) 
w wyniku popełnienia przez inną osobę umyślnego czynu zabronionego w 
związku 
z 
wykonywaniem 
przez 
policjanta 
czynności 
służbowych, 
stwierdzonego orzeczeniem wydanym przez uprawniony organ; 
3) 
na skutek czynów o charakterze bohaterskim dokonanych w szczególnie 
niebezpiecznych warunkach, z wykazaniem wyjątkowej odwagi, z narażeniem 
życia lub zdrowia, w obronie prawa, nienaruszalności granic państwowych, 
życia, mienia lub bezpieczeństwa obywateli; 
4) 
na skutek podlegania obowiązkowej kwarantannie, izolacji lub izolacji w 
warunkach domowych, o których mowa w przepisach o zapobieganiu oraz 
zwalczaniu zakażeń i chorób zakaźnych u ludzi, jeżeli podleganie tej kwarantan-
nie lub izolacji powstało w związku z wykonywaniem zadań służbowych w 
okresie ogłoszenia stanu zagrożenia epidemicznego lub stanu epidemii z powodu 
tej choroby. 
6a. Wykonywanie zadań służbowych, o których mowa w ust. 5 pkt 8 i ust. 6 pkt 
4, stwierdza pisemnie przełożony właściwy do spraw osobowych lub upoważniona 
przez niego osoba. 

 
 
 
s. 216/274 
 
2025-07-03 
 
7. Związek zwolnienia od zajęć służbowych z czynami, o których mowa w ust. 6 
pkt 3, stwierdza, w drodze decyzji, przełożony policjanta. 
8. Od decyzji, o której mowa w ust. 7, policjantowi przysługuje odwołanie do 
wyższego przełożonego.

***
## Art. 121c. {#policja-art-121c}

1. Okres przebywania na zwolnieniu lekarskim stwierdza 
zaświadczenie lekarskie wystawione zgodnie z art. 55 ust. 1 i art. 55a ust. 7 ustawy z 
dnia 25 czerwca 1999 r. o świadczeniach pieniężnych z ubezpieczenia społecznego w 
razie choroby i macierzyństwa albo wydruk zaświadczenia lekarskiego, o którym 
mowa w art. 55a ust. 6 tej ustawy, z tym że: 
1) 
w przypadku poddania się niezbędnym badaniom lekarskim przewidzianym dla 
kandydatów na dawców komórek, tkanek i narządów oraz niezdolności do służby 
wskutek poddania się zabiegowi pobrania komórek, tkanek i narządów – 
zaświadczenie wystawione przez lekarza na zwykłym druku zgodnie z przepisem 
art. 53 ust. 3 ustawy z dnia 25 czerwca 1999 r. o świadczeniach pieniężnych z 
ubezpieczenia społecznego w razie choroby i macierzyństwa; 
2) 
w przypadku, o którym mowa w art. 121b ust. 2 pkt 2 – zaświadczenie jednostki 
organizacyjnej publicznej służby krwi; 
3) 
w przypadku, o którym mowa w art. 121b ust. 2 pkt 5 lit. a – oświadczenie 
policjanta; 
4) 
w przypadkach, o których mowa w art. 121b ust. 2 pkt 5 lit. b i c – zaświadczenie 
lekarskie wystawione przez lekarza na zwykłym druku; 
5) 
w przypadku, o którym mowa w art. 6 ust. 2 pkt 1 ustawy z dnia 25 czerwca 1999 
r. o świadczeniach pieniężnych z ubezpieczenia społecznego w razie choroby i 
macierzyństwa – decyzja wydana przez właściwy organ albo uprawniony 
podmiot na podstawie przepisów o zapobieganiu oraz zwalczaniu zakażeń i 
chorób zakaźnych u ludzi. 
2. 
W 
przypadkach 
uzasadnionych 
charakterem 
zadań 
służbowych 
wykonywanych przez policjanta okres jego przebywania na zwolnieniu lekarskim 
stwierdza się w inny sposób niż określony w ust. 1. 
3. Komendant Główny Policji określi, w drodze zarządzenia, z zachowaniem 
przepisów o ochronie informacji niejawnych, sposób stwierdzania przebywania na 
zwolnieniu lekarskim policjanta, o którym mowa w ust. 2. 

 
 
 
s. 217/274 
 
2025-07-03

***
## Art. 121d. {#policja-art-121d}

1. Doręczenie zaświadczenia lekarskiego odbywa się przy 
wykorzystaniu profilu informacyjnego, o którym mowa w art. 58 ust. 1 ustawy z dnia 
25 czerwca 1999 r. o świadczeniach pieniężnych z ubezpieczenia społecznego w razie 
choroby i macierzyństwa, na zasadach określonych w tej ustawie. Kierownicy 
jednostek organizacyjnych Policji wykorzystują lub tworzą profil informacyjny 
płatnika składek, o którym mowa w art. 58 ust. 1 ustawy z dnia 25 czerwca 1999 r. 
o świadczeniach pieniężnych z ubezpieczenia społecznego w razie choroby i 
macierzyństwa. 
2. Wydruk zaświadczenia lekarskiego, o którym mowa w art. 55a ust. 6 ustawy 
z dnia 25 czerwca 1999 r. o świadczeniach pieniężnych z ubezpieczenia społecznego 
w razie choroby i macierzyństwa, zaświadczenie lekarskie, o którym mowa w art. 55a 
ust. 7 tej ustawy, albo zaświadczenie wystawione przez lekarza na zwykłym druku w 
przypadkach, o których mowa w art. 121b ust. 2 pkt 5 lit. b i c oraz art. 121c ust. 1 pkt 
1, policjant jest obowiązany dostarczyć przełożonemu właściwemu do spraw 
osobowych w terminie 7 dni od dnia jego otrzymania. 
3. Zaświadczenie jednostki organizacyjnej publicznej służby krwi albo decyzję, 
o której mowa w art. 121c ust. 1 pkt 5, policjant jest obowiązany dostarczyć 
właściwemu przełożonemu w terminie 7 dni od dnia ich otrzymania. 
4. Oświadczenie o wystąpieniu okoliczności, o których mowa w art. 121b ust. 2 
pkt 5 lit. a, policjant jest obowiązany złożyć przełożonemu właściwemu do spraw 
osobowych w terminie 7 dni od dnia ich zaistnienia. 
5. W przypadku niedopełnienia obowiązków, o których mowa w ust. 2–4, 
nieobecność w służbie w okresie przebywania na zwolnieniu lekarskim uznaje się za 
nieobecność nieusprawiedliwioną, chyba że niedostarczenie zaświadczenia, 
oświadczenia albo decyzji nastąpiło z przyczyn niezależnych od policjanta.

***
## Art. 121e. {#policja-art-121e}

1. Prawidłowość orzekania o czasowej niezdolności do służby z 
powodu choroby, prawidłowość wykorzystania zwolnienia lekarskiego, spełnienie 
wymogów formalnych zaświadczeń lekarskich oraz oświadczenie policjanta, o którym 
mowa w art. 121c ust. 1 pkt 3, może podlegać kontroli. 
2. Kontrolę przeprowadzają: 
1) 
komisje lekarskie podległe ministrowi właściwemu do spraw wewnętrznych – w 
zakresie prawidłowości orzekania o czasowej niezdolności do służby z powodu 
choroby oraz prawidłowości wykorzystania zwolnienia lekarskiego; 

 
 
 
s. 218/274 
 
2025-07-03 
 
2) 
przełożony policjanta właściwy w sprawach osobowych – w zakresie 
prawidłowości wykorzystania zwolnienia lekarskiego i spełnienia wymogów 
formalnych zaświadczeń lekarskich oraz w zakresie oświadczenia policjanta, o 
którym mowa w art. 121c ust. 1 pkt 3. 
3. Jeżeli w wyniku kontroli zostanie ustalone nieprawidłowe wykorzystanie 
zwolnienia lekarskiego, policjant traci prawo do uposażenia za cały okres zwolnienia. 
4. Jeżeli w wyniku kontroli zostanie ustalone, że oświadczenie policjanta, o 
którym mowa w art. 121c ust. 1 pkt 3, zostało złożone niezgodnie z prawdą, policjant 
traci prawo do uposażenia za cały okres zwolnienia. 
5. Jeżeli w wyniku kontroli komisja lekarska ustali datę ustania niezdolności do 
służby wcześniejszą niż data orzeczona w zaświadczeniu lekarskim, policjant traci 
prawo do uposażenia za okres od tej daty do końca zwolnienia. 
6. Jeżeli w wyniku kontroli zostanie ustalone, że zwolnienie lekarskie zostało 
sfałszowane, policjant traci prawo do uposażenia za cały okres zwolnienia. 
7. Kontrola prawidłowości wykorzystania zwolnień lekarskich polega na 
ustaleniu, czy policjant w okresie orzeczonej niezdolności do służby, w tym 
sprawowania osobistej opieki nad dzieckiem lub innym członkiem rodziny, nie 
wykorzystuje zwolnienia lekarskiego w sposób niezgodny z jego celem, a w 
szczególności czy nie wykonuje pracy zarobkowej. 
8. Kontrola oświadczenia policjanta, o którym mowa w art. 121c ust. 1 pkt 3, 
polega na ustaleniu, czy nastąpiło nieprzewidziane zamknięcie żłobka, klubu 
dziecięcego, przedszkola lub szkoły, do których uczęszcza dziecko policjanta, lub na 
ustaleniu, czy niania lub dzienny opiekun dziecka przebywali na zwolnieniu 
lekarskim. 
9. Kontrolę prawidłowości wykorzystania zwolnienia lekarskiego oraz 
oświadczenia policjanta, o którym mowa w art. 121c ust. 1 pkt 3, przeprowadza osoba 
upoważniona przez przełożonego policjanta. 
10. W razie stwierdzenia w trakcie kontroli, że policjant wykonuje pracę 
zarobkową albo wykorzystuje zwolnienie lekarskie w inny sposób niezgodny z jego 
celem, osoba kontrolująca sporządza protokół, w którym podaje, na czym polegało 
nieprawidłowe wykorzystanie zwolnienia lekarskiego. 
11. W razie stwierdzenia w trakcie kontroli, że oświadczenie policjanta, o którym 
mowa w art. 121c ust. 1 pkt 3, nie jest zgodne z prawdą, osoba kontrolująca sporządza 
protokół. 

 
 
 
s. 219/274 
 
2025-07-03 
 
12. Protokół przedstawia się policjantowi w celu wniesienia do niego 
ewentualnych uwag. Wniesienie uwag policjant potwierdza własnoręcznym 
podpisem. 
13. Na podstawie ustaleń zawartych w protokole przełożony stwierdza utratę 
prawa do uposażenia za okres, o którym mowa w ust. 3 lub 4. Przepis stosuje się 
odpowiednio w przypadku zawiadomienia przez komisję lekarską podległą ministrowi 
właściwemu do spraw wewnętrznych w wyniku przeprowadzenia przez tę komisję 
kontroli o nieprawidłowościach w wykorzystaniu zwolnienia lekarskiego. 
14. Od decyzji, o której mowa w ust. 13, policjantowi służy odwołanie do 
wyższego przełożonego. 
15. Kontrola wymogów formalnych zaświadczeń lekarskich polega na 
sprawdzeniu, czy zaświadczenie: 
1) 
nie zostało sfałszowane; 
2) 
zostało wydane zgodnie z przepisami w sprawie zasad i trybu wystawiania 
zaświadczeń lekarskich. 
16. Jeżeli w wyniku kontroli, o której mowa w ust. 15 pkt 1, zachodzi 
podejrzenie, że zaświadczenie lekarskie zostało sfałszowane, przełożony występuje do 
lekarza, który wystawił zaświadczenie lekarskie, o wyjaśnienie sprawy. 
17. W razie podejrzenia, że zaświadczenie lekarskie zostało wydane niezgodnie 
z przepisami w sprawie zasad i trybu wystawiania zaświadczeń lekarskich, przełożony 
występuje o wyjaśnienie sprawy do terenowej jednostki organizacyjnej Zakładu 
Ubezpieczeń Społecznych.

***
## Art. 121f. {#policja-art-121f}

1. Podstawę uposażenia, o którym mowa w art. 121b, stanowi 
uposażenie zasadnicze wraz z dodatkami o charakterze stałym, należne policjantowi 
na ostatnio zajmowanym stanowisku służbowym, z uwzględnieniem powstałych w 
tym okresie zmian, mających wpływ na prawo do uposażenia i innych należności lub 
ich wysokość. 
2. Przy obliczaniu uposażenia za okres przebywania na zwolnieniu lekarskim 
przyjmuje się, że uposażenie za jeden dzień przebywania na zwolnieniu lekarskim 
stanowi 1/30 uposażenia, o którym mowa w art. 121b. 
3. W przypadku gdy policjant pobrał już uposażenie za okres, w którym 
przebywał na zwolnieniu lekarskim, potrąca mu się odpowiednią część uposażenia 
przy najbliższej wypłacie. 

 
 
 
s. 220/274 
 
2025-07-03 
 
4. Policjantowi, który przebywał na zwolnieniu lekarskim w ostatnim miesiącu 
pełnienia służby, potrąca się odpowiednią część uposażenia z należności 
przysługujących mu z tytułu zwolnienia ze służby albo policjant ten zwraca 
odpowiednią część uposażenia w dniu ustania stosunku służbowego.

***
## Art. 121g. {#policja-art-121g}

1. Środki finansowe uzyskane z tytułu zmniejszenia uposażeń 
policjantów w okresie przebywania na zwolnieniu lekarskim przeznacza się w całości 
na nagrody za wykonywanie zadań służbowych w zastępstwie policjantów 
przebywających na zwolnieniach lekarskich. 
2. Środki finansowe, o których mowa w ust. 1, zwiększają fundusz nagród i 
zapomóg dla policjantów. 
3. Rozdział środków finansowych, o których mowa w ust. 1, odbywa się po 
zakończeniu okresu rozliczeniowego, trwającego nie krócej niż jeden miesiąc 
kalendarzowy i nie dłużej niż 3 miesiące kalendarzowe, przy czym wybór okresu 
rozliczeniowego uzależnia się od wielkości środków finansowych uzyskanych z tytułu 
zmniejszenia uposażeń policjantów.

***
## Art. 121h. {#policja-art-121h}

Zmniejszenia wysokości uposażenia zasadniczego wraz z dodatkami 
o charakterze stałym za okres przebywania na zwolnieniu lekarskim nie uwzględnia 
się przy ustalaniu podstawy wymiaru świadczeń, o których mowa w art. 108 ust. 1 pkt 
1, 3, 4a i 6 i ust. 2 pkt 2 oraz art. 117.

***
## Art. 121i. {#policja-art-121i}

1. Komendant Główny Policji sporządza roczne zestawienie zbiorcze 
przyczyn przebywania policjantów na zwolnieniach lekarskich, które przekazuje 
ministrowi właściwemu do spraw wewnętrznych w terminie do końca marca 
następnego roku. 
2. W zestawieniu, o którym mowa w ust. 1, wskazuje się łączny okres 
przebywania policjantów na zwolnieniach lekarskich, z uwzględnieniem podziału na 
przyczyny wskazane w art. 121b ust. 2, 5 i 6, oraz średni okres przebywania policjanta 
na zwolnieniu lekarskim, w tym średnią roczną liczbę godzin niewykonywania 
obowiązków przez policjanta. 
3. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
wzór zestawienia, o którym mowa w ust. 1, mając na uwadze potrzebę zapewnienia 
przejrzystości informacji zawartych w zestawieniu.

***
## Art. 122. {#policja-art-122}

1. Policjant skierowany do szkoły lub na przeszkolenie albo na studia 
w kraju otrzymuje uposażenie oraz inne należności pieniężne. 

 
 
 
s. 221/274 
 
2025-07-03 
 
2. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
wysokość i zasady otrzymywania uposażenia oraz innych należności, o których mowa 
w ust. 1, uwzględniając przypadki uprawniające policjanta skierowanego do szkoły 
lub na przeszkolenie albo na studia w kraju do otrzymywania uposażenia, oraz sposób 
obliczania zryczałtowanego równoważnika pieniężnego na pokrycie kosztów 
przejazdu, a także zasady rozliczania podróży służbowych związanych z odbywaniem 
nauki. 
3. Minister właściwy do spraw wewnętrznych, w porozumieniu z ministrem 
właściwym do spraw finansów publicznych oraz ministrem właściwym do spraw 
pracy, określi, w drodze rozporządzenia, wysokość uposażenia i innych należności 
pieniężnych policjanta skierowanego do akademii lub innych szkół (na kursy) za 
granicą, uwzględniając warunki ich otrzymywania oraz sposób i terminy ich 
wypłacania.

***
## Art. 122a. {#policja-art-122a}

Do policjanta delegowanego do pełnienia funkcji oficera 
łącznikowego w polskich przedstawicielstwach dyplomatycznych w zakresie prawa 
do uposażenia oraz innych świadczeń i należności pieniężnych stosuje się wyłącznie 
przepisy dotyczące pracowników polskich przedstawicielstw dyplomatycznych.

***
## Art. 123. {#policja-art-123}

1. W razie pobierania przez policjanta wynagrodzenia przewidzianego 
w przepisach o wynagrodzeniu osób zajmujących kierownicze stanowiska państwowe, 
policjantowi oraz członkom jego rodziny przysługują świadczenia i należności 
pieniężne z tytułu służby, określone w niniejszej ustawie, z wyjątkiem należności, o 
których mowa w art. 72. 
2. Świadczenia i należności pieniężne określone w ust. 1 wypłaca się w 
wysokości ustalonej, z uwzględnieniem wynagrodzenia należnego policjantowi na 
ostatnio zajmowanym stanowisku służbowym lub według stawki obowiązującej w 
dniu zwolnienia ze służby albo w dniu jego śmierci.

***
## Art. 124. {#policja-art-124}

1. Policjantowi zawieszonemu w czynnościach służbowych zawiesza 
się od najbliższego terminu płatności 50 % ostatnio należnego uposażenia. 
2. Po zakończeniu postępowania karnego lub dyscyplinarnego, będącego 
przyczyną zawieszenia w czynnościach służbowych, policjant otrzymuje zawieszoną 
część uposażenia oraz obligatoryjne podwyżki wprowadzone w okresie zawieszenia, 
jeżeli nie został skazany prawomocnym wyrokiem sądu lub ukarany karą 
dyscyplinarną wydalenia ze służby. 

 
 
 
s. 222/274 
 
2025-07-03

***
## Art. 125. {#policja-art-125}

1. Policjantowi tymczasowo aresztowanemu zawiesza się od 
najbliższego terminu płatności 50 % ostatnio należnego uposażenia. 
2. W razie umorzenia postępowania karnego lub uniewinnienia prawomocnym 
wyrokiem sądu, policjant otrzymuje zawieszoną część uposażenia oraz obligatoryjne 
podwyżki tego uposażenia, wprowadzone w okresie zawieszenia, choćby umorzenie 
lub uniewinnienie nastąpiło po zwolnieniu policjanta ze służby, z zastrzeżeniem 
przepisu ust. 3. 
3. Przepisu ust. 2 nie stosuje się w przypadku, gdy postępowanie karne umorzono 
z powodu przedawnienia lub amnestii, a także w razie warunkowego umorzenia 
postępowania karnego.

***
## Art. 125a. {#policja-art-125a}

Przełożony, o którym mowa w art. 32 ust. 1, biorąc pod uwagę 
okoliczności popełnienia zarzucanego policjantowi przestępstwa, w szczególności 
będącego następstwem użycia lub wykorzystania środków przymusu bezpośredniego 
lub broni palnej w związku z wykonywaniem czynności lub zadań służbowych może 
podjąć decyzję o zachowaniu policjantowi, na okres zawieszenia w czynnościach 
służbowych lub tymczasowego aresztowania, prawa do pełnego uposażenia, 
począwszy od dnia zawieszenia policjanta w czynnościach służbowych lub 
tymczasowego aresztowania.

***
## Art. 126. {#policja-art-126}

1. Policjantowi, który samowolnie opuścił miejsce pełnienia służby 
albo pozostaje poza nim lub nie podejmuje służby, zawiesza się uposażenie od 
najbliższego 
terminu 
płatności. 
Jeżeli 
policjant 
pobrał 
już 
za 
czas 
nieusprawiedliwionej nieobecności uposażenie, potrąca mu się odpowiednią część 
uposażenia przy najbliższej wypłacie. 
2. W razie uznania nieobecności za usprawiedliwioną, wypłaca się policjantowi 
zawieszone uposażenie; w przypadku nieobecności nieusprawiedliwionej policjant 
traci za każdy dzień nieobecności 1/30 część uposażenia miesięcznego. 
3. Przepisy ust. 1 i 2 stosuje się odpowiednio w razie zawinionej niemożności 
pełnienia przez policjanta obowiązków służbowych. 
4. Policjantowi, który rozpoczyna urlop bezpłatny w ciągu miesiąca 
kalendarzowego, przysługuje uposażenie w wysokości 1/30 uposażenia miesięcznego 
za każdy dzień poprzedzający dzień rozpoczęcia urlopu bezpłatnego. Jeżeli policjant 
pobrał już uposażenie za czas urlopu bezpłatnego, potrąca się mu odpowiednią część 
uposażenia przy najbliższej wypłacie. 

 
 
 
s. 223/274 
 
2025-07-03

***
## Art. 127. {#policja-art-127}

1. Z uposażenia policjanta mogą być dokonywane potrącenia w 
granicach i na zasadach określonych w przepisach prawa pracy oraz w innych 
przepisach szczególnych stosowanych do wynagrodzeń za pracę, jeżeli przepisy 
niniejszej ustawy nie stanowią inaczej. 
2. Przez uposażenie, o którym mowa w ust. 1, należy rozumieć uposażenie 
wymienione w art. 100, odprawę z tytułu zwolnienia ze służby oraz świadczenia 
wymienione w art. 112 i 117, z zastrzeżeniem ust. 3. 
3. Odprawa z tytułu zwolnienia ze służby podlega egzekucji wyłącznie na 
zaspokojenie zaległych świadczeń alimentacyjnych, z uwzględnieniem ograniczeń 
wynikających z ust. 1.

***
## Art. 128. {#policja-art-128}

Przepisu art. 127 ust. 1 i 2 nie stosuje się do zaliczek pobieranych do 
rozliczenia, a w szczególności na koszty podróży służbowej, delegacji i przeniesienia. 
Należności te potrąca się z uposażenia w pełnej wysokości, niezależnie od potrąceń z 
innych tytułów.

***
## Art. 129. {#policja-art-129}

Uprawnienia przewidziane w art. 12, art. 101 ust. 2, art. 102, art. 104 
ust. 6, art. 105 ust. 3, art. 110 ust. 1, art. 112 ust. 2, art. 113 ust. 2 i art. 120 ust. 2 
minister właściwy do spraw wewnętrznych wykonuje po zasięgnięciu opinii związków 
zawodowych.

***
## Art. 130. {#policja-art-130}

(uchylony)

***
## Art. 131. {#policja-art-131}

(uchylony)

