---
id: act.policja.ch15
title: Ustawa o Policji — Rozdział 10
dz_u: Dz.U. 1990 Nr 30 poz. 179 (t.j. 2025 poz. 636, 718)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: 145l
  last: 145w
source_pdf: D19900179Lj (1).pdf
chunking:
  strategy: by-article
  anchor_pattern: '## Art. {n}. {#policja-art-{n}}'
  hierarchy:
  - Rozdział
  - Art.
---

# Rozdział 10
d  
## Art. 145l. {#policja-art-145l}

1. Do użycia w Policji psy i konie dobiera się w taki sposób, aby 
spełniały kryteria zdrowotne i użytkowe, o których mowa w przepisach wydanych na 
podstawie art. 7 ust. 1 pkt 5, zapewniające przydatność zwierzęcia do użycia go w celu 
realizacji zadań, o których mowa w art. 1 ust. 2 pkt 1, 2 i 3a–4a.  
2. Psy służbowe i konie służbowe mogą być używane w Policji po odbyciu 
szkolenia, o którym mowa w przepisach wydanych na podstawie art. 7 ust. 1 pkt 5.  

 
 
 
s. 265/274 
 
2025-07-03 
 
3. Psy służbowe i konie służbowe znajdują się na stanie jednostki organizacyjnej 
Policji, która dokonała zakupu tych zwierząt, o ile Komendant Główny Policji nie 
wskazał innej jednostki organizacyjnej Policji.  
4. Psy służbowe wycofane z użycia i konie służbowe wycofane z użycia 
pozostają na stanie jednostki organizacyjnej Policji, o której mowa w ust. 3, albo 
jednostki organizacyjnej Policji wskazanej przez Komendanta Głównego Policji.

***
## Art. 145m. {#policja-art-145m}

1. Opiekunem psa służbowego lub opiekunem konia służbowego jest 
odpowiednio:  
1) 
przewodnik – policjant, któremu przydzielono pod opiekę psa służbowego i który 
ukończył szkolenie, o którym mowa w przepisach wydanych na podstawie art. 7 
ust. 1 pkt 5;  
2) 
kandydat na przewodnika – policjant, któremu przydzielono pod opiekę psa 
służbowego i którego wytypowano lub skierowano po raz pierwszy na szkolenie, 
o którym mowa w przepisach wydanych na podstawie art. 7 ust. 1 pkt 5;  
3) 
policjant-jeździec – policjant, któremu przydzielono pod opiekę konia 
służbowego i który ukończył szkolenie, o którym mowa w przepisach wydanych 
na podstawie art. 7 ust. 1 pkt 5;  
4) 
kandydat na policjanta-jeźdźca – policjant, któremu przydzielono pod opiekę 
konia służbowego i którego wytypowano lub skierowano po raz pierwszy na 
szkolenie, o którym mowa w przepisach wydanych na podstawie art. 7 ust. 1 pkt 
5;  
5) 
pracownik Policji wykonujący czynności służbowe z użyciem danego zwierzęcia 
lub w zakresie opieki nad nim.  
2. Szkolenie przewodników i kandydatów na przewodników, policjantów-
-jeźdźców i kandydatów na policjantów-jeźdźców oraz psów służbowych i koni 
służbowych realizowane jest w ramach doskonalenia zawodowego.

***
## Art. 145n. {#policja-art-145n}

1. Opiekunem psa służbowego wycofanego z użycia lub opiekunem 
konia służbowego wycofanego z użycia w pierwszej kolejności może być 
dotychczasowy opiekun tego zwierzęcia, jeżeli złoży pisemną deklarację woli 
sprawowania opieki.  
2. W następnej kolejności opiekunem psa służbowego wycofanego z użycia lub 
opiekunem konia służbowego wycofanego z użycia może być inny opiekun psa 

 
 
 
s. 266/274 
 
2025-07-03 
 
służbowego lub konia służbowego, jeżeli złoży pisemną deklarację woli sprawowania 
opieki.  
3. Jeżeli pies służbowy wycofany z użycia lub koń służbowy wycofany z użycia 
nie zostanie powierzony opiekunowi, o którym mowa w ust. 1 albo 2, zwierzę można 
powierzyć innemu policjantowi lub pracownikowi Policji, emerytowanemu 
policjantowi lub policjantowi zwolnionemu ze służby w Policji, który ma ustalone 
prawo do policyjnej renty inwalidzkiej w rozumieniu ustawy z dnia 18 lutego 1994 r. 
o zaopatrzeniu emerytalnym funkcjonariuszy Policji, Agencji Bezpieczeństwa 
Wewnętrznego, Agencji Wywiadu, Służby Kontrwywiadu Wojskowego, Służby 
Wywiadu Wojskowego, Centralnego Biura Antykorupcyjnego, Straży Granicznej, 
Straży Marszałkowskiej, Służby Ochrony Państwa, Państwowej Straży Pożarnej, 
Służby Celno-Skarbowej i Służby Więziennej oraz ich rodzin, jeżeli złoży pisemną 
deklarację woli sprawowania opieki oraz posiada wiedzę i umiejętności w zakresie 
opieki nad psem lub koniem.  
4. W przypadku zgłoszenia się większej liczby kandydatów na opiekuna psa 
służbowego wycofanego z użycia lub kandydatów na opiekuna konia służbowego 
wycofanego z użycia, o których mowa w ust. 2 i 3, kierownik jednostki organizacyjnej 
Policji, na której stanie znajduje się zwierzę, przeprowadza postępowanie 
rekrutacyjne.  
5. W ramach postępowania rekrutacyjnego w pierwszej kolejności są 
uwzględniane osoby, które zamieszkują na terenie działania jednostki organizacyjnej 
Policji, która przeprowadza to postępowanie.  
6. W przypadku śmierci opiekuna psa służbowego wycofanego z użycia lub 
opiekuna konia służbowego wycofanego z użycia opiekunem tego zwierzęcia w 
pierwszej kolejności może zostać członek rodziny zmarłego opiekuna, który prowadził 
z tym opiekunem wspólne gospodarstwo domowe, jeżeli złoży pisemną deklarację 
woli sprawowania opieki. Przepisy ust. 2 i 3 stosuje się odpowiednio.  
7. W przypadku gdy pies służbowy wycofany z użycia lub koń służbowy 
wycofany z użycia nie zostanie powierzony osobom, o których mowa w ust. 1–3 albo 
6, opiekę nad zwierzęciem sprawuje jednostka organizacyjna Policji, na której stanie 
znajduje się zwierzę, albo jednostka organizacyjna Policji wskazana przez 
Komendanta Głównego Policji.  
8. Kierownik jednostki organizacyjnej Policji, na której stanie znajduje się 
zwierzę, albo kierownik jednostki organizacyjnej Policji wskazanej przez Komendanta 

 
 
 
s. 267/274 
 
2025-07-03 
 
Głównego Policji wyznacza opiekuna psa służbowego wycofanego z użycia lub konia 
służbowego wycofanego z użycia.  
9. Kierownik jednostki organizacyjnej Policji, na której stanie znajduje się 
zwierzę, albo kierownik jednostki organizacyjnej Policji wskazanej przez Komendanta 
Głównego Policji może powierzyć opiekę nad psem służbowym wycofanym z użycia 
lub koniem służbowym wycofanym z użycia organizacji społecznej, której 
statutowym celem działania jest ochrona zwierząt.  
10. Opiekunem psa służbowego wycofanego z użycia lub konia służbowego 
wycofanego z użycia nie może zostać osoba, która w następstwie swojego 
zawinionego działania przyczyniła się do wycofania z użycia psa służbowego lub 
konia służbowego.  
11. Opiekunem psa służbowego wycofanego z użycia lub konia służbowego 
wycofanego z użycia nie może zostać opiekun, któremu odebrano zwierzę z powodów, 
o których mowa w art. 145v ust. 1 pkt 1 lub 2. Do organizacji, o której mowa w ust. 9, 
zdanie pierwsze stosuje się.

***
## Art. 145o. {#policja-art-145o}

Opiekun psa służbowego, opiekun konia służbowego, opiekun psa 
służbowego wycofanego z użycia i opiekun konia służbowego wycofanego z użycia, 
zwani dalej „opiekunem”, oraz organizacja, o której mowa w art. 145n ust. 9, 
zapewniają prawidłowe utrzymanie zwierzęcia obejmujące w szczególności:  
1) 
racjonalne żywienie oraz stały dostęp do czystej i świeżej wody;  
2) 
dbanie o stan zdrowia i kondycję, w tym poddawanie terminowym szczepieniom 
i zabiegom profilaktycznym oraz zapewnienie możliwości codziennego ruchu;  
3) 
pielęgnację i utrzymanie w czystości;  
4) 
warunki utrzymania dostosowane do potrzeb biologicznych.

***
## Art. 145p. {#policja-art-145p}

1. Żywienie psa służbowego, konia służbowego, psa służbowego 
wycofanego z użycia lub konia służbowego wycofanego z użycia jest dostosowane do 
potrzeb jego organizmu, wagi, wieku, stanu zdrowia, warunków klimatycznych, 
funkcji fizjologicznych oraz wysiłku fizycznego lub wskazań lekarza weterynarii.  
2. Żywienie psa służbowego, konia służbowego, psa służbowego wycofanego z 
użycia lub konia służbowego wycofanego z użycia odbywa się na podstawie normy 
wyżywienia, którą stanowi dobowa ilość karmy lub paszy, artykułów spożywczych 
oraz dodatków paszowych, niezbędnych do prawidłowego żywienia jednego psa lub 
konia. Z uwagi na zwiększone zapotrzebowanie energetyczne i odżywcze w trakcie 

 
 
 
s. 268/274 
 
2025-07-03 
 
odbywania szkolenia przez psa służbowego lub konia służbowego norma ta może 
zostać podwyższona. W przypadku wycofania psa służbowego lub konia służbowego 
z użycia norma ta jest zmniejszana w związku ze zmniejszonym wysiłkiem fizycznym 
zwierzęcia.  
3. W przypadku stwierdzenia przez lekarza weterynarii konieczności 
zastosowania w żywieniu psa służbowego, konia służbowego, psa służbowego 
wycofanego z użycia lub konia służbowego wycofanego z użycia diety lub karmy 
leczniczej norma, o której mowa w ust. 2, może zostać podwyższona.  
4. Opiekun psa służbowego lub opiekun konia służbowego otrzymuje 
wyżywienie dla psa lub konia w naturze albo równoważnik pieniężny w formie 
ryczałtu na pokrycie kosztów wyżywienia zwierzęcia. Ryczałt wypłaca się co miesiąc 
z góry.  
5. Opiekun psa służbowego wycofanego z użycia, opiekun konia służbowego 
wycofanego z użycia oraz organizacja, o której mowa w art. 145n ust. 9, otrzymują 
równoważnik pieniężny w formie ryczałtu na pokrycie kosztów wyżywienia 
zwierzęcia. Ryczałt wypłaca się co miesiąc z góry.  
6. Opiekun oraz organizacja, o której mowa w art. 145n ust. 9, są obowiązani do 
proporcjonalnego zwrotu wypłaconego ryczałtu na pokrycie kosztów wyżywienia 
zwierzęcia w przypadku:  
1) 
padnięcia albo konieczności bezzwłocznego uśmiercenia zwierzęcia na zasadach 
określonych w ustawie z dnia 21 sierpnia 1997 r. o ochronie zwierząt;  
2) 
odebrania zwierzęcia, o którym mowa w art. 145v ust. 1;  
3) 
utraty lub zaginięcia zwierzęcia;  
4) 
rezygnacji ze sprawowania opieki nad zwierzęciem;  
5) 
powierzenia opieki nad psem służbowym lub koniem służbowym innemu 
opiekunowi, o którym mowa w art. 145v ust. 3 albo 4;  
6) 
korzystania przez zwierzę w trakcie odbywania szkolenia z wyżywienia w 
naturze.  
7. W sprawach, o których mowa w ust. 3–6, właściwy jest kierownik jednostki 
organizacyjnej Policji, na której stanie znajduje się zwierzę. W przypadku odbywania 
szkolenia przez psa służbowego w szkole policyjnej, wyżywienie w naturze dla psa 
służbowego zapewnia komendant szkoły policyjnej.  

 
 
 
s. 269/274 
 
2025-07-03

***
## Art. 145q. {#policja-art-145q}

1. Psa służbowego, konia służbowego, psa służbowego wycofanego 
z użycia lub konia służbowego wycofanego z użycia poddaje się zabiegom 
profilaktycznym i leczeniu według wskazań lekarza weterynarii. Leczenie psa 
służbowego, konia służbowego, psa służbowego wycofanego z użycia lub konia 
służbowego wycofanego z użycia następuje po uprzednim uzgodnieniu z 
kierownikiem jednostki organizacyjnej Policji, na której stanie znajduje się zwierzę, 
lub z osobą przez niego upoważnioną.  
2. W sytuacjach nagłych, wymagających udzielenia natychmiastowej pomocy 
lekarsko-weterynaryjnej w celu ratowania życia lub zdrowia psa służbowego, konia 
służbowego, psa służbowego wycofanego z użycia lub konia służbowego wycofanego 
z użycia dopuszcza się możliwość odstąpienia od uzgodnienia zakresu udzielanej 
pomocy z kierownikiem jednostki organizacyjnej Policji, na której stanie znajduje się 
zwierzę, lub z osobą przez niego upoważnioną.  
3. W przypadku wystąpienia sytuacji nagłej, o której mowa w ust. 2, należy 
niezwłocznie poinformować o zaistniałej sytuacji i zakresie udzielonej pomocy 
lekarsko-weterynaryjnej kierownika jednostki organizacyjnej Policji, na której stanie 
znajduje się zwierzę, lub osobę przez niego upoważnioną. 
4. Koszty zabiegów profilaktycznych i leczenia psa służbowego, konia 
służbowego, psa służbowego wycofanego z użycia lub konia służbowego wycofanego 
z użycia, w tym koszty lekarstw, pokrywa się ze środków budżetowych Policji na 
podstawie faktury.  
5. Koszt utylizacji zwłok psa służbowego, konia służbowego, psa służbowego 
wycofanego z użycia lub konia służbowego wycofanego z użycia pokrywa się ze 
środków budżetowych Policji na podstawie faktury.  
6. W sprawach, o których mowa w ust. 4 i 5, właściwy jest kierownik jednostki 
organizacyjnej Policji, na której stanie znajduje się zwierzę. W przypadku odbywania 
szkolenia przez psa służbowego w szkole policyjnej właściwy w sprawach, o których 
mowa w ust. 1–4, jest komendant szkoły policyjnej.

***
## Art. 145r. {#policja-art-145r}

Opiekunowi oraz organizacji, o której mowa w art. 145n ust. 9, 
zabrania się:  
1) 
zbywania zwierzęcia;  
2) 
rozmnażania zwierzęcia, z wyjątkiem psów będących na stanie szkoły policyjnej;  
3) 
wykorzystywania zwierzęcia w celach zarobkowych.  

 
 
 
s. 270/274 
 
2025-07-03

***
## Art. 145s. {#policja-art-145s}

1. Psa służbowego lub konia służbowego wycofuje się z użycia w 
przypadku:  
1) 
trwałej utraty sprawności użytkowej;  
2) 
wystąpienia stanu chorobowego nierokującego poprawy;  
3) 
wystąpienia narowów u konia;  
4) 
braku postępów w szkoleniu rokujących osiągnięcie odpowiedniego poziomu 
wyszkolenia zwierzęcia;  
5) 
padnięcia albo konieczności jego bezzwłocznego uśmiercenia na zasadach 
określonych w ustawie z dnia 21 sierpnia 1997 r. o ochronie zwierząt;  
6) 
upływu 6 miesięcy od dnia jego utraty albo zaginięcia.  
2. Pies służbowy lub koń służbowy będące po raz pierwszy w trakcie szkolenia 
w przypadkach, o których mowa w ust. 1 pkt 2 lub 4, podlegają wymianie albo 
zwrotowi sprzedawcy na zasadach określonych w ustawie z dnia 23 kwietnia 1964 r. 
– Kodeks cywilny (Dz. U. z 2024 r. poz. 1061 i 1237). W przypadkach, o których 
mowa w zdaniu pierwszym, nie mają zastosowania przepisy art. 145l ust. 4, art. 145n–
145r i art. 145t–145v.  
3. Psa służbowego lub konia służbowego można wycofać z użycia po 
ukończeniu:  
1) 
9. roku życia przez psa;  
2) 
15. roku życia przez konia.  
4. Psa służbowego lub konia służbowego wycofuje z użycia kierownik jednostki 
organizacyjnej Policji, na której stanie znajduje się zwierzę.

***
## Art. 145t. {#policja-art-145t}

1. Nadzór nad psami służbowymi, końmi służbowymi, psami 
służbowymi wycofanymi z użycia oraz końmi służbowymi wycofanymi z użycia 
sprawuje kierownik jednostki organizacyjnej Policji, na której stanie znajdują się 
zwierzęta.  
2. Jeżeli pies służbowy wycofany z użycia lub koń służbowy wycofany z użycia 
znajduje się na terenie innej jednostki organizacyjnej Policji niż wymieniona w ust. 1, 
na wniosek kierownika jednostki organizacyjnej Policji, na której stanie znajdują się 
zwierzęta, wsparcie w trakcie realizacji nadzoru nad sposobem sprawowania opieki 
nad zwierzętami zapewnia kierownik jednostki organizacyjnej Policji, na której 
terenie znajdują się zwierzęta.  

 
 
 
s. 271/274 
 
2025-07-03

***
## Art. 145u. {#policja-art-145u}

1. Opiekun i przedstawiciel organizacji, o której mowa w art. 145n 
ust. 9, w celu umożliwienia sprawowania nadzoru, na żądanie policjanta lub 
pracownika wyznaczonego przez kierownika jednostki organizacyjnej Policji, na 
której stanie albo terenie znajduje się zwierzę, okazuje zwierzę, a opiekun konia 
okazuje dodatkowo paszport konia.  
2. Opiekun oraz organizacja, o której mowa w art. 145n ust. 9, niezwłocznie 
powiadamiają kierownika jednostki organizacyjnej Policji, na której stanie znajduje 
się zwierzę, o:  
1) 
zmianie stałego miejsca przebywania lub chowu zwierzęcia oraz zmianie miejsca 
przebywania zwierzęcia trwającej dłużej niż 30 dni, o ile nie przebywa ono w 
obiekcie należącym do tej jednostki organizacyjnej Policji;  
2) 
padnięciu albo konieczności bezzwłocznego uśmiercenia zwierzęcia na zasadach 
określonych w ustawie z dnia 21 sierpnia 1997 r. o ochronie zwierząt, utracie 
albo zaginięciu zwierzęcia oraz o okolicznościach tych zdarzeń.

***
## Art. 145v. {#policja-art-145v}

1. Psa służbowego, konia służbowego, psa służbowego wycofanego z 
użycia albo konia służbowego wycofanego z użycia odbiera się opiekunowi lub 
organizacji, o której mowa w art. 145n ust. 9, w przypadku:  
1) 
stwierdzenia zaniedbania zwierzęcia;  
2) 
niewywiązywania się z obowiązku opieki nad zwierzęciem lub postępowania 
wbrew zakazom, o których mowa w art. 145r;  
3) 
rezygnacji ze sprawowania opieki nad zwierzęciem.  
2. Do czasu powierzenia psa służbowego, konia służbowego, psa służbowego 
wycofanego z użycia lub konia służbowego wycofanego z użycia innemu opiekunowi 
opiekę nad zwierzęciem sprawuje jednostka organizacyjna Policji, na której stanie 
znajduje się zwierzę, albo jednostka organizacyjna Policji wskazana przez 
Komendanta Głównego Policji.  
3. W przypadku przeniesienia opiekuna psa służbowego lub opiekuna konia 
służbowego na stanowisko służbowe niezwiązane z realizacją czynności służbowych 
związanych z użyciem zwierzęcia lub opieką nad zwierzęciem opieka nad tym psem 
lub koniem może zostać powierzona innemu opiekunowi psa służbowego lub 
opiekunowi konia służbowego.  
4. W przypadku czasowego braku możliwości sprawowania opieki nad psem 
służbowym lub koniem służbowym przez opiekuna kierownik jednostki 

 
 
 
s. 272/274 
 
2025-07-03 
 
organizacyjnej Policji, na której stanie znajduje się zwierzę, może wyznaczyć 
czasowego opiekuna psa służbowego lub konia służbowego. Do czasowego opiekuna 
stosuje się odpowiednio przepisy dotyczące opiekuna psa służbowego lub konia 
służbowego, z zastrzeżeniem, że ryczałt na pokrycie kosztów wyżywienia zwierzęcia 
wypłaca się co miesiąc z góry, proporcjonalnie do okresu sprawowania opieki nad 
psem służbowym lub koniem służbowym.

***
## Art. 145w. {#policja-art-145w}

Minister właściwy do spraw wewnętrznych określi, w drodze 
rozporządzenia:  
1) 
tryb przydzielania opiekunowi psa służbowego i konia służbowego,  
2) 
tryb rekrutacji kandydatów, którzy mogą zostać opiekunami psów służbowych 
wycofanych z użycia i koni służbowych wycofanych z użycia,  
3) 
tryb wycofywania z użycia psa służbowego i konia służbowego,  
4) 
sposób utrzymania, zakres i sposób zapewnienia zabiegów profilaktycznych oraz 
sposób transportu psów służbowych, koni służbowych, psów służbowych 
wycofanych z użycia i koni służbowych wycofanych z użycia,  
5) 
sposób wyżywienia, wysokość normy wyżywienia psa służbowego i konia 
służbowego oraz normy wyżywienia psa służbowego wycofanego z użycia i 
konia służbowego wycofanego z użycia, w tym maksymalną wysokość normy 
w przypadku jej podwyższenia, jak również wysokość dziennej stawki pieniężnej 
na wyżywienie zwierzęcia,  
6) 
tryb przyznawania, wypłacania oraz zwrotu ryczałtu na pokrycie kosztów 
wyżywienia psa służbowego, konia służbowego, psa służbowego wycofanego z 
użycia lub konia służbowego wycofanego z użycia,  
7) 
tryb pokrywania kosztów zabiegów profilaktycznych i kosztów leczenia, w tym 
kosztów lekarstw, psa służbowego, konia służbowego, psa służbowego 
wycofanego z użycia lub konia służbowego wycofanego z użycia,  
8) 
sposób sprawowania nadzoru oraz dokumentowania wykonywania czynności 
związanych z nadzorem nad psami służbowymi, końmi służbowymi, psami 
służbowymi wycofanymi z użycia lub końmi służbowymi wycofanymi z użycia,  
9) 
tryb odbierania psa służbowego, konia służbowego, psa służbowego wycofanego 
z użycia lub konia służbowego wycofanego z użycia opiekunowi lub organizacji, 
o której mowa w art. 145n ust. 9,  
10) wzory dokumentów stosowanych w tych sprawach  

 
 
 
s. 273/274 
 
2025-07-03 
 
– uwzględniając potrzebę zapewnienia prawidłowej realizacji zadań związanych z 
użyciem psa służbowego lub konia służbowego, prawidłowej opieki nad zwierzęciem, 
racjonalnego wydatkowania środków finansowych, prawidłowego dokumentowania 
realizowanych czynności oraz to, że wysokość dziennej stawki pieniężnej na 
wyżywienie zwierząt jest uzależniona od wagi, okresu roku i zadań wykonywanych 
przez psa służbowego, okresu roku i zadań wykonywanych przez konia służbowego, 
a także że nie może ona przekroczyć 1/30 minimalnego wynagrodzenia za pracę, o 
którym mowa w ustawie z dnia 10 października 2002 r. o minimalnym wynagrodzeniu 
za pracę.

