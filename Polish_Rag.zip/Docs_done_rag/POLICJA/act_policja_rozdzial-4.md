---
id: act.policja.ch4
title: Ustawa o Policji — Rozdział 3
dz_u: Dz.U. 1990 Nr 30 poz. 179 (t.j. 2025 poz. 636, 718)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: 22a
  last: 22b
source_pdf: D19900179Lj (1).pdf
chunking:
  strategy: by-article
  anchor_pattern: '## Art. {n}. {#policja-art-{n}}'
  hierarchy:
  - Rozdział
  - Art.
---

# Rozdział 3
a 
## Art. 22a. {#policja-art-22a}

Jednostki pływające Policji podnoszą jako banderę flagę państwową z 
godłem Rzeczypospolitej Polskiej, określoną w odrębnych przepisach.

***
## Art. 22b. {#policja-art-22b}

1. W czasie wykonywania zadań określonych w ustawie jednostki 
pływające Policji podnoszą, niezależnie od bandery, flagę Policji. 
2. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
wzór flagi Policji, okoliczności i warunki jej podnoszenia oraz sposób oznakowania 
jednostek pływających i statków powietrznych, a także znaki rozpoznawcze używane 
na nich przez Policję w nocy, uwzględniając sposób umieszczenia bandery i flagi na 
jednostkach pływających, ze wskazaniem, które z nich podnoszą flagę Policji, oraz 
oznakowania statków powietrznych Policji, z ustaleniem, które z nich oznakowuje się 
symbolem Policji.

