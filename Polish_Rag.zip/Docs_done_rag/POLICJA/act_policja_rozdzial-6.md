---
id: act.policja.ch6
title: Ustawa o Policji — Rozdział 5
dz_u: Dz.U. 1990 Nr 30 poz. 179 (t.j. 2025 poz. 636, 718)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '25'
  last: 46b
source_pdf: D19900179Lj (1).pdf
chunking:
  strategy: by-article
  anchor_pattern: '## Art. {n}. {#policja-art-{n}}'
  hierarchy:
  - Rozdział
  - Art.
---

# Rozdział 5
 
## Art. 25. {#policja-art-25}

1. Służbę w Policji może pełnić obywatel polski o nieposzlakowanej 
opinii, który nie był skazany prawomocnym wyrokiem sądu za przestępstwo lub 
przestępstwo skarbowe, korzystający z pełni praw publicznych, posiadający 
co najmniej wykształcenie średnie lub średnie branżowe oraz zdolność fizyczną i 
psychiczną do służby w formacjach uzbrojonych, podległych szczególnej dyscyplinie 
służbowej, której jest gotów się podporządkować, a także dający rękojmię zachowania 

 
 
 
s. 102/274 
 
2025-07-03 
 
tajemnicy stosownie do wymogów określonych w przepisach o ochronie informacji 
niejawnych. 
2. Przyjęcie kandydata do służby w Policji, zwanego dalej „kandydatem”, 
następuje po przeprowadzeniu postępowania kwalifikacyjnego mającego na celu 
ustalenie, czy kandydat spełnia warunki przyjęcia do służby w Policji, oraz określenie 
jego predyspozycji do pełnienia tej służby. Postępowanie kwalifikacyjne składa się z 
następujących etapów: 
1) 
złożenia podania o przyjęcie do służby, kwestionariusza osobowego kandydata 
do służby w Policji, a także dokumentów stwierdzających wymagane 
wykształcenie i kwalifikacje zawodowe oraz zawierających dane o uprzednim 
zatrudnieniu; 
2) 
testu wiedzy; 
3) 
testu sprawności fizycznej; 
4) 
badania psychologicznego w tym testu psychologicznego; 
5) 
rozmowy kwalifikacyjnej; 
6) 
ustalenia zdolności fizycznej i psychicznej do służby w Policji; 
7) 
sprawdzenia w ewidencjach, rejestrach i kartotekach, w tym w policyjnych 
zbiorach danych, prawdziwości danych zawartych w kwestionariuszu osobowym 
kandydata do służby w Policji; 
8) 
postępowania sprawdzającego określonego w przepisach o ochronie informacji 
niejawnych 
– 
w przypadku 
braku 
odpowiedniego 
poświadczenia 
bezpieczeństwa. 
2a. Postępowanie kwalifikacyjne może być prowadzone wobec kandydatów, 
którzy ukończyli 18 lat, są uczniami ostatniej klasy szkoły, o której mowa 
w art. 18 ust. 1 pkt 2 lit. a, b i e ustawy z dnia 14 grudnia 2016 r. – Prawo oświatowe 
(Dz. U. z 2024 r. poz. 737, 854, 1562, 1635 i 1933), i nie posiadają w dniu rozpoczęcia 
postępowania 
kwalifikacyjnego 
dokumentów 
stwierdzających 
wymagane 
wykształcenie lub spełnienie warunku, o którym mowa w art. 28 ust. 3. 
2b. W przypadku, o którym mowa w ust. 2a, dokumenty stwierdzające 
wymagane wykształcenie lub spełnienie warunku, o którym mowa w art. 28 ust. 3, 
kandydat składa przed przyjęciem do służby. 
3. Podczas przeprowadzania testu wiedzy, badania psychologicznego oraz 
sprawdzenia 
wiedzy, 
umiejętności 
i znajomości 
języka, 
o którym 
mowa 

 
 
 
s. 103/274 
 
2025-07-03 
 
w ust. 12 pkt 2, ust. 12a pkt 2, ust. 12c pkt 2, ust. 13 pkt 2, ust. 13a pkt 2, ust. 13b 
pkt 2 i ust. 14 pkt 2, kandydatowi zakazuje się: 
1) 
korzystania z pomocy innych osób; 
2) 
posługiwania się urządzeniami służącymi do przekazu, odbioru lub zapisu 
informacji lub korzystania z niedopuszczonych do wykorzystania materiałów 
pomocniczych; 
3) 
zakłócania ich przebiegu w sposób inny niż określony w pkt 1 i 2. 
4. W przypadku złamania przez kandydata zakazów, o których mowa w ust. 3, 
kandydat otrzymuje negatywny wynik odpowiednio testu wiedzy, badania 
psychologicznego lub sprawdzenia wiedzy, umiejętności i znajomości języka, 
o którym mowa w ust. 12 pkt 2, ust. 12a pkt 2, ust. 12c pkt 2, ust. 13 pkt 2, ust. 13a 
pkt 2, ust. 13b pkt 2 i ust. 14 pkt 2. 
5. W uzasadnionych przypadkach postępowanie kwalifikacyjne dotyczące 
kandydata ubiegającego się o przyjęcie na stanowisko służbowe, na którym wymagane 
są specjalistyczne kwalifikacje, wykształcenie, uprawnienia lub umiejętności 
pożądane ze względu na potrzeby kadrowe Policji, składa się z następujących etapów: 
1) 
złożenia podania o przyjęcie do służby, kwestionariusza osobowego kandydata 
do służby w Policji, a także dokumentów stwierdzających wymagane 
wykształcenie i kwalifikacje zawodowe oraz zawierających dane o uprzednim 
zatrudnieniu; 
2) 
badania psychologicznego w tym testu psychologicznego; 
3) 
rozmowy kwalifikacyjnej; 
4) 
ustalenia zdolności fizycznej i psychicznej do służby w Policji; 
5) 
sprawdzenia w ewidencjach, rejestrach i kartotekach, w tym w policyjnych 
zbiorach danych, prawdziwości danych zawartych w kwestionariuszu osobowym 
kandydata do służby w Policji; 
6) 
postępowania sprawdzającego określonego w przepisach o ochronie informacji 
niejawnych 
– 
w przypadku 
braku 
odpowiedniego 
poświadczenia 
bezpieczeństwa. 
6. W przypadku kandydata, o którym mowa w ust. 5, rozmowa kwalifikacyjna 
przeprowadzana jest z uwzględnieniem wymagań dotyczących pełnienia służby na 
stanowisku służbowym, na którym wymagane są specjalistyczne kwalifikacje, 
wykształcenie, uprawnienia lub umiejętności pożądane ze względu na potrzeby 
kadrowe Policji. 

 
 
 
s. 104/274 
 
2025-07-03 
 
7. W przypadku gdy kandydat posiada specjalistyczne kwalifikacje, 
wykształcenie, uprawnienia lub umiejętności pożądane ze względu na potrzeby 
kadrowe Policji, uwzględnia się je w ocenie kandydata. 
8. W przypadku kandydata ubiegającego się o przyjęcie do służby w CBŚP, 
BSWP, CBZC albo CLKP postępowanie kwalifikacyjne może być rozszerzone o 
przeprowadzenie badania psychofizjologicznego. 
9. W przypadku kandydata ubiegającego się o przyjęcie na stanowisko do służby 
w 
CBŚP, 
BSWP, 
CBZC 
albo 
CLKP 
przeprowadzenie 
etapu 
badania 
psychologicznego następuje z uwzględnieniem wymagań dotyczących pełnienia 
służby w tych jednostkach organizacyjnych Policji. 
10. W przypadku kandydata ubiegającego się o przyjęcie na stanowisko do 
służby kontrterrorystycznej przeprowadzenie następujących etapów: 
1) 
testu sprawności fizycznej, 
2) 
badania psychologicznego w tym testu psychologicznego, 
3) 
rozmowy kwalifikacyjnej, 
4) 
ustalenia zdolności fizycznej i psychicznej do służby w Policji 
– 
następuje 
z 
uwzględnieniem 
wymagań 
dotyczących 
pełnienia 
służby 
kontrterrorystycznej. 
11. W przypadku kandydata ubiegającego się o przyjęcie do służby: 
1) 
w charakterze członka personelu lotniczego w specjalnościach: 
a) 
pilota, posiadającego odpowiednie uprawnienia i kwalifikacje lotnicze do 
pilotowania statków powietrznych, 
b) 
mechanika lotniczego, posiadającego specjalistyczne wykształcenie 
niezbędne do obsługi technicznej statków powietrznych, 
2) 
w charakterze członka personelu medycznego w wyodrębnionych oddziałach 
prewencji 
– postępowanie kwalifikacyjne składa się z następujących etapów: złożenia podania o 
przyjęcie do służby, kwestionariusza osobowego kandydata do służby w Policji, a 
także dokumentów stwierdzających wymagane wykształcenie i kwalifikacje 
zawodowe oraz zawierających dane o uprzednim zatrudnieniu, rozmowy 
kwalifikacyjnej, ustalenia zdolności fizycznej i psychicznej do służby w Policji, 
sprawdzenia w ewidencjach, rejestrach i kartotekach, w tym w policyjnych zbiorach 
danych, prawdziwości danych zawartych w kwestionariuszu osobowym kandydata 

 
 
 
s. 105/274 
 
2025-07-03 
 
oraz z postępowania sprawdzającego określonego w przepisach o ochronie informacji 
niejawnych – w przypadku braku odpowiedniego poświadczenia bezpieczeństwa. 
12. W przypadku kandydata ubiegającego się o przyjęcie do służby w CBZC na 
stanowisko związane z bezpośrednim rozpoznawaniem i zwalczaniem przestępstw 
popełnionych przy użyciu systemu informatycznego, systemu teleinformatycznego 
lub sieci teleinformatycznej oraz zapobieganiem tym przestępstwom, a także 
wykrywaniem i ściganiem sprawców tych przestępstw, postępowanie kwalifikacyjne: 
1) 
składa się z następujących etapów: 
a) 
złożenia podania o przyjęcie do służby, kwestionariusza osobowego 
kandydata do służby w Policji, a także dokumentów stwierdzających 
wymagane wykształcenie i kwalifikacje zawodowe oraz zawierających dane 
o uprzednim zatrudnieniu, 
b) 
badania psychologicznego w tym testu psychologicznego, 
c) 
rozmowy kwalifikacyjnej, 
d) 
ustalenia zdolności fizycznej i psychicznej do służby w Policji, 
e) 
sprawdzenia w ewidencjach, rejestrach i kartotekach, w tym w policyjnych 
zbiorach danych, prawdziwości danych zawartych w kwestionariuszu 
osobowym kandydata do służby w Policji, 
f) 
postępowania sprawdzającego określonego w przepisach o ochronie 
informacji niejawnych – w przypadku braku odpowiedniego poświadczenia 
bezpieczeństwa; 
2) 
obejmuje sprawdzenie wiedzy i umiejętności z zakresu informatyki, 
funkcjonowania systemów informatycznych, systemów teleinformatycznych, 
sieci teleinformatycznych oraz znajomości języka obcego obejmującej te 
dziedziny. 
12a. W przypadku kandydata, który złożył podanie o przyjęcie do służby 
w Policji przed upływem 3 lat od dnia ukończenia oddziału o profilu mundurowym, 
o którym mowa w art. 28aa ust. 1 ustawy z dnia 14 grudnia 2016 r. – Prawo 
oświatowe, i uzyskał pozytywny wynik testu sprawności fizycznej, o którym mowa 
w ust. 2 pkt 3, w ostatniej klasie szkoły, postępowanie kwalifikacyjne składa się 
z następujących etapów: 
1) 
złożenia podania o przyjęcie do służby, kwestionariusza osobowego kandydata 
do służby w Policji, a także dokumentów stwierdzających wymagane 

 
 
 
s. 106/274 
 
2025-07-03 
 
wykształcenie i kwalifikacje zawodowe oraz zawierających dane o uprzednim 
zatrudnieniu; 
2) 
badania psychologicznego, w tym testu psychologicznego; 
3) 
rozmowy kwalifikacyjnej; 
4) 
ustalenia zdolności fizycznej i psychicznej do służby w Policji; 
5) 
sprawdzenia w ewidencjach, rejestrach i kartotekach, w tym w policyjnych 
zbiorach danych, prawdziwości danych zawartych w kwestionariuszu osobowym 
kandydata do służby w Policji; 
6) 
postępowania sprawdzającego określonego w przepisach o ochronie informacji 
niejawnych 
– 
w przypadku 
braku 
odpowiedniego 
poświadczenia 
bezpieczeństwa. 
12b. W przypadku, o którym mowa w ust. 12a, test sprawności fizycznej 
przeprowadza zespół, w którego skład wchodzą policjanci lub pracownicy Policji. 
12c. W przypadku 
kandydata, 
który 
jest 
zatrudniony 
w jednostkach 
organizacyjnych Policji od co najmniej 5 lat w pełnym wymiarze czasu pracy i posiada 
odpowiednie kwalifikacje i kompetencje pożądane ze względu na potrzeby kadrowe 
Policji, oraz złożył podanie o przyjęcie do służby w Policji, postępowanie 
kwalifikacyjne: 
1) 
składa się z następujących etapów: 
a) 
złożenia podania o przyjęcie do służby, kwestionariusza osobowego 
kandydata do służby w Policji, a także dokumentów stwierdzających 
wymagane wykształcenie i kwalifikacje zawodowe oraz zawierających 
dane o uprzednim zatrudnieniu, 
b) 
testu sprawności fizycznej, 
c) 
badania psychologicznego, w tym testu psychologicznego, 
d) 
rozmowy kwalifikacyjnej, 
e) 
ustalenia zdolności fizycznej i psychicznej do służby w Policji, 
f) 
sprawdzenia w ewidencjach, rejestrach i kartotekach, w tym w policyjnych 
zbiorach danych, prawdziwości danych zawartych w kwestionariuszu 
osobowym kandydata do służby w Policji, 
g) 
postępowania sprawdzającego określonego w przepisach o ochronie 
informacji niejawnych – w przypadku braku odpowiedniego poświadczenia 
bezpieczeństwa; 

 
 
 
s. 107/274 
 
2025-07-03 
 
2) 
obejmuje 
sprawdzenie 
wiedzy 
i umiejętności 
z zakresu 
informatyki, 
funkcjonowania systemów informatycznych, systemów teleinformatycznych, 
sieci teleinformatycznych oraz znajomości języka obcego obejmującej 
te dziedziny – w przypadku kandydata ubiegającego się o przyjęcie do służby 
w CBZC 
na 
stanowisko 
związane 
z bezpośrednim 
rozpoznawaniem 
i zwalczaniem przestępstw popełnionych przy użyciu systemu informatycznego, 
systemu teleinformatycznego lub sieci teleinformatycznej oraz zapobieganiem 
tym przestępstwom, a także wykrywaniem i ściganiem sprawców tych 
przestępstw. 
13. W przypadku kandydata, który przed upływem 5 lat od dnia zwolnienia ze 
służby w Policji złożył podanie o przyjęcie do służby, kwestionariusz osobowy 
kandydata do służby w Policji, a także dokumenty stwierdzające wymagane 
wykształcenie i kwalifikacje zawodowe oraz zawierające dane o uprzednim 
zatrudnieniu, jeżeli podczas pełnienia służby w Policji uzyskał kwalifikacje 
zawodowe podstawowe, postępowanie kwalifikacyjne: 
1) 
składa się z następujących etapów: 
a) 
złożenia podania o przyjęcie do służby, kwestionariusza osobowego 
kandydata do służby w Policji, a także dokumentów stwierdzających 
wymagane wykształcenie i kwalifikacje zawodowe oraz zawierających 
dane o uprzednim zatrudnieniu, 
b) 
rozmowy kwalifikacyjnej, 
c) 
ustalenia zdolności fizycznej i psychicznej do służby w Policji, 
d) 
sprawdzenia w ewidencjach, rejestrach i kartotekach, w tym w policyjnych 
zbiorach danych, prawdziwości danych zawartych w kwestionariuszu 
osobowym kandydata do służby w Policji, 
e) 
postępowania sprawdzającego określonego w przepisach o ochronie 
informacji niejawnych – w przypadku braku odpowiedniego poświadczenia 
bezpieczeństwa; 
2) 
obejmuje 
sprawdzenie 
wiedzy 
i umiejętności 
z zakresu 
informatyki, 
funkcjonowania systemów informatycznych, systemów teleinformatycznych, 
sieci teleinformatycznych oraz znajomości języka obcego obejmującej 
te dziedziny – w przypadku kandydata ubiegającego się o przyjęcie do służby 
w CBZC 
na 
stanowisko 
związane 
z bezpośrednim 
rozpoznawaniem 
i zwalczaniem przestępstw popełnionych przy użyciu systemu informatycznego, 

 
 
 
s. 108/274 
 
2025-07-03 
 
systemu teleinformatycznego lub sieci teleinformatycznej oraz zapobieganiem 
tym przestępstwom, a także wykrywaniem i ściganiem sprawców tych 
przestępstw. 
13a. W przypadku kandydata, który po upływie 5 lat od dnia zwolnienia 
ze służby w Policji złożył podanie o przyjęcie do służby, kwestionariusz osobowy 
kandydata do służby w Policji, a także dokumenty stwierdzające wymagane 
wykształcenie i kwalifikacje zawodowe oraz zawierające dane o uprzednim 
zatrudnieniu, jeżeli podczas pełnienia służby w Policji uzyskał kwalifikacje 
zawodowe podstawowe, postępowanie kwalifikacyjne: 
1) 
składa się z następujących etapów: 
a) 
złożenia podania o przyjęcie do służby, kwestionariusza osobowego 
kandydata do służby w Policji, a także dokumentów stwierdzających 
wymagane wykształcenie i kwalifikacje zawodowe oraz zawierających 
dane o uprzednim zatrudnieniu, 
b) 
testu sprawności fizycznej, 
c) 
rozmowy kwalifikacyjnej, 
d) 
ustalenia zdolności fizycznej i psychicznej do służby w Policji, 
e) 
sprawdzenia w ewidencjach, rejestrach i kartotekach, w tym w policyjnych 
zbiorach danych, prawdziwości danych zawartych w kwestionariuszu 
osobowym kandydata do służby w Policji, 
f) 
postępowania sprawdzającego określonego w przepisach o ochronie 
informacji niejawnych – w przypadku braku odpowiedniego poświadczenia 
bezpieczeństwa; 
2) 
obejmuje 
sprawdzenie 
wiedzy 
i umiejętności 
z zakresu 
informatyki, 
funkcjonowania systemów informatycznych, systemów teleinformatycznych, 
sieci teleinformatycznych oraz znajomości języka obcego obejmującej 
te dziedziny – w przypadku kandydata ubiegającego się o przyjęcie do służby 
w CBZC 
na 
stanowisko 
związane 
z bezpośrednim 
rozpoznawaniem 
i zwalczaniem przestępstw popełnionych przy użyciu systemu informatycznego, 
systemu teleinformatycznego lub sieci teleinformatycznej oraz zapobieganiem 
tym przestępstwom, a także wykrywaniem i ściganiem sprawców tych 
przestępstw. 
13b. W przypadku kandydata zwolnionego ze służby w Policji, który złożył 
podanie o przyjęcie do służby, kwestionariusz osobowy kandydata do służby 

 
 
 
s. 109/274 
 
2025-07-03 
 
w Policji, a także dokumenty stwierdzające wymagane wykształcenie i kwalifikacje 
zawodowe oraz zawierające dane o uprzednim zatrudnieniu, jeżeli w dniu zwolnienia 
ze służby w Policji posiadał policyjny stopień w korpusie co najmniej oficerów 
młodszych Policji, postępowanie kwalifikacyjne: 
1) 
składa się z następujących etapów: 
a) 
złożenia podania o przyjęcie do służby, kwestionariusza osobowego 
kandydata do służby w Policji, a także dokumentów stwierdzających 
wymagane wykształcenie i kwalifikacje zawodowe oraz zawierających 
dane o uprzednim zatrudnieniu, 
b) 
rozmowy kwalifikacyjnej, 
c) 
ustalenia zdolności fizycznej i psychicznej do służby w Policji, 
d) 
sprawdzenia w ewidencjach, rejestrach i kartotekach, w tym w policyjnych 
zbiorach danych, prawdziwości danych zawartych w kwestionariuszu 
osobowym kandydata do służby w Policji, 
e) 
postępowania sprawdzającego określonego w przepisach o ochronie 
informacji niejawnych – w przypadku braku odpowiedniego poświadczenia 
bezpieczeństwa; 
2) 
obejmuje 
sprawdzenie 
wiedzy 
i umiejętności 
z zakresu 
informatyki, 
funkcjonowania systemów informatycznych, systemów teleinformatycznych, 
sieci teleinformatycznych oraz znajomości języka obcego obejmującej 
te dziedziny – w przypadku kandydata ubiegającego się o przyjęcie do służby 
w CBZC 
na 
stanowisko 
związane 
z bezpośrednim 
rozpoznawaniem 
i zwalczaniem przestępstw popełnionych przy użyciu systemu informatycznego, 
systemu teleinformatycznego lub sieci teleinformatycznej oraz zapobieganiem 
tym przestępstwom, a także wykrywaniem i ściganiem sprawców tych 
przestępstw. 
13c. W przypadku kandydata zwolnionego ze służby w Policji, który złożył 
podanie o przyjęcie na stanowisko do służby kontrterrorystycznej, kwestionariusz 
osobowy kandydata do służby w Policji, a także dokumenty stwierdzające wymagane 
wykształcenie i kwalifikacje zawodowe oraz zawierające dane o uprzednim 
zatrudnieniu, jeżeli podczas pełnienia służby w Policji uzyskał kwalifikacje 
zawodowe podstawowe, postępowanie kwalifikacyjne składa się z następujących 
etapów: 

 
 
 
s. 110/274 
 
2025-07-03 
 
1) 
złożenia podania o przyjęcie do służby, kwestionariusza osobowego kandydata 
do służby w Policji, a także dokumentów stwierdzających wymagane 
wykształcenie i kwalifikacje zawodowe oraz zawierających dane o uprzednim 
zatrudnieniu; 
2) 
testu sprawności fizycznej; 
3) 
badania psychologicznego, w tym testu psychologicznego; 
4) 
rozmowy kwalifikacyjnej; 
5) 
ustalenia zdolności fizycznej i psychicznej do służby w Policji; 
6) 
sprawdzenia w ewidencjach, rejestrach i kartotekach, w tym w policyjnych 
zbiorach danych, prawdziwości danych zawartych w kwestionariuszu osobowym 
kandydata do służby w Policji; 
7) 
postępowania sprawdzającego określonego w przepisach o ochronie informacji 
niejawnych 
– 
w przypadku 
braku 
odpowiedniego 
poświadczenia 
bezpieczeństwa. 
13d. Etapy, o których mowa w ust. 13c pkt 2, 3 i 5, przeprowadza się 
z uwzględnieniem wymagań dotyczących pełnienia służby kontrterrorystycznej. 
14. W przypadku kandydata, który przed upływem 5 lat od dnia zwolnienia ze 
służby w Policji złożył podanie o przyjęcie do służby, kwestionariusz osobowy 
kandydata do służby w Policji, a także dokumenty stwierdzające wymagane 
wykształcenie i kwalifikacje zawodowe oraz zawierające dane o uprzednim 
zatrudnieniu, został przyjęty do służby w Policji po przeprowadzeniu postępowania 
kwalifikacyjnego, o którym mowa w ust. 5 lub 12, oraz uzyskał kwalifikacje 
zawodowe podstawowe, postępowanie kwalifikacyjne: 
1) 
składa się z następujących etapów: 
a) 
złożenia podania o przyjęcie do służby, kwestionariusza osobowego 
kandydata do służby w Policji, a także dokumentów stwierdzających 
wymagane wykształcenie i kwalifikacje zawodowe oraz zawierających 
dane o uprzednim zatrudnieniu, 
b) 
testu wiedzy, 
c) 
testu sprawności fizycznej, 
d) 
rozmowy kwalifikacyjnej, 
e) 
ustalenia zdolności fizycznej i psychicznej do służby w Policji, 

 
 
 
s. 111/274 
 
2025-07-03 
 
f) 
sprawdzenia w ewidencjach, rejestrach i kartotekach, w tym w policyjnych 
zbiorach danych, prawdziwości danych zawartych w kwestionariuszu 
osobowym kandydata do służby w Policji, 
g) 
postępowania sprawdzającego określonego w przepisach o ochronie 
informacji niejawnych – w przypadku braku odpowiedniego poświadczenia 
bezpieczeństwa; 
2) 
obejmuje 
sprawdzenie 
wiedzy 
i umiejętności 
z zakresu 
informatyki, 
funkcjonowania systemów informatycznych, systemów teleinformatycznych, 
sieci teleinformatycznych oraz znajomości języka obcego obejmującej 
te dziedziny – w przypadku kandydata ubiegającego się o przyjęcie do służby 
w CBZC 
na 
stanowisko 
związane 
z bezpośrednim 
rozpoznawaniem 
i zwalczaniem przestępstw popełnionych przy użyciu systemu informatycznego, 
systemu teleinformatycznego lub sieci teleinformatycznej oraz zapobieganiem 
tym przestępstwom, a także wykrywaniem i ściganiem sprawców tych 
przestępstw. 
15. Kandydat, wobec którego rozpoczęto postępowanie kwalifikacyjne, o którym 
mowa w ust. 2, ale go nie zakończono, może przystąpić, po złożeniu podania, do 
postępowania kwalifikacyjnego, o którym mowa w ust. 5 lub 12. Pozytywne wyniki 
następujących etapów: 
1) 
złożenia podania o przyjęcie do służby, kwestionariusza osobowego kandydata 
do służby w Policji, a także dokumentów stwierdzających wymagane 
wykształcenie i kwalifikacje zawodowe oraz zawierających dane o uprzednim 
zatrudnieniu, 
2) 
badania psychologicznego w tym testu psychologicznego, 
3) 
ustalenia zdolności fizycznej i psychicznej do służby w Policji, 
4) 
sprawdzenia w ewidencjach, rejestrach i kartotekach, w tym w policyjnych 
zbiorach danych, prawdziwości danych zawartych w kwestionariuszu osobowym 
kandydata do służby w Policji 
– uzyskane w postępowaniu, o którym mowa w ust. 2, uznaje się w postępowaniu, o 
którym mowa w ust. 5 lub 12. 
16. Kandydat, wobec którego zakończono postępowanie kwalifikacyjne, o 
którym mowa w ust. 5 lub 12, lecz nie został przyjęty do służby w Policji z powodu 
ograniczonej liczby przyjęć albo innej usprawiedliwionej przyczyny leżącej po jego 
stronie, może przystąpić, po złożeniu podania, do postępowania kwalifikacyjnego, o 

 
 
 
s. 112/274 
 
2025-07-03 
 
którym mowa w ust. 2. Podanie składa się nie później niż w terminie 7 dni od dnia 
zakończenia postępowania kwalifikacyjnego. Pozytywne wyniki następujących 
etapów: 
1) 
złożenia podania o przyjęcie do służby, kwestionariusza osobowego kandydata 
do służby w Policji, a także dokumentów stwierdzających wymagane 
wykształcenie i kwalifikacje zawodowe oraz zawierających dane o uprzednim 
zatrudnieniu; 
2) 
badania psychologicznego w tym testu psychologicznego, 
3) 
rozmowy kwalifikacyjnej, 
4) 
ustalenia zdolności fizycznej i psychicznej do służby w Policji, 
5) 
sprawdzenia w ewidencjach, rejestrach i kartotekach, w tym w policyjnych 
zbiorach danych, prawdziwości danych zawartych w kwestionariuszu osobowym 
kandydata do służby w Policji 
– uzyskane w postępowaniu, o którym mowa w ust. 5 lub 12, uznaje się w 
postępowaniu, o którym mowa w ust. 2. 
17. Postępowanie kwalifikacyjne zarządza i prowadzi: 
1) 
Komendant Główny Policji – w stosunku do kandydatów, o których mowa w ust. 
2, 5, 11 pkt 1, ust. 12c–13c oraz 14, ubiegających się o przyjęcie do służby 
w Komendzie Głównej Policji oraz BOA; 
2) 
Komendant CBŚP – w stosunku do kandydatów, o których mowa w ust. 2, 5, 
12c–13b oraz 14, ubiegających się o przyjęcie do służby w CBŚP; 
3) 
Komendant BSWP – w stosunku do kandydatów, o których mowa w ust. 2, 5, 
12c–13b oraz 14, ubiegających się o przyjęcie do służby w BSWP; 
4) 
Komendant CBZC – w stosunku do kandydatów, o których mowa w ust. 2, 5, 12, 
12c–13b oraz 14, ubiegających się o przyjęcie do służby w CBZC; 
5) 
Dyrektor CLKP – w stosunku do kandydatów, o których mowa w ust. 5, 12c–
13b oraz 14, ubiegających się o przyjęcie do służby w CLKP; 
6) 
Komendant-Rektor Akademii Policji w Szczytnie albo komendant szkoły 
policyjnej – w stosunku do kandydatów, o których mowa w ust. 5, 12c–13b oraz 
14, ubiegających się o przyjęcie do służby w Akademii Policji w Szczytnie albo 
w szkole policyjnej; 
7) 
komendant wojewódzki albo Komendant Stołeczny Policji – w stosunku do 
kandydatów, o których mowa w ust. 2, 5, 11, 12a, 12c–13c oraz 14, ubiegających 

 
 
 
s. 113/274 
 
2025-07-03 
 
się o przyjęcie do służby w komendzie wojewódzkiej albo Komendzie Stołecznej 
Policji oraz w podległych im jednostkach organizacyjnych Policji. 
18. Zarządzenie przez Komendanta CBŚP, Komendanta BSWP, Komendanta 
CBZC, Dyrektora CLKP, Komendanta-Rektora Akademii Policji w Szczytnie, 
komendanta szkoły policyjnej, komendanta wojewódzkiego Policji oraz Komendanta 
Stołecznego Policji postępowania kwalifikacyjnego, o którym mowa w ust. 5, 
wymaga uzyskania zgody Komendanta Głównego Policji. Zgody udziela się na 
wniosek zarządzającego. 
19. Komendant Główny Policji, Komendant CBŚP, Komendant BSWP, 
Komendant CBZC, Dyrektor CLKP, Komendant-Rektor Akademii Policji 
w Szczytnie, komendant szkoły policyjnej, komendant wojewódzki Policji oraz 
Komendant 
Stołeczny Policji odmawiają 
objęcia 
kandydata 
postępowaniem 
kwalifikacyjnym albo odstępują od jego prowadzenia w przypadku: 
1) 
niezłożenia 
kompletu 
dokumentów, 
o których 
mowa 
w ust. 2 pkt 1, 
ust. 2b, 5 pkt 1, ust. 11, 12 pkt 1 lit. a, ust. 12a pkt 1, ust. 12c pkt 1 lit. a, 
ust. 13 pkt 1 lit. a, ust. 13a pkt 1 lit. a, ust. 13b pkt 1 lit. a, ust. 13c pkt 1 
i ust. 14 pkt 1 lit. a; 
2) 
niespełnienia wymagań określonych w ust. 1; 
3) 
uzyskania negatywnego wyniku co najmniej jednego z następujących etapów 
postępowania kwalifikacyjnego: 
a) 
testu wiedzy, 
b) 
testu sprawności fizycznej, 
c) 
badania psychologicznego w tym testu psychologicznego, 
d) 
rozmowy kwalifikacyjnej, 
e) 
ustalenia zdolności fizycznej i psychicznej do służby w Policji, 
f) 
postępowania sprawdzającego określonego w przepisach o ochronie 
informacji niejawnych – o ile zostało przeprowadzone; 
4) 
uzyskania negatywnego wyniku badania psychofizjologicznego – w przypadku 
kandydata ubiegającego się o przyjęcie do służby w CBŚP, BSWP, CBZC albo 
CLKP; 
5) 
uzyskania negatywnego wyniku sprawdzenia wiedzy i umiejętności z zakresu 
informatyki, 
funkcjonowania 
systemów 
informatycznych, 
systemów 
teleinformatycznych, sieci teleinformatycznych oraz znajomości języka obcego 

 
 
 
s. 114/274 
 
2025-07-03 
 
obejmującej te dziedziny – w przypadku kandydata ubiegającego się o przyjęcie 
do służby w CBZC; 
6) 
zatajenia lub podania nieprawdziwych danych w kwestionariuszu osobowym 
kandydata do służby w Policji; 
7) 
niepoddania 
się 
przez 
kandydata 
przewidzianym 
w 
postępowaniu 
kwalifikacyjnym czynnościom lub etapom tego postępowania; 
8) 
przystąpienia do ponownego postępowania kwalifikacyjnego pomimo uzyskania 
przez niego w poprzednim postępowaniu kwalifikacyjnym negatywnego wyniku 
postępowania sprawdzającego określonego w przepisach o ochronie informacji 
niejawnych, gdy z informacji posiadanych przez komendanta prowadzącego 
postępowanie wynika, że nie uległy zmianie okoliczności stanowiące podstawę 
negatywnego wyniku tego etapu; 
9) 
gdy nie znajduje to uzasadnienia w potrzebach kadrowych Policji; 
10) rezygnacji kandydata z ubiegania się o przyjęcie do służby w Policji. 
20. W przypadku odstąpienia od prowadzenia postępowania kwalifikacyjnego z 
powodu uzyskania przez kandydata negatywnego wyniku testu sprawności fizycznej, 
rozmowy kwalifikacyjnej, ustalenia zdolności fizycznej i psychicznej, badania 
psychologicznego, 
badania 
psychofizjologicznego, 
niespełnienia 
wymagań 
określonych w ust. 1, zatajenia lub podania nieprawdziwych danych w 
kwestionariuszu osobowym kandydata do służby w Policji albo postępowania 
sprawdzającego określonego w przepisach o ochronie informacji niejawnych może on 
ponownie przystąpić do postępowania kwalifikacyjnego po upływie okresów 
wskazanych w przepisach wykonawczych wydanych na podstawie ust. 23, liczonych 
od dnia wystąpienia przyczyny odstąpienia od prowadzenia postępowania 
kwalifikacyjnego. 
21. Postępowanie kwalifikacyjne kończy się umieszczeniem kandydata na liście 
kandydatów 
i 
zatwierdzeniem 
listy 
przez 
zarządzającego 
postępowanie 
kwalifikacyjne, o którym mowa w ust. 17. 
21a. Kandydat, o którym mowa w ust. 12a, 12c–13c oraz 14, który uzyskał 
pozytywny wynik etapów postępowania kwalifikacyjnego ma pierwszeństwo 
w przyjęciu do służby w Policji. 
22. Informacje o wynikach postępowania kwalifikacyjnego nie stanowią 
informacji publicznej i nie podlegają udostępnieniu w trybie ustawy z dnia 6 września 
2001 r. o dostępie do informacji publicznej (Dz. U. z 2022 r. poz. 902). 

 
 
 
s. 115/274 
 
2025-07-03 
 
23. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia: 
1) 
zakres informacji o planowanym postępowaniu kwalifikacyjnym oraz sposób 
podawania ich do wiadomości, 
2) 
tryb i sposób przeprowadzania postępowania kwalifikacyjnego, 
3) 
wzór kwestionariusza osobowego kandydata do służby w Policji, 
4) 
zakres tematyczny i sposób przeprowadzania testu wiedzy, zakres i sposób 
przeprowadzania testu sprawności fizycznej, badania psychologicznego i 
rozmowy kwalifikacyjnej, 
5) 
zakres tematyczny i sposób sprawdzenia wiedzy i umiejętności z zakresu 
informatyki, 
funkcjonowania 
systemów 
informatycznych, 
systemów 
teleinformatycznych, sieci teleinformatycznych oraz znajomości języka obcego 
obejmującej te dziedziny, 
6) 
zakres i sposób przeprowadzania badania psychologicznego kandydatów 
ubiegających się o przyjęcie na określone stanowisko do służby w CBŚP, BSWP, 
CBZC albo CLKP, 
7) 
zakres i sposób przeprowadzania testu sprawności fizycznej, badania 
psychologicznego i rozmowy kwalifikacyjnej kandydatów ubiegających się o 
przyjęcie do służby kontrterrorystycznej, 
8) 
zakres, sposób organizowania, tryb przeprowadzania i ramową metodykę badań 
psychofizjologicznych oraz wykaz komórek organizacyjnych uprawnionych do 
ich przeprowadzania, 
9) 
sposób uznawania wyników uzyskanych przez kandydata w postępowaniu 
kwalifikacyjnym, o którym mowa w ust. 2, w przypadku przystąpienia do 
postępowania kwalifikacyjnego określonego w ust. 5 lub 12, 
10) sposób uznawania wyników uzyskanych przez kandydata w postępowaniu 
kwalifikacyjnym, o którym mowa w ust. 5 lub 12, w przypadku przystąpienia do 
postępowania kwalifikacyjnego określonego w ust. 2, 
11) wymagania dla osób przeprowadzających test sprawności fizycznej, badanie 
psychologiczne, badanie psychofizjologiczne oraz sprawdzenie wiedzy i 
umiejętności 
z 
zakresu 
informatyki, 
funkcjonowania 
systemów 
informatycznych, systemów teleinformatycznych, sieci teleinformatycznych 
oraz znajomości języka obcego obejmującej te dziedziny, 
12) tryb złożenia i zakres informacji, jakie powinien zawierać wniosek, o którym 
mowa w ust. 18, 

 
 
 
s. 116/274 
 
2025-07-03 
 
13) sposób dokonywania oceny kandydatów, w tym sposób uwzględniania w ocenie 
preferencji z tytułu specjalistycznych kwalifikacji, wykształcenia, uprawnień lub 
umiejętności pożądanych ze względu na potrzeby kadrowe Policji, 
14) szczegółowy sposób zakończenia postępowania kwalifikacyjnego, w tym 
warunki umieszczenia kandydata na liście kandydatów oraz minimalny okres, po 
którym kandydat może ponownie przystąpić do postępowania kwalifikacyjnego 
lub poszczególnych jego etapów, 
15) zakres informacji o wyniku postępowania kwalifikacyjnego 
– 
uwzględniając 
powszechność 
dostępu 
do 
informacji 
o 
postępowaniu 
kwalifikacyjnym, 
czynności 
niezbędne 
do 
przeprowadzenia 
postępowania 
kwalifikacyjnego i ustalenia w jego toku predyspozycji kandydata, wykształcenie, 
kwalifikacje lub uprawnienia osób przeprowadzających test sprawności fizycznej, 
badanie psychologiczne, badanie psychofizjologiczne oraz sprawdzenie wiedzy i 
umiejętności z zakresu informatyki, funkcjonowania systemów informatycznych, 
systemów teleinformatycznych, sieci teleinformatycznych oraz znajomości języka 
obcego obejmującej te dziedziny, a także potrzebę zapewnienia sprawności 
prowadzenia tego postępowania, przejrzystości stosowanych kryteriów oceny, 
obiektywności wyników postępowania i wyboru kandydatów posiadających w 
największym stopniu cechy, umiejętności oraz kwalifikacje przydatne do realizacji 
zadań służbowych, w tym uwzględniając wymagania do pełnienia służby w 
jednostkach organizacyjnych Policji, o których mowa w art. 5a, art. 5b, art. 5d i art. 
5e, oraz służbie kontrterrorystycznej.

***
## Art. 25a. {#policja-art-25a}

1. Funkcjonariusz Straży Granicznej, Straży Marszałkowskiej, Służby 
Ochrony Państwa, Służby Celno-Skarbowej, Państwowej Straży Pożarnej, Agencji 
Bezpieczeństwa Wewnętrznego, Agencji Wywiadu, Służby Wywiadu Wojskowego, 
Służby Kontrwywiadu Wojskowego lub Centralnego Biura Antykorupcyjnego może 
być na własną prośbę przeniesiony do służby w Policji, jeżeli wykazuje on szczególne 
predyspozycje do jej pełnienia. 
2. Funkcjonariusza, o którym mowa w ust. 1, do służby w Policji przenosi w 
porozumieniu odpowiednio z Komendantem Głównym Straży Granicznej, Szefem 
Kancelarii Sejmu, Komendantem Służby Ochrony Państwa, Szefem Krajowej 
Administracji Skarbowej, Komendantem Głównym Państwowej Straży Pożarnej, 
Szefem Agencji Bezpieczeństwa Wewnętrznego, Szefem Agencji Wywiadu, Szefem 

 
 
 
s. 117/274 
 
2025-07-03 
 
Służby Wywiadu Wojskowego, Szefem Służby Kontrwywiadu Wojskowego lub 
Szefem Centralnego Biura Antykorupcyjnego Komendant Główny Policji za zgodą 
ministra właściwego do spraw wewnętrznych. 
3. Funkcjonariusz Straży Granicznej, Straży Marszałkowskiej, Służby Ochrony 
Państwa, 
Służby 
Celno-Skarbowej, 
Państwowej 
Straży 
Pożarnej, 
Agencji 
Bezpieczeństwa Wewnętrznego, Agencji Wywiadu, Służby Wywiadu Wojskowego, 
Służby Kontrwywiadu Wojskowego lub Centralnego Biura Antykorupcyjnego 
przeniesiony do służby w Policji zachowuje ciągłość służby. 
4. Funkcjonariuszowi przenoszonemu w trybie, o którym mowa w ust. 1, nie 
przysługuje odprawa ani inne należności przewidziane dla funkcjonariuszy 
odchodzących ze służby. 
5. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
szczegółowy sposób i tryb prowadzenia postępowania w stosunku do funkcjonariuszy, 
o których mowa w ust. 1, uwzględniając szczególne kwalifikacje predestynujące do 
służby w Policji, równorzędność okresów służby i stażu, należności oraz uzyskanych 
w dotychczasowych jednostkach kwalifikacji zawodowych z policyjnymi.

***
## Art. 26. {#policja-art-26}

1. Zdolność fizyczną i psychiczną do służby ustalają komisje lekarskie 
podległe ministrowi właściwemu do spraw wewnętrznych. 
2. (uchylony)

***
## Art. 27. {#policja-art-27}

1. Przed podjęciem służby policjant składa ślubowanie według 
następującej roty: 
„Ja, obywatel Rzeczypospolitej Polskiej, świadom podejmowanych 
obowiązków policjanta, ślubuję: służyć wiernie Narodowi, chronić 
ustanowiony Konstytucją Rzeczypospolitej Polskiej porządek prawny, 
strzec bezpieczeństwa Państwa i jego obywateli, nawet z narażeniem życia. 
Wykonując powierzone mi zadania, ślubuję pilnie przestrzegać prawa, 
dochować wierności konstytucyjnym organom Rzeczypospolitej Polskiej, 
przestrzegać dyscypliny służbowej oraz wykonywać rozkazy i polecenia 
przełożonych. Ślubuję strzec tajemnic związanych ze służbą, honoru, 
godności i dobrego imienia służby oraz przestrzegać zasad etyki 
zawodowej”. 
2. Minister właściwy do spraw wewnętrznych określi, w drodze zarządzenia, 
ceremoniał ślubowania, uwzględniając warunki, tryb i termin składania ślubowania 

 
 
 
s. 118/274 
 
2025-07-03 
 
przez policjantów, organy uprawnione do przyjmowania ślubowania, przebieg i 
sposób dokumentowania ślubowania oraz wzór formularza aktu ślubowania.

***
## Art. 28. {#policja-art-28}

1. Stosunek służbowy policjanta powstaje w drodze mianowania na 
podstawie dobrowolnego zgłoszenia się do służby. 
1a. Mianowanie, o którym mowa w ust. 1, może nastąpić: 
1) 
na okres służby przygotowawczej lub kandydackiej; 
2) 
na okres służby kontraktowej; 
3) 
na stałe. 
1b. (uchylony) 
1c. (uchylony)  
2. Początek służby liczy się od dnia określonego w rozkazie o mianowaniu 
funkcjonariusza Policji. 
3. Mianowanie może nastąpić w stosunku do osób, które posiadają uregulowany 
stosunek do służby wojskowej. 
4. Warunku określonego w ust. 3 nie stosuje się do kobiet i policjantów w służbie 
kandydackiej. 
[5. Minister właściwy do spraw wewnętrznych, w drodze rozporządzenia, określa 
rodzaje i wzory legitymacji służbowych i innych dokumentów policjantów, organy 
właściwe do ich wydawania oraz zasady dokonywania wpisów w tych dokumentach.]

***
## Art. 28a. {#policja-art-28a}

1. Mianowanie na okres służby kontraktowej następuje po zawarciu 
umowy, zwanej dalej „kontraktem”, między kandydatem do służby kontraktowej 
a przełożonym, o którym mowa w art. 32 ust. 1. 
2. Kontrakt zawiera w szczególności: 
1) 
wskazanie przełożonego, o którym mowa w art. 32 ust. 1; 
2) 
imię i nazwisko, numer PESEL i adres zamieszkania kandydata do służby 
kontraktowej; 
3) 
okres, na jaki został zawarty; 
4) 
stanowisko służbowe planowane dla kandydata do służby kontraktowej; 
5) 
planowaną datę ukończenia szkolenia dla policjantów w służbie kontraktowej; 
6) 
warunki uposażenia zasadniczego wraz z dodatkami o charakterze stałym oraz 
innymi należnościami i świadczeniami. 
Przepis 
uchylający ust. 5 
w art. 28 wejdzie 
w życie z dn. 
1.01.2027 r. (Dz. 
U. z 2024 r. poz. 
1562). 

 
 
 
s. 119/274 
 
2025-07-03 
 
3. Mianowanie na okres służby kontraktowej następuje na stanowisko 
w korpusie szeregowych Policji, jeżeli kandydat do służby kontraktowej ma co 
najmniej wykształcenie średnie lub średnie branżowe. 
4. Kandydat do służby kontraktowej nieposiadający wykształcenia średniego lub 
średniego branżowego może być mianowany na stanowisko w korpusie szeregowych 
Policji, jeżeli postępowanie kwalifikacyjne wykaże posiadanie przez niego 
specjalistycznych kwalifikacji, uprawnień lub umiejętności pożądanych ze względu na 
potrzeby kadrowe Policji. 
5. Przyjęcie do służby w Policji na okres służby kontraktowej następuje po 
przeprowadzeniu postępowania kwalifikacyjnego, o którym mowa w art. 25 ust. 2, 
a w przypadku policjanta zwolnionego ze służby w Policji – po przeprowadzeniu 
postępowania kwalifikacyjnego, o którym mowa odpowiednio w art. 25 ust. 13–14. 
6. Do postępowania kwalifikacyjnego, o którym mowa w ust. 5, stosuje się 
odpowiednio art. 25 ust. 3, 4, 7, 17 pkt 6 i 7, ust. 19 i 21–22. 
7. Kontrakt zawiera się na okres od 3 do 5 lat. Zawarcie kontraktu z tą samą 
osobą może nastąpić najwyżej dwukrotnie. 
8. Dla policjanta w służbie kontraktowej pierwsze 12 miesięcy służby w ramach 
pierwszego kontraktu jest okresem próbnym. 
9. Policjant w służbie kontraktowej odbywa szkolenie dla policjantów w służbie 
kontraktowej w zakresie niezbędnym do wykonywania zadań na stanowisku 
w korpusie szeregowych Policji. 
10. Policjanta przyjętego do służby kontraktowej przed upływem 12 miesięcy od 
dnia zakończenia służby kandydackiej nie kieruje się na szkolenie, o którym mowa 
w ust. 9. 
11. Policjanta zwolnionego ze służby w Policji i przyjętego do służby 
kontraktowej nie kieruje się na szkolenie, o którym mowa w ust. 9, jeżeli podczas 
pełnienia służby uzyskał kwalifikacje zawodowe podstawowe. 
12. W przypadku policjanta, o którym mowa w ust. 11, uznaje się kwalifikacje 
zawodowe odpowiednio do stopnia policyjnego uzyskanego podczas służby w Policji. 
13. Do policjanta w służbie kontraktowej nie stosuje się przepisów art. 36 ust. 4–
4b, art. 37, art. 84, art. 86, art. 91, art. 96, art. 104 ust. 2, art. 108 ust. 1 pkt 3, 5a i 5d, 
art. 111, art. 114 ust. 1 pkt 1, art. 115, art. 120a i art. 120d oraz przepisów 
wykonawczych wydanych na ich podstawie. 

 
 
 
s. 120/274 
 
2025-07-03 
 
14. Policjant lub przełożony, o którym mowa w art. 32 ust. 1, mogą złożyć 
oświadczenia na piśmie, najpóźniej na miesiąc przed upływem okresu próbnego, 
o zamiarze rozwiązania stosunku służbowego. W takim przypadku z dniem upływu 
okresu próbnego policjanta zwalnia się ze służby. 
15. W przypadku niezłożenia oświadczeń, o których mowa w ust. 14, policjant 
pełni nadal służbę kontraktową bez odrębnego mianowania. 
16. Najpóźniej na 6 miesięcy przed upływem okresu, na jaki został zawarty 
pierwszy kontrakt, policjant lub przełożony, o którym mowa w art. 32 ust. 1, mogą 
wystąpić z wnioskiem o zawarcie drugiego kontraktu. 
17. Najpóźniej na 6 miesięcy przed upływem okresu, na jaki został zawarty 
kontrakt, policjant posiadający co najmniej wykształcenie średnie lub średnie 
branżowe może wystąpić z wnioskiem o mianowanie na stałe. 
18. Warunkiem mianowania, o którym mowa w ust. 17, jest posiadanie zgody 
przełożonego wymienionego w art. 32 ust. 1 i ukończenie szkolenia zawodowego 
podstawowego, o którym mowa w art. 34c ust. 6, jeżeli policjant wcześniej nie 
uzyskał kwalifikacji zawodowych podstawowych. 
19. W przypadku mianowania na stałe okres służby kontraktowej wlicza się do 
okresu służby przy ustalaniu uprawnień przysługujących policjantowi z tytułu 
pełnienia służby. 
20. Zwolnienie ze służby z przyczyn, o których mowa w art. 41, albo 
mianowanie na stałe powoduje rozwiązanie kontraktu przed upływem okresu, na jaki 
został zawarty. 
<

***
## Art. 28b. {#policja-art-28b}

1. Policjantowi wydaje się, bezpośrednio po mianowaniu, 
legitymację służbową. 
2. Legitymacja służbowa zawiera następujące dane: 
1) 
nazwę jednostki organizacyjnej Policji, w której policjant pełni służbę, 
z tym że w przypadku legitymacji policjantów pełniących służbę w: 
a) 
komisariacie Policji umieszcza się nazwę komendy powiatowej Policji, 
komendy miejskiej Policji lub komendy rejonowej Policji, na której 
obszarze działania znajduje się komisariat Policji, 
b) 
komisariacie specjalistycznym Policji umieszcza się nazwę komendy 
wojewódzkiej (Stołecznej) Policji, na której obszarze działania 
znajduje się komisariat specjalistyczny Policji, 
Dodany art. 28b 
wejdzie w życie z 
dn. 1.01.2027 r. 
(Dz. U. z 2024 r. 
poz. 1562). 
 

 
 
 
s. 121/274 
 
2025-07-03 
 
c) 
ośrodku szkolenia Policji umieszcza się nazwę komendy wojewódzkiej 
(Stołecznej) Policji, na której obszarze działania znajduje się ośrodek 
szkolenia Policji; 
2) 
wizerunek twarzy policjanta; 
3) 
imię, nazwisko, stopień i numer identyfikacyjny policjanta; 
4) 
numer legitymacji służbowej oraz datę jej ważności; 
5) 
nazwę organu, który wydał legitymację służbową. 
3. Policjant jest obowiązany dbać o należyty stan legitymacji służbowej, 
a w szczególności chronić ją przed utratą lub zniszczeniem. 
4. Legitymacja służbowa podlega: 
1) 
zdeponowaniu w przypadku: 
a) 
udzielenia 
urlopu 
bezpłatnego 
w wymiarze 
powyżej 
30 dni 
kalendarzowych, urlopu macierzyńskiego, urlopu na warunkach 
urlopu macierzyńskiego, urlopu rodzicielskiego, urlopu ojcowskiego 
lub urlopu wychowawczego, 
b) 
zawieszenia w czynnościach służbowych; 
2) 
zwrotowi w przypadku: 
a) 
zwolnienia ze służby, 
b) 
upływu terminu jej ważności. 
5. W razie śmierci lub zaginięcia policjanta zwrotu legitymacji służbowej 
dokonuje członek jego rodziny lub przełożony. 
6. Legitymacja służbowa podlega wymianie w przypadku zmiany danych 
w niej zawartych, jej uszkodzenia, zniszczenia lub upływu terminu jej ważności. 
7. Minister 
właściwy 
do 
spraw 
wewnętrznych 
określi, 
w drodze 
rozporządzenia, organy właściwe do wydawania, wymiany, zdeponowania lub 
zwrotu legitymacji służbowej, tryb jej wymiany, zdeponowania lub zwrotu oraz 
wzór legitymacji służbowej, mając na względzie potrzebę jej ochrony oraz 
zapewnienie właściwej identyfikacji policjanta.>

***
## Art. 29. {#policja-art-29}

1. Osobę przyjętą do służby w Policji mianuje się policjantem w służbie 
przygotowawczej na okres 3 lat. 
1a. Policjant ponownie przyjęty do służby, z wyjątkiem policjanta przyjętego do 
służby kontraktowej, jest mianowany na stałe, jeżeli przed zwolnieniem ze służby był 
mianowany na stałe. 

 
 
 
s. 122/274 
 
2025-07-03 
 
2. Po upływie okresu służby przygotowawczej policjant zostaje mianowany na 
stałe. 
3. W szczególnie uzasadnionych przypadkach przełożony, o którym mowa w art. 
32 ust. 1, z wyłączeniem komendanta powiatowego (miejskiego) Policji, może skrócić 
okres służby przygotowawczej policjanta albo zwolnić go od odbywania tej służby. 
4. W razie przerwy w wykonywaniu przez policjanta obowiązków służbowych, 
trwającej dłużej niż 3 miesiące, przełożony może przedłużyć okres jego służby 
przygotowawczej. 
5. Okres służby kontraktowej zalicza się do okresu służby przygotowawczej.

***
## Art. 30. {#policja-art-30}

1. Osobę podlegającą kwalifikacji wojskowej skierowaną za jej zgodą 
do służby w oddziałach prewencji Policji mianuje się policjantem w służbie 
kandydackiej na okres, o którym mowa w art. 561 pkt 2 ustawy z dnia 11 marca 2022 r. 
o obronie Ojczyzny (Dz. U. z 2024 r. poz. 248, z późn. zm.6)). 
2. Policjant w służbie kandydackiej pełni służbę w systemie skoszarowanym. 
2a. Policjant w służbie kandydackiej odbywa szkolenie dla policjantów 
w służbie kandydackiej. 
3. Policjant w służbie kandydackiej po ukończeniu szkolenia, o którym mowa 
w ust. 2a, wykonuje jedynie czynności administracyjno-porządkowe. 
4. Okres służby kandydackiej zalicza się do okresu służby przygotowawczej, 
jeżeli przerwa pomiędzy służbą kandydacką a podjęciem służby przygotowawczej nie 
przekracza 3 miesięcy.

***
## Art. 31. {#policja-art-31}

1. Osobom, które stosownie do przepisów o obronie Ojczyzny odbywają 
ćwiczenia w jednostkach organizacyjnych podległych ministrowi właściwemu do 
spraw wewnętrznych na podstawie przydziałów organizacyjno-mobilizacyjnych, 
przysługują w zakresie przydzielonych im zadań uprawnienia policjantów określone 
w art. 15 i art. 16. 
2. Zakres uprawnień i obowiązków osób, o których mowa w ust. 1, wynikających 
ze stosunku służby określą odrębne przepisy.

***
## Art. 31a. {#policja-art-31a}

1. W razie ogłoszenia mobilizacji i w czasie wojny Policja może być 
objęta militaryzacją, o której mowa w art. 600 ust. 1 ustawy z dnia 11 marca 2022 r. o 
obronie Ojczyzny. 
 
6) Zmiany tekstu jednolitego wymienionej ustawy zostały ogłoszone w Dz. U. z 2024 r. poz. 834, 1089, 
1222, 1248, 1585, 1871 i 1907 oraz z 2025 r. poz. 39. 

 
 
 
s. 123/274 
 
2025-07-03 
 
2. Policjanci pozostający w stosunku służbowym w dniu ogłoszenia mobilizacji 
lub w dniu, w którym rozpoczyna się czas wojny, określonym przez Prezydenta 
Rzeczypospolitej Polskiej na podstawie art. 4a ust. 1 pkt 4a ustawy, o której mowa w 
ust. 1, stają się z mocy prawa policjantami pełniącymi służbę w czasie wojny i 
pozostają w tej służbie do czasu zwolnienia.

***
## Art. 32. {#policja-art-32}

1. Do mianowania policjanta na stanowiska służbowe, przenoszenia 
oraz zwalniania z tych stanowisk właściwi są przełożeni: Komendant Główny Policji, 
Komendant CBŚP, Komendant BSWP, Komendant CBZC, Dyrektor CLKP, 
komendanci wojewódzcy Policji albo Komendant Stołeczny Policji i komendanci 
powiatowi (miejscy, rejonowi) Policji oraz Komendant-Rektor Akademii Policji 
w Szczytnie i komendanci szkół policyjnych. 
2. Od decyzji, o których mowa w ust. 1, policjantowi służy odwołanie do 
wyższego przełożonego. 
3. Jeżeli decyzję, o której mowa w ust. 1, ustawa zastrzega dla Komendanta 
Głównego Policji, od decyzji takiej służy odwołanie do ministra właściwego do spraw 
wewnętrznych.

***
## Art. 33. {#policja-art-33}

1. Czas pełnienia służby policjanta jest określony wymiarem jego 
obowiązków, z uwzględnieniem prawa do wypoczynku. 
2. Zadania służbowe policjanta powinny być ustalone w sposób pozwalający na 
ich wykonanie w ramach 40-godzinnego tygodnia służby, w okresach rozliczeniowych 
od dnia 1 stycznia do dnia 30 czerwca danego roku oraz od dnia 1 lipca do dnia 31 
grudnia danego roku. 
2a. Liczba godzin służby przekraczających normę określoną w ust. 2 nie może 
przekraczać 8 godzin tygodniowo w okresie rozliczeniowym. 
2b. Przepisu ust. 2a nie stosuje się do realizacji zadań o szczególnym charakterze 
dla ochrony bezpieczeństwa ludzi oraz utrzymania bezpieczeństwa i porządku 
publicznego, w szczególności mających na celu zapobieżenie zdarzeniom, o których 
mowa w art. 18 ust. 1. 
3. W zamian za czas służby przekraczający normę określoną w ust. 2 
policjantowi przysługuje w okresie rozliczeniowym czas wolny od służby w tym 
samym wymiarze albo po zakończeniu okresu rozliczeniowego rekompensata 
pieniężna, o ile w terminie 10 dni od zakończenia okresu rozliczeniowego nie wystąpi 
z wnioskiem o udzielenie czasu wolnego od służby w tym samym wymiarze. 

 
 
 
s. 124/274 
 
2025-07-03 
 
3a. Rekompensatę pieniężną, o której mowa w ust. 3, przyznaje się w wysokości 
1/172 części miesięcznego uposażenia zasadniczego wraz z dodatkami o charakterze 
stałym należnego policjantowi na stanowisku zajmowanym w ostatnim dniu okresu 
rozliczeniowego za każdą godzinę służby przekraczającą normę określoną w ust. 2. 
Łączny czas służby przekraczający normę w danym okresie rozliczeniowym zaokrągla 
się w górę do pełnej godziny. 
3b. Przyznanie rekompensaty pieniężnej, o której mowa w ust. 3, może nastąpić 
także na podstawie porozumienia, o którym mowa w art. 13 ust. 4a pkt 1, jeżeli 
przekroczenie normy określonej w ust. 2 nastąpiło w związku z realizacją tego 
porozumienia. Rekompensata pieniężna przysługuje policjantowi za każdą pełną 
godzinę służby przekraczającą normę określoną w ust. 2. 
3c. W razie śmierci lub zaginięcia policjanta należną mu rekompensatę 
pieniężną, o której mowa w ust. 3, wypłaca się małżonkowi policjanta, który 
pozostawał z nim we wspólności małżeńskiej, a w dalszej kolejności jego dzieciom 
oraz rodzicom, jeżeli w dniu śmierci policjanta spełniali warunki do uzyskania renty 
rodzinnej na podstawie przepisów o zaopatrzeniu emerytalnym funkcjonariuszy 
Policji, Agencji Bezpieczeństwa Wewnętrznego, Agencji Wywiadu, Służby 
Kontrwywiadu Wojskowego, Służby Wywiadu Wojskowego, Centralnego Biura 
Antykorupcyjnego, Straży Granicznej, Straży Marszałkowskiej, Służby Ochrony 
Państwa, Państwowej Straży Pożarnej, Służby Celno-Skarbowej i Służby Więziennej 
oraz ich rodzin. 
3d. Rekompensatę pieniężną, o której mowa w ust. 3, wypłaca się: 
1) 
do końca kwartału następującego po okresie rozliczeniowym, o którym mowa w 
art. 33 ust. 2, lecz nie później niż w dniu zwolnienia ze służby; 
2) 
w przypadku śmierci albo zaginięcia policjanta – niezwłocznie po wydaniu 
rozkazu personalnego o wygaśnięciu stosunku służbowego. 
4. Przepisu ust. 3 nie stosuje się do policjanta uprawnionego do dodatku 
funkcyjnego. 
5. Liczba godzin służby przekraczających normę określoną w ust. 2, za którą 
przyznano rekompensatę pieniężną, o której mowa w art. 13 ust. 4a pkt 1, nie może 
przekraczać 1/4 tygodniowego wymiaru czasu służby policjanta w 3-miesięcznym 
okresie rozliczeniowym. 
6. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
podstawowy i zmianowy rozkład czasu służby, dzienny i tygodniowy wymiar czasu 

 
 
 
s. 125/274 
 
2025-07-03 
 
służby, przypadki przedłużenia czasu służby ponad ustaloną normę, sposób 
ewidencjonowania i rozliczania czasu służby, tryb oraz warunki przyznawania i termin 
wypłaty rekompensaty pieniężnej, o której mowa w art. 13 ust. 4a pkt 1, sposób 
pełnienia przez policjantów dyżurów domowych oraz grupy policjantów zwolnionych 
z pełnienia służby w porze nocnej, niedziele i święta, mając na względzie zapewnienie 
całodobowej i sprawnej realizacji zadań przez Policję.

***
## Art. 33a. {#policja-art-33a}

1. W okresie obowiązywania stanu zagrożenia epidemicznego, stanu 
epidemii lub stanu klęski żywiołowej związanej z występowaniem chorób zakaźnych 
u ludzi przełożony, o którym mowa w art. 32 ust. 1, lub osoba przez niego 
upoważniona mogą 
w celu 
przeciwdziałania chorobom 
zakaźnym 
polecić 
policjantowi 
pełnienie 
służby 
poza 
miejscem 
jej stałego 
wykonywania, 
w szczególności z wykorzystaniem środków bezpośredniego porozumiewania się na 
odległość (służba pełniona w formie zdalnej). 
2. Przełożony, o którym mowa w art. 32 ust. 1, lub osoba przez niego 
upoważniona wydają i cofają, w postaci papierowej lub elektronicznej, polecenia 
pełnienia służby w formie zdalnej. 
3. Przełożony, o którym mowa w art. 32 ust. 1, lub osoba przez niego 
upoważniona w poleceniu pełnienia służby w formie zdalnej określają czas i miejsce 
jej pełnienia oraz sposób porozumiewania się policjanta z bezpośrednim przełożonym. 
4. Policjant może pełnić służbę w formie zdalnej, jeżeli ma możliwości 
techniczne oraz lokalowe do jej pełnienia i pozwala na to charakter wykonywanych 
przez niego zadań. 
5. Narzędzia i materiały niezbędne do pełnienia służby w formie zdalnej oraz 
obsługę logistyczną zapewnia przełożony, o którym mowa w art. 32 ust. 1. 
6. W trakcie służby pełnionej w formie zdalnej policjant zapewnia ochronę 
tajemnic związanych ze służbą oraz danych osobowych. 
7. W trakcie pełnienia służby w formie zdalnej policjant może używać narzędzi 
lub materiałów niezapewnionych przez przełożonego, jeżeli: 
1) 
narzędzia i materiały spełniają wymagania, o których mowa w ust. 6; 
2) 
narzędzia spełniają wymagania określone w rozdziale IV działu dziesiątego 
ustawy z dnia 26 czerwca 1974 r. – Kodeks pracy (Dz. U. z 2025 r. poz. 277), 
zwanej dalej „Kodeksem pracy”. 

 
 
 
s. 126/274 
 
2025-07-03 
 
8. Na polecenie przełożonego, o którym mowa w art. 32 ust. 1, lub osoby przez 
niego upoważnionej policjant pełniący służbę w formie zdalnej ma obowiązek 
prowadzić ewidencję wykonanych czynności, uwzględniającą w szczególności opis 
tych czynności, a także datę ich wykonania. Ewidencję wykonanych czynności 
policjant sporządza w formie i z częstotliwością określonymi w poleceniu. 
9. Policjant ma obowiązek na polecenie bezpośredniego przełożonego stawić się 
w miejscu stałego wykonywania służby. 
10. Przełożony, o którym mowa w art. 32 ust. 1, lub osoba przez niego 
upoważniona mogą w każdym czasie cofnąć polecenie pełnienia służby w formie 
zdalnej.

***
## Art. 33b. {#policja-art-33b}

1. Przełożony, o którym mowa w art. 32 ust. 1, realizuje w stosunku 
do policjanta pełniącego służbę w formie zdalnej obowiązki określone w art. 71a–71d 
w czasie pełnienia przez niego służby w formie zdalnej, z wyłączeniem obowiązków 
określonych w art. 208 § 1, art. 2091–2093, art. 210 § 1–5, art. 212 pkt 1 i 4, art. 213, 
art. 214 i art. 233 oraz przepisów wykonawczych wydanych na podstawie 
art. 210 § 6 Kodeksu pracy. 
2. Przełożony, o którym mowa w art. 32 ust. 1, lub osoba przez niego 
upoważniona przed rozpoczęciem przez policjanta służby pełnionej w formie zdalnej 
przekazują policjantowi pełniącemu służbę w formie zdalnej informacje dotyczące: 
1) 
zasad: 
a) 
oraz sposobu właściwej organizacji stanowiska służby pełnionej w formie 
zdalnej, z uwzględnieniem wymagań ergonomii, 
b) 
bezpiecznego i higienicznego wykonywania służby pełnionej w formie 
zdalnej, 
c) 
postępowania w sytuacjach awaryjnych stwarzających zagrożenie dla życia 
lub zdrowia; 
2) 
czynności do wykonania po zakończeniu wykonywania służby pełnionej 
w formie zdalnej. 
3. Przed dopuszczeniem do wykonywania służby pełnionej w formie zdalnej 
policjant w oświadczeniu składanym w postaci papierowej lub elektronicznej: 
1) 
potwierdza: 
a) 
zapoznanie się z informacjami, o których mowa w ust. 2, 

 
 
 
s. 127/274 
 
2025-07-03 
 
b) 
że na stanowisku służby pełnionej w formie zdalnej w miejscu wskazanym 
w poleceniu, o którym mowa w art. 33a ust. 3, są zapewnione bezpieczne 
i higieniczne warunki tej służby; 
2) 
zobowiązuje się do przestrzegania zasad, o których mowa w ust. 2 pkt 1, oraz do 
wykonywania czynności, o których mowa w ust. 2 pkt 2. 
4. Policjant organizuje stanowisko służby pełnionej w formie zdalnej, 
uwzględniając wymagania ergonomii. 
5. Przełożony, o którym mowa w art. 32 ust. 1, lub osoba przez niego 
upoważniona mają prawo przeprowadzać kontrolę warunków bezpieczeństwa 
i higieny służby pełnionej w formie zdalnej przez policjanta w miejscu i w godzinach 
pełnienia tej służby. 
6. Przełożony, o którym mowa w art. 32 ust. 1, lub osoba przez niego 
upoważniona dostosowują sposób przeprowadzania kontroli, o której mowa w ust. 5, 
do miejsca wykonywania i charakteru służby pełnionej w formie zdalnej. 
Wykonywanie czynności kontrolnych nie może naruszać prywatności policjanta 
pełniącego służbę w formie zdalnej i innych osób ani utrudniać korzystania 
z pomieszczeń domowych w sposób zgodny z ich przeznaczeniem. 
7. W razie zaistnienia wypadku pozostającego w związku z pełnieniem służby 
w formie zdalnej stosuje się przepisy ustawy z dnia 4 kwietnia 2014 r. 
o świadczeniach odszkodowawczych przysługujących w razie wypadku lub choroby 
pozostających w związku ze służbą (Dz. U. z 2023 r. poz. 2015). 
8. Zgłoszenie 
bezpośredniemu 
przełożonemu 
wypadku 
pozostającego 
w związku z pełnieniem służby w formie zdalnej jest równoznaczne z wyrażeniem 
przez policjanta zgody na przeprowadzenie oględzin miejsca wypadku, narzędzi, 
oceny ich stanu technicznego oraz zbadania warunków pełnienia tej służby i innych 
okoliczności, które mogły mieć wpływ na powstanie wypadku lub mają z nim 
związek. Oględzin dokonuje się niezwłocznie po zgłoszeniu wypadku pozostającego 
w związku z pełnieniem służby w formie zdalnej, w terminie uzgodnionym przez 
policjanta albo jego domownika, w przypadku gdy policjant ze względu na stan 
zdrowia nie jest w stanie uzgodnić tego terminu, i przewodniczącego komisji 
powypadkowej. Komisja powypadkowa może odstąpić od dokonywania oględzin, 
jeżeli uzna, że okoliczności i przyczyny wypadku nie budzą jej wątpliwości. 

 
 
 
s. 128/274 
 
2025-07-03

***
## Art. 34. {#policja-art-34}

1. Mianowanie lub powołanie na stanowisko służbowe jest uzależnione 
od posiadanego przez policjanta wykształcenia, uzyskania określonych kwalifikacji 
zawodowych, a także stażu służby w Policji. 
2. Ustala się następujące kwalifikacje zawodowe: 
1) 
podstawowe; 
2) 
podoficerskie; 
3) 
aspiranckie; 
4) 
oficerskie. 
3. Policjant może być mianowany albo powołany na wyższe stanowisko 
służbowe, jeżeli spełnia łącznie następujące warunki: 
1) 
posiada wykształcenie, kwalifikacje zawodowe i staż służby wymagane na tym 
stanowisku; 
2) 
posiada pozytywną opinię służbową; 
3) 
w przypadku poddania go procedurze, o której mowa w art. 35a ust. 1, uzyskał 
pozytywny wynik testu lub badania przeprowadzonego w ramach tej procedury. 
4. Na wyższe stanowisko służbowe nie może być mianowany ani powołany 
policjant: 
1) 
który podczas ostatniego opiniowania służbowego otrzymał jedną z opinii 
służbowych, o których mowa w art. 38 ust. 2 pkt 2 albo 3 albo art. 41 ust. 1 pkt 
2 albo ust. 2 pkt 1 – przez okres jednego roku od dnia wydania ostatecznej opinii; 
2) 
przeciwko któremu wszczęto postępowanie karne w sprawie o przestępstwo 
umyślne ścigane z oskarżenia publicznego lub umyślne przestępstwo skarbowe 
lub postępowanie dyscyplinarne – do czasu prawomocnego zakończenia tego 
postępowania; 
3) 
ukarany karą dyscyplinarną – do czasu jej zatarcia; 
4) 
skazany za przestępstwo wyrokiem sądu – przez rok od dnia uprawomocnienia 
się orzeczenia, chyba że interes służby nie sprzeciwia się mianowaniu albo 
powołaniu na wyższe stanowisko służbowe pomimo skazania lub od popełnienia 
czynu, za który został skazany, upłynęło więcej niż 2 lata. 
5. Policjant, który ukończył w Akademii Policji w Szczytnie studia pierwszego 
stopnia o profilu praktycznym na kierunku nauka o Policji, w terminie miesiąca od 
dnia ukończenia tych studiów jest mianowany na stanowisko służbowe, dla którego 
określono policyjny stopień etatowy w korpusie oficerów młodszych Policji, jeżeli 
spełnia warunki, o których mowa w ust. 3. Przepis ust. 4 stosuje się. 

 
 
 
s. 129/274 
 
2025-07-03 
 
6. Do stażu służby, o którym mowa w ust. 3 pkt 1, nie wlicza się okresu 
zawieszenia w czynnościach służbowych oraz okresu tymczasowego aresztowania, 
jeżeli policjant został skazany prawomocnym wyrokiem za przestępstwo ścigane 
z oskarżenia publicznego lub przestępstwo skarbowe lub w prawomocnie 
zakończonym postępowaniu dyscyplinarnym został ukarany karą dyscyplinarną albo 
odstąpiono od jego ukarania, a także okresu urlopu wychowawczego oraz urlopu 
bezpłatnego. 
7. W szczególnie uzasadnionych przypadkach Komendant Główny Policji, 
Komendant CBŚP, Komendant BSWP, Komendant CBZC albo Dyrektor CLKP może 
wyrazić zgodę na mianowanie na stanowisko służbowe policjanta, także w służbie 
przygotowawczej, przed uzyskaniem przez niego kwalifikacji zawodowych oraz stażu 
służby wymaganych na tym stanowisku, przy spełnieniu wymagań w zakresie 
wykształcenia. Kwalifikacje zawodowe policjant jest obowiązany uzyskać przed 
mianowaniem na stałe. 
8. Warunkiem uzyskania przez policjanta kwalifikacji zawodowych niezbędnych 
do mianowania go lub powołania go na stanowisko służbowe jest ukończenie przez 
niego: 
1) 
szkolenia zawodowego: 
a) 
podstawowego – w przypadku kwalifikacji, o których mowa w ust. 2 pkt 1, 
b) 
podoficerskiego 
– 
w przypadku 
kwalifikacji, 
o których 
mowa 
w ust. 2 pkt 2, 
c) 
aspiranckiego – w przypadku kwalifikacji, o których mowa w ust. 2 pkt 3, 
d) 
oficerskiego – w przypadku kwalifikacji, o których mowa w ust. 2 pkt 4 
– i zdanie egzaminu końcowego; 
2) 
studiów w Akademii Policji w Szczytnie – w przypadku kwalifikacji, o których 
mowa w ust. 2 pkt 4, i zdanie egzaminu końcowego z zakresu szkolenia, 
o którym mowa w pkt 1 lit. d. 
9. Za równoznaczne ze spełnieniem warunków określonych w ust. 8 pkt 1: 
1) 
lit. a – uważa się zaliczenie w Akademii Policji w Szczytnie pierwszego roku 
studiów pierwszego stopnia o profilu praktycznym na kierunku nauka o Policji; 
2) 
lit. b – uważa się zaliczenie w Akademii Policji w Szczytnie drugiego roku 
studiów pierwszego stopnia o profilu praktycznym na kierunku nauka o Policji 
albo zdanie egzaminu końcowego z zakresu szkolenia, o którym mowa w ust. 8 
pkt 1 lit. b; 

 
 
 
s. 130/274 
 
2025-07-03 
 
3) 
lit. c – uważa się zaliczenie w Akademii Policji w Szczytnie trzeciego roku 
studiów pierwszego stopnia o profilu praktycznym na kierunku nauka o Policji 
albo zdanie egzaminu końcowego z zakresu szkolenia, o którym mowa w ust. 8 
pkt 1 lit. c; 
4) 
lit. d – uważa się zdanie egzaminu końcowego z zakresu szkolenia, o którym 
mowa w ust. 8 pkt 1 lit. d. 
10. Policjanta można skierować na egzamin końcowy z zakresu odpowiedniego 
szkolenia, o którym mowa w ust. 8 pkt 1 lit. b–d, bez konieczności odbywania tego 
szkolenia, jeżeli spełnia łącznie następujące warunki: 
1) 
ma zapewnione stanowisko służbowe, na którym są wymagane kwalifikacje 
zawodowe, o których mowa w ust. 2, lub pełni służbę na stanowisku służbowym, 
dla którego określono policyjny stopień etatowy w korpusie odpowiednio 
podoficerów, aspirantów i oficerów Policji; 
2) 
spełnia warunki, o których mowa w ust. 3 pkt 1 i 2, oraz nie zachodzą 
okoliczności, o których mowa w ust. 4. 
11. Warunkiem skierowania, o którym mowa w ust. 10, jest dla egzaminu 
końcowego z zakresu szkolenia, o którym mowa w ust. 8 pkt 1: 
1) 
lit. b – ukończenie szkolenia zawodowego podstawowego z wyróżnieniem; 
2) 
lit. c – posiadanie wykształcenia wyższego oraz ukończenie szkolenia 
zawodowego podoficerskiego z wyróżnieniem albo zdanie egzaminu końcowego 
z zakresu tego szkolenia z wyróżnieniem; 
3) 
lit. d – złożenie przez policjanta pisemnego raportu w sprawie skierowania go na 
ten egzamin oraz: 
a) 
ukończenie studiów drugiego stopnia lub jednolitych studiów magisterskich 
oraz ukończenie szkolenia zawodowego aspiranckiego z wyróżnieniem albo 
zdanie egzaminu końcowego z zakresu tego szkolenia z wyróżnieniem lub 
b) 
ukończenie studiów w Akademii Policji w Szczytnie. 
11a. Policjanta dopuszcza się do egzaminu końcowego po uzyskaniu zaliczeń 
oraz zdaniu egzaminów przewidzianych w programie szkolenia. 
11b. Policjantowi wystawia się ocenę negatywną z zaliczenia, egzaminu lub 
egzaminu końcowego, jeżeli w czasie ich przeprowadzania: 
1) 
korzysta z pomocy innych osób lub 
2) 
posługuje się niedozwolonymi urządzeniami, materiałami lub środkami, lub 
3) 
w inny sposób zakłóca ich przebieg. 

 
 
 
s. 131/274 
 
2025-07-03 
 
11c. Policjant, któremu wystawiono ocenę negatywną z zaliczenia, egzaminu lub 
egzaminu końcowego, zachowuje prawo odpowiednio do zaliczenia poprawkowego, 
egzaminu poprawkowego lub egzaminu końcowego poprawkowego, a jeżeli 
wystawienie oceny negatywnej nastąpiło podczas zaliczenia poprawkowego, 
egzaminu poprawkowego lub egzaminu końcowego poprawkowego – do zaliczenia 
komisyjnego, egzaminu komisyjnego lub egzaminu końcowego komisyjnego. 
11d. Egzamin końcowy przeprowadza komisja egzaminacyjna powołana przez 
Komendanta-Rektora Akademii Policji w Szczytnie, komendanta szkoły policyjnej 
albo kierownika ośrodka szkolenia. 
12. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
wymagania w zakresie wykształcenia, kwalifikacji zawodowych i stażu służby, jakim 
odpowiadają policjanci na stanowiskach komendantów Policji i innych stanowiskach 
służbowych, mając na uwadze zakres wykonywanych przez nich zadań.

***
## Art. 34a. {#policja-art-34a}

1. Policjanta można skierować na przeszkolenie, do szkoły, na studia 
wyższe lub podyplomowe w kraju albo za granicą lub na aplikację w zawodach 
prawniczych, które są realizowane poza jednostkami szkoleniowymi Policji. 
2. Z policjantem w służbie stałej, którego zamierza się skierować na koszt Policji 
na przeszkolenie, do szkoły, na studia wyższe lub podyplomowe w kraju albo za 
granicą lub na aplikację w zawodach prawniczych, które są realizowane poza 
jednostkami szkoleniowymi Policji, zawiera się umowę, jeżeli koszt ten w dniu 
skierowania 
przekracza 
kwotę 
sześciokrotności 
wysokości 
minimalnego 
wynagrodzenia za pracę ustalanego w danym roku na podstawie ustawy z dnia 10 
października 2002 r. o minimalnym wynagrodzeniu za pracę (Dz. U. z 2024 r. poz. 
1773). 
3. Policjant, który został zwolniony ze służby przed upływem 5 lat od dnia 
ukończenia nauki lub szkoleń wymienionych w ust. 2, których koszty zostały pokryte 
z budżetu Policji, jest obowiązany do zwrotu tych kosztów. 
4. Umowa, o której mowa w ust. 2, określa wzajemne prawa i obowiązki stron 
związane ze skierowaniem, w szczególności warunki zwrotu kosztów poniesionych na 
naukę i utrzymanie policjanta, w przypadku: 
1) 
nieukończenia przez niego przeszkolenia, szkoły, studiów wyższych lub 
podyplomowych w kraju albo za granicą lub aplikacji w zawodach prawniczych 

 
 
 
s. 132/274 
 
2025-07-03 
 
w wyniku uzyskania negatywnej oceny końcowej albo przerwania nauki z winy 
policjanta; 
2) 
zwolnienia ze służby w okresie, o którym mowa w ust. 3, z przyczyn określonych 
w art. 41 ust. 1 pkt 3–5, ust. 2 pkt 1, 2, 5, 7–9 oraz ust. 3. 
5. Zwrot poniesionych kosztów następuje w wysokości: 
1) 
kosztów poniesionych przez Policję – w przypadkach, o których mowa w ust. 4 
pkt 1 oraz art. 41 ust. 1 pkt 3–5 i ust. 2 pkt 2 i 8; 
2) 
proporcjonalnej do pozostałego, wynikającego z umowy, okresu służby pełnionej 
po zakończeniu nauki – w pozostałych przypadkach. 
6. Zwrot kosztów, o którym mowa w ust. 3, nie obejmuje uposażenia policjanta. 
7. Komendant Główny Policji może zwolnić policjanta z obowiązku zwrotu 
kosztów, o których mowa w ust. 3, w całości albo w części na pisemny wniosek 
policjanta uzasadniony jego szczególną sytuacją życiową, rodzinną lub materialną.

***
## Art. 34b. {#policja-art-34b}

Na szkolenie, o którym mowa w art. 34 ust. 8 pkt 1, policjanta kieruje 
przełożony za pośrednictwem komórki organizacyjnej Policji właściwej w sprawach 
szkolenia Komendy Głównej Policji, CBŚP, BSWP, CBZC, CLKP, komendy 
wojewódzkiej Policji, Komendy Stołecznej Policji, Akademii Policji w Szczytnie albo 
szkoły policyjnej.

***
## Art. 34c. {#policja-art-34c}

1. Policjanta po przyjęciu do służby, z wyjątkiem policjanta przyjętego 
do służby kontraktowej lub służby kandydackiej, kieruje się na szkolenie zawodowe 
podstawowe. 
2. Policjanta ponownie przyjętego do służby nie kieruje się na szkolenie 
zawodowe podstawowe, jeżeli podczas pełnienia służby uzyskał kwalifikacje 
zawodowe podstawowe. 
3. W stosunku do policjanta przyjętego do służby w Policji przed upływem 
12 miesięcy od dnia zakończenia służby kandydackiej można prowadzić szkolenie 
zawodowe 
podstawowe 
w zakresie 
niezbędnym 
do 
uzupełnienia 
wiedzy 
i umiejętności zdobytych w związku z pełnieniem służby kandydackiej. 
4. W stosunku do policjanta – absolwenta studiów, w ramach których, na 
podstawie porozumienia zawartego przez uczelnię z Komendantem Głównym Policji, 
zrealizowano określony przez Komendanta Głównego Policji minimalny zakres treści 
kształcenia, przyjętego do służby w Policji przed upływem 12 miesięcy od dnia 
ukończenia tych studiów można prowadzić szkolenie zawodowe podstawowe 

 
 
 
s. 133/274 
 
2025-07-03 
 
w zakresie uzupełniającym różnice programowe między zrealizowanym minimalnym 
zakresem treści kształcenia a szkoleniem zawodowym podstawowym. 
5. Policjanta będącego absolwentem oddziału o profilu mundurowym, o którym 
mowa w art. 28aa ust. 1 ustawy z dnia 14 grudnia 2016 r. – Prawo oświatowe, można 
skierować na szkolenie zawodowe podstawowe w zakresie uzupełniającym różnice 
programowe między zrealizowanym programem szkolenia w oddziale o profilu 
mundurowym a programem szkolenia zawodowego podstawowego. 
6. Policjanta w służbie kontraktowej przed mianowaniem na stałe kieruje się na 
szkolenie zawodowe podstawowe, uzupełniające wiedzę i umiejętności zdobyte 
w związku z pełnieniem służby kontraktowej, jeżeli wcześniej nie uzyskał kwalifikacji 
zawodowych podstawowych. 
7. Policjanta, który był zatrudniony w jednostkach organizacyjnych Policji przez 
co najmniej 5 lat w pełnym wymiarze czasu pracy, przyjętego do służby w Policji 
przed upływem 12 miesięcy od dnia zakończenia tego zatrudnienia można skierować 
na szkolenie zawodowe podstawowe w zakresie niezbędnym do uzupełnienia wiedzy 
i umiejętności zdobytych w okresie zatrudnienia w Policji.

***
## Art. 34d. {#policja-art-34d}

1. Na szkolenie zawodowe podoficerskie lub szkolenie zawodowe 
aspiranckie policjanta można skierować, jeżeli spełnia łącznie następujące warunki: 
1) 
ma zapewnione stanowisko służbowe, na którym są wymagane kwalifikacje 
zawodowe podoficerskie lub aspiranckie, lub pełni służbę na stanowisku 
służbowym, dla którego określono policyjny stopień etatowy w korpusie 
odpowiednio podoficerów albo aspirantów Policji; 
2) 
posiada staż służby wymagany do mianowania lub powołania na stanowisko 
służbowe; 
3) 
posiada pozytywną opinię służbową. 
2. Warunku wymienionego w ust. 1 pkt 2 nie stosuje się do policjanta, o którym 
mowa w art. 34 ust. 7. 
3. Na szkolenie zawodowe aspiranckie można skierować policjanta, który 
uzyskał kwalifikacje zawodowe, o których mowa w art. 34 ust. 2 pkt 2. 
4. Policjanta, który posiada specjalistyczne kwalifikacje, wykształcenie, 
uprawnienia lub umiejętności pożądane ze względu na potrzeby kadrowe Policji, 
można skierować na szkolenie zawodowe aspiranckie z wyłączeniem wymogu, 
o którym mowa w ust. 3. 

 
 
 
s. 134/274 
 
2025-07-03

***
## Art. 34e. {#policja-art-34e}

1. Na szkolenie zawodowe oficerskie policjanta można skierować, 
jeżeli spełnia łącznie następujące warunki: 
1) 
ukończył studia drugiego stopnia lub jednolite studia magisterskie; 
2) 
złożył pisemny raport w sprawie skierowania go na to szkolenie; 
3) 
ma zapewnione, bezpośrednio po ukończeniu szkolenia, stanowisko służbowe, 
na którym są wymagane kwalifikacje zawodowe oficerskie, lub pełni służbę na 
stanowisku służbowym, dla którego określono policyjny stopień etatowy 
w korpusie oficerów Policji; 
4) 
posiada staż służby wymagany do mianowania lub powołania na stanowisko 
służbowe; 
5) 
posiada pozytywną opinię służbową. 
2. Warunku wymienionego w ust. 1 pkt 4 nie stosuje się do policjanta, o którym 
mowa w art. 34 ust. 7 i art. 56 ust. 1. 
3. Na szkolenie zawodowe oficerskie można skierować policjanta, który uzyskał 
kwalifikacje zawodowe, o których mowa w art. 34 ust. 2 pkt 3. 
4. Policjanta, który posiada specjalistyczne kwalifikacje, wykształcenie, 
uprawnienia lub umiejętności pożądane ze względu na potrzeby kadrowe Policji, 
można skierować na szkolenie zawodowe oficerskie z wyłączeniem wymogu, 
o którym mowa w ust. 3.

***
## Art. 34f. {#policja-art-34f}

1. Policjanta 
usuwa 
się 
ze 
szkolenia, 
o którym 
mowa 
w art. 34 ust. 8 pkt 1, jeżeli: 
1) 
złożył pisemny raport o usunięcie ze szkolenia; 
2) 
zgłosił na piśmie wystąpienie ze służby w Policji; 
3) 
przełożony, o którym mowa w art. 32 ust. 1, wystąpił o jego usunięcie ze 
szkolenia; 
4) 
przełożony, o którym mowa w art. 39a ust. 1 i 2, zawiesił go w czynnościach 
służbowych; 
5) 
w szkoleniu nastąpiła przerwa spowodowana jego długotrwałą chorobą lub 
szczególnymi przyczynami losowymi; 
6) 
bez usprawiedliwienia przerwał udział w szkoleniu; 
7) 
bez usprawiedliwienia nie przystąpił w wyznaczonym terminie do zaliczeń lub 
egzaminów przewidzianych programem szkolenia lub do egzaminu końcowego; 

 
 
 
s. 135/274 
 
2025-07-03 
 
8) 
nie uzyskał zaliczenia lub nie zdał egzaminu przewidzianego w programie 
szkolenia lub egzaminu końcowego; 
9) 
popełnił czyn o znamionach wykroczenia albo przewinienia dyscyplinarnego, 
jeżeli popełnienie czynu jest oczywiste i uniemożliwia jego udział w szkoleniu; 
10) popełnił czyn o znamionach przestępstwa umyślnego ściganego z oskarżenia 
publicznego, jeżeli popełnienie czynu jest oczywiste; 
11) z innych ważnych przyczyn nie jest możliwy jego udział w szkoleniu. 
2. Policjanta skreśla się ze szkolenia w przypadku jego śmierci lub uznania za 
zaginionego.

***
## Art. 34g. {#policja-art-34g}

1. Policjant 
usunięty 
ze 
szkolenia, 
o którym 
mowa 
w art. 34 ust. 8 pkt 1, w przypadkach wskazanych w art. 34f ust. 1 pkt 1–5 i 11 może 
dokończyć przerwane szkolenie, jeżeli przed upływem 12 miesięcy od dnia usunięcia 
ze szkolenia ustanie przyczyna, z powodu której został usunięty, oraz zgłosi 
przełożonemu właściwemu do spraw osobowych gotowość do dokończenia szkolenia. 
2. Policjanta, o którym mowa w ust. 1, można ponownie skierować na szkolenie, 
jeżeli po upływie 12 miesięcy od dnia usunięcia ze szkolenia ustanie przyczyna, 
z powodu której został usunięty. 
3. Policjanta, 
który 
został 
usunięty 
ze 
szkolenia, 
o którym 
mowa 
w art. 34 ust. 8 pkt 1 lit. b–d, w przypadkach wskazanych w art. 34f ust. 1 pkt 6–
8 można ponownie skierować na szkolenie nie wcześniej niż po upływie 12 miesięcy 
od dnia jego usunięcia. 
4. Policjanta, 
który 
został 
usunięty 
ze 
szkolenia, 
o którym 
mowa 
w art. 34 ust. 8 pkt 1 lit. a, w przypadkach wskazanych w art. 34f ust. 1 pkt 6–
8 można ponownie skierować na szkolenie bez zachowania terminu wskazanego 
w ust. 3. 
5. Policjanta, 
który 
został 
usunięty 
ze 
szkolenia, 
o którym 
mowa 
w art. 34 ust. 8 pkt 1, w przypadkach wskazanych w art. 34f ust. 1 pkt 9 i 10 można 
ponownie skierować na szkolenie nie wcześniej niż po upływie 12 miesięcy od dnia 
jego usunięcia. 
6. Przepisów ust. 3 i 5 nie stosuje się do policjanta przywróconego do służby 
w Policji.

***
## Art. 34h. {#policja-art-34h}

1. Policjant może zostać skierowany na doskonalenie zawodowe w celu 
pogłębiania wiedzy i umiejętności zawodowych wymaganych przy wykonywaniu 

 
 
 
s. 136/274 
 
2025-07-03 
 
przez niego zadań i czynności służbowych, a także uzyskania przez niego 
dodatkowych uprawnień, w tym uprawnień instruktorskich. 
2. Doskonalenie zawodowe policjantów organizowane jest jako doskonalenie 
zawodowe: 
1) 
centralne – przez Akademię Policji w Szczytnie, szkoły policyjne lub ośrodki 
szkolenia; 
2) 
lokalne – przez jednostki organizacyjne Policji lub komórki organizacyjne tych 
jednostek; 
3) 
zewnętrzne – przez podmioty pozapolicyjne. 
3. Za zgodą Komendanta Głównego Policji doskonalenie zawodowe centralne 
mogą organizować CBŚP, BSWP, BOA, CBZC, CLKP oraz komendy wojewódzkie 
Policji i Komenda Stołeczna Policji. 
4. Do doskonalenia zawodowego, o którym mowa w ust. 2 pkt 1 i ust. 3, stosuje 
się odpowiednio przepisy art. 34 ust. 11b–11d, art. 34b, art. 34f i art. 34g ust. 1–3, 5 
i 6. 
5. Komendant Główny Policji, właściwy dla ośrodka szkolenia komendant 
wojewódzki Policji albo Komendant Stołeczny Policji, Komendant-Rektor Akademii 
Policji w Szczytnie lub komendant szkoły policyjnej, każdy w zakresie swojej 
właściwości, określają programy doskonalenia zawodowego centralnego.

***
## Art. 34i. {#policja-art-34i}

W przypadku wystąpienia sytuacji szczególnych wymagających 
ochrony bezpieczeństwa policjantów, w tym w przypadku ogłoszenia stanu 
zagrożenia epidemicznego, stanu epidemii lub wprowadzenia stanu klęski 
żywiołowej, Komendant Główny Policji, na czas wynikający z określonej potrzeby, 
może wprowadzić organizację szkolenia, o którym mowa w art. 34 ust. 8 pkt 1, oraz 
organizację doskonalenia zawodowego, o którym mowa w art. 34h ust. 2 pkt 1 i 2 oraz 
ust. 3, w systemie skoszarowanym.

***
## Art. 34j. {#policja-art-34j}

1. Policjant, 
który 
ukończył 
szkolenie, 
o którym 
mowa 
w art. 34 ust. 8 pkt 1, otrzymuje świadectwo ukończenia szkolenia lub świadectwo 
ukończenia szkolenia z wyróżnieniem. 
2. W przypadku, o którym mowa w art. 34 ust. 10, policjant otrzymuje 
świadectwo zdania egzaminu końcowego lub świadectwo zdania egzaminu 
końcowego z wyróżnieniem. 

 
 
 
s. 137/274 
 
2025-07-03 
 
3. Policjant, który ukończył szkolenie, o którym mowa w art. 30 ust. 2a, 
otrzymuje świadectwo ukończenia szkolenia dla policjantów w służbie kandydackiej. 
3a. Policjant, który ukończył szkolenie, o którym mowa w art. 28a ust. 9, 
otrzymuje świadectwo ukończenia szkolenia dla policjantów w służbie kontraktowej. 
4. Policjant, który ukończył doskonalenie zawodowe, o którym mowa w art. 34h 
ust. 2 pkt 1 i ust. 3, otrzymuje świadectwo ukończenia doskonalenia zawodowego 
centralnego.

***
## Art. 34k. {#policja-art-34k}

Minister właściwy do spraw wewnętrznych określi, w drodze 
rozporządzenia: 
1) 
formy, tryb, organizację, sposób odbywania i dokumentowania szkoleń, 
o których mowa w art. 34 ust. 8 pkt 1, 
2) 
sposób 
oceniania 
policjanta 
w trakcie 
szkoleń, 
o których 
mowa 
w art. 34 ust. 8 pkt 1, oraz zakres, tryb, formy i terminy składania egzaminów 
końcowych z tych szkoleń, 
3) 
sposób oceniania policjanta w trakcie egzaminów końcowych, o których mowa 
w art. 34 ust. 10, oraz zakres, tryb, formy i terminy składania tych egzaminów, 
4) 
sposób powoływania komisji egzaminacyjnej, 
5) 
sposób 
dokumentowania 
szkoleń, 
o których 
mowa 
w art. 28a 
ust. 9 
i art. 30 ust. 2a, oraz jednostki organizacyjne Policji właściwe do ich 
organizowania, 
6) 
formy, organizację, sposób odbywania i dokumentowania doskonalenia 
zawodowego oraz sposób oceniania policjanta w trakcie jego trwania, 
7) 
sposób sprawowania nadzoru nad realizacją szkoleń, o których mowa w art. 28a 
ust. 9, art. 30 ust. 2a i art. 34 ust. 8 pkt 1, oraz doskonalenia zawodowego, 
8) 
wzory świadectwa ukończenia szkolenia zawodowego, świadectwa ukończenia 
szkolenia zawodowego z wyróżnieniem, 
świadectwa zdania 
egzaminu 
końcowego, świadectwa zdania egzaminu końcowego z wyróżnieniem, 
świadectwa ukończenia szkolenia dla policjantów w służbie kandydackiej, 
świadectwa ukończenia szkolenia dla policjantów w służbie kontraktowej oraz 
świadectwa ukończenia doskonalenia zawodowego centralnego 
– mając na uwadze zapewnienie właściwego przygotowania policjantów do 
wykonywania zadań służbowych oraz konieczność zapewnienia właściwej realizacji 
oraz prawidłowego dokumentowania szkoleń, o których mowa w art. 28a ust. 9, 

 
 
 
s. 138/274 
 
2025-07-03 
 
art. 30 ust. 2a oraz art. 34 ust. 8 pkt 1, i doskonalenia zawodowego oraz przebiegu 
egzaminów końcowych.

***
## Art. 35. {#policja-art-35}

1. Policjant podlega okresowemu opiniowaniu służbowemu. 
2. Policjant zapoznaje się z opinią służbową w ciągu 14 dni od jej sporządzenia; 
może on w terminie 14 dni od zapoznania się z opinią wnieść odwołanie do wyższego 
przełożonego. 
3. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
wzór formularza opinii służbowej, szczegółowe zasady i tryb opiniowania 
funkcjonariuszy, uwzględniając przesłanki opiniowania i jego częstotliwości, kryteria 
brane pod uwagę przy opiniowaniu, właściwość przełożonych w zakresie wydawania 
opinii, tryb zapoznawania funkcjonariuszy z opinią służbową oraz tryb wnoszenia i 
rozpatrywania odwołań od opinii.

***
## Art. 35a. {#policja-art-35a}

1. Policjant może zostać poddany procedurze określającej jego 
predyspozycje do służby na określonych stanowiskach lub w określonych komórkach 
organizacyjnych, poprzez przeprowadzenie testu sprawności fizycznej, badania 
psychologicznego lub badania psychofizjologicznego. 
2. Test lub badania są przeprowadzane przez uprawnioną komórkę organizacyjną 
Policji. 
3. W stosunku do policjantów pełniących służbę lub ubiegających się o podjęcie 
służby w Komendzie Głównej Policji test i badania zarządza Komendant Główny 
Policji. 
3a. W stosunku do policjantów pełniących służbę lub ubiegających się o podjęcie 
służby w CBŚP test i badania zarządza Komendant CBŚP. 
3b. W stosunku do policjantów pełniących służbę lub ubiegających się o podjęcie 
służby w BSWP test i badania zarządza Komendant BSWP. 
3c. W stosunku do policjantów pełniących służbę lub ubiegających się o podjęcie 
służby w BOA test i badania zarządza Komendant Główny Policji. 
3d. W stosunku do policjantów pełniących służbę lub ubiegających się o podjęcie 
służby w samodzielnym pododdziale kontrterrorystycznym Policji test i badania 
zarządza właściwy miejscowo komendant wojewódzki lub Komendant Stołeczny 
Policji. 
3e. W stosunku do policjantów pełniących służbę lub ubiegających się o podjęcie 
służby w CBZC badania zarządza Komendant CBZC. 

 
 
 
s. 139/274 
 
2025-07-03 
 
3f. W stosunku do policjantów CLKP lub ubiegających się o podjęcie służby w 
CLKP test i badania zarządza Dyrektor CLKP. 
4. W stosunku do policjantów pełniących służbę na obszarze terytorialnego 
działania komendanta wojewódzkiego, z zastrzeżeniem art. 6 ust. 3 i 4, test i badania 
zarządza komendant wojewódzki Policji. 
5. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
tryb i warunki określania predyspozycji fizycznych i psychicznych do służby na 
określonych stanowiskach lub w określonych komórkach organizacyjnych Policji oraz 
przeprowadzania badań psychofizjologicznych, uwzględniając wykaz komórek 
organizacyjnych uprawnionych do przeprowadzania testu lub badań, o których mowa 
w ust. 1, wykaz komórek organizacyjnych Policji i stanowisk służbowych, dla których 
test lub badania mogą być przeprowadzane, oraz zakres i ramową metodykę badań, 
mając na względzie zapewnienie sprawnego przebiegu wyłonienia osób posiadających 
predyspozycje do pełnienia służby na określonych stanowiskach lub w określonych 
komórkach organizacyjnych Policji.

***
## Art. 35b. {#policja-art-35b}

Policjanta, za jego zgodą, przenosi na stanowisko związane z 
bezpośrednim rozpoznawaniem i zwalczaniem przestępstw popełnionych przy użyciu 
systemu informatycznego, systemu teleinformatycznego lub sieci teleinformatycznej 
oraz zapobieganiem tym przestępstwom, a także wykrywaniem i ściganiem sprawców 
tych przestępstw w CBZC Komendant Główny Policji, na wniosek Komendanta 
CBZC, po uzyskaniu przez policjanta pozytywnego wyniku sprawdzenia wiedzy, 
umiejętności i znajomości języka, o którym mowa w art. 25 ust. 12 pkt 2.

***
## Art. 36. {#policja-art-36}

1. Policjant może być przeniesiony do pełnienia służby albo delegowany 
do czasowego pełnienia służby w innej jednostce organizacyjnej Policji lub w innej 
miejscowości z urzędu lub na własną prośbę. 
2. Do przenoszenia lub delegowania policjanta właściwi są: Komendant Główny 
Policji na obszarze całego państwa, Komendant CBŚP w odniesieniu do policjanta 
CBŚP w ramach tej jednostki organizacyjnej, Komendant BSWP w odniesieniu do 
policjanta BSWP w ramach tej jednostki organizacyjnej, Komendant CBZC w 
odniesieniu do policjanta CBZC w ramach tej jednostki organizacyjnej, Dyrektor 
CLKP w odniesieniu do policjanta CLKP w ramach tej jednostki organizacyjnej, 
komendant wojewódzki Policji na obszarze właściwego województwa, komendant 
powiatowy (miejski) Policji na obszarze właściwego powiatu (miasta). Jeżeli 

 
 
 
s. 140/274 
 
2025-07-03 
 
przeniesienie między województwami, a także między CBŚP a innymi jednostkami 
organizacyjnymi Policji, BSWP a innymi jednostkami organizacyjnymi Policji, CBZC 
a innymi jednostkami organizacyjnymi Policji oraz między CLKP a innymi 
jednostkami organizacyjnymi Policji następuje w związku z porozumieniem 
zainteresowanych przełożonych i policjanta, przeniesienia dokonuje komendant 
wojewódzki Policji właściwy dla województwa, w którym policjant ma pełnić służbę, 
w przypadku przeniesienia do CBŚP – Komendant CBŚP, w przypadku przeniesienia 
do BSWP – Komendant BSWP, w przypadku przeniesienia do CBZC – Komendant 
CBZC, a w przypadku przeniesienia do CLKP – Dyrektor CLKP. 
3. Czas delegacji nie może przekraczać 6 miesięcy. Komendant Główny Policji, 
Komendant CBŚP, Komendant BSWP, Komendant CBZC albo Dyrektor CLKP w 
wyjątkowych przypadkach może przedłużyć czas delegacji do 12 miesięcy. 
4. Komendant Główny Policji może oddelegować policjanta, za jego zgodą, do 
pełnienia zadań służbowych poza Policją w kraju i za granicą na czas określony. 
4a. Policjant może być oddelegowany do wykonywania zadań służbowych poza 
Policją w celu realizacji zadań określonych w ustawie lub zadań Policji wynikających 
z obowiązujących Rzeczpospolitą Polską umów i zobowiązań międzynarodowych. 
4b. Policjant może być oddelegowany do: 
1) 
urzędu krajowego obsługującego organ władzy publicznej, w którym są 
wykonywane zadania o charakterze określonym w ust. 4a, zwanego dalej 
„instytucją krajową”; 
2) 
urzędu, organizacji lub instytucji międzynarodowej albo państwa obcego, w 
których są wykonywane zadania, o których mowa w ust. 4a, zwanych dalej 
„instytucją zagraniczną”. 
4c. Oddelegowanie policjanta do wykonywania zadań w Biurze Nadzoru 
Wewnętrznego następuje na zasadach określonych w ustawie z dnia 21 czerwca 1996 
r. o szczególnych formach sprawowania nadzoru przez ministra właściwego do spraw 
wewnętrznych. W zakresie nieuregulowanym stosuje się odpowiednio przepisy art. 
36a–36p. 
4d. Policjanta przyjętego do służby na zasadach, o których mowa w art. 25 ust. 
5, 11 lub 12, można przenieść lub delegować do innej służby w Policji pod warunkiem 
przystąpienia przez niego do pominiętych zgodnie z tymi zasadami etapów 
postępowania kwalifikacyjnego, o których mowa w art. 25 ust. 2, oraz uzyskania ich 
pozytywnego wyniku. 

 
 
 
s. 141/274 
 
2025-07-03 
 
5. (uchylony) 
6. (uchylony)

***
## Art. 36a. {#policja-art-36a}

1. Z wnioskiem o oddelegowanie policjanta do wykonywania zadań 
służbowych poza Policją mogą wystąpić: 
1) 
organy Policji lub kierownik komórki organizacyjnej Komendy Głównej Policji; 
2) 
instytucje krajowe; 
3) 
instytucje zagraniczne. 
2. Wniosek, o którym mowa w ust. 1, powinien określać nazwę instytucji, 
komórki organizacyjnej oraz nazwę stanowiska przeznaczonego dla policjanta lub 
pełnionej funkcji, opis kwalifikacji wymaganych do zajmowania stanowiska lub 
pełnienia funkcji, zakres wykonywanych zadań, przewidywany okres oddelegowania 
oraz określenie należności pieniężnych i innych świadczeń przysługujących 
oddelegowanemu policjantowi. Wniosek instytucji zagranicznej powinien dodatkowo 
zawierać określenie uprawnień i należności przysługujących oddelegowanemu 
policjantowi w tej instytucji. 
3. W przypadku policjanta, który ma zostać oddelegowany za granicę do 
wykonywania zadań zleconych przez instytucję zagraniczną albo zadań wynikających 
z programów finansowanych ze środków funduszy Unii Europejskiej, gdy okres 
oddelegowania ma trwać co najmniej rok, a wykonywanie zadań nie wymaga objęcia 
przez policjanta stanowiska w instytucji zagranicznej, wniosek powinien dodatkowo 
określać zakres uprawnień i należności, jakie przysługują oddelegowanemu 
policjantowi lub jego jednostce organizacyjnej Policji od instytucji finansującej, przez 
którą należy rozumieć instytucję krajową albo instytucję zagraniczną, w tym 
organizację międzynarodową, inną niż podmiot oddelegowujący lub podmiot, do 
którego następuje oddelegowanie, finansującą wykonywanie zadań, o których mowa 
w art. 36 ust. 4a. 
4. Wniosek składa się nie później niż 14 dni przed przewidywanym dniem 
oddelegowania policjanta do instytucji krajowej lub instytucji zagranicznej.

***
## Art. 36b. {#policja-art-36b}

Oddelegowanie do wykonywania zadań służbowych poza Policją 
następuje po zapoznaniu się policjanta z treścią wniosku oraz po wyrażeniu przez 
niego zgody na oddelegowanie w formie pisemnego oświadczenia wskazującego 
nazwę instytucji krajowej lub instytucji zagranicznej, nazwę stanowiska służbowego 
lub pełnionej funkcji, a także okres oddelegowania. 

 
 
 
s. 142/274 
 
2025-07-03

***
## Art. 36c. {#policja-art-36c}

1. W przypadku gdy oddelegowanie policjanta do instytucji 
zagranicznej jest poprzedzone postępowaniem kwalifikacyjnym przewidzianym w 
umowie międzynarodowej lub przepisach prawa Unii Europejskiej, policjant zwraca 
się pisemnie do Komendanta Głównego Policji z wnioskiem o wyrażenie zgody na 
uczestnictwo w tym postępowaniu. 
2. W przypadku pozytywnie zakończonego postępowania kwalifikacyjnego, o 
którym mowa w ust. 1, oddelegowanie policjanta do instytucji zagranicznej następuje 
po przedstawieniu Komendantowi Głównemu Policji kontraktu z instytucją 
zagraniczną. 
3. W razie otrzymania przez policjanta od instytucji zagranicznej propozycji 
przedłużenia kontraktu lub gdy policjant ubiega się o kolejny kontrakt w instytucji 
zagranicznej, stosuje się odpowiednio ust. 1.

***
## Art. 36d. {#policja-art-36d}

Komendant Główny Policji może z własnej inicjatywy oddelegować 
policjanta do wykonywania zadań służbowych poza Policją.

***
## Art. 36e. {#policja-art-36e}

1. Komendant Główny Policji w razie uwzględnienia wniosku: 
1) 
uzgadnia z instytucją krajową lub instytucją zagraniczną obsadę personalną 
stanowiska służbowego określonego we wniosku albo pełnioną funkcję, po 
uprzednim uzyskaniu od policjanta pisemnego oświadczenia, o którym mowa 
w art. 36b, jeśli kwestie te nie zostały wcześniej uzgodnione; 
2) 
zwalnia policjanta z zajmowanego stanowiska służbowego, z jednoczesnym 
przeniesieniem go do dyspozycji przełożonego właściwego w sprawach 
osobowych; 
3) 
zalicza, do celów obliczenia uposażenia i innych należności pieniężnych 
przysługujących policjantowi w okresie oddelegowania, stanowisko służbowe w 
instytucji 
krajowej 
określone 
we 
wniosku 
do 
odpowiedniej 
grupy 
zaszeregowania oraz ustala policyjny stopień etatowy, stosownie do 
zaszeregowania stanowisk służbowych policjantów; 
4) 
oddelegowuje policjanta do wykonywania zadań służbowych poza Policją, z 
wyjątkiem przypadku, o którym mowa w art. 11g ust. 4 ustawy z dnia 21 czerwca 
1996 r. o szczególnych formach sprawowania nadzoru przez ministra właś-
ciwego do spraw wewnętrznych. 
2. Od decyzji, o której mowa w ust. 1 pkt 4, policjantowi służy odwołanie do 
ministra właściwego do spraw wewnętrznych. 

 
 
 
s. 143/274 
 
2025-07-03 
 
3. Komendant Główny Policji nie uwzględnia wniosku, jeżeli wskazane w nim 
stanowisko, charakter lub zakres zadań, jakie miałby wykonywać policjant 
oddelegowany poza Policję, nie odpowiada zadaniom określonym w ustawie oraz 
zadaniom wynikającym z obowiązujących Rzeczpospolitą Polską umów i zobowiązań 
międzynarodowych.

***
## Art. 36f. {#policja-art-36f}

1. Warunkiem oddelegowania policjanta do instytucji krajowej lub 
instytucji zagranicznej jest wyznaczenie go na stanowisko służbowe lub do pełnienia 
funkcji, zgodnie z wnioskiem, o którym mowa w art. 36a ust. 2. 
2. Instytucja krajowa lub instytucja zagraniczna może przenieść oddelegowanego 
policjanta na inne stanowisko służbowe niż określone we wniosku o oddelegowanie, 
jeżeli na stanowisku tym są wykonywane zadania, o których mowa w art. 36 ust. 4a. 
W takim przypadku przepisy art. 36a–36e i art. 36g stosuje się odpowiednio.

***
## Art. 36g. {#policja-art-36g}

1. Komendant Główny Policji odwołuje policjanta z oddelegowania w 
przypadku konieczności zwolnienia go ze służby w Policji, zawiadamiając o tym 
odpowiednio instytucję krajową, instytucję zagraniczną lub instytucję finansującą. 
2. Komendant Główny Policji, na uzasadniony wniosek instytucji krajowej, 
instytucji zagranicznej lub instytucji finansującej, odwołuje policjanta z 
oddelegowania bez jego zgody. Właściwa instytucja, składając Komendantowi 
Głównemu Policji wniosek o odwołanie policjanta z oddelegowania, zawiadamia o 
tym policjanta. Odwołanie następuje nie wcześniej niż z upływem 30 dni od dnia 
złożenia wniosku. 
3. Komendant Główny Policji odwołuje policjanta z oddelegowania do instytucji 
krajowej lub instytucji zagranicznej na jego wniosek, zawiadamiając odpowiednio 
właściwą instytucję. Odwołanie następuje w terminie do 3 miesięcy od dnia złożenia 
wniosku. 
4. Komendant Główny Policji, z uwagi na uzasadnione potrzeby Policji, może 
odwołać policjanta z oddelegowania bez jego zgody, zawiadamiając o tym instytucję 
krajową, instytucję zagraniczną lub instytucję finansującą oraz policjanta. Odwołanie 
następuje nie wcześniej niż z upływem 30 dni od dnia zawiadomienia. 
5. Terminy, o których mowa w ust. 2–4, mogą być skracane za porozumieniem 
Komendanta Głównego Policji, instytucji krajowej, instytucji zagranicznej lub 
instytucji finansującej oraz zainteresowanego policjanta. 

 
 
 
s. 144/274 
 
2025-07-03

***
## Art. 36h. {#policja-art-36h}

1. Po odwołaniu policjanta z oddelegowania przełożony właściwy w 
sprawach osobowych mianuje go na stanowisko nie niższe niż zajmowane przed 
oddelegowaniem. 
2. Komendant Główny Policji może wyrazić zgodę na zwolnienie ze służby w 
Policji policjanta, o którym mowa w art. 36g, ze stanowiska równorzędnego do 
zajmowanego w instytucji krajowej. Nie dotyczy to policjanta, który podlega 
zwolnieniu ze służby na podstawie art. 41 ust. 1 pkt 3–5 oraz ust. 2 pkt 1, 2, 5 i 8 albo 
wobec którego orzeczono karę dyscyplinarną wyznaczenia na niższe stanowisko 
służbowe.

***
## Art. 36i. {#policja-art-36i}

1. Policjant w okresie oddelegowania do instytucji krajowej lub 
instytucji zagranicznej podlega przełożonemu właściwemu w sprawach osobowych, z 
wyjątkiem oddelegowania do Biura Nadzoru Wewnętrznego. 
2. Przepis ust. 1 nie narusza uprawnień przełożonego, któremu policjant podlega 
z tytułu zajmowania stanowiska służbowego albo pełnienia funkcji w instytucji 
krajowej lub instytucji zagranicznej.

***
## Art. 36j. {#policja-art-36j}

1. Policjant oddelegowany do wykonywania zadań służbowych w 
instytucji krajowej zachowuje prawo do urlopu w wymiarze i na zasadach określonych 
w ustawie. 
2. Policjantowi oddelegowanemu do wykonywania zadań służbowych w 
instytucji zagranicznej przysługuje urlop w wymiarze i na zasadach obowiązujących 
w tej instytucji. 
3. Policjant oddelegowany do wykonywania zadań służbowych w instytucji 
zagranicznej jest obowiązany informować na piśmie przełożonego właściwego w 
sprawach osobowych o wymiarze urlopu przysługującego i wykorzystanego w 
instytucji zagranicznej. 
4. Policjantowi odwołanemu z oddelegowania w instytucji zagranicznej 
przysługuje urlop uzupełniający w wymiarze odpowiadającym różnicy pomiędzy 
wymiarem urlopu wypoczynkowego i dodatkowego, ustalonego na podstawie ustawy, 
a wymiarem urlopu przysługującego mu w instytucji zagranicznej.

***
## Art. 36k. {#policja-art-36k}

1. Policjantowi oddelegowanemu do wykonywania zadań służbowych 
w instytucji krajowej przysługują uprawnienia i świadczenia, w tym uposażenie i inne 
należności pieniężne, w wysokości i na warunkach określonych w ustawie. 

 
 
 
s. 145/274 
 
2025-07-03 
 
2. Policjantowi oddelegowanemu do wykonywania zadań służbowych w 
instytucji krajowej położonej poza miejscowością stanowiącą siedzibę jednostki 
organizacyjnej Policji, w której policjant pełnił dotychczas służbę, przysługują z tego 
tytułu należności przewidziane dla policjanta delegowanego do czasowego pełnienia 
służby w innej miejscowości. 
3. Instytucja krajowa wypłaca oddelegowanemu policjantowi: 
1) 
uposażenie zasadnicze wraz z dodatkami do uposażenia; 
2) 
nagrody roczne za okres oddelegowania; 
3) 
nagrody motywacyjne; 
4) 
należności z tytułu podróży służbowych oraz oddelegowania, o którym mowa w 
ust. 2. 
4. Świadczenia i należności pieniężne niewymienione w ust. 3 przyznaje i 
wypłaca jednostka organizacyjna Policji, w której policjant pełnił służbę bezpośrednio 
przed oddelegowaniem.

***
## Art. 36l. {#policja-art-36l}

Do policjanta oddelegowanego do wykonywania zadań służbowych w 
instytucji krajowej stosuje się przepisy, które mają zastosowanie do pracowników 
zatrudnionych na stanowiskach analogicznych do zajmowanego przez niego 
stanowiska służbowego, w szczególności dotyczące obowiązków pracodawcy i 
pracownika, regulaminów pracy, wyróżnień, odpowiedzialności materialnej 
pracowników, czasu pracy, bezpieczeństwa i higieny pracy, a także funduszu nagród, 
z wyłączeniem pozostałych przepisów w sprawie wynagrodzeń oraz innych świadczeń 
i należności pieniężnych wynikających ze stosunku pracy.

***
## Art. 36m. {#policja-art-36m}

1. Policjant w czasie oddelegowania do wykonywania zadań 
służbowych w instytucji zagranicznej zachowuje prawo do uposażenia zasadniczego, 
dodatków do uposażenia o charakterze stałym i innych należności pieniężnych 
należnych na ostatnio zajmowanym stanowisku służbowym, z uwzględnieniem 
powstałych w tym okresie zmian mających wpływ na prawo do uposażenia i innych 
należności pieniężnych lub na ich wysokość. 
2. Policjantowi, o którym mowa w ust. 1, przysługują również: 
1) 
należności z tytułu zagranicznej podróży służbowej; 
2) 
zwrot kosztów przewozu rzeczy osobistego użytku i przedmiotów gospodarstwa 
domowego; 
3) 
ryczałt na pokrycie kosztów utrzymania; 

 
 
 
s. 146/274 
 
2025-07-03 
 
4) 
zwrot kosztów leczenia. 
3. Uposażenie oraz świadczenia i należności pieniężne, o których mowa w ust. 1 
i ust. 2 pkt 3, nie przysługują policjantowi otrzymującemu za granicą wynagrodzenie 
na podstawie kontraktu zawartego z instytucją zagraniczną lub instytucją finansującą. 
4. Przepis ust. 1 stosuje się odpowiednio do policjanta oddelegowanego za 
granicę do wykonywania zadań zleconych przez instytucję zagraniczną albo zadań 
wynikających z programów finansowanych ze środków funduszy Unii Europejskiej, 
gdy okres oddelegowania trwa co najmniej rok, a wykonywanie zadań nie wymaga 
objęcia przez policjanta stanowiska w instytucji zagranicznej, w przypadku gdy 
wynagrodzenie to jest refundowane jednostce organizacyjnej Policji przez instytucję 
finansującą.

***
## Art. 36ma. {#policja-art-36ma}

Kierownik lub dyrektor generalny urzędu, jednostki organizacyjnej 
lub służby, do których oddelegowano policjanta, na wniosek Komendanta Głównego 
Policji lub upoważnionej przez niego osoby przesyła informacje dotyczące oceny 
wykonywania przez policjanta zadań i obowiązków w czasie trwania oddelegowania, 
w celu i zakresie niezbędnym do sporządzenia opinii służbowej.

***
## Art. 36n. {#policja-art-36n}

1. Policjantowi oddelegowanemu do wykonywania zadań służbowych 
w instytucji zagranicznej przysługują diety na pokrycie kosztów wyżywienia i inne 
drobne wydatki, zwrot kosztów noclegów, przejazdów i dojazdów oraz innych 
niezbędnych wydatków uznanych przez Komendanta Głównego Policji, na warunkach 
określonych w przepisach w sprawie przyznawania policjantom należności za podróże 
służbowe i przeniesienia. 
2. Należności, o których mowa w ust. 1, policjant otrzymuje z tytułu podróży 
odbywanych: 
1) 
w związku z rozpoczęciem i zakończeniem służby w instytucji zagranicznej; 
2) 
w celu załatwienia w kraju lub w innym państwie spraw służbowych na polecenie 
lub za zgodą Komendanta Głównego Policji; 
3) 
w razie śmierci pozostających w kraju członków rodziny, na których przysługuje 
zasiłek pogrzebowy na podstawie ustawy, a w innych przypadkach losowych – 
za zgodą Komendanta Głównego Policji; 
4) 
w celu wykorzystania urlopu wypoczynkowego w kraju, raz na 2 lata, nie 
wcześniej niż po upływie 12 miesięcy służby w instytucji zagranicznej, z 
wyłączeniem ostatniego roku tej służby. 

 
 
 
s. 147/274 
 
2025-07-03 
 
3. Zwrot kosztów przewozu nie przysługuje, jeżeli z tytułu podróży, o której 
mowa w ust. 2 pkt 1, policjant otrzymał zwrot kosztów przejazdu ustalony z 
uwzględnieniem stawek za kilometr przebiegu pojazdu, określony na podstawie 
przepisów w sprawie przyznawania policjantom należności za podróże służbowe i 
przeniesienia.

***
## Art. 36o. {#policja-art-36o}

Należności i świadczenia, o których mowa w art. 36m ust. 2, nie 
przysługują, jeżeli policjant otrzymuje od instytucji zagranicznej lub instytucji 
finansującej świadczenia pieniężne na cele analogiczne do określonych w tych 
przepisach.

***
## Art. 36p. {#policja-art-36p}

Minister właściwy do spraw wewnętrznych określi, w drodze 
rozporządzenia, wysokość, tryb przyznawania i wypłaty należności przysługujących 
policjantowi oddelegowanemu do instytucji zagranicznej, o których mowa w art. 36m 
ust. 2, oraz właściwość przełożonych w tych sprawach, a także sposób i zakres 
składania informacji przełożonemu w związku z oddelegowaniem do instytucji 
zagranicznej, mając na względzie zapewnienie sprawnej i terminowej wypłaty 
należności.

***
## Art. 37. {#policja-art-37}

Policjantowi można powierzyć pełnienie obowiązków służbowych na 
innym stanowisku w tej samej miejscowości na czas nieprzekraczający 12 miesięcy; 
w takim przypadku uposażenie policjanta nie może być obniżone.

***
## Art. 37a. {#policja-art-37a}

Policjanta w przypadku zwolnienia z dotychczas zajmowanego 
stanowiska służbowego można przenieść do dyspozycji przełożonego właściwego w 
sprawach osobowych, na okres: 
1) 
poprzedzający powołanie lub mianowanie na inne stanowisko służbowe albo 
zwolnienie ze służby, nie dłuższy niż 12 miesięcy; 
2) 
zwolnienia z obowiązku wykonywania zadań służbowych, udzielonego na 
zasadach określonych w przepisach o związkach zawodowych; 
3) 
delegowania do pełnienia zadań służbowych poza Policją w kraju lub za granicą.

***
## Art. 38. {#policja-art-38}

1. Policjanta przenosi się na niższe stanowisko służbowe w razie 
wymierzenia kary dyscyplinarnej wyznaczenia na niższe stanowisko służbowe. 
2. Policjanta można przenieść na niższe stanowisko służbowe w przypadkach: 

 
 
 
s. 148/274 
 
2025-07-03 
 
1) 
orzeczenia trwałej niezdolności do pełnienia służby na zajmowanym stanowisku 
przez komisję lekarską, jeżeli nie ma możliwości mianowania go na stanowisko 
równorzędne; 
2) 
nieprzydatności na zajmowanym stanowisku, stwierdzonej w opinii służbowej w 
okresie służby przygotowawczej; 
3) 
niewywiązywania się z obowiązków służbowych na zajmowanym stanowisku, 
stwierdzonego w okresie służby stałej w dwóch kolejnych opiniach służbowych, 
między którymi upłynęło co najmniej 6 miesięcy; 
4) 
likwidacji zajmowanego stanowiska służbowego lub z innych przyczyn 
uzasadnionych potrzebami organizacyjnymi, gdy nie ma możliwości 
mianowania go na inne równorzędne stanowisko; 
5) 
niewyrażenia zgody na mianowanie na stanowisko służbowe w okresie 
pozostawania w dyspozycji przełożonego właściwego w sprawach osobowych, 
gdy nie ma możliwości mianowania go na inne równorzędne stanowisko. 
3. Policjanta można przenieść na niższe stanowisko służbowe również na jego 
prośbę. 
4. Policjant, który nie wyraził zgody na przeniesienie na niższe stanowisko z 
przyczyn określonych w ust. 2, może być zwolniony ze służby.

***
## Art. 38a. {#policja-art-38a}

Równorzędnym stanowiskiem służbowym jest stanowisko 
zaszeregowane do tej samej grupy uposażenia zasadniczego i takiego samego stopnia 
etatowego.

***
## Art. 39. {#policja-art-39}

1. Policjanta zawiesza się w czynnościach służbowych w razie 
wszczęcia przeciwko niemu postępowania karnego w sprawie o przestępstwo lub 
przestępstwo skarbowe, umyślne, ścigane z oskarżenia publicznego – na czas nie 
dłuższy niż 3 miesiące. 
2. Policjanta można zawiesić w czynnościach służbowych w razie wszczęcia 
przeciwko niemu postępowania karnego w sprawie o przestępstwo lub przestępstwo 
skarbowe, nieumyślne, ścigane z oskarżenia publicznego lub postępowania 
dyscyplinarnego, jeżeli jest to celowe z uwagi na dobro postępowania lub dobro służby 
– na czas nie dłuższy niż 12 miesięcy. 
2a. W razie wniesienia przeciwko policjantowi aktu oskarżenia określonego w 
art. 55 § 1 Kodeksu postępowania karnego przepis ust. 2 stosuje się odpowiednio. 

 
 
 
s. 149/274 
 
2025-07-03 
 
3. W szczególnie uzasadnionych przypadkach okres zawieszenia w czynnościach 
służbowych można przedłużyć do czasu ukończenia postępowania karnego. 
4. (uchylony)

***
## Art. 39a. {#policja-art-39a}

1. Przełożonymi właściwymi do zawieszania policjantów w 
czynnościach służbowych są: 
1) 
minister właściwy do spraw wewnętrznych – w stosunku do Komendanta 
Głównego Policji oraz Komendanta BSWP i jego zastępcy; 
2) 
Komendant Główny Policji – w stosunku do policjanta na stanowisku 
służbowym: 
a) 
Komendanta CBŚP i jego zastępcy, 
aa) Komendanta CBZC i jego zastępcy, 
ab) Dyrektora CLKP i jego zastępcy, 
b) 
komendanta wojewódzkiego (Stołecznego) Policji i jego zastępcy, 
c) 
Komendanta-Rektora Akademii Policji w Szczytnie i jego zastępcy, 
d) 
komendanta szkoły policyjnej i jego zastępcy, 
e) 
w Komendzie Głównej Policji lub pozostającego w jego dyspozycji, 
f) 
(uchylona) 
g) 
w BOA; 
3) 
Komendant CBŚP – w stosunku do policjanta na stanowisku służbowym w 
CBŚP; 
3a)  Komendant CBZC – w stosunku do policjanta na stanowisku służbowym w 
CBZC; 
4) 
Komendant BSWP – w stosunku do policjanta na stanowisku służbowym w 
BSWP; 
4a)  Dyrektor CLKP – w stosunku do policjanta pełniącego służbę na stanowisku 
służbowym w CLKP; 
5) 
komendant wojewódzki (Stołeczny) Policji – w stosunku do policjanta na 
stanowisku służbowym: 
a) 
komendanta powiatowego (miejskiego, rejonowego) Policji oraz jego 
zastępcy, 
b) 
w jednostce organizacyjnej Policji bezpośrednio podległej, 
c) 
w komendzie wojewódzkiej (Stołecznej) Policji lub pozostającego w jego 
dyspozycji; 

 
 
 
s. 150/274 
 
2025-07-03 
 
6) 
komendant powiatowy (miejski, rejonowy) Policji – w stosunku do policjanta na 
stanowisku służbowym: 
a) 
komendanta komisariatu Policji oraz jego zastępcy, 
b) 
w jednostce organizacyjnej Policji bezpośrednio podległej, 
c) 
w komendzie powiatowej (miejskiej, rejonowej) Policji lub pozostającego 
w jego dyspozycji; 
7) 
Komendant-Rektor Akademii Policji w Szczytnie – w stosunku do policjanta na 
stanowisku służbowym w Akademii Policji w Szczytnie; 
8) 
komendant szkoły policyjnej – w stosunku do policjanta na stanowisku 
służbowym w szkole policyjnej. 
2. W szczególnie uzasadnionych przypadkach Komendant Główny Policji może 
zawiesić w czynnościach służbowych również policjantów wymienionych w ust. 1 pkt 
3–8. 
3. Okres zawieszenia w czynnościach służbowych przedłuża przełożony 
właściwy do zawieszenia w czynnościach służbowych. Jeżeli zawieszenie w 
czynnościach służbowych nastąpiło na podstawie ust. 2, okres zawieszenia w czyn-
nościach służbowych przedłuża Komendant Główny Policji.

***
## Art. 39b. {#policja-art-39b}

1. Zawieszenie w czynnościach służbowych oraz przedłużenie okresu 
zawieszenia w czynnościach służbowych następują w drodze decyzji. 
2. W decyzji o zawieszeniu w czynnościach służbowych oraz decyzji o 
przedłużeniu okresu zawieszenia w czynnościach służbowych zamieszcza się: 
1) 
oznaczenie przełożonego podejmującego decyzję; 
2) 
datę wydania decyzji; 
3) 
podstawę prawną; 
4) 
stopień policyjny, nazwisko i imię, imię ojca oraz numer identyfikacyjny 
zawieszonego policjanta; 
5) 
nazwę stanowiska służbowego zawieszonego policjanta oraz nazwę jednostki 
organizacyjnej Policji; 
6) 
wskazanie okresu, na który nastąpi zawieszenie lub przedłużenie okresu 
zawieszenia; 
7) 
termin rozliczenia się z obowiązków oraz realizacji zadań i czynności 
służbowych zawieszonego policjanta; 

 
 
 
s. 151/274 
 
2025-07-03 
 
8) 
uzasadnienie faktyczne i prawne zawieszenia w czynnościach służbowych 
policjanta; 
9) 
pouczenie o przysługującym zawieszonemu policjantowi środku odwoławczym; 
10) podpis z podaniem imienia i nazwiska oraz stanowiska służbowego przełożonego 
uprawnionego do ich wydania. 
3. Decyzję, o której mowa w ust. 1, doręcza się niezwłocznie zainteresowanemu 
policjantowi, a kopię decyzji włącza się do jego akt osobowych.

***
## Art. 39c. {#policja-art-39c}

1. Od decyzji o zawieszeniu w czynnościach służbowych oraz od 
decyzji o przedłużeniu okresu zawieszenia w czynnościach służbowych policjantowi 
przysługuje odwołanie do: 
1) 
ministra właściwego do spraw wewnętrznych, jeżeli decyzję wydał Komendant 
Główny Policji; 
2) 
Komendanta Głównego Policji, jeżeli decyzję wydał: Komendant BSWP, 
Komendant CBŚP, Komendant CBZC, Dyrektor CLKP, komendant wojewódzki 
Policji albo Komendant Stołeczny Policji, Komendant-Rektor Akademii Policji 
w Szczytnie oraz komendant szkoły policyjnej; 
3) 
komendanta wojewódzkiego (Stołecznego) Policji, jeżeli decyzję wydał 
komendant powiatowy (miejski, rejonowy) Policji. 
2. Jeżeli decyzję o zawieszeniu w czynnościach służbowych lub decyzję o 
przedłużeniu okresu zawieszenia w czynnościach służbowych wydał minister 
właściwy do spraw wewnętrznych, odwołanie nie przysługuje. Odwołujący może 
zwrócić się z wnioskiem o ponowne rozpatrzenie sprawy do ministra właściwego do 
spraw wewnętrznych. Do wniosku o ponowne rozpatrzenie sprawy stosuje się przepisy 
dotyczące odwołań od decyzji. 
3. Decyzja o zawieszeniu w czynnościach służbowych lub decyzja o jego 
przedłużeniu podlega natychmiastowemu wykonaniu. 
4. Odwołanie i wniosek o ponowne rozpatrzenie sprawy, o których mowa w ust. 
1 i 2, wnosi się w terminie 14 dni od dnia doręczenia decyzji przełożonego, który 
wydał decyzję. 
5. Rozpatrzenie odwołania i wniosku o ponowne rozpatrzenie sprawy, o których 
mowa w ust. 1 i 2, następuje w drodze decyzji, wydanej w terminie 7 dni od dnia 
otrzymania odwołania lub wniosku, wraz z aktami sprawy. 

 
 
 
s. 152/274 
 
2025-07-03

***
## Art. 39d. {#policja-art-39d}

1. Wygaśnięcie decyzji o zawieszeniu w czynnościach służbowych 
następuje w przypadku: 
1) 
upływu terminu określonego w decyzji o zawieszeniu w czynnościach 
służbowych, jeżeli zawieszenia nie przedłużono do czasu ukończenia 
postępowania karnego; 
2) 
prawomocnego zakończenia postępowania karnego lub dyscyplinarnego; 
3) 
zwolnienia policjanta ze służby; 
4) 
śmierci lub zaginięcia policjanta. 
2. Decyzję o zawieszeniu w czynnościach służbowych uchyla się w przypadku 
ustania przesłanek: 
1) 
wskazujących na celowość zawieszenia, o których mowa w art. 39 ust. 2; 
2) 
które były podstawą przedłużenia okresu zawieszenia. 
3. Do decyzji o uchyleniu zawieszenia w czynnościach służbowych stosuje się 
odpowiednio przepisy art. 39a ust. 1 i 2, art. 39b ust. 2 pkt 1–5, 7–10 i ust. 3 oraz art. 
39c.

***
## Art. 40. {#policja-art-40}

Policjant może być skierowany do komisji lekarskiej podległej 
ministrowi właściwemu do spraw wewnętrznych: 
1) 
z urzędu lub na jego wniosek – w celu określenia stanu zdrowia oraz ustalenia 
zdolności fizycznej i psychicznej do służby, jak również związku 
poszczególnych chorób ze służbą; 
2) 
z urzędu – w celu sprawdzenia prawidłowości orzekania o czasowej niezdolności 
do służby z powodu choroby lub prawidłowości wykorzystania zwolnienia 
lekarskiego.

***
## Art. 40a. {#policja-art-40a}

1. Funkcjonariusz jest obowiązany poddać się badaniom zleconym 
przez komisję lekarską, w tym również badaniom specjalistycznym, psychologicznym 
i dodatkowym. 
2. W przypadku gdy przeprowadzone badania i zgromadzona dokumentacja nie 
pozwalają na wydanie orzeczenia, funkcjonariusz może zostać skierowany na 
obserwację w podmiocie leczniczym, jeżeli wyraża na to zgodę.

***
## Art. 41. {#policja-art-41}

1. Policjanta zwalnia się ze służby w przypadkach: 
1) 
orzeczenia trwałej niezdolności do służby przez komisję lekarską; 
2) 
nieprzydatności do służby, stwierdzonej w opinii służbowej w okresie służby 
przygotowawczej lub służby kontraktowej; 

 
 
 
s. 153/274 
 
2025-07-03 
 
3) 
wymierzenia kary dyscyplinarnej wydalenia ze służby; 
4) 
skazania prawomocnym wyrokiem sądu za przestępstwo lub przestępstwo 
skarbowe, umyślne, ścigane z oskarżenia publicznego; 
4a) wymierzenia przez sąd prawomocnym orzeczeniem środka karnego w postaci 
zakazu wykonywania zawodu policjanta; 
5) 
zrzeczenia się obywatelstwa polskiego; 
6) 
upływu okresu służby określonego w kontrakcie, jeżeli nie nastąpi zawarcie 
kolejnego kontraktu lub mianowanie na stałe; 
7) 
upływu okresu próbnego służby kontraktowej, jeżeli policjant lub przełożony 
skorzystał z uprawnienia określonego w art. 28a ust. 14. 
2. Policjanta można zwolnić ze służby w przypadkach: 
1) 
niewywiązywania się z obowiązków służbowych w okresie odbywania służby 
stałej, stwierdzonego w 2 kolejnych opiniach, między którymi upłynęło co 
najmniej 6 miesięcy; 
2) 
skazania prawomocnym wyrokiem sądu za przestępstwo lub przestępstwo 
skarbowe inne niż określone w ust. 1 pkt 4; 
3) 
powołania do innej służby państwowej, a także objęcia funkcji z wyboru w 
organach samorządu terytorialnego lub stowarzyszeniach; 
4) 
(uchylony) 
5) 
gdy wymaga tego ważny interes służby; 
6) 
likwidacji jednostki Policji lub jej reorganizacji połączonej ze zmniejszeniem 
obsady etatowej, jeżeli przeniesienie policjanta do innej jednostki lub na niższe 
stanowisko służbowe nie jest możliwe; 
7) 
upływu 12 miesięcy od dnia zaprzestania służby z powodu choroby; 
7a) dwukrotnego nieusprawiedliwionego niestawienia się na badania, o których 
mowa w art. 40a ust. 1, lub niepoddania się im, albo w przypadku dwukrotnego 
nieusprawiedliwionego niestawienia się na obserwację w podmiocie leczniczym, 
w przypadku wyrażenia zgody przez funkcjonariusza, chyba że skierowanie do 
komisji lekarskiej nastąpiło na wniosek funkcjonariusza; 
8) 
popełnienia czynu o znamionach przestępstwa albo przestępstwa skarbowego, 
jeżeli popełnienie czynu jest oczywiste i uniemożliwia jego pozostanie w służbie; 
9) 
upływu 12 miesięcy zawieszenia w czynnościach służbowych, jeżeli nie ustały 
przyczyny będące podstawą zawieszenia; 

 
 
 
s. 154/274 
 
2025-07-03 
 
10) usunięcia ze szkolenia zawodowego podstawowego, w przypadkach wskazanych 
w art. 34f ust. 1 pkt 1, 3 i 5–8. 
3. Policjanta zwalnia się ze służby w terminie do 3 miesięcy od dnia pisemnego 
zgłoszenia przez niego wystąpienia ze służby. 
3a. (uchylony) 
3b. (uchylony) 
4. W przypadkach określonych w ust. 2 pkt 6 zwolnienie następuje po upływie 6 
miesięcy, a w przypadku służby przygotowawczej, po upływie 3 miesięcy od dnia 
podjęcia decyzji o likwidacji jednostki Policji lub jej reorganizacji.

***
## Art. 42. {#policja-art-42}

1. Uchylenie lub stwierdzenie nieważności decyzji o zwolnieniu ze 
służby w Policji z powodu jej wadliwości stanowi podstawę przywrócenia do służby 
na stanowisko równorzędne. 
2. Jeżeli zwolniony policjant w ciągu 7 dni od przywrócenia do służby nie zgłosi 
gotowości niezwłocznego jej podjęcia, stosunek służbowy ulega rozwiązaniu na 
podstawie art. 41 ust. 3. 
3. Jeżeli po przywróceniu do służby okaże się, że mimo zgłoszenia gotowości 
niezwłocznego podjęcia służby policjant nie może zostać do niej dopuszczony, gdyż 
po zwolnieniu zaistniały okoliczności powodujące niemożność jej pełnienia, stosunek 
służbowy ulega rozwiązaniu na podstawie art. 41 ust. 2 pkt 5, chyba że zaistnieje inna 
podstawa zwolnienia. 
4. Prawo do uposażenia powstaje z dniem podjęcia służby, chyba że po 
zgłoszeniu do służby zaistniały okoliczności usprawiedliwiające niepodjęcie tej 
służby. 
5. Policjantowi przywróconemu do służby przysługuje za okres pozostawania 
poza służbą świadczenie pieniężne równe uposażeniu na stanowisku zajmowanym 
przed zwolnieniem, nie więcej jednak niż za okres 6 miesięcy i nie mniej niż 
za 1 miesiąc. Takie samo świadczenie przysługuje osobie, o której mowa w ust. 3. 
6. Okres, za który policjantowi przysługuje świadczenie pieniężne, wlicza się do 
okresu służby uwzględnianego przy ustalaniu okresu, od którego zależą uprawnienia 
określone w art. 29 ust. 2, art. 52 ust. 1, art. 82 ust. 2 i 3, art. 101 ust. 1, art. 110 ust. 1, 
art. 111 ust. 1 i art. 115 ust. 1. Okresu pozostawania poza służbą, za który policjant nie 
otrzymał świadczenia, nie uważa się za przerwę w służbie w zakresie uprawnień 
uzależnionych od nieprzerwanego jej biegu. 

 
 
 
s. 155/274 
 
2025-07-03 
 
7. Przepisy ust. 1–6 stosuje się odpowiednio do policjanta zwolnionego ze służby 
na podstawie: 
1) 
art. 41 ust. 1 pkt 3, jeżeli zapadło prawomocne orzeczenie, o którym mowa w art. 
135s ust. 1 pkt 1, w postępowaniu dyscyplinarnym, które wznowiono ze względu 
na to, że prowadzone przeciwko niemu, o ten sam czyn, postępowanie karne, 
karne skarbowe lub w sprawach o wykroczenia, zostało zakończone 
prawomocnym wyrokiem uniewinniającym albo orzeczeniem o umorzeniu 
postępowania ze względu na okoliczności określone w art. 17 § 1 pkt 1 lub 2 
Kodeksu postępowania karnego albo w art. 5 § 1 pkt 1 lub 2 Kodeksu 
postępowania w sprawach o wykroczenia; 
2) 
art. 41 ust. 2 pkt 8 i 9, jeżeli postępowanie karne lub karne skarbowe zostało 
zakończone prawomocnym wyrokiem uniewinniającym albo orzeczeniem o 
umorzeniu postępowania ze względu na okoliczności określone w art. 17 § 1 pkt 
1 lub 2 Kodeksu postępowania karnego.

***
## Art. 43. {#policja-art-43}

1. Zwolnienie policjanta ze służby na podstawie art. 38 ust. 4 oraz art. 
41 ust. 1 pkt 1 i 2 oraz ust. 2 pkt 1 i 6 nie może nastąpić przed upływem 12 miesięcy 
od dnia zaprzestania służby z powodu choroby, chyba że policjant zgłosi pisemnie 
wystąpienie ze służby. 
2. (uchylony) 
3. Zwolnienie policjanta ze służby na podstawie art. 41 ust. 2 pkt 5 i 8 może 
nastąpić po zasięgnięciu opinii zakładowej organizacji związkowej reprezentującej 
policjanta. 
4. Policjant może wskazać zakładową organizację związkową, o której mowa w 
ust. 3, w terminie 3 dni od dnia doręczenia wezwania w sprawie wskazania takiej 
organizacji. 
5. Zakładowa organizacja związkowa, o której mowa w ust. 3, sporządza opinię 
w terminie 7 dni od dnia otrzymania wniosku o sporządzenie opinii. 
6. W przypadku, gdy policjant w terminie, o którym mowa w ust. 4, nie wskazał 
zakładowej organizacji związkowej albo zakładowa organizacja związkowa w 
terminie, o którym mowa w ust. 5, nie przekazała opinii, zwolnienie policjanta ze 
służby może nastąpić bez zasięgnięcia opinii zakładowej organizacji związkowej.

***
## Art. 44. {#policja-art-44}

1. Policjanta nie można zwolnić ze służby w okresie ciąży, w czasie 
urlopu 
macierzyńskiego, 
urlopu 
na 
warunkach 
urlopu 
macierzyńskiego, 

 
 
 
s. 156/274 
 
2025-07-03 
 
uzupełniającego urlopu macierzyńskiego, urlopu ojcowskiego, urlopu rodzicielskiego 
lub urlopu wychowawczego, z wyjątkiem przypadków określonych w art. 41 ust. 1 pkt 
3 i 4 oraz ust. 2 pkt 2, 3, 5 i 6. 
2. W razie zwolnienia policjanta ze służby na podstawie art. 41 ust. 2 pkt 5 i 6 w 
okresie ciąży, w czasie urlopu macierzyńskiego, urlopu na warunkach urlopu 
macierzyńskiego, uzupełniającego urlopu macierzyńskiego, urlopu ojcowskiego lub 
urlopu rodzicielskiego przysługuje mu uposażenie do końca okresu ciąży oraz trwania 
wymienionego urlopu.

***
## Art. 44a. {#policja-art-44a}

Policjantowi zwolnionemu na podstawie art. 41 ust. 2 pkt 5 i 6 w czasie 
urlopu wychowawczego przysługują do końca okresu, na który ten urlop został 
udzielony: 
1) 
świadczenie pieniężne, wypłacane na zasadach obowiązujących przy wypłacaniu 
zasiłku wychowawczego; 
2) 
inne uprawnienia przewidziane dla pracowników zwalnianych z pracy w czasie 
urlopu wychowawczego z przyczyn niedotyczących pracowników.

***
## Art. 45. {#policja-art-45}

1. Zwolnienia ze służby na podstawie art. 41 ust. 2 pkt 5 policjanta, 
którego przełożonym wymienionym w art. 32 ust. 1 jest komendant powiatowy 
(miejski, rejonowy) Policji, dokonuje właściwy komendant wojewódzki Policji albo 
Komendant Stołeczny Policji. 
2. Pozostawienie w służbie policjanta, o którym mowa w art. 41 ust. 2 pkt 2, 
którego przełożonym wymienionym w art. 32 ust. 1 jest komendant powiatowy 
(miejski, rejonowy) Policji, wymaga zgody właściwego komendanta wojewódzkiego 
Policji albo Komendanta Stołecznego Policji. 
3. W pozostałych przypadkach decyzje w sprawach, o których mowa w art. 37–
41, podejmuje przełożony wymieniony w art. 32 ust. 1.

***
## Art. 46. {#policja-art-46}

1. Policjant zwolniony ze służby otrzymuje niezwłocznie świadectwo 
służby oraz na swój wniosek opinię o służbie. 
2. Policjant może żądać sprostowania świadectwa służby oraz odwołać się do 
wyższego przełożonego od opinii o służbie w terminie 7 dni od dnia otrzymania opinii. 
3. Szczegółowe dane, które należy podać w świadectwie służby oraz w opinii o 
służbie, a także tryb wydawania i prostowania świadectw służby oraz odwoływania 
się od opinii o służbie, określa minister właściwy do spraw wewnętrznych 
w przepisach wydanych na podstawie art. 81. 

 
 
 
s. 157/274 
 
2025-07-03

***
## Art. 46a. {#policja-art-46a}

Komendant Główny Policji określa, w drodze zarządzenia, zasady 
prowadzenia przez przełożonych dokumentacji w sprawach związanych ze 
stosunkiem służbowym policjantów oraz sposób prowadzenia akt osobowych.

***
## Art. 46b. {#policja-art-46b}

1. Policja jest uprawniona do przetwarzania informacji, w tym danych 
osobowych, w zakresie niezbędnym do prowadzenia postępowań kwalifikacyjnych do 
służby w Policji, przenoszenia do służby w Policji oraz w zakresie wynikającym z 
przebiegu stosunku służbowego policjantów, także po jego ustaniu, w tym ma prawo 
przetwarzać dane osobowe, o których mowa w art. 9 i art. 10 rozporządzenia (UE) 
2016/679, z wyłączeniem danych dotyczących kodu genetycznego oraz danych 
daktyloskopijnych. 
2. Do przetwarzania danych osobowych, o których mowa w ust. 1, nie stosuje się 
art. 13 ust. 1 lit. d i e oraz art. 16 rozporządzenia (UE) 2016/679, w zakresie, w jakim 
przepisy szczególne przewidują odrębny tryb sprostowania. Zabezpieczenie 
przetwarzania danych osobowych polega co najmniej na dopuszczeniu do ich 
przetwarzania wyłącznie policjantów lub pracowników posiadających pisemne 
upoważnienie wydane przez administratora danych po pisemnym zobowiązaniu 
policjantów lub pracowników do zachowania przetwarzanych danych w poufności. 
3. Administratorem danych osobowych, o których mowa w ust. 1, w zakresie, 
w jakim przetwarza te dane, jest Komendant Główny Policji, Komendant CBŚP, 
Komendant BSWP, Komendant CBZC, Dyrektor CLKP, komendanci wojewódzcy 
Policji, Komendant Stołeczny Policji, Komendant-Rektor Akademii Policji 
w Szczytnie oraz komendanci szkół policyjnych.

