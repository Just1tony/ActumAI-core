---
id: act.policja.ch12
title: Ustawa o Policji — Rozdział 10
dz_u: Dz.U. 1990 Nr 30 poz. 179 (t.j. 2025 poz. 636, 718)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: 145a
  last: 145ga
source_pdf: D19900179Lj (1).pdf
chunking:
  strategy: by-article
  anchor_pattern: '## Art. {n}. {#policja-art-{n}}'
  hierarchy:
  - Rozdział
  - Art.
---

# Rozdział 10
a 
## Art. 145a. {#policja-art-145a}

1. Policjant może zostać delegowany do pełnienia służby poza 
granicami państwa w celu realizacji zadań określonych w art. 1 ust. 2 pkt 7 i ust. 3, w 
kontyngencie policyjnym wydzielonym do udziału w: 
1) 
misji pokojowej; 
2) 
akcji zapobiegania aktom terroryzmu lub ich skutkom; 
3) 
akcji ratowniczej i poszukiwawczej lub humanitarnej; 
4) 
szkoleniu i ćwiczeniach policyjnych; 
5) 
przedsięwzięciach reprezentacyjnych. 
2. Delegowanie do pełnienia służby poza granicami państwa oraz przedłużanie 
czasu delegowania w przypadkach wymienionych w ust. 1 pkt 1 i 2 następuje za 
pisemną zgodą policjanta.

***
## Art. 145b. {#policja-art-145b}

1. O utworzeniu i likwidacji kontyngentu policyjnego postanawia: 
1) 
Rada Ministrów – uchwałą, w przypadku, o którym mowa w art. 145a ust. 1 pkt 
1; 
2) 
minister właściwy do spraw wewnętrznych – zarządzeniem, w przypadkach, o 
których mowa w art. 145a ust. 1 pkt 2 i 3; 
3) 
Komendant Główny Policji – decyzją, w przypadkach, o których mowa w art. 
145a ust. 1 pkt 4 i 5. 
2. W uchwale, zarządzeniu lub decyzji, o których mowa w ust. 1, określa się w 
szczególności: 
1) 
nazwę kontyngentu, jego liczebność oraz czas pozostawania poza granicami 
państwa; 
2) 
cel skierowania kontyngentu, zakres jego zadań oraz obszar działania; 
3) 
system kierowania i dowodzenia kontyngentem oraz organ organizacji 
międzynarodowej, któremu kontyngent zostanie podporządkowany na czas 
operacji; 
4) 
organy administracji rządowej odpowiedzialne za współpracę z kierowniczymi 
organami właściwej organizacji międzynarodowej w zakresie kierowania 
działalnością kontyngentu wykonującego zadania poza granicami państwa; 
5) 
uzbrojenie i wyposażenie kontyngentu w środki i sprzęt specjalny; 
6) 
trasy i czas przemieszczania się kontyngentu w przypadku tranzytu. 

 
 
 
s. 255/274 
 
2025-07-03

***
## Art. 145c. {#policja-art-145c}

1. W skład kontyngentu policyjnego mogą wchodzić pracownicy 
Policji, z zastrzeżeniem ust. 2. 
2. W celu zapewnienia obsady niektórych stanowisk w kontyngencie policyjnym 
przez osoby posiadające specjalistyczne kwalifikacje można zatrudniać pracowników 
na zasadach określonych w przepisach Kodeksu pracy.

***
## Art. 145d. {#policja-art-145d}

1. Policjanci i pracownicy Policji wchodzący w skład kontyngentu 
policyjnego podlegają na terytorium państwa obcego przepisom dyscyplinarnym i 
porządkowym obowiązującym w Rzeczypospolitej Polskiej. 
2. Osoby, o których mowa w ust. 1, są obowiązane przestrzegać prawa państwa 
przyjmującego oraz wiążące Rzeczpospolitą Polską prawo międzynarodowe.

***
## Art. 145e. {#policja-art-145e}

1. Policjant w czasie delegowania do pełnienia służby w kontyngencie 
policyjnym poza granicami państwa otrzymuje uposażenie zasadnicze, dodatki do 
uposażenia i inne należności pieniężne przysługujące na ostatnio zajmowanym 
stanowisku służbowym – z uwzględnieniem powstałych w tym okresie zmian, 
mających wpływ na prawo do uposażenia i innych należności lub ich wysokość. 
2. Policjantowi, o którym mowa w ust. 1, mogą być przyznawane dodatki do 
uposażenia, świadczenia z tytułu uszczerbku na zdrowiu, podróży i przejazdów oraz 
inne należności pieniężne związane z delegowaniem, wypłacane w walucie polskiej 
lub obcej.

***
## Art. 145f. {#policja-art-145f}

Rada Ministrów określi, w drodze rozporządzenia: 
1) 
warunki otrzymywania, rodzaj waluty oraz wysokość dodatków, świadczeń i 
należności, o których mowa w art. 145e ust. 2, uwzględniając ich rodzaje i zakres 
przyznawania z uwagi na występujące zagrożenia, uciążliwość lub miejsce 
pełnienia służby oraz sprawowaną przez policjanta funkcję; 
2) 
uprawnienia i obowiązki policjantów delegowanych do pełnienia służby poza 
granicami państwa, z uwzględnieniem warunków i trybu delegowania 
policjantów, przypadków ich odwoływania przed wyznaczonym terminem oraz 
przedłużania czasu delegowania, a także przełożonych właściwych w tych 
sprawach; 
3) 
szczegółowe zasady zatrudniania w kontyngentach policyjnych pracowników, o 
których mowa w art. 145c, i ich wynagradzania, z uwzględnieniem postanowień 
zawartych w przepisach prawa pracy oraz specyfiki związanej z wykonywaniem 
pracy w kontyngencie policyjnym realizującym zadania poza granicami państwa, 

 
 
 
s. 256/274 
 
2025-07-03 
 
a w szczególności prawa do dodatku zagranicznego, świadczeń z tytułu podróży 
i przejazdów oraz innych należności pieniężnych związanych z delegowaniem, a 
także świadczeń odszkodowawczych wynikających z odrębnych ustaw; 
4) 
warunki otrzymywania świadczeń opieki zdrowotnej, o których mowa w art. 42 
ust. 2 ustawy z dnia 27 sierpnia 2004 r. o świadczeniach opieki zdrowotnej 
finansowanych ze środków publicznych (Dz. U. z 2024 r. poz. 146, z późn. 
zm.12)), przez policjantów i pracowników, o których mowa w art. 145c, w 
związku z urazami nabytymi podczas wykonywania przez nich zadań poza 
granicami państwa oraz sposób i tryb finansowania kosztów, uwzględniając 
zasady i sposób wydatkowania środków publicznych; 
5) 
szczegółowe zasady i tryb finansowania i działania kontyngentu policyjnego, w 
tym jego wyposażenia i przewozu, z uwzględnieniem przepisów o finansach 
publicznych.

***
## Art. 145g. {#policja-art-145g}

1. Wydatki związane z udziałem kontyngentów policyjnych poza 
granicami państwa finansowane są z budżetu państwa, w części ministra właściwego 
do spraw wewnętrznych. 
2. Jeżeli środki finansowe na ten cel nie zostały uwzględnione w budżecie 
ministra właściwego do spraw wewnętrznych, zapewnia je Rada Ministrów.

***
## Art. 145ga. {#policja-art-145ga}

1. Policjant delegowany do pełnienia służby poza granicami państwa 
w kontyngencie policyjnym, o którym mowa w art. 145a ust. 1 pkt 1–3, po powrocie 
do kraju podlega bezpłatnym badaniom lekarskim i psychologicznym. 
2. W przypadku odniesienia ran, kontuzji, urazu psychicznego lub schorzenia 
przez policjanta, o którym mowa w ust. 1, lub ze względu na jego stan psychofizyczny 
zgodnie ze wskazaniami lekarza policjant może być skierowany na bezpłatny turnus 
leczniczo-profilaktyczny wraz z pełnoletnim najbliższym członkiem rodziny w 
rozumieniu art. 4 pkt 12 ustawy z dnia 19 sierpnia 2011 r. o weteranach działań poza 
granicami państwa (Dz. U. z 2023 r. poz. 2112). 
3. Turnus leczniczo-profilaktyczny trwa 14 dni kalendarzowych i obejmuje 
działania leczniczo-rehabilitacyjne i profilaktykę zdrowotną, w tym profilaktykę 
psychologiczną. 
 
12) Zmiany tekstu jednolitego wymienionej ustawy zostały ogłoszone w Dz. U. z 2024 r. poz. 858, 1222, 
1593, 1615 i 1915 oraz z 2025 r. poz. 129 i 304. 

 
 
 
s. 257/274 
 
2025-07-03 
 
4. Udział policjanta w kolejnym turnusie leczniczo-profilaktycznym po pełnieniu 
służby w tym samym kontyngencie policyjnym może odbyć się pod warunkiem 
poddania się leczeniu specjalistycznemu, ambulatoryjnemu lub stacjonarnemu albo 
konsultacji specjalistycznej zakończonej wskazaniem uczestnictwa w turnusie 
leczniczo-profilaktycznym jako niezbędnym do kontynuacji leczenia. 
5. Osoby skierowane na turnus leczniczo-profilaktyczny mogą skorzystać z 
prawa do turnusu leczniczo-profilaktycznego w trakcie pełnienia służby przez 
policjanta. 
6. Pełne koszty uczestnictwa w turnusie leczniczo-profilaktycznym policjanta 
oraz 50 % kosztów uczestnictwa pełnoletniego najbliższego członka rodziny pokrywa 
się z budżetu państwa z części pozostającej w dyspozycji ministra właściwego do 
spraw wewnętrznych. 
7. Skierowanie na badania, o których mowa w ust. 1, zawiera następujące dane 
policjanta: 
1) 
imię i nazwisko; 
2) 
numer PESEL; 
3) 
miejsce zamieszkania; 
4) 
miejsce pełnienia służby; 
5) 
okres delegowania, miejsce, stanowisko i zakres zadań wykonanych podczas 
służby w kontyngencie. 
8. Skierowanie na turnus leczniczo-profilaktyczny zawiera następujące dane: 
1) 
policjanta: 
a) 
imię i nazwisko, 
b) 
numer PESEL, 
c) 
miejsce zamieszkania, 
d) 
miejsce pełnienia służby; 
2) 
pełnoletniego najbliższego członka rodziny: 
a) 
imię i nazwisko, 
b) 
datę urodzenia, 
c) 
stopień pokrewieństwa. 
9. Przepisy ust. 1–8 stosuje się odpowiednio do pracowników Policji, o których 
mowa w art. 145c ust. 1. 
10. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia: 

 
 
 
s. 258/274 
 
2025-07-03 
 
1) 
organ właściwy do kierowania policjanta i pracownika Policji na badania, o 
których mowa w ust. 1, 
2) 
zakres badań, o których mowa w ust. 1, 
3) 
podmiot właściwy do przeprowadzania badań, o których mowa w ust. 1, 
4) 
rodzaje i wzory dokumentów wystawianych po przeprowadzeniu badań, o 
których mowa w ust. 1, 
5) 
tryb kierowania policjanta i pracownika Policji, wraz z pełnoletnim najbliższym 
członkiem rodziny, na turnus leczniczo-profilaktyczny, 
6) 
podmiot kierujący na turnus leczniczo-profilaktyczny, 
7) 
ramowy program turnusu leczniczo-profilaktycznego, 
8) 
podmiot prowadzący turnus leczniczo-profilaktyczny, 
9) 
rodzaje i wzory dokumentów wystawianych w związku z kierowaniem na turnus 
leczniczo-profilaktyczny 
– uwzględniając potrzeby policjanta i pracownika Policji wynikające z ich aktualnego 
stanu zdrowia, w tym konieczność zapewnienia ich pełnej rekonwalescencji oraz 
umożliwienie im dalszego leczenia lub rehabilitacji po zakończeniu pobytu na turnusie 
leczniczo-profilaktycznym.

