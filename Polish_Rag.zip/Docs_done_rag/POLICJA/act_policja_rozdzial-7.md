---
id: act.policja.ch7
title: Ustawa o Policji — Rozdział 6
dz_u: Dz.U. 1990 Nr 30 poz. 179 (t.j. 2025 poz. 636, 718)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '47'
  last: '57'
source_pdf: D19900179Lj (1).pdf
chunking:
  strategy: by-article
  anchor_pattern: '## Art. {n}. {#policja-art-{n}}'
  hierarchy:
  - Rozdział
  - Art.
---

# Rozdział 6
 
## Art. 47. {#policja-art-47}

1. Ustanawia się korpusy Policji i stopnie policyjne w następującym 
porządku: 
1) 
w korpusie generałów Policji: 
a) 
generalny inspektor Policji, 
b) 
nadinspektor Policji; 
2) 
w korpusie oficerów starszych Policji: 
a) 
inspektor Policji, 
b) 
młodszy inspektor Policji, 
c) 
podinspektor Policji; 

 
 
 
s. 158/274 
 
2025-07-03 
 
3) 
w korpusie oficerów młodszych Policji: 
a) 
nadkomisarz Policji, 
b) 
komisarz Policji, 
c) 
podkomisarz Policji; 
4) 
w korpusie aspirantów Policji: 
a) 
aspirant sztabowy Policji, 
b) 
starszy aspirant Policji, 
c) 
aspirant Policji, 
d) 
młodszy aspirant Policji; 
5) 
w korpusie podoficerów Policji: 
a) 
sierżant sztabowy Policji, 
b) 
starszy sierżant Policji, 
c) 
sierżant Policji; 
6) 
w korpusie szeregowych Policji: 
a) 
starszy posterunkowy, 
b) 
posterunkowy. 
2. Rada Ministrów określi, w drodze rozporządzenia, jakie stopnie wojskowe, 
Straży Granicznej, Straży Marszałkowskiej, Biura Ochrony Rządu, Służby Ochrony 
Państwa, Służby Celnej, Służby Celno-Skarbowej, Państwowej Straży Pożarnej, 
Urzędu Ochrony Państwa, Agencji Bezpieczeństwa Wewnętrznego, Agencji 
Wywiadu, Służby Wywiadu Wojskowego, Służby Kontrwywiadu Wojskowego lub 
Służby Więziennej odpowiadają poszczególnym stopniom policyjnym, mając na 
względzie zapewnienie równorzędności tych stopni w poszczególnych korpusach.

***
## Art. 48. {#policja-art-48}

1. Na stopnie policyjne w korpusach szeregowych i podoficerów Policji 
mianuje przełożony, o którym mowa w art. 32 ust. 1. Na stopień posterunkowego 
mianuje się z dniem mianowania na stanowisko służbowe. 
2. Na stopnie policyjne w korpusie aspirantów Policji, a także na stopnie 
komisarza i nadkomisarza Policji mianuje przełożony, o którym mowa w art. 32 ust. 
1, z wyjątkiem komendanta powiatowego (miejskiego, rejonowego) Policji. 
3. Na pierwszy stopień oficerski, z zastrzeżeniem art. 56 ust. 3, oraz na stopnie 
generalnego 
inspektora 
Policji 
i nadinspektora 
Policji 
mianuje 
Prezydent 
Rzeczypospolitej Polskiej na wniosek ministra właściwego do spraw wewnętrznych. 
Na pozostałe stopnie oficerskie w służbie spraw wewnętrznych mianuje minister 

 
 
 
s. 159/274 
 
2025-07-03 
 
właściwy do spraw wewnętrznych. Natomiast na pozostałe stopnie oficerskie mianuje 
Komendant Główny Policji. 
4. Mianowanie policjanta na stopień policyjny następuje na wniosek 
bezpośredniego przełożonego składany do przełożonego właściwego do mianowania 
na stopień policyjny za pośrednictwem komórki organizacyjnej Policji właściwej 
w sprawach osobowych. 
5. W przypadku powzięcia wiarygodnych, należycie uzasadnionych informacji 
podważających opinię, o której mowa w art. 25 ust. 1, lub ujawnienia co najmniej 
jednej z okoliczności, o których mowa w art. 34 ust. 4, składający wniosek 
o mianowanie niezwłocznie informuje o tym przełożonego właściwego do 
mianowania na stopień policyjny objęty tym wnioskiem. 
6. Policjantowi mianowanemu na stopień policyjny wręcza się akt mianowania.

***
## Art. 49. {#policja-art-49}

1. Na pierwszy stopień policyjny w korpusie podoficerów Policji może 
być mianowany policjant, który spełnia warunki określone w art. 25 ust. 1, uzyskał 
kwalifikacje zawodowe podoficerskie i został mianowany albo powołany 
na stanowisko służbowe, dla którego określono policyjny stopień etatowy w 
korpusach podoficerów, aspirantów lub oficerów Policji. 
2. Na pierwszy stopień policyjny w korpusie aspirantów Policji może być 
mianowany policjant, który spełnia warunki określone w art. 25 ust. 1, uzyskał 
kwalifikacje zawodowe aspiranckie i został mianowany albo powołany na stanowisko 
służbowe, dla którego określono policyjny stopień etatowy w korpusach aspirantów 
lub oficerów Policji.

***
## Art. 50. {#policja-art-50}

Na pierwszy stopień policyjny w korpusie oficerów młodszych Policji 
może być mianowany policjant, który spełnia warunki określone w art. 25 ust. 1, 
uzyskał kwalifikacje zawodowe oficerskie i został mianowany albo powołany 
na stanowisko służbowe, dla którego określono policyjny stopień etatowy w korpusie 
oficerów Policji.

***
## Art. 50a. {#policja-art-50a}

W przypadku planowanego przedterminowego mianowania na stopnie 
policyjne w korpusie oficerów młodszych Policji i korpusie oficerów starszych Policji 
właściwy przełożony może wystąpić do Inspektora Nadzoru Wewnętrznego o 
dokonanie weryfikacji, o której mowa w art. 11a ust. 3 pkt 2 ustawy z dnia 21 czerwca 
1996 r. o szczególnych formach sprawowania nadzoru przez ministra właściwego do 
spraw wewnętrznych. 

 
 
 
s. 160/274 
 
2025-07-03

***
## Art. 51. {#policja-art-51}

(uchylony)

***
## Art. 52. {#policja-art-52}

1. Mianowanie na kolejny wyższy stopień następuje stosownie do 
zajmowanego stanowiska służbowego oraz w zależności od opinii służbowej. Nadanie 
tego stopnia nie może jednak nastąpić wcześniej niż po przesłużeniu w 
dotychczasowym stopniu: 
– posterunkowego       – 1 roku, 
– starszego posterunkowego – 1 roku, 
– sierżanta           – 2 lat, 
– starszego sierżanta      – 2 lat, 
– sierżanta sztabowego    – 2 lat, 
– młodszego aspiranta     – 3 lat, 
– aspiranta           – 3 lat, 
– starszego aspiranta      – 2 lat, 
– aspiranta sztabowego    – 4 lat, 
– podkomisarza         – 3 lat, 
– komisarza           – 4 lat, 
– nadkomisarza         – 4 lat, 
– podinspektora        – 3 lat, 
– młodszego inspektora    – 4 lat, 
– inspektora           – 4 lat. 
1a. W szczególnie uzasadnionych przypadkach Prezydent Rzeczypospolitej 
Polskiej, na wniosek ministra właściwego do spraw wewnętrznych, może mianować 
inspektora Policji na stopień nadinspektora Policji z pominięciem wymogu 
przesłużenia w dotychczasowym stopniu okresu, o którym mowa w ust. 1 tiret 
piętnaste. 
2. (uchylony) 
3. W szczególnie uzasadnionych przypadkach minister właściwy do spraw 
wewnętrznych, na wniosek Komendanta Głównego Policji, może mianować każdego 
policjanta na wyższy stopień, z uwzględnieniem ograniczeń wynikających 
z przepisów art. 48 oraz art. 49 i art. 50. 
4. W szczególnie uzasadnionych przypadkach: 

 
 
 
s. 161/274 
 
2025-07-03 
 
1) 
Prezydent Rzeczypospolitej Polskiej, na wniosek ministra właściwego do spraw 
wewnętrznych, może mianować na pierwszy stopień oficerski oraz na stopnie 
generalnego inspektora Policji i nadinspektora Policji, 
2) 
Komendant Główny Policji może mianować na pozostałe stopnie policyjne 
– policjanta, który poniósł śmierć w związku z wykonywaniem czynności służbowych.

***
## Art. 53. {#policja-art-53}

1. Stopnie określone w art. 47 są dożywotnie. 
2. Policjanci zwolnieni ze służby mogą używać posiadanych stopni, o których 
mowa w art. 47, z dodaniem określenia „w stanie spoczynku”. 
3. Utrata stopnia wymienionego w art. 47 następuje w razie: 
1) 
utraty obywatelstwa polskiego lub 
2) 
orzeczenia prawomocnym wyrokiem sądu środka karnego pozbawienia praw 
publicznych albo 
3) 
skazania prawomocnym wyrokiem sądu na karę pozbawienia wolności za 
przestępstwo popełnione w wyniku motywacji zasługującej na szczególne 
potępienie.

***
## Art. 54. {#policja-art-54}

1. O obniżeniu stopnia decyduje przełożony właściwy do mianowania 
na ten stopień. 
2. O pozbawieniu stopnia oficerskiego decyduje Komendant Główny Policji. 
3. O obniżeniu stopnia lub pozbawieniu stopni generalnego inspektora i 
nadinspektora Policji decyduje Prezydent Rzeczypospolitej Polskiej na wniosek 
ministra właściwego do spraw wewnętrznych.

***
## Art. 55. {#policja-art-55}

1. Policjantowi przywraca się stopień w razie uchylenia: 
1) 
orzeczenia prawomocnym wyrokiem sądu środka karnego pozbawienia praw 
publicznych lub 
2) 
prawomocnego skazania na karę pozbawienia wolności za przestępstwo 
popełnione w wyniku motywacji zasługującej na szczególne potępienie albo 
3) 
decyzji, na podstawie której nastąpiło pozbawienie stopnia, albo 
4) 
kary dyscyplinarnej obniżenia stopnia. 
2. Decyzję o przywróceniu stopnia oficerskiego podejmuje Komendant Główny 
Policji. W pozostałych przypadkach decyzję o przywróceniu stopnia podejmuje 
przełożony właściwy do mianowania na ten stopień.

***
## Art. 56. {#policja-art-56}

1. Osobę przyjmowaną do służby w Policji i posiadającą stopień 
wojskowy, stopień Straży Granicznej, Straży Marszałkowskiej, Biura Ochrony Rządu, 

 
 
 
s. 162/274 
 
2025-07-03 
 
Służby Ochrony Państwa, Służby Celnej, Służby Celno-Skarbowej, Państwowej 
Straży Pożarnej, Urzędu Ochrony Państwa, Agencji Bezpieczeństwa Wewnętrznego, 
Agencji Wywiadu, Służby Wywiadu Wojskowego, Służby Kontrwywiadu 
Wojskowego lub Służby Więziennej mianuje się na odpowiedni stopień policyjny. 
2. Mianowanie, o którym mowa w ust. 1, jest uzależnione od uzyskania 
kwalifikacji zawodowych, o których mowa w art. 34 ust. 2 pkt 1. 
3. Przy przyjmowaniu do służby osoby posiadającej stopień odpowiadający 
stopniowi podkomisarza Policji na pierwszy stopień oficerski mianuje Komendant 
Główny Policji. 
4. Funkcjonariusza przenoszonego do służby w Policji na podstawie art. 25a ust. 
1, posiadającego stopień Straży Granicznej, Straży Marszałkowskiej, Służby Ochrony 
Państwa, 
Służby 
Celno-Skarbowej, 
Państwowej 
Straży 
Pożarnej, 
Agencji 
Bezpieczeństwa Wewnętrznego, Agencji Wywiadu, Służby Wywiadu Wojskowego 
lub Służby Kontrwywiadu Wojskowego, mianuje się na odpowiedni stopień policyjny.

***
## Art. 57. {#policja-art-57}

Minister właściwy do spraw wewnętrznych określi, w drodze 
rozporządzenia, terminy mianowania policjantów na stopnie policyjne, wzory 
wniosku o mianowanie na stopień policyjny i aktu mianowania na stopień policyjny, 
a także tryb ich sporządzania oraz przełożonych właściwych w tych sprawach, mając 
na uwadze konieczność zachowania właściwego trybu mianowania policjantów na 
stopnie policyjne i jego dokumentowania.

