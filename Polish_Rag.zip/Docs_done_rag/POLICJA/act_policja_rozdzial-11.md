---
id: act.policja.ch11
title: Ustawa o Policji — Rozdział 10
dz_u: Dz.U. 1990 Nr 30 poz. 179 (t.j. 2025 poz. 636, 718)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '132'
  last: '145'
source_pdf: D19900179Lj (1).pdf
chunking:
  strategy: by-article
  anchor_pattern: '## Art. {n}. {#policja-art-{n}}'
  hierarchy:
  - Rozdział
  - Art.
---

# Rozdział 10
 
## Art. 132. {#policja-art-132}

1. Policjant odpowiada dyscyplinarnie za popełnienie przewinienia 
dyscyplinarnego 
polegającego 
na 
naruszeniu 
dyscypliny 
służbowej 
lub 
nieprzestrzeganiu zasad etyki zawodowej. 
2. Naruszenie dyscypliny służbowej stanowi czyn policjanta polegający na 
zawinionym przekroczeniu uprawnień lub niewykonaniu obowiązków wynikających 
z przepisów prawa lub rozkazów i poleceń wydanych przez przełożonych upraw-
nionych na podstawie tych przepisów. 
3. Naruszeniem dyscypliny służbowej jest w szczególności: 
1) 
niedopełnienie obowiązków policjanta wynikających ze złożonego ślubowania, 
a także przepisów prawa; 

 
 
 
s. 224/274 
 
2025-07-03 
 
2) 
odmowa wykonania lub niewykonanie rozkazu lub polecenia, z zastrzeżeniem 
przypadku określonego w art. 58 ust. 2; 
3) 
zaniechanie czynności służbowej albo wykonanie jej w sposób nieprawidłowy; 
4) 
niedopełnienie obowiązków służbowych albo przekroczenie uprawnień 
określonych w przepisach prawa; 
5) 
wprowadzenie w błąd przełożonego lub innego policjanta, jeżeli spowodowało 
to lub mogło spowodować szkodę służbie, policjantowi lub innej osobie; 
6) 
nadużycie zajmowanego stanowiska dla osiągnięcia korzyści majątkowej lub 
osobistej; 
7) 
postępowanie przełożonego w sposób przyczyniający się do rozluźnienia 
dyscypliny służbowej w podległej jednostce organizacyjnej lub komórce 
organizacyjnej Policji; 
8) 
porzucenie służby; 
9) 
samowolne oddalenie się z rejonu zakwaterowania lub nieusprawiedliwione 
opuszczenie miejsca pełnienia służby lub niestawienie się w tym miejscu; 
10) stawienie się do służby w stanie nietrzeźwości albo po użyciu alkoholu lub po 
użyciu podobnie działającego środka, pełnienie jej w takim stanie, a także 
spożywanie alkoholu lub używanie podobnie działającego środka w czasie 
służby; 
11) umyślne naruszenie dóbr osobistych innego policjanta; 
12) utrata służbowej broni palnej, amunicji lub legitymacji służbowej; 
13) utrata przedmiotu stanowiącego wyposażenie służbowe, którego wykorzystanie 
przez osoby nieuprawnione wyrządziło szkodę innej osobie lub stworzyło 
zagrożenie dla porządku publicznego lub bezpieczeństwa powszechnego; 
14) ujawnienie informacji pozostającej w związku z wykonywaniem czynności 
służbowych, jeżeli spowodowało to lub mogło spowodować szkodę służbie. 
4. Czyn stanowiący przewinienie dyscyplinarne, wypełniający jednocześnie 
znamiona przestępstwa lub wykroczenia albo przestępstwa skarbowego lub 
wykroczenia skarbowego, podlega odpowiedzialności dyscyplinarnej niezależnie od 
odpowiedzialności karnej. 
4a. 
W 
przypadku 
czynu 
stanowiącego 
przewinienie 
dyscyplinarne, 
wypełniającego jednocześnie znamiona wykroczenia, w przypadku mniejszej wagi lub 
ukarania grzywną, przełożony dyscyplinarny może nie wszczynać postępowania 
dyscyplinarnego, a wszczęte umorzyć. 

 
 
 
s. 225/274 
 
2025-07-03 
 
4b. W przypadku czynu stanowiącego przewinienie dyscyplinarne mniejszej 
wagi przełożony dyscyplinarny może odstąpić od wszczęcia postępowania i 
przeprowadzić ze sprawcą przewinienia dyscyplinarnego udokumentowaną w formie 
notatki rozmowę dyscyplinującą. 
4ba. Rozmowę dyscyplinującą, o której mowa w ust. 4b, można przeprowadzić 
w terminie do 30 dni od dnia powzięcia przez przełożonego dyscyplinarnego 
wiadomości o popełnieniu przewinienia dyscyplinarnego. Rozmowa ta polega na 
wytknięciu policjantowi niewłaściwego postępowania oraz uprzedzeniu go o 
możliwości zastosowania innych środków dyscyplinujących, a także wszczęcia 
postępowania i wymierzenia kary dyscyplinarnej w przypadku ponownego 
popełnienia czynu, za który policjant ponosi odpowiedzialność dyscyplinarną. 
4c. Notatkę, o której mowa w ust. 4b, włącza się do akt osobowych na okres 5 
miesięcy. 
4d. W terminie 5 dni od dnia przeprowadzenia rozmowy dyscyplinującej sprawca 
przewinienia 
dyscyplinarnego 
może 
złożyć 
sprzeciw 
do 
przełożonego 
dyscyplinarnego. 
Złożenie 
sprzeciwu 
skutkuje 
wszczęciem 
postępowania 
dyscyplinarnego, a zebrane dotychczas materiały stają się materiałami postępowania 
dyscyplinarnego. 
4e. Rozmowę dyscyplinującą przeprowadza przełożony dyscyplinarny. W 
uzasadnionym przypadku przełożony dyscyplinarny może na piśmie upoważnić do 
przeprowadzenia w jego imieniu rozmowy dyscyplinującej policjanta w stopniu nie 
niższym od stopnia posiadanego przez policjanta, z którym rozmowa dyscyplinująca 
ma być prowadzona, lub zajmującego co najmniej równorzędne z tym policjantem 
stanowisko służbowe. 
4f. Upoważnienie do przeprowadzenia rozmowy dyscyplinującej zawiera: 
1) 
podstawę prawną; 
2) 
stopień, imię, nazwisko i stanowisko służbowe upoważnionego policjanta; 
3) 
stopień, imię, nazwisko i stanowisko służbowe policjanta, z którym ma być 
prowadzona rozmowa dyscyplinująca; 
4) 
określenie czynu, w związku z którym rozmowa dyscyplinująca ma być 
prowadzona, wraz z jego kwalifikacją prawną; 
5) 
określenie przesłanek, jakie spowodowały podjęcie przez przełożonego 
dyscyplinarnego rozstrzygnięcia o przeprowadzeniu w danym przypadku 
rozmowy dyscyplinującej; 

 
 
 
s. 226/274 
 
2025-07-03 
 
6) 
określenie terminu, w jakim przeprowadza się rozmowę dyscyplinującą.

***
## Art. 132a. {#policja-art-132a}

Przewinienie dyscyplinarne jest zawinione wtedy, gdy policjant: 
1) 
ma zamiar jego popełnienia, to jest chce je popełnić albo przewidując możliwość 
jego popełnienia, na to się godzi; 
2) 
nie mając zamiaru jego popełnienia, popełnia je jednak na skutek niezachowania 
ostrożności wymaganej w danych okolicznościach, mimo że możliwość taką 
przewidywał albo mógł i powinien przewidzieć.

***
## Art. 132b. {#policja-art-132b}

1. Policjant odpowiada dyscyplinarnie, jeżeli popełnia przewinienie 
dyscyplinarne sam albo wspólnie i w porozumieniu z inną osobą, a także w przypadku 
gdy kieruje popełnieniem przez innego policjanta przewinienia dyscyplinarnego albo 
poleca jego popełnienie. 
2. Policjant odpowiada dyscyplinarnie także wówczas, gdy chcąc, aby inny 
policjant popełnił przewinienie dyscyplinarne, nakłania go do tego. 
3. Policjant odpowiada dyscyplinarnie w przypadku, gdy chcąc, aby inny 
policjant popełnił przewinienie dyscyplinarne lub godząc się na to, swoim 
zachowaniem ułatwia jego popełnienie. 
4. Każdy z policjantów, o których mowa w ust. 1–3, odpowiada w granicach 
swojej winy, niezależnie od odpowiedzialności pozostałych osób. 
5. 
Policjant 
odpowiada 
dyscyplinarnie 
za 
popełnienie 
przewinienia 
dyscyplinarnego za granicą.

***
## Art. 132c. {#policja-art-132c}

Dwa lub więcej zachowań podjętych w krótkich odstępach czasu w 
celu wykonania tego samego zamiaru lub z wykorzystaniem takiej samej sposobności 
uważa się za jedno przewinienie dyscyplinarne.

***
## Art. 133. {#policja-art-133}

1. Przełożonym dyscyplinarnym jest przełożony, o którym mowa w art. 
32 ust. 1. Taką samą władzę dyscyplinarną posiada policjant, któremu powierzono 
pełnienie obowiązków na stanowisku służbowym, o którym mowa w art. 32 ust. 1. 
2. Przełożonym dyscyplinarnym policjanta delegowanego do czasowego 
pełnienia służby lub policjanta, któremu powierzono pełnienie obowiązków 
służbowych albo którego skierowano na szkolenie zawodowe, doskonalenie 
zawodowe centralne lub studia w Akademii Policji w Szczytnie, jest przełożony 
dyscyplinarny w miejscu pełnienia służby, odbywania szkolenia, doskonalenia lub 
studiów, z wyłączeniem możliwości orzekania kar dyscyplinarnych określonych 
w art. 134 pkt 3–7, które wymierza przełożony, o którym mowa w art. 32 ust. 1. 

 
 
 
s. 227/274 
 
2025-07-03 
 
3. Przełożonym dyscyplinarnym policjanta delegowanego do pełnienia służby 
poza granicami państwa jest dowódca kontyngentu policyjnego, w którym policjant 
pełni służbę, z wyłączeniem możliwości orzekania kar określonych w art. 134 pkt 3–
7, które wymierza przełożony, o którym mowa w art. 32 ust. 1. 
3a. Przełożonym dyscyplinarnym policjanta oddelegowanego do pełnienia 
służby w Biurze Nadzoru Wewnętrznego jest Inspektor Nadzoru Wewnętrznego, z 
wyłączeniem możliwości orzekania kar określonych w art. 134 pkt 3–7, które 
wymierza przełożony, o którym mowa w art. 32 ust. 1. Przepisy art. 135d ust. 2, art. 
135h ust. 2, art. 135k ust. 4, art. 135r ust. 9 oraz art. 135s ust. 5 stosuje się 
odpowiednio. 
3b. Przełożonym dyscyplinarnym Komendanta Głównego Policji, Komendanta 
BSWP i jego zastępców jest minister właściwy do spraw wewnętrznych. Przepisy art. 
135d ust. 2, art. 135h ust. 2, art. 135k ust. 4, art. 135r ust. 9 oraz art. 135s ust. 5 stosuje 
się odpowiednio. 
4. W przypadku przeniesienia policjanta do pełnienia służby w innej jednostce 
organizacyjnej Policji i związanej z tym zmiany właściwości przełożonego 
dyscyplinarnego, postępowanie dyscyplinarne wszczęte wobec policjanta przejmuje 
i orzeka w pierwszej instancji nowy przełożony dyscyplinarny. 
5. Policjant oddelegowany do pełnienia zadań służbowych poza Policją podlega 
władzy dyscyplinarnej przełożonego, o którym mowa w art. 32 ust. 1. 
6. Przełożony dyscyplinarny może w formie pisemnej upoważnić swoich 
zastępców lub innych policjantów z kierowanej przez niego jednostki organizacyjnej 
Policji do załatwiania spraw dyscyplinarnych w jego imieniu w ustalonym zakresie. 
7. Wątpliwości w zakresie ustalenia właściwości przełożonego w sprawach 
dyscyplinarnych 
rozstrzyga 
wyższy 
przełożony 
dyscyplinarny 
w 
drodze 
postanowienia. 
8. Wyższymi przełożonymi dyscyplinarnymi w postępowaniu dyscyplinarnym 
są: 
1) 
komendant wojewódzki Policji – w stosunku do komendanta powiatowego 
(miejskiego) Policji; 
2) 
Komendant Stołeczny Policji – w stosunku do komendanta powiatowego 
(miejskiego) i rejonowego Policji; 
3) 
Komendant Główny Policji – w stosunku do Komendanta CBŚP, Komendanta 
CBZC, Dyrektora CLKP, komendanta wojewódzkiego Policji, Komendanta 

 
 
 
s. 228/274 
 
2025-07-03 
 
Stołecznego Policji, komendanta szkoły policyjnej, dowódcy kontyngentu 
policyjnego oraz policjantów, których przełożonym dyscyplinarnym jest 
Komendant BSWP albo Komendant-Rektor Akademii Policji w Szczytnie.

***
## Art. 134. {#policja-art-134}

Karami dyscyplinarnymi są: 
1) 
upomnienie; 
2) 
nagana; 
3) 
ostrzeżenie o niepełnej przydatności do służby na zajmowanym stanowisku; 
4) 
wyznaczenie na niższe stanowisko służbowe; 
5) 
obniżenie stopnia; 
6) 
ostrzeżenie o niepełnej przydatności do służby; 
7) 
wydalenie ze służby.

***
## Art. 134a. {#policja-art-134a}

Kara upomnienia i kara nagany oznaczają wytknięcie ukaranemu 
przez przełożonego dyscyplinarnego niewłaściwego postępowania.

***
## Art. 134b. {#policja-art-134b}

(uchylony)

***
## Art. 134c. {#policja-art-134c}

Kara ostrzeżenia o niepełnej przydatności do służby na zajmowanym 
stanowisku oznacza wytknięcie ukaranemu niewłaściwego postępowania i 
uprzedzenie go, że jeżeli ponownie popełni przewinienie dyscyplinarne, zostanie 
wyznaczony na niższe stanowisko służbowe lub ukarany surowszą karą dyscyplinarną.

***
## Art. 134d. {#policja-art-134d}

1. Kara wyznaczenia na niższe stanowisko służbowe oznacza 
odwołanie lub zwolnienie z dotychczas zajmowanego stanowiska służbowego i 
powołanie lub mianowanie na stanowisko służbowe niższe od dotychczas 
zajmowanego. Wymierzenie kary wyznaczenia na niższe stanowisko służbowe 
powoduje utratę uprawnień, o których mowa w art. 6e ust. 3 i art. 103 ust. 2. 
2. Przed zatarciem kary wyznaczenia na niższe stanowisko służbowe policjanta 
nie można powołać lub mianować na wyższe stanowisko służbowe.

***
## Art. 134e. {#policja-art-134e}

1. Kara obniżenia stopnia oznacza obniżenie posiadanego stopnia 
policyjnego. 
2. Karę obniżenia stopnia można wymierzyć tylko obok kary wyznaczenia na 
niższe stanowisko służbowe, kary ostrzeżenia o niepełnej przydatności do służby albo 
kary wydalenia ze służby. 

 
 
 
s. 229/274 
 
2025-07-03

***
## Art. 134ea. {#policja-art-134ea}

Kara ostrzeżenia o niepełnej przydatności do służby oznacza 
wytknięcie ukaranemu niewłaściwego postępowania i uprzedzenie go, że jeżeli 
ponownie popełni przewinienie dyscyplinarne, zostanie wydalony ze służby.

***
## Art. 134f. {#policja-art-134f}

Kara wydalenia ze służby oznacza zwolnienie ze służby w Policji.

***
## Art. 134g. {#policja-art-134g}

1. Za popełnione przewinienie dyscyplinarne można wymierzyć tylko 
jedną karę dyscyplinarną. 
2. Za popełnienie kilku przewinień dyscyplinarnych można wymierzyć jedną 
karę dyscyplinarną, odpowiednio surowszą. 
3. Przepisy ust. 1 i 2 stosuje się z zastrzeżeniem art. 134e ust. 2.

***
## Art. 134h. {#policja-art-134h}

1. Obwinionemu wymierza się karę dyscyplinarną współmierną do 
popełnionego przewinienia dyscyplinarnego oraz stopnia zawinienia. 
1a. Przy wymierzaniu kary dyscyplinarnej uwzględnia się okoliczności 
popełnienia przewinienia dyscyplinarnego, jego skutki, w tym następstwa negatywne 
dla służby, rodzaj i stopień naruszenia ciążących na obwinionym obowiązków, 
pobudki działania, zachowanie obwinionego przed popełnieniem przewinienia 
dyscyplinarnego i po jego popełnieniu, dotychczasowy przebieg służby, opinię 
służbową, okres pozostawania w służbie, a także istotne w sprawie okoliczności, 
zarówno łagodzące, jak i obciążające. 
2. Na zaostrzenie wymiaru kary mają wpływ następujące okoliczności 
popełnienia przewinienia dyscyplinarnego: 
1) 
działanie z motywacji zasługującej na szczególne potępienie, w stanie 
nietrzeźwości albo w stanie po użyciu alkoholu lub podobnie działającego 
środka; 
2) 
popełnienie przewinienia dyscyplinarnego przez policjanta przed zatarciem 
wymierzonej mu kary dyscyplinarnej; 
3) 
poważne skutki przewinienia dyscyplinarnego, zwłaszcza istotne zakłócenie 
realizacji zadań Policji lub naruszenia dobrego imienia Policji; 
4) 
działanie w obecności podwładnego, wspólnie z nim lub na jego szkodę. 
3. Na złagodzenie wymiaru kary mają wpływ następujące okoliczności 
popełnienia przewinienia dyscyplinarnego: 
1) 
nieumyślność jego popełnienia; 
2) 
podjęcie przez policjanta starań o zmniejszenie jego skutków; 

 
 
 
s. 230/274 
 
2025-07-03 
 
3) 
brak należytego doświadczenia zawodowego lub dostatecznych umiejętności 
zawodowych; 
4) 
dobrowolne poinformowanie przełożonego dyscyplinarnego o popełnieniu 
przewinienia dyscyplinarnego przed wszczęciem postępowania dyscyplinarnego. 
4. Przełożony dyscyplinarny uwzględnia okoliczności, o których mowa w ust. 1–
3, wyłącznie w stosunku do policjanta, którego one dotyczą.

***
## Art. 134ha. {#policja-art-134ha}

1. Podstawę wszelkich rozstrzygnięć w postępowaniach 
dyscyplinarnych stanowią ustalenia faktyczne. 
2. Przełożony dyscyplinarny i rzecznik dyscyplinarny kształtują swoje 
przekonanie na podstawie wszystkich przeprowadzonych dowodów, ocenianych 
swobodnie, z uwzględnieniem zasad prawidłowego rozumowania oraz wskazań 
wiedzy i doświadczenia życiowego. 
3. Przełożony dyscyplinarny i rzecznik dyscyplinarny rozstrzygają samodzielnie 
zagadnienia faktyczne i prawne oraz nie są związani rozstrzygnięciem sądu lub innego 
organu. Prawomocne rozstrzygnięcia sądu kształtujące prawo lub stosunek prawny są 
jednak wiążące.

***
## Art. 134i. {#policja-art-134i}

1. Przełożony dyscyplinarny, jeżeli zachodzi uzasadnione 
przypuszczenie popełnienia przez policjanta przewinienia dyscyplinarnego: 
1) 
wszczyna postępowanie dyscyplinarne: 
a) 
z własnej inicjatywy, 
b) 
na wniosek bezpośredniego przełożonego policjanta, 
c) 
na polecenie wyższego przełożonego, 
d) 
na żądanie sądu lub prokuratora, 
e) 
wskutek złożenia sprzeciwu, o którym mowa w art. 132 ust. 4d; 
2) 
może wszcząć postępowanie dyscyplinarne na wniosek innego zainteresowanego 
organu, instytucji lub pokrzywdzonego. 
1a. 
Wszczęcie 
postępowania 
dyscyplinarnego 
następuje 
w 
drodze 
postanowienia, którego odpis niezwłocznie doręcza się obwinionemu. 
1b. Pokrzywdzonym jest osoba, której dobro prawne zostało bezpośrednio 
naruszone przez przewinienie dyscyplinarne. 
2. Wyższy przełożony dyscyplinarny lub Komendant Główny Policji mogą 
wszcząć lub przejąć do prowadzenia postępowanie dyscyplinarne przed wydaniem 
orzeczenia, jeżeli w jego ocenie jest to konieczne z uwagi na charakter sprawy. 

 
 
 
s. 231/274 
 
2025-07-03 
 
3. W przypadku, o którym mowa w ust. 1 pkt 1 lit. d i pkt 2, przełożony 
dyscyplinarny lub Komendant Główny Policji zawiadamiają odpowiednio sąd lub 
prokuratora oraz organ lub instytucję albo pokrzywdzonego o wszczęciu postępowania 
dyscyplinarnego i wyniku tego postępowania. Materiały przekazane przez sąd, 
prokuratora, organ, instytucję albo pokrzywdzonego włącza się do akt postępowania 
dyscyplinarnego. 
4. Jeżeli zachodzą wątpliwości co do popełnienia przewinienia dyscyplinarnego, 
jego kwalifikacji prawnej albo tożsamości sprawcy, przed wszczęciem postępowania 
dyscyplinarnego przełożony dyscyplinarny zleca przeprowadzenie czynności 
wyjaśniających. Czynności te należy ukończyć w terminie 30 dni. W szczególnych 
przypadkach ze względu na charakter sprawy czynności wyjaśniające za zgodą 
przełożonego właściwego w sprawach dyscyplinarnych mogą być kontynuowane w 
terminie nie dłuższym niż 60 dni od dnia wydania postanowienia, o którym mowa w 
ust. 4a. 
4a. Rozpoczęcie czynności wyjaśniających następuje w drodze postanowienia. 
4b. Postanowienie, o którym mowa w ust. 4a, zawiera: 
1) 
stopień, imię, nazwisko i stanowisko służbowe przełożonego dyscyplinarnego; 
2) 
datę wydania; 
3) 
podstawę prawną; 
4) 
datę 
otrzymania 
przez 
przełożonego 
dyscyplinarnego 
informacji 
uzasadniających przeprowadzenie czynności wyjaśniających; 
5) 
określenie okoliczności stanowiących przedmiot czynności wyjaśniających; 
6) 
wskazanie 
rzecznika 
dyscyplinarnego 
do 
prowadzenia 
czynności 
wyjaśniających; 
7) 
podpis 
przełożonego 
dyscyplinarnego 
i 
urzędową 
pieczęć 
jednostki 
organizacyjnej Policji albo urzędową pieczęć ministra właściwego do spraw 
wewnętrznych. 
4c. Jeżeli w toku czynności wyjaśniających zostały ujawnione inne okoliczności 
wskazujące na możliwość popełnienia przewinienia dyscyplinarnego, rzecznik 
dyscyplinarny za zgodą przełożonego dyscyplinarnego może poszerzyć zakres 
okoliczności stanowiących przedmiot czynności wyjaśniających, o których mowa w 
ust. 4b pkt 5. 
4d. W toku czynności wyjaśniających nie przeprowadza się dowodu z opinii 
biegłego ani czynności wymagających spisania protokołu. 

 
 
 
s. 232/274 
 
2025-07-03 
 
4e. Z czynności wyjaśniających rzecznik dyscyplinarny sporządza sprawozdanie, 
w którym w szczególności przedstawia wnioski dotyczące wszczęcia postępowania 
dyscyplinarnego, odstąpienia od wszczęcia postępowania dyscyplinarnego albo 
odstąpienia od wszczęcia postępowania dyscyplinarnego i przeprowadzenia rozmowy 
dyscyplinującej ze sprawcą przewinienia dyscyplinarnego. 
4f. W przypadku wszczęcia postępowania dyscyplinarnego materiały zebrane 
podczas przeprowadzania czynności 
wyjaśniających stają się materiałami 
postępowania dyscyplinarnego. 
4g. Wyższy przełożony dyscyplinarny lub Komendant Główny Policji może 
zlecić przeprowadzenie lub przeprowadzić czynności wyjaśniające w sprawach 
dotyczących policjantów podległych przełożonym dyscyplinarnym, jeżeli w jego 
ocenie jest to konieczne ze względu na charakter sprawy. 
5. Postępowanie dyscyplinarne wszczyna się z dniem wydania postanowienia o 
wszczęciu postępowania dyscyplinarnego. Policjanta, co do którego wydano 
postanowienie o wszczęciu postępowania dyscyplinarnego, uważa się za 
obwinionego. 
5a. Celem postępowania dyscyplinarnego jest w szczególności: 
1) 
ustalenie, czy czyn, którego popełnienie zarzucono obwinionemu, został 
popełniony i czy obwiniony jest jego sprawcą; 
2) 
wyjaśnienie przyczyn i okoliczności popełnienia czynu, o którym mowa w pkt 1; 
3) 
zebranie i utrwalenie dowodów w sprawie. 
5b. Przełożony dyscyplinarny i wyższy przełożony dyscyplinarny badają swoją 
właściwość przed podjęciem czynności w sprawach dyscyplinarnych, a w przypadku 
stwierdzenia braku właściwości przekazują sprawę odpowiednio uprawnionemu 
przełożonemu dyscyplinarnemu albo wyższemu przełożonemu dyscyplinarnemu. 
5c. 
Rzecznik 
dyscyplinarny 
przekazuje 
niezwłocznie 
przełożonemu 
dyscyplinarnemu dokumenty w sprawach dyscyplinarnych zastrzeżonych do jego 
właściwości. 
6. Postanowienie o wszczęciu postępowania dyscyplinarnego zawiera: 
1) 
oznaczenie przełożonego dyscyplinarnego; 
2) 
datę wydania postanowienia; 
3) 
stopień, imię i nazwisko oraz stanowisko służbowe obwinionego; 
4) 
opis przewinienia dyscyplinarnego zarzucanego obwinionemu wraz z jego 
kwalifikacją prawną; 

 
 
 
s. 233/274 
 
2025-07-03 
 
5) 
uzasadnienie faktyczne zarzucanego przewinienia dyscyplinarnego; 
6) 
oznaczenie rzecznika dyscyplinarnego prowadzącego postępowanie; 
7) 
podpis z podaniem stopnia, imienia i nazwiska przełożonego dyscyplinarnego; 
8) 
pouczenie o uprawnieniach przysługujących obwinionemu w toku postępowania 
dyscyplinarnego; 
9) 
datę otrzymania przez przełożonego dyscyplinarnego informacji uzasadniającej 
podejrzenie popełnienia przez policjanta zarzucanego mu czynu. 
7. W przypadku uchylenia w postępowaniu odwoławczym orzeczenia, o którym 
mowa w art. 135fa ust. 1, i przekazania sprawy do ponownego rozpatrzenia za dzień 
wszczęcia postępowania dyscyplinarnego przyjmuje się dzień wydania orzeczenia, o 
którym mowa w art. 135fa ust. 1.

***
## Art. 135. {#policja-art-135}

1. Postępowania dyscyplinarnego nie wszczyna się, jeżeli: 
1) 
czynności wyjaśniające nie potwierdziły popełnienia czynu stanowiącego 
przewinienie dyscyplinarne; 
2) 
upłynęły terminy określone w ust. 4 i 5; 
3) 
postępowanie dyscyplinarne w sprawie tego samego czynu i tego samego 
policjanta zostało prawomocnie zakończone lub, wcześniej wszczęte, toczy się. 
2. Postanowienie o odmowie wszczęcia postępowania dyscyplinarnego oraz 
orzeczenie o umorzeniu postępowania dyscyplinarnego doręcza się pokrzywdzonemu, 
jeżeli 
złożył 
on 
wniosek 
o 
wszczęcie 
postępowania 
dyscyplinarnego. 
Na postanowienie o odmowie wszczęcia postępowania dyscyplinarnego oraz na 
orzeczenie o umorzeniu tego postępowania pokrzywdzony może wnieść odpowiednio 
zażalenie lub odwołanie, w terminie 7 dni od dnia ich doręczenia. 
3. Postępowania dyscyplinarnego nie wszczyna się po upływie 90 dni od dnia 
powzięcia przez przełożonego dyscyplinarnego wiadomości o popełnieniu 
przewinienia dyscyplinarnego. 
3a. Jeżeli policjant z powodu nieobecności w służbie nie ma możliwości złożenia 
wyjaśnień, bieg terminu, o którym mowa w ust. 3, nie rozpoczyna się, a rozpoczęty 
ulega zawieszeniu do dnia stawienia się policjanta do służby. 
4. Karalność przewinienia dyscyplinarnego ustaje z upływem 2 lat od dnia jego 
popełnienia. Zawieszenie postępowania dyscyplinarnego wstrzymuje bieg tego 
terminu. 

 
 
 
s. 234/274 
 
2025-07-03 
 
5. Jeżeli przewinieniem dyscyplinarnym jest czyn zawierający jednocześnie 
znamiona przestępstwa lub wykroczenia albo przestępstwa skarbowego lub 
wykroczenia skarbowego, upływ terminu określonego w ust. 4 nie może nastąpić 
wcześniej niż terminów przedawnienia karalności tych przestępstw lub wykroczeń. 
6. (uchylony)

***
## Art. 135a. {#policja-art-135a}

1. Postępowanie dyscyplinarne oraz czynności wyjaśniające, o 
których mowa w art. 134i ust. 4, prowadzi rzecznik dyscyplinarny. 
2. Przełożony dyscyplinarny powołuje rzeczników dyscyplinarnych na okres 4 
lat spośród policjantów w służbie stałej. 
3. Przełożony dyscyplinarny do prowadzenia postępowania dyscyplinarnego 
oraz czynności wyjaśniających, o których mowa w art. 134i ust. 4, wyznacza rzecznika 
dyscyplinarnego w stopniu: 
1) 
co najmniej młodszego aspiranta, jeżeli postępowanie ma dotyczyć policjanta 
posiadającego stopień w korpusie szeregowych, podoficerów lub aspirantów; 
2) 
co najmniej podkomisarza, jeżeli postępowanie ma dotyczyć policjanta 
posiadającego stopień podkomisarza, komisarza lub nadkomisarza albo 
policjanta ze stopniem, o którym mowa w pkt 1; 
3) 
co najmniej podinspektora, jeżeli postępowanie ma dotyczyć policjanta 
posiadającego stopień podinspektora lub wyższy albo policjanta ze stopniem, o 
którym mowa w pkt 2.

***
## Art. 135b. {#policja-art-135b}

1. Przełożony dyscyplinarny odwołuje rzecznika dyscyplinarnego w 
przypadkach: 
1) 
zaistnienia okoliczności, które stanowią podstawę zwolnienia go ze służby w 
Policji; 
2) 
prawomocnego ukarania go karą dyscyplinarną; 
3) 
przeniesienia go do innej jednostki organizacyjnej Policji niepodlegającej 
bezpośrednio przełożonemu dyscyplinarnemu. 
1a. Przełożony dyscyplinarny może odwołać rzecznika dyscyplinarnego na jego 
uzasadniony wniosek. 
2. Rzecznik dyscyplinarny, za zgodą przełożonego dyscyplinarnego, może 
skorzystać z pomocy innego rzecznika dyscyplinarnego przy przeprowadzaniu 
czynności dowodowych. 

 
 
 
s. 235/274 
 
2025-07-03

***
## Art. 135c. {#policja-art-135c}

1. Przełożony dyscyplinarny lub rzecznik dyscyplinarny podlegają 
wyłączeniu od udziału w postępowaniu dyscyplinarnym, jeżeli: 
1) 
sprawa dotyczy go bezpośrednio; 
2) 
jest małżonkiem, krewnym lub powinowatym obwinionego lub osoby przez 
niego pokrzywdzonej w rozumieniu przepisów Kodeksu postępowania karnego; 
3) 
był świadkiem czynu; 
4) 
między nim a obwinionym lub osobą pokrzywdzoną przez obwinionego zachodzi 
stosunek osobisty mogący wywołać wątpliwości co do jego bezstronności. 
2. Przełożonego dyscyplinarnego i rzecznika dyscyplinarnego można wyłączyć 
od udziału w postępowaniu dyscyplinarnym także z innych uzasadnionych przyczyn. 
3. O okolicznościach uzasadniających wyłączenie od udziału w postępowaniu 
dyscyplinarnym przełożony dyscyplinarny i rzecznik dyscyplinarny zawiadamiają 
niezwłocznie odpowiednio wyższego przełożonego dyscyplinarnego i przełożonego 
dyscyplinarnego. 
4. Wyłączenie przełożonego dyscyplinarnego i rzecznika dyscyplinarnego od 
udziału w postępowaniu dyscyplinarnym może nastąpić również na wniosek 
obwinionego lub jego obrońcy, jeżeli został ustanowiony. 
5. Przełożony dyscyplinarny wydaje postanowienie o wyłączeniu lub odmowie 
wyłączenia rzecznika dyscyplinarnego od udziału w postępowaniu dyscyplinarnym. 
6. Wyższy przełożony dyscyplinarny wydaje postanowienie o wyłączeniu lub o 
odmowie wyłączenia przełożonego dyscyplinarnego od udziału w postępowaniu 
dyscyplinarnym. 
7. Do dnia wydania postanowienia, o którym mowa w ust. 6, przełożony 
dyscyplinarny podejmuje czynności niecierpiące zwłoki.

***
## Art. 135d. {#policja-art-135d}

1. W przypadku wyłączenia przełożonego dyscyplinarnego od udziału 
w postępowaniu dyscyplinarnym na podstawie art. 135c ust. 1 i 2, postępowanie 
dyscyplinarne przejmuje wyższy przełożony dyscyplinarny albo wyznacza 
przełożonego dyscyplinarnego z równorzędnej jednostki organizacyjnej Policji. 
2. W przypadku wyłączenia Komendanta Głównego Policji od udziału w 
postępowaniu dyscyplinarnym na podstawie art. 135c ust. 1 i 2, postępowanie 
dyscyplinarne przejmuje jeden z jego zastępców. 

 
 
 
s. 236/274 
 
2025-07-03 
 
3. W przypadku wyłączenia rzecznika dyscyplinarnego od udziału w 
postępowaniu dyscyplinarnym na podstawie art. 135c ust. 1 i 2, postępowanie 
dyscyplinarne przejmuje do prowadzenia inny wyznaczony rzecznik dyscyplinarny. 
4. Do czasu wydania przez przełożonego dyscyplinarnego postanowienia o 
wyłączeniu rzecznik dyscyplinarny podejmuje wyłącznie czynności niecierpiące 
zwłoki.

***
## Art. 135e. {#policja-art-135e}

1. Rzecznik dyscyplinarny zbiera materiał dowodowy i podejmuje 
czynności niezbędne do wyjaśnienia sprawy. W szczególności przesłuchuje 
świadków, obwinionego i pokrzywdzonego, przeprowadza oględziny, konfrontacje, 
okazania oraz dokonuje odtworzenia przebiegu stanowiących przedmiot rozpoznania 
zdarzeń lub ich fragmentów. Z czynności tych sporządza protokoły. Rzecznik 
dyscyplinarny może także zlecić przeprowadzenie odpowiednich badań. 
2. Z czynności innych niż wymienione w ust. 1 sporządza się protokół, jeżeli 
przepis szczególny tego wymaga albo przełożony dyscyplinarny lub rzecznik 
dyscyplinarny uzna to za potrzebne. W pozostałych przypadkach można ograniczyć 
się do sporządzenia notatki urzędowej. 
3. Protokół zawiera: 
1) 
oznaczenie czynności, jej czasu i miejsca, osób w niej uczestniczących lub 
obecnych oraz charakteru ich uczestnictwa; 
2) 
opis przebiegu czynności; 
3) 
w miarę potrzeby: 
a) 
stwierdzenie innych okoliczności dotyczących przebiegu czynności, 
b) 
oświadczenia i wnioski uczestników czynności, 
c) 
pouczenie o uprawnieniach i obowiązkach. 
4. Wyjaśnienia, zeznania, oświadczenia i wnioski oraz stwierdzenia określonych 
okoliczności 
przez 
rzecznika 
dyscyplinarnego 
lub 
kierownika 
jednostki 
organizacyjnej Policji, o którym mowa w ust. 8, zapisuje się w protokole z możliwą 
dokładnością, a osoby biorące udział w czynności mają prawo żądać zapisania w 
protokole z pełną dokładnością wszystkiego, co dotyczy ich praw i interesów. 
5. Osoby biorące udział w czynności, z której jest sporządzany protokół, a także 
osoby obecne, po zapoznaniu się z treścią protokołu, podpisują każdą jego stronę. 
Odmowę zapoznania się z treścią protokołu, a także odmowę lub brak podpisu 
którejkolwiek osoby należy omówić w protokole. 

 
 
 
s. 237/274 
 
2025-07-03 
 
6. Rzecznik dyscyplinarny w toku postępowania wydaje postanowienia, jeżeli 
ich wydanie nie jest zastrzeżone do właściwości przełożonego dyscyplinarnego. 
7. Postanowienie wydane w toku postępowania, z wyjątkiem postanowienia o 
wszczęciu postępowania dyscyplinarnego, powinno zawierać: 
1) 
oznaczenie 
wydającego 
postanowienie 
rzecznika 
dyscyplinarnego 
lub 
przełożonego dyscyplinarnego; 
2) 
datę wydania postanowienia; 
3) 
podstawę prawną wydania postanowienia; 
4) 
stopień, imię i nazwisko oraz stanowisko służbowe obwinionego; 
5) 
rozstrzygnięcie; 
6) 
uzasadnienie faktyczne i prawne; 
7) 
pouczenie, czy i w jakim trybie przysługuje prawo złożenia zażalenia; 
8) 
podpis z podaniem stopnia, imienia i nazwiska wydającego postanowienie. 
7a. Rzecznik dyscyplinarny, który wydał postanowienie, w przypadku 
wniesienia zażalenia na to postanowienie, niezwłocznie przekazuje je przełożonemu 
dyscyplinarnemu wraz z aktami postępowania oraz ze swoim stanowiskiem, 
nie później jednak niż w terminie 3 dni od dnia, w którym otrzymał zażalenie. 
8. W przypadku konieczności przeprowadzenia czynności poza miejscowością, 
w której toczy się postępowanie dyscyplinarne, przełożony dyscyplinarny lub rzecznik 
dyscyplinarny mogą zwrócić się o ich przeprowadzenie do przełożonego 
dyscyplinarnego właściwego według miejsca, w którym czynność ma być dokonana. 
Czynności przeprowadza rzecznik dyscyplinarny wyznaczony przez kierownika tej 
jednostki organizacyjnej Policji. 
9. Jeżeli czyn będący przedmiotem postępowania dyscyplinarnego jest lub był 
przedmiotem innego postępowania, w tym postępowania przygotowawczego, 
przełożony dyscyplinarny lub rzecznik dyscyplinarny mogą zwrócić się do właś-
ciwego organu o udostępnienie akt tego postępowania w całości lub w części. Za zgodą 
tego organu, potrzebne odpisy lub wyciągi z udostępnionych akt włącza się do akt 
postępowania dyscyplinarnego. 
9a. Rzecznik dyscyplinarny, w razie ustalenia na podstawie zebranego materiału 
dowodowego, że obwinionemu należy zarzucić czyn, który nie był objęty uprzednio 
wydanym postanowieniem, lub że zachodzi potrzeba istotnej zmiany opisu czynu lub 
jego kwalifikacji prawnej, występuje do przełożonego dyscyplinarnego z wnioskiem 
o zmianę lub uzupełnienie zarzutów. 

 
 
 
s. 238/274 
 
2025-07-03 
 
10. Jeżeli zebrany materiał dowodowy to uzasadnia, przełożony dyscyplinarny 
wydaje postanowienie o zmianie lub uzupełnieniu zarzutów.

***
## Art. 135f. {#policja-art-135f}

1. W toku postępowania dyscyplinarnego obwiniony ma prawo do: 
1) 
odmowy składania wyjaśnień; 
2) 
zgłaszania wniosków dowodowych; 
3) 
przeglądania akt postępowania dyscyplinarnego oraz sporządzania z nich notatek 
lub fotokopii; 
4) 
(utracił moc)11) 
4a) ustanowienia obrońcy, którym może być policjant, adwokat albo radca prawny; 
5) 
wnoszenia do przełożonego dyscyplinarnego zażaleń na postanowienia wydane 
w toku postępowania przez rzecznika dyscyplinarnego, w terminie 3 dni od dnia 
doręczenia i w przypadkach wskazanych w ustawie; od postanowień wydanych 
przez przełożonego dyscyplinarnego zażalenie przysługuje do wyższego 
przełożonego dyscyplinarnego, z zastrzeżeniem art. 135k ust. 4. 
2. Rzecznik dyscyplinarny może, w drodze postanowienia, odmówić 
udostępnienia akt, jeżeli sprzeciwia się temu dobro postępowania dyscyplinarnego. Na 
postanowienie przysługuje zażalenie. 
3. Ustanowienie obrońcy uprawnia go do działania w całym postępowaniu 
dyscyplinarnym, nie wyłączając czynności po uprawomocnieniu się orzeczenia, jeżeli 
nie zawiera ograniczeń. O zmianie zakresu pełnomocnictwa uprawniającego do 
działania w postępowaniu dyscyplinarnym lub o jego cofnięciu obwiniony 
niezwłocznie zawiadamia obrońcę oraz rzecznika dyscyplinarnego. 
4. Obrońca nie może podejmować czynności na niekorzyść obwinionego. Może 
on 
zrezygnować 
z 
reprezentowania 
obwinionego 
w 
toku 
postępowania 
dyscyplinarnego, zawiadamiając o tym obwinionego oraz rzecznika dyscyplinarnego. 
Do czasu ustanowienia nowego obrońcy, jednak nie dłużej niż 14 dni od dnia 
zawiadomienia obwinionego, obrońca jest obowiązany podejmować niezbędne 
czynności. 
5. Udział obrońcy w postępowaniu dyscyplinarnym nie wyłącza osobistego 
działania w nim obwinionego. 
 
11) Z dniem 2 kwietnia 2007 r. na podstawie wyroku Trybunału Konstytucyjnego z dnia 19 marca 2007 r. 
sygn. akt K 47/05 (Dz. U. poz. 390). 

 
 
 
s. 239/274 
 
2025-07-03 
 
6. Orzeczenia, postanowienia, zawiadomienia i inne pisma, wydane w toku 
postępowania dyscyplinarnego, doręcza się obwinionemu oraz obrońcy, jeżeli został 
ustanowiony. W razie doręczenia obwinionemu i obrońcy w różnych terminach pisma, 
od którego przysługuje odwołanie lub zażalenie, termin do złożenia odwołania lub 
zażalenia liczy się od dnia doręczenia, które nastąpiło wcześniej. 
7. 
Wniosek 
dowodowy 
obwiniony 
zgłasza 
na 
piśmie 
rzecznikowi 
dyscyplinarnemu, który rozstrzyga o uwzględnieniu wniosku albo odmawia, w drodze 
postanowienia, uwzględnienia wniosku, jeżeli: 
1) 
okoliczność, która ma być udowodniona, nie ma znaczenia dla rozstrzygnięcia 
sprawy albo jest już udowodniona zgodnie z twierdzeniem wnioskodawcy; 
2) 
dowód jest nieprzydatny do stwierdzenia danej okoliczności lub nie da się 
przeprowadzić; 
3) 
przeprowadzenie dowodu jest niedopuszczalne; 
4) 
wniosek dowodowy w sposób oczywisty zmierza do przedłużenia postępowania; 
5) 
wniosek dowodowy został złożony po zakreślonym terminie, o którym 
wnioskodawca został zawiadomiony. 
8. Na postanowienie w przedmiocie nieuwzględnienia wniosku dowodowego 
przysługuje zażalenie. 
9. Nieusprawiedliwiona nieobecność obwinionego w służbie, zwolnienie 
obwinionego od zajęć służbowych z powodu choroby oraz nieusprawiedliwione 
niestawiennictwo na wezwanie rzecznika dyscyplinarnego nie wstrzymują biegu 
postępowania dyscyplinarnego, a czynności, w których jest przewidziany udział 
obwinionego, nie przeprowadza się albo przeprowadza się w miejscu jego pobytu. 
10. Choroba obwinionego, świadka i innego uczestnika postępowania 
dyscyplinarnego stwierdzona zwolnieniem lekarskim usprawiedliwia nieobecność 
tych osób podczas czynności objętych danym postępowaniem przez okresy nie dłuższe 
niż łącznie 14 dni w ciągu całego postępowania dyscyplinarnego. Usprawiedliwienie 
nieobecności z powodu choroby za każdy następny jej okres wymaga przedstawienia 
zaświadczenia wystawionego przez lekarza uprawnionego do wystawiania 
zaświadczeń potwierdzających niemożność stawienia się na wezwanie lub 
zawiadomienie organu prowadzącego postępowanie karne.

***
## Art. 135fa. {#policja-art-135fa}

1. Przełożony dyscyplinarny może wydać orzeczenie bez 
wszczynania postępowania dyscyplinarnego, jeżeli okoliczności popełnionego czynu 

 
 
 
s. 240/274 
 
2025-07-03 
 
i wina policjanta nie budzą wątpliwości oraz nie zachodzi potrzeba wymierzenia kary 
dyscyplinarnej surowszej niż nagana. 
2. W przypadkach, o których mowa w ust. 1, orzeczenie wydaje się po 
wysłuchaniu policjanta i złożeniu przez niego wyjaśnienia na piśmie oraz wyrażeniu 
pisemnej zgody na poddanie się karze dyscyplinarnej bez prowadzenia postępowania 
dyscyplinarnego. 
3. Po wszczęciu postępowania dyscyplinarnego do czasu zakończenia 
pierwszego przesłuchania w charakterze obwinionego obwiniony może złożyć 
wniosek o dobrowolne poddanie się karze dyscyplinarnej. 
4. Przełożony dyscyplinarny może uwzględnić wniosek o dobrowolne poddanie 
się 
karze 
dyscyplinarnej, 
jeżeli 
okoliczności 
popełnienia 
przewinienia 
dyscyplinarnego i wina obwinionego nie budzą wątpliwości, a charakter popełnionego 
przewinienia uzasadnia wymierzenie kary dyscyplinarnej, o której mowa w art. 134 
pkt 1 lub 2. Czynności, o których mowa w art. 135i ust. 1–6, nie przeprowadza się. 
5. W przypadku uwzględnienia wniosku o dobrowolne poddanie się karze 
dyscyplinarnej przełożony dyscyplinarny wydaje orzeczenie o ukaraniu. 
6. Od orzeczenia o ukaraniu obwinionemu przysługuje odwołanie w terminie 7 
dni od dnia doręczenia orzeczenia. Odwołanie składa się do przełożonego 
dyscyplinarnego, który wydał orzeczenie. 
7. Przełożony dyscyplinarny odmawia przyjęcia odwołania, w drodze 
postanowienia, jeżeli zostało wniesione po terminie lub przez osobę nieuprawnioną 
albo jest niedopuszczalne. Postanowienie w tej sprawie jest ostateczne. 
8. W przypadku złożenia odwołania przez obwinionego przełożony 
dyscyplinarny uchyla orzeczenie o ukaraniu, kontynuuje postępowanie dyscyplinarne 
i wydaje orzeczenie, o którym mowa w art. 135j ust. 1, od którego przysługuje 
odwołanie w trybie art. 135k. 
9. Cofnięcie odwołania, o którym mowa w ust. 6, jest niedopuszczalne.

***
## Art. 135g. {#policja-art-135g}

1. Przełożony dyscyplinarny i rzecznik dyscyplinarny są obowiązani 
badać oraz uwzględniać okoliczności przemawiające zarówno na korzyść, jak i na 
niekorzyść obwinionego. 
2. Obwinionego uważa się za niewinnego, dopóki wina jego nie zostanie 
udowodniona i stwierdzona prawomocnym orzeczeniem. Niedające się usunąć 
wątpliwości rozstrzyga się na korzyść obwinionego. 

 
 
 
s. 241/274 
 
2025-07-03

***
## Art. 135h. {#policja-art-135h}

1. Czynności dowodowe w postępowaniu dyscyplinarnym kończy się 
w terminie miesiąca od dnia wszczęcia tego postępowania. Wyższy przełożony 
dyscyplinarny, w drodze postanowienia, może przedłużyć termin prowadzenia 
czynności dowodowych na czas oznaczony do 3 miesięcy. 
2. Komendant Główny Policji, w drodze postanowienia, może przedłużyć termin 
prowadzenia czynności dowodowych na czas oznaczony dłuższy niż 3 miesiące. 
2a. Przedłużenie terminu następuje na wniosek przełożonego dyscyplinarnego 
prowadzącego postępowanie dyscyplinarne. Wniosek o przedłużenie terminu 
prowadzenia czynności dowodowych w postępowaniu dyscyplinarnym składa się nie 
później niż 5 dni przed upływem tego terminu. Przed wydaniem postanowienia o 
przedłużeniu terminu prowadzenia czynności dowodowych właściwy do jego wydania 
wyższy przełożony dyscyplinarny lub Komendant Główny Policji może zażądać 
niezwłocznego przekazania akt postępowania. 
3. Przełożony dyscyplinarny może zawiesić postępowanie dyscyplinarne, w 
drodze 
postanowienia, 
z 
powodu 
zaistnienia 
długotrwałej 
przeszkody 
uniemożliwiającej prowadzenie postępowania. 
3a. Przełożony dyscyplinarny zawiesza postępowanie dyscyplinarne z ostatnim 
dniem pełnienia służby w jednostce organizacyjnej Policji i przekazuje materiały 
postępowania dyscyplinarnego przełożonemu dyscyplinarnemu w nowym miejscu 
służby obwinionego. 
3b. 
Na 
postanowienie 
o 
zawieszeniu 
postępowania 
dyscyplinarnego 
obwinionemu i pokrzywdzonemu przysługuje zażalenie, z wyjątkiem postanowienia, 
o którym mowa w ust. 3a. Jeżeli postanowienie wydał minister właściwy do spraw 
wewnętrznych albo Komendant Główny Policji, zażalenie nie przysługuje, jednak 
obwiniony i pokrzywdzony mogą zwrócić się odpowiednio do ministra właściwego 
do spraw wewnętrznych albo Komendanta Głównego Policji z wnioskiem o ponowne 
rozpatrzenie sprawy. 
3c. Zawieszenie postępowania dyscyplinarnego wstrzymuje bieg terminów. 
4. Przełożony dyscyplinarny wydaje postanowienie o podjęciu zawieszonego 
postępowania dyscyplinarnego po ustaniu przeszkody, o której mowa w ust. 3. 
5. Postanowienie o podjęciu zawieszonego postępowania dyscyplinarnego w 
sprawie obwinionego przeniesionego do innej jednostki organizacyjnej Policji wydaje 
się niezwłocznie po otrzymaniu materiałów postępowania dyscyplinarnego 
wszczętego w poprzednim miejscu służby obwinionego. 

 
 
 
s. 242/274 
 
2025-07-03

***
## Art. 135ha. {#policja-art-135ha}

1. Jeżeli przeciwko obwinionemu jest prowadzone postępowanie 
dyscyplinarne obejmujące zarzuty popełnienia dwóch lub więcej czynów, a zebrane 
na danym etapie postępowania dowody dają podstawy do uznania obwinionego 
winnym popełnienia jednego z zarzuconych mu czynów, przełożony dyscyplinarny 
może, w drodze postanowienia, wyłączyć ten czyn do odrębnego postępowania 
dyscyplinarnego, bez względu na to, czy wyjaśniono wszystkie okoliczności 
dotyczące pozostałych czynów objętych postępowaniem. 
2. W przypadku, o którym mowa w ust. 1, zebrane w toku postępowania 
dyscyplinarnego dowody dotyczące wyłączonego czynu stają się dowodami 
odrębnego postępowania dyscyplinarnego.

***
## Art. 135hb. {#policja-art-135hb}

1. Oczywiste omyłki pisarskie i rachunkowe w orzeczeniu lub 
postanowieniu można sprostować w każdym czasie w drodze postanowienia. 
2. Sprostowanie oczywistych omyłek pisarskich i rachunkowych w protokołach 
sporządzanych w toku postępowania dyscyplinarnego wymaga opisania tych omyłek 
przez osobę sporządzającą protokół przed jego podpisaniem. W przypadku ujawnienia 
omyłek pisarskich lub rachunkowych po podpisaniu protokołu prostuje się je w drodze 
postanowienia. 
3. Od postanowień, o których mowa w ust. 1 i 2, odwołanie nie przysługuje. 
4. Sprostowanie omyłek pisarskich i rachunkowych następuje z urzędu albo na 
wniosek pokrzywdzonego, ukaranego lub obwinionego albo, w przypadku jego 
śmierci, na wniosek jego małżonka, krewnych w linii prostej, rodzeństwa, 
przysposabiającego lub przysposobionego. 
5. Sprostowania dokonuje przełożony dyscyplinarny lub rzecznik dyscyplinarny, 
który popełnił omyłkę.

***
## Art. 135i. {#policja-art-135i}

1. Rzecznik dyscyplinarny, po przeprowadzeniu czynności 
dowodowych i uznaniu, że zostały wyjaśnione wszystkie istotne okoliczności sprawy, 
zapoznaje obwinionego z aktami postępowania dyscyplinarnego. 
2. Obrońca może zapoznać się z aktami postępowania dyscyplinarnego, o 
których mowa w ust. 1, nie później niż do dnia zapoznania obwinionego z tymi aktami. 
3. Z czynności zapoznania z aktami postępowania dyscyplinarnego sporządza się 
protokół. 
4. Odmowa zapoznania się z aktami postępowania lub złożenia podpisu 
stwierdzającego 
tę 
okoliczność 
nie 
wstrzymuje 
postępowania. 
Rzecznik 

 
 
 
s. 243/274 
 
2025-07-03 
 
dyscyplinarny 
dokonuje 
wzmianki 
o 
odmowie 
w 
aktach 
postępowania. 
Nieusprawiedliwione niestawienie się obwinionego lub jego obrońcy na czynność 
zapoznania się z aktami postępowania dyscyplinarnego jest równoznaczne z odmową 
skorzystania z prawa do zapoznania się z tymi aktami. 
5. Obwiniony ma prawo w terminie 3 dni od dnia zapoznania się z aktami 
postępowania dyscyplinarnego zgłosić wniosek o ich uzupełnienie. Na wydane przez 
rzecznika dyscyplinarnego postanowienie o odmowie uzupełnienia akt postępowania 
dyscyplinarnego obwinionemu służy prawo złożenia zażalenia. 
6. Obwiniony ma prawo w terminie 3 dni od dnia zapoznania się z uzupełnionymi 
aktami postępowania dyscyplinarnego zgłosić wniosek o ich uzupełnienie w zakresie 
wynikającym z przeprowadzonych czynności dowodowych uzupełniających akta tego 
postępowania. 
7. Rzecznik dyscyplinarny, po zapoznaniu obwinionego z aktami postępowania 
dyscyplinarnego, wydaje postanowienie o zakończeniu czynności dowodowych oraz 
w terminie 7 dni od dnia zakończenia czynności dowodowych sporządza 
sprawozdanie, które: 
1) 
wskazuje prowadzącego postępowanie i przełożonego dyscyplinarnego, który 
wydał postanowienie o wszczęciu postępowania dyscyplinarnego; 
2) 
wskazuje obwinionego oraz określa zarzucane mu przewinienie dyscyplinarne, z 
opisem stanu faktycznego ustalonym na podstawie zebranych dowodów; 
3) 
przedstawia wnioski dotyczące uniewinnienia, odstąpienia od ukarania lub 
wymierzenia kary albo umorzenia postępowania.

***
## Art. 135j. {#policja-art-135j}

1. Na podstawie zebranego w postępowaniu materiału dowodowego 
przełożony dyscyplinarny wydaje orzeczenie o: 
1) 
uniewinnieniu, jeżeli przeprowadzone postępowanie nie potwierdziło zarzutów 
stawianych obwinionemu, albo 
2) 
uznaniu 
winnym 
popełnienia 
czynu, 
za 
który 
obwiniony 
ponosi 
odpowiedzialność dyscyplinarną, i o wymierzeniu kary dyscyplinarnej, albo 
3) 
uznaniu 
winnym 
popełnienia 
czynu, 
za 
który 
obwiniony 
ponosi 
odpowiedzialność dyscyplinarną, i o odstąpieniu od wymierzenia kary 
dyscyplinarnej, albo 
4) 
umorzeniu postępowania. 

 
 
 
s. 244/274 
 
2025-07-03 
 
1a. Przełożony dyscyplinarny w orzeczeniu może zmienić opis czynu lub jego 
kwalifikację prawną wyłącznie w granicach czynu zarzucanego obwinionemu i jego 
kwalifikacji prawnej. 
2. Orzeczenie powinno zawierać: 
1) 
oznaczenie przełożonego dyscyplinarnego; 
2) 
datę wydania orzeczenia; 
3) 
stopień, imię i nazwisko oraz stanowisko służbowe obwinionego; 
4) 
opis przewinienia dyscyplinarnego zarzucanego obwinionemu wraz z 
kwalifikacją prawną; 
5) 
rozstrzygnięcie o uniewinnieniu, stwierdzeniu winy i odstąpieniu od ukarania lub 
wymierzeniu 
kary 
dyscyplinarnej 
albo 
umorzeniu 
postępowania 
dyscyplinarnego; 
6) 
uzasadnienie faktyczne i prawne orzeczenia; 
7) 
pouczenie o prawie, terminie i trybie wniesienia odwołania; 
8) 
podpis, z podaniem stopnia, imienia i nazwiska przełożonego dyscyplinarnego, 
oraz pieczęć jednostki organizacyjnej Policji. 
3. Jeżeli przełożony dyscyplinarny uzna, że w przekazanych mu aktach 
postępowania dyscyplinarnego są istotne braki, w terminie 14 dni od dnia przekazania 
mu akt wydaje postanowienie o uchyleniu postanowienia o zakończeniu czynności 
dowodowych i zwraca sprawę rzecznikowi dyscyplinarnemu w celu usunięcia 
stwierdzonych braków w materiale dowodowym. 
4. Jeżeli w dniu wydania orzeczenia zachodzi okoliczność uzasadniająca 
umorzenie postępowania w części, o umorzeniu rozstrzyga się w tym orzeczeniu. 
5. Przełożony dyscyplinarny może odstąpić od ukarania, jeżeli stopień winy lub 
stopień szkodliwości przewinienia dyscyplinarnego dla służby nie jest znaczny, a 
właściwości i warunki osobiste policjanta oraz dotychczasowy przebieg służby 
uzasadniają przypuszczenie, że pomimo odstąpienia od ukarania będzie on 
przestrzegał dyscypliny służbowej oraz zasad etyki zawodowej. 
6. Orzeczenie, o którym mowa w ust. 1, wraz z uzasadnieniem sporządza się na 
piśmie nie później niż w terminie 14 dni od dnia wydania postanowienia o 
zakończeniu czynności dowodowych. 
7. Orzeczenie, o którym mowa w ust. 1, doręcza się niezwłocznie obwinionemu. 
8. Jeżeli przełożony dyscyplinarny, o którym mowa w art. 133 ust. 2 i 3, uzna, że 
należy wymierzyć karę dyscyplinarną, do której wymierzenia nie jest uprawniony, 

 
 
 
s. 245/274 
 
2025-07-03 
 
wniosek w tej sprawie wraz z aktami postępowania dyscyplinarnego przesyła 
przełożonemu dyscyplinarnemu uprawnionemu do wymierzenia tej kary. 
9. W przypadku zamiaru wymierzenia kary wydalenia ze służby w Policji 
przełożony dyscyplinarny, przed wydaniem orzeczenia dyscyplinarnego, wzywa 
obwinionego do raportu w celu wysłuchania go. W raporcie uczestniczy rzecznik 
dyscyplinarny. O terminie raportu należy zawiadomić wskazaną przez obwinionego, 
w terminie 3 dni od dnia doręczenia wezwania w sprawie, zakładową organizację 
związkową. Przedstawiciel zakładowej organizacji związkowej będący policjantem 
może uczestniczyć w raporcie, chyba że obwiniony nie wyrazi na to zgody. 
Obwinionemu oraz zakładowej organizacji związkowej, w przypadku gdy obwiniony 
wyraził zgodę na udział jej przedstawiciela w raporcie, doręcza się sprawozdanie w 
terminie umożliwiającym zapoznanie się z nim przed raportem. 
10. Przepisu ust. 9 nie stosuje się w przypadku: 
1) 
tymczasowego aresztowania obwinionego; 
2) 
odmowy obwinionego stawienia się do raportu lub nieusprawiedliwionej 
nieobecności w wyznaczonym terminie raportu; 
3) 
zaistnienia innej przeszkody uniemożliwiającej obwinionemu stawienie się do 
raportu w terminie 14 dni od dnia doręczenia postanowienia o zakończeniu 
czynności dowodowych.

***
## Art. 135ja. {#policja-art-135ja}

1. Postępowanie dyscyplinarne umarza się, jeżeli: 
1) 
nastąpiło przedawnienie wymierzenia kary dyscyplinarnej; 
2) 
postępowanie dyscyplinarne wszczęto po upływie terminu, o którym mowa w 
art. 135 ust. 3; 
3) 
ustalono, że czyn stanowiący przewinienie dyscyplinarne przypisany 
obwinionemu nie wypełnia znamion czynu stanowiącego przewinienie 
dyscyplinarne; 
4) 
obwiniony zmarł lub został uznany za zaginionego; 
5) 
obwiniony przestał podlegać orzecznictwu dyscyplinarnemu; 
6) 
postępowanie dyscyplinarne w sprawie tego samego czynu zarzuconego 
obwinionemu zostało prawomocnie zakończone albo, wszczęte wcześniej, toczy 
się. 
2. Postępowanie dyscyplinarne można umorzyć w przypadku: 
1) 
długotrwałej choroby obwinionego; 

 
 
 
s. 246/274 
 
2025-07-03 
 
2) 
wycofania wniosku, o którym mowa w art. 134i ust. 1 pkt 2. 
3. Orzeczenia o umorzeniu postępowania z uwagi na przedawnienie karalności 
nie wydaje się, w przypadku gdy zebrane dowody uzasadniają uniewinnienie 
obwinionego od popełnienia zarzucanego mu czynu. 
4. W przypadku przywrócenia do służby policjanta, wobec którego w dniu jego 
zwolnienia ze służby postępowanie dyscyplinarne zostało umorzone na podstawie 
przesłanki, o której mowa w ust. 1 pkt 5, przełożony dyscyplinarny wydaje 
postanowienie 
o 
uchyleniu 
orzeczenia 
o 
umorzeniu 
tego 
postępowania 
dyscyplinarnego, o ile nie nastąpiło przedawnienie wymierzenia kary dyscyplinarnej 
za czyn będący przedmiotem tego postępowania, oraz wyznacza rzecznika 
dyscyplinarnego do prowadzenia postępowania dyscyplinarnego.

***
## Art. 135k. {#policja-art-135k}

1. Postępowanie dyscyplinarne jest dwuinstancyjne. Od orzeczenia 
wydanego w pierwszej instancji obwinionemu przysługuje odwołanie w terminie 7 dni 
od dnia doręczenia orzeczenia. 
2. Odwołanie składa się do wyższego przełożonego dyscyplinarnego za 
pośrednictwem przełożonego, który wydał orzeczenie w pierwszej instancji. 
3. Wyższy przełożony dyscyplinarny odmawia przyjęcia odwołania, w drodze 
postanowienia, jeżeli zostało wniesione po terminie lub przez osobę nieuprawnioną 
albo jest niedopuszczalne. Postanowienie w tej sprawie jest ostateczne. 
4. Jeżeli orzeczenie lub postanowienie w pierwszej instancji wydał minister 
właściwy do spraw wewnętrznych lub Komendant Główny Policji, odwołanie lub 
zażalenie nie przysługuje. Obwiniony może jednak w terminie, o którym mowa w ust. 
1, zwrócić się do ministra właściwego do spraw wewnętrznych lub Komendanta 
Głównego Policji z wnioskiem o ponowne rozpatrzenie sprawy; do wniosku tego 
stosuje się odpowiednio przepisy dotyczące odwołań od orzeczeń. 
5. Przełożony dyscyplinarny, który wydał orzeczenie lub postanowienie w 
pierwszej instancji, w przypadku wniesienia odwołania lub zażalenia niezwłocznie 
przekazuje je wyższemu przełożonemu dyscyplinarnemu wraz z aktami postępowania, 
aktami osobowymi obwinionego oraz ze swoim stanowiskiem, nie później jednak niż 
w terminie 14 dni od dnia, w którym otrzymał odwołanie lub zażalenie.

***
## Art. 135l. {#policja-art-135l}

1. W postępowaniu odwoławczym rozpoznanie sprawy następuje na 
podstawie stanu faktycznego ustalonego w postępowaniu dyscyplinarnym. Jeżeli jest 
to potrzebne do prawidłowego wydania orzeczenia, wyższy przełożony dyscyplinarny 

 
 
 
s. 247/274 
 
2025-07-03 
 
może uzupełnić materiał dowodowy, zlecając rzecznikowi dyscyplinarnemu 
prowadzącemu postępowanie dyscyplinarne wykonanie czynności dowodowych, 
określając ich zakres. 
2. Z materiałami uzyskanymi w wyniku czynności dowodowych, o których 
mowa w ust. 1, rzecznik dyscyplinarny zapoznaje obwinionego. W terminie 3 dni od 
dnia zapoznania obwiniony ma prawo zgłoszenia wyższemu przełożonemu 
dyscyplinarnemu, o którym mowa w ust. 1, uwag dotyczących przeprowadzonych 
czynności dowodowych. Przepisy art. 135i ust. 1–4 stosuje się odpowiednio.

***
## Art. 135m. {#policja-art-135m}

1. Wyższy przełożony dyscyplinarny w terminie 7 dni od dnia 
wniesienia odwołania może powołać komisję do zbadania zaskarżonego orzeczenia, 
zwaną dalej „komisją”. W przypadku odwołania od orzeczenia o ukaraniu karą, 
o której mowa w art. 134 pkt 4–7, wyższy przełożony dyscyplinarny jest obowiązany 
powołać komisję. 
2. Komisja składa się z trzech oficerów w służbie stałej, z których dwóch 
wyznacza wyższy przełożony dyscyplinarny, a jednego wskazana przez obwinionego 
zakładowa organizacja związkowa. 
3. O wyznaczeniu przedstawiciela związku zawodowego do składu komisji 
zakładowa 
organizacja 
związkowa 
zawiadamia 
wyższego 
przełożonego 
dyscyplinarnego w terminie 7 dni od dnia otrzymania zawiadomienia o powołaniu 
takiej komisji. W przypadku niewyznaczenia przedstawiciela związku zawodowego, 
trzeciego członka komisji wyznacza wyższy przełożony dyscyplinarny. 
4. Wyższy przełożony dyscyplinarny wyznacza przewodniczącego spośród 
członków komisji. 
5. Przepisy art. 135c ust. 1–3 stosuje się odpowiednio do członków komisji. 
6. Komisja może wysłuchać rzecznika dyscyplinarnego, obwinionego lub jego 
obrońcę. 
7. Niestawiennictwo prawidłowo zawiadomionych: rzecznika dyscyplinarnego, 
obwinionego lub jego obrońcy nie wstrzymuje rozpoznawania sprawy. 
8. Komisja może wystąpić do wyższego przełożonego dyscyplinarnego o 
uzupełnienie materiału dowodowego w trybie art. 135l ust. 1.

***
## Art. 135n. {#policja-art-135n}

1. Z przeprowadzonych czynności komisja sporządza sprawozdanie 
wraz z wnioskiem dotyczącym sposobu załatwienia odwołania. 

 
 
 
s. 248/274 
 
2025-07-03 
 
2. 
Komisja 
przedstawia 
wyższemu 
przełożonemu 
dyscyplinarnemu 
sprawozdanie, o którym mowa w ust. 1, w terminie 21 dni od dnia jej powołania. 
3. Rozpatrzenie odwołania przez wyższego przełożonego dyscyplinarnego 
następuje w terminie 30 dni od dnia wpływu odwołania, a w przypadku powołania 
komisji – w terminie 14 dni od dnia otrzymania sprawozdania, o którym mowa w ust. 
1. 
4. Wyższy przełożony dyscyplinarny może zaskarżone orzeczenie: 
1) 
utrzymać w mocy albo 
2) 
uchylić w całości albo w części i w tym zakresie uniewinnić obwinionego, 
odstąpić od ukarania, względnie wymierzyć inną karę dyscyplinarną albo 
umorzyć postępowanie, albo uchylając to orzeczenie – umorzyć postępowanie 
dyscyplinarne pierwszej instancji, albo 
3) 
uchylić w całości i przekazać sprawę do ponownego rozpatrzenia przez 
przełożonego 
dyscyplinarnego, 
gdy 
rozstrzygnięcie 
sprawy 
wymaga 
przeprowadzenia czynności dowodowych w całości lub w znacznej części. 
5. Postępowanie odwoławcze umarza się w przypadku cofnięcia odwołania. 
6. W postępowaniu odwoławczym wyższy przełożony dyscyplinarny nie może 
wymierzyć surowszej kary dyscyplinarnej, chyba że zaskarżone orzeczenie rażąco 
narusza prawo lub interes służby.

***
## Art. 135o. {#policja-art-135o}

1. Orzeczenie lub postanowienie staje się prawomocne: 
1) 
z upływem terminu do wniesienia odwołania, wniosku o ponowne rozpatrzenie 
sprawy lub zażalenia, jeżeli go nie wniesiono; 
2) 
w dniu wydania orzeczenia lub postanowienia przez organ odwoławczy. 
2. Przełożony dyscyplinarny, po uprawomocnieniu się orzeczenia lub 
postanowienia, niezwłocznie wykonuje orzeczoną karę.  
3. Przełożony właściwy w sprawach osobowych po uprawomocnieniu się 
orzeczenia niezwłocznie wykonuje karę ostrzeżenia o niepełnej przydatności do 
służby na zajmowanym stanowisku lub karę ostrzeżenia o niepełnej przydatności do 
służby. 
4. Przełożony, o którym mowa w ust. 3, po uprawomocnieniu się orzeczenia 
niezwłocznie wykonuje karę: wyznaczenia na niższe stanowisko służbowe, obniżenia 
stopnia lub wydalenia ze służby przez wydanie rozkazu personalnego odpowiednio o: 
zwolnieniu lub odwołaniu ukaranego z dotychczas zajmowanego stanowiska 

 
 
 
s. 249/274 
 
2025-07-03 
 
służbowego i powołaniu lub mianowaniu go na niższe stanowisko służbowe, 
obniżeniu stopnia lub zwolnieniu ukaranego policjanta ze służby. Przepis art. 134e 
ust. 2 stosuje się odpowiednio. 
5. Prawomocne orzeczenie o odstąpieniu od ukarania albo o ukaraniu oraz 
prawomocne 
postanowienie 
o 
odstąpieniu 
od 
wszczęcia 
postępowania 
dyscyplinarnego włącza się do akt osobowych policjanta.

***
## Art. 135p. {#policja-art-135p}

1. W zakresie nieuregulowanym w niniejszej ustawie do 
postępowania dyscyplinarnego stosuje się odpowiednio przepisy Kodeksu 
postępowania karnego dotyczące porządku czynności procesowych, z wyjątkiem art. 
117 i art. 117a, wezwań, terminów, doręczeń i świadków, z wyłączeniem możliwości 
nakładania kar porządkowych oraz konfrontacji, okazania, oględzin i eksperymentu 
procesowego. W postępowaniu dyscyplinarnym do świadków nie stosuje się przepisu 
art. 184 Kodeksu postępowania karnego. 
2. O zwolnieniu od złożenia zeznania lub odpowiedzi na pytania osoby 
pozostającej z obwinionym w szczególnie bliskim stosunku osobistym rozstrzyga 
rzecznik dyscyplinarny. Na odmowę zwolnienia od złożenia zeznania lub odpowiedzi 
na pytania służy zażalenie w terminie 3 dni od dnia doręczenia postanowienia.

***
## Art. 135q. {#policja-art-135q}

1. Zatarcie kary dyscyplinarnej oznacza uznanie kary za niebyłą. 
2. Kary dyscyplinarne podlegają zatarciu po upływie: 
1) 
6 miesięcy od dnia uprawomocnienia się orzeczenia kary upomnienia lub 
nagany; 
2) 
12 miesięcy od dnia uprawomocnienia się orzeczenia kary ostrzeżenia o 
niepełnej przydatności do służby na zajmowanym stanowisku; 
3) 
18 miesięcy od dnia uprawomocnienia się orzeczenia kary wyznaczenia na niższe 
stanowisko służbowe; 
4) 
24 miesięcy od dnia uprawomocnienia się orzeczenia kary ostrzeżenia o 
niepełnej przydatności do służby. 
3. W przypadku nienagannej służby stwierdzonej w opinii służbowej przełożony 
dyscyplinarny, o którym mowa w art. 32 ust. 1, może zatrzeć karę dyscyplinarną przed 
upływem terminu określonego w ust. 2, jednak nie wcześniej niż przed upływem: 
1) 
3 miesięcy od dnia uprawomocnienia się orzeczenia kary upomnienia lub 
nagany; 

 
 
 
s. 250/274 
 
2025-07-03 
 
2) 
6 miesięcy od dnia uprawomocnienia się orzeczenia kary ostrzeżenia o niepełnej 
przydatności do służby na zajmowanym stanowisku; 
3) 
9 miesięcy od dnia uprawomocnienia się orzeczenia kary wyznaczenia na niższe 
stanowisko służbowe; 
4) 
12 miesięcy od dnia uprawomocnienia się orzeczenia kary ostrzeżenia o 
niepełnej przydatności do służby. 
3a. Kara obniżenia stopnia podlega zatarciu po upływie terminu przewidzianego 
dla kary dyscyplinarnej wymierzonej obok kary obniżenia stopnia. Przepis ust. 3 
stosuje się odpowiednio. 
4. Za wykazanie męstwa lub odwagi oraz za poważne osiągnięcia w 
wykonywaniu zadań służbowych przełożony dyscyplinarny, o którym mowa w art. 32 
ust. 1, może w każdym czasie zatrzeć karę dyscyplinarną. 
5. Jeżeli policjant zostanie ponownie ukarany przed zatarciem kary 
dyscyplinarnej, okres wymagany do zatarcia nieodbytej kary biegnie na nowo od dnia 
orzeczenia nowej kary. 
6. W przypadku jednoczesnego wykonywania więcej niż jednej kary 
dyscyplinarnej zatarcie kar następuje z upływem terminu przewidzianego dla kary 
surowszej. 
7. Zatarcie kary dyscyplinarnej powoduje usunięcie z akt osobowych policjanta 
orzeczenia o ukaraniu. Orzeczenie o odstąpieniu od ukarania usuwa się z akt 
osobowych po upływie 6 miesięcy od dnia jego uprawomocnienia się, przepisy ust. 3 
i 4 stosuje się odpowiednio.

***
## Art. 135qa. {#policja-art-135qa}

1. Decyzję o zatarciu kary dyscyplinarnej w przypadku, o którym 
mowa w art. 135q ust. 3, wydaje przełożony dyscyplinarny, o którym mowa w art. 32 
ust. 1. 
2. Decyzję o zatarciu kary dyscyplinarnej doręcza się policjantowi.

***
## Art. 135r. {#policja-art-135r}

1. Postępowanie dyscyplinarne zakończone prawomocnym 
orzeczeniem wznawia się, jeżeli: 
1) 
dowody, na podstawie których ustalono istotne dla sprawy okoliczności, okazały 
się fałszywe; 
2) 
zostały ujawnione istotne dla sprawy okoliczności, które nie były znane w toku 
postępowania dyscyplinarnego; 

 
 
 
s. 251/274 
 
2025-07-03 
 
3) 
orzeczenie wydano z naruszeniem obowiązujących przepisów, jeżeli mogło to 
mieć wpływ na treść orzeczenia; 
4) 
orzeczenie zostało wydane w oparciu o inną decyzję lub orzeczenie sądu, które 
zostały następnie uchylone lub zmienione; 
5) 
prowadzone o ten sam czyn postępowanie karne, karne skarbowe lub w sprawach 
o wykroczenia zostało zakończone prawomocnym wyrokiem uniewinniającym 
albo orzeczeniem o umorzeniu postępowania ze względu na okoliczności 
określone w art. 17 § 1 pkt 1 lub 2 Kodeksu postępowania karnego albo w art. 5 
§ 1 pkt 1 lub 2 Kodeksu postępowania w sprawach o wykroczenia. 
2. Postępowanie dyscyplinarne wznawia się na wniosek ukaranego lub 
obwinionego albo, w przypadku jego śmierci, na wniosek jego małżonka, krewnych 
w linii prostej, rodzeństwa, przysposabiającego lub przysposobionego oraz rzecznika 
dyscyplinarnego, jeżeli w wyniku orzeczenia Trybunału Konstytucyjnego stracił moc 
lub uległ zmianie przepis prawny będący podstawą wydania orzeczenia 
dyscyplinarnego. 
3. W przypadku, o którym mowa w ust. 2, wniosek o wznowienie składa się w 
terminie miesiąca od dnia wejścia w życie orzeczenia Trybunału Konstytucyjnego. 
4. Postępowania dyscyplinarnego nie wznawia się na niekorzyść ukaranego po 
ustaniu karalności przewinienia dyscyplinarnego. 
5. Postępowania dyscyplinarnego nie wznawia się po upływie 10 lat od dnia 
uprawomocnienia się orzeczenia dyscyplinarnego. 
5a. Przepisu ust. 5 nie stosuje się do spraw o wznowienie postępowania 
dyscyplinarnego zakończonego prawomocnym orzeczeniem o wydaleniu ze służby. 
6. 
Przełożony 
dyscyplinarny, 
który 
wydał 
prawomocne 
orzeczenie 
dyscyplinarne, wznawia postępowanie dyscyplinarne z urzędu lub na wniosek 
ukaranego lub obwinionego albo, w przypadku jego śmierci, na wniosek jego 
małżonka, krewnych w linii prostej, rodzeństwa, przysposabiającego lub 
przysposobionego. O wznowieniu postępowania dyscyplinarnego z urzędu 
zawiadamia się ukaranego lub obwinionego albo, w przypadku jego śmierci, jego 
małżonka, krewnych w linii prostej, rodzeństwo, przysposabiającego lub 
przysposobionego. 
7. Wniosek o wznowienie postępowania dyscyplinarnego wnosi się do 
przełożonego dyscyplinarnego, który wydał orzeczenie w pierwszej instancji, w 

 
 
 
s. 252/274 
 
2025-07-03 
 
terminie 30 dni od dnia, w którym obwiniony dowiedział się o okoliczności 
stanowiącej podstawę do wznowienia postępowania. 
8. Jeżeli przyczyną wznowienia postępowania jest działalność przełożonego 
dyscyplinarnego, o którym mowa w ust. 6, o wznowieniu rozstrzyga wyższy 
przełożony dyscyplinarny. 
9. Na postanowienie o odmowie wznowienia postępowania dyscyplinarnego 
ukaranemu oraz osobom, o których mowa w ust. 6, służy zażalenie do wyższego 
przełożonego dyscyplinarnego w terminie 7 dni od dnia doręczenia, z tym że na 
postanowienie wydane przez Komendanta Głównego Policji przysługuje jedynie w 
takim samym terminie wniosek o ponowne rozpatrzenie sprawy.

***
## Art. 135s. {#policja-art-135s}

1. Po wznowieniu postępowania dyscyplinarnego przeprowadza się 
czynności dowodowe ograniczone do przyczyn wznowienia, a po ich zakończeniu, 
stosownie do poczynionych ustaleń, wydaje się orzeczenie: 
1) 
uchylające dotychczasowe orzeczenie i stwierdzające uniewinnienie ukaranego 
lub umorzenie postępowania dyscyplinarnego albo 
2) 
zmieniające dotychczasowe orzeczenie i wymierzające inną karę dyscyplinarną, 
albo 
3) 
odmawiające uchylenia dotychczasowego orzeczenia. 
2. Zmiana dotychczasowego orzeczenia i wymierzenie innej kary dyscyplinarnej 
nie może nastąpić po ustaniu karalności przewinienia dyscyplinarnego. 
3. Orzeczenie kary surowszej od dotychczasowej jest możliwe tylko wtedy, gdy 
wznowienie następuje z urzędu i orzeczona kara jest rażąco niewspółmierna do 
popełnionego przewinienia dyscyplinarnego. 
4. Jeżeli w następstwie wznowienia postępowania wymierzono karę 
łagodniejszą, ulegają uchyleniu skutki kary dotychczasowej, a w razie wymierzenia 
kary surowszej, jej wykonanie rozpoczyna się od dnia wymierzenia. 
5. Na orzeczenie i postanowienie wydane w trybie wznowienia postępowania 
dyscyplinarnego służy ukaranemu lub obwinionemu, a w przypadku jego śmierci, jego 
małżonkowi, krewnym w linii prostej, rodzeństwu, przysposabiającemu lub 
przysposobionemu, 
odwołanie 
lub 
zażalenie 
do 
wyższego 
przełożonego 
dyscyplinarnego w terminie 7 dni od dnia doręczenia, z tym że na orzeczenia i 
postanowienia wydane przez Komendanta Głównego Policji przysługuje jedynie w 

 
 
 
s. 253/274 
 
2025-07-03 
 
takim samym terminie wniosek o ponowne rozpatrzenie sprawy. Przepisy art. 135n 
ust. 4–6 stosuje się odpowiednio. 
6. Termin zatarcia kary zmienionej w następstwie wznowienia postępowania 
liczy się od dnia uprawomocnienia się orzeczenia o wymierzeniu nowej kary. Na 
poczet okresu zatarcia nowej kary zalicza się okres zatarcia, który upłynął od 
uprawomocnienia się orzeczenia kary dotychczasowej.

***
## Art. 136. {#policja-art-136}

(uchylony)

***
## Art. 137. {#policja-art-137}

(uchylony)

***
## Art. 138. {#policja-art-138}

Od orzeczenia i postanowienia kończących postępowanie 
dyscyplinarne policjantowi przysługuje prawo wniesienia skargi do sądu 
administracyjnego.

***
## Art. 139. {#policja-art-139}

Minister właściwy do spraw wewnętrznych określi, w drodze 
rozporządzenia, obieg dokumentów związanych z postępowaniem dyscyplinarnym 
oraz wzory postanowień i innych dokumentów sporządzanych w postępowaniu 
dyscyplinarnym, mając na względzie potrzebę zapewnienia rzetelności i sprawności 
prowadzonego postępowania.

***
## Art. 140. {#policja-art-140}

(uchylony)

***
## Art. 141. {#policja-art-141}

(uchylony)

***
## Art. 141a. {#policja-art-141a}

Przepisy art. 115 § 18 oraz art. 318 i 344 Kodeksu karnego mają 
odpowiednie zastosowanie do funkcjonariuszy Policji.

***
## Art. 142. {#policja-art-142}

(uchylony)

***
## Art. 143. {#policja-art-143}

(uchylony)

***
## Art. 144. {#policja-art-144}

(uchylony)

***
## Art. 144a. {#policja-art-144a}

Nie popełnia przestępstwa, kto, będąc do tego uprawnionym, 
wykonuje czynności określone w art. 19a ust. 1 i 2, a także kto wykonuje czynności 
określone w art. 19b ust. 1.

***
## Art. 145. {#policja-art-145}

(uchylony) 

 
 
 
s. 254/274 
 
2025-07-03

