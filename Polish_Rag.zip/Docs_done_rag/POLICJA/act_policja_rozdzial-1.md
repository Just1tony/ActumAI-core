---
id: act.policja.ch1
title: Ustawa o Policji — Rozdział 1
dz_u: Dz.U. 1990 Nr 30 poz. 179 (t.j. 2025 poz. 636, 718)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '1'
  last: 3a
source_pdf: D19900179Lj (1).pdf
chunking:
  strategy: by-article
  anchor_pattern: '## Art. {n}. {#policja-art-{n}}'
  hierarchy:
  - Rozdział
  - Art.
---

# Rozdział 1
 
## Art. 1. {#policja-art-1}

1. Tworzy się Policję jako umundurowaną i uzbrojoną formację służącą 
społeczeństwu i przeznaczoną do ochrony bezpieczeństwa ludzi oraz do utrzymywania 
bezpieczeństwa i porządku publicznego. 
1a. Nazwa „Policja” przysługuje wyłącznie formacji, o której mowa w ust. 1. 
2. Do podstawowych zadań Policji należą: 
1) 
ochrona życia i zdrowia ludzi oraz mienia przed bezprawnymi zamachami 
naruszającymi te dobra; 
2) 
ochrona bezpieczeństwa i porządku publicznego, w tym zapewnienie spokoju w 
miejscach publicznych oraz w środkach publicznego transportu i komunikacji 
publicznej, w ruchu drogowym i na wodach przeznaczonych do powszechnego 
korzystania; 
3) 
inicjowanie i organizowanie działań mających na celu zapobieganie popełnianiu 
przestępstw i wykroczeń oraz zjawiskom kryminogennym i współdziałanie w 
tym zakresie z organami państwowymi, samorządowymi i organizacjami 
społecznymi; 
3a) prowadzenie działań kontrterrorystycznych w rozumieniu ustawy z dnia 10 
czerwca 2016 r. o działaniach antyterrorystycznych (Dz. U. z 2025 r. poz. 194); 
 
1) Niniejsza ustawa wdraża w zakresie swojej regulacji dyrektywę Parlamentu Europejskiego i Rady 
(UE) 2019/1158 z dnia 20 czerwca 2019 r. w sprawie równowagi między życiem zawodowym 
a prywatnym rodziców i opiekunów oraz uchylającą dyrektywę Rady 2010/18/UE (Dz. Urz. 
UE L 188 z 12.07.2019, str. 79). 

podstawie: 
t.j. 

poz. 636, 718. 

 
 
 
s. 2/274 
 
2025-07-03 
 
4) 
wykrywanie przestępstw i wykroczeń oraz ściganie ich sprawców; 
4a) ochrona obiektów stanowiących siedziby członków Rady Ministrów, z 
wyłączeniem obiektów służących Ministrowi Obrony Narodowej i Ministrowi 
Sprawiedliwości, 
wskazanych 
przez 
ministra 
właściwego 
do 
spraw 
wewnętrznych; 
5) 
nadzór nad specjalistycznymi uzbrojonymi formacjami ochronnymi w zakresie 
określonym w odrębnych przepisach; 
6) 
kontrola 
przestrzegania 
przepisów 
porządkowych 
i 
administracyjnych 
związanych z działalnością publiczną lub obowiązujących w miejscach 
publicznych; 
7) 
współdziałanie 
z 
policjami 
innych 
państw 
oraz 
ich 
organizacjami 
międzynarodowymi, a także z organami i instytucjami Unii Europejskiej na 
podstawie umów i porozumień międzynarodowych oraz odrębnych przepisów; 
8) 
przetwarzanie informacji kryminalnych, w tym danych osobowych; 
9) 
(uchylony) 
10) prowadzenie zbiorów danych zawierających informacje gromadzone przez 
uprawnione organy o odciskach linii papilarnych osób, niezidentyfikowanych 
śladach linii papilarnych z miejsc przestępstw oraz o wynikach analizy kwasu 
deoksyrybonukleinowego (DNA). 
11) (uchylony) 
3. Policja realizuje także zadania wynikające z innych ustaw, z przepisów prawa 
Unii Europejskiej oraz umów i porozumień międzynarodowych na zasadach i w 
zakresie w nich określonych. 
4. (uchylony)

***
## Art. 2. {#policja-art-2}

W zakresie, trybie i na zasadach określonych w odrębnych przepisach 
zadania przewidziane dla Policji wykonują w Siłach Zbrojnych Rzeczypospolitej 
Polskiej oraz w stosunku do żołnierzy Żandarmeria Wojskowa i wojskowe organy 
porządkowe.

***
## Art. 3. {#policja-art-3}

Wojewoda oraz wójt (burmistrz, prezydent miasta) lub starosta 
sprawujący władzę administracji ogólnej oraz organy gminy, powiatu i samorządu 
województwa wykonują zadania w zakresie ochrony bezpieczeństwa lub porządku 
publicznego na zasadach określonych w ustawach. 

 
 
 
s. 3/274 
 
2025-07-03

***
## Art. 3a. {#policja-art-3a}

Obowiązku doręczenia korespondencji przy wykorzystaniu publicznej 
usługi rejestrowanego doręczenia elektronicznego albo publicznej usługi hybrydowej, 
o których mowa w ustawie z dnia 18 listopada 2020 r. o doręczeniach elektronicznych 
(Dz. U. z 2024 r. poz. 1045 i 1841), nie stosuje się:  
1) 
w sprawach osobowych funkcjonariuszy Policji;  
2) 
w sprawach osobowych byłych funkcjonariuszy Policji;  
3) 
jeżeli doręczenie korespondencji przy wykorzystaniu publicznej usługi 
rejestrowanego doręczenia elektronicznego albo publicznej usługi hybrydowej 
mogłoby istotnie utrudniać lub uniemożliwić realizację zadań Policji.

