---
id: act.policja.ch9
title: Ustawa o Policji — Rozdział 8
dz_u: Dz.U. 1990 Nr 30 poz. 179 (t.j. 2025 poz. 636, 718)
status: obowiązujący
last_consolidated: '2025'
articles_range:
  first: '88'
  last: '98'
source_pdf: D19900179Lj (1).pdf
chunking:
  strategy: by-article
  anchor_pattern: '## Art. {n}. {#policja-art-{n}}'
  hierarchy:
  - Rozdział
  - Art.
---

# Rozdział 8
 
## Art. 88. {#policja-art-88}

1. Policjantowi w służbie stałej przysługuje prawo do lokalu 
mieszkalnego w miejscowości, w której pełni służbę, lub w miejscowości pobliskiej, 
z uwzględnieniem liczby członków rodziny oraz ich uprawnień wynikających z 
przepisów odrębnych. 
2. Policjant w służbie przygotowawczej lub kontraktowej może otrzymać 
tymczasową kwaterę. 
3. Policjant traci prawo do lokalu mieszkalnego w razie dyscyplinarnego 
wydalenia ze służby. 
4. Miejscowością pobliską, o której mowa w ust. 1, jest miejscowość, z której 
czas dojazdu do miejsca pełnienia służby i z powrotem środkami publicznego 
transportu zbiorowego, zgodnie z rozkładem jazdy, łącznie z przesiadkami, nie 
przekracza w obie strony dwóch godzin, licząc od stacji (przystanku) położonej 
najbliżej miejsca zamieszkania do stacji (przystanku) położonej najbliżej miejsca 
pełnienia służby bez uwzględnienia czasu dojazdu do i od stacji (przystanku) w 
obrębie miejscowości, z której policjant dojeżdża, oraz miejscowości, w której 
wykonuje obowiązki służbowe.

***
## Art. 89. {#policja-art-89}

Członkami rodziny policjanta, których uwzględnia się przy przydziale 
lokalu mieszkalnego, są pozostający z policjantem we wspólnym gospodarstwie 
domowym: 
1) 
małżonek; 
2) 
dzieci (własne lub małżonka, przysposobione lub przyjęte na wychowanie w 
ramach rodziny zastępczej) pozostające na jego utrzymaniu, nie dłużej jednak niż 
do ukończenia przez nie 25 lat życia; 
3) 
rodzice policjanta i jego małżonka będący na jego wyłącznym utrzymaniu lub 
jeżeli ze względu na wiek albo inwalidztwo10), albo inne okoliczności są 
niezdolni do wykonywania zatrudnienia; za rodziców uważa się również ojczyma 
i macochę oraz osoby przysposabiające. 
 
10) Obecnie całkowita lub częściowa niezdolność do pracy, na podstawie art. 10 ust. 1 ustawy, o której 
mowa w odnośniku 7. 

 
 
 
s. 190/274 
 
2025-07-03

***
## Art. 90. {#policja-art-90}

Na lokale mieszkalne dla policjantów przeznacza się lokale będące w 
dyspozycji ministra właściwego do spraw wewnętrznych lub podległych mu organów.

***
## Art. 91. {#policja-art-91}

1. Policjantowi przysługuje równoważnik pieniężny za remont 
zajmowanego lokalu mieszkalnego, z uwzględnieniem liczby członków rodziny oraz 
ich uprawnień wynikających z przepisów odrębnych. 
2. Minister właściwy do spraw wewnętrznych, w porozumieniu z ministrem 
właściwym do spraw finansów publicznych, określi, w drodze rozporządzenia, 
wysokość oraz szczegółowe zasady przyznawania, odmowy przyznania, cofania 
i zwracania równoważnika, o którym mowa w ust. 1, uwzględniając podmioty 
uprawnione do jego otrzymania, wzory wymaganych dokumentów, organy właściwe 
do jego przyznawania, odmowy przyznania, wypłaty, cofania albo żądania jego zwrotu 
oraz sposób postępowania w przypadku wystąpienia zbiegu uprawnień do jego 
otrzymania.

***
## Art. 92. {#policja-art-92}

1. Policjantowi przysługuje równoważnik pieniężny, jeżeli on sam lub 
członkowie jego rodziny nie posiadają lokalu mieszkalnego w miejscu pełnienia 
służby lub w miejscowości pobliskiej. 
2. Minister właściwy do spraw wewnętrznych, w porozumieniu z ministrem 
właściwym do spraw finansów publicznych, określi, w drodze rozporządzenia, 
wysokość oraz szczegółowe zasady przyznawania, odmowy przyznania, cofania oraz 
zwracania równoważnika pieniężnego, o którym mowa w ust. 1, uwzględniając 
podmioty uprawnione do jego otrzymania, sposób ustalania wysokości równoważnika, 
wzory wymaganych dokumentów, organy właściwe do jego przyznawania, odmowy 
przyznania, wypłaty, cofania albo żądania jego zwrotu, a także sposób postępowania 
w przypadku wystąpienia zbiegu uprawnień do jego otrzymania.

***
## Art. 93. {#policja-art-93}

1. Policjantowi, który zajmuje lokal mieszkalny w miejscowości 
pobliskiej miejsca pełnienia służby, przysługuje zwrot kosztów dojazdu do miejsca 
pełnienia służby w wysokości ceny biletów za przejazd koleją lub autobusem. 
2. Zwrot kosztów, o których mowa w ust. 1, nie przysługuje w roku 
kalendarzowym, w którym wykupiono uprawnienia do bezpłatnych przejazdów 
państwowymi środkami komunikacji, na podstawie odrębnych przepisów.

***
## Art. 94. {#policja-art-94}

1. Policjantowi, który nie otrzymał lokalu mieszkalnego na podstawie 
decyzji administracyjnej o przydziale, przysługuje pomoc finansowa na uzyskanie 

 
 
 
s. 191/274 
 
2025-07-03 
 
lokalu mieszkalnego w spółdzielni mieszkaniowej albo domu jednorodzinnego lub 
lokalu mieszkalnego stanowiącego odrębną nieruchomość. 
1a. Osoba, która została skazana prawomocnym wyrokiem sądu za przestępstwo 
umyślne lub przestępstwo skarbowe umyślne, ścigane z oskarżenia publicznego, 
popełnione w związku z wykonywaniem obowiązków służbowych i w celu 
osiągnięcia korzyści majątkowej lub osobistej, albo za przestępstwo określone w art. 
258 Kodeksu karnego lub wobec której orzeczono prawomocnie środek karny 
pozbawienia praw publicznych za przestępstwo lub przestępstwo skarbowe, jest 
obowiązana do zwrotu pomocy finansowej, o której mowa w ust. 1. 
2. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
tryb postępowania oraz szczegółowe zasady przyznawania, cofania oraz zwracania 
pomocy finansowej, o której mowa w ust. 1, uwzględniając przypadki, w których 
pomoc ta jest przyznawana, cofana lub podlega zwrotowi, jak również sposób 
obliczania wysokości pomocy finansowej przyznawanej lub orzekanej do zwrotu, a 
także rodzaje dokumentów wymaganych przy ubieganiu się o przyznanie tej pomocy.

***
## Art. 95. {#policja-art-95}

1. Lokalu mieszkalnego na podstawie decyzji administracyjnej nie 
przydziela się policjantowi: 
1) 
w razie skorzystania z pomocy finansowej, o której mowa w art. 94; 
2) 
posiadającemu w miejscowości, w której pełni służbę, lub w miejscowości 
pobliskiej lokal mieszkalny odpowiadający co najmniej przysługującej mu 
powierzchni 
mieszkalnej 
albo 
dom 
jednorodzinny 
lub 
dom 
mieszkalno-pensjonatowy; 
3) 
którego małżonek posiada lokal mieszkalny lub dom określony w pkt 2; 
4) 
w razie zbycia przez niego lub jego małżonka własnościowego prawa do 
spółdzielczego lokalu mieszkalnego stanowiącego odrębną nieruchomość albo 
dom, o którym mowa w pkt 2, z wyjątkiem przypadków określonych na 
podstawie art. 96 ust. 3. 
2. Decyzję o opróżnieniu lokalu mieszkalnego, o którym mowa w art. 90, wydaje 
się, jeżeli policjant: 
1) 
podnajmuje albo oddaje do bezpłatnego używania przydzielony lokal lub jego 
część; 

 
 
 
s. 192/274 
 
2025-07-03 
 
2) 
używa lokal mieszkalny w sposób sprzeczny z umową najmu lub niezgodnie z 
przeznaczeniem, zaniedbuje obowiązki, dopuszczając do powstania szkód, albo 
niszczy urządzenia przeznaczone do wspólnego korzystania przez mieszkańców; 
3) 
wykracza w sposób rażący lub uporczywy przeciwko porządkowi domowemu, 
czyniąc uciążliwym korzystanie z innych lokali; 
4) 
jest w zwłoce z zapłatą czynszu lub opłat za świadczenia związane z eksploatacją 
lokalu przez okres co najmniej dwóch pełnych okresów płatności, pomimo 
uprzedzania na piśmie o zamiarze wydania decyzji o opróżnieniu lokalu i 
wyznaczenia dodatkowego, miesięcznego terminu zapłaty zaległych i bieżących 
należności; 
5) 
otrzymał pomoc finansową, o której mowa w art. 94 ust. 1; 
6) 
został przeniesiony do pełnienia służby w innej miejscowości i przydzielono mu 
w tej lub pobliskiej miejscowości następny lokal mieszkalny; 
7) 
nie zwolnił, w terminie określonym odrębnymi przepisami, wcześniej 
przydzielonego lokalu mieszkalnego; 
8) 
zrzekł się uprawnień do zajmowanego lokalu mieszkalnego; 
9) 
został skazany prawomocnym wyrokiem sądu za przestępstwo umyślne lub 
przestępstwo skarbowe umyślne, ścigane z oskarżenia publicznego, popełnione 
w związku z wykonywaniem obowiązków służbowych i w celu osiągnięcia 
korzyści majątkowej lub osobistej, albo za przestępstwo określone w art. 258 
Kodeksu karnego lub wobec którego orzeczono prawomocnie środek karny 
pozbawienia praw publicznych za przestępstwo lub przestępstwo skarbowe. 
3. Decyzję o opróżnieniu lokalu mieszkalnego wydaje się także: 
1) 
jeżeli policjantowi lub jego małżonkowi przysługuje tytuł prawny do innego 
lokalu mieszkalnego, o którym mowa w art. 90; w takim przypadku osobom tym 
przysługuje prawo wyboru jednego z zajmowanych lokali; 
2) 
gdy policjant zwolniony ze służby lub pozostali po policjancie członkowie 
rodziny zajmują lokal mieszkalny położony w budynku przeznaczonym na cele 
służbowe lub na terenie obiektu zamkniętego, a osobom tym przydzielono lokal 
mieszkalny w tej samej lub pobliskiej miejscowości, o powierzchni 
odpowiadającej przysługującym normom zaludnienia; 
3) 
w przypadku zajmowania lokalu mieszkalnego, o którym mowa w art. 90, przez 
policjanta lub członków jego rodziny albo inne osoby – bez tytułu prawnego. 

 
 
 
s. 193/274 
 
2025-07-03 
 
3a. Decyzję o opróżnieniu lokalu wydaje się również, jeżeli właściciel lokalu 
wypowiedział stosunek prawny dotyczący lokalu. 
4. Decyzję o opróżnieniu lokalu wydaje się w stosunku do wszystkich osób 
zamieszkałych w tym lokalu.

***
## Art. 96. {#policja-art-96}

1. Policjantowi przeniesionemu do służby w innej miejscowości, który 
poza miejscem pełnienia służby posiada lokal mieszkalny, dom jednorodzinny lub 
dom mieszkalno-pensjonatowy, może być przydzielony lokal mieszkalny na 
podstawie decyzji administracyjnej w nowym miejscu pełnienia służby, jeżeli: 
1) 
zwolni zajmowany lokal mieszkalny lub dom; 
2) 
zwróci pomoc finansową przyznaną: 
a) 
na 
wkład 
mieszkaniowy 
lub 
wkład 
budowlany 
w 
wysokości 
zwaloryzowanej przez spółdzielnię, 
b) 
na spłatę innych należności – w wysokości przyznanej. 
2. Policjantowi, który skorzystał z pomocy finansowej, może być przydzielony 
lokal mieszkalny na podstawie decyzji administracyjnej, jeżeli zwolni zajmowany 
lokal mieszkalny lub dom, o którym mowa w ust. 1, oraz zwróci pomoc finansową na 
zasadach określonych w tym przepisie. 
3. Minister właściwy do spraw wewnętrznych określi, w drodze rozporządzenia, 
tryb przydzielania lokalu mieszkalnego w przypadkach, o których mowa w ust. 1 i 2, 
szczegółowe zasady zwracania udzielonej pomocy finansowej oraz zwalniania 
zajmowanych lokali mieszkalnych lub domów określonych w ust. 1, uwzględniając 
przesłanki uzasadniające przydział lokalu mieszkalnego policjantowi przeniesionemu 
do służby w innej miejscowości, sposób postępowania w przypadku, gdy policjant ten 
skorzystał z pomocy finansowej na uzyskanie lokalu mieszkalnego, oraz rodzaje 
dokumentów potwierdzających zwolnienie przez policjanta lokalu mieszkalnego 
dotychczas zajmowanego. 
4. Policjantowi przeniesionemu z urzędu do służby w innej miejscowości lub 
innej jednostce organizacyjnej Policji, który nie zwolnił zajmowanego lokalu 
mieszkalnego lub domu, o którym mowa w ust. 1, można przydzielić tymczasową 
kwaterę według przysługujących norm, bez uwzględnienia zamieszkałych z nim 
członków rodziny. Koszty zakwaterowania pokrywane są ze środków budżetowych 
Policji. 

 
 
 
s. 194/274 
 
2025-07-03 
 
5. Policjant delegowany do czasowego pełnienia służby w innej miejscowości 
otrzymuje tymczasową kwaterę. Koszty zakwaterowania pokrywa się ze środków 
budżetu Policji.

***
## Art. 97. {#policja-art-97}

1. Minister właściwy do spraw wewnętrznych, w porozumieniu z 
ministrem właściwym do spraw budownictwa, planowania i zagospodarowania 
przestrzennego oraz mieszkalnictwa, określi, w drodze rozporządzenia, szczegółowe 
zasady przydziału i opróżniania oraz normy zaludnienia lokali mieszkalnych, o 
których mowa w art. 90, a także szczegółowe zasady przydziału lokalu mieszkalnego 
i tymczasowej kwatery policjantowi, opróżnienia lub zamiany tego lokalu i 
tymczasowej kwatery, oraz organy właściwe do wydawania decyzji administracyjnych 
w tych sprawach, wysokość norm zaludnienia i sposób ich ustalania. 
2. Minister właściwy do spraw wewnętrznych, w porozumieniu z ministrem 
właściwym do spraw budownictwa, planowania i zagospodarowania przestrzennego 
oraz mieszkalnictwa oraz ministrem właściwym do spraw finansów publicznych, 
określi, w drodze rozporządzenia, warunki najmu lokali mieszkalnych znajdujących 
się w budynkach będących własnością Skarbu Państwa pozostających w zarządzie 
jednostek organizacyjnych Policji, a także sposób obliczania czynszu najmu, prawa i 
obowiązki najemcy oraz wynajmującego, a także części składowe czynszu najmu i 
okoliczności wpływające na jego wysokość. 
3. Dodatkowe normy zaludnienia określone na podstawie ust. 1, związane z 
zajmowanym stanowiskiem służbowym lub posiadanym stopniem, stosuje się również 
przy przydziałach policjantom innych lokali mieszkalnych niż wymienione w art. 90. 
4. W sprawach spornych, wynikających ze stosunku najmu lokali, o których 
mowa w ust. 2, rozstrzygają sądy powszechne. 
5. Przydział i opróżnianie mieszkań oraz załatwianie spraw, o których mowa w 
art. 91, 92, 94 i 95 ust. 2–4, następuje w formie decyzji administracyjnej.

***
## Art. 98. {#policja-art-98}

Policjant zwolniony ze służby, który nie posiada prawa do lokalu 
mieszkalnego na warunkach określonych w przepisach o zaopatrzeniu emerytalnym 
funkcjonariuszy Policji, Agencji Bezpieczeństwa Wewnętrznego, Agencji Wywiadu, 
Służby Kontrwywiadu Wojskowego, Służby Wywiadu Wojskowego, Centralnego 
Biura Antykorupcyjnego, Straży Granicznej, Straży Marszałkowskiej, Służby 
Ochrony Państwa, Państwowej Straży Pożarnej i Służby Więziennej oraz ich rodzin, 

 
 
 
s. 195/274 
 
2025-07-03 
 
zachowuje prawo do przydzielonego lokalu mieszkalnego według norm powszechnie 
obowiązujących lub może być przeniesiony do zamiennego lokalu mieszkalnego.

