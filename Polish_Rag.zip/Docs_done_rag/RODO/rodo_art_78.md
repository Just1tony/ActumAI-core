---
id: rodo-art-78
title: RODO — Artykuł 78
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '78'
anchors:
- rodo-art-78
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 78 {#rodo-art-78}

1. Prezes Urzędu przeprowadza kontrolę przestrzegania przepisów 
o ochronie danych osobowych. 
2. Kontrolę prowadzi się zgodnie z zatwierdzonym przez Prezesa Urzędu 
planem kontroli lub na podstawie uzyskanych przez Prezesa Urzędu informacji lub 
w ramach monitorowania przestrzegania stosowania rozporządzenia 2016/679.
