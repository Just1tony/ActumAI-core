---
id: rodo-art-7
title: RODO — Artykuł 7
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '7'
anchors:
- rodo-art-7
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 7 {#rodo-art-7}

1. W sprawach nieuregulowanych w ustawie do postępowań 
administracyjnych przed Prezesem Urzędu Ochrony Danych Osobowych, zwanym 
dalej „Prezesem Urzędu”, o których mowa w rozdziałach 4–7 i 11, stosuje się 
ustawę z dnia 14 czerwca 1960 r. – Kodeks postępowania administracyjnego. 
2. Postępowanie 
przed 
Prezesem 
Urzędu 
jest 
postępowaniem 
jednoinstancyjnym. 
3. Do postanowień wydanych w postępowaniach, o których mowa w ust. 1, 
na które zgodnie z ustawą z dnia 14 czerwca 1960 r. − Kodeks postępowania 
administracyjnego służy zażalenie, przepisów o zażaleniu nie stosuje się. 
4. Na postanowienia, o których mowa w ust. 3, służy skarga do sądu 
administracyjnego. 
Rozdział 2 
Wyznaczanie inspektora ochrony danych
