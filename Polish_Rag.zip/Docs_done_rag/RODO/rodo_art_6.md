---
id: rodo-art-6
title: RODO — Artykuł 6
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '6'
anchors:
- rodo-art-6
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 6 {#rodo-art-6}

Ustawy oraz rozporządzenia 2016/679 nie stosuje się do: 
1) 
przetwarzania danych osobowych przez jednostki sektora finansów 
publicznych, o których mowa w art. 9 pkt 1, 3, 5, 6 i 14 ustawy z dnia 
27 sierpnia 2009 r. o finansach publicznych (Dz. U. z 2019 r. poz. 869 i 1622), 
w zakresie, w jakim przetwarzanie to jest konieczne do realizacji zadań 
mających na celu zapewnienie bezpieczeństwa narodowego, jeżeli przepisy 
szczególne przewidują niezbędne środki ochrony praw i wolności osoby, 
której dane dotyczą; 
2) 
działalności służb specjalnych w rozumieniu art. 11 ustawy z dnia 24 maja 
2002 r. o Agencji Bezpieczeństwa Wewnętrznego oraz Agencji Wywiadu 
(Dz. U. z 2018 r. poz. 2387, 2245 i 2399 oraz z 2019 r. poz. 53, 125 i 1091).
