---
id: rodo-art-72
title: RODO — Artykuł 72
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '72'
anchors:
- rodo-art-72
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 72 {#rodo-art-72}

W uzasadnieniu 
decyzji 
kończącej 
postępowanie 
w sprawie 
wskazuje się dodatkowo przesłanki określone w art. 83 ust. 2 rozporządzenia 
2016/679, na których Prezes Urzędu oparł się, nakładając administracyjną karę 
pieniężną oraz ustalając jej wysokość.
