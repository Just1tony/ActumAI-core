---
id: rodo-art-56
title: RODO — Artykuł 56
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '56'
anchors:
- rodo-art-56
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 56 {#rodo-art-56}

Prezes Urzędu, w drodze decyzji: 
1) 
zatwierdza 
wiążące 
reguły 
korporacyjne, 
o których 
mowa 
w art. 47 rozporządzenia 2016/679; 
2) 
udziela 
zezwolenia, 
o którym 
mowa 
w art. 46 ust. 3 rozporządzenia 
2016/679. 

 
s. 26/47 
 
10.10.2019
