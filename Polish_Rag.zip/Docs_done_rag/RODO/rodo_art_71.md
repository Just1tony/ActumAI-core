---
id: rodo-art-71
title: RODO — Artykuł 71
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '71'
anchors:
- rodo-art-71
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 71 {#rodo-art-71}

1. Jeżeli w toku postępowania Prezes Urzędu uzna, że istnieją 
uzasadnione wątpliwości co do zgodności z prawem Unii Europejskiej decyzji 
Komisji Europejskiej, o której mowa w art. 40 ust. 9 w sprawie kodeksu 

 
s. 29/47 
 
10.10.2019 
 
postępowania, o którym mowa w art. 46 ust. 2 lit. e, oraz decyzji, o której mowa 
w art. 45 ust. 3 i 5 i art. 46 ust. 2 lit. c rozporządzenia 2016/679, Prezes Urzędu 
występuje do sądu administracyjnego z wnioskiem o wystąpienie z pytaniem 
prawnym na podstawie art. 267 Traktatu o funkcjonowaniu Unii Europejskiej 
w sprawie ważności decyzji Komisji Europejskiej. 
2. Wniosek, o którym mowa w ust. 1, poza spełnianiem wymagań 
dotyczących skargi, o których mowa w art. 64 § 2 ustawy z dnia 30 sierpnia 2002 r. 
– Prawo o postępowaniu przed sądami administracyjnymi (Dz. U. z 2018 r. poz. 
1302, z późn. zm.5)), zawiera w szczególności: 
1) 
wskazanie decyzji Komisji Europejskiej, której wniosek dotyczy; 
2) 
omówienie powodów, dla których Prezes Urzędu powziął wątpliwości 
w kwestii ważności decyzji Komisji Europejskiej i jej niezgodności 
z przepisami prawa; 
3) 
treść pytania lub pytań, które sąd administracyjny przedstawia Trybunałowi 
Sprawiedliwości Unii Europejskiej, zawierającą: 
a) 
przedmiot sporu oraz ustalenia co do okoliczności faktycznych, w tym 
stanowisko strony podniesione w postępowaniu przed organem, jeżeli 
zostało przedstawione przez stronę, 
b) 
wskazanie przepisów prawa mających zastosowanie w sprawie, 
c) 
proponowaną do przedstawienia Trybunałowi Sprawiedliwości Unii 
Europejskiej przez sąd administracyjny sentencję pytania lub pytań; 
4) 
oświadczenie o zgodności treści załącznika, o którym mowa w ust. 3, 
z wnioskiem złożonym w postaci papierowej. 
3. Do wniosku, o którym mowa w ust. 1, dołącza się załącznik zawierający 
treść 
wniosku 
w formie 
dokumentu 
elektronicznego 
zapisanego 
na 
informatycznym nośniku danych w formacie danych pozwalającym na edycję jego 
treści. 
4. Stroną postępowania przed sądem administracyjnym w sprawie wniosku, 
o którym mowa w ust. 1, jest Prezes Urzędu. 
5. Sąd administracyjny rozpoznaje wniosek, o którym mowa w ust. 1, na 
posiedzeniu niejawnym, w składzie 3 sędziów. 
                                                           
5) Zmiany tekstu jednolitego wymienionej ustawy zostały ogłoszone w Dz. U. z 2018 r. poz. 1467 
i 1629 oraz z 2019 r. poz. 11, 60, 848 i 934. 

 
s. 30/47 
 
10.10.2019 
 
6. Sąd administracyjny, uznając wniosek, o którym mowa w ust. 1, za 
uzasadniony, występuje do Trybunału Sprawiedliwości Unii Europejskiej 
z pytaniem prejudycjalnym na podstawie art. 267 Traktatu o funkcjonowaniu Unii 
Europejskiej. 
7. W przypadku uznania przez sąd administracyjny, że wniosek, o którym 
mowa w ust. 1, nie zawiera wystarczającego uzasadnienia dla wystąpienia 
z pytaniem prejudycjalnym do Trybunału Sprawiedliwości Unii Europejskiej, 
wydaje się postanowienie o odmowie wystąpienia z pytaniem. 
8. Na postanowienie, o którym mowa w ust. 7, nie służy środek odwoławczy. 
9. Sąd administracyjny sporządza uzasadnienie postanowienia, o którym 
mowa w ust. 7, w terminie 21 dni. 
10. Od wniosku, o którym mowa w ust. 1, nie pobiera się opłaty sądowej.
