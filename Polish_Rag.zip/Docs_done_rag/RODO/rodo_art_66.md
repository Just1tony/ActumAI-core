---
id: rodo-art-66
title: RODO — Artykuł 66
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '66'
anchors:
- rodo-art-66
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 66 {#rodo-art-66}

Prezes Urzędu wydaje postanowienie, o którym mowa w art. 74 § 2 
ustawy z dnia 14 czerwca 1960 r. – Kodeks postępowania administracyjnego, 
również w przypadku, gdy udostępnienie informacji i dokumentów, o których 
mowa w art. 65 ust. 1, grozi ujawnieniem tajemnic prawnie chronionych albo 
ujawnieniem tajemnicy przedsiębiorstwa, jeżeli o ograniczenie wglądu do akt dla 
stron postępowania wnosi przedsiębiorca, od którego informacja pochodzi.
