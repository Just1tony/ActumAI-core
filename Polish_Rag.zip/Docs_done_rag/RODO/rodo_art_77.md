---
id: rodo-art-77
title: RODO — Artykuł 77
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '77'
anchors:
- rodo-art-77
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 77 {#rodo-art-77}

W przypadku otrzymania przez Prezesa Urzędu wniosku organu 
nadzorczego innego państwa członkowskiego Unii Europejskiej dotyczącego 
uczestnictwa we wspólnej operacji, o której mowa w art. 62 ust. 1 rozporządzenia 
2016/679, albo wystąpienia przez Prezesa Urzędu z takim wnioskiem, Prezes 
Urzędu dokonuje z organem nadzorczym innego państwa członkowskiego Unii 
Europejskiej ustaleń dotyczących wspólnej operacji i niezwłocznie sporządza 
wykaz ustaleń. 
Rozdział 9 
Kontrola przestrzegania przepisów o ochronie danych osobowych
