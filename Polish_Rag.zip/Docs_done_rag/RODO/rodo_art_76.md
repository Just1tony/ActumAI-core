---
id: rodo-art-76
title: RODO — Artykuł 76
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '76'
anchors:
- rodo-art-76
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 76 {#rodo-art-76}

Wszelkie informacje kierowane przez Prezesa Urzędu do organów 
nadzorczych innych państw członkowskich w ramach europejskiej współpracy 
administracyjnej podlegają tłumaczeniu na jeden z języków urzędowych tego 
państwa członkowskiego lub na język angielski.
