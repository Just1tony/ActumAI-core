---
id: rodo-art-68
title: RODO — Artykuł 68
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '68'
anchors:
- rodo-art-68
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 68 {#rodo-art-68}

1. Jeżeli w toku postępowania zajdzie konieczność uzupełnienia 
dowodów, Prezes Urzędu może przeprowadzić postępowanie kontrolne. 
2. Okresu postępowania kontrolnego nie wlicza się do terminów, o których 
mowa w art. 35 ustawy z dnia 14 czerwca 1960 r. – Kodeks postępowania 
administracyjnego.
