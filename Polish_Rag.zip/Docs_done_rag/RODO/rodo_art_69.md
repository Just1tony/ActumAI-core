---
id: rodo-art-69
title: RODO — Artykuł 69
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '69'
anchors:
- rodo-art-69
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 69 {#rodo-art-69}

1. W przypadku, o którym mowa w art. 88 ustawy z dnia 14 czerwca 
1960 r. – Kodeks postępowania administracyjnego, Prezes Urzędu wymierza karę 
grzywny w wysokości od 500 złotych do 5000 złotych. 
2. Wymierzając karę grzywny, Prezes Urzędu bierze pod uwagę: 
1) 
w przypadku osoby fizycznej – sytuację osobistą wezwanego i stopień 
zrozumienia powagi ciążących na nim obowiązków wynikających 
z wezwania lub 
2) 
potrzebę dostosowania wysokości kary grzywny do celu, jakim jest 
przymuszenie wezwanego do zadośćuczynienia wezwaniu. 
3. Kara grzywny, o której mowa w ust. 1, może być nałożona także 
w przypadku, gdy strona odmówiła przedstawienia tłumaczenia na język polski 
dokumentacji sporządzonej w języku obcym.
