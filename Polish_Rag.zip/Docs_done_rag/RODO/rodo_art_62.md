---
id: rodo-art-62
title: RODO — Artykuł 62
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '62'
anchors:
- rodo-art-62
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 62 {#rodo-art-62}

W przypadku, o którym mowa w art. 36 ustawy z dnia 14 czerwca 
1960 r. − Kodeks postępowania administracyjnego, Prezes Urzędu, zawiadamiając 

 
s. 27/47 
 
10.10.2019 
 
strony 
o niezałatwieniu 
sprawy 
w terminie, 
jest 
obowiązany 
również 
poinformować o stanie sprawy i przeprowadzonych w jej toku czynnościach.
