---
id: rodo-art-98
title: RODO — Artykuł 98
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '98'
anchors:
- rodo-art-98
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 98 {#rodo-art-98}

1. 
W sprawach 
o roszczenia 
z tytułu 
naruszenia 
przepisów 
o ochronie danych osobowych, które mogą być dochodzone wyłącznie 
w postępowaniu przed sądem, Prezes Urzędu może wytaczać powództwa na rzecz 
osoby, której dane dotyczą, za jej zgodą, a także wstępować, za zgodą powoda, do 
postępowania w każdym jego stadium. 
2. W pozostałych sprawach o roszczenia z tytułu naruszenia przepisów 
o ochronie danych osobowych Prezes Urzędu może wstępować, za zgodą powoda, 
do postępowania przed sądem w każdym jego stadium, chyba że toczy się przed 
nim postępowanie dotyczące tego samego naruszenia przepisów o ochronie danych 
osobowych. 

 
s. 39/47 
 
10.10.2019 
 
3. W przypadkach, o których mowa w ust. 1 i 2, do Prezesa Urzędu stosuje się 
odpowiednio przepisy ustawy z dnia 17 listopada 1964 r. – Kodeks postępowania 
cywilnego (Dz. U. z 2019 r. poz. 1460, 1469 i 1495) o prokuratorze.
