---
id: rodo-art-64
title: RODO — Artykuł 64
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '64'
anchors:
- rodo-art-64
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 64 {#rodo-art-64}

W celu realizacji swoich zadań Prezes Urzędu ma prawo dostępu do 
informacji objętych tajemnicą prawnie chronioną, chyba że przepisy szczególne 
stanowią inaczej.
