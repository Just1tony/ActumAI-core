---
id: rodo-art-65
title: RODO — Artykuł 65
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '65'
anchors:
- rodo-art-65
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 65 {#rodo-art-65}

1. Strona może zastrzec informacje, dokumenty lub ich części 
zawierające tajemnicę przedsiębiorstwa, przedstawiane Prezesowi Urzędu. 
W takim przypadku strona jest obowiązana przedstawić Prezesowi Urzędu również 
wersję dokumentu niezawierającą informacji objętych zastrzeżeniem. 
2. W przypadku nieprzedstawienia wersji dokumentu niezawierającej 
informacji objętych zastrzeżeniem, zastrzeżenie uważa się za nieskuteczne. 
3. Prezes Urzędu może uchylić zastrzeżenie, w drodze decyzji, jeżeli uzna, że 
informacje, dokumenty lub ich części nie spełniają przesłanek do objęcia ich 
tajemnicą przedsiębiorstwa. 
4. W przypadku ustawowego obowiązku przekazania informacji lub 
dokumentów otrzymanych od przedsiębiorców innym krajowym lub zagranicznym 
organom lub instytucjom, informacje i dokumenty przekazuje się wraz 
z zastrzeżeniem i pod warunkiem jego przestrzegania.
