---
id: rodo-art-99
title: RODO — Artykuł 99
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '99'
anchors:
- rodo-art-99
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 99 {#rodo-art-99}

Prezes Urzędu, jeżeli uzna, że przemawia za tym interes publiczny, 
przedstawia sądowi istotny dla sprawy pogląd w sprawie o roszczenie z tytułu 
naruszenia przepisów o ochronie danych osobowych.
