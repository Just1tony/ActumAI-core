---
id: rodo-art-70
title: RODO — Artykuł 70
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '70'
anchors:
- rodo-art-70
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 70 {#rodo-art-70}

1. Jeżeli w toku postępowania zostanie uprawdopodobnione, że 
przetwarzanie danych osobowych narusza przepisy o ochronie danych osobowych, 
a dalsze ich przetwarzanie może spowodować poważne i trudne do usunięcia 
skutki, Prezes Urzędu, w celu zapobieżenia tym skutkom, może, w drodze 
postanowienia, zobowiązać podmiot, któremu jest zarzucane naruszenie przepisów 
o ochronie danych osobowych, do ograniczenia przetwarzania danych osobowych, 
wskazując dopuszczalny zakres tego przetwarzania. 
2. W postanowieniu, o którym mowa w ust. 1, Prezes Urzędu określa termin 
obowiązywania ograniczenia przetwarzania danych osobowych nie dłuższy niż do 
dnia wydania decyzji kończącej postępowanie w sprawie. 
3. Na postanowienie, o którym mowa w ust. 1, służy skarga do sądu 
administracyjnego.
