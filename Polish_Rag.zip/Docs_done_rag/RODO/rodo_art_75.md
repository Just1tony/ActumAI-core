---
id: rodo-art-75
title: RODO — Artykuł 75
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '75'
anchors:
- rodo-art-75
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 75 {#rodo-art-75}

1. W przypadkach, o których mowa w art. 61 ust. 8, art. 62 ust. 7 
i art. 66 ust. 1 rozporządzenia 
2016/679, 
Prezes 
Urzędu 
może 
wydać 

 
s. 31/47 
 
10.10.2019 
 
postanowienie 
o zastosowaniu 
środka 
tymczasowego, 
o którym 
mowa 
w art. 70 ust. 1. 
2. W postanowieniu Prezes Urzędu określa termin obowiązywania środka 
tymczasowego, o którym mowa w art. 70 ust. 1, nie dłuższy niż 3 miesiące. 
3. Na postanowienie służy skarga do sądu administracyjnego.
