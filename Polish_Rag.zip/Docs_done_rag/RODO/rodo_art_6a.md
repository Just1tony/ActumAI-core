---
id: rodo-art-6a
title: RODO — Artykuł 6a
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: 6a
anchors:
- rodo-art-6a
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 6a {#rodo-art-6a}

1. Do przetwarzania danych osobowych w ramach wykonywania 
konstytucyjnych i ustawowych kompetencji Prezydenta Rzeczypospolitej Polskiej, 
w zakresie nieobjętym bezpieczeństwem narodowym, stosuje się odpowiednio 
przepisy art. 4–7, art. 11, art. 12, art. 16, art. 17, art. 24 ust. 1 i 2, art. 25 ust. 1 i 2, 
art. 28–30, art. 32, art. 34, art. 35, art. 37–39 i art. 86 rozporządzenia 2016/679 oraz 
przepisy art. 6 i art. 11 ustawy.  
2. Przetwarzanie danych, o których mowa w art. 9 i art. 10 rozporządzenia 
2016/679, następuje w zakresie niezbędnym do realizacji konstytucyjnych i 
ustawowych kompetencji Prezydenta Rzeczypospolitej Polskiej, jeżeli prawa lub 
wolności osoby, której dane dotyczą, nie są nadrzędne w stosunku do realizacji 
zadań wynikających z tych kompetencji. 

 
s. 6/47 
 
10.10.2019
