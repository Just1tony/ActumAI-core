---
id: rodo-art-8
title: RODO — Artykuł 8
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '8'
anchors:
- rodo-art-8
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 8 {#rodo-art-8}

Administrator 
i podmiot 
przetwarzający 
są 
obowiązani 
do 
wyznaczenia inspektora ochrony danych, zwanego dalej „inspektorem”, 
w przypadkach i na zasadach określonych w art. 37 rozporządzenia 2016/679.
