---
id: rodo-art-74
title: RODO — Artykuł 74
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '74'
anchors:
- rodo-art-74
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 74 {#rodo-art-74}

Wniesienie przez stronę skargi do sądu administracyjnego 
wstrzymuje wykonanie decyzji w zakresie administracyjnej kary pieniężnej. 
Rozdział 8 
Europejska współpraca administracyjna
