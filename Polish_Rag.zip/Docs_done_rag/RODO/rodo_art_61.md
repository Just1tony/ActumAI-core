---
id: rodo-art-61
title: RODO — Artykuł 61
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '61'
anchors:
- rodo-art-61
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 61 {#rodo-art-61}

Organizacja społeczna, o której mowa w art. 31 § 1 ustawy z dnia 
14 czerwca 1960 r. − Kodeks postępowania administracyjnego, może również 
występować w postępowaniu za zgodą osoby, której dane dotyczą, w jej imieniu 
i na jej rzecz.
