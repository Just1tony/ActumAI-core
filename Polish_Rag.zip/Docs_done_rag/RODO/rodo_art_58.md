---
id: rodo-art-58
title: RODO — Artykuł 58
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '58'
anchors:
- rodo-art-58
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 58 {#rodo-art-58}

Jeżeli Prezes Urzędu, na podstawie posiadanych informacji, uzna, że 
doszło do naruszenia przepisów dotyczących przetwarzania danych osobowych, 
może żądać wszczęcia postępowania dyscyplinarnego lub innego przewidzianego 
prawem postępowania przeciwko osobom, które dopuściły się naruszeń, 
i poinformowania go, w określonym terminie, o wynikach tego postępowania 
i podjętych działaniach.
