---
id: rodo-art-57
title: RODO — Artykuł 57
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '57'
anchors:
- rodo-art-57
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 57 {#rodo-art-57}

1. Administrator może wystąpić do Prezesa Urzędu z wnioskiem o 
przeprowadzenie uprzednich konsultacji, o których mowa w art. 36 rozporządzenia 
2016/679. 
2. Do wniosku stosuje się odpowiednio przepis art. 63 ustawy z dnia 
14 czerwca 1960 r. – Kodeks postępowania administracyjnego. 
3. Jeżeli 
wniosek 
nie 
spełnia 
wymogów 
określonych 
w art. 36 ust. 3 rozporządzenia 2016/679 oraz art. 63 ustawy z dnia 14 czerwca 
1960 r. – Kodeks postępowania administracyjnego, Prezes Urzędu informuje 
o nieudzieleniu konsultacji, wskazując przyczyny ich nieudzielenia.
