---
id: rodo-art-9
title: RODO — Artykuł 9
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '9'
anchors:
- rodo-art-9
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 9 {#rodo-art-9}

Przez organy i podmioty publiczne obowiązane do wyznaczenia 
inspektora, o których mowa w art. 37 ust. 1 lit. a rozporządzenia 2016/679, 
rozumie się: 
1) 
jednostki sektora finansów publicznych; 
2) 
instytuty badawcze; 
3) 
Narodowy Bank Polski.
