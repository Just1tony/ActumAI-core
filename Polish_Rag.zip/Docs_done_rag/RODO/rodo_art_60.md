---
id: rodo-art-60
title: RODO — Artykuł 60
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '60'
anchors:
- rodo-art-60
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 60 {#rodo-art-60}

Postępowanie w sprawie naruszenia przepisów o ochronie danych 
osobowych, zwane dalej „postępowaniem”, jest prowadzone przez Prezesa Urzędu.
