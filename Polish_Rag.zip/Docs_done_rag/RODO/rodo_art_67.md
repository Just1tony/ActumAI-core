---
id: rodo-art-67
title: RODO — Artykuł 67
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '67'
anchors:
- rodo-art-67
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 67 {#rodo-art-67}

Jeżeli liczba stron w postępowaniu przekracza 20, Prezes Urzędu 
może zastosować przepis art. 49 ustawy z dnia 14 czerwca 1960 r. – Kodeks 
postępowania administracyjnego. 

 
s. 28/47 
 
10.10.2019
