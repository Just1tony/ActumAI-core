---
id: rodo-art-59
title: RODO — Artykuł 59
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '59'
anchors:
- rodo-art-59
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 59 {#rodo-art-59}

1. Prezes Urzędu w sprawach ochrony danych osobowych 
współpracuje z niezależnymi organami nadzorczymi powołanymi na podstawie 
art. 91 rozporządzenia 2016/679. 
2. Prezes Urzędu może zawrzeć z organami, o których mowa w ust. 1, 
porozumienie o współpracy i wzajemnym przekazywaniu informacji. 
Rozdział 7 
Postępowanie w sprawie naruszenia przepisów o ochronie danych osobowych
