---
id: rodo-art-73
title: RODO — Artykuł 73
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '73'
anchors:
- rodo-art-73
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 73 {#rodo-art-73}

1. Prezes Urzędu, jeżeli uzna, że przemawia za tym interes publiczny, 
po zakończeniu postępowania informuje o wydaniu decyzji na swojej stronie 
podmiotowej w Biuletynie Informacji Publicznej. 
2. Jednostki sektora finansów publicznych, instytuty badawcze oraz 
Narodowy Bank Polski, w stosunku do których Prezes Urzędu wydał prawomocną 
decyzję stwierdzającą naruszenie, niezwłocznie podają do publicznej wiadomości 
na swojej stronie internetowej lub stronie podmiotowej w Biuletynie Informacji 
Publicznej, informację o działaniach podjętych w celu wykonania decyzji.
