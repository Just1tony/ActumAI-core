---
id: rodo-art-5a
title: RODO — Artykuł 5a
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: 5a
anchors:
- rodo-art-5a
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 5a {#rodo-art-5a}

1. Administrator, który otrzymał dane osobowe od podmiotu 
realizującego zadanie publiczne, nie wykonuje obowiązków, o których mowa w art. 
15 ust. 1–3 rozporządzenia 2016/679, w przypadku gdy podmiot przekazujący dane 
osobowe wystąpił z żądaniem w tym zakresie ze względu na konieczność 
prawidłowego wykonania zadania publicznego mającego na celu: 
1) 
zapobieganie przestępczości, wykrywanie lub ściganie czynów zabronionych 
lub wykonywanie kar, w tym ochronę przed zagrożeniami dla bezpieczeństwa 
publicznego i zapobieganie takim zagrożeniom; 
2) 
ochronę interesów gospodarczych i finansowych państwa obejmującą w 
szczególności: 
a) 
realizację i dochodzenie dochodów z podatków, opłat, niepodatkowych 
należności budżetowych oraz innych należności, 
b) 
wykonywanie egzekucji administracyjnej należności pieniężnych i 
niepieniężnych 
oraz 
wykonywanie 
zabezpieczenia 
należności 
pieniężnych i niepieniężnych, 

 
s. 5/47 
 
10.10.2019 
 
c) 
przeciwdziałanie wykorzystywaniu działalności banków i instytucji 
finansowych do celów mających związek z wyłudzeniami skarbowymi, 
d) 
ujawnianie i odzyskiwanie mienia zagrożonego przepadkiem w związku 
z przestępstwami, 
e) 
prowadzenie kontroli, w tym kontroli celno-skarbowych. 
2. W przypadku, o którym mowa w ust. 1, administrator udziela odpowiedzi 
na żądanie wniesione na podstawie art. 15 rozporządzenia 2016/679 w sposób, 
który uniemożliwia ustalenie, że administrator przetwarza dane osobowe 
otrzymane od podmiotu wykonującego zadanie publiczne.
