---
id: rodo-art-63
title: RODO — Artykuł 63
short: RODO
source_pdf: D20181000Lj.pdf
status: obowiązujący
last_consolidated: '2018'
articles_range: '63'
anchors:
- rodo-art-63
chunking:
  strategy: per-article
  anchor_pattern: '## Art. {n} {#rodo-art-{n}}'
---

## Art. 63 {#rodo-art-63}

Prezes Urzędu może żądać od strony przedstawienia tłumaczenia na 
język polski sporządzonej w języku obcym dokumentacji przedłożonej przez 
stronę. Tłumaczenie dokumentacji strona jest obowiązana wykonać na własny 
koszt.
