---
id: "code_kpk_dzial-xi"
title: "KPK — DZIAŁ XI"
source_pdf: "D19970555Lj (1).pdf"
dz_u: "Dz. U. 1997 Nr 89 poz. 555"
status: "obowiązujący"
last_consolidated: "2025-09-11"
law: "Kodeks postępowania karnego"
tags: ["kpk", "kodeks", "postępowanie karne"]
articles_range: {"first": "519", "last": "548"}
---

# DZIAŁ XI

## Art. 519. {#kpk-art-519}
Od prawomocnego wyroku 

sądu odwoławczego kończącego 

postępowanie oraz od prawomocnego postanowienia 

sądu odwoławczego 

o umorzeniu postępowania i zastosowaniu środka zabezpieczającego określonego 

w art. 93a Kodeksu karnego może być wniesiona kasacja. Przepisu art. 425 § 2 zdanie 

trzecie nie stosuje się.


## Art. 520. {#kpk-art-520}
§ 1. Do wniesienia kasacji uprawnione są strony. 

§ 2. Strona, która nie zaskarżyła orzeczenia sądu pierwszej instancji, nie może 

wnieść kasacji od orzeczenia sądu odwoławczego, jeżeli orzeczenie sądu pierwszej 

instancji utrzymano w mocy lub zmieniono na jej korzyść. 

§ 3. Ograniczenie, o którym mowa w § 2, nie dotyczy uchybień wymienionych 

w art. 439.


## Art. 521. {#kpk-art-521}
§ 1. Prokurator Generalny, a także Rzecznik Praw Obywatelskich 

może wnieść kasację od każdego prawomocnego orzeczenia sądu kończącego 

postępowanie. 

§ 2. Rzecznik Praw Dziecka może wnieść kasację od każdego prawomocnego 

orzeczenia sądu kończącego postępowanie, jeżeli przez wydanie orzeczenia doszło do 

naruszenia praw dziecka. 

§ 3. Organy, o których mowa w § 1 i 2, mają prawo żądać do wglądu akt 

sądowych i prokuratorskich oraz akt innych organów ścigania po zakończeniu 

postępowania i zapadnięciu rozstrzygnięcia.


## Art. 522. {#kpk-art-522}
Kasację w stosunku do tego samego oskarżonego i od tego samego 

orzeczenia każdy uprawniony może wnieść tylko raz.


## Art. 523. {#kpk-art-523}
§ 1. Kasacja może być wniesiona 

tylko z powodu uchybień 

wymienionych w art. 439 lub innego rażącego naruszenia prawa, jeżeli mogło ono 

mieć istotny wpływ na treść orzeczenia. Kasacja nie może być wniesiona wyłącznie 

z powodu niewspółmierności kary. 

§ 1a. Ograniczenia, o którym mowa w § 1 zdanie drugie, nie stosuje się do 

kasacji wniesionej przez Prokuratora Generalnego w sprawach o zbrodnie. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 212/356 

§ 2. Kasację na korzyść można wnieść jedynie w razie skazania oskarżonego za 

przestępstwo lub przestępstwo skarbowe na karę pozbawienia wolności bez 

warunkowego zawieszenia jej wykonania. 

§ 3.9) Kasację na niekorzyść można wnieść jedynie w razie uniewinnienia 

oskarżonego albo umorzenia postępowania. 

§ 4. Ograniczenia przewidziane w § 2 i 3 nie dotyczą kasacji: 

1) wniesionej z powodu uchybień wymienionych w art. 439; 

2) w wypadku określonym w art. 521.


## Art. 524. {#kpk-art-524}
§ 1. Termin do wniesienia kasacji dla stron wynosi 30 dni od daty 

doręczenia orzeczenia 

z uzasadnieniem. Wniosek o doręczenie orzeczenia 

z uzasadnieniem należy zgłosić w sądzie, który wydał orzeczenie, w terminie zawitym 

7 dni od daty ogłoszenia orzeczenia, a jeżeli ustawa przewiduje doręczenie orzeczenia, 

od daty jego doręczenia. Przepis art. 445 § 2 stosuje się odpowiednio. 

§ 2. Terminu do wniesienia kasacji wskazanego w § 1 nie stosuje się do kasacji 

wnoszonej przez Prokuratora Generalnego, Rzecznika Praw Obywatelskich 

i Rzecznika Praw Dziecka. 

§ 3. Niedopuszczalne jest uwzględnienie kasacji na niekorzyść oskarżonego 

wniesionej po upływie roku od daty uprawomocnienia się orzeczenia.


## Art. 525. {#kpk-art-525}
§ 1. Strona wnosi kasację do Sądu Najwyższego za pośrednictwem 

sądu odwoławczego. 

§ 2. W wypadku określonym w art. 521 kasację wnosi się bezpośrednio do Sądu 

Najwyższego.


## Art. 526. {#kpk-art-526}
§ 1. W kasacji należy podać, na czym polega zarzucane uchybienie. 

§ 2. Jeżeli kasacja nie pochodzi od prokuratora, Prokuratora Generalnego, 

Rzecznika Praw Obywatelskich albo Rzecznika Praw Dziecka, powinna być 

sporządzona i podpisana przez adwokata, radcę prawnego albo radcę Prokuratorii 

Generalnej Rzeczypospolitej Polskiej. 

9) Utracił moc z dniem 8 lipca 2019 r. w zakresie, w jakim dopuszcza możliwość wniesienia kasacji 
na niekorzyść oskarżonego w razie umorzenia postępowania z powodu zastosowania aktu łaski przez 
Prezydenta Rzeczypospolitej Polskiej, na podstawie wyroku Trybunału Konstytucyjnego z dnia 26 
czerwca 2019 r. sygn. akt K 8/17 (Dz. U. poz. 1255). 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 213/356


## Art. 527. {#kpk-art-527}
§ 1. Do kasacji strona dołącza dowód uiszczenia opłaty sądowej; nie 

dotyczy to prokuratora. 

§ 2. Osoba pozbawiona wolności nie uiszcza opłaty przy wnoszeniu kasacji; 

w wypadku pozostawienia bez rozpoznania albo oddalenia wniesionej przez nią 

kasacji zasądza się od niej opłatę. 

§ 3. Żołnierz odbywający zasadniczą służbę wojskową nie uiszcza opłaty. 

§ 4. Opłata ulega zwrotowi stronie, która ją uiściła, jeżeli kasacja zostanie 

uwzględniona, chociażby w części, albo zostanie cofnięta. 

§ 5. Minister Sprawiedliwości określa, w drodze rozporządzenia, wysokość 

opłaty, mając na uwadze faktyczne koszty postępowania oraz zasadę dostępu do sądu.


## Art. 528. {#kpk-art-528}
§ 1. Środek odwoławczy nie przysługuje na odmowę: 

1) 

zwolnienia od uiszczenia opłaty, o której mowa w art. 527 § 1; 

2) wyznaczenia adwokata lub radcy prawnego w celu sporządzenia kasacji; 

3) 

przywrócenia terminu, o którym mowa w art. 524 § 1 zdanie pierwsze. 

§ 2. Przepis art. 447 § 4 stosuje się odpowiednio.


## Art. 529. {#kpk-art-529}
10) Wniesieniu i rozpoznaniu kasacji na korzyść oskarżonego nie stoi na 

przeszkodzie wykonanie kary, zatarcie skazania, akt łaski ani też okoliczność 

wyłączająca ściganie lub uzasadniająca zawieszenie postępowania.


## Art. 530. {#kpk-art-530}
§ 1. W wypadku określonym w art. 525 § 1, przyjmując kasację, 

prezes sądu doręcza jej odpis pozostałym stronom oraz, po złożeniu przez prokuratora 

pisemnej odpowiedzi na kasację, niezwłocznie przesyła akta sądowi właściwemu do 

rozpoznania kasacji, jeżeli sąd, do którego wniesiono kasację, nie jest uprawniony do 

jej rozpoznania. 

§ 2. Prezes sądu, do którego wniesiono kasację, odmawia jej przyjęcia, jeżeli 

zachodzą okoliczności, o których mowa w art. 120 § 2 lub w art. 429 § 1, albo gdy 

kasację oparto na innych powodach niż wskazane w art. 523 § 1. 

§ 3. Na zarządzenie, o którym mowa w § 2, zażalenie przysługuje do Sądu 

Najwyższego. Sąd Najwyższy rozpoznaje zażalenie jednoosobowo. Sąd kasacyjny 

10) Utracił moc z dniem 8 lipca 2019 r. w zakresie, w jakim dopuszcza wniesienie i rozpoznanie kasacji 
na niekorzyść oskarżonego w sytuacji, gdy w kasacji zakwestionowano prawidłowość zastosowania 
aktu łaski przez Prezydenta Rzeczypospolitej, na podstawie wyroku Trybunału Konstytucyjnego, o 
którym mowa w odnośniku 9. 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 214/356 

wydaje postanowienie bez udziału stron, chyba że Prezes Sądu Najwyższego zarządzi 

inaczej. 

§ 4. W wypadku przyjęcia kasacji, której prokurator nie uznał za oczywiście 

bezzasadną, odpis pisemnej odpowiedzi prokuratora na kasację doręcza się 

pozostałym stronom, ich obrońcom i pełnomocnikom. Dalsze pisma procesowe wnosi 

się bezpośrednio do sądu kasacyjnego. 

§ 5. Prokurator, uznając kasację za oczywiście bezzasadną, przesyła odpis 

odpowiedzi na kasację pozostałym stronom, ich obrońcom i pełnomocnikom, którzy 

w terminie 14 dni od otrzymania odpowiedzi prokuratora mogą przedstawić sądowi 

na piśmie swoje stanowisko.


## Art. 531. {#kpk-art-531}
§ 1. Sąd Najwyższy pozostawia bez rozpoznania przyjętą kasację, 

jeżeli nie odpowiada ona przepisom wymienionym w art. 530 § 2 lub gdy przyjęcie 

kasacji nastąpiło na skutek niezasadnego przywrócenia terminu. Sąd kasacyjny wydaje 

postanowienie bez udziału stron, chyba że prezes Sądu Najwyższego zarządzi inaczej. 

§ 2. Sąd Najwyższy może jednak zwrócić akta sprawy sądowi odwoławczemu, 

jeżeli stwierdzi, że nie zostały dopełnione czynności zmierzające do usunięcia braków 

formalnych wniesionej kasacji. 

§ 3. Przepis § 1 zdanie drugie stosuje się odpowiednio w wypadku cofnięcia 

kasacji.


## Art. 532. {#kpk-art-532}
§ 1. W razie wniesienia kasacji Sąd Najwyższy może wstrzymać 

wykonanie zaskarżonego orzeczenia, jak i innego orzeczenia, którego wykonanie 

zależy od rozstrzygnięcia kasacji. 

§ 2. Wstrzymanie wykonania orzeczenia można połączyć z zastosowaniem 

środków określonych w art. 266, 271, 272, 275 i 277. 

§ 3. Sąd kasacyjny wydaje postanowienie na posiedzeniu bez udziału stron, 

chyba że prezes Sądu Najwyższego zarządzi inaczej.


## Art. 533. {#kpk-art-533}
Jeżeli kasację wniesiono na niekorzyść oskarżonego, Sąd Najwyższy 

może zastosować środek zapobiegawczy, chyba że oskarżony był uniewinniony.


## Art. 534. {#kpk-art-534}
§ 1. Jeżeli ustawa nie wymaga wydania wyroku, Sąd Najwyższy 

orzeka jednoosobowo, chyba że Prezes Sądu Najwyższego zarządzi rozpoznanie 

sprawy w składzie trzech sędziów. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 215/356 

§ 2. Jeżeli kasacja dotyczy orzeczenia Sądu Najwyższego, podlega rozpoznaniu 

w składzie siedmiu sędziów, chyba że orzeczenie zostało wydane jednoosobowo; 

w takim wypadku Sąd Najwyższy orzeka w składzie trzech sędziów.


## Art. 535. {#kpk-art-535}
§ 1. Sąd Najwyższy rozpoznaje kasację na rozprawie, a w wypadkach 

przewidzianych przez ustawę – na posiedzeniu bez udziału stron. 

§ 2. Strony pozbawionej wolności nie sprowadza się na rozprawę, chyba że 

Prezes Sądu Najwyższego lub Sąd Najwyższy uzna to za konieczne. 

§ 3. Oddalenie kasacji jako oczywiście bezzasadnej nie wymaga pisemnego 

uzasadnienia; jeżeli postanowienie zostało wydane na posiedzeniu oraz wtedy, gdy 

zostało wydane na rozprawie a strona pozbawiona wolności nie miała przedstawiciela 

procesowego i nie została sprowadzona na rozprawę, uzasadnienie sporządza się na 

jej wniosek. Przepisy art. 422 i 423 stosuje się odpowiednio. 

§ 4. Kasację wniesioną na podstawie art. 521 Sąd Najwyższy rozpoznaje na 

rozprawie. 

§ 5. Kasacja może być uwzględniona w całości na posiedzeniu bez udziału stron 

w razie jej oczywistej zasadności.


## Art. 536. {#kpk-art-536}
Sąd Najwyższy 

rozpoznaje kasację w granicach zaskarżenia 

i podniesionych zarzutów, a w zakresie szerszym – tylko w wypadkach określonych 

w art. 435, 439 i 455.


## Art. 537. {#kpk-art-537}
§ 1. Sąd Najwyższy po rozpoznaniu sprawy oddala kasację albo 

zaskarżone orzeczenie uchyla w całości lub w części. 

§ 2. Uchylając zaskarżone orzeczenie Sąd Najwyższy przekazuje sprawę 

właściwemu sądowi do ponownego rozpoznania albo umarza postępowanie, a jeżeli 

skazanie jest oczywiście niesłuszne – uniewinnia oskarżonego.


## Art. 537a. {#kpk-art-537a}
Nie można uchylić wyroku sądu odwoławczego z tego powodu, że 

jego uzasadnienie nie spełnia wymogów określonych w art. 457 § 3.


## Art. 538. {#kpk-art-538}
§ 1. Z chwilą uchylenia wyroku wykonanie kary, środka karnego, 

przepadku i środka kompensacyjnego ustaje; karę, środek karny, przepadek i środek 

kompensacyjny już wykonane – w wypadku późniejszego ponownego skazania – 

zalicza się odpowiednio na poczet nowo orzeczonej kary, środka karnego, przepadku 

i środka kompensacyjnego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 216/356 

§ 2. Sąd Najwyższy, uchylając orzeczenie, może zastosować 

środek 

zapobiegawczy. Na postanowienie o zastosowaniu tymczasowego aresztowania służy 

zażalenie do równorzędnego składu Sądu Najwyższego. 

§ 3. W razie uchylenia prawomocnego wyroku o warunkowym umorzeniu 

postępowania lub orzekającego karę z warunkowym zawieszeniem jej wykonania, 

w wypadku ponownego orzeczenia o warunkowym umorzeniu postępowania lub kary 

z warunkowym zawieszeniem jej wykonania, na poczet okresu próby zalicza się okres 

próby, który upłynął od uprawomocnienia się wyroku do daty jego uchylenia.


## Art. 539. {#kpk-art-539}
Niedopuszczalna jest kasacja od orzeczenia Sądu Najwyższego 

zapadłego w następstwie rozpoznania kasacji. 


# Rozdział 55
a 

Skarga na wyrok sądu odwoławczego


## Art. 539a. {#kpk-art-539a}
§ 1. Od wyroku sądu odwoławczego uchylającego wyrok sądu 

pierwszej instancji i przekazującego sprawę do ponownego rozpoznania stronom 

przysługuje skarga do Sądu Najwyższego. 

§ 2. Wyrok można zaskarżyć w całości lub w części. 

§ 3. Skarga może być wniesiona wyłącznie z powodu naruszenia art. 437 lub 

z powodu uchybień określonych w art. 439 § 1.


## Art. 539b. {#kpk-art-539b}
§ 1. Skargę wnosi się w terminie 7 dni od daty doręczenia wyroku 

z uzasadnieniem. Przepisy art. 524 § 1 zdanie drugie i trzecie stosuje się odpowiednio. 

§ 2. Wniesienie skargi powoduje wstrzymanie wykonania zaskarżonego wyroku.


## Art. 539c. {#kpk-art-539c}
§ 1. Do skargi dołącza się odpowiednią liczbę odpisów dla 

pozostałych stron. 

§ 2. Prezes sądu, doręczając odpis skargi pozostałym stronom, poucza o prawie 

wniesienia pisemnej odpowiedzi na skargę w terminie 7 dni od daty doręczenia odpisu 

skargi. Po upływie tego terminu prezes sądu niezwłocznie przesyła akta Sądowi 

Najwyższemu.


## Art. 539d. {#kpk-art-539d}
Po przekazaniu sprawy do Sądu Najwyższego orzeka on w razie 

potrzeby w przedmiocie środka zapobiegawczego. Na postanowienie o zastosowaniu 

tymczasowego aresztowania służy zażalenie do równorzędnego składu Sądu 

Najwyższego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 217/356


## Art. 539e. {#kpk-art-539e}
§ 1. Sąd Najwyższy rozpoznaje skargę na posiedzeniu bez udziału 

stron. 

§ 2. Sąd Najwyższy postanowieniem oddala skargę albo wyrokiem uchyla 

zaskarżony wyrok w całości lub w części i przekazuje sprawę właściwemu sądowi 

odwoławczemu do ponownego rozpoznania.


## Art. 539f. {#kpk-art-539f}
Przepisy art. 425 § 3 i 4, art. 428 § 1, art. 431, art. 432, art. 435, 

art. 436, art. 442 § 1 i 3, art. 457 § 1 i 3, art. 525 § 1, art. 526, art. 527 § 1–4, art. 528 

§ 1, art. 530 § 2 i 3, art. 531, art. 534 § 1 i art. 536, a także przepisy wydane na 

podstawie art. 527 § 5 stosuje się odpowiednio. 


# Rozdział 56
 

Wznowienie postępowania


## Art. 540. {#kpk-art-540}
§ 1. Postępowanie sądowe zakończone prawomocnym orzeczeniem 

wznawia się, jeżeli: 

1) w związku z postępowaniem dopuszczono się przestępstwa, a istnieje 

uzasadniona podstawa do przyjęcia, że mogło to mieć wpływ na treść orzeczenia; 

2) 

po wydaniu orzeczenia ujawnią się nowe fakty lub dowody wskazujące na to, że: 

a) 

skazany nie popełnił czynu albo czyn jego nie stanowił przestępstwa lub nie 

podlegał karze, 

b) 

skazano go za przestępstwo zagrożone karą surowszą albo nie 

uwzględniono okoliczności 

zobowiązujących do nadzwyczajnego 

złagodzenia kary albo też błędnie przyjęto okoliczności wpływające na 

nadzwyczajne obostrzenie kary, 

c) 

sąd umorzył lub warunkowo umorzył postępowanie karne, błędnie 

przyjmując popełnienie przez oskarżonego zarzucanego mu czynu. 

§ 2. Postępowanie wznawia się na korzyść strony, jeżeli Trybunał Konstytucyjny 

orzekł o niezgodności z Konstytucją, ratyfikowaną umową międzynarodową lub 

z ustawą przepisu prawnego, na podstawie którego zostało wydane orzeczenie; 

wznowienie nie może nastąpić na niekorzyść oskarżonego. 

§ 3. Postępowanie wznawia się na korzyść oskarżonego, gdy potrzeba taka 

wynika z rozstrzygnięcia organu międzynarodowego działającego na mocy umowy 

międzynarodowej ratyfikowanej przez Rzeczpospolitą Polską. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 218/356


## Art. 540a. {#kpk-art-540a}
Postępowanie sądowe zakończone prawomocnym orzeczeniem 

można wznowić, jeżeli: 

1) 

skazany, do którego zastosowano przepis art. 60 § 3 lub 4 Kodeksu karnego lub 

art. 36 § 3 Kodeksu karnego skarbowego, nie potwierdził w postępowaniu 

karnym ujawnionych przez siebie informacji; 

2) 

zachodzi okoliczność określona w art. 11 § 3.


## Art. 540b. {#kpk-art-540b}
§ 1. Postępowanie sądowe zakończone prawomocnym orzeczeniem 

można wznowić na wniosek oskarżonego, złożony w terminie zawitym miesiąca od 

dnia, w którym dowiedział się o zapadłym wobec niego orzeczeniu, jeżeli sprawę 

rozpoznano pod nieobecność oskarżonego, któremu nie doręczono zawiadomienia 

o terminie posiedzenia lub rozprawy albo doręczono je w inny sposób niż osobiście, 

gdy wykaże on, że nie wiedział o terminie oraz o możliwości wydania orzeczenia pod 

jego nieobecność. 

§ 2. Przepisu § 1 nie stosuje się w wypadkach, o których mowa w art. 133 § 2, 

art. 136 § 1 oraz art. 139 § 1, a także jeżeli w rozprawie lub posiedzeniu uczestniczył 

obrońca.


## Art. 541. {#kpk-art-541}
§ 1. Czyn, o którym mowa w art. 540 § 1 pkt 1, musi być ustalony 

prawomocnym wyrokiem skazującym, chyba że orzeczenie takie nie może zapaść 

z powodu przyczyn wymienionych w art. 17 § 1 pkt 3–11 lub w art. 22. 

§ 2. W tym wypadku wniosek o wznowienie postępowania powinien wskazywać 

wyrok skazujący lub orzeczenie zapadłe w postępowaniu karnym, stwierdzające 

niemożność wydania wyroku skazującego.


## Art. 542. {#kpk-art-542}
§ 1. Wznowienie postępowania może nastąpić na wniosek strony lub 

z urzędu. 

§ 2. Wniosek o wznowienie na korzyść złożyć może w razie śmierci skazanego 

osoba najbliższa. 

§ 3. Postępowanie wznawia się z urzędu tylko w razie ujawnienia się jednego 

z uchybień wymienionych w art. 439 § 1, przy czym wznowienie postępowania 

jedynie z powodów określonych w pkt 9–11 może nastąpić tylko na korzyść 

oskarżonego. 

§ 4. Wznowienie nie może nastąpić z przyczyn wymienionych w § 3, jeżeli były 

one przedmiotem rozpoznania w trybie kasacji. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 219/356 

§ 5. Niedopuszczalne jest wznowienie postępowania z urzędu na niekorzyść 

oskarżonego po upływie roku od daty uprawomocnienia się orzeczenia.


## Art. 543. {#kpk-art-543}
(uchylony)


## Art. 544. {#kpk-art-544}
§ 1. W kwestii wznowienia postępowania orzeka sąd okręgowy, zaś 

w kwestii wznowienia postępowania zakończonego orzeczeniem sądu okręgowego – 

sąd apelacyjny. Sąd orzeka w składzie trzech sędziów. 

§ 2. W kwestii wznowienia postępowania zakończonego orzeczeniem sądu 

apelacyjnego lub Sądu Najwyższego orzeka Sąd Najwyższy w składzie trzech 

sędziów. 

§ 3. W kwestii wznowienia postępowania sąd orzeka na posiedzeniu bez udziału 

stron, chyba że prezes sądu lub sąd postanowi inaczej.


## Art. 545. {#kpk-art-545}
§ 1. W postępowaniu o wznowienie stosuje się odpowiednio art. 425 

§ 2 zdanie pierwsze, § 3 i 4, art. 429, art. 430 § 1, art. 431, art. 432, art. 435, art. 442, 

art. 456, art. 457 § 1 i 3, art. 529, art. 530, art. 532 i art. 538, a w razie wznowienia 

postępowania na korzyść oskarżonego stosuje się odpowiednio art. 434 i art. 443. 

§ 2. Wniosek o wznowienie postępowania, jeżeli nie pochodzi od prokuratora, 

powinien być sporządzony i podpisany przez adwokata, radcę prawnego albo radcę 

Prokuratorii Generalnej Rzeczypospolitej Polskiej. Przepisy art. 446 stosuje się 

odpowiednio. 

§ 3. Sąd, 

orzekając 

jednoosobowo, 

odmawia 

przyjęcia wniosku 

niepochodzącego od osoby wymienionej w § 2 bez wzywania do usunięcia jego 

braków formalnych, jeżeli z treści wniosku, w szczególności odwołującego się do 

okoliczności, które były 

już 

rozpoznawane w postępowaniu o wznowienie 

postępowania, wynika jego oczywista bezzasadność. Na postanowienie o odmowie 

przyjęcia wniosku przysługuje zażalenie do tego samego sądu orzekającego 

w składzie trzech sędziów.


## Art. 546. {#kpk-art-546}
Jeżeli sąd zarządził sprawdzenie okoliczności w trybie art. 97, strony 

mają prawo wziąć udział w czynnościach sprawdzających.


## Art. 547. {#kpk-art-547}
§ 1. Na postanowienie oddalające wniosek lub pozostawiające go bez 

rozpoznania przysługuje zażalenie, chyba że orzekł o tym sąd apelacyjny lub Sąd 

Najwyższy. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 220/356 

§ 2. Orzekając o wznowieniu postępowania, sąd uchyla zaskarżone orzeczenie 

i przekazuje sprawę właściwemu sądowi do ponownego rozpoznania. Od tego 

orzeczenia środek odwoławczy nie przysługuje. 

§ 3. Uchylając zaskarżone orzeczenie, sąd może wyrokiem uniewinnić 

oskarżonego, jeżeli nowe fakty lub dowody wskazują na to, że orzeczenie to jest 

oczywiście niesłuszne, albo też postępowanie umorzyć. Od wyroku uniewinniającego 

lub umarzającego postępowanie przysługuje środek odwoławczy. 

§ 4. Od orzeczeń, o których mowa w § 3, wydanych przez Sąd Najwyższy, 

środek odwoławczy nie przysługuje. 

§ 5. Wyrok wydany na posiedzeniu doręcza się stronom.


## Art. 548. {#kpk-art-548}
Jeżeli postępowanie wznowiono na skutek wniosku na korzyść 

oskarżonego i toczy się ono po jego śmierci lub jeżeli zachodzi przyczyna zawieszenia 

postępowania, prezes sądu wyznacza do obrony praw oskarżonego obrońcę z urzędu, 

chyba że wnioskodawca ustanowił już obrońcę.
