---
id: "code_kpk_dzial-xiv"
title: "KPK — DZIAŁ XIV"
source_pdf: "D19970555Lj (1).pdf"
dz_u: "Dz. U. 1997 Nr 89 poz. 555"
status: "obowiązujący"
last_consolidated: "2025-09-11"
law: "Kodeks postępowania karnego"
tags: ["kpk", "kodeks", "postępowanie karne"]
articles_range: {"first": "616", "last": "641"}
---

# DZIAŁ XIV

## Art. 616. {#kpk-art-616}
§ 1. Do kosztów procesu należą: 

koszty sądowe; 

uzasadnione wydatki stron, w tym z tytułu ustanowienia w sprawie jednego 

1) 

2) 

obrońcy lub pełnomocnika. 

§ 2. Koszty sądowe obejmują: 

1) 

opłaty; 

2) wydatki poniesione przez Skarb Państwa od chwili wszczęcia postępowania.


## Art. 617. {#kpk-art-617}
Rodzaje i wysokość opłat oraz zasady i tryb ich wymierzania określa 

odrębna ustawa.


## Art. 618. {#kpk-art-618}
§ 1. Wydatki Skarbu Państwa obejmują w szczególności wypłaty 

dokonane z tytułu: 

1) 

2) 

doręczenia wezwań i innych pism; 

przejazdów sędziów, prokuratorów 

i innych osób z powodu czynności 

postępowania; 

3) 

sprowadzenia i przewozu oskarżonego, świadków i biegłych; 

3a) sprowadzenia i przewozu osoby wydanej na skutek wniosku, o którym mowa 

w art. 593, lub zobowiązanej do powrotu do Rzeczypospolitej Polskiej, jeżeli 

organ procesowy tak postanowi ze względu na wagę sprawy; 

4) 

oględzin, badań przedsięwziętych w toku postępowania oraz przesyłek 

i przechowania zajętych przedmiotów, jak również ich sprzedaży; 

5) 

ogłoszeń w prasie, radiu i telewizji; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 338/356 

6) wykonania orzeczenia, w tym również o zabezpieczeniu grożących kar 

majątkowych, jeżeli kary te zostały orzeczone, z wyłączeniem kosztów 

utrzymania w zakładzie karnym i kosztów pobytu w zakładach leczniczych na 

7) 

8) 

9) 

obserwacji psychiatrycznej; 

należności świadków i tłumaczy; 

kosztów postępowania mediacyjnego; 

należności biegłych lub instytucji wyznaczonych do wydania opinii lub 

wystawienia zaświadczenia, w tym koszty wystawienia zaświadczenia przez 

lekarza sądowego; 

9a) kosztów obserwacji psychiatrycznej oskarżonego, z wyłączeniem należności 

biegłych psychiatrów; 

9b) kosztów zarządu przymusowego; 

10) opłat przewidzianych za udzielenie informacji z rejestru skazanych; 

11) nieopłaconej przez strony pomocy prawnej udzielonej z urzędu przez adwokatów 

lub radców prawnych; 

12) ryczałtu kuratora sądowego za przeprowadzenie wywiadu środowiskowego, 

o którym mowa w art. 214 § 1; 

12a) ryczałtu asystenta rodziny za udział w posiedzeniu albo rozprawie, o których 

mowa w art. 76a § 1; 

13) realizacji umów międzynarodowych, których Rzeczpospolita Polska jest stroną, 

i postępowań prowadzonych na podstawie działu XIII, także jeżeli nie zostało 

wydane postanowienie, o którym mowa w art. 303. 

§ 2. Jeżeli wysokości i zasad ustalania należności określonych w § 1 nie regulują 

odrębne przepisy, Minister Sprawiedliwości, w porozumieniu z ministrem właściwym 

do spraw finansów publicznych, określi, w drodze rozporządzenia, wysokość i sposób 

ich obliczania, mając na uwadze faktyczny koszt dokonania danej czynności. 

§ 3. W razie braku przepisów wymienionych w § 2, o wysokości danego 

wydatku decydują kwoty przyznane przez sąd, prokuratora lub inny organ prowadzący 

postępowanie.


## Art. 618a. {#kpk-art-618a}
§ 1. Świadkowi przysługuje zwrot kosztów podróży – z miejsca jego 

zamieszkania do miejsca wykonywania czynności postępowania na wezwanie sądu 

lub organu prowadzącego postępowanie przygotowawcze – w wysokości 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 339/356 

rzeczywiście poniesionych racjonalnych i celowych kosztów przejazdu własnym 

samochodem lub innym odpowiednim środkiem transportu. 

§ 2. Górną granicę należności, o których mowa w § 1, stanowi wysokość 

kosztów przysługujących pracownikowi zatrudnionemu w państwowej 

lub 

samorządowej jednostce sfery budżetowej z tytułu podróży służbowej na obszarze 

kraju. 

§ 3. Według tych samych zasad świadkowi przysługuje zwrot kosztów noclegu 

oraz utrzymania w miejscu wykonywania czynności postępowania. 

§ 4. Wysokość kosztów, o których mowa w § 1 i 3, świadek powinien należycie 

wykazać.


## Art. 618b. {#kpk-art-618b}
§ 1. Świadkowi przysługuje zwrot zarobku lub dochodu utraconego 

z powodu stawiennictwa na wezwanie sądu lub organu prowadzącego postępowanie 

przygotowawcze. 

§ 2. Wynagrodzenie za utracony zarobek lub dochód za każdy dzień udziału 

w czynnościach postępowania przyznaje się świadkowi w wysokości 

jego 

przeciętnego dziennego zarobku lub dochodu. W przypadku świadka pozostającego 

w stosunku pracy przeciętny dzienny utracony zarobek oblicza się według zasad 

obowiązujących przy ustalaniu należnego pracownikowi ekwiwalentu pieniężnego za 

urlop. 

§ 3. Górną granicę należności, o których mowa w § 2, stanowi równowartość 

4,6 % kwoty bazowej dla osób zajmujących kierownicze stanowiska państwowe, 

której wysokość, ustaloną według odrębnych zasad, określa ustawa budżetowa. 

W przypadku gdy ogłoszenie ustawy budżetowej nastąpi po dniu 1 stycznia roku, 

którego dotyczy ustawa budżetowa, podstawę obliczenia należności za okres od 

1 stycznia do dnia ogłoszenia ustawy budżetowej stanowi kwota bazowa w wysokości 

obowiązującej w grudniu roku poprzedniego. 

§ 4. Utratę zarobku lub dochodu, o których mowa w § 1, oraz ich wysokość 

świadek powinien należycie wykazać.


## Art. 618c. {#kpk-art-618c}
§ 1. Prawo do żądania należności przewidzianych w art. 618a 

i art. 618b służy osobie wezwanej w charakterze świadka, jeżeli się stawiła, choćby 

nie została przesłuchana. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 340/356 

§ 2. W przypadku gdy osoba uprawniona do otrzymania należności 

przewidzianych w art. 618a i art. 618b zostanie wezwana w charakterze świadka 

w kilku sprawach na ten sam dzień, przyznaje się jej te należności tylko raz. 

§ 3. Świadkowi, który zgłosił się bez wezwania sądu lub organu prowadzącego 

postępowanie przygotowawcze, należności przewidziane w art. 618a i art. 618b mogą 

być przyznane tylko wtedy, gdy został przesłuchany.


## Art. 618d. {#kpk-art-618d}
Przepisy art. 618a–618c stosuje się odpowiednio do osoby 

towarzyszącej świadkowi, jeżeli świadek nie mógł stawić się na wezwanie sądu lub 

organu prowadzącego postępowanie przygotowawcze bez opieki tej osoby.


## Art. 618e. {#kpk-art-618e}
Przepisów art. 618a–618c nie stosuje się do świadka zatrudnionego 

w organie władzy publicznej, jeżeli powołany został do zeznawania w związku z tym 

zatrudnieniem. W tym przypadku świadkowi służy prawo do należności na zasadach 

określonych w przepisach regulujących wysokość i warunki ustalania należności 

przysługujących pracownikowi zatrudnionemu w państwowej lub samorządowej 

jednostce sfery budżetowej z tytułu podróży służbowej na obszarze kraju.


## Art. 618f. {#kpk-art-618f}
§ 1. Biegłemu i specjaliście niebędącemu funkcjonariuszem organów 

procesowych powołanym przez sąd 

lub organ prowadzący postępowanie 

przygotowawcze przysługuje wynagrodzenie za wykonaną pracę oraz zwrot 

poniesionych przez nich wydatków w zakresie, w jakim bezpośrednio dotyczyły one 

konkretnej opinii i były niezbędne dla jej wydania. 

§ 2. Wysokość wynagrodzenia za wykonaną pracę biegłego i specjalisty 

niebędącego funkcjonariuszem organów procesowych ustala się uwzględniając 

wymagane kwalifikacje, potrzebny do wydania opinii czas i nakład pracy, a wysokość 

wydatków, o których mowa w § 1 – na podstawie złożonego rachunku. 

§ 3. Wynagrodzenie biegłych oblicza się według stawki wynagrodzenia za 

godzinę pracy albo według taryfy zryczałtowanej określonej dla poszczególnych 

kategorii biegłych ze względu na dziedzinę, w której są oni specjalistami. Podstawę 

obliczenia stawki wynagrodzenia za godzinę pracy i taryfy zryczałtowanej stanowi 

ułamek kwoty bazowej dla osób zajmujących kierownicze stanowiska państwowe, 

której wysokość określa ustawa budżetowa. 

§ 4. Wynagrodzenie biegłego 

i specjalisty niebędącego 

funkcjonariuszem 

organów procesowych, będących podatnikami obowiązanymi do rozliczenia podatku 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 341/356 

od towarów i usług, podwyższa się o kwotę podatku od towarów i usług, określoną 

zgodnie ze stawką 

tego podatku obowiązującą w dniu orzekania o tym 

wynagrodzeniu. 

§ 4a. Jeżeli opinia jest fałszywa, wynagrodzenie oraz zwrot jakichkolwiek 

kosztów poniesionych przez biegłego związanych z jej sporządzeniem lub złożeniem 

nie przysługują. 

§ 4b. Jeżeli opinia jest nierzetelna lub została sporządzona lub złożona ze 

znacznym 

nieusprawiedliwionym 

opóźnieniem, 

wynagrodzenie 

ulega 

odpowiedniemu obniżeniu; można również odstąpić od przyznania wynagrodzenia lub 

zwrotu jakichkolwiek kosztów poniesionych przez biegłego związanych z jej 

sporządzeniem lub złożeniem. 

§ 5. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, stawki 

wynagrodzenia biegłych za wykonaną pracę oraz taryfy zryczałtowane, o których 

mowa w § 3, mając na uwadze nakład pracy i kwalifikacje biegłego oraz poziom 

wynagrodzeń uzyskiwanych przez pracowników wykonujących podobne zawody, 

stopień złożoności problemu będącego przedmiotem opinii oraz warunki, w jakich 

opracowano opinię, a także sposób dokumentowania wydatków niezbędnych dla 

wydania opinii.


## Art. 618fa. {#kpk-art-618fa}
§ 1. W wyjątkowych wypadkach organ procesowy może postanowić 

o wypłacie biegłemu przed sporządzeniem opinii, jednorazowo lub w ratach, 

określonej kwoty pieniężnej na poczet wynagrodzenia, jeżeli jest to uzasadnione 

szczególną czasochłonnością czynności niezbędnych do wydania opinii lub innymi 

szczególnymi okolicznościami. 

§ 2. Na postanowienie w przedmiocie wypłaty na poczet wynagrodzenia 

zażalenie nie przysługuje. 

§ 3. Biegły ma obowiązek zwrotu wypłaconej mu kwoty, w zakresie w jakim 

przewyższa ona kwotę ostatecznie przyznanego mu wynagrodzenia, a w wypadkach 

określonych w art. 618f § 4a i 4b biegły ma obowiązek zwrotu całej wypłaconej mu 

kwoty, jeżeli wynagrodzenie mu nie przysługuje albo od przyznania wynagrodzenia 

odstąpiono.


## Art. 618g. {#kpk-art-618g}
Do biegłego, tłumacza i specjalisty niebędącego funkcjonariuszem 

organów procesowych powołanych przez 

sąd 

lub organ postępowania 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 342/356 

przygotowawczego stosuje się odpowiednio art. 618a. Dotyczy to również sytuacji, 

gdy sąd lub organ postępowania przygotowawczego nie skorzystał z usług takiego 

biegłego, tłumacza lub specjalisty.


## Art. 618h. {#kpk-art-618h}
§ 1. 

Biegłemu, 

tłumaczowi 

i specjaliście 

niebędącemu 

funkcjonariuszem organów procesowych wezwanym przez sąd lub organ prowadzący 

postępowanie przygotowawcze, w razie nieskorzystania z ich usług, przysługuje zwrot 

utraconego zarobku lub dochodu. 

§ 2. Wynagrodzenie za utracony zarobek lub dochód przyznaje się biegłemu, 

tłumaczowi i specjaliście niebędącemu funkcjonariuszem organów procesowych, 

uwzględniając ich kwalifikacje i czas zużyty w związku z wezwaniem. Przepisy 

art. 618b § 3 i 4 stosuje się odpowiednio.


## Art. 618i. {#kpk-art-618i}
W przypadku gdy biegły, 

tłumacz 

lub specjalista niebędący 

funkcjonariuszem organów procesowych zostaną wezwani przez uprawniony organ 

w kilku sprawach na ten sam dzień, zwrot kosztów podróży, noclegu, utrzymania 

w miejscu wykonywania czynności postępowania, utraconego zarobku lub dochodu 

z powodu stawiennictwa na wezwanie organu, przysługuje im tylko raz.


## Art. 618ia. {#kpk-art-618ia}
§ 1. Asystentowi rodziny przysługuje ryczałt za udział w posiedzeniu 

albo rozprawie, o których mowa w art. 76a § 1. 

§ 2. Minister Sprawiedliwości w porozumieniu z ministrem właściwym do 

spraw finansów publicznych określi, w drodze rozporządzenia, wysokość ryczałtu za 

udział w posiedzeniu albo rozprawie, o których mowa w art. 76a § 1, mając na uwadze 

przewidywane 

średnie koszty 

stawiennictwa 

i udziału 

asystenta 

rodziny 

w posiedzeniu albo rozprawie.


## Art. 618j. {#kpk-art-618j}
Należności przysługujące 

stronie w związku z jej udziałem 

w postępowaniu przyznaje się w wysokości przewidzianej dla świadków.


## Art. 618k. {#kpk-art-618k}
§ 1. Należności, o których mowa w art. 618a, art. 618b, art. 618d oraz 

art. 618f–618h, przyznaje się na wniosek. 

§ 2. Wniosek o przyznanie należności, o których mowa w § 1, składa się ustnie 

do protokołu lub na piśmie, w terminie zawitym 3 dni od dnia zakończenia czynności 

z udziałem osoby uprawnionej do tych należności, a w przypadku osoby, o której 

mowa w art. 618d – z udziałem świadka, któremu ona towarzyszyła. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 343/356 

§ 3. Roszczenie o zwrot należności, o których mowa w § 1, przedawnia się 

z upływem 3 lat od dnia powstania tego roszczenia. 

§ 4. Świadek, osoba mu towarzysząca, biegły, tłumacz oraz specjalista niebędący 

funkcjonariuszem organów procesowych powinni być pouczeni o prawie i sposobie 

zgłoszenia wniosku o zwrot należności oraz o skutkach niezachowania terminu 

wskazanego w § 2.


## Art. 618l. {#kpk-art-618l}
§ 1. Należności świadka, osoby mu towarzyszącej, biegłego, tłumacza 

oraz specjalisty niebędącego funkcjonariuszem organów procesowych ustala 

i przyznaje sąd lub organ prowadzący postępowanie przygotowawcze. 

§ 2. Przyznaną należność należy wypłacić niezwłocznie. W przypadku braku 

takiej możliwości należność przekazuje się przekazem pocztowym lub przelewem 

bankowym bez obciążania osoby uprawnionej opłatą pocztową lub kosztami 

przelewu.


## Art. 619. {#kpk-art-619}
§ 1. Jeżeli ustawa nie stanowi inaczej, wszelkie wydatki wykłada 

tymczasowo Skarb Państwa. 

§ 2. Koszty postępowania mediacyjnego ponosi Skarb Państwa. 

§ 3. Skarb Państwa ponosi także koszty związane z udziałem w postępowaniu 

tłumacza w zakresie koniecznym dla zapewnienia oskarżonemu jego prawa do obrony.


## Art. 620. {#kpk-art-620}
Wydatki związane z ustanowieniem obrońcy lub pełnomocnika 

wykłada strona, która go ustanowiła.


## Art. 621. {#kpk-art-621}
§ 1. Oskarżyciel prywatny składa przy akcie oskarżenia lub wraz 

z oświadczeniem o przyłączeniu się do toczącego się postępowania lub podtrzymaniu 

oskarżenia, od którego prokurator odstąpił, dowód wpłacenia do kasy sądowej 

zryczałtowanej równowartości wydatków. Ryczałt ten nie obejmuje kosztów 

wskazanych w art. 618 § 1 pkt 5 i 11. 

§ 2. Minister Sprawiedliwości, w porozumieniu z ministrem właściwym do 

spraw 

finansów publicznych, określi, w drodze 

rozporządzenia, wysokość 

zryczałtowanej równowartości wydatków, mając na uwadze przeciętne koszty 

postępowania oraz zasadę dostępu do sądu.


## Art. 622. {#kpk-art-622}
W postępowaniu z oskarżenia prywatnego w razie pojednania się stron 

przed wszczęciem przewodu sądowego, warunkowego umorzenia postępowania, 

umorzenia postępowania z powodu niepoczytalności sprawcy lub znikomej społecznej 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 344/356 

szkodliwości czynu albo z powodu stwierdzenia w zarzucanym czynie znamion 

przestępstwa ściganego z urzędu, zmiany trybu ścigania z powodu przyłączenia się 

prokuratora do postępowania wszczętego przez oskarżyciela prywatnego 

i zakończenia tego postępowania w trybie publicznoskargowym – prezes sądu lub 

referendarz sądowy zarządza zwrot uiszczonych przez oskarżyciela prywatnego 

zryczałtowanych wydatków w całości, a w połowie – w razie pojednania się stron po 

rozpoczęciu przewodu sądowego. 


# Rozdział 69
 

Zwolnienie od kosztów sądowych


## Art. 623. {#kpk-art-623}
Sąd lub referendarz sądowy zwalnia osobę w całości lub w części od 

wyłożenia kosztów podlegających uiszczeniu przy wnoszeniu pisma procesowego, 

jeżeli wykazała ona, że ze względu na jej sytuację rodzinną, majątkową i wysokość 

dochodów wyłożenie ich byłoby zbyt uciążliwe.


## Art. 624. {#kpk-art-624}
§ 1. Sąd może zwolnić oskarżonego lub oskarżyciela posiłkowego 

w całości lub w części od zapłaty na rzecz Skarbu Państwa kosztów sądowych, jeżeli 

istnieją podstawy do uznania, że uiszczenie ich byłoby dla nich zbyt uciążliwe ze 

względu na sytuację rodzinną, majątkową i wysokość dochodów, jak również wtedy, 

gdy przemawiają za tym względy słuszności. 

§ 2. Przepis § 1 stosuje się odpowiednio do oskarżyciela prywatnego w razie 

rozpoznania sprawy bez zachowania wymagań określonych w art. 621 § 1.


## Art. 625. {#kpk-art-625}
W razie skazania lub warunkowego umorzenia postępowania wobec 

żołnierza odbywającego zasadniczą służbę wojskową nie pobiera się od niego 

należnych Skarbowi Państwa kosztów sądowych. 


# Rozdział 70
 

Zasądzenie kosztów procesu


## Art. 626. {#kpk-art-626}
§ 1. W orzeczeniu kończącym postępowanie w sprawie sąd określa, 

kto, w jakiej części i zakresie ponosi koszty procesu. 

§ 2. Jeżeli w orzeczeniu wymienionym w § 1 nie zamieszczono rozstrzygnięcia 

o kosztach, jak również gdy zachodzi konieczność dodatkowego ustalenia ich 

wysokości lub rozstrzygnięcia o kosztach postępowania wykonawczego, orzeczenie 

w tym przedmiocie wydaje odpowiednio sąd pierwszej instancji, sąd odwoławczy, 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 345/356 

a w zakresie dodatkowego ustalenia wysokości kosztów także referendarz sądowy 

właściwego sądu. 

§ 3. Na orzeczenie w przedmiocie kosztów służy zażalenie, jeżeli nie wniesiono 

apelacji. W razie wniesienia apelacji i zażalenia – zażalenie rozpoznaje sąd 

odwoławczy łącznie z apelacją.


## Art. 626a. {#kpk-art-626a}
Zażalenie na postanowienie prokuratora albo 

innego organu 

prowadzącego postępowanie przygotowawcze w przedmiocie kosztów wnosi się, 

odpowiednio, do prokuratora nadrzędnego nad prokuratorem, który wydał 

postanowienie, albo do prokuratora właściwego do sprawowania nadzoru nad 

postępowaniem przygotowawczym prowadzonym przez inny organ. Jeżeli prokurator 

nie przychyli się do zażalenia, kieruje je do sądu.


## Art. 627. {#kpk-art-627}
Od skazanego w sprawach z oskarżenia publicznego sąd zasądza 

koszty sądowe na rzecz Skarbu Państwa oraz wydatki na rzecz oskarżyciela 

posiłkowego.


## Art. 628. {#kpk-art-628}
Od skazanego w sprawach z oskarżenia prywatnego sąd zasądza na 

rzecz: 

1) 

oskarżyciela prywatnego poniesione przez niego koszty procesu; 

2) Skarbu Państwa wydatki ustalone na podstawie art. 618, od których uiszczenia 

oskarżyciel został zwolniony lub w razie rozpoznania sprawy bez ich uiszczenia.


## Art. 629. {#kpk-art-629}
Przepisy art. 627 i 628 stosuje się odpowiednio w razie warunkowego 

umorzenia postępowania, a w sprawach z oskarżenia prywatnego – również w razie 

umorzenia postępowania na podstawie art. 17 § 1 pkt 3.


## Art. 630. {#kpk-art-630}
W sprawach z oskarżenia publicznego, jeżeli oskarżonego nie skazano 

za wszystkie zarzucane mu przestępstwa, wydatki związane z oskarżeniem w części 

uniewinniającej lub umarzającej postępowanie ponosi Skarb Państwa.


## Art. 631. {#kpk-art-631}
W sprawach z oskarżenia prywatnego, w razie odstąpienia od 

wymierzenia kary z powodu wzajemności krzywd lub wyzywającego zachowania się 

oskarżyciela prywatnego, jak również biorąc pod uwagę liczbę i rodzaj zarzutów, od 

których oskarżony został uniewinniony, sąd może obciążyć oskarżonego 

poniesionymi przez oskarżyciela kosztami procesu tylko częściowo. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 346/356


## Art. 632. {#kpk-art-632}
Jeżeli ustawa nie stanowi inaczej, w razie uniewinnienia oskarżonego 

lub umorzenia postępowania koszty procesu ponosi: 

1) w sprawach z oskarżenia prywatnego – oskarżyciel prywatny, a w razie 

pojednania się stron – oskarżyciel i oskarżony w zakresie przez siebie 

poniesionym, jeżeli strony w zawartej ugodzie nie uregulowały tego inaczej; 

2) w sprawach z oskarżenia publicznego – Skarb Państwa, z wyjątkiem należności 

z tytułu udziału adwokata lub radcy prawnego w charakterze pełnomocnika 

pokrzywdzonego, oskarżyciela posiłkowego albo innej osoby.


## Art. 632a. {#kpk-art-632a}
§ 1. W wyjątkowych wypadkach, w razie umorzenia postępowania, 

sąd może orzec, że koszty procesu ponosi w całości lub w części oskarżony, 

a w sprawach z oskarżenia prywatnego oskarżony lub Skarb Państwa. 

§ 2. W razie uniewinnienia oskarżonego lub umorzenia postępowania sąd 

orzeka, że koszty procesu ponosi w całości lub w części oskarżony, jeżeli: 

1) 

oskarżony skierował przeciwko sobie podejrzenie popełnienia czynu 

zabronionego; 

2) 

ukrywanie się oskarżonego przyczyniło się do przedawnienia karalności 

zarzucanego mu czynu; 

3) 

umorzono przeciwko oskarżonemu postępowanie na podstawie art. 11 § 1. 

§ 3. W razie umorzenia postępowania ze względu na cofnięcie wniosku 

o ściganie po rozpoczęciu przewodu sądowego sąd może orzec, że koszty procesu 

ponosi w całości lub w części oskarżony.


## Art. 632b. {#kpk-art-632b}
Jeżeli w sprawach, o których mowa w art. 632 pkt 2, przyczyny 

umorzenia powstały w toku postępowania, sąd może orzec od Skarbu Państwa zwrot 

należności z tytułu ustanowienia jednego pełnomocnika.


## Art. 633. {#kpk-art-633}
Koszty procesu przypadające od kilku oskarżonych lub oskarżycieli 

prywatnych albo posiłkowych, jak również od oskarżonych i oskarżycieli, sąd zasądza 

od każdego z nich według zasad słuszności, mając w szczególności na względzie 

koszty związane ze sprawą każdego z nich.


## Art. 634. {#kpk-art-634}
Jeżeli przepisy ustawy nie stanowią inaczej, do kosztów procesu za 

postępowanie odwoławcze od orzeczeń kończących postępowanie w sprawie mają 

odpowiednie zastosowanie przepisy o kosztach za postępowanie przed sądem 

pierwszej instancji. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 347/356


## Art. 635. {#kpk-art-635}
Niezależnie od tego, kto wniósł środek odwoławczy, jeżeli dojdzie do 

zmiany wyroku skazującego lub orzeczenia o warunkowym umorzeniu postępowania 

na niekorzyść oskarżonego, koszty procesu za postępowanie odwoławcze ustala się na 

ogólnych zasadach.


## Art. 636. {#kpk-art-636}
§ 1. W sprawach z oskarżenia publicznego, w razie nieuwzględnienia 

środka odwoławczego, wniesionego wyłącznie przez oskarżonego lub oskarżyciela 

posiłkowego, koszty procesu za postępowanie odwoławcze ponosi na ogólnych 

zasadach ten, kto wniósł środek odwoławczy, a jeżeli środek ten pochodzi wyłącznie 

od oskarżyciela publicznego – koszty procesu za postępowanie odwoławcze ponosi 

Skarb Państwa. 

§ 2. W razie nieuwzględnienia środków odwoławczych wniesionych przez co 

najmniej dwa uprawnione podmioty, stosuje się odpowiednio art. 633. 

§ 3. Przepisy § 1 

i 2 stosuje się odpowiednio w sprawach z oskarżenia 

prywatnego.


## Art. 637. {#kpk-art-637}
§ 1. Przepisy art. 635 

i 636 stosuje się odpowiednio w razie 

pozostawienia środka odwoławczego bez rozpoznania wobec jego cofnięcia lub 

z przyczyn wskazanych w art. 430. 

§ 2. W wypadku cofnięcia wniosku o ściganie, kosztami postępowania można 

obciążyć osobę, która wniosek cofnęła.


## Art. 637a. {#kpk-art-637a}
Do kosztów postępowania kasacyjnego stosuje się odpowiednio 

przepisy o kosztach postępowania odwoławczego, chyba że ustawa stanowi inaczej.


## Art. 638. {#kpk-art-638}
Wydatki poniesione przez sąd, związane z rozpoznaniem kasacji 

wniesionej przez podmioty wymienione w art. 521 lub wznowieniem postępowania 

z urzędu, ponosi Skarb Państwa.


## Art. 639. {#kpk-art-639}
Przepisy o kosztach procesu mają odpowiednie zastosowanie 

w sprawach o wznowienie postępowania. W razie oddalenia wniosku 

lub 

pozostawienia go bez rozpoznania, obowiązek pokrycia kosztów obciąża osobę, która 

złożyła wniosek.


## Art. 640. {#kpk-art-640}
§ 1. Przepisy odnoszące się do kosztów procesu w sprawach 

z oskarżenia prywatnego mają odpowiednie zastosowanie w sprawach z oskarżenia 

publicznego, w których akt oskarżenia wniósł oskarżyciel posiłkowy. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 348/356 

§ 2. Sąd nie może zasądzić od oskarżyciela posiłkowego zwrotu wydatków, 

o których mowa w art. 618, w wysokości przekraczającej kwotę zryczałtowanej 

równowartości wydatków określonej na podstawie art. 621 § 2.


## Art. 641. {#kpk-art-641}
Prawo do ściągnięcia zasądzonych kosztów procesu przedawnia się 

z upływem 3 lat od dnia, kiedy należało je uiścić. 

(zawierający art. 642–645 – uchylony) 


# Rozdział 71
