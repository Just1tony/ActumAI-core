---
id: "code_kpk_dzial-vii"
title: "KPK — DZIAŁ VII"
source_pdf: "D19970555Lj (1).pdf"
dz_u: "Dz. U. 1997 Nr 89 poz. 555"
status: "obowiązujący"
last_consolidated: "2025-09-11"
law: "Kodeks postępowania karnego"
tags: ["kpk", "kodeks", "postępowanie karne"]
articles_range: {"first": "297", "last": "336"}
---

# DZIAŁ VII

## Art. 297. {#kpk-art-297}
§ 1. Celem postępowania przygotowawczego jest: 

1) 

ustalenie, czy został popełniony czyn zabroniony i czy stanowi on przestępstwo; 

2) wykrycie i w razie potrzeby ujęcie sprawcy; 

3) 

zebranie danych stosownie do art. 213 i 214; 

4) wyjaśnienie okoliczności sprawy, w tym ustalenie osób pokrzywdzonych 

i rozmiarów szkody; 

5) 

zebranie, zabezpieczenie i w niezbędnym zakresie utrwalenie dowodów dla 

sądu. 

§ 2. (uchylony)


## Art. 298. {#kpk-art-298}
§ 1. Postępowanie przygotowawcze prowadzi 

lub nadzoruje 

prokurator, a w zakresie przewidzianym w ustawie prowadzi je Policja. W wypadkach 

przewidzianych w ustawie uprawnienia Policji przysługują innym organom. 

§ 2. Określone w ustawie czynności w postępowaniu przygotowawczym 

przeprowadza sąd.


## Art. 299. {#kpk-art-299}
§ 1. W postępowaniu przygotowawczym pokrzywdzony i podejrzany 

są stronami. 

§ 2. W wypadkach wskazanych w ustawie określone uprawnienia przysługują 

również osobom niebędącym stronami. 

§ 3. W czynnościach 

sądowych 

w postępowaniu 

przygotowawczym 

prokuratorowi przysługują prawa strony.


## Art. 299a. {#kpk-art-299a}
§ 1. Podczas czynności z udziałem pokrzywdzonego w postępowaniu 

przygotowawczym może być obecna osoba przez niego wskazana, jeżeli nie 

uniemożliwia to przeprowadzenia czynności albo nie utrudnia jej w istotny sposób. 

2025-09-11 

 
 
 
 

Zmiana § 2 w art. 
299a wejdzie w 
życie 
dn. 
z 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

©Kancelaria Sejmu 

s. 131/356 

 [§ 2. Na wniosek pokrzywdzonego zgłoszony w postępowaniu przygotowawczym 

sąd powiadamia go o sposobie zakończenia sprawy listem zwykłym, przesłanym na 

wskazany przez pokrzywdzonego adres, za pośrednictwem telefaksu lub poczty 

elektronicznej wraz z odpisem prawomocnego orzeczenia kończącego postępowanie 

w sprawie lub jego wyciągiem, które mogą być przesłane w postaci elektronicznej.] 

 <§ 2. Na wniosek 

pokrzywdzonego 

zgłoszony w postępowaniu 

przygotowawczym sąd powiadamia go o sposobie zakończenia sprawy listem 

zwykłym, przesłanym na wskazany przez pokrzywdzonego adres, za 

pośrednictwem telefaksu lub poczty elektronicznej wraz z kopią prawomocnego 

orzeczenia kończącego postępowanie w sprawie lub jego wyciągiem, które mogą 

być przesłane w postaci elektronicznej.>


## Art. 299b. {#kpk-art-299b}
Podczas czynności z udziałem podejrzanego, który nie ukończył 

18 lat, w postępowaniu przygotowawczym może być obecny jego przedstawiciel 

ustawowy lub osoba, pod której pieczą podejrzany pozostaje, chyba że udział tych 

osób może prowadzić do naruszenia praw lub interesów podejrzanego, jest niecelowy 

ze względu na jego dobro, uniemożliwia przeprowadzenie czynności albo utrudnia ją 

w istotny sposób. Jeżeli podejrzany nie posiada przedstawiciela ustawowego lub 

osoby, pod której pieczą pozostaje, albo jeżeli zaistniały okoliczności wyłączające 

udział w czynności tych osób, podejrzany może wskazać inną osobę pełnoletnią, 

chyba że udział tej osoby może prowadzić do naruszenia praw lub interesów 

podejrzanego, 

jest niecelowy ze względu na 

jego dobro, uniemożliwia 

przeprowadzenie czynności albo utrudnia ją w istotny sposób.


## Art. 300. {#kpk-art-300}
§ 1. Przed pierwszym przesłuchaniem poucza się podejrzanego o jego 

uprawnieniach: do składania wyjaśnień, do odmowy składania wyjaśnień lub odmowy 

odpowiedzi na pytania, do informacji o treści zarzutów i ich zmianach, do składania 

wniosków o dokonanie czynności śledztwa lub dochodzenia, do korzystania z pomocy 

obrońcy, w tym do wystąpienia o obrońcę z urzędu w wypadku określonym w art. 78 

i art. 78a, oraz o treści art. 202, art. 214, art. 215, art. 257 § 1 i 2, art. 259, art. 316, 

art. 338b, art. 360, art. 361 i art. 374 § 1, o treści przepisów dotyczących środków 

zapobiegawczych, o których mowa w rozdziale 28, innych niż 

tymczasowe 

aresztowanie, o uprawnieniu do końcowego 

zaznajomienia 

z materiałami 

postępowania przygotowawczego, 

jak 

również o uprawnieniach określonych 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 132/356 

w art. 23a § 1, art. 72 § 1, art. 156 § 5 i 5a, art. 301, art. 335, art. 338a i art. 387 oraz 

o obowiązkach i konsekwencjach wskazanych w art. 74, art. 75, art. 133 § 2, art. 138 

i art. 139. Ponadto podejrzanego, który nie ukończył 18 lat, poucza się o treści art. 76, 

art. 76a i art. 299b oraz o treści art. 212 Kodeksu karnego wykonawczego, a także 

o roli organów uczestniczących w postępowaniu karnym. Pouczenie należy wręczyć 

podejrzanemu na piśmie; podejrzany otrzymanie pouczenia potwierdza podpisem. 

Jeżeli podejrzany nie ukończył 18 lat 

to pouczenie wręcza się 

również 

przedstawicielowi ustawowemu lub osobie, pod której pieczą podejrzany pozostaje, 

albo innej osobie wskazanej albo wyznaczonej, o której mowa w art. 76a, która 

otrzymanie pouczenia potwierdza podpisem. 

§ 2. Przed pierwszym przesłuchaniem albo niezwłocznie po ustaleniu 

pokrzywdzonego, 

jeżeli odstępuje się od 

jego przesłuchania, poucza się 

pokrzywdzonego o posiadaniu 

statusu 

strony procesowej w postępowaniu 

przygotowawczym oraz o wynikających z tego uprawnieniach, w szczególności: do 

składania wniosków o dokonanie czynności śledztwa lub dochodzenia i warunkach 

uczestniczenia w tych czynnościach, określonych w art. 51, art. 52 i art. 315–318, do 

korzystania z pomocy pełnomocnika, w tym do złożenia wniosku o wyznaczenie 

pełnomocnika z urzędu w okolicznościach wskazanych w art. 78, jak również 

o uprawnieniach określonych w art. 23a § 1, art. 156, art. 204, art. 306 i art. 315a oraz 

o obowiązkach 

i konsekwencjach wskazanych w art. 138 

i art. 139. Pouczenie 

obejmuje również 

informację o: możliwościach naprawienia szkody przez 

oskarżonego lub uzyskania kompensaty państwowej, dostępie do pomocy prawnej, 

dostępnych środkach ochrony 

i pomocy, o których mowa w ustawie z dnia 

28 listopada 2014 r. o ochronie i pomocy dla pokrzywdzonego i świadka, pomocy 

przewidzianej w art. 43 § 8 Kodeksu karnego wykonawczego, możliwości wydania 

europejskiego nakazu ochrony, organizacjach wsparcia pokrzywdzonych, treści 

art. 337a oraz możliwości zwrotu kosztów poniesionych w związku z udziałem 

w postępowaniu. Pouczenie należy wręczyć pokrzywdzonemu na piśmie; 

pokrzywdzony otrzymanie pouczenia potwierdza podpisem. W razie odstąpienia od 

przesłuchania pokrzywdzonego pouczenie podlega doręczeniu. 

§ 3. Przed pierwszym przesłuchaniem poucza się świadka o jego uprawnieniach 

i obowiązkach określonych w art. 177–192a oraz dostępnych środkach ochrony 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 133/356 

i pomocy, o których mowa w ustawie z dnia 28 listopada 2014 r. o ochronie i pomocy 

dla pokrzywdzonego i świadka. 

§ 3a. Osoby, o których mowa w § 1–3, nieporadne ze względu na wiek lub stan 

zdrowia, oraz które nie ukończyły 18 lat, mogą otrzymać dostęp do wyjaśnień co do 

zakresu ich uprawnień i obowiązków oraz sposobu i warunków przesłuchania. Wzory 

wyjaśnień umieszcza się także na stronie internetowej Ministerstwa Sprawiedliwości. 

§ 3b. Pouczenia, o których mowa w § 1–3, i wyjaśnienia, o których mowa 

w § 3a, mogą być opisowe lub graficzne. 

§ 4. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, wzory 

pisemnych: 

1) 

pouczeń, o których mowa w § 1–3, w tym odrębne dla osób, które nie ukończyły 

18 lat, mając na względzie konieczność zrozumienia pouczenia przez osoby 

niekorzystające z pomocy obrońcy lub pełnomocnika, osoby nieporadne ze 

względu na wiek lub stan zdrowia lub osoby, które nie ukończyły 18 lat; 

2) wyjaśnień, o których mowa w § 3a, odrębne dla osób nieporadnych ze względu 

na wiek lub stan zdrowia oraz osób, które nie ukończyły 18 lat, mając na 

względzie konieczność zrozumienia wyjaśnień przez te osoby. 

 <Art. 

300a. 

Przed 

pierwszym 

przesłuchaniem 

podejrzanego, 

pokrzywdzonego lub świadka odbiera się od nich na piśmie albo zamieszcza w 

protokole przesłuchania oświadczenie o wyrażeniu zgody na dokonywanie 

doręczeń na adres do doręczeń elektronicznych wraz z podaniem tego adresu albo 

o braku takiej zgody. Przed odebraniem oświadczenia osoby te należy pouczyć o 

skutkach procesowych wyrażenia zgody albo jej braku.>


## Art. 301. {#kpk-art-301}
Na żądanie podejrzanego należy przesłuchać go z udziałem 

ustanowionego obrońcy. Niestawiennictwo obrońcy nie tamuje przesłuchania.


## Art. 302. {#kpk-art-302}
§ 1. Osobom niebędącym stronami przysługuje zażalenie na 

postanowienia i zarządzenia naruszające ich prawa. 

§ 2. Stronom oraz osobom niebędącym stronami służy zażalenie na czynności 

inne niż postanowienia i zarządzenia naruszające ich prawa. 

§ 3. Zażalenie na postanowienia 

i zarządzenia oraz na 

inne czynności 

prokuratora w postępowaniu przygotowawczym, o których mowa odpowiednio w § 1 

i 2, rozpoznaje prokurator bezpośrednio przełożony. 

2025-09-11 

Dodane art. 300a 
i 302a wejdą w 
życie 
dn. 
z 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 
 
 
 
 

©Kancelaria Sejmu 

s. 134/356 

 <Art. 302a. Przepis art. 100a stosuje się odpowiednio do aktu oskarżenia, 

wniosku o wydanie wyroku skazującego, wniosku o rozpoznanie sprawy w 

postępowaniu przyspieszonym, wniosku o warunkowe umorzenie postępowania, 

wniosku o umorzenie postępowania z powodu niepoczytalności sprawcy i o 

zastosowanie środka zabezpieczającego.> 


# Rozdział 34
 

Wszczęcie śledztwa


## Art. 303. {#kpk-art-303}
Jeżeli zachodzi uzasadnione podejrzenie popełnienia przestępstwa, 

wydaje się z urzędu lub na skutek zawiadomienia o przestępstwie postanowienie 

o wszczęciu śledztwa, w którym określa się czyn będący przedmiotem postępowania 

oraz jego kwalifikację prawną.


## Art. 304. {#kpk-art-304}
§ 1. Każdy, dowiedziawszy się o popełnieniu przestępstwa ściganego 

z urzędu, ma społeczny obowiązek zawiadomić o tym prokuratora lub Policję. 

Przepisy art. 148a oraz art. 156a stosuje się odpowiednio. 

§ 2. Instytucje państwowe i samorządowe, które w związku ze swą działalnością 

dowiedziały się o popełnieniu przestępstwa ściganego z urzędu, są obowiązane 

niezwłocznie zawiadomić o tym prokuratora lub Policję oraz przedsięwziąć niezbędne 

czynności do czasu przybycia organu powołanego do ścigania przestępstw lub do 

czasu wydania przez ten organ stosownego zarządzenia, aby nie dopuścić do zatarcia 

śladów i dowodów przestępstwa. 

§ 3. Zawiadomienie o przestępstwie lub własne dane świadczące o popełnieniu 

takiego przestępstwa, co do którego obowiązkowe jest prowadzenie śledztwa przez 

prokuratora, Policja przekazuje wraz z zebranym materiałem niezwłocznie 

prokuratorowi.


## Art. 304a. {#kpk-art-304a}
Sporządza się wspólny protokół z przyjęcia ustnego zawiadomienia 

o przestępstwie i przesłuchania w charakterze świadka osoby zawiadamiającej; 

w protokole tym można również zamieścić wniosek o ściganie.


## Art. 304b. {#kpk-art-304b}
Na wniosek pokrzywdzonego 

składającego 

zawiadomienie 

o przestępstwie wydaje mu się potwierdzenie złożenia zawiadomienia, zawierające 

datę oraz miejsce jego przyjęcia, wskazanie organu przyjmującego wraz z danymi do 

kontaktu, sygnaturę sprawy, dane określające tożsamość pokrzywdzonego, czas 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 135/356 

i miejsce popełnienia czynu, którego dotyczy zawiadomienie, oraz zwięzły opis czynu 

i wyrządzonej szkody. O prawie tym należy pokrzywdzonego pouczyć.


## Art. 305. {#kpk-art-305}
§ 1. Niezwłocznie po otrzymaniu zawiadomienia o przestępstwie 

organ powołany do prowadzenia postępowania przygotowawczego obowiązany jest 

wydać postanowienie o wszczęciu bądź o odmowie wszczęcia śledztwa. 

§ 2. (uchylony) 

§ 3. Postanowienie o wszczęciu śledztwa wydaje prokurator. Postanowienie 

o odmowie wszczęcia lub o umorzeniu śledztwa wydaje prokurator albo Policja; 

postanowienie wydane przez Policję zatwierdza prokurator. 

§ 4. O wszczęciu, odmowie wszczęcia albo o umorzeniu śledztwa zawiadamia 

się osobę lub instytucję państwową, samorządową lub społeczną, która złożyła 

zawiadomienie o przestępstwie, oraz ujawnionego pokrzywdzonego, a o umorzeniu 

także podejrzanego – z pouczeniem o przysługujących im uprawnieniach.


## Art. 306. {#kpk-art-306}
§ 1. Na postanowienie o odmowie wszczęcia śledztwa przysługuje 

zażalenie: 

1) 

2) 

3) 

1) 

2) 

pokrzywdzonemu; 

instytucji wymienionej w art. 305 § 4; 

osobie wymienionej w art. 305 § 4, jeżeli wskutek przestępstwa doszło do 

naruszenia jej praw. 

§ 1a. Na postanowienie o umorzeniu śledztwa przysługuje zażalenie: 

stronom; 

instytucji państwowej 

lub samorządowej, która złożyła zawiadomienie 

o przestępstwie; 

3) 

osobie 

niebędącej 

pokrzywdzonym, 

która 

złożyła 

zawiadomienie 

o przestępstwie określonym w art. 228–231, art. 233, art. 235, art. 236, art. 245, 

art. 270–277, art. 278–294 lub w art. 296–306c Kodeksu karnego, jeżeli 

postępowanie karne wszczęto w wyniku jej zawiadomienia, a wskutek tego 

przestępstwa doszło do naruszenia jej praw. 

§ 1b. Uprawnionym do złożenia zażalenia, o którym mowa w § 1 

i 1a, 

przysługuje prawo przejrzenia akt. W celu przejrzenia akt prokurator może udostępnić 

akta w postaci elektronicznej. 

§ 2. (uchylony) 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 136/356 

§ 3. Jeżeli osoba lub instytucja, która złożyła zawiadomienie o przestępstwie, nie 

zostanie w ciągu 6 tygodni powiadomiona o wszczęciu albo odmowie wszczęcia 

śledztwa, może wnieść zażalenie do prokuratora nadrzędnego albo powołanego do 

nadzoru nad organem, któremu złożono zawiadomienie.


## Art. 307. {#kpk-art-307}
§ 1. 

Jeżeli zachodzi potrzeba, można zażądać uzupełnienia 

w wyznaczonym terminie danych zawartych w zawiadomieniu o przestępstwie lub 

dokonać sprawdzenia faktów w tym zakresie. W tym wypadku postanowienie 

o wszczęciu śledztwa albo o odmowie wszczęcia należy wydać najpóźniej w terminie 

30 dni od otrzymania zawiadomienia. 

§ 2. W postępowaniu sprawdzającym nie przeprowadza się dowodu z opinii 

biegłego ani czynności wymagających spisania protokołu, z wyjątkiem przyjęcia 

ustnego zawiadomienia o przestępstwie lub wniosku o ściganie oraz czynności 

określonej w § 3. 

§ 3. Uzupełnienie danych zawartych w zawiadomieniu o przestępstwie może 

nastąpić również przez przesłuchanie w charakterze świadka osoby zawiadamiającej. 

§ 4. (uchylony) 

§ 5. Przepis § 2 stosuje się odpowiednio w wypadku podejmowania przez organy 

ścigania przed wydaniem postanowienia o wszczęciu śledztwa sprawdzenia własnych 

informacji, nasuwających przypuszczenie, że popełniono przestępstwo.


## Art. 308. {#kpk-art-308}
§ 1. W granicach koniecznych dla zabezpieczenia śladów i dowodów 

przestępstwa przed ich utratą, zniekształceniem lub zniszczeniem, prokurator albo 

Policja może w każdej sprawie, w wypadkach niecierpiących zwłoki, jeszcze przed 

wydaniem postanowienia o wszczęciu śledztwa lub dochodzenia, przeprowadzić 

w niezbędnym zakresie czynności procesowe, a zwłaszcza dokonać oględzin, w razie 

potrzeby z udziałem biegłego, przeszukania lub czynności wymienionych w art. 74 

§ 2 pkt 1 w stosunku do osoby podejrzanej, a także przedsięwziąć wobec niej inne 

niezbędne czynności, nie wyłączając pobrania krwi, włosów i wydzielin organizmu. 

Po dokonaniu tych czynności, w sprawach, w których prowadzenie śledztwa przez 

prokuratora 

jest obowiązkowe, prowadzący postępowanie przekazuje sprawę 

niezwłocznie prokuratorowi. 

§ 2. W wypadkach niecierpiących zwłoki, w szczególności wtedy, gdy mogłoby 

to spowodować zatarcie śladów lub dowodów przestępstwa, można w toku czynności 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 137/356 

wymienionych w § 1 przesłuchać osobę podejrzaną o popełnienie przestępstwa 

w charakterze podejrzanego przed wydaniem postanowienia o przedstawieniu 

zarzutów, 

jeżeli zachodzą warunki do sporządzenia 

takiego postanowienia. 

Przesłuchanie rozpoczyna się od informacji o treści zarzutu. 

§ 3. W wypadku przewidzianym w § 2, w sprawach, w których prowadzenie 

śledztwa jest obowiązkowe, najpóźniej w ciągu 5 dni od dnia przesłuchania wydaje 

się postanowienie o przedstawieniu zarzutów albo, w razie braku warunków do jego 

sporządzenia, umarza się postępowanie w stosunku do osoby przesłuchanej. 

§ 4. W sprawach, w których obowiązkowe 

jest prowadzenie 

śledztwa, 

postanowienie przewidziane w § 3 wydaje prokurator. 

§ 5. Czynności, o których mowa w § 1 i 2, mogą być dokonywane tylko w ciągu 

5 dni od dnia pierwszej czynności. 

§ 6. W wypadkach określonych w § 1 i 2 czas trwania śledztwa lub dochodzenia 

liczy się od dnia pierwszej czynności. 


# Rozdział 35
 

Przebieg śledztwa


## Art. 309. {#kpk-art-309}
Śledztwo prowadzi się w sprawach: 

1) w których rozpoznanie w pierwszej instancji należy do właściwości sądu 

okręgowego; 

2) 

o występki – gdy osobą podejrzaną jest sędzia, prokurator, funkcjonariusz Policji, 

Agencji Bezpieczeństwa Wewnętrznego, Agencji Wywiadu, Służby 

Kontrwywiadu Wojskowego, Służby Wywiadu Wojskowego, Służby Ochrony 

Państwa, Straży Marszałkowskiej, Służby Celno-Skarbowej lub Centralnego 

Biura Antykorupcyjnego; 

3) 

o występki – gdy osobą podejrzaną jest funkcjonariusz Straży Granicznej, 

Żandarmerii Wojskowej, finansowego organu postępowania przygotowawczego 

lub 

organu 

nadrzędnego 

nad 

finansowym 

organem 

postępowania 

przygotowawczego, w zakresie spraw należących do właściwości tych organów 

lub o występki popełnione przez 

tych 

funkcjonariuszy w związku 

z wykonywaniem czynności służbowych; 

4) 

o występki, w których nie prowadzi się dochodzenia; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 138/356 

5) 

o występki, w których prowadzi się dochodzenie, jeżeli prokurator tak postanowi 

ze względu na wagę lub zawiłość sprawy.


## Art. 310. {#kpk-art-310}
§ 1. Śledztwo powinno być ukończone w ciągu 3 miesięcy. 

§ 2. W uzasadnionych wypadkach okres śledztwa może być przedłużony na 

dalszy czas oznaczony przez prokuratora nadzorującego śledztwo lub prokuratora 

bezpośrednio przełożonego wobec prokuratora, który prowadzi śledztwo, nie dłuższy 

jednak niż rok. W szczególnie uzasadnionych wypadkach właściwy prokurator 

nadrzędny nad prokuratorem nadzorującym lub prowadzącym śledztwo może 

przedłużyć jego okres na dalszy czas oznaczony.


## Art. 311. {#kpk-art-311}
§ 1. Śledztwo prowadzi prokurator. 

§ 2. Prokurator może powierzyć Policji przeprowadzenie śledztwa w całości lub 

w określonym zakresie albo dokonanie poszczególnych czynności śledztwa; 

w wypadkach określonych w art. 309 pkt 2 i 3 można powierzyć Policji jedynie 

dokonanie poszczególnych czynności śledztwa. 

§ 3. Powierzenie przewidziane w § 2 nie może obejmować czynności 

związanych z przedstawieniem zarzutów, zmianą lub uzupełnieniem postanowienia 

o przedstawieniu zarzutów oraz zamknięciem śledztwa; może 

jednak mieć 

zastosowanie art. 308 § 2. 

§ 4. W sytuacji, o której mowa w § 2, Policja może dokonać innych czynności, 

jeżeli wyłoni się taka potrzeba. 

§ 5. Prokurator może zastrzec do osobistego wykonania jakąkolwiek czynność 

śledztwa, a w szczególności czynności wymagające postanowienia. 

§ 6. (uchylony) 

§ 7. (uchylony)


## Art. 312. {#kpk-art-312}
Uprawnienia Policji przysługują także: 

1) 

organom Straży Granicznej, Agencji Bezpieczeństwa Wewnętrznego, Krajowej 

Administracji Skarbowej, Centralnego Biura Antykorupcyjnego oraz 

Żandarmerii Wojskowej, w zakresie ich właściwości; 

2) 

innym organom przewidzianym w przepisach szczególnych.


## Art. 313. {#kpk-art-313}
§ 1. Jeżeli dane istniejące w chwili wszczęcia śledztwa lub zebrane 

w jego toku uzasadniają dostatecznie podejrzenie, że czyn popełniła określona osoba, 

wydaje się postanowienie o przedstawieniu zarzutów, ogłasza je niezwłocznie 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 139/356 

podejrzanemu i przesłuchuje się go, chyba że ogłoszenie postanowienia lub 

przesłuchanie podejrzanego nie jest możliwe z powodu jego ukrywania się lub 

nieobecności w kraju. 

§ 1a. Od ogłoszenia postanowienia i przesłuchania podejrzanego, o których 

mowa w § 1, można odstąpić, jeżeli nie jest możliwe ich przeprowadzenie ze względu 

na stan zdrowia podejrzanego albo stan nietrzeźwości lub odurzenia w jakim znajduje 

się podejrzany, a zachodzi potrzeba niezwłocznego zastosowania 

środka 

zapobiegawczego. W takim wypadku należy ogłosić postanowienie o przedstawieniu 

zarzutów i przesłuchać podejrzanego w terminie 7 dni od ustania okoliczności 

uniemożliwiającej wykonanie tych czynności. 

§ 2. Postanowienie o przedstawieniu zarzutów zawiera wskazanie podejrzanego, 

dokładne określenie zarzucanego mu czynu i jego kwalifikacji prawnej. 

§ 3. Podejrzany może do czasu zawiadomienia go o terminie zaznajomienia 

z materiałami śledztwa żądać podania mu ustnie podstaw zarzutów, a także 

sporządzenia uzasadnienia na piśmie, o czym należy go pouczyć. Uzasadnienie 

doręcza się podejrzanemu i ustanowionemu obrońcy w terminie 14 dni. 

§ 4. W uzasadnieniu należy w szczególności wskazać, jakie fakty i dowody 

zostały przyjęte za podstawę zarzutów.


## Art. 314. {#kpk-art-314}
Jeżeli w toku śledztwa okaże się, że podejrzanemu należy zarzucić 

czyn nie objęty wydanym uprzednio postanowieniem o przedstawieniu zarzutów albo 

czyn w zmienionej w istotny sposób postaci lub też, że czyn zarzucany należy 

zakwalifikować z surowszego przepisu, wydaje się niezwłocznie nowe postanowienie, 

ogłasza się je podejrzanemu oraz przesłuchuje się go. Przepis art. 313 § 3 i 4 stosuje 

się odpowiednio.


## Art. 315. {#kpk-art-315}
§ 1. Podejrzany i jego obrońca oraz pokrzywdzony i jego pełnomocnik 

mogą składać wnioski o dokonanie czynności śledztwa. 

§ 2. Stronie, która złożyła wniosek, oraz jej obrońcy lub pełnomocnikowi nie 

można odmówić wzięcia udziału w czynności, jeżeli tego żądają. Przepis art. 318 

zdanie drugie stosuje się.


## Art. 315a. {#kpk-art-315a}
Od przesłuchania pokrzywdzonego w charakterze świadka można 

odstąpić, jeżeli czynność ta nie jest niezbędna do dokonania ustaleń faktycznych. 

Pokrzywdzony, który nie był przesłuchany w charakterze świadka, powinien zostać 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 140/356 

przesłuchany w tym charakterze, jeżeli tego zażąda, chyba że uwzględnienie żądania 

prowadziłoby do przewlekłości postępowania.


## Art. 316. {#kpk-art-316}
§ 1. Jeżeli czynności śledztwa nie będzie można powtórzyć na 

rozprawie, należy podejrzanego, pokrzywdzonego i ich przedstawicieli ustawowych, 

a obrońcę i pełnomocnika, jeżeli są już w sprawie ustanowieni, dopuścić do udziału 

w czynności, chyba że zachodzi niebezpieczeństwo utraty lub zniekształcenia dowodu 

w razie zwłoki. 

§ 2. Podejrzanego pozbawionego wolności nie sprowadza się wtedy, gdy zwłoka 

grozi utratą lub zniekształceniem dowodu. 

§ 3. Jeżeli zachodzi niebezpieczeństwo, że świadka nie będzie można 

przesłuchać na rozprawie, strona lub prokurator albo inny organ prowadzący 

postępowanie mogą zwrócić się do sądu z żądaniem przesłuchania go przez sąd.


## Art. 317. {#kpk-art-317}
§ 1. Strony, a obrońcę lub pełnomocnika, gdy są już w sprawie 

ustanowieni, należy także na żądanie dopuścić do udziału w innych czynnościach 

śledztwa. 

§ 2. W szczególnie uzasadnionym wypadku prokurator może postanowieniem 

odmówić dopuszczenia do udziału w czynności ze względu na ważny interes śledztwa 

albo odmówić 

sprowadzenia oskarżonego pozbawionego wolności, gdy 

spowodowałoby to poważne trudności.


## Art. 318. {#kpk-art-318}
Gdy dopuszczono dowód z opinii biegłych albo instytucji naukowej 

lub specjalistycznej, podejrzanemu i jego obrońcy oraz pokrzywdzonemu i jego 

pełnomocnikowi doręcza się postanowienie o dopuszczeniu tego dowodu i zezwala na 

wzięcie udziału w przesłuchaniu biegłych oraz na zapoznanie się z opinią, jeżeli 

złożona została na piśmie. Podejrzanego pozbawionego wolności nie sprowadza się, 

gdy spowodowałoby to poważne trudności.


## Art. 319. {#kpk-art-319}
(uchylony)


## Art. 320. {#kpk-art-320}
(uchylony) 


# Rozdział 36
 

Zamknięcie śledztwa


## Art. 321. {#kpk-art-321}
§ 1. Jeżeli istnieją podstawy do zamknięcia śledztwa, na wniosek 

podejrzanego 

lub 

jego obrońcy o końcowe 

zaznajomienie 

z materiałami 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 141/356 

postępowania, prowadzący postępowanie powiadamia podejrzanego 

i obrońcę 

o terminie końcowego zaznajomienia, pouczając ich o prawie uprzedniego przejrzenia 

akt w terminie odpowiednim do wagi lub zawiłości sprawy, określonym przez organ 

procesowy. W celu przejrzenia akt prokurator może udostępnić akta w postaci elektro-

nicznej. 

§ 2. Termin zaznajomienia podejrzanego z materiałami postępowania powinien 

być tak wyznaczony, aby od daty doręczenia zawiadomienia o nim podejrzanemu 

i jego obrońcy upłynęło co najmniej 7 dni. 

§ 3. W czynnościach zaznajomienia podejrzanego z materiałami postępowania 

ma prawo uczestniczyć obrońca. 

§ 4. Nieusprawiedliwione niestawiennictwo podejrzanego lub jego obrońcy nie 

tamuje dalszego postępowania. 

§ 5. W terminie 3 dni od daty zaznajomienia podejrzanego z materiałami 

postępowania strony mogą składać wnioski o uzupełnienie śledztwa. Przepis art. 315 

§ 2 stosuje się odpowiednio. 

§ 6. Jeżeli nie zachodzi potrzeba uzupełnienia śledztwa, wydaje się 

postanowienie o jego zamknięciu i ogłasza się je lub o jego treści zawiadamia się 

podejrzanego oraz jego obrońcę.


## Art. 322. {#kpk-art-322}
§ 1. Jeżeli postępowanie nie dostarczyło podstaw do wniesienia aktu 

oskarżenia, a nie zachodzą warunki określone w art. 324, umarza się śledztwo bez 

konieczności uprzedniego zaznajomienia z materiałami postępowania 

i jego 

zamknięcia. 

§ 2. Postanowienie o umorzeniu śledztwa powinno zawierać, oprócz danych 

wymienionych w art. 94, dokładne określenie czynu i jego kwalifikacji prawnej oraz 

wskazanie przyczyn umorzenia. 

§ 3. Jeżeli umorzenie następuje po wydaniu postanowienia o przedstawieniu 

zarzutów albo przesłuchaniu osoby w charakterze podejrzanego, postanowienie 

o umorzeniu powinno zawierać także imię i nazwisko podejrzanego oraz w razie 

potrzeby inne dane o jego osobie.


## Art. 323. {#kpk-art-323}
§ 1. W razie umorzenia śledztwa prokurator wydaje postanowienie co 

do dowodów rzeczowych stosownie do przepisów art. 230–233. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 142/356 

§ 2. Na postanowienie, o którym mowa w § 1, przysługuje zażalenie 

podejrzanemu, pokrzywdzonemu i osobie, od której przedmioty te odebrano lub która 

zgłosiła do nich roszczenie. 

§ 3. Po uprawomocnieniu się postanowienia o umorzeniu śledztwa prokurator, w 

razie istnienia podstaw określonych w art. 45a Kodeksu karnego lub w art. 43 § 1 i 2, 

art. 43a oraz art. 47 § 4 Kodeksu karnego skarbowego, występuje do sądu z wnioskiem 

o orzeczenie przepadku. Z takim wnioskiem prokurator może wystąpić również w 

wypadku umorzenia postępowania wobec niewykrycia sprawcy przestępstwa, 

przestępstwa skarbowego lub wykroczenia skarbowego, o ile przepis przewiduje 

orzeczenie przepadku.


## Art. 324. {#kpk-art-324}
§ 1. Jeżeli zostanie ustalone, że podejrzany dopuścił się czynu w stanie 

niepoczytalności, a istnieją podstawy do zastosowania środków zabezpieczających, 

prokurator po zamknięciu śledztwa kieruje sprawę do sądu z wnioskiem o umorzenie 

postępowania i zastosowanie środków zabezpieczających. Przepis art. 321 stosuje się 

odpowiednio. 

§ 1a. Do wniosku, o którym mowa w § 1, stosuje się odpowiednio art. 331 § 1 

i 4, art. 332, art. 333 § 1–3 i art. 334 § 1, a przekazując wniosek do sądu, prokurator 

informuje o tym ujawnionego pokrzywdzonego. 

§ 2. Jeżeli sąd nie znajduje podstaw do uwzględnienia wniosku, o którym mowa 

w § 1, przekazuje sprawę prokuratorowi do dalszego prowadzenia. 

§ 3. Na postanowienie sądu przysługuje zażalenie.


## Art. 325. {#kpk-art-325}
Postanowienie o zawieszeniu śledztwa, jeżeli nie zostało wydane przez 

prokuratora, wymaga jego pisemnego zatwierdzenia. 


# Rozdział 36
a 

Dochodzenie


## Art. 325a. {#kpk-art-325a}
§ 1. Dochodzenie prowadzi Policja lub organy, o których mowa 

w art. 312, chyba że prowadzi je prokurator. 

§ 2. Przepisy dotyczące śledztwa stosuje się odpowiednio do dochodzenia, jeżeli 

przepisy niniejszego rozdziału nie stanowią inaczej.


## Art. 325b. {#kpk-art-325b}
§ 1. Dochodzenie prowadzi się w sprawach o przestępstwa należące 

do właściwości sądu rejonowego: 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 143/356 

1) 

zagrożone karą nieprzekraczającą 5 lat pozbawienia wolności, z tym że 

w wypadku przestępstw przeciwko mieniu tylko wówczas, gdy wartość 

przedmiotu przestępstwa albo szkoda wyrządzona lub grożąca nie przekracza 

200 000 zł; 

2) 

3) 

przewidziane w art. 159, art. 254a i art. 262 § 2 Kodeksu karnego; 

przewidziane 

w art. 278 § 3a, 

art. 279 § 1, 

art. 286 § 1 

i 2 

oraz 

w art. 289 § 2 Kodeksu karnego, jeżeli wartość przedmiotu przestępstwa albo 

szkoda wyrządzona lub grożąca nie przekracza 200 000 zł. 

§ 2. Spośród spraw o przestępstwa wymienione w § 1 pkt 1 nie prowadzi się 

dochodzenia w sprawach o przestępstwa określone w art. 155, art. 156 § 2, art. 157a 

§ 1, art. 165 § 2, art. 168, art. 174 § 2, art. 175, art. 181–184, art. 186, art. 201, art. 231 

§ 1 i 3, art. 240 § 1, art. 250a § 1–3, art. 265 § 3 oraz w rozdziale XXXVI, z wyjątkiem 

art. 297 i art. 300, i rozdziale XXXVII Kodeksu karnego.


## Art. 325c. {#kpk-art-325c}
(uchylony)


## Art. 325d. {#kpk-art-325d}
Minister Sprawiedliwości w porozumieniu z właściwymi ministrami 

określi, w drodze rozporządzenia, organy uprawnione obok Policji do prowadzenia 

dochodzeń oraz organy uprawnione do wnoszenia i popierania oskarżenia przed 

sądem pierwszej instancji w sprawach, w których prowadzono dochodzenie, jak 

również zakres spraw zleconych tym organom, mając na uwadze określony przez 

ustawę zakres kompetencji tych organów.


## Art. 325e. {#kpk-art-325e}
§ 1. Postanowienia o wszczęciu dochodzenia, odmowie wszczęcia 

dochodzenia, umorzeniu dochodzenia i wpisaniu sprawy do rejestru przestępstw, 

umorzeniu dochodzenia oraz o jego zawieszeniu wydaje prowadzący postępowanie. 

Mogą one zostać zamieszczone w protokole, o którym mowa w art. 304a, i nie 

wymagają uzasadnienia. Na wniosek strony organ prowadzący dochodzenie podaje 

ustnie najważniejsze powody rozstrzygnięcia. 

§ 1a. W przypadku gdy zawiadomienie o przestępstwie zostało złożone przez 

inspektora pracy 

lub Najwyższą Izbę Kontroli, uzasadnienie postanowienia 

o odmowie wszczęcia dochodzenia oraz umorzeniu dochodzenia sporządza się na ich 

wniosek. Przepisy art. 422 i art. 423 stosuje się odpowiednio. Zażalenie wnosi się 

w terminie 7 dni od daty doręczenia postanowienia z uzasadnieniem. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 144/356 

§ 2. Postanowienia, o których mowa w § 1, z wyjątkiem postanowienia 

o wszczęciu dochodzenia oraz umorzeniu i wpisaniu sprawy do rejestru przestępstw, 

zatwierdza prokurator. Przepisy art. 323 stosuje prokurator, a w sprawie, którą po 

umorzeniu wpisano do rejestru przestępstw – Policja. 

§ 3. (uchylony) 

§ 4. Zażalenie na postanowienie o umorzeniu dochodzenia i wpisaniu sprawy do 

rejestru przestępstw wnosi się do prokuratora właściwego do sprawowania nadzoru 

nad dochodzeniem. Jeżeli prokurator nie przychyli się do zażalenia, kieruje je do sądu.


## Art. 325f. {#kpk-art-325f}
§ 1. Jeżeli dane uzyskane w toku czynności, o których mowa 

w art. 308 § 1, lub prowadzonego przez okres co najmniej 5 dni dochodzenia nie 

stwarzają dostatecznych podstaw do wykrycia sprawcy w drodze dalszych czynności 

procesowych, można wydać postanowienie o umorzeniu dochodzenia i wpisaniu 

sprawy do rejestru przestępstw. 

§ 2. Po wydaniu postanowienia, o którym mowa w § 1, Policja, na podstawie 

odrębnych przepisów, prowadzi czynności w celu wykrycia sprawcy i uzyskania 

dowodów. 

§ 3. Jeżeli zostaną ujawnione dane pozwalające na wykrycie sprawcy, Policja 

wydaje postanowienie o podjęciu na nowo dochodzenia. Przepis art. 305 § 4 stosuje 

się odpowiednio; przepisów art. 305 § 3 zdanie pierwsze oraz art. 327 § 1 nie stosuje 

się. 

§ 4. (uchylony)


## Art. 325g. {#kpk-art-325g}
§ 1. Nie jest wymagane sporządzenie postanowienia o przedstawieniu 

zarzutów oraz wydanie postanowienia o zamknięciu dochodzenia, chyba że 

podejrzany jest tymczasowo aresztowany. 

§ 2. Przesłuchanie osoby podejrzanej zaczyna się od powiadomienia jej o treści 

zarzutu wpisanego do protokołu przesłuchania. Osobę tę od chwili rozpoczęcia 

przesłuchania uważa się za podejrzanego. 

§ 3. Podejrzanemu należy umożliwić przygotowanie się do obrony, a zwłaszcza 

ustanowienie lub wyznaczenie obrońcy.


## Art. 325h. {#kpk-art-325h}
§ 1. Dochodzenie można ograniczyć do ustalenia, czy zachodzą 

wystarczające podstawy do wniesienia aktu oskarżenia lub innego zakończenia 

postępowania. Należy jednak dokonać czynności przewidzianych w art. 321 § 1–5 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 145/356 

oraz w art. 325g § 2, przesłuchać podejrzanego i pokrzywdzonego oraz przeprowadzić 

i utrwalić w protokołach czynności, których nie będzie można powtórzyć. Utrwalenie 

innych czynności dowodowych następuje w formie protokołu ograniczonego do 

zapisu najbardziej istotnych oświadczeń osób biorących udział w czynności; przepisu 

art. 148 § 2 zdanie pierwsze nie stosuje się. 

§ 2. Przepis art. 315a stosuje się.


## Art. 325i. {#kpk-art-325i}
§ 1. Dochodzenie powinno być ukończone w ciągu 2 miesięcy. 

Prokurator może przedłużyć ten okres do 3 miesięcy, a w wypadkach szczególnie 

uzasadnionych – na dalszy czas oznaczony. 

§ 2. (uchylony) 

§ 3. Uprawnienia prokuratora określone w art. 335, 

art. 336 

i art. 387 

§ 2 przysługują także innym niż prokurator organom uprawnionym do wnoszenia 

i popierania oskarżenia w sprawach o przestępstwa ścigane z oskarżenia publicznego. 


# Rozdział 37
 

Nadzór prokuratora nad postępowaniem przygotowawczym


## Art. 326. {#kpk-art-326}
§ 1. 

Prokurator 

sprawuje 

nadzór 

nad 

postępowaniem 

przygotowawczym w zakresie, w jakim go sam nie prowadzi; prokurator może także 

objąć nadzorem postępowanie, o którym mowa w art. 307. 

§ 2. Prokurator 

jest obowiązany czuwać nad prawidłowym 

i sprawnym 

przebiegiem całego nadzorowanego przez siebie postępowania. 

§ 3. Z tytułu sprawowanego nadzoru prokurator może w szczególności: 

1) 

zaznajamiać się z zamierzeniami prowadzącego postępowanie, wskazywać 

kierunki postępowania oraz wydawać co do tego zarządzenia; 

2) 

3) 

żądać przedstawienia sobie materiałów zbieranych w toku postępowania; 

uczestniczyć w czynnościach 

dokonywanych 

przez 

prowadzących 

postępowanie, osobiście je przeprowadzać albo przejąć sprawę do swego 

prowadzenia; 

4) wydawać postanowienia, zarządzenia lub polecenia oraz zmieniać i uchylać 

postanowienia i zarządzenia wydane przez prowadzącego postępowanie. 

§ 4. W razie niewykonania przez organ niebędący prokuratorem postanowienia, 

zarządzenia lub polecenia wydanego przez prokuratora sprawującego nadzór, na jego 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 146/356 

żądanie przełożony funkcjonariusza wszczyna postępowanie służbowe; o wyniku 

postępowania informuje się prokuratora.


## Art. 327. {#kpk-art-327}
§ 1. Umorzone postępowanie przygotowawcze może być w każdym 

czasie podjęte na nowo na mocy postanowienia prokuratora, jeżeli nie będzie się 

toczyć przeciw osobie, która w poprzednim postępowaniu występowała w charakterze 

podejrzanego. Przepis ten stosuje się odpowiednio w sprawie, w której odmówiono 

wszczęcia śledztwa lub dochodzenia. 

§ 2. Prawomocnie umorzone postępowanie przygotowawcze wznawia się 

przeciwko osobie, która występowała w charakterze podejrzanego, na mocy 

postanowienia prokuratora nadrzędnego nad tym, który wydał lub zatwierdził 

postanowienie o umorzeniu, tylko wtedy, gdy ujawnią się nowe istotne fakty lub 

dowody nie znane w poprzednim postępowaniu albo gdy zachodzi okoliczność 

określona w art. 11 § 3. Przewidziane w ustawie ograniczenia okresu tymczasowego 

aresztowania stosuje się wówczas do łącznego czasu trwania tego środka. 

§ 3. Przed wydaniem postanowienia o podjęciu lub wznowieniu, prokurator 

może przedsięwziąć osobiście lub zlecić Policji dokonanie niezbędnych czynności 

dowodowych w celu 

sprawdzenia okoliczności 

uzasadniających wydanie 

postanowienia. 

§ 4. Po wniesieniu aktu oskarżenia sąd umarza postępowanie, jeżeli stwierdzi, że 

postępowanie przygotowawcze wznowiono mimo braku podstaw.


## Art. 328. {#kpk-art-328}
§ 1. Prokurator Generalny może uchylić prawomocne postanowienie 

o umorzeniu postępowania przygotowawczego w stosunku do osoby, która 

występowała w charakterze podejrzanego, 

jeżeli 

stwierdzi, że umorzenie 

postępowania było niezasadne. Nie dotyczy to wypadku, w którym sąd utrzymał 

w mocy postanowienie o umorzeniu. 

§ 2. Po upływie roku od daty uprawomocnienia się postanowienia o umorzeniu 

Prokurator Generalny może uchylić lub zmienić postanowienie albo jego uzasadnienie 

jedynie na korzyść podejrzanego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 147/356 


# Rozdział 38
 

Czynności sądowe w postępowaniu przygotowawczym


## Art. 329. {#kpk-art-329}
§ 1. 

Przewidzianych w ustawie 

czynności w postępowaniu 

przygotowawczym dokonuje na posiedzeniu sąd powołany do rozpoznania sprawy 

w pierwszej instancji, jeżeli ustawa nie stanowi inaczej. 

§ 2. Sąd dokonuje czynności jednoosobowo także wtedy, gdy rozpoznaje 

zażalenie na czynności postępowania przygotowawczego, chyba że ustawa stanowi 

inaczej.


## Art. 330. {#kpk-art-330}
§ 1. Uchylając 

postanowienie 

o umorzeniu 

postępowania 

przygotowawczego lub odmowie jego wszczęcia, sąd wskazuje powody uchylenia, 

a w miarę potrzeby także okoliczności, które należy wyjaśnić, lub czynności, które 

należy przeprowadzić. Wskazania te są dla organu prowadzącego postępowanie 

przygotowawcze wiążące. 

§ 2. Jeżeli organ prowadzący postępowanie nadal nie znajduje podstaw do 

wniesienia aktu oskarżenia, wydaje postanowienie o umorzeniu postępowania lub 

odmowie jego wszczęcia. Postanowienie to podlega zaskarżeniu tylko do prokuratora 

nadrzędnego. W razie 

utrzymania w mocy 

zaskarżonego 

postanowienia 

pokrzywdzony, który co najmniej dwukrotnie wykorzystał uprawnienia przewidziane 

w art. 306 § 1 lub 1a, w tym zaskarżył postanowienie utrzymane w mocy przez 

prokuratora nadrzędnego, może wnieść akt oskarżenia określony w art. 55 § 1. 

§ 2a. W razie utrzymania w mocy postanowienia o umorzeniu postępowania 

przygotowawczego lub odmowie jego wszczęcia, prokurator nadrzędny przesyła 

pokrzywdzonemu, który spełnia warunki określone w § 2 zdanie 

trzecie, 

zawiadomienie 

o utrzymaniu w mocy 

zaskarżonego 

postanowienia wraz 

z pouczeniem o treści art. 55 § 1 oraz odpis postanowienia o utrzymaniu w mocy 

zaskarżonego postanowienia. Innego skarżącego powiadamia się o utrzymaniu 

w mocy postanowienia o umorzeniu postępowania przygotowawczego lub odmowie 

jego wszczęcia. 

§ 3. W razie wniesienia przez pokrzywdzonego aktu oskarżenia prezes sądu 

przesyła jego odpis prokuratorowi, wzywając go do nadesłania w terminie 14 dni akt 

postępowania przygotowawczego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 148/356 

§ 4. Jeżeli akt oskarżenia, którego odpis został przesłany prokuratorowi na 

podstawie § 3, nie został wniesiony przez pokrzywdzonego, prokurator odmawia 

przesłania akt postępowania przygotowawczego, zawiadamiając o tym prezesa sądu. 

Podmiotowi, który wniósł akt oskarżenia, przysługuje zażalenie na zarządzenie 

prokuratora o odmowie przesłania akt postępowania przygotowawczego; właściwy do 

rozpoznania zażalenia jest prokurator nadrzędny. 


# Rozdział 39
 

Akt oskarżenia


## Art. 331. {#kpk-art-331}
§ 1. W ciągu 14 dni od daty zamknięcia śledztwa albo od otrzymania 

aktu oskarżenia sporządzonego przez Policję w dochodzeniu, prokurator sporządza akt 

oskarżenia lub zatwierdza akt oskarżenia sporządzony przez Policję w dochodzeniu 

i wnosi go do sądu albo sam wydaje postanowienie o umorzeniu, o zawieszeniu albo 

o uzupełnieniu śledztwa lub dochodzenia. 

§ 2. Organ, o którym mowa w art. 325d, może wnieść akt oskarżenia 

bezpośrednio do sądu, chyba że prokurator postanowi inaczej. 

§ 3. Jeżeli podejrzany jest tymczasowo aresztowany, termin wymieniony 

w § 1 wynosi 7 dni. 

§ 4. W sprawie, w której wobec podejrzanego stosowane jest tymczasowe 

aresztowanie, akt oskarżenia należy wnieść nie później niż 14 dni przed upływem 

dotychczas określonego terminu stosowania tego środka.


## Art. 332. {#kpk-art-332}
§ 1. Akt oskarżenia powinien zawierać: 

1) 

imię i nazwisko oskarżonego, inne dane o jego osobie, w tym numer telefonu, 

telefaksu i adres poczty elektronicznej lub informację o ich nieposiadaniu przez 

oskarżonego lub niemożności ich ustalenia, dane o zastosowaniu środka 

zapobiegawczego oraz zabezpieczenia majątkowego; 

<1a) informację o złożonym przez oskarżonego oświadczeniu o wyrażeniu zgody 

na dokonywanie doręczeń na adres do doręczeń elektronicznych wraz z 

podaniem tego adresu albo o braku takiej zgody;> 

2) 

dokładne określenie zarzucanego oskarżonemu czynu ze wskazaniem czasu, 

miejsca, sposobu i okoliczności jego popełnienia oraz skutków, a zwłaszcza 

wysokości powstałej szkody; 

2025-09-11 

Dodany pkt 1a w 
§ 1 w art. 332 
wejdzie w życie z 
dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 
 
 
 
 

©Kancelaria Sejmu 

s. 149/356 

3) wskazanie, że czyn został popełniony w warunkach wymienionych w art. 64, 

art. 64a 

lub art. 65 Kodeksu karnego albo art. 37 § 1 Kodeksu karnego 

skarbowego; 

4) wskazanie przepisów ustawy karnej, pod które zarzucany czyn podpada; 

5) wskazanie sądu właściwego do rozpoznania sprawy. 

6) 

(uchylony) 

§ 2. Do aktu oskarżenia dołącza się jego uzasadnienie, przytaczające fakty 

i dowody, na których oskarżenie się opiera, a w miarę potrzeby wyjaśniające podstawę 

prawną oskarżenia i omawiające okoliczności, na które powołuje się oskarżony 

w swej obronie. 

§ 3. Jeżeli postępowanie przygotowawcze zakończyło się w formie dochodzenia, 

akt oskarżenia może nie zawierać uzasadnienia.


## Art. 333. {#kpk-art-333}
§ 1. Akt oskarżenia powinien także zawierać: 

1) 

listę osób, których wezwania oskarżyciel żąda; 

2) wykaz innych dowodów, których przeprowadzenia na rozprawie głównej 

domaga się oskarżyciel. 

§ 2. Prokurator może wnieść o zaniechanie wezwania i odczytanie na rozprawie 

zeznań świadków, o których mowa w art. 350a. 

§ 3. Do aktu oskarżenia dołącza się, do wiadomości sądu, listę ujawnionych osób 

pokrzywdzonych z podaniem ich adresów, a także adresy osób, o których mowa w § 1 

pkt 1. [Należy również podać numery telefonów, telefaksów i adresy poczty 

elektronicznej osób wskazanych w zdaniu pierwszym, chyba że informacji tych nie 

można ustalić.] <Należy również podać numery telefonów, telefaksów, adresy 

poczty elektronicznej osób wskazanych w zdaniu pierwszym, chyba że informacji 

tych nie można ustalić, oraz adresy do doręczeń elektronicznych, jeżeli osoby te 

wyraziły zgodę na dokonywanie doręczeń na ten adres.> 

§ 3a. Do aktu oskarżenia dołącza się listę pokrzywdzonych, którzy złożyli 

wnioski na podstawie art. 299a § 2. 

§ 4. (uchylony) 

§ 5. Prokurator może także dołączyć do aktu oskarżenia wniosek o orzeczenie 

wobec podmiotu zobowiązanego określonego w art. 91a zwrotu korzyści majątkowej 

albo jej równowartości uprawnionemu podmiotowi lub orzeczenie przepadku 

2025-09-11 

Nowe brzmienie 
zd. drugiego w § 3 
w art. 333 oraz 
zmiana w pkt 2 w 
§ 2 w art. 334 
wejdą w życie z 
dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 

 
 
 
 

©Kancelaria Sejmu 

s. 150/356 

świadczenia albo jego równowartości na rzecz Skarbu Państwa. Wniosek powinien 

zawierać uzasadnienie.


## Art. 334. {#kpk-art-334}
§ 1. Z aktem oskarżenia przesyła się sądowi akta postępowania 

przygotowawczego wraz z załącznikami. 

§ 2. Do aktu oskarżenia dołącza się także: 

1) 

załącznik adresowy do akt sprawy; 

 [2) po jednym odpisie tego aktu dla każdego oskarżonego, a w przypadku 

określonym w art. 335 § 2 także dla każdego pokrzywdzonego.] 

 <2) po jednej kopii tego aktu dla każdego oskarżonego, a w przypadku 

określonym w art. 335 § 2 także dla każdego pokrzywdzonego.> 

§ 2a. Odpisy aktu oskarżenia, o których mowa w § 2 pkt 2, mogą być przesłane 

sądowi w postaci elektronicznej, z wyłączeniem odpisów przeznaczonych dla 

adresatów, którzy w dniu przesłania sądowi aktu oskarżenia są pozbawieni wolności 

lub których adresu poczty elektronicznej nie ustalono. 

§ 3. O przesłaniu aktu oskarżenia do sądu oraz o treści przepisów art. 343, 

art. 343a i art. 378a oskarżyciel publiczny zawiadamia oskarżonego i ujawnionego 

pokrzywdzonego, a także osobę lub instytucję, która złożyła zawiadomienie 

o przestępstwie. Pokrzywdzonego należy pouczyć o treści przepisu art. 49a, a także 

o prawie do złożenia oświadczenia o działaniu w charakterze oskarżyciela 

posiłkowego. 

§ 4. O złożeniu wniosku, o którym mowa w art. 333 § 5, prokurator zawiadamia 

podmiot zobowiązany i podmiot uprawniony określone w art. 91a oraz poucza te 

podmioty o treści przepisów art. 91a, art. 415a i art. 444 § 2.


## Art. 335. {#kpk-art-335}
§ 1. Jeżeli oskarżony przyznaje się do winy, a w świetle jego wyjaśnień 

okoliczności popełnienia przestępstwa i wina nie budzą wątpliwości, a postawa 

oskarżonego wskazuje, że cele postępowania zostaną osiągnięte, można zaniechać 

przeprowadzenia dalszych czynności. Jeżeli zachodzi potrzeba oceny wiarygodności 

złożonych wyjaśnień, czynności dowodowych dokonuje się jedynie w niezbędnym do 

tego zakresie. W każdym jednak wypadku, jeżeli jest to konieczne dla zabezpieczenia 

śladów i dowodów przestępstwa przed ich utratą, zniekształceniem lub zniszczeniem, 

należy przeprowadzić w niezbędnym zakresie czynności procesowe, a zwłaszcza 

dokonać oględzin, w razie potrzeby z udziałem biegłego, przeszukania lub czynności 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 151/356 

wymienionych w art. 74 § 2 pkt 1 w stosunku do osoby podejrzanej, a także 

przedsięwziąć wobec niej inne niezbędne czynności, nie wyłączając pobrania krwi, 

włosów i wydzielin organizmu. Prokurator, zamiast z aktem oskarżenia, występuje do 

sądu z wnioskiem o wydanie na posiedzeniu wyroku skazującego i orzeczenie 

uzgodnionych z oskarżonym kar lub innych środków przewidzianych za zarzucany mu 

występek, uwzględniających również prawnie chronione interesy pokrzywdzonego. 

Uzgodnienie może obejmować 

także wydanie określonego 

rozstrzygnięcia 

w przedmiocie poniesienia kosztów procesu. 

§ 1a. Do wniosku, o którym mowa w § 1, stosuje się odpowiednio przepisy 

dotyczące aktu oskarżenia zawarte w rozdziale 40, z wyjątkiem art. 344a. 

§ 2. Prokurator może dołączyć do aktu oskarżenia wniosek o wydanie na 

posiedzeniu wyroku skazującego i orzeczenie uzgodnionych z oskarżonym kar lub 

innych środków przewidzianych za zarzucany mu występek, uwzględniających też 

prawnie chronione 

interesy pokrzywdzonego, 

jeżeli okoliczności popełnienia 

przestępstwa i wina oskarżonego nie budzą wątpliwości, oświadczenia dowodowe 

złożone przez oskarżonego nie są sprzeczne z dokonanymi ustaleniami, a postawa 

oskarżonego wskazuje, że cele postępowania zostaną osiągnięte. Do wniosku stosuje 

się odpowiednio przepisy § 1 zdanie piąte i § 3 zdanie drugie. Do aktu oskarżenia nie 

stosuje się przepisów art. 333 § 1 i 2. 

§ 2a. Prokurator, uzgadniając z oskarżonym treść wniosku, o którym mowa 

w § 1 lub 2, poucza go o treści art. 447 § 5. O pouczeniu zamieszcza się adnotację 

w aktach sprawy. 

§ 3. Wniosek, o którym mowa w § 1, powinien zawierać dane wskazane 

w art. 332 § 1. Uzasadnienie wniosku ogranicza się do wskazania dowodów 

świadczących o tym, że okoliczności popełnienia czynu i wina oskarżonego nie budzą 

wątpliwości oraz że cele postępowania zostaną osiągnięte bez przeprowadzenia 

rozprawy. Przepisy art. 333 § 3 i art. 334 stosuje się odpowiednio. Stronom, obrońcom 

i pełnomocnikom przysługuje prawo do przejrzenia akt sprawy, o czym należy ich 

pouczyć. 

§ 4. W wypadku gdy sąd, nie uwzględniając wniosku, o którym mowa w § 1, 

zwrócił sprawę prokuratorowi, ponowne wystąpienie z takim wnioskiem jest możliwe, 

jeżeli zwrot nastąpił z przyczyn wskazanych w art. 343 § 1, 2 lub 3. Zwrot sprawy nie 

stoi też na przeszkodzie wystąpieniu następnie z wnioskiem, o którym mowa w § 2. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 152/356


## Art. 336. {#kpk-art-336}
§ 1. Jeżeli spełnione są przesłanki uzasadniające warunkowe 

umorzenie postępowania, prokurator może zamiast aktu oskarżenia sporządzić 

i skierować do sądu wniosek o takie umorzenie. 

§ 2. Do wniosku stosuje się odpowiednio przepisy art. 332 § 1 pkt 1, 2, 4 i 5. 

Uzasadnienie wniosku można ograniczyć do wskazania dowodów świadczących 

o tym, że wina oskarżonego nie budzi wątpliwości, a ponadto okoliczności 

przemawiających za warunkowym umorzeniem. 

§ 3. Prokurator może wskazać proponowany okres próby, obowiązki, które 

należy nałożyć na oskarżonego i, stosownie do okoliczności, wnioski co do dozoru. 

§ 4. Do wniosku dołącza się, do wiadomości sądu, listę ujawnionych osób 

pokrzywdzonych z podaniem ich adresów. Przepis art. 334 stosuje się odpowiednio. 

§ 5. Do wniosku o warunkowe umorzenie postępowania stosuje się odpowiednio 

przepisy dotyczące aktu oskarżenia zawarte w rozdziale 40.
