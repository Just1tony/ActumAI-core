---
id: "code_kpk_dzial-xv"
title: "KPK — DZIAŁ XV"
source_pdf: "D19970555Lj (1).pdf"
dz_u: "Dz. U. 1997 Nr 89 poz. 555"
status: "obowiązujący"
last_consolidated: "2025-09-11"
law: "Kodeks postępowania karnego"
tags: ["kpk", "kodeks", "postępowanie karne"]
articles_range: {"first": "646", "last": "673"}
---

# DZIAŁ XV

## Art. 646. {#kpk-art-646}
W sprawach podlegających orzecznictwu sądów wojskowych nie 

stosuje 

się 

przepisów 

o postępowaniu 

prywatnoskargowym, 

nakazowym 

i przyspieszonym. Poza tym stosuje się przepisy działów poprzednich, chyba że 

przepisy działu niniejszego stanowią inaczej.


## Art. 647. {#kpk-art-647}
§ 1. Orzecznictwu sądów wojskowych podlegają sprawy: 

1) 

żołnierzy w czynnej służbie wojskowej, z wyjątkiem terytorialnej służby 

wojskowej pełnionej dyspozycyjnie, o przestępstwa: 

a) określone w rozdziałach XXXIX–XLIV Kodeksu karnego, 

b) popełnione przeciwko organowi wojskowemu lub innemu żołnierzowi, 

c) popełnione podczas lub w związku z pełnieniem obowiązków służbowych, 

w obrębie obiektu wojskowego lub wyznaczonego miejsca przebywania, na 

szkodę wojska lub z naruszeniem obowiązku wynikającego ze służby 

wojskowej, 

d) popełnione za granicą, podczas użycia lub pobytu Sił Zbrojnych Rzeczy-

pospolitej Polskiej poza granicami państwa, w rozumieniu ustawy z dnia 

17 grudnia 1998 r. o zasadach użycia lub pobytu Sił Zbrojnych Rzeczy-

pospolitej Polskiej poza granicami państwa (Dz. U. z 2023 r. poz. 755); 

2) 

pracowników wojska o przestępstwa: 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 349/356 

a) określone w art. 356–363 Kodeksu karnego w związku z art. 317 § 2 tego 

kodeksu, 

b) popełnione za granicą, podczas użycia lub pobytu Sił Zbrojnych Rzeczy-

pospolitej Polskiej poza granicami państwa, w rozumieniu ustawy z dnia 

17 grudnia 1998 r. o zasadach użycia lub pobytu Sił Zbrojnych Rzeczy-

pospolitej Polskiej poza granicami państwa; 

3) 

żołnierzy sił zbrojnych państw obcych, przebywających na 

terytorium 

Rzeczypospolitej Polskiej, oraz członków 

ich personelu cywilnego, 

o przestępstwa popełnione w związku z pełnieniem obowiązków służbowych, 

chyba że umowa międzynarodowa, której Rzeczpospolita Polska jest stroną, 

stanowi inaczej. 

§ 2. Sprawy o przestępstwa wymienione w § 1 nie przestają podlegać 

orzecznictwu sądów wojskowych mimo zwolnienia żołnierza z czynnej służby 

wojskowej lub ustania zatrudnienia pracownika w wojsku. 

§ 3. W razie zwolnienia żołnierza z czynnej służby wojskowej lub ustania 

zatrudnienia pracownika w wojsku sprawę, o której mowa w § 1 pkt 1 lit. b lub d, oraz 

– jeżeli przestępstwo nie wiąże się z naruszeniem obowiązku służbowego – w § 1 

pkt 2 lit. b, sąd wojskowy, najpóźniej do dnia rozpoczęcia przewodu sądowego na 

rozprawie głównej, może przekazać do rozpoznania sądowi powszechnemu, jeżeli 

dobro wymiaru sprawiedliwości temu się nie sprzeciwia. 

§ 4. (uchylony) 

§ 5. Na 

postanowienie w przedmiocie 

przekazania 

sprawy w myśl 

§ 3 przysługuje zażalenie.


## Art. 648. {#kpk-art-648}
Orzecznictwu sądów wojskowych podlegają także sprawy o: 

1) współdziałanie w popełnieniu przestępstw określonych w rozdziałach XXXIX–

XLIV Kodeksu karnego; 

2) 

przestępstwa określone w art. 239, 291–293, a także w art. 294 w odniesieniu do 

art. 291 § 1, Kodeksu karnego – 

jeżeli czyn pozostaje w związku 

z przestępstwem przewidzianym w rozdziałach XXXIX–XLIV tego kodeksu; 

3) 

inne przestępstwa, o ile przepisy szczególne tak stanowią.


## Art. 649. {#kpk-art-649}
§ 1. Jeżeli sprawca przestępstwa podlegającego orzecznictwu sądów 

wojskowych popełnił 

także przestępstwo podlegające orzecznictwu sądów 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 350/356 

powszechnych, a przestępstwa pozostają ze sobą w takim związku, że dobro wymiaru 

sprawiedliwości wymaga ich łącznego rozpoznania, rozpoznaje je łącznie sąd 

wojskowy. 

§ 2. Przepis § 1 stosuje się odpowiednio w postępowaniu przygotowawczym.


## Art. 650. {#kpk-art-650}
§ 1. Jeżeli w sprawie przeciwko dwóm lub więcej oskarżonym sąd 

wojskowy nie byłby właściwy do jej rozpoznania w całości bądź ze względu na rodzaj 

jednego z czynów, bądź ze względu na osobę jednego z oskarżonych, a dobro 

wymiaru sprawiedliwości tego wymaga, sąd wojskowy może rozpoznać sprawę 

łącznie lub przekazać ją w tym celu sądowi powszechnemu. 

§ 2. (uchylony) 

§ 3. Przekazanie nie może nastąpić, jeżeli sprawa dotyczy przestępstwa 

wskazanego w art. 647 § 1 pkt 1 lit. a lub c lub pkt 2 lit. a oraz w art. 648 pkt 1. 

§ 4. Na 

postanowienie w przedmiocie 

przekazania 

sprawy w myśl 

§ 1 przysługuje zażalenie.


## Art. 651. {#kpk-art-651}
§ 1. W sprawach o przestępstwa wymienione w art. 647 § 1 pkt 1 

i 2 orzeka sąd wojskowy, obejmujący swoją właściwością jednostkę wojskową, 

w której żołnierz pełnił służbę wojskową lub pracownik był zatrudniony. 

§ 2. Właściwość sądu wojskowego ze względu na przynależność oskarżonego do 

jednostki wojskowej określa się według chwili wszczęcia przeciwko niemu 

postępowania karnego. 

§ 3. (uchylony)


## Art. 652. {#kpk-art-652}
W sprawach podlegających orzecznictwu sądów wojskowych orzekają 

stosownie do zakresu właściwości: 

1) wojskowy sąd garnizonowy; 

2) wojskowy sąd okręgowy; 

3) Sąd Najwyższy.


## Art. 653. {#kpk-art-653}
§ 1. Wojskowy sąd garnizonowy orzeka w pierwszej instancji we 

wszystkich sprawach, z wyjątkiem spraw przekazanych ustawą do właściwości innego 

sądu. 

§ 2. W wypadkach wskazanych w ustawie wojskowy sąd garnizonowy 

rozpoznaje również w zakresie swej właściwości środki odwoławcze od orzeczeń 

i zarządzeń wydanych w postępowaniu przygotowawczym. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 351/356 

§ 3. Wojskowy sąd garnizonowy ma poza tym uprawnienia i obowiązki 

procesowe, które w postępowaniu przed sądami powszechnymi przysługują sądowi 

rejonowemu.


## Art. 654. {#kpk-art-654}
§ 1. Wojskowy sąd okręgowy orzeka w pierwszej instancji w sprawach 

o przestępstwa: 

1) 

2) 

popełnione przez żołnierzy posiadających stopień majora i wyższy; 

podlegające w postępowaniu przed sądami powszechnymi właściwości sądu 

okręgowego oraz określone w art. 339 § 3 i art. 345 § 3 i 4 Kodeksu karnego; 

3) 

popełnione przez żołnierzy i członków personelu cywilnego, o których mowa 

w art. 647 § 1 pkt 3; 

4) 

inne na podstawie przepisów szczególnych. 

§ 2. W postępowaniu 

przygotowawczym, w przedmiocie 

tymczasowego 

aresztowania w stosunku do żołnierzy, o których mowa w § 1 pkt 1, a także do 

żołnierzy sił zbrojnych państw obcych i członków ich personelu cywilnego, o których 

mowa w § 1 pkt 3, orzeka jednoosobowo wojskowy sąd okręgowy. 

§ 3. Wojskowy sąd okręgowy rozpoznaje także środki odwoławcze od orzeczeń 

i zarządzeń wydanych w pierwszej instancji w wojskowym sądzie garnizonowym oraz 

w wypadkach wskazanych w ustawie i z zachowaniem granic wskazanych w § 1 – od 

orzeczeń i zarządzeń wydanych w postępowaniu przygotowawczym. 

§ 4. Wojskowy sąd okręgowy rozpoznaje ponadto sprawy przewidziane dla sądu 

wyższego rzędu nad wojskowym sądem garnizonowym oraz inne sprawy przekazane 

mu przez ustawę. 

§ 5. Wojskowy sąd okręgowy ma poza tym uprawnienia i obowiązki procesowe, 

które w postępowaniu przed sądami powszechnymi przysługują sądowi okręgowemu.


## Art. 655. {#kpk-art-655}
§ 1. Sąd Najwyższy rozpoznaje: 

1) 

środki odwoławcze od orzeczeń i zarządzeń wydanych w pierwszej instancji 

w wojskowym sądzie okręgowym; 

kasacje; 

sprawy przewidziane w niniejszym kodeksie dla sądu wyższego rzędu nad 

2) 

3) 

wojskowym sądem okręgowym; 

4) 

inne sprawy przekazane przez ustawę Sądowi Najwyższemu. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 352/356 

§ 2. Przepisy art. 39 i art. 439 § 1 pkt 3 stosuje się odpowiednio do orzeczeń Sądu 

Najwyższego w zakresie spraw podlegających orzecznictwu sądów wojskowych.


## Art. 656. {#kpk-art-656}
§ 1. W sprawie dwu lub więcej oskarżonych, należącej do właściwości 

sądów wojskowych tego samego rzędu, orzeka sąd wojskowy właściwy dla 

oskarżonego o przestępstwo zagrożone karą najsurowszą. W razie niemożności 

ustalenia w ten sposób właściwości, sprawę rozpoznaje sąd wojskowy, na którego 

obszarze działania najpierw wszczęto postępowanie. 

§ 2. Jeżeli jednak sprawa należy do właściwości sądów wojskowych różnego 

rzędu, rozpoznaje ją sąd wyższego rzędu.


## Art. 657. {#kpk-art-657}
§ 1. Uprawnienia procesowe Prokuratora Generalnego przysługują 

również Zastępcy Prokuratora Generalnego do Spraw Wojskowych, jeżeli ustawa nie 

stanowi inaczej, a uprawnienia prokuratora okręgowego przysługują odpowiednio 

zastępcy prokuratora okręgowego do spraw wojskowych. 

§ 2. Jeżeli niniejszy kodeks mówi o oskarżycielu publicznym lub prokuratorze, 

należy przez to rozumieć prokuratora powszechnej jednostki organizacyjnej 

prokuratury. 

§ 3. Przepisu art. 45 § 2 nie stosuje się. 

§ 4. Jeżeli niniejszy kodeks mówi o prokuratorze wojskowym, należy przez to 

rozumieć 

prokuratora 

powszechnej 

jednostki 

organizacyjnej 

prokuratury 

wykonującego czynności w komórce organizacyjnej do spraw wojskowych.


## Art. 658. {#kpk-art-658}
§ 1. Prokurator wojskowy odmawia wszczęcia postępowania 

o przestępstwo ścigane na wniosek dowódcy jednostki wojskowej, jeżeli wobec 

sprawcy zastosowano 

już 

środki przewidziane w wojskowych przepisach 

dyscyplinarnych. 

§ 2. Nie dotyczy to wypadku, w którym wniosek o ściganie składa wyższy 

dowódca po uchyleniu kary dyscyplinarnej albo prokurator wojskowy korzysta 

z uprawnienia przewidzianego w art. 660. 

§ 3. Przepisu art. 12 § 3 nie stosuje się do wniosku dowódcy jednostki wojskowej 

lub wniosku wyższego dowódcy.


## Art. 659. {#kpk-art-659}
§ 1. W sprawach o przestępstwa ścigane na wniosek dowódcy 

jednostki wojskowej uprawnienia pokrzywdzonego 

lub 

instytucji określone 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 353/356 

w art. 306, a w wypadku przewidzianym w art. 330 § 2 – również określone w art. 55 

§ 1, przysługują temu dowódcy. 

§ 2. Uprawnienia 

i obowiązki dowódcy 

jednostki wojskowej przysługują 

odpowiednio kierownikowi instytucji cywilnej, w której żołnierz pełni służbę 

wojskową.


## Art. 660. {#kpk-art-660}
§ 1. Prokurator wojskowy może wszcząć postępowanie karne 

o przestępstwo ścigane na wniosek dowódcy jednostki wojskowej, także bez wniosku, 

jeżeli wymagają tego ważne względy dyscypliny wojskowej. 

§ 2. Dowódcy jednostki, a w wypadku określonym w art. 347 § 1 Kodeksu 

karnego także pokrzywdzonemu, na postanowienie prokuratora przysługuje zażalenie 

do sądu właściwego do rozpoznania sprawy. 

§ 3. Przepisu § 2 nie stosuje się, jeżeli dopiero w toku postępowania sądowego 

okaże się, iż czyn wyczerpuje znamiona przestępstwa ściganego na wniosek dowódcy 

jednostki wojskowej.


## Art. 661. {#kpk-art-661}
§ 1. Przestępstwo ścigane z oskarżenia prywatnego staje się z chwilą 

złożenia skargi przez pokrzywdzonego przestępstwem ściganym z urzędu. 

§ 2. Prokurator wojskowy może 

także wszcząć z urzędu postępowanie 

o przestępstwo ścigane z oskarżenia prywatnego, jeżeli wymaga tego interes 

społeczny. 

§ 3. Na postanowienie prokuratora pokrzywdzonemu przysługuje zażalenie do 

sądu właściwego do rozpoznania sprawy. 

§ 4. Na wniosek pokrzywdzonego, złożony przed prawomocnym ukończeniem 

postępowania wszczętego na podstawie § 1, postępowanie w sprawie umarza się, 

chyba że interes społeczny temu się sprzeciwia; w razie złożenia wniosku po 

rozpoczęciu przewodu sądowego w pierwszej instancji konieczna jest ponadto zgoda 

oskarżonego.


## Art. 662. {#kpk-art-662}
§ 1. O oskarżonym żołnierzu, oprócz danych określonych w art. 213, 

zbiera się też dane dotyczące przebiegu służby wojskowej, wyróżnień oraz ukarań 

dyscyplinarnych. 

§ 2. Uprawnienia i obowiązki zawodowego kuratora sądowego przysługują 

odpowiednio wojskowemu kuratorowi społecznemu. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 354/356 

§ 3. Minister Obrony Narodowej w porozumieniu z Ministrem Sprawiedliwości 

określi, w drodze rozporządzenia, sposób powoływania 

i zakres działalności 

wojskowych kuratorów społecznych, mając na uwadze warunki funkcjonowania Sił 

Zbrojnych Rzeczypospolitej Polskiej i wymagania służby wojskowej. 


# Rozdział 73
 

Środki przymusu i postępowanie przygotowawcze


## Art. 663. {#kpk-art-663}
(uchylony)


## Art. 664. {#kpk-art-664}
Prawo zatrzymania osoby podejrzanej podlegającej właściwości sądów 

wojskowych przysługuje, w warunkach określonych w art. 244, także przełożonemu 

wojskowemu i wojskowym organom porządkowym.


## Art. 665. {#kpk-art-665}
§ 1. O zatrzymaniu żołnierza 

lub pracownika wojska należy 

niezwłocznie zawiadomić dowódcę jednostki wojskowej, w której żołnierz pełni 

służbę a pracownik jest zatrudniony, również gdy zatrzymany tego nie żąda. 

§ 2. Jeżeli zatrzymanie żołnierza w warunkach określonych w art. 244 

§ 1 nastąpiło w związku z uzasadnionym przypuszczeniem popełnienia przestępstwa 

ściganego na wniosek dowódcy 

jednostki wojskowej, zatrzymanego należy 

niezwłocznie zwolnić również na polecenie uprawnionego dowódcy, chyba że wyższy 

dowódca lub prokurator wojskowy temu się sprzeciwią.


## Art. 666. {#kpk-art-666}
§ 1. Tymczasowe aresztowanie żołnierza oskarżonego o popełnienie 

przestępstwa określonego w art. 338 § 1, art. 339, 341 § 1, art. 343 § 2, art. 345, 352 

i 358 § 2 Kodeksu karnego może nastąpić wyjątkowo również wtedy, gdy zachodzi 

uzasadniona obawa, że oskarżony ponownie popełni jedno z tych przestępstw. 

§ 2. Przepis 

§ 1 stosuje 

się 

odpowiednio 

do 

pozostałych 

środków 

zapobiegawczych.


## Art. 667. {#kpk-art-667}
Postępowanie przygotowawcze ma na celu również zebranie danych, 

o jakich mowa w art. 662 § 1.


## Art. 668. {#kpk-art-668}
§ 1. Śledztwo prowadzi się w sprawach o zbrodnie, a w innych 

sprawach, gdy wymaga tego waga lub zawiłość sprawy. 

§ 2. Postępując w myśl art. 334 § 2 prokurator wojskowy poucza oskarżonego 

oraz pokrzywdzonego niebędącego żołnierzem także o prawie do złożenia wniosku, 

o którym mowa w art. 669 § 2 i 2a. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 355/356 


# Rozdział 74
 

Postępowanie przed sądem


## Art. 669. {#kpk-art-669}
§ 1. Ławnikiem nie może być żołnierz mający niższy stopień 

wojskowy niż oskarżony pełniący czynną służbę wojskową. Ograniczenia tego nie 

stosuje się, jeżeli ławnik ma stopień generała brygady lub kontradmirała. 

§ 2. W sprawie o zbrodnię, na wniosek oskarżonego złożony w terminie 7 dni od 

doręczenia mu zawiadomienia prokuratora wojskowego o przesłaniu aktu oskarżenia 

do sądu wojskowego z pouczeniem, o którym mowa w art. 668 § 2, prezes tego sądu, 

jeżeli nie zachodzi wypadek przewidziany w art. 28 § 3, wyznacza do składu 

orzekającego zamiast ławników żołnierzy – ławników sądu powszechnego. 

§ 2a. Przepis § 2 stosuje się odpowiednio na wniosek pokrzywdzonego 

niebędącego żołnierzem; w wypadku określonym w art. 55 § 1 wniosek dołącza się do 

aktu oskarżenia. 

§ 3. Minister Sprawiedliwości w porozumieniu z Ministrem Obrony Narodowej 

określi, w drodze rozporządzenia, sposób postępowania w sprawach związanych 

z uczestnictwem ławników sądów powszechnych w składach orzekających sądów 

wojskowych, o których mowa w § 2, mając na uwadze konieczność zapewnienia 

właściwego współdziałania prezesów sądów wojskowych i powszechnych przy 

wyznaczaniu ławników do składu orzekającego.


## Art. 670. {#kpk-art-670}
(uchylony)


## Art. 671. {#kpk-art-671}
§ 1. Udział obrońcy w rozprawie głównej przeciwko żołnierzowi 

odbywającemu zasadniczą służbę wojskową jest obowiązkowy przed wszystkimi 

sądami wojskowymi. 

§ 2. Udział obrońcy w rozprawie głównej jest obowiązkowy przed wszystkimi 

sądami wojskowymi w sprawie przeciwko żołnierzowi oskarżonemu o przestępstwo 

popełnione w związku z wykonywaniem przez niego obowiązków służbowych poza 

granicami państwa. 

§ 3. Udział obrońcy w posiedzeniu sądu wojskowego przeciwko osobom 

wymienionym w § 1 i 2 jest obowiązkowy również w wypadkach przewidzianych 

w art. 339 § 1 pkt 2 i 3. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 356/356 

§ 4. Udział obrońcy w rozprawie głównej przeciwko innemu oskarżonemu niż 

wymieniony w § 1 jest obowiązkowy przed wojskowym sądem okręgowym, jeżeli 

zachodzi wypadek przewidziany w art. 654 § 1 pkt 2. 

§ 5. W wypadkach określonych w § 1–4 stosuje się odpowiednio art. 81.


## Art. 671a. {#kpk-art-671a}
(uchylony)


## Art. 672. {#kpk-art-672}
Sąd wojskowy pierwszej instancji sporządza uzasadnienie wyroku 

z urzędu; nie dotyczy to wyroku uwzględniającego wnioski, o których mowa 

w art. 335 § 1 lub 2 oraz art. 387.


## Art. 672a. {#kpk-art-672a}
(uchylony)


## Art. 673. {#kpk-art-673}
W kwestii wznowienia postępowania orzeka w składzie trzech sędziów 

wojskowy sąd okręgowy, a w sprawach zakończonych orzeczeniem tego sądu lub 

Sądu Najwyższego – Sąd Najwyższy. 


# Rozdział 75
 

(zawierający art. 674–682 – uchylony) 

2025-09-11
