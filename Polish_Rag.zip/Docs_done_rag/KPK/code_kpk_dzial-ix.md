---
id: "code_kpk_dzial-ix"
title: "KPK — DZIAŁ IX"
source_pdf: "D19970555Lj (1).pdf"
dz_u: "Dz. U. 1997 Nr 89 poz. 555"
status: "obowiązujący"
last_consolidated: "2025-09-11"
law: "Kodeks postępowania karnego"
tags: ["kpk", "kodeks", "postępowanie karne"]
articles_range: {"first": "425", "last": "467"}
---

# DZIAŁ IX

## Art. 425. {#kpk-art-425}
§ 1. Od orzeczenia wydanego w pierwszej instancji przysługuje środek 

odwoławczy stronom oraz innym osobom wskazanym w przepisach ustawy. 

§ 2. Orzeczenie można zaskarżyć w całości lub w części. Można także zaskarżyć 

brak określonego rozstrzygnięcia. Przedmiotem zaskarżenia może być również samo 

uzasadnienie orzeczenia. 

§ 3. Odwołujący się może skarżyć jedynie rozstrzygnięcia lub ustalenia 

naruszające jego prawa lub szkodzące jego interesom. Ograniczenie to nie dotyczy 

oskarżyciela publicznego. 

§ 4. Oskarżyciel publiczny ma prawo wnieść środek odwoławczy także na 

korzyść oskarżonego.


## Art. 426. {#kpk-art-426}
§ 1. Od orzeczeń sądu odwoławczego oraz od orzeczeń wydanych 

przez Sąd Najwyższy nie przysługuje środek odwoławczy, chyba że ustawa stanowi 

inaczej. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 188/356 

§ 2. Od wydanego na skutek zażalenia postanowienia o zastosowaniu 

tymczasowego aresztowania, w tym w zakresie zastrzeżenia, o którym mowa 

w art. 257 § 2, a także od wydanego w toku postępowania odwoławczego 

postanowienia 

o przeprowadzeniu 

obserwacji, 

zastosowaniu 

środka 

zapobiegawczego, nałożeniu kary porządkowej, zawieszeniu postępowania oraz 

w przedmiocie kosztów procesu, o których po raz pierwszy orzekał sąd odwoławczy, 

przysługuje zażalenie do innego równorzędnego składu sądu odwoławczego. Jeżeli 

zaskarżone postanowienie wydał sąd w składzie jednego sędziego, zażalenie 

rozpoznaje sąd odwoławczy w składzie trzech sędziów, chyba że zażalenie dotyczy 

postanowienia o nałożeniu kary porządkowej lub w przedmiocie kosztów procesu.


## Art. 427. {#kpk-art-427}
§ 1. Odwołujący się powinien wskazać zaskarżone rozstrzygnięcie lub 

ustalenie, a także podać, czego się domaga. 

§ 2. Jeżeli środek odwoławczy pochodzi od oskarżyciela publicznego, obrońcy 

lub pełnomocnika, powinien ponadto zawierać wskazanie zarzutów stawianych 

rozstrzygnięciu oraz uzasadnienie. 

§ 3. Odwołujący się może również wskazać nowe fakty lub dowody, jeżeli nie 

mógł powołać ich w postępowaniu przed sądem pierwszej instancji. 

§ 3a. W środku odwoławczym nie można podnosić zarzutu nieprzeprowadzenia 

dowodu z urzędu, chyba że okoliczność, która ma być udowodniona, ma istotne 

znaczenie dla ustalenia, czy został popełniony czyn zabroniony, czy stanowi on 

przestępstwo i jakie, czy czyn zabroniony został popełniony w warunkach, o których 

mowa w art. 64 lub art. 65 Kodeksu karnego, lub czy zachodzą warunki do orzeczenia 

pobytu w zakładzie psychiatrycznym na podstawie art. 93g Kodeksu karnego. 

§ 4. (uchylony) 

§ 5. (uchylony)


## Art. 428. {#kpk-art-428}
§ 1. Środek odwoławczy wnosi się na piśmie do sądu, który wydał 

zaskarżone orzeczenie. 

§ 2. Strona może złożyć pisemną odpowiedź na środek odwoławczy. 

<§ 3. Prokurator, obrońca lub pełnomocnik będący adwokatem lub radcą 

prawnym lub Prokuratoria Generalna Rzeczypospolitej Polskiej mogą złożyć 

środek odwoławczy, a także odpowiedź na środek odwoławczy oraz dalsze pisma 

2025-09-11 

Dodany § 3 w art. 
428 wejdzie w 
życie 
dn. 
z 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1178). 

 
 
 
 
 

©Kancelaria Sejmu 

s. 189/356 

w toku postępowania odwoławczego – przez umieszczenie ich treści w portalu 

informacyjnym.>


## Art. 429. {#kpk-art-429}
§ 1. Prezes sądu pierwszej instancji odmawia przyjęcia środka 

odwoławczego, jeżeli wniesiony został po terminie lub przez osobę nieuprawnioną 

albo jest niedopuszczalny z mocy ustawy. 

§ 2. Na zarządzenie odmawiające przyjęcia środka odwoławczego na podstawie 

§ 1 lub art. 120 § 2 przysługuje zażalenie.


## Art. 430. {#kpk-art-430}
§ 1. Sąd odwoławczy pozostawia bez rozpoznania przyjęty środek 

odwoławczy, jeżeli zachodzą okoliczności określone w art. 429 § 1 albo jeżeli 

przyjęcie tego środka nastąpiło na skutek niezasadnego przywrócenia terminu. 

§ 2. Na postanowienie przysługuje zażalenie do innego równorzędnego składu 

sądu odwoławczego, chyba że zostało wydane przez Sąd Najwyższy.


## Art. 431. {#kpk-art-431}
§ 1. Środek odwoławczy można cofnąć. 

§ 2. Oskarżony może cofnąć wniesiony na jego korzyść środek odwoławczy, 

chyba że wniósł go oskarżyciel publiczny lub zachodzi wypadek przewidziany 

w art. 79. 

§ 3. Środka odwoławczego wniesionego na korzyść oskarżonego nie można bez 

jego zgody cofnąć.


## Art. 432. {#kpk-art-432}
Cofnięty środek odwoławczy sąd odwoławczy pozostawia bez 

rozpoznania, chyba że zachodzi jedna z przyczyn wymienionych w art. 439 lub 

art. 440.


## Art. 433. {#kpk-art-433}
§ 1. Sąd odwoławczy rozpoznaje sprawę w granicach zaskarżenia, 

a jeżeli w środku odwoławczym zostały wskazane zarzuty stawiane rozstrzygnięciu – 

również w granicach podniesionych zarzutów, uwzględniając treść art. 447 § 1–3, 

a w zakresie szerszym w wypadkach wskazanych w art. 435, art. 439 § 1, art. 440 

i art. 455. 

§ 2. Sąd odwoławczy jest obowiązany rozważyć wszystkie wnioski i zarzuty 

wskazane w środku odwoławczym, chyba że ustawa stanowi inaczej.


## Art. 434. {#kpk-art-434}
§ 1. Sąd odwoławczy może orzec na niekorzyść oskarżonego jedynie: 

1) wtedy, gdy wniesiono na jego niekorzyść środek odwoławczy, oraz 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 190/356 

2) w granicach zaskarżenia, chyba że ustawa nakazuje wydanie orzeczenia 

niezależnie od granic zaskarżenia, oraz 

3) w razie stwierdzenia uchybień podniesionych w środku odwoławczym, chyba że 

środek odwoławczy nie pochodzi od oskarżyciela publicznego lub pełnomocnika 

i nie podniesiono w nim zarzutów albo ustawa nakazuje wydanie orzeczenia 

niezależnie od podniesionych zarzutów. 

§ 2. Środek odwoławczy wniesiony na niekorzyść oskarżonego może 

spowodować orzeczenie także na korzyść oskarżonego, jeżeli zachodzą przesłanki 

określone w art. 440 lub art. 455. 

§ 3. (uchylony) 

§ 4. W przypadku skazania z zastosowaniem art. 60 § 3 lub 4 Kodeksu karnego 

lub art. 36 § 3 Kodeksu karnego skarbowego sąd odwoławczy może orzec na 

niekorzyść oskarżonego, i to niezależnie od granic zaskarżenia i podniesionych 

zarzutów, także wówczas, jeżeli środek odwoławczy wniesiono wyłącznie na korzyść 

oskarżonego, który po wydaniu wyroku odwołał lub w istotny sposób zmienił swoje 

wyjaśnienia lub zeznania. Nie dotyczy to jednak przypadku zasadnego podniesienia 

zarzutu obrazy prawa materialnego lub stwierdzenia przez sąd odwoławczy 

okoliczności uzasadniających uchylenie orzeczenia, określonych w art. 439 § 1. 

§ 5. (uchylony)


## Art. 435. {#kpk-art-435}
Sąd odwoławczy uchyla 

lub zmienia orzeczenie na korzyść 

współoskarżonych, choćby nie wnieśli środka odwoławczego, jeżeli je uchylił lub 

zmienił na rzecz współoskarżonego, którego środek odwoławczy dotyczył, gdy te 

same względy przemawiają za uchyleniem lub zmianą na rzecz tamtych.


## Art. 436. {#kpk-art-436}
Sąd może ograniczyć rozpoznanie środka odwoławczego tylko do 

poszczególnych uchybień, podniesionych przez 

stronę 

lub podlegających 

uwzględnieniu z urzędu, jeżeli rozpoznanie w tym zakresie jest wystarczające do 

wydania orzeczenia, a rozpoznanie pozostałych uchybień byłoby przedwczesne lub 

bezprzedmiotowe dla dalszego toku postępowania.


## Art. 437. {#kpk-art-437}
§ 1. Po rozpoznaniu środka odwoławczego sąd orzeka o utrzymaniu 

w mocy, zmianie lub uchyleniu zaskarżonego orzeczenia w całości lub w części. 

§ 2. Sąd odwoławczy zmienia zaskarżone orzeczenie, orzekając odmiennie co do 

istoty, lub uchyla je i umarza postępowanie; w innych wypadkach uchyla orzeczenie 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 191/356 

i przekazuje sprawę sądowi pierwszej instancji do ponownego rozpoznania. Uchylenie 

orzeczenia i przekazanie sprawy do ponownego rozpoznania może nastąpić wyłącznie 

w wypadkach wskazanych w art. 439 § 1, art. 454 lub jeżeli jest konieczne 

przeprowadzenie na nowo przewodu w całości.


## Art. 438. {#kpk-art-438}
Orzeczenie ulega uchyleniu lub zmianie w razie stwierdzenia: 

1) 

obrazy przepisów prawa materialnego w zakresie kwalifikacji prawnej czynu 

przypisanego oskarżonemu; 

1a) obrazy przepisów prawa materialnego w innym wypadku niż wskazany w pkt 1, 

chyba że pomimo błędnej podstawy prawnej orzeczenie odpowiada prawu; 

2) 

obrazy przepisów postępowania, jeżeli mogła ona mieć wpływ na treść 

orzeczenia; 

3) 

błędu w ustaleniach faktycznych przyjętych za podstawę orzeczenia, jeżeli mógł 

on mieć wpływ na treść tego orzeczenia; 

4) 

rażącej niewspółmierności kary, środka karnego, nawiązki lub niesłusznego 

zastosowania albo niezastosowania środka zabezpieczającego, przepadku lub 

innego środka.


## Art. 439. {#kpk-art-439}
§ 1. Niezależnie od granic zaskarżenia i podniesionych zarzutów oraz 

wpływu uchybienia na treść orzeczenia sąd odwoławczy na posiedzeniu uchyla 

zaskarżone orzeczenie, jeżeli: 

1) w wydaniu orzeczenia brała udział osoba nieuprawniona lub niezdolna do 

orzekania bądź podlegająca wyłączeniu na podstawie art. 40; 

2) 

sąd był nienależycie obsadzony lub którykolwiek z jego członków nie był obecny 

na całej rozprawie, z wyjątkiem wypadków, gdy wynika to z prowadzenia 

w dalszym ciągu na podstawie art. 402 § 2a lub art. 404 § 2a rozprawy 

przerwanej lub odroczonej; 

3) 

sąd powszechny orzekł w sprawie należącej do właściwości sądu szczególnego 

albo sąd szczególny orzekł w sprawie należącej do właściwości sądu 

powszechnego; 

4) 

sąd niższego rzędu orzekł w sprawie należącej do właściwości sądu wyższego 

rzędu; 

5) 

orzeczono karę, 

środek karny, 

środek kompensacyjny 

lub 

środek 

zabezpieczający nieznane ustawie; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 192/356 

6) 

zapadło z naruszeniem zasady większości głosów lub nie zostało podpisane przez 

którąkolwiek z osób biorących udział w jego wydaniu; 

7) 

8) 

zachodzi sprzeczność w treści orzeczenia, uniemożliwiająca jego wykonanie; 

zostało wydane pomimo to, że postępowanie karne co do tego samego czynu tej 

samej osoby zostało już prawomocnie zakończone; 

9) 

zachodzi 

jedna z okoliczności wyłączających postępowanie, określonych 

w art. 17 § 1 pkt 5, 6 i 8–11; 

10) oskarżony w postępowaniu sądowym nie miał obrońcy w wypadkach 

określonych w art. 79 § 1 i 2 oraz art. 80 lub obrońca nie brał udziału 

w czynnościach, w których jego udział był obowiązkowy; 

11) sprawę rozpoznano podczas nieobecności oskarżonego, którego obecność była 

obowiązkowa. 

§ 2. Uchylenie orzeczenia jedynie z powodów określonych w § 1 pkt 9–11 może 

nastąpić tylko na korzyść oskarżonego. 

§ 3. W posiedzeniu mają prawo wziąć udział strony, obrońcy i pełnomocnicy. 

Przepis art. 451 stosuje się odpowiednio.


## Art. 439a. {#kpk-art-439a}
Orzeczenia w sprawie o wykroczenie nie uchyla się z tego tylko 

powodu, że sąd orzekł w postępowaniu karnym zamiast w postępowaniu w sprawach 

o wykroczenia.


## Art. 440. {#kpk-art-440}
Jeżeli utrzymanie orzeczenia w mocy byłoby rażąco niesprawiedliwe, 

podlega ono niezależnie od granic zaskarżenia i podniesionych zarzutów zmianie na 

korzyść oskarżonego albo w sytuacji określonej w art. 437 § 2 zdanie drugie 

uchyleniu.


## Art. 441. {#kpk-art-441}
§ 1. Jeżeli przy rozpoznawaniu środka odwoławczego wyłoni się 

zagadnienie prawne wymagające zasadniczej wykładni ustawy, sąd odwoławczy może 

odroczyć rozpoznanie sprawy i przekazać zagadnienie do rozstrzygnięcia Sądowi 

Najwyższemu. 

§ 2. Sąd Najwyższy może przekazać rozstrzygnięcie zagadnienia prawnego 

powiększonemu składowi tego sądu. 

§ 3. Uchwała Sądu Najwyższego jest w danej sprawie wiążąca. 

§ 4. Prokurator, obrońcy 

i pełnomocnicy mają prawo wziąć udział 

w posiedzeniu. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 193/356 

§ 5. Sąd Najwyższy może przejąć sprawę do swego rozpoznania.


## Art. 442. {#kpk-art-442}
§ 1. Sąd, któremu przekazano sprawę do ponownego rozpoznania, 

orzeka w granicach, w jakich nastąpiło przekazanie. Uchylenie wyroku tylko 

w zakresie rozstrzygnięcia o karze albo innym środku nie stoi na przeszkodzie 

uniewinnieniu oskarżonego lub umorzeniu postępowania. 

§ 2. W wypadku przekazania sprawy do ponownego rozpoznania sąd orzekający 

w pierwszej instancji, przeprowadzając postępowanie w zakresie dowodów, które nie 

miały wpływu na uchylenie wyroku, może poprzestać na ich ujawnieniu. 

§ 3. Zapatrywania prawne i wskazania sądu odwoławczego co do dalszego 

postępowania są wiążące dla sądu, któremu sprawę przekazano do ponownego 

rozpoznania. Wskazania sądu odwoławczego co do dalszego postępowania mogą 

dotyczyć wyłącznie dowodów 

i innych 

czynności, które powinny być 

przeprowadzone, 

lub okoliczności, które należy wyjaśnić. Wskazania sądu 

odwoławczego nie mogą dotyczyć sposobu oceny poszczególnych dowodów.


## Art. 443. {#kpk-art-443}
W razie przekazania sprawy do ponownego rozpoznania wolno 

w dalszym postępowaniu wydać orzeczenie surowsze niż uchylone tylko wtedy, gdy 

orzeczenie to było zaskarżone na niekorzyść oskarżonego albo na korzyść 

oskarżonego w warunkach określonych w art. 434 § 4. Nie dotyczy to orzekania 

o środkach zabezpieczających wymienionych w art. 93a § 1 Kodeksu karnego.


## Art. 443a. {#kpk-art-443a}
§ 1. Do zaskarżenia uzasadnienia orzeczenia stosuje się odpowiednio 

przepisy art. 438 i art. 440. 

§ 2. Środkiem odwoławczym od uzasadnienia orzeczenia jest zażalenie, jeżeli 

nie wniesiono apelacji. W razie wniesienia apelacji i zażalenia – zażalenie rozpoznaje 

sąd odwoławczy łącznie z apelacją. 

§ 3. Strony mają prawo wziąć udział w posiedzeniu sądu odwoławczego 

rozpoznającego zażalenie. Przepis art. 451 stosuje się odpowiednio. 

§ 4. Po rozpoznaniu środka odwoławczego od uzasadnienia sąd orzeka 

o utrzymaniu w mocy lub zmianie zaskarżonego uzasadnienia w całości lub w części. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 194/356 


# Rozdział 49
 

Apelacja


## Art. 444. {#kpk-art-444}
§ 1. Od wyroku sądu pierwszej instancji stronom, a pokrzywdzonemu 

od wyroku warunkowo umarzającego postępowanie, wydanego na posiedzeniu 

przysługuje apelacja. 

§ 2. Apelacja przysługuje również podmiotowi zobowiązanemu określonemu w 

art. 91a.


## Art. 445. {#kpk-art-445}
§ 1. Termin do wniesienia apelacji wynosi 14 dni i biegnie dla każdego 

uprawnionego od daty doręczenia mu wyroku z uzasadnieniem. 

§ 2. Apelacja wniesiona przed upływem 

terminu 

złożenia wniosku 

o sporządzenie uzasadnienia wywołuje skutki określone w art. 422 

i podlega 

rozpoznaniu; apelację taką można uzupełnić w terminie określonym w § 1.


## Art. 446. {#kpk-art-446}
§ 1. Apelacja od wyroku sądu okręgowego, która nie pochodzi od 

prokuratora, powinna być sporządzona i podpisana przez adwokata, radcę prawnego 

albo radcę Prokuratorii Generalnej Rzeczypospolitej Polskiej. 

§ 2. Do apelacji dołącza się odpowiednią liczbę odpisów dla stron przeciwnych; 

do apelacji wnoszonej do sądu apelacyjnego dołącza się dodatkowo jeden odpis.


## Art. 447. {#kpk-art-447}
§ 1. Apelację co do winy uważa się za zwróconą przeciwko całości 

wyroku. 

§ 2. Apelację co do kary uważa się za zwróconą przeciwko całości 

rozstrzygnięcia o karze i środkach karnych. 

§ 3. Apelację co do środka karnego, środka kompensacyjnego albo przepadku 

uważa się za zwróconą odpowiednio przeciwko całości rozstrzygnięcia o środkach 

karnych albo o środkach kompensacyjnych albo o przepadku. 

§ 4. W apelacji można podnosić zarzuty, które nie stanowiły lub nie mogły 

stanowić przedmiotu zażalenia. 

§ 5. Podstawą apelacji nie mogą być zarzuty określone w art. 438 pkt 3 i 4, 

związane z treścią zawartego porozumienia, o którym mowa w art. 343, art. 343a 

i art. 387. 

§ 6. Podstawą apelacji nie mogą być wyłącznie zarzuty, których uwzględnienie 

mogłoby nastąpić w trybie określonym w art. 105, art. 420 lub art. 626. Przepisy 

art. 118 § 1 i 2 stosuje się. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 195/356


## Art. 448. {#kpk-art-448}
§ 1. O przyjęciu apelacji zawiadamia się prokuratora oraz obrońców 

i pełnomocników, a także strony, po czym akta przekazuje się niezwłocznie sądowi 

odwoławczemu. 

§ 1a. W przypadku apelacji od wyroku częściowego sądowi odwoławczemu 

zamiast akt sprawy przekazuje się uwierzytelnione kopie dokumentów z akt sprawy, 

a w razie niezbędnej potrzeby na jego żądanie udostępnia się akta sprawy na czas 

oznaczony. Przekazanie dokumentów lub udostępnienie akt sprawy może nastąpić 

w postaci elektronicznej. 

§ 2. Do zawiadomienia dołącza się odpis apelacji strony przeciwnej, chyba że 

w sprawie była wyłączona jawność rozprawy ze względu na ochronę informacji 

niejawnych o klauzuli tajności „tajne” lub „ściśle tajne”.


## Art. 449. {#kpk-art-449}
§ 1. Sąd odwoławczy rozpoznaje sprawę na rozprawie, a w wypadkach 

przewidzianych przez ustawę – na posiedzeniu. 

§ 2. Jeżeli postępowanie przygotowawcze zakończyło się w formie dochodzenia 

oraz w sprawach z oskarżenia prywatnego, sąd odwoławczy orzeka na rozprawie 

jednoosobowo, chyba że zaskarżone orzeczenie sąd pierwszej instancji wydał 

w innym składzie niż w składzie jednego sędziego.


## Art. 449a. {#kpk-art-449a}
§ 1. Jeżeli jest to niezbędne dla prawidłowego wyrokowania 

w sprawie, sąd odwoławczy przed wydaniem orzeczenia może zwrócić akta sprawy 

sądowi pierwszej instancji w celu uzupełnienia uzasadnienia zaskarżonego wyroku, 

jednocześnie szczegółowo wskazując kwestie, o które należy uzupełnić uzasadnienie. 

Kwestie te mogą dotyczyć uzupełnienia zakresu uzasadnienia o inne części wyroku 

w wypadkach, o których mowa w art. 423 § 1a, lub uzupełnienia treści zawartych 

w uzasadnieniu w tym zakresie, w jakim zostało ono sporządzone. 

§ 2. Do uzupełnienia uzasadnienia stosuje się odpowiednio przepisy dotyczące 

sporządzania, doręczania i zaskarżania uzasadnienia wyroku. 

§ 3. Strona, która wniosła apelację, może ją uzupełnić w terminie 14 dni od daty 

doręczenia jej uzupełnionego uzasadnienia.


## Art. 450. {#kpk-art-450}
§ 1. Udział w rozprawie prokuratora, a obrońcy w wypadkach 

określonych w art. 79 i art. 80 jest obowiązkowy. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 196/356 

§ 2. Udział w rozprawie innych stron i ich pełnomocników oraz obrońcy 

w wypadkach niewymienionych w § 1 jest obowiązkowy wtedy, gdy prezes sądu lub 

sąd uzna to za konieczne. 

§ 3. Niestawiennictwo należycie zawiadomionych o terminie rozprawy stron, 

obrońców lub pełnomocników nie tamuje rozpoznania sprawy, chyba że ich udział jest 

obowiązkowy.


## Art. 451. {#kpk-art-451}
Sąd odwoławczy, na wniosek oskarżonego pozbawionego wolności 

złożony w terminie 7 dni od daty doręczenia mu zawiadomienia o przyjęciu apelacji, 

zarządza sprowadzenie go na rozprawę, chyba że uzna za wystarczającą obecność 

obrońcy. Wniosek złożony po terminie podlega rozpoznaniu, jeżeli nie powoduje to 

konieczności odroczenia rozprawy. O prawie złożenia wniosku należy pouczyć 

oskarżonego. Jeżeli sąd nie zarządza sprowadzenia oskarżonego, który nie ma 

obrońcy, sąd, prezes sądu lub referendarz sądowy wyznacza obrońcę z urzędu.


## Art. 452. {#kpk-art-452}
§ 1. (uchylony) 

§ 2. Sąd odwoławczy oddala wniosek dowodowy również, jeżeli: 

1) 

przeprowadzenie dowodu przez 

ten sąd byłoby niecelowe z przyczyn 

określonych w art. 437 § 2 zdanie drugie; 

2) 

dowód nie był powołany przed sądem pierwszej instancji, pomimo że składający 

wniosek mógł go wówczas powołać, 

lub okoliczność, która ma być 

udowodniona, dotyczy nowego faktu, niebędącego przedmiotem postępowania 

przed sądem pierwszej instancji, a składający wniosek mógł go wówczas 

wskazać. 

§ 3. Wniosku dowodowego nie można oddalić na podstawie § 2 pkt 2, jeżeli 

okoliczność, która ma być udowodniona, w granicach rozpoznania sprawy przez sąd 

odwoławczy, ma istotne znaczenie dla ustalenia, czy został popełniony czyn 

zabroniony, czy stanowi on przestępstwo i jakie, czy czyn zabroniony został 

popełniony w warunkach, o których mowa w art. 64 lub art. 65 Kodeksu karnego, lub 

czy zachodzą warunki do orzeczenia pobytu w zakładzie psychiatrycznym na 

podstawie art. 93g Kodeksu karnego.


## Art. 453. {#kpk-art-453}
§ 1. Przewód sądowy w sądzie odwoławczym rozpoczyna ustne 

sprawozdanie, w którym sędzia sprawozdawca przedstawia przebieg i wyniki 

dotychczasowego postępowania, a w szczególności treść zaskarżonego wyroku oraz 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 197/356 

zarzuty i wnioski apelacyjne, jak również kwestie wymagające rozstrzygnięcia 

z urzędu. W miarę potrzeby odczytuje się z akt poszczególne ich części. 

§ 1a. Jeżeli na rozprawę stawili się jedynie uczestnicy postępowania, sąd może 

na wniosek lub za zgodą obecnych stron odstąpić od ustnego sprawozdania. Jeżeli na 

rozprawę nie stawił się nikt, sąd może odstąpić od ustnego sprawozdania. W tych 

wypadkach przewód sądowy rozpoczyna ogłoszenie postanowienia o odstąpieniu od 

ustnego sprawozdania. 

§ 2. Strony mogą składać wyjaśnienia, oświadczenia i wnioski ustnie lub na 

piśmie; złożone na piśmie podlegają odczytaniu, przy czym przepis art. 394 stosuje 

się. 

§ 3. Przewodniczący udziela głosu uczestnikom postępowania, o których mowa 

w art. 406 § 1, w kolejności przez siebie ustalonej, przy czym najpierw udziela głosu 

skarżącemu. Oskarżonemu i jego obrońcy nie można odmówić zabrania głosu po 

przemówieniach innych uczestników postępowania.


## Art. 454. {#kpk-art-454}
§ 1. Sąd odwoławczy nie może skazać oskarżonego, który został 

uniewinniony w pierwszej instancji lub co do którego w pierwszej instancji umorzono 

postępowanie. 

§ 2. (uchylony) 

§ 3. (uchylony)


## Art. 455. {#kpk-art-455}
Nie zmieniając ustaleń faktycznych, sąd odwoławczy poprawia błędną 

kwalifikację prawną niezależnie od granic zaskarżenia i podniesionych zarzutów. 

Poprawienie kwalifikacji prawnej na niekorzyść oskarżonego może nastąpić tylko 

wtedy, gdy wniesiono środek odwoławczy na jego niekorzyść.


## Art. 455a. {#kpk-art-455a}
Nie można uchylić wyroku z tego powodu, że jego uzasadnienie nie 

spełnia wymogów określonych w art. 424.


## Art. 456. {#kpk-art-456}
O utrzymaniu w mocy, uchyleniu lub zmianie wyroku sądu pierwszej 

instancji sąd odwoławczy orzeka wyrokiem.


## Art. 457. {#kpk-art-457}
§ 1. Uzasadnienie wyroku sporządza się z urzędu w terminie 14 dni. 

§ 2. Jeżeli sąd zmienia lub utrzymuje zaskarżony wyrok w mocy, uzasadnienie 

sporządza się na wniosek strony. Przepisy art. 422 i art. 423 stosuje się odpowiednio. 

§ 3. W uzasadnieniu należy podać, czym kierował się sąd wydając wyrok oraz 

dlaczego zarzuty i wnioski apelacji sąd uznał za zasadne albo niezasadne. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 198/356


## Art. 458. {#kpk-art-458}
Przepisy dotyczące postępowania przed sądem pierwszej instancji 

stosuje się odpowiednio w postępowaniu przed sądem odwoławczym, chyba że 

przepisy niniejszego rozdziału stanowią inaczej. 


# Rozdział 50
 

Zażalenie i sprzeciw


## Art. 459. {#kpk-art-459}
§ 1. Zażalenie przysługuje na postanowienia sądu zamykające drogę 

do wydania wyroku, chyba że ustawa stanowi inaczej. 

§ 2. Zażalenie przysługuje 

także na postanowienia 

co do 

środka 

zabezpieczającego oraz na inne postanowienia w wypadkach przewidzianych 

w ustawie. 

§ 3. Zażalenie przysługuje stronom, a także osobie, której postanowienie 

bezpośrednio dotyczy, chyba że ustawa stanowi inaczej.


## Art. 460. {#kpk-art-460}
Zażalenie lub sprzeciw wnosi się w terminie 7 dni od daty ogłoszenia 

postanowienia, a jeżeli ustawa nakazuje doręczenie postanowienia – od daty 

doręczenia. Dotyczy to również zażalenia na zawarte w wyroku rozstrzygnięcie 

w przedmiocie kosztów lub opłat; jeżeli jednak odwołujący się złoży wniosek 

o sporządzenie na piśmie oraz doręczenie uzasadnienia wyroku, zażalenie można 

wnieść w terminie przewidzianym do wniesienia apelacji.


## Art. 461. {#kpk-art-461}
§ 1. Do zażalenia na postanowienie kończące postępowanie dołącza się 

odpowiednią liczbę odpisów dla osób, których dotyczy zaskarżone postanowienie. 

Odpisy te doręcza się tym osobom niezwłocznie. 

§ 2. O wniesieniu zażalenia na postanowienie inne niż wymienione w § 1 oraz 

sprzeciwu zawiadamia się osoby, których dotyczy zaskarżone postanowienie.


## Art. 462. {#kpk-art-462}
§ 1. Jeżeli ustawa nie stanowi inaczej, zażalenie nie wstrzymuje 

wykonania zaskarżonego postanowienia; sąd jednak, który je wydał, lub sąd powołany 

do rozpoznania zażalenia może wstrzymać wykonanie postanowienia. 

§ 2. Odmowa wstrzymania nie wymaga uzasadnienia.


## Art. 463. {#kpk-art-463}
§ 1. Sąd, na którego postanowienie złożono zażalenie, może je 

uwzględnić, jeżeli orzeka w tym samym składzie, w którym wydał zaskarżone 

postanowienie; w innych wypadkach prezes sądu przekazuje zażalenie niezwłocznie, 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 199/356 

wraz z aktami lub niezbędnymi odpisami z akt sprawy, sądowi powołanemu do 

rozpoznania zażalenia. 

§ 2. Zażalenie na postanowienie w przedmiocie tymczasowego aresztowania 

oraz zabezpieczenia majątkowego powinno być przekazane do rozpoznania w ciągu 

48 godzin.


## Art. 464. {#kpk-art-464}
§ 1. Strony oraz obrońcy i pełnomocnicy mają prawo wziąć udział 

w posiedzeniu sądu odwoławczego rozpoznającego zażalenie na postanowienie 

kończące postępowanie, na postanowienie w przedmiocie środka zapobiegawczego 

innego niż 

tymczasowe 

aresztowanie, na postanowienie w przedmiocie 

zabezpieczenia majątkowego oraz na zatrzymanie. Mają oni prawo do udziału 

w posiedzeniu sądu odwoławczego także wtedy, gdy przysługuje im prawo udziału 

w posiedzeniu sądu pierwszej instancji. 

§ 2. W innych wypadkach sąd odwoławczy może zezwolić stronom lub obrońcy 

albo pełnomocnikowi na wzięcie udziału w posiedzeniu. 

§ 3. (uchylony)


## Art. 465. {#kpk-art-465}
§ 1. Przepisy dotyczące zażaleń na postanowienia sądu stosuje się 

odpowiednio do zażaleń na postanowienia prokuratora i prowadzącego postępowanie 

przygotowawcze. 

§ 2. Na postanowienie prokuratora przysługuje zażalenie do sądu właściwego do 

rozpoznania sprawy, chyba że ustawa stanowi inaczej. 

§ 2a. W sprawach z oskarżenia prywatnego zażalenie na postanowienie 

prokuratora o odmowie wszczęcia lub o umorzeniu postępowania przygotowawczego 

rozpoznaje prokurator nadrzędny, jeżeli postanowienie zapadło z uwagi na brak 

interesu społecznego w ściganiu z urzędu sprawcy. 

§ 3. Zażalenie na postanowienie prowadzącego postępowanie przygotowawcze, 

jeżeli nie jest nim prokurator, rozpoznaje prokurator sprawujący nadzór nad tym 

postępowaniem.


## Art. 466. {#kpk-art-466}
§ 1. Przepisy dotyczące sprzeciwów i zażaleń na postanowienia stosuje 

się odpowiednio do sprzeciwów i zażaleń na zarządzenia. 

§ 2. Zażalenie na zarządzenie prezesa rozpoznaje sąd odwoławczy.


## Art. 467. {#kpk-art-467}
§ 1. Przepisy rozdziału niniejszego stosuje się odpowiednio do 

przewidzianych w ustawie zażaleń na czynności lub zaniechanie czynności. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 200/356 

§ 2. Uznając zasadność zażalenia, organ odwoławczy stwierdza niezgodność 

czynności z prawem lub brak czynności i zarządza, co należy, zwłaszcza w celu 

naprawienia skutków uchybienia oraz zapobieżenia podobnym uchybieniom 

w przyszłości, a także podejmuje inne przewidziane w ustawie środki.
