---
id: "code_kpk_dzial-ii"
title: "KPK — DZIAŁ II"
source_pdf: "D19970555Lj (1).pdf"
dz_u: "Dz. U. 1997 Nr 89 poz. 555"
status: "obowiązujący"
last_consolidated: "2025-09-11"
law: "Kodeks postępowania karnego"
tags: ["kpk", "kodeks", "postępowanie karne"]
articles_range: {"first": "24", "last": "44"}
---

# DZIAŁ II

## Art. 24. {#kpk-art-24}
§ 1. Sąd rejonowy orzeka w pierwszej instancji we wszystkich 

sprawach, z wyjątkiem spraw przekazanych ustawą do właściwości innego sądu. 

§ 2. Sąd rejonowy rozpoznaje ponadto środki odwoławcze w wypadkach 

wskazanych w ustawie.


## Art. 25. {#kpk-art-25}
§ 1. Sąd okręgowy orzeka w pierwszej 

instancji w sprawach 

o następujące przestępstwa: 

1) 

2) 

o zbrodnie określone w Kodeksie karnym oraz w ustawach szczególnych; 

o występki określone w rozdziałach XVI i XVII oraz w art. 140–142, art. 148 § 4 

i 5, art. 148a, art. 149, art. 150 § 1, art. 151–154, art. 158 § 3, art. 163 § 3 i 4, 

art. 165 § 1, 3 i 4, art. 166 § 1, art. 173 § 3 i 4, art. 185 § 2, art. 189a § 2, 

art. 210 § 2, art. 211a, art. 252 § 3, art. 258 § 1–3, art. 265 § 1 i 2, art. 269, 

art. 278 § 1, 2 i 3a w zw. z art. 294 § 1 lub 2, art. 284 § 1 i 2 w zw. z art. 294 § 1 

lub 2, art. 286 § 1 w zw. z art. 294 § 1 lub 2, art. 287 § 1 w zw. z art. 294 § 1 lub 

2, art. 296 § 3 oraz art. 299 Kodeksu karnego; 

3) 

o występki, które z mocy przepisu szczególnego należą do właściwości sądu 

okręgowego. 

§ 2. Sąd apelacyjny, na wniosek sądu rejonowego, może przekazać do 

rozpoznania sądowi okręgowemu, jako sądowi pierwszej instancji, sprawę o każde 

przestępstwo, ze względu na szczególną wagę lub zawiłość sprawy. 

§ 3. Sąd okręgowy rozpoznaje ponadto środki odwoławcze od orzeczeń 

i zarządzeń wydanych w pierwszej instancji w sądzie rejonowym oraz inne sprawy 

przekazane mu przez ustawę.


## Art. 26. {#kpk-art-26}
Sąd apelacyjny rozpoznaje środki odwoławcze od orzeczeń i zarządzeń 

wydanych w pierwszej instancji w sądzie okręgowym oraz inne sprawy przekazane 

mu przez ustawę.


## Art. 27. {#kpk-art-27}
Sąd Najwyższy rozpoznaje kasacje oraz środki odwoławcze i inne 

sprawy w wypadkach określonych w ustawie. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 11/356


## Art. 28. {#kpk-art-28}
§ 1. Na rozprawie głównej sąd orzeka w składzie jednego sędziego, 

jeżeli ustawa nie stanowi inaczej. Sędzia ma prawa i obowiązki przewodniczącego. 

§ 2. W sprawach o zbrodnie sąd orzeka w składzie jednego sędziego i dwóch 

ławników. 

§ 3. Ze względu na szczególną zawiłość sprawy lub jej wagę sąd pierwszej 

instancji może postanowić o jej rozpoznaniu w składzie trzech sędziów albo jednego 

sędziego i dwóch ławników. 

§ 4. W sprawach o przestępstwa, za które ustawa przewiduje karę dożywotniego 

pozbawienia wolności, sąd orzeka w składzie dwóch sędziów i trzech ławników.


## Art. 29. {#kpk-art-29}
§ 1. Na rozprawie apelacyjnej i kasacyjnej sąd orzeka w składzie trzech 

sędziów, jeżeli ustawa nie stanowi inaczej. 

§ 2. Apelację 

lub kasację od wyroku orzekającego karę dożywotniego 

pozbawienia wolności albo apelację wnoszącą o wymierzenie takiej kary rozpoznaje 

sąd w składzie pięciu sędziów.


## Art. 30. {#kpk-art-30}
§ 1. Na posiedzeniu sąd orzeka jednoosobowo, chyba że ustawa stanowi 

inaczej albo ze względu na szczególną zawiłość sprawy lub jej wagę prezes sądu 

zarządzi jej rozpoznanie w składzie trzech sędziów. 

§ 2. Sąd odwoławczy na posiedzeniu orzeka jednoosobowo, a w składzie trzech 

sędziów wówczas, gdy zaskarżone orzeczenie wydano w składzie innym niż 

jednoosobowy albo ze względu na szczególną zawiłość sprawy lub jej wagę prezes 

sądu zarządzi jej rozpoznanie w składzie trzech sędziów, chyba że ustawa stanowi 

inaczej.


## Art. 31. {#kpk-art-31}
§ 1. Miejscowo właściwy do rozpoznania sprawy jest sąd, w którego 

okręgu popełniono przestępstwo. 

§ 2. Jeżeli przestępstwo popełniono na polskim statku wodnym lub powietrznym, 

a § 1 nie może mieć zastosowania, właściwy jest sąd macierzystego portu statku. 

§ 3. Jeżeli przestępstwo popełniono w okręgu kilku sądów, właściwy jest ten sąd, 

w którego okręgu najpierw wszczęto postępowanie przygotowawcze.


## Art. 32. {#kpk-art-32}
§ 1. Jeżeli nie można ustalić miejsca popełnienia przestępstwa, 

właściwy jest sąd, w którego okręgu: 

1) 

2) 

ujawniono przestępstwo, 

ujęto oskarżonego, 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 12/356 

3) 

oskarżony przed popełnieniem przestępstwa stale mieszkał lub czasowo 

przebywał 

– zależnie od tego, gdzie najpierw wszczęto postępowanie przygotowawcze. 

§ 2. Przepis § 1 stosuje się odpowiednio, jeżeli przestępstwo popełniono za 

granicą. 

§ 3. Jeżeli nie można ustalić właściwości miejscowej sądu według przepisów 

poprzedzających, sprawę rozpoznaje sąd właściwy dla dzielnicy Śródmieście miasta 

stołecznego Warszawy.


## Art. 33. {#kpk-art-33}
§ 1. Jeżeli tę samą osobę oskarżono o kilka przestępstw, a sprawy należą 

do właściwości różnych sądów tego samego rzędu, właściwy jest sąd, w którego 

okręgu najpierw wszczęto postępowanie przygotowawcze. 

§ 2. Jeżeli sprawy należą do właściwości sądów różnego rzędu, sprawę 

rozpoznaje sąd wyższego rzędu.


## Art. 34. {#kpk-art-34}
§ 1. Sąd właściwy dla sprawców przestępstw jest również właściwy dla 

pomocników, podżegaczy oraz innych osób, których przestępstwo pozostaje 

w ścisłym związku z przestępstwem sprawcy, jeżeli postępowanie przeciwko nim 

toczy się jednocześnie. 

§ 2. Sprawy osób wymienionych w § 1 powinny być połączone we wspólnym 

postępowaniu; przepis art. 33 stosuje się odpowiednio. 

§ 3. Jeżeli łączne rozpoznanie spraw, o których mowa w § 2, jest istotnie 

utrudnione z uwagi na przyczyny określone w art. 22 § 1 lub inne ważne powody, 

można wyłączyć 

i odrębnie 

rozpoznać 

sprawę poszczególnych osób 

lub 

o poszczególne czyny, chyba że przeszkoda nie ma charakteru długotrwałego lub 

kontynuowanie postępowania nie narusza prawa do obrony oskarżonego, którego 

odpowiedzialności karnej przeszkoda dotyczy. 

§ 4. Sprawa wyłączona po otwarciu przewodu sądowego podlega rozpoznaniu 

przez sąd, który dokonał wyłączenia, chyba że nie jest on właściwy rzeczowo. 

§ 5. Jeżeli sprawa wyłączona po otwarciu przewodu sądowego podlega 

rozpoznaniu przez sąd, który dokonał wyłączenia, można prowadzić ją w dalszym 

ciągu w tym samym składzie, chyba że wskutek wyłączenia zaistniała okoliczność 

określona w art. 41 § 1. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 13/356 

§ 6. Na postanowienie o wyłączeniu sprawy do odrębnego rozpoznania wydane 

po otwarciu przewodu sądowego przysługuje zażalenie prokuratorowi oraz stronie, 

której sprawę do odrębnego rozpoznania wyłączono.


## Art. 35. {#kpk-art-35}
§ 1. Sąd bada z urzędu swą właściwość, a w razie stwierdzenia swej 

niewłaściwości przekazuje sprawę właściwemu sądowi lub innemu organowi. 

§ 2. Jeżeli sąd na rozprawie głównej stwierdza, że nie jest właściwy miejscowo 

lub że właściwy jest sąd niższego rzędu, może przekazać sprawę innemu sądowi 

jedynie wtedy, gdy powstaje konieczność odroczenia rozprawy. 

§ 3. Na postanowienie w kwestii właściwości przysługuje zażalenie.


## Art. 36. {#kpk-art-36}
Sąd wyższego rzędu nad sądem właściwym może przekazać sprawę 

innemu sądowi równorzędnemu, jeżeli większość osób, które należy wezwać na 

rozprawę, zamieszkuje blisko tego sądu, a z dala od sądu właściwego.


## Art. 37. {#kpk-art-37}
§ 1. Sąd Najwyższy może z inicjatywy właściwego sądu lub na wniosek 

prokuratora przekazać sprawę do rozpoznania innemu sądowi równorzędnemu, jeżeli 

wymaga tego dobro wymiaru sprawiedliwości. 

§ 2. Właściwy sąd przekazuje wniosek prokuratora, o którym mowa w § 1, wraz 

z aktami sprawy, w terminie 14 dni od dnia jego otrzymania do rozpoznania Sądowi 

Najwyższemu, przedstawiając własne stanowisko.


## Art. 38. {#kpk-art-38}
§ 1. Spór o właściwość między sądami rozstrzyga ostatecznie sąd 

wyższego rzędu właściwy ze względu na siedzibę sądu, który pierwszy wszczął spór. 

Spór o właściwość między sądem rejonowym a sądem okręgowym rozstrzyga sąd 

apelacyjny, a spór o właściwość między sądem apelacyjnym a innym sądem 

powszechnym – Sąd Najwyższy. 

§ 2. W czasie trwania sporu każdy z tych sądów przedsiębierze czynności 

niecierpiące zwłoki.


## Art. 39. {#kpk-art-39}
Jeżeli sąd wojskowy przekaże sprawę sądowi powszechnemu lub nie 

przyjmie sprawy przekazanej mu przez sąd powszechny, sprawę rozpoznaje sąd 

powszechny. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 14/356 


# Rozdział 2
 

Wyłączenie sędziego 

1) 

2)


## Art. 40. {#kpk-art-40}
§ 1. Sędzia jest z mocy prawa wyłączony od udziału w sprawie, jeżeli: 

sprawa dotyczy tego sędziego bezpośrednio; 

jest małżonkiem strony lub pokrzywdzonego albo ich obrońcy, pełnomocnika lub 

przedstawiciela ustawowego albo pozostaje we wspólnym pożyciu z jedną z tych 

osób; 

3) 

jest krewnym lub powinowatym w linii prostej, a w linii bocznej aż do stopnia 

pomiędzy dziećmi rodzeństwa osób wymienionych w pkt 2 albo jest związany 

z jedną z tych osób węzłem przysposobienia, opieki lub kurateli; 

4) 

był świadkiem czynu, o który sprawa się toczy, albo w tej samej sprawie był 

przesłuchany w charakterze świadka lub występował jako biegły; 

5) 

brał udział w sprawie jako prokurator, obrońca, pełnomocnik, przedstawiciel 

ustawowy strony, albo prowadził postępowanie przygotowawcze; 

6) 

brał udział w wydaniu zaskarżonego orzeczenia 

lub wydał zaskarżone 

zarządzenie; 

brał udział w wydaniu orzeczenia, które zostało uchylone; 

(uchylony) 

brał udział w wydaniu orzeczenia, co do którego wniesiono sprzeciw; 

7) 

8) 

9) 

10) prowadził mediację. 

§ 2. Powody wyłączenia trwają mimo ustania uzasadniającego je małżeństwa, 

wspólnego pożycia, przysposobienia, opieki lub kurateli. 

§ 3. Sędzia, który brał udział w wydaniu orzeczenia objętego wnioskiem o 

wznowienie, zaskarżonego w trybie kasacji lub objętego skargą nadzwyczajną, nie 

może orzekać co do tego wniosku, kasacji lub skargi.


## Art. 41. {#kpk-art-41}
§ 1.4) Sędzia ulega wyłączeniu, jeżeli istnieje okoliczność tego rodzaju, 

że mogłaby wywołać uzasadnioną wątpliwość co do jego bezstronności w danej 

sprawie. 

4) Utracił moc z dniem 12 marca 2020 r. w związku z art. 42 § 1, stosowany odpowiednio na podstawie 
art. 741 pkt 1 ustawy z dnia 6 lipca 1982 r. o radcach prawnych, w zakresie, w jakim dopuszcza 
rozpoznanie wniosku o wyłączenie sędziego z powodu wadliwości powołania sędziego przez 
Prezydenta Rzeczypospolitej Polskiej na wniosek Krajowej Rady Sądownictwa, w skład której 
wchodzą sędziowie wybrani na podstawie art. 9a ustawy z dnia 12 maja 2011 r. o Krajowej Radzie 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 15/356 

§ 2. Wniosek o wyłączenie sędziego, zgłoszony na podstawie § 1 po rozpoczęciu 

przewodu sądowego, pozostawia się bez rozpoznania, chyba że przyczyna wyłączenia 

powstała lub stała się stronie wiadoma dopiero po rozpoczęciu przewodu.


## Art. 41a. {#kpk-art-41a}
Wniosek o wyłączenie sędziego oparty na tych samych podstawach 

faktycznych co wniosek wcześniej rozpoznany pozostawia się bez rozpoznania; 

przepisu art. 42 § 3 nie stosuje się.


## Art. 42. {#kpk-art-42}
§ 1. Wyłączenie następuje na żądanie sędziego, z urzędu albo na 

wniosek strony. 

§ 2. Jeżeli sędzia uznaje, że zachodzi przyczyna wyłączająca go z mocy art. 40, 

wyłącza się, składając oświadczenie na piśmie do akt, a na jego miejsce wstępuje inny 

sędzia. 

§ 3. Sędzia, co do którego zgłoszono wniosek o wyłączenie na podstawie art. 41, 

może złożyć do akt stosowne oświadczenie na piśmie. Wniosek rozpoznaje się 

niezwłocznie. Z chwilą wyłączenia sędziego czynności procesowe dokonane z jego 

udziałem po złożeniu wniosku stają się bezskuteczne. 

§ 4. Poza wypadkiem określonym w § 2 o wyłączeniu orzeka sąd, przed którym 

toczy się postępowanie; w składzie orzekającym w kwestii wyłączenia nie może brać 

udziału sędzia, którego dotyczy wyłączenie. W razie niemożności utworzenia takiego 

składu sądu, w kwestii wyłączenia orzeka sąd wyższego rzędu.


## Art. 43. {#kpk-art-43}
Jeżeli z powodu wyłączenia sędziów rozpoznanie sprawy w danym 

sądzie jest niemożliwe, sąd wyższego rzędu przekazuje sprawę innemu sądowi 

równorzędnemu.


## Art. 44. {#kpk-art-44}
Przepisy niniejszego rozdziału stosuje się odpowiednio do referendarzy 

sądowych i ławników. O wyłączeniu referendarza orzeka sąd w składzie jednego 

sędziego. 

Sądownictwa, na podstawie wyroku Trybunału Konstytucyjnego z dnia 4 marca 2020 r. sygn. akt 
P 22/19 (Dz. U. poz. 413). 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 16/356
