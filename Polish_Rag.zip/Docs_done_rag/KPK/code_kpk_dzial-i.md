---
id: "code_kpk_dzial-i"
title: "KPK — DZIAŁ I"
source_pdf: "D19970555Lj (1).pdf"
dz_u: "Dz. U. 1997 Nr 89 poz. 555"
status: "obowiązujący"
last_consolidated: "2025-09-11"
law: "Kodeks postępowania karnego"
tags: ["kpk", "kodeks", "postępowanie karne"]
articles_range: {"first": "1", "last": "23b"}
---

# DZIAŁ I

## Art. 1. {#kpk-art-1}
Postępowanie karne w sprawach należących do właściwości sądów toczy 

się według przepisów niniejszego kodeksu.


## Art. 2. {#kpk-art-2}
§ 1. Przepisy niniejszego kodeksu mają na celu takie ukształtowanie 

postępowania karnego, aby: 

1) 

sprawca przestępstwa został wykryty i pociągnięty do odpowiedzialności karnej, 

a osoba niewinna nie poniosła tej odpowiedzialności; 

2) 

przez trafne zastosowanie środków przewidzianych w prawie karnym oraz 

ujawnienie okoliczności sprzyjających popełnieniu przestępstwa osiągnięte 

zostały zadania postępowania karnego nie tylko w zwalczaniu przestępstw, lecz 

1) Niniejsza ustawa w zakresie swojej regulacji realizuje postanowienia: 

1) dyrektywy Parlamentu Europejskiego i Rady 2013/48/UE z dnia 22 października 2013 r. 
w sprawie prawa dostępu do adwokata w postępowaniu karnym i w postępowaniu dotyczącym 
europejskiego nakazu aresztowania oraz w sprawie prawa do poinformowania osoby trzeciej 
o pozbawieniu wolności i prawa do porozumiewania się z osobami trzecimi i organami 
konsularnymi w czasie pozbawienia wolności (Dz. Urz. UE L 294 z 06.11.2013, str. 1); 

2) dyrektywy Parlamentu Europejskiego i Rady (UE) 2016/343 z dnia 9 marca 2016 r. w sprawie 
wzmocnienia niektórych aspektów domniemania niewinności i prawa do obecności na rozprawie 
w postępowaniu karnym (Dz. Urz. UE L 65 z 11.03.2016, str. 1); 

3) dyrektywy Parlamentu Europejskiego i Rady (UE) 2016/1919 z dnia 26 października 2016 r. 
w sprawie pomocy prawnej z urzędu dla podejrzanych i oskarżonych w postępowaniu karnym 
oraz dla osób, których dotyczy wniosek w postępowaniu dotyczącym europejskiego nakazu 
aresztowania (Dz. Urz. UE L 297 z 04.11.2016, str. 1 oraz Dz. Urz. UE L 91 z 05.04.2017, 
str. 40); 

4) dyrektywy Parlamentu Europejskiego i Rady (UE) 2016/800 z dnia 11 maja 2016 r. w sprawie 
gwarancji procesowych dla dzieci będących podejrzanymi lub oskarżonymi w postępowaniu 
karnym (Dz. Urz. UE L 132 z 21.05.2016, str. 1). 

2) Niniejsza ustawa w zakresie swojej regulacji służy stosowaniu rozporządzenia Rady (UE) 
2017/1939 z dnia 12 października 2017 r. wdrażającego wzmocnioną współpracę w zakresie 
ustanowienia Prokuratury Europejskiej (Dz. Urz. UE L 283 z 31.10.2017, str. 1 oraz Dz. Urz. 
UE L 431 z 21.12.2020, str. 1). 

2025-09-11 

 
 
 
 
 
 
 

©Kancelaria Sejmu 

s. 2/356 

również w zapobieganiu im oraz w umacnianiu poszanowania prawa i zasad 

współżycia społecznego; 

3) 

zostały uwzględnione prawnie chronione interesy pokrzywdzonego przy 

jednoczesnym poszanowaniu jego godności; 

4) 

rozstrzygnięcie sprawy nastąpiło w rozsądnym terminie. 

§ 2. Podstawę wszelkich rozstrzygnięć powinny stanowić prawdziwe ustalenia 

faktyczne.


## Art. 3. {#kpk-art-3}
W granicach określonych w ustawie postępowanie karne odbywa się 

z udziałem czynnika społecznego.


## Art. 4. {#kpk-art-4}
Organy prowadzące postępowanie karne są obowiązane badać oraz 

uwzględniać okoliczności przemawiające zarówno na korzyść, jak i na niekorzyść 

oskarżonego.


## Art. 5. {#kpk-art-5}
§ 1. Oskarżonego uważa się za niewinnego, dopóki wina jego nie zostanie 

udowodniona i stwierdzona prawomocnym wyrokiem. 

§ 2. Niedające się usunąć wątpliwości rozstrzyga się na korzyść oskarżonego.


## Art. 6. {#kpk-art-6}
Oskarżonemu przysługuje prawo do obrony, w tym prawo do korzystania 

z pomocy obrońcy, o czym należy go pouczyć.


## Art. 7. {#kpk-art-7}
Organy postępowania kształtują swe przekonanie na podstawie 

wszystkich przeprowadzonych dowodów, ocenianych swobodnie z uwzględnieniem 

zasad prawidłowego rozumowania oraz wskazań wiedzy i doświadczenia życiowego.


## Art. 8. {#kpk-art-8}
§ 1. Sąd karny rozstrzyga samodzielnie zagadnienia faktyczne i prawne 

oraz nie jest związany rozstrzygnięciem innego sądu lub organu. 

§ 2. Prawomocne rozstrzygnięcia sądu kształtujące prawo lub stosunek prawny 

są jednak wiążące.


## Art. 9. {#kpk-art-9}
§ 1. Organy procesowe prowadzą postępowanie i dokonują czynności 

z urzędu, chyba że ustawa uzależnia je od wniosku określonej osoby, instytucji lub 

organu albo od zezwolenia władzy. 

§ 2. Strony i inne osoby bezpośrednio zainteresowane mogą składać wnioski 

o dokonanie również tych czynności, które organ może lub ma obowiązek 

podejmować z urzędu. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 3/356


## Art. 10. {#kpk-art-10}
§ 1. Organ powołany do ścigania przestępstw jest obowiązany do 

wszczęcia 

i przeprowadzenia postępowania przygotowawczego, a oskarżyciel 

publiczny także do wniesienia i popierania oskarżenia – o czyn ścigany z urzędu. 

§ 2. Z wyjątkiem wypadków 

określonych w ustawie 

lub w prawie 

międzynarodowym nikt nie może być zwolniony od odpowiedzialności za popełnione 

przestępstwo.


## Art. 11. {#kpk-art-11}
§ 1. Postępowanie w sprawie o występek, zagrożony karą pozbawienia 

wolności do lat 5, można umorzyć, jeżeli orzeczenie wobec oskarżonego kary byłoby 

oczywiście niecelowe ze względu na rodzaj i wysokość kary prawomocnie orzeczonej 

za inne przestępstwo, a interes pokrzywdzonego temu się nie sprzeciwia. 

§ 2. Jeżeli kara za inne przestępstwo nie została prawomocnie orzeczona, 

postępowanie można zawiesić. Zawieszone postępowanie należy umorzyć albo podjąć 

przed upływem 3 miesięcy od uprawomocnienia się orzeczenia w sprawie o inne 

przestępstwo, o którym mowa w § 1. 

§ 3. Postępowanie umorzone na podstawie § 1 można wznowić w wypadku 

uchylenia lub istotnej zmiany treści prawomocnego wyroku, z powodu którego zostało 

ono umorzone.


## Art. 12. {#kpk-art-12}
§ 1. W sprawach o przestępstwa ścigane na wniosek postępowanie 

z chwilą złożenia wniosku toczy się z urzędu. Organ ścigania poucza osobę 

uprawnioną do złożenia wniosku o przysługującym jej uprawnieniu. 

§ 1a. Uzyskanie wniosku o ściganie należy do oskarżyciela. Jeżeli powodem 

uzyskania wniosku jest wyłącznie uprzedzenie przez sąd stron o możliwości 

zakwalifikowania czynu według innego przepisu prawnego, przewidującego ściganie 

na wniosek, uzyskanie wniosku o ściganie należy do sądu. 

§ 2. W razie złożenia wniosku o ściganie niektórych tylko sprawców obowiązek 

ścigania obejmuje również inne osoby, których czyny pozostają w ścisłym związku 

z czynem osoby wskazanej we wniosku, o czym należy uprzedzić składającego 

wniosek. Przepisu tego nie stosuje się do najbliższych osoby składającej wniosek. 

§ 3. Wniosek może być cofnięty w postępowaniu przygotowawczym za zgodą 

prokuratora, a w postępowaniu sądowym za zgodą sądu – aż do zamknięcia przewodu 

sądowego na pierwszej rozprawie głównej. W sprawach, w których akt oskarżenia 

wniósł oskarżyciel publiczny, cofnięcie wniosku po rozpoczęciu przewodu sądowego 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 4/356 

jest skuteczne, jeżeli nie sprzeciwi się temu oskarżyciel publiczny obecny na 

rozprawie lub posiedzeniu. Ponowne złożenie wniosku jest niedopuszczalne. 

§ 4. W sprawie o przestępstwo z art. 190 § 1 Kodeksu karnego można wszcząć 

i prowadzić postępowanie pomimo niezłożenia wniosku o ściganie, jeżeli zachodzi 

duże prawdopodobieństwo, że niezłożenie wniosku wynika z obawy pokrzywdzonego 

przed odwetem albo jeżeli przemawia za tym interes społeczny. W takim przypadku 

postępowanie do czasu prawomocnego zakończenia toczy się z urzędu.


## Art. 13. {#kpk-art-13}
Uzyskanie zezwolenia władzy, od którego ustawa uzależnia ściganie, 

należy do oskarżyciela.


## Art. 14. {#kpk-art-14}
§ 1. Wszczęcie postępowania sądowego następuje na żądanie 

uprawnionego oskarżyciela lub innego uprawnionego podmiotu. 

§ 2. Oskarżyciel publiczny może cofnąć akt oskarżenia do czasu rozpoczęcia 

przewodu sądowego na pierwszej rozprawie głównej. W toku przewodu sądowego 

przed sądem pierwszej instancji cofnięcie aktu oskarżenia dopuszczalne jest jedynie 

za zgodą oskarżonego. Ponowne wniesienie aktu oskarżenia przeciwko tej samej 

osobie o ten sam czyn jest niedopuszczalne.


## Art. 15. {#kpk-art-15}
§ 1. Policja i inne organy w zakresie postępowania karnego wykonują 

polecenia sądu, referendarza sądowego i prokuratora oraz prowadzą pod nadzorem 

prokuratora śledztwo lub dochodzenie w granicach określonych w ustawie. 

§ 2. Wszystkie instytucje państwowe i samorządowe są obowiązane w zakresie 

swego działania do udzielania pomocy organom prowadzącym postępowanie karne 

w terminie wyznaczonym przez te organy. 

§ 3. Osoby prawne lub jednostki organizacyjne niemające osobowości prawnej 

inne niż określone w § 2, a także osoby fizyczne są obowiązane do udzielenia pomocy 

na wezwanie organów prowadzących postępowanie karne w zakresie i w terminie 

przez nie wyznaczonym, jeżeli bez tej pomocy przeprowadzenie czynności 

procesowej jest niemożliwe albo znacznie utrudnione.


## Art. 16. {#kpk-art-16}
§ 1. Jeżeli organ prowadzący postępowanie jest obowiązany pouczyć 

uczestników postępowania o ciążących obowiązkach 

i o przysługujących 

im 

uprawnieniach, brak takiego pouczenia lub mylne pouczenie nie może wywoływać 

ujemnych skutków procesowych dla uczestnika postępowania lub innej osoby, której 

to dotyczy. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 5/356 

§ 2. Organ prowadzący postępowanie powinien ponadto w miarę potrzeby 

udzielać uczestnikom 

postępowania 

informacji o ciążących obowiązkach 

i o przysługujących im uprawnieniach także w wypadkach, gdy ustawa wyraźnie 

takiego obowiązku nie stanowi. W razie braku takiego pouczenia, gdy w świetle 

okoliczności sprawy było ono nieodzowne, albo mylnego pouczenia, stosuje się 

odpowiednio § 1. 

§ 3. Jeżeli uczestnikiem postępowania jest osoba, która nie ukończyła 18 lat, lub 

osoba nieporadna, w szczególności ze względu na wiek lub stan zdrowia, sposób 

pouczenia powinien być dostosowany do jej wieku, stanu zdrowia i stanu rozwoju 

umysłowego.


## Art. 17. {#kpk-art-17}
§ 1.3) Nie wszczyna się postępowania, a wszczęte umarza, gdy: 

1) 

czynu nie popełniono albo brak jest danych dostatecznie uzasadniających 

podejrzenie jego popełnienia; 

2) 

czyn nie zawiera znamion czynu zabronionego albo ustawa stanowi, że sprawca 

nie popełnia przestępstwa; 

społeczna szkodliwość czynu jest znikoma; 

ustawa stanowi, że sprawca nie podlega karze; 

oskarżony zmarł; 

nastąpiło przedawnienie karalności; 

postępowanie karne co do tego samego czynu tej samej osoby zostało 

prawomocnie zakończone albo wcześniej wszczęte toczy się; 

sprawca nie podlega orzecznictwu polskich sądów karnych; 

brak skargi uprawnionego oskarżyciela; 

3) 

4) 

5) 

6) 

7) 

8) 

9) 

10) brak wymaganego zezwolenia na ściganie lub wniosku o ściganie pochodzącego 

od osoby uprawnionej, chyba że ustawa stanowi inaczej; 

11) zachodzi inna okoliczność wyłączająca ściganie. 

§ 2. Do chwili otrzymania wniosku lub zezwolenia władzy, od których ustawa 

uzależnia ściganie, organy procesowe dokonują tylko czynności niecierpiących zwłoki 

w celu zabezpieczenia śladów i dowodów, a także czynności zmierzających do 

wyjaśnienia, czy wniosek będzie złożony lub zezwolenie będzie wydane. 

3) Uznany za niezgodny z Konstytucją z dniem 19 lipca 2018 r. w zakresie, w jakim nie czyni aktu abolicji 
indywidualnej negatywną przesłanką prowadzenia postępowania karnego, na podstawie wyroku 
Trybunału Konstytucyjnego z dnia 17 lipca 2018 r. sygn. akt K 9/17 (Dz. U. poz. 1387). 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 6/356 

§ 3. Niemożność przypisania winy sprawcy czynu nie wyłącza postępowania 

dotyczącego zastosowania środków zabezpieczających. 

§ 4. Istnienie okoliczności określonych w § 1 pkt 4–6 nie wyłącza postępowania 

w przedmiocie przepadku, o którym mowa w art. 45a § 2 Kodeksu karnego i art. 43a 

Kodeksu karnego skarbowego.


## Art. 18. {#kpk-art-18}
§ 1. Jeżeli czyn stanowi tylko wykroczenie, prokurator odmawiając 

wszczęcia postępowania lub umarzając je przekazuje sprawę Policji w celu 

wystąpienia z wnioskiem o ukaranie do właściwego sądu; prokurator może sam 

wystąpić z takim wnioskiem. 

§ 2. Jeżeli 

sąd 

lub prokurator dopatruje 

się w czynie przewinienia 

dyscyplinarnego albo naruszenia obowiązków służbowych lub zasad współżycia 

społecznego, może odmawiając wszczęcia postępowania albo umarzając je, zwłaszcza 

z powodu znikomej szkodliwości społecznej czynu, przekazać sprawę innemu 

właściwemu organowi.


## Art. 19. {#kpk-art-19}
§ 1. W razie stwierdzenia w postępowaniu karnym poważnego 

uchybienia w działaniu 

instytucji państwowej, samorządowej 

lub społecznej, 

zwłaszcza gdy sprzyja ono popełnieniu przestępstwa, sąd, a w postępowaniu 

przygotowawczym prokurator, zawiadamia o tym uchybieniu organ powołany do 

nadzoru nad daną jednostką organizacyjną, zaś w razie potrzeby także organ kontroli. 

Policja powiadamia prokuratora o ujawnionych przez siebie uchybieniach. 

§ 2. Zawiadamiając o uchybieniu, sąd lub prokurator może zażądać nadesłania 

w wyznaczonym 

terminie wyjaśnień 

i podania 

środków podjętych w celu 

zapobieżenia takim uchybieniom w przyszłości. 

§ 3. W razie nieudzielenia wyjaśnień w wyznaczonym terminie można nałożyć 

na kierownika organu zobowiązanego do wyjaśnień karę pieniężną w wysokości do 

10 000 złotych. 

§ 4. Na postanowienie o nałożeniu kary pieniężnej przysługuje zażalenie. 

Zażalenie na postanowienie prokuratora rozpoznaje sąd rejonowy, w którego okręgu 

toczy się postępowanie.


## Art. 20. {#kpk-art-20}
§ 1. W razie rażącego naruszenia przez obrońcę lub pełnomocnika 

strony ich obowiązków procesowych sąd, a w postępowaniu przygotowawczym 

prokurator, zawiadamia o tym właściwą okręgową radę adwokacką lub radę 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 7/356 

okręgowej izby radców prawnych, żądając od dziekana właściwej rady nadesłania 

w wyznaczonym, nie krótszym niż 30 dni, terminie informacji o podjętych działaniach 

wynikających z zawiadomienia. Odpis zawiadomienia przesyła się Ministrowi 

Sprawiedliwości. 

§ 1a. W razie nienadesłania w wyznaczonym terminie informacji, o których 

mowa w § 1, można nałożyć na dziekana właściwej rady karę pieniężną w wysokości 

do 10 000 złotych. 

§ 1b. Na postanowienie o ukaraniu przysługuje zażalenie. Na postanowienie 

o ukaraniu wydane przez prokuratora w postępowaniu przygotowawczym zażalenie 

przysługuje do sądu rejonowego, w którego okręgu toczy się postępowanie. 

§ 2. W razie rażącego naruszenia obowiązków procesowych przez oskarżyciela 

publicznego lub prowadzącego postępowanie przygotowawcze sąd zawiadamia o tym 

bezpośredniego przełożonego osoby, która dopuściła się uchybienia, żądając 

nadesłania w wyznaczonym, nie krótszym niż 14 dni, terminie informacji o podjętych 

działaniach wynikających z zawiadomienia; w stosunku do Policji oraz innych 

organów postępowania przygotowawczego uprawnienie takie przysługuje również 

prokuratorowi. 

§ 2a. Odpis zawiadomienia, o którym mowa w § 2, sąd przesyła Prokuratorowi 

Generalnemu, jeżeli uchybienia dopuścił się prokurator, a w wypadku gdy uchybienia 

dopuścił się oskarżyciel publiczny niebędący prokuratorem – właściwemu organowi 

przełożonemu w stosunku do bezpośredniego przełożonego tego oskarżyciela.


## Art. 21. {#kpk-art-21}
§ 1. O wszczęciu i ukończeniu postępowania toczącego się z urzędu 

przeciw: 

1) 

funkcjonariuszom 

publicznym, 

osobom 

zatrudnionym w instytucjach 

państwowych, samorządowych i społecznych, uczniom i słuchaczom szkół, 

żołnierzom, a także duchownym i członkom zakonów oraz diakonatów – należy 

bezzwłocznie zawiadomić przełożonych tych osób; 

2) 

osobom będącym członkami samorządu zawodowego – należy bezzwłocznie 

zawiadomić właściwy organ tego samorządu; 

3) 

komornikom sądowym, asesorom komorniczym i aplikantom komorniczym – 

należy bezzwłocznie zawiadomić Ministra Sprawiedliwości, prezesa sądu 

apelacyjnego oraz prezesa sądu rejonowego właściwych ze względu na siedzibę 

kancelarii komorniczej; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 8/356 

4) 

rodzicowi albo opiekunowi prawnemu lub faktycznemu o przestępstwo 

popełnione na szkodę małoletniego – należy bezzwłocznie zawiadomić sąd 

rodzinny właściwy dla miejsca zamieszkania małoletniego. 

§ 2. O wszczęciu postępowania przeciw osobom, o których mowa w § 1, 

zawiadamia prokurator.


## Art. 22. {#kpk-art-22}
§ 1. Jeżeli zachodzi długotrwała przeszkoda uniemożliwiająca 

prowadzenie postępowania, a w szczególności jeżeli nie można ująć oskarżonego albo 

nie może on brać udziału w postępowaniu z powodu choroby psychicznej lub innej 

ciężkiej choroby, postępowanie zawiesza się na czas trwania przeszkody. 

§ 2. Na postanowienie w przedmiocie zawieszenia postępowania przysługuje 

zażalenie. 

§ 3. W czasie zawieszenia postępowania należy jednak dokonać odpowiednich 

czynności w celu zabezpieczenia dowodów przed ich utratą lub zniekształceniem. 

§ 4. W razie istnienia podstaw określonych w art. 45a § 2 Kodeksu karnego lub 

art. 43a Kodeksu karnego skarbowego po uprawomocnieniu się postanowienia o 

zawieszeniu postępowania sąd orzeka w przedmiocie przepadku z urzędu, 

a w postępowaniu przygotowawczym – na wniosek prokuratora. Jeżeli oskarżony nie 

ma obrońcy, do udziału w postępowaniu dotyczącym przepadku wyznacza się obrońcę 

z urzędu. 

§ 5. Na postanowienie w przedmiocie przepadku przysługuje zażalenie.


## Art. 23. {#kpk-art-23}
W sprawie o przestępstwo popełnione na szkodę małoletniego, we 

współdziałaniu z małoletnim 

lub w okolicznościach, które mogą świadczyć 

o demoralizacji małoletniego albo o gorszącym wpływie na niego, sąd, a w 

postępowaniu przygotowawczym prokurator, zawiadamia sąd rodzinny w celu 

rozważenia środków przewidzianych w przepisach o postępowaniu w sprawach 

nieletnich oraz w Kodeksie rodzinnym i opiekuńczym.


## Art. 23a. {#kpk-art-23a}
§ 1. Sąd 

lub 

referendarz 

sądowy, 

a w postępowaniu 

przygotowawczym prokurator lub inny organ prowadzący to postępowanie, może 

z inicjatywy lub za zgodą oskarżonego i pokrzywdzonego skierować sprawę do 

instytucji lub osoby do tego uprawnionej w celu przeprowadzenia postępowania 

mediacyjnego między pokrzywdzonym i oskarżonym, o czym się ich poucza, 

informując o celach i zasadach postępowania mediacyjnego, w tym o treści art. 178a. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 9/356 

§ 2. Postępowanie mediacyjne nie powinno trwać dłużej niż miesiąc, a jego 

okresu nie wlicza się do czasu trwania postępowania przygotowawczego. 

§ 3. Postępowania mediacyjnego nie może prowadzić osoba, co do której 

w sprawie zachodzą okoliczności określone w art. 40 i art. 41 § 1, czynny zawodowo 

sędzia, prokurator, asesor prokuratorski, a także aplikant wymienionych zawodów, 

ławnik, 

referendarz sądowy, asystent sędziego, asystent prokuratora oraz 

funkcjonariusz instytucji uprawnionej do ścigania przestępstw. Przepis art. 42 stosuje 

się odpowiednio. 

§ 4. Udział oskarżonego i pokrzywdzonego w postępowaniu mediacyjnym jest 

dobrowolny. Zgodę na uczestniczenie w postępowaniu mediacyjnym odbiera organ 

kierujący sprawę do mediacji 

lub mediator, po wyjaśnieniu oskarżonemu 

i pokrzywdzonemu celów i zasad postępowania mediacyjnego i pouczeniu ich 

o możliwości cofnięcia tej zgody aż do zakończenia postępowania mediacyjnego. 

§ 5. Mediatorowi udostępnia się akta sprawy w zakresie niezbędnym do 

przeprowadzenia postępowania mediacyjnego. 

§ 6. Instytucja lub osoba do tego uprawniona sporządza, po przeprowadzeniu 

postępowania mediacyjnego, sprawozdanie z jego wyników. Do sprawozdania załącza 

się ugodę podpisaną przez oskarżonego, pokrzywdzonego i mediatora, jeżeli została 

zawarta. 

§ 7. Postępowanie mediacyjne prowadzi się w sposób bezstronny i poufny. 

§ 8. Minister Sprawiedliwości określi, w drodze rozporządzenia, szczegółowy 

tryb przeprowadzania postępowania mediacyjnego, warunki, 

jakim powinny 

odpowiadać instytucje i osoby uprawnione do jego przeprowadzenia, sposób ich 

powoływania i odwoływania, zakres i warunki udostępniania im akt sprawy oraz 

formę i zakres sprawozdania z wyników postępowania mediacyjnego, mając na 

uwadze potrzebę skutecznego przeprowadzenia tego postępowania.


## Art. 23b. {#kpk-art-23b}
(uchylony) 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 10/356
