---
id: "code_kpk_dzial-iii"
title: "KPK — DZIAŁ III"
source_pdf: "D19970555Lj (1).pdf"
dz_u: "Dz. U. 1997 Nr 89 poz. 555"
status: "obowiązujący"
last_consolidated: "2025-09-11"
law: "Kodeks postępowania karnego"
tags: ["kpk", "kodeks", "postępowanie karne"]
articles_range: {"first": "45", "last": "91b"}
---

# DZIAŁ III

## Art. 45. {#kpk-art-45}
§ 1. Oskarżycielem publicznym przed wszystkimi sądami 

jest 

prokurator. 

§ 1a. W wypadkach określonych w ustawie czynności procesowe wykonuje 

prokurator bezpośrednio przełożony lub prokurator nadrzędny. 

§ 1b. (uchylony) 

§ 1c. (uchylony) 

§ 2. Inny organ państwowy może być oskarżycielem publicznym z mocy 

szczególnych przepisów ustawy, określających zakres jego działania.


## Art. 46. {#kpk-art-46}
§ 1. W sprawach o przestępstwa ścigane z oskarżenia publicznego 

udział oskarżyciela publicznego w rozprawie jest obowiązkowy, jeżeli ustawa nie 

stanowi inaczej. 

§ 2. Jeżeli postępowanie przygotowawcze zakończyło się w formie dochodzenia, 

niestawiennictwo oskarżyciela publicznego na rozprawie nie tamuje jej toku. 

Przewodniczący lub sąd mogą uznać obecność oskarżyciela publicznego za 

obowiązkową.


## Art. 47. {#kpk-art-47}
§ 1. Przepisy art. 40 § 1 pkt 1–4, 6 i 10, § 2 oraz art. 41, art. 41a 

i art. 42 stosuje się odpowiednio do prokuratora, innych osób prowadzących 

postępowanie przygotowawcze oraz innych oskarżycieli publicznych. 

§ 2. Osoby wymienione w § 1 ulegają również wyłączeniu, jeżeli brały udział 

w sprawie jako obrońca, pełnomocnik, przedstawiciel społeczny albo przedstawiciel 

ustawowy strony.


## Art. 48. {#kpk-art-48}
§ 1. O wyłączeniu prowadzącego lub nadzorującego postępowanie 

przygotowawcze oraz oskarżyciela publicznego orzeka prokurator nadzorujący 

postępowanie lub bezpośrednio przełożony. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 17/356 

§ 2. Czynności dokonane przez osobę podlegającą wyłączeniu, zanim ono 

nastąpiło, nie są z tej przyczyny bezskuteczne; jednakże czynność dowodową należy 

na żądanie strony, w miarę możności, powtórzyć. 


# Rozdział 4
 

Pokrzywdzony


## Art. 49. {#kpk-art-49}
§ 1. Pokrzywdzonym jest osoba fizyczna lub prawna, której dobro 

prawne zostało bezpośrednio naruszone lub zagrożone przez przestępstwo. 

§ 2. Pokrzywdzonym może być także niemająca osobowości prawnej: 

1) 

2) 

instytucja państwowa lub samorządowa; 

inna jednostka organizacyjna, której odrębne przepisy przyznają zdolność 

prawną. 

§ 3. Za pokrzywdzonego uważa się zakład ubezpieczeń w zakresie, w jakim 

pokrył szkodę wyrządzoną pokrzywdzonemu przez przestępstwo lub jest zobowiązany 

do jej pokrycia. 

§ 3a. W sprawach o przestępstwa przeciwko prawom osób wykonujących pracę 

zarobkową, o których mowa w art. 218–221 oraz w art. 225 § 2 Kodeksu karnego, 

organy Państwowej Inspekcji Pracy mogą wykonywać prawa pokrzywdzonego, jeżeli 

w zakresie swego działania ujawniły przestępstwo lub wystąpiły o wszczęcie 

postępowania. 

§ 4. W sprawach o przestępstwa, którymi wyrządzono szkodę w mieniu 

instytucji lub jednostki organizacyjnej, o której mowa w § 2, jeżeli nie działa organ 

pokrzywdzonej instytucji lub jednostki organizacyjnej, prawa pokrzywdzonego mogą 

wykonywać organy kontroli państwowej, które w zakresie swojego działania ujawniły 

przestępstwo lub wystąpiły o wszczęcie postępowania.


## Art. 49a. {#kpk-art-49a}
§ 1. Pokrzywdzony, a także prokurator, może aż do zamknięcia 

przewodu sądowego na rozprawie głównej złożyć wniosek, o którym mowa w art. 46 

§ 1 Kodeksu karnego. 

§ 2. Pokrzywdzony może aż do zamknięcia przewodu sądowego na rozprawie 

głównej złożyć wniosek, o którym mowa w art. 41a § 1a Kodeksu karnego.


## Art. 49b. {#kpk-art-49b}
Jeżeli wątpliwości co do wieku pokrzywdzonego nie da się usunąć, a 

zachodzi uzasadnione przypuszczenie, że jest on małoletni, stosuje się do niego 

przepisy niniejszego kodeksu dotyczące małoletnich pokrzywdzonych. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 18/356


## Art. 50. {#kpk-art-50}
W postępowaniu sądowym z uprawnień pokrzywdzonego określonych 

w art. 53 nie może korzystać osoba występująca w tej samej sprawie w charakterze 

oskarżonego, z wyjątkiem przewidzianym w art. 497 i art. 498 § 3.


## Art. 51. {#kpk-art-51}
§ 1. Za pokrzywdzonego, który nie jest osobą fizyczną, czynności 

procesowych dokonuje organ uprawniony do działania w jego imieniu. 

§ 2. Jeżeli pokrzywdzonym jest małoletni albo ubezwłasnowolniony całkowicie 

lub częściowo, prawa jego wykonuje przedstawiciel ustawowy albo osoba, pod której 

stałą pieczą pokrzywdzony pozostaje. 

§ 2a. Sąd, a w postępowaniu przygotowawczym prokurator niezwłocznie, nie 

później niż w terminie 7 dni od dnia zaistnienia okoliczności, o których mowa w art. 

98 § 2 Kodeksu rodzinnego i opiekuńczego, występuje do sądu opiekuńczego z 

wnioskiem o wyznaczenie reprezentanta dziecka, o którym mowa w art. 99 § 1 

Kodeksu rodzinnego i opiekuńczego. 

§ 3. Jeżeli pokrzywdzonym jest osoba nieporadna, w szczególności ze względu 

na wiek lub stan zdrowia, jego prawa może wykonywać osoba, pod której pieczą 

pokrzywdzony pozostaje.


## Art. 52. {#kpk-art-52}
§ 1. W razie śmierci pokrzywdzonego prawa, które by mu 

przysługiwały, mogą wykonywać osoby najbliższe lub osoby pozostające na jego 

utrzymaniu, a w wypadku ich braku lub nieujawnienia – prokurator, działając 

z urzędu. 

§ 2. W przypadku gdy organ prowadzący postępowanie dysponuje informacjami 

o osobach najbliższych dla pokrzywdzonego lub osobach pozostających na jego 

utrzymaniu, poucza o przysługujących uprawnieniach co najmniej jedną z nich.


## Art. 52a. {#kpk-art-52a}
§ 1. Mając 

na względzie 

potrzebę 

zastosowania wobec 

pokrzywdzonego art. 147 § 1, w odniesieniu do czynności, o której mowa 

w art. 143 § 1 pkt 2, lub potrzebę zastosowania wobec pokrzywdzonego art. 177 § 1a, 

art. 184–185c, art. 185e, art. 299a § 1, art. 360 § 1 pkt 1 lit. d oraz pkt 3, art. 390 § 2 

i 3 oraz art. 10 ust. 2 ustawy z dnia 28 listopada 2014 r. o ochronie i pomocy dla 

pokrzywdzonego i świadka (Dz. U. z 2015 r. poz. 21 oraz z 2024 r. poz. 1228), organ 

prowadzący postępowanie karne ustala właściwości 

i warunki osobiste 

pokrzywdzonego oraz rodzaj i rozmiar ujemnych następstw popełnionego na jego 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 19/356 

szkodę przestępstwa, mając na uwadze charakter tego przestępstwa oraz okoliczności 

jego popełnienia. 

§ 2. Przed 

rozpoczęciem czynności, o której mowa w art. 143 § 1 pkt 2 

z zastosowaniem art. 147 § 1, lub czynności wskazanych w art. 177 § 1a, art. 184–

185c, art. 185e, art. 299a § 1, art. 360 § 1 pkt 1 lit. d oraz pkt 3, art. 390 § 2 i 3 oraz 

art. 10 ust. 2 ustawy z dnia 28 listopada 2014 r. o ochronie 

i pomocy dla 

pokrzywdzonego i świadka, organ prowadzący postępowanie karne odbiera od 

pokrzywdzonego oświadczenie, czy chce zastosowania przewidzianych w nich 

środków, chyba że odebranie oświadczenia 

jest niemożliwe, zastosowanie 

określonego środka jest obowiązkowe lub organ prowadzący postępowanie działa na 

wniosek pokrzywdzonego. Oświadczenie składa się na piśmie albo do protokołu 

organu prowadzącego postępowanie karne. Organ prowadzący postępowanie karne 

bierze pod uwagę oświadczenie pokrzywdzonego przy podejmowaniu decyzji 

dotyczących czynności wskazanych w przepisach wymienionych w zdaniu 

pierwszym. 

§ 3. Ustaleń, o których mowa w § 1, dokonuje organ prowadzący postępowanie 

karne przy użyciu kwestionariusza indywidualnej oceny pokrzywdzonego najpóźniej 

przed rozpoczęciem czynności, o której mowa w art. 143 § 1 pkt 2 z zastosowaniem 

art. 147 § 1, lub czynności wskazanych w art. 177 § 1a, art. 184–185c, art. 185e, 

art. 299a § 1, art. 360 § 1 pkt 1 lit. d oraz pkt 3, art. 390 § 2 i 3 oraz art. 10 ust. 2 

ustawy z dnia 28 listopada 2014 r. o ochronie i pomocy dla pokrzywdzonego 

i świadka. Organ prowadzący postępowanie karne może odstąpić od użycia kwestio-

nariusza indywidualnej oceny pokrzywdzonego, gdy zachodzi niebezpieczeństwo 

utraty lub zniekształcenia dowodu w razie zwłoki lub gdy utrudni to postępowanie. 

W takim wypadku 

informacje dotyczące ustaleń, o których mowa w § 1, 

i oświadczenia, o którym mowa w § 2, należy zamieścić w protokole czynności. 

§ 4. Kwestionariusz indywidualnej oceny pokrzywdzonego nie stanowi dowodu 

okoliczności, o których mowa w § 1. 

§ 5. Przepisy § 1–4 stosuje się odpowiednio do świadka, jeżeli występują u niego 

zaburzenia psychiczne, 

rozwojowe, zakłócenia zdolności postrzegania 

lub 

odtwarzania przez niego postrzeżeń uzasadniające przekonanie, że przesłuchanie 

powinno się odbyć w trybie określonym w art. 185e, w zakresie niezbędnym do 

dokonania ustaleń co do przeprowadzenia przesłuchania zgodnie z tym przepisem. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 20/356 

§ 6. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, wzór 

kwestionariusza indywidualnej oceny, odrębnie dla pokrzywdzonego i świadka 

wskazanego w § 5, oraz sposób i miejsce przechowywania tego kwestionariusza, 

mając na uwadze konieczność zebrania w sposób wyczerpujący danych 

o pokrzywdzonym lub świadku, niezbędnych do ustalenia, czy zachodzą podstawy do 

przeprowadzenia czynności przewidzianych w przepisach wymienionych w § 1 oraz 

konieczność zachowania ustawowych wymogów ochrony danych pokrzywdzonego 

lub świadka. 


# Rozdział 5
 

Oskarżyciel posiłkowy


## Art. 53. {#kpk-art-53}
W sprawach o przestępstwa 

ścigane 

z oskarżenia publicznego 

pokrzywdzony może działać jako strona w charakterze oskarżyciela posiłkowego obok 

oskarżyciela publicznego lub zamiast niego.


## Art. 54. {#kpk-art-54}
§ 1. Jeżeli akt oskarżenia wniósł oskarżyciel publiczny, pokrzywdzony 

może aż do czasu rozpoczęcia przewodu sądowego na rozprawie głównej złożyć 

oświadczenie, że będzie działał w charakterze oskarżyciela posiłkowego. 

§ 2. Cofnięcie aktu oskarżenia przez oskarżyciela publicznego nie pozbawia 

uprawnień oskarżyciela posiłkowego. Pokrzywdzony, który uprzednio nie korzystał 

z uprawnień oskarżyciela posiłkowego, może w terminie 14 dni od powiadomienia go 

o cofnięciu przez oskarżyciela publicznego aktu oskarżenia oświadczyć, że 

przystępuje do postępowania jako oskarżyciel posiłkowy.


## Art. 55. {#kpk-art-55}
§ 1. [Pokrzywdzony, o którym mowa w art. 330 § 2 zdanie trzecie, 

w terminie miesiąca od doręczenia mu zawiadomienia o postanowieniu prokuratora 

nadrzędnego o utrzymaniu w mocy zaskarżonego postanowienia, może wnieść akt 

oskarżenia do sądu, dołączając po jednym odpisie dla każdego oskarżonego oraz dla 

prokuratora.] <Pokrzywdzony, o którym mowa w art. 330 § 2 zdanie trzecie, 

w terminie miesiąca od doręczenia mu zawiadomienia o postanowieniu 

prokuratora nadrzędnego o utrzymaniu w mocy zaskarżonego postanowienia, 

może wnieść akt oskarżenia do sądu, dołączając po jednej kopii dla każdego 

oskarżonego oraz dla prokuratora. Przepis art. 488 § 2 stosuje się odpowiednio. 

Przepisów art. 339 § 3 pkt 3a i art. 396a nie stosuje się. 

2025-09-11 

Zmiana w zd. 
pierwszym w § 1 
w art. 55 wejdzie 
w życie z dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 
 
 
 
 

©Kancelaria Sejmu 

s. 21/356 

§ 2. Akt oskarżenia wniesiony przez pokrzywdzonego powinien być 

sporządzony i podpisany przez adwokata, radcę prawnego albo radcę Prokuratorii 

Generalnej Rzeczypospolitej Polskiej, z zachowaniem warunków określonych w § 2b, 

art. 332 i art. 333 § 1. 

§ 2a. O wniesieniu aktu oskarżenia zawiadamia się innych pokrzywdzonych 

znanych sądowi. 

§ 2b. Do aktu oskarżenia załącza się zawiadomienie, o którym mowa w § 1, wraz 

z odpisem postanowienia prokuratora nadrzędnego wydanego na podstawie 

art. 330 § 2. 

§ 3. Inny pokrzywdzony tym samym czynem może aż do rozpoczęcia przewodu 

sądowego na rozprawie głównej przyłączyć się do postępowania. 

§ 4. Do sprawy wszczętej na podstawie aktu oskarżenia wniesionego przez 

oskarżyciela posiłkowego może w każdym czasie wstąpić prokurator, stając się 

oskarżycielem publicznym. Postępowanie toczy się wówczas z oskarżenia publicz-

nego, a pokrzywdzony, który wniósł akt oskarżenia, korzysta z praw oskarżyciela 

posiłkowego, o którym mowa w art. 54. Cofnięcie aktu oskarżenia przez oskarżyciela 

publicznego jest dopuszczalne jedynie za zgodą pokrzywdzonego, który wniósł akt 

oskarżenia, a w razie przyłączenia się do postępowania pokrzywdzonego, o którym 

mowa w § 3 – również tego pokrzywdzonego. 

§ 5. Prokurator, który nie wstąpił do sprawy jako oskarżyciel publiczny, może do 

niej wstąpić jako uczestnik postępowania, jeżeli uzna, że wymaga tego ochrona 

praworządności lub interes społeczny; w takim wypadku prokuratorowi przysługują 

prawa strony, przy czym stosuje się do niego odpowiednio przepisy art. 48, 

art. 425 § 3 zdanie drugie, art. 425 § 4, art. 427 § 2 i art. 431 § 2. Ilekroć przepisy 

określają porządek zadawania pytań, zabierania głosu lub wykonywania innych praw, 

prokurator korzysta z tych praw bezpośrednio po oskarżycielu.


## Art. 56. {#kpk-art-56}
§ 1. Sąd może ograniczyć 

liczbę oskarżycieli posiłkowych 

występujących w sprawie, jeżeli jest to konieczne dla zabezpieczenia prawidłowego 

toku postępowania. Sąd orzeka, że oskarżyciel posiłkowy nie może brać udziału w 

postępowaniu, gdy bierze w nim już udział określona przez sąd liczba oskarżycieli. 

§ 1a. Na postanowienie sądu wydane na podstawie § 1 zażalenie nie przysługuje. 

§ 2. Sąd orzeka także, iż oskarżyciel posiłkowy nie może brać udziału 

w postępowaniu, jeżeli stwierdzi, że nie jest on osobą uprawnioną lub jego akt 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 22/356 

oskarżenia albo oświadczenie o przystąpieniu do postępowania zostało złożone po 

terminie. 

§ 3. Na postanowienie sądu wydane na podstawie § 2 przysługuje zażalenie do 

innego równorzędnego składu tego sądu. 

§ 4. Oskarżyciel posiłkowy, który nie bierze udziału w postępowaniu z przyczyn 

określonych w § 1, może przedstawić sądowi na piśmie swoje stanowisko w terminie 

7 dni od daty doręczenia postanowienia.


## Art. 56a. {#kpk-art-56a}
Oskarżycielowi posiłkowemu, który nie włada w wystarczającym 

stopniu językiem polskim, orzeczenie podlegające zaskarżeniu lub kończące 

postępowanie doręcza się wraz z tłumaczeniem; za zgodą oskarżyciela posiłkowego 

można poprzestać na ogłoszeniu przetłumaczonego orzeczenia kończącego 

postępowanie, jeżeli nie podlega ono zaskarżeniu.


## Art. 57. {#kpk-art-57}
§ 1. W razie odstąpienia oskarżyciela posiłkowego od oskarżenia nie 

może on ponownie przyłączyć się do postępowania. 

§ 1a. W sprawie, w której oskarżyciel publiczny nie bierze udziału, 

niestawiennictwo oskarżyciela posiłkowego i jego pełnomocnika na rozprawie 

głównej bez usprawiedliwienia uważa się za odstąpienie od oskarżenia. 

§ 2. O odstąpieniu oskarżyciela posiłkowego od oskarżenia w sprawie, w której 

oskarżyciel publiczny nie bierze udziału, 

sąd zawiadamia prokuratora. 

Nieprzystąpienie przez niego do oskarżenia w terminie 14 dni od doręczenia 

zawiadomienia powoduje umorzenie postępowania. Postanowienie o umorzeniu 

postępowania może wydać także referendarz sądowy.


## Art. 58. {#kpk-art-58}
§ 1. Śmierć oskarżyciela posiłkowego nie tamuje biegu postępowania; 

osoby najbliższe lub osoby pozostające na jego utrzymaniu mogą przystąpić do 

postępowania w charakterze oskarżyciela posiłkowego w każdym 

stadium 

postępowania. 

§ 2. W razie śmierci oskarżyciela posiłkowego, który samodzielnie popierał 

oskarżenie, stosuje się odpowiednio art. 61. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 23/356 


# Rozdział 6
 

Oskarżyciel prywatny


## Art. 59. {#kpk-art-59}
§ 1. Pokrzywdzony może jako oskarżyciel prywatny wnosić i popierać 

oskarżenie o przestępstwa ścigane z oskarżenia prywatnego. 

§ 2. Inny pokrzywdzony tym samym czynem może aż do rozpoczęcia przewodu 

sądowego na rozprawie głównej przyłączyć się do toczącego się postępowania.


## Art. 60. {#kpk-art-60}
§ 1. W sprawach o przestępstwa ścigane z oskarżenia prywatnego 

prokurator wszczyna postępowanie albo jako oskarżyciel publiczny wstępuje do 

postępowania już wszczętego, jeżeli wymaga tego ochrona praworządności lub interes 

społeczny. 

§ 2. Postępowanie toczy się wówczas z urzędu, a pokrzywdzony, który przedtem 

wniósł oskarżenie prywatne, korzysta z praw oskarżyciela posiłkowego; do 

pokrzywdzonego, który przedtem nie wniósł oskarżenia prywatnego, stosuje się 

art. 54, 55 § 3 i art. 58. 

§ 3. Jeżeli prokurator, który wstąpił do postępowania, odstąpił potem od 

oskarżenia, pokrzywdzony powraca w dalszym postępowaniu do praw oskarżyciela 

prywatnego. 

§ 4. Pokrzywdzony, który nie wniósł oskarżenia, może w terminie zawitym 

14 dni od daty powiadomienia go o odstąpieniu prokuratora od oskarżenia złożyć akt 

oskarżenia lub oświadczenie, że podtrzymuje oskarżenie jako prywatne, a jeżeli 

takiego oświadczenia nie złoży, sąd lub referendarz sądowy umarza postępowanie. 

§ 5. Przepis art. 55 § 5 stosuje się odpowiednio.


## Art. 60a. {#kpk-art-60a}
Oskarżycielowi prywatnemu, który nie włada w wystarczającym 

stopniu językiem polskim, orzeczenie podlegające zaskarżeniu lub kończące 

postępowanie doręcza się wraz z tłumaczeniem; za zgodą oskarżyciela prywatnego 

można poprzestać na ogłoszeniu przetłumaczonego orzeczenia kończącego 

postępowanie, jeżeli nie podlega ono zaskarżeniu.


## Art. 61. {#kpk-art-61}
§ 1. W razie śmierci oskarżyciela prywatnego postępowanie zawiesza 

się, a osoby najbliższe lub osoby pozostające na utrzymaniu zmarłego mogą wstąpić 

w jego prawa. Postanowienie o zawieszeniu postępowania może wydać także 

referendarz sądowy. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 24/356 

§ 2. Jeżeli w terminie zawitym 3 miesięcy od dnia śmierci oskarżyciela 

prywatnego osoba uprawniona nie wstąpi w prawa zmarłego, sąd lub referendarz 

sądowy umarza postępowanie. 

(zawierający art. 62–70 – uchylony) 


# Rozdział 7
 


# Rozdział 8
 

Oskarżony


## Art. 71. {#kpk-art-71}
§ 1. Za podejrzanego uważa się osobę, co do której wydano 

postanowienie o przedstawieniu zarzutów albo której bez wydania 

takiego 

postanowienia postawiono zarzut w związku z przystąpieniem do przesłuchania 

w charakterze podejrzanego. 

§ 2. Za oskarżonego uważa się osobę, przeciwko której wniesiono oskarżenie do 

sądu, a także osobę, co do której prokurator złożył wniosek wskazany w art. 335 § 1 

lub wniosek o warunkowe umorzenie postępowania. 

§ 3. Jeżeli kodeks niniejszy używa w znaczeniu ogólnym określenia 

„oskarżony”, odpowiednie przepisy mają zastosowanie także do podejrzanego.


## Art. 72. {#kpk-art-72}
§ 1. Oskarżony ma prawo do korzystania z bezpłatnej pomocy tłumacza, 

jeżeli nie włada w wystarczającym stopniu językiem polskim. 

§ 2. Tłumacza należy wezwać do czynności z udziałem oskarżonego, o którym 

mowa w § 1. Na wniosek oskarżonego lub jego obrońcy tłumacza należy wezwać 

również w celu porozumienia się oskarżonego z obrońcą w związku z czynnością, do 

udziału w której oskarżony jest uprawniony. 

§ 3. Oskarżonemu, o którym mowa w § 1, postanowienie o przedstawieniu, 

uzupełnieniu lub zmianie zarzutów, akt oskarżenia oraz orzeczenie podlegające 

zaskarżeniu lub kończące postępowanie doręcza się wraz z tłumaczeniem; za zgodą 

oskarżonego można poprzestać na ogłoszeniu przetłumaczonego orzeczenia 

kończącego postępowanie, jeżeli nie podlega ono zaskarżeniu.


## Art. 73. {#kpk-art-73}
§ 1. Oskarżony tymczasowo aresztowany może porozumiewać się ze 

swym obrońcą podczas nieobecności innych osób oraz korespondencyjnie. 

§ 2. W postępowaniu przygotowawczym prokurator, udzielając zezwolenia na 

porozumiewanie się, może zastrzec w szczególnie uzasadnionych wypadkach, jeżeli 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 25/356 

wymaga tego dobro postępowania przygotowawczego, że będzie przy tym obecny sam 

lub osoba przez niego upoważniona. 

§ 3. Jeżeli wymaga tego dobro postępowania przygotowawczego, prokurator, 

w szczególnie uzasadnionych wypadkach, może 

również zastrzec kontrolę 

korespondencji podejrzanego z obrońcą. 

§ 4. Zastrzeżenia, o których mowa w § 2 i 3, nie mogą być utrzymywane ani 

dokonane po upływie 14 dni od dnia tymczasowego aresztowania podejrzanego.


## Art. 74. {#kpk-art-74}
§ 1. Oskarżony nie ma obowiązku dowodzenia swej niewinności ani 

obowiązku dostarczania dowodów na swoją niekorzyść. 

§ 2. Oskarżony jest jednak obowiązany poddać się: 

1) 

oględzinom zewnętrznym ciała oraz 

innym badaniom niepołączonym 

z naruszeniem integralności ciała; wolno także w szczególności od oskarżonego 

pobrać odciski, fotografować go oraz okazać w celach rozpoznawczych innym 

osobom; 

2) 

badaniom psychologicznym i psychiatrycznym oraz badaniom połączonym 

z dokonaniem zabiegów na jego ciele, z wyjątkiem chirurgicznych, pod 

warunkiem że dokonywane są przez uprawnionego do tego pracownika służby 

zdrowia z zachowaniem wskazań wiedzy lekarskiej i nie zagrażają zdrowiu 

oskarżonego, 

jeżeli przeprowadzenie 

tych badań 

jest nieodzowne; 

w szczególności oskarżony jest obowiązany przy zachowaniu tych warunków 

poddać się pobraniu krwi, włosów lub wydzielin organizmu, z zastrzeżeniem 

pkt 3; 

3) 

pobraniu przez funkcjonariusza Policji wymazu ze śluzówki policzków, jeżeli 

jest to nieodzowne i nie zachodzi obawa, że zagrażałoby to zdrowiu oskarżonego 

lub innych osób. 

§ 3. W stosunku do osoby podejrzanej można dokonać badań lub czynności, 

o których mowa w § 2 pkt 1, a także, przy zachowaniu wymagań określonych w § 2 

pkt 2 lub 3, pobrać krew, włosy, wymaz ze śluzówki policzków lub inne wydzieliny 

organizmu. 

§ 3a. Oskarżonego lub osobę podejrzaną wzywa się do poddania się obowiązkom 

wynikającym z § 2 i 3. W razie odmowy poddania się tym obowiązkom oskarżonego 

lub osobę podejrzaną można zatrzymać i przymusowo doprowadzić, a także stosować 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 26/356 

wobec nich siłę fizyczną lub środki techniczne służące obezwładnieniu, w zakresie 

niezbędnym do wykonania danej czynności. 

§ 4. Minister Sprawiedliwości w porozumieniu z ministrem właściwym do 

spraw zdrowia określi, w drodze rozporządzenia, szczegółowe warunki i sposób 

poddawania oskarżonego oraz osoby podejrzanej badaniom, a także wykonywania 

z ich udziałem czynności, o których mowa w § 2 pkt 1 i 3 oraz § 3, mając na uwadze, 

aby gromadzenie, utrwalanie i analiza materiału dowodowego były dokonywane 

zgodnie z aktualną wiedzą w zakresie kryminalistyki i medycyny sądowej.


## Art. 75. {#kpk-art-75}
§ 1. Oskarżony jest obowiązany zawiadamiać organ prowadzący 

postępowanie o każdej zmianie miejsca swojego zamieszkania lub pobytu trwającego 

dłużej niż 7 dni, w tym także z powodu pozbawienia wolności w innej sprawie, jak 

również o każdej zmianie danych umożliwiających kontaktowanie się, wskazanych 

w art. 213 § 1, o których wie, że są znane organowi prowadzącemu postępowanie. 

Oskarżony jest obowiązany ponadto stawić się na każde wezwanie w toku 

postępowania karnego. O powyższych obowiązkach należy oskarżonego uprzedzić 

przy pierwszym przesłuchaniu. 

§ 2. W razie nieusprawiedliwionego niestawiennictwa oskarżonego można 

zatrzymać go i sprowadzić przymusowo. 

§ 3. Przepisy art. 246 stosuje się odpowiednio. Zażalenie na postanowienie sądu 

rozpoznaje ten sam sąd w składzie trzech sędziów.


## Art. 76. {#kpk-art-76}
Jeżeli oskarżony nie ukończył 18 lat lub jest ubezwłasnowolniony, jego 

przedstawiciel ustawowy lub osoba, pod której pieczą oskarżony pozostaje, może 

podejmować na jego korzyść wszelkie czynności procesowe, a przede wszystkim 

wnosić środki zaskarżenia, składać wnioski oraz ustanowić obrońcę.


## Art. 76a. {#kpk-art-76a}
§ 1. Na wniosek oskarżonego, który nie ukończył 18 lat, podczas 

posiedzenia albo rozprawy z jego udziałem może być obecny jego przedstawiciel 

ustawowy lub osoba, pod której pieczą oskarżony pozostaje. Jeśli oskarżony nie 

posiada przedstawiciela ustawowego lub osoby, pod której pieczą pozostaje, albo 

przewodniczący uznał, że udział tych osób może prowadzić do naruszenia praw lub 

interesów oskarżonego, jest niecelowy ze względu na jego dobro, uniemożliwia 

przeprowadzenie posiedzenia albo rozprawy albo utrudnia je w istotny sposób, 

oskarżony może wskazać inną osobę pełnoletnią. Jeżeli oskarżony nie wskazał takiej 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 27/356 

osoby lub przewodniczący uznał, że jej obecność może prowadzić do naruszenia praw 

lub interesów oskarżonego, jest niecelowa ze względu na jego dobro, uniemożliwia 

przeprowadzenie posiedzenia albo rozprawy albo utrudnia je w istotny sposób, 

przewodniczący wyznacza asystenta rodziny, o którym mowa w art. 12 ustawy z dnia 

9 czerwca 2011 r. o wspieraniu rodziny i systemie pieczy zastępczej (Dz. U. z 2024 r. 

poz. 177, 742, 743, 858 i 1572). 

§ 2. Przewodniczący wyznacza asystenta rodziny, mając na uwadze konieczność 

ochrony praw 

lub 

interesów oskarżonego oraz zapewnienia 

sprawnego 

przeprowadzenia posiedzenia lub rozprawy. Przed wyznaczeniem asystenta rodziny 

przewodniczący wzywa podmiot wskazany w art. 17 ust. 1 ustawy z dnia 9 czerwca 

2011 r. o wspieraniu rodziny i systemie pieczy zastępczej, właściwy miejscowo ze 

względu na miejsce prowadzenia postępowania, do niezwłocznego przekazania listy 

asystentów rodziny wraz z danymi kontaktowymi.


## Art. 77. {#kpk-art-77}
Oskarżony może mieć jednocześnie nie więcej niż trzech obrońców.


## Art. 78. {#kpk-art-78}
§ 1. Oskarżony, który nie ma obrońcy z wyboru, może żądać, aby mu 

wyznaczono obrońcę z urzędu, jeżeli w sposób należyty wykaże, że nie jest w stanie 

ponieść kosztów obrony bez uszczerbku dla niezbędnego utrzymania siebie i rodziny. 

Podstawą odmowy wyznaczenia obrońcy z urzędu nie może być skorzystanie przez 

oskarżonego z nieodpłatnej pomocy prawnej lub nieodpłatnego poradnictwa 

obywatelskiego, o których mowa w ustawie z dnia 5 sierpnia 2015 r. o nieodpłatnej 

pomocy prawnej, nieodpłatnym poradnictwie obywatelskim oraz edukacji prawnej 

(Dz. U. z 2024 r. poz. 1534). 

§ 1a. Przepis § 1 stosuje się odpowiednio, jeżeli oskarżony żąda wyznaczenia 

obrońcy z urzędu w celu dokonania określonej czynności procesowej. 

§ 2. Sąd może cofnąć wyznaczenie obrońcy, jeżeli okaże się, że nie istnieją oko-

liczności, na podstawie których go wyznaczono. Na postanowienie o cofnięciu 

wyznaczenia obrońcy przysługuje zażalenie do innego równorzędnego składu tego 

sądu.


## Art. 78a. {#kpk-art-78a}
§ 1. Żołnierz, funkcjonariusz Policji lub funkcjonariusz Straży 

Granicznej oskarżony o przestępstwo popełnione w następstwie stosowania środków 

przymusu bezpośredniego, użycia broni lub innego uzbrojenia albo użycia lub 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 28/356 

wykorzystania środków przymusu bezpośredniego lub broni palnej w związku 

z wykonywaniem czynności lub zadań służbowych odpowiednio: 

1) 

na podstawie art. 11b albo art. 11c ustawy z dnia 12 października 1990 r. 

o Straży Granicznej (Dz. U. z 2024 r. poz. 915, z późn. zm.5)), art. 18 ustawy 

z dnia 6 kwietnia 1990 r. o Policji (Dz. U. z 2024 r. poz. 145, z późn. zm.6)) albo 

w czasie trwania operacji wojskowej, o której mowa w art. 2 pkt 18a ustawy 

z dnia 11 marca 2022 r. o obronie Ojczyzny (Dz. U. z 2024 r. poz. 248, 834, 

1089, 1222, 1248 i 1585), 

2) w przypadku konieczności odparcia bezpośredniego, bezprawnego zamachu na 

życie, zdrowie lub wolność swoją lub innej osoby albo nienaruszalność granicy 

państwowej lub przeciwdziałania czynnościom zmierzającym bezpośrednio do 

tych zamachów albo prowadzenia działań kontrterrorystycznych, o których 

mowa w art. 2 pkt 2 ustawy z dnia 10 czerwca 2016 r. o działaniach 

antyterrorystycznych (Dz. U. z 2024 r. poz. 92, 1248 i 1684) 

– który nie ma obrońcy z wyboru, może żądać, aby mu wyznaczono obrońcę z urzędu. 

§ 2. Przepis § 1 stosuje się odpowiednio, jeżeli oskarżony żąda wyznaczenia 

obrońcy z urzędu w celu dokonania określonej czynności procesowej. 

§ 3. Sąd może cofnąć wyznaczenie obrońcy, jeżeli okaże się, że nie istnieją 

okoliczności, na podstawie których go wyznaczono. Na postanowienie o cofnięciu 

wyznaczenia obrońcy przysługuje zażalenie do innego równorzędnego składu tego 

sądu.


## Art. 79. {#kpk-art-79}
§ 1. W postępowaniu karnym oskarżony musi mieć obrońcę, jeżeli: 

1) 

2) 

3) 

nie ukończył 18 lat; 

jest głuchy, niemy lub niewidomy; 

zachodzi uzasadniona wątpliwość, czy jego zdolność rozpoznania znaczenia 

czynu lub kierowania swoim postępowaniem nie była w czasie popełnienia tego 

czynu wyłączona lub w znacznym stopniu ograniczona; 

5) Zmiany tekstu jednolitego wymienionej ustawy zostały ogłoszone w Dz. U. z 2024 r. poz. 1089, 

1222, 1248, 1473, 1562, 1688 i 1717. 

6) Zmiany tekstu jednolitego wymienionej ustawy zostały ogłoszone w Dz. U. z 2024 r. poz. 1006, 

1089, 1222, 1248, 1473, 1562, 1688 i 1717. 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 29/356 

4) 

zachodzi uzasadniona wątpliwość, czy stan jego zdrowia psychicznego pozwala 

na udział w postępowaniu lub prowadzenie obrony w sposób samodzielny oraz 

rozsądny. 

§ 2. Oskarżony musi mieć obrońcę również wtedy, gdy sąd uzna to za niezbędne 

ze względu na inne okoliczności utrudniające obronę. 

§ 3. W wypadkach, o których mowa w § 1 i 2, udział obrońcy jest obowiązkowy 

w rozprawie oraz w tych posiedzeniach, w których obowiązkowy jest udział 

oskarżonego. 

§ 4. Uznając za uzasadnioną opinię biegłych lekarzy psychiatrów, że czyn 

oskarżonego nie został popełniony w warunkach wyłączenia 

lub znacznego 

ograniczenia zdolności rozpoznania znaczenia czynu lub kierowania swoim postę-

powaniem 

i że stan zdrowia psychicznego oskarżonego pozwala na udział 

w postępowaniu i prowadzenie obrony w sposób samodzielny i rozsądny, sąd orzeka, 

że udział obrońcy nie jest obowiązkowy. Prezes sądu albo sąd zwalnia wówczas 

obrońcę z jego obowiązków, chyba że zachodzą inne okoliczności przemawiające za 

tym, aby oskarżony miał obrońcę wyznaczonego z urzędu.


## Art. 80. {#kpk-art-80}
Oskarżony musi mieć obrońcę w postępowaniu przed sądem 

okręgowym, jeżeli zarzucono mu zbrodnię. W takim wypadku udział obrońcy 

w rozprawie głównej jest obowiązkowy.


## Art. 80a. {#kpk-art-80a}
(uchylony)


## Art. 81. {#kpk-art-81}
§ 1. Jeżeli w sytuacji określonej w art. 78 § 1 lub 1a, art. 78a § 1 lub 2, 

art. 79 § 1 i 2 oraz art. 80 oskarżony nie ma obrońcy z wyboru, prezes lub referendarz 

sądowy sądu właściwego do rozpoznania sprawy wyznacza mu obrońcę z urzędu. 

§ 1a. Na zarządzenie prezesa sądu o odmowie wyznaczenia obrońcy przysługuje 

zażalenie do sądu właściwego do rozpoznania sprawy, a na postanowienie sądu 

o odmowie wyznaczenia obrońcy – zażalenie do innego równorzędnego składu tego 

sądu. 

§ 1b. Ponowny wniosek o wyznaczenie obrońcy, oparty na tych samych oko-

licznościach, pozostawia się bez rozpoznania. 

§ 2. Na uzasadniony wniosek oskarżonego lub jego obrońcy prezes lub 

referendarz sądowy sądu właściwego do rozpoznania sprawy może wyznaczyć 

nowego obrońcę w miejsce dotychczasowego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 30/356


## Art. 81a. {#kpk-art-81a}
§ 1. Obrońca z urzędu wyznaczany jest z listy obrońców. 

§ 2. Wniosek o wyznaczenie obrońcy z urzędu prezes sądu, sąd lub referendarz 

sądowy rozpoznaje niezwłocznie. 

§ 3. Jeżeli okoliczności wskazują na konieczność natychmiastowego podjęcia 

obrony: 

1) wniosek o wyznaczenie obrońcy oraz inne dokumenty niezbędne do rozpoznania 

wniosku mogą być przekazane przez organ prowadzący postępowanie 

przygotowawcze do właściwego sądu za pośrednictwem telefaksu lub poczty 

elektronicznej; 

2) 

prezes sądu, sąd lub referendarz sądowy, w sposób wskazany w art. 137, 

powiadamia oskarżonego oraz obrońcę o wyznaczeniu obrońcy z urzędu. 

§ 4. Minister Sprawiedliwości określi, w drodze rozporządzenia: 

1) 

sposób zapewnienia oskarżonemu korzystania z pomocy obrońcy z urzędu, 

w tym sposób ustalania listy obrońców udzielających pomocy prawnej z urzędu 

oraz sposób wyznaczania obrońcy udzielającego pomocy prawnej z urzędu, 

2) 

tryb przekazywania do sądu wniosku o wyznaczenie obrońcy z urzędu oraz 

szczegółowy tryb rozpoznawania takiego wniosku 

– mając na uwadze konieczność zapewnienia prawidłowego toku postępowania oraz 

prawidłowej realizacji prawa do obrony. 


# Rozdział 9
 

Obrońcy i pełnomocnicy


## Art. 82. {#kpk-art-82}
Obrońcą może być jedynie osoba uprawniona do obrony według 

przepisów o ustroju adwokatury lub ustawy o radcach prawnych.


## Art. 83. {#kpk-art-83}
§ 1. Obrońcę ustanawia oskarżony; do czasu ustanowienia obrońcy 

przez oskarżonego pozbawionego wolności, obrońcę może ustanowić inna osoba, 

o czym niezwłocznie zawiadamia się oskarżonego. 

§ 2. Upoważnienie do obrony może być udzielone na piśmie albo przez 

oświadczenie do protokołu organu prowadzącego postępowanie karne.


## Art. 84. {#kpk-art-84}
§ 1. Ustanowienie obrońcy lub wyznaczenie obrońcy z urzędu uprawnia 

go do działania w całym postępowaniu, nie wyłączając czynności po 

uprawomocnieniu się orzeczenia, jeżeli nie zawiera ograniczeń. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 31/356 

§ 2. Wyznaczenie obrońcy z urzędu nakłada na niego obowiązek podejmowania 

czynności procesowych do prawomocnego zakończenia postępowania. Jeżeli jednak 

czynności należy dokonać poza siedzibą lub miejscem zamieszkania obrońcy 

z urzędu, prezes sądu, przed którym ma być dokonana czynność, lub referendarz 

sądowy tego sądu, a w postępowaniu przygotowawczym prezes sądu rejonowego 

miejsca czynności lub referendarz sądowy tego sądu, na uzasadniony wniosek 

dotychczasowego obrońcy może wyznaczyć do dokonania tej czynności innego 

obrońcę spośród miejscowych adwokatów lub radców prawnych. 

§ 3. Obrońca 

wyznaczony 

z urzędu 

w postępowaniu 

kasacyjnym, 

w postępowaniu o uchylenie wyroku sądu odwoławczego uchylającego wyrok sądu 

pierwszej instancji i przekazującego sprawę do ponownego rozpoznania lub w 

postępowaniu o wznowienie postępowania powinien sporządzić i podpisać kasację, 

skargę od wyroku sądu odwoławczego uchylającego wyrok sądu pierwszej instancji 

i przekazującego sprawę do ponownego rozpoznania lub wniosek o wznowienie 

postępowania albo poinformować na piśmie sąd, że nie stwierdził podstaw do 

wniesienia kasacji, skargi lub wniosku o wznowienie postępowania. Jeżeli kasacja, 

skarga lub wniosek zostaną wniesione, obrońca ten jest uprawniony do udziału 

w toczącym się postępowaniu.


## Art. 85. {#kpk-art-85}
§ 1. Obrońca może bronić kilku oskarżonych, jeżeli ich interesy nie 

pozostają w sprzeczności. 

§ 2.7) Stwierdzając 

sprzeczność 

sąd wydaje postanowienie, zakreślając 

oskarżonym termin do ustanowienia innych obrońców. W wypadku obrony z urzędu 

sąd wyznacza innego obrońcę. Na postanowienie przysługuje zażalenie. 

§ 3. W postępowaniu 

przygotowawczym 

uprawnienia 

sądu 

określone 

w § 2 przysługują prezesowi sądu właściwego do rozpoznania sprawy.


## Art. 86. {#kpk-art-86}
§ 1. Obrońca może przedsiębrać czynności procesowe jedynie na 

korzyść oskarżonego. 

7) Uznany za niezgodny z Konstytucją z dniem 6 maja 2022 r. w związku z art. 85 § 3 w zakresie, w 
jakim nie przewidują możliwości wniesienia zażalenia na zarządzenie prezesa sądu, w którym 
stwierdza się, że interesy kilku podejrzanych, reprezentowanych przez tego samego obrońcę, nie 
pozostają w sprzeczności, na podstawie wyroku Trybunału Konstytucyjnego z dnia 27 kwietnia 
2022 r. sygn. akt SK 53/20 (Dz. U. poz. 958). 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 32/356 

§ 2. Udział obrońcy w postępowaniu nie wyłącza osobistego działania w nim 

oskarżonego.


## Art. 87. {#kpk-art-87}
§ 1. Strona inna niż oskarżony może ustanowić pełnomocnika. 

§ 2. Osoba niebędąca stroną może ustanowić pełnomocnika, jeżeli wymagają 

tego jej interesy w toczącym się postępowaniu. 

§ 3. Sąd, a w postępowaniu przygotowawczym prokurator, może odmówić 

dopuszczenia do udziału w postępowaniu pełnomocnika, o którym mowa w § 2, jeżeli 

uzna, że nie wymaga tego obrona interesów osoby niebędącej stroną.


## Art. 87a. {#kpk-art-87a}
(uchylony)


## Art. 88. {#kpk-art-88}
§ 1. Pełnomocnikiem może być adwokat, radca prawny lub radca 

Prokuratorii Generalnej Rzeczypospolitej Polskiej. Pełnomocnika z urzędu wyznacza 

prezes lub referendarz sądowy sądu właściwego do rozpoznania sprawy. Do pełno-

mocnika stosuje się odpowiednio przepisy art. 77, art. 78, art. 78a, art. 81 § 1a–2, 

art. 81a § 1–3, art. 83, art. 84, art. 86 § 2 oraz przepisy wydane na podstawie art. 81a 

§ 4. 

2. Na zasadach określonych w odrębnej ustawie czynności zastępstwa wykonuje 

Prokuratoria Generalna Rzeczy- 

pospolitej Polskiej.


## Art. 89. {#kpk-art-89}
W kwestiach dotyczących pełnomocnika, a nieunormowanych przez 

przepisy niniejszego kodeksu, stosuje się odpowiednio przepisy obowiązujące 

w postępowaniu cywilnym. 


# Rozdział 10
 

Przedstawiciel społeczny


## Art. 90. {#kpk-art-90}
§ 1. W postępowaniu sądowym udział w postępowaniu może zgłosić 

organizacja społeczna, jeżeli zachodzi potrzeba ochrony interesu społecznego lub 

interesu indywidualnego, objętego zadaniami statutowymi tej organizacji, w szcze-

gólności ochrony wolności i praw człowieka. 

§ 2. W zgłoszeniu organizacja społeczna wskazuje interes społeczny lub 

indywidualny, objęty zadaniami statutowymi tej organizacji, oraz przedstawiciela, 

który ma reprezentować tę organizację. Do zgłoszenia dołącza się odpis statutu lub 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 33/356 

innego dokumentu regulującego działalność tej organizacji. Przedstawiciel organizacji 

społecznej przedkłada sądowi pisemne upoważnienie. 

§ 3. Sąd dopuszcza przedstawiciela organizacji społecznej do występowania 

w sprawie, jeżeli przynajmniej jedna ze stron wyrazi na to zgodę. Strona może 

w każdym czasie cofnąć wyrażoną zgodę. W wypadku braku zgody choćby jednej ze 

stron na występowanie w sprawie przedstawiciela organizacji społecznej sąd wyłącza 

tego przedstawiciela od udziału w sprawie, chyba że jego udział leży w interesie 

wymiaru sprawiedliwości. 

§ 4. Sąd dopuszcza przedstawiciela organizacji społecznej do występowania 

w sprawie pomimo braku zgody stron, 

jeżeli 

leży 

to w interesie wymiaru 

sprawiedliwości. 

§ 5. Sąd odmawia dopuszczenia przedstawiciela organizacji społecznej do 

występowania w sprawie, jeżeli stwierdzi, że wskazany w zgłoszeniu interes 

społeczny lub indywidualny nie jest objęty zadaniami statutowymi tej organizacji lub 

nie jest związany z rozpoznawaną sprawą. 

§ 6. Sąd może ograniczyć liczbę przedstawicieli organizacji społecznych 

występujących w sprawie, jeżeli jest to konieczne dla zabezpieczenia prawidłowego 

toku postępowania. Sąd wzywa wówczas oskarżyciela i oskarżonego do wskazania nie 

więcej niż dwóch przedstawicieli organizacji społecznych, którzy będą mogli 

występować w sprawie. Jeżeli w sprawie występuje więcej niż jeden oskarżony lub 

więcej niż jeden oskarżyciel, każdy z nich może wskazać jednego przedstawiciela. 

Niewskazanie przedstawiciela uznaje się za cofnięcie zgody na jego występowanie 

w sprawie. Niezależnie od stanowisk stron sąd może postanowić o dalszym udziale 

poszczególnych przedstawicieli organizacji społecznych, jeżeli ich udział leży 

w interesie wymiaru sprawiedliwości.


## Art. 91. {#kpk-art-91}
Dopuszczony do udziału w postępowaniu sądowym przedstawiciel 

organizacji społecznej może uczestniczyć w rozprawie, wypowiadać się i składać 

oświadczenia na piśmie. 


# Rozdział 10
a 

Podmiot zobowiązany


## Art. 91a. {#kpk-art-91a}
§ 1. Jeżeli w związku z popełnieniem czynu zabronionego osoba 

fizyczna, prawna albo jednostka organizacyjna niemająca osobowości prawnej, której 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 34/356 

odrębne przepisy przyznają zdolność prawną, uzyskała korzyść majątkową lub 

świadczenie określone w art. 405–407, art. 410 i art. 412 Kodeksu cywilnego od 

Skarbu Państwa, jednostki samorządowej, państwowej lub samorządowej jednostki 

organizacyjnej, podmiotu, dla którego organ samorządu jest organem założycielskim, 

lub spółki prawa handlowego z większościowym udziałem Skarbu Państwa lub 

jednostki samorządowej, na wniosek prokuratora sąd, stosując przepisy prawa 

cywilnego, zobowiązuje tę osobę lub jednostkę do zwrotu korzyści albo jej 

równowartości uprawnionemu podmiotowi lub orzeka przepadek świadczenia albo 

jego równowartości na rzecz Skarbu Państwa. 

§ 2. Podmiot zobowiązany określony w § 1 jest przesłuchiwany w postępowaniu 

karnym w charakterze świadka. W przypadku podmiotu innego niż osoba fizyczna 

przesłuchuje się osobę lub osoby uprawnione do działania w jego imieniu. 

§ 3. Osoba, o której mowa w § 2, może odmówić zeznań. 

§ 4. Przepisy art. 72, art. 75, art. 87 § 1, art. 89, art. 156 § 1 zdanie pierwsze oraz 

art. 167 stosuje się odpowiednio. Osoba, o której mowa w § 2, może zadawać pytania 

osobie przesłuchiwanej oraz zabrać głos końcowy przed obrońcą oskarżonego i 

oskarżonym. 


# Rozdział 10
b 

Właściciel przedsiębiorstwa zagrożonego przepadkiem


## Art. 91b. {#kpk-art-91b}
Właścicielowi przedsiębiorstwa zagrożonego przepadkiem, o którym 

mowa w art. 44a § 2 Kodeksu karnego, przysługują prawa strony w zakresie czynności 

procesowych odnoszących się do tego środka.
