---
id: "code_kpk_dzial-xiii"
title: "KPK — DZIAŁ XIII"
source_pdf: "D19970555Lj (1).pdf"
dz_u: "Dz. U. 1997 Nr 89 poz. 555"
status: "obowiązujący"
last_consolidated: "2025-09-11"
law: "Kodeks postępowania karnego"
tags: ["kpk", "kodeks", "postępowanie karne"]
articles_range: {"first": "578", "last": "615a"}
---

# DZIAŁ XIII

## Art. 578. {#kpk-art-578}
Nie podlegają orzecznictwu polskich sądów karnych: 

1) 

uwierzytelnieni w Rzeczypospolitej Polskiej szefowie przedstawicielstw 

dyplomatycznych państw obcych; 

2) 

3) 

osoby należące do personelu dyplomatycznego tych przedstawicielstw; 

osoby należące do personelu administracyjnego 

i technicznego 

tych 

przedstawicielstw; 

4) 

członkowie rodzin osób wymienionych w pkt 1–3, jeżeli pozostają z nimi we 

wspólnocie domowej; 

5) 

inne osoby korzystające z immunitetów dyplomatycznych na podstawie ustaw, 

umów lub powszechnie uznanych zwyczajów międzynarodowych.


## Art. 579. {#kpk-art-579}
§ 1. Nie podlegają orzecznictwu polskich sądów karnych w zakresie 

czynności pełnionych podczas i w związku z wykonywaniem ich funkcji urzędowych, 

a na zasadzie wzajemności w pozostałym zakresie: 

1) 

2) 

kierownicy urzędów konsularnych i inni urzędnicy konsularni państw obcych; 

osoby zrównane z nimi na podstawie umów lub powszechnie uznanych 

zwyczajów międzynarodowych. 

§ 2. Kierownik urzędu konsularnego oraz inni urzędnicy konsularni państw 

obcych podlegają zatrzymaniu lub tymczasowemu aresztowaniu jedynie w razie 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 230/356 

zarzutu popełnienia zbrodni. O ich zatrzymaniu lub tymczasowym aresztowaniu 

zawiadamia się niezwłocznie Ministra Spraw Zagranicznych12). 

§ 3. Poza wypadkiem określonym w § 2 osoby te mogą być pozbawione 

wolności tylko w wykonaniu prawomocnego wyroku sądu polskiego.


## Art. 580. {#kpk-art-580}
§ 1. Przepisów art. 578 i 579 nie stosuje się, gdy państwo wysyłające 

zrzeknie się w sposób wyraźny immunitetu w stosunku do osoby wymienionej w tych 

przepisach. 

§ 2. W stosunku 

do 

funkcjonariuszy 

organizacji międzynarodowych 

korzystających z immunitetu o zrzeczeniu, o którym mowa w § 1, rozstrzyga 

właściwa organizacja międzynarodowa.


## Art. 581. {#kpk-art-581}
§ 1. Osoby wymienione w art. 578 nie są obowiązane do składania 

zeznań w charakterze świadka lub do występowania w charakterze biegłego lub 

tłumacza; można jednak zwrócić się o wyrażenie przez te osoby zgody na złożenie 

zeznań albo na wystąpienie w charakterze biegłego lub tłumacza. 

§ 2. W razie wyrażenia zgody, o której mowa w § 1, wezwania doręczone tym 

osobom nie mogą zawierać zagrożenia stosowaniem środków przymusu, a w razie 

niestawiennictwa na wezwanie lub odmowy złożenia zeznań nie można wobec nich 

stosować tych środków.


## Art. 582. {#kpk-art-582}
§ 1. Do osób wymienionych w art. 579 stosuje się odpowiednio 

art. 581, jeżeli okoliczności, których zeznania lub opinie mają dotyczyć, związane są 

z wykonywaniem przez te osoby funkcji urzędowych lub służbowych, a na zasadzie 

wzajemności także w zakresie innych okoliczności. 

§ 2. Osoby wymienione w art. 578 i 579 nie są obowiązane do przedstawienia 

korespondencji i dokumentów odnoszących się do tych funkcji.


## Art. 583. {#kpk-art-583}
§ 1. Przeszukania pomieszczeń przedstawicielstwa dyplomatycznego 

można dokonać tylko za zgodą szefa tego przedstawicielstwa lub osoby czasowo 

pełniącej jego funkcje. 

12) Obecnie ministra właściwego do spraw zagranicznych na podstawie art. 4 ust. 1, art. 5 pkt 27 
i art. 32 ustawy z dnia 4 września 1997 r. o działach administracji rządowej (Dz. U. z 2024 r. poz. 
1370), która weszła w życie z dniem 1 kwietnia 1999 r. 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 231/356 

§ 2. Do przeszukania pomieszczeń konsularnych konieczna 

jest zgoda 

kierownika urzędu konsularnego lub osoby czasowo pełniącej jego funkcje albo szefa 

przedstawicielstwa dyplomatycznego.


## Art. 584. {#kpk-art-584}
Przepisów art. 578–583 nie stosuje się do osób w nich wymienionych, 

w zakresie czynności niepełnionych podczas i w związku z wykonywaniem ich 

funkcji urzędowych, jeżeli są obywatelami polskimi lub mają w Rzeczypospolitej 

Polskiej stałe miejsce zamieszkania. 


# Rozdział 62
 

Pomoc prawna i doręczenia w sprawach karnych


## Art. 585. {#kpk-art-585}
W drodze pomocy prawnej mogą być dokonywane niezbędne 

czynności postępowania karnego, a w szczególności: 

1) 

doręczanie pism osobom przebywającym za granicą lub instytucjom mającym 

siedzibę za granicą; 

2) 

3) 

przesłuchiwanie osób w charakterze oskarżonych, świadków lub biegłych; 

dokonywanie oględzin oraz przeszukiwanie pomieszczeń, innych miejsc i osób, 

zajęcie przedmiotów i wydawanie przedmiotów tych za granicę; 

4) wzywanie osób przebywających za granicą do osobistego dobrowolnego 

stawiennictwa przed sądem lub prokuratorem w celu przesłuchania świadka lub 

konfrontacji, jak również doprowadzanie w tym celu osób pozbawionych w tym 

czasie wolności; 

5) 

6) 

udostępnianie akt i dokumentów oraz informacji o karalności oskarżonych; 

udzielanie informacji o prawie.


## Art. 586. {#kpk-art-586}
§ 1. O doręczenie pisma przebywającej za granicą osobie, która ma 

obywatelstwo polskie, lub o przesłuchanie takiej osoby w charakterze oskarżonego, 

świadka lub biegłego sąd lub prokurator zwraca się do polskiego przedstawicielstwa 

dyplomatycznego lub urzędu konsularnego. 

§ 2. W razie niemożności dokonania czynności w sposób określony w § 1, 

można zwracać się o dokonanie tych czynności do sądu, prokuratury lub innego 

właściwego organu państwa obcego. W wypadku przeszukania, zajęcia i wydania 

przedmiotu należy do wniosku dołączyć odpis postanowienia sądu lub prokuratora 

nakazującego przeprowadzenie tej czynności w danej sprawie. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 232/356


## Art. 587. {#kpk-art-587}
Sporządzone na wniosek polskiego sądu lub prokuratora protokoły 

oględzin, przesłuchań osób w charakterze oskarżonych, świadków, biegłych lub 

protokoły innych czynności dowodowych, dokonanych przez sądy lub prokuratorów 

państw obcych albo organy działające pod ich nadzorem, mogą być odczytywane na 

rozprawie na zasadach określonych w art. 389, 391 

i 393, 

jeżeli sposób 

przeprowadzenia czynności nie jest sprzeczny z zasadami porządku prawnego 

w Rzeczypospolitej Polskiej.


## Art. 588. {#kpk-art-588}
§ 1. Sądy i prokuratorzy udzielają pomocy prawnej na wniosek sądów 

i prokuratorów państw obcych. 

§ 2. Sąd i prokurator odmawiają udzielenia pomocy prawnej i przekazują 

odmowę właściwym organom obcego państwa, jeżeli żądana czynność byłaby 

sprzeczna z zasadami porządku prawnego Rzeczypospolitej Polskiej albo naruszałaby 

jej suwerenność. 

§ 3. Sąd i prokurator mogą odmówić udzielenia pomocy prawnej, jeżeli: 

1) wykonanie żądanej czynności nie należy do zakresu działania sądu lub 

prokuratora według prawa polskiego; 

2) 

państwo, od którego wniosek o udzielenie pomocy prawnej pochodzi, nie 

zapewnia w tym zakresie wzajemności; 

3) wniosek dotyczy czynu, który nie jest przestępstwem według prawa polskiego. 

§ 4. Do czynności procesowych, dokonywanych na wniosek sądu 

lub 

prokuratora państwa obcego, stosuje się ustawy polskie. Należy jednak uczynić zadość 

życzeniu tych organów, aby przy dokonaniu czynności zastosowano szczególny tryb 

postępowania lub szczególną formę, jeżeli nie jest to sprzeczne z zasadami porządku 

prawnego Rzeczypospolitej Polskiej. 

§ 5. Koszty udzielania pomocy prawnej ustala się zgodnie z art. 616–619.


## Art. 589. {#kpk-art-589}
§ 1. Wezwany z zagranicy świadek lub biegły niebędący obywatelem 

polskim, który stawi się dobrowolnie przed sądem, nie może być ani ścigany, ani 

zatrzymany, ani też tymczasowo aresztowany z powodu przestępstwa będącego 

przedmiotem danego postępowania karnego i jakiegokolwiek innego przestępstwa 

popełnionego przed przekroczeniem polskiej granicy państwowej. Nie może być także 

w stosunku do niego wykonana kara orzeczona za takie przestępstwo. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 233/356 

§ 2. Świadek lub biegły traci ochronę przewidzianą w § 1, jeżeli nie opuści 

terytorium Rzeczypospolitej Polskiej, chociaż mógł to uczynić, w ciągu 7 dni od 

czasu, gdy sąd oznajmił mu, że obecność jego stała się zbędna. 

§ 3. Wezwanemu świadkowi lub biegłemu przysługuje zwrot kosztów podróży 

i pobytu oraz zwrot utraconego zarobku, a biegłemu – wynagrodzenie za sporządzenie 

opinii. 

§ 4. W wezwaniu doręczonym świadkowi lub biegłemu stale przebywającemu za 

granicą należy zamieścić pouczenie o treści przepisów § 1–3. Nie należy natomiast 

zamieszczać zagrożenia stosowaniem środków przymusu z powodu niestawiennictwa.


## Art. 589a. {#kpk-art-589a}
§ 1. Wobec osoby pozbawionej wolności na terytorium państwa 

obcego, czasowo wydanej w celu złożenia zeznań w charakterze świadka lub 

dokonania z jej udziałem innej czynności procesowej przed polskim sądem lub 

prokuratorem, sąd okręgowy miejsca wykonania czynności zarządza umieszczenie 

osoby wydanej w polskim zakładzie karnym lub areszcie śledczym na czas jej pobytu 

na terytorium Rzeczypospolitej Polskiej, nieprzekraczający jednak czasu pozbawienia 

wolności określonego w państwie wydającym. 

§ 2. Na postanowienie sądu zażalenie nie przysługuje.


## Art. 589b. {#kpk-art-589b}
§ 1. Pomoc prawna w postępowaniu przygotowawczym między 

polskimi organami uprawnionymi do prowadzenia 

tego postępowania oraz 

właściwymi organami państwa członkowskiego Unii Europejskiej lub innego państwa, 

jeżeli pozwala na to umowa międzynarodowa, której Rzeczpospolita Polska jest 

stroną, albo na zasadach wzajemności, może także polegać na wykonywaniu 

czynności śledztwa w ramach wspólnego zespołu śledczego, zwanego dalej 

„zespołem”. 

§ 2. Zespół powołują, w drodze porozumienia, Prokurator Generalny oraz 

właściwy organ państwa, o którym mowa w § 1, zwanego dalej „państwem 

współpracującym”, na potrzeby określonego postępowania przygotowawczego, na 

czas oznaczony. 

§ 3. Porozumienie o powołaniu zespołu powinno określać: 

1) 

2) 

3) 

przedmiot, cel, miejsce i okres współpracy; 

skład zespołu, ze wskazaniem osoby kierującej; 

zadania poszczególnych członków zespołu. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 234/356 

§ 4. W porozumieniu o powołaniu zespołu można zastrzec możliwość 

dopuszczenia do prac w zespole, w określonych warunkach, przedstawiciela instytucji 

międzynarodowej powołanej do zwalczania przestępczości. 

§ 5. Okres współpracy w ramach 

zespołu, wskazany w porozumieniu 

o powołaniu zespołu, może być przedłużony na dalszy czas oznaczony, niezbędny do 

osiągnięcia celu tej współpracy; przedłużenie wymaga zgody wszystkich stron 

porozumienia.


## Art. 589c. {#kpk-art-589c}
§ 1. Zespół, w ramach którego współpraca odbywa się na terytorium 

Rzeczypospolitej Polskiej, zwany dalej „zespołem polskim”, można powołać 

w szczególności, gdy: 

1) w toku prowadzonego na terytorium Rzeczypospolitej Polskiej postępowania 

przygotowawczego w sprawie o przestępstwo o charakterze terrorystycznym, 

handlu ludźmi, obrotu środkami odurzającymi, substancjami psychotropowymi 

lub ich prekursorami albo o inne ciężkie przestępstwo ujawniono, że sprawca 

działał lub następstwa jego czynu wystąpiły na terytorium innego państwa 

i zachodzi potrzeba wykonania czynności śledztwa na terytorium tego państwa 

lub z udziałem jego organu; 

2) 

prowadzone na terytorium Rzeczypospolitej Polskiej postępowanie przygo-

towawcze pozostaje w związku przedmiotowym lub podmiotowym z postę-

powaniem przygotowawczym o przestępstwo wymienione w pkt 1, prowa-

dzonym na terytorium innego państwa i zachodzi potrzeba wykonania więk-

szości czynności śledztwa w obu postępowaniach na terytorium Rzeczypo-

spolitej Polskiej. 

§ 2. Pracami zespołu polskiego kieruje polski prokurator. 

§ 3. W skład zespołu polskiego mogą wchodzić inni polscy prokuratorzy 

i przedstawiciele innych organów uprawnionych do prowadzenia śledztwa oraz 

funkcjonariusze właściwych organów państwa współpracującego, zwani dalej 

„funkcjonariuszami delegowanymi”. 

§ 4. Do 

czynności w postępowaniu przygotowawczym wykonywanych 

w ramach zespołu polskiego stosuje się przepisy prawa krajowego, z zastrzeżeniem 

§ 5–8 oraz art. 589e. 

§ 5. Funkcjonariusze delegowani mogą być obecni przy wszystkich 

czynnościach procesowych wykonywanych w ramach zespołu polskiego, chyba że 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 235/356 

w szczególnym wypadku, uzasadnionym potrzebą ochrony ważnego interesu Rzeczy-

pospolitej Polskiej lub praw jednostki, osoba kierująca tym zespołem zarządzi inaczej. 

§ 6. Za zgodą stron porozumienia o utworzeniu zespołu polskiego osoba 

kierująca 

tym zespołem może powierzyć funkcjonariuszowi delegowanemu 

wykonanie określonej czynności śledztwa, z wyłączeniem wydawania postanowień 

przewidzianych w niniejszym kodeksie. W takim wypadku w czynności uczestniczy 

polski członek zespołu i sporządza z niej protokół. 

§ 7. Jeżeli zachodzi potrzeba wykonania czynności śledztwa na terytorium 

państwa współpracującego, z wnioskiem o pomoc prawną zwraca się do właściwej 

instytucji lub organu funkcjonariusz delegowany przez to państwo. Do sporządzonych 

w wykonaniu tego wniosku protokołów stosuje się odpowiednio przepis art. 587. 

§ 8. W granicach określonych w porozumieniu o powołaniu zespołu polskiego 

przedstawicielowi instytucji międzynarodowej, o którym mowa w art. 589b § 4, 

przysługują uprawnienia określone w § 5.


## Art. 589d. {#kpk-art-589d}
§ 1. Prokurator lub przedstawiciel innego organu uprawnionego do 

prowadzenia śledztwa może być delegowany do zespołu na terytorium innego państwa 

współpracującego w wypadkach określonych przepisami państwa, na którego 

terytorium odbywa się współpraca zespołu. O delegowaniu decyduje odpowiednio 

Prokurator Generalny albo inny właściwy organ. 

§ 2. Członkowi zespołu, o którym mowa w § 1, będącemu polskim prokuratorem 

przysługują uprawnienia prokuratora państwa obcego określone w art. 588 § 1. 

Przepisu art. 613 § 1 nie stosuje się. 

§ 3. Instytucje i organy Rzeczypospolitej Polskiej, inne niż prokurator, o którym 

mowa w § 2, udzielają niezbędnej pomocy polskiemu członkowi zespołu, o którym 

mowa w § 1, w granicach i z zastosowaniem przepisów prawa krajowego.


## Art. 589e. {#kpk-art-589e}
§ 1. 

Informacje uzyskane przez członka zespołu w związku 

z udziałem w pracach zespołu, niedostępne w innym trybie dla państwa, które go 

delegowało, mogą być wykorzystane przez właściwy organ tego państwa także w celu: 

1) 

przeprowadzenia postępowania karnego we własnym zakresie – za zgodą 

państwa współpracującego, którego instytucja lub organ udzieliły informacji; 

2) 

zapobiegnięcia bezpośredniemu, poważnemu zagrożeniu dla bezpieczeństwa 

publicznego; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 236/356 

3) 

innym niż wymienione w pkt 1 i 2, jeżeli tak stanowi porozumienie o powołaniu 

zespołu. 

§ 2. Zgoda, o której mowa w § 1 pkt 1, może być cofnięta wyłącznie wtedy, gdy 

wykorzystanie informacji mogłoby zagrażać dobru postępowania przygotowawczego 

prowadzonego w państwie współpracującym, którego instytucja lub organ udzieliły 

informacji, oraz w wypadku, w którym państwo to mogłoby odmówić wzajemnej 

pomocy.


## Art. 589f. {#kpk-art-589f}
§ 1. Za szkodę wyrządzoną przez członka zespołu w związku 

z wykonywanymi czynnościami odpowiada państwo, które go delegowało, na 

zasadach określonych w przepisach państwa, na którego terytorium odbywała się 

współpraca zespołu. 

§ 2. Jeżeli szkoda wyrządzona innej osobie jest następstwem działania lub 

zaniechania członka zespołu delegowanego przez inne państwo współpracujące, 

kwotę pieniężną stanowiącą równowartość odszkodowania tymczasowo wypłaca 

poszkodowanemu właściwy organ państwa, na którego terytorium odbywała się 

współpraca zespołu. 

§ 3. W wypadku określonym w § 2 wypłacona kwota pieniężna podlega 

zwrotowi organowi, który ją tymczasowo wypłacił, na jego wniosek. 


# Rozdział 62
a 

Wystąpienie do państwa członkowskiego Unii Europejskiej o wykonanie 

postanowienia o zatrzymaniu dowodów lub mającego na celu zabezpieczenie 

mienia


## Art. 589g. {#kpk-art-589g}
§ 1. W razie ustalenia, że mogące stanowić dowód w sprawie rzeczy, 

korespondencja, przesyłki, wykazy połączeń telefonicznych lub innych przekazów 

informacji lub dane przechowywane w systemie informatycznym lub na nośniku, 

w tym korespondencja przesyłana pocztą elektroniczną, albo mienie podlegające 

zajęciu w celu zabezpieczenia wykonania postanowienia o przepadku znajdują się na 

terytorium innego państwa członkowskiego Unii Europejskiej, sąd właściwy do 

rozpoznania sprawy albo prokurator może wystąpić o wykonanie postanowienia o ich 

zatrzymaniu albo zabezpieczeniu bezpośrednio do właściwego organu sądowego tego 

państwa. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 237/356 

§ 2. Przekazując do wykonania postanowienie o zatrzymaniu dowodów, 

właściwy sąd lub prokurator występuje jednocześnie do właściwego organu sądowego 

państwa wykonania postanowienia z wnioskiem o ich wydanie. 

§ 3. Niezwłocznie po uprawomocnieniu się postanowienia o przepadku 

zabezpieczonego mienia, o którym mowa w § 1, właściwy sąd występuje do 

właściwego organu sądowego państwa wykonania postanowienia z wnioskiem 

o wykonanie tego przepadku. 

§ 4. (uchylony) 

§ 5. Do postanowienia, o którym mowa w § 1, dołącza się zaświadczenie 

zawierające wszystkie istotne informacje umożliwiające jego prawidłowe wykonanie. 

§ 6. Przekazywane dokumenty powinny zostać przetłumaczone na język 

urzędowy państwa wykonania postanowienia albo na inny język wskazany przez to 

państwo. 

§ 7. Przekazanie postanowienia oraz zaświadczenia, o którym mowa w § 5, 

może nastąpić również z wykorzystaniem urządzeń służących do automatycznego 

przesyłania danych, w sposób umożliwiający stwierdzenie autentyczności tych 

dokumentów. 

§ 8. W razie trudności w ustaleniu właściwego organu państwa wykonania 

postanowienia właściwy sąd albo prokurator może również zwracać się do właściwych 

jednostek organizacyjnych Europejskiej Sieci Sądowej. 

§ 9. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, wzór 

zaświadczenia, o którym mowa w § 5, mając na uwadze konieczność udostępnienia 

państwu wykonania postanowienia wszystkich niezbędnych informacji, w tym 

informacji o terminie, do którego ma 

trwać zatrzymanie dowodów albo 

zabezpieczenie mienia.


## Art. 589h. {#kpk-art-589h}
Wydane dowody zwraca się państwu wykonania postanowienia 

niezwłocznie po wykorzystaniu, jeżeli przy ich przekazaniu zastrzeżono zwrot lub gdy 

podlegają one zwrotowi pokrzywdzonemu lub innemu uprawnionemu podmiotowi, 

przebywającemu na terytorium tego państwa.


## Art. 589i. {#kpk-art-589i}
W razie uchylenia postanowienia o zatrzymaniu dowodów 

lub 

zabezpieczeniu mienia właściwy sąd albo prokurator o jego treści niezwłocznie 

zawiadamia właściwy organ państwa członkowskiego Unii Europejskiej. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 238/356


## Art. 589j. {#kpk-art-589j}
§ 1. Na postanowienie, o którym mowa w art. 589g § 1, wydane przez 

prokuratora, przysługuje zażalenie do sądu rejonowego, w którego okręgu prowadzi 

się postępowanie. Termin do wniesienia zażalenia biegnie od daty doręczenia 

postanowienia. 

§ 2. Przepis art. 589g § 6 stosuje się odpowiednio.


## Art. 589k. {#kpk-art-589k}
§ 1. Jeżeli według prawa państwa wykonania postanowienia państwo 

to ponosi odpowiedzialność za szkodę wyrządzoną w związku z wykonaniem 

postanowienia o zatrzymaniu dowodów lub mającego na celu zabezpieczenie mienia, 

wydanego przez polski sąd albo prokuratora, na wniosek właściwego organu tego 

państwa Skarb Państwa zwraca mu kwotę pieniężną stanowiącą równowartość 

wypłaconego odszkodowania. 

§ 2. Przepisu § 1 nie stosuje się, jeżeli szkoda jest następstwem wyłącznie 

działania lub zaniechania organu państwa wykonania postanowienia.


## Art. 589ka. {#kpk-art-589ka}
Przepisy niniejszego rozdziału w zakresie zatrzymania dowodów 

stosuje się do wystąpień do państw członkowskich Unii Europejskiej, w których nie 

ma zastosowania europejski nakaz dochodzeniowy. 


# Rozdział 62
b 

Wystąpienie państwa członkowskiego Unii Europejskiej o wykonanie orzeczenia 

o zatrzymaniu dowodów lub mającego na celu zabezpieczenie mienia


## Art. 589l. {#kpk-art-589l}
§ 1. Właściwy miejscowo sąd rejonowy albo prokurator wykonuje 

niezwłocznie wydane przez właściwy organ sądowy innego państwa członkowskiego 

Unii Europejskiej orzeczenie o zatrzymaniu mogących stanowić dowód w sprawie 

rzeczy, korespondencji, przesyłek, wykazów połączeń telefonicznych lub innych 

przekazów informacji lub danych przechowywanych w systemie informatycznym lub 

na nośniku, w tym korespondencji przesyłanej pocztą elektroniczną, albo orzeczenie 

o zajęciu mienia w celu zabezpieczenia wykonania orzeczenia o przepadku, jeżeli 

rzeczy te, korespondencja, przesyłki, wykazy, dane lub mienie znajdują się lub są 

przechowywane na terytorium Rzeczypospolitej Polskiej. 

§ 2. Jeżeli sąd albo prokurator, do którego zostało skierowane orzeczenie, nie jest 

właściwy do nadania mu biegu, przekazuje je właściwemu organowi i powiadamia 

o tym właściwy organ sądowy państwa członkowskiego Unii Europejskiej, który 

wystąpił z orzeczeniem. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 239/356 

§ 3. Jeżeli przepisy niniejszego 

rozdziału nie stanowią 

inaczej, przy 

wykonywaniu orzeczeń, o których mowa w § 1, stosuje się przepisy prawa polskiego.


## Art. 589m. {#kpk-art-589m}
§ 1. Można odmówić wykonania orzeczenia o zatrzymaniu 

dowodów, o którym mowa w art. 589l § 1, jeżeli: 

1) 

czyn, w związku z którym wydano to orzeczenie, nie stanowi przestępstwa 

według prawa polskiego, chyba że zgodnie z prawem państwa wydania 

orzeczenia jest to przestępstwo wymienione w art. 607w pkt 1–33, zagrożone 

karą pozbawienia wolności, której górna granica wynosi co najmniej 3 lata, lub 

innym środkiem polegającym na pozbawieniu wolności co najmniej w tym 

samym wymiarze; 

2) 

dowody, których dotyczy orzeczenie, nie mogą być zajęte z przyczyn 

faktycznych, w szczególności z uwagi na ich utratę, zniszczenie lub niemożność 

odnalezienia; 

3) 

do orzeczenia o zatrzymaniu dowodów nie dołączono zaświadczenia 

zawierającego wszystkie istotne informacje umożliwiające jego prawidłowe 

wykonanie albo zaświadczenie to jest niekompletne lub oczywiście nie 

odpowiada treści orzeczenia; 

4) 

z treści zaświadczenia, określonego w pkt 3, w oczywistym stopniu wynika, że 

przekazane do wykonania orzeczenie dotyczy tego samego czynu tej samej 

osoby, co do którego postępowanie karne zostało prawomocnie zakończone; 

5) wykonanie orzeczenia nie jest możliwe z powodu odmowy przedstawienia 

korespondencji i dokumentów na podstawie art. 582 § 2. 

§ 2. Można odmówić wykonania orzeczenia mającego na celu zabezpieczenie 

mienia, o którym mowa w art. 589l § 1: 

1) 

jeżeli według prawa polskiego w sprawie o przestępstwo, w związku z którym 

wydano 

to orzeczenie, zabezpieczenie wykonania przepadku byłoby 

niedopuszczalne, chyba że zgodnie z prawem państwa wydania orzeczenia jest 

to przestępstwo wymienione w art. 607w pkt 1–33, zagrożone karą pozbawienia 

wolności, której górna granica wynosi co najmniej 3 lata, lub innym środkiem 

polegającym na pozbawieniu wolności co najmniej w tym samym wymiarze; 

2) w wypadkach określonych w § 1 pkt 2–4. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 240/356 

§ 3. Przepisów § 1 pkt 1 oraz § 2 pkt 1 nie stosuje się, jeżeli czyn nie stanowi 

przestępstwa z powodu braku lub odmiennego uregulowania w prawie polskim 

odpowiednich opłat, podatków, ceł lub zasad obrotu dewizowego. 

§ 4. W wypadku określonym w § 1 pkt 2, właściwy sąd albo prokurator, przed 

wydaniem postanowienia w przedmiocie wykonania orzeczenia o zatrzymaniu 

dowodów lub mającego na celu zabezpieczenie mienia, konsultuje się z organem, 

który je wydał, dla uzyskania wszystkich istotnych informacji, umożliwiających 

odnalezienie tych dowodów albo mienia. Jeżeli uzyskane informacje nie przyczyniły 

się do odnalezienia tych dowodów albo mienia, sąd lub prokurator powiadamia 

niezwłocznie właściwy organ sądowy państwa wydania orzeczenia o niemożności 

wykonania orzeczenia. 

§ 5. W wypadku, o którym mowa w § 1 pkt 3, właściwy sąd albo prokurator 

może wyznaczyć organowi, który wydał orzeczenie, termin do przekazania 

zaświadczenia, określonego w § 1 pkt 3, jego uzupełnienia lub sprostowania. 

§ 6. W razie niedotrzymania terminu, o którym mowa w § 5, postanowienie 

w przedmiocie wykonania orzeczenia wydaje się w oparciu o informacje przekazane 

wcześniej.


## Art. 589n. {#kpk-art-589n}
§ 1. 

Postanowienie w przedmiocie wykonania 

orzeczenia 

o zatrzymaniu dowodów lub mające na celu zabezpieczenie mienia, o których mowa 

w art. 589l § 1, właściwy sąd albo prokurator wydaje niezwłocznie, w miarę możli-

wości w ciągu 24 godzin od otrzymania orzeczenia. 

§ 2. Postanowienie, o którym mowa w § 1, doręcza się wraz z pouczeniem 

o uprawnieniach wynikających z przepisów państwa wydania orzeczenia, o którym 

mowa w art. 589l § 1. 

§ 3. Na postanowienie, o którym mowa w § 1, przysługuje zażalenie osobom, 

których prawa zostały naruszone. Osobom tym przysługuje także zażalenie na 

czynności związane z zatrzymaniem dowodów lub zabezpieczeniem mienia, co nie 

narusza uprawnień skarżącego wynikających z przepisów państwa wydania 

orzeczenia. W zażaleniu na czynność skarżący może domagać się wyłącznie zbadania 

prawidłowości jej przeprowadzenia. 

§ 4. O wniesieniu zażalenia, jak również o treści rozstrzygnięcia zapadłego 

w wyniku jego rozpoznania, należy niezwłocznie powiadomić właściwy organ 

sądowy państwa wydania orzeczenia. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 241/356 

§ 5. Przepis art. 589g § 6 stosuje się odpowiednio.


## Art. 589o. {#kpk-art-589o}
Wydając postanowienie o wykonaniu orzeczenia o zatrzymaniu 

dowodów lub mające na celu zabezpieczenie mienia, właściwy sąd albo prokurator 

może jednocześnie wstrzymać jego wykonanie, jeżeli: 

1) wykonanie orzeczenia mogłoby utrudnić inne, toczące się postępowanie karne – 

na czas niezbędny dla zabezpieczenia prawidłowego toku tego postępowania; 

2) 

dowód albo mienie, których dotyczy orzeczenie, zostały wcześniej zatrzymane 

albo zajęte dla potrzeb innego toczącego się postępowania karnego – do czasu 

zwolnienia spod zatrzymania albo zajęcia.


## Art. 589p. {#kpk-art-589p}
§ 1. O treści postanowienia w przedmiocie wykonania orzeczenia 

o zatrzymaniu dowodów lub mającego na celu zabezpieczenie mienia powiadamia się 

niezwłocznie, w miarę możliwości w ciągu 24 godzin od otrzymania orzeczenia, 

właściwy organ sądowy państwa wydania tego orzeczenia. Powiadomienie to może 

być przekazane również przy użyciu urządzeń służących do automatycznego 

przesyłania danych, w sposób umożliwiający 

stwierdzenie 

autentyczności 

przekazanych dokumentów. 

§ 2. W wypadkach, o których mowa w art. 589o, należy 

także wskazać 

przyczyny wstrzymania wykonania postanowienia oraz, jeżeli jest to możliwe, jego 

przewidywany okres. 

§ 3. Przepis § 1 stosuje się odpowiednio w razie ustania przyczyn wstrzymania 

wykonania postanowienia określonego w art. 589o. W takim wypadku należy 

poinformować właściwy organ sądowy państwa wydania orzeczenia o zatrzymaniu 

lub zabezpieczeniu dowodów albo mienia dla potrzeb innego postępowania, lub 

podjętych działaniach zmierzających do wykonania orzeczenia.


## Art. 589r. {#kpk-art-589r}
§ 1. Wykonując orzeczenie o zatrzymaniu dowodów lub mające na 

celu zabezpieczenie mienia, należy uczynić zadość życzeniu organu, który wydał to 

orzeczenie, aby przy dokonaniu czynności zastosowano szczególny tryb postępowania 

lub szczególną formę, jeżeli nie jest to sprzeczne z zasadami porządku prawnego 

Rzeczypospolitej Polskiej. 

§ 2. Protokół zatrzymania dowodów lub zajęcia mienia należy niezwłocznie 

przekazać właściwemu organowi sądowemu państwa wydania orzeczenia. Przepis 

art. 589p § 1 zdanie drugie stosuje się odpowiednio. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 242/356


## Art. 589s. {#kpk-art-589s}
§ 1. Zatrzymanie dowodów oraz zajęcie mienia w celu zabezpieczenia 

wykonania orzeczenia o przepadku trwa do czasu rozstrzygnięcia w przedmiocie 

wystąpienia właściwego organu sądowego państwa wydania orzeczenia, odpowiednio 

o wydanie dowodów albo o wykonanie wniosku o wykonanie prawomocnego 

orzeczenia o przepadku. 

§ 2. Przez wzgląd na okoliczności sprawy właściwy sąd albo prokurator może 

jednak, po konsultacji z właściwym organem sądowym państwa wydania orzeczenia, 

wyznaczyć 

temu organowi nieprzekraczalny 

termin do przekazania żądania 

określonego w § 1, po upływie którego może nastąpić zwolnienie spod zatrzymania 

albo zajęcia. 

§ 3. Przed upływem terminu, o którym mowa w § 2, właściwy sąd albo 

prokurator informuje właściwy organ sądowy państwa wykonania orzeczenia 

o zamiarze zwolnienia spod zatrzymania albo zajęcia, umożliwiając mu zgłoszenie 

stanowiska na piśmie. Jeżeli organ ten nie przedstawi argumentów dostatecznie 

uzasadniających dalsze zatrzymanie albo zajęcie, właściwy sąd albo prokurator 

wydaje postanowienie o zwolnieniu spod zatrzymania albo zajęcia. [Odpis 

postanowienia doręcza się osobom zainteresowanym.] <Kopię postanowienia 

doręcza się osobom zainteresowanym.> 

§ 4. Postanowienie o zwolnieniu spod zatrzymania albo zajęcia wydaje się także 

wtedy, gdy właściwy organ sądowy państwa wydania orzeczenia zawiadomi o jego 

uchyleniu. Przepis § 3 zdanie trzecie stosuje się.


## Art. 589t. {#kpk-art-589t}
(uchylony)


## Art. 589u. {#kpk-art-589u}
§ 1. Jeżeli Skarb Państwa ponosi odpowiedzialność za szkodę 

wyrządzoną w związku z wykonaniem orzeczenia o zatrzymaniu dowodów albo 

mającego na celu zabezpieczenie mienia, wydanego przez organ sądowy państwa 

członkowskiego Unii Europejskiej, Skarb Państwa występuje do właściwego organu 

tego państwa o zwrot kwoty pieniężnej stanowiącej równowartość wypłaconego 

odszkodowania. 

§ 2. Przepisu § 1 nie stosuje się, jeżeli szkoda jest następstwem wyłącznie 

działania lub zaniechania organu polskiego. 

2025-09-11 

Zmiana w zd. 
trzecim w § 3 w 
art. 589s wejdzie 
w życie z dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 
 
 
 
 

©Kancelaria Sejmu 

s. 243/356


## Art. 589v. {#kpk-art-589v}
Przepisy niniejszego rozdziału w zakresie zatrzymania dowodów 

stosuje się do orzeczeń organów państw członkowskich Unii Europejskiej, w których 

nie ma zastosowania europejski nakaz dochodzeniowy. 


# Rozdział 62
c 

Wystąpienie do państwa członkowskiego Unii Europejskiej o przeprowadzenie 

czynności dochodzeniowych na podstawie europejskiego nakazu 

dochodzeniowego


## Art. 589w. {#kpk-art-589w}
§ 1. W razie konieczności przeprowadzenia lub uzyskania dowodu, 

który znajduje się lub może zostać przeprowadzony na terytorium innego państwa 

członkowskiego Unii Europejskiej, zwanego w niniejszym rozdziale „państwem 

wykonania orzeczenia”, sąd, przed którym sprawa się toczy, albo prokurator 

prowadzący postępowanie przygotowawcze może wydać z urzędu lub na wniosek 

strony, obrońcy lub pełnomocnika europejski nakaz dochodzeniowy, zwany w 

niniejszym rozdziale „END”, chyba że END nie ma w tym państwie zastosowania. 

§ 2. W przypadku prowadzenia przez Policję lub organy, o których mowa w art. 

312, dochodzenia lub postępowania sprawdzającego, o którym mowa w art. 307, albo 

w przypadku prowadzenia postępowania przygotowawczego przez organy, o których 

mowa w art. 133 § 1 i art. 134 § 1 Kodeksu karnego skarbowego, END może wydać 

także prowadzący postępowanie. Wydanie END wymaga zatwierdzenia przez 

prokuratora. 

§ 3. END można wydać także w celu zabezpieczenia śladów i dowodów 

przestępstwa przed ich utratą, zniekształceniem lub zniszczeniem. 

§ 4. Postanowienie o wydaniu END dotyczącego kontroli i utrwalania treści 

rozmów telefonicznych oraz utrwalania przy użyciu środków technicznych treści 

innych rozmów lub przekazów informacji, w tym korespondencji przesyłanej pocztą 

elektroniczną, zastępuje postanowienie, o którym mowa w art. 237 § 1. Przepisy 

rozdziału 26 stosuje się odpowiednio. 

§ 5. Postanowienie o wydaniu END dotyczącego dowodu, którego dopuszczenie, 

uzyskanie lub przeprowadzenie wymaga wydania postanowienia, zastępuje to 

postanowienie. Przepisy dotyczące poszczególnych czynności i dowodów stosuje się 

odpowiednio. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 244/356 

§ 6. Jeżeli END został wydany w związku z czynnościami, o których mowa w § 

4, jest on przekazywany do tego państwa wykonania orzeczenia, w którym znajduje 

się albo będzie się znajdować osoba, której END dotyczy. 

§ 7. W przypadku prowadzenia czynności operacyjno-rozpoznawczych na 

podstawie odrębnych przepisów END wydaje organ prowadzący takie czynności po 

uprzednim uzgodnieniu z organem państwa wykonania orzeczenia czasu ich trwania 

oraz warunków ich wykonywania. Wydanie END wymaga zatwierdzenia przez 

prokuratora właściwego na podstawie odrębnych przepisów, chyba że dopuszczenie, 

uzyskanie lub przeprowadzenie dowodu jest zastrzeżone do właściwości sądu. 

Wówczas wydanie END wymaga zatwierdzenia przez sąd właściwy na podstawie 

odrębnych przepisów.


## Art. 589x. {#kpk-art-589x}
Wydanie END jest niedopuszczalne, jeżeli: 

nie wymaga tego interes wymiaru sprawiedliwości; 

prawo polskie nie dopuszcza przeprowadzenia lub uzyskania danego dowodu. 

1) 

2)


## Art. 589y. {#kpk-art-589y}
§ 1. END zawiera: 

1) 

oznaczenie organu wydającego END i zatwierdzającego END, ze wskazaniem 

ich adresów, numerów telefonów, telefaksów i adresów poczty elektronicznej; 

2) 

3) 

datę oraz wskazanie miejsca wydania END; 

określenie żądanej czynności dochodzeniowej podlegającej END lub dowodu, 

który należy uzyskać, lub okoliczności, jakie mają zostać ustalone w wyniku 

czynności dochodzeniowej; 

4) 

dostępne dane określające tożsamość i obywatelstwo osoby, której dotyczy END, 

a także adres zamieszkania lub inny adres, w tym adres zakładu karnego, jeżeli 

ta osoba w nim przebywa; 

5) 

sygnaturę akt i wskazanie rodzaju postępowania, w związku z którym END 

został wydany; 

6) 

przytoczenie opisu i kwalifikacji prawnej czynu będącego przedmiotem 

postępowania; 

7) 

zwięzły opis stanu faktycznego sprawy. 

§ 2. END zawiera odwołanie do wcześniej wydanego END, jeżeli jest z nim 

związany, wraz z datą jego wydania, oznaczeniem organu, do którego został 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 245/356 

przekazany, oraz sygnaturą akt nadaną przez organ wydający END i państwo 

wykonania orzeczenia. 

§ 3. Jeżeli END jest wydany w celu zabezpieczenia śladów i dowodów 

przestępstwa przed ich utratą, zniekształceniem lub zniszczeniem, zawiera także 

informację o tym, czy ślad lub dowód ma zostać przekazany organowi wydającemu 

END, czy ma pozostać w państwie wykonania orzeczenia. W przypadku gdy ślad lub 

dowód ma pozostać w państwie wykonania orzeczenia organ wydający END określa 

termin obowiązywania zabezpieczenia. 

§ 4. END powinien zostać przetłumaczony na język urzędowy państwa 

wykonania orzeczenia albo na inny język wskazany przez to państwo. 

§ 5. Przekazanie END może nastąpić również z wykorzystaniem urządzeń 

służących do automatycznego przesyłania danych, w sposób umożliwiający 

stwierdzenie autentyczności tego dokumentu. 

§ 6. Minister Sprawiedliwości określi, w drodze rozporządzenia, wzór 

formularza END, mając na uwadze konieczność udostępnienia państwu wykonania 

orzeczenia danych niezbędnych do podjęcia prawidłowej decyzji w przedmiocie 

wykonania END.


## Art. 589z. {#kpk-art-589z}
§ 1. Jeżeli END dotyczy czasowego wydania do Rzeczypospolitej 

Polskiej osoby pozbawionej wolności na terytorium państwa wykonania orzeczenia w 

celu przeprowadzenia czynności dochodzeniowej, przepis art. 589a stosuje się 

odpowiednio. Sąd lub prokurator zarządza zwolnienie osoby, jeżeli państwo 

wykonania orzeczenia o to wystąpi. 

§ 2. Wydana czasowo osoba pozbawiona wolności, o której mowa w § 1, nie 

może być ścigana ani zatrzymana, ani tymczasowo aresztowana z powodu 

przestępstwa popełnionego przed przekroczeniem polskiej granicy państwowej, 

niewskazanego w END. Nie może być także w stosunku do takiej osoby wykonana 

kara orzeczona za takie przestępstwo. 

§ 3. Zakazów określonych w § 2 nie stosuje się wobec osoby, która mogąc 

opuścić terytorium Rzeczypospolitej Polskiej, znajduje się na nim po upływie 15 dni 

od dnia otrzymania informacji od sądu lub prokuratora, że jej obecność stała się zbędna 

dla postępowania karnego, albo powróci na terytorium Rzeczypospolitej Polskiej po 

upływie tego terminu. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 246/356 

§ 4. Przed wydaniem END dotyczącego czasowego wydania osoby pozbawionej 

wolności na terytorium Rzeczypospolitej Polskiej do państwa wykonania orzeczenia 

organ wydający END wysłuchuje tej osoby. 

§ 5. Jeżeli END dotyczy czasowego wydania osoby pozbawionej wolności na 

terytorium Rzeczypospolitej Polskiej do państwa wykonania orzeczenia w celu 

przeprowadzenia czynności dochodzeniowej, okres faktycznego pozbawienia 

wolności tej osoby w tym państwie zalicza się na poczet orzeczonej lub wykonywanej 

w Rzeczypospolitej Polskiej kary pozbawienia wolności.


## Art. 589za. {#kpk-art-589za}
§ 1. Organ wydający END może zażądać, aby przy przeprowadzeniu 

dowodu był obecny jego przedstawiciel. 

§ 2. Jeżeli według prawa państwa wykonania orzeczenia państwo to poniosło 

odpowiedzialność za szkodę wyrządzoną przez przedstawiciela, o którym mowa w § 

1, w związku z wykonaniem END wydanego lub zatwierdzonego przez sąd albo 

prokuratora, na wniosek właściwego organu tego państwa Skarb Państwa zwraca mu 

kwotę pieniężną stanowiącą równowartość wypłaconego odszkodowania.


## Art. 589zb. {#kpk-art-589zb}
§ 1. END jest przekazywany bezpośrednio właściwemu organowi 

państwa wykonania orzeczenia. END może być przekazywany również za 

pośrednictwem sądów okręgowych lub Ministra Sprawiedliwości albo prokuratora 

okręgowego lub Prokuratora Krajowego. 

§ 2. W razie trudności w ustaleniu właściwego sądu lub innego organu państwa 

wykonania orzeczenia sąd lub prokurator może zwracać się do właściwych jednostek 

organizacyjnych Europejskiej Sieci Sądowej. 

§ 3. Jeżeli wykonanie END ma nastąpić przez przeprowadzenie innej czynności 

dochodzeniowej niż czynność określona w orzeczeniu, organ wydający END może go 

zmienić, uzupełnić lub cofnąć. 

§ 4. Jeżeli wykonanie END wiązałoby się ze znacznymi kosztami i jeżeli nie 

zawarto porozumienia z państwem wykonania orzeczenia w sprawie podziału tych 

kosztów, organ wydający END może zdecydować o całkowitym lub częściowym 

wycofaniu END albo o poniesieniu kosztów przez ten organ. 

§ 5. Koszty związane z czasowym wydaniem osoby pozbawionej wolności 

ponosi organ wydający END. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 247/356


## Art. 589zc. {#kpk-art-589zc}
§ 1. Na postanowienie w przedmiocie wydania END zażalenie nie 

przysługuje, chyba że przepis szczególny dotyczący czynności wskazanej w END 

stanowi inaczej. 

§ 2. O wniesieniu zażalenia oraz o treści rozstrzygnięcia zapadłego w wyniku 

jego rozpoznania należy niezwłocznie powiadomić właściwy organ państwa 

wykonania orzeczenia.


## Art. 589zd. {#kpk-art-589zd}
§ 1. W związku z kontrolą i utrwalaniem treści rozmów 

telefonicznych zarządzonymi lub zatwierdzonymi na podstawie art. 237 § 1 i 2 w 

stosunku do osoby znajdującej się na terytorium innego państwa członkowskiego Unii 

Europejskiej, jeżeli nie zachodzi potrzeba wydania END, prokurator, Policja lub 

organ, o którym mowa w art. 312, powiadamia właściwy organ tego państwa o 

zamiarze przeprowadzenia tych czynności, ich przeprowadzaniu albo wykonaniu 

w zależności od tego, kiedy dowiedział się, że osoba, której czynność dotyczy, 

przebywa na terytorium tego państwa członkowskiego. 

§ 2. Do powiadomienia stosuje się odpowiednio przepis art. 589y § 4. 

§ 3. Powiadomienie zawiera informacje dotyczące: 

1) 

2) 

organu, który zarządził kontrolę i utrwalanie treści rozmów telefonicznych; 

kontroli i utrwalania treści rozmów telefonicznych, w tym okresu, na jaki ją 

zarządzono; 

3) 

osoby, której dotyczy kontrola i utrwalanie treści rozmów telefonicznych. 

§ 4. Minister Sprawiedliwości określi, w drodze rozporządzenia, wzór 

formularza powiadomienia, o którym mowa w § 1, mając na uwadze udostępnienie 

państwu członkowskiemu Unii Europejskiej danych niezbędnych do przekazania 

informacji w przedmiocie możliwości przeprowadzenia czynności na terytorium tego 

państwa oraz wykorzystania uzyskanych w ich wyniku dowodów w postępowaniu 

karnym. 


# Rozdział 62
d 

Wystąpienie państwa członkowskiego Unii Europejskiej o przeprowadzenie 

czynności dochodzeniowych na podstawie europejskiego nakazu 

dochodzeniowego


## Art. 589ze. {#kpk-art-589ze}
§ 1. W razie wystąpienia państwa członkowskiego Unii Europejskiej, 

zwanego w niniejszym rozdziale „państwem wydania orzeczenia”, o wykonanie 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 248/356 

europejskiego nakazu dochodzeniowego, zwanego w niniejszym rozdziale „END”, 

postanowienie w przedmiocie jego wykonania wydaje prokurator albo sąd rejonowy, 

w którego okręgu znajduje się lub może zostać przeprowadzony dowód. 

§ 2. Jeżeli dopuszczenie, uzyskanie lub przeprowadzenie dowodu jest 

zastrzeżone do właściwości sądu albo uzależnione od zarządzenia tego sądu, 

postanowienie, o którym mowa w § 1, wydaje ten sąd. 

§ 3. Sąd okręgowy jest właściwy do wydania postanowienia w przedmiocie 

wykonania END dotyczącego czasowego wydania osoby pozbawionej wolności do 

państwa wydania orzeczenia w celu przeprowadzenia w tym państwie czynności 

dochodzeniowej. Przed wydaniem postanowienia należy wysłuchać osoby, której 

dotyczy END. 

§ 4. Sąd okręgowy jest właściwy do wydania postanowienia w przedmiocie 

wykonania END dotyczącego czasowego wydania osoby pozbawionej wolności do 

Rzeczypospolitej Polskiej w celu przeprowadzenia czynności dochodzeniowej. 

§ 5. Jeżeli sąd lub prokurator, do którego został skierowany END, nie jest 

właściwy do nadania mu biegu, przekazuje go właściwemu sądowi lub prokuratorowi 

i powiadamia o tym właściwy sąd lub inny organ państwa wydania orzeczenia, zwane 

w niniejszym rozdziale „organem wydającym END”. 

§ 6. Jeżeli END został wydany przez nieuprawniony organ państwa wydania 

orzeczenia, zwraca się go bez wykonania, informując ten organ o przyczynie zwrotu. 

§ 7. Na postanowienie o wykonaniu END zażalenie nie przysługuje, chyba że 

przepis szczególny dotyczący postanowienia o wykonaniu czynności tożsamej z 

czynnością wskazaną w END stanowi inaczej. W zażaleniu na czynność skarżący 

może domagać się wyłącznie zbadania zgodności postanowienia o wykonaniu END z 

prawem polskim i prawidłowości jej przeprowadzenia. 

§ 8. O wniesieniu zażalenia, jak również o treści rozstrzygnięcia zapadłego w 

wyniku jego rozpoznania należy niezwłocznie powiadomić organ wydający END. 

§ 9. Jeżeli przepis szczególny uzależnia ujawnienie informacji od wystąpienia 

przez sąd lub prokuratora z żądaniem ich ujawnienia w związku z toczącym się 

postępowaniem o przestępstwo 

lub przestępstwo skarbowe, END wraz z 

prawomocnym postanowieniem sądu lub prokuratora o jego wykonaniu zastępuje 

takie żądanie. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 249/356 

§ 10. Postanowienie o wykonaniu END, który dotyczy kontroli i utrwalania treści 

rozmów telefonicznych oraz utrwalania przy użyciu środków technicznych treści 

innych rozmów lub przekazów informacji, w tym korespondencji przesyłanej pocztą 

elektroniczną, zastępuje postanowienie, o którym mowa w art. 237 § 1. Przepisy art. 

237 § 3–7, art. 238 § 1 i 2, art. 239 § 1 i art. 241 stosuje się odpowiednio.


## Art. 589zf. {#kpk-art-589zf}
§ 1. Jeżeli END dotyczy czasowego wydania do Rzeczypospolitej 

Polskiej osoby pozbawionej wolności w celu przeprowadzenia czynności 

dochodzeniowej, przepis art. 589a stosuje się odpowiednio. Sąd lub prokurator 

zarządza zwolnienie osoby, jeżeli państwo wydania orzeczenia o to wystąpi. Sąd albo 

prokurator informuje organ wydający END o faktycznym okresie pozbawienia 

wolności tej osoby w Rzeczypospolitej Polskiej. 

§ 2. Wydana czasowo osoba pozbawiona wolności, o której mowa w § 1, nie 

może być ścigana ani zatrzymana, ani tymczasowo aresztowana z powodu 

przestępstwa popełnionego przed przekroczeniem polskiej granicy państwowej, 

niewskazanego w END. Nie może być także w stosunku do takiej osoby wykonana 

kara orzeczona za takie przestępstwo. 

§ 3. Zakazów określonych w § 2 nie stosuje się wobec osoby, która mogąc 

opuścić terytorium Rzeczypospolitej Polskiej, znajduje się na nim po upływie 15 dni 

od dnia otrzymania informacji sądu lub prokuratora, że jej obecność stała się zbędna 

dla postępowania karnego, albo powróci na terytorium Rzeczypospolitej Polskiej po 

upływie tego terminu. 

§ 4. Jeżeli END dotyczy czasowego wydania osoby pozbawionej wolności do 

państwa wydania orzeczenia w celu przeprowadzenia czynności dochodzeniowej, 

okres faktycznego pozbawienia wolności tej osoby w tym państwie zalicza się na 

poczet orzeczonej lub wykonywanej w Rzeczypospolitej Polskiej kary pozbawienia 

wolności.


## Art. 589zg. {#kpk-art-589zg}
§ 1. Sąd lub prokurator orzeka w przedmiocie wykonania END 

niezwłocznie, nie później jednak niż w terminie 30 dni, licząc od dnia jego otrzymania. 

§ 2. Jeżeli termin określony w § 1 nie może być dotrzymany, orzeczenie w 

przedmiocie wykonania END powinno zostać wydane w terminie kolejnych 30 dni, 

licząc od dnia upływu tego terminu. O opóźnieniu należy powiadomić organ wydający 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 250/356 

END, podając przyczynę opóźnienia oraz przewidywany termin wydania orzeczenia 

w przedmiocie wykonania END.


## Art. 589zh. {#kpk-art-589zh}
§ 1. Jeżeli dowód, którego dotyczy END, nie został jeszcze 

przeprowadzony, sąd lub prokurator przeprowadza ten dowód niezwłocznie po 

wydaniu postanowienia o wykonaniu END, nie później jednak niż w terminie 90 dni, 

licząc od dnia wydania tego postanowienia. Jeżeli organ wydający END określił 

termin do przeprowadzenia dowodu, sąd lub prokurator w miarę możliwości 

uwzględnia ten termin. 

§ 2. Jeżeli termin określony w § 1 nie może być dotrzymany, o opóźnieniu należy 

powiadomić organ wydający END, podając przyczynę opóźnienia oraz przewidywany 

termin przeprowadzenia dowodu.


## Art. 589zi. {#kpk-art-589zi}
§ 1. Jeżeli przepisy niniejszego rozdziału nie stanowią inaczej, przy 

wykonywaniu END stosuje się przepisy prawa polskiego. Należy jednak uczynić 

zadość życzeniu organu wydającego END, aby przy dokonaniu czynności 

zastosowano szczególny tryb postępowania lub szczególną formę, jeżeli nie jest to 

sprzeczne z zasadami porządku prawnego Rzeczypospolitej Polskiej. 

§ 2. Jeżeli czynność dochodzeniowa określona w END nie jest przewidziana 

przez prawo polskie lub byłaby niedopuszczalna w podobnej sprawie krajowej, sąd 

lub prokurator informuje o tym organ wydający END, wskazując termin do zmiany, 

uzupełnienia lub cofnięcia END oraz określając możliwą do przeprowadzenia 

zastępczą czynność dochodzeniową zgodną z celem END. Po upływie terminu sąd lub 

prokurator postanawia o wykonaniu zastępczej czynności dochodzeniowej. Jeżeli 

zastępczej czynności nie da się określić, sąd lub prokurator odmawia wykonania END. 

§ 3. Zastępczej czynności dochodzeniowej nie przeprowadza się, jeżeli END 

dotyczy: 

1) 

2) 

3) 

4) 

dowodów już znajdujących się w posiadaniu sądu lub prokuratora; 

informacji uzyskanych z rejestrów i baz danych dostępnych dla sądu lub 

prokuratora wykonującego END; 

przesłuchania osoby na terytorium Rzeczypospolitej Polskiej; 

dowodu, którego dopuszczenie, uzyskanie ani przeprowadzenie nie wymaga 

wydania postanowienia; 

5) 

identyfikacji abonenta telefonu lub adresu IP. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 251/356 

§ 4. W przypadkach, o których mowa w § 3, przeprowadza się czynność 

wskazaną w END. 

§ 5. Jeżeli uzyskanie dowodu określonego w END jest możliwe przez 

przeprowadzenie zastępczej czynności dochodzeniowej, innej niż wskazana w tym 

orzeczeniu i mniej dolegliwej dla osoby, której END dotyczy, sąd lub prokurator 

informuje o tym organ wydający END, wskazując termin do zmiany, uzupełnienia lub 

cofnięcia END. Po upływie terminu sąd lub prokurator określa w postanowieniu 

przeprowadzenie zastępczej czynności dochodzeniowej. 

§ 6. Jeżeli END zawiera wniosek o przeprowadzenie czynności operacyjno-

rozpoznawczych, w zakresie tego wniosku odpowiednie służby polskie i służby 

państwa wydania orzeczenia uzgadniają czas trwania i warunki wykonywania 

czynności. Można odmówić wykonania END, który nie zawiera informacji o 

uzgodnieniu, a organ wydający END nie uzupełni tej informacji w terminie 

wskazanym przez sąd lub prokuratora. Odmawia się wykonania END, jeżeli 

wykonanie czynności w nim określonych nie byłoby dopuszczalne w podobnej 

sprawie krajowej. 

§ 7. Do czasu otrzymania informacji lub upływu terminu, o których mowa w § 6, 

termin określony w art. 589zg § 1 nie biegnie.


## Art. 589zj. {#kpk-art-589zj}
§ 1. Odmawia się wykonania END, jeżeli: 

1) 

sąd lub prokurator nie uzyskał wymaganego zezwolenia umożliwiającego 

przeprowadzenie czynności z udziałem osoby wskazanej w END; 

2) w stosunku do osoby ściganej zapadło w państwie członkowskim Unii 

Europejskiej prawomocne orzeczenie co do tych samych czynów, które zostały 

wskazane w END, oraz, w przypadku skazania za te same czyny, osoba ścigana 

odbywa karę lub ją odbyła albo kara nie może być wykonana według prawa 

państwa, w którym zapadł wyrok skazujący; 

3) wykonanie END mogłoby narazić na niebezpieczeństwo funkcjonariusza przy 

wykonywaniu czynności operacyjno- 

-rozpoznawczych oraz osobę udzielającą mu pomocy w zakresie tych czynności; 

4) END dotyczy przesłuchania na okoliczność objętą bezwzględnym zakazem 

przesłuchania; 

5) wykonanie END naruszyłoby wolności i prawa człowieka i obywatela; 

6) 

żądana czynność zagrażałaby bezpieczeństwu narodowemu; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 252/356 

7) END dotyczy czasowego wydania osoby pozbawionej wolności do państwa 

wydania orzeczenia, a jego wykonanie skutkowałoby przedłużeniem okresu 

pozbawienia wolności tej osoby. 

§ 2. Można odmówić wykonania END, jeżeli: 

1) 

czyn będący podstawą wydania END, inny niż wymieniony w art. 607w, nie 

stanowi przestępstwa według prawa polskiego; 

2) 

czyn będący podstawą wydania END według prawa polskiego został popełniony 

w całości lub w części na terytorium Rzeczypospolitej Polskiej lub na polskim 

statku wodnym lub powietrznym i nie stanowi przestępstwa według prawa 

polskiego; 

3) wykonanie END wiązałoby się z ujawnieniem 

informacji niejawnych 

uzyskanych w toku czynności operacyjno- 

-rozpoznawczych, jak również związanych z prowadzeniem tych czynności; 

4) według prawa polskiego czynność dochodzeniowa, której dotyczy END, nie 

może być przeprowadzona w sprawie o przestępstwo będące podstawą jego 

wydania; 

5) według prawa polskiego czynność dochodzeniowa, której dotyczy END, nie 

może być przeprowadzona w postępowaniu, w którym został on wydany; 

6) END dotyczy czasowego wydania osoby pozbawionej wolności do państwa 

wydania orzeczenia albo do Rzeczypospolitej Polskiej, a osoba ta nie wyraża na 

to zgody; 

7) END 

dotyczy 

przesłuchania 

przy 

użyciu 

urządzeń 

technicznych 

umożliwiających przeprowadzenie tej czynności na odległość z jednoczesnym 

bezpośrednim przekazem obrazu i dźwięku, a oskarżony, który ma zostać 

przesłuchany, nie wyraża na to zgody; 

8) END dotyczy przesłuchania osób, o których mowa w art. 179 § 1 lub art. 180 § 

1 i 2, co do okoliczności określonych w tych przepisach. 

§ 3. Przepisów § 2 pkt 1 i 2 nie stosuje się, jeżeli czyn nie stanowi przestępstwa 

z powodu braku lub odmiennego uregulowania w prawie polskim odpowiednich opłat, 

podatków, ceł lub zasad obrotu dewizowego. 

§ 4. W przypadku określonym w § 2 pkt 8 sąd, działając z urzędu lub na wniosek 

prokuratora, orzeka w przedmiocie zwolnienia tych osób z zachowania tajemnicy. 

Przepisy art. 179 i art. 180 § 1–4 stosuje się. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 253/356 

§ 5. Przed wydaniem postanowienia o odmowie wykonania END z przyczyn 

określonych w § 1 pkt 1–6 lub § 2 pkt 2, 3 i 8 sąd lub prokurator konsultuje się z 

organem wydającym END w celu umożliwienia mu zmiany lub uzupełnienia END. 

§ 6. Nie można odmówić wykonania END z przyczyn określonych w § 2 pkt 1 i 

4, jeżeli dotyczy on czynności dochodzeniowych określonych w art. 589zi § 3.


## Art. 589zk. {#kpk-art-589zk}
§ 1. Właściwy sąd lub prokurator może postanowić o odroczeniu 

wykonania END na niezbędny okres, jeżeli: 

1) 

2) 

jego wykonanie mogłoby zaszkodzić toczącemu się postępowaniu karnemu; 

przedmioty, dokumenty lub dane są wykorzystywane w innym postępowaniu. 

§ 2. Po ustaniu przyczyny odroczenia wykonania END właściwy sąd lub 

prokurator niezwłocznie przystępuje do jego wykonania, informując o tym 

jednocześnie organ wydający END.


## Art. 589zl. {#kpk-art-589zl}
§ 1. Sąd lub prokurator potwierdza otrzymanie END niezwłocznie, 

nie później jednak niż w terminie tygodnia, licząc od dnia jego otrzymania. 

§ 2. Potwierdzenie, o którym mowa w § 1, zawiera informacje dotyczące organu, 

który otrzymał END, lub organu, któremu END został przekazany zgodnie z 

właściwością. 

§ 3. Minister Sprawiedliwości określi, w drodze rozporządzenia, wzór 

formularza potwierdzenia otrzymania END, mając na uwadze konieczność 

udostępnienia państwu wydania orzeczenia pełnych informacji o otrzymaniu END.


## Art. 589zm. {#kpk-art-589zm}
Sąd lub prokurator niezwłocznie informuje organ wydający END: 

1) 

o niemożności wydania postanowienia w sprawie END, w przypadku gdy 

formularz END jest niekompletny lub błędnie wypełniony; 

2) 

jeżeli uzna, że może być celowe przeprowadzenie czynności dochodzeniowych, 

których nie przewidziano lub których nie można było wskazać w chwili 

wydawania END; 

3) 

o niemożności dopełnienia formalności i procedur wskazanych przez organ 

wydający END; 

4) 

o każdym przypadku odmowy wykonania END 

lub o postanowieniu 

przeprowadzenia zastępczej czynności dochodzeniowej na podstawie art. 589zi 

§ 2 lub 5; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 254/356 

5) 

o każdym przypadku odroczenia wykonania END, podając przyczyny 

uzasadniające to odroczenie i jego okres; 

6) 

o uchyleniu lub zakończeniu okresu zabezpieczenia stosowanego zgodnie z art. 

589zq.


## Art. 589zn. {#kpk-art-589zn}
§ 1. W przypadku powzięcia wątpliwości, czy wydanie END było 

uzasadnione lub celowe lub czy dana czynność dochodzeniowa byłaby dopuszczalna 

w państwie wydania orzeczenia, właściwy sąd lub prokurator konsultuje się z organem 

wydającym END i jeżeli wymaga tego interes wymiaru sprawiedliwości, występuje z 

wnioskiem o cofnięcie END. 

§ 2. W przypadku powzięcia wątpliwości co do autentyczności dokumentów 

niezbędnych do wykonania END 

lub wystąpienia 

technicznych przeszkód 

uniemożliwiających jego wykonanie, przepis § 1 stosuje się odpowiednio.


## Art. 589zo. {#kpk-art-589zo}
§ 1. Na wniosek państwa wydania orzeczenia przedstawicielowi 

organu wydającego END umożliwia się obecność przy wykonywaniu czynności, 

których dotyczy END, jeżeli nie jest to sprzeczne z zasadami porządku prawnego 

Rzeczypospolitej Polskiej i nie stanowi zagrożenia dla bezpieczeństwa narodowego. 

§ 2. Przedstawiciel, o którym mowa w § 1, za zgodą sądu lub prokuratora, może 

zadawać określone pytania lub w inny sposób uczestniczyć w przeprowadzeniu 

dowodu. 

§ 3. Przedstawiciela, o którym mowa w § 1, uważa się za funkcjonariusza 

publicznego w rozumieniu przepisów Kodeksu karnego. 

§ 4. Jeżeli Skarb Państwa poniósł odpowiedzialność za szkodę wyrządzoną przez 

przedstawiciela, o którym mowa w § 1, w związku z wykonaniem END, Skarb 

Państwa występuje do organu wydającego END o zwrot wypłaconej kwoty pieniężnej 

stanowiącej równowartość wypłaconego odszkodowania.


## Art. 589zp. {#kpk-art-589zp}
§ 1. Dowody uzyskane w związku z wykonaniem END są 

niezwłocznie przekazywane państwu wydania orzeczenia. W przypadku określonym 

w art. 589zo § 1 mogą być one przekazywane, na wniosek państwa wydania 

orzeczenia, przedstawicielowi organu wydającego END. 

§ 2. Przekazując dowody uzyskane w związku z wykonaniem END, sąd lub 

prokurator może, po konsultacjach z organem wydającym END, zastrzec ich zwrot. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 255/356


## Art. 589zq. {#kpk-art-589zq}
§ 1. Jeżeli END został wydany w celu zabezpieczenia śladów i 

dowodów przestępstwa przed ich utratą, zniekształceniem lub zniszczeniem, właściwy 

sąd lub prokurator orzeka w przedmiocie wykonania END w terminie 24 godzin od 

jego otrzymania, a jeżeli nie jest to możliwe – niezwłocznie po upływie tego terminu. 

Zgodnie z wnioskiem państwa wydania orzeczenia sąd lub prokurator przekazuje 

dowód państwu wydania orzeczenia lub pozostawia dowód do swojej dyspozycji na 

czas określony przez państwo wydania orzeczenia. 

§ 2. Sąd lub prokurator po konsultacji z organem wydającym END może 

zdecydować o skróceniu okresu zabezpieczenia.


## Art. 589zr. {#kpk-art-589zr}
§ 1. Koszty związane z wykonaniem END ponosi Skarb Państwa. W 

uzasadnionych przypadkach sąd lub prokurator może wystąpić do organu wydającego 

END o zwrot całości lub części przewidywanych wydatków albo o zmianę END. 

§ 2. Koszty związane z czasowym wydaniem osoby pozbawionej wolności 

ponosi państwo wydania orzeczenia.


## Art. 589zs. {#kpk-art-589zs}
§ 1. Na wniosek innego państwa członkowskiego Unii Europejskiej 

Minister Sprawiedliwości udziela zezwolenia na przewóz przez 

terytorium 

Rzeczypospolitej Polskiej osoby pozbawionej wolności czasowo wydanej. 

§ 2. Wniosek o zezwolenie na przewóz zawiera: 

oznaczenie organu wnioskującego; 

datę oraz wskazanie miejsca wydania END; 

dane określające tożsamość i obywatelstwo osoby; 

1) 

2) 

3) 

4) wskazanie czynności dochodzeniowej, na potrzeby której osoba jest czasowo 

wydawana. 

§ 3. W przypadku korzystania z drogi powietrznej bez planowanego lądowania 

można poprzestać na powiadomieniu Ministra Sprawiedliwości o przewożeniu osoby 

pozbawionej wolności czasowo wydanej nad terytorium Rzeczypospolitej Polskiej. 

Jeżeli jednak nastąpi nieprzewidziane lądowanie, państwo, które wystąpiło z 

wnioskiem, dostarcza niezwłocznie dane, o których mowa w § 2. 

§ 4. Jeżeli jest to uzasadnione długością pobytu na terytorium Rzeczypospolitej 

Polskiej osoby pozbawionej wolności i przewożonej przez to terytorium w celu jej 

czasowego wydania, do osoby tej stosuje się odpowiednio przepis art. 589zf. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 256/356


## Art. 589zt. {#kpk-art-589zt}
§ 1. Jeżeli organ innego państwa członkowskiego Unii Europejskiej 

zamiast END przekazał powiadomienie o zamiarze przeprowadzenia albo o 

przeprowadzeniu kontroli i utrwalania treści rozmów telefonicznych, prokurator bez-

pośrednio lub za pośrednictwem właściwego komendanta Policji przekazuje temu 

organowi informacje w przedmiocie dopuszczalności: 

1) 

czynności, mając na względzie art. 237 § 3–4 oraz art. 238 § 1 i 2; 

2) wykorzystania uzyskanego dowodu w postępowaniu karnym. 

§ 2. Informacje, o których mowa w § 1, przekazuje się w terminie 96 godzin od 

otrzymania powiadomienia. 


# Rozdział 63
 

Przejęcie i przekazanie ścigania karnego


## Art. 590. {#kpk-art-590}
§ 1. W sprawie o przestępstwo popełnione za granicą przez: 

obywatela polskiego, 

osobę mającą na 

terytorium Rzeczypospolitej Polskiej stałe miejsce 

1) 

2) 

zamieszkania, 

3) 

osobę, która odbywa lub będzie odbywać w Rzeczypospolitej Polskiej karę 

pozbawienia wolności, 

4) 

osobę, przeciwko której zostało wszczęte w Rzeczypospolitej Polskiej 

postępowanie karne 

– Minister Sprawiedliwości zwraca się, jeżeli wymaga tego interes wymiaru 

sprawiedliwości, do właściwego organu państwa obcego z wnioskiem o przekazanie 

ścigania albo może przyjąć taki wniosek od właściwego organu państwa obcego. 

§ 2. Przejęcie ścigania karnego uważa się za wszczęcie postępowania karnego 

według prawa polskiego. 

§ 3. Jeżeli przejęcie ścigania łączy się z przekazaniem przez państwo obce 

tymczasowo aresztowanego, art. 598 stosuje się. 

§ 4. Do dowodów zebranych za granicą przed przejęciem ścigania stosuje się 

odpowiednio art. 587, choćby czynności dowodowe nie były podjęte na wniosek 

polskiego sądu lub prokuratora. 

§ 5. Minister Sprawiedliwości zawiadamia właściwy organ państwa obcego 

o sposobie prawomocnego zakończenia postępowania karnego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 257/356


## Art. 591. {#kpk-art-591}
§ 1. W sprawie 

o przestępstwo 

popełnione 

na 

terytorium 

Rzeczypospolitej Polskiej przez cudzoziemca, 

Minister Sprawiedliwości, z urzędu albo z inicjatywy sądu lub prokuratora, 

zwraca się, jeżeli wymaga tego interes wymiaru sprawiedliwości, do właściwego 

organu państwa: 

1) 

którego osoba ścigana jest obywatelem, 

2) w którym osoba ścigana ma stałe miejsce zamieszkania, 

3) w którym osoba ścigana odbywa lub będzie odbywała karę pozbawienia 

wolności, 

4) w którym zostało wszczęte przeciwko osobie ściganej postępowanie karne 

– z wnioskiem o przejęcie ścigania karnego albo może przyjąć taki wniosek od 

właściwego organu państwa obcego. 

§ 2. Jeżeli pokrzywdzonym jest obywatel polski, złożenie wniosku o przejęcie 

ścigania może nastąpić tylko za jego zgodą, chyba że uzyskanie tej zgody nie jest 

możliwe. 

§ 3. Przed wystąpieniem 

z wnioskiem, o którym mowa w § 1, 

lub 

rozstrzygnięciem takiego wniosku pochodzącego od organu państwa obcego właściwy 

organ umożliwia osobie ściganej przebywającej na terytorium Rzeczypospolitej 

Polskiej zajęcie stanowiska ustnie lub na piśmie w przedmiocie przejęcia ścigania. 

§ 4. W razie pozytywnego rozstrzygnięcia wniosku o przekazanie ścigania 

dotyczącego osoby tymczasowo aresztowanej na terytorium Rzeczypospolitej Polskiej 

Minister Sprawiedliwości zwraca się do właściwego organu o niezwłoczne podjęcie 

czynności mających na celu wydanie i przekazanie takiej osoby organom państwa 

obcego. Wraz z osobą przekazuje się akta sprawy, o ile nie zostały one uprzednio 

przekazane wraz z wnioskiem. 

§ 5. Minister Sprawiedliwości zwraca się do właściwego organu państwa obcego 

o informację co do sposobu prawomocnego zakończenia postępowania karnego. 

§ 6. Przekazanie ścigania karnego uważa się za umorzenie postępowania karnego 

według prawa polskiego; nie stoi to na przeszkodzie ponownemu postępowaniu 

karnemu w razie bezpodstawnego zaniechania ścigania za granicą.


## Art. 592. {#kpk-art-592}
§ 1. Jeżeli co do tego samego czynu tej samej osoby wszczęto 

postępowanie karne w Rzeczypospolitej Polskiej i w państwie obcym, Minister 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 258/356 

Sprawiedliwości przeprowadza konsultacje z właściwym organem państwa obcego i – 

jeżeli wymaga tego interes wymiaru sprawiedliwości – występuje z wnioskiem 

o przejęcie albo przekazanie ścigania karnego. Przepisy art. 590 § 2–5 oraz art. 591 

§ 2–6 stosuje się odpowiednio. 

§ 2. Jeżeli na podstawie umowy międzynarodowej, której Rzeczpospolita Polska 

jest stroną, wszczęto w Rzeczypospolitej Polskiej postępowanie karne o przestępstwo 

popełnione za granicą, Minister Sprawiedliwości może wystąpić do właściwego 

organu państwa obcego o przejęcie ścigania przez organy tego państwa niezależnie od 

tego, czy w państwie obcym wszczęto ściganie co do tego samego czynu. Przepisy 

art. 591 § 2, 5 i 6 stosuje się odpowiednio. 

§ 3. W sprawie o przestępstwo popełnione za granicą przez obywatela polskiego 

przebywającego za granicą, jeżeli wymaga tego interes wymiaru sprawiedliwości, 

Minister Sprawiedliwości może wystąpić do właściwego organu państwa obcego 

o przejęcie ścigania przez organy tego państwa. Przepisy art. 591 § 2, 5 i 6 stosuje się 

odpowiednio.


## Art. 592a. {#kpk-art-592a}
§ 1. Jeżeli zachodzą okoliczności wskazane w art. 590 § 1, art. 591 

§ 1 lub inne okoliczności nasuwające przypuszczenie, że co do tego samego czynu tej 

samej osoby wszczęto postępowanie karne w Rzeczypospolitej Polskiej i w innym 

państwie członkowskim Unii Europejskiej, sąd lub prokurator występuje do 

właściwego sądu lub innego organu państwa członkowskiego Unii Europejskiej 

z wnioskiem o udzielenie informacji o tym postępowaniu. 

§ 2. W razie trudności w ustaleniu właściwego sądu lub innego organu państwa 

członkowskiego Unii Europejskiej sąd lub prokurator może również zwracać się do 

właściwych jednostek organizacyjnych Europejskiej Sieci Sądowej. 

§ 3. Przepisu § 1 nie stosuje się, jeżeli informacje o toczącym się postępowaniu 

karnym w innym państwie członkowskim Unii Europejskiej powzięte zostały 

z urzędu.


## Art. 592b. {#kpk-art-592b}
§ 1. W razie wystąpienia sądu 

lub 

innego organu państwa 

członkowskiego Unii Europejskiej o udzielenie 

informacji, czy 

toczy się 

postępowanie karne co do tego samego czynu tej samej osoby, sąd lub prokurator 

udziela odpowiedzi we wskazanym przez ten organ terminie. W razie braku takiego 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 259/356 

terminu lub w wypadku stosowania wobec oskarżonego środka polegającego na 

pozbawieniu wolności sąd lub prokurator udziela odpowiedzi niezwłocznie. 

§ 2. W wypadku niedotrzymania terminu określonego w § 1 zdanie pierwsze sąd 

lub prokurator niezwłocznie informuje sąd lub inny organ państwa członkowskiego 

Unii Europejskiej o przyczynie opóźnienia i podaje przewidywany termin udzielenia 

informacji. 

§ 3. Jeżeli sąd lub prokurator, do którego zostało skierowane wystąpienie, nie jest 

właściwy do nadania mu biegu, przekazuje je właściwemu sądowi lub prokuratorowi 

i zawiadamia o tym sąd lub inny organ państwa członkowskiego Unii Europejskiej.


## Art. 592c. {#kpk-art-592c}
§ 1. Jeżeli co do tego samego czynu tej samej osoby wszczęto 

postępowanie karne w Rzeczypospolitej Polskiej i w innym państwie członkowskim 

Unii Europejskiej, sąd lub prokurator przeprowadza konsultacje z właściwym sądem 

lub innym organem państwa członkowskiego Unii Europejskiej i – jeżeli wymaga tego 

interes wymiaru sprawiedliwości – występuje z wnioskiem o przejęcie albo 

przekazanie ścigania karnego. Przepisy art. 590–592 stosuje się odpowiednio. 

§ 2. W trakcie konsultacji sąd lub prokurator przekazuje sądowi lub innemu 

organowi państwa członkowskiego Unii Europejskiej informacje o zastosowanych 

w postępowaniu środkach zapobiegawczych, a także inne informacje na wniosek 

właściwego organu. 

§ 3. Sąd lub prokurator może nie udzielić informacji, jeśli jej udzielenie mogłoby 

naruszyć bezpieczeństwo Rzeczypospolitej Polskiej lub narażałoby uczestnika 

postępowania na niebezpieczeństwo utraty życia lub zdrowia.


## Art. 592d. {#kpk-art-592d}
§ 1. Jeśli w wyniku konsultacji, o których mowa w art. 592c § 1, nie 

ustalono, które państwo członkowskie powinno przejąć ściganie, sąd lub prokurator 

może wystąpić do Eurojust w sprawach o przestępstwa należące do jego kompetencji 

z wnioskiem o pomoc w rozstrzygnięciu, które państwo mogłoby przejąć ściganie. 

§ 2. Po uzyskaniu opinii Eurojust sąd lub prokurator, jeżeli wymaga tego interes 

wymiaru sprawiedliwości, występuje z wnioskiem o przejęcie lub przekazanie 

ścigania karnego. Przepisy art. 590–592 stosuje się odpowiednio.


## Art. 592e. {#kpk-art-592e}
W wypadkach przewidzianych w art. 592c § 1 i art. 592d § 2 sąd lub 

prokurator zawiadamia sąd lub inny organ państwa członkowskiego Unii Europejskiej 

o sposobie prawomocnego zakończenia postępowania karnego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 260/356


## Art. 592f. {#kpk-art-592f}
Wystąpienie, o którym mowa w art. 592a, jak również konsultacje, 

o których mowa w art. 592c, nie wstrzymują czynności postępowania karnego. 


# Rozdział 64
 

Wystąpienie o wydanie lub przewóz osób ściganych lub skazanych 

przebywających za granicą 

oraz o wydanie przedmiotów


## Art. 593. {#kpk-art-593}
Sądy 

i prokuratorzy 

zgłaszają 

za 

pośrednictwem Ministra 

Sprawiedliwości wnioski o wydanie przez państwo obce osoby, przeciwko której 

wszczęto postępowanie karne, o wydanie osoby w celu przeprowadzenia 

postępowania sądowego lub wykonania orzeczonej kary pozbawienia wolności, 

o przewóz osoby ściganej lub skazanej przez terytorium państwa obcego oraz 

o wydanie z terytorium państwa obcego dowodów rzeczowych lub przedmiotów 

uzyskanych przez sprawcę w wyniku przestępstwa.


## Art. 594. {#kpk-art-594}
§ 1. Do wniosku dołącza się odpis postanowienia o tymczasowym 

aresztowaniu wraz z uzasadnieniem, wyjaśniającym okoliczności 

faktyczne 

i podstawę prawną ścigania. 

§ 2. W wypadku prawomocnego wyroku skazującego na karę pozbawienia 

wolności dołącza się zamiast postanowienia wymienionego w § 1 odpis tego wyroku. 

§ 3. Przepis art. 280 § 1 pkt 2 stosuje się odpowiednio.


## Art. 595. {#kpk-art-595}
W wypadkach niecierpiących zwłoki sąd lub prokurator może zwrócić 

się bezpośrednio do właściwego organu państwa obcego o tymczasowe aresztowanie 

lub zatrzymanie osoby, co do której ma być złożony wniosek o wydanie, po czym 

niezwłocznie składa wniosek zgodnie z art. 593 i 594.


## Art. 596. {#kpk-art-596}
Osoba wydana nie może być bez zgody państwa wydającego ścigana, 

skazana ani pozbawiona wolności w celu wykonania kary za inne przestępstwo 

popełnione przed dniem wydania niż to, w związku z którym nastąpiło wydanie.


## Art. 597. {#kpk-art-597}
W razie zastrzeżenia przy wydaniu, że w stosunku do osoby wydanej 

orzeczone już kary będą wykonane tylko za te przestępstwa, co do których nastąpiło 

wydanie, sąd, który prawomocnie orzekł w sprawie, wydaje w razie potrzeby na 

posiedzeniu wyrok zmieniający orzeczenie w taki sposób, aby kary były wykonywane 

tylko za te przestępstwa, co do których nastąpiło wydanie sprawcy. Prokurator i osoba 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 261/356 

wydana mają prawo wziąć udział w posiedzeniu. Przepis art. 451 stosuje się 

odpowiednio.


## Art. 598. {#kpk-art-598}
§ 1. Terminy przewidziane w art. 263 biegną w stosunku do osoby 

wydanej od chwili przejęcia tej osoby przez właściwe organy na terytorium 

Rzeczypospolitej Polskiej. 

§ 2. Przepis art. 265 stosuje się także, gdy zatrzymanie nastąpiło za granicą.


## Art. 599. {#kpk-art-599}
Jeżeli osoba wydana przez państwo obce nie opuści bez 

usprawiedliwionej przyczyny terytorium Rzeczypospolitej Polskiej w ciągu 45 dni od 

daty prawomocnego zakończenia postępowania, a w razie skazania – od daty odbycia 

lub darowania kary, albo jeżeli po opuszczeniu terytorium Rzeczypospolitej Polskiej 

powróci na nie, ograniczeń wynikających z art. 596 i 597 nie stosuje się.


## Art. 600. {#kpk-art-600}
Po wydaniu prawomocnego orzeczenia w sprawie przeciwko osobie 

wydanej przez państwo obce sąd przesyła odpis wyroku Ministrowi Sprawiedliwości, 

który odpis ten przekazuje właściwemu organowi obcego państwa. Przepis art. 157 

§ 2 stosuje się odpowiednio.


## Art. 601. {#kpk-art-601}
Przekazane przez państwo obce przedmioty uzyskane w wyniku 

przestępstwa zwraca się, jeżeli przy ich wydaniu zastrzeżono zwrot; podobnie należy 

postąpić z dowodami rzeczowymi. 


# Rozdział 65
 

Wydanie oraz przewóz osób ściganych albo skazanych lub wydanie 

przedmiotów na wniosek państw obcych


## Art. 602. {#kpk-art-602}
§ 1. (uchylony) 

§ 2. W razie złożenia przez organ państwa obcego wniosku o wydanie osoby 

ściganej w celu przeprowadzenia przeciw niej postępowania karnego lub wykonania 

orzeczonej co do niej kary albo środka zabezpieczającego, prokurator przesłuchuje tę 

osobę i w miarę potrzeby zabezpiecza dowody znajdujące się w kraju, po czym wnosi 

sprawę do właściwego miejscowo sądu okręgowego.


## Art. 603. {#kpk-art-603}
§ 1. Sąd okręgowy wydaje na posiedzeniu postanowienie 

w przedmiocie wniosku państwa obcego. Przed wydaniem postanowienia należy 

umożliwić osobie ściganej złożenie wyjaśnień ustnie lub na piśmie, a w razie wniosku 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 262/356 

o wydanie w celu przeprowadzenia postępowania karnego należy na uzasadniony 

wniosek tej osoby przeprowadzić dowody znajdujące się w kraju. 

§ 2. W posiedzeniu mają prawo wziąć udział prokurator i obrońca. 

§ 3. Jeżeli sąd wydał postanowienie o niedopuszczalności wydania, wydanie nie 

może nastąpić. 

§ 4. Na postanowienie sądu w przedmiocie wydania przysługuje zażalenie. 

§ 5. Sąd przekazuje prawomocne postanowienie wraz z aktami sprawy 

Ministrowi Sprawiedliwości, który po rozstrzygnięciu wniosku zawiadamia o tym 

właściwy organ państwa obcego.


## Art. 603a. {#kpk-art-603a}
§ 1. Jeżeli umowa międzynarodowa, której Rzeczpospolita Polska 

jest stroną, tak stanowi, wniosek państwa obcego o zastosowanie tymczasowego 

aresztowania osoby ściganej zastępuje wniosek o wydanie. 

§ 2. W wypadku, o którym mowa w § 1, prokurator podczas przesłuchania 

informuje osobę ściganą o możliwości wyrażenia przez nią zgody na wydanie lub 

zgody na wydanie połączonej ze zrzeczeniem się korzystania z ograniczeń okreś-

lonych w art. 596 i 597. Jeżeli osoba ścigana wyrazi wolę złożenia takiego 

oświadczenia, prokurator kieruje sprawę do sądu okręgowego, w którego okręgu 

prowadzi się postępowanie. 

§ 3. Sąd na posiedzeniu rozstrzyga o tymczasowym aresztowaniu osoby 

ściganej, odbiera oświadczenie o wyrażeniu zgody na wydanie lub zgody na wydanie 

połączonej ze zrzeczeniem się korzystania z ograniczeń określonych w art. 596 i 597, 

a także wydaje postanowienie o dopuszczalności wydania. 

§ 4. Zgoda osoby ściganej oraz zrzeczenie, o którym mowa w § 2, nie mogą 

zostać cofnięte, o czym poucza się osobę ściganą. 

§ 5. Sąd niezwłocznie przekazuje prawomocne postanowienie wraz z aktami 

sprawy Ministrowi Sprawiedliwości, który rozstrzyga o wydaniu osoby. 

§ 6. Jeżeli oświadczenie, o którym mowa w § 3, nie zostało złożone lub sąd 

stwierdził, że zachodzi okoliczność określona w art. 604 § 1, albo jeżeli posiedzenie 

zostało odroczone na czas przekraczający 7 dni, stosuje się przepisy art. 602 § 2, 

art. 603 i 605.


## Art. 604. {#kpk-art-604}
§ 1. Wydanie jest niedopuszczalne, jeżeli: 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 263/356 

1) 

osoba, której wniosek dotyczy, jest obywatelem polskim albo korzysta 

w Rzeczypospolitej Polskiej z prawa azylu; 

2) 

czyn nie zawiera znamion czynu zabronionego albo gdy ustawa uznaje, że czyn 

nie stanowi przestępstwa albo że sprawca nie popełnia przestępstwa lub nie 

3) 

4) 

5) 

6) 

podlega karze; 

nastąpiło przedawnienie; 

postępowanie karne co do tego samego czynu tej samej osoby zostało 

prawomocnie zakończone; 

byłoby ono sprzeczne z polskim prawem; 

zachodzi uzasadniona obawa, że w państwie żądającym wydania wobec osoby 

wydanej może zostać orzeczona lub wykonana kara śmierci; 

7) 

zachodzi uzasadniona obawa, że w państwie żądającym wydania może dojść do 

naruszenia wolności i praw osoby wydanej; 

8) 

dotyczy osoby ściganej za popełnienie bez użycia przemocy przestępstwa 

z przyczyn politycznych. 

§ 2. Wydania można odmówić w szczególności, jeżeli: 

1) 

osoba, której wniosek dotyczy, ma w Rzeczypospolitej Polskiej stałe miejsce 

zamieszkania; 

2) 

przestępstwo zostało popełnione na terytorium Rzeczypospolitej Polskiej albo na 

polskim statku wodnym lub powietrznym; 

3) 

4) 

co do tego samego czynu tej samej osoby toczy się postępowanie karne; 

przestępstwo podlega ściganiu z oskarżenia prywatnego; 

5) według prawa państwa, które złożyło wniosek o wydanie, przestępstwo jest 

zagrożone karą pozbawienia wolności do roku lub karą łagodniejszą albo 

orzeczono taką karę; 

6) 

przestępstwo, w związku z którym żąda się wydania, jest przestępstwem 

o charakterze wojskowym lub skarbowym, albo o charakterze politycznym 

innym niż określone w § 1 pkt 8; 

7) 

państwo, które złożyło wniosek o wydanie, nie zapewnia wzajemności. 

§ 3. W wypadkach wskazanych w § 1 pkt 4 i § 2 pkt 3 rozpoznanie wniosku 

o wydanie można odroczyć do czasu ukończenia w Rzeczypospolitej Polskiej 

postępowania karnego przeciwko tej samej osobie lub odbycia przez nią orzeczonej 

kary albo jej darowania. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 264/356


## Art. 605. {#kpk-art-605}
§ 1. Jeżeli wniosek o wydanie dotyczy przestępstwa, którego sprawca 

podlega wydaniu, sąd okręgowy z urzędu lub na wniosek prokuratora może wydać 

postanowienie o tymczasowym aresztowaniu osoby ściganej; przepis art. 263 stosuje 

się odpowiednio. 

§ 2. Przed złożeniem wniosku o wydanie sąd może wydać postanowienie 

o tymczasowym aresztowaniu ściganego na czas nie dłuższy niż 40 dni, jeżeli organ 

państwa obcego zwraca się o to, zapewniając, że wobec tej osoby zapadł w tym 

państwie prawomocny wyrok skazujący lub wydano decyzję o tymczasowym 

aresztowaniu. 

§ 3. Na postanowienie sądu w przedmiocie 

tymczasowego aresztowania 

przysługuje zażalenie. 

§ 4. O dniu tymczasowego aresztowania należy niezwłocznie powiadomić 

Ministra Sprawiedliwości Rzeczypospolitej Polskiej oraz przedstawicielstwo 

dyplomatyczne lub urząd konsularny albo organ ścigający państwa obcego. 

§ 5. Jeżeli dane zawarte we wniosku o wydanie są niewystarczające i sąd lub 

prokurator zażądał ich uzupełnienia, a państwo obce nie nadeśle w terminie miesiąca 

od dnia doręczenia żądania uzupełnienia wniosku o wydanie organowi, który je 

zgłosił, potrzebnych dokumentów lub informacji, postanowienie o tymczasowym 

aresztowaniu uchyla się. 

§ 6. W razie odmowy wydania, cofnięcia przez państwo obce wniosku o wydanie 

lub tymczasowe aresztowanie albo w razie gdy organ państwa obcego zawiadomiony 

o czasie i miejscu wydania żądanej osoby nie przejmuje jej w terminie 7 dni od 

ustalonego dnia wydania, zarządza się zwolnienie tymczasowo aresztowanego, jeżeli 

nie jest on pozbawiony wolności w innej sprawie.


## Art. 605a. {#kpk-art-605a}
§ 1. Zatrzymanie osoby ściganej może nastąpić także na podstawie 

informacji o poszukiwaniu zamieszczonych w bazie danych Międzynarodowej 

Organizacji Policji Kryminalnej lub w Systemie Informacyjnym Schengen. Przepisy 

art. 244–246 i art. 248 stosuje się. 

§ 2. Przed złożeniem kierowanego do Rzeczypospolitej Polskiej wniosku o 

tymczasowe aresztowanie osoby ściganej sąd może zastosować wobec tej osoby 

tymczasowe aresztowanie na czas nie dłuższy niż 7 dni, jeżeli zwraca się o to właściwy 

organ państwa obcego poprzez wprowadzenie wpisu do bazy danych 

Międzynarodowej Organizacji Policji Kryminalnej lub do Systemu Informacyjnego 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 265/356 

Schengen, stanowiącego zapewnienie, że wobec osoby ściganej zapadł prawomocny 

wyrok skazujący lub wydano inną decyzję będącą podstawą pozbawienia wolności, a 

w przypadku rejestracji w bazie Międzynarodowej Organizacji Policji Kryminalnej – 

że państwo to wystąpi o jej wydanie.


## Art. 606. {#kpk-art-606}
§ 1. Zezwolenia na przewóz osoby ściganej przez terytorium 

Rzeczypospolitej Polskiej udziela Minister Sprawiedliwości. Przepisy art. 594, 604 

i 605 stosuje się odpowiednio. 

§ 2. Jeżeli podróż odbywa się drogą powietrzną i nie przewiduje się lądowania, 

wystarczy powiadomienie Ministra Sprawiedliwości o przewożeniu osoby ściganej 

nad terytorium Rzeczypospolitej Polskiej.


## Art. 607. {#kpk-art-607}
§ 1. Do rozstrzygania wniosków państwa obcego, dotyczących 

wydania przedmiotów stanowiących dowody rzeczowe lub uzyskanych w wyniku 

przestępstwa, właściwy jest prokurator lub sąd w zależności od tego, do czyjego 

rozporządzenia przedmioty te zostały zdeponowane. Przepis art. 588 § 2 i 4 stosuje się 

odpowiednio. 

§ 2. Postanowienie o wydaniu przedmiotów powinno wymieniać rzeczy, które 

ulegają wydaniu państwu obcemu, oraz wskazywać rzeczy podlegające zwrotowi po 

ukończeniu postępowania karnego, prowadzonego przez organy państwa obcego. 


# Rozdział 65
a 

Wystąpienie do państwa członkowskiego Unii Europejskiej o przekazanie osoby 

ściganej 

na podstawie europejskiego nakazu aresztowania


## Art. 607a. {#kpk-art-607a}
W razie podejrzenia, że osoba ścigana za przestępstwo podlegające 

jurysdykcji polskich sądów karnych może przebywać na terytorium państwa 

członkowskiego Unii Europejskiej, właściwy miejscowo sąd okręgowy, na wniosek 

prokuratora, a w postępowaniu sądowym i wykonawczym – z urzędu lub na wniosek 

właściwego sądu rejonowego, może wydać europejski nakaz aresztowania, zwany 

w niniejszym rozdziale „nakazem”.


## Art. 607b. {#kpk-art-607b}
Wydanie nakazu jest niedopuszczalne, jeśli nie wymaga tego interes 

wymiaru sprawiedliwości. Ponadto wydanie nakazu jest niedopuszczalne: 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 266/356 

1) w związku z prowadzonym przeciwko osobie ściganej postępowaniem karnym 

o przestępstwo zagrożone karą pozbawienia wolności do roku; 

2) w celu wykonania kary pozbawienia wolności orzeczonej w wymiarze do 

4 miesięcy albo innego środka polegającego na pozbawieniu wolności na czas 

nieprzekraczający 4 miesięcy.


## Art. 607c. {#kpk-art-607c}
§ 1. Nakaz powinien zawierać: 

1) 

oznaczenie sądu występującego, ze wskazaniem jego adresu, numeru telefonu, 

2) 

3) 

4) 

5) 

6) 

telefaksu i adresu poczty elektronicznej; 

datę oraz miejsce wydania nakazu; 

dane określające tożsamość i obywatelstwo osoby ściganej; 

sygnaturę, rodzaj 

i treść prawomocnego albo podlegającego wykonaniu 

orzeczenia sądu, w związku z którym nakaz został wydany; 

przytoczenie opisu i kwalifikacji prawnej czynu; 

górną granicę ustawowego zagrożenia karą pozbawienia wolności przestępstwa, 

o które toczy się postępowanie, lub wysokość orzeczonej kary pozbawienia 

wolności albo innego środka polegającego na pozbawieniu wolności; 

7) 

zwięzły opis stanu faktycznego sprawy; 

8) wskazanie następstw czynu nieobjętych ustawowymi znamionami przestępstwa. 

§ 2. Nakaz powinien zostać przetłumaczony na język urzędowy państwa 

wykonania nakazu. 

§ 3. Minister Sprawiedliwości określi, w drodze rozporządzenia, wzór nakazu, 

mając na uwadze konieczność udostępnienia państwu członkowskiemu Unii 

Europejskiej, do którego jest kierowany, danych niezbędnych do podjęcia prawidłowej 

decyzji w przedmiocie przekazania osoby ściganej.


## Art. 607d. {#kpk-art-607d}
§ 1. Jeżeli istnieje podejrzenie, że osoba ścigana może przebywać na 

terytorium państwa członkowskiego Unii Europejskiej, a jej miejsce pobytu nie jest 

znane, prokurator, a w postępowaniu sądowym i wykonawczym sąd okręgowy, który 

wydał nakaz, przesyła jego odpis do centralnej jednostki Policji współpracującej 

z Interpolem z wnioskiem o wszczęcie poszukiwań międzynarodowych. 

§ 2. Jeżeli miejsce pobytu osoby ściganej jest znane lub zostało ustalone 

w wyniku poszukiwań, o których mowa w § 1, prokurator, a w postępowaniu 

sądowym i wykonawczym sąd okręgowy, który wydał nakaz, przekazuje go 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 267/356 

bezpośrednio organowi sądowemu państwa wykonania nakazu; odpis nakazu 

przekazuje się Ministrowi Sprawiedliwości. 

§ 3. Przepis § 2 stosuje się odpowiednio w wypadku, gdy państwo wykonania 

nakazu zwróciło się o przedstawienie dodatkowych informacji lub dokumentów. 

§ 4. Przekazanie nakazu oraz wszystkich związanych z nim 

informacji 

i dokumentów może nastąpić również z wykorzystaniem urządzeń służących do 

automatycznego przesyłania danych w sposób umożliwiający 

stwierdzenie 

autentyczności tych dokumentów.


## Art. 607e. {#kpk-art-607e}
§ 1. Osoby przekazanej w wyniku wykonania nakazu nie można 

ścigać za przestępstwa inne niż te, które stanowiły podstawę przekazania, ani wykonać 

orzeczonych wobec niej za te przestępstwa kar pozbawienia wolności albo innych 

środków polegających na pozbawieniu wolności. 

§ 2. Sąd, który prawomocnie orzekł w sprawie, może zarządzić wykonanie kary 

tylko za te przestępstwa, które stanowiły podstawę przekazania osoby ściganej. 

W posiedzeniu sądu mają prawo wziąć udział prokurator i osoba ścigana. Przepis 

art. 451 stosuje się odpowiednio. 

§ 3. Przepisu § 1 nie stosuje się, jeżeli: 

1) 

państwo wykonania nakazu złożyło oświadczenie o dopuszczalności ścigania lub 

wykonania kar pozbawienia wolności albo innych środków polegających na 

pozbawieniu wolności za wszystkie czyny popełnione przed przekazaniem, 

chyba że organ sądowy tego państwa w orzeczeniu o przekazaniu postanowił 

inaczej; 

2) 

osoba przekazana, pomimo takiej możliwości, nie opuściła terytorium Rze-

czypospolitej Polskiej w ciągu 45 dni od dnia prawomocnego zakończenia 

postępowania albo po opuszczeniu terytorium Rzeczypospolitej Polskiej na nie 

powróciła; 

3) 

nie została orzeczona kara pozbawienia wolności albo inny środek polegający na 

pozbawieniu wolności; 

4) 

postępowanie karne nie wiąże się ze stosowaniem wobec osoby ściganej środka 

polegającego na pozbawieniu wolności; 

5) 

czyn osoby ściganej jest zagrożony karą lub środkiem niepolegającymi na 

pozbawieniu wolności; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 268/356 

6) 

osoba ścigana wyraziła zgodę na przekazanie i zrzekła się korzystania z prawa 

określonego w § 1; 

7) 

osoba ścigana, po jej przekazaniu, złożyła przed sądem właściwym do 

rozpoznania sprawy oświadczenie o zrzeczeniu się korzystania z prawa 

określonego w § 1 w odniesieniu do czynów popełnionych przed przekazaniem; 

8) 

organ sądowy państwa wykonania nakazu, który przekazał osobę ściganą, na 

wniosek sądu właściwego do wydania nakazu, wyraził zgodę na ściganie lub 

wykonanie kar pozbawienia wolności albo innych środków polegających 

na pozbawieniu wolności za przestępstwa określone w pkt 1. 

§ 3a. Osoba ścigana nie może cofnąć zgody ani oświadczenia, o których mowa 

w § 3 pkt 6 i 7. 

§ 4. Wniosek, o którym mowa w § 3 pkt 8, powinien zawierać informacje 

wymienione w art. 607c § 1. Przepis art. 607c § 2 stosuje się odpowiednio.


## Art. 607f. {#kpk-art-607f}
Na poczet orzeczonej lub wykonywanej kary pozbawienia wolności 

zalicza się okres faktycznego pozbawienia wolności w państwie wykonania nakazu 

w związku z przekazaniem.


## Art. 607g. {#kpk-art-607g}
Po prawomocnym zakończeniu postępowania karnego przeciwko 

osobie ściganej lub wykonaniu wobec niej kary pozbawienia wolności albo innego 

środka polegającego na pozbawieniu wolności sąd właściwy do rozpoznania sprawy 

przesyła odpis orzeczenia lub zawiadomienie o wykonaniu kary albo innego środka do 

organu wymiaru sprawiedliwości państwa wykonania nakazu.


## Art. 607h. {#kpk-art-607h}
§ 1. Właściwy sąd lub prokurator może wystąpić do organu sądowego 

państwa wykonania nakazu o zajęcie i przekazanie przedmiotów pochodzących 

bezpośrednio z przestępstwa, przedmiotów, które służyły lub były przeznaczone do 

popełnienia przestępstwa, lub mogących stanowić dowód w sprawie rzeczy, 

korespondencji, przesyłek, wykazów połączeń telekomunikacyjnych lub innych 

przekazów informacji lub danych przechowywanych w systemie informatycznym lub 

na nośniku, w tym korespondencji przesyłanej pocztą elektroniczną. 

§ 2. Można wystąpić o zajęcie i przekazanie dowodów i przedmiotów, o których 

mowa w § 1, również wtedy, gdy wykonanie nakazu nie jest możliwe ze względu na 

śmierć lub ucieczkę osoby ściganej. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 269/356 

§ 3. Przekazane przedmioty, o których mowa w § 1, zwraca się państwu 

wykonania nakazu, jeżeli przy ich przekazaniu zastrzeżono zwrot lub gdy podlegają 

one zwrotowi pokrzywdzonemu 

lub 

innemu uprawnionemu podmiotowi, 

przebywającemu na terytorium państwa wykonania nakazu. 

§ 4. Przepisy rozdziału 62a stosuje się odpowiednio.


## Art. 607i. {#kpk-art-607i}
§ 1. Osoba ścigana, która w wyniku przekazania znalazła się na 

terytorium Rzeczypospolitej Polskiej, podlega dalszemu przekazaniu bez zgody 

państwa wykonania nakazu w związku z przestępstwami popełnionymi przed 

przekazaniem, tylko wtedy, gdy: 

1) 

pomimo takiej możliwości nie opuściła terytorium Rzeczypospolitej Polskiej 

w ciągu 45 dni od dnia prawomocnego zakończenia postępowania albo po 

opuszczeniu terytorium Rzeczypospolitej Polskiej na nie powróciła; 

2) wyraziła zgodę na przekazanie do państwa innego niż państwo wykonania 

nakazu; 

3) 

stosuje się do niej przepis art. 607e § 3 pkt 2, 6, 7 albo 8. 

§ 2. Na dalsze przekazanie osoby ściganej, która w wyniku przekazania znalazła 

się na terytorium Rzeczypospolitej Polskiej, wymagana jest zgoda właściwego organu 

sądowego państwa wykonania nakazu, które przekazało tę osobę. Wniosek 

właściwego sądu okręgowego o wyrażenie zgody na dalsze przekazanie powinien 

zawierać informacje wymienione w art. 607c § 1. Przepis art. 607c § 2 stosuje się 

odpowiednio. 

§ 3. Na wydanie osoby ściganej, która w wyniku przekazania znalazła się na 

terytorium Rzeczypospolitej Polskiej, wymagana jest zgoda właściwego organu 

państwa wykonania nakazu, które przekazało tę osobę.


## Art. 607j. {#kpk-art-607j}
§ 1. Jeżeli państwo wykonania nakazu przekazało osobę ściganą pod 

warunkiem, że wykonanie kary pozbawienia wolności albo 

innego środka 

polegającego na pozbawieniu wolności nastąpi w tym państwie, postępowania wyko-

nawczego nie wszczyna się. 

§ 2. W wypadku, o którym mowa w § 1, sąd właściwy do rozpoznania sprawy, 

niezwłocznie po uprawomocnieniu 

się orzeczenia, wydaje postanowienie 

o przekazaniu skazanego do właściwego państwa członkowskiego Unii Europejskiej 

w celu wykonania orzeczonej kary albo innego środka polegającego na pozbawieniu 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 270/356 

wolności. Odpis postanowienia wraz z odpisem orzeczenia podlegającego wykonaniu 

przekazuje się właściwemu organowi sądowemu państwa wykonania nakazu. 


# Rozdział 65
b 

Wystąpienie państwa członkowskiego Unii Europejskiej o przekazanie osoby 

ściganej 

na podstawie europejskiego nakazu aresztowania


## Art. 607k. {#kpk-art-607k}
§ 1. Przekazanie z terytorium Rzeczypospolitej Polskiej osoby 

ściganej europejskim nakazem aresztowania, zwanym w niniejszym rozdziale 

„nakazem europejskim”, następuje w celu przeprowadzenia przeciwko niej, na 

terytorium innego państwa członkowskiego Unii Europejskiej, postępowania karnego 

lub wykonania orzeczonej kary pozbawienia wolności albo 

innego środka 

polegającego na pozbawieniu wolności. 

§ 2. W razie otrzymania nakazu europejskiego prokurator przesłuchuje osobę, 

której nakaz dotyczy, informując ją o treści nakazu europejskiego oraz o możliwości 

wyrażenia zgody na przekazanie lub zgody na niestosowanie przepisu art. 607e § 1, 

po czym wnosi sprawę do właściwego miejscowo sądu okręgowego. 

§ 2a. Zatrzymanie osoby ściganej nakazem europejskim może nastąpić także na 

podstawie wpisu do Systemu Informacyjnego Schengen lub do bazy danych 

Międzynarodowej Organizacji Policji Kryminalnej. Przepisy art. 244–246 i art. 248 

stosuje się. 

§ 3. Na wniosek prokuratora sąd okręgowy może zastosować tymczasowe 

aresztowanie, oznaczając jego termin na czas niezbędny do przekazania osoby 

ściganej. Łączny okres stosowania tymczasowego aresztowania nie może przekroczyć 

100 dni. Samoistną podstawą zastosowania tymczasowego aresztowania jest istnienie 

wydanego w innym państwie członkowskim Unii Europejskiej prawomocnego 

wyroku skazującego lub innej decyzji stanowiącej podstawę pozbawienia wolności 

osoby ściganej. 

§ 3a. Przed wpłynięciem nakazu europejskiego sąd może zastosować wobec 

osoby ściganej tymczasowe aresztowanie na czas nie dłuższy niż 7 dni, jeżeli zwraca 

się o to właściwy organ sądowy, który wydał nakaz europejski, poprzez wprowadzenie 

wpisu do Systemu Informacyjnego Schengen lub do bazy danych Międzynarodowej 

Organizacji Policji Kryminalnej, stanowiącego zapewnienie, że wobec osoby ściganej 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 271/356 

zapadł prawomocny wyrok skazujący lub wydano inną decyzję będącą podstawą 

pozbawienia wolności. 

§ 4. Jeżeli odrębne przepisy prawa polskiego stanowią, że ściganie osoby, wobec 

której wydano nakaz europejski, jest uzależnione od zezwolenia właściwej władzy, 

przed skierowaniem sprawy do sądu stosuje się przepis art. 13. 

§ 5. Jeżeli 

jednocześnie 

z wydaniem 

nakazu 

europejskiego 

państwo 

członkowskie Unii Europejskiej zwróciło się o dokonanie przesłuchania osoby 

ściganej, osobę taką należy przesłuchać przed rozpoznaniem nakazu. Przesłuchanie 

odbywa się w obecności osoby wskazanej w nakazie europejskim. Przepis art. 588 

§ 4 stosuje się odpowiednio.


## Art. 607l. {#kpk-art-607l}
§ 1. W przedmiocie przekazania i tymczasowego aresztowania sąd 

orzeka na posiedzeniu, w którym mają prawo wziąć udział prokurator i obrońca. 

§ 1a. Zawiadamiając osobę ściganą o posiedzeniu, o którym mowa w § 1, sąd 

doręcza nakaz europejski wraz z tłumaczeniem przekazanym przez prokuratora. Jeżeli 

ze względu na szczególne okoliczności nie jest możliwe sporządzenie tłumaczenia 

przed posiedzeniem, tłumaczenie zarządza sąd. Można poprzestać na poinformowaniu 

osoby o treści nakazu europejskiego, jeśli nie utrudni to realizacji przysługujących jej 

praw, w tym praw wymienionych w § 2. 

§ 2. Jeżeli osoba ścigana wyrazi taką wolę, sąd przyjmuje od niej do protokołu 

oświadczenie o zgodzie na przekazanie lub o zgodzie na niestosowanie przepisu 

art. 607e § 1. Oświadczenie nie może być cofnięte, o czym należy pouczyć osobę 

ściganą. 

§ 3. Na postanowienie sądu w przedmiocie przekazania przysługuje zażalenie. 

Zażalenie wnosi się w terminie 3 dni od dnia ogłoszenia postanowienia, a jeżeli osoba 

ścigana pozbawiona jest wolności i nie została sprowadzona na posiedzenie sądu – od 

dnia jego doręczenia. Art. 252 stosuje się odpowiednio. 

§ 3a. W wypadku zatrzymania osoby, której nakaz europejski dotyczy, należy ją 

niezwłocznie pouczyć o jej uprawnieniach: do uzyskania informacji o treści nakazu 

europejskiego, o możliwości wyrażenia zgody na przekazanie, o możliwości złożenia 

oświadczenia w przedmiocie przekazania, do korzystania z pomocy obrońcy, do 

składania wyjaśnień, do odmowy składania wyjaśnień lub odmowy odpowiedzi na 

pytania, do przeglądania akt w zakresie dotyczącym przyczyn zatrzymania, do dostępu 

do pierwszej pomocy medycznej i do obecności na posiedzeniu, o którym mowa 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 272/356 

w § 1, jak również o uprawnieniach określonych w § 3, w art. 72 § 1, art. 78 § 1, art. 

78a § 1, art. 202, art. 215, art. 257 § 1 i 2, art. 259, art. 261 § 1, 2 i 2a, art. 360, 

art. 361, art. 612 oraz o treści art. 607k § 3 i 3a, a także o treści przepisów dotyczących 

środków zapobiegawczych, o których mowa w rozdziale 28, innych niż tymczasowe 

aresztowanie, a jeśli osoba, której nakaz europejski dotyczy, nie ukończyła 18 lat – 

ponadto o treści art. 76, art. 76a oraz o treści art. 212 Kodeksu karnego 

wykonawczego, a także o roli organów uczestniczących w postępowaniu karnym. 

Pouczenie należy wręczyć na piśmie; otrzymanie pouczenia potwierdza się podpisem. 

Jeżeli osoba, której nakaz europejski dotyczy, nie ukończyła 18 lat, pouczenie wręcza 

się również przedstawicielowi ustawowemu lub osobie, pod której pieczą osoba, której 

nakaz europejski dotyczy, pozostaje, albo innej osobie wskazanej albo wyznaczonej, 

o której mowa w art. 76a, która otrzymanie pouczenia potwierdza podpisem. 

§ 3b. Osoby, o których mowa w § 3a, nieporadne ze względu na wiek lub stan 

zdrowia, oraz które nie ukończyły 18 lat, mogą otrzymać dostęp do wyjaśnień co do 

zakresu ich uprawnień. Wzory wyjaśnień umieszcza się także na stronie internetowej 

Ministerstwa Sprawiedliwości. 

§ 3c. Pouczenie, o którym mowa w § 3a, i wyjaśnienia, o których mowa w § 3b, 

mogą być opisowe lub graficzne. 

§ 4. Minister Sprawiedliwości określi, w drodze rozporządzenia: 

1) wzór pisemnego pouczenia, o którym mowa w § 3a, w tym odrębny dla osób, 

które nie ukończyły 18 lat, mając na względzie konieczność zrozumienia 

pouczenia przez osoby niekorzystające z pomocy obrońcy lub pełnomocnika, 

osoby nieporadne ze względu na wiek lub stan zdrowia lub osoby, które nie 

ukończyły 18 lat; 

2) wzory pisemnych wyjaśnień, o których mowa w § 3b, odrębnych dla osób 

nieporadnych ze względu na wiek lub stan zdrowia oraz osób, które nie 

ukończyły 18 lat, mając na względzie konieczność zrozumienia wyjaśnień przez 

te osoby.


## Art. 607m. {#kpk-art-607m}
§ 1. Postanowienie w przedmiocie przekazania sąd okręgowy 

wydaje w terminie 40 dni od dnia zatrzymania osoby ściganej. Jeżeli osoba ścigana 

złożyła oświadczenie, o którym mowa w art. 607l § 2, termin ten wynosi 3 dni 

i biegnie od dnia złożenia oświadczenia. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 273/356 

§ 1a. Postępowanie w przedmiocie przekazania powinno zakończyć się 

prawomocnie w terminie 60 dni od dnia zatrzymania osoby ściganej lub 10 dni od 

złożenia przez nią oświadczenia, o którym mowa w art. 607l § 2. 

§ 2. W szczególnie uzasadnionych wypadkach, gdy terminy określone w § 1a nie 

mogą być dotrzymane, postępowanie w przedmiocie przekazania powinno zakończyć 

się prawomocnie w terminie kolejnych 30 dni od dnia upływu tych terminów. 

O opóźnieniu należy powiadomić organ sądowy, który wydał nakaz europejski, 

podając przyczynę opóźnienia. 

§ 3. W wypadku, określonym w art. 607k § 4, terminy, o których mowa w § 1 

i 2, biegną od uzyskania zezwolenia na ściganie. Jeżeli bieg tych terminów już się 

rozpoczął, ulega on zawieszeniu do czasu uzyskania zezwolenia.


## Art. 607n. {#kpk-art-607n}
§ 1. Osobę 

ściganą, wobec której 

zapadło prawomocne 

postanowienie o przekazaniu, przekazuje się właściwemu organowi sądowemu 

państwa wydania nakazu europejskiego najpóźniej w terminie 10 dni od dnia 

uprawomocnienia się postanowienia. 

§ 2. Jeżeli przekazanie osoby ściganej w terminie określonym w § 1 nie jest 

możliwe na skutek siły wyższej albo zagrożenia dla życia lub zdrowia tej osoby, osobę 

ściganą, o której mowa w § 1, przekazuje się właściwemu organowi sądowemu 

państwa wydania nakazu europejskiego w ciągu 10 dni od dnia upływu nowo 

ustalonego terminu przekazania. 

§ 3. Jeżeli państwo wydania nakazu europejskiego nie przejmie osoby 

podlegającej przekazaniu w terminach, o których mowa w § 1 albo 2, zarządza się 

niezwłoczne zwolnienie tej osoby, jeżeli nie jest ona pozbawiona wolności w innej 

sprawie.


## Art. 607o. {#kpk-art-607o}
§ 1. Jeżeli przeciwko osobie ściganej jest prowadzone w kraju 

postępowanie karne o inny czyn niż wskazany w nakazie europejskim lub osoba ta ma 

odbyć w kraju za taki czyn karę pozbawienia wolności, sąd, wydając postanowienie 

o przekazaniu, może odroczyć jego wykonanie do czasu zakończenia w kraju 

postępowania karnego lub do czasu wykonania w kraju kary pozbawienia wolności. 

§ 2. W sytuacji określonej w § 1 sąd, po powiadomieniu o jej zaistnieniu organu, 

który wydał nakaz europejski, może, na jego wniosek, czasowo przekazać osobę 

ściganą na warunkach określonych w porozumieniu zawartym z tym organem. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 274/356 

Porozumienie takie powinno być sporządzone na piśmie i określać warunki 

przekazania, w tym zwłaszcza termin powrotnego przekazania osoby ściganej.


## Art. 607p. {#kpk-art-607p}
§ 1. Odmawia się wykonania nakazu europejskiego, jeżeli: 

1) 

przestępstwo, którego dotyczy nakaz europejski, w wypadku jurysdykcji 

polskich sądów karnych, podlega darowaniu na mocy amnestii; 

2) w stosunku do osoby ściganej zapadło w innym państwie prawomocne 

orzeczenie co do tych samych czynów oraz, w wypadku skazania za te same 

czyny, osoba ścigana odbywa karę lub ją odbyła albo kara nie może być 

wykonana według prawa państwa, w którym zapadł wyrok skazujący; 

3) w stosunku do osoby ściganej zapadło prawomocne orzeczenie o przekazaniu do 

innego państwa członkowskiego Unii Europejskiej; 

4) 

osoba, której dotyczy nakaz europejski, z powodu wieku nie ponosi według 

prawa polskiego odpowiedzialności karnej za czyny będące podstawą wydania 

5) 

6) 

nakazu europejskiego; 

naruszałoby to wolności i prawa człowieka i obywatela; 

nakaz wydany został w związku z przestępstwem popełnionym bez użycia 

przemocy z przyczyn politycznych. 

§ 2. Jeżeli nakaz europejski został wydany wobec osoby ściganej, która jest 

obywatelem polskim, wykonanie nakazu może nastąpić pod warunkiem, że czyn, 

którego nakaz europejski dotyczy, nie został popełniony na terytorium Rzeczy-

pospolitej Polskiej ani na polskim statku wodnym lub powietrznym oraz stanowił 

przestępstwo według prawa Rzeczypospolitej Polskiej lub stanowiłby przestępstwo 

według prawa Rzeczypospolitej Polskiej w razie popełnienia na 

terytorium 

Rzeczypospolitej Polskiej, zarówno w czasie jego popełnienia, jak i w chwili 

wpłynięcia nakazu europejskiego.


## Art. 607r. {#kpk-art-607r}
§ 1. Można odmówić wykonania nakazu europejskiego, jeżeli: 

1) 

przestępstwo będące podstawą wydania nakazu europejskiego, inne niż 

wymienione w art. 607w, nie stanowi przestępstwa według prawa polskiego; 

2) 

przeciwko osobie ściganej, której dotyczy nakaz europejski, toczy się 

w Rzeczypospolitej Polskiej postępowanie karne o przestępstwo, które stanowi 

podstawę nakazu europejskiego; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 275/356 

3) wobec osoby ściganej, w związku z czynem będącym podstawą wydania nakazu 

europejskiego zapadło prawomocne orzeczenie o odmowie wszczęcia 

postępowania, o umorzeniu postępowania 

lub 

inne orzeczenie kończące 

postępowanie w sprawie; 

4) według prawa polskiego nastąpiło przedawnienie ścigania lub wykonania kary, 

a przestępstwa, których to dotyczy, podlegały jurysdykcji sądów polskich; 

5) 

nakaz europejski dotyczy przestępstw, które według prawa polskiego zostały 

popełnione, w całości lub w części, na terytorium Rzeczypospolitej Polskiej, jak 

również na polskim statku wodnym lub powietrznym; 

6) 

za czyn zabroniony, którego dotyczy nakaz europejski, w państwie wydania 

nakazu europejskiego można orzec karę dożywotniego pozbawienia wolności 

albo inny środek polegający na pozbawieniu wolności bez możliwości ubiegania 

się o jego skrócenie. 

§ 2. Przepisu § 1 pkt 1 nie stosuje się, jeżeli czyn nie stanowi przestępstwa 

z powodu braku lub odmiennego uregulowania w prawie polskim odpowiednich opłat, 

podatków, ceł lub zasad obrotu dewizowego. 

§ 3. Można także odmówić wykonania nakazu europejskiego, wydanego w celu 

wykonania kary albo środka polegającego na pozbawieniu wolności, orzeczonych pod 

nieobecność osoby ściganej, chyba że: 

a) osobę ściganą wezwano do udziału w postępowaniu lub w inny sposób 

zawiadomiono o terminie i miejscu rozprawy albo posiedzenia, pouczając, 

że niestawiennictwo nie stanowi przeszkody dla wydania orzeczenia albo 

miała ona obrońcę, który był obecny na rozprawie lub posiedzeniu, 

b) po doręczeniu osobie ściganej odpisu orzeczenia wraz z pouczeniem 

o przysługującym jej prawie, terminie i sposobie złożenia w państwie 

wydania nakazu wniosku o przeprowadzenie z jej udziałem nowego 

postępowania sądowego w tej samej sprawie, osoba ścigana w ustawowym 

terminie nie złożyła takiego wniosku albo oświadczyła, że nie kwestionuje 

orzeczenia, 

c) organ, który wydał nakaz europejski, zapewni, że niezwłocznie po 

przekazaniu osoby ściganej do państwa wydania nakazu, zostanie jej 

doręczony odpis orzeczenia wraz z pouczeniem o przysługującym jej 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 276/356 

prawie, terminie i sposobie złożenia wniosku o przeprowadzenie z jej 

udziałem nowego postępowania sądowego w tej samej sprawie.


## Art. 607s. {#kpk-art-607s}
§ 1. Nie podlega wykonaniu nakaz europejski wydany w celu 

wykonania kary pozbawienia wolności lub środka polegającego na pozbawieniu 

wolności wobec osoby ściganej, będącej obywatelem polskim albo korzystającej 

w Rzeczypospolitej Polskiej z prawa azylu, jeżeli nie wyrazi ona zgody na 

przekazanie. 

§ 2. Można także odmówić wykonania nakazu europejskiego, jeżeli został on 

wydany w celu, o którym mowa w § 1, a osoba ścigana ma miejsce zamieszkania lub 

stale przebywa na terytorium Rzeczypospolitej Polskiej. 

§ 3. Odmawiając przekazania, z przyczyn określonych w § 1 lub 2, sąd orzeka 

o wykonaniu kary albo środka, orzeczonych przez organ sądowy państwa wydania 

nakazu europejskiego. 

§ 4. W postanowieniu, o którym mowa w § 3, sąd określa kwalifikację prawną 

czynu według prawa polskiego. Jeżeli kara lub środek, orzeczone przez organ sądowy 

państwa wydania nakazu europejskiego, przekracza górną granicę ustawowego 

zagrożenia, sąd określa podlegającą wykonaniu karę lub środek według prawa 

polskiego, w wysokości odpowiadającej górnej granicy ustawowego zagrożenia, 

uwzględniając okres rzeczywistego pozbawienia wolności za granicą oraz wykonaną 

tam karę lub środek. Jeżeli do nakazu europejskiego nie dołączono dokumentów lub 

informacji niezbędnych do wykonania kary na terytorium Rzeczypospolitej Polskiej, 

sąd odracza posiedzenie i zwraca się do właściwego organu państwa wydania nakazu 

europejskiego o nadesłanie takich dokumentów lub informacji. 

§ 5. Wykonanie kary odbywa się według przepisów prawa polskiego. Przepisy 

rozdziału 66g stosuje się odpowiednio, z wyjątkiem art. 611tg, art. 611ti § 2 i 3, 

art. 611tk, art. 611tm, art. 611to § 2 i art. 611tp.


## Art. 607t. {#kpk-art-607t}
§ 1. Jeżeli nakaz europejski został wydany w celu ścigania osoby, 

która jest obywatelem polskim albo korzysta w Rzeczypospolitej Polskiej z prawa 

azylu, przekazanie może nastąpić pod warunkiem, że osoba ta będzie odesłana na 

terytorium Rzeczypospolitej Polskiej po prawomocnym zakończeniu postępowania 

w państwie wydania nakazu europejskiego, jeśli osoba ta wyraża na to zgodę. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 277/356 

§ 2. W razie skazania osoby, o której mowa w § 1, na karę pozbawienia wolności 

albo orzeczenia wobec niej innego środka polegającego na pozbawieniu wolności 

stosuje się odpowiednio przepisy art. 607s § 3–5.


## Art. 607u. {#kpk-art-607u}
Jeżeli nakaz europejski został wydany w celu wykonania kary albo 

środka polegającego na pozbawieniu wolności, orzeczonych w warunkach 

określonych w art. 607r § 3 lit. c, osobę ściganą należy pouczyć o prawie żądania 

odpisu orzeczenia. Informację o zgłoszeniu żądania odpisu orzeczenia przekazuje się 

niezwłocznie państwu wydania nakazu europejskiego, a po otrzymaniu orzeczenia 

doręcza się go osobie ściganej. Zgłoszenie żądania nie wstrzymuje wykonania nakazu 

europejskiego.


## Art. 607w. {#kpk-art-607w}
Jeżeli nakaz europejski dotyczy osoby niebędącej obywatelem 

polskim, okoliczność, że czyn nie jest przestępstwem według prawa polskiego, nie 

stanowi przeszkody do wykonania nakazu europejskiego, o ile dotyczy on czynu 

zagrożonego w państwie jego wydania karą co najmniej 3 lat pozbawienia wolności 

albo czynu, za który może być orzeczony co najmniej w tym samym wymiarze inny 

środek polegający na pozbawieniu wolności, będącego przestępstwem: 

1) 

udziału w zorganizowanej grupie albo związku mających na celu popełnianie 

2) 

3) 

4) 

5) 

przestępstw; 

o charakterze terrorystycznym; 

handlu ludźmi; 

przeciwko wolności seksualnej lub obyczajności na szkodę małoletniego; 

nielegalnego wytwarzania, przetwarzania, przemytu środków odurzających, 

prekursorów, środków zastępczych lub substancji psychotropowych lub obrotu 

nimi; 

6) 

nielegalnego obrotu bronią, amunicją, materiałami wybuchowymi 

lub 

radioaktywnymi; 

łapownictwa i płatnej protekcji; 

oszustwa; 

7) 

8) 

9) wprowadzania do obrotu finansowego wartości majątkowych pochodzących 

z nielegalnych lub nieujawnionych źródeł; 

10) fałszowania oraz obrotu fałszywymi pieniędzmi 

lub 

innymi środkami 

płatniczymi; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 278/356 

11) przeciwko ochronie danych gromadzonych, przechowywanych, przetwarzanych 

lub przekazywanych w systemie informatycznym; 

12) przeciwko środowisku naturalnemu, w tym nielegalnego obrotu zagrożonymi 

gatunkami zwierząt i roślin; 

13) udzielenia pomocy w nielegalnym przekroczeniu granicy lub pobycie; 

14) zabójstwa; 

15) spowodowania ciężkiego uszczerbku na zdrowiu; 

16) nielegalnego obrotu organami i tkankami ludzkimi; 

17) bezprawnego pozbawienia człowieka wolności; 

18) uprowadzenia człowieka dla okupu; 

19) wzięcia lub przetrzymywania zakładnika; 

20) popełnionym 

z powodów 

narodowościowych, 

etnicznych, 

rasowych, 

wyznaniowych albo ze względu na bezwyznaniowość; 

21) rozboju z użyciem broni palnej lub groźby jej użycia; 

22) wymuszenia rozbójniczego z użyciem broni palnej lub groźby jej użycia; 

23) nielegalnego obrotu dobrami kultury; 

24) sprzeniewierzenia cudzego mienia; 

25) podrabiania oraz obrotu podrobionymi wyrobami; 

26) fałszowania oraz obrotu sfałszowanymi dokumentami; 

27) nielegalnego obrotu hormonami lub podobnymi substancjami; 

28) obrotu kradzionymi pojazdami mechanicznymi; 

29) zgwałcenia; 

30) podpalenia; 

31) należącym do właściwości Międzynarodowego Trybunału Karnego; 

32) porwania statku wodnego lub powietrznego; 

33) sabotażu.


## Art. 607wa. {#kpk-art-607wa}
§ 1. Właściwy sąd lub prokurator na wniosek organu sądowego 

państwa wydania nakazu europejskiego dokonuje zajęcia i przekazania przedmiotów 

pochodzących bezpośrednio z przestępstwa, przedmiotów, które służyły lub były 

przeznaczone do popełnienia przestępstwa, lub mogących stanowić dowód w sprawie 

rzeczy, korespondencji, przesyłek, wykazów połączeń telekomunikacyjnych lub 

innych przekazów 

informacji 

lub danych przechowywanych w systemie 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 279/356 

informatycznym 

lub na nośniku, w tym korespondencji przesyłanej pocztą 

elektroniczną. 

§ 2. Zajęcia i przekazania dowodów i przedmiotów, o których mowa w § 1, 

należy dokonać również wtedy, gdy wykonanie nakazu europejskiego nie jest możliwe 

ze względu na śmierć lub ucieczkę osoby ściganej. 

§ 3. Przy przekazaniu przedmiotów, o których mowa w § 1, można zastrzec ich 

zwrot, w szczególności gdy podlegają one zwrotowi pokrzywdzonemu lub innemu 

uprawnionemu podmiotowi, przebywającemu na 

terytorium Rzeczypospolitej 

Polskiej. 

§ 4. Przepisy rozdziału 62b stosuje się odpowiednio.


## Art. 607x. {#kpk-art-607x}
§ 1. Jeżeli przed wydaniem w pierwszej instancji postanowienia 

w przedmiocie przekazania wpłynie nakaz europejski dotyczący tej samej osoby, 

wydany przez organ sądowy innego państwa członkowskiego Unii Europejskiej, sąd 

rozpoznaje oba nakazy europejskie łącznie. Orzekając o przekazaniu osoby ściganej 

do danego państwa, sąd bierze pod uwagę okoliczności każdej ze spraw, wagę 

przestępstwa i miejsce jego popełnienia, kolejność wydania nakazów europejskich 

oraz ich cele. 

§ 2. Jeżeli kolejny nakaz europejski dotyczący tej samej osoby wpłynie po 

wydaniu w pierwszej instancji postanowienia w przedmiocie poprzedniego nakazu 

europejskiego, sąd odracza rozpoznanie kolejnego nakazu europejskiego do czasu 

uprawomocnienia się tego postanowienia. 

§ 3. W wypadku uchylenia przez sąd odwoławczy postanowienia, o którym 

mowa w § 2, i przekazania nakazu europejskiego do ponownego rozpoznania 

w pierwszej instancji, stosuje się odpowiednio przepisy § 1.


## Art. 607y. {#kpk-art-607y}
§ 1. Jeżeli w stosunku do tej samej osoby ściganej wpłynie nakaz 

europejski oraz wniosek o wydanie państwu obcemu, po rozpoznaniu nakazu 

europejskiego sąd orzeka w przedmiocie dopuszczalności jego wykonania oraz 

zawiesza 

postępowanie 

i zawiadamia 

o treści 

postanowienia Ministra 

Sprawiedliwości. 

§ 2. Jeżeli Minister Sprawiedliwości postanowi o wydaniu państwu obcemu 

osoby, której dotyczy nakaz europejski, postępowanie w przedmiocie nakazu 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 280/356 

europejskiego umarza się. W wypadku odmowy wydania sąd podejmuje zawieszone 

postępowanie i wydaje postanowienie w przedmiocie przekazania.


## Art. 607z. {#kpk-art-607z}
§ 1. Jeżeli informacje przekazane przez państwo wydania nakazu 

europejskiego nie są wystarczające do podjęcia decyzji w przedmiocie przekazania 

osoby ściganej, sąd wzywa organ sądowy, który wydał nakaz europejski, do ich 

uzupełnienia we wskazanym terminie. 

§ 2. W wypadku niedotrzymania 

terminu, o którym mowa w § 1, nakaz 

europejski podlega rozpoznaniu w oparciu o informacje przekazane wcześniej.


## Art. 607za. {#kpk-art-607za}
§ 1. Wniosek właściwego organu sądowego państwa wydania 

nakazu europejskiego o zgodę na ściganie lub wykonanie kar pozbawienia wolności 

albo środków polegających na pozbawieniu wolności za czyny popełnione przed 

przekazaniem albo o zgodę na dalsze przekazanie osoby ściganej rozpatruje sąd 

okręgowy, który orzekł o przekazaniu. Przepisy art. 607b, 607p, 607r, 607s § 1 i 2 oraz 

art. 607z stosuje się odpowiednio. 

§ 2. W przedmiocie wniosku, o którym mowa w § 1, sąd orzeka w terminie 

30 dni od dnia otrzymania wniosku.


## Art. 607zb. {#kpk-art-607zb}
§ 1. Na wniosek państwa wykonania nakazu europejskiego Minister 

Sprawiedliwości udziela zezwolenia na przewóz osoby ściganej na podstawie nakazu 

europejskiego przez terytorium Rzeczypospolitej Polskiej. 

§ 2. Wniosek o zezwolenie na przewóz, o którym mowa w § 1, powinien 

zawierać: 

1) 

2) 

3) 

4) 

5) 

oznaczenie organu wnioskującego; 

datę oraz miejsce wydania nakazu europejskiego; 

dane określające tożsamość i obywatelstwo osoby ściganej; 

przytoczenie opisu i kwalifikacji prawnej czynu; 

zwięzły opis stanu faktycznego sprawy. 

§ 3. Jeżeli osoba 

ścigana 

jest obywatelem polskim 

albo korzysta 

w Rzeczypospolitej Polskiej z prawa azylu, zezwolenie, o którym mowa w § 1, można 

wydać pod warunkiem, że osoba ta po zakończeniu postępowania zostanie przekazana 

do wykonania kary pozbawienia wolności lub środka polegającego na pozbawieniu 

wolności na terytorium Rzeczypospolitej Polskiej. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 281/356 

§ 4. W wypadku korzystania z drogi powietrznej bez planowanego lądowania, 

można poprzestać na powiadomieniu Ministra Sprawiedliwości o przewożeniu osoby 

ściganej nad 

terytorium Rzeczypospolitej Polskiej. 

Jeżeli 

jednak nastąpi 

nieprzewidziane lądowanie, państwo wykonania nakazu europejskiego dostarcza 

niezwłocznie dane, o których mowa w § 2; przepis § 3 stosuje się odpowiednio.


## Art. 607zc. {#kpk-art-607zc}
Jeżeli sąd, do którego został skierowany nakaz europejski, nie jest 

właściwy do nadania mu biegu, przekazuje go właściwemu organowi sądowemu 

i powiadamia o tym organ sądowy, który go wydał. 


# Rozdział 65
c 

Wystąpienie do państwa członkowskiego Unii Europejskiej o wykonanie środka 

zapobiegawczego


## Art. 607zd. {#kpk-art-607zd}
§ 1. W razie orzeczenia przez polski sąd lub prokuratora środka 

zapobiegawczego określonego w art. 272, art. 275, art. 275a lub art. 276 oraz jeżeli 

zapewni to prawidłowy tok postępowania, sąd lub prokurator może wystąpić 

o wykonanie tego orzeczenia do właściwego sądu lub innego organu państwa 

członkowskiego Unii Europejskiej, zwanego w niniejszym rozdziale „państwem 

wykonania orzeczenia”, w którym oskarżony posiada legalne stałe miejsce pobytu, 

o ile przebywa on w tym państwie lub oświadczy, że zamierza tam powrócić. 

§ 2. Wystąpienie, o którym mowa w § 1, może być na wniosek oskarżonego 

skierowane również do innego państwa członkowskiego niż państwo legalnego stałego 

miejsca pobytu oskarżonego, za zgodą właściwego sądu lub innego organu tego 

państwa. 

§ 3. Wystąpienie, o którym mowa w § 1, sąd lub prokurator kieruje każdorazowo 

wyłącznie do jednego państwa wykonania orzeczenia. Ponowne wystąpienie do 

innego państwa wykonania orzeczenia może nastąpić jedynie w razie niewykonania 

albo częściowego wykonania orzeczenia. 

§ 4. Do poświadczonego za zgodność z oryginałem odpisu orzeczenia, o którym 

mowa w § 1, dołącza się zaświadczenie zawierające informacje umożliwiające jego 

prawidłowe wykonanie dotyczące: orzeczenia, osoby oskarżonego, środka 

zapobiegawczego i kwalifikacji prawnej czynu. 

§ 5. Zaświadczenie powinno zostać przetłumaczone na język urzędowy państwa 

wykonania orzeczenia albo na inny język wskazany przez to państwo. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 282/356 

§ 6. Przekazanie odpisu orzeczenia oraz zaświadczenia, o którym mowa w § 4, 

może nastąpić również z wykorzystaniem urządzeń służących do automatycznego 

przesyłania danych, w sposób umożliwiający stwierdzenie autentyczności tych 

dokumentów. Na żądanie właściwego sądu lub innego organu państwa wykonania 

orzeczenia sąd 

lub prokurator przekazuje odpis orzeczenia oraz oryginał 

zaświadczenia. 

§ 7. W razie trudności w ustaleniu właściwego sądu lub innego organu państwa 

wykonania orzeczenia sąd lub prokurator może również zwracać się do właściwych 

jednostek organizacyjnych Europejskiej Sieci Sądowej. 

§ 8. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, wzór 

zaświadczenia, o którym mowa w § 4, mając na uwadze konieczność udostępnienia 

państwu wykonania orzeczenia wszelkich niezbędnych informacji umożliwiających 

podjęcie prawidłowej decyzji w przedmiocie wykonania orzeczenia.


## Art. 607ze. {#kpk-art-607ze}
§ 1. Do chwili otrzymania informacji o przejęciu wykonania 

orzeczenia, o którym mowa w art. 607zd § 1, przez właściwy sąd lub inny organ 

państwa wykonania orzeczenia, a także w razie otrzymania informacji o niemożności 

lub odmowie wykonania orzeczenia przez właściwy sąd lub inny organ państwa 

wykonania orzeczenia, o zaprzestaniu jego wykonywania przez ten organ, a także 

w wypadku cofnięcia wystąpienia środek zapobiegawczy 

jest wykonywany 

w dalszym ciągu przez właściwy organ. 

§ 2. W razie otrzymania informacji o dostosowaniu środka zapobiegawczego do 

prawa państwa wykonania orzeczenia i przed rozpoczęciem wykonywania tego środka 

w tym państwie sąd lub prokurator w ciągu 10 dni od dnia otrzymania informacji może 

cofnąć wystąpienie, o którym mowa w art. 607zd § 1, mając na uwadze cele środka.


## Art. 607zf. {#kpk-art-607zf}
§ 1. W razie zmiany lub uchylenia środka zapobiegawczego albo 

zmiany obowiązków nałożonych na oskarżonego sąd lub prokurator niezwłocznie 

zawiadamia o tym właściwy sąd lub inny organ państwa wykonania orzeczenia. 

§ 2. Zawiadomienie, o którym mowa w § 1, może być przekazane również przy 

użyciu urządzeń służących do automatycznego przesyłania danych, w sposób 

umożliwiający stwierdzenie autentyczności przekazanych dokumentów. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 283/356


## Art. 607zg. {#kpk-art-607zg}
Na postanowienie sądu lub prokuratora w sprawie wystąpienia do 

właściwego sądu lub innego organu państwa wykonania orzeczenia zażalenie nie 

przysługuje. 


# Rozdział 65
d 

Wystąpienie państwa członkowskiego Unii Europejskiej o wykonanie orzeczenia 

wydanego w celu zapewnienia prawidłowego toku postępowania


## Art. 607zh. {#kpk-art-607zh}
§ 1. W razie wystąpienia państwa 

członkowskiego Unii 

Europejskiej, zwanego w niniejszym rozdziale „państwem wydania orzeczenia”, 

o wykonanie orzeczenia wydanego w celu zapewnienia prawidłowego 

toku 

postępowania i nakładającego na osobę, przeciwko której w tym państwie prowadzone 

jest postępowanie karne, obowiązek: 

1) 

2) 

3) 

stawiennictwa przed określonym organem, 

powstrzymania się od opuszczania miejsca pobytu lub kraju, 

informowania określonego organu o zmianie miejsca pobytu albo uzyskiwania 

zgody na taką zmianę, 

4) 

przebywania albo powstrzymania się od przebywania w określonych 

środowiskach lub miejscach, 

5) 

powstrzymania się od kontaktów z określonymi osobami lub zbliżania się do 

określonych osób, 

6) 

7) 

8) 

powstrzymania się od wykonywania czynności służbowych lub zawodu, 

powstrzymania się od określonej działalności, 

powstrzymania się od prowadzenia określonego rodzaju pojazdów 

– orzeczenie to podlega wykonaniu przez prokuratora właściwego miejscowo ze 

względu na legalne stałe miejsce pobytu tej osoby. 

§ 2. Do orzeczenia, o którym mowa w § 1, lub jego odpisu poświadczonego za 

zgodność z oryginałem powinno być dołączone zaświadczenie zawierające informacje 

umożliwiające jego prawidłowe wykonanie. 

§ 3. Jeżeli prokurator, do którego zostało skierowane wystąpienie, nie jest 

właściwy do nadania mu biegu, przekazuje 

je właściwemu prokuratorowi 

i zawiadamia o tym właściwy sąd lub inny organ państwa wydania orzeczenia. 

§ 4. Na wniosek właściwego sądu lub innego organu państwa wydania 

orzeczenia prokurator może wyrazić zgodę na wykonanie orzeczenia, o którym mowa 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 284/356 

w § 1, wydanego wobec osoby określonej w tym paragrafie, nieposiadającej legalnego 

stałego miejsca pobytu na terytorium Rzeczypospolitej Polskiej, jeżeli w większym 

stopniu zapewni to prawidłowy tok postępowania. 

§ 5. Jeżeli przepisy niniejszego 

rozdziału nie stanowią 

inaczej, przy 

wykonywaniu orzeczeń, o których mowa w § 1, stosuje się przepisy prawa polskiego.


## Art. 607zi. {#kpk-art-607zi}
§ 1. Jeżeli państwo wydania orzeczenia nie przekazało wszystkich 

informacji potrzebnych do podjęcia decyzji w przedmiocie wykonania orzeczenia, 

prokurator wzywa właściwy sąd lub inny organ państwa wydania orzeczenia do ich 

uzupełnienia we wskazanym terminie. W razie niedotrzymania terminu postanowienie 

w przedmiocie wykonania orzeczenia wydaje się w oparciu o posiadane informacje. 

§ 2. Jeżeli rodzaj albo sposób wykonania obowiązków są nieznane ustawie, 

prokurator określa środek lub obowiązek według prawa polskiego, z uwzględnieniem 

różnic na korzyść osoby, przeciwko której w państwie wydania orzeczenia 

prowadzone jest postępowanie karne.


## Art. 607zj. {#kpk-art-607zj}
§ 1. Postanowienie w przedmiocie wykonania orzeczenia, o którym 

mowa w art. 607zh § 1, prokurator wydaje w terminie 30 dni od dnia otrzymania 

orzeczenia wraz z zaświadczeniem. 

§ 2. Na postanowienie prokuratora w przedmiocie wykonania orzeczenia, 

o którym mowa w art. 607zh § 1, przysługuje zażalenie do sądu rejonowego, w okręgu 

którego osoba, przeciwko której w państwie wydania orzeczenia prowadzone jest 

postępowanie karne, posiada legalne stałe miejsce pobytu. Sąd rozpoznaje zażalenie 

na posiedzeniu, w którym ma prawo wziąć udział prokurator, osoba wymieniona 

w zdaniu pierwszym, jeżeli przebywa na terytorium Rzeczypospolitej Polskiej, i jej 

obrońca, jeżeli się na nie stawi. Jeżeli osoba wymieniona w zdaniu pierwszym nie 

przebywa na terytorium Rzeczypospolitej Polskiej i nie posiada obrońcy, prezes sądu 

właściwego do rozpoznania zażalenia może jej wyznaczyć obrońcę z urzędu. 

§ 3. Postępowanie w przedmiocie wykonania orzeczenia powinno zakończyć się 

prawomocnie w terminie 60 dni od dnia otrzymania orzeczenia wraz 

z zaświadczeniem. 

§ 4. W wypadku gdy termin określony w § 3 nie może być dotrzymany, należy 

zawiadomić właściwy sąd lub inny organ państwa wydania orzeczenia o przyczynie 

opóźnienia i podać przewidywany termin wydania postanowienia. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 285/356 

§ 5. Do wykonania orzeczenia właściwego sądu lub innego organu państwa 

wydania orzeczenia prokurator przystępuje niezwłocznie.


## Art. 607zk. {#kpk-art-607zk}
§ 1. Odmawia się wykonania orzeczenia, o którym mowa 

w art. 607zh § 1, jeżeli: 

1) 

czyn, w związku z którym zastosowano środek zapobiegawczy, nie stanowi 

przestępstwa według prawa polskiego; 

2) 

osoba, przeciwko której w państwie wydania orzeczenia prowadzone jest 

postępowanie karne, nie przebywa na terytorium Rzeczypospolitej Polskiej, 

chyba że istnieją podstawy do uznania, że na nie powróci. 

§ 2. Przepisu § 1 pkt 1 nie stosuje się, jeżeli czyn nie stanowi przestępstwa 

z powodu braku lub odmiennego uregulowania w prawie polskim odpowiednich opłat, 

podatków, ceł lub zasad obrotu dewizowego. 

§ 3. Można odmówić wykonania orzeczenia, o którym mowa w art. 607zh § 1, 

jeżeli: 

1) 

pomimo wezwania przez prokuratora do uzupełnienia informacji we wskazanym 

terminie do orzeczenia nie dołączono zaświadczenia, o którym mowa 

w art. 607zh § 2, albo zaświadczenie to jest niekompletne lub w sposób 

oczywisty niezgodne z treścią orzeczenia; 

2) 

przekazane do wykonania orzeczenie dotyczy tego samego czynu tej samej 

osoby, co do której postępowanie karne zostało prawomocnie zakończone 

w państwie członkowskim Unii Europejskiej, a osoba ta odbywa karę lub ją 

odbyła albo kara nie może być wykonana według prawa państwa, w którym 

zapadł wyrok skazujący; 

3) według prawa polskiego nastąpiło przedawnienie wykonania kary, 

a przestępstwo, którego to dotyczy, podlegało jurysdykcji sądów polskich; 

4) 

orzeczenie dotyczy przestępstwa, które według prawa polskiego zostało 

popełnione w całości albo w części na terytorium Rzeczypospolitej Polskiej, jak 

również na polskim statku wodnym lub powietrznym; 

5) 

osoba, przeciwko której w państwie wydania orzeczenia prowadzone jest 

postępowanie karne, z powodu wieku nie ponosi według prawa polskiego 

odpowiedzialności karnej za czyn będący podstawą wydania orzeczenia; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 286/356 

6) 

osoba, przeciwko której w państwie wydania orzeczenia prowadzone jest 

postępowanie karne, korzysta z immunitetu, zgodnie z którym niemożliwy jest 

nadzór nad przestrzeganiem nałożonych obowiązków; 

7) 

orzeczenie dotyczy wyłącznie obowiązków innych niż określone w art. 607zh 

§ 1; 

8) 

orzeczenie zostało przekazane pomimo niespełnienia warunków przewidzianych 

w art. 607zh § 4; 

9) 

przestępstwo, którego dotyczy orzeczenie, w wypadku jurysdykcji polskich 

sądów karnych podlegałoby darowaniu na mocy amnestii; 

10) pomimo niestosowania się osoby, przeciwko której w państwie wydania 

orzeczenia prowadzone jest postępowanie karne, do wymagań określonych 

w orzeczeniu nie jest możliwe przekazanie jej z terytorium Rzeczypospolitej 

Polskiej na podstawie europejskiego nakazu aresztowania. 

§ 4. W wypadku wskazanym w § 3 pkt 10, gdy przemawiają za tym szczególne 

względy, prokurator, w uzgodnieniu z właściwym sądem lub innym organem państwa 

wydania orzeczenia, może orzec o wykonaniu orzeczenia. 

§ 5. W wypadkach przewidzianych w § 1 pkt 2 oraz w § 3 pkt 1, 2 i 7 prokurator 

przed podjęciem decyzji w przedmiocie wykonania orzeczenia 

informuje 

o możliwości odmowy wykonania orzeczenia właściwy sąd lub inny organ państwa 

wydania orzeczenia.


## Art. 607zl. {#kpk-art-607zl}
§ 1. W razie otrzymania od właściwego sądu lub innego organu 

państwa wydania orzeczenia informacji o tym, iż orzeczenie przekazane do wykonania 

nie podlega dalszemu wykonaniu, prokurator niezwłocznie wydaje postanowienie 

o zaprzestaniu wykonywania orzeczenia. 

§ 2. Jeżeli dalsze wykonywanie orzeczenia nie jest możliwe z przyczyn 

faktycznych 

lub prawnych, prokurator niezwłocznie wydaje postanowienie 

o zaprzestaniu wykonywania orzeczenia i zawiadamia właściwy sąd lub inny organ 

państwa wydania orzeczenia. 

§ 3. W razie otrzymania od właściwego sądu lub innego organu państwa wydania 

orzeczenia informacji o zmianie obowiązku nałożonego na osobę, przeciwko której 

w państwie wydania orzeczenia prowadzone jest postępowanie karne, prokurator 

rozpoznaje sprawę wykonania zmienionego orzeczenia na zasadach określonych 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 287/356 

w niniejszym rozdziale. Przepisu art. 607zk nie stosuje się, z wyjątkiem § 1 pkt 2 i § 3 

pkt 7.


## Art. 607zm. {#kpk-art-607zm}
§ 1. O treści postanowienia w przedmiocie wykonania orzeczenia, 

o którym mowa w art. 607zh § 1, o wniesieniu środka odwoławczego od tego 

postanowienia, o istotnych orzeczeniach zapadłych w trakcie postępowania, jak 

również w razie zmiany legalnego stałego miejsca pobytu przez osobę, przeciwko 

której w państwie wydania orzeczenia prowadzone jest postępowanie karne, 

zawiadamia się niezwłocznie właściwy sąd lub inny organ państwa wydania 

orzeczenia. 

§ 2. Prokurator zawiadamia niezwłocznie właściwy sąd lub inny organ państwa 

wydania orzeczenia o wszelkich okolicznościach mających wpływ na jego wykonanie. 

Zawiadomienie następuje w formie zaświadczenia zawierającego 

informacje 

dotyczące osoby określonej w § 1 oraz naruszonego obowiązku. 

§ 3. W razie ustania przyczyn, na skutek których obowiązek został zastosowany, 

lub powstania przyczyn uzasadniających jego uchylenie lub zmianę prokurator może 

wystąpić do właściwego sądu lub innego organu państwa wydania orzeczenia o jego 

uchylenie lub zmianę. 

§ 4. Zawiadomienia, o których mowa w § 1 i 2 oraz wystąpienie, o którym mowa 

w § 3, mogą być przekazane również przy użyciu urządzeń służących do 

automatycznego przesyłania danych, w sposób umożliwiający 

stwierdzenie 

autentyczności przekazanych dokumentów. 

§ 5. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, wzór 

zaświadczenia, o którym mowa w § 2, mając na uwadze konieczność udostępnienia 

państwu wydania orzeczenia wszelkich niezbędnych informacji umożliwiających 

podjęcie prawidłowej decyzji.


## Art. 607zn. {#kpk-art-607zn}
Koszty związane z wykonaniem orzeczenia, o którym mowa 

w art. 607zh § 1, ponosi Skarb Państwa. 


# Rozdział 66
 

Przejęcie i przekazanie orzeczeń do wykonania


## Art. 608. {#kpk-art-608}
§ 1. W razie prawomocnego skazania obywatela polskiego przez sąd 

państwa obcego na karę pozbawienia wolności podlegającą wykonaniu albo 

prawomocnego orzeczenia wobec obywatela polskiego środka polegającego na 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 288/356 

pozbawieniu wolności, Minister Sprawiedliwości może wystąpić do właściwego 

organu tego państwa z wnioskiem o przejęcie skazanego albo osoby, wobec której 

orzeczono środek, w celu wykonania kary pozbawienia wolności lub środka 

w Rzeczypospolitej Polskiej. 

§ 2. W razie prawomocnego skazania przez sąd państwa obcego obywatela 

polskiego, osoby mającej miejsce stałego pobytu, posiadającej mienie lub prowadzącej 

działalność zawodową na terytorium Rzeczypospolitej Polskiej, na grzywnę lub 

w razie prawomocnego orzeczenia wobec niej zakazu zajmowania określonego 

stanowiska, wykonywania określonego zawodu 

lub prowadzenia określonej 

działalności gospodarczej, zakazu prowadzenia pojazdów, przepadku albo środka 

zabezpieczającego nie polegającego na pozbawieniu wolności, Minister 

Sprawiedliwości może wystąpić do właściwego organu tego państwa z wnioskiem 

o przejęcie orzeczenia do wykonania w Rzeczypospolitej Polskiej. 

§ 3. Przed wystąpieniem z wnioskiem, o którym mowa w § 1 lub 2, Minister 

Sprawiedliwości zwraca się do właściwego sądu o wydanie postanowienia 

w przedmiocie dopuszczalności przejęcia orzeczenia do wykonania w Rzeczy-

pospolitej Polskiej.


## Art. 609. {#kpk-art-609}
§ 1. W razie otrzymania wniosku państwa obcego o wykonanie wobec 

obywatela polskiego lub osoby mającej miejsce stałego pobytu na terytorium 

Rzeczypospolitej Polskiej prawomocnie orzeczonej kary pozbawienia wolności lub 

środka polegającego na pozbawieniu wolności, Minister Sprawiedliwości zwraca się 

do właściwego sądu o wydanie postanowienia w przedmiocie dopuszczalności 

przejęcia orzeczenia do wykonania na terytorium Rzeczypospolitej Polskiej. 

§ 2. W razie otrzymania wniosku państwa obcego o wykonanie wobec obywatela 

polskiego, osoby mającej miejsce stałego pobytu, posiadającej mienie lub prowadzącej 

działalność zawodową w Rzeczypospolitej Polskiej prawomocnie orzeczonej 

grzywny, zakazu zajmowania określonego stanowiska, wykonywania określonego 

zawodu lub prowadzenia określonej działalności gospodarczej, zakazu prowadzenia 

pojazdów, przepadku albo środka zabezpieczającego nie polegającego na pozbawieniu 

wolności, Minister Sprawiedliwości zwraca się do właściwego sądu o wydanie 

postanowienia w przedmiocie dopuszczalności przejęcia orzeczenia do wykonania 

w Rzeczypospolitej Polskiej. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 289/356 

§ 3. Jeżeli orzeczenie, którego wniosek dotyczy, nie jest prawomocne lub osoba 

objęta wnioskiem określonym w § 1 nie jest obywatelem polskim lub nie ma na 

terytorium Rzeczypospolitej Polskiej miejsca stałego pobytu, Minister Sprawied-

liwości zwraca wniosek.


## Art. 610. {#kpk-art-610}
§ 1. W razie prawomocnego skazania cudzoziemca przez sąd polski na 

karę pozbawienia wolności podlegającą wykonaniu albo prawomocnego orzeczenia 

wobec niego środka polegającego na pozbawieniu wolności, Minister Sprawiedliwości 

może wystąpić do właściwego organu państwa, którego skazany albo osoba, wobec 

której orzeczono środek, jest obywatelem, z wnioskiem o przejęcie go w celu odbycia 

kary lub wykonania środka. 

§ 2. Przed wystąpieniem z wnioskiem, o którym mowa w § 1, Minister 

Sprawiedliwości zwraca się do właściwego sądu o wydanie postanowienia 

w przedmiocie dopuszczalności przekazania orzeczenia do wykonania za granicą. 

§ 3. W razie otrzymania wniosku państwa obcego o przejęcie cudzoziemca 

prawomocnie skazanego przez sąd polski na karę pozbawienia wolności podlegającą 

wykonaniu albo wobec którego prawomocnie orzeczono środek polegający na 

pozbawieniu wolności, Minister Sprawiedliwości zwraca się do właściwego sądu 

o wydanie postanowienia w przedmiocie dopuszczalności przekazania orzeczenia do 

wykonania za granicą. 

§ 4. W razie prawomocnego skazania przez sąd polski osoby mającej miejsce 

stałego pobytu za granicą albo posiadającej mienie lub prowadzącej działalność 

zawodową za granicą na grzywnę lub prawomocnego orzeczenia wobec niej zakazu 

zajmowania określonego stanowiska, wykonywania określonego zawodu 

lub 

prowadzenia określonej działalności gospodarczej, zakazu prowadzenia pojazdów, 

przepadku albo środka zabezpieczającego nie polegającego na pozbawieniu wolności, 

sąd właściwy do wykonania kary lub środka może wystąpić za pośrednictwem 

Ministra Sprawiedliwości do właściwego organu państwa, na terytorium którego 

skazany lub osoba, wobec której orzeczono środek, stale przebywa, posiada mienie 

lub prowadzi działalność, z wnioskiem o wykonanie orzeczenia. 

§ 5. W razie otrzymania wniosku państwa obcego o przejęcie do wykonania 

prawomocnego skazania przez sąd polski osoby mającej miejsce stałego pobytu w tym 

państwie albo posiadającej mienie lub prowadzącej działalność zawodową w tym 

państwie na grzywnę lub prawomocnego orzeczenia wobec niej zakazu zajmowania 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 290/356 

określonego stanowiska, zakazu wykonywania określonego zawodu lub prowadzenia 

określonej działalności gospodarczej, zakazu prowadzenia pojazdów, przepadku albo 

środka zabezpieczającego nie polegającego na pozbawieniu wolności, Minister 

Sprawiedliwości zwraca się do właściwego sądu o wydanie postanowienia 

w przedmiocie dopuszczalności przekazania orzeczenia do wykonania za granicą.


## Art. 610a. {#kpk-art-610a}
Minister Sprawiedliwości może zawrzeć z odpowiednim organem 

państwa obcego porozumienie przewidujące podział kwot 

lub przedmiotów 

uzyskanych z wykonania orzeczenia skazującego na grzywnę lub z orzeczenia 

przepadku, o których mowa w art. 609 § 2 oraz art. 610 § 4 i 5.


## Art. 611. {#kpk-art-611}
§ 1. Właściwy do rozpoznania spraw określonych w art. 608 § 3 

w związku z § 1 i art. 609 § 1 jest sąd okręgowy, w którego okręgu skazany ostatnio 

stale mieszkał lub czasowo przebywał. 

2. (uchylony) 

§ 3. Właściwy do rozpoznania spraw określonych w art. 610 § 2 i 3 jest sąd 

okręgowy, w którego okręgu wydano orzeczenie, którego wniosek dotyczy. 

§ 3a. Do rozpoznania spraw innych niż określone w § 1 i 3 właściwy jest sąd 

rejonowy, w którego okręgu skazany stale mieszkał lub czasowo przebywał, a jeżeli 

tego nie ustalono – sąd rejonowy, w którego okręgu znajduje się mienie nadające się 

do egzekucji lub w którego okręgu skazany prowadzi działalność objętą zakazem. 

§ 4. Jeżeli nie można ustalić właściwości według zasad określonych w § 1, 

sprawę rozpoznaje Sąd Okręgowy w Warszawie. 

§ 5. Jeżeli nie można ustalić właściwości według zasad określonych w § 3a, 

sprawę rozpoznaje sąd właściwy dla dzielnicy Śródmieście miasta stołecznego 

Warszawy.


## Art. 611a. {#kpk-art-611a}
§ 1. Sąd 

rozpoznaje sprawę dopuszczalności przejęcia 

lub 

przekazania orzeczenia do wykonania na posiedzeniu, w którym ma prawo wziąć 

udział prokurator i skazany, jeżeli przebywa na terytorium Rzeczypospolitej Polskiej, 

oraz obrońca skazanego, jeżeli się na nie stawi. Jeżeli skazany, który nie przebywa na 

terytorium Rzeczypospolitej Polskiej, nie posiada obrońcy, prezes sądu właściwego 

do rozpoznania sprawy może mu wyznaczyć obrońcę z urzędu. 

§ 2. Jeżeli dane zawarte we wniosku są niewystarczające, sąd może zarządzić ich 

uzupełnienie. W tym celu sąd może odroczyć rozpoznanie sprawy. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 291/356 

§ 3. Jeżeli sąd wydał postanowienie o niedopuszczalności przejęcia 

lub 

przekazania orzeczenia do wykonania, przejęcie ani przekazanie nie może nastąpić. 

§ 4. W wypadku określonym w art. 610 § 4 sąd wydaje postanowienie 

o wystąpieniu z wnioskiem do organu obcego państwa o przejęcie orzeczenia do 

wykonania. 

§ 5. Na postanowienie sądu w przedmiocie przejęcia lub przekazania orzeczenia 

do wykonania przysługuje zażalenie. 

§ 6. Jeżeli postępowanie dotyczy przejęcia orzeczenia do wykonania, sąd może 

orzec środek zapobiegawczy.


## Art. 611b. {#kpk-art-611b}
§ 1. Przejęcie orzeczenia do wykonania w Rzeczypospolitej Polskiej 

jest niedopuszczalne, jeżeli: 

1) 

orzeczenie nie jest prawomocne albo nie podlega wykonaniu; 

2) wykonanie orzeczenia mogłoby naruszać suwerenność, bezpieczeństwo lub 

porządek prawny Rzeczypospolitej Polskiej; 

3) 

skazany na karę pozbawienia wolności lub osoba, wobec której orzeczono środek 

polegający na pozbawieniu wolności, nie wyraża zgody na przejęcie; 

4) 

skazany na grzywnę albo wobec którego orzeczono przepadek, niezamieszkujący 

na stałe na terytorium Rzeczypospolitej Polskiej, nie posiada mienia na jej 

terytorium; 

5) 

czyn wskazany we wniosku nie stanowi czynu zabronionego według prawa 

polskiego; 

6) 

zachodzą okoliczności, o których mowa w art. 604 § 1 pkt 2, 3 i 5. 

§ 2. Przekazanie orzeczenia do wykonania w państwie obcym 

jest 

niedopuszczalne, jeżeli: 

1) 

2) 

orzeczenie nie jest prawomocne albo nie podlega wykonaniu; 

skazany na karę pozbawienia wolności lub osoba, wobec której orzeczono środek 

polegający na pozbawieniu wolności, nie wyraża zgody na przekazanie; 

3) 

skazany na karę pozbawienia wolności lub osoba, wobec której orzeczono środek 

polegający na pozbawieniu wolności, jest osobą określoną w art. 604 § 1 pkt 1; 

4) 

zachodzą okoliczności, o których mowa w art. 604 § 1 pkt 3 i 5.


## Art. 611c. {#kpk-art-611c}
§ 1. Po przejęciu orzeczenia do wykonania sąd określa kwalifikację 

prawną czynu według prawa polskiego oraz karę i środek podlegające wykonaniu. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 292/356 

§ 2. Określając karę lub środek podlegające wykonaniu, sąd stosuje odpowiednio 

przepis art. 114 § 4 Kodeksu karnego. 

§ 3. Określając wysokość grzywny, sąd dokonuje przeliczenia wysokości 

grzywny orzeczonej kwotowo lub wysokości stawki dziennej, określonych w obcej 

walucie, według kursu średniego walut określonego przez Narodowy Bank Polski na 

dzień wydania orzeczenia w państwie obcym. Jeżeli grzywnę wymierzono kwotowo, 

kwota grzywny nie może przekroczyć iloczynu wysokości stawki dziennej i ilości 

stawek dziennych. 

§ 4. Sąd rozpoznaje sprawę na posiedzeniu. Przepisy art. 352 oraz 611a § 1 

i 5 stosuje się odpowiednio.


## Art. 611d. {#kpk-art-611d}
§ 1. Jeżeli w toku postępowania zajdą okoliczności uzasadniające 

wydanie orzeczenia o zabezpieczeniu majątkowym z uwagi na grożący przepadek 

przedmiotów albo mienia stanowiącego korzyść majątkową osiągniętą z popełnienia 

przestępstwa, a przedmioty te lub składniki tego mienia znajdują się na terytorium 

państwa obcego, sąd, a w postępowaniu przygotowawczym prokurator, może 

wystąpić za pośrednictwem Ministra Sprawiedliwości do właściwego organu tego 

państwa o zabezpieczenie przedmiotów lub mienia zagrożonych przepadkiem. 

§ 2. Jeżeli organ państwa obcego zwróci się o wykonanie prawomocnego 

orzeczenia o zabezpieczeniu mienia, gdy mienie podlegające zabezpieczeniu znajduje 

się na terytorium Rzeczypospolitej Polskiej, właściwy do wykonania orzeczenia jest 

sąd rejonowy lub prokurator, w którego okręgu znajduje się to mienie.


## Art. 611e. {#kpk-art-611e}
Jeżeli skazany prawomocnym wyrokiem albo wobec którego 

prawomocnie orzeczono środek, opuści terytorium państwa skazania, udając się na 

terytorium państwa, którego jest obywatelem, zanim odbędzie orzeczoną karę albo 

zanim zostanie wykonany orzeczony wobec niego środek, przepisy niniejszego 

rozdziału stosuje się odpowiednio. Przepisów art. 611b § 1 pkt 3 oraz § 2 pkt 2 nie 

stosuje się.


## Art. 611ea. {#kpk-art-611ea}
§ 1. Jeżeli umowa międzynarodowa, której Rzeczpospolita Polska 

jest stroną, przewiduje bezpośrednie przekazywanie wniosków o przejęcie 

i przekazanie orzeczeń do wykonania między polskimi sądami a właściwymi 

organami państwa obcego, to: 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 293/356 

1) 

przepisów niniejszego 

rozdziału o udziale Ministra Sprawiedliwości 

w przejmowaniu i przekazywaniu orzeczeń do wykonania nie stosuje się; 

2) 

postępowanie w przedmiocie dopuszczalności przejęcia lub przekazania można 

wszcząć z urzędu; 

3) 

o przekazanie orzeczenia do wykonania sąd może do właściwego organu państwa 

obcego zwrócić się z urzędu; 

4) 

stwierdzenie dopuszczalności przejęcia lub przekazania jest równoznaczne ze 

zgodą na przejęcie lub przekazanie; 

5) 

stwierdzenie niedopuszczalności przejęcia lub przekazania jest równoznaczne 

z odmową zgody na przejęcie lub przekazanie. 

§ 2. Minister Sprawiedliwości może przejąć prowadzenie każdej sprawy 

w przedmiocie przejęcia lub przekazania orzeczenia do wykonania, jeżeli umowa 

międzynarodowa nie sprzeciwia się temu. 

§ 3. Minister Sprawiedliwości może zażądać przedstawienia mu niezbędnych 

informacji lub kopii dokumentów z akt sprawy, jeśli zachodzi konieczność, aby 

rozważył przejęcie prowadzenia sprawy o przejęcie lub przekazanie orzeczenia do 

wykonania. 

§ 4. Przejęcie prowadzenia sprawy przez Ministra Sprawiedliwości może 

nastąpić do czasu prawomocnego zakończenia postępowania w przedmiocie 

dopuszczalności przejęcia lub przekazania orzeczenia do wykonania. W razie 

skutecznego przejęcia sprawy przepisu § 1 nie stosuje się, a postępowanie prowadzi 

się od początku.


## Art. 611f. {#kpk-art-611f}
Przepisy niniejszego rozdziału stosuje się odpowiednio do przejęcia 

lub przekazania do wykonania orzeczeń o karach pieniężnych. 


# Rozdział 66
a 

Wystąpienie do państwa członkowskiego Unii Europejskiej o wykonanie 

orzeczenia dotyczącego grzywny, nawiązki, świadczenia pieniężnego lub 

orzeczenia zasądzającego od sprawcy koszty procesu


## Art. 611fa. {#kpk-art-611fa}
§ 1. W razie prawomocnego orzeczenia przez sąd polski wobec 

obywatela polskiego lub cudzoziemca grzywny, nawiązki, świadczenia pieniężnego 

lub zasądzenia od sprawcy kosztów procesu sąd może wystąpić o jego wykonanie 

bezpośrednio do właściwego sądu lub innego organu państwa członkowskiego Unii 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 294/356 

Europejskiej, zwanego w niniejszym rozdziale „państwem wykonania orzeczenia”, 

w którym sprawca posiada mienie lub osiąga dochody albo ma stałe lub czasowe 

miejsce pobytu. 

§ 2. Wystąpienie, o którym mowa w § 1, każdorazowo sąd kieruje wyłącznie do 

jednego państwa wykonania orzeczenia. Ponowne wystąpienie do innego państwa 

wykonania orzeczenia może nastąpić jedynie w razie niewykonania albo częściowego 

wykonania orzeczenia. 

§ 3. Do poświadczonego za zgodność z oryginałem odpisu orzeczenia, o którym 

mowa w § 1, dołącza się zaświadczenie zawierające wszystkie istotne informacje 

umożliwiające jego prawidłowe wykonanie. 

§ 4. Zaświadczenie powinno zostać przetłumaczone na język urzędowy państwa 

wykonania orzeczenia albo na inny język wskazany przez to państwo. 

§ 5. Przekazanie odpisu orzeczenia oraz zaświadczenia, o którym mowa w § 3, 

może nastąpić również z wykorzystaniem urządzeń służących do automatycznego 

przesyłania danych, w sposób umożliwiający stwierdzenie autentyczności tych 

dokumentów. Na żądanie właściwego sądu lub innego organu państwa wykonania 

orzeczenia sąd przekazuje odpis orzeczenia oraz oryginał zaświadczenia. 

§ 6. W razie trudności w ustaleniu właściwego sądu lub innego organu państwa 

wykonania orzeczenia sąd może również zwracać się do właściwych jednostek 

organizacyjnych Europejskiej Sieci Sądowej. 

§ 7. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, wzór 

zaświadczenia, o którym mowa w § 3, obejmujący szczegółowe informacje dotyczące 

przekazanego do wykonania orzeczenia, w tym informacje o każdej wpłacie 

dokonanej na poczet orzeczonej kary, środka karnego, środka kompensacyjnego lub 

kosztów procesu oraz o ewentualnej zgodzie na zamianę grzywny na pracę społecznie 

użyteczną, wykonanie zastępczej kary pozbawienia wolności lub inny środek, mając 

na uwadze konieczność udostępnienia państwu wykonania orzeczenia wszelkich 

niezbędnych 

informacji 

umożliwiających 

podjęcie 

prawidłowej 

decyzji 

w przedmiocie wykonania orzeczenia.


## Art. 611fb. {#kpk-art-611fb}
§ 1. Kwoty uzyskane z egzekucji orzeczeń, o których mowa 

w art. 611fa § 1, przypadają państwu wykonania orzeczenia. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 295/356 

§ 2. Minister Sprawiedliwości może zawrzeć z odpowiednim organem państwa 

wykonania orzeczenia porozumienie przewidujące podział kwot uzyskanych 

z egzekucji orzeczeń, o których mowa w § 1. 

§ 3. W wypadku zawarcia porozumienia, o którym mowa w § 2, sąd wzywa 

właściwy sąd lub inny organ państwa wykonania orzeczenia do przekazania całości 

albo części wyegzekwowanej kwoty na rachunek bankowy tego sądu lub rachunek 

bankowy innego wskazanego podmiotu. Przekazana na rachunek sądu kwota uzyskana 

z egzekucji środka karnego lub środka kompensacyjnego orzeczonego na rzecz 

pokrzywdzonego lub innej osoby uprawnionej albo wskazanej w orzeczeniu instytucji, 

stowarzyszenia, fundacji lub organizacji społecznej zostaje następnie przekazana tej 

osobie lub podmiotowi.


## Art. 611fc. {#kpk-art-611fc}
§ 1. W razie wystąpienia o wykonanie orzeczenia, o którym mowa 

w art. 611fa § 1, postępowanie wykonawcze zawiesza się. 

§ 2. Po otrzymaniu 

informacji o wykonaniu orzeczenia sąd podejmuje 

zawieszone postępowanie i umarza je. Postępowanie umarza się również, jeżeli 

w stosunku do sprawcy zapadło w innym państwie członkowskim i zostało wykonane 

prawomocne orzeczenie co do tego samego czynu. 

§ 3. W razie otrzymania 

informacji o niemożności wykonania orzeczenia 

w całości albo części z powodów innych niż wskazane w § 2 zdanie drugie sąd 

podejmuje zawieszone postępowanie celem jego dalszego prowadzenia.


## Art. 611fd. {#kpk-art-611fd}
§ 1. W razie uchylenia orzeczenia na skutek kasacji albo wznowienia 

postępowania, darowania kary, przedawnienia jej wykonania lub też w razie 

wystąpienia innych okoliczności skutkujących niemożnością wykonania orzeczenia, 

o którym mowa w art. 611fa § 1, sąd niezwłocznie zawiadamia o tym właściwy sąd 

lub inny organ państwa wykonania orzeczenia. 

§ 2. Sąd zawiadamia niezwłocznie właściwy sąd lub inny organ państwa 

wykonania orzeczenia o każdej wpłacie dokonanej na poczet orzeczonej kary, 

środków karnych, środków kompensacyjnych lub kosztów procesu, o których mowa 

w art. 611fa § 1, a także o orzeczonym przepadku.


## Art. 611fe. {#kpk-art-611fe}
Sąd rozpoznaje sprawę wystąpienia do właściwego sądu lub innego 

organu państwa wykonania orzeczenia na posiedzeniu, w którym ma prawo wziąć 

udział prokurator, pokrzywdzony lub inna osoba albo podmiot uprawniony, o których 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 296/356 

mowa w art. 611fb § 3, sprawca, jeżeli przebywa na terytorium Rzeczypospolitej 

Polskiej i jego obrońca, jeżeli się na nie stawi. Na postanowienie sądu zażalenie nie 

przysługuje. 


# Rozdział 66
b 

Wystąpienie państwa członkowskiego Unii Europejskiej o wykonanie orzeczenia 

o karach 

o charakterze pieniężnym


## Art. 611ff. {#kpk-art-611ff}
§ 1. W razie wystąpienia państwa członkowskiego Unii Europejskiej, 

zwanego w niniejszym rozdziale „państwem wydania orzeczenia”, o wykonanie 

prawomocnego orzeczenia o karach o charakterze pieniężnym, orzeczenie to podlega 

wykonaniu przez sąd rejonowy, w okręgu którego sprawca posiada mienie lub osiąga 

dochody, albo ma stałe lub czasowe miejsce pobytu. W rozumieniu przepisów 

niniejszego rozdziału „karą o charakterze pieniężnym” jest obowiązek uiszczenia 

przez sprawcę określonych w orzeczeniu: 

1) 

2) 

kwoty pieniężnej jako kary za popełnione przestępstwo; 

zadośćuczynienia na rzecz pokrzywdzonego, jeżeli nie mógł on w ramach 

postępowania karnego dochodzić roszczeń o charakterze cywilnym; 

3) 

kwoty pieniężnej na rzecz funduszu publicznego lub organizacji pomocy ofiarom 

przestępstw; 

4) 

kosztów procesu. 

§ 2. Do orzeczenia, o którym mowa w § 1, lub jego odpisu poświadczonego za 

zgodność z oryginałem powinno być dołączone zaświadczenie zawierające wszystkie 

istotne informacje umożliwiające jego prawidłowe wykonanie. 

§ 3. Do wykonania orzeczenia sądu lub innego organu państwa wydania 

orzeczenia sąd przystępuje niezwłocznie. 

§ 4. Jeżeli sąd, do którego zostało skierowane orzeczenie, nie jest właściwy do 

nadania mu biegu, przekazuje je właściwemu sądowi i powiadamia o tym właściwy 

sąd lub inny organ państwa wydania orzeczenia. 

§ 5. Jeżeli orzeczenie, o którym mowa w § 1, dotyczy czynów, które nie zostały 

popełnione na terytorium państwa wydania orzeczenia i podlegają jurysdykcji sądów 

polskich, sąd może postanowić o obniżeniu wysokości podlegającej egzekucji kary 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 297/356 

o charakterze pieniężnym do maksymalnej wysokości kary lub środka karnego jakie 

mogłyby być orzeczone za takie same czyny według prawa polskiego. 

§ 6. Jeżeli przepisy niniejszego 

rozdziału nie stanowią 

inaczej, przy 

wykonywaniu orzeczeń, o których mowa w § 1, stosuje się przepisy prawa polskiego. 

Przepis art. 611c § 3 stosuje się odpowiednio.


## Art. 611fg. {#kpk-art-611fg}
Można odmówić wykonania orzeczenia, o którym mowa 

w art. 611ff § 1, jeżeli: 

1) 

czyn, w związku z którym wydano to orzeczenie, nie stanowi przestępstwa 

według prawa polskiego, chyba że zgodnie z prawem państwa wydania 

orzeczenia jest to przestępstwo wymienione w art. 607w lub zgodnie z prawem 

państwa wydania orzeczenia jest to przestępstwo: 

a) popełnione z użyciem przemocy na osobie lub gróźb karalnych, 

b) popełnione w związku z imprezą masową, 

c) przeciwko bezpieczeństwu w komunikacji, 

d) kradzieży, 

e) 

f) 

zniszczenia lub uszkodzenia mienia, 

przemytu towarów, 

g) przeciwko prawom własności intelektualnej, 

h) określone w celu wykonania wynikających z aktów prawnych przyjętych 

przez właściwe instytucje Unii Europejskiej zobowiązań do ustanowienia 

sankcji w prawie wewnętrznym państw członkowskich, jednakże wyłącznie 

w granicach, w jakich zobowiązanie to zostało w tych aktach określone; 

2) 

do orzeczenia nie dołączono zaświadczenia o którym mowa w art. 611ff § 2, albo 

zaświadczenie to jest niekompletne lub w sposób oczywisty jest niezgodne 

z treścią orzeczenia; 

3) 

przekazane do wykonania orzeczenie dotyczy tego samego czynu tej samej osoby 

co do której postępowanie karne zostało prawomocnie zakończone w państwie 

członkowskim, a orzeczenie w zakresie kary o charakterze pieniężnym zostało 

wykonane; 

4) według prawa polskiego nastąpiło przedawnienie wykonania kary, 

a przestępstwa, których to dotyczy, podlegały jurysdykcji sądów polskich; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 298/356 

5) 

orzeczenie dotyczy przestępstw, które według prawa polskiego zostały 

popełnione w całości albo w części na terytorium Rzeczypospolitej Polskiej, jak 

również na polskim statku wodnym lub powietrznym; 

6) 

orzeczenie dotyczy przestępstw popełnionych poza terytorium państwa wydania 

orzeczenia, a prawo polskie nie dopuszcza ścigania takiego rodzaju przestępstw, 

jeżeli zostały one popełnione poza terytorium Rzeczypospolitej Polskiej; 

7) 

sprawca nie podlega jurysdykcji polskich sądów karnych, lub też brak jest 

wymaganego zezwolenia na jego ściganie; 

8) 

osoba, której dotyczy orzeczenie, z powodu wieku nie ponosi według prawa 

polskiego odpowiedzialności karnej za czyny będące podstawą wydania 

orzeczenia; 

9) 

z treści zaświadczenia, o którym mowa w art. 611ff § 2, wynika, iż osoba, której 

dotyczy orzeczenie, nie została należycie pouczona o możliwości i prawie do 

zaskarżenia tego orzeczenia; 

10) z treści zaświadczenia, o którym mowa w art. 611ff § 2, wynika, że orzeczenie 

zostało wydane pod nieobecność sprawcy, chyba że: 

a) 

sprawcę wezwano do udziału w postępowaniu 

lub w inny sposób 

zawiadomiono o terminie i miejscu rozprawy albo posiedzenia, pouczając, 

że niestawiennictwo nie stanowi przeszkody dla wydania orzeczenia albo 

sprawca miał obrońcę, który był obecny na rozprawie lub posiedzeniu, 

b) po doręczeniu 

sprawcy odpisu orzeczenia wraz 

z pouczeniem 

o przysługującym mu prawie, terminie i sposobie złożenia w państwie 

wydania nakazu wniosku o przeprowadzenie z jego udziałem nowego 

postępowania sądowego w tej samej sprawie, sprawca w ustawowym 

terminie nie złożył takiego wniosku albo oświadczył, że nie kwestionuje 

orzeczenia; 

11) przestępstwo, którego dotyczy orzeczenie, w wypadku jurysdykcji polskich 

sądów karnych, podlega darowaniu na mocy amnestii; 

12) orzeczenie dotyczy kary o charakterze pieniężnym niższej niż 70 euro lub niższej 

niż równowartość tej kwoty w innej walucie.


## Art. 611fh. {#kpk-art-611fh}
§ 1. Sąd rozpoznaje sprawę wykonania orzeczenia o karach 

o charakterze pieniężnym na posiedzeniu, w którym ma prawo wziąć udział 

prokurator, sprawca, jeżeli przebywa na terytorium Rzeczypospolitej Polskiej, i jego 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 299/356 

obrońca, jeżeli się na nie stawi. Jeżeli sprawca, który nie przebywa na terytorium 

Rzeczypospolitej Polskiej, nie posiada obrońcy, prezes sądu właściwego do 

rozpoznania sprawy może mu wyznaczyć obrońcę z urzędu. 

§ 2. Na postanowienie sądu w przedmiocie wykonania orzeczenia o karach 

o charakterze pieniężnym przysługuje zażalenie. 

§ 3. Prawomocne orzeczenie o karach o charakterze pieniężnym wraz 

z dołączonym zaświadczeniem, o którym mowa w art. 611ff § 2, stanowi tytuł 

egzekucyjny 

i podlega wykonaniu w Rzeczypospolitej Polskiej po wydaniu 

postanowienia o jego wykonaniu. 

§ 4. Jeżeli informacje przekazane przez państwo wydania orzeczenia nie są 

wystarczające do podjęcia decyzji w przedmiocie wykonania orzeczenia o karach 

o charakterze pieniężnym, sąd wzywa właściwy sąd lub inny organ państwa wydania 

orzeczenia do ich uzupełnienia we wskazanym terminie. 

§ 5. W razie niedotrzymania terminu, o którym mowa w § 4, postanowienie 

w przedmiocie wykonania orzeczenia wydaje się w oparciu o informacje przekazane 

wcześniej.


## Art. 611fi. {#kpk-art-611fi}
§ 1. Kwota uzyskana z tytułu wykonania orzeczenia, o którym mowa 

w art. 611ff § 1, stanowi dochód budżetu państwa. 

§ 2. Minister Sprawiedliwości może zawrzeć z odpowiednim organem państwa 

wydania orzeczenia porozumienie przewidujące podział kwot uzyskanych 

z wykonania orzeczenia, o którym mowa w § 1. 

§ 3. W wypadku zawarcia porozumienia, o którym mowa w § 2, sąd, na 

wezwanie właściwego sądu lub innego organu państwa wydania orzeczenia, 

przekazuje całość albo część kwoty uzyskanej z tytułu wykonania orzeczenia, zgodnie 

z porozumieniem.


## Art. 611fj. {#kpk-art-611fj}
§ 1. Jeżeli sprawca lub inna osoba przedstawi dowód uiszczenia 

w całości albo części kar o charakterze pieniężnym, o których mowa w podlegającym 

wykonaniu orzeczeniu, sąd, przed wydaniem postanowienia w przedmiocie 

wykonania tego orzeczenia, wzywa właściwy sąd lub inny organ państwa wydania 

orzeczenia do potwierdzenia dokonanej wpłaty. 

§ 2. Kwoty uprzednio uzyskane na poczet kary w państwie wydania lub 

wykonania orzeczenia są odliczane od kwoty, która ma być wyegzekwowana. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 300/356


## Art. 611fk. {#kpk-art-611fk}
W razie otrzymania od właściwego sądu lub innego organu państwa 

wydania orzeczenia informacji o tym, iż orzeczenie przekazane do wykonania nie 

podlega dalszemu wykonaniu, sąd wydaje niezwłocznie postanowienie o umorzeniu 

postępowania wykonawczego.


## Art. 611fl. {#kpk-art-611fl}
O treści postanowienia w przedmiocie wykonania orzeczenia 

o karach o charakterze pieniężnym, 

jak również o zakończeniu postępowania 

egzekucyjnego, a także o zamianie kary o charakterze pieniężnym na pracę społecznie 

użyteczną lub o wykonaniu zastępczej kary pozbawienia wolności, jeżeli prawo 

polskie dopuszcza taką możliwość, powiadamia się niezwłocznie właściwy sąd lub 

inny organ państwa wydania orzeczenia. Powiadomienie to może być przekazane 

również przy użyciu urządzeń służących do automatycznego przesyłania danych, 

w sposób umożliwiający stwierdzenie autentyczności przekazanych dokumentów.


## Art. 611fm. {#kpk-art-611fm}
Koszty związane z wykonaniem orzeczenia, o którym mowa 

w art. 611ff § 1, ponosi Skarb Państwa. 


# Rozdział 66
c 

Wystąpienie do państwa członkowskiego Unii Europejskiej o wykonanie 

orzeczenia przepadku


## Art. 611fn. {#kpk-art-611fn}
§ 1. W razie prawomocnego orzeczenia przez sąd polski wobec 

obywatela polskiego lub cudzoziemca przepadku, sąd może wystąpić o jego 

wykonanie bezpośrednio do właściwego sądu 

lub 

innego organu państwa 

członkowskiego Unii Europejskiej, zwanego w niniejszym rozdziale „państwem 

wykonania orzeczenia”, w którym sprawca posiada mienie lub osiąga dochody, 

a w razie niemożności jego ustalenia, państwa, w którym ma stałe lub czasowe miejsce 

pobytu. 

§ 2. Wystąpienie, o którym mowa w § 1, sąd każdorazowo kieruje wyłącznie do 

jednego państwa wykonania orzeczenia, z zastrzeżeniem § 3 i 4. 

§ 3. Jeżeli wystąpienie dotyczy określonych składników mienia, może ono 

nastąpić do więcej niż jednego państwa wykonania orzeczenia, jeżeli istnieje 

prawdopodobieństwo, że: 

1) 

określone składniki mienia znajdują się w więcej niż jednym państwie wy-

konania orzeczenia lub w jednym z wielu państw wykonania orzeczenia lub 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 301/356 

2) 

postępowanie wykonawcze będzie prowadzone w więcej niż jednym państwie 

wykonania orzeczenia. 

§ 4. Jeżeli wystąpienie dotyczy kwoty pieniężnej, może być skierowane do 

więcej niż jednego państwa wykonania orzeczenia, jeżeli mienie, co do którego może 

nastąpić przepadek, nie zostało zabezpieczone na podstawie postanowienia, o którym 

mowa w art. 589g § 1, 

lub gdy 

jego wartość nie 

jest wystarczająca do 

wyegzekwowania kwoty pieniężnej, co do której orzeczono przepadek, lub gdy 

przemawia za tym dobro postępowania. 

§ 5. Do poświadczonego za zgodność z oryginałem odpisu orzeczenia, o którym 

mowa w § 1, dołącza się zaświadczenie zawierające wszystkie istotne informacje 

umożliwiające jego prawidłowe wykonanie. 

§ 6. Zaświadczenie powinno zostać przetłumaczone na język urzędowy państwa 

wykonania orzeczenia albo na inny język wskazany przez to państwo. 

§ 7. Przekazanie odpisu orzeczenia oraz zaświadczenia, o którym mowa w § 5, 

może nastąpić również z wykorzystaniem urządzeń służących do automatycznego 

przesyłania danych, w sposób umożliwiający stwierdzenie autentyczności tych 

dokumentów. Na żądanie właściwego sądu lub innego organu państwa wykonania 

orzeczenia sąd przekazuje odpis orzeczenia oraz oryginał zaświadczenia. 

§ 8. W razie trudności w ustaleniu właściwego sądu lub innego organu państwa 

wykonania orzeczenia sąd może również zwracać się do właściwych jednostek 

organizacyjnych Europejskiej Sieci Sądowej. 

§ 9. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, wzór 

zaświadczenia, o którym mowa w § 5, zawierając w nim szczegółowe informacje 

dotyczące przekazanego do wykonania orzeczenia, w tym informacje o każdej wpłacie 

dokonanej na poczet orzeczonego przepadku kwoty pieniężnej, przepadku 

równowartości przedmiotów lub przepadku równowartości korzyści majątkowej oraz 

o ewentualnej zgodzie na wykonanie przepadku przez zapłatę jego równowartości 

pieniężnej, o zgodzie na przekazanie mienia innego niż pieniądze oraz o zastępczych 

formach wykonania przepadku, mając na uwadze konieczność udostępnienia państwu 

wykonania orzeczenia wszelkich niezbędnych informacji umożliwiających podjęcie 

prawidłowej decyzji w przedmiocie wykonania orzeczenia.


## Art. 611fo. {#kpk-art-611fo}
§ 1. Jeżeli kwota uzyskana z tytułu wykonania orzeczeń, o których 

mowa w art. 611fn § 1, przewyższa równowartość 10 000 euro, sąd wzywa właściwy 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 302/356 

sąd lub inny organ państwa wykonania orzeczenia do przekazania połowy uzyskanej 

kwoty na rachunek bankowy tego sądu. 

§ 2. Jeżeli wystąpienie obejmuje przepadek kwoty pieniężnej, sąd może wezwać 

właściwy sąd lub inny organ państwa wykonania orzeczenia do przekazania mienia 

innego niż pieniądze, uzyskanego z tytułu wykonania orzeczenia objętego 

wystąpieniem. 

§ 3. Minister Sprawiedliwości może zawrzeć z odpowiednim organem państwa 

wykonania orzeczenia porozumienie co do sposobu wykonania orzeczenia przepadku, 

w szczególności przewidując odmienny podział kwot uzyskanych z egzekucji 

orzeczeń, o których mowa w § 1. 

§ 4. W wypadku zawarcia porozumienia, o którym mowa w § 3, sąd wzywa 

właściwy sąd lub inny organ państwa wykonania orzeczenia do przekazania całości 

albo części wyegzekwowanej kwoty lub mienia innego niż pieniądze, uzyskanych 

z tytułu wykonania orzeczenia, zgodnie z porozumieniem.


## Art. 611fp. {#kpk-art-611fp}
Wystąpienie o wykonanie orzeczenia, o którym mowa w art. 611fn 

§ 1, nie wstrzymuje postępowania wykonawczego.


## Art. 611fr. {#kpk-art-611fr}
§ 1. W razie uchylenia orzeczenia na skutek kasacji albo wznowienia 

postępowania, darowania kary, przedawnienia jej wykonania lub też w razie 

wystąpienia innych okoliczności skutkujących niemożnością wykonania orzeczenia, 

o którym mowa w art. 611fn § 1, sąd niezwłocznie zawiadamia o tym właściwy sąd 

lub inny organ państwa wykonania orzeczenia. 

§ 2. Sąd zawiadamia niezwłocznie właściwy sąd lub inny organ państwa 

wykonania orzeczenia o każdej kwocie pieniężnej uzyskanej z tytułu wykonania 

orzeczeń, o których mowa w art. 611fn § 1.


## Art. 611fs. {#kpk-art-611fs}
Sąd rozpoznaje sprawę wystąpienia do właściwego sądu lub innego 

organu państwa wykonania orzeczenia na posiedzeniu, w którym ma prawo wziąć 

udział prokurator, sprawca, jeżeli przebywa na terytorium Rzeczypospolitej Polskiej, 

i jego obrońca, jeżeli się na nie stawi. Na postanowienie sądu zażalenie nie 

przysługuje.


## Art. 611ft. {#kpk-art-611ft}
§ 1. Jeżeli według prawa państwa wykonania orzeczenia państwo to 

ponosi odpowiedzialność za szkodę wyrządzoną w związku z wykonaniem orzeczenia 

przepadku wydanego przez polski sąd, na wniosek właściwego sądu lub innego organu 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 303/356 

tego państwa Skarb Państwa zwraca mu kwotę pieniężną stanowiącą równowartość 

wypłaconego odszkodowania. 

§ 2. Przepisu § 1 nie stosuje się, jeżeli szkoda jest wyłącznym następstwem 

działania lub zaniechania organu państwa wykonania orzeczenia. 


# Rozdział 66
d 

Wystąpienie państwa członkowskiego Unii Europejskiej o wykonanie orzeczenia 

przepadku


## Art. 611fu. {#kpk-art-611fu}
§ 1. W razie wystąpienia państwa 

członkowskiego Unii 

Europejskiej, zwanego w niniejszym rozdziale „państwem wydania orzeczenia”, 

o wykonanie prawomocnego orzeczenia przepadku, orzeczenie to podlega wykonaniu 

przez sąd rejonowy, w okręgu którego sprawca posiada mienie lub osiąga dochody 

albo ma stałe lub czasowe miejsce pobytu. 

§ 2. Do orzeczenia, o którym mowa w § 1, lub jego odpisu poświadczonego za 

zgodność z oryginałem powinno być dołączone zaświadczenie zawierające wszystkie 

istotne informacje umożliwiające jego prawidłowe wykonanie. 

§ 3. Do wykonania orzeczenia państwa wydania orzeczenia sąd przystępuje 

niezwłocznie. 

§ 4. Jeżeli sąd, do którego zostało skierowane orzeczenie, nie jest właściwy do 

nadania mu biegu, przekazuje je właściwemu sądowi i powiadamia o tym właściwy 

sąd lub inny organ państwa wydania orzeczenia. 

§ 5. Jeżeli przepisy niniejszego 

rozdziału nie stanowią 

inaczej, przy 

wykonywaniu orzeczeń, o których mowa w § 1, stosuje się przepisy prawa polskiego. 

Przepis art. 611c § 3 stosuje się odpowiednio.


## Art. 611fw. {#kpk-art-611fw}
§ 1. Odmawia się wykonania orzeczenia przepadku korzyści 

majątkowej albo jej równowartości w części, w której zostało ono wydane w oparciu 

o domniemanie pochodzenia tej korzyści z przestępstwa, inne niż domniemanie: 

1) 

pochodzenia korzyści majątkowej z przestępstwa innego niż to, za które sprawca 

został skazany, popełnionego do chwili wydania chociażby nieprawomocnego 

wyroku; 

2) 

pochodzenia korzyści majątkowej z innego przestępstwa podobnego do 

przestępstwa, za które sprawca został skazany, popełnionego do chwili wydania 

chociażby nieprawomocnego wyroku; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 304/356 

3) 

pochodzenia z przestępstwa mienia nieznajdującego pokrycia w ujawnionych 

źródłach przychodu sprawcy. 

§ 2. Można odmówić wykonania orzeczenia przepadku korzyści majątkowej 

albo jej równowartości, wydanego w oparciu o domniemania, o których mowa w § 1, 

w części, w której orzeczenie przepadku byłoby niedopuszczalne według prawa 

polskiego. 

§ 3. Można odmówić wykonania orzeczenia, o którym mowa w art. 611fu § 1, 

jeżeli: 

1) 

czyn, w związku z którym wydano to orzeczenie, nie stanowi przestępstwa 

według prawa polskiego lub za przestępstwo będące podstawą wydania 

orzeczenia nie można orzec przepadku według prawa polskiego, chyba że 

zgodnie z prawem państwa wydania orzeczenia jest to przestępstwo wymienione 

w art. 607w; przepis art. 607r § 2 stosuje się odpowiednio; 

2) 

do orzeczenia nie dołączono zaświadczenia, o którym mowa w art. 611fu § 2, 

albo zaświadczenie to jest niekompletne lub w sposób oczywisty jest niezgodne 

z treścią orzeczenia; 

3) 

przekazane do wykonania orzeczenie dotyczy tego samego czynu tej samej 

osoby, co do której postępowanie karne zostało prawomocnie zakończone 

w państwie członkowskim, a orzeczenie w zakresie przepadku zostało wyko-

nane; 

4) według prawa polskiego nastąpiło przedawnienie wykonania kary, a prze-

stępstwa, których to dotyczy, podlegały jurysdykcji sądów polskich; 

5) 

orzeczenie dotyczy przestępstw, które według prawa polskiego zostały po-

pełnione w całości albo w części na terytorium Rzeczypospolitej Polskiej, jak 

również na polskim statku wodnym lub powietrznym; 

6) 

orzeczenie dotyczy przestępstw popełnionych poza terytorium państwa wydania 

orzeczenia, a prawo polskie nie dopuszcza ścigania takiego rodzaju przestępstw, 

jeżeli zostały one popełnione poza terytorium Rzeczypospolitej Polskiej; 

7) 

sprawca nie podlega jurysdykcji polskich sądów karnych lub też brak jest 

wymaganego zezwolenia na jego ściganie; 

8) 

z treści zaświadczenia, o którym mowa w art. 611fu § 2, wynika, że orzeczenie 

zostało wydane pod nieobecność sprawcy, chyba że: 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 305/356 

a) 

sprawcę wezwano do udziału w postępowaniu 

lub w inny sposób 

zawiadomiono o terminie i miejscu rozprawy albo posiedzenia, pouczając, 

że niestawiennictwo nie stanowi przeszkody dla wydania orzeczenia albo 

sprawca miał obrońcę, który był obecny na rozprawie lub posiedzeniu, 

b) po doręczeniu 

sprawcy odpisu orzeczenia wraz 

z pouczeniem 

o przysługującym mu prawie, terminie i sposobie złożenia w państwie 

wydania nakazu wniosku o przeprowadzenie z jego udziałem nowego 

postępowania sądowego w tej samej sprawie, sprawca w ustawowym 

terminie nie złożył takiego wniosku albo oświadczył, że nie kwestionuje 

orzeczenia; 

9) 

przestępstwo, którego dotyczy orzeczenie, w wypadku jurysdykcji polskich 

sądów karnych, podlega darowaniu na mocy amnestii; 

10) zachodzi uzasadniona obawa, że wykonanie orzeczenia może naruszyć prawa 

osób trzecich. 

§ 4. Jeżeli informacje przekazane przez państwo wydania orzeczenia nie są 

wystarczające do podjęcia decyzji w przedmiocie wykonania orzeczenia przepadku, 

sąd wzywa właściwy sąd lub inny organ państwa wydania orzeczenia do ich 

uzupełnienia we wskazanym terminie. 

§ 5. W razie niedotrzymania terminu, o którym mowa w § 4, postanowienie 

w przedmiocie wykonania orzeczenia wydaje się w oparciu o informacje przekazane 

wcześniej. 

§ 6. Jeżeli wykonanie orzeczenia nie jest możliwe z przyczyn faktycznych lub 

prawnych, sąd niezwłocznie powiadamia właściwy sąd lub inny organ państwa 

wydania orzeczenia.


## Art. 611fx. {#kpk-art-611fx}
§ 1. Sąd rozpoznaje sprawę wykonania orzeczenia przepadku na 

posiedzeniu, w którym ma prawo wziąć udział prokurator, sprawca, jeżeli przebywa 

na terytorium Rzeczypospolitej Polskiej, i jego obrońca, jeżeli się na nie stawi, oraz 

osoba trzecia, której prawa mogą zostać naruszone przez wykonanie orzeczenia. Jeżeli 

sprawca, który nie przebywa na terytorium Rzeczypospolitej Polskiej, nie posiada 

obrońcy, prezes sądu właściwego do rozpoznania sprawy może mu wyznaczyć 

obrońcę z urzędu. 

§ 2. Na postanowienie sądu w przedmiocie wykonania orzeczenia przepadku 

zażalenie przysługuje stronom oraz osobie trzeciej, o której mowa w § 1. Sąd, który 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 306/356 

wydał postanowienie, powiadamia właściwy sąd lub inny organ państwa wydania 

orzeczenia o wniesieniu zażalenia. 

§ 3. Prawomocne orzeczenie przepadku wraz z dołączonym zaświadczeniem 

stanowi tytuł egzekucyjny i podlega wykonaniu w Rzeczypospolitej Polskiej po 

wydaniu postanowienia o jego wykonaniu.


## Art. 611fy. {#kpk-art-611fy}
§ 1. Sąd może zawiesić postępowanie w przedmiocie wykonania 

orzeczenia, o którym mowa w art. 611fu § 1, jeżeli: 

1) wystąpienie, dotyczące kwoty pieniężnej, nastąpiło do więcej niż jednego 

państwa członkowskiego, a istnieje prawdopodobieństwo, że wskutek wy-

konania orzeczenia w kilku państwach członkowskich przepadkowi ulegnie 

kwota wyższa niż określona w orzeczeniu; 

2) wykonanie orzeczenia mogłoby utrudnić toczące się postępowanie karne; 

3) mienie może podlegać przepadkowi w toczącym się w Polsce postępowaniu; 

4) 

uzna za niezbędne przetłumaczenie orzeczenia na język polski. 

§ 2. Na postanowienie w przedmiocie zawieszenia postępowania zażalenie 

przysługuje stronom oraz osobie trzeciej, o której mowa w art. 611fx § 1. Sąd, który 

wydał postanowienie, powiadamia właściwy sąd lub inny organ państwa wydania 

orzeczenia o zawieszeniu postępowania i jego przyczynach. 

§ 3. W razie zawieszenia postępowania sąd z urzędu może zabezpieczyć 

wykonanie orzeczenia. Przepisy o zabezpieczeniu majątkowym na mieniu 

oskarżonego stosuje się odpowiednio.


## Art. 611fz. {#kpk-art-611fz}
Jeżeli mienie podlegające egzekucji nie jest wystarczające do 

wykonania dwóch lub więcej orzeczeń, o których mowa w art. 611fu § 1, wydanych 

przeciwko tej samej osobie i dotyczących kwoty pieniężnej, albo jeżeli dwa lub więcej 

orzeczeń dotyczy określonego składnika mienia, sąd orzeka łącznie w przedmiocie 

wykonania orzeczeń w całości albo części.


## Art. 611fza. {#kpk-art-611fza}
§ 1. Jeżeli sprawca lub inna osoba przedstawi dowód wykonania 

w całości albo części orzeczenia, o którym mowa w art. 611fu § 1, sąd, przed 

wydaniem postanowienia w przedmiocie wykonania tego orzeczenia, wzywa właś-

ciwy sąd lub inny organ państwa wydania orzeczenia do potwierdzenia dokonanej 

wpłaty. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 307/356 

§ 2. Kwoty uprzednio uzyskane z tytułu przepadku w państwie wydania 

orzeczenia lub państwie wykonania orzeczenia są zaliczane na poczet kwoty 

podlegającej egzekucji.


## Art. 611fzb. {#kpk-art-611fzb}
§ 1. Kwota uzyskana z tytułu wykonania orzeczenia, o którym 

mowa w art. 611fu § 1, nieprzewyższająca równowartości 10 000 euro, stanowi 

dochód budżetu państwa. W pozostałych wypadkach państwu wydania orzeczenia 

przekazuje się połowę uzyskanej kwoty na rachunek bankowy wskazany przez 

właściwy sąd lub inny organ tego państwa. 

§ 2. Mienie inne niż pieniądze, uzyskane z tytułu wykonania orzeczenia, 

o którym mowa w § 1, spienięża się według przepisów o egzekucji świadczeń 

pieniężnych w postępowaniu egzekucyjnym w administracji. Przepis § 1 stosuje się 

odpowiednio do kwoty uzyskanej z egzekucji. 

§ 3. W uzasadnionych wypadkach sąd może odstąpić od spieniężenia mienia, 

o którym mowa w § 2, i przekazać je właściwemu sądowi lub innemu organowi 

państwa wydania orzeczenia. Jeżeli wystąpienie obejmuje przepadek kwoty 

pieniężnej, przekazanie może nastąpić tylko za zgodą tego sądu lub organu. 

§ 4. Sąd odmawia wydania państwu wydania orzeczenia uzyskanych 

przedmiotów będących dobrami kultury stanowiącymi część narodowego dziedzictwa 

kulturalnego. 

§ 5. Minister Sprawiedliwości może zawrzeć z odpowiednim organem państwa 

wydania orzeczenia porozumienie co do sposobu wykonania orzeczenia przepadku, 

w szczególności przewidując w nim odmienny, od określonego w § 1, podział kwot 

uzyskanych z wykonania orzeczenia. 

§ 6. W wypadku zawarcia porozumienia, o którym mowa w § 5, sąd, na 

wezwanie właściwego sądu lub innego organu państwa wydania orzeczenia, 

przekazuje całość albo część wyegzekwowanej kwoty pieniężnej lub mienie inne niż 

pieniądze, uzyskane z tytułu wykonania orzeczenia, zgodnie z porozumieniem.


## Art. 611fzc. {#kpk-art-611fzc}
W razie otrzymania od właściwego sądu lub innego organu państwa 

wydania orzeczenia informacji o tym, że orzeczenie przekazane do wykonania nie 

podlega dalszemu wykonaniu, sąd wydaje niezwłocznie postanowienie o umorzeniu 

postępowania wykonawczego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 308/356


## Art. 611fzd. {#kpk-art-611fzd}
O treści postanowienia w przedmiocie wykonania orzeczenia 

przepadku, jak również o zakończeniu 

postępowania egzekucyjnego, powiadamia się niezwłocznie właściwy sąd lub 

inny organ państwa wydania orzeczenia. Powiadomienie to może być przekazane 

również przy użyciu urządzeń służących do automatycznego przesyłania danych, 

w sposób umożliwiający stwierdzenie autentyczności przekazanych dokumentów.


## Art. 611fze. {#kpk-art-611fze}
§ 1. Koszty związane z wykonaniem orzeczenia, o którym mowa 

w art. 611fu § 1, ponosi Skarb Państwa. W uzasadnionych wypadkach sąd może 

wystąpić do właściwego sądu lub innego organu państwa wydania orzeczenia o zwrot 

części poniesionych wydatków. Do wystąpienia załącza się szczegółowy wykaz 

poniesionych wydatków wraz z propozycją ich podziału. 

§ 2. Jeżeli Skarb Państwa ponosi odpowiedzialność za szkodę wyrządzoną 

w związku z wykonaniem orzeczenia przepadku, wydanego przez organ sądowy 

państwa wydania orzeczenia, Skarb Państwa występuje do właściwego organu tego 

państwa o zwrot kwoty pieniężnej stanowiącej 

równowartość wypłaconego 

odszkodowania. 

§ 3. Przepisu § 2 nie stosuje się, jeżeli szkoda jest wyłącznym następstwem 

działania lub zaniechania organu polskiego. 


# Rozdział 66
e 

Współpraca z Międzynarodowym Trybunałem Karnym


## Art. 611g. {#kpk-art-611g}
§ 1. Wniosek o współpracę Międzynarodowego Trybunału Karnego, 

zwanego dalej „Trybunałem”, w zależności od stadium postępowania wykonuje 

właściwy sąd lub prokurator za pośrednictwem Ministra Sprawiedliwości. 

§ 2. Przepis § 1 stosuje się odpowiednio do wniosku o pomoc prawną 

kierowanego do Trybunału przez sąd lub prokuratora.


## Art. 611h. {#kpk-art-611h}
§ 1. W wypadku wniosku Trybunału o dostarczenie osoby 

Trybunałowi, w rozumieniu przepisów Statutu, zwanego dalej „wnioskiem 

o dostarczenie osoby”, przed pierwszym przesłuchaniem należy pouczyć osobę, której 

dotyczy wniosek, o jej uprawnieniach określonych w Statucie oraz o możliwości 

podniesienia zarzutu prawomocnego zakończenia prowadzonego przeciwko niej 

postępowania karnego o czyn, którego dotyczy wniosek o dostarczenie osoby. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 309/356 

§ 2. W wypadku wystąpienia przesłanek uzasadniających zarzut, o którym mowa 

w § 1, sąd powiadamia o tym Ministra Sprawiedliwości, który może odroczyć 

wykonanie wniosku o dostarczenie osoby. 

§ 3. Przy orzekaniu w przedmiocie dopuszczalności dostarczenia osoby 

przepisów art. 604 nie stosuje się. 

§ 4. Jeżeli po wydaniu przez sąd postanowienia o dopuszczalności dostarczenia 

osoby Trybunałowi Minister Sprawiedliwości odroczył wykonanie wniosku 

o dostarczenie osoby z powodu 

toczącego się w Rzeczypospolitej Polskiej 

postępowania karnego albo odbywania przez tę osobę kary pozbawienia wolności za 

inne przestępstwo, osobę, której wniosek o dostarczenie osoby dotyczy, można 

tymczasowo dostarczyć Trybunałowi na zasadach ustalonych z Trybunałem. 

§ 5. Ustaleń z Trybunałem, o których mowa w § 4, dokonuje Minister 

Sprawiedliwości.


## Art. 611i. {#kpk-art-611i}
§ 1. W wypadku nieprzewidzianego 

lądowania na 

terytorium 

Rzeczypospolitej Polskiej osoby dostarczanej Trybunałowi drogą powietrzną Minister 

Sprawiedliwości może zwrócić się do Trybunału o przekazanie wniosku o zezwolenie 

na ten przewóz. 

§ 2. Jeżeli w ciągu 96 godzin od chwili nieprzewidzianego lądowania nie 

wpłynie wniosek, o którym mowa w § 1, osobę dostarczaną zwalnia się.


## Art. 611j. {#kpk-art-611j}
§ 1. Na wniosek Trybunału o tymczasowe aresztowanie 

lub 

o aresztowanie i dostarczenie osoby ściganej sąd stosuje tymczasowe aresztowanie. 

§ 2. Tymczasowe aresztowanie, o którym mowa w § 1, można uchylić lub 

zmienić na łagodniejszy środek zapobiegawczy w wypadkach określonych w Statucie. 

Przepisów art. 257–259 nie stosuje się. 

§ 3. W postępowaniu w przedmiocie 

uchylenia 

lub 

zmiany 

środka 

zapobiegawczego sąd lub prokurator uwzględnia stanowisko Trybunału.


## Art. 611k. {#kpk-art-611k}
Minister Sprawiedliwości przed rozpatrzeniem wniosku Trybunału 

o zgodę na ściganie, ukaranie lub pozbawienie wolności osoby dostarczonej za 

przestępstwo popełnione przed dostarczeniem, inne niż to, z powodu którego nastąpiło 

dostarczenie, może zwrócić się do Trybunału o nadesłanie dodatkowych informacji, 

a także protokołu zawierającego oświadczenie osoby dostarczonej dotyczące 

przestępstwa określonego w tym wniosku. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 310/356


## Art. 611l. {#kpk-art-611l}
Minister Sprawiedliwości może wyrazić zgodę na dostarczenie 

Trybunałowi osoby wydanej lub przekazanej innemu państwu.


## Art. 611m. {#kpk-art-611m}
Jeżeli udzielenie pomocy prawnej przewidzianej w Statucie, 

w zakresie lub w sposób określony we wniosku Trybunału, byłoby sprzeczne 

z zasadami porządku prawnego Rzeczypospolitej Polskiej, sąd lub prokurator nie 

rozstrzyga w przedmiocie wniosku 

i przekazuje 

akta 

sprawy Ministrowi 

Sprawiedliwości w celu dokonania ustaleń z Trybunałem.


## Art. 611n. {#kpk-art-611n}
Jeżeli wniosek Trybunału o udzielenie pomocy prawnej dotyczy 

czynności innej niż przewidziana w Statucie, której wykonanie, mimo ustaleń 

dokonanych z Trybunałem, jest w dalszym ciągu niedopuszczalne na mocy ustawy 

i pomoc prawna nie może być udzielona pod żadnym warunkiem, w późniejszym 

terminie lub w inny sposób, sąd lub prokurator odmawia udzielenia tej pomocy.


## Art. 611o. {#kpk-art-611o}
§ 1. Jeżeli wniosek Trybunału dotyczy udostępnienia dokumentu lub 

innego dowodu zawierającego informacje, których ujawnienie mogłoby zagrażać 

bezpieczeństwu Rzeczypospolitej Polskiej, sąd lub prokurator nie rozstrzyga 

w przedmiocie wniosku i przekazuje akta sprawy Ministrowi Sprawiedliwości, który 

w porozumieniu z właściwym organem dokonuje ustaleń z Trybunałem. 

§ 2. Jeżeli mimo dokonania ustaleń z Trybunałem w dalszym ciągu udzielenie 

pomocy prawnej mogłoby zagrażać bezpieczeństwu Rzeczypospolitej Polskiej, sąd 

lub prokurator odmawia jej udzielenia.


## Art. 611p. {#kpk-art-611p}
Jeżeli wniosek Trybunału dotyczy wydania dokumentu lub innego 

dowodu, udostępnionego organowi lub instytucji Rzeczypospolitej Polskiej przez inne 

państwo lub organizację międzynarodową z zastrzeżeniem zachowania w tajemnicy 

informacji zawartej w tym dokumencie lub dowodzie, wydanie może nastąpić 

wyłącznie po wyrażeniu zgody przez udostępniającego dany dokument lub dowód.


## Art. 611r. {#kpk-art-611r}
§ 1. Przy wykonywaniu wniosku o współpracę, na żądanie Trybunału, 

Prokuratorowi Trybunału oraz innym osobom upoważnionym przez Trybunał 

zapewnia się obecność przy wykonywaniu czynności, których dotyczy wniosek. 

§ 2. Osoby, o których mowa w § 1, mogą zwracać się o zadawanie określonych 

pytań oraz utrwalać przebieg czynności na potrzeby postępowania prowadzonego 

przed Trybunałem. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 311/356 

§ 3. Prokuratorowi Trybunału umożliwia się samodzielne dokonywanie 

czynności procesowych na terytorium Rzeczypospolitej Polskiej na zasadach 

i w warunkach określonych w Statucie.


## Art. 611s. {#kpk-art-611s}
Ustaleń z Trybunałem, o których mowa w przepisach Statutu, innych 

niż określone w niniejszym rozdziale, dokonuje Minister Sprawiedliwości. 


# Rozdział 66
f 

Wystąpienie do państwa członkowskiego Unii Europejskiej o wykonanie kary 

pozbawienia wolności


## Art. 611t. {#kpk-art-611t}
§ 1. W razie prawomocnego orzeczenia przez sąd polski wobec 

obywatela polskiego lub cudzoziemca kary pozbawienia wolności podlegającej 

wykonaniu, sąd okręgowy, w którego okręgu wydano orzeczenie, za zgodą skazanego, 

może wystąpić o wykonanie orzeczenia bezpośrednio do właściwego sądu lub innego 

organu państwa członkowskiego Unii Europejskiej, zwanego w niniejszym rozdziale 

„państwem wykonania orzeczenia”, jeżeli przekazanie orzeczenia do wykonania 

pozwoli w większym stopniu zrealizować wychowawcze i zapobiegawcze cele kary. 

§ 2. Wystąpienie, o którym mowa w § 1, może nastąpić także na wniosek 

Ministra Sprawiedliwości, właściwego sądu lub innego organu państwa wykonania 

orzeczenia lub skazanego. 

§ 3. Wystąpienie, o którym mowa w § 1, sąd kieruje do właściwego sądu lub 

innego organu: 

1) 

państwa wykonania orzeczenia, którego skazany jest obywatelem i w którym 

posiada stałe lub czasowe miejsce pobytu, 

2) 

państwa wykonania orzeczenia, którego skazany jest obywatelem i w którym nie 

posiada stałego lub czasowego miejsca pobytu, lecz na podstawie prawomocnej 

decyzji będzie do niego wydalony po odbyciu kary lub zwolnieniu z zakładu 

karnego, 

3) 

innego państwa wykonania orzeczenia, za zgodą właściwego sądu lub innego 

organu tego państwa 

– o ile skazany przebywa na terytorium Rzeczypospolitej Polskiej lub w państwie, do 

którego skierowano wystąpienie. 

§ 4. Wystąpienie, o którym mowa w § 1, każdorazowo sąd kieruje wyłącznie do 

jednego państwa wykonania orzeczenia. Ponowne wystąpienie do innego państwa 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 312/356 

wykonania orzeczenia może nastąpić jedynie w razie niewykonania albo częściowego 

wykonania orzeczenia. 

§ 5. Zgoda skazanego na przekazanie nie jest wymagana, w wypadku gdy 

orzeczenie jest przekazywane do: 

1) 

państwa wykonania orzeczenia, którego skazany jest obywatelem i w którym 

posiada stałe lub czasowe miejsce pobytu; 

2) 

państwa wykonania orzeczenia, do którego skazany będzie wydalony po odbyciu 

kary lub zwolnieniu z zakładu karnego na podstawie prawomocnej decyzji 

o zobowiązaniu cudzoziemca do powrotu; 

3) 

państwa wykonania orzeczenia, do którego skazany zbiegł z obawy przed 

toczącym się na terytorium Rzeczypospolitej Polskiej postępowaniem karnym 

lub obowiązkiem odbycia orzeczonej kary. 

§ 6. Do poświadczonego za zgodność z oryginałem odpisu orzeczenia, o którym 

mowa w § 1, dołącza się zaświadczenie zawierające wszystkie istotne informacje 

umożliwiające jego prawidłowe wykonanie. Odpis orzeczenia wraz z odpisem 

zaświadczenia przekazuje się Ministrowi Sprawiedliwości. 

§ 7. Zaświadczenie powinno zostać przetłumaczone na język urzędowy państwa 

wykonania orzeczenia albo na inny język wskazany przez to państwo. 

§ 8. Przekazanie odpisu orzeczenia oraz zaświadczenia, o którym mowa w § 6, 

może nastąpić również przy użyciu urządzeń służących do automatycznego 

przesyłania danych, w sposób umożliwiający stwierdzenie autentyczności tych 

dokumentów. Na żądanie właściwego sądu lub innego organu państwa wykonania 

orzeczenia sąd przekazuje odpis orzeczenia oraz oryginał zaświadczenia. 

§ 9. W razie trudności w ustaleniu właściwego sądu lub innego organu państwa 

wykonania orzeczenia sąd może również zwracać się do właściwych jednostek 

organizacyjnych Europejskiej Sieci Sądowej. 

§ 10. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, wzór 

zaświadczenia, o którym mowa w § 6, zawierając w nim szczegółowe informacje 

dotyczące przekazanego do wykonania orzeczenia, mając na uwadze konieczność 

udostępnienia państwu wykonania orzeczenia wszelkich niezbędnych informacji 

umożliwiających podjęcie prawidłowej decyzji w przedmiocie wykonania orzeczenia.


## Art. 611ta. {#kpk-art-611ta}
§ 1. Przed wystąpieniem do państwa, o którym mowa w art. 611t § 3 

pkt 3, sąd zwraca się do właściwego sądu lub innego organu tego państwa o zgodę na 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 313/356 

przekazanie orzeczenia do wykonania. W pozostałych wypadkach sąd może zwrócić 

się do właściwego sądu lub innego organu państwa wykonania orzeczenia o opinię 

w przedmiocie przekazania orzeczenia. 

§ 2. Jeżeli zostaną ujawnione okoliczności przemawiające za tym, iż przekazanie 

orzeczenia do wykonania do państwa wykonania orzeczenia nie pozwalałoby 

w większym stopniu zrealizować wychowawczych i zapobiegawczych celów kary, 

sąd może odstąpić od wystąpienia, o którym mowa w art. 611t § 1, lub je cofnąć.


## Art. 611tb. {#kpk-art-611tb}
§ 1. Sąd rozpoznaje sprawę wystąpienia do właściwego sądu lub 

innego organu państwa wykonania orzeczenia na posiedzeniu, w którym ma prawo 

wziąć udział prokurator, skazany, jeżeli przebywa na terytorium Rzeczypospolitej 

Polskiej, i jego obrońca, jeżeli się na nie stawi. Na postanowienie sądu zażalenie nie 

przysługuje. 

§ 2. Sąd umożliwia skazanemu, przebywającemu na terytorium Rzeczypospolitej 

Polskiej, zajęcie stanowiska ustnie lub na piśmie w przedmiocie wystąpienia, o którym 

mowa w art. 611t § 1. Jeżeli wymagana jest zgoda skazanego na przekazanie, sąd 

odbiera od skazanego przebywającego na terytorium Rzeczypospolitej Polskiej 

oświadczenie w tym przedmiocie. 

§ 3. W wypadku gdy skazany przebywający na terytorium Rzeczypospolitej 

Polskiej nie wyraził zgody na wystąpienie, o którym mowa w art. 611t § 1, sąd umarza 

postępowanie w przedmiocie wystąpienia, chyba że ma zastosowanie art. 611t § 5. 

W pozostałych wypadkach złożone oświadczenie przesyła się do państwa wykonania 

orzeczenia wraz z zaświadczeniem, o którym mowa w art. 611t § 6. 

§ 4. Jeżeli skazany przebywa na terytorium Rzeczypospolitej Polskiej, sąd 

zawiadamia go o przekazaniu orzeczenia; w innym wypadku przekazuje 

zawiadomienie wraz z zaświadczeniem, o którym mowa w art. 611t § 6, do państwa 

wykonania orzeczenia. 

§ 5. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, wzór 

zawiadomienia, o którym mowa w § 4, zawierając w nim informacje dotyczące 

istotnych elementów związanych z wykonaniem orzeczenia, takich jak wskazanie 

właściwych organów państwa wydania i wykonania orzeczenia, prawa określającego 

warunki odbycia kary, warunkowego zwolnienia lub zawieszenia wykonania kary, 

mając na uwadze konieczność poinformowania skazanego o przekazaniu orzeczenia. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 314/356


## Art. 611tc. {#kpk-art-611tc}
§ 1. Sąd może zwrócić się do właściwego sądu lub innego organu 

państwa wykonania orzeczenia o przekazanie informacji o treści prawa obcego 

mającego zastosowanie do warunkowego zwolnienia. Po uzyskaniu informacji o treści 

prawa obcego sąd może odstąpić od wystąpienia, o którym mowa w art. 611t § 1, lub 

je cofnąć albo zastrzec w porozumieniu z właściwym sądem lub innym organem 

państwa wykonania orzeczenia, że do decyzji o warunkowym zwolnieniu 

zastosowanie ma prawo polskie. 

§ 2. Do czasu rozpoczęcia wykonania kary w państwie wykonania orzeczenia 

sąd może odstąpić od wystąpienia, o którym mowa w art. 611t § 1, lub je cofnąć także 

w wyniku zaistnienia innych przeszkód. 

§ 3. Jeżeli państwo wykonania orzeczenia zwraca się o zgodę na ściganie 

skazanego za popełnione przestępstwo lub wykonanie kar orzeczonych przed 

przekazaniem skazanego temu państwu, sąd wydaje postanowienie w przedmiocie 

wniosku w terminie 30 dni. Art. 607e § 3 pkt 6, art. 607p, art. 607r oraz art. 607s § 1 

i 2 stosuje się odpowiednio.


## Art. 611td. {#kpk-art-611td}
§ 1. Wystąpienie o wykonanie orzeczenia, o którym mowa 

w art. 611t § 1, nie wstrzymuje postępowania wykonawczego. 

§ 2. Po otrzymaniu informacji o rozpoczęciu odbywania przez skazanego kary 

w państwie wykonania orzeczenia, postępowanie wykonawcze zawiesza się. 

§ 3. Po otrzymaniu informacji o zakończeniu wykonywania kary sąd podejmuje 

zawieszone postępowanie i umarza je. Postępowanie umarza się również, jeżeli 

w stosunku do sprawcy zapadło w innym państwie członkowskim Unii Europejskiej 

i zostało wykonane prawomocne orzeczenie co do tego samego czynu. 

§ 4. W razie otrzymania 

informacji o niemożności wykonania orzeczenia 

w całości albo w części z powodów innych niż wskazane w § 3 zdanie drugie, sąd 

podejmuje zawieszone postępowanie w celu jego dalszego prowadzenia. 

§ 5. Sąd może uzgodnić z właściwym sądem lub innym organem państwa 

wykonania orzeczenia, że w państwie tym nastąpi wykonanie tylko części orzeczonej 

kary pozbawienia wolności, pod warunkiem że nie spowoduje to wydłużenia czasu 

trwania kary. W takim wypadku, po otrzymaniu informacji, o której mowa w § 2, 

postępowanie wykonawcze zawiesza się do czasu przekazania skazanego w celu 

dalszego wykonywania kary na terytorium Rzeczypospolitej Polskiej, a okres 

pozbawienia wolności w państwie wykonania orzeczenia zalicza się na poczet kary. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 315/356


## Art. 611te. {#kpk-art-611te}
W razie uchylenia orzeczenia, o którym mowa w art. 611t § 1, na 

skutek kasacji albo wznowienia postępowania, ułaskawienia skazanego, darowania 

przestępstwa na mocy amnestii albo przedawnienia wykonania kary, sąd niezwłocznie 

zawiadamia o tym właściwy sąd lub inny organ państwa wykonania orzeczenia.


## Art. 611tf. {#kpk-art-611tf}
§ 1. Skazanego przebywającego na terytorium Rzeczypospolitej 

Polskiej przekazuje się właściwemu sądowi lub innemu organowi państwa wykonania 

orzeczenia najpóźniej w terminie 30 dni od daty uprawomocnienia się zapadłej w tym 

państwie decyzji o wykonaniu orzeczenia. Art. 607n § 2 stosuje się odpowiednio. 

§ 2. W wypadku konieczności uzyskania zgody innego państwa członkowskiego 

Unii Europejskiej na przewóz skazanego przez 

jego 

terytorium, Minister 

Sprawiedliwości występuje z wnioskiem o udzielenie zezwolenia na przewóz. Art. 

611t § 6 zdanie pierwsze i § 7 stosuje się odpowiednio. 

§ 3. W wypadku gdy właściwy organ innego państwa członkowskiego Unii 

Europejskiej wskaże, iż skazany może być ścigany lub pozbawiony wolności 

w związku z przestępstwem popełnionym przed opuszczeniem przez niego terytorium 

Rzeczypospolitej Polskiej, Minister Sprawiedliwości może cofnąć wniosek 

o udzielenie zezwolenia na przewóz. 

§ 4. Jeżeli nastąpi nieprzewidziane lądowanie, o którym mowa w art. 607zb § 4, 

informacje określone w art. 611t § 6 przekazuje się w terminie 72 godzin. 


# Rozdział 66
g 

Wystąpienie państwa członkowskiego Unii Europejskiej o wykonanie kary 

pozbawienia wolności


## Art. 611tg. {#kpk-art-611tg}
§ 1. W razie wystąpienia 

państwa 

członkowskiego Unii 

Europejskiej, zwanego w niniejszym rozdziale „państwem wydania orzeczenia”, 

o wykonanie w Rzeczypospolitej Polskiej prawomocnie orzeczonej kary pozbawienia 

wolności, orzeczenie to podlega wykonaniu przez sąd okręgowy. 

§ 2. Sąd okręgowy na wniosek Ministra Sprawiedliwości, sprawcy lub z urzędu 

może zwrócić się do właściwego sądu lub innego organu państwa wydania orzeczenia 

o przekazanie orzeczenia, o którym mowa w § 1, do wykonania, jeżeli pozwoli to w 

większym stopniu zrealizować wychowawcze i zapobiegawcze cele kary. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 316/356 

§ 3. Do orzeczenia, o którym mowa w § 1, lub jego odpisu poświadczonego za 

zgodność z oryginałem powinno być dołączone zaświadczenie zawierające wszystkie 

istotne informacje umożliwiające jego prawidłowe wykonanie. 

§ 4. Jeżeli zostaną ujawnione okoliczności przemawiające za tym, iż przejęcie 

orzeczenia do wykonania nie pozwoli w większym 

stopniu zrealizować 

wychowawczych i zapobiegawczych celów kary, sąd zawiadamia o tym właściwy sąd 

lub inny organ państwa wydania orzeczenia. 

§ 5. Na wniosek właściwego sądu lub innego organu państwa wydania 

orzeczenia, sąd może wyrazić zgodę na wykonanie kary pozbawienia wolności, 

orzeczonej wobec sprawcy niemającego obywatelstwa polskiego lub nieposiadającego 

stałego lub czasowego miejsca pobytu na terytorium Rzeczypospolitej Polskiej, jeżeli 

pozwoli to w większym stopniu zrealizować wychowawcze i zapobiegawcze cele 

kary. 

§ 6. Jeżeli przepisy niniejszego 

rozdziału nie stanowią 

inaczej, przy 

wykonywaniu orzeczeń, o których mowa w § 1, stosuje się przepisy prawa polskiego.


## Art. 611th. {#kpk-art-611th}
§ 1. Właściwy do rozpoznania spraw określonych w art. 611tg § 1, 2 

i 5 jest sąd okręgowy, w którego okręgu skazany posiada stałe lub czasowe miejsce 

pobytu. 

§ 2. Jeżeli nie można ustalić właściwości według zasad określonych w § 1, 

właściwy jest Sąd Okręgowy w Warszawie. 

§ 3. Jeżeli sąd, do którego zostało skierowane orzeczenie, nie jest właściwy do 

nadania mu biegu, przekazuje je właściwemu sądowi i zawiadamia o tym właściwy 

sąd lub inny organ państwa wydania orzeczenia.


## Art. 611ti. {#kpk-art-611ti}
§ 1. Sąd rozpoznaje sprawę wykonania orzeczenia, o którym mowa 

w art. 611tg § 1, na posiedzeniu, w którym ma prawo wziąć udział prokurator, 

skazany, jeżeli przebywa na terytorium Rzeczypospolitej Polskiej, i jego obrońca, 

jeżeli się na nie stawi. Jeżeli skazany, który nie przebywa na terytorium 

Rzeczypospolitej Polskiej, nie posiada obrońcy, prezes sądu właściwego do 

rozpoznania sprawy może mu wyznaczyć obrońcę z urzędu. 

§ 2. Skazany może ustnie lub na piśmie wyrazić zgodę na przekazanie lub złożyć 

oświadczenie o zrzeczeniu się korzystania z prawa określonego w art. 611tm, jeżeli 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 317/356 

zgoda lub oświadczenie nie zostały złożone w państwie wydania orzeczenia. Art. 611t 

§ 5 stosuje się odpowiednio. 

§ 3. Jeżeli państwo wydania orzeczenia nie przekazało wszystkich informacji 

potrzebnych do podjęcia decyzji w przedmiocie wykonania orzeczenia, sąd wzywa 

właściwy sąd lub inny organ państwa wydania orzeczenia do ich uzupełnienia we 

wskazanym terminie. W razie niedotrzymania terminu postanowienie w przedmiocie 

wykonania orzeczenia wydaje się w oparciu o posiadane informacje.


## Art. 611tj. {#kpk-art-611tj}
§ 1. Postanowienie w przedmiocie wykonania orzeczenia, o którym 

mowa w art. 611tg § 1, sąd wydaje w terminie 40 dni od daty otrzymania orzeczenia 

wraz z zaświadczeniem. 

§ 2. Na postanowienie sądu w przedmiocie wykonania orzeczenia przysługuje 

zażalenie. 

§ 3. Postępowanie w przedmiocie wykonania orzeczenia powinno zakończyć się 

prawomocnie w terminie 90 dni od daty otrzymania orzeczenia wraz 

z zaświadczeniem. 

§ 4. W wypadku gdy termin określony w § 3 nie może być dotrzymany, należy 

zawiadomić właściwy sąd lub inny 

organ państwa wydania orzeczenia, podając przyczynę opóźnienia 

i przewidywany termin wydania orzeczenia. 

 [§ 5. Odpis postanowienia przekazuje się Ministrowi Sprawiedliwości.] 

 <§ 5. Kopię postanowienia przekazuje się Ministrowi Sprawiedliwości.> 

§ 6. Do wykonania orzeczenia właściwego sądu lub innego organu państwa 

wydania orzeczenia sąd przystępuje niezwłocznie.


## Art. 611tk. {#kpk-art-611tk}
§ 1. Odmawia się wykonania orzeczenia, o którym mowa 

w art. 611tg § 1, jeżeli: 

1) 

czyn, w związku z którym wydano to orzeczenie, nie stanowi przestępstwa 

według prawa polskiego; 

2) 

przekazane do wykonania orzeczenie dotyczy tego samego czynu tej samej 

osoby, co do której postępowanie karne zostało prawomocnie zakończone 

w państwie członkowskim Unii Europejskiej, a orzeczenie w zakresie kary 

pozbawienia wolności zostało wykonane; 

3) 

skazany nie wyraża zgody na przekazanie, chyba że: 

2025-09-11 

Zmiana w § 5 w 
art. 611tj wejdzie 
w życie z dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 
 
 
 
 

©Kancelaria Sejmu 

s. 318/356 

a) 

jest obywatelem polskim i posiada stałe lub czasowe miejsce pobytu na 

terytorium Rzeczypospolitej Polskiej, 

b) 

została wobec niego wydana decyzja o wydaleniu lub deportacji na tery-

torium Rzeczypospolitej Polskiej, 

c) 

zbiegł na terytorium Rzeczypospolitej Polskiej w obawie przed toczącym 

się w państwie wydania orzeczenia postępowaniem karnym lub obowiąz-

kiem odbycia orzeczonej kary; 

4) 

skazany z powodu wieku nie ponosi według prawa polskiego odpowiedzialności 

karnej za czyny będące podstawą wydania orzeczenia; 

5) 

naruszałoby to wolności i prawa człowieka i obywatela; 

6) wykonanie kary łączy się z zastosowaniem terapii lub innych środków 

nieznanych ustawie; 

7) 

skazany nie jest obywatelem polskim, chyba że zachodzą przesłanki określone 

w § 4. 

§ 2. Przepisu § 1 pkt 1 nie stosuje się, jeżeli czyn nie stanowi przestępstwa 

z powodu braku lub odmiennego uregulowania w prawie polskim odpowiednich opłat, 

podatków, ceł lub zasad obrotu dewizowego. 

§ 3. Można odmówić wykonania orzeczenia, o którym mowa w art. 611tg § 1, 

jeżeli: 

1) mimo wezwania przez sąd do uzupełnienia informacji we wskazanym terminie, 

do orzeczenia nie dołączono zaświadczenia, o którym mowa w art. 611tg § 3, 

albo zaświadczenie to jest niekompletne lub w sposób oczywisty niezgodne 

z treścią orzeczenia; 

2) według prawa polskiego nastąpiło przedawnienie wykonania kary, 

a przestępstwo, którego to dotyczy, podlegało jurysdykcji sądów polskich; 

3) 

skazany nie ma na terytorium Rzeczypospolitej Polskiej stałego ani czasowego 

miejsca pobytu, chyba że na podstawie prawomocnej decyzji ma zostać 

wydalony do Polski lub zachodzą przesłanki określone w § 4; 

4) 

z treści zaświadczenia, o którym mowa w art. 611tg § 3, wynika, iż orzeczenie 

zostało wydane pod nieobecność sprawcy, chyba że: 

a) 

skazanego wezwano do udziału w postępowaniu lub w inny sposób za-

wiadomiono o terminie i miejscu rozprawy albo posiedzenia, pouczając, że 

niestawiennictwo nie stanowi przeszkody dla wydania orzeczenia, 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 319/356 

b) obrońca sprawcy był obecny na rozprawie lub posiedzeniu, 

c) po doręczeniu skazanemu odpisu orzeczenia wraz z pouczeniem o przy-

sługującym mu prawie, terminie i sposobie złożenia w państwie wydania 

nakazu wniosku o przeprowadzenie z jego udziałem nowego postępowania 

sądowego w tej samej sprawie, skazany w ustawowym terminie nie złożył 

takiego wniosku albo oświadczył, że nie kwestionuje orzeczenia; 

5) 

orzeczenie dotyczy przestępstwa, które według prawa polskiego zostało 

popełnione w całości albo w części na terytorium Rzeczypospolitej Polskiej, jak 

również na polskim statku wodnym lub powietrznym; 

6) w chwili otrzymania orzeczenia pozostała do wykonania kara jest krótsza niż 

6 miesięcy pozbawienia wolności; 

7) 

skazany nie podlega jurysdykcji polskich sądów karnych, lub też brak jest 

wymaganego zezwolenia na jego ściganie; 

8) 

przestępstwo, którego dotyczy orzeczenie, w wypadku jurysdykcji polskich 

sądów karnych podlegałoby darowaniu na mocy amnestii; 

9) 

organ państwa wydania orzeczenia nie wyraził zgody na podstawie art. 607e § 3 

pkt 8 w związku z art. 611tm na to, by sprawcę ścigać za przestępstwo inne niż 

to, które stanowiło podstawę przekazania, lub by wykonać orzeczoną wobec 

niego karę pozbawienia wolności za inne przestępstwo. 

§ 4. Sąd może wyrazić zgodę na przejęcie do wykonania orzeczenia, o którym 

mowa w art. 611tg § 1, zapadłego wobec skazanego niebędącego obywatelem polskim 

lub niemającego na terytorium Rzeczypospolitej Polskiej stałego ani czasowego 

miejsca pobytu, jeżeli ze względu na sytuację rodzinną lub szczególne warunki 

osobiste skazanego przejęcie orzeczenia pozwoli w większym stopniu zrealizować 

wychowawcze i zapobiegawcze cele kary. 

§ 5. W wypadkach przewidzianych w § 1 pkt 2, 3 i 6 oraz w § 3 pkt 1, 2, 4, 5 

i 8 sąd przed podjęciem decyzji w przedmiocie wykonania orzeczenia informuje 

o możliwości odmowy wykonania orzeczenia właściwy sąd lub inny organ państwa 

wydania orzeczenia.


## Art. 611tl. {#kpk-art-611tl}
§ 1. Orzekając o wykonaniu kary pozbawienia wolności, sąd określa 

kwalifikację prawną czynu według prawa polskiego. Art. 607s § 4 stosuje się 

odpowiednio. Na poczet orzeczonej lub wykonywanej kary pozbawienia wolności 

zalicza się okres faktycznego pozbawienia wolności w państwie wydania orzeczenia. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 320/356 

§ 2. Jeżeli rodzaj kary polegającej na pozbawieniu wolności jest nieznany 

ustawie, sąd określa podlegającą wykonaniu karę jako karę pozbawienia wolności. 

Jeżeli przestępstwo zgodnie z przyjętą według prawa polskiego kwalifikacją prawną 

nie jest zagrożone karą pozbawienia wolności, wykonuje się karę orzeczoną przez sąd 

państwa wydania orzeczenia w wymiarze nieprzekraczającym 6 miesięcy 

pozbawienia wolności.


## Art. 611tm. {#kpk-art-611tm}
§ 1. W postępowaniu w przedmiocie wykonania orzeczenia 

dotyczącego kary pozbawienia wolności prawomocnie orzeczonej przez sąd innego 

państwa członkowskiego Unii Europejskiej stosuje się odpowiednio art. 607e. 

§ 2. Na wniosek właściwego sądu lub innego organu państwa wydania 

orzeczenia sąd udziela informacji o treści prawa polskiego mającego zastosowanie do 

warunkowego zwolnienia. Jeżeli sąd lub inny organ państwa wydania orzeczenia 

cofnie wystąpienie do czasu rozpoczęcia wykonywania kary, orzeczenie nie podlega 

wykonaniu.


## Art. 611tn. {#kpk-art-611tn}
§ 1. W razie otrzymania od właściwego sądu lub innego organu 

państwa wydania orzeczenia informacji o tym, iż orzeczenie przekazane do wykonania 

nie podlega dalszemu wykonaniu, sąd wydaje niezwłocznie postanowienie 

o umorzeniu postępowania wykonawczego. 

§ 2. Jeżeli dalsze wykonywanie orzeczenia nie jest możliwe z przyczyn 

faktycznych lub prawnych, sąd niezwłocznie wydaje postanowienie o umorzeniu 

postępowania wykonawczego i zawiadamia właściwy sąd lub inny organ państwa 

wydania orzeczenia.


## Art. 611to. {#kpk-art-611to}
§ 1. Jeżeli skazany znajduje się na terytorium Rzeczypospolitej 

Polskiej, sąd z urzędu lub na wniosek właściwego sądu lub innego organu państwa 

wydania orzeczenia może wydać postanowienie o tymczasowym aresztowaniu. 

Zamiast 

tymczasowego aresztowania 

sąd może zastosować 

inny 

środek 

zapobiegawczy, jeżeli jest on wystarczający do zapewnienia, iż skazany pozostanie na 

terytorium Rzeczypospolitej Polskiej do czasu podjęcia decyzji w przedmiocie wyko-

nania orzeczenia. 

§ 2. Jeżeli zastosowanie środka określonego w § 1 następuje w wyniku wniosku 

państwa wydania orzeczenia przed otrzymaniem orzeczenia wraz z zaświadczeniem, 

art. 605 § 5 i 6 i art. 607k § 3a stosuje się odpowiednio. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 321/356 

§ 3. Sąd może zastosować tymczasowe aresztowanie, oznaczając jego termin na 

czas niezbędny do przekazania skazanego z terytorium państwa członkowskiego Unii 

Europejskiej i doprowadzenia do zakładu karnego. Łączny okres stosowania 

tymczasowego aresztowania nie może przekroczyć 100 dni. Samoistną podstawą 

zastosowania 

tymczasowego aresztowania 

jest orzeczenie o wykonaniu kary 

pozbawienia wolności orzeczonej w innym państwie członkowskim Unii 

Europejskiej.


## Art. 611tp. {#kpk-art-611tp}
§ 1. Na wniosek państwa wydania orzeczenia Minister 

Sprawiedliwości udziela zezwolenia na przewóz sprawcy przez 

terytorium 

Rzeczypospolitej Polskiej, w terminie 7 dni od daty otrzymania wniosku. 

§ 2. Do wniosku o zezwolenie na przewóz, o którym mowa w § 1, powinno być 

załączone zaświadczenie, o którym mowa w art. 611tg § 3. Wydanie zezwolenia, 

o którym mowa w § 1, można odroczyć do czasu uzyskania 

tłumaczenia 

zaświadczenia na język polski. 

§ 3. Minister Sprawiedliwości informuje właściwy organ państwa wydania 

orzeczenia, iż art. 607e § 1 nie znajduje zastosowania w odniesieniu do przestępstwa 

popełnionego lub kary pozbawienia wolności orzeczonej przed opuszczeniem przez 

skazanego terytorium państwa wydania. 

§ 4. Art. 607zb § 2–4 stosuje się odpowiednio.


## Art. 611tr. {#kpk-art-611tr}
§ 1. O treści postanowienia w przedmiocie wykonania orzeczenia, 

o którym mowa w art. 611tj § 1, oraz o istotnych orzeczeniach zapadłych w trakcie 

postępowania wykonawczego, jak również o ucieczce lub ukryciu się skazanego 

zawiadamia się niezwłocznie właściwy sąd lub inny organ państwa wydania 

orzeczenia. Zawiadomienie to może być przekazane również przy użyciu urządzeń 

służących do automatycznego przesyłania danych, w sposób umożliwiający 

stwierdzenie autentyczności przekazanych dokumentów. 

§ 2. W wypadku ucieczki lub ukrycia się skazanego postępowanie wykonawcze 

umarza się. Jeżeli miejsce pobytu skazanego na terytorium Rzeczypospolitej Polskiej 

zostanie następnie ustalone, zawiadamia się o tym niezwłocznie właściwy sąd lub inny 

organ państwa wydania orzeczenia. Orzeczona w tym państwie kara pozbawienia 

wolności może być wykonywana, jeżeli jego właściwy sąd lub inny organ ponownie 

skieruje wystąpienie, o którym mowa w art. 611tg § 1. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 322/356


## Art. 611ts. {#kpk-art-611ts}
Koszty związane z wykonaniem orzeczenia, o którym mowa 

w art. 611tg § 1, ponosi Skarb Państwa, z wyjątkiem kosztów przekazania sprawcy na 

terytorium Rzeczypospolitej Polskiej. 


# Rozdział 66
h 

Wystąpienie do państwa członkowskiego Unii Europejskiej o wykonanie 

orzeczenia skazującego na karę pozbawienia wolności z warunkowym 

zawieszeniem jej wykonania, karę ograniczenia wolności, samoistnie orzeczony 

środek karny, a także orzeczenia o warunkowym zwolnieniu oraz warunkowym 

umorzeniu postępowania karnego


## Art. 611u. {#kpk-art-611u}
§ 1. W razie prawomocnego orzeczenia przez sąd polski wobec 

obywatela polskiego lub cudzoziemca kary pozbawienia wolności z warunkowym 

zawieszeniem jej wykonania, kary ograniczenia wolności, samoistnie orzeczonego 

środka karnego, a także w razie warunkowego zwolnienia lub warunkowego 

umorzenia postępowania karnego, jeżeli orzeczenie nakłada na sprawcę obowiązki 

określone w art. 34 § 1a pkt 1, art. 39 pkt 2–2d, art. 46 § 1 lub 2, art. 67 § 2, art. 72 § 1 

pkt 1, 3–7a i 8 lub art. 72 § 2 Kodeksu karnego lub oddaje skazanego pod dozór 

kuratora lub instytucji publicznej, sąd może wystąpić o wykonanie orzeczenia do 

właściwego sądu lub innego organu państwa członkowskiego Unii Europejskiej, 

zwanego w niniejszym rozdziale „państwem wykonania orzeczenia”, w którym 

sprawca posiada legalne stałe miejsce pobytu, o ile sprawca przebywa w tym państwie 

lub oświadczy, że zamierza tam powrócić. 

§ 2. Wystąpienie, o którym mowa w § 1, może być na wniosek sprawcy 

skierowane również do innego państwa członkowskiego Unii Europejskiej niż 

państwo legalnego stałego miejsca pobytu sprawcy, za zgodą właściwego sądu lub 

innego organu tego państwa. 

§ 3. Wystąpienie, o którym mowa w § 1 i 2, każdorazowo sąd kieruje wyłącznie 

do jednego państwa wykonania orzeczenia. Ponowne wystąpienie do innego państwa 

wykonania orzeczenia może nastąpić jedynie w razie niewykonania albo częściowego 

wykonania orzeczenia. 

§ 4. Do poświadczonego za zgodność z oryginałem odpisu orzeczenia, o którym 

mowa w § 1, dołącza się zaświadczenie zawierające wszystkie istotne informacje 

umożliwiające jego prawidłowe wykonanie. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 323/356 

§ 5. Zaświadczenie powinno zostać przetłumaczone na język urzędowy państwa 

wykonania orzeczenia albo na inny język wskazany przez to państwo. 

§ 6. Przekazanie odpisu orzeczenia oraz zaświadczenia może nastąpić również 

przy użyciu urządzeń służących do automatycznego przesyłania danych, w sposób 

umożliwiający stwierdzenie autentyczności 

tych dokumentów. Na żądanie 

właściwego sądu lub innego organu państwa wykonania orzeczenia sąd przekazuje 

odpis orzeczenia oraz oryginał zaświadczenia. 

§ 7. W razie trudności w ustaleniu właściwego sądu lub innego organu państwa 

wykonania orzeczenia sąd może również zwracać się do właściwych jednostek 

organizacyjnych Europejskiej Sieci Sądowej. 

§ 8. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, wzór 

zaświadczenia, o którym mowa w § 4, zawierając w nim szczegółowe informacje 

dotyczące przekazanego do wykonania orzeczenia, osoby skazanego, rodzaju 

i wymiaru kary lub środka oraz czasu i sposobu wykonania nałożonych obowiązków, 

mając na uwadze konieczność udostępnienia państwu wykonania orzeczenia 

wszelkich niezbędnych informacji umożliwiających podjęcie prawidłowej decyzji w 

przedmiocie wykonania orzeczenia.


## Art. 611ua. {#kpk-art-611ua}
§ 1. W razie wystąpienia o wykonanie orzeczenia, o którym mowa 

w art. 611u § 1, postępowanie wykonawcze zawiesza się. 

§ 2. Po otrzymaniu informacji o zakończeniu wykonywania orzeczenia sąd 

podejmuje zawieszone postępowanie i umarza je. Postępowanie umarza się również, 

jeżeli w stosunku do sprawcy zapadło w innym państwie członkowskim Unii 

Europejskiej i zostało wykonane prawomocne orzeczenie co do tego samego czynu. 

§ 3. W razie otrzymania 

informacji o niemożności wykonania orzeczenia 

w całości albo w części z powodów innych niż wskazane w § 2 zdanie drugie, a także 

o niemożności wydania przez to państwo orzeczenia w przedmiocie zarządzenia 

wykonania kary warunkowo zawieszonej, odwołania warunkowego zwolnienia albo 

innego orzeczenia związanego z wykonaniem orzeczenia, o którym mowa w art. 611u 

§ 1, sąd podejmuje zawieszone postępowanie w celu jego dalszego prowadzenia. 

§ 4. W razie otrzymania informacji o dostosowaniu orzeczenia, o którym mowa 

w art. 611u § 1, do prawa państwa wykonania orzeczenia i przed rozpoczęciem 

wykonywania tego orzeczenia w tym państwie, sąd w ciągu 10 dni może cofnąć 

wystąpienie, o którym mowa w art. 611u § 1 i 2, mając na uwadze cele kary. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 324/356 

§ 5. W razie wszczęcia nowego postępowania karnego przeciwko sprawcy, sąd 

może zwrócić się do właściwego sądu lub innego organu państwa wykonania 

orzeczenia o wyrażenie zgody na cofnięcie wystąpienia, o którym mowa w art. 611u 

§ 1 i 2. Po uzyskaniu zgody, sąd podejmuje zawieszone postępowanie w celu jego 

dalszego prowadzenia. 

§ 6. Na poczet wykonywanej kary lub środka, o których mowa w art. 611u § 1, 

zalicza się okres faktycznego ich wykonywania w państwie wykonania orzeczenia.


## Art. 611ub. {#kpk-art-611ub}
§ 1. W razie uchylenia orzeczenia, o którym mowa w art. 611u § 1, 

na skutek kasacji albo wznowienia postępowania, ułaskawienia sprawcy, darowania 

przestępstwa na mocy amnestii albo przedawnienia wykonania kary lub w razie 

wystąpienia innych okoliczności skutkujących niemożnością wykonania tego 

orzeczenia, sąd niezwłocznie zawiadamia o tym właściwy sąd lub inny organ państwa 

wykonania orzeczenia. 

§ 2. Sąd zawiadamia niezwłocznie właściwy sąd lub inny organ państwa 

wykonania orzeczenia, przy użyciu zaświadczenia, o wszelkich okolicznościach 

mających wpływ na wykonanie orzeczenia, o którym mowa w art. 611u § 1. Sąd 

zawiadamia również niezwłocznie właściwy sąd lub inny organ państwa wykonania 

orzeczenia o wszelkich istotnych orzeczeniach zapadłych w trakcie postępowania 

wykonawczego. 

§ 3. Zawiadomienia, o których mowa w § 1 i 2, mogą być przekazane również 

przy użyciu urządzeń służących do automatycznego przesyłania danych, w sposób 

umożliwiający stwierdzenie autentyczności przekazanych dokumentów. 

§ 4. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, wzór 

zaświadczenia, o którym mowa w § 2, zawierając w nim szczegółowe informacje 

dotyczące naruszeń obowiązków nałożonych na sprawcę i innych okoliczności 

mających wpływ na wykonanie orzeczenia, mając na uwadze konieczność 

udostępnienia państwu wykonania orzeczenia wszelkich niezbędnych informacji 

umożliwiających podjęcie prawidłowej decyzji.


## Art. 611uc. {#kpk-art-611uc}
Sąd rozpoznaje sprawę wystąpienia do właściwego sądu lub innego 

organu państwa wykonania orzeczenia na posiedzeniu, w którym ma prawo wziąć 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 325/356 

udział prokurator i pokrzywdzony, sprawca, jeżeli przebywa na terytorium Rzeczy-

pospolitej Polskiej, i jego obrońca, jeżeli się na nie stawi. Na postanowienie sądu 

zażalenie nie przysługuje. 


# Rozdział 66
i 

Wystąpienie państwa członkowskiego Unii Europejskiej o wykonanie orzeczenia 

karnego związanego z poddaniem sprawcy próbie


## Art. 611ud. {#kpk-art-611ud}
§ 1. W razie wystąpienia państwa 

członkowskiego Unii 

Europejskiej, zwanego w niniejszym rozdziale „państwem wydania orzeczenia”, 

o wykonanie prawomocnego orzeczenia skazującego na karę pozbawienia wolności 

z warunkowym zawieszeniem jej wykonania albo na samoistną karę lub środek 

niepolegający na pozbawieniu wolności lub na grzywnie, bądź orzekającego 

o warunkowym zwolnieniu, warunkowym umorzeniu postępowania karnego lub 

innym warunkowym odroczeniu wykonania kary, orzeczenie to podlega wykonaniu 

przez sąd rejonowy, w którego okręgu sprawca posiada legalne stałe miejsce pobytu, 

jeżeli w wyznaczonym okresie próby nakłada ono na sprawcę obowiązek: 

1) 

2) 

stawiennictwa przed określonym organem; 

informowania określonego organu o zmianie miejsca pobytu lub miejsca pracy 

albo uzyskiwania zgody na taką zmianę; 

3) 

przebywania albo powstrzymania się od przebywania w określonych 

środowiskach lub miejscach, w tym również jeśli orzeczenie zakazuje wstępu do 

określonych miejsc lub na imprezy o charakterze masowym; 

4) 

powstrzymania się od kontaktowania z określonymi osobami lub zbliżania się do 

określonych osób; 

powstrzymania się od posiadania określonych przedmiotów; 

łożenia na utrzymanie innej osoby; 

naprawienia szkody; 

nauki; 

5) 

6) 

7) 

8) 

9) wykonywania nieodpłatnej, kontrolowanej pracy na cele społeczne, pracy 

społecznie użytecznej lub pracy zarobkowej; 

10) poddania się określonym zakazom albo ograniczeniom w wykonywaniu zawodu, 

prowadzeniu działalności zawodowej lub gospodarczej; 

11) poddania się leczeniu albo oddziaływaniom terapeutycznym; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 326/356 

12) poddania się dozorowi kuratora, pracownika społecznego lub instytucji 

publicznej, do której działalności należy troska o wychowanie, zapobieganie 

demoralizacji lub pomoc skazanym. 

§ 2. Do orzeczenia, o którym mowa w § 1, lub jego odpisu poświadczonego za 

zgodność z oryginałem powinno być dołączone zaświadczenie zawierające wszystkie 

istotne informacje umożliwiające jego prawidłowe wykonanie. 

§ 3. Jeżeli sąd, do którego zostało skierowane wystąpienie, nie jest właściwy do 

nadania mu biegu, przekazuje je właściwemu sądowi i zawiadamia o tym właściwy 

sąd lub inny organ państwa wydania orzeczenia. Art. 32 § 3 stosuje się odpowiednio. 

§ 4. Na wniosek właściwego sądu lub innego organu państwa wydania 

orzeczenia, sąd może wyrazić zgodę na wykonanie kary lub środka, o których mowa 

w § 1, orzeczonego wobec sprawcy nieposiadającego legalnego stałego miejsca 

pobytu na terytorium Rzeczypospolitej Polskiej, jeżeli pozwoli to w większym stopniu 

zrealizować wychowawcze i zapobiegawcze cele kary lub środka. 

§ 5. Jeżeli przepisy niniejszego 

rozdziału nie stanowią 

inaczej, przy 

wykonywaniu orzeczeń, o których mowa w § 1, stosuje się przepisy prawa polskiego. 

Art. 611c § 3 stosuje się odpowiednio.


## Art. 611ue. {#kpk-art-611ue}
§ 1. Sąd rozpoznaje sprawę wykonania orzeczenia, o którym mowa 

w art. 611ud § 1, na posiedzeniu, w którym ma prawo wziąć udział prokurator, 

sprawca, jeżeli przebywa na terytorium Rzeczypospolitej Polskiej, i jego obrońca, 

jeżeli się na nie stawi. Jeżeli sprawca, który nie przebywa na terytorium 

Rzeczypospolitej Polskiej, nie posiada obrońcy, prezes sądu właściwego do 

rozpoznania sprawy może mu wyznaczyć obrońcę z urzędu. 

§ 2. Jeżeli państwo wydania orzeczenia nie przekazało wszystkich informacji 

potrzebnych do podjęcia decyzji w przedmiocie wykonania orzeczenia, sąd wzywa 

właściwy sąd lub inny organ państwa wydania orzeczenia do ich uzupełnienia we 

wskazanym terminie. W razie niedotrzymania terminu, postanowienie w przedmiocie 

wykonania orzeczenia wydaje się w oparciu o posiadane informacje. 

§ 3. Orzekając o wykonaniu kary lub środka, o których mowa w art. 611ud § 1, 

sąd określa kwalifikację prawną czynu według prawa polskiego. Jeżeli rodzaj kary lub 

środka albo sposób wykonania nałożonych obowiązków są nieznane ustawie, sąd 

określa karę, środek lub obowiązek według prawa polskiego. Podstawę określenia 

kary lub środka podlegającego wykonaniu stanowi orzeczenie wydane przez sąd 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 327/356 

państwa członkowskiego Unii Europejskiej, kara grożąca za taki czyn w polskim 

prawie oraz okres rzeczywistego wykonywania kary, środka lub obowiązku za granicą, 

z uwzględnieniem różnic na korzyść skazanego. Jeżeli wymiar kary, środka, 

obowiązku lub okresu próby jest wyższy niż przewidziany w ustawie, sąd określa go 

w górnej granicy wymiaru według prawa polskiego. 

§ 4. Jeżeli orzeczenie, o którym mowa w art. 611ud § 1, nie określa kary 

pozbawienia wolności, 

która 

będzie wymierzona 

sprawcy w wypadku 

niewykonywania nałożonych obowiązków lub podjęcia warunkowo umorzonego 

postępowania karnego, sąd orzeka o wykonaniu orzeczenia jedynie w zakresie 

nałożonych w nim obowiązków. Art. 611ub § 2 i 3 stosuje się odpowiednio.


## Art. 611uf. {#kpk-art-611uf}
§ 1. Postanowienie w przedmiocie wykonania orzeczenia, o którym 

mowa w art. 611ud § 1, sąd wydaje w terminie 30 dni od daty otrzymania orzeczenia 

wraz z zaświadczeniem. 

§ 2. Na postanowienie sądu w przedmiocie wykonania orzeczenia przysługuje 

zażalenie. 

§ 3. Postępowanie w przedmiocie wykonania orzeczenia powinno zakończyć się 

prawomocnie w terminie 60 dni od daty otrzymania orzeczenia wraz 

z zaświadczeniem. 

§ 4. W wypadku gdy termin określony w § 3 nie może być dotrzymany, należy 

zawiadomić właściwy sąd lub inny 

organ państwa wydania orzeczenia, podając przyczynę opóźnienia 

i przewidywany termin wydania orzeczenia. 

§ 5. Do wykonania orzeczenia właściwego sądu lub innego organu państwa 

wydania orzeczenia sąd przystępuje niezwłocznie.


## Art. 611ug. {#kpk-art-611ug}
§ 1. Odmawia się wykonania orzeczenia, o którym mowa 

w art. 611ud § 1, jeżeli: 

1) 

czyn, w związku z którym wydano to orzeczenie, nie stanowi przestępstwa 

według prawa polskiego; 

2) 

sprawca nie przebywa na terytorium Rzeczypospolitej Polskiej, chyba że istnieją 

podstawy do uznania, że sprawca na nie powróci. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 328/356 

§ 2. Przepisu § 1 pkt 1 nie stosuje się, jeżeli czyn nie stanowi przestępstwa 

z powodu braku lub odmiennego uregulowania w prawie polskim odpowiednich opłat, 

podatków, ceł lub zasad obrotu dewizowego. 

§ 3. Można odmówić wykonania orzeczenia, o którym mowa w art. 611ud § 1, 

jeżeli: 

1) mimo wezwania przez sąd do uzupełnienia informacji we wskazanym terminie, 

do orzeczenia nie dołączono zaświadczenia, o którym mowa w art. 611ud § 2, 

albo zaświadczenie to jest niekompletne lub w sposób oczywisty niezgodne 

z treścią orzeczenia; 

2) 

przekazane do wykonania orzeczenie dotyczy tego samego czynu tej samej 

osoby, co do której postępowanie karne zostało prawomocnie zakończone 

w państwie członkowskim Unii Europejskiej, a orzeczenie w zakresie kary 

pozbawienia wolności z warunkowym zawieszeniem wykonania albo samoistnej 

kary lub środka niepolegającego na pozbawieniu wolności lub na grzywnie 

zostało wykonane; 

3) według prawa polskiego nastąpiło przedawnienie wykonania kary, 

a przestępstwo, którego to dotyczy, podlegało jurysdykcji sądów polskich; 

4) 

orzeczenie dotyczy przestępstwa, które według prawa polskiego zostało 

popełnione w całości albo w części na terytorium Rzeczypospolitej Polskiej, jak 

również na polskim statku wodnym lub powietrznym; 

5) 

sprawca z powodu wieku nie ponosi według prawa polskiego odpowiedzialności 

karnej za czyny będące podstawą wydania orzeczenia; 

6) 

sprawca korzysta z immunitetu, zgodnie z którym niemożliwy jest nadzór nad 

przestrzeganiem nałożonych obowiązków; 

7) 

z treści zaświadczenia, o którym mowa w art. 611ud § 2, wynika, że orzeczenie 

zostało wydane pod nieobecność sprawcy, chyba że: 

a) 

sprawcę wezwano do udziału w postępowaniu lub w inny sposób zawia-

domiono o terminie i miejscu rozprawy albo posiedzenia, pouczając, że 

niestawiennictwo nie stanowi przeszkody dla wydania orzeczenia, 

b) obrońca sprawcy był obecny na rozprawie lub posiedzeniu, 

c) po doręczeniu sprawcy odpisu orzeczenia wraz z pouczeniem o przy-

sługującym mu prawie, terminie i sposobie złożenia w państwie wydania 

nakazu wniosku o przeprowadzenie z jego udziałem nowego postępowania 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 329/356 

sądowego w tej samej sprawie, sprawca w ustawowym terminie nie złożył 

takiego wniosku albo oświadczył, że nie kwestionuje orzeczenia; 

8) 

orzeczenie dotyczy wyłącznie obowiązków innych niż określone w art. 611ud 

§ 1 lub zostało przekazane pomimo niespełnienia warunków przewidzianych 

w art. 611u; 

9) 

przestępstwo, którego dotyczy orzeczenie, w wypadku jurysdykcji polskich 

sądów karnych podlegałoby darowaniu na mocy amnestii; 

10) orzeczenie przewiduje środek związany z leczeniem, nieznany ustawie; 

11) pozostały czas wykonania nałożonych obowiązków jest krótszy niż 6 miesięcy. 

§ 4. W wypadkach wskazanych w § 1 i 3, gdy przemawiają za tym szczególne 

względy, sąd, w uzgodnieniu z właściwym sądem lub innym organem państwa 

wydania orzeczenia, może orzec o wykonaniu orzeczenia jedynie w zakresie 

nałożonych w nim obowiązków. W zakresie zarządzenia wykonania kary, odwołania 

warunkowego zwolnienia, orzeczenia kary zastępczej oraz ustanowienia, 

rozszerzenia, zmiany i zwolnienia od wykonania nałożonych obowiązków w okresie 

próby albo uznania kary lub środka za wykonane – orzeczenie wykonuje właściwy sąd 

lub inny organ państwa wydania orzeczenia, chyba że uzgodniono inaczej. 

§ 5. W wypadkach przewidzianych w § 1 pkt 2 oraz w § 3 pkt 1, 2, 4, 7 lub 9–

11 sąd przed podjęciem decyzji w przedmiocie wykonania orzeczenia informuje 

o możliwości odmowy wykonania orzeczenia właściwy sąd lub inny organ państwa 

wydania orzeczenia.


## Art. 611uh. {#kpk-art-611uh}
§ 1. W razie otrzymania od właściwego sądu lub innego organu 

państwa wydania orzeczenia informacji o tym, iż orzeczenie przekazane do wykonania 

nie podlega dalszemu wykonaniu, sąd niezwłocznie wydaje postanowienie 

o umorzeniu postępowania wykonawczego. 

§ 2. Jeżeli dalsze wykonywanie orzeczenia nie jest możliwe z przyczyn 

faktycznych lub prawnych, sąd niezwłocznie wydaje postanowienie o umorzeniu 

postępowania wykonawczego i zawiadamia właściwy sąd lub inny organ państwa 

wydania orzeczenia. 

§ 3. W razie otrzymania od właściwego sądu lub innego organu państwa wydania 

orzeczenia informacji o tym, iż przeciwko sprawcy wszczęto nowe postępowanie 

karne i na uzasadniony wniosek tego sądu lub organu, sąd może wyrazić zgodę na 

cofnięcie wystąpienia, o którym mowa w art. 611ud § 1, mając na uwadze cele kary 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 330/356 

lub środka, okres ich wykonywania oraz postawę sprawcy. Sąd umożliwia sprawcy, 

przebywającemu na terytorium Rzeczypospolitej Polskiej, zajęcie stanowiska ustnie 

lub na piśmie w przedmiocie cofnięcia wystąpienia. Wyrażając zgodę na cofnięcie 

wystąpienia, sąd umarza postępowanie wykonawcze.


## Art. 611ui. {#kpk-art-611ui}
O treści postanowienia w przedmiocie wykonania orzeczenia, 

o którym mowa w art. 611ud § 1, oraz o istotnych orzeczeniach zapadłych w trakcie 

postępowania wykonawczego zawiadamia się niezwłocznie właściwy sąd lub inny 

organ państwa wydania orzeczenia. Zawiadomienie to może być przekazane również 

przy użyciu urządzeń służących do automatycznego przesyłania danych, w sposób 

umożliwiający stwierdzenie autentyczności przekazanych dokumentów.


## Art. 611uj. {#kpk-art-611uj}
Koszty związane z wykonaniem orzeczenia, o którym mowa 

w art. 611ud § 1, ponosi Skarb Państwa. 


# Rozdział 66
j 

Wystąpienie do państwa członkowskiego Unii Europejskiej o wykonanie 

europejskiego nakazu ochrony


## Art. 611w. {#kpk-art-611w}
§ 1. W razie orzeczenia lub wykonywania przez polski sąd lub 

prokuratora środka zapobiegawczego, środka karnego lub obowiązku związanego 

z poddaniem sprawcy próbie, polegającego na powstrzymaniu się od przebywania 

w określonych środowiskach lub miejscach lub kontaktowania się z określonymi 

osobami, lub zbliżania się do określonych osób, oraz gdy jest to niezbędne dla ochrony 

praw pokrzywdzonego, sąd lub prokurator może, na wniosek pokrzywdzonego, 

wystąpić o wykonanie tego środka lub obowiązku do właściwego sądu lub innego 

organu państwa członkowskiego Unii Europejskiej, zwanego w niniejszym rozdziale 

„państwem wykonania nakazu”, w którym pokrzywdzony przebywa lub oświadczy, 

że zamierza tam przebywać, wydając europejski nakaz ochrony. 

§ 2. W razie potrzeby sąd lub prokurator kieruje nakaz do więcej niż jednego 

państwa wykonania nakazu. 

§ 3. Nakaz zawiera informacje umożliwiające jego prawidłowe wykonanie, 

dotyczące orzeczenia, pokrzywdzonego, oskarżonego i środka lub obowiązku, 

o których mowa w § 1. Do nakazu dołącza się poświadczony za zgodność 

z oryginałem odpis orzeczenia, o którym mowa w § 1. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 331/356 

§ 4. Nakaz powinien zostać przetłumaczony na język urzędowy państwa 

wykonania nakazu albo na inny język wskazany przez to państwo. 

§ 5. Przekazanie odpisu nakazu oraz orzeczenia może nastąpić również przy 

użyciu urządzeń służących do automatycznego przesyłania danych, w sposób 

umożliwiający stwierdzenie autentyczności tych dokumentów. Na żądanie właś-

ciwego sądu lub innego organu państwa wykonania nakazu sąd lub prokurator 

przekazuje odpis orzeczenia oraz oryginał nakazu. 

§ 6. W razie trudności w ustaleniu właściwego sądu lub innego organu państwa 

wykonania nakazu sąd lub prokurator może również zwracać się do właściwych 

jednostek organizacyjnych Europejskiej Sieci Sądowej lub Eurojust. 

§ 7. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, wzór 

europejskiego nakazu ochrony, mając na uwadze konieczność udostępnienia państwu 

wykonania nakazu wszelkich niezbędnych informacji umożliwiających podjęcie 

prawidłowej decyzji w przedmiocie wykonania nakazu.


## Art. 611wa. {#kpk-art-611wa}
Wystąpienie o wykonanie europejskiego nakazu ochrony nie 

wstrzymuje wykonywania środka lub obowiązku, o którym mowa w art. 611w § 1.


## Art. 611wb. {#kpk-art-611wb}
§ 1. W razie zmiany lub uchylenia środka lub obowiązku, o którym 

mowa w art. 611w § 1, sąd lub prokurator niezwłocznie zawiadamia o tym właściwy 

sąd lub inny organ państwa wykonania nakazu. 

§ 2. Zawiadomienie, o którym mowa w § 1, może zostać przekazane również 

przy użyciu urządzeń służących do automatycznego przesyłania danych, w sposób 

umożliwiający stwierdzenie autentyczności przekazanych dokumentów.


## Art. 611wc. {#kpk-art-611wc}
Na 

postanowienie 

sądu 

lub 

prokuratora w przedmiocie 

europejskiego nakazu ochrony zażalenie nie przysługuje. 


# Rozdział 66
k 

Wystąpienie państwa członkowskiego Unii Europejskiej o wykonanie 

europejskiego nakazu ochrony


## Art. 611wd. {#kpk-art-611wd}
§ 1. W razie wystąpienia państwa 

członkowskiego Unii 

Europejskiej, zwanego w niniejszym rozdziale „państwem wydania nakazu”, 

o wykonanie europejskiego nakazu ochrony, wydanego na podstawie orzeczenia 

nakładającego na osobę, przeciwko której jest lub było prowadzone postępowanie 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 332/356 

karne, obowiązek polegający na powstrzymaniu się od przebywania w określonych 

środowiskach lub miejscach lub kontaktowania się z określonymi osobami, lub 

zbliżania się do określonych osób, nakaz ten podlega wykonaniu przez prokuratora 

właściwego miejscowo ze względu na miejsce pobytu osoby podlegającej ochronie. 

§ 2. Nakaz powinien zawierać informacje umożliwiające jego prawidłowe 

wykonanie. Do nakazu powinno być dołączone orzeczenie, o którym mowa w § 1, lub 

jego odpis poświadczony za zgodność z oryginałem. W odniesieniu do zawartych 

w nakazie danych dotyczących miejsca pobytu i pracy osoby podlegającej ochronie 

stosuje się odpowiednio art. 148a. 

§ 3. Jeżeli prokurator, do którego został skierowany nakaz, nie jest właściwy do 

nadania mu biegu, przekazuje go właściwemu prokuratorowi i zawiadamia o tym 

właściwy sąd lub inny organ państwa wydania nakazu. 

§ 4. Jeżeli wniosek o wydanie nakazu został skierowany przez osobę podlegającą 

ochronie na podstawie orzeczenia wydanego w innym państwie członkowskim Unii 

Europejskiej bezpośrednio do polskiego prokuratora, z pominięciem właściwego 

organu, prokurator przekazuje wniosek właściwemu sądowi lub innemu organowi 

w państwie, w którym wydano orzeczenie wobec osoby, przeciwko której jest lub było 

prowadzone postępowanie karne. 

§ 5. Jeżeli przepisy niniejszego 

rozdziału nie stanowią 

inaczej, przy 

wykonywaniu nakazu stosuje się przepisy prawa polskiego.


## Art. 611we. {#kpk-art-611we}
§ 1. Jeżeli państwo wydania nakazu nie przekazało wszystkich 

informacji potrzebnych do podjęcia decyzji w przedmiocie wykonania europejskiego 

nakazu ochrony, prokurator wzywa właściwy sąd lub inny organ państwa wydania 

nakazu do ich uzupełnienia we wskazanym terminie. W razie niedotrzymania terminu 

postanowienie w przedmiocie wykonania nakazu wydaje się w oparciu o posiadane 

informacje. 

§ 2. Jeżeli rodzaj albo sposób wykonania obowiązków są nieznane ustawie, 

prokurator określa obowiązek według prawa polskiego, z uwzględnieniem różnic na 

korzyść osoby, przeciwko której jest lub było prowadzone postępowanie karne.


## Art. 611wf. {#kpk-art-611wf}
§ 1. Na postanowienie prokuratora w przedmiocie wykonania 

europejskiego nakazu ochrony przysługuje zażalenie do sądu rejonowego, w którego 

okręgu wydano to postanowienie. Sąd rozpoznaje zażalenie na posiedzeniu, w którym 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 333/356 

ma prawo wziąć udział prokurator, osoba, przeciwko której jest lub było prowadzone 

postępowanie karne, i osoba podlegająca ochronie, jeżeli przebywają na terytorium 

Rzeczypospolitej Polskiej, oraz obrońca i pełnomocnik, jeżeli stawią się na nie. Jeżeli 

osoba, przeciwko której jest lub było prowadzone postępowanie karne, nie przebywa 

na terytorium Rzeczypospolitej Polskiej ani nie posiada obrońcy, prezes sądu 

właściwego do rozpoznania zażalenia może jej wyznaczyć obrońcę z urzędu. 

§ 2. Do wykonania nakazu prokurator przystępuje niezwłocznie.


## Art. 611wg. {#kpk-art-611wg}
§ 1. Odmawia się wykonania europejskiego nakazu ochrony, jeżeli 

osoba podlegająca ochronie nie przebywa na terytorium Rzeczypospolitej Polskiej, 

chyba że istnieją podstawy do uznania, że zamierza na nim przebywać. 

§ 2. Można odmówić wykonania nakazu, jeżeli: 

1) 

czyn, w związku z którym nałożono obowiązek, nie stanowi przestępstwa 

według prawa polskiego; 

2) 

pomimo wezwania przez prokuratora do uzupełnienia informacji we wskazanym 

terminie do nakazu nie dołączono orzeczenia, o którym mowa w art. 611wd § 1, 

albo jest on niekompletny lub w sposób oczywisty niezgodny z treścią 

orzeczenia; 

3) 

orzeczenie dotyczy tego samego czynu tej samej osoby, co do której 

postępowanie 

karne 

zostało 

prawomocnie 

zakończone w państwie 

członkowskim Unii Europejskiej, a osoba ta odbywa lub odbyła karę albo kara 

nie może zostać wykonana według prawa państwa, w którym zapadł wyrok 

skazujący; 

4) według prawa polskiego nastąpiło przedawnienie wykonania kary, 

a przestępstwo, którego to dotyczy, podlegało jurysdykcji sądów polskich; 

5) 

orzeczenie dotyczy przestępstwa, które według prawa polskiego zostało 

popełnione w całości albo w części na terytorium Rzeczypospolitej Polskiej, jak 

również na polskim statku wodnym lub powietrznym; 

6) 

osoba, przeciwko której jest lub było prowadzone postępowanie karne, z powodu 

wieku nie ponosi według prawa polskiego odpowiedzialności karnej za czyn 

będący podstawą wydania orzeczenia; 

7) 

osoba, przeciwko której jest lub było prowadzone postępowanie karne, korzysta 

z immunitetu, zgodnie z którym jest niemożliwy nadzór nad przestrzeganiem 

nałożonych obowiązków; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 334/356 

8) 

orzeczenie dotyczy wyłącznie obowiązków innych niż określone w art. 611wd 

§ 1; 

9) 

przestępstwo, którego dotyczy orzeczenie, w wypadku jurysdykcji polskich 

sądów karnych podlegałoby darowaniu na mocy amnestii.


## Art. 611wh. {#kpk-art-611wh}
§ 1. W razie otrzymania od właściwego sądu lub innego organu 

państwa wydania nakazu informacji o tym, iż europejski nakaz ochrony nie podlega 

dalszemu wykonaniu, prokurator niezwłocznie wydaje postanowienie o zaprzestaniu 

jego wykonywania. 

§ 2. Jeżeli dalsze wykonywanie nakazu nie jest możliwe z przyczyn faktycznych 

lub prawnych, prokurator niezwłocznie wydaje postanowienie o zaprzestaniu jego 

wykonywania i zawiadamia o tym właściwy sąd lub inny organ państwa wydania 

nakazu, osobę, przeciwko której jest lub było prowadzone postępowanie karne, oraz 

osobę podlegającą ochronie, jeżeli przebywają na terytorium Rzeczypospolitej 

Polskiej. 

§ 3. W razie otrzymania od właściwego sądu lub innego organu państwa wydania 

nakazu informacji o zmianie obowiązku nałożonego na osobę, przeciwko której jest 

lub było prowadzone postępowanie karne, prokurator rozpoznaje sprawę wykonania 

zmienionego nakazu na zasadach określonych w niniejszym rozdziale. Przepisu 

art. 611wg nie stosuje się, z wyjątkiem § 1 i § 2 pkt 2 i 8.


## Art. 611wi. {#kpk-art-611wi}
§ 1. O treści 

postanowienia w przedmiocie wykonania 

europejskiego nakazu ochrony, o wniesieniu środka odwoławczego od 

tego 

postanowienia, o istotnych orzeczeniach zapadłych w trakcie postępowania, jak 

również o zmianie miejsca pobytu osoby, przeciwko której jest lub było prowadzone 

postępowanie karne, albo osoby podlegającej ochronie zawiadamia się niezwłocznie 

właściwy sąd lub inny organ państwa wydania nakazu. 

§ 2. Prokurator zawiadamia niezwłocznie właściwy sąd lub inny organ państwa 

wydania nakazu o wszelkich okolicznościach mających wpływ na jego wykonanie, 

w szczególności o naruszeniu nałożonego obowiązku. Zawiadomienie o naruszeniu 

tego obowiązku następuje w formie zaświadczenia zawierającego 

informacje 

dotyczące osoby, przeciwko której jest lub było prowadzone postępowanie karne, oraz 

naruszonego obowiązku. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 335/356 

§ 3. W razie uzyskania 

informacji o naruszeniu nałożonego obowiązku 

prokurator może przedsięwziąć osobiście lub zlecić Policji sprawdzenie faktów w tym 

zakresie. Za zgodą osoby podlegającej ochronie prokurator może również wystąpić do 

właściwego komendanta Policji z wnioskiem o zastosowanie środków ochrony 

i pomocy przewidzianych w ustawie z dnia 28 listopada 2014 r. o ochronie i pomocy 

dla pokrzywdzonego i świadka. 

§ 4. W razie ustania przyczyn nałożenia obowiązku lub powstania przyczyn 

uzasadniających jego uchylenie lub zmianę prokurator może wystąpić do właściwego 

sądu lub innego organu państwa wydania nakazu o uchylenie lub zmianę nakazu. 

§ 5. Zawiadomienia, o których mowa w § 1 i 2, oraz wystąpienie, o którym 

mowa w § 4, mogą zostać przekazane również przy użyciu urządzeń służących do 

automatycznego przesyłania danych, w sposób umożliwiający 

stwierdzenie 

autentyczności przekazanych dokumentów. 

§ 6. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, wzór 

zaświadczenia, o którym mowa w § 2, mając na uwadze konieczność udostępnienia 

państwu wydania nakazu wszelkich niezbędnych informacji umożliwiających 

podjęcie prawidłowej decyzji.


## Art. 611wj. {#kpk-art-611wj}
Koszty związane z wykonaniem nakazu ponosi Skarb Państwa. 


# Rozdział 67
 

Przepisy końcowe


## Art. 612. {#kpk-art-612}
§ 1. O każdorazowym wypadku 

zastosowania 

tymczasowego 

aresztowania wobec obywatela państwa obcego, na jego prośbę, zawiadamia się 

niezwłocznie właściwy miejscowo urząd konsularny tego państwa lub – w braku 

takiego urzędu – przedstawicielstwo dyplomatyczne tego państwa. 

§ 2. W razie zatrzymania obywatela państwa obcego należy zatrzymanemu 

umożliwić, na jego prośbę, nawiązanie w dostępnej formie kontaktu z właściwym 

urzędem konsularnym 

lub przedstawicielstwem dyplomatycznym, a w razie 

zatrzymania osoby nieposiadającej żadnego obywatelstwa – z przedstawicielem 

państwa, w którym ma ona stałe miejsce zamieszkania.


## Art. 613. {#kpk-art-613}
§ 1. Z wyjątkiem wypadków 

określonych w art. 592a–592f 

i w art. 595 oraz w rozdziałach 62a–62d, 65a–65d, 66a–66d i 66f–66k z mającymi 

siedzibę za granicą organami obcego państwa oraz z osobami wymienionymi 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 336/356 

w art. 578 oraz w art. 579 sądy i prokuratorzy każdorazowo porozumiewają się, w tym 

przy doręczaniu pism procesowych, za pośrednictwem Ministra Sprawiedliwości, 

a ten w razie potrzeby za pośrednictwem ministra właściwego do spraw za-

granicznych. 

§ 2. Z urzędami konsularnymi obcego państwa w Rzeczypospolitej Polskiej sądy 

i prokuratorzy, w wypadkach określonych przez Ministra Sprawiedliwości, mogą 

porozumiewać się bezpośrednio.


## Art. 614. {#kpk-art-614}
Wydatki poniesione w związku z czynnościami przewidzianymi 

w niniejszym dziale pokrywa państwo obce, które złożyło wniosek o dokonanie 

czynności. Organy państwa polskiego mogą odstąpić od żądania zwrotu poniesionych 

wydatków, jeżeli państwo obce zapewnia wzajemność.


## Art. 615. {#kpk-art-615}
§ 1. W stosunkach z międzynarodowymi trybunałami karnymi i ich 

organami działającymi na podstawie umów międzynarodowych, których 

Rzeczpospolita Polska 

jest 

stroną, albo powołanymi przez organizacje 

międzynarodowe ukonstytuowane umową ratyfikowaną przez Rzeczpospolitą Polską, 

stosuje się odpowiednio przepisy niniejszego działu. 

§ 2. Przepisów niniejszego działu nie stosuje się, jeżeli umowa międzynarodowa, 

której Rzeczpospolita Polska jest stroną, albo akt prawny regulujący działanie 

międzynarodowego trybunału karnego stanowi inaczej. 

§ 3. Przepisów niniejszego działu można nie stosować wobec państwa obcego, 

z którym Rzeczpospolita Polska nie ma w tym przedmiocie umowy, a państwo to nie 

zapewnia wzajemności. 

§ 4. Jeżeli umowa międzynarodowa albo akt prawny regulujący działanie 

międzynarodowego trybunału karnego tego wymaga, Minister Sprawiedliwości 

zawiadamia międzynarodowy trybunał karny o wszczęciu postępowania przeciwko 

osobie o popełnienie przestępstwa podlegającego ściganiu przez ten trybunał. 

§ 5. Jeżeli co do tego samego czynu tej samej osoby wszczęto postępowanie 

karne w Rzeczypospolitej Polskiej i przed międzynarodowym trybunałem karnym, 

Minister Sprawiedliwości przekazuje ściganie temu trybunałowi, jeżeli wymagają tego 

akty prawne regulujące działanie trybunału.


## Art. 615a. {#kpk-art-615a}
§ 1. Przepisy rozdziałów 62, 62c, 62d, 63, 65b, 65d i 67, a także 

przepisy rozporządzenia Parlamentu Europejskiego i Rady (UE) 2018/1805 z dnia 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 337/356 

14 listopada 2018 r. w sprawie wzajemnego uznawania nakazów zabezpieczenia 

i nakazów konfiskaty 

(Dz. Urz. UE L 303 z 28.11.2018, str. 1) stosuje się 

odpowiednio do współpracy między sądami, prokuratorami i innymi organami 

procesowymi a Prokuraturą Europejską. 

§ 2. (uchylony)
