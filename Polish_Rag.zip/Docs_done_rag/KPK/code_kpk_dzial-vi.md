---
id: "code_kpk_dzial-vi"
title: "KPK — DZIAŁ VI"
source_pdf: "D19970555Lj (1).pdf"
dz_u: "Dz. U. 1997 Nr 89 poz. 555"
status: "obowiązujący"
last_consolidated: "2025-09-11"
law: "Kodeks postępowania karnego"
tags: ["kpk", "kodeks", "postępowanie karne"]
articles_range: {"first": "243", "last": "296"}
---

# DZIAŁ VI

## Art. 243. {#kpk-art-243}
§ 1. Każdy ma prawo ująć osobę na gorącym uczynku przestępstwa lub 

w pościgu podjętym bezpośrednio po popełnieniu przestępstwa, jeżeli zachodzi obawa 

ukrycia się tej osoby lub nie można ustalić jej tożsamości. 

§ 2. Osobę ujętą należy niezwłocznie oddać w ręce Policji.


## Art. 244. {#kpk-art-244}
§ 1. Policja ma prawo zatrzymać osobę podejrzaną, jeżeli istnieje 

uzasadnione przypuszczenie, że popełniła ona przestępstwo, a zachodzi obawa 

ucieczki lub ukrycia się tej osoby albo zatarcia śladów przestępstwa bądź też nie 

można ustalić jej tożsamości albo istnieją przesłanki do przeprowadzenia przeciwko 

tej osobie postępowania w trybie przyspieszonym. 

§ 1a. Policja ma prawo zatrzymać osobę podejrzaną, jeżeli istnieje uzasadnione 

przypuszczenie, że popełniła ona przestępstwo z użyciem przemocy na szkodę osoby 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 102/356 

wspólnie zamieszkującej, a zachodzi obawa, że ponownie popełni przestępstwo 

z użyciem przemocy wobec tej osoby, zwłaszcza gdy popełnieniem takiego 

przestępstwa grozi. 

§ 1b. Policja zatrzymuje osobę podejrzaną, jeśli przestępstwo, o którym mowa 

w § 1a, zostało popełnione przy użyciu broni palnej, noża lub innego niebezpiecznego 

przedmiotu, a zachodzi obawa, że ponownie popełni ona przestępstwo z użyciem 

przemocy wobec osoby wspólnie zamieszkującej, zwłaszcza gdy popełnieniem 

takiego przestępstwa grozi. 

§ 2. Zatrzymanego 

należy 

natychmiast 

poinformować 

o przyczynach 

zatrzymania i o przysługujących mu prawach, w tym o prawie do skorzystania 

z pomocy adwokata lub radcy prawnego, do korzystania z bezpłatnej pomocy 

tłumacza, jeżeli nie włada w wystarczającym stopniu językiem polskim, do złożenia 

oświadczenia i odmowy złożenia oświadczenia, do otrzymania odpisu protokołu 

zatrzymania, do dostępu do pierwszej pomocy medycznej oraz o prawach wskazanych 

w art. 245, art. 246 § 1 i art. 612 § 2, jak również o treści art. 248 § 1 i 2, a także 

wysłuchać go. 

§ 3. Z zatrzymania sporządza się protokół, w którym należy podać imię, 

nazwisko i funkcję dokonującego tej czynności, imię i nazwisko osoby zatrzymanej, 

a w razie niemożności ustalenia tożsamości – jej rysopis oraz dzień, godzinę, miejsce 

i przyczynę zatrzymania z podaniem, o jakie przestępstwo się ją podejrzewa. Należy 

także wciągnąć do protokołu złożone przez zatrzymanego oświadczenia oraz 

zaznaczyć udzielenie mu informacji o przysługujących prawach. Odpis protokołu 

doręcza się zatrzymanemu. 

§ 4. Niezwłocznie po zatrzymaniu osoby podejrzanej należy przystąpić do 

zebrania niezbędnych danych, a także o zatrzymaniu zawiadomić prokuratora. 

W razie istnienia podstaw, o których mowa w art. 258 § 1–3, należy wystąpić do 

prokuratora w sprawie skierowania do sądu wniosku o tymczasowe aresztowanie. 

§ 5. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, wzór 

pouczenia, o którym mowa w § 2, zawierającego w szczególności informacje 

o przysługujących zatrzymanemu uprawnieniach: do korzystania z bezpłatnej pomocy 

tłumacza, do złożenia oświadczenia i odmowy złożenia oświadczenia, do otrzymania 

odpisu protokołu zatrzymania, do dostępu do pierwszej pomocy medycznej, jak 

również o prawach wskazanych w § 2, w art. 245, art. 246 § 1 oraz art. 612 § 2 oraz 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 103/356 

informację o treści art. 248 § 1 i 2, mając na względzie konieczność zrozumienia 

pouczenia także przez osoby niekorzystające z pomocy pełnomocnika.


## Art. 245. {#kpk-art-245}
§ 1. Zatrzymanemu na jego żądanie należy niezwłocznie umożliwić 

nawiązanie w dostępnej formie kontaktu z adwokatem lub radcą prawnym, a także 

bezpośrednią z nimi 

rozmowę; w wyjątkowych wypadkach, uzasadnionych 

szczególnymi okolicznościami, zatrzymujący może zastrzec, że będzie przy niej 

obecny. 

§ 2. Przepis art. 517j § 1 oraz przepisy wydane na podstawie art. 517j § 2 stosuje 

się odpowiednio. 

§ 3. Przepisy art. 261 stosuje się odpowiednio, z tym że zawiadomienie 

następuje na żądanie zatrzymanego.


## Art. 246. {#kpk-art-246}
§ 1. Zatrzymanemu przysługuje zażalenie do sądu. W zażaleniu 

zatrzymany może się domagać zbadania zasadności, legalności oraz prawidłowości 

jego zatrzymania. 

§ 2. Zażalenie przekazuje się niezwłocznie sądowi rejonowemu miejsca 

zatrzymania 

lub prowadzenia postępowania, który również niezwłocznie 

je 

rozpoznaje. 

§ 3. W razie uznania bezzasadności lub nielegalności zatrzymania sąd zarządza 

natychmiastowe zwolnienie zatrzymanego. 

§ 4. W wypadku 

stwierdzenia 

bezzasadności, 

nielegalności 

lub 

nieprawidłowości zatrzymania sąd zawiadamia o tym prokuratora i organ przełożony 

nad organem, który dokonał zatrzymania. 

§ 5. W razie zbiegu zażaleń na zatrzymanie i tymczasowe aresztowanie można 

rozpoznać je łącznie.


## Art. 247. {#kpk-art-247}
§ 1. Prokurator może 

zarządzić 

zatrzymanie 

i przymusowe 

doprowadzenie osoby podejrzanej albo podejrzanego, jeżeli zachodzi uzasadniona 

obawa, że: 

1) 

nie stawią się na wezwanie w celu przeprowadzenia z ich udziałem czynności, 

o których mowa w art. 313 § 1 lub art. 314, albo badań lub czynności, o których 

mowa w art. 74 § 2 lub 3; 

2) mogą w inny bezprawny sposób utrudniać postępowanie. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 104/356 

§ 2. Zatrzymanie i przymusowe doprowadzenie, o którym mowa w § 1, może 

także nastąpić, gdy zachodzi potrzeba niezwłocznego zastosowania środka 

zapobiegawczego. 

§ 3. W związku z zatrzymaniem można też zarządzić przeszukanie. Przepisy 

art. 220–222 i art. 224 stosuje się odpowiednio. 

§ 4. Niezwłocznie 

po 

doprowadzeniu 

przeprowadza 

się 

z udziałem 

zatrzymanego czynności wskazane w § 1, a po ich dokonaniu należy zwolnić go, o ile 

nie zachodzi potrzeba stosowania środka zapobiegawczego. 

§ 5. Rozstrzygając w przedmiocie 

środka 

zapobiegawczego, prokurator 

niezwłocznie zwalnia zatrzymanego albo występuje do sądu z wnioskiem 

o zastosowanie tymczasowego aresztowania. 

§ 6. Do zatrzymania, o którym mowa w § 1, stosuje się odpowiednio art. 246. 

§ 7. Zarządzenia, o których mowa w § 1, wykonuje Policja lub inne organy, o 

których mowa w art. 312, w zakresie swych właściwości, jeżeli ustawa uprawnia je do 

zatrzymywania osoby. Zarządzenia dotyczące zatrzymania 

i przymusowego 

doprowadzenia żołnierza w czynnej służbie wojskowej, z wyjątkiem terytorialnej 

służby wojskowej pełnionej dyspozycyjnie, w sprawach niezwiązanych z 

wykonywaniem obowiązków służbowych, wykonują właściwe organy wojskowe.


## Art. 248. {#kpk-art-248}
§ 1. Zatrzymanego należy natychmiast zwolnić, gdy ustanie przyczyna 

zatrzymania, a także jeżeli w ciągu 48 godzin od chwili zatrzymania przez uprawniony 

organ nie zostanie on przekazany do dyspozycji sądu wraz z wnioskiem 

o zastosowanie tymczasowego aresztowania; należy go także zwolnić na polecenie 

sądu lub prokuratora. 

§ 2. Zatrzymanego należy zwolnić, jeżeli w ciągu 24 godzin od przekazania go 

do dyspozycji sądu nie doręczono mu postanowienia o zastosowaniu wobec niego 

tymczasowego aresztowania albo nie ogłoszono mu tego postanowienia na 

posiedzeniu przeprowadzonym w sposób określony w art. 250 § 3b. Przepis 

art. 136 § 1 stosuje się odpowiednio, w tym również w przypadku, gdy odbiór tego 

postanowienia przez zatrzymanego nie jest możliwy. 

§ 3. Ponowne zatrzymanie osoby podejrzanej na podstawie tych samych faktów 

i dowodów jest niedopuszczalne. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 105/356 


# Rozdział 28
 

Środki zapobiegawcze


## Art. 249. {#kpk-art-249}
§ 1. Środki zapobiegawcze można stosować w celu zabezpieczenia 

prawidłowego 

toku postępowania, a wyjątkowo 

także w celu zapobiegnięcia 

popełnieniu przez oskarżonego nowego, ciężkiego przestępstwa; można je stosować 

tylko wtedy, gdy zebrane dowody wskazują na duże prawdopodobieństwo, że 

oskarżony popełnił przestępstwo. 

§ 2. W postępowaniu przygotowawczym można stosować środki zapobiegawcze 

tylko względem osoby, wobec której wydano postanowienie o przedstawieniu 

zarzutów. 

§ 3. Przed zastosowaniem środka zapobiegawczego sąd albo prokurator 

stosujący środek przesłuchuje oskarżonego, chyba że jest to niemożliwe z powodu 

jego ukrywania się lub jego nieobecności w kraju. Należy dopuścić do udziału 

w przesłuchaniu ustanowionego obrońcę, jeżeli się stawi; zawiadomienie obrońcy 

o terminie przesłuchania nie jest obowiązkowe, chyba że oskarżony o to wnosi, a nie 

utrudni to przeprowadzenia czynności. O terminie przesłuchania sąd zawiadamia 

prokuratora. 

§ 3a. Jeżeli przesłuchanie podejrzanego przez sąd albo prokuratora nie jest 

możliwe ze względu na okoliczności wskazane w art. 313 § 1a, określonego 

w § 3 wymogu przesłuchania oskarżonego nie stosuje się. Do udziału w postępowaniu 

w przedmiocie tymczasowego aresztowania wyznacza się obrońcę z urzędu, chyba że 

podejrzany ma obrońcę. Niestawiennictwo obrońcy należycie zawiadomionego 

o terminie nie tamuje rozpoznania sprawy. 

§ 4. Środki zapobiegawcze mogą być stosowane aż do chwili rozpoczęcia 

wykonania kary. Przepis niniejszy stosuje się do tymczasowego aresztowania tylko 

w razie orzeczenia kary pozbawienia wolności. 

§ 5. Prokurator i obrońca mają prawo wziąć udział w posiedzeniu sądu 

dotyczącym przedłużenia stosowania tymczasowego aresztowania oraz rozpoznania 

zażalenia na zastosowanie lub przedłużenie tego środka zapobiegawczego. Na żądanie 

oskarżonego, który nie ma obrońcy, wyznacza się do tej czynności obrońcę z urzędu. 

Zarządzenie może wydać także referendarz sądowy. Niestawiennictwo obrońcy lub 

prokuratora należycie zawiadomionych o terminie nie tamuje rozpoznania sprawy. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 106/356


## Art. 249a. {#kpk-art-249a}
§ 1. Podstawę orzeczenia o zastosowaniu 

lub przedłużeniu 

tymczasowego aresztowania mogą stanowić ustalenia poczynione na podstawie: 

1) 

2) 

dowodów jawnych dla oskarżonego i jego obrońcy; 

dowodów z zeznań świadków, o których mowa w art. 250 § 2b. 

§ 2. Sąd, uprzedzając o tym prokuratora, uwzględnia z urzędu 

także 

okoliczności, których prokurator nie ujawnił, po ich ujawnieniu na posiedzeniu, jeżeli 

są one korzystne dla oskarżonego.


## Art. 250. {#kpk-art-250}
§ 1. Tymczasowe aresztowanie może nastąpić tylko na mocy 

postanowienia sądu. 

§ 2. Tymczasowe aresztowanie stosuje w postępowaniu przygotowawczym na 

wniosek prokuratora sąd rejonowy, w którego okręgu prowadzi się postępowanie, 

a w wypadkach niecierpiących zwłoki także inny sąd rejonowy. Po wniesieniu aktu 

oskarżenia tymczasowe aresztowanie stosuje sąd, przed którym sprawa się toczy. 

§ 2a. We wniosku o zastosowanie tymczasowego aresztowania wymienia się 

dowody wskazujące na duże prawdopodobieństwo, że oskarżony popełnił 

przestępstwo, okoliczności przemawiające za istnieniem zagrożeń dla prawidłowego 

toku postępowania lub możliwości popełnienia przez oskarżonego nowego, ciężkiego 

przestępstwa oraz określonej podstawy stosowania tego środka zapobiegawczego 

i konieczności jego stosowania. 

§ 2b. Jeżeli zachodzi uzasadniona obawa niebezpieczeństwa dla życia, zdrowia 

albo wolności świadka lub osoby dla niego najbliższej, prokurator dołącza do wniosku, 

o którym mowa w § 2a, w wyodrębnionym zbiorze dokumentów, dowody z zeznań 

świadka, których nie udostępnia się oskarżonemu i jego obrońcy. 

§ 3. Prokurator, przesyłając wraz z aktami sprawy wniosek, o którym mowa 

w § 2, poucza podejrzanego o przysługujących mu w wypadku zastosowania 

tymczasowego 

aresztowania 

uprawnieniach 

oraz 

zarządza 

jednocześnie 

doprowadzenie go do sądu. 

§ 3a. Jeżeli tymczasowe aresztowanie stosowane jest w postępowaniu sądowym, 

pouczenia oskarżonego o przysługujących mu w wypadku 

zastosowania 

tymczasowego aresztowania uprawnieniach dokonuje sąd niezwłocznie po ogłoszeniu 

lub doręczeniu oskarżonemu postanowienia o zastosowaniu 

tego 

środka 

zapobiegawczego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 107/356 

§ 3b. Można odstąpić od przymusowego doprowadzenia do sądu podejrzanego, 

jeżeli zostanie zapewniony udział podejrzanego w posiedzeniu, w szczególności 

złożenie przez niego wyjaśnień, przy użyciu urządzeń technicznych, umożliwiających 

przeprowadzenie tego posiedzenia na odległość z jednoczesnym bezpośrednim 

przekazem obrazu i dźwięku. 

§ 3c. W wypadku określonym w § 3b w posiedzeniu bierze udział w miejscu 

przebywania podejrzanego referendarz sądowy lub asystent sędziego zatrudniony w 

sądzie, w którego okręgu przebywa podejrzany, lub przedstawiciel administracji 

zakładu karnego lub aresztu śledczego, jeżeli podejrzany przebywa w zakładzie 

karnym lub areszcie śledczym. 

§ 3d. Obrońca bierze udział w posiedzeniu przeprowadzonym w sposób 

określony w § 3b w miejscu przebywania oskarżonego, chyba że obrońca stawi się w 

tym celu w sądzie lub sąd zobowiąże go do udziału w posiedzeniu w budynku sądu z 

uwagi na konieczność uchylenia ryzyka nierozstrzygnięcia wniosku w przedmiocie 

zastosowania tymczasowego aresztowania przed upływem dopuszczalnego czasu 

zatrzymania oskarżonego. 

§ 3e. W wypadku, gdy obrońca bierze udział w posiedzeniu przebywając w 

innym miejscu niż oskarżony, sąd na wniosek oskarżonego lub obrońcy może 

zarządzić przerwę na czas oznaczony i zezwolić na telefoniczny kontakt obrońcy 

z oskarżonym, chyba że uwzględnienie wniosku może zakłócić prawidłowy przebieg 

posiedzenia 

lub stwarza ryzyko nierozstrzygnięcia wniosku w przedmiocie 

zastosowania tymczasowego aresztowania przed upływem dopuszczalnego czasu 

zatrzymania oskarżonego. 

§ 3f. Przepisu § 3b nie stosuje się w wypadku oskarżonego, którego dotyczą 

okoliczności wskazane w art. 79 § 1 pkt 2. 

§ 3g. Tłumacz może wziąć udział w posiedzeniu również w miejscu przebywania 

oskarżonego. 

§ 3h. Przepisy art. 517ea stosuje się odpowiednio. 

§ 4. Inne 

środki 

zapobiegawcze 

stosuje 

sąd, 

a w postępowaniu 

przygotowawczym także prokurator.


## Art. 251. {#kpk-art-251}
§ 1. W postanowieniu o zastosowaniu środka zapobiegawczego należy 

wymienić osobę, zarzucany jej czyn, jego kwalifikację prawną oraz podstawę prawną 

zastosowania tego środka. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 108/356 

§ 2. W postanowieniu o zastosowaniu 

tymczasowego aresztowania należy 

określić czas jego trwania, a ponadto oznaczyć termin, do którego aresztowanie ma 

trwać. Obowiązek każdorazowego oznaczenia terminu stosowania tymczasowego 

aresztowania trwa do uprawomocnienia się orzeczenia kończącego postępowanie. 

W przedmiocie tymczasowego aresztowania po wydaniu orzeczenia kończącego 

postępowanie orzeka sąd, który wydał to orzeczenie, a w razie przekazania sprawy do 

drugiej instancji – sąd odwoławczy. 

§ 3. Uzasadnienie postanowienia o zastosowaniu środka zapobiegawczego 

powinno zawierać przedstawienie dowodów świadczących o popełnieniu przez 

oskarżonego przestępstwa, wykazanie okoliczności wskazujących na istnienie 

zagrożeń dla prawidłowego toku postępowania lub możliwości popełnienia przez 

oskarżonego nowego, ciężkiego przestępstwa w razie niezastosowania środka 

zapobiegawczego oraz określonej podstawy 

jego zastosowania 

i potrzeby 

zastosowania danego środka. W wypadku tymczasowego aresztowania należy 

ponadto wyjaśnić, dlaczego nie uznano za wystarczające zastosowanie innego środka 

zapobiegawczego. 

§ 4. Postanowienie o zastosowaniu tymczasowego aresztowania doręcza się 

oskarżonemu. Postanowienie o zastosowaniu innego środka zapobiegawczego doręcza 

się oskarżonemu, jeżeli nie był obecny przy ogłoszeniu tego postanowienia.


## Art. 252. {#kpk-art-252}
§ 1. Na postanowienie w przedmiocie środka zapobiegawczego 

przysługuje zażalenie na zasadach ogólnych, chyba że ustawa stanowi inaczej. 

§ 2. Na postanowienie prokuratora w przedmiocie środka zapobiegawczego 

zażalenie przysługuje do sądu rejonowego, w którego okręgu prowadzi się 

postępowanie. 

§ 3. Zażalenie na postanowienie w przedmiocie środka zapobiegawczego sąd 

rozpoznaje niezwłocznie, z tym że zażalenie na postanowienie w przedmiocie 

tymczasowego aresztowania nie później niż przed upływem 7 dni od przekazania 

sądowi zażalenia wraz z niezbędnymi aktami.


## Art. 253. {#kpk-art-253}
§ 1. Środek zapobiegawczy należy niezwłocznie uchylić lub zmienić, 

jeżeli ustaną przyczyny, wskutek których został on zastosowany, lub powstaną 

przyczyny uzasadniające jego uchylenie albo zmianę. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 109/356 

§ 2. Zastosowany przez sąd środek zapobiegawczy może być w postępowaniu 

przygotowawczym uchylony 

lub zmieniony na 

łagodniejszy również przez 

prokuratora. 

§ 3. Sąd lub prokurator niezwłocznie zawiadamia pokrzywdzonego, jego 

przedstawiciela ustawowego lub osobę, pod której stałą pieczą pokrzywdzony 

pozostaje, o uchyleniu, nieprzedłużeniu lub zmianie tymczasowego aresztowania na 

inny środek zapobiegawczy, jak również o ucieczce oskarżonego z aresztu śledczego, 

chyba że pokrzywdzony oświadczy, iż z takiego uprawnienia rezygnuje. 

§ 4. W uzasadnionych przypadkach zawiadomienie, o którym mowa w § 3, 

przekazuje się również świadkowi.


## Art. 254. {#kpk-art-254}
§ 1. Oskarżony może składać w każdym czasie wniosek o uchylenie 

lub zmianę środka zapobiegawczego; w przedmiocie wniosku rozstrzyga, najpóźniej 

w ciągu 3 dni, prokurator, a po wniesieniu aktu oskarżenia do sądu – sąd, przed którym 

sprawa się toczy. 

§ 2. Na postanowienie w przedmiocie wniosku oskarżonemu zażalenie 

przysługuje tylko wtedy, gdy wniosek został złożony po upływie co najmniej 

3 miesięcy od dnia wydania postanowienia w przedmiocie środka zapobiegawczego. 

§ 3. Zażalenie na postanowienie sądu rozpoznaje ten sam sąd w składzie trzech 

sędziów.


## Art. 255. {#kpk-art-255}
Zawieszenie postępowania nie stoi na przeszkodzie orzekaniu co do 

środków zapobiegawczych.


## Art. 256. {#kpk-art-256}
Nadzór nad prawidłowością zatrzymania 

i wykonania środków 

zapobiegawczych sprawuje sąd, a w postępowaniu przygotowawczym – także 

prokurator.


## Art. 257. {#kpk-art-257}
§ 1. Tymczasowego aresztowania nie stosuje się, jeżeli wystarczający 

jest inny środek zapobiegawczy. 

§ 2. Stosując tymczasowe aresztowanie, sąd może zastrzec, że środek ten ulegnie 

zmianie pod warunkiem złożenia, nie później niż w wyznaczonym terminie, 

określonego poręczenia majątkowego; na uzasadniony wniosek oskarżonego lub jego 

obrońcy, złożony najpóźniej w ostatnim dniu wyznaczonego terminu, sąd może 

przedłużyć termin złożenia poręczenia. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 110/356 

§ 3. Jeżeli prokurator oświadczy, najpóźniej na posiedzeniu po ogłoszeniu 

postanowienia wydanego na podstawie § 2, że sprzeciwia się zmianie środka 

zapobiegawczego, postanowienie to, w zakresie dotyczącym zmiany tymczasowego 

aresztowania na poręczenie majątkowe, 

staje 

się wykonalne 

z dniem 

uprawomocnienia.


## Art. 258. {#kpk-art-258}
§ 1. Tymczasowe aresztowanie i pozostałe środki zapobiegawcze 

można stosować, jeżeli zachodzi: 

1) 

uzasadniona obawa ucieczki lub ukrycia się oskarżonego, zwłaszcza wtedy, gdy 

nie można ustalić jego tożsamości albo nie ma on w kraju stałego miejsca pobytu; 

2) 

uzasadniona obawa, że oskarżony będzie nakłaniał do składania fałszywych 

zeznań lub wyjaśnień albo w inny bezprawny sposób utrudniał postępowanie 

karne. 

§ 2. Jeżeli oskarżonemu zarzuca się popełnienie zbrodni 

lub występku 

zagrożonego karą pozbawienia wolności, której górna granica wynosi co najmniej 

8 lat, albo gdy sąd pierwszej instancji skazał go na karę pozbawienia wolności nie 

niższą niż 3 lata, potrzeba zastosowania tymczasowego aresztowania w celu 

zabezpieczenia prawidłowego toku postępowania może być uzasadniona grożącą 

oskarżonemu surową karą. 

§ 3. Środek zapobiegawczy można wyjątkowo zastosować także wtedy, gdy 

zachodzi uzasadniona obawa, że oskarżony, któremu zarzucono popełnienie zbrodni 

lub umyślnego występku, popełni przestępstwo przeciwko życiu, zdrowiu lub 

bezpieczeństwu powszechnemu, zwłaszcza gdy popełnieniem takiego przestępstwa 

groził. 

§ 4. Decydując 

o zastosowaniu 

określonego 

środka 

zapobiegawczego, 

uwzględnia się rodzaj i charakter obaw wskazanych w § 1–3, przyjętych za podstawę 

stosowania danego środka oraz nasilenie ich zagrożenia dla prawidłowego przebiegu 

postępowania w określonym jego stadium.


## Art. 258a. {#kpk-art-258a}
Jeżeli oskarżony uniemożliwia 

lub utrudnia wykonywanie 

zastosowanego wobec niego środka zapobiegawczego lub umyślnie naruszył 

obowiązek lub zakaz związany ze stosowaniem takiego środka, sąd lub prokurator 

stosuje środek zapobiegawczy gwarantujący skuteczną realizację celów jego 

stosowania. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 111/356


## Art. 259. {#kpk-art-259}
§ 1. Jeżeli szczególne względy nie stoją temu na przeszkodzie, należy 

odstąpić od tymczasowego aresztowania, zwłaszcza gdy pozbawienie oskarżonego 

wolności: 

1) 

2) 

spowodowałoby dla jego życia lub zdrowia poważne niebezpieczeństwo; 

pociągałoby wyjątkowo ciężkie skutki dla oskarżonego lub jego najbliższej 

rodziny. 

§ 2. Tymczasowego aresztowania nie stosuje się, gdy na podstawie okoliczności 

sprawy można przewidywać, że sąd orzeknie w stosunku do oskarżonego karę 

pozbawienia wolności z warunkowym zawieszeniem jej wykonania lub karę 

łagodniejszą albo że okres tymczasowego aresztowania przekroczy przewidywany 

wymiar kary pozbawienia wolności bez warunkowego zawieszenia. 

§ 3. Tymczasowe aresztowanie nie może być stosowane, jeżeli przestępstwo 

zagrożone jest karą pozbawienia wolności nieprzekraczającą roku. 

§ 4. Ograniczenia przewidziane w § 2 i 3 nie mają zastosowania, gdy oskarżony 

ukrywa się, uporczywie nie stawia się na wezwania lub w inny bezprawny sposób 

utrudnia postępowanie albo nie można ustalić jego tożsamości. Ograniczenie 

przewidziane w § 2 nie ma 

również zastosowania, gdy zachodzi wysokie 

prawdopodobieństwo orzeczenia środka zabezpieczającego polegającego na 

umieszczeniu sprawcy w zakładzie zamkniętym.


## Art. 260. {#kpk-art-260}
§ 1. Jeżeli stan zdrowia oskarżonego tego wymaga, tymczasowe 

aresztowanie może być wykonywane tylko w postaci umieszczenia w odpowiednim 

zakładzie leczniczym, w tym w zakładzie psychiatrycznym. 

§ 2. Minister Sprawiedliwości w porozumieniu z ministrem właściwym do 

spraw zdrowia określi, w drodze rozporządzenia, wykaz zakładów leczniczych, w tym 

psychiatrycznych, przeznaczonych do wykonywania tymczasowego aresztowania 

stosowanego wobec osób, których stan zdrowia wymaga umieszczenia w takim 

zakładzie, oraz warunki zabezpieczenia tych zakładów uniemożliwiające samowolne 

wydalenie się z nich tymczasowo aresztowanych oraz umożliwiające izolowanie ich 

ze względów bezpieczeństwa, przy zapewnieniu dostępu do 

tymczasowo 

aresztowanych przez organy prowadzące postępowanie karne, mając na uwadze 

potrzebę zapewnienia prawidłowego toku postępowania, oraz tryb umieszczenia, 

warunki pobytu i leczenia tymczasowo aresztowanych w takim zakładzie, mając na 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 112/356 

uwadze niezbędne wyposażenie medyczne oraz warunki techniczne i organizacyjne 

tych zakładów.


## Art. 261. {#kpk-art-261}
§ 1. O zastosowaniu tymczasowego aresztowania sąd jest obowiązany 

bezzwłocznie zawiadomić osobę najbliższą dla oskarżonego; może to być osoba 

wskazana przez oskarżonego. 

§ 2. Na wniosek oskarżonego można również zawiadomić inną osobę zamiast lub 

obok osoby wskazanej w § 1. 

§ 2a. O zastosowaniu 

tymczasowego aresztowania sąd zawiadamia organ 

prowadzący przeciwko oskarżonemu postępowanie w innej sprawie, o ile powziął 

informację o tym postępowaniu. Sąd poucza oskarżonego o treści art. 75 § 1. 

§ 3. O zastosowaniu 

tymczasowego aresztowania 

sąd 

jest obowiązany 

niezwłocznie zawiadomić pracodawcę, szkołę lub uczelnię, w stosunku do żołnierza – 

jego dowódcę, a w przypadku, gdy oskarżonym jest przedsiębiorca lub niebędący 

pracownikiem członek organu zarządzającego przedsiębiorcy, na jego wniosek – 

zarządzającego przedsiębiorstwem.


## Art. 262. {#kpk-art-262}
§ 1. Sąd stosujący tymczasowe aresztowanie ma obowiązek: 

1) 

zawiadomienia o tym sądu opiekuńczego, jeżeli zachodzi potrzeba zapewnienia 

opieki nad dziećmi aresztowanego; 

2) 

zawiadomienia organu opieki społecznej, jeżeli zachodzi potrzeba roztoczenia 

opieki nad osobą niedołężną lub chorą, którą aresztowany się opiekował; 

3) 

przedsięwzięcia czynności niezbędnych do ochrony mienia i mieszkania 

aresztowanego. 

§ 2. O poczynionych wystąpieniach 

i wydanych 

zarządzeniach 

należy 

powiadomić tymczasowo aresztowanego.


## Art. 263. {#kpk-art-263}
§ 1. W postępowaniu przygotowawczym sąd, stosując tymczasowe 

aresztowanie, oznacza jego termin na okres nie dłuższy niż 3 miesiące. 

§ 2. Jeżeli ze względu na szczególne okoliczności sprawy nie można było 

ukończyć postępowania przygotowawczego w terminie określonym w § 1, na wniosek 

prokuratora, sąd pierwszej instancji właściwy do rozpoznania sprawy, gdy zachodzi 

tego potrzeba, może przedłużyć tymczasowe aresztowanie na okres, który łącznie nie 

może przekroczyć 12 miesięcy. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 113/356 

§ 3. Łączny okres stosowania tymczasowego aresztowania do chwili wydania 

pierwszego wyroku przez sąd pierwszej instancji nie może przekroczyć 2 lat. 

§ 3a. W przypadku zbiegu tymczasowego aresztowania z wykonywaną karą 

pozbawienia wolności orzeczoną w innej sprawie do okresów, o których mowa w § 2 

i 3, zalicza się okres odbywania przez tymczasowo aresztowanego kary pozbawienia 

wolności. 

§ 4. Przedłużenia stosowania tymczasowego aresztowania na okres oznaczony, 

przekraczający terminy określone w § 2 i 3 może dokonać sąd apelacyjny, w którego 

okręgu prowadzi się postępowanie na wniosek sądu, przed którym sprawa się toczy, 

a w postępowaniu przygotowawczym na wniosek właściwego prokuratora 

bezpośrednio przełożonego wobec prokuratora prowadzącego lub nadzorującego 

śledztwo – jeżeli konieczność taka powstaje w związku z zawieszeniem postępowania 

karnego, czynnościami zmierzającymi do ustalenia lub potwierdzenia tożsamości 

oskarżonego, wykonywaniem czynności dowodowych w sprawie o szczególnej 

zawiłości lub poza granicami kraju, a także celowym przewlekaniem postępowania 

przez oskarżonego. 

§ 4a. (uchylony) 

§ 4b. Przedłużenia stosowania tymczasowego aresztowania, o którym mowa 

w § 4, nie stosuje się w odniesieniu do terminu określonego w § 2, gdy kara realnie 

grożąca oskarżonemu za zarzucane mu przestępstwo nie przekroczy 3 lat pozbawienia 

wolności, a w stosunku do terminu wskazanego w § 3, gdy nie przekroczy ona 5 lat 

pozbawienia wolności, chyba że konieczność takiego przedłużenia jest spowodowana 

celowym przewlekaniem postępowania przez oskarżonego. 

§ 5. Na postanowienie sądu apelacyjnego wydane na podstawie § 4 przysługuje 

zażalenie do sądu apelacyjnego orzekającego w składzie trzech sędziów. 

§ 6. Z wnioskiem o przedłużenie okresu tymczasowego aresztowania należy 

wystąpić, z jednoczesnym przesłaniem właściwemu sądowi akt sprawy, nie później 

niż 14 dni przed upływem dotychczas określonego terminu stosowania tego środka. 

§ 7. Jeżeli zachodzi potrzeba stosowania 

tymczasowego aresztowania po 

wydaniu pierwszego wyroku przez sąd pierwszej instancji, każdorazowe jego 

przedłużenie może następować na okres nie dłuższy niż 6 miesięcy. 

§ 8. Minister Sprawiedliwości określi, w drodze rozporządzenia, wzór pouczenia 

o przysługujących 

oskarżonemu w wypadku 

zastosowania 

tymczasowego 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 114/356 

aresztowania uprawnieniach: do składania wyjaśnień, do odmowy składania wyjaś-

nień lub odmowy odpowiedzi na pytania, do informacji o treści stawianych zarzutów, 

do przeglądania akt w części zawierającej treść dowodów wskazanych we wniosku 

o tymczasowe aresztowanie, do dostępu do pierwszej pomocy medycznej, jak również 

uprawnieniach wskazanych w art. 72 § 1, art. 78 § 1, art. 78a § 1, art. 249 § 5, art. 252, 

art. 254 § 1 i 2, art. 261 § 1, 2 i 2a oraz art. 612 § 1, mając na względzie konieczność 

zrozumienia pouczenia także przez osoby niekorzystające z pomocy obrońcy.


## Art. 264. {#kpk-art-264}
§ 1. W razie uniewinnienia oskarżonego, umorzenia lub warunkowego 

umorzenia postępowania, warunkowego zawieszenia wykonania kary, wymierzenia 

kary pozbawienia wolności odpowiadającej co najwyżej okresowi tymczasowego 

aresztowania, skazania na karę łagodniejszą niż pozbawienie wolności albo w razie 

odstąpienia od wymierzenia kary, zarządza się niezwłoczne zwolnienie tymczasowo 

aresztowanego, jeżeli nie jest on pozbawiony wolności w innej sprawie. 

§ 2. W razie skazania oskarżonego tymczasowo aresztowanego na karę inną niż 

wymieniona w § 1 albo w razie umorzenia postępowania z powodu niepoczytalności 

sprawcy i orzeczenia środka zabezpieczającego polegającego na umieszczeniu go 

w zakładzie zamkniętym, sąd, po wysłuchaniu obecnych stron, wydaje postanowienie 

co do dalszego stosowania tymczasowego aresztowania. 

§ 2a. W razie umorzenia postępowania z powodu niepoczytalności sprawcy 

i orzeczenia środka zabezpieczającego polegającego na umieszczeniu go w zakładzie 

zamkniętym można zastosować tymczasowe aresztowanie. 

§ 3. W wypadku prawomocnego orzeczenia 

środka 

zabezpieczającego 

polegającego na umieszczeniu sprawcy w zakładzie zamkniętym można zastosować 

tymczasowe aresztowanie do czasu rozpoczęcia wykonywania środka, jednak nie 

dłużej niż na okres 3 miesięcy, z możliwością 

jednorazowego przedłużenia 

w szczególnie uzasadnionym wypadku na kolejny miesiąc. 

§ 3a. Tymczasowe aresztowanie stosowane do czasu rozpoczęcia wykonywania 

środka zabezpieczającego polegającego na umieszczeniu sprawcy w zakładzie 

zamkniętym wykonuje się 

tylko w postaci umieszczenia 

takiego sprawcy 

w odpowiednim zakładzie leczniczym, w tym w zakładzie psychiatrycznym, 

wymienionym w wykazie określonym w przepisach wydanych na podstawie art. 260 

§ 2. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 115/356 

§ 4. Tymczasowe aresztowanie w wypadku orzeczenia wobec skazanego kary 

pozbawienia wolności oraz środka zabezpieczającego polegającego na umieszczeniu 

sprawcy w zakładzie zamkniętym stosowane do czasu rozpoczęcia wykonywania kary 

pozbawienia wolności wykonuje się w warunkach umożliwiających stosowanie 

odpowiedniego postępowania leczniczego, terapeutycznego, rehabilitacyjnego oraz 

resocjalizacyjnego.


## Art. 265. {#kpk-art-265}
Okres tymczasowego aresztowania liczy się od dnia zatrzymania.


## Art. 266. {#kpk-art-266}
§ 1. Poręczenie majątkowe w postaci pieniędzy, papierów 

wartościowych, zastawu lub hipoteki może złożyć oskarżony albo inna osoba. 

§ 1a. Przedmiot poręczenia majątkowego nie może pochodzić z przysporzenia na 

rzecz oskarżonego albo innej osoby składającej poręczenie dokonanego na ten cel. Sąd 

albo prokurator może uzależnić przyjęcie przedmiotu poręczenia majątkowego od 

wykazania przez osobę składającą poręczenie źródła pochodzenia tego przedmiotu. W 

postępowaniu przygotowawczym przyjęcia przedmiotu poręczenia majątkowego 

dokonuje prokurator. Oświadczenie w przedmiocie źródła pochodzenia przedmiotu 

poręczenia majątkowego osoba składająca poręczenie składa pod rygorem 

odpowiedzialności karnej, o czym należy ją uprzedzić. 

§ 2. Wysokość, rodzaj i warunki poręczenia majątkowego, a w szczególności 

termin złożenia przedmiotu poręczenia, należy określić w postanowieniu, mając na 

względzie sytuację materialną oskarżonego i składającego poręczenie majątkowe, 

wysokość wyrządzonej szkody oraz charakter popełnionego czynu. 

§ 3. Na postanowienie prokuratora o odmowie przyjęcia przedmiotu 

zastosowanego przez 

sąd poręczenia majątkowego zażalenie przysługuje 

podejrzanemu i osobie składającej poręczenie. Zażalenie rozpoznaje sąd wyższego 

rzędu nad sądem, który zastosował poręczenie majątkowe. Jeżeli poręczenie 

majątkowe zastosował sąd apelacyjny, zażalenie rozpoznaje ten sąd w składzie trzech 

sędziów.


## Art. 267. {#kpk-art-267}
Osobę 

składającą 

poręczenie majątkowe 

zawiadamia 

się 

o każdorazowym wezwaniu oskarżonego do stawiennictwa; do osoby składającej 

poręczenie majątkowe za oskarżonego stosuje się odpowiednio art. 138 i 139 § 1.


## Art. 268. {#kpk-art-268}
§ 1. Stanowiące przedmiot poręczenia wartości majątkowe lub 

zobowiązania ulegają przepadkowi albo ściągnięciu w razie ucieczki lub ukrycia się 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 116/356 

oskarżonego. W wypadku utrudniania w inny sposób postępowania karnego można 

orzec przepadek lub ściągnięcie tych wartości. 

§ 1a. Orzekając w przedmiocie przepadku lub ściągnięcia wartości majątkowych 

stanowiących przedmiot poręczenia, sąd może orzec częściowy przepadek lub 

ściągnięcie tych wartości, stosując wówczas wobec oskarżonego ponadto inny jeszcze 

środek zapobiegawczy, z uwzględnieniem wymogów art. 258 § 4, z wyjątkiem 

tymczasowego aresztowania. 

§ 2. O treści § 1 oraz art. 269 należy uprzedzić osobę składającą poręczenie 

majątkowe.


## Art. 269. {#kpk-art-269}
§ 1. Ulegające przepadkowi przedmioty poręczenia lub ściągnięte 

sumy poręczenia majątkowego przekazuje się lub przelewa na rzecz Skarbu Państwa; 

pokrzywdzony ma wówczas pierwszeństwo zaspokojenia na nich swoich roszczeń 

wynikających z przestępstwa, jeżeli w inny sposób nie można uzyskać naprawienia 

szkody. 

§ 2. Z chwilą ustania poręczenia majątkowego przedmiot poręczenia zwraca się, 

a sumę poręczenia zwalnia się, pod tym jednak warunkiem, że w razie prawomocnego 

skazania oskarżonego na karę pozbawienia wolności następuje to z chwilą rozpoczęcia 

odbywania przez niego kary. W razie niezgłoszenia się na wezwanie do odbycia kary 

stosuje się art. 268 § 1. 

§ 3. Cofnięcie poręczenia majątkowego staje się skuteczne dopiero z chwilą 

przyjęcia nowego poręczenia majątkowego, zastosowania 

innego 

środka 

zapobiegawczego lub odstąpienia od stosowania tego środka. 

§ 4. Przepisy § 2 i 3 nie dotyczą cofnięcia poręczenia majątkowego i zwrotu 

przedmiotów, jeżeli już zapadło postanowienie o jego przepadku lub o ściągnięciu 

sumy poręczenia.


## Art. 270. {#kpk-art-270}
§ 1. O przepadku przedmiotu poręczenia lub ściągnięciu sumy 

poręczenia orzeka z urzędu sąd, przed którym postępowanie się 

toczy, 

a w postępowaniu przygotowawczym na wniosek prokuratora – sąd właściwy do 

rozpoznania sprawy. 

§ 2. Oskarżony, poręczający 

i prokurator mają prawo wziąć udział 

w posiedzeniu sądowym 

lub złożyć wyjaśnienia na piśmie. Oskarżonego 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 117/356 

pozbawionego wolności sprowadza się na posiedzenie, jeżeli prezes sądu lub sąd uzna 

to za potrzebne. 

§ 3. Na postanowienie określone w § 1 przysługuje zażalenie.


## Art. 271. {#kpk-art-271}
§ 1. Od pracodawcy, u którego oskarżony jest zatrudniony, od 

kierownictwa szkoły lub uczelni, których oskarżony jest uczniem lub studentem, od 

zespołu, w którym oskarżony pracuje lub uczy się, albo od organizacji społecznej, 

której oskarżony jest członkiem, można, na ich wniosek, przyjąć poręczenie, że 

oskarżony stawi się na każde wezwanie i nie będzie w sposób bezprawny utrudniał 

postępowania; jeżeli oskarżony jest żołnierzem, można przyjąć poręczenie od zespołu 

żołnierskiego, zgłoszone za pośrednictwem właściwego dowódcy. 

§ 2. Do wniosku o przyjęcie poręczenia zespół lub organizacja społeczna dołącza 

wyciąg z protokołu zawierającego uchwałę o podjęciu się poręczenia. 

§ 3. We wniosku o przyjęcie poręczenia należy wskazać osobę, która ma 

wykonywać obowiązki poręczającego; osoba ta składa oświadczenie o przyjęciu tych 

obowiązków.


## Art. 272. {#kpk-art-272}
Poręczenie, że oskarżony stawi się na każde wezwanie i nie będzie 

w sposób bezprawny utrudniał postępowania, można także przyjąć od osoby godnej 

zaufania. Przepis art. 275 § 2 stosuje się odpowiednio.


## Art. 273. {#kpk-art-273}
§ 1. Przy odbieraniu poręczenia zawiadamia się udzielającego 

poręczenia lub wykonującego obowiązki poręczającego o treści zarzutu stawianego 

oskarżonemu oraz o obowiązkach wynikających z poręczenia 

i skutkach 

ich 

niedotrzymania. 

§ 2. Poręczający jest obowiązany niezwłocznie powiadomić sąd lub prokuratora 

o wiadomych mu poczynaniach oskarżonego, zmierzających do uchylenia się od 

obowiązku stawienia się na wezwanie lub do utrudniania w inny bezprawny sposób 

postępowania.


## Art. 274. {#kpk-art-274}
Jeżeli mimo poręczenia oskarżony nie stawi się na wezwanie lub 

w inny bezprawny sposób będzie utrudniał postępowanie, organ stosujący środek 

zapobiegawczy zawiadomi o tym udzielającego poręczenia, a ponadto może 

zawiadomić bezpośredniego przełożonego osoby, która złożyła poręczenie, 

i organizację społeczną, do której należy, a także statutowy organ nadrzędny nad 

poręczającą organizacją społeczną, 

jeżeli zostanie stwierdzone zaniedbanie 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 118/356 

obowiązków wynikających z poręczenia. Przed zawiadomieniem należy osobę, która 

złożyła poręczenie, wezwać w celu złożenia wyjaśnień.


## Art. 275. {#kpk-art-275}
§ 1. Tytułem środka zapobiegawczego można oddać oskarżonego pod 

dozór Policji, a oskarżonego żołnierza, z wyjątkiem żołnierza pełniącego terytorialną 

służbę wojskową dyspozycyjnie – pod dozór przełożonego wojskowego. 

§ 2. Oddany pod dozór ma obowiązek stosowania się do wymagań zawartych 

w postanowieniu sądu lub prokuratora. Obowiązek ten może polegać na zakazie 

opuszczania określonego miejsca pobytu, zgłaszaniu się do organu dozorującego 

w określonych odstępach czasu, zawiadamianiu go o zamierzonym wyjeździe oraz 

o terminie powrotu, zakazie kontaktowania się z pokrzywdzonym lub z innymi 

osobami, zakazie zbliżania się do określonych osób na wskazaną odległość, zakazie 

przebywania w określonych miejscach, a także na innych ograniczeniach swobody 

oskarżonego, niezbędnych do wykonywania dozoru. 

§ 3. Jeżeli zachodzą przesłanki zastosowania tymczasowego aresztowania wobec 

oskarżonego o przestępstwo popełnione z użyciem przemocy lub groźby bezprawnej 

na szkodę osoby najbliższej albo innej osoby zamieszkującej wspólnie ze sprawcą, 

zamiast tymczasowego aresztowania można zastosować dozór, pod warunkiem że 

oskarżony w wyznaczonym 

terminie opuści 

lokal 

zajmowany wspólnie 

z pokrzywdzonym oraz określi miejsce swojego pobytu. 

§ 4. Oddany pod dozór Policji ma obowiązek stawiania się we wskazanej 

jednostce organizacyjnej Policji z dokumentem stwierdzającym 

tożsamość, 

wykonywania poleceń mających na celu dokumentowanie przebiegu dozoru oraz 

udzielania informacji koniecznych dla ustalenia, czy stosuje się on do wymagań 

nałożonych w postanowieniu sądu lub prokuratora. W celu uzyskania takich 

informacji można wzywać oskarżonego do stawiennictwa w wyznaczonym terminie. 

§ 5. W wypadku niestosowania się przez oddanego pod dozór do wymagań 

określonych w postanowieniu organ dozorujący niezwłocznie zawiadamia o tym sąd 

lub prokuratora, który wydał postanowienie.


## Art. 275a. {#kpk-art-275a}
§ 1. Tytułem środka zapobiegawczego można nakazać oskarżonemu 

o przestępstwo popełnione z użyciem przemocy na szkodę osoby wspólnie 

zamieszkującej 

okresowe 

opuszczenie 

lokalu 

zajmowanego wspólnie 

z pokrzywdzonym i jego najbliższego otoczenia lub zakazać mu zbliżania się do 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 119/356 

pokrzywdzonego na wskazaną odległość, jeżeli zachodzi uzasadniona obawa, że 

oskarżony ponownie popełni przestępstwo z użyciem przemocy wobec tej osoby, 

zwłaszcza gdy popełnieniem takiego przestępstwa groził. 

§ 2. W postępowaniu przygotowawczym środek przewidziany w § 1 stosuje się 

na wniosek Policji albo z urzędu. 

§ 3. Jeżeli wobec oskarżonego, zatrzymanego na podstawie art. 244 § 1a lub 1b, 

zachodzą podstawy do zastosowania środka zapobiegawczego przewidzianego w § 1, 

Policja niezwłocznie, nie później niż przed upływem 24 godzin od chwili zatrzymania, 

występuje z wnioskiem do prokuratora o zastosowanie tego środka zapobiegawczego; 

wniosek powinien być rozpoznany przed upływem 48 godzin od chwili zatrzymania 

oskarżonego. 

§ 4. Środek przewidziany w § 1 stosuje się na okres nie dłuższy niż 3 miesiące. 

Jeżeli nie ustały przesłanki jego stosowania sąd pierwszej instancji właściwy do 

rozpoznania sprawy, na wniosek prokuratora, może przedłużyć jego stosowanie na 

dalsze okresy, nie dłuższe niż 3 miesiące. 

§ 5. Wydając postanowienie o nakazie okresowego opuszczenia przez 

oskarżonego lokalu zajmowanego wspólnie z pokrzywdzonym, można, na wniosek 

oskarżonego, wskazać mu miejsce pobytu w placówkach zapewniających miejsca 

noclegowe. Placówkami wskazanymi do umieszczenia oskarżonego nie mogą być 

placówki pobytu osób doznających przemocy domowej.


## Art. 276. {#kpk-art-276}
Tytułem środka zapobiegawczego można zawiesić oskarżonego 

w czynnościach 

służbowych 

lub w wykonywaniu 

zawodu 

albo nakazać 

powstrzymanie się od określonej działalności lub od prowadzenia określonego rodzaju 

pojazdów, lub zakazać ubiegania się o zamówienia publiczne na czas trwania 

postępowania.


## Art. 276a. {#kpk-art-276a}
§ 1. Tytułem środka zapobiegawczego można orzec wobec 

oskarżonego o przestępstwo popełnione w stosunku do członka personelu 

medycznego, w związku z wykonywaniem przez niego czynności opieki medycznej 

lub osoby przybranej personelowi medycznemu do pomocy w związku z 

wykonywaniem tych czynności, zakaz zbliżania się do pokrzywdzonego na wskazaną 

odległość, zakaz kontaktów lub zakaz publikacji, w tym za pośrednictwem systemów 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 120/356 

informatycznych lub sieci telekomunikacyjnych treści godzących w prawnie 

chronione dobra pokrzywdzonego. 

§ 1a. Środek zapobiegawczy, o którym mowa w § 1, można orzec również wobec 

oskarżonego o przestępstwo, o którym mowa w art. 190a ustawy z dnia 6 czerwca 

1997 r. – Kodeks karny, popełnione z powodu wykonywanego przez pokrzywdzonego 

zawodu. 

§ 2. Zakazy, o których mowa w § 1, mogą być połączone z określeniem 

poręczenia majątkowego. Do poręczenia majątkowego zastosowanie mają przepisy 

art. 266–270, z tym że stanowiące przedmiot poręczenia wartości majątkowe lub 

zobowiązania ulegają przepadkowi albo ściągnięciu również w razie niezastosowania 

się do zakazów o których mowa w § 1. 

§ 3. Zakaz publikacji 

treści godzących w prawnie chronione dobra 

pokrzywdzonego, o którym mowa w § 1, obejmuje zakaz publikowania i innego 

udostępniania tych treści niezależnie od tego, czy zostały wytworzone przez 

oskarżonego czy inną osobę, za pośrednictwem internetowych portali, stanowiących 

usługę świadczoną drogą elektroniczną w rozumieniu ustawy z dnia 18 lipca 2002 r. o 

świadczeniu usług drogą elektroniczną. 

§ 4. Czas stosowania zakazów o których mowa w § 1, określa się przy 

uwzględnieniu potrzeb w zakresie zabezpieczenia prawidłowego biegu postępowania 

karnego oraz zapewnienia odpowiedniej ochrony pokrzywdzonemu lub osobom dla 

niego najbliższym. 

§ 5. Przedłużenie stosowania zakazu na dalszy okres, przekraczający łącznie 6 

miesięcy, w postępowaniu przygotowawczym może dokonać, na wniosek prokuratora, 

sąd rejonowy, w okręgu którego prowadzone jest postępowanie.


## Art. 277. {#kpk-art-277}
§ 1. W razie uzasadnionej obawy ucieczki można zastosować 

w charakterze środka zapobiegawczego zakaz opuszczania przez oskarżonego kraju, 

który może być połączony z zatrzymaniem mu paszportu lub innego dokumentu 

uprawniającego do przekroczenia granicy albo z zakazem wydania 

takiego 

dokumentu. 

§ 2. Do czasu wydania postanowienia w przedmiocie, o którym mowa w § 1, 

organ prowadzący postępowanie może zatrzymać dokument, jednakże na czas nie 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 121/356 

dłuższy niż 7 dni. Do odebrania dokumentów stosuje się odpowiednio przepisy 

rozdziału 25. 


# Rozdział 29
 

Poszukiwanie oskarżonego i list gończy


## Art. 278. {#kpk-art-278}
Jeżeli miejsce pobytu oskarżonego lub osoby podejrzanej nie jest 

znane, zarządza się jego poszukiwanie. Przepis art. 247 stosuje się odpowiednio.


## Art. 279. {#kpk-art-279}
§ 1. Jeżeli oskarżony, w stosunku do którego wydano postanowienie 

o tymczasowym aresztowaniu, ukrywa się, sąd lub prokurator może wydać 

postanowienie o poszukiwaniu go listem gończym. 

§ 2. Jeżeli postanowienie o tymczasowym aresztowaniu nie było wydane, można 

postanowienie takie wydać bez względu na to, czy nastąpiło przesłuchanie 

podejrzanego. 

§ 3. W razie ujęcia i zatrzymania osoby ściganej listem gończym należy 

niezwłocznie doprowadzić ją do sądu, który wydał postanowienie o tymczasowym 

aresztowaniu, w celu rozstrzygnięcia przez sąd o utrzymaniu, zmianie lub uchyleniu 

tego środka, chyba że prokurator po przesłuchaniu zatrzymanego zmienił już środek 

zapobiegawczy lub uchylił tymczasowe aresztowanie. Przepis art. 344 zdanie drugie 

stosuje się odpowiednio. 

§ 4. W razie ujęcia i zatrzymania osoby ściganej więcej niż jednym listem 

gończym wystarczające jest doprowadzenie jej w trybie § 3 do jednego z sądów, które 

wydały postanowienia o tymczasowym aresztowaniu.


## Art. 280. {#kpk-art-280}
§ 1. W liście gończym podaje się: 

1) 

2) 

sąd lub prokuratora, który wydał postanowienie o poszukiwaniu listem gończym; 

dane o osobie, które mogą ułatwić jej poszukiwanie, a przede wszystkim 

personalia, 

rysopis, znaki 

szczególne, miejsce zamieszkania 

i pracy, 

z dołączeniem w miarę możliwości fotografii poszukiwanego; 

3) 

informację o treści zarzutu postawionego oskarżonemu oraz o postanowieniu 

o jego tymczasowym aresztowaniu albo o zapadłym wyroku; 

4) wezwanie każdego, kto zna miejsce pobytu poszukiwanego, do zawiadomienia 

o tym najbliższej jednostki Policji, prokuratora lub sądu; 

5) 

ostrzeżenie o odpowiedzialności karnej za ukrywanie poszukiwanego lub 

dopomaganie mu w ucieczce. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 122/356 

§ 2. W liście gończym można wyznaczyć nagrodę za ujęcie lub przyczynienie się 

do ujęcia poszukiwanego, a także udzielić zapewnienia o utrzymaniu tajemnicy co do 

osoby informującej. 

§ 3. List gończy podlega rozpowszechnieniu przez opublikowanie za pomocą 

Internetu, chyba że sąd lub prokurator postanowi inaczej. 

§ 4. Sąd 

lub prokurator, zależnie od potrzeby, może postanowić o 

rozpowszechnieniu 

listu gończego przez 

rozesłanie, 

rozplakatowanie 

lub 

opublikowanie, w szczególności za pomocą prasy, radia i telewizji. 


# Rozdział 30
 

List żelazny


## Art. 281. {#kpk-art-281}
§ 1. Jeżeli oskarżony przebywający za granicą złoży oświadczenie, że 

stawi się do sądu lub do prokuratora w oznaczonym terminie pod warunkiem 

odpowiadania z wolnej stopy, właściwy miejscowo sąd okręgowy może wydać 

oskarżonemu list żelazny. 

§ 2. W postępowaniu przygotowawczym list żelazny może być wydany na 

wniosek prokuratora albo przy braku jego sprzeciwu. 

§ 3. Udział prokuratora w posiedzeniu w przedmiocie wydania listu żelaznego 

jest obowiązkowy. 

§ 4. Wydając list żelazny, sąd uchyla tymczasowe aresztowanie. Postanowienie 

o uchyleniu 

tymczasowego 

aresztowania 

staje 

się wykonalne 

z dniem 

uprawomocnienia się postanowienia o wydaniu listu żelaznego.


## Art. 282. {#kpk-art-282}
§ 1. List żelazny zapewnia oskarżonemu pozostawanie na wolności aż 

do prawomocnego ukończenia postępowania, jeżeli oskarżony: 

1) 

będzie się stawiał w oznaczonym terminie na wezwanie sądu, a w postępowaniu 

przygotowawczym – także na wezwanie prokuratora; 

2) 

3) 

nie będzie się wydalał bez pozwolenia sądu z obranego miejsca pobytu w kraju; 

nie będzie nakłaniał do fałszywych zeznań lub wyjaśnień albo w inny bezprawny 

sposób starał się utrudniać postępowanie karne. 

§ 2. W razie nieusprawiedliwionego niestawienia się oskarżonego na wezwanie 

lub naruszenia innych warunków wymienionych w § 1, właściwy miejscowo sąd 

okręgowy orzeka o odwołaniu listu żelaznego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 123/356 

§ 3. W postępowaniu przygotowawczym odwołanie listu żelaznego następuje na 

wniosek prokuratora.


## Art. 283. {#kpk-art-283}
§ 1. Wydanie listu żelaznego można uzależnić od złożenia poręczenia 

majątkowego. 

§ 2. W razie odwołania 

listu żelaznego z powodu naruszenia warunków 

wymienionych w art. 282 § 1, wartości majątkowe udzielone z tytułu poręczenia 

ulegają przepadkowi lub ściągnięciu; orzeka o tym sąd wymieniony w art. 282 § 2.


## Art. 284. {#kpk-art-284}
§ 1. (uchylony) 

§ 2. Na postanowienie w przedmiocie listu żelaznego oraz na postanowienie 

wydane na podstawie art. 283 § 2 przysługuje zażalenie.


## Art. 284a. {#kpk-art-284a}
Wniosek o wydanie listu żelaznego nie wstrzymuje rozpoznania 

wniosku o zastosowanie wobec podejrzanego tymczasowego aresztowania. 


# Rozdział 31
 

Kary porządkowe


## Art. 285. {#kpk-art-285}
§ 1. Na świadka, biegłego, tłumacza lub specjalistę, który bez 

należytego usprawiedliwienia nie stawił się na wezwanie organu prowadzącego 

postępowanie albo bez zezwolenia tego organu wydalił się z miejsca czynności przed 

jej zakończeniem, można nałożyć karę pieniężną w wysokości do 3000 złotych. 

§ 1a. Przepis § 1 stosuje się odpowiednio do obrońcy lub pełnomocnika, 

w wypadkach szczególnych ze względu na ich wpływ na przebieg czynności; 

w postępowaniu przygotowawczym karę pieniężną, na wniosek prokuratora, nakłada 

sąd rejonowy, w którego okręgu prowadzi się postępowanie. 

§ 2. W wypadkach określonych w § 1 można ponadto zarządzić zatrzymanie 

i przymusowe doprowadzenie świadka. Zatrzymanie i przymusowe doprowadzenie 

biegłego, tłumacza i specjalisty stosuje się tylko wyjątkowo. W stosunku do żołnierza 

stosuje się art. 247 § 7.


## Art. 286. {#kpk-art-286}
Karę pieniężną należy uchylić, 

jeżeli ukarany dostatecznie 

usprawiedliwi swe niestawiennictwo lub samowolne oddalenie się. Usprawiedliwienie 

może nastąpić w ciągu tygodnia od daty doręczenia postanowienia wymierzającego 

karę pieniężną. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 124/356


## Art. 287. {#kpk-art-287}
§ 1. Przepis art. 285 § 1 stosuje się odpowiednio do osoby, która 

bezpodstawnie uchyla się od złożenia zeznania, wykonania czynności biegłego, 

tłumacza lub specjalisty, złożenia przyrzeczenia, wydania przedmiotu, dopełnienia 

obowiązków poręczyciela albo spełnienia innego ciążącego na niej obowiązku w toku 

postępowania, jak również do przedstawiciela lub kierownika instytucji, osoby 

prawnej lub jednostki organizacyjnej niemającej osobowości prawnej obowiązanej 

udzielić pomocy organowi prowadzącemu postępowanie karne, która bezpodstawnie 

nie udziela pomocy w wyznaczonym terminie. 

§ 2. W razie uporczywego uchylania się od złożenia zeznania, wykonania 

czynności biegłego, tłumacza lub specjalisty oraz wydania przedmiotu można 

zastosować, niezależnie od kary pieniężnej, aresztowanie na czas nieprzekraczający 

30 dni. Przepis ten stosuje się odpowiednio w razie uporczywego niestawiennictwa na 

wezwanie organu prowadzącego postępowanie, jeżeli zarządzenie zatrzymania 

i przymusowego doprowadzenia, o którym mowa w art. 285 § 2, nie 

jest 

wystarczające dla zapewnienia stawiennictwa osoby wezwanej. 

§ 3. Aresztowanie należy uchylić, jeżeli osoba aresztowana spełni obowiązek 

albo postępowanie przygotowawcze lub postępowanie w danej instancji ukończono. 

§ 4. Przepisów § 1 i 2 nie stosuje się do stron, ich obrońców i pełnomocników, 

a w zakresie kary za niedopełnienie obowiązku wydania rzeczy – także do osób, które 

mogą się uchylić od złożenia zeznań. 

§ 5. Przepisów § 1 i 2 nie stosuje się do sędziów i prokuratorów w zakresie 

odnoszącym się do ich obowiązków służbowych.


## Art. 288. {#kpk-art-288}
§ 1. W razie uchybienia przez żołnierza w czynnej służbie, z wyjątkiem 

terytorialnej służby wojskowej pełnionej dyspozycyjnie, obowiązkom określonym w 

art. 285 § 1 i art. 287 sąd lub prokurator występuje do dowódcy jednostki wojskowej, 

w której ten żołnierz pełni służbę, o pociągnięcie go do odpowiedzialności 

dyscyplinarnej. 

§ 2. Przepis § 1 stosuje się choćby za uchybienie, którego dopuścił się żołnierz 

przed wstąpieniem do wojska, była mu poprzednio wymierzona kara porządkowa, lecz 

nie została do tego czasu wykonana.


## Art. 289. {#kpk-art-289}
§ 1. Osobę, w tym obrońcę, pełnomocnika 

lub oskarżyciela 

publicznego, która przez niewykonanie obowiązków wymienionych w art. 285 § 1 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 125/356 

i 1a lub art. 287 § 1 spowodowała dodatkowe koszty postępowania, można obciążyć 

tymi kosztami; dopuszczalne jest obciążenie kosztami kilku osób solidarnie. Żołnierza 

odbywającego zasadniczą służbę wojskową nie obciąża się tymi kosztami. 

§ 2. W razie uchylenia kary porządkowej ustaje również obowiązek pokrycia 

kosztów postępowania.


## Art. 290. {#kpk-art-290}
§ 1. Postanowienia przewidziane w niniejszym rozdziale wydaje sąd, 

a w postępowaniu przygotowawczym także prokurator. Aresztowanie, o którym 

mowa w art. 287 § 2, w postępowaniu przygotowawczym stosuje na wniosek 

prokuratora sąd rejonowy, w którego okręgu prowadzi się postępowanie. 

§ 2. Na postanowienia i zarządzenia przewidziane w niniejszym rozdziale 

przysługuje zażalenie; na zarządzenie prokuratora, o którym mowa w art. 285 § 2, 

zażalenie przysługuje do sądu rejonowego, w którego okręgu prowadzi się 

postępowanie. 

§ 3. Złożenie zażalenia wstrzymuje wykonanie postanowienia o aresztowaniu. 


# Rozdział 32
 

Zabezpieczenie majątkowe


## Art. 291. {#kpk-art-291}
§ 1. W razie zarzucenia oskarżonemu popełnienia przestępstwa, za 

które lub w związku z którym można orzec: 

1) 

2) 

3) 

4) 

5) 

grzywnę, 

świadczenie pieniężne, 

przepadek, 

środek kompensacyjny, 

zwrot pokrzywdzonemu lub innemu uprawnionemu podmiotowi korzyści 

majątkowej, jaką sprawca osiągnął z popełnionego przestępstwa, albo jej 

równowartości 

– może z urzędu nastąpić zabezpieczenie wykonania tego orzeczenia na mieniu 

oskarżonego lub na mieniu, o którym mowa w art. 45 § 2 Kodeksu karnego, jeżeli 

zachodzi uzasadniona obawa, że bez takiego zabezpieczenia wykonanie orzeczenia 

będzie niemożliwe albo znacznie utrudnione. 

§ 2. W razie popełnienia przestępstwa, w związku z którym można orzec 

przepadek wskazany w § 1 pkt 3 lub zwrot wskazany w § 1 pkt 5, zabezpieczenie 

wykonania orzeczenia może nastąpić również: 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 126/356 

1) 

na mieniu osoby fizycznej, o której mowa w art. 44a Kodeksu karnego, lub osoby 

fizycznej, prawnej lub jednostki organizacyjnej niemającej osobowości prawnej, 

o której mowa w art. 45 § 3 Kodeksu karnego, lub na mieniu, które podlegałoby 

przepadkowi na podstawie art. 33 § 3 Kodeksu karnego skarbowego; 

2) 

niezależnie od tego, czy wydano postanowienie o przedstawieniu zarzutów lub 

postawiono zarzut w związku z przystąpieniem do przesłuchania w charakterze 

podejrzanego – na mieniu, które podlegałoby: 

a) przepadkowi lub zwrotowi na podstawie art. 45a § 1 lub 2 Kodeksu karnego 

oraz art. 43 § 1 lub 2 lub art. 43a Kodeksu karnego skarbowego, 

b) przepadkowi lub zwrotowi na podstawie art. 44 Kodeksu karnego, jeżeli co 

do 

tego mienia na podstawie odrębnych przepisów zastosowano 

wstrzymanie transakcji lub blokadę rachunku; 

c) przepadkowi pojazdu mechanicznego, o którym mowa w art. 44b Kodeksu 

karnego. 

§ 2a. Zabezpieczenie wykonania orzeczenia zwrotu korzyści majątkowej albo jej 

równowartości lub orzeczenia przepadku świadczenia albo jego równowartości wobec 

podmiotu zobowiązanego określonego w art. 91a może z urzędu nastąpić na mieniu 

tego podmiotu. 

§ 3. Z urzędu może także nastąpić na mieniu oskarżonego zabezpieczenie 

wykonania orzeczenia o kosztach sądowych, jeżeli zachodzi uzasadniona obawa, że 

bez takiego zabezpieczenia wykonanie orzeczenia w tym zakresie będzie niemożliwe 

albo znacznie utrudnione. 

§ 4. Zabezpieczenie majątkowe należy niezwłocznie uchylić w całości lub 

w części, jeżeli ustaną przyczyny, wskutek których zostało ono zastosowane 

w określonym rozmiarze, lub powstaną przyczyny uzasadniające jego uchylenie 

choćby w części.


## Art. 292. {#kpk-art-292}
§ 1. Zabezpieczenie następuje w sposób wskazany w przepisach 

Kodeksu postępowania cywilnego, chyba że ustawa stanowi inaczej. 

§ 2. Zabezpieczenie grożącego przepadku następuje przez zajęcie ruchomości, 

wierzytelności i innych praw majątkowych oraz przez ustanowienie zakazu zbywania 

i obciążania nieruchomości. Zakaz ten podlega ujawnieniu w księdze wieczystej, a w 

jej braku, w zbiorze złożonych dokumentów. W miarę potrzeby może być 

ustanowiony zarząd nieruchomości oskarżonego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 127/356 

§ 3. Przepis art. 232 stosuje się odpowiednio.


## Art. 292a. {#kpk-art-292a}
§ 1. Zabezpieczenie wykonania orzeczenia, o którym mowa w art. 291 

§ 1, może nastąpić 

również przez ustanowienie przymusowego zarządu 

przedsiębiorstwa 

i wyznaczenie zarządcy. W postanowieniu określa 

się 

przedsiębiorstwo lub jego zorganizowaną część oraz wskazuje się zarządcę spośród 

osób posiadających licencję doradcy restrukturyzacyjnego, o której mowa w ustawie 

z dnia 15 czerwca 2007 r. o licencji doradcy restrukturyzacyjnego (Dz. U. z 2022 r. 

poz. 1007). 

§ 2. W postępowaniu przygotowawczym postanowienie o zabezpieczeniu przez 

ustanowienie przymusowego zarządu wydaje prokurator. Postanowienie podlega 

zatwierdzeniu przez sąd. 

§ 3. Po wydaniu postanowienia, o którym mowa w § 2, prokurator najpóźniej w 

ciągu 7 dni występuje do sądu o jego zatwierdzenie. W przedmiocie zatwierdzenia sąd 

rozstrzyga w ciągu 7 dni od dnia przekazania mu postanowienia. 

§ 4. Zabezpieczenie upada z chwilą uprawomocnienia się postanowienia sądu o 

odmowie zatwierdzenia postanowienia, o którym mowa w § 2. 

§ 5. W przedmiocie zatwierdzenia postanowienia prokuratora o zabezpieczeniu 

orzeka na wniosek prokuratora w postępowaniu przygotowawczym sąd rejonowy, w 

którego okręgu prowadzi się postępowanie, a po wniesieniu aktu oskarżenia w 

przedmiocie zatwierdzenia orzeka sąd, przed którym sprawa się toczy. 

§ 6. Po wniesieniu aktu oskarżenia postanowienie o zabezpieczeniu przez 

ustanowienie przymusowego zarządu wydaje sąd, przed którym sprawa się toczy. 

§ 7. Na postanowienie sądu w przedmiocie zatwierdzenia postanowienia o 

zabezpieczeniu lub w przedmiocie zabezpieczenia stronom, pokrzywdzonemu oraz 

właścicielowi lub osobie kierującej przedsiębiorstwem w jego imieniu przysługuje 

zażalenie. 

§ 8. Zarządca zapewnia ciągłość pracy zabezpieczonego przedsiębiorstwa oraz 

przekazuje sądowi lub prokuratorowi posiadane informacje mające znaczenie dla 

toczącego się postępowania, w szczególności o sposobie i okolicznościach 

wykorzystania tego przedsiębiorstwa do popełnienia przestępstwa lub ukrycia 

osiągniętej z niego korzyści oraz o rzeczach i dokumentach mogących stanowić 

dowód w sprawie. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 128/356 

§ 9. Zarządca sporządza spis składników majątku i praw majątkowych 

przedsiębiorstwa 

i przekazuje go prokuratorowi 

lub sądowi, który wydał 

postanowienie o 

zabezpieczeniu. Właściciel 

lub 

inna osoba kierująca 

przedsiębiorstwem w jego imieniu może wnosić do prokuratora lub sądu, który wydał 

postanowienie o zabezpieczeniu, o wyłączenie określonych składników majątku lub 

praw majątkowych z zabezpieczenia. 

§ 10. Na postanowienie w przedmiocie wyłączenia określonych składników 

majątku lub praw majątkowych z zabezpieczenia stronom, pokrzywdzonemu oraz 

właścicielowi lub innej osobie kierującej przedsiębiorstwem w jego imieniu 

przysługuje zażalenie.


## Art. 292b. {#kpk-art-292b}
Zabezpieczenie, o którym mowa w art. 292a § 1, może nastąpić 

również w stosunku do przedsiębiorstwa podmiotu zbiorowego w rozumieniu ustawy 

z dnia 28 października 2002 r. o odpowiedzialności podmiotów zbiorowych za czyny 

zabronione pod groźbą kary (Dz. U. z 2023 r. poz. 659 oraz z 2024 r. poz. 1222), jeśli 

zebrane dowody wskazują na wysokie prawdopodobieństwo, że podmiot ten może 

podlegać odpowiedzialności na podstawie tej ustawy.


## Art. 293. {#kpk-art-293}
§ 1. Postanowienie o zabezpieczeniu majątkowym wydaje sąd, 

a w postępowaniu przygotowawczym prokurator. 

§ 2. W postanowieniu określa się kwotowo zakres i sposób zabezpieczenia, 

uwzględniając rozmiar możliwej do orzeczenia w okolicznościach danej sprawy 

grzywny, środków karnych, przepadku lub środków kompensacyjnych. Rozmiar 

zabezpieczenia powinien odpowiadać jedynie potrzebom tego, co ma zabezpieczać. 

Wymóg kwotowego określenia zabezpieczenia nie dotyczy zabezpieczenia na zajętym 

przedmiocie podlegającym przepadkowi, 

jako pochodzącym bezpośrednio 

z przestępstwa lub służącym albo przeznaczonym do jego popełnienia. 

§ 3. Na postanowienie w przedmiocie zabezpieczenia przysługuje zażalenie. 

Przepis art. 254 § 2 stosuje się odpowiednio. 

§ 4. Jeżeli postanowienie wydał prokurator, a postępowanie przygotowawcze 

prowadzone jest w okręgu innego sądu niż sąd miejscowo i rzeczowo właściwy, 

zażalenie przysługuje do sądu rzeczowo właściwego do rozpoznania tej sprawy 

w pierwszej 

instancji, w którego okręgu prowadzone 

jest postępowanie 

przygotowawcze. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 129/356 

§ 5. Postanowienie o zabezpieczeniu majątkowym z chwilą wydania stanowi 

tytuł wykonawczy. 

§ 5a. Postanowienie o uchyleniu zabezpieczenia majątkowego lub o zmianie 

prowadzącej do obniżenia wartości zabezpieczonego mienia staje się wykonalne 

z dniem uprawomocnienia. 

§ 6. Jeżeli zabezpieczenie nastąpiło na rzeczach, które uprzednio oskarżony 

wydał organowi procesowemu lub które zatrzymano w wyniku czynności, o których 

mowa w rozdziale 25, nie podejmuje się czynności egzekucyjnych dla wykonania 

postanowienia o zabezpieczeniu. 

§ 7. Osoba fizyczna, prawna lub jednostka organizacyjna niemająca osobowości 

prawnej, o której mowa w art. 45 § 3 Kodeksu karnego, może wystąpić 

z powództwem przeciwko Skarbowi Państwa o ustalenie, że mienie lub jego część nie 

podlega przepadkowi. Do czasu prawomocnego rozstrzygnięcia sprawy postępowanie 

egzekucyjne ulega zawieszeniu.


## Art. 294. {#kpk-art-294}
§ 1. Zabezpieczenie upada, gdy niezależnie od tego, jakie orzeczenie 

było nim objęte, nie zostanie prawomocnie orzeczone którekolwiek z orzeczeń 

wskazanych w art. 291 § 1 i 3, a powództwo o zabezpieczone roszczenie nie zostanie 

wytoczone przed upływem 3 miesięcy od daty uprawomocnienia się orzeczenia. 

§ 2. W razie 

wytoczenia 

powództwa 

w terminie 

wskazanym 

w § 1 zabezpieczenie pozostaje w mocy, jeżeli w postępowaniu cywilnym sąd nie 

orzeknie inaczej.


## Art. 295. {#kpk-art-295}
§ 1. W razie popełnienia przestępstwa, o którym mowa w art. 291, 

Policja może dokonać tymczasowego zajęcia mienia ruchomego osoby podejrzanej, 

jeżeli zachodzi obawa usunięcia tego mienia. 

§ 1a. W razie popełnienia przestępstwa za które orzeka się przepadek pojazdu 

mechanicznego, o którym mowa w art. 44b Kodeksu karnego, Policja dokonuje 

tymczasowego zajęcia pojazdu mechanicznego prowadzonego przez sprawcę w czasie 

popełnienia tego przestępstwa. 

§ 2. Przepisy art. 217–235 stosuje się odpowiednio. 

§ 3. Tymczasowe zajęcie nie może dotyczyć przedmiotów, które nie podlegają 

egzekucji. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 130/356 

§ 4. Tymczasowe zajęcie upada, jeżeli w ciągu 7 dni od daty jego dokonania nie 

zostanie wydane postanowienie o zabezpieczeniu majątkowym.


## Art. 296. {#kpk-art-296}
(uchylony)
