---
id: "code_kpk_dzial-viii"
title: "KPK — DZIAŁ VIII"
source_pdf: "D19970555Lj (1).pdf"
dz_u: "Dz. U. 1997 Nr 89 poz. 555"
status: "obowiązujący"
last_consolidated: "2025-09-11"
law: "Kodeks postępowania karnego"
tags: ["kpk", "kodeks", "postępowanie karne"]
articles_range: {"first": "337", "last": "424"}
---

# DZIAŁ VIII

## Art. 337. {#kpk-art-337}
§ 1. Jeżeli akt oskarżenia nie odpowiada warunkom formalnym 

wymienionym w art. 119, art. 332, art. 333 lub art. 335, a także jeżeli nie zostały 

spełnione warunki wymienione w art. 334, prezes sądu zwraca go oskarżycielowi 

w celu usunięcia braków w terminie 7 dni. 

§ 1a. (uchylony) 

§ 2. Na zarządzenie, o którym mowa w § 1, oskarżycielowi przysługuje 

zażalenie do sądu właściwego do rozpoznania sprawy. 

§ 3. Oskarżyciel publiczny, który nie wnosi zażalenia, jest obowiązany wnieść 

w terminie wskazanym w § 1 poprawiony lub uzupełniony akt oskarżenia. 

§ 4. (uchylony)


## Art. 337a. {#kpk-art-337a}
§ 1. Na wniosek pokrzywdzonego należy poinformować go 

o zarzutach oskarżenia i ich kwalifikacji prawnej. 

§ 2. Jeżeli wnioski, o których mowa w § 1, złożyło tylu pokrzywdzonych, że ich 

indywidualne poinformowanie spowodowałoby poważne utrudnienie w prowadzeniu 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 153/356 

postępowania, informację zamieszcza się przez ogłoszenie na stronie internetowej 

sądu. W informacji wskazuje się sygnaturę akt sprawy, a nie podaje się danych 

osobowych zawartych w zarzutach.


## Art. 338. {#kpk-art-338}
[§ 1. Jeżeli akt oskarżenia odpowiada warunkom formalnym, prezes 

sądu lub referendarz sądowy niezwłocznie zarządza doręczenie jego odpisu 

oskarżonemu, wzywając do składania wniosków dowodowych w terminie 7 dni od daty 

doręczenia mu aktu oskarżenia.] 

 <§ 1. Jeżeli akt oskarżenia odpowiada warunkom formalnym, prezes sądu 

lub referendarz sądowy niezwłocznie zarządza doręczenie 

jego kopii 

oskarżonemu, wzywając do składania wniosków dowodowych w terminie 7 dni 

od daty doręczenia mu aktu oskarżenia.> 

§ 1a. Oskarżonego poucza się również o treści przepisów art. 291 § 3, art. 338a, 

art. 338b, art. 341 § 1, art. 349 § 8 zdanie trzecie, art. 374, art. 376, art. 377 i art. 422 

oraz o tym, że w zależności od wyniku procesu oskarżony może być obciążony 

kosztami wyznaczenia obrońcy z urzędu. 

 [§ 1b. Jeżeli złożono wniosek, o którym mowa w art. 335 § 1, albo akt 

oskarżenia zawiera wniosek, o którym mowa w art. 335 § 2, jego odpis doręcza się 

ujawnionemu pokrzywdzonemu.] 

 <§ 1b. Jeżeli złożono wniosek, o którym mowa w art. 335 § 1, albo akt 

oskarżenia zawiera wniosek, o którym mowa w art. 335 § 2, jego kopię doręcza 

się ujawnionemu pokrzywdzonemu.> 

Zmiana w § 1 w 
art. 338 wejdzie 
w życie z dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

§ 2. Oskarżony ma prawo wniesienia, w terminie 7 dni od doręczenia mu aktu 

oskarżenia, pisemnej odpowiedzi na akt oskarżenia, o czym należy go pouczyć. 

§ 3. [Jeżeli zachodzi niebezpieczeństwo ujawnienia informacji niejawnych 

o klauzuli „tajne” lub „ściśle tajne”, oskarżonemu doręcza się odpis aktu oskarżenia 

bez uzasadnienia.] <Jeżeli zachodzi niebezpieczeństwo ujawnienia informacji 

niejawnych o klauzuli „tajne” lub „ściśle tajne”, oskarżonemu doręcza się kopię 

aktu oskarżenia bez uzasadnienia.> Uzasadnienie aktu oskarżenia udostępnia się 

Zmiany w § 1b i 
zd. pierwszym w 
3 w art. 338 
wejdą w życie z 
1.10.2029 r 
dn. 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

jednak z zachowaniem rygorów określonych przez prezesa sądu lub sąd. 

§ 4. Odpis aktu oskarżenia w postaci elektronicznej doręcza się na adres poczty 

elektronicznej. Art. 132 § 3 zdanie drugie stosuje się. 

§ 5. O dacie doręczenia odpisu aktu oskarżenia oraz adresie poczty 

elektronicznej, na który odpis został wysłany, zawiadamia się adresata za 

2025-09-11 

 
 
 
 
 
 

©Kancelaria Sejmu 

s. 154/356 

pośrednictwem operatora pocztowego, o którym mowa w art. 131 § 1 pkt 1, 

a w uzasadnionych wypadkach można go zawiadomić telefonicznie. 

§ 6. Jeżeli oskarżony nie włada w wystarczającym stopniu językiem polskim, 

przed wydaniem zarządzenia o doręczeniu aktu oskarżenia prezes sądu lub referendarz 

sądowy wzywa tłumacza w celu przełożenia aktu oskarżenia na język obcy. 

Oskarżonemu doręcza się odpis aktu oskarżenia wraz z tłumaczeniem.


## Art. 338a. {#kpk-art-338a}
Oskarżony, któremu zarzucono przestępstwo zagrożone karą 

nieprzekraczającą 15 lat pozbawienia wolności, może przed doręczeniem mu 

zawiadomienia o terminie rozprawy złożyć wniosek o wydanie wyroku skazującego 

i wymierzenie mu określonej kary lub środka karnego, orzeczenie przepadku lub 

środka kompensacyjnego bez przeprowadzenia postępowania dowodowego. Wniosek 

może również dotyczyć wydania określonego rozstrzygnięcia w przedmiocie 

poniesienia kosztów procesu.


## Art. 338b. {#kpk-art-338b}
§ 1. [Żądanie, o którym mowa w art. 78 § 1 i art. 78a, powinno 

zostać złożone do sądu w terminie 7 dni od daty doręczenia odpisu aktu oskarżenia.] 

<Żądanie, o którym mowa w art. 78 § 1 i art. 78a, powinno zostać złożone do 

sądu w terminie 7 dni od daty doręczenia kopii aktu oskarżenia.> Do żądania, 

o którym mowa w art. 78 § 1, należy dołączyć dowody mające wykazać, że oskarżony 

nie jest w stanie ponieść kosztów obrony bez uszczerbku dla niezbędnego utrzymania 

siebie i rodziny. 

§ 2. Jeżeli złożenie żądania po terminie spowodowałoby konieczność zmiany 

terminu rozprawy albo posiedzenia, o którym mowa w art. 341, art. 343 lub art. 343a, 

żądanie rozpoznaje się niezwłocznie po terminie rozprawy lub posiedzenia. Przepis 

ten stosuje się odpowiednio, jeżeli żądanie zostało złożone w terminie, lecz nie 

odpowiada wymaganiom formalnym, o których mowa w art. 120 § 1, lub nie 

dołączono dowodów, o których mowa w § 1 zdanie drugie. 

§ 3. Po pierwszym terminie rozprawy albo posiedzenia, o którym mowa 

w art. 341, art. 343 lub art. 343a, żądanie, o którym mowa w art. 78 § 1 lub w art. 78a 

§ 1, powinno zostać złożone do sądu w takim terminie, aby jego rozpoznanie nie 

powodowało konieczności zmiany kolejnego terminu rozprawy albo posiedzenia. 

Przepisy § 1 zdanie drugie oraz § 2 stosuje się odpowiednio.


## Art. 339. {#kpk-art-339}
§ 1. Prezes sądu kieruje sprawę na posiedzenie, jeżeli: 

2025-09-11 

art. 

Zmiana w zd. 
pierwszym w § 1 
338b 
w 
wejdzie w życie z 
dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 
 
 
 
 

©Kancelaria Sejmu 

s. 155/356 

1) 

2) 

3) 

prokurator złożył wniosek o orzeczenie środków zabezpieczających; 

zachodzi potrzeba rozważenia kwestii warunkowego umorzenia postępowania; 

do aktu oskarżenia dołączono wniosek, o którym mowa w art. 335 § 2; 

3a) prokurator złożył wniosek, o którym mowa w art. 335 § 1. 

4) 

5) 

(uchylony) 

(uchylony) 

§ 2. (uchylony) 

§ 3. Prezes sądu kieruje sprawę na posiedzenie także wtedy, gdy zachodzi 

potrzeba innego rozstrzygnięcia przekraczającego jego uprawnienia, a zwłaszcza: 

1) 

2) 

umorzenia postępowania na podstawie art. 17 § 1 pkt 2–11; 

umorzenia postępowania z powodu oczywistego braku faktycznych podstaw 

oskarżenia; 

3) wydania postanowienia o niewłaściwości sądu; 

3a) zwrotu sprawy prokuratorowi w celu usunięcia istotnych braków postępowania 

przygotowawczego; 

4) 

(uchylony) 

5) wydania postanowienia o zawieszeniu postępowania; 

6) wydania postanowienia w przedmiocie tymczasowego aresztowania lub innego 

środka przymusu; 

7) wydania wyroku nakazowego. 

§ 3a. Prezes sądu może skierować sprawę na posiedzenie, jeżeli oskarżony, 

któremu zarzucono przestępstwo zagrożone karą nieprzekraczającą 15 lat 

pozbawienia wolności, przed doręczeniem mu zawiadomienia o wyznaczeniu 

rozprawy złożył wniosek, o którym mowa w art. 338a, a prezes sądu uzna, że cele 

postępowania nie sprzeciwiają się rozpoznaniu sprawy na posiedzeniu. 

§ 3b. Jeżeli akt oskarżenia pochodzi od oskarżyciela posiłkowego, prezes sądu 

na wniosek oskarżonego kieruje sprawę na posiedzenie w celu rozstrzygnięcia, czy 

zachodzi potrzeba umorzenia postępowania na podstawie art. 17 § 1 pkt 9. 

§ 4. Prezes sądu kieruje sprawę na posiedzenie ponadto, gdy zachodzi potrzeba 

rozważenia możliwości przekazania jej do postępowania mediacyjnego; przepis 

art. 23a stosuje się odpowiednio. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 156/356 

§ 4a. Jeżeli akt oskarżenia odpowiada warunkom formalnym, czynności, 

o których mowa w § 1, 3 i 4, prezes sądu dokonuje w terminie 30 dni od wniesienia 

aktu oskarżenia. 

§ 5. Strony, obrońcy i pełnomocnicy mogą wziąć udział w posiedzeniach 

wymienionych w § 1, § 3 pkt 1, 2 i 6 oraz § 3b, z tym że udział prokuratora i obrońcy 

w posiedzeniu w przedmiocie orzeczenia środka zabezpieczającego określonego 

w art. 93a § 1 pkt 4 Kodeksu karnego jest obowiązkowy. Pokrzywdzony ma prawo 

wziąć udział w posiedzeniach wymienionych w § 3 pkt 1 i 2 oraz § 3b. Zawiadamiając 

pokrzywdzonego o posiedzeniu poucza 

się go o możliwości zakończenia 

postępowania bez przeprowadzenia rozprawy oraz wcześniejszego złożenia 

oświadczenia, o którym mowa w art. 54 § 1. Do prokuratora, niebędącego stroną 

postępowania, biorącego udział w posiedzeniu wyznaczonym na podstawie § 3b, 

stosuje się odpowiednio przepisy dotyczące 

jego udziału w postępowaniu 

w charakterze uczestnika, o którym mowa w art. 55 § 5.


## Art. 340. {#kpk-art-340}
§ 1. W kwestii umorzenia postępowania stosuje się odpowiednio 

art. 322 oraz art. 323 § 1 i 2. 

§ 2. W razie istnienia podstaw określonych w art. 45a Kodeksu karnego albo 

art. 43 § 1 lub 2, art. 43a lub art. 47 § 4 Kodeksu karnego skarbowego sąd, umarzając 

postępowanie lub rozpoznając wniosek prokuratora, o którym mowa w art. 323 § 3, 

orzeka przepadek. 

§ 2a. Na postanowienie w przedmiocie przepadku przysługuje zażalenie stronom 

i osobie, od której przedmioty te odebrano lub która zgłosiła do nich roszczenie. 

§ 3. Osoba roszcząca sobie prawo do korzyści lub przedmiotów, których 

przepadek orzeczono na podstawie art. 44–45a Kodeksu karnego lub art. 43 § 1 i 2, 

art. 43a oraz art. 47 § 4 Kodeksu karnego skarbowego, może dochodzić swych 

roszczeń tylko w postępowaniu cywilnym.


## Art. 341. {#kpk-art-341}
§ 1. Prokurator, oskarżony i pokrzywdzony mają prawo wziąć udział 

w posiedzeniu w przedmiocie warunkowego umorzenia postępowania. Udział ich jest 

obowiązkowy, jeżeli prezes sądu lub sąd tak zarządzi. 

§ 2. Jeżeli oskarżony sprzeciwia się warunkowemu umorzeniu, jak również 

wtedy, gdy sąd uznaje, że warunkowe umorzenie byłoby nieuzasadnione, kieruje 

sprawę na rozprawę. Wniosek prokuratora o warunkowe umorzenie postępowania 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 157/356 

zastępuje akt oskarżenia. W terminie 7 dni prokurator dokonuje czynności 

określonych w art. 333 § 1–2. 

§ 3. Jeżeli sąd uzna za celowe ze względu na możliwość porozumienia się 

oskarżonego z pokrzywdzonym w kwestii naprawienia szkody lub zadośćuczynienia, 

może odroczyć posiedzenie, wyznaczając stronom odpowiedni termin. Na wniosek 

oskarżonego i pokrzywdzonego, uzasadniony potrzebą dokonania uzgodnień, sąd 

zarządza stosowną przerwę lub odracza posiedzenie. 

§ 4. Sąd orzekając o warunkowym umorzeniu bierze pod uwagę wyniki 

porozumienia się oskarżonego z pokrzywdzonym w kwestii wskazanej w § 3. 

§ 5. W przedmiocie warunkowego umorzenia postępowania sąd orzeka na 

posiedzeniu wyrokiem.


## Art. 342. {#kpk-art-342}
§ 1. W wyroku warunkowo umarzającym postępowanie należy 

dokładnie określić czyn przypisany oskarżonemu, jego kwalifikację prawną oraz 

oznaczyć okres próby. 

§ 2. W wyroku sąd określa także nałożone na oskarżonego obowiązki oraz 

sposób i termin ich wykonania albo zamiast tych obowiązków orzeka nawiązkę, 

a w razie uznania za celowe – orzeka świadczenie pieniężne lub zakaz prowadzenia 

pojazdów, dozór kuratora, osoby godnej zaufania albo instytucji lub organizacji 

społecznej. 

§ 3. Wyrok powinien w razie potrzeby zawierać rozstrzygnięcie co do dowodów 

rzeczowych. Sąd stosuje odpowiednio art. 230 § 2 

i 3 oraz art. 231–233, 

uwzględniając potrzebę zabezpieczenia dowodów na wypadek podjęcia postępowania. 

§ 4. Zawarte w wyroku rozstrzygnięcie, o którym mowa w § 3, może być 

zaskarżone zażaleniem przez osoby wskazane w art. 323 § 2. 

§ 5. (uchylony)


## Art. 343. {#kpk-art-343}
§ 1. Jeżeli nie ma zastosowania art. 46 Kodeksu karnego, sąd może 

uzależnić uwzględnienie wniosku, o którym mowa w art. 335, od naprawienia szkody 

w całości albo w części lub od zadośćuczynienia za doznaną krzywdę. Przepis art. 341 

§ 3 stosuje się odpowiednio. 

§ 2. Uwzględnienie wniosku jest możliwe tylko wówczas, jeżeli nie sprzeciwi się 

temu pokrzywdzony, należycie powiadomiony o terminie posiedzenia. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 158/356 

§ 3. Sąd może uzależnić uwzględnienie wniosku od dokonania w nim przez 

prokuratora wskazanej przez siebie zmiany, zaakceptowanej przez oskarżonego. 

§ 4. Postępowania dowodowego nie prowadzi się. 

§ 5. Prokurator, oskarżony 

i pokrzywdzony mają prawo wziąć udział 

w posiedzeniu. Zawiadamiając pokrzywdzonego o posiedzeniu poucza się go 

o możliwości zakończenia postępowania bez przeprowadzenia rozprawy oraz 

wcześniejszego złożenia oświadczenia, o którym mowa w art. 54 § 1. Udział 

podmiotów wskazanych w zdaniu pierwszym w posiedzeniu jest obowiązkowy, jeżeli 

prezes sądu lub sąd tak zarządzi. 

§ 5a. Przed uwzględnieniem wniosku, o którym mowa w art. 335, sąd poucza 

obecnego oskarżonego o treści art. 447 § 5. 

§ 6. Sąd, uwzględniając wniosek, skazuje oskarżonego wyrokiem. 

§ 7. Jeżeli sąd uzna, że nie zachodzą podstawy do uwzględnienia wniosku, 

o którym mowa w art. 335 § 1, zwraca 

sprawę prokuratorowi. W razie 

nieuwzględnienia wniosku wskazanego w art. 335 § 2 sprawa podlega rozpoznaniu na 

zasadach ogólnych, a prokurator, w terminie 7 dni od dnia posiedzenia, dokonuje 

czynności określonych w art. 333 § 1 i 2.


## Art. 343a. {#kpk-art-343a}
§ 1. W wypadku złożenia przez oskarżonego wniosku, o którym 

mowa w art. 338a, o terminie posiedzenia zawiadamia się strony i pokrzywdzonego, 

przesyłając im odpis wniosku. 

§ 2. Sąd może uwzględnić wniosek, jeżeli okoliczności popełnienia przestępstwa 

i wina nie budzą wątpliwości, a postawa oskarżonego wskazuje, że cele postępowania 

zostaną osiągnięte. Uwzględnienie wniosku jest możliwe tylko wówczas, gdy nie 

sprzeciwi się temu prokurator. Przepis art. 343 stosuje się odpowiednio. 

§ 3. W razie złożenia kolejnego wniosku podlega on rozpoznaniu na rozprawie.


## Art. 343b. {#kpk-art-343b}
Postanowienia o nieuwzględnieniu wniosków, o których mowa 

w art. 335, art. 336 § 1 i art. 338a, mogą być również wydane na posiedzeniu, 

o którego terminie nie zawiadomiono uczestników uprawnionych do stawiennictwa.


## Art. 344. {#kpk-art-344}
Jeżeli oskarżony 

jest 

tymczasowo aresztowany, sąd z urzędu 

rozstrzyga o utrzymaniu, zmianie lub uchyleniu tego środka. W razie potrzeby orzeka 

także o innych środkach zapobiegawczych. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 159/356


## Art. 344a. {#kpk-art-344a}
§ 1. Sąd przekazuje sprawę prokuratorowi w celu uzupełnienia 

śledztwa lub dochodzenia, jeżeli akta sprawy wskazują na istotne braki tego 

postępowania, zwłaszcza na potrzebę poszukiwania dowodów, zaś dokonanie 

niezbędnych czynności przez sąd powodowałoby znaczne trudności. 

§ 2. Przekazując sprawę prokuratorowi, sąd wskazuje kierunek uzupełnienia, 

a w razie potrzeby także odpowiednie czynności, jakie należy przedsięwziąć. 

§ 3. Na postanowienie, o którym mowa w § 1, służy stronom zażalenie.


## Art. 344b. {#kpk-art-344b}
Po uzupełnieniu śledztwa lub dochodzenia oskarżyciel publiczny 

składa nowy akt oskarżenia lub podtrzymuje poprzedni, kieruje do sądu wniosek 

o warunkowe umorzenie postępowania albo postępowanie umarza.


## Art. 345. {#kpk-art-345}
(uchylony)


## Art. 346. {#kpk-art-346}
(uchylony)


## Art. 347. {#kpk-art-347}
W dalszym postępowaniu sąd nie jest związany ani oceną faktyczną, 

ani prawną przyjętą za podstawę postanowień i zarządzeń wydanych na posiedzeniu. 


# Rozdział 41
 

Przygotowanie do rozprawy głównej


## Art. 348. {#kpk-art-348}
Rozprawę należy wyznaczyć i przeprowadzić bez nieuzasadnionej 

zwłoki.


## Art. 349. {#kpk-art-349}
§ 1. Jeżeli przewidywany zakres postępowania dowodowego 

uzasadnia przypuszczenie, że przewód sądowy nie zostanie zamknięty na pierwszym 

terminie rozprawy, prezes sądu niezwłocznie wyznacza sędziego albo członków 

składu orzekającego, a przewodniczący składu orzekającego kieruje sprawę na 

posiedzenie wstępne. Posiedzenie wstępne może zostać wyznaczone na ten sam dzień, 

na który wyznaczono pierwszy termin rozprawy głównej. Posiedzenia wstępnego 

można nie przeprowadzać, jeżeli złożono wniosek, o którym mowa w art. 387 § 1. 

§ 2. W przypadku zaistnienia okoliczności określonych w § 1, uzasadniających 

odstąpienie od skierowania sprawy na posiedzenie wstępne, przewodniczący wydaje 

w tym przedmiocie zarządzenie. Zarządzenie wymaga uzasadnienia. 

§ 3. Udział prokuratora, obrońcy i pełnomocnika oskarżyciela posiłkowego 

w posiedzeniu wstępnym jest obowiązkowy, a pozostałych stron i pokrzywdzonego – 

jeżeli przewodniczący tak zarządzi. Niestawiennictwo strony, obrońcy, pełnomocnika 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 160/356 

lub pokrzywdzonego, należycie wezwanych na posiedzenie lub zawiadomionych 

o jego terminie, nie stoi na przeszkodzie przeprowadzeniu posiedzenia. Strony 

pozbawionej wolności nie sprowadza się, chyba że przewodniczący uzna to za 

konieczne. 

§ 4. Strony 

i inne osoby, których udział w posiedzeniu wstępnym 

jest 

obowiązkowy, a także pozostałe strony i pokrzywdzony mogą przedstawić stanowisko 

w przedmiocie planowania i organizacji rozprawy głównej. Stanowisko przedstawia 

się na piśmie, a na posiedzeniu można je przedstawić również ustnie. Przewodniczący 

może wezwać strony i inne osoby obowiązane lub uprawnione do udziału 

w posiedzeniu wstępnym do przedstawienia na piśmie oświadczeń lub wniosków, 

o których mowa w § 5, zakreślając w tym celu stosowny termin. 

§ 5. Stanowisko, o którym mowa w § 4, może obejmować oświadczenia 

o proponowanych terminach rozprawy i okresach występowania obiektywnych 

przeszkód uniemożliwiających udział w rozprawie, wnioski o przeprowadzenie 

dowodów bezpośrednio lub poprzez ich odczytanie, a także o ich przeprowadzenie 

w określonej kolejności, wnioski o sprowadzenie dowodu rzeczowego na rozprawę 

lub uzyskanie przez sąd określonego dokumentu urzędowego mającego znaczenie dla 

rozstrzygnięcia sprawy, wnioski o zezwolenie na udział w rozprawie na odległość 

z wykorzystaniem urządzeń umożliwiających jednoczesny i bezpośredni przekaz 

obrazu i dźwięku, a także inne oświadczenia i wnioski dotyczące okoliczności 

istotnych dla sprawnego i prawidłowego przeprowadzenia przewodu sądowego. 

Stanowisko może też obejmować wnioski dowodowe, jak również odniesienie się do 

wniosków dowodowych złożonych przez inną stronę. 

§ 6. W sprawach, w których wyznaczono posiedzenie wstępne, wnioski 

formalne dotyczące biegu postępowania, w tym dotyczące właściwości sądu, 

przekazania sprawy 

innemu sądowi, występowania okoliczności określonych 

w art. 17 § 1, przekazania sprawy prokuratorowi w celu uzupełnienia śledztwa lub 

dochodzenia, a także wnioski o wyłączenie sędziego powinny być złożone najpóźniej 

na tym posiedzeniu. 

§ 7. Wnioski, o których mowa w § 6, złożone po zakończeniu posiedzenia 

wstępnego pozostawia się bez rozpoznania, chyba że wnioskodawca wykaże, iż 

okoliczności uzasadniające złożenie wniosku powstały albo stały się mu znane 

później. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 161/356 

§ 8. Na posiedzeniu wstępnym rozpoznaje się wnioski, o których mowa w § 6, 

a w razie potrzeby można rozpoznać wnioski dowodowe. Przewodniczący, biorąc pod 

uwagę stanowiska, o których mowa w § 5, rozstrzyga w drodze zarządzenia co do 

objętych nimi okoliczności oraz innych okoliczności istotnych dla sprawnego i pra-

widłowego przeprowadzenia przewodu sądowego, wyznacza terminy rozprawy, 

w liczbie co najmniej 5, o ile zakres przewidywanego postępowania dowodowego nie 

uzasadnia ich mniejszej liczby, a następnie ogłasza je stronom i innym osobom 

biorącym udział w posiedzeniu. Ogłoszenie wyznaczonych terminów rozprawy ma 

skutek 

równoznaczny z wezwaniem do 

stawiennictwa na 

rozprawie 

lub 

zawiadomieniem o jej terminie. 

§ 9. Jeżeli strona, obrońca lub pełnomocnik nie brali udziału w posiedzeniu 

wstępnym, o wyznaczonych terminach rozprawy powiadamia się ich na piśmie; 

powiadomienie ma skutek równoznaczny z wezwaniem do stawiennictwa na 

rozprawie lub zawiadomieniem o jej terminie. Przepisy art. 129 § 1 i 2 stosuje się 

odpowiednio. 

§ 10. Wniosek o zmianę terminu rozprawy wyznaczonego na posiedzeniu 

wstępnym można pozostawić bez rozpoznania, chyba że w sposób oczywisty 

zasługuje na uwzględnienie. 

§ 11. Na wniosek strony 

lub z urzędu można wyznaczyć posiedzenie 

w przedmiocie planowania i organizacji rozprawy głównej również po rozpoczęciu 

przewodu sądowego, jeżeli przyczyni się to do usprawnienia dalszego biegu 

postępowania. Przepisy § 3–10 stosuje się odpowiednio.


## Art. 350. {#kpk-art-350}
§ 1. W sprawach, w których nie wyznaczono posiedzenia, o którym 

mowa w art. 349, prezes sądu wydaje pisemne zarządzenie wskazujące sędziego albo 

członków składu orzekającego. 

§ 2. Przewodniczący składu orzekającego wydaje pisemne zarządzenie 

o wyznaczeniu rozprawy głównej, w którym wskazuje: 

1) 

2) 

dzień, godzinę i salę rozpraw; 

strony i inne osoby, które należy wezwać na rozprawę lub zawiadomić o jej 

terminie; 

3) 

inne czynności konieczne do przygotowania rozprawy. 

§ 3. Co do oskarżonego pozbawionego wolności należy wydać zarządzenie 

o doprowadzeniu go na rozprawę w celu udziału w czynnościach, o których mowa 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 162/356 

w art. 374 § 1a, a także jeśli złożył on wniosek, o którym mowa w art. 353 § 3, albo 

gdy jego obecność na rozprawie została uznana za obowiązkową. 

§ 4. O terminie i miejscu rozprawy głównej zawiadamia się pokrzywdzonego.


## Art. 350a. {#kpk-art-350a}
Przewodniczący składu orzekającego może zaniechać wezwania na 

rozprawę świadków, którzy zostali przesłuchani, przebywających za granicą lub 

mających stwierdzić okoliczności, które nie są tak doniosłe, aby konieczne było 

bezpośrednie przesłuchanie świadków na rozprawie, w szczególności takie, którym 

oskarżony w wyjaśnieniach swych nie zaprzeczył. Nie dotyczy to osób wymienionych 

w art. 182.


## Art. 351. {#kpk-art-351}
(uchylony)


## Art. 352. {#kpk-art-352}
Przewodniczący składu orzekającego po rozważeniu wniosków stron 

albo sąd z urzędu dopuszcza dowody, a przewodniczący zarządza ich sprowadzenie 

na rozprawę. Przepis art. 368 § 1 stosuje się odpowiednio.


## Art. 353. {#kpk-art-353}
§ 1. Pomiędzy doręczeniem zawiadomienia a terminem rozprawy 

głównej powinno upłynąć co najmniej 7 dni. 

§ 2. W razie niezachowania tego terminu w stosunku do oskarżonego lub jego 

obrońcy rozprawa na ich wniosek, zgłoszony przed rozpoczęciem przewodu 

sądowego, ulega odroczeniu. 

§ 3. Doręczając oskarżonemu pozbawionemu wolności, którego obecność na 

rozprawie nie jest obowiązkowa, zawiadomienie o terminie rozprawy, należy pouczyć 

go o prawie do złożenia w terminie 7 dni od daty doręczenia tego zawiadomienia 

wniosku o doprowadzenie go na rozprawę. 

§ 4. Doręczając oskarżonemu wezwanie na rozprawę albo zawiadomienie o jej 

terminie, poucza się go o treści przepisów art. 100 § 3 i 4, art. 374, art. 376, art. 377, 

art. 378a, art. 419 § 1, art. 422 i art. 447 § 5. 

§ 4a. Doręczając stronie zawiadomienie o terminie rozprawy, poucza się ją 

o treści art. 402 § 1 zdanie trzecie. 

§ 5. Wniosek o doprowadzenie na rozprawę złożony po terminie, o którym 

mowa w § 3, podlega rozpoznaniu, jeżeli nie powoduje to konieczności zmiany 

terminu rozprawy. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 163/356


## Art. 354. {#kpk-art-354}
W wypadku wniosku prokuratora o umorzenie postępowania 

z powodu niepoczytalności sprawcy i o zastosowanie środków zabezpieczających 

stosuje się odpowiednio przepisy niniejszego rozdziału z następującymi zmianami: 

1) 

nie stosuje się przepisów o oskarżycielu posiłkowym; 

2) wniosek kieruje się na rozprawę, chyba że w świetle materiałów postępowania 

przygotowawczego popełnienie czynu zabronionego przez podejrzanego i jego 

niepoczytalność w chwili czynu nie budzą wątpliwości, a prezes sądu uzna za 

celowe rozpoznanie sprawy na posiedzeniu z udziałem prokuratora, obrońcy 

i podejrzanego; podejrzany nie bierze udziału w posiedzeniu, jeżeli z opinii 

biegłych wynika, że byłoby to niewskazane, chyba że sąd uzna jego udział za 

konieczny; pokrzywdzony ma prawo wziąć udział w posiedzeniu; 

3) w razie umorzenia postępowania stosuje się art. 322 § 2 i 3.


## Art. 354a. {#kpk-art-354a}
§ 1. Przed orzeczeniem środka zabezpieczającego, o którym mowa 

w art. 93a § 1 Kodeksu karnego, albo nakazu lub zakazów, o których mowa w art. 39 

pkt 2–3 Kodeksu karnego, orzeczonych tytułem środka zabezpieczającego, sąd 

wysłuchuje: 

1) 

biegłego psychologa; 

2) w 

sprawach osób niepoczytalnych, o ograniczonej poczytalności 

lub 

z zaburzeniami osobowości albo gdy sąd uzna to za wskazane – ponadto biegłych 

lekarzy psychiatrów; 

3) w sprawach osób z zaburzeniami preferencji seksualnych – biegłych wskazanych 

w pkt 1 i 2 oraz biegłego lekarza seksuologa lub biegłego psychologa 

seksuologa. 

W sprawach osób uzależnionych można również wysłuchać biegłego w przedmiocie 

uzależnienia. 

§ 2. Jeżeli sprawca, wobec którego istnieją podstawy do orzeczenia terapii lub 

terapii uzależnień, wyraża zgodę na taką terapię lub terapię uzależnień, przepisu 

§ 1 nie stosuje się; sąd może jednak, jeżeli uzna to za wskazane, wysłuchać jednego 

lub więcej biegłych wskazanych w tym przepisie. 


# Rozdział 42
 

Jawność rozprawy głównej


## Art. 355. {#kpk-art-355}
Rozprawa odbywa się jawnie. Ograniczenia jawności określa ustawa. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 164/356


## Art. 356. {#kpk-art-356}
§ 1. Na rozprawie oprócz osób biorących udział w postępowaniu mogą 

być obecne tylko osoby pełnoletnie, nieuzbrojone. 

§ 2. Przewodniczący może zezwolić na obecność na rozprawie małoletnim oraz 

osobom obowiązanym do noszenia broni. 

§ 3. Nie mogą być obecne na rozprawie osoby znajdujące się w stanie 

nielicującym z powagą sądu.


## Art. 357. {#kpk-art-357}
§ 1. Sąd zezwala przedstawicielom środków masowego przekazu na 

dokonywanie za pomocą aparatury utrwaleń obrazu i dźwięku z przebiegu rozprawy. 

§ 2. Sąd może określić warunki udziału przedstawicieli środków masowego 

przekazu w rozprawie. 

§ 3. Jeżeli ze względów techniczno-organizacyjnych obecność przedstawicieli 

środków masowego przekazu utrudnia przebieg rozprawy, sąd ogranicza liczbę 

przedstawicieli środków masowego przekazu na sali 

rozprawy 

i wskazuje 

uprawnionych do dokonywania za pomocą aparatury utrwaleń obrazu i dźwięku 

z przebiegu rozprawy według kolejności zgłoszeń lub na podstawie losowania. 

§ 4. Sąd zarządza opuszczenie sali rozprawy przez przedstawicieli środków 

masowego przekazu, którzy zakłócają przebieg rozprawy. 

§ 5. W wyjątkowych wypadkach, gdy należy się obawiać, że obecność 

przedstawicieli środków masowego przekazu mogłaby oddziaływać krępująco na 

zeznania świadka, przewodniczący może zarządzić opuszczenie sali rozprawy przez 

przedstawicieli środków masowego przekazu na czas przesłuchania danej osoby.


## Art. 358. {#kpk-art-358}
Jeżeli nie przemawia przeciw 

temu wzgląd na prawidłowość 

postępowania, sąd na wniosek strony wyraża zgodę na utrwalenie przez nią przebiegu 

rozprawy za pomocą urządzenia rejestrującego dźwięk.


## Art. 359. {#kpk-art-359}
Niejawna jest rozprawa, która dotyczy: 

1) wniosku prokuratora o umorzenie postępowania z powodu niepoczytalności 

sprawcy i zastosowanie środka zabezpieczającego; 

2) 

sprawy o pomówienie lub znieważenie; na wniosek pokrzywdzonego rozprawa 

odbywa się jednak jawnie.


## Art. 360. {#kpk-art-360}
§ 1. Sąd może wyłączyć jawność rozprawy w całości albo w części: 

1) 

jeżeli jawność mogłaby: 

a) wywołać zakłócenie spokoju publicznego, 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 165/356 

b) obrażać dobre obyczaje, 

c) ujawnić okoliczności, które ze względu na ważny interes państwa powinny 

być zachowane w tajemnicy, 

d) naruszyć ważny interes prywatny; 

2) 

jeżeli choćby jeden z oskarżonych nie ukończył 18 lat lub na czas przesłuchania 

świadka, który nie ukończył 15 lat; 

3) 

na żądanie osoby, która złożyła wniosek o ściganie. 

§ 2. Jeżeli prokurator sprzeciwi się wyłączeniu jawności, rozprawa odbywa się 

jawnie.


## Art. 361. {#kpk-art-361}
§ 1. W razie wyłączenia jawności mogą być obecne na rozprawie, 

oprócz osób biorących udział w postępowaniu, po dwie osoby wskazane przez 

oskarżyciela publicznego, oskarżyciela posiłkowego, oskarżyciela prywatnego 

i oskarżonego. Jeżeli jest kilku oskarżycieli lub oskarżonych, każdy z nich może żądać 

pozostawienia na sali rozpraw po jednej osobie. 

§ 1a. Podczas czynności z udziałem pokrzywdzonego przeprowadzanych na 

rozprawie z wyłączeniem jawności może być obecna osoba przez niego wskazana. 

§ 2. Przepisów § 1 i 1a nie stosuje się, jeżeli zachodzi obawa ujawnienia 

informacji niejawnych o klauzuli „tajne” lub „ściśle tajne”. 

§ 3. W razie wyłączenia 

jawności 

przewodniczący może 

zezwolić 

poszczególnym osobom na obecność na rozprawie.


## Art. 362. {#kpk-art-362}
Przewodniczący 

poucza 

obecnych 

o obowiązku 

zachowania 

w tajemnicy okoliczności ujawnionych na rozprawie toczącej się z wyłączeniem 

jawności i uprzedza o skutkach niedopełnienia tego obowiązku.


## Art. 363. {#kpk-art-363}
Z chwilą zgłoszenia wniosku o wyłączenie 

jawności rozprawa 

w zakresie tego wniosku odbywa się z wyłączeniem jawności, jeżeli o to wnosi strona 

lub sąd uzna to za potrzebne.


## Art. 364. {#kpk-art-364}
§ 1. Ogłoszenie wyroku odbywa się jawnie. 

§ 2. Jeżeli jawność rozprawy wyłączono w całości lub w części, przytoczenie 

powodów wyroku może nastąpić również z wyłączeniem jawności w całości lub 

w części. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 166/356 


# Rozdział 43
 

Przepisy ogólne o rozprawie głównej


## Art. 365. {#kpk-art-365}
Rozprawa odbywa się ustnie.


## Art. 366. {#kpk-art-366}
§ 1. Przewodniczący kieruje rozprawą i czuwa nad jej prawidłowym 

przebiegiem, bacząc, aby zostały wyjaśnione wszystkie istotne okoliczności sprawy. 

§ 2. Przewodniczący powinien dążyć do tego, aby rozstrzygnięcie sprawy 

nastąpiło na pierwszej rozprawie głównej.


## Art. 367. {#kpk-art-367}
§ 1. Przewodniczący umożliwia stronom wypowiedzenie się co do 

każdej kwestii podlegającej rozstrzygnięciu. 

§ 2. Jeżeli w jakiejkolwiek kwestii jedna ze stron zabiera głos, prawo głosu 

przysługuje również wszystkim innym stronom. Obrońcy oskarżonego i oskarżonemu 

przysługuje głos ostatni.


## Art. 367a. {#kpk-art-367a}
(uchylony)


## Art. 368. {#kpk-art-368}
§ 1. O przychylnym załatwieniu wniosku dowodowego strony, 

któremu inna strona nie sprzeciwiła się, rozstrzyga ostatecznie przewodniczący; 

w innych wypadkach sąd wydaje postanowienie. 

§ 2. Wniosku o dopuszczenie tego samego dowodu, zgłoszonego ponownie po 

oddaleniu w postępowaniu przed sądem poprzedniego wniosku, nie rozpoznaje się, 

jeżeli został on oparty na tych samych podstawach faktycznych. Wzmiankę o tym 

zamieszcza się w protokole.


## Art. 368a. {#kpk-art-368a}
§ 1. Jeżeli w toku rozprawy głównej w sprawie, w której akt 

oskarżenia pochodzi od oskarżyciela posiłkowego, oskarżony złożył wniosek 

o umorzenie postępowania na podstawie art. 17 § 1 pkt 9, wniosek podlega 

niezwłocznemu rozpoznaniu. Przepisu art. 349 § 7 nie stosuje się. Do czasu 

rozstrzygnięcia wniosku dokonuje się jedynie czynności niecierpiących zwłoki. 

§ 2. Na postanowienie w przedmiocie wniosku przysługuje zażalenie.


## Art. 369. {#kpk-art-369}
Dowody na poparcie oskarżenia powinny być w miarę możności 

przeprowadzone przed dowodami służącymi do obrony.


## Art. 370. {#kpk-art-370}
§ 1. Po swobodnym wypowiedzeniu się osoby przesłuchiwanej na 

wezwanie przewodniczącego, stosownie do art. 171 § 1, mogą zadawać jej pytania 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 167/356 

w następującym porządku: oskarżyciel publiczny, oskarżyciel posiłkowy, 

pełnomocnik oskarżyciela posiłkowego, oskarżyciel prywatny, pełnomocnik 

oskarżyciela prywatnego, biegły, obrońca, oskarżony, członkowie 

składu 

orzekającego. 

§ 2. Strona, na której wniosek świadek został dopuszczony, zadaje pytania przed 

pozostałymi stronami. 

§ 2a. W razie potrzeby członkowie składu orzekającego mogą zadawać 

dodatkowe pytania poza kolejnością. 

§ 3. W przypadku dopuszczenia dowodu z urzędu pytania jako pierwsi zadają 

członkowie składu orzekającego. 

§ 4. Przewodniczący uchyla pytania, o których mowa w art. 171 § 6, lub gdy 

z innych powodów uznaje je za niestosowne.


## Art. 371. {#kpk-art-371}
§ 1. Przy przesłuchaniu świadka nie powinni być obecni świadkowie, 

którzy jeszcze nie zostali przesłuchani. 

§ 2. Przewodniczący 

powinien 

przedsiębrać 

środki 

zapobiegające 

porozumiewaniu się osób przesłuchanych z osobami, które jeszcze nie zostały 

przesłuchane.


## Art. 372. {#kpk-art-372}
Przewodniczący wydaje wszelkie zarządzenia niezbędne do 

utrzymania na sali sądowej spokoju i porządku.


## Art. 373. {#kpk-art-373}
Od zarządzeń przewodniczącego wydanych na rozprawie głównej 

przysługuje odwołanie do składu orzekającego, chyba że sąd orzeka jednoosobowo.


## Art. 374. {#kpk-art-374}
§ 1. Oskarżony ma prawo brać udział w rozprawie.8) Przewodniczący 

lub sąd mogą uznać jego obecność za obowiązkową. 

§ 1a. W sprawach o zbrodnie obecność oskarżonego podczas czynności, 

o których mowa w art. 385 i art. 386, jest obowiązkowa. 

§ 2. Przewodniczący może wydać zarządzenie w celu uniemożliwienia 

oskarżonemu wydalenia się z sądu przed zakończeniem rozprawy. 

8) Zdanie pierwsze uznane za niezgodne z Konstytucją z dniem 26 sierpnia 2020 r. w związku z art. 
380 w związku z art. 354 pkt 2 w zakresie, w jakim nie przewiduje obowiązkowej obecności 
podejrzanego, o którym mowa w art. 380, na rozprawie w sprawie wniosku prokuratora o umorzenie 
postępowania z powodu niepoczytalności sprawcy i o zastosowanie środków zabezpieczających, na 
podstawie wyroku Trybunału Konstytucyjnego z dnia 19 sierpnia 2020 r. sygn. akt K 46/15 (Dz. U. 
poz. 1458). 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 168/356 

§ 3. Przewodniczący, na wniosek prokuratora, wyraża zgodę na jego udział w 

rozprawie przy użyciu urządzeń technicznych, umożliwiających udział w rozprawie 

na odległość z jednoczesnym bezpośrednim przekazem obrazu i dźwięku, jeżeli nie 

stoją temu na przeszkodzie względy techniczne. 

§ 4. Przewodniczący może zwolnić z obowiązku stawiennictwa na rozprawie 

oskarżonego, oskarżyciela posiłkowego albo oskarżyciela prywatnego, którzy są 

pozbawieni wolności, jeżeli zostanie zapewniony udział tych stron w rozprawie przy 

użyciu urządzeń technicznych, umożliwiających udział w rozprawie na odległość z 

jednoczesnym bezpośrednim przekazem obrazu i dźwięku. 

§ 5. W wypadku określonym w § 4 w rozprawie bierze udział w miejscu 

przebywania strony referendarz sądowy lub asystent sędziego, zatrudniony w sądzie, 

w którego okręgu strona przebywa, lub przedstawiciel administracji zakładu karnego 

lub aresztu śledczego, jeżeli strona przebywa w zakładzie karnym lub areszcie 

śledczym. 

§ 6. Obrońca bierze udział w rozprawie przeprowadzanej w sposób określony w 

§ 4 w miejscu przebywania oskarżonego, chyba że stawi się w tym celu w sądzie. 

§ 7. W wypadku gdy obrońca bierze udział w rozprawie przebywając w innym 

miejscu niż oskarżony, sąd na wniosek oskarżonego lub obrońcy może zarządzić 

przerwę na czas oznaczony, w celu kontynuacji rozprawy w tym samym dniu, aby 

umożliwić telefoniczny kontakt obrońcy z oskarżonym, chyba że złożenie wniosku w 

sposób oczywisty nie służy realizacji prawa do obrony, a w szczególności zmierza do 

zakłócenia lub nieuzasadnionego przedłużenia rozprawy. 

§ 8. Jeżeli zachodzi potrzeba udziału tłumacza w rozprawie przeprowadzanej w 

sposób określony w § 4, tłumacz bierze udział w rozprawie w miejscu przebywania 

oskarżonego niewładającego w wystarczającym stopniu językiem polskim lub w 

miejscu przebywania osoby, co do której zachodzą okoliczności określone w art. 204 

§ 1 pkt 1, chyba że przewodniczący zarządzi inaczej. 

§ 9. Przepisy art. 517ea stosuje się odpowiednio.


## Art. 375. {#kpk-art-375}
§ 1. Jeżeli oskarżony pomimo upomnienia go przez przewodniczącego 

zachowuje się nadal w sposób zakłócający porządek rozprawy lub godzący w powagę 

sądu, przewodniczący może wydalić go na pewien czas z sali rozprawy. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 169/356 

§ 2. Zezwalając oskarżonemu na powrót, przewodniczący niezwłocznie 

informuje go o przebiegu rozprawy w czasie jego nieobecności oraz umożliwia mu 

złożenie wyjaśnień co do przeprowadzonych w czasie jego nieobecności dowodów.


## Art. 376. {#kpk-art-376}
§ 1. Jeżeli oskarżony, którego obecność na 

rozprawie 

jest 

obowiązkowa, złożył już wyjaśnienia i opuścił 

salę rozprawy bez zezwolenia przewodniczącego, sąd może prowadzić rozprawę 

w dalszym ciągu pomimo nieobecności oskarżonego. Sąd zarządza zatrzymanie 

i przymusowe doprowadzenie oskarżonego, jeżeli uznaje jego obecność za niezbędną. 

Na postanowienie w przedmiocie zatrzymania i przymusowego doprowadzenia 

przysługuje zażalenie do innego równorzędnego składu tego sądu. 

§ 2. Przepis § 1 stosuje się odpowiednio, jeżeli oskarżony, którego obecność na 

rozprawie jest obowiązkowa, po złożeniu wyjaśnień, zawiadomiony o terminie 

rozprawy odroczonej lub przerwanej nie stawił się na tę rozprawę bez usprawied-

liwienia. 

§ 3. Jeżeli na rozprawę odroczoną lub przerwaną nie stawił się współoskarżony, 

który usprawiedliwił swoje niestawiennictwo, sąd może prowadzić rozprawę 

w zakresie niedotyczącym bezpośrednio nieobecnego oskarżonego, 

jeżeli nie 

ograniczy to jego prawa do obrony.


## Art. 377. {#kpk-art-377}
§ 1. Jeżeli oskarżony wprawił się ze swej winy w stan powodujący 

niezdolność do udziału w rozprawie lub w posiedzeniu, w których jego udział jest 

obowiązkowy, sąd może postanowić o prowadzeniu postępowania pomimo jego 

nieobecności, nawet jeżeli nie złożył jeszcze wyjaśnień. 

§ 2. Przed wydaniem postanowienia, o którym mowa w § 1, sąd zapoznaje się ze 

świadectwem lekarza, który stwierdził stan takiej niezdolności, lub przesłuchuje go 

w charakterze biegłego. Stan powodujący niezdolność oskarżonego do udziału 

w rozprawie można stwierdzić 

także na podstawie badania niepołączonego 

z naruszeniem integralności ciała, przeprowadzonego za pomocą stosownego 

urządzenia. 

§ 3. Jeżeli oskarżony, którego obecność na rozprawie lub posiedzeniu jest 

obowiązkowa, zawiadomiony o terminie rozprawy lub posiedzenia oświadcza, że nie 

weźmie udziału w rozprawie lub posiedzeniu, uniemożliwia doprowadzenie go na 

rozprawę lub posiedzenie albo zawiadomiony o nich osobiście nie stawia się na 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 170/356 

rozprawę lub posiedzenie bez usprawiedliwienia, sąd może prowadzić postępowanie 

bez 

jego udziału; sąd może 

jednak zarządzić zatrzymanie 

i przymusowe 

doprowadzenie oskarżonego. Na postanowienie w przedmiocie zatrzymania i przymu-

sowego doprowadzenia przysługuje zażalenie do innego równorzędnego składu tego 

sądu. 

§ 4. Jeżeli oskarżony nie złożył jeszcze wyjaśnień przed sądem, można 

zastosować art. 396 § 2 lub uznać za wystarczające odczytanie jego poprzednio 

złożonych wyjaśnień. Przesłuchania oskarżonego można dokonać z wykorzystaniem 

środków, o których mowa w art. 177 § 1a.


## Art. 378. {#kpk-art-378}
§ 1. Jeżeli w sprawie, w której oskarżony musi mieć obrońcę i korzysta 

z obrony z wyboru, obrońca lub oskarżony wypowiada stosunek obrończy, sąd, prezes 

sądu lub referendarz sądowy ustanawia obrońcę z urzędu, o ile oskarżony nie powołał 

obrońcy z wyboru. W razie potrzeby rozprawę przerywa się lub odracza. 

§ 2. W sprawie, w której oskarżony korzysta z obrońcy z urzędu, sąd na 

uzasadniony wniosek obrońcy lub oskarżonego zwalnia obrońcę z jego obowiązków 

i wyznacza oskarżonemu innego obrońcę z urzędu. 

§ 3. W wypadkach określonych w § 1 i 2 sąd podejmuje zarazem decyzję, czy 

dotychczasowy obrońca może bez uszczerbku dla prawa oskarżonego do obrony 

pełnić obowiązki do czasu podjęcia obrony przez nowego obrońcę.


## Art. 378a. {#kpk-art-378a}
§ 1. Jeżeli oskarżony lub obrońca nie stawił się na rozprawę, będąc 

zawiadomiony o jej terminie, sąd, w szczególnie uzasadnionych wypadkach, może 

przeprowadzić postępowanie dowodowe podczas jego nieobecności, chociażby 

usprawiedliwił należycie niestawiennictwo, a w szczególności przesłuchać świadków, 

którzy stawili się na rozprawę, nawet jeżeli oskarżony nie złożył jeszcze wyjaśnień. 

§ 2. W wypadku, o którym mowa w § 1, oskarżonego lub obrońcę należy 

wezwać lub zawiadomić o nowym terminie rozprawy, jeżeli termin ten nie był im 

znany. Przy doręczeniu wezwania lub zawiadomienia należy również doręczyć 

pouczenie, o którym mowa w § 7. 

§ 3. Jeżeli sąd przeprowadził postępowanie dowodowe podczas nieobecności 

oskarżonego lub obrońcy w wypadku, o którym mowa w § 1, oskarżony lub obrońca 

może najpóźniej na kolejnym 

terminie rozprawy, o którym był należycie 

zawiadomiony przy 

jednoczesnym braku procesowych przeszkód do 

jego 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 171/356 

stawiennictwa, 

złożyć wniosek o uzupełniające przeprowadzenie dowodu 

przeprowadzonego podczas jego nieobecności. Prawo do złożenia wniosku nie 

przysługuje, jeżeli okaże się, że nieobecność oskarżonego lub obrońcy na terminie 

rozprawy, na którym przeprowadzono postępowanie dowodowe na podstawie § 1, 

była nieusprawiedliwiona. 

§ 4. W razie niezłożenia wniosku w terminie, o którym mowa w § 3 zdanie 

pierwsze, prawo do jego złożenia wygasa i w dalszym postępowaniu nie jest 

dopuszczalne 

podnoszenie 

zarzutu 

naruszenia 

gwarancji 

procesowych, 

w szczególności prawa do obrony, wskutek przeprowadzenia tego dowodu podczas 

nieobecności oskarżonego lub obrońcy. 

§ 5. We wniosku o uzupełniające przeprowadzenie dowodu oskarżony lub 

obrońca ma obowiązek wykazać, że sposób przeprowadzenia dowodu podczas jego 

nieobecności naruszał gwarancje procesowe, w szczególności prawo do obrony. 

§ 6. W razie uwzględnienia wniosku o uzupełniające przeprowadzenie dowodu 

sąd przeprowadza dowód uzupełniająco, jedynie w zakresie, w którym wykazano 

naruszenie gwarancji procesowych, w szczególności prawa do obrony. 

§ 7. Jeżeli oskarżony lub obrońca stawi się na termin rozprawy, o którym mowa 

w § 3 zdanie pierwsze, przewodniczący poucza go o możliwości złożenia wniosku 

o uzupełniające przeprowadzenie dowodu przeprowadzonego podczas 

jego 

nieobecności oraz o treści przepisów § 4 i 5, a także umożliwia mu wypowiedzenie się 

co do tej kwestii.


## Art. 379. {#kpk-art-379}
§ 1. Gdy sąd wchodzi na salę lub ją opuszcza, wszyscy obecni wstają. 

§ 2. Wstaje również każda osoba, do której sąd się zwraca lub która do sądu 

przemawia, chyba że przewodniczący zwolni ją od tego obowiązku.


## Art. 380. {#kpk-art-380}
Przepisy dotyczące oskarżonego stosuje się odpowiednio do osoby, 

której prokurator zarzuca popełnienie czynu zabronionego w stanie niepoczytalności 

i wnosi o umorzenie postępowania oraz o zastosowanie wobec niej środków 

zabezpieczających. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 172/356 


# Rozdział 44
 

Rozpoczęcie rozprawy głównej


## Art. 381. {#kpk-art-381}
Rozprawę główną 

rozpoczyna wywołanie sprawy. Następnie 

przewodniczący sprawdza, czy wszyscy wezwani stawili się oraz czy nie ma 

przeszkód do rozpoznania sprawy.


## Art. 382. {#kpk-art-382}
W razie nieusprawiedliwionego niestawiennictwa oskarżonego, 

którego obecność jest obowiązkowa, przewodniczący zarządza jego natychmiastowe 

zatrzymanie i doprowadzenie lub przerywa w tym celu rozprawę albo też sąd ją 

odracza. Przepis art. 376 § 1 zdanie trzecie stosuje się.


## Art. 383. {#kpk-art-383}
(uchylony)


## Art. 384. {#kpk-art-384}
§ 1. Po sprawdzeniu obecności przewodniczący zarządza opuszczenie 

sali rozpraw przez świadków. Biegli pozostają na sali, jeżeli przewodniczący nie 

zarządzi inaczej. 

§ 2. Pokrzywdzony może wziąć udział w rozprawie, jeżeli się stawi, i pozostać 

na sali, choćby miał składać zeznania jako świadek. W tym wypadku sąd przesłuchuje 

go w pierwszej kolejności. 

§ 3. Uznając to za celowe sąd może zobowiązać pokrzywdzonego do obecności 

na rozprawie lub jej części. 

§ 4. (uchylony) 


# Rozdział 45
 

Przewód sądowy


## Art. 385. {#kpk-art-385}
§ 1. Przewód sądowy rozpoczyna się od zwięzłego przedstawienia 

przez oskarżyciela zarzutów oskarżenia. 

§ 1a. Jeżeli w rozprawie nie bierze udziału oskarżyciel, przewodniczący 

dokonuje zwięzłego przedstawienia zarzutów oskarżenia. 

§ 2. Jeśli wniesiono odpowiedź na akt oskarżenia, przewodniczący informuje 

o jej treści.


## Art. 386. {#kpk-art-386}
§ 1. Jeżeli 

oskarżony 

bierze 

udział w rozprawie 

głównej, 

przewodniczący, po przedstawieniu zarzutów oskarżenia, poucza go o prawie 

składania wyjaśnień, odmowy wyjaśnień lub odpowiedzi na pytania, składania 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 173/356 

wniosków dowodowych i konsekwencjach nieskorzystania z tego uprawnienia, po 

czym pyta go, czy przyznaje się do zarzucanego mu czynu oraz czy chce złożyć 

wyjaśnienia i jakie. 

§ 2. Po przesłuchaniu oskarżonego przewodniczący poucza go o prawie 

zadawania pytań osobom przesłuchiwanym oraz składania wyjaśnień co do każdego 

dowodu. 

§ 3. Przepisy § 1 i 2 stosuje się odpowiednio do oskarżonego, który stawi się po 

raz pierwszy na kolejnej rozprawie głównej.


## Art. 387. {#kpk-art-387}
§ 1. Do chwili zakończenia pierwszego przesłuchania wszystkich 

oskarżonych na rozprawie głównej oskarżony, któremu zarzucono przestępstwo 

zagrożone karą nieprzekraczającą 15 lat pozbawienia wolności, może złożyć wniosek 

o wydanie wyroku skazującego i wymierzenie mu określonej kary lub środka karnego, 

orzeczenie przepadku 

lub 

środka kompensacyjnego bez przeprowadzania 

postępowania dowodowego. Wniosek może również dotyczyć wydania określonego 

rozstrzygnięcia w przedmiocie poniesienia kosztów procesu. Jeżeli oskarżony nie ma 

obrońcy z wyboru, sąd może, na jego wniosek, wyznaczyć mu obrońcę z urzędu. 

§ 1a. Przed uwzględnieniem wniosku o wydanie wyroku skazującego sąd poucza 

obecnego oskarżonego o treści art. 447 § 5. 

§ 2. Sąd może uwzględnić wniosek o wydanie wyroku skazującego, gdy 

okoliczności popełnienia przestępstwa 

i wina nie budzą wątpliwości, a cele 

postępowania zostaną osiągnięte mimo nieprzeprowadzenia rozprawy w całości; 

uwzględnienie wniosku jest możliwe jedynie wówczas, gdy prokurator wyrazi zgodę, 

a pokrzywdzony należycie powiadomiony o terminie rozprawy oraz pouczony 

o możliwości zgłoszenia przez oskarżonego takiego wniosku nie zgłosi sprzeciwu. 

O treści wniosku należy powiadomić pokrzywdzonego, jeżeli wniosek został złożony 

przed powiadomieniem go o terminie rozprawy. 

§ 3. Sąd może uzależnić uwzględnienie wniosku oskarżonego od dokonania 

w nim wskazanej przez siebie zmiany. Przepis art. 341 § 3 stosuje się odpowiednio. 

§ 4. (uchylony) 

§ 5. Przychylając się do wniosku, sąd może uznać za ujawnione dowody 

wymienione w akcie oskarżenia lub dokumenty przedłożone przez stronę. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 174/356


## Art. 388. {#kpk-art-388}
Za zgodą obecnych stron sąd może przeprowadzić postępowanie 

dowodowe tylko częściowo, jeżeli wyjaśnienia oskarżonego przyznającego się do 

winy nie budzą wątpliwości.


## Art. 389. {#kpk-art-389}
§ 1. Jeżeli oskarżony nie stawił się na rozprawę, odmawia wyjaśnień 

lub wyjaśnia odmiennie niż poprzednio albo oświadcza, że pewnych okoliczności nie 

pamięta, wolno na rozprawie odczytywać tylko w odpowiednim zakresie protokoły 

jego wyjaśnień złożonych poprzednio w charakterze oskarżonego w tej lub innej 

sprawie w postępowaniu przygotowawczym 

lub przed sądem albo w innym 

postępowaniu przewidzianym przez ustawę. 

§ 2. Po odczytaniu protokołu przewodniczący zwraca się do oskarżonego 

o wypowiedzenie się co do jego treści i o wyjaśnienie zachodzących sprzeczności. 

§ 3. Wolno na rozprawie odczytać wyjaśnienia współoskarżonego, który zmarł.


## Art. 390. {#kpk-art-390}
§ 1. Oskarżony ma prawo być obecny przy wszystkich czynnościach 

postępowania dowodowego. 

§ 2. W wyjątkowych wypadkach, gdy należy się obawiać, że obecność 

oskarżonego mogłaby oddziaływać krępująco na wyjaśnienia współoskarżonego albo 

na zeznania świadka lub biegłego, przewodniczący może zarządzić, aby na czas 

przesłuchania danej osoby oskarżony opuścił salę sądową. Przepis art. 375 § 2 stosuje 

się odpowiednio. 

§ 3. W wypadkach przewidzianych w § 2 przewodniczący może 

również 

przeprowadzić przesłuchanie przy użyciu urządzeń technicznych umożliwiających 

przeprowadzenie 

tej czynności na odległość z jednoczesnym bezpośrednim 

przekazem obrazu i dźwięku. W miejscu składania wyjaśnień lub zeznań w czynności 

bierze udział referendarz sądowy, asystent sędziego lub urzędnik sądowy. 

§ 4. W sprawie o zagrożone karą pozbawienia wolności, której górna granica 

wynosi co najmniej 8 lat, umyślne przestępstwo przeciwko życiu i zdrowiu, przeciwko 

wolności lub przestępstwo z użyciem przemocy lub groźby bezprawnej, gdy należy 

się obawiać, że obecność oskarżonego mogłaby oddziaływać krępująco na 

pokrzywdzonego, zwłaszcza gdy uzasadnia 

to dotychczasowe zachowanie 

oskarżonego w toku postępowania, na wniosek pokrzywdzonego przewodniczący 

zarządza, aby na czas jego przesłuchania oskarżony opuścił salę sądową, chyba że 

przemawia przeciwko temu wzgląd na konieczność dokonania prawidłowych ustaleń 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 175/356 

faktycznych. O ile nie stoją temu na przeszkodzie względy techniczne lub 

organizacyjne, nakazując oskarżonemu opuszczenie sali sądowej przewodniczący 

umożliwia mu udział w rozprawie przy użyciu urządzeń, o których mowa w § 3; 

w takim przypadku w miejscu przebywania oskarżonego jest obecny referendarz 

sądowy, asystent sędziego lub urzędnik sądowy. 

§ 5. Jeżeli oskarżony, któremu nakazano opuszczenie sali sądowej na czas 

przesłuchania pokrzywdzonego, nie bierze udziału w rozprawie w sposób, o którym 

mowa w § 4, przepis art. 375 § 2 stosuje się odpowiednio.


## Art. 391. {#kpk-art-391}
§ 1. Jeżeli 

świadek bezpodstawnie odmawia zeznań, zeznaje 

odmiennie niż poprzednio albo oświadczy, że pewnych okoliczności nie pamięta, albo 

przebywa za granicą lub nie można mu było doręczyć wezwania, albo nie stawił się 

z powodu niedających się usunąć przeszkód lub przewodniczący zaniechał wezwania 

świadka na podstawie art. 350a, a także wtedy, gdy świadek zmarł, wolno odczytywać 

w odpowiednim zakresie protokoły złożonych poprzednio przez niego zeznań 

w postępowaniu przygotowawczym lub przed sądem w tej lub innej sprawie albo 

w innym postępowaniu przewidzianym przez ustawę. 

§ 1a. (uchylony) 

§ 1b. (uchylony) 

§ 1c. (uchylony) 

§ 1d. (uchylony) 

§ 2. W warunkach określonych w § 1, a także w wypadku określonym w art. 182 

§ 3, wolno również odczytywać na rozprawie protokoły złożonych poprzednio przez 

świadka wyjaśnień w charakterze oskarżonego. 

§ 3. Przepis art. 389 § 2 stosuje się odpowiednio.


## Art. 392. {#kpk-art-392}
§ 1. Wolno odczytywać na rozprawie głównej protokoły przesłuchania 

świadków i oskarżonych, sporządzone w postępowaniu przygotowawczym lub przed 

sądem albo w innym postępowaniu przewidzianym przez ustawę, gdy bezpośrednie 

przeprowadzenie dowodu nie jest niezbędne, a żadna z obecnych stron temu się nie 

sprzeciwia. 

§ 2. Sprzeciw strony, której zeznania lub wyjaśnienia nie dotyczą, nie stoi na 

przeszkodzie odczytaniu protokołu. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 176/356


## Art. 393. {#kpk-art-393}
§ 1. Wolno odczytywać na rozprawie protokoły oględzin, przeszukania 

i zatrzymania rzeczy, opinie biegłych, instytutów, zakładów lub instytucji, dane 

o karalności, wyniki wywiadu środowiskowego oraz wszelkie dokumenty urzędowe 

złożone w postępowaniu przygotowawczym 

lub 

sądowym albo w innym 

postępowaniu przewidzianym przez ustawę. Nie wolno jednak odczytywać notatek 

dotyczących czynności, z których wymagane jest sporządzenie protokołu. 

§ 2. Wolno również odczytywać zawiadomienie o przestępstwie, chyba że 

zostało złożone do protokołu, o którym mowa w art. 304a. 

§ 3. Mogą być odczytywane na rozprawie wszelkie dokumenty prywatne, 

powstałe poza postępowaniem karnym, w szczególności oświadczenia, publikacje, 

listy oraz notatki. 

§ 4. Wolno odczytywać na rozprawie protokoły zeznań świadka przesłuchanego 

w warunkach określonych w art. 184. Rozprawa jest wówczas niejawna; przepisów 

art. 361 § 1 i 1a nie stosuje się.


## Art. 393a. {#kpk-art-393a}
W warunkach określonych w art. 389 § 1 i 3, art. 391 § 1 i 2, art. 392 

i art. 393 wolno również odczytywać lub odtwarzać zapisy, o których mowa 

w art. 145 § 1 i art. 147 § 1–2b.


## Art. 394. {#kpk-art-394}
§ 1. Dane dotyczące osoby oskarżonego oraz wyniki wywiadu 

środowiskowego odczytuje się na żądanie oskarżonego lub obrońcy. 

§ 1a. (uchylony) 

§ 2. Protokoły i dokumenty podlegające odczytaniu na rozprawie odczytuje się: 

1) 

na wniosek strony, która nie miała możliwości zapoznania się z ich treścią; 

przepis art. 392 § 2 stosuje się odpowiednio, lub 

2) 

gdy sąd uzna to za niezbędne.


## Art. 394a. {#kpk-art-394a}
Protokoły 

i dokumenty, o których mowa w art. 389 § 1 

i 3, 

art. 391 § 1 

i 2, 

art. 392 § 1, 

art. 393, 

art. 393a 

i art. 394 § 1, 

odczytuje 

przewodniczący lub na jego zarządzenie członek składu orzekającego bądź 

protokolant.


## Art. 395. {#kpk-art-395}
Jeżeli nie stoją 

temu na przeszkodzie właściwości dowodów 

rzeczowych, na wniosek strony lub gdy sąd uzna to za niezbędne, sprowadza się je na 

salę rozpraw i udostępnia stronom, a w razie potrzeby – świadkom i biegłym. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 177/356


## Art. 396. {#kpk-art-396}
§ 1. Jeżeli strona wniosła o sprowadzenie dowodu rzeczowego lub sąd 

uznał to za niezbędne, a zapoznanie się z dowodem rzeczowym przez pełny skład sądu 

napotyka znaczne trudności albo jeżeli strony wyrażają na to zgodę, sąd wyznacza do 

tej czynności sędziego ze swego składu albo sąd wezwany. 

§ 1a. Przepis § 1 stosuje się odpowiednio w razie dopuszczenia dowodu 

z oględzin. 

§ 2. Sąd może zlecić przesłuchanie świadka sędziemu wyznaczonemu ze swego 

składu lub sądowi wezwanemu, w którego okręgu świadek przebywa, jeżeli świadek 

nie stawił się z powodu przeszkód zbyt trudnych do usunięcia. 

§ 3. W czynnościach wskazanych w § 1–2 mają prawo brać udział strony, 

obrońcy i pełnomocnicy. Oskarżonego pozbawionego wolności sprowadza się tylko 

wtedy, gdy sąd uzna to za konieczne. 

§ 4. Sędzia wyznaczony lub sąd wezwany może przeprowadzić także inny 

dowód, którego potrzeba wyłoni się w toku czynności wskazanych w § 1–2.


## Art. 396a. {#kpk-art-396a}
§ 1. Jeżeli dopiero w toku rozprawy ujawnią się istotne braki 

postępowania przygotowawczego, a ich usunięcie przez sąd uniemożliwiałoby 

wydanie prawidłowego orzeczenia w rozsądnym terminie, zaś przeszkód tych nie 

można usunąć, stosując przepis art. 396, sąd może przerwać albo odroczyć rozprawę, 

zakreślając oskarżycielowi publicznemu termin do przedstawienia dowodów, których 

przeprowadzenie pozwoliłoby na usunięcie dostrzeżonych braków. 

§ 2. Oskarżyciel publiczny w celu zebrania dowodów, o których mowa w § 1, 

może przedsięwziąć osobiście, a prokurator 

także zlecić Policji dokonanie 

niezbędnych czynności dowodowych. 

§ 3. Oskarżyciel publiczny w wypadku niemożności dotrzymania zakreślonego 

terminu może zwrócić się do sądu o jego przedłużenie. 

§ 4. Jeżeli oskarżyciel publiczny w wyznaczonym terminie nie przedstawi 

stosownych dowodów, sąd rozstrzyga na korzyść oskarżonego wątpliwości 

wynikające z nieprzeprowadzenia tych dowodów.


## Art. 397. {#kpk-art-397}
(uchylony)


## Art. 398. {#kpk-art-398}
§ 1. Jeżeli na podstawie okoliczności, które wyszły na jaw w toku 

rozprawy, oskarżyciel zarzucił oskarżonemu inny czyn oprócz objętego aktem 

oskarżenia, sąd może za zgodą oskarżonego rozpoznać nowe oskarżenie na tej samej 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 178/356 

rozprawie, chyba że zachodzi konieczność przeprowadzenia postępowania 

przygotowawczego co do nowego czynu. 

§ 2. W razie odroczenia rozprawy oskarżyciel wnosi nowy lub dodatkowy akt 

oskarżenia.


## Art. 399. {#kpk-art-399}
§ 1. Jeżeli w toku rozprawy okaże się, że nie wychodząc poza granice 

oskarżenia można czyn zakwalifikować według innego przepisu prawnego, sąd 

uprzedza o tym obecne na rozprawie strony. 

§ 2. Na wniosek oskarżonego można przerwać rozprawę w celu umożliwienia 

mu przygotowania się do obrony.


## Art. 400. {#kpk-art-400}
§ 1. Jeżeli po rozpoczęciu przewodu sądowego ujawni się, że czyn 

oskarżonego stanowi wykroczenie, sąd, nie przekazując sprawy właściwemu sądowi, 

rozpoznaje ją w tym samym składzie, stosując w dalszym jej toku przepisy Kodeksu 

postępowania w sprawach o wykroczenia. 

§ 2. Przepis § 1 stosuje się również w sprawach o wykroczenia popełnione przez 

żołnierzy w czynnej służbie wojskowej, z wyjątkiem terytorialnej służby wojskowej 

pełnionej dyspozycyjnie.


## Art. 401. {#kpk-art-401}
§ 1. Przewodniczący może przerwać 

rozprawę główną w celu 

przygotowania przez strony wniosków dowodowych lub sprowadzenia dowodu albo 

dla wypoczynku lub z innej ważnej przyczyny. 

§ 2. Każdorazowa przerwa w rozprawie może trwać nie dłużej niż 42 dni.


## Art. 402. {#kpk-art-402}
§ 1. 

Jeżeli przewodniczący, 

zarządzając przerwę, oznaczy 

jednocześnie czas i miejsce dalszego ciągu rozprawy, osoby obecne na rozprawie 

przerwanej, których obecność była obowiązkowa, są obowiązane stawić się w nowym 

terminie bez wezwania. Przepis art. 285 stosuje się odpowiednio. Osoby uprawnione 

do stawiennictwa nie muszą być zawiadamiane o nowym terminie, nawet jeśli nie 

uczestniczyły w rozprawie przerwanej. 

§ 1a. Oskarżonego, którego obecność jest obowiązkowa, nie wzywa się 

w sytuacjach określonych w art. 376 lub art. 377, jeżeli okres przerwy uniemożliwia 

jego wezwanie oraz stawienie się na rozprawę po przerwie. 

§ 2. Rozprawę przerwaną prowadzi się po przerwie w dalszym ciągu, a od 

początku – jeżeli skład sądu uległ zmianie albo sąd uzna to za konieczne. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 179/356 

§ 2a. Jeżeli w sprawie rozpoznawanej w składzie wieloosobowym zmianie 

z przyczyn losowych lub z powodu przeszkód prawnych uległ jeden z członków 

składu, rozprawę przerwaną można prowadzić po przerwie w dalszym ciągu, jeżeli nie 

zagraża to prawidłowości orzekania w sprawie. 

§ 3. W razie przekroczenia terminu przerwy rozprawę uważa się za odroczoną.


## Art. 403. {#kpk-art-403}
Orzeczenia zapadające w czasie przerwy w rozprawie wydaje się 

w składzie rozpoznającym sprawę, a w wypadku niemożności jego utworzenia – 

w takim samym składzie.


## Art. 404. {#kpk-art-404}
§ 1. Sąd może odroczyć rozprawę tylko wtedy, gdy zarządzenie 

przerwy nie byłoby wystarczające. 

§ 2. Rozprawę odroczoną prowadzi się w nowym terminie od początku. Sąd 

może wyjątkowo prowadzić rozprawę odroczoną w dalszym ciągu, chyba że skład 

sądu uległ zmianie. 

§ 2a. Jeżeli w sprawie rozpoznawanej w składzie wieloosobowym zmianie 

z przyczyn losowych lub z powodu przeszkód prawnych uległ jeden z członków 

składu, rozprawę odroczoną można prowadzić w dalszym ciągu, jeżeli nie zagraża to 

prawidłowości orzekania w sprawie. 

§ 3. W wypadku podjęcia postępowania zawieszonego przepis § 2 stosuje się 

odpowiednio.


## Art. 404a. {#kpk-art-404a}
(uchylony)


## Art. 404b. {#kpk-art-404b}
§ 1. W razie prowadzenia rozprawy w dalszym ciągu w wypadkach 

określonych w art. 402 § 2a lub art. 404 § 2a przed przystąpieniem do dalszych 

czynności dowodowych przewodniczący zarządza przerwę w rozprawie albo sąd 

rozprawę odracza na czas niezbędny do zapoznania się przez nowego członka składu 

orzekającego 

z dotychczasowym 

przebiegiem 

postępowania, 

w tym 

z przeprowadzonymi dowodami. 

§ 2. Nowy członek składu orzekającego, po zapoznaniu się z dotychczasowym 

przebiegiem postępowania, w tym z przeprowadzonymi dowodami, oświadcza na 

piśmie lub do protokołu rozprawy, czy i w jakim zakresie uznaje za konieczne 

uzupełniające przeprowadzenie dowodów przeprowadzonych przed jego wstąpieniem 

do składu orzekającego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 180/356 

§ 3. Sąd przeprowadza dowody wskazane w oświadczeniu, o którym mowa 

w § 2, chyba że jest to niemożliwe z przyczyn niezależnych od sądu.


## Art. 404c. {#kpk-art-404c}
§ 1. Jeżeli przewodniczący uzna, że zachodzi potrzeba oceny, czy 

przeprowadzone 

dowody 

pozwalają 

na 

rozstrzygnięcie w przedmiocie 

odpowiedzialności karnej jednego lub niektórych z oskarżonych, może zarządzić 

przerwę w rozprawie na czas niezbędny dla przeprowadzenia narady w tym zakresie 

(narada wstępna). Do narady wstępnej stosuje się odpowiednio przepisy art. 108, 

art. 109 i art. 111. 

§ 2. Jeżeli po naradzie wstępnej sąd uzna, że przeprowadzone dowody pozwalają 

na rozstrzygnięcie, o którym mowa w § 1, i wydanie wyroku (wyrok częściowy), 

przewodniczący informuje o tym oskarżyciela publicznego oraz strony, których 

interesu prawnego rozstrzygnięcie dotyczy. Przepisy art. 405 stosuje się odpowiednio. 

§ 3. Po zamknięciu przewodu sądowego w odniesieniu do oskarżonego lub 

oskarżonych, których odpowiedzialności karnej dotyczyła narada wstępna, a przed 

udzieleniem głosu stronom, przewodniczący zarządza przerwę w rozprawie albo sąd 

rozprawę odracza w odniesieniu do pozostałych oskarżonych. 

§ 4. Jeżeli w sprawie 

rozpoznawanej w składzie 

jednego 

sędziego 

przeprowadzone 

dowody 

pozwalają 

na 

rozstrzygnięcie w przedmiocie 

odpowiedzialności karnej jednego lub niektórych oskarżonych, przepisu § 1 nie 

stosuje się, a przepisy § 2 i 3 stosuje się odpowiednio. 

§ 5. Do postępowania po zamknięciu przewodu sądowego, o którym mowa 

w § 3, art. 406 oraz przepisy rozdziału 47 stosuje się odpowiednio, z tym że 

w przypadku, o którym mowa w art. 411 § 2, rozprawę prowadzi się w dalszym ciągu 

w odniesieniu do wszystkich oskarżonych. 

§ 6. Przepisów § 1–4 nie stosuje się, jeżeli: 

1) 

oskarżonemu, o którym mowa w § 1, zarzucono popełnienie przestępstwa 

w warunkach przestępczego współdziałania z oskarżonym nieobjętym zakresem 

narady wstępnej; 

2) 

czyn oskarżonego, o którym mowa w § 1, pozostaje z czynem zarzucanym 

innemu oskarżonemu w takim związku, że rozstrzygnięcie w przedmiocie jego 

odpowiedzialności karnej wywarłoby wpływ na ustalenia w przedmiocie 

odpowiedzialności karnej oskarżonego nieobjętego zakresem narady wstępnej; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 181/356 

3) wyrokiem częściowym nie mogą zostać objęte wszystkie czyny zarzucane 

oskarżonemu, o którym mowa w § 1; 

4) wydanie wyroku częściowego uniemożliwiłoby pokrzywdzonemu realizację 

jego uprawnień.


## Art. 405. {#kpk-art-405}
§ 1. Po przeprowadzeniu dowodów dopuszczonych w sprawie 

przewodniczący zapytuje strony, czy wnoszą o uzupełnienie postępowania 

dowodowego i w razie odpowiedzi przeczącej – zamyka przewód sądowy. 

§ 2. Z chwilą zamknięcia przewodu sądowego ujawnione są bez odczytywania 

wszystkie protokoły i dokumenty podlegające odczytaniu na rozprawie, które nie 

zostały odczytane. 

§ 3. Protokołami 

i dokumentami, o których mowa w § 2, są protokoły 

i dokumenty: 

1) wskazane przez oskarżyciela w akcie oskarżenia jako dowody, których 

przeprowadzenia na rozprawie głównej się on domaga, z wyjątkiem tych, co do 

których sąd oddalił wniosek dowodowy; 

2) wskazane we wniosku dowodowym strony, który został uwzględniony; 

3) 

dopuszczone przez sąd z urzędu. 

§ 4. O ujawnieniu bez odczytywania protokołów i dokumentów zamieszcza się 

wzmiankę w protokole 

rozprawy. Wskazywanie poszczególnych protokołów 

i dokumentów nie jest konieczne. 


# Rozdział 46
 

Głosy końcowe


## Art. 406. {#kpk-art-406}
§ 1. Po zamknięciu przewodu sądowego przewodniczący udziela głosu 

stronom, ich przedstawicielom oraz przedstawicielowi społecznemu. Głos zabierają 

w następującej kolejności: oskarżyciel publiczny, oskarżyciel posiłkowy, oskarżyciel 

prywatny, 

przedstawiciel 

społeczny, 

obrońca 

oskarżonego 

i oskarżony. 

Przedstawiciele procesowi stron zabierają głos przed stronami. 

§ 2. Jeżeli oskarżyciel ponownie zabiera głos, należy również udzielić głosu 

obrońcy i oskarżonemu.


## Art. 407. {#kpk-art-407}
(uchylony) 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 182/356 


# Rozdział 47
 

Wyrokowanie


## Art. 408. {#kpk-art-408}
Po wysłuchaniu głosów końcowych sąd niezwłocznie przystępuje do 

narady.


## Art. 409. {#kpk-art-409}
Sąd aż do ogłoszenia wyroku może wznowić przewód sądowy, 

zwłaszcza w wypadku przewidzianym w art. 399, albo też udzielić dodatkowego głosu 

uczestnikom postępowania, o których mowa w art. 406 § 1.


## Art. 410. {#kpk-art-410}
Podstawę wyroku może stanowić tylko całokształt okoliczności 

ujawnionych w toku rozprawy głównej.


## Art. 411. {#kpk-art-411}
§ 1. W sprawie zawiłej albo z innych ważnych powodów sąd może 

odroczyć wydanie wyroku na czas nieprzekraczający 14 dni. 

§ 2. W razie przekroczenia tego terminu rozprawę prowadzi się od początku. 

§ 3. W postanowieniu o odroczeniu wydania wyroku należy wskazać czas 

i miejsce jego ogłoszenia.


## Art. 412. {#kpk-art-412}
Niezwłocznie po ukończeniu głosowania sąd sporządza wyrok na 

piśmie.


## Art. 413. {#kpk-art-413}
§ 1. Każdy wyrok powinien zawierać: 

1) 

oznaczenie sądu, który go wydał, oraz sędziów, ławników, oskarżycieli 

i protokolanta; 

2) 

3) 

4) 

datę oraz miejsce rozpoznania sprawy i wydania wyroku; 

imię, nazwisko oraz inne dane określające tożsamość oskarżonego; 

przytoczenie opisu i kwalifikacji prawnej czynu, którego popełnienie oskarżyciel 

zarzucił oskarżonemu; 

5) 

rozstrzygnięcie sądu; 

6) wskazanie zastosowanych przepisów ustawy karnej. 

§ 2. Wyrok skazujący powinien ponadto zawierać: 

1) 

dokładne określenie przypisanego oskarżonemu czynu oraz jego kwalifikację 

prawną; 

2) 

rozstrzygnięcia co do kary i środków karnych, środków kompensacyjnych 

i przepadku, a w razie potrzeby – co do zaliczenia na ich poczet okresów 

wskazanych w art. 63 Kodeksu karnego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 183/356 

§ 3. Jeżeli zgłoszono zdanie odrębne, wyrok powinien również zawierać 

wzmiankę, o której mowa w art. 114 § 1.


## Art. 414. {#kpk-art-414}
§ 1. W razie stwierdzenia po rozpoczęciu przewodu sądowego 

okoliczności wyłączającej ściganie lub danych przemawiających za warunkowym 

umorzeniem postępowania, sąd wyrokiem umarza postępowanie albo umarza je 

warunkowo. Jednakże w razie stwierdzenia okoliczności wymienionych w art. 17 § 1 

pkt 1 i 2 sąd wydaje wyrok uniewinniający, chyba że sprawca w chwili czynu był 

niepoczytalny. 

§ 2. Umarzając postępowanie sąd stosuje odpowiednio art. 322 § 2 i 3, art. 323 

§ 1 i 2 oraz art. 340 § 2 i 3. 

§ 3. Sąd stosuje środek zabezpieczający wskazany w art. 93a § 2 Kodeksu 

karnego, w art. 22 § 3 pkt 5 i 6 Kodeksu karnego skarbowego lub orzeka przepadek 

przedmiotów wskazany w art. 45a Kodeksu karnego, jeżeli wyniki przewodu 

sądowego to uzasadniają, a umorzenie następuje z powodu niepoczytalności sprawcy 

w chwili popełnienia czynu. 

§ 4. Umarzając postępowanie warunkowo, sąd stosuje odpowiednio art. 341. 

§ 5. Przewidując możliwość warunkowego umorzenia postępowania albo 

możliwość orzeczenia kary z warunkowym zawieszeniem jej wykonania, sąd może 

wznowić przewód sądowy celem odpowiedniego zastosowania art. 341 § 3; wówczas 

sąd może zarządzić przerwę.


## Art. 415. {#kpk-art-415}
§ 1. W razie skazania oskarżonego lub warunkowego umorzenia 

postępowania w wypadkach wskazanych w ustawie sąd orzeka nawiązkę na rzecz 

pokrzywdzonego, obowiązek naprawienia, w całości lub w części, szkody lub 

zadośćuczynienia za doznaną krzywdę. Nawiązki na rzecz pokrzywdzonego, 

obowiązku naprawienia szkody lub zadość- 

uczynienia za doznaną krzywdę nie orzeka się, jeżeli roszczenie wynikające 

z popełnienia przestępstwa jest przedmiotem innego postępowania albo o roszczeniu 

tym prawomocnie orzeczono. 

§ 2. Jeżeli orzeczony obowiązek naprawienia szkody lub zadośćuczynienia za 

doznaną krzywdę albo nawiązka orzeczona na rzecz pokrzywdzonego nie pokrywają 

całej szkody lub nie stanowią pełnego zadośćuczynienia za doznaną krzywdę, 

pokrzywdzony może dochodzić dodatkowych roszczeń w postępowaniu cywilnym. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 184/356


## Art. 415a. {#kpk-art-415a}
§ 1. W razie skazania oskarżonego lub warunkowego umorzenia 

postępowania sąd uwzględnia wniosek prokuratora, o którym mowa w art. 91a. 

Wniosku nie uwzględnia się, jeżeli roszczenie o zwrot korzyści majątkowej lub 

przepadek świadczenia jest przedmiotem innego postępowania albo o roszczeniu tym 

prawomocnie orzeczono. 

§ 2. Orzeczenie w przedmiocie wniosku nie wyłącza możliwości dochodzenia 

roszczeń w postępowaniu cywilnym w zakresie nieuwzględnionym w tym orzeczeniu.


## Art. 416. {#kpk-art-416}
(uchylony)


## Art. 417. {#kpk-art-417}
Zaliczeniu na poczet orzeczonej kary podlega również okres 

tymczasowego aresztowania odbytego przez oskarżonego w innej sprawie, w której 

postępowanie toczyło się równocześnie, a zapadł w niej prawomocny wyrok 

uniewinniający, umorzono postępowanie albo odstąpiono od wymierzenia kary.


## Art. 418. {#kpk-art-418}
§ 1. Po podpisaniu wyroku przewodniczący ogłasza go publicznie; 

w czasie ogłaszania wyroku wszyscy obecni, z wyjątkiem sądu, stoją. 

§ 1a. Ogłaszając wyrok można pominąć treść zarzutów oskarżenia. 

§ 1b. Jeżeli ze względu na obszerność wyroku jego ogłoszenie wymagałoby 

zarządzenia przerwy lub odroczenia rozprawy, przewodniczący, ogłaszając wyrok, 

może poprzestać na zwięzłym przedstawieniu rozstrzygnięcia sądu oraz zastoso-

wanych przepisów ustawy karnej. Przed ogłoszeniem wyroku przewodniczący 

uprzedza obecnych o takim sposobie ogłoszenia wyroku i o jego przyczynie oraz 

poucza o możliwości zapoznania się z pełną treścią wyroku po jego ogłoszeniu 

w sekretariacie sądu. 

§ 2. Zgłoszenie zdania odrębnego podaje się do wiadomości wraz ze 

wskazaniem, w jakiej części i w jakim kierunku kwestionuje ono orzeczenie, a za 

zgodą członka składu orzekającego, który zgłosił to zdanie, także z jego imieniem 

i nazwiskiem. 

§ 3. Po ogłoszeniu przewodniczący lub jeden z członków składu orzekającego 

podaje ustnie najważniejsze powody wyroku, chyba że na ogłoszeniu nikt się nie 

stawił. 

§ 4. Po podaniu najważniejszych powodów wyroku, o których mowa w § 3, 

członek składu orzekającego, który zgłosił zdanie odrębne, może podać ustnie 

najważniejsze powody jego zgłoszenia. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 185/356


## Art. 418a. {#kpk-art-418a}
W wypadku wyrokowania na posiedzeniu odbywającym się 

z wyłączeniem jawności treść wyroku udostępnia się publicznie przez złożenie jego 

odpisu na okres 7 dni w sekretariacie sądu, o czym należy uczynić wzmiankę 

w protokole lub notatce urzędowej z posiedzenia.


## Art. 419. {#kpk-art-419}
§ 1. Niestawiennictwo stron, ich obrońców i pełnomocników nie stoi 

na przeszkodzie ogłoszeniu wyroku. 

§ 2. (uchylony)


## Art. 420. {#kpk-art-420}
§ 1. Jeżeli wyrok nie zawiera rozstrzygnięcia co do przepadku, 

zaliczenia okresu rzeczywistego pozbawienia wolności, okresu zatrzymania prawa 

jazdy lub innego odpowiedniego dokumentu lub okresu stosowania środków 

zapobiegawczych wymienionych w art. 276, nałożenia obowiązku zwrotu dokumentu 

uprawniającego do prowadzenia pojazdu albo dowodów rzeczowych, sąd orzeka 

o tym postanowieniem na posiedzeniu. 

§ 2. Jeżeli sąd nieprawidłowo zaliczył okres rzeczywistego pozbawienia 

wolności, okres zatrzymania prawa jazdy lub innego odpowiedniego dokumentu lub 

okres stosowania środków zapobiegawczych wymienionych w art. 276, stosuje się 

odpowiednio przepis § 1. 

§ 3. Strony mają prawo wziąć udział w posiedzeniu, jeżeli jego przedmiotem jest 

rozstrzygnięcie co do przepadku albo dowodów rzeczowych. Oskarżonego 

pozbawionego wolności sprowadza się na posiedzenie tylko wtedy, gdy prezes sądu 

lub sąd uzna to za konieczne. 

§ 4. Na postanowienia, o których mowa w § 1 i § 2, przysługuje zażalenie.


## Art. 421. {#kpk-art-421}
Osobie niebędącej oskarżonym, która zgłasza roszczenie do mienia 

objętego przepadkiem przedmiotów, przysługuje prawo dochodzenia swych roszczeń 

tylko w drodze postępowania cywilnego.


## Art. 422. {#kpk-art-422}
§ 1. W terminie zawitym 7 dni od daty ogłoszenia wyroku, strona, 

a w wypadku wyroku warunkowo umarzającego postępowanie, wydanego na 

posiedzeniu, także pokrzywdzony, mogą złożyć wniosek o sporządzenie na piśmie 

i doręczenie uzasadnienia wyroku. Sporządzenie uzasadnienia z urzędu nie zwalnia 

strony oraz pokrzywdzonego od złożenia wniosku o doręczenie uzasadnienia. 

Wniosek składa się na piśmie. 

2025-09-11 

 
 
 
 

Dodany § 1a w 
art. 422 wejdzie 
w życie z dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
1178). 

©Kancelaria Sejmu 

s. 186/356 

§ 1a. Wniosek, o którym mowa w § 1, może również złożyć podmiot 

zobowiązany określony w art. 91a. Przepis § 1 stosuje się odpowiednio. 

<§ 1b. Prokurator, obrońca lub pełnomocnik będący adwokatem lub radcą 

prawnym lub Prokuratoria Generalna Rzeczypospolitej Polskiej mogą złożyć 

wniosek, o którym mowa w § 1, przez umieszczenie jego treści w portalu 

informacyjnym.> 

§ 2. We wniosku należy wskazać, czy dotyczy całości wyroku czy też niektórych 

czynów, których popełnienie oskarżyciel zarzucił oskarżonemu, bądź też jedynie 

rozstrzygnięcia o karze i o innych konsekwencjach prawnych czynu. Wniosek 

niepochodzący od oskarżonego powinien również wskazywać tego z oskarżonych, 

którego dotyczy. 

§ 2a. Dla oskarżonego pozbawionego wolności, który nie ma obrońcy i – 

pomimo złożenia wniosku o doprowadzenie go na termin rozprawy, na którym 

ogłoszono wyrok – nie był obecny podczas ogłoszenia wyroku, termin wymieniony 

w § 1 biegnie od daty doręczenia mu wyroku. 

§ 3. Prezes sądu odmawia przyjęcia wniosku złożonego przez osobę 

nieuprawnioną, po terminie lub jeżeli zachodzą okoliczności, o których mowa 

w art. 120 § 2. Na zarządzenie przysługuje zażalenie. 

§ 4. Zarządzenie, o którym mowa w § 3, może wydać również referendarz 

sądowy.


## Art. 423. {#kpk-art-423}
§ 1. Uzasadnienie wyroku powinno być sporządzone w ciągu 14 dni od 

daty wpływu do sądu wniosku o sporządzenie uzasadnienia, a w wypadku 

sporządzenia uzasadnienia z urzędu – od daty ogłoszenia wyroku; w sprawie zawiłej 

lub z innej ważnej przyczyny, w razie niemożności sporządzenia uzasadnienia 

w terminie, prezes sądu może przedłużyć ten termin na czas oznaczony. 

§ 1a. W wypadku złożenia wniosku o uzasadnienie wyroku w części odnoszącej 

się do niektórych czynów, których popełnienie oskarżyciel zarzucił oskarżonemu, 

bądź też jedynie do rozstrzygnięcia o karze i o innych konsekwencjach prawnych 

czynu lub w części odnoszącej się do niektórych oskarżonych sąd może ograniczyć 

zakres uzasadnienia do tych tylko części wyroku, których wniosek dotyczy. 

§ 2. Wyrok z uzasadnieniem doręcza się temu, kto złożył wniosek na podstawie 

art. 422. Przepis art. 100 § 7 stosuje się odpowiednio. 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 187/356


## Art. 424. {#kpk-art-424}
§ 1. Uzasadnienie powinno zawierać zwięzłe: 

1) wskazanie, jakie fakty sąd uznał za udowodnione lub nieudowodnione, na jakich 

w tej mierze oparł się dowodach i dlaczego nie uznał dowodów przeciwnych; 

2) wyjaśnienie podstawy prawnej wyroku. 

§ 2. W uzasadnieniu wyroku należy ponadto przytoczyć okoliczności, które sąd 

miał na względzie przy wymiarze kary, a zwłaszcza przy zastosowaniu 

nadzwyczajnego złagodzenia kary, środków zabezpieczających oraz przy innych 

rozstrzygnięciach zawartych w wyroku. 

§ 3. W wypadku złożenia wniosku o uzasadnienie wyroku jedynie co do 

rozstrzygnięcia o karze 

i o innych konsekwencjach prawnych czynu albo 

o uzasadnienie wyroku wydanego w trybie art. 343, art. 343a lub art. 387 uzasadnienie 

powinno zawierać co najmniej wyjaśnienie podstawy prawnej tego wyroku oraz 

wskazanych rozstrzygnięć.
