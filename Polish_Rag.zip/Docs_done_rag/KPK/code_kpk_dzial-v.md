---
id: "code_kpk_dzial-v"
title: "KPK — DZIAŁ V"
source_pdf: "D19970555Lj (1).pdf"
dz_u: "Dz. U. 1997 Nr 89 poz. 555"
status: "obowiązujący"
last_consolidated: "2025-09-11"
law: "Kodeks postępowania karnego"
tags: ["kpk", "kodeks", "postępowanie karne"]
articles_range: {"first": "167", "last": "242"}
---

# DZIAŁ V

## Art. 167. {#kpk-art-167}
Dowody przeprowadza się na wniosek stron albo z urzędu.


## Art. 168. {#kpk-art-168}
Fakty powszechnie znane nie wymagają dowodu. To samo dotyczy 

faktów znanych z urzędu, należy jednak zwrócić na nie uwagę stron. Nie wyłącza to 

dowodu przeciwnego.


## Art. 168a. {#kpk-art-168a}
Dowodu nie można uznać za niedopuszczalny wyłącznie na tej 

podstawie, że został uzyskany z naruszeniem przepisów postępowania lub za pomocą 

czynu zabronionego, o którym mowa w art. 1 § 1 Kodeksu karnego, chyba że dowód 

został uzyskany w związku z pełnieniem przez funkcjonariusza publicznego 

obowiązków 

służbowych, w wyniku: zabójstwa, umyślnego 

spowodowania 

uszczerbku na zdrowiu lub pozbawienia wolności.


## Art. 168b. {#kpk-art-168b}
Jeżeli w wyniku kontroli operacyjnej zarządzonej na wniosek 

uprawnionego organu na podstawie przepisów szczególnych uzyskano dowód 

popełnienia przez osobę, wobec której kontrola operacyjna była stosowana, innego 

przestępstwa ściganego z urzędu lub przestępstwa skarbowego niż przestępstwo objęte 

zarządzeniem kontroli operacyjnej 

lub przestępstwa ściganego z urzędu 

lub 

przestępstwa skarbowego popełnionego przez inną osobę niż objętą zarządzeniem 

kontroli operacyjnej, prokurator podejmuje decyzję w przedmiocie wykorzystania 

tego dowodu w postępowaniu karnym.


## Art. 169. {#kpk-art-169}
§ 1. We wniosku dowodowym należy podać oznaczenie dowodu oraz 

okoliczności, które mają być udowodnione. Można 

także określić sposób 

przeprowadzenia dowodu. 

§ 2. Wniosek dowodowy może zmierzać do wykrycia lub oceny właściwego 

dowodu.


## Art. 170. {#kpk-art-170}
§ 1. Oddala się wniosek dowodowy, jeżeli: 

1) 

przeprowadzenie dowodu jest niedopuszczalne; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 67/356 

2) 

okoliczność, która ma być udowodniona, nie ma znaczenia dla rozstrzygnięcia 

sprawy albo jest już udowodniona zgodnie z twierdzeniem wnioskodawcy; 

dowód jest nieprzydatny do stwierdzenia danej okoliczności; 

dowodu nie da się przeprowadzić; 

3) 

4) 

5) wniosek dowodowy w sposób oczywisty zmierza do przedłużenia postępowania; 

6) wniosek dowodowy został złożony po zakreślonym przez organ procesowy 

terminie, o którym strona składająca wniosek została zawiadomiona. 

§ 1a. Nie można oddalić wniosku dowodowego na podstawie § 1 pkt 5 lub 6, 

jeżeli okoliczność, która ma być udowodniona, ma istotne znaczenie dla ustalenia, czy 

został popełniony czyn zabroniony, czy stanowi on przestępstwo i jakie, czy czyn 

zabroniony został popełniony w warunkach, o których mowa w art. 64 lub art. 65 

Kodeksu karnego, lub czy zachodzą warunki do orzeczenia pobytu w zakładzie 

psychiatrycznym na podstawie art. 93g Kodeksu karnego. 

§ 2. Nie można oddalić wniosku dowodowego na 

tej podstawie, że 

dotychczasowe dowody wykazały przeciwieństwo tego, co wnioskodawca zamierza 

udowodnić. 

§ 3. Oddalenie wniosku dowodowego następuje w formie postanowienia. 

§ 4. Oddalenie wniosku dowodowego nie stoi na przeszkodzie późniejszemu 

dopuszczeniu dowodu, chociażby nie ujawniły się nowe okoliczności.


## Art. 171. {#kpk-art-171}
§ 1. Osobie 

przesłuchiwanej 

należy 

umożliwić 

swobodne 

wypowiedzenie się w granicach określonych celem danej czynności, a dopiero 

następnie można zadawać pytania zmierzające do uzupełnienia, wyjaśnienia lub 

kontroli wypowiedzi. 

§ 2. Prawo zadawania pytań mają, oprócz organu przesłuchującego, strony, 

obrońcy, pełnomocnicy oraz biegli. Pytania zadaje się osobie przesłuchiwanej 

bezpośrednio, chyba że organ przesłuchujący zarządzi inaczej. 

§ 3. Jeżeli osoba przesłuchiwana nie ukończyła 18 lat, czynności z jej udziałem 

powinny być, w miarę możliwości, przeprowadzone w obecności przedstawiciela 

ustawowego, faktycznego opiekuna lub osoby pełnoletniej wskazanej przez osobę 

przesłuchiwaną, chyba że dobro postępowania stoi temu na przeszkodzie lub 

sprzeciwia się temu osoba przesłuchiwana. 

§ 4. Nie wolno zadawać pytań sugerujących osobie przesłuchiwanej treść 

odpowiedzi. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 68/356 

§ 4a. Pytania zadawane świadkowi nie mogą dotyczyć jego życia seksualnego, 

chyba że jest to niezbędne dla rozstrzygnięcia sprawy. 

§ 5. Niedopuszczalne jest: 

1) wpływanie na wypowiedzi osoby przesłuchiwanej za pomocą przymusu lub 

groźby bezprawnej; 

2) 

stosowanie hipnozy albo środków chemicznych lub technicznych wpływających 

na procesy psychiczne osoby przesłuchiwanej albo mających na celu kontrolę 

nieświadomych reakcji jej organizmu w związku z przesłuchaniem. 

§ 6. Organ przesłuchujący uchyla pytania określone w § 4 lub 4a, jak również 

pytania nieistotne. 

§ 7. Wyjaśnienia, 

zeznania oraz oświadczenia 

złożone w warunkach 

wyłączających swobodę wypowiedzi lub uzyskane wbrew zakazom wymienionym 

w § 5 nie mogą stanowić dowodu. 

§ 8. Przed pierwszym przesłuchaniem osoba, o której mowa w § 3, otrzymuje 

informacje o przebiegu, sposobie i warunkach przesłuchania. Informacje zawierają 

opisowe lub graficzne przedstawienie przebiegu, sposobu i warunków przesłuchania. 

Pomiędzy doręczeniem informacji a terminem przesłuchania powinno upłynąć co 

najmniej 3 dni, chyba że dobro postępowania stoi temu na przeszkodzie. 

§ 9. Minister Sprawiedliwości określi, w drodze rozporządzenia, wzór informacji 

o przebiegu, sposobie i warunkach przesłuchania dla osób, o których mowa w § 3, 

odrębnie dla podejrzanego i świadka, uwzględniając potrzebę zrozumienia tych 

informacji przez osoby przesłuchiwane.


## Art. 172. {#kpk-art-172}
Osoby przesłuchiwane mogą być konfrontowane w celu wyjaśnienia 

sprzeczności. Konfrontacja nie jest dopuszczalna w wypadku określonym w art. 184.


## Art. 173. {#kpk-art-173}
§ 1. Osobie przesłuchiwanej można okazać inną osobę, jej wizerunek 

lub rzecz w celu jej rozpoznania. Okazanie powinno być przeprowadzone tak, aby 

wyłączyć sugestię. 

§ 2. W razie potrzeby okazanie można przeprowadzić również tak, aby wyłączyć 

możliwość rozpoznania osoby przesłuchiwanej przez osobę rozpoznawaną. 

§ 3. Podczas okazania osoba okazywana powinna znajdować się w grupie 

obejmującej łącznie co najmniej cztery osoby. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 69/356 

§ 4. Minister Sprawiedliwości, w porozumieniu z ministrem właściwym do 

spraw wewnętrznych, określi, w drodze rozporządzenia, warunki 

techniczne 

przeprowadzenia okazania, mając na uwadze konieczność zapewnienia sprawnego 

toku postępowania, a także właściwej realizacji gwarancji procesowych 

jej 

uczestników.


## Art. 174. {#kpk-art-174}
Dowodu z wyjaśnień oskarżonego lub z zeznań świadka nie wolno 

zastępować treścią pism, zapisków lub notatek urzędowych. 


# Rozdział 20
 

Wyjaśnienia oskarżonego


## Art. 175. {#kpk-art-175}
§ 1. Oskarżony ma prawo składać wyjaśnienia; może jednak bez 

podania powodów odmówić odpowiedzi na poszczególne pytania lub odmówić 

składania wyjaśnień. O prawie tym należy go pouczyć. 

§ 2. Obecny przy czynnościach dowodowych oskarżony ma prawo składać 

wyjaśnienia co do każdego dowodu.


## Art. 176. {#kpk-art-176}
§ 1. W postępowaniu przygotowawczym oskarżonemu należy, na jego 

żądanie lub jego obrońcy, umożliwić w toku przesłuchania złożenie wyjaśnień na 

piśmie. Przesłuchujący podejmie w tym wypadku środki zapobiegające porozumieniu 

się oskarżonego z innymi osobami w czasie spisywania wyjaśnień. 

§ 2. Przesłuchujący może z ważnych powodów odmówić zgody na złożenie 

przez oskarżonego wyjaśnień na piśmie. 

§ 3. (uchylony) 

§ 4. Pisemne wyjaśnienia oskarżonego, podpisane przez niego, z zaznaczeniem 

daty ich złożenia, stanowią załącznik do protokołu. 


# Rozdział 21
 

Świadkowie


## Art. 177. {#kpk-art-177}
§ 1. Każda osoba wezwana w charakterze świadka ma obowiązek 

stawić się i złożyć zeznania. 

§ 1a. Przesłuchanie świadka może nastąpić przy użyciu urządzeń technicznych 

umożliwiających przeprowadzenie tej czynności na odległość z jednoczesnym 

bezpośrednim przekazem obrazu i dźwięku. W postępowaniu przygotowawczym, 

w czynności przeprowadzanej przez prokuratora, w miejscu przebywania świadka 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 70/356 

bierze udział aplikant prokuratorski, asystent prokuratora lub urzędnik zatrudniony 

w prokuraturze, a w postępowaniu przed sądem – aplikant sędziowski, referendarz 

sądowy, asystent sędziego lub urzędnik zatrudniony w sądzie, w którego okręgu 

świadek przebywa. 

§ 1b. W miejscu przebywania świadka przesłuchiwanego w sposób określony w 

§ 1a, zamiast osób wskazanych w tym przepisie, może być obecny: 

1) 

przedstawiciel administracji zakładu karnego lub aresztu śledczego – jeżeli 

świadek przebywa w zakładzie karnym lub areszcie śledczym; 

2) 

urzędnik konsularny – jeżeli świadek będący obywatelem polskim przebywa za 

granicą. 

§ 1c. Warunki techniczne przeprowadzenia czynności przesłuchania świadka 

w sposób określony w § 1a w postępowaniu przygotowawczym zapewnia prokurator. 

§ 1d. Do czynności przesłuchania świadka przeprowadzanej w postępowaniu 

przygotowawczym przez organ prowadzący postępowanie, niebędący prokuratorem, 

przepisy § 1a i 1b stosuje się odpowiednio, z tym że w czynności przeprowadzanej 

w miejscu przebywania świadka bierze udział funkcjonariusz lub inny pracownik 

upoważniony przez kierownika organu prowadzącego postępowanie przygotowawcze. 

Warunki techniczne przeprowadzenia czynności przesłuchania świadka zapewnia 

organ prowadzący postępowanie. 

§ 2. Świadka, który nie może się stawić na wezwanie z powodu choroby, 

kalectwa lub innej niedającej się pokonać przeszkody, można przesłuchać w miejscu 

jego pobytu.


## Art. 178. {#kpk-art-178}
Nie wolno przesłuchiwać jako świadków: 

1) 

obrońcy albo adwokata lub radcy prawnego działającego na podstawie art. 245 

§ 1, co do faktów, o których dowiedział się udzielając porady prawnej lub 

prowadząc sprawę; 

2) 

duchownego co do faktów, o których dowiedział się przy spowiedzi.


## Art. 178a. {#kpk-art-178a}
Nie wolno przesłuchiwać jako świadka mediatora co do faktów, 

o których dowiedział się od oskarżonego 

lub pokrzywdzonego prowadząc 

postępowanie mediacyjne, z wyłączeniem informacji o przestępstwach, o których 

mowa w art. 240 § 1 Kodeksu karnego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 71/356


## Art. 179. {#kpk-art-179}
§ 1. Osoby obowiązane do zachowania w tajemnicy informacji 

niejawnych o klauzuli tajności „tajne” lub „ściśle tajne” mogą być przesłuchane co do 

okoliczności, na które rozciąga się ten obowiązek, tylko po zwolnieniu tych osób od 

obowiązku zachowania tajemnicy przez uprawniony organ przełożony. 

§ 2. Zwolnienia wolno odmówić tylko wtedy, gdyby złożenie zeznania 

wyrządzić mogło poważną szkodę państwu. 

§ 3. Sąd lub prokurator może zwrócić się do właściwego naczelnego organu 

administracji rządowej o zwolnienie świadka od obowiązku zachowania tajemnicy, 

jeżeli ustawy szczególne nie stanowią inaczej.


## Art. 180. {#kpk-art-180}
§ 1. Osoby obowiązane do zachowania w tajemnicy informacji 

niejawnych o klauzuli tajności „zastrzeżone” lub „poufne” lub tajemnicy związanej 

z wykonywaniem zawodu lub funkcji mogą odmówić zeznań co do okoliczności, 

na które rozciąga się ten obowiązek, chyba że sąd lub prokurator dla dobra wymiaru 

sprawiedliwości zwolni te osoby od obowiązku zachowania tajemnicy, jeżeli ustawy 

szczególne nie stanowią inaczej. Na postanowienie w tym przedmiocie przysługuje 

zażalenie. 

§ 2. Osoby obowiązane do zachowania tajemnicy notarialnej, adwokackiej, radcy 

prawnego, doradcy podatkowego, lekarskiej, dziennikarskiej lub statystycznej oraz 

tajemnicy Prokuratorii Generalnej, mogą być przesłuchiwane co do faktów objętych 

tą tajemnicą tylko wtedy, gdy jest to niezbędne dla dobra wymiaru sprawiedliwości, a 

okoliczność nie może być ustalona na podstawie innego dowodu. W postępowaniu 

przygotowawczym w przedmiocie przesłuchania lub zezwolenia na przesłuchanie 

decyduje sąd, na posiedzeniu bez udziału stron, w terminie nie dłuższym niż 7 dni od 

daty doręczenia wniosku prokuratora. Na postanowienie sądu przysługuje zażalenie. 

§ 3. Zwolnienie dziennikarza od obowiązku zachowania tajemnicy nie może 

dotyczyć danych umożliwiających identyfikację autora materiału prasowego, listu do 

redakcji lub innego materiału o tym charakterze, jak również identyfikację osób 

udzielających informacji opublikowanych lub przekazanych do opublikowania, jeżeli 

osoby te zastrzegły nieujawnianie powyższych danych. 

§ 4. Przepisu § 3 nie stosuje się, jeżeli informacja dotyczy przestępstwa, 

o którym mowa w art. 240 § 1 Kodeksu karnego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 72/356 

§ 5. Odmowa przez dziennikarza ujawnienia danych, o których mowa w § 3, nie 

uchyla jego odpowiedzialności za przestępstwo, którego dopuścił się publikując 

informację.


## Art. 181. {#kpk-art-181}
§ 1. W wypadkach 

przewidzianych 

w art. 179 

i art. 180 sąd 

przesłuchuje taką osobę na rozprawie z wyłączeniem jawności. Nie dotyczy to 

wypadku, gdy zwolnienie z tajemnicy nastąpiło na podstawie art. 40 ust. 2 pkt 4, 

art. 40 ust. 3, art. 40 ust. 3b i 3c ustawy z dnia 5 grudnia 1996 r. o zawodach lekarza 

i lekarza dentysty (Dz. U. z 2024 r. poz. 1287), art. 14 ust. 2 pkt 3, art. 14 ust. 3 lub 

art. 14 ust. 6 i 7 ustawy z dnia 6 listopada 2008 r. o prawach pacjenta i Rzeczniku 

Praw Pacjenta (Dz. U. z 2024 r. poz. 581), w przewidzianym przez te ustawy zakresie. 

§ 1a. Jeżeli zwolnienie z tajemnicy nastąpiło na podstawie i na zasadach, 

o których mowa w § 1 zdanie drugie, okoliczności objęte tajemnicą, które zostały 

ujawnione na rozprawie z wyłączeniem jawności, mogą być rozpowszechniane 

publicznie przez osobę, której zgoda była wymagana do zwolnienia z tej tajemnicy. 

§ 2. Minister Sprawiedliwości określi, w drodze rozporządzenia, sposób 

sporządzania, przechowywania i udostępniania protokołów przesłuchań oskarżonych, 

świadków, biegłych i kuratorów, a także innych dokumentów lub przedmiotów, na 

które rozciąga się obowiązek zachowania w tajemnicy informacji niejawnych albo 

zachowania tajemnicy związanej z wykonywaniem zawodu lub funkcji, jak również 

dopuszczalny sposób powoływania się na 

takie przesłuchania, dokumenty 

i przedmioty w orzeczeniach i pismach procesowych, mając na uwadze konieczność 

zapewnienia właściwej ochrony tajemnicy przed nieuprawnionym ujawnieniem.


## Art. 182. {#kpk-art-182}
§ 1. Osoba najbliższa dla oskarżonego może odmówić zeznań. 

§ 2. Prawo odmowy zeznań trwa mimo ustania małżeństwa lub przysposobienia. 

§ 3. Prawo odmowy zeznań przysługuje także świadkowi, który w innej toczącej 

się sprawie jest oskarżony o współudział w przestępstwie objętym postępowaniem.


## Art. 183. {#kpk-art-183}
§ 1. Świadek może uchylić się od odpowiedzi na pytanie, jeżeli 

udzielenie odpowiedzi mogłoby narazić jego lub osobę dla niego najbliższą na 

odpowiedzialność za przestępstwo lub przestępstwo skarbowe. 

§ 2. Świadek może żądać, aby przesłuchano go na rozprawie z wyłączeniem 

jawności, jeżeli treść zeznań mogłaby narazić na hańbę jego lub osobę dla niego 

najbliższą. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 73/356


## Art. 184. {#kpk-art-184}
§ 1. Jeżeli zachodzi uzasadniona obawa niebezpieczeństwa dla życia, 

zdrowia, wolności albo mienia w znacznych rozmiarach świadka lub osoby dla niego 

najbliższej, sąd, a w postępowaniu przygotowawczym prokurator, może wydać 

postanowienie o zachowaniu w tajemnicy okoliczności umożliwiających ujawnienie 

tożsamości świadka, w tym danych osobowych, jeżeli nie mają one znaczenia dla 

rozstrzygnięcia w sprawie. Postępowanie w tym zakresie toczy się bez udziału stron 

i objęte jest tajemnicą jako informacja niejawna o klauzuli tajności „tajne” lub „ściśle 

tajne”. W postanowieniu pomija się okoliczności, o których mowa w zdaniu 

pierwszym. 

§ 2. W razie wydania postanowienia określonego w § 1 okoliczności, o których 

mowa w tym przepisie, pozostają wyłącznie do wiadomości sądu i prokuratora, a gdy 

zachodzi konieczność – również funkcjonariusza Policji prowadzącego postępowanie. 

Protokół przesłuchania świadka wolno udostępniać oskarżonemu lub obrońcy tylko 

w sposób uniemożliwiający ujawnienie okoliczności, o których mowa w § 1. 

§ 3. Świadka przesłuchuje prokurator, a także sąd, który może zlecić wykonanie 

tej czynności sędziemu wyznaczonemu ze swojego składu – w miejscu i w sposób 

uniemożliwiający ujawnienie okoliczności, o których mowa w § 1. W przesłuchaniu 

świadka przez sąd lub sędziego wyznaczonego mają prawo wziąć udział prokurator, 

oskarżony i jego obrońca. Przepis art. 396 § 3 zdanie drugie stosuje się odpowiednio. 

§ 4. W razie przesłuchania świadka przy użyciu urządzeń 

technicznych 

umożliwiających przeprowadzenie tej czynności na odległość, w protokole czynności 

z udziałem specjalistów należy wskazać ich imiona, nazwiska, specjalności i rodzaj 

wykonywanej czynności. Przepisu art. 205 § 3 nie stosuje się. 

§ 5. Na postanowienie w sprawie zachowania w tajemnicy okoliczności, 

o których mowa w § 1, świadkowi i oskarżonemu, a w postępowaniu przed sądem 

także prokuratorowi, przysługuje w terminie 3 dni zażalenie. Zażalenie na 

postanowienie prokuratora rozpoznaje sąd właściwy do rozpoznania sprawy. 

Postępowanie dotyczące zażalenia toczy się bez udziału stron i jest objęte tajemnicą 

jako informacja niejawna o klauzuli tajności „tajne” lub „ściśle tajne”. 

§ 6. W razie uwzględnienia zażalenia protokół przesłuchania świadka podlega 

zniszczeniu; o zniszczeniu protokołu należy uczynić wzmiankę w aktach sprawy. 

§ 7. Świadek może, do czasu zamknięcia przewodu sądowego przed sądem 

pierwszej instancji, wystąpić z wnioskiem o uchylenie postanowienia, o którym mowa 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 74/356 

w § 1. Na postanowienie w przedmiocie wniosku służy zażalenie. Przepis § 5 stosuje 

się odpowiednio. W razie uwzględnienia wniosku protokół przesłuchania świadka 

podlega ujawnieniu w całości. 

§ 8. Jeżeli okaże się, że w czasie wydania postanowienia, o którym mowa w § 1, 

nie istniała uzasadniona obawa niebezpieczeństwa dla życia, zdrowia, wolności albo 

mienia w znacznych rozmiarach świadka lub osoby dla niego najbliższej albo że 

świadek złożył świadomie fałszywe zeznania lub nastąpiło jego ujawnienie, 

prokurator w postępowaniu przygotowawczym, a w postępowaniu sądowym sąd, na 

wniosek prokuratora, może uchylić to postanowienie. Przepis § 5 stosuje się 

odpowiednio. Protokół przesłuchania świadka podlega ujawnieniu w całości. 

§ 9. Minister Sprawiedliwości określi, w drodze rozporządzenia, sposób 

i warunki składania wniosku o wydanie postanowienia, o którym mowa w § 1, 

przesłuchania świadka, co do którego wydano to postanowienie, oraz sporządzania, 

przechowywania i udostępniania protokołów przesłuchania tego świadka, a także 

dopuszczalny sposób powoływania się na jego zeznania w orzeczeniach i pismach 

procesowych, mając na uwadze zapewnienie właściwej ochrony 

tajemnicy 

okoliczności umożliwiających ujawnienie tożsamości świadka przed nieuprawnionym 

ujawnieniem.


## Art. 185. {#kpk-art-185}
Można zwolnić od złożenia zeznania lub odpowiedzi na pytania osobę 

pozostającą z oskarżonym w szczególnie bliskim stosunku osobistym, jeżeli osoba 

taka wnosi o zwolnienie.


## Art. 185a. {#kpk-art-185a}
§ 1. W sprawach o przestępstwa popełnione z użyciem przemocy lub 

groźby bezprawnej lub określone w rozdziałach XXIII, XXV i XXVI Kodeksu 

karnego pokrzywdzonego, który w chwili przesłuchania nie ukończył 15 lat, 

przesłuchuje się w charakterze świadka tylko wówczas, gdy jego zeznania mogą mieć 

istotne znaczenie dla rozstrzygnięcia sprawy, i tylko raz, chyba że wyjdą na jaw istotne 

okoliczności, których wyjaśnienie wymaga ponownego przesłuchania, lub w razie 

uwzględnienia wniosku dowodowego oskarżonego, który nie miał obrońcy w czasie 

pierwszego przesłuchania pokrzywdzonego. 

§ 2. Przesłuchanie przeprowadza sąd na posiedzeniu z udziałem biegłego 

psychologa niezwłocznie, nie później niż w terminie 14 dni od dnia wpływu wniosku. 

Prokurator, obrońca oraz pełnomocnik pokrzywdzonego mają prawo wziąć udział 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 75/356 

w przesłuchaniu. Osoba wymieniona w art. 51 § 2 lub osoba pełnoletnia wskazana 

przez pokrzywdzonego, o którym mowa w § 1, ma prawo również być obecna przy 

przesłuchaniu, jeżeli nie ogranicza to swobody wypowiedzi przesłuchiwanego. Jeżeli 

oskarżony zawiadomiony o tej czynności nie posiada obrońcy z wyboru, sąd 

wyznacza mu obrońcę z urzędu. 

§ 3. Na rozprawie głównej odtwarza się sporządzony zapis obrazu i dźwięku 

przesłuchania oraz odczytuje się protokół przesłuchania. 

§ 4. W sprawach 

o przestępstwa 

wymienione 

w § 1 małoletniego 

pokrzywdzonego, który w chwili przesłuchania ukończył 15 lat, przesłuchuje się 

w warunkach określonych w § 1–3, gdy zachodzi uzasadniona obawa, że 

przesłuchanie w innych warunkach mogłoby wywrzeć negatywny wpływ na jego stan 

psychiczny. W takim wypadku przepisu art. 185c nie stosuje się. 

§ 5. W sprawach o przestępstwa określone w § 1 biegły psycholog biorący 

udział w przesłuchaniu powinien być osobą płci wskazanej przez pokrzywdzonego, 

chyba że będzie to utrudniać postępowanie.


## Art. 185b. {#kpk-art-185b}
§ 1. W sprawach o przestępstwa popełnione z użyciem przemocy lub 

groźby bezprawnej lub określone w rozdziałach XXV i XXVI Kodeksu karnego 

świadka, który w chwili przesłuchania nie ukończył 15 lat, przesłuchuje się 

w warunkach określonych w art. 185a § 1–3 i 5, jeżeli zeznania tego świadka mogą 

mieć istotne znaczenie dla rozstrzygnięcia sprawy. 

§ 2. W sprawach o przestępstwa wymienione w § 1 małoletniego świadka, który 

w chwili przesłuchania ukończył 15 lat, przesłuchuje się w trybie określonym 

w art. 177 § 1a, gdy zachodzi uzasadniona obawa, że bezpośrednia obecność 

oskarżonego przy przesłuchaniu mogłaby oddziaływać krępująco na zeznania świadka 

lub wywierać negatywny wpływ na jego stan psychiczny. 

§ 3. Przepisów § 1 

i 2 nie stosuje się do świadka współdziałającego 

w popełnieniu czynu zabronionego, o który toczy się postępowanie karne, lub 

świadka, którego czyn pozostaje w związku z czynem, o który toczy się postępowanie 

karne.


## Art. 185c. {#kpk-art-185c}
§ 1. W sprawach o przestępstwa określone w art. 197–199 Kodeksu 

karnego zawiadomienie o przestępstwie, jeżeli składa je pokrzywdzony, powinno 

ograniczyć się do wskazania najważniejszych faktów i dowodów. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 76/356 

§ 1a. W sprawach o przestępstwa określone w § 1 pokrzywdzonego, który 

w chwili przesłuchania ukończył 15 lat, przesłuchuje się w charakterze świadka tylko 

wówczas, gdy jego zeznania mogą mieć istotne znaczenie dla rozstrzygnięcia sprawy, 

i tylko raz, chyba że wyjdą na jaw istotne okoliczności, których wyjaśnienie wymaga 

ponownego przesłuchania, 

lub w razie uwzględnienia wniosku dowodowego 

oskarżonego, który nie miał obrońcy w czasie pierwszego przesłuchania 

pokrzywdzonego. 

§ 2. Przesłuchanie pokrzywdzonego, o którym mowa w § 1a, w charakterze 

świadka przeprowadza sąd na posiedzeniu z udziałem biegłego psychologa 

niezwłocznie, nie później niż w terminie 14 dni od dnia wpływu wniosku. Prokurator, 

obrońca oraz pełnomocnik pokrzywdzonego mają prawo wziąć udział 

w przesłuchaniu. Osoba wymieniona w art. 51 § 2 lub osoba pełnoletnia wskazana 

przez pokrzywdzonego ma prawo również być obecna przy przesłuchaniu, jeżeli nie 

ogranicza to swobody wypowiedzi przesłuchiwanego. Na rozprawie głównej odtwarza 

się sporządzony zapis obrazu i dźwięku przesłuchania oraz odczytuje się protokół 

przesłuchania. 

§ 3. (uchylony) 

§ 4. Na wniosek pokrzywdzonego należy zapewnić, aby biegły psycholog 

biorący udział w przesłuchaniu był osobą o wskazanej przez niego płci, chyba że 

będzie to utrudniać postępowanie.


## Art. 185d. {#kpk-art-185d}
(uchylony)


## Art. 185e. {#kpk-art-185e}
§ 1. Jeżeli u świadka występują zaburzenia psychiczne, rozwojowe, 

zakłócenia zdolności postrzegania lub odtwarzania przez niego postrzeżeń i zachodzi 

uzasadniona obawa, że przesłuchanie w innych warunkach niż wskazane w tym 

przepisie mogłoby wpłynąć negatywnie na jego stan psychiczny lub byłoby znacznie 

utrudnione, świadka przesłuchuje się tylko wówczas, gdy jego zeznania mogą mieć 

istotne znaczenie dla rozstrzygnięcia sprawy, i tylko raz, chyba że wyjdą na jaw istotne 

okoliczności, których wyjaśnienie wymaga ponownego przesłuchania, lub w razie 

uwzględnienia wniosku dowodowego oskarżonego, który nie miał obrońcy w czasie 

pierwszego przesłuchania świadka. 

§ 2. Przesłuchanie przeprowadza sąd na posiedzeniu z udziałem biegłego 

psychologa, nie później niż w terminie 14 dni od dnia wpływu wniosku. Prokurator, 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 77/356 

obrońca oraz pełnomocnik mają prawo wziąć udział w przesłuchaniu. Osoba 

wymieniona w art. 51 § 2 lub 3 lub osoba pełnoletnia wskazana przez świadka ma 

prawo również być obecna przy przesłuchaniu, jeżeli nie ogranicza to swobody 

wypowiedzi przesłuchiwanego. Na rozprawie głównej odtwarza się sporządzony zapis 

obrazu i dźwięku przesłuchania oraz odczytuje się protokół przesłuchania. 

§ 3. Biegły psycholog biorący udział w przesłuchaniu powinien być osobą płci 

wskazanej przez świadka, chyba że będzie to utrudniać postępowanie. 

§ 4. Jeżeli świadek ma problemy z komunikacją werbalną, przesłuchanie 

przeprowadza się przy wykorzystaniu komunikacji wspomagającej i alternatywnej, 

którymi posługuje się świadek. W przesłuchaniu bierze udział biegły mający 

odpowiednią wiedzę w zakresie komunikacji wspomagającej i alternatywnej. 

§ 5. W odniesieniu do świadków, o których mowa w § 1, przepisów art. 185a–

185c nie stosuje się.


## Art. 185f. {#kpk-art-185f}
§ 1. Przesłuchania w trybie określonym w art. 185a–185c oraz 

art. 185e przeprowadza się w odpowiednio przystosowanych pomieszczeniach 

w siedzibie sądu lub poza jego siedzibą. Przesłuchanie w trybie określonym 

w art. 185e może być przeprowadzone także w innym miejscu, jeżeli uzasadniają to 

indywidualne potrzeby świadka i istnieje możliwość utrwalenia czynności za pomocą 

urządzenia rejestrującego obraz i dźwięk. 

§ 2. Przed pierwszym przesłuchaniem osoba przesłuchiwana w trybie 

określonym w art. 185a–185c oraz art. 185e otrzymuje informacje o przebiegu, 

sposobie i warunkach przesłuchania. Informacje zawierają opisowe lub graficzne 

przedstawienie przebiegu, sposobu i warunków przesłuchania. Pomiędzy doręczeniem 

informacji a terminem przesłuchania powinno upłynąć co najmniej 3 dni, chyba że 

dobro postępowania stoi temu na przeszkodzie. Przepisu art. 171 § 8 nie stosuje się. 

§ 3. Minister Sprawiedliwości określi, w drodze rozporządzenia, wzór informacji 

o przebiegu, sposobie i warunkach przesłuchania dla osób, o których mowa w § 2, 

odrębnie dla osób przesłuchiwanych, o których mowa w art. 185a–185c oraz art. 185e, 

uwzględniając potrzebę zrozumienia tych informacji przez osoby przesłuchiwane. 

§ 4. Minister Sprawiedliwości określi, w drodze rozporządzenia, sposób 

przygotowania i przeprowadzenia przesłuchań, o których mowa w § 1, oraz warunki, 

jakim powinny odpowiadać pomieszczenia przeznaczone do przeprowadzania 

przesłuchań, o których mowa w § 1 zdanie pierwsze, w tym ich wyposażenie 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 78/356 

techniczne, mając na względzie konieczność zapewnienia swobody wypowiedzi 

i poczucia 

bezpieczeństwa 

osób 

przesłuchiwanych 

przy 

uwzględnieniu 

indywidualnych potrzeb tych osób.


## Art. 186. {#kpk-art-186}
§ 1. Osoba uprawniona do odmowy złożenia zeznań albo zwolniona na 

podstawie art. 185 może oświadczyć, że chce z tego prawa skorzystać, nie później 

jednak niż przed rozpoczęciem pierwszego zeznania w postępowaniu sądowym; 

poprzednio złożone zeznanie tej osoby nie może wówczas służyć za dowód ani być 

odtworzone. 

§ 2. Sporządzone w postępowaniu karnym protokoły oględzin ciała podlegają 

ujawnieniu na rozprawie, choćby osoba poddana oględzinom odmówiła wyjaśnień lub 

zeznań albo została od nich zwolniona na podstawie art. 182 lub art. 185.


## Art. 187. {#kpk-art-187}
§ 1. Przyrzeczenie od świadka może odebrać tylko sąd lub sędzia 

wyznaczony. 

§ 2. Świadek składa przyrzeczenie przed rozpoczęciem zeznań. 

§ 3. Można odstąpić od odebrania przyrzeczenia od świadka, jeżeli obecne strony 

nie sprzeciwiają się temu.


## Art. 188. {#kpk-art-188}
§ 1. Świadek składa przyrzeczenie powtarzając za sędzią słowa: 

„Świadomy znaczenia moich słów i odpowiedzialności przed prawem przyrzekam 

uroczyście, że będę mówił szczerą prawdę, niczego nie ukrywając z tego, co mi jest 

wiadome”. 

§ 2. W czasie składania przyrzeczenia wszyscy, nie wyłączając sędziów, stoją. 

§ 3. Osoby nieme i głuche składają przyrzeczenie przez podpisanie tekstu 

przyrzeczenia. 

§ 4. Świadkowi, który w danej sprawie składał 

już przyrzeczenie, sąd 

przypomina je przy przesłuchaniu, chyba że uzna za potrzebne ponowne odebranie 

przyrzeczenia. 

1) 

2)


## Art. 189. {#kpk-art-189}
Nie odbiera się przyrzeczenia: 

od osób, które nie ukończyły 17 lat; 

gdy zachodzi uzasadnione podejrzenie, że świadek z powodu zaburzeń 

psychicznych nie zdaje sobie należycie sprawy ze znaczenia przyrzeczenia; 

3) 

gdy świadek jest osobą podejrzaną o popełnienie przestępstwa będącego 

przedmiotem postępowania lub pozostającego w ścisłym związku z czynem 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 79/356 

stanowiącym przedmiot postępowania albo gdy za to przestępstwo został 

skazany; 

4) 

gdy świadek był prawomocnie skazany za fałszywe zeznanie lub oskarżenie.


## Art. 190. {#kpk-art-190}
§ 1. Przed rozpoczęciem przesłuchania należy uprzedzić świadka 

o odpowiedzialności karnej za zeznanie nieprawdy lub zatajenie prawdy. 

§ 2. W postępowaniu przygotowawczym świadek podpisuje oświadczenie, że 

został uprzedzony o tej odpowiedzialności.


## Art. 191. {#kpk-art-191}
§ 1. Przesłuchanie rozpoczyna się od zapytania świadka o imię, 

nazwisko, wiek, zajęcie, karalność za fałszywe zeznanie lub oskarżenie oraz stosunek 

do stron. 

§ 1a. Miejsce zamieszkania świadka ustala się na podstawie dokumentu 

tożsamości lub pisemnego oświadczenia świadka. 

§ 1b. Pytania zadawane świadkowi nie mogą zmierzać do ujawnienia jego 

miejsca zamieszkania ani miejsca pracy, chyba że ma to znaczenie dla rozstrzygnięcia 

sprawy. 

§ 2. Świadka należy uprzedzić o treści art. 182, a o treści art. 183 oraz art. 185, 

jeżeli ujawnią się okoliczności objęte tymi przepisami. 

§ 3. (uchylony)


## Art. 192. {#kpk-art-192}
§ 1. Jeżeli karalność czynu zależy od stanu zdrowia pokrzywdzonego, 

nie może on sprzeciwić się oględzinom i badaniom niepołączonym z zabiegiem 

chirurgicznym lub obserwacją w zakładzie leczniczym. 

§ 2. Jeżeli istnieje wątpliwość co do stanu psychicznego świadka, jego stanu 

rozwoju umysłowego, zdolności postrzegania lub odtwarzania przez niego postrzeżeń, 

sąd lub prokurator może zarządzić przesłuchanie świadka z udziałem biegłego lekarza 

lub biegłego psychologa, a świadek nie może się temu sprzeciwić. 

§ 3. Przepisów § 1 i 2 nie stosuje się do osób, które odmówiły zeznań lub zostały 

od nich zwolnione na podstawie art. 182 § 1 i 2 lub art. 185. 

§ 4. Dla celów dowodowych można również świadka, za jego zgodą, poddać 

oględzinom ciała i badaniu lekarskiemu lub psychologicznemu.


## Art. 192a. {#kpk-art-192a}
§ 1. W celu ograniczenia kręgu osób podejrzanych lub ustalenia 

wartości dowodowej ujawnionych śladów można pobrać odciski daktyloskopijne, 

wymaz ze śluzówki policzków, włosy, ślinę, próby pisma, zapach, wykonać fotografię 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 80/356 

osoby lub dokonać utrwalenia głosu. Po wykorzystaniu w sprawie, w której dokonano 

pobrania lub utrwalenia, pobrany lub utrwalony materiał zbędny dla postępowania 

należy niezwłocznie usunąć z akt i zniszczyć. 

§ 2. W wypadkach, o których mowa w § 1, za zgodą osoby badanej biegły może 

również zastosować środki techniczne mające na celu kontrolę nieświadomych reakcji 

organizmu tej osoby. 

§ 3. Badania i czynności, o których mowa w § 1 i art. 192 § 1, wykonuje się 

odpowiednio w warunkach 

i w sposób określony w przepisach wydanych na 

podstawie art. 74 § 4. 


# Rozdział 22
 

Biegli, tłumacze, specjaliści


## Art. 193. {#kpk-art-193}
§ 1. Jeżeli stwierdzenie okoliczności mających istotne znaczenie dla 

rozstrzygnięcia sprawy wymaga wiadomości specjalnych, zasięga się opinii biegłego 

albo biegłych. 

§ 2. W celu wydania opinii można też zwrócić się do instytucji naukowej lub 

specjalistycznej. 

§ 2a. Do instytucji naukowej lub specjalistycznej oraz do osób, które biorą udział 

w wydaniu opinii tej instytucji, stosuje się odpowiednio przepisy dotyczące biegłych. 

§ 3. W wypadku powołania biegłych z zakresu różnych specjalności, o tym, czy 

mają oni przeprowadzić badania wspólnie i wydać jedną wspólną opinię, czy opinie 

odrębne, rozstrzyga organ procesowy powołujący biegłych.


## Art. 194. {#kpk-art-194}
O dopuszczeniu dowodu z opinii biegłego wydaje się postanowienie, 

w którym należy wskazać: 

1) 

imię, nazwisko i specjalność biegłego lub biegłych, a w wypadku opinii 

instytucji, w razie potrzeby, specjalność i kwalifikacje osób, które powinny 

wziąć udział w przeprowadzeniu ekspertyzy; 

2) 

przedmiot i zakres ekspertyzy ze sformułowaniem, w miarę potrzeby, pytań 

szczegółowych; 

3) 

termin dostarczenia opinii.


## Art. 195. {#kpk-art-195}
Do pełnienia czynności biegłego jest obowiązany nie tylko biegły 

sądowy, lecz także każda osoba, o której wiadomo, że ma odpowiednią wiedzę 

w danej dziedzinie. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 81/356


## Art. 196. {#kpk-art-196}
§ 1. Nie mogą być biegłymi osoby wymienione w art. 178, 182 i 185 

oraz osoby, do których odnoszą się odpowiednie przyczyny wyłączenia wymienione 

w art. 40 § 1 pkt 1–3 i 5, osoby powołane w sprawie w charakterze świadków, a także 

osoby, które były świadkiem czynu. 

§ 2. Jeżeli ujawnią się przyczyny wyłączenia biegłego wymienione w § 1, 

wydana przez niego opinia nie stanowi dowodu, a na miejsce biegłego wyłączonego 

powołuje się innego biegłego. 

§ 3. Jeżeli ujawnią się powody osłabiające zaufanie do wiedzy lub bezstronności 

biegłego albo inne ważne powody, powołuje się innego biegłego.


## Art. 197. {#kpk-art-197}
§ 1. Biegły składa przyrzeczenie następującej treści: „Świadomy 

znaczenia moich słów i odpowiedzialności przed prawem, przyrzekam uroczyście, że 

powierzone mi obowiązki wykonam z całą sumiennością i bezstronnością”. 

§ 2. Biegły sądowy powołuje się na przyrzeczenie złożone przy ustanowieniu go 

w tym charakterze. 

§ 2a. Jeżeli zachodzi uzasadniona obawa użycia przemocy 

lub groźby 

bezprawnej wobec biegłego lub osoby najbliższej w związku z jego czynnościami, 

może on zastrzec dane dotyczące miejsca zamieszkania do wyłącznej wiadomości 

prokuratora lub sądu. Pisma procesowe doręcza się wówczas do instytucji, w której 

biegły jest zatrudniony, lub na inny wskazany przez niego adres. 

§ 3. Do biegłego stosuje się odpowiednio przepisy art. 177, art. 179–181, 

art. 187, art. 188 § 2 i 4, art. 190 oraz art. 191 § 1.


## Art. 198. {#kpk-art-198}
§ 1. Jeżeli jest to niezbędne do wydania opinii, sąd lub prokurator 

udostępnia biegłemu poszczególne dokumenty z akt sprawy lub uwierzytelnione kopie 

tych dokumentów. Dokumenty mogą być również udostępnione w postaci 

elektronicznej. Biegłemu powołanemu z tego względu, że wydana przez innego 

biegłego opinia jest niepełna lub niejasna albo gdy zachodzi sprzeczność w niej samej 

lub między różnymi innymi opiniami w tej samej sprawie, przed wydaniem opinii nie 

udostępnia się tej innej opinii lub tych innych opinii. Inną opinię lub inne opinie można 

udostępnić biegłemu, w niezbędnym zakresie, tylko w wyjątkowym, szczególnie 

uzasadnionym wypadku, gdy przedmiot opinii powołanego biegłego bezpośrednio 

dotyczy treści tej innej opinii lub tych innych opinii. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 82/356 

§ 1a. W wypadku udostępnienia biegłemu dokumentów z akt sprawy, również 

w postaci elektronicznej, lub uwierzytelnionych kopii tych dokumentów, o których 

mowa w § 1, sporządza się w formie notatki urzędowej wykaz dokumentów, których 

oryginały, postać elektroniczna lub uwierzytelnione kopie zostały przed wydaniem 

opinii udostępnione biegłemu. Notatka powinna być podpisana przez osobę 

sporządzającą z podaniem imienia, nazwiska i stanowiska służbowego oraz załączona 

do akt sprawy. 

§ 1b. W miarę potrzeby biegłego wzywa się do udziału w przeprowadzeniu 

dowodów. 

§ 2. Organ procesowy może zastrzec swoją obecność przy przeprowadzaniu 

przez biegłego niektórych lub wszystkich badań, jeżeli nie wpłynie to ujemnie na 

wynik badania. 

§ 3. W razie potrzeby organ procesowy może wprowadzić zmiany co do zakresu 

ekspertyzy lub postawionych pytań oraz stawiać pytania dodatkowe.


## Art. 199. {#kpk-art-199}
Złożone wobec biegłego albo wobec lekarza udzielającego pomocy 

medycznej oświadczenia oskarżonego, dotyczące zarzucanego mu czynu, nie mogą 

stanowić dowodu.


## Art. 199a. {#kpk-art-199a}
Stosowanie w czasie badania przez biegłego środków technicznych 

mających na celu kontrolę nieświadomych reakcji organizmu badanej osoby możliwe 

jest wyłącznie za jej zgodą. Przepisu art. 199 nie stosuje się.


## Art. 200. {#kpk-art-200}
§ 1. W zależności od polecenia organu procesowego biegły składa 

opinię ustnie lub na piśmie. 

§ 2. Opinia powinna zawierać: 

1) 

imię, nazwisko, stopień i tytuł naukowy, specjalność i stanowisko zawodowe 

biegłego; 

2) 

imiona i nazwiska oraz pozostałe dane innych osób, które uczestniczyły 

w przeprowadzeniu ekspertyzy, ze wskazaniem czynności dokonanych przez 

każdą z nich; 

3) w wypadku opinii instytucji – także pełną nazwę i siedzibę instytucji; 

4) 

5) 

czas przeprowadzonych badań oraz datę wydania opinii; 

sprawozdanie z przeprowadzonych czynności i spostrzeżeń oraz oparte na nich 

wnioski; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 83/356 

6) 

podpisy wszystkich biegłych, którzy uczestniczyli w wydaniu opinii. 

§ 3. Osoby, które brały udział w wydaniu opinii, mogą być, w razie potrzeby, 

przesłuchiwane w charakterze biegłych, a osoby, które uczestniczyły 

tylko 

w badaniach – w charakterze świadków.


## Art. 201. {#kpk-art-201}
Jeżeli opinia jest niepełna lub niejasna albo gdy zachodzi sprzeczność 

w samej opinii lub między różnymi opiniami w tej samej sprawie, można wezwać 

ponownie tych samych biegłych lub powołać innych.


## Art. 202. {#kpk-art-202}
§ 1. W celu wydania opinii o stanie zdrowia psychicznego 

oskarżonego sąd, a w postępowaniu przygotowawczym prokurator, powołuje co 

najmniej dwóch biegłych lekarzy psychiatrów. 

§ 2. Na wniosek psychiatrów do udziału w wydaniu opinii powołuje się ponadto 

biegłego lub biegłych innych specjalności. 

§ 3. Do udziału w wydaniu opinii o stanie zdrowia psychicznego oskarżonego, 

w zakresie 

zaburzeń 

preferencji 

seksualnych, 

sąd, 

a w postępowaniu 

przygotowawczym prokurator, powołuje biegłego lekarza seksuologa. 

§ 4. Biegli nie mogą pozostawać ze sobą w związku małżeńskim ani w innym 

stosunku, który mógłby wywołać uzasadnioną wątpliwość co do ich samodzielności. 

§ 5. Opinia biegłych powinna zawierać stwierdzenia dotyczące zarówno 

poczytalności oskarżonego w chwili popełnienia zarzucanego mu czynu, jak i jego 

aktualnego stanu zdrowia psychicznego, a zwłaszcza wskazanie, czy stan ten pozwala 

oskarżonemu na udział w postępowaniu 

i na prowadzenie obrony w sposób 

samodzielny i rozsądny, a w razie potrzeby także stwierdzenia co do okoliczności 

wymienionych w art. 93b Kodeksu karnego.


## Art. 203. {#kpk-art-203}
§ 1. W razie zgłoszenia przez biegłych takiej konieczności, badanie 

stanu zdrowia psychicznego oskarżonego może być połączone z obserwacją 

w zakładzie leczniczym tylko wtedy, gdy zebrane dowody wskazują na duże 

prawdopodobieństwo, że oskarżony popełnił przestępstwo. Przepis art. 259 § 2 stosuje 

się odpowiednio, chyba że oskarżony wnosi o poddanie go obserwacji. 

§ 2. O potrzebie obserwacji w zakładzie leczniczym orzeka sąd, określając 

miejsce i czas trwania obserwacji. W postępowaniu przygotowawczym sąd orzeka na 

wniosek prokuratora. Przepisy art. 156 § 5a oraz art. 249 § 3 i 5 stosuje się 

odpowiednio. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 84/356 

§ 3. Obserwacja w zakładzie 

leczniczym nie powinna 

trwać dłużej niż 

4 tygodnie; na wniosek zakładu sąd może przedłużyć ten termin na czas określony, 

niezbędny do zakończenia obserwacji; łączny czas trwania obserwacji w danej 

sprawie nie może przekroczyć 8 tygodni. O zakończeniu obserwacji biegli 

niezwłocznie zawiadamiają sąd. 

§ 4. Na postanowienia, o których mowa w § 2 i 3, przysługuje zażalenie. Sąd 

rozpoznaje zażalenie niezwłocznie. 

§ 5. Minister właściwy do spraw zdrowia, w porozumieniu z Ministrem 

Sprawiedliwości, 

określi, w drodze 

rozporządzenia, wykaz 

zakładów 

psychiatrycznych i zakładów leczenia odwykowego przeznaczonych do wykonywania 

obserwacji, w tym do wykonywania obserwacji osób pozbawionych wolności, oraz 

sposób finansowania obserwacji, a także warunki zabezpieczenia zakładów dla osób 

pozbawionych wolności, mając na uwadze potrzebę zapewnienia sprawnego toku 

postępowania.


## Art. 204. {#kpk-art-204}
§ 1. Należy wezwać tłumacza, jeżeli zachodzi potrzeba przesłuchania: 

głuchego lub niemego, a nie wystarcza porozumienie się z nim za pomocą pisma; 

osoby niewładającej językiem polskim. 

1) 

2) 

§ 2. Należy również wezwać tłumacza, jeżeli zachodzi potrzeba przełożenia na 

język polski pisma sporządzonego w języku obcym lub odwrotnie albo zapoznania 

strony z treścią przeprowadzanego dowodu. 

§ 3. Do tłumacza stosuje się odpowiednio przepisy dotyczące biegłych.


## Art. 205. {#kpk-art-205}
§ 1. Jeżeli dokonanie oględzin, przesłuchania przy użyciu urządzeń 

technicznych umożliwiających przeprowadzenie 

tej czynności na odległość, 

eksperymentu, ekspertyzy, zatrzymania rzeczy lub przeszukania wymaga czynności 

technicznych, w szczególności takich jak wykonanie pomiarów, obliczeń, zdjęć, 

utrwalenie śladów, można do udziału w nich wezwać specjalistów. 

§ 2. Specjalistę niebędącego funkcjonariuszem organów procesowych można 

wezwać, przed przystąpieniem do czynności, do złożenia następującego 

przyrzeczenia: „Świadomy znaczenia powierzonej mi czynności i odpowiedzialności 

przed prawem przyrzekam uroczyście, że powierzone mi obowiązki wykonam z całą 

sumiennością i bezstronnością”. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 85/356 

§ 3. W protokole czynności przeprowadzonej z udziałem specjalistów należy 

wskazać ich imiona i nazwiska, specjalność, miejsce zamieszkania, miejsce pracy 

i stanowisko oraz podać rodzaj i zakres czynności wykonanych przez każdego z nich.


## Art. 206. {#kpk-art-206}
§ 1. Do specjalistów stosuje się odpowiednio przepisy dotyczące 

biegłych, z wyjątkiem art. 194, 197, 200 i 202. 

§ 2. W razie potrzeby można przesłuchiwać specjalistów w charakterze 

świadków. 


# Rozdział 23
 

Oględziny. Otwarcie zwłok. Eksperyment procesowy


## Art. 207. {#kpk-art-207}
§ 1. W razie potrzeby dokonuje się oględzin miejsca, osoby lub rzeczy. 

§ 2. Jeżeli przedmiot może ulec przy badaniu zniszczeniu lub zniekształceniu, 

część tego przedmiotu należy w miarę możności zachować w stanie niezmienionym, 

a gdy to nie jest możliwe – stan ten utrwalić w inny sposób.


## Art. 208. {#kpk-art-208}
Oględzin lub badań ciała, które mogą wywołać uczucie wstydu, 

powinna dokonać osoba tej samej płci, chyba że łączą się z tym szczególne trudności; 

inne osoby odmiennej płci mogą być obecne tylko w razie konieczności.


## Art. 209. {#kpk-art-209}
§ 1. Jeżeli zachodzi podejrzenie przestępnego spowodowania śmierci, 

przeprowadza się oględziny i otwarcie zwłok. 

§ 2. Oględzin zwłok dokonuje prokurator, a w postępowaniu sądowym sąd, 

z udziałem biegłego lekarza, w miarę możności z zakresu medycyny sądowej. 

W wypadkach niecierpiących zwłoki oględzin dokonuje Policja z obowiązkiem 

niezwłocznego powiadomienia prokuratora. 

§ 3. Oględzin zwłok dokonuje się na miejscu ich znalezienia. Do czasu przybycia 

biegłego oraz prokuratora lub sądu przemieszczać lub poruszać zwłoki można tylko 

w razie konieczności. 

§ 4. Otwarcia zwłok dokonuje biegły lekarz, w miarę możności z zakresu 

medycyny sądowej, w obecności prokuratora albo sądu. W postępowaniu przed sądem 

art. 396 § 1 i 4 stosuje się odpowiednio. 

§ 5. Do obecności przy oględzinach i otwarciu zwłok można, w razie potrzeby, 

oprócz biegłego, wezwać lekarza, który ostatnio udzielił pomocy zmarłemu. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 86/356 

Z oględzin i otwarcia zwłok biegły sporządza opinię z zachowaniem wymagań 

art. 200 § 2.


## Art. 210. {#kpk-art-210}
W celu dokonania oględzin lub otwarcia zwłok prokurator albo sąd 

może zarządzić wyjęcie zwłok z grobu.


## Art. 211. {#kpk-art-211}
W celu sprawdzenia okoliczności mających istotne znaczenie dla 

sprawy można przeprowadzić, w drodze eksperymentu procesowego, doświadczenie 

lub odtworzenie przebiegu stanowiących przedmiot rozpoznania zdarzeń lub ich 

fragmentów.


## Art. 212. {#kpk-art-212}
W toku oględzin lub eksperymentu procesowego można dokonywać 

również przesłuchań lub innych czynności dowodowych. 


# Rozdział 24
 

Wywiad środowiskowy i badanie osoby oskarżonego


## Art. 213. {#kpk-art-213}
§ 1. W postępowaniu należy ustalić tożsamość oskarżonego, jego 

numer PESEL, a w przypadku osoby nieposiadającej numeru PESEL – numer i nazwę 

dokumentu stwierdzającego tożsamość oraz nazwę organu, który wydał dokument, 

a także wiek oskarżonego, jego stosunki rodzinne i majątkowe, wykształcenie, zawód 

wyuczony i wykonywany oraz zajmowane stanowisko lub pełnioną funkcję, a także 

miejsce pracy i źródła dochodu, dane o jego karalności, a w miarę możliwości numer 

telefonu 

lub adres poczty elektronicznej umożliwiające kontaktowanie się 

z oskarżonym oraz numer identyfikacji podatkowej (NIP), o ile został nadany. 

Odnośnie do oskarżonego będącego funkcjonariuszem publicznym w chwili 

popełnienia czynu lub w czasie postępowania należy ponadto zebrać dane dotyczące 

przebiegu służby publicznej, wyróżnień oraz ukarań dyscyplinarnych. 

§ 1a. W razie potrzeby prokurator, inny organ prowadzący postępowanie 

przygotowawcze lub sąd uzyskuje informację z systemu teleinformatycznego ministra 

właściwego do spraw finansów publicznych dotyczącą stosunków majątkowych 

i źródeł dochodu oskarżonego, w tym prowadzonych i zakończonych postępowań 

podatkowych, na podstawie aktualnych danych znajdujących się w tym systemie. 

Informację uzyskuje się drogą elektroniczną. 

§ 1b. W postępowaniu w sprawach o przestępstwa w ruchu lądowym określone 

w rozdziale XXI Kodeksu karnego należy także uzyskać informacje z centralnej 

2025-09-11 

Zmiana § 2 w art. 
213 wejdzie w 

 
 
 
 

©Kancelaria Sejmu 

s. 87/356 

ewidencji kierowców oraz z ewidencji kierowców naruszających przepisy ruchu 

drogowego prowadzonej przez Policję, dotyczące oskarżonego. Jeżeli od sporządzenia 

tych informacji upłynął okres 6 miesięcy, należy uzyskać je ponownie. 

 [§ 2. Jeżeli podejrzany był już prawomocnie skazany, dla ustalenia, czy 

przestępstwo zostało popełnione w warunkach art. 64 lub art. 64a Kodeksu karnego 

lub przestępstwo skarbowe – w warunkach art. 37 § 1 pkt 4 Kodeksu karnego 

skarbowego, dołącza się do akt postępowania odpis lub wyciąg wyroku oraz dane 

dotyczące odbycia kary. Dokumenty te dołącza się także w sprawach o zbrodnie.] 

 <§ 2. Jeżeli podejrzany był już prawomocnie skazany, dla ustalenia, czy 

przestępstwo zostało popełnione w warunkach art. 64 lub art. 64a Kodeksu 

karnego lub przestępstwo skarbowe – w warunkach art. 37 § 1 pkt 4 Kodeksu 

karnego skarbowego, dołącza się do akt postępowania kopię lub wyciąg wyroku 

oraz dane dotyczące odbycia kary. Dokumenty te dołącza się także w sprawach 

o zbrodnie.> 

§ 2a. Jeżeli 

organ 

prowadzący 

postępowanie 

powziął 

informację 

o prawomocnym skazaniu, przepis § 2 stosuje się odpowiednio do orzeczeń 

skazujących wydanych przez sąd innego państwa członkowskiego Unii Europejskiej. 

§ 3. (uchylony) 

§ 4. Minister Sprawiedliwości, w porozumieniu z ministrem właściwym do 

spraw finansów publicznych, określi, w drodze rozporządzenia, wzór i szczegółowy 

zakres informacji, o której mowa w § 1a, oraz sposób postępowania w celu jej 

uzyskania, mając na względzie potrzebę uzyskania przez organ postępowania danych 

niezbędnych do realizacji celów procesu, zachowanie wymogów tajemnicy ustawowo 

chronionej oraz okresy rozliczeniowe przyjęte dla poszczególnych zobowiązań 

podatkowych.


## Art. 214. {#kpk-art-214}
§ 1. W razie potrzeby, a w szczególności gdy niezbędne jest ustalenie 

danych co do właściwości i warunków osobistych oraz dotychczasowego sposobu 

życia oskarżonego, sąd, a w postępowaniu przygotowawczym prokurator, zarządza 

w stosunku do oskarżonego przeprowadzenie wywiadu środowiskowego przez 

kuratora sądowego lub inny podmiot uprawniony na podstawie odrębnych przepisów, 

a w szczególnie uzasadnionych wypadkach przez Policję. 

§ 2. Przeprowadzenie wywiadu środowiskowego jest obowiązkowe: 

1) w sprawach o zbrodnie; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 88/356 

1a) w stosunku do oskarżonego, który w chwili czynu nie ukończył 18 lat; 

2) w stosunku do oskarżonego, który w chwili czynu nie ukończył 21 roku życia, 

jeżeli zarzucono mu popełnienie umyślnego występku przeciwko życiu. 

§ 3. Wywiadu środowiskowego można nie przeprowadzać w stosunku do 

oskarżonego, który nie ma w kraju stałego miejsca zamieszkania. 

§ 4. Wynik wywiadu środowiskowego powinien w szczególności zawierać: 

1) 

2) 

3) 

imię i nazwisko osoby przeprowadzającej wywiad; 

imię i nazwisko oskarżonego; 

zwięzły opis dotychczasowego życia oskarżonego oraz dokładne informacje 

o środowisku oskarżonego, w tym rodzinnym, szkolnym lub zawodowym, 

a nadto informacje o jego stanie majątkowym i źródłach dochodów; 

4) 

informacje dotyczące stanu zdrowia oskarżonego, a także o nadużywaniu przez 

niego alkoholu, środków odurzających, środków zastępczych lub substancji 

psychotropowych; 

5) własne spostrzeżenia i konkluzje osoby przeprowadzającej wywiad, zwłaszcza 

dotyczące właściwości i warunków osobistych oraz dotychczasowego sposobu 

życia oskarżonego. 

§ 5. Dane o osobach, które dostarczyły 

informacji w ramach wywiadu 

środowiskowego, osoba przeprowadzająca wywiad ujawnia jedynie na żądanie sądu, 

a w postępowaniu przygotowawczym – prokuratora. 

§ 6. Osoby, które dostarczyły informacji w ramach wywiadu środowiskowego, 

mogą być w razie potrzeby przesłuchane w charakterze świadków. 

§ 7. Policja jest obowiązana udzielić osobie przeprowadzającej wywiad pomocy 

przy wykonywaniu zadań związanych z wywiadem środowiskowym w celu 

zapewnienia jej bezpieczeństwa. 

§ 8. Do osoby powołanej do przeprowadzenia wywiadu środowiskowego stosuje 

się odpowiednio przepisy o wyłączeniu 

sędziego. Orzeka o tym 

sąd, 

a w postępowaniu przygotowawczym – prokurator. 

§ 9. Minister Sprawiedliwości, w porozumieniu z ministrem właściwym do 

spraw wewnętrznych, określi, w drodze rozporządzenia, regulamin czynności 

w zakresie przeprowadzania wywiadu środowiskowego oraz wzór kwestionariusza 

tego wywiadu, mając na uwadze konieczność zapewnienia zebrania wyczerpujących 

danych o osobie oskarżonego. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 89/356


## Art. 215. {#kpk-art-215}
W razie 

potrzeby 

sąd, 

a w postępowaniu 

przygotowawczym 

prokurator, może zarządzić badanie oskarżonego przez biegłych psychologów lub 

lekarzy z zachowaniem zasad określonych w art. 74.


## Art. 216. {#kpk-art-216}
W razie potrzeby można przesłuchiwać w charakterze świadków 

osoby, które przeprowadziły wywiad. 


# Rozdział 25
 

Zatrzymanie rzeczy. Przeszukanie


## Art. 217. {#kpk-art-217}
§ 1. Rzeczy mogące stanowić dowód w sprawie lub podlegające 

zajęciu w celu zabezpieczenia kar majątkowych, środków karnych o charakterze 

majątkowym, przepadku, środków kompensacyjnych albo roszczeń o naprawienie 

szkody należy wydać na żądanie sądu lub prokuratora, a w wypadkach niecierpiących 

zwłoki – także na żądanie Policji lub innego uprawnionego organu. 

§ 2. Osobę mającą rzecz podlegającą wydaniu wzywa się do wydania jej 

dobrowolnie. 

§ 3. W razie zatrzymania rzeczy stosuje się odpowiednio przepis art. 228. 

Protokołu można nie sporządzać, jeżeli rzecz załącza się do akt sprawy. 

§ 4. Jeżeli wydania żąda Policja albo inny uprawniony organ działający we 

własnym zakresie, osoba, która rzecz wyda, ma prawo niezwłocznie złożyć wniosek 

o sporządzenie i doręczenie jej postanowienia sądu lub prokuratora o zatwierdzeniu 

zatrzymania, o czym należy ją pouczyć. Doręczenie powinno nastąpić w terminie 

14 dni od zatrzymania rzeczy. 

§ 5. W razie odmowy dobrowolnego wydania rzeczy można przeprowadzić jej 

odebranie. Przepisy art. 220 § 3 i art. 229 stosuje się odpowiednio.


## Art. 218. {#kpk-art-218}
§ 1. Urzędy, instytucje i podmioty prowadzące działalność w 

dziedzinie poczty lub działalność telekomunikacyjną, urzędy celno-skarbowe oraz 

instytucje i przedsiębiorstwa transportowe obowiązane są wydać sądowi lub 

prokuratorowi, na żądanie zawarte w postanowieniu, korespondencję i przesyłki oraz 

dane, o których mowa w art. 45 ust. 1 i art. 49 ustawy z dnia 12 lipca 2024 r. – Prawo 

komunikacji elektronicznej (Dz. U. poz. 1221), jeżeli mają znaczenie dla toczącego 

się postępowania. Tylko sąd lub prokurator mają prawo je otwierać lub zarządzić ich 

otwarcie. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 90/356 

§ 2. Postanowienie, o którym mowa w § 1, doręcza 

się 

adresatom 

korespondencji oraz abonentowi telefonu lub nadawcy, którego wykaz połączeń lub 

innych przekazów informacji został wydany. Doręczenie postanowienia może być 

odroczone na czas oznaczony, niezbędny ze względu na dobro sprawy, lecz nie później 

niż do czasu prawomocnego zakończenia postępowania. 

§ 3. Pozbawioną znaczenia dla postępowania karnego korespondencję i przesyłki 

należy 

niezwłocznie 

zwrócić właściwym 

urzędom, 

instytucjom 

lub 

przedsiębiorstwom wymienionym w § 1.


## Art. 218a. {#kpk-art-218a}
§ 1. Urzędy, 

instytucje 

i podmioty 

prowadzące 

działalność 

telekomunikacyjną lub świadczące usługi drogą elektroniczną oraz dostawcy usług 

cyfrowych obowiązani są niezwłocznie zabezpieczyć, na żądanie sądu lub prokuratora 

zawarte w postanowieniu, na czas określony, nieprzekraczający jednak 90 dni, dane 

informatyczne przechowywane w urządzeniach zawierających te dane na nośniku lub 

w systemie informatycznym. W sprawach o przestępstwa określone w art. 200b, 

art. 202 § 3, 4, 4a, 4b lub art. 255a Kodeksu karnego oraz w rozdziale 7 ustawy z dnia 

29 lipca 2005 r. o przeciwdziałaniu narkomanii (Dz. U. z 2023 r. poz. 1939) 

zabezpieczenie może być połączone z obowiązkiem uniemożliwienia dostępu do tych 

danych. Przepis art. 218 § 2 zdanie drugie stosuje się odpowiednio. 

§ 2. Pozbawione znaczenia dla postępowania karnego dane informatyczne, 

o których mowa w § 1, należy niezwłocznie zwolnić spod zabezpieczenia. 

§ 3. Przepisy § 1 

i 2 stosuje się odpowiednio do zabezpieczania 

treści 

publikowanych lub udostępnianych drogą elektroniczną, przy czym podmiotem 

obowiązanym do wykonania żądania sądu lub prokuratora może być również 

administrator treści. 

§ 4. Jeżeli publikacja lub udostępnienie treści, o których mowa w § 3, stanowiło 

czyn zabroniony, o którym mowa w § 1, sąd lub prokurator może zarządzić usunięcie 

tych treści, nakładając obowiązek wykonania postanowienia na podmioty, o których 

mowa w § 1 lub 3.


## Art. 218b. {#kpk-art-218b}
Minister Sprawiedliwości w porozumieniu z ministrem właściwym 

do spraw łączności, ministrem właściwym do spraw informatyzacji, Ministrem 

Obrony Narodowej oraz ministrem właściwym do spraw wewnętrznych określi, 

w drodze rozporządzenia, sposób technicznego przygotowania systemów i sieci 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 91/356 

służących do przekazywania informacji – do gromadzenia danych, o których mowa 

w art. 218 § 1, niestanowiących treści rozmowy telefonicznej lub innego przekazu 

informacji, a także sposoby zabezpieczania danych informatycznych, o których mowa 

w art. 218 § 1 

i art. 218a § 1, oraz 

treści, o których mowa w art. 218a § 3, 

w urządzeniach zawierających te dane oraz w systemach i na informatycznych noś-

nikach danych, mając na uwadze konieczność zabezpieczenia tych danych oraz treści 

przed ich utratą, zniekształceniem lub nieuprawnionym ujawnieniem, a w przypadku 

połączenia zabezpieczenia z obowiązkiem uniemożliwienia dostępu do tych danych 

informatycznych 

lub 

treści, również konieczność 

ich zabezpieczenia przed 

nieuprawnionym dostępem i ujawnieniem, a w przypadku usunięcia treści – przed ich 

nieuprawnionym odzyskaniem.


## Art. 219. {#kpk-art-219}
§ 1. W celu wykrycia 

lub zatrzymania albo przymusowego 

doprowadzenia osoby podejrzanej, a także w celu znalezienia rzeczy mogących 

stanowić dowód w sprawie lub podlegających zajęciu w postępowaniu karnym, można 

dokonać przeszukania pomieszczeń i innych miejsc, jeżeli istnieją uzasadnione 

podstawy do przypuszczenia, że osoba podejrzana lub wymienione rzeczy tam się 

znajdują. 

§ 2. W celu znalezienia 

rzeczy wymienionych w § 1 

i pod warunkiem 

określonym w tym przepisie oraz z uwzględnieniem zasad i granic określonych 

w art. 227 można też dokonać przeszukania osoby, jej odzieży i podręcznych 

przedmiotów.


## Art. 220. {#kpk-art-220}
§ 1. Przeszukania może dokonać prokurator albo na polecenie sądu lub 

prokuratora Policja, a w wypadkach wskazanych w ustawie – także inny organ. 

§ 2. Postanowienie sądu lub prokuratora należy okazać osobie, u której 

przeszukanie ma być przeprowadzone. 

§ 3. W wypadkach niecierpiących zwłoki, jeżeli postanowienie sądu lub 

prokuratora nie mogło zostać wydane, organ dokonujący przeszukania okazuje nakaz 

kierownika swojej jednostki lub legitymację służbową, a następnie zwraca się 

niezwłocznie do sądu lub prokuratora o zatwierdzenie przeszukania. Postanowienie 

sądu lub prokuratora w przedmiocie zatwierdzenia należy doręczyć osobie, u której 

dokonano przeszukania, w terminie 7 dni od daty czynności na zgłoszone do protokołu 

żądanie tej osoby. O prawie zgłoszenia żądania należy ją pouczyć. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 92/356


## Art. 221. {#kpk-art-221}
§ 1. Przeszukania zamieszkałych pomieszczeń można dokonać 

w porze nocnej tylko w wypadkach niecierpiących zwłoki; za porę nocną uważa się 

czas od godziny 22 do godziny 6. 

§ 2. Przeszukanie rozpoczęte za dnia można prowadzić nadal mimo nastania pory 

nocnej. 

§ 3. W porze nocnej można przeszukać lokale dostępne w tym czasie dla 

nieokreślonej liczby osób albo służące do przechowywania przedmiotów.


## Art. 222. {#kpk-art-222}
§ 1. Przy rozpoczęciu przeszukania pomieszczenia lub miejsca 

zamkniętego, należącego do instytucji państwowej lub samorządowej, należy 

o zamierzonym przeszukaniu zawiadomić kierownika tej instytucji lub jego zastępcę 

albo organ nadrzędny i dopuścić ich do udziału w czynności. 

§ 2. Przeszukanie pomieszczenia zajętego przez wojsko może nastąpić jedynie 

w obecności dowódcy lub osoby przez niego wyznaczonej.


## Art. 223. {#kpk-art-223}
Przeszukania osoby i odzieży na niej należy dokonywać w miarę 

możności za pośrednictwem osoby tej samej płci.


## Art. 224. {#kpk-art-224}
§ 1. Osobę, u której ma nastąpić przeszukanie, należy przed 

rozpoczęciem czynności zawiadomić o jej celu i wezwać do wydania poszukiwanych 

przedmiotów. 

§ 2. Podczas przeszukania ma prawo być obecna osoba wymieniona w § 1 oraz 

osoba przybrana przez prowadzącego czynność. Ponadto może być obecna osoba 

wskazana przez tego, u kogo dokonuje się przeszukania, jeżeli nie uniemożliwia to 

przeszukania albo nie utrudnia go w istotny sposób. 

§ 3. Jeżeli przy przeszukaniu nie ma na miejscu gospodarza lokalu, należy do 

przeszukania przywołać przynajmniej jednego dorosłego domownika lub sąsiada.


## Art. 225. {#kpk-art-225}
§ 1. Jeżeli kierownik instytucji państwowej lub samorządowej albo też 

osoba, u której dokonano zatrzymania rzeczy lub u której przeprowadza się 

przeszukanie, oświadczy, że wydane lub znalezione przy przeszukaniu pismo lub inny 

dokument zawiera informacje niejawne lub wiadomości objęte tajemnicą zawodową 

lub 

inną 

tajemnicą prawnie chronioną albo ma charakter osobisty, organ 

przeprowadzający czynność przekazuje niezwłocznie pismo lub inny dokument bez 

jego odczytania prokuratorowi lub sądowi w opieczętowanym opakowaniu. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 93/356 

§ 2. Tryb wskazany w § 1 nie obowiązuje w stosunku do pism lub innych 

dokumentów, które zawierają informacje niejawne o klauzuli „zastrzeżone” lub 

„poufne” albo dotyczą tajemnicy zawodowej lub innej tajemnicy prawnie chronionej, 

jeżeli ich posiadaczem jest osoba podejrzana o popełnienie przestępstwa, ani 

w stosunku do pism lub innych dokumentów o charakterze osobistym, których jest ona 

posiadaczem, autorem lub adresatem. 

§ 3. Jeżeli obrońca lub inna osoba, od której żąda się wydania rzeczy lub u której 

dokonuje się przeszukania, oświadczy, że wydane lub znalezione w toku przeszukania 

pisma lub inne dokumenty obejmują okoliczności związane z wykonywaniem funkcji 

obrońcy, organ dokonujący czynności pozostawia te dokumenty wymienionej osobie 

bez zapoznawania się z ich treścią lub wyglądem. Jeżeli jednak oświadczenie osoby 

niebędącej obrońcą budzi wątpliwości, organ dokonujący czynności przekazuje te 

dokumenty z zachowaniem rygorów określonych w § 1 sądowi, który po zapoznaniu 

się z dokumentami zwraca je w całości lub w części, z zachowaniem rygorów 

określonych w § 1, osobie, od której je zabrano, albo wydaje postanowienie o ich 

zatrzymaniu dla celów postępowania. 

§ 4. Wydaną, odebraną lub znalezioną w toku przeszukania dokumentację 

psychiatryczną organ przeprowadzający czynność przekazuje, z zachowaniem 

rygorów określonych w § 1, sądowi lub prokuratorowi.


## Art. 226. {#kpk-art-226}
W kwestii wykorzystania dokumentów zawierających informacje 

niejawne lub tajemnicę zawodową, jako dowodów w postępowaniu karnym, stosuje 

się odpowiednio zakazy 

i ograniczenia określone w art. 178–181. Jednakże 

w postępowaniu przygotowawczym o wykorzystaniu, jako dowodów, dokumentów 

zawierających tajemnicę lekarską decyduje prokurator.


## Art. 227. {#kpk-art-227}
Przeszukanie lub zatrzymanie rzeczy powinno być dokonane zgodnie 

z celem tej czynności, z zachowaniem umiaru, oraz w granicach niezbędnych dla 

osiągnięcia celu 

tych czynności przy zachowaniu należytej 

staranności, 

w poszanowaniu prywatności i godności osób, których ta czynność dotyczy, oraz bez 

wyrządzania niepotrzebnych szkód i dolegliwości.


## Art. 228. {#kpk-art-228}
§ 1. Przedmioty wydane lub znalezione w czasie przeszukania należy 

po dokonaniu oględzin, sporządzeniu spisu i opisu zabrać albo oddać na przechowanie 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 94/356 

osobie godnej zaufania z zaznaczeniem obowiązku przedstawienia na każde żądanie 

organu prowadzącego postępowanie. 

§ 2. Tak samo należy postąpić ze znalezionymi w czasie przeszukania 

przedmiotami mogącymi stanowić dowód innego przestępstwa, podlegającymi 

przepadkowi lub których posiadanie jest zabronione. 

§ 3. Osobom zainteresowanym należy natychmiast wręczyć pokwitowanie 

stwierdzające, jakie przedmioty i przez kogo zostały zatrzymane.


## Art. 229. {#kpk-art-229}
Protokół zatrzymania rzeczy lub przeszukania powinien, oprócz 

wymagań wymienionych w art. 148 i art. 148a, zawierać oznaczenie sprawy, z którą 

zatrzymanie rzeczy lub przeszukanie ma związek, oraz podanie dokładnej godziny 

rozpoczęcia i zakończenia czynności, dokładną listę zatrzymanych rzeczy i w miarę 

potrzeby ich opis, a nadto wskazanie polecenia sądu lub prokuratora. Jeżeli polecenie 

nie 

zostało uprzednio wydane, 

zamieszcza 

się w protokole wzmiankę 

o poinformowaniu osoby, u której czynność przeprowadzono, że na jej wniosek 

otrzyma postanowienie w przedmiocie zatwierdzenia czynności.


## Art. 230. {#kpk-art-230}
§ 1. Jeżeli zatrzymanie rzeczy lub przeszukanie nastąpiło bez 

uprzedniego polecenia sądu lub prokuratora, a w ciągu 7 dni od dnia czynności nie 

nastąpiło jej zatwierdzenie, należy niezwłocznie zwrócić zatrzymane rzeczy osobie 

uprawnionej, chyba że nastąpiło dobrowolne wydanie, a osoba ta nie złożyła wniosku, 

o którym mowa w art. 217 § 4. 

§ 2. Należy 

również zwrócić osobie uprawnionej zatrzymane 

rzeczy 

niezwłocznie po stwierdzeniu ich zbędności dla postępowania karnego. Jeżeli 

wyniknie spór co do własności rzeczy, a nie ma dostatecznych danych do 

niezwłocznego rozstrzygnięcia, odsyła się osoby zainteresowane na drogę procesu 

cywilnego. 

§ 3. Rzeczy, których posiadanie jest zabronione, przekazuje się właściwemu 

urzędowi lub instytucji. Jeżeli rzeczy mają wartość naukową, artystyczną lub 

historyczną, na wniosek lub za zgodą muzeum, można je przekazać temu muzeum.


## Art. 231. {#kpk-art-231}
§ 1. Jeżeli powstaje wątpliwość, komu należy wydać zatrzymaną rzecz, 

sąd, referendarz sądowy lub prokurator składa ją do depozytu sądowego albo oddaje 

osobie godnej zaufania aż do wyjaśnienia uprawnienia do odbioru. Przepisy 

o likwidacji depozytów i nieodebranych rzeczy stosuje się odpowiednio. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 95/356 

§ 2. Przedmioty o wartości naukowej, artystycznej lub historycznej oddaje się na 

przechowanie muzeum lub innej właściwej instytucji.


## Art. 232. {#kpk-art-232}
§ 1. Przedmioty ulegające szybkiemu zniszczeniu lub takie, których 

przechowywanie byłoby połączone z niewspółmiernymi kosztami lub nadmiernymi 

trudnościami albo powodowałoby znaczne obniżenie wartości rzeczy, można sprzedać 

według trybu określonego dla właściwych organów postępowania wykonawczego. 

Postanowienie w przedmiocie sprzedaży w postępowaniu przygotowawczym może 

wydać prokurator, a w postępowaniu sądowym sąd lub referendarz sądowy. 

§ 2. Uzyskaną kwotę pieniężną przekazuje się do depozytu sądowego. 

§ 3. O czasie i warunkach sprzedaży należy w miarę możności zawiadomić 

oskarżonego oraz inne zainteresowane osoby.


## Art. 232a. {#kpk-art-232a}
§ 1. Przedmioty i substancje stwarzające niebezpieczeństwo dla życia 

lub zdrowia, a w szczególności broń, amunicję, materiały wybuchowe lub łatwopalne, 

materiały radioaktywne, substancje trujące, duszące lub parzące, środki odurzające, 

substancje psychotropowe lub ich preparaty oraz prekursory kategorii 1, a także 

wyroby tytoniowe i napoje alkoholowe, przechowuje się w miejscu i w sposób 

zapewniający ich należyte zabezpieczenie. 

§ 2. Jeżeli dla zapewnienia prawidłowego toku postępowania wystarczające jest 

przechowywanie próbek w ilości niezbędnej do przeprowadzenia badań przedmiotów 

lub substancji, o których mowa w § 1, sąd właściwy do rozpoznania sprawy lub 

referendarz sądowy na wniosek prokuratora, niezwłocznie zarządza zniszczenie 

w całości lub w części pozostałych ilości przedmiotów lub substancji zbędnych do 

przeprowadzenia badań. 

§ 3. Jeżeli sąd 

lub referendarz sądowy zarządził zniszczenie w części 

przedmiotów 

lub substancji, o których mowa w § 1, wskazuje 

jednocześnie 

w postanowieniu miejsce i czas przechowywania ich pozostałej części w ilości 

niezbędnej do przeprowadzenia badań. 

§ 4. Przedmioty i substancje stwarzające bezpośrednie niebezpieczeństwo dla 

życia lub zdrowia przez możliwość eksplozji materiałów wybuchowych lub 

łatwopalnych, innego gwałtownego wyzwolenia energii, rozprzestrzeniania się 

substancji trujących, duszących lub parzących, wyzwolenia energii jądrowej lub 

promieniowania jonizującego albo których przechowywanie w niezmienionym stanie 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 96/356 

nie jest możliwe, można zniszczyć przed wydaniem postanowienia, o którym mowa 

w § 2. 

§ 5. Rada Ministrów określi, w drodze rozporządzenia, podmioty uprawnione do 

przechowywania oraz zniszczenia przedmiotów i substancji, o których mowa w § 1, 

oraz ich próbek, szczegółowe warunki, sposób oraz miejsca ich przechowywania, 

a także warunki i sposób ich zniszczenia, mając na uwadze potrzebę zapewnienia 

prawidłowego toku postępowania i jego koszty.


## Art. 232b. {#kpk-art-232b}
§ 1. W stanie zagrożenia epidemicznego lub stanie epidemii zajęte 

przedmioty mające znaczenie dla zdrowia lub bezpieczeństwa publicznego, można 

nieodpłatnie przekazać podmiotom leczniczym, Państwowej Straży Pożarnej, Siłom 

Zbrojnym Rzeczypospolitej Polskiej, Policji, Straży Granicznej oraz instytucjom 

państwowym i samorządowym. Art. 192 Kodeksu karnego wykonawczego stosuje się 

odpowiednio. 

§ 2. Postanowienie o nieodpłatnym przekazaniu przedmiotów wydaje w 

postępowaniu przygotowawczym prokurator, a po wniesieniu aktu oskarżenia sąd 

właściwy do rozpoznania sprawy. 

§ 3. Na postanowienie, o którym mowa w ust. 2, przysługuje zażalenie. 

Wniesienie zażalenia nie wstrzymuje wykonania zaskarżonego postanowienia.


## Art. 233. {#kpk-art-233}
Oddając na przechowanie krajowe środki płatnicze lub wartości 

dewizowe, organ, przekazując je, określa charakter depozytu i sposób rozporządzenia 

oddanymi na przechowanie wartościami.


## Art. 234. {#kpk-art-234}
Rozporządzenia przedmiotem dokonane po jego odebraniu lub 

zabezpieczeniu są bezskuteczne w stosunku do Skarbu Państwa.


## Art. 235. {#kpk-art-235}
Sąd lub referendarz sądowy dokonuje czynności przewidzianych 

w tym 

rozdziale w postępowaniu 

sądowym, 

a prokurator w postępowaniu 

przygotowawczym, chyba że ustawa stanowi inaczej.


## Art. 236. {#kpk-art-236}
§ 1. Na postanowienie dotyczące przeszukania, zatrzymania rzeczy 

i w przedmiocie dowodów rzeczowych oraz na inne czynności przysługuje zażalenie 

osobom, których prawa zostały naruszone; zażalenie na postanowienie wydane lub 

czynność dokonaną w postępowaniu przygotowawczym rozpoznaje sąd rejonowy, 

w okręgu którego prowadzone jest postępowanie. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 97/356 

§ 2. Jeżeli jednak postanowienie albo zarządzenie wydał referendarz sądowy, 

stosuje się art. 93a § 3 i 4.


## Art. 236a. {#kpk-art-236a}
Przepisy 

rozdziału niniejszego stosuje się odpowiednio do 

dysponenta i użytkownika urządzenia zawierającego dane informatyczne lub systemu 

informatycznego, w zakresie danych przechowywanych w tym urządzeniu lub 

systemie albo na nośniku znajdującym się w jego dyspozycji lub użytkowaniu, w tym 

korespondencji przesyłanej pocztą elektroniczną.


## Art. 236b. {#kpk-art-236b}
§ 1. Rzeczą lub przedmiotem w rozumieniu przepisów niniejszego 

rozdziału są również środki na rachunku. 

§ 2. Postanowienie w przedmiocie dowodów rzeczowych może dotyczyć 

środków na rachunku, jeżeli zostały zatrzymane jako dowód w sprawie. 


# Rozdział 26
 

Kontrola i utrwalanie rozmów


## Art. 237. {#kpk-art-237}
§ 1. Po wszczęciu postępowania sąd na wniosek prokuratora może 

zarządzić kontrolę i utrwalanie treści rozmów telefonicznych w celu wykrycia 

i uzyskania dowodów dla toczącego się postępowania lub zapobieżenia popełnieniu 

nowego przestępstwa. 

§ 2. W wypadkach niecierpiących zwłoki kontrolę i utrwalanie treści rozmów 

telefonicznych może zarządzić prokurator, który jest obowiązany zwrócić się 

w terminie 3 dni do sądu z wnioskiem o zatwierdzenie postanowienia. Sąd wydaje 

postanowienie w przedmiocie wniosku w terminie 5 dni na posiedzeniu bez udziału 

stron. W wypadku niezatwierdzenia postanowienia prokuratora sąd w postanowieniu 

wydanym w przedmiocie wniosku zarządza zniszczenie wszystkich utrwalonych 

zapisów. Zaskarżenie postanowienia wstrzymuje jego wykonanie. 

§ 3. Kontrola i utrwalanie treści rozmów telefonicznych są dopuszczalne tylko 

wtedy, gdy toczące się postępowanie lub uzasadniona obawa popełnienia nowego 

przestępstwa dotyczy: 

1) 

2) 

3) 

4) 

zabójstwa; 

narażenia na niebezpieczeństwo powszechne lub sprowadzenia katastrofy; 

handlu ludźmi; 

uprowadzenia osoby; 

5) wymuszania okupu; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 98/356 

6) 

7) 

8) 

9) 

uprowadzenia statku powietrznego lub wodnego; 

rozboju, kradzieży rozbójniczej lub wymuszenia rozbójniczego; 

zamachu na niepodległość lub integralność państwa; 

zamachu na konstytucyjny ustrój państwa lub jego naczelne organy, albo na 

jednostkę Sił Zbrojnych Rzeczypospolitej Polskiej; 

10) szpiegostwa lub ujawnienia informacji niejawnych o klauzuli tajności „tajne” lub 

„ściśle tajne”; 

11) gromadzenia broni, materiałów wybuchowych lub radioaktywnych; 

12) fałszowania oraz obrotu fałszywymi pieniędzmi, środkami lub instrumentami 

płatniczymi albo zbywalnymi dokumentami uprawniającymi do otrzymania 

sumy pieniężnej, towaru, ładunku albo wygranej rzeczowej albo zawierającymi 

obowiązek wpłaty kapitału, odsetek, udziału w zyskach lub stwierdzenie 

uczestnictwa w spółce; 

12a) podrabiania lub przerabiania faktur lub używania faktur podrobionych lub 

przerobionych w zakresie okoliczności faktycznych mogących mieć znaczenie 

dla określenia wysokości należności publicznoprawnej lub jej zwrotu albo 

zwrotu innej należności o charakterze podatkowym oraz wystawiania i używania 

faktur poświadczających nieprawdę co do okoliczności faktycznych mogących 

mieć znaczenie dla określenia wysokości należności publicznoprawnej lub jej 

zwrotu albo zwrotu innej należności o charakterze podatkowym; 

13) wytwarzania, przetwarzania, obrotu 

i przemytu środków odurzających, 

prekursorów, środków zastępczych lub substancji psychotropowych; 

14) zorganizowanej grupy przestępczej; 

15) mienia znacznej wartości; 

16) użycia przemocy lub groźby bezprawnej w związku z postępowaniem karnym; 

16a) składania fałszywych zeznań oraz przedstawienia przez biegłego, rzeczoznawcę 

lub tłumacza fałszywej opinii, ekspertyzy lub tłumaczenia; 

16b) fałszywego oskarżenia innej osoby o popełnienie przestępstwa, przestępstwa 

skarbowego lub wykroczenia skarbowego; 

16c) tworzenia fałszywych dowodów lub innych podstępnych zabiegów, kierujących 

przeciwko innej osobie ściganie o przestępstwo, przestępstwo skarbowe lub 

wykroczenie skarbowe albo podejmowania 

takich zabiegów w 

toku 

postępowania; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 99/356 

16d) zatajenia dowodów niewinności osoby podejrzanej o popełnienie przestępstwa, 

przestępstwa skarbowego lub wykroczenia skarbowego; 

16e) zawiadomienia organu powołanego do ścigania o niepopełnionym przestępstwie 

lub przestępstwie skarbowym; 

16f) poplecznictwa; 

16g) niezawiadomienia o przestępstwie; 

17) łapownictwa i płatnej protekcji; 

18) stręczycielstwa, kuplerstwa i sutenerstwa; 

19) przestępstw określonych w rozdziale XVI ustawy z dnia 6 czerwca 1997 r. – 

Kodeks karny (Dz. U. z 2024 r. poz. 17 i 1228) oraz w art. 5–8 Rzymskiego 

Statutu Międzynarodowego Trybunału Karnego, sporządzonego w Rzymie dnia 

17 lipca 1998 r. (Dz. U. z 2003 r. poz. 708 oraz z 2018 r. poz. 1753), zwanego 

dalej „Statutem”. 

§ 3a. Kontrola i utrwalanie treści rozmów telefonicznych są dopuszczalne 

również w celu ujawnienia mienia zagrożonego przepadkiem, o którym mowa w art. 

45 § 2 Kodeksu karnego albo art. 33 § 2 Kodeksu karnego skarbowego. 

§ 4. Kontrola i utrwalanie treści rozmów telefonicznych są dopuszczalne 

w stosunku do osoby podejrzanej, oskarżonego oraz w stosunku do pokrzywdzonego 

lub innej osoby, z którą może się kontaktować oskarżony albo która może mieć 

związek ze sprawcą lub z grożącym przestępstwem. 

§ 5. Urzędy 

i instytucje prowadzące działalność 

telekomunikacyjną oraz 

przedsiębiorca telekomunikacyjny w rozumieniu ustawy z dnia 12 lipca 2024 r. – 

Prawo komunikacji elektronicznej, obowiązani 

są umożliwić wykonanie 

postanowienia sądu lub prokuratora w zakresie przeprowadzenia kontroli rozmów 

telefonicznych oraz zapewnić rejestrowanie faktu przeprowadzenia takiej kontroli. 

§ 6. Prawo odtwarzania zapisów ma sąd lub prokurator, a w wypadkach 

niecierpiących zwłoki, za zgodą sądu lub prokuratora, także Policja. 

§ 7. Prawo zapoznawania się z rejestrem przeprowadzonych kontroli rozmów 

telefonicznych ma sąd, a w postępowaniu przygotowawczym – prokurator. 

§ 8. (uchylony)


## Art. 237a. {#kpk-art-237a}
Jeżeli w wyniku kontroli uzyskano dowód popełnienia przez osobę, 

wobec której kontrola była stosowana, innego przestępstwa ściganego z urzędu lub 

przestępstwa skarbowego niż przestępstwo objęte zarządzeniem kontroli, lub 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 100/356 

przestępstwa ściganego z urzędu lub przestępstwa skarbowego popełnionego przez 

inną osobę niż objętą zarządzeniem kontroli, prokurator podejmuje decyzję 

w przedmiocie wykorzystania tego dowodu w postępowaniu karnym.


## Art. 237b. {#kpk-art-237b}
(uchylony)


## Art. 238. {#kpk-art-238}
§ 1. Kontrola 

i utrwalanie 

rozmów 

telefonicznych mogą być 

wprowadzone najwyżej na okres 3 miesięcy, z możliwością przedłużenia, 

w szczególnie uzasadnionym wypadku, na okres najwyżej dalszych 3 miesięcy. 

§ 2. Kontrola powinna być zakończona niezwłocznie po ustaniu przyczyn 

wymienionych w art. 237 § 1–3, najpóźniej jednak z upływem okresu, na który została 

wprowadzona. 

§ 3. Prokurator po zakończeniu kontroli wnosi o zarządzenie zniszczenia 

wszystkich utrwalonych zapisów, 

jeżeli w całości nie mają znaczenia dla 

postępowania karnego. Sąd orzeka w przedmiocie wniosku niezwłocznie, na 

posiedzeniu bez udziału stron. 

§ 4. Po zakończeniu postępowania przygotowawczego prokurator wnosi 

o zarządzenie zniszczenia utrwalonych zapisów w części, w jakiej nie mają znaczenia 

dla postępowania karnego, w którym zarządzono kontrolę i utrwalanie rozmów 

telefonicznych, oraz nie stanowią dowodu, o którym mowa w art. 237a. Sąd orzeka 

w przedmiocie wniosku na posiedzeniu, w którym mogą wziąć udział strony. 

§ 5. Z wnioskiem o zarządzenie zniszczenia utrwalonych zapisów, nie wcześniej 

niż po zakończeniu postępowania przygotowawczego, może wystąpić także osoba 

wymieniona w art. 237 § 4. Sąd orzeka w przedmiocie wniosku na posiedzeniu, 

w którym mogą wziąć udział strony oraz wnioskodawca.


## Art. 239. {#kpk-art-239}
§ 1. Ogłoszenie postanowienia o kontroli 

i utrwalaniu rozmów 

telefonicznych osobie, której ono dotyczy, może być odroczone na czas niezbędny ze 

względu na dobro sprawy. 

§ 2. Ogłoszenie postanowienia, o którym mowa w § 1, w postępowaniu 

przygotowawczym może być odroczone nie później niż do czasu zakończenia tego 

postępowania.


## Art. 240. {#kpk-art-240}
Na postanowienie dotyczące kontroli 

i utrwalania 

rozmów 

telefonicznych przysługuje zażalenie. Osoba, której dotyczy postanowienie, może 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 101/356 

w zażaleniu domagać się zbadania zasadności oraz legalności kontroli i utrwalania 

rozmów telefonicznych. Zażalenie na postanowienie prokuratora rozpoznaje sąd.


## Art. 241. {#kpk-art-241}
Przepisy rozdziału niniejszego stosuje się odpowiednio do kontroli 

oraz do utrwalania przy użyciu środków technicznych treści innych rozmów lub 

przekazów informacji, w tym korespondencji przesyłanej pocztą elektroniczną.


## Art. 242. {#kpk-art-242}
Minister Sprawiedliwości, w porozumieniu z ministrem właściwym do 

spraw informatyzacji, Ministrem Obrony Narodowej oraz ministrem właściwym do 

spraw wewnętrznych, określi, w drodze rozporządzenia, sposób technicznego 

przygotowania sieci służących do przekazywania informacji, do kontroli rozmów 

telefonicznych lub innych przekazów informacji dokonywanych z wykorzystaniem 

tych sieci oraz sposób dokonywania, rejestracji, przechowywania, odtwarzania 

i niszczenia zapisów z kontrolowanych rozmów telefonicznych oraz treści innych 

rozmów lub przekazów informacji, w tym korespondencji przesyłanej pocztą 

elektroniczną, mając na uwadze konieczność właściwego zabezpieczenia 

dokonywanych zapisów przed ich utratą, zniekształceniem lub nieuprawnionym 

ujawnieniem.
