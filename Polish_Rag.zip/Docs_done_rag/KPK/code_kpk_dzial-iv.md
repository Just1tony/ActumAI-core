---
id: "code_kpk_dzial-iv"
title: "KPK — DZIAŁ IV"
source_pdf: "D19970555Lj (1).pdf"
dz_u: "Dz. U. 1997 Nr 89 poz. 555"
status: "obowiązujący"
last_consolidated: "2025-09-11"
law: "Kodeks postępowania karnego"
tags: ["kpk", "kodeks", "postępowanie karne"]
articles_range: {"first": "92", "last": "166"}
---

# DZIAŁ IV

## Art. 92. {#kpk-art-92}
Podstawę orzeczenia może stanowić tylko całokształt okoliczności 

ujawnionych w postępowaniu, mających znaczenie dla rozstrzygnięcia.


## Art. 93. {#kpk-art-93}
§ 1. Jeżeli ustawa nie wymaga wydania wyroku, sąd wydaje 

postanowienie. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 35/356 

§ 2. W kwestiach niewymagających postanowienia prezes sądu, przewodniczący 

wydziału, przewodniczący składu orzekającego albo upoważniony sędzia wydają 

zarządzenia. 

§ 3. W postępowaniu przygotowawczym postanowienia i zarządzenia wydaje 

prokurator oraz inny uprawniony organ, a sąd – w wypadkach przewidzianych 

w ustawie. 

§ 4. W wypadkach określonych w ustawie sąd oraz prokurator wydają polecenia 

Policji lub innym organom.


## Art. 93a. {#kpk-art-93a}
§ 1. W wypadkach określonych w ustawie referendarz sądowy może 

wydawać postanowienia lub zarządzenia. 

§ 2. Polecenia, które zgodnie z ustawą wydaje sąd, może wydawać także 

referendarz sądowy. 

§ 3. Od postanowień i zarządzeń wydanych przez referendarza sądowego może 

być wniesiony sprzeciw. Sprzeciw przysługuje stronom, a także osobie, której 

postanowienie bezpośrednio dotyczy, chyba że ustawa stanowi inaczej. W razie 

wniesienia sprzeciwu postanowienie lub zarządzenie traci moc. 

§ 4. Prezes sądu odmawia przyjęcia sprzeciwu, jeżeli został wniesiony po 

terminie lub przez osobę nieuprawnioną.


## Art. 94. {#kpk-art-94}
§ 1. Postanowienie powinno zawierać: 

oznaczenie organu oraz osoby lub osób, wydających postanowienie; 

datę wydania postanowienia; 

1) 

2) 

3) wskazanie sprawy oraz kwestii, której postanowienie dotyczy; 

4) 

5) 

rozstrzygnięcie z podaniem podstawy prawnej; 

uzasadnienie, chyba że ustawa zwalnia od tego wymagania. 

§ 2. Przepis § 1 stosuje się odpowiednio do zarządzeń.


## Art. 95. {#kpk-art-95}
§ 1. Sąd orzeka na rozprawie w wypadkach wskazanych w ustawie, 

a w innych – na posiedzeniu. Orzeczenia wydawane na posiedzeniu mogą zapadać 

również na rozprawie. 

§ 2. Referendarz sądowy wydaje postanowienia na posiedzeniu.


## Art. 95a. {#kpk-art-95a}
§ 1. W sprawach wskazanych w art. 2a § 1 i 2 Kodeksu wykroczeń 

orzeka na posiedzeniu sąd, który wydał wyrok w pierwszej instancji. 

§ 2. Na postanowienie przysługuje zażalenie. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 36/356


## Art. 95aa. {#kpk-art-95aa}
§ 1. W sprawach wskazanych w art. 4 § 2–4 Kodeksu karnego orzeka 

na posiedzeniu sąd, który wydał wyrok w pierwszej instancji. 

§ 2. Przy orzekaniu sąd bierze pod uwagę czyn objęty wyrokiem i przypisany 

sprawcy na podstawie ustaleń faktycznych przyjętych za podstawę tego wyroku. 

§ 3. Na postanowienie przysługuje zażalenie.


## Art. 95b. {#kpk-art-95b}
§ 1. Posiedzenie odbywa się z wyłączeniem jawności, chyba że ustawa 

stanowi inaczej albo prezes sądu lub sąd zarządzi inaczej. 

§ 1a. Do posiedzeń stosuje się odpowiednio przepis art. 358. 

§ 2. Jawne są posiedzenia, o których mowa w art. 339 § 3 pkt 1, 2 i 5, art. 340, 

art. 341, art. 343 § 5, art. 343a, art. 603, art. 607l § 1, art. 607s § 3, art. 611c § 4 

i art. 611ti § 1. 

§ 3. Do posiedzeń, które odbywają się jawnie, przepisy rozdziału 42 stosuje się 

odpowiednio.


## Art. 96. {#kpk-art-96}
§ 1. Strony oraz osoby niebędące stronami, jeżeli wykażą interes prawny 

w rozstrzygnięciu, mają prawo wziąć udział w posiedzeniu wówczas, gdy ustawa tak 

stanowi, chyba że ich udział jest obowiązkowy. Przepis art. 451 stosuje się 

odpowiednio. 

§ 2. W pozostałych wypadkach nie zawiadamia się ich o posiedzeniu, a mogą 

wziąć w nim udział, jeżeli się stawią, chyba że ustawa stanowi inaczej.


## Art. 96a. {#kpk-art-96a}
Przepisy art. 374 § 3–8 i art. 517ea stosuje się odpowiednio do 

posiedzeń.


## Art. 97. {#kpk-art-97}
Jeżeli zachodzi potrzeba sprawdzenia okoliczności faktycznych przed 

wydaniem orzeczenia na posiedzeniu, sąd dokonuje tego sam albo w tym celu 

wyznacza sędziego ze składu orzekającego bądź zwraca się o wykonanie określonych 

czynności do sądu miejscowo właściwego. Jeżeli czynność nie wymaga 

przeprowadzenia dowodu, może ją wykonać także referendarz sądowy.


## Art. 98. {#kpk-art-98}
§ 1. Uzasadnienie postanowienia sporządza się na piśmie wraz z samym 

postanowieniem. 

§ 2. W sprawie zawiłej lub z innych ważnych przyczyn można odroczyć 

sporządzenie uzasadnienia postanowienia na czas do 7 dni. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 37/356 

§ 3. Nie wymaga uzasadnienia dopuszczenie dowodu, 

jak 

również 

uwzględnienie wniosku, któremu inna strona nie sprzeciwiła się, chyba że orzeczenie 

podlega zaskarżeniu.


## Art. 99. {#kpk-art-99}
§ 1. Tryb i formę uzasadnienia wyroku określają przepisy szczególne. 

§ 2. Zarządzenie wymaga pisemnego uzasadnienia, jeżeli podlega zaskarżeniu.


## Art. 99a. {#kpk-art-99a}
§ 1. Uzasadnienie wyroku sądu pierwszej instancji, w tym wyroku 

nakazowego i wyroku łącznego, oraz wyroku sądu odwoławczego i wyroku wydanego 

w postępowaniu o wznowienie postępowania sporządza się na formularzu według 

ustalonego wzoru. 

§ 2. Minister Sprawiedliwości określi, w drodze 

rozporządzenia, wzory 

formularzy uzasadnień wyroków oraz sposób ich wypełniania, mając na uwadze 

konieczność zamieszczenia w nich niezbędnych informacji wskazanych w ustawie, 

w sposób umożliwiający należyte sporządzenie przez uprawnionego środka 

zaskarżenia, a także właściwe dokonanie kontroli wyroku w razie wniesienia takiego 

środka.


## Art. 100. {#kpk-art-100}
§ 1. Orzeczenie lub zarządzenie wydane na rozprawie ogłasza się 

ustnie. 

§ 1a. Orzeczenie lub zarządzenie wydane na posiedzeniu jawnym ogłasza się 

ustnie. Jeżeli na ogłoszeniu nikt się nie stawił, można uznać wydane orzeczenie lub 

zarządzenie za ogłoszone. Przyczynę odstąpienia od ogłoszenia należy wskazać 

w protokole albo notatce urzędowej z posiedzenia. 

§ 2. Orzeczenie lub zarządzenie wydane na innym posiedzeniu ogłasza się ustnie, 

jeżeli bierze w nim udział strona. 

§ 3. Wyrok doręcza się podmiotom uprawnionym do wniesienia środka 

zaskarżenia, jeżeli ustawa tak stanowi. 

§ 4. Postanowienie albo zarządzenie wydane poza rozprawą, od którego 

przysługuje środek zaskarżenia, doręcza się podmiotom uprawnionym do wniesienia 

tego środka, a postanowienie kończące postępowanie jego stronom, chyba że byli 

obecni przy ogłoszeniu postanowienia albo zarządzenia. Stronom doręcza się również 

postanowienie wraz z uzasadnieniem w wypadku wskazanym w art. 98 § 2. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 38/356 

§ 5. Strony należy powiadomić o treści 

innych postanowień 

i zarządzeń 

wydanych poza rozprawą i posiedzeniem, a także wydanych na posiedzeniu, o którego 

terminie strona nie była zawiadomiona. 

§ 6. Jeżeli ustawa nie zwalnia od równoczesnego sporządzenia uzasadnienia, 

orzeczenie i zarządzenie doręcza się lub ogłasza wraz z uzasadnieniem. W wypadku 

określonym w art. 98 § 2 po ogłoszeniu postanowienia, na wniosek strony obecnej 

przy ogłoszeniu tego postanowienia, podaje się ustnie najważniejsze powody 

rozstrzygnięcia. Obecne strony należy pouczyć o możliwości złożenia takiego 

wniosku. 

§ 7. Jeżeli sprawę rozpoznano z wyłączeniem jawności ze względu na ważny 

interes państwa, zamiast uzasadnienia doręcza się zawiadomienie, że uzasadnienie 

zostało sporządzone. 

§ 8. Po ogłoszeniu lub przy doręczeniu orzeczenia i zarządzenia należy pouczyć 

uczestników postępowania o przysługującym im prawie, terminie i sposobie 

wniesienia środka zaskarżenia lub o tym, że orzeczenie lub zarządzenie nie podlega 

zaskarżeniu. 

§ 9. W razie skazania z zastosowaniem art. 60 § 3 lub 4 Kodeksu karnego lub 

art. 36 § 3 Kodeksu karnego skarbowego po ogłoszeniu lub przy doręczeniu wyroku 

należy pouczyć oskarżonego o treści art. 434 § 4 oraz art. 443. 

§ 10. Podmiot lub stronę, która bierze udział w posiedzeniu przy użyciu urządzeń 

technicznych umożliwiających udział w posiedzeniu na odległość z jednoczesnym 

bezpośrednim przekazem obrazu i dźwięku, na którym wydano postanowienie albo 

zarządzenie, uznaje się za „obecną przy ogłoszeniu” postanowienia albo zarządzenia 

w rozumieniu § 4 lub 6. 

 <Art. 100a. Niezwłocznie po wydaniu orzeczenia albo podlegającego 

zaskarżeniu zarządzenia kopię tego orzeczenia albo zarządzenia zamieszcza się w 

systemie 

teleinformatycznym 

i opatruje 

się unikalnym oznaczeniem 

identyfikującym.> 

 <Art. 100b. § 1. System teleinformatyczny, o którym mowa w art. 100a, 

prowadzi Minister Sprawiedliwości. Realizację 

zadań 

związanych 

z 

prowadzeniem systemu teleinformatycznego Minister Sprawiedliwości może 

powierzyć, w całości lub w części, jednostce organizacyjnej jemu podległej lub 

przez niego nadzorowanej lub Prokuratorowi Krajowemu. 

2025-09-11 

Dodany art. 100a 
wejdzie w życie z 
dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 
 
 
 
 

Dodany art. 100b 
wejdzie w życie z 
1.10.2028 r 
dn. 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

©Kancelaria Sejmu 

s. 39/356 

§ 2. W systemie teleinformatycznym, o którym mowa w art. 100a, gromadzi 

się kopie: 

1) 

2) 

orzeczeń i podlegających zaskarżeniu zarządzeń; 

aktów oskarżenia, wniosków o wydanie wyroku skazującego, wniosków o 

rozpoznanie sprawy w postępowaniu przyspieszonym, wniosków o 

warunkowe umorzenie postępowania, wniosków o umorzenie postępowania 

z powodu 

niepoczytalności 

sprawcy 

i 

o 

zastosowanie 

środka 

zabezpieczającego. 

§ 3. System teleinformatyczny, o którym mowa w art. 100a, służy weryfikacji 

treści i autentyczności kopii dokumentów, o których mowa w § 2. 

§ 4. Administratorem systemu teleinformatycznego, o którym mowa w art. 

100a, jest Minister Sprawiedliwości. 

§ 5. Minister Sprawiedliwości określi, w drodze rozporządzenia, strukturę 

systemu teleinformatycznego, o którym mowa w art. 100a, jego minimalną 

funkcjonalność, warunki organizacyjno-techniczne gromadzenia i pobierania 

zgromadzonych w nim danych oraz sposób opatrywania kopii, o których mowa 

w § 2, unikalnym oznaczeniem identyfikującym, a ponadto może określić 

podmiot, któremu powierza realizację zadań związanych z prowadzeniem tego 

systemu, oraz zakres zadań powierzonych do realizacji, uwzględniając 

konieczność zapewnienia powszechnej dostępności zgromadzonych danych, 

zapewnienia sprawności wprowadzania danych do systemu, zapewnienia 

kompletności i prawidłowości danych przetwarzanych w systemie oraz potrzebę 

zabezpieczenia danych przed nieuprawnionym dostępem do nich.> 

Art. 101–104. (uchylone)


## Art. 105. {#kpk-art-105}
§ 1. Oczywiste omyłki pisarskie i rachunkowe oraz w obliczeniu 

terminów w orzeczeniu lub zarządzeniu albo w ich uzasadnieniu można sprostować 

w każdym czasie. 

§ 2. Sprostowania dokonuje organ, który popełnił omyłkę. Jeżeli postępowanie 

toczy się przed instancją odwoławczą, może ona z urzędu sprostować orzeczenie 

pierwszej instancji. 

§ 3. Sprostowanie orzeczenia 

lub 

jego uzasadnienia następuje w drodze 

postanowienia, a sprostowanie zarządzenia w drodze zarządzenia. 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 40/356 

§ 4. Na postanowienie lub zarządzenie co do sprostowania wydane w pierwszej 

instancji służy zażalenie.


## Art. 106. {#kpk-art-106}
Przepisy art. 100 § 4–8 stosuje się odpowiednio w postępowaniu 

przygotowawczym.


## Art. 107. {#kpk-art-107}
§ 1. Sąd lub referendarz sądowy nadaje na żądanie osoby uprawnionej 

klauzulę wykonalności orzeczeniu podlegającemu wykonaniu w drodze egzekucji. 

§ 2. Orzeczenia 

nakładające 

obowiązek 

naprawienia 

szkody 

lub 

zadośćuczynienia za doznaną krzywdę oraz nawiązkę orzeczoną na rzecz 

pokrzywdzonego uważa się za orzeczenia co do roszczeń majątkowych, jeżeli nadają 

się do egzekucji w myśl przepisów Kodeksu postępowania cywilnego. 

§ 3. Przepisy § 1 i 2 stosuje się odpowiednio do obowiązku wynikającego 

z ugody zawartej przed sądem lub referendarzem sądowym, a także ugody zawartej 

w postępowaniu mediacyjnym. 

§ 4. Sąd lub referendarz sądowy odmawia nadania klauzuli wykonalności 

ugodzie zawartej przed mediatorem, w całości lub w części, jeżeli ugoda jest 

sprzeczna z prawem lub zasadami współżycia społecznego albo zmierza do obejścia 

prawa. 


# Rozdział 12
 

Narada i głosowanie


## Art. 108. {#kpk-art-108}
§ 1. Przebieg narady i głosowania nad orzeczeniem jest tajny, 

a zwolnienie od zachowania w tym względzie tajemnicy nie jest dopuszczalne. 

§ 2. Podczas narady i głosowania oprócz członków składu orzekającego może 

być obecny jedynie protokolant, chyba że przewodniczący uzna jego obecność za 

zbędną.


## Art. 109. {#kpk-art-109}
§ 1. Naradą i głosowaniem kieruje przewodniczący, a jeżeli co do 

porządku i sposobu narady oraz głosowania podniesione zostaną wątpliwości, 

rozstrzyga je skład orzekający. 

§ 2. Po naradzie przewodniczący zbiera głosy poczynając od najmłodszego, 

najpierw od ławników według ich wieku, następnie od sędziów według ich 

starszeństwa służbowego, a sam głosuje ostatni. Sprawozdawca, jeżeli nie jest 

przewodniczącym, głosuje pierwszy. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 41/356


## Art. 110. {#kpk-art-110}
Narada i głosowanie nad wyrokiem odbywają się osobno co do winy 

i kwalifikacji prawnej czynu, co do kary, co do środków karnych, co do przepadku, co 

do środków kompensacyjnych oraz co do pozostałych kwestii.


## Art. 111. {#kpk-art-111}
§ 1. Orzeczenia zapadają większością głosów. 

§ 2. Jeżeli zdania tak się podzielą, że żadne z nich nie uzyska większości, zdanie 

najmniej korzystne dla oskarżonego przyłącza się do zdania najbardziej doń 

zbliżonego, aż do uzyskania większości.


## Art. 112. {#kpk-art-112}
Sędzia, który głosował przeciwko uznaniu oskarżonego za winnego, 

może wstrzymać się od głosowania nad dalszymi kwestiami; wówczas głos tego 

sędziego przyłącza się do zdania najprzychylniejszego dla oskarżonego.


## Art. 113. {#kpk-art-113}
Orzeczenie podpisują wszyscy członkowie składu orzekającego, nie 

wyłączając przegłosowanego, chyba że orzeczenie zamieszczono w protokole.


## Art. 114. {#kpk-art-114}
§ 1. Przy składaniu podpisu członek składu orzekającego ma prawo 

zaznaczyć na orzeczeniu swoje zdanie odrębne. Wzmianka dotycząca zdania 

odrębnego powinna wskazywać, w jakiej części i w jakim kierunku członek składu 

orzekającego kwestionuje orzeczenie. 

§ 2. Zdanie odrębne może dotyczyć również samego uzasadnienia orzeczenia; 

wówczas zdanie to, ze wskazaniem daty jego zgłoszenia, zaznacza się przy 

podpisywaniu uzasadnienia. Przepis § 1 zdanie drugie stosuje się odpowiednio. 

§ 3. Uzasadnienie zdania odrębnego należy sporządzić, jeżeli sporządza się 

uzasadnienie orzeczenia. 

§ 4. Uzasadnienie zdania odrębnego sporządza członek składu orzekającego, 

który je zgłosił, w terminie przewidzianym dla sporządzenia uzasadnienia orzeczenia, 

a jeżeli zdanie odrębne dotyczy uzasadnienia orzeczenia – w terminie 7 dni od 

zgłoszenia zdania odrębnego. Obowiązek sporządzenia uzasadnienia zdania 

odrębnego nie dotyczy ławnika. 

§ 5. Jeżeli ustawa wymaga doręczenia orzeczenia wraz z uzasadnieniem, doręcza 

się również uzasadnienie zdania odrębnego. Przepis art. 100 § 7 stosuje się 

odpowiednio.


## Art. 115. {#kpk-art-115}
§ 1. Uzasadnienie orzeczenia podpisują osoby, które orzeczenie 

wydały, nie wyłączając osoby przegłosowanej. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 42/356 

§ 2. W sprawach rozpoznawanych w składzie sędziego i dwóch ławników 

uzasadnienie podpisuje tylko przewodniczący, chyba że zgłoszono zdanie odrębne. 

W sprawach rozpoznawanych w składzie dwóch sędziów 

i trzech 

ławników 

uzasadnienie podpisują obaj sędziowie, chyba że zgłoszono zdanie odrębne. 

§ 3. Jeżeli nie można uzyskać podpisu przewodniczącego lub innego członka 

składu orzekającego, jeden z podpisujących czyni o tym wzmiankę na uzasadnieniu 

z zaznaczeniem przyczyny tego faktu. 


# Rozdział 13
 

Porządek czynności procesowych 

[Art. 116. Jeżeli ustawa nie stanowi inaczej, strony i inni uprawnieni do wzięcia 

udziału w czynności procesowej mogą składać wnioski i inne oświadczenia na piśmie 

albo ustnie do protokołu.] 

 <Art. 116. § 1. Jeżeli ustawa nie stanowi inaczej, strony i inni uprawnieni 

do wzięcia udziału w czynności procesowej mogą składać oświadczenia, w tym 

wnioski, na piśmie albo ustnie do protokołu. Za oświadczenie złożone na piśmie 

uważa się również oświadczenie złożone elektronicznie. 

§ 2. Oświadczenie składane elektronicznie opatruje się kwalifikowanym 

podpisem elektronicznym, podpisem zaufanym albo podpisem osobistym i wysyła 

na adres do doręczeń elektronicznych, o którym mowa w art. 2 pkt 1 ustawy z 

dnia 18 listopada 2020 r. o doręczeniach elektronicznych (Dz. U. z 2024 r. poz. 

1045), zwany dalej „adresem do doręczeń elektronicznych”, wpisany do bazy 

adresów elektronicznych, o której mowa w art. 25 tej ustawy. 

§ 3. Oświadczenie złożone elektronicznie włącza się do akt sprawy.> 

<Art. 116a. § 1. Jeżeli przepis ustawy tak stanowi, pisma można wnosić 

przez umieszczenie ich treści w portalu informacyjnym, o którym mowa 

w art. 53e § 1 ustawy z dnia 27 lipca 2001 r. – Prawo o ustroju sądów 

powszechnych (Dz. U. z 2024 r. poz. 334 i 1907 oraz z 2025 r. poz. 526, 820, 1172 

i 1178), zwanym dalej „portalem informacyjnym”, w sposób, który umożliwia 

wnoszącemu pismo uzyskanie dokumentu elektronicznego potwierdzającego 

wniesienie pisma do sądu. 

§ 2. Pisma wnoszone za pośrednictwem portalu informacyjnego włącza się 

do akt sprawy.> 

2025-09-11 

Nowe brzmienie 
art. 116 wejdzie 
w życie z dn. 
1.10.2029 r. 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

Dodany art. 116a 
wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1178). 

 
 
 
 
 

©Kancelaria Sejmu 

s. 43/356


## Art. 117. {#kpk-art-117}
§ 1. Uprawnionego do wzięcia udziału w czynności procesowej 

zawiadamia się o jej czasie i miejscu, chyba że ustawa stanowi inaczej. 

§ 2. Czynności nie przeprowadza się, jeżeli osoba uprawniona nie stawiła się, 

a brak dowodu, że została o niej powiadomiona, oraz jeżeli zachodzi uzasadnione 

przypuszczenie, że niestawiennictwo wynikło z powodu przeszkód żywiołowych lub 

innych wyjątkowych przyczyn, a także wtedy, gdy osoba ta usprawiedliwiła należycie 

niestawiennictwo i wnosi o nieprzeprowadzanie czynności bez jej obecności, chyba że 

ustawa stanowi inaczej. 

§ 2a. Usprawiedliwienie niestawiennictwa z powodu choroby oskarżonych, 

świadków, obrońców, pełnomocników i innych uczestników postępowania, których 

obecność była obowiązkowa lub którzy wnosili o dopuszczenie do czynności, będąc 

uprawnionymi do wzięcia w niej udziału, wymaga przedstawienia zaświadczenia 

potwierdzającego niemożność stawienia się na wezwanie lub zawiadomienie organu 

prowadzącego postępowanie, wystawionego przez lekarza sądowego. 

§ 3. W razie niestawiennictwa strony, obrońcy lub pełnomocnika, których 

stawiennictwo jest obowiązkowe, czynności procesowej nie przeprowadza się, chyba 

że ustawa stanowi inaczej. 

§ 3a. Niestawiennictwo 

strony, która została należycie zawiadomiona 

o czynności procesowej, niezależnie od jego przyczyny, nie stoi na przeszkodzie 

przeprowadzeniu tej czynności, jeżeli stawił się jej obrońca lub pełnomocnik. Nie 

dotyczy to czynności, w której udział strony jest obowiązkowy. 

§ 4. (uchylony) 

§ 5. Przepisu § 2a nie stosuje się do osób pozbawionych wolności, których 

zasady usprawiedliwiania niestawiennictwa regulują odrębne przepisy.


## Art. 117a. {#kpk-art-117a}
§ 1. Jeżeli strona ma więcej niż jednego obrońcę lub pełnomocnika, 

czynność procesową można przeprowadzić w wypadku stawiennictwa przynajmniej 

jednego z nich, chyba że strona wyrazi zgodę na przeprowadzenie czynności bez 

udziału obrońcy lub pełnomocnika, których udział nie jest obowiązkowy. 

§ 2. Przepis § 1 stosuje się odpowiednio do pełnomocnika osoby niebędącej 

stroną, o której mowa w art. 87 § 2.


## Art. 118. {#kpk-art-118}
§ 1. Znaczenie czynności procesowej ocenia się według treści 

złożonego oświadczenia. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 44/356 

§ 2. Niewłaściwe oznaczenie czynności procesowej, a zwłaszcza środka 

zaskarżenia, nie pozbawia czynności znaczenia prawnego. 

§ 3. Pismo w sprawie należącej do właściwości sądu, prokuratora, Policji lub 

innego organu dochodzenia, skierowane do niewłaściwego organu, przekazuje się 

właściwemu organowi.


## Art. 119. {#kpk-art-119}
§ 1. Pismo procesowe powinno zawierać: 

1) 

oznaczenie organu, do którego jest skierowane, oraz sprawy, której dotyczy; 

 [2) oznaczenie oraz adres wnoszącego pismo, a także – w pierwszym piśmie 

złożonym w sprawie – numer telefonu, telefaksu i adres poczty elektronicznej lub 

oświadczenie o ich nieposiadaniu;] 

 <2) oznaczenie oraz adres wnoszącego pismo, a także – w pierwszym piśmie 

złożonym w sprawie: 

a) oświadczenie wnoszącego pismo będącego podmiotem niepublicznym, o 

którym mowa w art. 2 pkt 5 ustawy z dnia 18 listopada 2020 r. o 

doręczeniach elektronicznych, o wyrażeniu zgody na dokonywanie 

doręczeń na adres do doręczeń elektronicznych, wraz ze wskazaniem 

tego adresu albo braku takiej zgody, chyba że takie oświadczenie już 

zostało przez niego w tym postępowaniu złożone, 

b) numer 

telefonu, 

telefaksu 

i adres poczty elektronicznej 

lub 

oświadczenie o ich nieposiadaniu;> 

<2a) numer wpisu na właściwą listę adwokatów lub radców prawnych – 

w przypadku obrońcy lub pełnomocnika będącego adwokatem lub radcą 

prawnym;> 

3) 

4) 

treść wniosku lub oświadczenia, w miarę potrzeby z uzasadnieniem; 

datę i podpis składającego pismo. 

§ 2. Za osobę, która nie może się podpisać, pismo podpisuje osoba przez nią 

upoważniona, ze wskazaniem przyczyny złożenia swego podpisu. 

<§ 3. Pismo procesowe wniesione za pośrednictwem portalu informacyjnego 

opatruje się kwalifikowanym podpisem elektronicznym, podpisem zaufanym 

albo podpisem osobistym, a w przypadku prokuratora – także zaawansowanym 

podpisem elektronicznym wydawanym przez właściwe jednostki organizacyjne 

prokuratury. 

2025-09-11 

Nowe brzmienie 
pkt 2 w § 1 w art. 
119 wejdzie w 
życie 
dn. 
z 
1.10.2029 r. 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

Dodany pkt 2a w 
§ 1 oraz dodane § 
3 i 4 w art. 119 
wejdą w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1178). 

 
 
 
 
 
 

©Kancelaria Sejmu 

s. 45/356 

§ 4. Minister Sprawiedliwości w porozumieniu z ministrem właściwym do 

spraw informatyzacji określi, w drodze rozporządzenia, tryb i sposób wnoszenia 

pism procesowych w postaci elektronicznej za pośrednictwem portalu 

informacyjnego, mając na względzie skuteczność ich wnoszenia, konieczność 

zapewnienia sprawnego toku postępowania, a także ochronę praw osób 

wnoszących pisma.> 

<Art. 119a. Dokumenty dołączane do pisma procesowego wnoszonego za 

pośrednictwem portalu informacyjnego obrońca lub pełnomocnik będący 

adwokatem, 

radcą 

prawnym 

lub 

radcą Prokuratorii Generalnej 

Rzeczypospolitej Polskiej opatrują kwalifikowanym podpisem elektronicznym, 

podpisem zaufanym albo podpisem osobistym. Strona, która powołuje się 

w piśmie na dokument, jest obowiązana na żądanie sądu lub strony przeciwnej 

złożyć oryginał dokumentu w sądzie jeszcze przed rozprawą.>


## Art. 120. {#kpk-art-120}
[§ 1. Jeżeli pismo nie odpowiada wymaganiom 

formalnym, 

przewidzianym w art. 119 lub w przepisach szczególnych, a brak jest tego rodzaju, że 

pismo nie może otrzymać biegu, albo brak polega na niezłożeniu należytych opłat lub 

upoważnienia do podjęcia czynności procesowej, wzywa się osobę, która wniosła 

pismo, do usunięcia braku w terminie 7 dni.] 

 <§ 1. Jeżeli: 

1) pismo nie odpowiada wymaganiom formalnym, przewidzianym w art. 119 § 

1 pkt 1, pkt 2 lit. b, pkt 3 i 4 lub § 2 lub w przepisach szczególnych, a brak 

jest tego rodzaju, że pismo nie może otrzymać biegu, 

2) pismo nie odpowiada wymaganiom formalnym, przewidzianym w art. 119 § 

1 pkt 2 lit. a, 

3) brak polega na niezłożeniu należytych opłat lub upoważnienia do podjęcia 

czynności procesowej 

– wzywa się osobę, która wniosła pismo, do usunięcia braku w terminie 7 dni.> 

 <§ 1a. Wzywając do usunięcia braku, o którym mowa w § 1 pkt 2, osobę, 

która wniosła pismo, należy pouczyć o skutkach procesowych wyrażenia zgody 

albo jej braku.> 

2025-09-11 

Dodany art. 119a 
wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1178). 

Nowe brzmienie 
§ 1 i dodany § 1a 
w art. 120 wejdą 
w życie z dn. 
1.10.2029 r 
.(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 
 
 
 
 
 

©Kancelaria Sejmu 

s. 46/356 

§ 2. W razie uzupełnienia braku w terminie, pismo wywołuje skutki od dnia jego 

wniesienia. W razie nieuzupełnienia braku w terminie, pismo uznaje się za 

bezskuteczne, o czym należy pouczyć przy doręczeniu wezwania. 

§ 3. W postępowaniu przed sądem zarządzenia w sprawach, o których mowa 

w § 1 i 2, może wydać także referendarz sądowy.


## Art. 121. {#kpk-art-121}
Jeżeli osoba uczestnicząca w czynności procesowej odmawia podpisu 

lub nie może go złożyć, organ dokonujący czynności zaznacza przyczynę braku 

podpisu. 


# Rozdział 14
 

Terminy


## Art. 122. {#kpk-art-122}
§ 1. Czynność procesowa dokonana po upływie terminu zawitego jest 

bezskuteczna. 

§ 2. Zawite są terminy do wnoszenia środków zaskarżenia oraz inne, które 

ustawa za zawite uznaje.


## Art. 123. {#kpk-art-123}
§ 1. Do biegu terminu nie wlicza się dnia, od którego liczy się dany 

termin. 

§ 2. Jeżeli termin jest oznaczony w tygodniach, miesiącach lub latach, koniec 

terminu przypada na ten dzień tygodnia lub miesiąca, który odpowiada początkowi 

terminu; jeżeli w danym miesiącu nie ma takiego dnia, koniec terminu przypada na 

ostatni dzień tego miesiąca. 

§ 3. Jeżeli koniec terminu przypada na dzień uznany przez ustawę za dzień wolny 

od pracy lub na sobotę, czynność można wykonać następnego dnia, który nie jest 

dniem wolnym od pracy ani sobotą. 

 [Art. 124. Termin jest zachowany, jeżeli przed jego upływem pismo zostało 

nadane w placówce podmiotu zajmującego się doręczaniem korespondencji na terenie 

Unii Europejskiej, w polskim urzędzie konsularnym lub złożone przez żołnierza, z 

wyjątkiem żołnierza pełniącego terytorialną służbę wojskową dyspozycyjnie, w 

dowództwie 

jednostki wojskowej albo przez osobę pozbawioną wolności w 

administracji odpowiedniego zakładu, a przez członka załogi polskiego statku 

morskiego – kapitanowi statku.] 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 47/356 

 <Art. 124. Termin jest zachowany, jeżeli przed jego upływem pismo 

zostało: 

1) nadane w placówce podmiotu zajmującego się doręczaniem korespondencji 

na terenie Unii Europejskiej albo w polskim urzędzie konsularnym; 

2) 

złożone przez żołnierza, z wyjątkiem żołnierza pełniącego terytorialną 

służbę wojskową dyspozycyjnie, w dowództwie jednostki wojskowej albo 

przez osobę pozbawioną wolności w administracji odpowiedniego zakładu, 

a przez członka załogi polskiego statku morskiego – kapitanowi statku; 

3) wysłane na adres do doręczeń elektronicznych.> 

Nowe brzmienie 
art. 124 wejdzie 
w życie z dn. 
1.10.2029 r. 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

<Art. 124a. Jeżeli pismo zostanie wniesione przez umieszczenie jego treści 

w portalu informacyjnym, uznaje się je za wniesione w chwili wskazanej 

w elektronicznym potwierdzeniu wniesienia pisma.> 

Dodany art. 124a 
wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1178).


## Art. 125. {#kpk-art-125}
Pismo omyłkowo wniesione przed upływem 

terminu do 

niewłaściwego sądu, prokuratora, organu Policji albo innego organu postępowania 

przygotowawczego uważa się za wniesione z zachowaniem terminu.


## Art. 126. {#kpk-art-126}
§ 1. Jeżeli niedotrzymanie terminu zawitego nastąpiło z przyczyn od 

strony niezależnych, strona w zawitym terminie 7 dni od daty ustania przeszkody 

może zgłosić wniosek o przywrócenie terminu, dopełniając jednocześnie czynności, 

która miała być w terminie wykonana; to samo stosuje się do osób niebędących 

stronami. 

§ 2. W kwestii przywrócenia terminu orzeka postanowieniem organ, przed 

którym należało dokonać czynności. 

§ 3. Na odmowę przywrócenia terminu przysługuje zażalenie.


## Art. 127. {#kpk-art-127}
Wniosek o przywrócenie 

terminu nie wstrzymuje wykonania 

orzeczenia, jednakże organ, do którego wniosek złożono, lub organ powołany do 

rozpoznania środka zaskarżenia może wstrzymać wykonanie orzeczenia; odmowa 

wstrzymania nie wymaga uzasadnienia.


## Art. 127a. {#kpk-art-127a}
§ 1. Jeżeli warunkiem skuteczności czynności procesowej jest jej 

dokonanie przez obrońcę lub pełnomocnika, termin do jej dokonania ulega 

zawieszeniu dla strony postępowania na czas rozpoznania wniosku o przyznanie 

pomocy prawnej w tym zakresie. 

2025-09-11 

 
 
 
 
 
 

©Kancelaria Sejmu 

s. 48/356 

§ 2. W wypadku wyznaczenia obrońcy lub pełnomocnika z urzędu termin do 

dokonania czynności przez wyznaczonego przedstawiciela procesowego rozpoczyna 

bieg od daty doręczenia mu postanowienia lub zarządzenia o tym wyznaczeniu.


## Art. 127b. {#kpk-art-127b}
Jeżeli czas trwania środków przymusu jest określony w tygodniach, 

miesiącach lub latach, przyjmuje się, że tydzień liczy się za dni 7, miesiąc za dni 30, 

a rok za dni 365.


## Art. 127c. {#kpk-art-127c}
Za dzień trwania środka przymusu skutkującego pozbawieniem 

wolności przyjmuje się okres 24 godzin 

liczony od chwili rzeczywistego pozbawienia wolności. 


# Rozdział 15
 

Doręczenia


## Art. 128. {#kpk-art-128}
[§ 1. Orzeczenia i zarządzenia doręcza się w uwierzytelnionych 

odpisach, jeżeli ustawa nakazuje ich doręczenie.] 

 <§ 1. Orzeczenie albo podlegające zaskarżeniu zarządzenie doręcza się w 

postaci kopii tego orzeczenia albo zarządzenia zamieszczonego w systemie 

teleinformatycznym, o którym mowa w art. 100a, opatrzonej unikalnym 

oznaczeniem identyfikującym.> 

Nowe brzmienie 
§ 1 oraz dodane § 
1a i 1b w art. 128 
wejdą w życie z 
dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 <§ 1a. Orzeczenie albo zarządzenie doręcza się, jeżeli ustawa tak stanowi. 

§ 1b. Przepis § 1 stosuje się odpowiednio do aktu oskarżenia, wniosku o 

wydanie wyroku skazującego, wniosku o rozpoznanie sprawy w postępowaniu 

przyspieszonym, wniosku o warunkowe umorzenie postępowania, wniosku 

o umorzenie postępowania z powodu niepoczytalności sprawcy i o zastosowanie 

środka zabezpieczającego.> 

§ 2. Wszelkie pisma przeznaczone dla uczestników postępowania doręcza się 

w taki sposób, by treść ich nie była udostępniona osobom niepowołanym. 

§ 3. Orzeczenia i zarządzenia mogą być doręczane przez umieszczenie ich treści 

w portalu informacyjnym.


## Art. 129. {#kpk-art-129}
§ 1. W wezwaniu należy oznaczyć organ wysyłający oraz podać, 

w jakiej sprawie, w jakim charakterze, miejscu i czasie ma się stawić adresat i czy jego 

stawiennictwo jest obowiązkowe, a także uprzedzić o skutkach niestawiennictwa. 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 49/356 

§ 2. Przepis § 1 stosuje się odpowiednio do zawiadomień. 

§ 3. Jeżeli od dnia doręczenia pisma biegnie termin wykonania czynności 

procesowej, należy pouczyć o tym adresata.


## Art. 130. {#kpk-art-130}
Pisma doręcza się za pokwitowaniem odbioru. [Odbierający 

potwierdza odbiór swym czytelnym podpisem zawierającym imię i nazwisko na 

zwrotnym pokwitowaniu, na którym doręczający potwierdza swym podpisem sposób 

doręczenia.] <Jeżeli ustawa nie stanowi inaczej, odbierający potwierdza odbiór 

swym czytelnym podpisem zawierającym imię i nazwisko na zwrotnym 

pokwitowaniu, na którym doręczający potwierdza swym podpisem sposób 

doręczenia.>


## Art. 131. {#kpk-art-131}
[§ 1. Wezwania, zawiadomienia oraz inne pisma, od których daty 

doręczenia biegną terminy, doręcza się przez: 

1) 

operatora pocztowego w rozumieniu ustawy z dnia 23 listopada 2012 r. – Prawo 

pocztowe (Dz. U. z 2023 r. poz. 1640 oraz z 2024 r. poz. 467, 1222 i 1717); 

2) 

3) 

pracownika organu wysyłającego; 

organ procesowy dokonujący czynności procesowej – w toku tej czynności; 

4) Policję – tylko w razie niezbędnej konieczności.] 

 <§ 1. Wezwania, zawiadomienia oraz inne pisma doręcza się: 

1) na adres do doręczeń 

elektronicznych; doręczenia podmiotowi 

niepublicznemu, o którym mowa w art. 2 pkt 5 ustawy z dnia 18 listopada 

2020 r. o doręczeniach elektronicznych, dokonuje się za jego zgodą 

wyrażoną w tym postępowaniu; 

2) przez organ procesowy dokonujący czynności procesowej – w toku tej 

czynności.> 

 <§ 1a. Jeżeli doręczenia nie można dokonać w sposób wskazany w § 1, 

doręczenia dokonuje się: 

1) przez operatora wyznaczonego w ramach publicznej usługi hybrydowej, o 

której mowa w art. 2 pkt 7 ustawy z dnia 18 listopada 2020 r. o doręczeniach 

elektronicznych; 

2) przez operatora pocztowego w rozumieniu ustawy z dnia 23 listopada 2012 

r. – Prawo pocztowe (Dz. U. z 2023 r. poz. 1640 oraz z 2024 r. poz. 467, 1222 

i 1717); 

2025-09-11 

Nowe brzmienie 
zd. drugiego w 
art. 130 wejdzie 
w życie z dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

Nowe brzmienie 
§ 1 i dodany § 1a 
w art. 131 wejdą 
w życie z dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 
 
 
 
 
 

Dodany art. 131a 
oraz 
nowe 
brzmienie § 1 i 
zd. drugiego w § 
1a w art. 132 
wejdą w życie z 
dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

©Kancelaria Sejmu 

s. 50/356 

3) przez pracownika organu wysyłającego; 

4) przez Policję – tylko w razie niezbędnej konieczności.> 

§ 2. Jeżeli w sprawie ustalono tylu pokrzywdzonych, że ich indywidualne 

zawiadomienie o przysługujących im uprawnieniach spowodowałoby poważne 

utrudnienie w prowadzeniu postępowania, zawiadamia się ich poprzez ogłoszenie 

w prasie, radiu, telewizji lub na stronie internetowej sądu albo prokuratury. 

§ 3. Jeżeli istnieje obowiązek doręczenia postanowienia, przepis § 2 stosuje się 

odpowiednio. Należy jednak zawsze doręczyć je temu pokrzywdzonemu, który 

w zawitym terminie 7 dni od dnia ogłoszenia o to się zwróci. 

 <Art. 131a. Jeżeli doręczenie jest dokonywane w sposób wskazany w art. 

131 § 1 pkt 1, w wypadku braku dowodu otrzymania, w rozumieniu ustawy z dnia 

18 listopada 2020 r. o doręczeniach elektronicznych, pismo uznaje się za 

doręczone po upływie 14 dni od dnia wystawienia dowodu wysłania w rozumieniu 

tej ustawy.>


## Art. 132. {#kpk-art-132}
[§ 1. Pismo doręcza się adresatowi osobiście.] 

 <§ 1. Pismo doręczane w sposób wskazany w art. 131 § 1 pkt 2 lub § 1a 

doręcza się adresatowi osobiście.> 

§ 1a. Na wniosek adresata doręczenie może być dokonane na wskazany przez 

niego adres skrytki pocztowej. [W tym wypadku pismo przesłane za pośrednictwem 

operatora pocztowego, o którym mowa w art. 131 § 1 pkt 1, składa się w placówce 

pocztowej tego operatora, umieszczając zawiadomienie o tym w skrytce pocztowej 

adresata.] <W tym wypadku pismo przesłane za pośrednictwem operatora, o 

którym mowa w art. 131 § 1a pkt 1 lub 2, składa się w placówce pocztowej 

operatora pocztowego w rozumieniu ustawy z dnia 23 listopada 2012 r. – Prawo 

pocztowe, umieszczając zawiadomienie o tym w skrytce pocztowej adresata.> 

§ 2. W razie chwilowej nieobecności adresata w jego mieszkaniu pismo doręcza 

się dorosłemu domownikowi. W razie nieobecności domownika pismo doręcza się 

administracji domu, dozorcy domu lub sołtysowi, jeżeli podejmą się oddać pismo 

adresatowi. Przepis art. 133 § 2 stosuje się odpowiednio. 

§ 3. Pismo może być także doręczone za pośrednictwem telefaksu lub poczty 

elektronicznej. W takim wypadku dowodem doręczenia jest potwierdzenie transmisji 

danych. 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 51/356 

§ 4. Przepisów § 2 i 3 oraz art. 133 § 3 nie stosuje się do doręczenia oskarżonemu 

zawiadomienia o pierwszym terminie rozprawy głównej, terminie posiedzenia, 

o którym mowa w art. 341 § 1, art. 343 § 5, art. 343a i art. 420 § 1, oraz doręczenia 

wyroku, o którym mowa w art. 500 § 1.


## Art. 133. {#kpk-art-133}
[§ 1. Jeżeli doręczenia nie można dokonać w sposób wskazany 

w art. 132, pismo przesłane za pośrednictwem operatora pocztowego w rozumieniu 

ustawy z dnia 23 listopada 2012 r. – Prawo pocztowe pozostawia się w najbliższej 

placówce pocztowej 

tego operatora pocztowego, a przesłane w inny sposób 

w najbliższej jednostce Policji albo we właściwym urzędzie gminy.] 

 <§ 1. Jeżeli doręczenia nie można dokonać w sposób wskazany w art. 132, 

pismo przesłane za pośrednictwem operatora, o którym mowa w art. 131 § 1a pkt 

1 lub 2, pozostawia się w najbliższej placówce pocztowej operatora pocztowego w 

rozumieniu ustawy z dnia 23 listopada 2012 r. – Prawo pocztowe, a przesłane w 

inny sposób w najbliższej jednostce Policji albo we właściwym urzędzie gminy.> 

§ 2. O pozostawieniu pisma w myśl § 1 doręczający umieszcza zawiadomienie 

w skrzynce do doręczania korespondencji bądź na drzwiach mieszkania adresata lub 

w innym widocznym miejscu ze wskazaniem, gdzie i kiedy pismo pozostawiono oraz 

że należy je odebrać w ciągu 7 dni; w razie bezskutecznego upływu tego terminu, 

należy czynność zawiadomienia powtórzyć jeden raz. W razie dokonania tych 

czynności pismo uznaje się za doręczone. 

§ 2a. Pismo pozostawione w placówce pocztowej w rozumieniu ustawy z dnia 

23 listopada 2012 r. – Prawo pocztowe może zostać odebrane także przez osobę 

upoważnioną na podstawie pełnomocnictwa pocztowego do odbioru przesyłek 

pocztowych w rozumieniu tej ustawy. 

§ 2b. (uchylony) 

§ 2c. (uchylony) 

Nowe brzmienie 
§ 1 w art. 133 
wejdzie w życie z 
dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

§ 3. Pismo można również pozostawić osobie upoważnionej do odbioru 

korespondencji w miejscu stałego zatrudnienia adresata.


## Art. 133a. {#kpk-art-133a}
[§ 1. Sąd dokonuje doręczeń pism procesowych lub innych pism 

prokuratorowi, obrońcy i pełnomocnikowi będącemu adwokatem lub radcą prawnym, 

Prokuratorii Generalnej Rzeczypospolitej Polskiej, przez umieszczenie ich treści 

w portalu informacyjnym, o którym mowa w art. 53e § 1 ustawy z dnia 27 lipca 

Nowe brzmienie 
§ 1 w art. 133a 
wejdzie w życie z 
dn. 1.06.2026 r. 
(Dz. U. z 2025 r. 
poz. 1178). 

2025-09-11 

 
 
 
 
 
 

©Kancelaria Sejmu 

s. 52/356 

2001 r. – Prawo o ustroju sądów powszechnych (Dz. U. z 2024 r. poz. 334), w sposób 

umożliwiający uzyskanie przez nadawcę i odbiorcę dokumentu potwierdzającego 

doręczenie.] 

<§ 1. Sąd dokonuje doręczeń pism procesowych 

lub 

innych pism 

prokuratorowi, obrońcy i pełnomocnikowi będącemu adwokatem lub radcą 

prawnym, Prokuratorii Generalnej Rzeczypospolitej Polskiej, a także stronie, 

która dokonała wyboru takiego sposobu doręczania, przez umieszczenie ich treści 

w portalu informacyjnym w sposób, który umożliwia uzyskanie przez nadawcę 

i odbiorcę dokumentu potwierdzającego doręczenie.> 

<§ 1a. Oświadczenie o wyborze doręczeń dokonywanych w sposób, 

o którym mowa w § 1, lub oświadczenie o rezygnacji z nich strona składa za 

pośrednictwem portalu informacyjnego i opatruje kwalifikowanym podpisem 

elektronicznym, podpisem zaufanym albo podpisem osobistym. Oświadczenie 

o rezygnacji z doręczeń dokonywanych w sposób, o którym mowa w § 1, można 

Dodany § 1a w 
art. 133a wejdzie 
w życie z dn. 
1.06.2026 r. (Dz. 
U. z 2025 r. poz. 
1178). 

złożyć również na piśmie.> 

[§ 2. Sąd może doręczyć pismo procesowe lub inne pismo w sposób określony 

w § 1, jeżeli dysponuje nim w postaci elektronicznej. Nie dotyczy to pism, które 

podlegają doręczeniu wraz z odpisami pism procesowych stron 

lub 

innymi 

dokumentami niepochodzącymi od sądu.] 

Nowe brzmienie 
§ 2 w art. 133a 
wejdzie w życie z 
dn. 1.03.2026 r. 
(Dz. U. z 2025 r. 
poz. 1178). 

<§ 2. Sąd może doręczyć pismo procesowe lub inne pismo w sposób 

określony w § 1, jeżeli dysponuje nim w postaci elektronicznej. Nie dotyczy to 

pism, które podlegają doręczeniu wraz z odpisami pism procesowych stron lub 

innymi dokumentami niepochodzącymi od sądu, chyba że zostały złożone przez 

umieszczenie ich treści w portalu informacyjnym na podstawie art. 428 § 3.> 

§ 3. W przypadku, o którym mowa w § 1, pismo uznaje się za doręczone 

w czasie wskazanym w dokumencie potwierdzającym doręczenie. W przypadku 

braku dokumentu, który potwierdza doręczenie pisma, doręczenie to uznaje się za 

skuteczne z upływem 14 dni od dnia umieszczenia treści tego pisma w portalu 

informacyjnym w sposób określony w § 1. 

§ 3a. Jeżeli 

podmiot wskazany w § 1 nie 

posiada 

konta w portalu 

informacyjnym, pismo uważa się za doręczone z upływem 14 dni od dnia 

umieszczenia treści tego pisma w tym portalu w sposób, który umożliwia uzyskanie 

przez nadawcę i odbiorcę dokumentu potwierdzającego doręczenie. 

2025-09-11 

 
 
 
 
 
 

©Kancelaria Sejmu 

s. 53/356 

§ 4. Przewodniczący zarządza odstąpienie od doręczenia pisma przez 

umieszczenie jego treści w portalu informacyjnym, jeżeli dokonanie doręczenia w taki 

sposób jest niemożliwe ze względu na charakter tego pisma, w szczególności jeżeli 

zachodzi potrzeba wydania stronie uwierzytelnionego odpisu orzeczenia. 

§ 5. Minister Sprawiedliwości, w porozumieniu z ministrem właściwym do 

spraw informatyzacji, określi, w drodze rozporządzenia, tryb i sposób dokonywania 

doręczeń pism w postaci elektronicznej w postępowaniu karnym, mając na względzie 

zapewnienie skuteczności doręczeń tych pism oraz ochronę praw osób, którym te 

pisma są doręczane.


## Art. 134. {#kpk-art-134}
§ 1. Pisma adresowane do żołnierzy oraz funkcjonariuszy Policji, 

Agencji Bezpieczeństwa Wewnętrznego, Agencji Wywiadu, Służby Kontrwywiadu 

Wojskowego, Służby Wywiadu Wojskowego, Służby Ochrony Państwa, Centralnego 

Biura Antykorupcyjnego, Straży Granicznej, Straży Marszałkowskiej, Służby Celno-

Skarbowej i Służby Więziennej można doręczyć adresatom za pośrednictwem ich 

przełożonych, przy czym wezwania przeznaczone dla żołnierzy pełniących zasadniczą 

służbę wojskową przesyła się do dowódcy jednostki wojskowej, w której żołnierz 

pełni służbę, w celu doręczenia i zarządzenia stawienia się stosownie do wezwania. 

§ 2. Osobom pozbawionym wolności doręcza się pismo za pośrednictwem 

administracji odpowiedniego zakładu. 

§ 3. Pismo przeznaczone dla adresata niebędącego osobą fizyczną albo dla 

obrońcy lub pełnomocnika doręcza się w biurze adresata osobie tam zatrudnionej.


## Art. 135. {#kpk-art-135}
Prokuratora zawiadamia się o rozprawach i posiedzeniach przez 

doręczenie wykazu spraw, które mają być w danym dniu rozpoznane.


## Art. 136. {#kpk-art-136}
§ 1. W razie odmowy przyjęcia pisma lub odmowy albo niemożności 

pokwitowania odbioru przez adresata, doręczający sporządza na zwrotnym 

pokwitowaniu odpowiednią wzmiankę; wówczas doręczenie uważa się za dokonane. 

§ 2. Pismo nie przyjęte przez adresata zwraca się organowi wysyłającemu.


## Art. 137. {#kpk-art-137}
W wypadkach niecierpiących zwłoki można wzywać lub zawiadamiać 

osoby telefonicznie albo w inny sposób stosownie do okoliczności, pozostawiając 

w aktach odpis nadanego komunikatu z podpisem osoby nadającej.


## Art. 138. {#kpk-art-138}
<§ 1.> Strona, a także osoba niebędąca stroną, której prawa zostały 

naruszone, nieprzebywająca w kraju ani w innym państwie członkowskim Unii 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 54/356 

Europejskiej, ma obowiązek wskazać adresata dla doręczeń w kraju lub w innym 

państwie członkowskim Unii Europejskiej; w razie nieuczynienia tego pismo wysłane 

na ostatnio znany adres w kraju lub w innym państwie członkowskim Unii 

Europejskiej albo, jeżeli adresu tego nie ma, załączone do akt sprawy uważa się za 

doręczone. 

 <§ 2. Przepisu § 1 nie stosuje się, jeżeli strona, a także osoba niebędąca 

stroną, której prawa zostały naruszone, wyraziła zgodę na dokonywanie doręczeń 

na adres do doręczeń elektronicznych.>


## Art. 139. {#kpk-art-139}
§ 1. Jeżeli strona, nie podając nowego adresu, zmienia miejsce 

zamieszkania lub nie przebywa pod wskazanym przez siebie adresem, w tym także 

z powodu pozbawienia wolności w innej sprawie, pismo wysłane pod tym adresem 

uważa się za doręczone. [Dotyczy to także strony, która zgłosiła wniosek 

o dokonywanie doręczeń na adres oznaczonej skrytki pocztowej i nie zawiadomiła 

organu o zmianie tego adresu lub zaprzestaniu korzystania z niego.] <Dotyczy to 

także strony, która zgłosiła wniosek o dokonywanie doręczeń na adres oznaczonej 

skrytki pocztowej albo wyraziła zgodę na dokonywanie doręczeń na adres do 

doręczeń elektronicznych i nie zawiadomiła organu o zmianie tego adresu lub o 

zaprzestaniu korzystania z niego.> 

§ 1a. Przepis § 1 stosuje się do pokrzywdzonego także wtedy, gdy nie jest stroną. 

§ 2. (uchylony) 

§ 3. Przepis § 1 nie dotyczy pism wysłanych po raz pierwszy po prawomocnym 

uniewinnieniu oskarżonego. 

 [Art. 140. Jeżeli ustawa nie stanowi 

inaczej, orzeczenia, zarządzenia, 

zawiadomienia i odpisy, które ustawa nakazuje doręczać stronom, doręcza się również 

obrońcom, pełnomocnikom i ustawowym przedstawicielom.] 

 <Art. 140. Jeżeli ustawa nie stanowi inaczej, orzeczenia, zarządzenia, 

zawiadomienia i kopie, które ustawa nakazuje doręczać stronom, doręcza się 

również obrońcom, pełnomocnikom i ustawowym przedstawicielom.> 

 [Art. 141. Minister Sprawiedliwości w porozumieniu z ministrem właściwym do 

spraw łączności określi, w drodze rozporządzenia, szczegółowe zasady i tryb 

doręczania pism organów procesowych, mając na uwadze konieczność zapewnienia 

2025-09-11 

Dodany § 2 w art. 
138 oraz nowe 
brzmienie 
zd. 
drugiego w § 1 w 
art. 139 wejdą w 
życie 
dn. 
z 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

Zmiana w art. 
140 oraz nowe 
brzmienie 
art. 
141 wejdą w życie 
z dn. 1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 
 
 
 
 
 

©Kancelaria Sejmu 

s. 55/356 

sprawnego toku postępowania, a także właściwej realizacji gwarancji procesowych 

jego uczestników.] 

 <Art. 141. Minister Sprawiedliwości w porozumieniu z ministrem 

właściwym do spraw łączności określi, w drodze rozporządzenia, szczegółowe 

zasady i tryb doręczania pism organów procesowych, z wyłączeniem doręczeń, 

o których mowa w art. 131 § 1 pkt 1, mając na uwadze konieczność zapewnienia 

sprawnego 

toku postępowania, a także właściwej realizacji gwarancji 

procesowych jego uczestników.>


## Art. 142. {#kpk-art-142}
Doręczenie bez zachowania przepisów niniejszego rozdziału uważa się 

za dokonane, jeżeli osoba, dla której pismo było przeznaczone, oświadczy, że pismo 

to otrzymała. 


# Rozdział 16
 

Protokoły


## Art. 143. {#kpk-art-143}
§ 1. Spisania protokołu wymagają: 

1) 

przyjęcie ustnego zawiadomienia o przestępstwie, wniosku o ściganie i jego 

cofnięcie; 

przesłuchanie oskarżonego, świadka, biegłego i kuratora; 

dokonanie oględzin; 

dokonanie otwarcia zwłok oraz wyjęcie zwłok z grobu; 

przeprowadzenie eksperymentu, konfrontacji oraz okazania; 

przeszukanie osoby, miejsca, 

rzeczy 

i systemu 

informatycznego oraz 

zatrzymanie rzeczy i danych informatycznych; 

otwarcie korespondencji i przesyłki oraz odtworzenie utrwalonych zapisów; 

zaznajomienie podejrzanego 

z materiałami 

zebranymi w postępowaniu 

2) 

3) 

4) 

5) 

6) 

7) 

8) 

przygotowawczym; 

9) 

przyjęcie poręczenia; 

10) przebieg posiedzenia sądu, jeżeli stawią się na nim uprawnione osoby albo ich 

obecność jest obowiązkowa; 

11) przebieg rozprawy. 

§ 2. Z innych czynności spisuje się protokół, jeżeli przepis szczególny tego 

wymaga albo przeprowadzający czynność uzna to za potrzebne. W innych wypadkach 

można ograniczyć się do sporządzenia notatki urzędowej. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 56/356


## Art. 144. {#kpk-art-144}
§ 1. Protokół rozprawy spisuje pracownik sekretariatu lub inna osoba 

upoważniona przez prezesa sądu. 

§ 2. Inny protokół spisać może, poza osobami wymienionymi w § 1, osoba 

przybrana w charakterze protokolanta przez prowadzącego czynność lub sam 

przeprowadzający czynność. 

§ 3. Od osoby przybranej, która nie jest pracownikiem organu prowadzącego 

postępowanie, odbiera się przyrzeczenie następującej treści: „Przyrzekam uroczyście, 

że powierzone mi obowiązki protokolanta wykonam sumiennie”.


## Art. 145. {#kpk-art-145}
§ 1. Jeżeli czynność procesową utrwala się za pomocą stenogramu, 

protokół można ograniczyć do zapisu najbardziej istotnych oświadczeń osób 

biorących w niej udział. Stenograf przekłada stenogram na pismo zwykłe, przy czym 

czyni wzmiankę, jakim posługiwał się systemem; pierwopis stenogramu oraz jego 

przekład stają się załącznikami do protokołu. 

§ 2. Przepis art. 144 § 3 stosuje się odpowiednio.


## Art. 146. {#kpk-art-146}
§ 1. Protokolant i stenograf ulegają wyłączeniu z tych samych 

powodów co sędzia. 

§ 2. O wyłączeniu orzeka w toku rozprawy lub posiedzenia sąd, a w innych 

wypadkach osoba, która przeprowadza czynność protokołowaną.


## Art. 147. {#kpk-art-147}
§ 1. Przebieg czynności protokołowanych może być utrwalony 

ponadto za pomocą urządzenia rejestrującego obraz lub dźwięk, o czym należy przed 

uruchomieniem urządzenia uprzedzić osoby uczestniczące w czynności. 

§ 2. Przesłuchanie świadka lub biegłego utrwala się za pomocą urządzenia 

rejestrującego obraz i dźwięk, gdy: 

1) 

zachodzi niebezpieczeństwo, że przesłuchanie tej osoby nie będzie możliwe 

w dalszym postępowaniu; 

2) 

przesłuchanie następuje w trybie określonym w art. 396. 

§ 2a. Przesłuchanie w trybie określonym w art. 185a–185c oraz art. 185e utrwala 

się za pomocą urządzenia rejestrującego obraz i dźwięk. 

§ 2b. Przebieg rozprawy utrwala się za pomocą urządzenia rejestrującego dźwięk 

albo obraz i dźwięk, chyba że jest to niemożliwe ze względów technicznych. 

§ 2c. Przebiegu rozprawy w zakresie, w którym wyłączono jej jawność ze 

względu na obawę ujawnienia informacji niejawnych o klauzuli tajności „tajne” lub 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 57/356 

„ściśle tajne”, nie utrwala się w sposób określony w § 2b, jeżeli nie ma możliwości 

zapewnienia właściwej ochrony zapisu dźwięku albo obrazu i dźwięku przed 

nieuprawnionym ujawnieniem. 

§ 3. Jeżeli czynność procesową inną niż rozprawa utrwala się za pomocą 

urządzenia rejestrującego dźwięk albo obraz i dźwięk, protokół można ograniczyć do 

zapisu najbardziej istotnych oświadczeń osób biorących w niej udział. 

§ 3a. Zapis obrazu lub dźwięku staje się załącznikiem do protokołu. W wypadku 

ograniczenia protokołu do zapisu najbardziej istotnych oświadczeń osób biorących 

udział w czynności sporządza się przekład zapisu dźwięku, który również staje się 

załącznikiem do protokołu. 

§ 4. Strona, obrońca, pełnomocnik i przedstawiciel ustawowy ma prawo 

otrzymać odpłatnie jedną kopię zapisu obrazu lub dźwięku. Nie dotyczy to przebiegu 

rozprawy lub innej czynności odbywającej się z wyłączeniem jawności albo czynności 

w postępowaniu przygotowawczym. Z ważnych przyczyn, uzasadnionych ochroną 

interesu prywatnego osób biorących udział w rozprawie, prezes sądu może nie wyrazić 

zgody na sporządzenie dla stron, obrońców, pełnomocników i przedstawicieli 

ustawowych kopii zapisu obrazu z rozprawy. 

§ 5. Minister Sprawiedliwości określi, w drodze rozporządzenia, rodzaje 

urządzeń i środków technicznych służących do utrwalania obrazu lub dźwięku dla 

celów procesowych, sposób przechowywania, odtwarzania i kopiowania zapisów, 

sposób i tryb udostępniania stronom, obrońcom, pełnomocnikom i przedstawicielom 

ustawowym zapisu obrazu lub dźwięku oraz przekazywania im kopii zapisu obrazu 

lub dźwięku, jak również wysokość opłaty za sporządzenie i przekazanie kopii zapisu 

obrazu lub dźwięku oraz zakładanie kont w systemie informatycznym w celu 

przekazywania kopii zapisu obrazu lub dźwięku, mając na uwadze konieczność 

właściwego zabezpieczenia utrwalonego obrazu lub dźwięku przed utratą dowodu, 

jego zniekształceniem lub nieuprawnionym ujawnieniem, konieczność niezwłocznego 

dostępu uczestników postępowania do zapisu obrazu lub dźwięku oraz uzyskania kopii 

zapisu z akt sprawy, a także zapewnienia, aby wysokość opłaty odpowiadała 

rzeczywistym kosztom sporządzenia i przekazania kopii zapisu obrazu lub dźwięku.


## Art. 148. {#kpk-art-148}
§ 1. Protokół powinien zawierać: 

1) 

2) 

oznaczenie czynności, jej czasu i miejsca oraz osób w niej uczestniczących; 

przebieg czynności oraz oświadczenia i wnioski jej uczestników; 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 58/356 

3) wydane w toku czynności postanowienia i zarządzenia, a jeżeli postanowienie 

lub zarządzenie sporządzono osobno, wzmiankę o jego wydaniu; 

4) w miarę potrzeby stwierdzenie innych okoliczności dotyczących przebiegu 

czynności. 

§ 2. Wyjaśnienia, zeznania, oświadczenia 

i wnioski oraz 

stwierdzenia 

określonych okoliczności przez organ prowadzący postępowanie zamieszcza się 

w protokole z możliwą dokładnością. Osoby biorące udział w czynności mają prawo 

żądać zamieszczenia w protokole z pełną dokładnością wszystkiego, co dotyczy ich 

praw lub interesów. 

§ 2a. (uchylony) 

§ 2b. (uchylony) 

§ 2c. (uchylony) 

§ 3. W protokole nie wolno zastępować zapisu treści zeznań lub wyjaśnień 

odwoływaniem się do innych protokołów. 

§ 4. Osoby biorące udział w czynności mają prawo żądać odczytania fragmentów 

ich wypowiedzi wciągniętych do protokołu.


## Art. 148a. {#kpk-art-148a}
[§ 1. W protokole nie zamieszcza się danych dotyczących miejsca 

zamieszkania i miejsca pracy, a także numeru telefonu, telefaksu ani adresu poczty 

elektronicznej pokrzywdzonych i świadków uczestniczących w czynności. Dane te, 

niezamieszczone w protokole, zamieszcza się w załączniku do protokołu, który 

przechowuje się w załączniku adresowym do akt sprawy, do wiadomości organu 

prowadzącego postępowanie.] 

 <§ 1. W protokole nie zamieszcza się danych dotyczących miejsca 

zamieszkania i miejsca pracy, a także numeru telefonu, telefaksu ani adresu 

poczty elektronicznej i adresu do doręczeń elektronicznych pokrzywdzonych i 

świadków uczestniczących w czynności. Dane te, niezamieszczone w protokole, 

zamieszcza się w załączniku do protokołu, który przechowuje się w załączniku 

adresowym do akt sprawy, do wiadomości organu prowadzącego postępowanie.> 

§ 2. Przepis § 1 zdanie pierwsze nie dotyczy miejsca pracy świadka będącego 

funkcjonariuszem publicznym, składającego zeznania w związku z pełnioną funkcją, 

chyba że przeprowadzający czynność w postępowaniu przygotowawczym albo 

2025-09-11 

Nowe brzmienie 
§ 1 i 3 w art. 148a 
wejdzie w życie z 
dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 
 
 
 
 

©Kancelaria Sejmu 

s. 59/356 

przewodniczący składu orzekającego przeprowadzającego czynność uzna, iż dla dobra 

postępowania karnego nie powinno ono zostać zamieszczone w protokole. 

 [§ 3. Jeżeli dane dotyczące miejsca zamieszkania, miejsca pracy, numeru 

telefonu, telefaksu i adresu poczty elektronicznej pokrzywdzonych i świadków zawarte 

są w dokumentach innych niż protokół, o którym mowa w § 1, dokumenty, w całości 

lub w części, w jakiej zawierają te dane, przechowuje się w załączniku adresowym do 

akt sprawy, do wiadomości organu prowadzącego postępowanie. Do akt sprawy 

załącza się uwierzytelnione kserokopie dokumentów lub ich części, sporządzone 

w sposób uniemożliwiający zapoznanie się z tymi danymi.] 

 <§ 3. Jeżeli dane dotyczące miejsca zamieszkania, miejsca pracy, numeru 

telefonu, telefaksu, adresu poczty elektronicznej 

i adresu do doręczeń 

elektronicznych pokrzywdzonych i świadków zawarte są w dokumentach innych 

niż protokół, o którym mowa w § 1, dokumenty, w całości lub w części, w jakiej 

zawierają te dane, przechowuje się w załączniku adresowym do akt sprawy, do 

wiadomości organu prowadzącego postępowanie. Do akt sprawy załącza się 

uwierzytelnione kserokopie dokumentów lub ich części, sporządzone w sposób 

uniemożliwiający zapoznanie się z tymi danymi.> 

 [§ 4. Przeprowadzający czynność w postępowaniu przygotowawczym albo 

przewodniczący składu sądu – w odniesieniu do protokołu, o którym mowa w § 1, 

a w odniesieniu do 

innych dokumentów – organ prowadzący postępowanie 

przygotowawcze albo prezes sądu lub przewodniczący składu sądu, może zarządzić 

o odstąpieniu, w całości lub w części, od stosowania przepisów § 1 lub 3: 

1) 

jeżeli dane dotyczące miejsca zamieszkania, miejsca pracy, numeru telefonu, 

telefaksu lub adresu poczty elektronicznej pokrzywdzonego lub świadka są 

oskarżonemu znane; 

2) w odniesieniu do danych dotyczących miejsca zamieszkania, miejsca pracy, 

numeru telefonu, telefaksu lub adresu poczty elektronicznej pokrzywdzonego lub 

świadka, jeżeli dane te są związane z miejscem prowadzenia działalności 

gospodarczej przez pokrzywdzonego lub świadka i zostały przekazane do 

publicznej wiadomości do właściwego rejestru lub ewidencji; 

3) 

z powodu oczywistego braku potrzeby ochrony danych dotyczących miejsca 

zamieszkania, miejsca pracy, numeru telefonu, telefaksu lub adresu poczty 

elektronicznej pokrzywdzonego lub świadka z uwagi na charakter sprawy.] 

2025-09-11 

Nowe brzmienie 
§ 4 w art. 148a 
wejdzie w życie z 
dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 
 
 
 
 

©Kancelaria Sejmu 

s. 60/356 

 <§ 4. Przeprowadzający czynność w postępowaniu przygotowawczym albo 

przewodniczący składu sądu – w odniesieniu do protokołu, o którym mowa w § 

1, a w odniesieniu do innych dokumentów – organ prowadzący postępowanie 

przygotowawcze albo prezes sądu lub przewodniczący składu sądu, może 

zarządzić o odstąpieniu, w całości lub w części, od stosowania przepisów § 1 lub 

3: 

1) 

jeżeli dane dotyczące miejsca zamieszkania, miejsca pracy, numeru 

telefonu, telefaksu lub adresu poczty elektronicznej i adresu do doręczeń 

elektronicznych pokrzywdzonego lub świadka są oskarżonemu znane; 

2) w odniesieniu do danych dotyczących miejsca zamieszkania, miejsca pracy, 

numeru telefonu, telefaksu lub adresu poczty elektronicznej i adresu do 

doręczeń elektronicznych pokrzywdzonego lub świadka, jeżeli dane te są 

związane z miejscem prowadzenia działalności gospodarczej przez 

pokrzywdzonego 

lub świadka 

i zostały przekazane do publicznej 

wiadomości do właściwego rejestru lub ewidencji; 

3) 

z powodu oczywistego braku potrzeby ochrony danych dotyczących miejsca 

zamieszkania, miejsca pracy, numeru telefonu, telefaksu lub adresu poczty 

elektronicznej i adresu do doręczeń elektronicznych pokrzywdzonego lub 

świadka z uwagi na charakter sprawy.> 

§ 5. Sąd lub organ prowadzący postępowanie przygotowawcze może ujawnić 

w niezbędnym zakresie dane, o których mowa w § 1, lub oryginały dokumentów, 

o których mowa w § 3, jeżeli mają one znaczenie dla rozstrzygnięcia sprawy.


## Art. 149. {#kpk-art-149}
§ 1. Protokół rozprawy oraz posiedzenia podpisują niezwłocznie 

przewodniczący i protokolant. 

§ 2. Stenogram oraz 

jego przekład podpisuje 

stenograf, 

a ponadto 

przewodniczący rozprawy lub przeprowadzający czynność. 

§ 3. Jeżeli przewodniczący nie może podpisać protokołu, protokół podpisuje za 

niego jeden z członków składu orzekającego, zaznaczając przyczynę braku podpisu 

przewodniczącego.


## Art. 150. {#kpk-art-150}
§ 1. Z wyjątkiem protokołu rozprawy lub posiedzenia protokół 

podpisują osoby biorące udział w czynności. Przed podpisaniem należy go odczytać 

i uczynić o tym wzmiankę. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 61/356 

§ 2. Osoba uczestnicząca w czynności może podpisując protokół zgłosić 

jednocześnie zarzuty co do jego treści; zarzuty te należy wciągnąć do protokołu wraz 

z oświadczeniem osoby wykonującej czynność protokołowaną.


## Art. 151. {#kpk-art-151}
§ 1. Skreślenia oraz poprawki i uzupełnienia poczynione w protokole 

wymagają omówienia podpisanego przez osoby podpisujące protokół. 

§ 2. Jeżeli protokół nie został należycie podpisany bezpośrednio po zakończeniu 

czynności, brakujące podpisy mogą być złożone później, ze wskazaniem daty ich 

złożenia i przyczyn opóźnienia.


## Art. 152. {#kpk-art-152}
Strony oraz osoby mające w tym interes prawny mogą złożyć wniosek 

o sprostowanie protokołu rozprawy i posiedzenia lub przekładu zapisu dźwięku, 

wskazując na nieścisłości i opuszczenia.


## Art. 153. {#kpk-art-153}
§ 1. Przewodniczący po wysłuchaniu protokolanta lub osoby, która 

sporządziła przekład zapisu dźwięku, oraz po odtworzeniu zapisu dźwięku albo obrazu 

i dźwięku może przychylić się do wniosku i wydać zarządzenie o sprostowaniu 

protokołu lub przekładu zapisu dźwięku; w przeciwnym razie w przedmiocie 

sprostowania orzeka, po wysłuchaniu protokolanta lub osoby, która sporządziła 

przekład zapisu dźwięku, sąd w składzie, który rozpoznawał sprawę. 

§ 2. Jeżeli nie można utworzyć tego samego składu, postanowienie nie zapada, 

a poszczególni jego członkowie oraz protokolant lub osoba, która sporządziła przekład 

zapisu dźwięku, składają do akt sprawy oświadczenie co do zasadności wniosku. 

§ 3. W razie uwzględnienia wniosku należy w sprostowanym protokole 

i przekładzie zapisu dźwięku umieścić odpowiednią wzmiankę, którą podpisują 

przewodniczący i protokolant lub osoba, która sporządziła przekład zapisu dźwięku. 

§ 4. Jeżeli nieścisłość lub opuszczenie w przekładzie zapisu dźwięku wynika 

z niedającego się usunąć zniekształcenia lub braku zapisu dźwięku, stosowną 

wzmiankę należy zamieścić w protokole i przekładzie zapisu dźwięku. 

§ 5. Wniosek o sprostowanie protokołu rozprawy i posiedzenia lub przekładu 

zapisu dźwięku pozostawia się bez rozpoznania, jeżeli został złożony po wysłaniu akt 

sprawy do wyższej instancji.


## Art. 154. {#kpk-art-154}
Sprostowanie oczywistych omyłek pisarskich lub rachunkowych 

w protokole lub przekładzie zapisu dźwięku może nastąpić na wniosek lub z urzędu 

w każdym czasie; przepisy art. 153 stosuje się odpowiednio. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 62/356


## Art. 155. {#kpk-art-155}
§ 1. O treści sprostowania zawiadamia się strony, a o odmowie 

sprostowania osobę, która zgłosiła wniosek o sprostowanie. 

§ 2. Wniosek o sprostowanie, niezależnie od sposobu jego załatwienia, dołącza 

się do protokołu. 


# Rozdział 17
 

Przeglądanie akt i sporządzanie odpisów


## Art. 156. {#kpk-art-156}
§ 1. Stronom, obrońcom, pełnomocnikom 

i przedstawicielom 

ustawowym udostępnia się akta sprawy sądowej oraz daje możność sporządzenia 

z nich odpisów lub kopii. Za zgodą prezesa sądu akta te mogą być udostępnione 

również innym osobom. Informacje o aktach sprawy mogą być udostępnione także za 

pomocą systemu teleinformatycznego, jeżeli względy techniczne nie stoją temu na 

przeszkodzie. 

§ 1a. (uchylony) 

§ 2. Na wniosek oskarżonego lub jego obrońcy wydaje się odpłatnie kopie 

dokumentów z akt sprawy. Kopie takie wydaje się odpłatnie, na wniosek, również 

innym stronom, pełnomocnikom 

i przedstawicielom ustawowym. Zarządzenie 

w przedmiocie wniosku może wydać również referendarz sądowy. Od kopii 

wykonanej samodzielnie nie pobiera się opłaty. 

§ 3. Prezes sądu lub referendarz sądowy może w razie uzasadnionej potrzeby 

zarządzić wydanie odpłatnie uwierzytelnionych odpisów z akt sprawy. 

§ 4. Jeżeli zachodzi niebezpieczeństwo ujawnienia informacji niejawnych 

o klauzuli tajności „tajne” lub „ściśle tajne”, przeglądanie akt, sporządzanie odpisów 

i kopii odbywa się z zachowaniem rygorów określonych przez prezesa sądu lub sąd. 

Uwierzytelnionych odpisów i kopii nie wydaje się, chyba że ustawa stanowi inaczej. 

§ 5. Jeżeli nie zachodzi potrzeba zabezpieczenia prawidłowego 

toku 

postępowania lub ochrony ważnego interesu państwa, w toku postępowania 

przygotowawczego stronom, obrońcom, pełnomocnikom i przedstawicielom usta-

wowym udostępnia się akta, umożliwia sporządzanie odpisów lub kopii oraz wydaje 

odpłatnie uwierzytelnione odpisy lub kopie. W przedmiocie udostępnienia akt, 

sporządzenia odpisów lub kopii lub wydania uwierzytelnionych odpisów lub kopii 

prowadzący postępowanie przygotowawcze wydaje zarządzenie. W wypadku 

odmowy udostępnienia akt pokrzywdzonemu na jego wniosek należy poinformować 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 63/356 

go o możliwości udostępnienia mu akt w późniejszym 

terminie. Z chwilą 

powiadomienia podejrzanego lub obrońcy o terminie końcowego zaznajomienia 

z materiałami 

postępowania 

przygotowawczego 

pokrzywdzonemu, 

jego 

pełnomocnikowi 

lub przedstawicielowi ustawowemu nie można odmówić 

udostępnienia akt, umożliwienia sporządzania odpisów lub kopii oraz wydania 

odpisów 

lub kopii. Za 

zgodą prokuratora 

akta w toku postępowania 

przygotowawczego mogą być w wyjątkowych wypadkach udostępnione innym 

osobom. Prokurator może udostępnić akta w postaci elektronicznej. 

§ 5a. W razie złożenia w toku postępowania przygotowawczego wniosku 

o zastosowanie albo przedłużenie tymczasowego aresztowania podejrzanemu i jego 

obrońcy udostępnia się niezwłocznie akta sprawy w części zawierającej treść 

dowodów dołączonych do wniosku, z wyłączeniem dowodów z zeznań świadków, 

o których mowa w art. 250 § 2b. 

§ 5b. Przepis § 5 stosuje się odpowiednio do udostępniania akt zakończonego 

postępowania przygotowawczego. 

§ 6. Minister Sprawiedliwości określi, w drodze rozporządzenia, wysokość 

opłaty za wydanie kopii dokumentów oraz uwierzytelnionych odpisów z akt sprawy, 

mając na uwadze koszt wykonania takich kopii i odpisów.


## Art. 156a. {#kpk-art-156a}
Dane lub oryginały dokumentów znajdujące się w załączniku 

adresowym udostępnia się wyłącznie organom państwowym oraz organom samorządu 

terytorialnego na ich wniosek, jeżeli jest to niezbędne dla wykonywania ustawowych 

zadań tych organów. Można je udostępnić także na wniosek innych instytucji lub osób, 

jeżeli przemawia za tym ich ważny interes.


## Art. 157. {#kpk-art-157}
[§ 1. Stronom oraz osobom, których orzeczenie bezpośrednio dotyczy, 

należy na ich żądanie nieodpłatnie wydać jeden uwierzytelniony odpis każdego 

orzeczenia. Odpis wydaje się z uzasadnieniem, jeżeli je sporządzono.] 

 <§ 1. Stronom oraz osobom, których orzeczenie albo podlegające 

zaskarżeniu zarządzenie bezpośrednio dotyczy, należy na 

ich żądanie 

nieodpłatnie wydać jedną kopię każdego orzeczenia albo podlegającego 

zaskarżeniu zarządzenia. Kopię wydaje się z uzasadnieniem, jeżeli je 

sporządzono.> 

2025-09-11 

Nowe brzmienie 
§ 1 i 2 w art. 157 
wejdzie w życie z 
1.10.2029 r 
dn. 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 
 
 
 
 

©Kancelaria Sejmu 

s. 64/356 

 [§ 2. W sprawach, w których wyłączono jawność ze względu na ważny interes 

państwa, osobom, o których mowa w § 1, wydaje się tylko odpis orzeczenia 

kończącego postępowanie w danej instancji, bez uzasadnienia.] 

 <§ 2. W sprawach, w których wyłączono jawność ze względu na ważny 

interes państwa, osobom, o których mowa w § 1, wydaje się tylko kopię orzeczenia 

kończącego postępowanie w danej instancji, bez uzasadnienia.> 

§ 3. Nie można odmówić stronie zezwolenia na sporządzenie odpisu protokołu 

czynności, w której strona uczestniczyła lub miała prawo uczestniczyć, jak również 

dokumentu pochodzącego od niej lub sporządzonego z jej udziałem.


## Art. 158. {#kpk-art-158}
§ 1. Prokurator może przeglądać akta sprawy sądowej w każdym jej 

stanie oraz żądać przesłania mu ich w tym celu, jeżeli nie tamuje to biegu 

postępowania i nie ogranicza dostępu do akt innym uczestnikom postępowania, 

a zwłaszcza oskarżonemu i jego obrońcy. 

§ 2. W razie przesłania akt prokuratorowi jest on obowiązany udostępnić je 

stronie, obrońcy lub pełnomocnikowi.


## Art. 159. {#kpk-art-159}
Na odmowę udostępnienia akt w postępowaniu przygotowawczym 

przysługuje stronom zażalenie; na zarządzenie prokuratora zażalenie przysługuje do 

sądu. 


# Rozdział 18
 

Odtworzenie zaginionych lub zniszczonych akt


## Art. 160. {#kpk-art-160}
§ 1. Postępowanie w wypadku zaginięcia lub zniszczenia w całości lub 

w części akt sprawy będącej w toku przeprowadza sąd, w którym sprawa ostatnio się 

toczyła. 

§ 2. Sąd Najwyższy przeprowadza takie postępowanie jedynie w zakresie 

odtworzenia akt tego sądu. 

§ 3. Postępowanie w wypadku zaginięcia 

lub zniszczenia akt sprawy 

prawomocnie zakończonej przeprowadza sąd, w którym sprawa się 

toczyła 

w pierwszej instancji, lub inny sąd wskazany w ustawie. 

§ 4. Akta postępowania przygotowawczego odtwarza prokurator, stosując 

odpowiednio przepisy niniejszego rozdziału. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 65/356


## Art. 161. {#kpk-art-161}
Jeżeli zaginęły lub uległy zniszczeniu akta sprawy prawomocnie 

zakończonej, odtworzenie nastąpi w częściach niezbędnych do wykonania orzeczenia, 

wznowienia postępowania, przeprowadzenia postępowania w trybie kasacji albo 

urzeczywistnienia innych uzasadnionych interesów stron.


## Art. 162. {#kpk-art-162}
Prezes sądu lub referendarz sądowy wzywa strony do złożenia 

w oznaczonym terminie wniosków co do sposobu odtworzenia akt sprawy oraz 

przedstawienia dokumentów umożliwiających ich odtworzenie.


## Art. 163. {#kpk-art-163}
§ 1. Prezes sądu lub referendarz sądowy wzywa osoby posiadające 

potrzebne dokumenty do ich przedstawienia sądowi, a w razie potrzeby prezes sądu 

zarządza ich przymusowe odebranie. Przepisy art. 217–236 stosuje się odpowiednio. 

§ 2. Po sporządzeniu uwierzytelnionych odpisów należy dokumenty zwrócić 

osobie, która je dostarczyła lub od której je odebrano.


## Art. 164. {#kpk-art-164}
W celu odtworzenia akt sąd przeprowadza postępowanie, w tym 

również dowody, jakie uzna za konieczne. W szczególności sąd bierze pod uwagę 

wpisy do rejestrów karnych, repertoriów i innych ksiąg biurowych, utrwalenia 

dźwięku lub obrazu, notatki protokolantów, sędziów, ławników, prokuratorów, 

adwokatów lub radców prawnych, którzy uczestniczyli w rozprawie. Sąd może też 

przesłuchać w charakterze świadków wszystkich uczestników sprawy, której akta 

zaginęły lub uległy zniszczeniu, a także inne osoby, które mogą mieć wiadomości co 

do treści akt. Strony mają prawo wziąć udział w posiedzeniu.


## Art. 165. {#kpk-art-165}
§ 1. Postanowienie co do odtworzenia akt sprawy ustala jego zakres 

lub stwierdza, że odtworzenie akt jest niemożliwe. 

§ 2. Na postanowienie to przysługuje zażalenie.


## Art. 166. {#kpk-art-166}
Jeżeli akta sprawy prawomocnie nie ukończonej nie mogą być 

odtworzone albo zostały odtworzone w części, należy czynności procesowe 

powtórzyć w zakresie niezbędnym do kontynuowania postępowania. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 66/356
