---
id: "code_kpk_dzial-xii"
title: "KPK — DZIAŁ XII"
source_pdf: "D19970555Lj (1).pdf"
dz_u: "Dz. U. 1997 Nr 89 poz. 555"
status: "obowiązujący"
last_consolidated: "2025-09-11"
law: "Kodeks postępowania karnego"
tags: ["kpk", "kodeks", "postępowanie karne"]
articles_range: {"first": "577a", "last": "577d"}
---

# DZIAŁ XII

## Art. 577a. {#kpk-art-577a}
Ilekroć w przepisach niniejszego działu jest mowa o: 

1) 

postępowaniu europejskim – rozumie się przez to postępowanie karne 

prowadzone lub nadzorowane przez prokuratora Prokuratury Europejskiej 

zgodnie z właściwością określoną w rozporządzeniu Rady (UE) 2017/1939 

z dnia 12 października 2017 r. wdrażającym wzmocnioną współpracę w zakresie 

ustanowienia Prokuratury Europejskiej (Dz. Urz. UE L 283 z 31.10.2017, str. 1, 

z późn. zm.11)), zwanym dalej „rozporządzeniem 2017/1939”; 

2) 

postępowaniu krajowym – rozumie się przez to postępowanie karne prowadzone 

lub nadzorowane przez prokuratora powszechnej jednostki organizacyjnej 

prokuratury.


## Art. 577b. {#kpk-art-577b}
§ 1. Organem właściwym do wydania: 

11) Zmiany wymienionego rozporządzenia zostały ogłoszone w Dz. Urz. UE L 431 z 21.12.2020, str. 1. 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 228/356 

1) 

opinii 

w przedmiocie 

przejęcia 

postępowania, 

o której 

mowa 

w art. 27 ust. 4 rozporządzenia 2017/1939, 

2) 

zgody, o której mowa w art. 25 ust. 4 i art. 34 ust. 5 rozporządzenia 2017/1939 

– jest Prokurator Krajowy. 

§ 2. Organem właściwym do: 

1) 

przeprowadzenia konsultacji przewidzianych w art. 39 ust. 3 rozporządzenia 

2017/1939, 

2) wydania opinii, o której mowa w art. 25 ust. 2 i 3 oraz art. 40 ust. 1 zdanie drugie 

rozporządzenia 2017/1939, 

3) 

złożenia wniosku, o którym mowa w art. 34 ust. 6 i art. 91 ust. 6 zdanie pierwsze 

rozporządzenia 2017/1939 

– jest kierownik jednostki organizacyjnej prokuratury, od której Prokuratura 

Europejska przejęła sprawę, a jeśli sprawa nie była dotychczas prowadzona przez 

powszechną jednostkę organizacyjną prokuratury – Prokurator Krajowy. 

§ 3. Spór o właściwość, o którym mowa w art. 25 ust. 6 rozporządzenia 

2017/1939, rozstrzyga Prokurator Generalny. Na postanowienie Prokuratora 

Generalnego przysługuje zażalenie prokuratorowi Prokuratury Europejskiej, jeżeli 

rozstrzygnięcie sporu wymaga wykładni art. 22 lub art. 25 rozporządzenia 2017/1939. 

Zażalenie wnosi się do sądu okręgowego właściwego miejscowo dla siedziby 

powszechnej jednostki organizacyjnej prokuratury, przy której utworzono biuro 

delegowanego prokuratora europejskiego uczestniczącego w sporze.


## Art. 577c. {#kpk-art-577c}
§ 1. Do czasu trwania postępowania krajowego nie wlicza się czasu 

trwania postępowania europejskiego. 

§ 2. Dowody przeprowadzone w postępowaniu europejskim są dowodami 

w postępowaniu krajowym, chociażby czynności dowodowe zostały przeprowadzone 

w innym państwie członkowskim Unii Europejskiej lub zgodnie z przepisami tego 

państwa, jeżeli sposób przeprowadzenia czynności nie jest sprzeczny z zasadami 

porządku prawnego Rzeczypospolitej Polskiej.


## Art. 577d. {#kpk-art-577d}
§ 1. Policja 

i inne organy postępowania przygotowawczego 

przekazują niezwłocznie do właściwego biura delegowanego prokuratora 

europejskiego informację o podejrzeniu popełnienia przestępstwa pozostającego we 

właściwości Prokuratury Europejskiej zgodnie z rozporządzeniem 2017/1939. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 229/356 

§ 2. Jeżeli po wszczęciu postępowania okaże się, że sprawa dotyczy przestępstwa 

pozostającego we właściwości Prokuratury Europejskiej zgodnie z rozporządzeniem 

2017/1939, 

informację 

o sprawie 

Policja 

i inne 

organy 

postępowania 

przygotowawczego przekazują niezwłocznie do właściwego biura delegowanego 

prokuratora europejskiego.
