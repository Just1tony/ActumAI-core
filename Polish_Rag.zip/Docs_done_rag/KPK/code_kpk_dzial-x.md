---
id: "code_kpk_dzial-x"
title: "KPK — DZIAŁ X"
source_pdf: "D19970555Lj (1).pdf"
dz_u: "Dz. U. 1997 Nr 89 poz. 555"
status: "obowiązujący"
last_consolidated: "2025-09-11"
law: "Kodeks postępowania karnego"
tags: ["kpk", "kodeks", "postępowanie karne"]
articles_range: {"first": "485", "last": "517j"}
---

# DZIAŁ X

## Art. 485. {#kpk-art-485}
W sprawach 

z oskarżenia prywatnego 

stosuje 

się przepisy 

o postępowaniu zwyczajnym, z zachowaniem przepisów niniejszego rozdziału.


## Art. 486. {#kpk-art-486}
(uchylony)


## Art. 487. {#kpk-art-487}
Akt oskarżenia może ograniczyć się do oznaczenia osoby oskarżonego, 

zarzucanego mu czynu oraz wskazania dowodów, na których opiera się oskarżenie.


## Art. 488. {#kpk-art-488}
§ 1. Policja na żądanie pokrzywdzonego przyjmuje ustną lub pisemną 

skargę i w razie potrzeby zabezpiecza dowody, po czym przesyła skargę do 

właściwego sądu. 

§ 2. Na polecenie sądu Policja dokonuje określonych przez sąd czynności 

dowodowych, po czym ich wyniki przekazuje sądowi. Przepis art. 308 stosuje się 

odpowiednio.


## Art. 489. {#kpk-art-489}
§ 1. Rozprawę główną poprzedza posiedzenie pojednawcze, które 

prowadzi sędzia lub referendarz sądowy. 

§ 2. Na wniosek 

lub za zgodą stron sąd może zamiast posiedzenia 

pojednawczego wyznaczyć odpowiedni termin dla przeprowadzenia postępowania 

mediacyjnego. Przepis art. 23a stosuje się odpowiednio.


## Art. 490. {#kpk-art-490}
§ 1. Posiedzenie pojednawcze rozpoczyna się wezwaniem stron do 

pojednania. 

§ 2. W protokole posiedzenia pojednawczego należy w szczególności zaznaczyć 

stanowisko stron wobec wezwania do pojednania oraz wyniki przeprowadzonego 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 201/356 

posiedzenia pojednawczego; jeżeli doszło do pojednania, protokół podpisują także 

strony.


## Art. 491. {#kpk-art-491}
§ 1. Niestawiennictwo oskarżyciela prywatnego i jego pełnomocnika 

na posiedzenie pojednawcze bez usprawiedliwienia uważa się za odstąpienie od 

oskarżenia; w takim wypadku prowadzący posiedzenie postępowanie umarza. 

§ 2. W razie nieusprawiedliwionego niestawiennictwa oskarżonego prowadzący 

posiedzenie pojednawcze kieruje sprawę na rozprawę główną, a w miarę możności 

wyznacza od razu jej termin.


## Art. 492. {#kpk-art-492}
§ 1. W razie pojednania stron postępowanie umarza się. Postanowienie 

o umorzeniu postępowania może wydać także referendarz sądowy. 

§ 2. Jeżeli do pojednania doszło w wyniku mediacji, przepis art. 490 § 2 stosuje 

się odpowiednio.


## Art. 493. {#kpk-art-493}
W toku posiedzenia pojednawczego 

lub w wyniku mediacji 

dopuszczalne jest pojednanie się obejmujące również inne sprawy z oskarżenia 

prywatnego, toczące się pomiędzy tymi samymi stronami.


## Art. 494. {#kpk-art-494}
§ 1. Równocześnie z pojednaniem strony mogą zawrzeć ugodę, której 

przedmiotem mogą być również roszczenia pozostające w związku z oskarżeniem. 

§ 2. (uchylony)


## Art. 495. {#kpk-art-495}
§ 1. W razie niedojścia do pojednania kieruje się sprawę na rozprawę 

główną, a w miarę możności wyznacza od razu jej termin, chyba że zachodzi potrzeba 

skierowania sprawy na posiedzenie w celu innego rozstrzygnięcia. 

§ 2. Strony obecne na posiedzeniu powinny zgłosić wnioski dowodowe. 

§ 3. (uchylony)


## Art. 496. {#kpk-art-496}
§ 1. Postępowanie w sprawach z oskarżenia prywatnego umarza się za 

zgodą oskarżonego, jeżeli oskarżyciel prywatny odstąpi od oskarżenia przed 

prawomocnym zakończeniem postępowania. 

§ 2. Zgoda oskarżonego nie jest wymagana, jeżeli oskarżyciel prywatny odstąpi 

od oskarżenia przed rozpoczęciem przewodu sądowego na pierwszej rozprawie 

głównej. 

§ 3. Niestawiennictwo oskarżyciela prywatnego 

i jego pełnomocnika na 

rozprawie głównej bez usprawiedliwienia uważa się za odstąpienie od oskarżenia. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 202/356


## Art. 497. {#kpk-art-497}
§ 1. Oskarżony może aż do rozpoczęcia przewodu sądowego na 

rozprawie głównej wnieść przeciwko oskarżycielowi prywatnemu będącemu 

pokrzywdzonym wzajemny akt oskarżenia o ścigany z oskarżenia prywatnego czyn, 

pozostający w związku z czynem mu zarzucanym. Sąd rozpoznaje wówczas łącznie 

obie sprawy. 

§ 2. Odstąpienie jednego z oskarżycieli prywatnych od oskarżenia powoduje 

umorzenie postępowania tylko w części dotyczącej wniesionego przezeń oskarżenia. 

§ 3. Obaj oskarżyciele prywatni korzystają z uprawnień oskarżonego. 

Pierwszeństwo zadawania pytań i przemówień przysługuje temu oskarżycielowi 

prywatnemu, który pierwszy wniósł akt oskarżenia. Sąd w wyroku zaznacza, że 

postępowanie toczyło się z powodu oskarżeń wzajemnych.


## Art. 498. {#kpk-art-498}
§ 1. Oskarżenie wzajemne jest niedopuszczalne, jeżeli prokurator 

wcześniej wszczął postępowanie albo przyłączył się do postępowania. 

§ 2. Jeżeli po wniesieniu oskarżenia wzajemnego prokurator przyłączy się do 

jednego z oskarżeń wzajemnych, sąd wyłącza oskarżenie przeciwne do osobnego 

postępowania. Przepis art. 60 § 2 stosuje się. 

§ 3. W razie objęcia przez prokuratora obu oskarżeń wzajemnych postępowanie 

toczy się z urzędu, zaś oskarżeni korzystają w odpowiednim zakresie również 

z uprawnień oskarżycieli posiłkowych.


## Art. 499. {#kpk-art-499}
Przepisy art. 492–494 stosuje się odpowiednio również na rozprawie. 


# Rozdział 53
 

Postępowanie nakazowe


## Art. 500. {#kpk-art-500}
§ 1. W sprawach, w których prowadzono dochodzenie, uznając na 

podstawie 

zebranego w postępowaniu 

przygotowawczym materiału, 

że 

przeprowadzenie rozprawy nie jest konieczne, sąd może w wypadkach pozwalających 

na orzeczenie kary ograniczenia wolności lub grzywny wydać wyrok nakazowy. 

§ 2. W postępowaniu 

nakazowym 

stosuje 

się 

odpowiednio 

przepisy 

o postępowaniu zwyczajnym, jeżeli przepisy niniejszego rozdziału nie stanowią 

inaczej. 

§ 3. Sąd może wydać wyrok nakazowy, jeżeli na podstawie zebranych dowodów 

okoliczności czynu i wina oskarżonego nie budzą wątpliwości. 

§ 4. Sąd wydaje wyrok nakazowy na posiedzeniu bez udziału stron. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 203/356


## Art. 501. {#kpk-art-501}
Wydanie wyroku nakazowego jest niedopuszczalne: 

1) 

(uchylony) 

2) w sprawie z oskarżenia prywatnego; 

3) 

jeżeli zachodzą okoliczności, o których mowa w art. 79 § 1.


## Art. 502. {#kpk-art-502}
§ 1. Wyrokiem nakazowym można orzec karę ograniczenia wolności 

lub grzywnę w wysokości do 200 stawek dziennych albo do 200 000 złotych. 

§ 2. Obok kary określonej w § 1 można, w wypadkach przewidzianych 

w ustawie, orzec środek karny, przepadek lub środek kompensacyjny. 

§ 3. Sąd może poprzestać na orzeczeniu środka karnego, przepadku lub środka 

kompensacyjnego, jeżeli zachodzą warunki orzeczenia tylko tego środka.


## Art. 503. {#kpk-art-503}
(uchylony)


## Art. 504. {#kpk-art-504}
§ 1. Wyrok nakazowy powinien zawierać: 

oznaczenie sądu i sędziego, który go wydał; 

datę wydania wyroku; 

imię i nazwisko oraz inne dane określające tożsamość oskarżonego; 

dokładne określenie czynu przypisanego przez sąd oskarżonemu, ze wskazaniem 

1) 

2) 

3) 

4) 

zastosowanych przepisów ustawy karnej; 

5) wymiar kary i inne niezbędne rozstrzygnięcia. 

§ 2. Wyrok nakazowy może nie zawierać uzasadnienia.


## Art. 505. {#kpk-art-505}
§ 1. 

 [Odpis wyroku nakazowego doręcza się oskarżycielowi 

i pokrzywdzonemu, a oskarżonemu i jego obrońcy – wraz z odpisem aktu oskarżenia.] 

<Kopię wyroku nakazowego doręcza się oskarżycielowi i pokrzywdzonemu, 

a oskarżonemu i jego obrońcy – wraz z kopią aktu oskarżenia.> [W każdym 

wypadku odpis tego wyroku doręcza się prokuratorowi.] <W każdym wypadku 

kopię tego wyroku doręcza się prokuratorowi.> 

§ 2. [Wraz z odpisem wyroku należy doręczyć pouczenie przytaczające przepisy 

o prawie, terminie i sposobie wniesienia sprzeciwu oraz skutkach jego niewniesienia.] 

<Wraz z kopią wyroku należy doręczyć pouczenie przytaczające przepisy 

o prawie, terminie 

i sposobie wniesienia sprzeciwu oraz skutkach jego 

niewniesienia.> Pokrzywdzonego należy ponadto pouczyć, że warunkiem wniesienia 

sprzeciwu jest złożenie w terminie, o którym mowa w art. 506 § 1, nie później niż 

2025-09-11 

Zmiany w zd. 
pierwszym 
i 
drugim w § 1 
oraz 
zd. 
w 
pierwszym w § 2 
w art. 505 wejdą 
w życie z dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 
 
 
 
 

©Kancelaria Sejmu 

s. 204/356 

jednocześnie ze sprzeciwem oświadczenia, że będzie on działał w charakterze 

oskarżyciela posiłkowego. 

§ 3. Przepisy art. 131 § 2 i 3 stosuje się odpowiednio.


## Art. 506. {#kpk-art-506}
§ 1. Oskarżonemu i oskarżycielowi przysługuje prawo wniesienia 

sprzeciwu do sądu, który wydał wyrok nakazowy, w terminie zawitym 7 dni od 

doręczenia tego wyroku. 

§ 2. Prezes sądu odmawia przyjęcia sprzeciwu, jeżeli został wniesiony po 

terminie lub przez osobę nieuprawnioną. 

§ 3. W razie wniesienia sprzeciwu wyrok nakazowy traci moc; sprawa podlega 

rozpoznaniu na zasadach ogólnych. 

§ 4. (uchylony) 

§ 5. Sprzeciw może być cofnięty do czasu rozpoczęcia przewodu sądowego na 

pierwszej rozprawie głównej. 

§ 6. Sąd rozpoznający sprawę po wniesieniu sprzeciwu nie jest związany treścią 

wyroku nakazowego, który utracił moc.


## Art. 507. {#kpk-art-507}
Wyrok nakazowy, od którego nie wniesiono sprzeciwu lub sprzeciw 

cofnięto, staje się prawomocny. 

(zawierający art. 508–517 – uchylony) 


# Rozdział 54
 


# Rozdział 54
a 

Postępowanie przyspieszone


## Art. 517a. {#kpk-art-517a}
§ 1. W postępowaniu 

przyspieszonym 

stosuje 

się 

przepisy 

o postępowaniu zwyczajnym, jeżeli przepisy niniejszego rozdziału nie stanowią 

inaczej. 

§ 2. Niestawiennictwo oskarżyciela publicznego nie tamuje toku rozprawy ani 

posiedzenia. Jeżeli w rozprawie nie bierze udziału oskarżyciel publiczny, zarzuty 

oskarżenia odczytuje protokolant.


## Art. 517b. {#kpk-art-517b}
§ 1. W postępowaniu przyspieszonym mogą być rozpoznawane 

sprawy, w których prowadzi się dochodzenie, jeżeli sprawca został ujęty na gorącym 

uczynku popełnienia przestępstwa lub bezpośrednio potem, zatrzymany oraz w ciągu 

48 godzin doprowadzony przez Policję i przekazany do dyspozycji sądu wraz 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 205/356 

z wnioskiem o rozpoznanie sprawy w postępowaniu przyspieszonym, zwanym dalej 

„wnioskiem o rozpoznanie sprawy”. 

§ 2. Postępowanie przyspieszone toczy się w trybie publicznoskargowym także 

o przestępstwa ścigane z oskarżenia prywatnego, 

jeżeli miały one charakter 

chuligański. 

§ 2a. Można odstąpić od przymusowego doprowadzenia do sądu sprawcy 

ujętego w warunkach określonych w § 1, jeżeli zostanie zapewnione uczestniczenie 

przez sprawcę we wszystkich czynnościach sądowych, w których ma on prawo 

uczestniczyć, w szczególności złożenie przez niego wyjaśnień, przy użyciu urządzeń 

technicznych, umożliwiających przeprowadzenie tych czynności na odległość 

z jednoczesnym bezpośrednim przekazem obrazu i dźwięku. W takim wypadku 

złożenie wniosku o rozpoznanie sprawy jest równoznaczne z przekazaniem sprawcy 

do dyspozycji sądu. 

§ 2b. W wypadku określonym w § 2a we wszystkich czynnościach sądowych 

przy użyciu urządzeń 

technicznych, umożliwiających przeprowadzenie 

tych 

czynności na odległość, bierze udział w miejscu przebywania sprawcy referendarz 

sądowy lub asystent sędziego zatrudniony w sądzie, w którego okręgu przebywa 

sprawca. 

§ 2c. Jeżeli w wypadku określonym w § 2a został ustanowiony obrońca, 

uczestniczy on w czynnościach sądowych przy użyciu urządzeń technicznych 

umożliwiających przeprowadzenie 

tych czynności na odległość, w miejscu 

przebywania sprawcy. 

§ 2d. Jeżeli w wypadku określonym w § 2a w odniesieniu do sprawcy zachodzą 

okoliczności, o których mowa w art. 204 § 1, tłumacz uczestniczy w czynnościach 

sądowych przy użyciu urządzeń technicznych umożliwiających przeprowadzenie tych 

czynności na odległość, w miejscu przebywania sprawcy. 

§ 3. Można odstąpić od zatrzymania i przymusowego doprowadzenia do sądu 

sprawcy ujętego w warunkach określonych w § 1 lub zwolnić zatrzymanego, 

zobowiązując go do stawienia się w sądzie w wyznaczonym miejscu i czasie, 

w okresie nieprzekraczającym 72 godzin od chwili zatrzymania albo oddania sprawcy 

w ręce Policji, ze skutkiem wezwania. Wniosek o rozpoznanie sprawy przekazuje się 

w takim wypadku sądowi wraz z materiałem dowodowym w ciągu 48 godzin od 

chwili zatrzymania albo oddania sprawcy w ręce Policji, a gdy termin ten upływa 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 206/356 

w dniu wolnym od pracy – w najbliższym dniu roboczym, tak jednak aby sąd mógł 

przystąpić do rozpoznania sprawy przed upływem 72 godzin od chwili zatrzymania 

albo oddania sprawcy w ręce Policji. 

§ 4. W stosunku do sprawcy występku o charakterze chuligańskim przepis 

§ 3 może być stosowany wyjątkowo, jeżeli z okoliczności wynika, że sprawca stawi 

się w sądzie w wyznaczonym miejscu i czasie oraz nie będzie utrudniał postępowania 

w inny sposób.


## Art. 517c. {#kpk-art-517c}
§ 1. Dochodzenie można ograniczyć do przesłuchania osoby 

podejrzanej w charakterze 

podejrzanego 

oraz 

zabezpieczenia 

dowodów 

w niezbędnym zakresie. W toku dochodzenia czynności procesowych określonych 

w art. 303 i 321 można nie dokonywać. 

§ 2. Podejrzanego poucza się o jego uprawnieniach: do składania wyjaśnień, do 

odmowy składania wyjaśnień lub odmowy odpowiedzi na pytania, do korzystania 

z pomocy obrońcy, do złożenia – już w toku dochodzenia – wniosku, o którym mowa 

w art. 338a, a także o możliwości złożenia przez prokuratora wniosku, o którym 

mowa w art. 335 § 1 lub 2, oraz o obowiązkach i konsekwencjach wskazanych 

w art. 74, art. 75, art. 138 i art. 139. Pouczenie to należy wręczyć podejrzanemu na 

piśmie za potwierdzeniem odbioru. 

§ 2a. W wypadku określonym w art. 517b § 2a podejrzanego należy pouczyć 

ponadto o treści art. 517b § 2a i 2c, art. 517e § 1a i art. 517ea. 

§ 3. (uchylony)


## Art. 517d. {#kpk-art-517d}
§ 1. W razie 

istnienia podstaw do wystąpienia z wnioskiem 

o rozpoznanie sprawy, Policja sporządza taki wniosek i przekazuje go do sądu wraz ze 

zgromadzonym materiałem dowodowym, zawiadamiając o tym niezwłocznie 

prokuratora; wniosek ten zastępuje akt oskarżenia. 

§ 1a. [W wypadku określonym w art. 517b § 2a sporządza się odpisy wniosku 

o rozpoznanie sprawy dla sprawcy oraz dla jego obrońcy, jeżeli został ustanowiony, 

a także uwierzytelnione kopie wszystkich dokumentów materiału dowodowego 

przekazywanych do 

sądu 

i pozostawia w miejscu przebywania 

sprawcy.] 

<W wypadku określonym w art. 517b § 2a sporządza się kopie wniosku 

o rozpoznanie sprawy dla sprawcy oraz dla jego obrońcy, jeżeli został 

ustanowiony, a także uwierzytelnione kopie wszystkich dokumentów materiału 

2025-09-11 

art. 

Zmiana w zd. 
pierwszym w § 1a 
517d 
w 
wejdzie w życie z 
dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

 
 
 
 
 

©Kancelaria Sejmu 

s. 207/356 

dowodowego przekazywanych do sądu i pozostawia w miejscu przebywania 

sprawcy.> Po zakończeniu wszystkich czynności sądowych przeprowadzanych 

w trybie art. 517b § 2a kopie te włącza się do akt sprawy. 

§ 2. Jeżeli zachodzą warunki do wystąpienia z wnioskiem, o którym mowa 

w art. 335 § 1 lub 2, lub gdy podejrzany złożył wniosek określony w art. 338a, Policja 

przedstawia wniosek o rozpoznanie sprawy prokuratorowi do zatwierdzenia. 

Prokurator może odmówić zatwierdzenia wniosku o rozpoznanie sprawy, podejmując 

decyzję co do dalszego toku sprawy; zatwierdzając wniosek o rozpoznanie sprawy, 

może też dołączyć do niego wniosek, o którym mowa w art. 335 § 2, albo wystąpić 

z wnioskiem, o którym mowa w art. 335 § 1. 

§ 3. Wniosek o rozpoznanie sprawy powinien zawierać dane, o których mowa 

w art. 332 § 1; przepisy art. 333 § 1–3 i art. 334 § 1 i 2 stosuje się odpowiednio. 

Policja doręcza pokrzywdzonemu pisemne pouczenie o uprawnieniach wynikających 

z art. 46 § 1 Kodeksu karnego, art. 343 § 2 i art. 387 § 2 oraz o treści art. 49a 

i art. 338a, a także o prawie do złożenia oświadczenia o działaniu w charakterze 

oskarżyciela posiłkowego. 

§ 4. Każda osoba wezwana przez Policję w charakterze świadka, biegłego, 

tłumacza lub specjalisty jest obowiązana stawić się w sądzie lub w miejscu 

przebywania sprawcy we wskazanym terminie. Art. 177 § 1a stosuje się.


## Art. 517e. {#kpk-art-517e}
§ 1. [Odpis wniosku o rozpoznanie sprawy prezes sądu lub sąd 

doręcza oskarżonemu oraz jego obrońcy, jeżeli został ustanowiony, oznaczając czas 

na przygotowanie do obrony.] <Kopię wniosku o rozpoznanie sprawy prezes sądu 

lub sąd doręcza oskarżonemu oraz jego obrońcy, jeżeli został ustanowiony, 

oznaczając czas na przygotowanie do obrony.> Oskarżonemu należy umożliwić 

kontakt z obrońcą bez obecności osób trzecich. 

§ 1a. W wypadku określonym w art. 517b § 2a prezes sądu lub sąd, w sposób 

wskazany w art. 137, zawiadamia oskarżonego oraz jego obrońcę, jeżeli został 

ustanowiony, o doręczeniu wniosku o rozpoznanie sprawy i oznacza czas na 

przygotowanie się do obrony. [Oskarżonemu oraz jego obrońcy doręcza się za 

pokwitowaniem przez funkcjonariusza Policji odpisy wniosku o rozpoznanie sprawy 

oraz udostępnia się kopie dokumentów, o których mowa w art. 517d § 1a.] 

<Oskarżonemu oraz jego obrońcy doręcza się za pokwitowaniem przez 

funkcjonariusza Policji kopie wniosku o rozpoznanie sprawy oraz udostępnia się 

Zmiany w zd. 
pierwszym w § 1 i 
w zd. drugim w § 
1a w art. 517e 
wejdą w życie z 
dn. 
1.10.2029 r 
(Dz. U. z 2020 r. 
poz. 2320, z 2021 
r. poz. 1135, z 
2022 r. poz. 1002 
i 2754 oraz z 2023 
r. poz. 1860). 

2025-09-11 

 
 
 
 
 

©Kancelaria Sejmu 

s. 208/356 

kopie dokumentów, o których mowa w art. 517d § 1a.> Zatrzymanemu 

oskarżonemu należy umożliwić, w miejscu jego przebywania, kontakt z obrońcą bez 

obecności osób trzecich. 

§ 2. (uchylony) 

§ 3. Sąd przystępuje niezwłocznie do rozpoznania sprawy. Przepisów art. 339 

§ 1 pkt 1 i 2 oraz art. 353 nie stosuje się. 

§ 4. (uchylony)


## Art. 517ea. {#kpk-art-517ea}
§ 1. W wypadku określonym w art. 517b § 2a podczas czynności 

sądowych, w których oskarżony uczestniczy przy użyciu urządzeń technicznych 

umożliwiających przeprowadzenie tych czynności na odległość, uczestnicy postę-

powania mogą składać wnioski oraz inne oświadczenia oraz dokonywać czynności 

procesowych wyłącznie ustnie do protokołu. O treści wszystkich pism procesowych, 

które wpłynęły do akt sprawy od chwili przekazania do sądu wniosku o rozpoznanie 

sprawy, sąd jest obowiązany poinformować przy najbliższej czynności procesowej 

oskarżonego oraz jego obrońcę. Na żądanie oskarżonego lub obrońcy sąd ma 

obowiązek odczytać treść tych pism. 

§ 2. W wypadku określonym w art. 517b § 2a pisma procesowe oskarżonego 

i jego obrońcy, których nie można było przekazać do sądu, mogą być przez nich 

odczytane na rozprawie. Z chwilą ich odczytania wywołują one skutek procesowy i są 

traktowane jako czynności dokonane w formie ustnej.


## Art. 517f. {#kpk-art-517f}
§ 1. Postępowanie przyspieszone prowadzi się również w razie 

potrzeby przerwania rozprawy; łączny czas zarządzonych przerw nie może 

przekroczyć 14 dni. 

§ 2. W razie zarządzenia przerwy sąd rozstrzyga w przedmiocie zastosowania 

środka zapobiegawczego. 

§ 3. Przepisów art. 98 § 2 i art. 411 § 1 nie stosuje się.


## Art. 517g. {#kpk-art-517g}
§ 1. Jeżeli sąd przed rozprawą główną lub w jej toku stwierdzi, że 

sprawa nie podlega rozpoznaniu w trybie przyspieszonym, rozstrzyga w przedmiocie 

środka zapobiegawczego i przekazuje sprawę prokuratorowi w celu przeprowadzenia 

postępowania przygotowawczego na zasadach ogólnych, zawiadamiając o tym 

pokrzywdzonego. Jeżeli natomiast sąd stwierdzi jedynie, że sprawy nie można 

rozpoznać w postępowaniu przyspieszonym z zachowaniem dopuszczalnego czasu 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 209/356 

przerw w rozprawie, określonego w art. 517f § 1, rozpoznaje ją w dalszym ciągu 

w trybie zwyczajnym. Jeżeli jednak sąd stwierdzi niemożność zachowania łącznego 

czasu przerw, określonego w art. 517f § 1, 

już przed rozprawą, rozstrzyga 

w przedmiocie środka zapobiegawczego i przekazuje sprawę prokuratorowi do 

przeprowadzenia postępowania przygotowawczego na zasadach ogólnych, 

zawiadamiając o tym pokrzywdzonego. 

§ 2. Jeżeli na podstawie okoliczności ujawnionych po rozpoczęciu przewodu 

sądowego sąd stwierdzi, że zachodzi potrzeba uzupełnienia postępowania 

dowodowego, zaś dokonanie niezbędnych czynności w postępowaniu sądowym 

powodowałoby znaczne 

trudności, przekazuje sprawę prokuratorowi w celu 

przeprowadzenia postępowania przygotowawczego na zasadach ogólnych, 

zawiadamiając o tym pokrzywdzonego; przed przekazaniem sprawy sąd rozstrzyga 

w przedmiocie środka zapobiegawczego. 

§ 3. Jeżeli na podstawie okoliczności ujawnionych po rozpoczęciu przewodu 

sądowego sąd przewiduje możliwość wymierzenia kary powyżej 2 lat pozbawienia 

wolności, rozstrzyga w przedmiocie środka zapobiegawczego i przekazuje sprawę 

prokuratorowi w celu przeprowadzenia postępowania przygotowawczego na zasadach 

ogólnych; sędzia, który brał udział w wydaniu postanowienia, jest z mocy prawa 

wyłączony od dalszego udziału w sprawie. 

§ 4. W razie skazania oskarżonego na karę pozbawienia wolności bez 

warunkowego zawieszenia jej wykonania sąd, po wysłuchaniu stron, rozstrzyga 

w przedmiocie środka zapobiegawczego.


## Art. 517ga. {#kpk-art-517ga}
W razie zarządzenia przerwy w rozprawie lub zmiany trybu 

postępowania w dalszym postępowaniu nie stosuje się w stosunku do oskarżonego 

sposobu uczestniczenia w czynnościach sądowych przewidzianego w art. 517b § 2a.


## Art. 517h. {#kpk-art-517h}
§ 1. Wniosek o sporządzenie na piśmie i doręczenie uzasadnienia 

wyroku może być złożony na piśmie w terminie zawitym 3 dni od daty ogłoszenia 

wyroku, a jeżeli ustawa przewiduje doręczenie wyroku – od daty jego doręczenia. 

Wniosek można również złożyć ustnie do protokołu rozprawy lub posiedzenia. 

§ 2. Sąd sporządza uzasadnienie wyroku w terminie 3 dni od daty złożenia 

wniosku o sporządzenie uzasadnienia. 

2025-09-11 

 
 
 
 

©Kancelaria Sejmu 

s. 210/356 

§ 3. Termin do wniesienia apelacji wynosi 7 dni i biegnie dla każdego 

uprawnionego od daty doręczenia mu wyroku z uzasadnieniem. 

§ 4. W razie złożenia apelacji przekazuje się ją niezwłocznie wraz z aktami 

sądowi odwoławczemu, który rozpoznaje sprawę najpóźniej w ciągu miesiąca od daty 

jej wpływu do tego sądu. Przepisu art. 448 nie stosuje się. 

§ 5. W wypadku wniesienia apelacji przez prokuratora, obrońcę 

lub 

pełnomocnika sąd odwoławczy dołącza do zawiadomienia o terminie rozprawy 

apelacyjnej odpis apelacji strony przeciwnej.


## Art. 517i. {#kpk-art-517i}
§ 1. Jeżeli po rozpoznaniu środka odwoławczego sąd stwierdza, że 

zachodzi potrzeba uzupełnienia postępowania dowodowego, 

a dokonanie 

niezbędnych czynności przez sąd powodowałoby znaczne trudności, może – uchylając 

wyrok – przekazać sprawę prokuratorowi w celu przeprowadzenia postępowania 

przygotowawczego na zasadach ogólnych. 

§ 2. W wypadku uchylenia wyroku i przekazania sprawy do ponownego 

rozpoznania dalsze postępowanie toczy się w trybie zwyczajnym.


## Art. 517j. {#kpk-art-517j}
§ 1. W celu umożliwienia oskarżonemu korzystania z pomocy 

obrońcy w postępowaniu przyspieszonym ustanawia się obowiązek pełnienia przez 

adwokatów i radców prawnych dyżurów w czasie i miejscu ustalonym w odrębnych 

przepisach. 

§ 2. Minister Sprawiedliwości określi, w drodze rozporządzenia, sposób 

zapewnienia oskarżonemu korzystania z pomocy obrońcy i możliwości jego wyboru 

w postępowaniu przyspieszonym, w tym organizacji dyżurów, o których mowa w § 1, 

mając na uwadze prawidłowy przebieg postępowania przyspieszonego oraz 

konieczność zapewnienia oskarżonemu możliwości wyboru obrońcy.
