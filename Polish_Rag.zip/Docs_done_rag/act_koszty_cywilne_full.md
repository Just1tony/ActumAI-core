---
id: act.koszty-cywilne
title: "Ustawa z dnia 28 lipca 2005 r. o kosztach sądowych w sprawach cywilnych (tekst jednolity)"
category: act
jurisdiction: PL
language: pl
source_type: statute
canonical_citation: "Dz.U. 2005 nr 167 poz. 1398"
status: "obowiązujący"
last_consolidated: "2025-09-24"
aliases: ["Ustawa o kosztach sądowych w sprawach cywilnych"]
tags: ["koszty sądowe","postępowanie cywilne","opłaty sądowe","PL"]
source_pdf: "D20051398Lj.pdf"
---

# Ustawa o kosztach sądowych w sprawach cywilnych

©Kancelaria Sejmu 
 
 
 
 
s. 1/46 
2025-09-24 
 
 
Dz. U. 2005 Nr 167 poz. 1398  
 
 
 
U S TAWA  
z dnia 28 lipca 2005 r. 
o kosztach sądowych w sprawach cywilnych1) 
TYTUŁ I 
Przepisy ogólne
***
## Art. 1. {#art-1}

Ustawa określa zasady i tryb pobierania kosztów sądowych w sprawach 
cywilnych, zasady ich zwrotu, wysokość opłat sądowych w sprawach cywilnych, 
zasady zwalniania od kosztów sądowych oraz umarzania, rozkładania na raty 
i odraczania terminu zapłaty należności sądowych.
***
## Art. 2. {#art-2}

1. Koszty sądowe obejmują opłaty i wydatki. 
2. Do uiszczenia kosztów sądowych obowiązana jest strona, która wnosi do sądu 
pismo podlegające opłacie lub powodujące wydatki, chyba że ustawa stanowi inaczej.
***
## Art. 3. {#art-3}

1. Opłacie podlega pismo, jeżeli przepis ustawy przewiduje jej pobranie. 
2. Opłacie podlegają w szczególności następujące pisma: 
- 1) 
pozew i pozew wzajemny; 
1a) pismo zawierające oświadczenie o rozszerzeniu powództwa lub jego zmianie 
w sposób powodujący wzrost wartości przedmiotu sporu; 
- 2) 
apelacja i zażalenie; 
- 3) 
skarga kasacyjna i skarga o stwierdzenie niezgodności z prawem prawomocnego 
orzeczenia; 
- 1) Niniejsza ustawa w zakresie swojej regulacji wdraża dyrektywę Parlamentu Europejskiego i Rady 
(UE) 2020/1828 z dnia 25 listopada 2020 r. w sprawie powództw przedstawicielskich wytaczanych 
w celu ochrony zbiorowych interesów konsumentów i uchylającą dyrektywę 2009/22/WE (Dz. Urz. 
UE L 409 z 04.12.2020, str. 1, Dz. Urz. UE L 265 z 12.10.2022, str. 1, Dz. Urz. UE L 277 
z 27.10.2022, str. 1, Dz. Urz. UE L 135 z 23.05.2023, str. 1 oraz Dz. Urz. UE L 2023/2854 
z 22.12.2023). 
Opracowano na 
podstawie: 
t.j. 
Dz. U. z 2025 r. 
poz. 1228. 

©Kancelaria Sejmu 
 
 
 
 
s. 2/46 
2025-09-24 
- 4) 
sprzeciw od wyroku zaocznego; 
- 5) 
zarzuty od nakazu zapłaty; 
- 6) 
interwencja główna i uboczna; 
- 7) 
wniosek: 
  - a) 
o wszczęcie postępowania nieprocesowego, 
  - b) 
o ogłoszenie upadłości, 
  - c) 
o wpis i wykreślenie w księdze wieczystej, 
  - d) 
o wpis w Krajowym Rejestrze Sądowym i w rejestrze zastawów oraz 
o zmianę i wykreślenie tych wpisów; 
- 8) 
skarga: 
  - a) 
o wznowienie postępowania, 
  - b) 
o uchylenie wyroku sądu polubownego, 
  - c) 
na orzeczenie referendarza sądowego, 
  - d) 
na czynności komornika; 
- 9) 
odwołanie od decyzji oraz zażalenie na postanowienie Prezesa Urzędu Ochrony 
Konkurencji i Konsumentów, Prezesa Urzędu Regulacji Energetyki, Prezesa 
Urzędu Komunikacji Elektronicznej, Prezesa Urzędu Transportu Kolejowego, 
Przewodniczącego Krajowej Rady Radiofonii i Telewizji oraz organu 
regulacyjnego, o którym mowa w ustawie z dnia 7 czerwca 2001 r. o zbiorowym 
zaopatrzeniu w wodę i zbiorowym odprowadzaniu ścieków (Dz. U. z 2024 r. 
poz. 757). 
3. Opłacie podlega wniosek o wydanie na podstawie akt: odpisu, wypisu, 
zaświadczenia, wyciągu, innego dokumentu oraz kopii, a nadto wniosek o wydanie 
odpisu księgi wieczystej (opłata kancelaryjna).
***
## Art. 4. {#art-4}

1. Pismo wnoszone przez kilka osób podlega jednej opłacie. Jeżeli jednak 
przedmiotem sprawy są roszczenia lub zobowiązania jednego rodzaju i oparte na 
jednakowej podstawie faktycznej i prawnej (współuczestnictwo formalne), każdy 
współuczestnik uiszcza opłatę oddzielnie, stosownie do swojego roszczenia lub 
zobowiązania. 
2. Opłatę od wniosku o dokonanie wpisu w księdze wieczystej pobiera się od 
osoby, która wystąpiła z takim wnioskiem, także wówczas, gdy na jego podstawie 
mają być ujawnione prawa osób, które nie są wnioskodawcami. 
3. (uchylony)
***
## Art. 5. {#art-5}

1. Wydatki obejmują w szczególności: 

©Kancelaria Sejmu 
 
 
 
 
s. 3/46 
2025-09-24 
- 1) 
koszty podróży strony zwolnionej od kosztów sądowych związane z nakazanym 
przez sąd jej osobistym stawiennictwem; 
- 2) 
zwrot kosztów podróży i noclegu oraz utraconych zarobków lub dochodów 
świadków; 
- 3) 
wynagrodzenie i zwrot kosztów poniesionych przez biegłych, tłumaczy oraz 
kuratorów ustanowionych dla strony w danej sprawie; 
3a) zryczałtowane koszty przeprowadzenia dowodu z opinii opiniodawczego 
zespołu sądowych specjalistów; 
- 4) 
wynagrodzenie należne innym osobom lub instytucjom oraz zwrot poniesionych 
przez nie kosztów; 
- 5) 
koszty przeprowadzenia innych dowodów; 
- 6) 
koszty przewozu zwierząt i rzeczy, utrzymywania ich lub przechowywania; 
- 7) 
koszty ogłoszeń; 
- 8) 
koszty osadzenia i pobytu w areszcie; 
- 9) 
ryczałty 
należne 
kuratorom 
sądowym 
za 
przeprowadzenie 
wywiadu 
środowiskowego w sprawach: o unieważnienie małżeństwa, o rozwód oraz 
separację, a także za uczestniczenie przy ustalonych przez sąd kontaktach 
rodziców z dziećmi; 
- 10) koszty wystawienia zaświadczenia przez lekarza sądowego; 
- 11) koszty mediacji prowadzonej na skutek skierowania przez sąd. 
2. Wydatki związane z doręczaniem pism sądowych nie obciążają stron, 
z wyjątkiem kosztów doręczenia za pośrednictwem komornika oraz dodatkowych 
kosztów doręczenia za granicą, w tym kosztów tłumaczenia. 
3. Wydatki związane ze zwrotem opłat nie obciążają stron.
***
## Art. 6. {#art-6}

(uchylony)
***
## Art. 7. {#art-7}

1. Stroną w rozumieniu ustawy jest każdy uczestnik postępowania 
sądowego, w tym także świadek, biegły i tłumacz, a kosztami procesu są również 
koszty innych rodzajów postępowania. 
2. Przez pismo wnoszone do sądu rozumie się również składany ustnie do 
protokołu pozew, wniosek wszczynający innego rodzaju postępowanie lub inny 
wniosek, jeżeli podlega opłacie.
***
## Art. 8. {#art-8}

1. W postępowaniu dotyczącym kosztów sądowych stosuje się przepisy 
ustawy z dnia 17 listopada 1964 r. – Kodeks postępowania cywilnego (Dz. U. z 2024 
r. poz. 1568 i 1841 oraz z 2025 r. poz. 620 i 1172), chyba że ustawa stanowi inaczej. 

©Kancelaria Sejmu 
 
 
 
 
s. 4/46 
2025-09-24 
2. Postanowienie w przedmiocie kosztów sądowych może wydać także 
referendarz sądowy. 
3. Uiszczenie opłaty wyższej niż należna nie powoduje dla strony niekorzystnych 
skutków procesowych.
***
## Art. 9. {#art-9}

Minister Sprawiedliwości określi, w drodze rozporządzenia: 
- 1) 
sposób uiszczania opłat sądowych w sprawach cywilnych, w tym wnoszonych 
na rachunek bankowy sądu lub w formie znaków opłaty sądowej według 
ustalonego wzoru, mając na względzie łatwość uiszczenia opłat przez strony oraz 
skutek w postaci zwrotu lub odrzucenia pisma, od którego przy jego wniesieniu 
nie została uiszczona należna opłata; 
- 2) 
wzór oświadczenia o stanie rodzinnym, majątku, dochodach i źródłach 
utrzymania, o którym mowa w art. 102 ust. 2, a także sposób udostępniania 
osobom fizycznym wzoru druków tych oświadczeń w siedzibach sądów, mając 
na względzie komunikatywność niezbędnych pouczeń dla stron co do sposobu 
wypełnienia, skutków niezłożenia lub złożenia nieprawdziwego oświadczenia; 
- 3) 
wysokość wynagrodzenia i zwrot wydatków poniesionych przez kuratorów 
ustanowionych dla strony w danej sprawie, mając na względzie rodzaj sprawy, 
stopień jej zawiłości i nakład pracy kuratorów; 
- 4) 
wysokość zryczałtowanych kosztów przeprowadzenia dowodu z opinii 
opiniodawczego zespołu sądowych specjalistów, mając na względzie zakres 
przeprowadzanych przez zespół badań, wymagania dotyczące kwalifikacji 
specjalistów zespołu oraz nakład pracy niezbędny do wydania opinii. 
TYTUŁ II 
Opłaty 
DZIAŁ 1 
Przepisy ogólne
***
## Art. 10. {#art-10}

Opłatę należy uiścić przy wniesieniu do sądu pisma podlegającego 
opłacie.
***
## Art. 11. {#art-11}

Opłata jest stała, stosunkowa albo podstawowa.
***
## Art. 12. {#art-12}

Opłatę stałą pobiera się w sprawach o prawa niemajątkowe oraz we 
wskazanych w ustawie niektórych sprawach o prawa majątkowe, w wysokości 
jednakowej, niezależnie od wartości przedmiotu sporu lub wartości przedmiotu 

©Kancelaria Sejmu 
 
 
 
 
s. 5/46 
2025-09-24 
zaskarżenia. Opłata stała nie może być niższa niż 30 złotych i wyższa niż 
10 000 złotych.
***
## Art. 13. {#art-13}

1. W sprawach o prawa majątkowe pobiera się od pisma opłatę stałą 
ustaloną według wartości przedmiotu sporu lub wartości przedmiotu zaskarżenia 
wynoszącej: 
- 1) 
do 500 złotych – w kwocie 30 złotych; 
- 2) 
ponad 500 złotych do 1500 złotych – w kwocie 100 złotych; 
- 3) 
ponad 1500 złotych do 4000 złotych – w kwocie 200 złotych; 
- 4) 
ponad 4000 złotych do 7500 złotych – w kwocie 400 złotych; 
- 5) 
ponad 7500 złotych do 10 000 złotych – w kwocie 500 złotych; 
- 6) 
ponad 10 000 złotych do 15 000 złotych – w kwocie 750 złotych; 
- 7) 
ponad 15 000 złotych do 20 000 złotych – w kwocie 1000 złotych. 
2. W sprawach o prawa majątkowe przy wartości przedmiotu sporu lub wartości 
przedmiotu zaskarżenia ponad 20 000 złotych pobiera się od pisma opłatę stosunkową 
wynoszącą 5 % tej wartości, nie więcej jednak niż 100 000 złotych. 
Art. 13a. W sprawach o roszczenia wynikające z czynności bankowych od 
strony będącej konsumentem lub osobą fizyczną prowadzącą gospodarstwo rodzinne 
przy wartości przedmiotu sporu lub wartości przedmiotu zaskarżenia wynoszącej 
ponad 20 000 złotych pobiera się opłatę stałą w kwocie 1000 złotych. 
Art. 13b. W sprawach o roszczenia wynikające z art. 36 ustawy z dnia 27 marca 
2003 r. o planowaniu i zagospodarowaniu przestrzennym (Dz. U. z 2024 r. poz. 1130, 
1907 i 1940 oraz z 2025 r. poz. 527 i 680) przy wartości przedmiotu sporu lub wartości 
przedmiotu zaskarżenia wynoszącej ponad 20 000 złotych pobiera się opłatę stałą 
w kwocie 1000 złotych. 
Art. 13c. W sprawach o: 
- 1) 
usunięcie niezgodności treści księgi wieczystej z rzeczywistym stanem 
prawnym, 
- 2) 
pozbawienie tytułu wykonawczego wykonalności, 
- 3) 
zwolnienie zajętego przedmiotu od egzekucji 
– przy wartości przedmiotu sporu lub wartości przedmiotu zaskarżenia wynoszącej 
ponad 40 000 złotych pobiera się opłatę stałą w kwocie 2000 złotych. 
Art. 13d. W sprawach o prawa majątkowe dochodzone w postępowaniu 
grupowym opłata stała lub stosunkowa wynosi połowę opłaty ustalonej zgodnie 

©Kancelaria Sejmu 
 
 
 
 
s. 6/46 
2025-09-24 
z art. 13, art. 13a i art. 13b, jednak nie mniej niż 100 złotych i nie więcej niż 
200 000 złotych. 
Art. 13e. W sprawach, w których powód przed wytoczeniem powództwa wziął 
udział w mediacji prowadzonej na podstawie umowy o mediację zgodnie z ustawą 
z dnia 17 listopada 1964 r. – Kodeks postępowania cywilnego lub podjął próbę 
rozwiązania sporu przez złożenie wniosku o rozpatrzenie sporu przez właściwy sąd 
polubowny ustanowiony ustawą w celu rozpatrywania sporów konsumenckich albo 
wniosku o wszczęcie postępowania w sprawie pozasądowego rozwiązania sporu 
konsumenckiego, opłata stała lub stosunkowa od pozwu podlega obniżeniu o dwie 
trzecie, nie więcej jednak niż o 400 złotych. 
Art. 13f. W sprawach o uznanie za bezskuteczną czynności prawnej dłużnika 
dokonanej z pokrzywdzeniem wierzycieli, przy wartości przedmiotu sporu lub 
wartości przedmiotu zaskarżenia wynoszącej ponad 20 000 złotych pobiera się opłatę 
stałą w wysokości 1000 złotych, jeżeli roszczenie wierzyciela wobec dłużnika zostało 
stwierdzone prawomocnym orzeczeniem sądu, orzeczeniem sądu polubownego, 
którego wykonalność została stwierdzona przez sąd, ugodą zawartą przed sądem albo 
sądem polubownym, albo ugodą zawartą przed mediatorem i zatwierdzoną przez sąd.
***
## Art. 14. {#art-14}

1. Opłatę podstawową pobiera się w sprawach, w których przepisy nie 
przewidują opłaty stałej, stosunkowej lub tymczasowej. 
2. (uchylony) 
3. Opłata podstawowa wynosi 30 złotych i stanowi minimalną opłatę, którą 
strona jest obowiązana uiścić od pisma podlegającego opłacie, chyba że ustawa 
stanowi inaczej. 
4. Pobranie od pisma opłaty podstawowej wyłącza pobranie innej opłaty. 
5. Przepisów 
o opłacie 
podstawowej 
nie 
stosuje 
się 
w postępowaniu 
wieczystoksięgowym oraz w postępowaniu rejestrowym. 
Art. 14a. 1. W sprawie, w której powództwo oddalono na podstawie art. 1911 
ustawy z dnia 17 listopada 1964 r. – Kodeks postępowania cywilnego, powoda nie 
obciąża się kosztami sądowymi. 
2. Jeżeli jednak apelację oddalono na podstawie art. 3911 ustawy z dnia 
17 listopada 1964 r. – Kodeks postępowania cywilnego, sąd drugiej instancji obciąży 
powoda opłatą podstawową od pozwu i od apelacji. Jeżeli powód wniósł o zwolnienie 
od kosztów sądowych, sąd drugiej instancji może mu je przyznać. 

©Kancelaria Sejmu 
 
 
 
 
s. 7/46 
2025-09-24
***
## Art. 15. {#art-15}

1. Od pisma wniesionego w sprawie o prawa majątkowe, w której 
wartości przedmiotu sprawy nie da się ustalić w chwili jej wszczęcia, przewodniczący 
określa opłatę tymczasową. 
2. Opłatę tymczasową określa się w granicach od 30 złotych do 2000 złotych, 
a w sprawach dochodzonych w postępowaniu grupowym od 300 złotych do 
20 000 złotych. 
3. W orzeczeniu kończącym postępowanie w pierwszej instancji sąd określa 
wysokość opłaty ostatecznej, która jest bądź opłatą stosunkową, obliczoną od wartości 
przedmiotu sporu ustalonej w toku postępowania, bądź opłatą określoną przez sąd, 
jeżeli wartości tej nie udało się ustalić. W tym wypadku opłatę ostateczną sąd określa 
w kwocie nie wyższej niż 5000 złotych, mając na względzie społeczną doniosłość 
rozstrzygnięcia i stopień zawiłości sprawy.
***
## Art. 16. {#art-16}

1. Jeżeli opłata ostateczna jest wyższa od opłaty tymczasowej, sąd 
orzeka o obowiązku uiszczenia różnicy, stosując odpowiednio zasady obowiązujące 
przy zwrocie kosztów procesu. 
2. (uchylony)
***
## Art. 17. {#art-17}

W wypadku wstąpienia do sprawy osoby, na której rzecz prokurator 
wytoczył powództwo lub zgłosił wniosek o wszczęcie postępowania, pobiera się od 
tej osoby opłatę należną od takiego pozwu lub wniosku.
***
## Art. 18. {#art-18}

1. Całą opłatę pobiera się od pozwu i pozwu wzajemnego oraz wniosku 
o wszczęcie postępowania nieprocesowego lub samodzielnej jego części, chyba że 
przepis szczególny stanowi inaczej. 
2. Przepisy ustawy przewidujące pobranie opłaty od pozwu lub wniosku 
wszczynającego postępowanie w sprawie stosuje się również do opłaty od apelacji, 
skargi kasacyjnej, skargi o stwierdzenie niezgodności z prawem prawomocnego 
orzeczenia, interwencji głównej, skargi o wznowienie postępowania, skargi 
o uchylenie wyroku sądu polubownego, chyba że przepis szczególny stanowi inaczej.
***
## Art. 19. {#art-19}

1. Połowę opłaty pobiera się od sprzeciwu od wyroku zaocznego i od 
wniosku o uchylenie europejskiego nakazu zapłaty. 
2. Czwartą część opłaty pobiera się od pozwu: 
- 1) 
spełniającego przesłanki do rozpoznania w postępowaniu nakazowym; 
- 2) 
w elektronicznym postępowaniu upominawczym, z tym że w przypadku, 
o którym mowa w art. 50537 § 2 ustawy z dnia 17 listopada 1964 r. – Kodeks 
postępowania cywilnego, uiszczoną opłatę od pozwu w elektronicznym 

©Kancelaria Sejmu 
 
 
 
 
s. 8/46 
2025-09-24 
postępowaniu upominawczym zalicza się na poczet opłaty od nowo wniesionego 
pozwu. 
3. Piątą część opłaty pobiera się od: 
- 1) 
interwencji ubocznej; 
- 2) 
zażalenia, chyba że przepis szczególny stanowi inaczej; 
- 3) 
wniosku o zawezwanie do próby ugodowej w sprawach o prawa niemajątkowe, 
nie mniej jednak niż 100 złotych. 
4. Trzy czwarte części opłaty pobiera się od pozwanego w razie wniesienia 
zarzutów od nakazu zapłaty wydanego w postępowaniu nakazowym, jednakże w 
przypadku gdy nakaz zapłaty w postępowaniu nakazowym został wydany przeciwko 
konsumentowi, od pozwanego konsumenta pobiera się opłatę nie większą niż 750 
złotych.
***
## Art. 20. {#art-20}

1. Opłata, o której mowa w art. 19, nie może wynosić mniej niż 
30 złotych. 
2. Jeżeli opłata ta ma być pobrana przed ustaleniem opłaty ostatecznej, pobiera 
się odpowiednią część opłaty tymczasowej, nie mniej jednak niż 30 złotych.
***
## Art. 21. {#art-21}

Końcówkę opłaty zaokrągla się w górę do pełnego złotego. 
Art. 21a. W przypadku przekazania sprawy innemu sądowi nie przekazuje się 
temu sądowi pobranych w tej sprawie opłat. 
DZIAŁ 2 
Wysokość opłat we wszystkich rodzajach spraw
***
## Art. 22. {#art-22}

Opłatę stałą w kwocie 100 złotych pobiera się od zażalenia na 
postanowienie w przedmiocie: 
- 1) 
oddalenia wniosku o wyłączenie sędziego lub ławnika; 
- 2) 
skazania na grzywnę strony, świadka, biegłego, tłumacza lub innej osoby oraz 
odmowy zwolnienia od grzywny; 
- 3) 
przymusowego sprowadzenia lub aresztowania świadka oraz odmowy 
zwolnienia od przymusowego sprowadzenia; 
- 4) 
wynagrodzenia i zwrotu kosztów poniesionych przez mediatora, biegłego, 
tłumacza, kuratora lub uprawnioną osobę trzecią; 
- 5) 
należności świadka.
***
## Art. 23. {#art-23}

Opłatę stałą w kwocie 100 złotych pobiera się od: 

©Kancelaria Sejmu 
 
 
 
 
s. 9/46 
2025-09-24 
- 1) 
wniosku o wszczęcie postępowania nieprocesowego lub samodzielnej jego 
części, chyba że przepis szczególny stanowi inaczej; 
- 2) 
apelacji, zażalenia, skargi kasacyjnej, skargi o wznowienie postępowania i skargi 
o stwierdzenie niezgodności z prawem prawomocnego orzeczenia w sprawie, 
w której postępowanie nieprocesowe zostało wszczęte z urzędu; 
- 3) 
(uchylony) 
- 4) 
wniosku o zabezpieczenie dowodu. 
Art. 23a. 1. Opłatę stałą w kwocie 120 złotych pobiera się od wniosku 
o zawezwanie do próby ugodowej w sprawach o prawa majątkowe, gdy wartość 
przedmiotu sporu nie przekracza 20 000 złotych. 
2. Opłatę stałą w kwocie 300 złotych pobiera się od wniosku o zawezwanie do 
próby ugodowej w sprawach o prawa majątkowe, gdy wartość przedmiotu sporu 
przekracza 20 000 złotych.
***
## Art. 24. {#art-24}

1. Opłatę stałą w kwocie 300 zł pobiera się od wniosku o: 
- 1) 
ustalenie, że orzeczenie sądu państwa obcego lub rozstrzygnięcie innego organu 
państwa obcego podlega albo nie podlega uznaniu; 
- 2) 
stwierdzenie wykonalności orzeczenia sądu państwa obcego lub rozstrzygnięcia 
innego organu państwa obcego albo ugody zawartej przed tym sądem lub 
organem lub zatwierdzonej przez ten sąd lub organ; 
2a) odmowę wykonania, o którym mowa w przepisach rozporządzenia Parlamentu 
Europejskiego i Rady (UE) nr 1215/2012 z dnia 12 grudnia 2012 r. w sprawie 
jurysdykcji i uznawania orzeczeń sądowych oraz ich wykonywania w sprawach 
cywilnych 
i handlowych 
(wersja 
przekształcona) 
(Dz. Urz. 
UE L 351 
z 20.12.2012, str. 1, z późn. zm.), rozporządzenia (WE) nr 805/2004 Parlamentu 
Europejskiego i Rady z dnia 21 kwietnia 2004 r. w sprawie utworzenia 
Europejskiego Tytułu Egzekucyjnego dla roszczeń bezspornych (Dz. Urz. 
UE L 143 z 30.04.2004, str. 15, z późn. zm.; Dz. Urz. UE Polskie wydanie 
specjalne, rozdz. 19, t. 7, str. 38), rozporządzenia (WE) nr 1896/2006 Parlamentu 
Europejskiego i Rady z dnia 12 grudnia 2006 r. ustanawiającego postępowanie 
w sprawie europejskiego nakazu zapłaty (Dz. Urz. UE L 399 z 30.12.2006, str. 1, 
z późn. zm.), rozporządzenia (WE) nr 861/2007 Parlamentu Europejskiego 
i Rady z dnia 11 lipca 2007 r. ustanawiającego europejskie postępowanie 
w sprawie drobnych roszczeń (Dz. Urz. UE L 199 z 31.07.2007, str. 1, z późn. 
zm.), rozporządzenia Rady (WE) nr 4/2009 z dnia 18 grudnia 2008 r. w sprawie 

©Kancelaria Sejmu 
 
 
 
 
s. 10/46 
2025-09-24 
jurysdykcji, prawa właściwego, uznawania i wykonywania orzeczeń oraz 
współpracy w zakresie zobowiązań alimentacyjnych (Dz. Urz. UE L 7 
z 10.01.2009, str. 1, z późn. zm.) lub rozporządzenia Parlamentu Europejskiego 
i Rady (UE) nr 606/2013 z dnia 12 czerwca 2013 r. w sprawie wzajemnego 
uznawania środków ochrony w sprawach cywilnych (Dz. Urz. UE L 181 
z 29.06.2013, str. 4) lub rozporządzenia Rady (UE) 2019/1111 z dnia 25 czerwca 
2019 r. w sprawie jurysdykcji, uznawania i wykonywania orzeczeń w sprawach 
małżeńskich i w sprawach dotyczących odpowiedzialności rodzicielskiej oraz 
w sprawie uprowadzenia dziecka za granicę (wersja przekształcona) (Dz. Urz. 
UE L 178 z 02.07.2019, str. 1); 
2b) odmowę uznania albo stwierdzenie braku podstaw do odmowy uznania, 
o których mowa w przepisach rozporządzenia Parlamentu Europejskiego i Rady 
(UE) nr 1215/2012 z dnia 12 grudnia 2012 r. w sprawie jurysdykcji i uznawania 
orzeczeń sądowych oraz ich wykonywania w sprawach cywilnych i handlowych 
(wersja przekształcona) lub rozporządzenia Rady (UE) 2019/1111 z dnia 
25 czerwca 2019 r. w sprawie jurysdykcji, uznawania i wykonywania orzeczeń 
w sprawach 
małżeńskich 
i w sprawach 
dotyczących 
odpowiedzialności 
rodzicielskiej oraz w sprawie uprowadzenia dziecka za granicę (wersja 
przekształcona); 
2c) odmowę uznania, o którym mowa w przepisach rozporządzenia Parlamentu 
Europejskiego i Rady (UE) nr 606/2013 z dnia 12 czerwca 2013 r. w sprawie 
wzajemnego uznawania środków ochrony w sprawach cywilnych; 
- 3) 
uznanie lub stwierdzenie wykonalności orzeczenia sądu polubownego lub ugody 
zawartej przed tym sądem; 
- 4) 
wydanie europejskiego poświadczenia spadkowego. 
- 5) 
(uchylony) 
2. Opłatę stałą w kwocie 200 zł pobiera się od wniosku o dokonanie przez sąd 
czynności w trakcie postępowania przed sądem polubownym niewymienionych 
w ust. 1.
***
## Art. 25. {#art-25}

1. Opłatę stałą w kwocie 50 złotych pobiera się od skargi na czynności 
komornika. 
1a. Opłatę stałą w kwocie 100 złotych pobiera się od zażalenia na odmowę 
dokonania czynności notarialnej. 
2. Opłatę od skargi na orzeczenie referendarza pobiera się w wysokości opłaty 
od wniosku o wydanie tego orzeczenia, nie więcej jednak niż 100 złotych. 

©Kancelaria Sejmu 
 
 
 
 
s. 11/46 
2025-09-24 
Art. 25a. Opłatę od pisma zawierającego oświadczenie o rozszerzeniu 
powództwa lub jego zmianie w sposób powodujący wzrost wartości przedmiotu sporu 
pobiera się w wysokości różnicy między opłatą należną od powództwa rozszerzonego 
lub zmienionego a opłatą należną sprzed rozszerzenia lub zmiany powództwa, nie 
niższej jednak niż 30 złotych. 
Art. 25b. 1. Opłatę stałą w kwocie 100 złotych pobiera się od wniosku 
o doręczenie wyroku albo postanowienia co do istoty sprawy z uzasadnieniem 
zgłoszonego w terminie tygodnia od dnia ogłoszenia albo doręczenia tego orzeczenia. 
2. Opłatę stałą w kwocie 30 złotych pobiera się od wniosku o doręczenie 
postanowienia, innego niż wskazane w ust. 1, lub zarządzenia z uzasadnieniem 
zgłoszonego w terminie tygodnia od dnia ogłoszenia albo doręczenia tego orzeczenia 
albo zarządzenia. 
3. W przypadku wniesienia środka zaskarżenia opłatę uiszczoną od wniosku 
o doręczenie orzeczenia albo zarządzenia z uzasadnieniem zalicza się na poczet opłaty 
od środka zaskarżenia. Ewentualna nadwyżka nie podlega zwrotowi. 
DZIAŁ 3 
Wysokość opłat w procesie 
Rozdział 1 
Sprawy z zakresu prawa cywilnego i rodzinnego
***
## Art. 26. {#art-26}

1. Opłatę stałą w kwocie 600 złotych pobiera się od pozwu o: 
- 1) 
rozwód; 
- 2) 
separację; 
- 3) 
ochronę dóbr osobistych; 
- 4) 
(uchylony) 
- 5) 
(uchylony) 
- 6) 
ochronę innych praw niemajątkowych, chyba że przepis szczególny stanowi 
inaczej; 
- 7) 
ochronę niemajątkowych praw dochodzonych w postępowaniu grupowym. 
2. W sprawach o rozwód, o separację lub o unieważnienie małżeństwa, w razie 
zasądzenia alimentów na rzecz małżonka w orzeczeniu kończącym postępowanie 
w instancji, pobiera się od małżonka zobowiązanego opłatę stosunkową od 
zasądzonego roszczenia, a w razie nakazania eksmisji jednego z małżonków albo 

©Kancelaria Sejmu 
 
 
 
 
s. 12/46 
2025-09-24 
podziału wspólnego majątku pobiera się także opłatę w wysokości przewidzianej od 
pozwu lub wniosku w takiej sprawie. 
Art. 26a. 1. W sprawach o: 
- 1) 
ochronę praw autorskich i praw pokrewnych jak również dotyczących 
wynalazków, 
wzorów 
użytkowych, 
wzorów 
przemysłowych, 
znaków 
towarowych, oznaczeń geograficznych i topografii układów scalonych oraz 
ochronę innych praw na dobrach niematerialnych, w tym europejskich praw 
własności intelektualnej, 
- 2) 
zapobieganie i zwalczanie nieuczciwej konkurencji 
– pobiera się od pozwu opłatę stałą lub stosunkową w kwocie określonej w art. 13–
13d od każdego roszczenia pieniężnego, a od każdego innego roszczenia stałą 
w kwocie 300 złotych. 
2. Opłatę stałą w kwocie 200 złotych pobiera się od wniosku o: 
- 1) 
zabezpieczenie środka dowodowego, o którym mowa w art. 80 ust. 1 pkt 1 
ustawy z dnia 4 lutego 1994 r. o prawie autorskim i prawach pokrewnych 
(Dz. U. z 2025 r. poz. 24), art. 2861 ust. 1 pkt 1 ustawy z dnia 30 czerwca 2000 r. 
– Prawo własności przemysłowej (Dz. U. z 2023 r. poz. 1170), art. 36b 
ust. 1 pkt 1 ustawy z dnia 26 czerwca 2003 r. o ochronie prawnej odmian roślin 
(Dz. U. z 2021 r. poz. 213) oraz art. 11a ust. 1 pkt 1 ustawy z dnia 27 lipca 
2001 r. o ochronie baz danych (Dz. U. z 2024 r. poz. 1769); 
- 2) 
wezwanie do udzielenia informacji, o którym mowa w art. 80 ust. 1 pkt 3 ustawy 
z dnia 4 lutego 1994 r. o prawie autorskim i prawach pokrewnych, 
art. 2861 ust. 1 pkt 3 ustawy z dnia 30 czerwca 2000 r. – Prawo własności 
przemysłowej, art. 36b ust. 1 pkt 3 ustawy z dnia 26 czerwca 2003 r. o ochronie 
prawnej odmian roślin oraz art. 11a ust. 1 pkt 3 ustawy z dnia 27 lipca 2001 r. 
o ochronie baz danych.
***
## Art. 27. {#art-27}

Opłatę stałą w kwocie 200 złotych pobiera się od pozwu w sprawie o: 
- 1) 
ustalenie istnienia lub nieistnienia małżeństwa; 
- 2) 
unieważnienie małżeństwa; 
- 3) 
rozwiązanie przysposobienia; 
- 4) 
zaprzeczenie ojcostwa lub macierzyństwa; 
- 5) 
unieważnienie uznania dziecka; 
- 6) 
ustanowienie przez sąd rozdzielności majątkowej; 
- 7) 
naruszenie posiadania; 

©Kancelaria Sejmu 
 
 
 
 
s. 13/46 
2025-09-24 
- 8) 
uchylenie uchwały organu spółdzielni; 
8a) stwierdzenie nieważności uchwały organu spółdzielni; 
8b) ustalenie istnienia lub nieistnienia uchwały organu spółdzielni; 
- 9) 
uchylenie uchwały wspólnoty mieszkaniowej; 
- 10) przyjęcie w poczet członków spółdzielni mieszkaniowej; 
- 11) opróżnienie lokalu mieszkalnego lub lokalu o innym przeznaczeniu; 
- 12) ustalenie wstąpienia w stosunek najmu; 
- 13) uchylenie uchwały organu fundacji rodzinnej; 
- 14) stwierdzenie nieważności uchwały organu fundacji rodzinnej. 
Art. 27a. Opłatę stałą w kwocie 500 zł pobiera się od pozwu w sprawie wydania 
orzeczenia zastępującego uchwałę walnego zgromadzenia spółdzielni o podziale. 
Art. 27b. Opłatę stałą w kwocie 100 zł pobiera się od pozwu w sprawie 
rozpoznawanej w europejskim postępowaniu w sprawie drobnych roszczeń.
***
## Art. 28. {#art-28}

(uchylony) 
Art. 28a. Opłatę stałą w kwocie 1000 złotych pobiera się od pozwu w sprawie 
o naruszenie prawa do znaku towarowego lub wzoru przemysłowego, obejmującego 
żądanie unieważnienia lub stwierdzenia wygaśnięcia prawa ochronnego na znak 
towarowy, wspólnego prawa ochronnego na znak towarowy, unieważnienia prawa z 
rejestracji wzoru przemysłowego, unieważnienia lub stwierdzenia wygaśnięcia prawa 
ochronnego na wspólny znak towarowy, prawa ochronnego na znak towarowy 
gwarancyjny, 
uznania 
na 
terytorium 
Rzeczypospolitej 
Polskiej 
ochrony 
międzynarodowego znaku towarowego, oraz unieważnienia uznania na terytorium 
Rzeczypospolitej Polskiej ochrony międzynarodowego wzoru przemysłowego. 
Rozdział 2 
Sprawy gospodarcze
***
## Art. 29. {#art-29}

Opłatę stałą w kwocie 5000 złotych pobiera się od pozwu w sprawie o: 
- 1) 
rozwiązanie spółki; 
- 2) 
wyłączenie wspólnika ze spółki; 
- 3) 
uchylenie uchwały wspólników lub uchwały walnego zgromadzenia spółki; 
- 4) 
stwierdzenie nieważności uchwały wspólników lub uchwały walnego 
zgromadzenia spółki; 
- 5) 
ustalenie istnienia lub nieistnienia uchwały organu spółki; 
- 6) 
uchylenie uchwały zgromadzenia obligatariuszy; 

©Kancelaria Sejmu 
 
 
 
 
s. 14/46 
2025-09-24 
- 7) 
stwierdzenie nieważności uchwały zgromadzenia obligatariuszy.
***
## Art. 30. {#art-30}

Opłatę stałą w kwocie 100 złotych pobiera się od pozwu w sprawie 
z zakresu ochrony środowiska.
***
## Art. 31. {#art-31}

Opłatę stałą w kwocie 1500 złotych pobiera się od pozwu: 
- 1) 
w sprawie z umowy o przekazanie mienia w ramach prywatyzacji; 
- 2) 
w sprawie o unieważnienie przetargu.
***
## Art. 32. {#art-32}

1. Opłatę stałą w kwocie 1000 złotych pobiera się od odwołania od 
decyzji Prezesa Urzędu Ochrony Konkurencji i Konsumentów, Prezesa Urzędu 
Regulacji Energetyki, Prezesa Urzędu Komunikacji Elektronicznej oraz Prezesa 
Urzędu Transportu Kolejowego, a także od apelacji, skargi kasacyjnej i skargi 
o stwierdzenie niezgodności z prawem prawomocnego orzeczenia w takiej sprawie. 
2. Opłatę stałą w kwocie 500 złotych pobiera się od zażalenia na postanowienie 
Prezesa Urzędu Ochrony Konkurencji i Konsumentów, Prezesa Urzędu Regulacji 
Energetyki, Prezesa Urzędu Komunikacji Elektronicznej oraz Prezesa Urzędu 
Transportu Kolejowego. 
3. (uchylony) 
4. (uchylony) 
Art. 32a. 1. Opłatę stałą w kwocie 100 złotych pobiera się od odwołania od 
decyzji organu regulacyjnego, o którym mowa w ustawie z dnia 7 czerwca 2001 r. 
o zbiorowym zaopatrzeniu w wodę i zbiorowym odprowadzaniu ścieków, a także od 
apelacji, skargi kasacyjnej i skargi o stwierdzenie niezgodności z prawem 
prawomocnego orzeczenia w takiej sprawie. 
2. Opłatę stałą w kwocie 50 złotych pobiera się od zażalenia na postanowienie 
organu regulacyjnego, o którym mowa w ustawie z dnia 7 czerwca 2001 r. 
o zbiorowym zaopatrzeniu w wodę i zbiorowym odprowadzaniu ścieków.
***
## Art. 33. {#art-33}

Opłatę stałą w kwocie 3000 złotych pobiera się od odwołania od decyzji 
Przewodniczącego Krajowej Rady Radiofonii i Telewizji, a także od apelacji, skargi 
kasacyjnej i skargi o stwierdzenie niezgodności z prawem prawomocnego orzeczenia 
w takiej sprawie.
***
## Art. 34. {#art-34}

1. Od skargi na orzeczenie Krajowej Izby Odwoławczej przy Prezesie 
Urzędu Zamówień Publicznych pobiera się opłatę stałą w wysokości trzykrotności 
wpisu wniesionego od odwołania w sprawie, której dotyczy skarga. 

©Kancelaria Sejmu 
 
 
 
 
s. 15/46 
2025-09-24 
2. (utracił moc)2) 
Art. 34a. 1. Opłatę stałą w kwocie 100 złotych od każdej osoby, której wniosek 
dotyczy, pobiera się od wniosku o wezwanie na rozprawę świadka, biegłego lub 
strony, jeżeli wniosek został złożony po zatwierdzeniu planu rozprawy. 
2. W przypadku konieczności zarządzenia przymusowego sprowadzenia 
świadka pobiera się dodatkowo opłatę w kwocie 200 złotych. 
Rozdział 3 
Sprawy z zakresu prawa pracy i ubezpieczeń społecznych
***
## Art. 35. {#art-35}

1. W sprawach z zakresu prawa pracy od pracodawcy pobiera się opłatę 
podstawową wyłącznie od apelacji, zażalenia, skargi kasacyjnej i skargi 
o stwierdzenie niezgodności z prawem prawomocnego orzeczenia. Jednakże 
w sprawach, w których wartość przedmiotu sporu przewyższa kwotę 50 000 złotych, 
od wartości przedmiotu sporu ponad tę kwotę, od pracownika i pracodawcy pobiera 
się opłatę od apelacji, na zasadach przewidzianych w art. 13. 
1a. (uchylony) 
2. Pracodawca uiszcza opłatę podstawową od pism podlegających opłacie 
wymienionych w ust. 1, także w sprawie o ustalenie istnienia stosunku pracy 
wytoczonej z powództwa inspektora pracy.
***
## Art. 36. {#art-36}

1. W sprawach z zakresu ubezpieczeń społecznych i w sprawach 
odwołań rozpoznawanych przez sąd pracy i ubezpieczeń społecznych pobiera się 
opłatę podstawową wyłącznie od apelacji, zażalenia, skargi kasacyjnej i skargi 
o stwierdzenie niezgodności z prawem prawomocnego orzeczenia. 
2. Przepisu ust. 1 nie stosuje się do strony wnoszącej odwołanie do sądu pracy 
i ubezpieczeń społecznych. 
DZIAŁ 4 
Wysokość opłat w postępowaniu nieprocesowym 
Rozdział 1 
Sprawy z zakresu prawa rodzinnego i opiekuńczego
***
## Art. 37. {#art-37}

Opłatę stałą w kwocie 100 złotych pobiera się od wniosku o: 
- 1) 
zezwolenie na zawarcie związku małżeńskiego; 
- 2) Z dniem 28 kwietnia 2014 r. na podstawie wyroku Trybunału Konstytucyjnego z dnia 15 kwietnia 2014 r. 
sygn. akt SK 12/13 (Dz. U. poz. 545). 

©Kancelaria Sejmu 
 
 
 
 
s. 16/46 
2025-09-24 
- 2) 
zmianę wyroku orzekającego rozwód lub separację w części dotyczącej władzy 
rodzicielskiej; 
- 3) 
separację na zgodne żądanie małżonków; 
- 4) 
zniesienie separacji; 
- 5) 
zezwolenie na udzielenie pełnomocnictwa do oświadczenia o wstąpieniu 
w związek małżeński; 
- 6) 
zwolnienie od obowiązku złożenia lub przedstawienia kierownikowi urzędu 
stanu cywilnego dokumentu potrzebnego do zawarcia związku małżeńskiego.
***
## Art. 38. {#art-38}

1. Opłatę stałą w kwocie 1000 złotych pobiera się od wniosku o podział 
majątku wspólnego po ustaniu małżeńskiej wspólności majątkowej. 
2. Jeżeli wniosek zawiera zgodny projekt podziału tego majątku, pobiera się 
opłatę stałą w kwocie 300 złotych. 
Rozdział 2 
Sprawy z zakresu prawa rzeczowego
***
## Art. 39. {#art-39}

1. Opłatę stałą w kwocie 200 złotych pobiera się od wniosku o: 
- 1) 
ustanowienie drogi koniecznej; 
- 2) 
rozgraniczenie nieruchomości; 
- 3) 
stwierdzenie nabycia służebności gruntowej przez zasiedzenie. 
2. Opłatę w kwocie 100 złotych pobiera się od wniosku o: 
- 1) 
ustalenie sposobu korzystania z rzeczy wspólnej; 
- 2) 
ustanowienie zarządcy rzeczy wspólnej lub przedmiotu użytkowania; 
- 3) 
rozstrzygnięcie co do dokonania czynności dotyczącej rzeczy wspólnej.
***
## Art. 40. {#art-40}

Opłatę stałą w kwocie 2000 złotych pobiera się od wniosku 
o stwierdzenie nabycia własności nieruchomości przez zasiedzenie.
***
## Art. 41. {#art-41}

1. Opłatę stałą w kwocie 1000 złotych pobiera się od wniosku 
o zniesienie współwłasności. 
2. Jeżeli wniosek zawiera zgodny projekt zniesienia współwłasności, pobiera się 
opłatę stałą w kwocie 300 złotych. 

©Kancelaria Sejmu 
 
 
 
 
s. 17/46 
2025-09-24 
Rozdział 3 
Sprawy z zakresu prawa o księgach wieczystych
***
## Art. 42. {#art-42}

1. Opłatę stałą w kwocie 200 złotych pobiera się od wniosku o wpis 
w księdze wieczystej własności, użytkowania wieczystego lub ograniczonego prawa 
rzeczowego, chyba że przepis szczególny stanowi inaczej. 
2. Jeżeli wniosek dotyczy wpisu udziału w prawie, pobiera się część opłaty stałej 
proporcjonalną do wysokości udziału, nie mniej jednak niż 100 złotych. 
3. Od wniosku o wpis w księdze wieczystej własności, użytkowania wieczystego 
lub spółdzielczego własnościowego prawa do lokalu na podstawie dziedziczenia, 
zapisu lub działu spadku albo zniesienia współwłasności pobiera się jedną opłatę stałą 
w wysokości 150 złotych niezależnie od liczby udziałów w tych prawach.
***
## Art. 43. {#art-43}

Opłatę stałą w kwocie 150 złotych pobiera się od wniosku o wpis: 
- 1) 
własności, użytkowania wieczystego, spółdzielczego własnościowego prawa do 
lokalu nabytego w wyniku podziału majątku wspólnego po ustaniu wspólności 
majątkowej między małżonkami; 
- 2) 
własności nieruchomości rolnej o powierzchni do 5 ha; 
- 3) 
praw osobistych i roszczeń; 
- 4) 
zmiany treści ograniczonych praw rzeczowych. 
Art. 43a. 1. Opłatę stałą w kwocie 40 zł pobiera się od wniosku o wpis 
służebności przesyłu na rzecz przedsiębiorcy telekomunikacyjnego. 
2. Opłatę stałą w kwocie 30 zł pobiera się od wniosku o wpis, o którym mowa w 
art. 30 ust. 5a ustawy z dnia 7 maja 2010 r. o wspieraniu rozwoju usług i sieci 
telekomunikacyjnych (Dz. U. z 2025 r. poz. 311 i 1019), oraz wniosku o wpis, 
o którym mowa w art. 33 ust. 3a tej ustawy.
***
## Art. 44. {#art-44}

1. Opłatę stałą w kwocie 100 złotych pobiera się od wniosku o: 
- 1) 
założenie księgi wieczystej; 
- 2) 
połączenie nieruchomości w jednej księdze wieczystej, która jest już 
prowadzona, niezależnie od liczby łączonych nieruchomości; 
- 3) 
odłączenie nieruchomości lub jej części; 
- 4) 
sprostowanie działu I–O; 
- 5) 
wpis ostrzeżenia o niezgodności stanu prawnego ujawnionego w księdze 
wieczystej z rzeczywistym stanem prawnym; 
- 6) 
dokonanie innych wpisów, poza określonymi w art. 42 i 43. 

©Kancelaria Sejmu 
 
 
 
 
s. 18/46 
2025-09-24 
2. Jeżeli założenie księgi wieczystej następuje w związku z odłączeniem 
nieruchomości lub jej części z istniejącej księgi wieczystej, pobiera się tylko jedną 
opłatę stałą określoną w ust. 1.
***
## Art. 45. {#art-45}

1. Opłatę stałą określoną w art. 44 ust. 1 pkt 1–3 pobiera się niezależnie 
od opłaty za dokonanie wpisu własności, użytkowania wieczystego lub spółdzielczego 
własnościowego prawa do lokalu. 
2. Opłatę stałą określoną w art. 42 i 43 pobiera się odrębnie od wniosku o wpis 
każdego prawa, choćby wpis dwu lub więcej praw miał być dokonany na tej samej 
podstawie prawnej. 
3. Od wniosku o wpis hipoteki łącznej lub służebności pobiera się jedną opłatę 
stałą, choćby wniosek ten obejmował więcej niż jedną księgę wieczystą.
***
## Art. 46. {#art-46}

Od wniosku o wykreślenie wpisu pobiera się połowę opłaty należnej od 
wniosku o wpis.
***
## Art. 47. {#art-47}

Wydatki związane z drukiem księgi wieczystej i teczki akt tej księgi nie 
obciążają stron.
***
## Art. 48. {#art-48}

Od wniosku o złożenie do zbioru dokumentów pobiera się opłatę stałą, 
przewidzianą dla wniosku o wpis do księgi wieczystej. 
Rozdział 4 
Sprawy z zakresu prawa spadkowego
***
## Art. 49. {#art-49}

1. Opłatę stałą w kwocie 100 złotych pobiera się od wniosku o: 
- 1) 
stwierdzenie nabycia spadku; 
- 2) 
zabezpieczenie spadku; 
- 3) 
sporządzenie spisu inwentarza; 
- 4) 
odebranie oświadczenia o przyjęciu lub odrzuceniu spadku. 
2. Jeżeli wnioski, o których mowa w ust. 1, są umieszczone w jednym piśmie lub 
we wniosku o dział spadku, opłatę pobiera się od każdego z nich odrębnie.
***
## Art. 50. {#art-50}

Opłatę stałą w kwocie 100 złotych pobiera się od: 
- 1) 
apelacji, skargi kasacyjnej i skargi o stwierdzenie niezgodności z prawem 
prawomocnego orzeczenia w sprawie o stwierdzenie nabycia spadku; 
- 2) 
wniosku o zabezpieczenie spadku po cudzoziemcu; 
- 3) 
wniosku o wydanie właściwemu konsulowi spadku po cudzoziemcu. 

©Kancelaria Sejmu 
 
 
 
 
s. 19/46 
2025-09-24
***
## Art. 51. {#art-51}

1. Opłatę stałą w kwocie 500 złotych pobiera się od wniosku o dział 
spadku, a jeżeli zawiera on zgodny projekt działu spadku, pobiera się opłatę stałą 
w kwocie 300 złotych. 
2. Opłatę stałą w kwocie 1000 złotych pobiera się od wniosku o dział spadku 
połączony ze zniesieniem współwłasności, a jeżeli zawiera on zgodny projekt działu 
spadku i zniesienia współwłasności, pobiera się opłatę stałą w kwocie 600 złotych. 
Rozdział 5 
Sprawy z zakresu działania Krajowego Rejestru Sądowego
***
## Art. 52. {#art-52}

1. Opłatę stałą w kwocie 500 złotych pobiera się od wniosku 
o zarejestrowanie podmiotu w rejestrze przedsiębiorców w Krajowym Rejestrze 
Sądowym, chyba że przepis szczególny stanowi inaczej. 
2. Opłatę stałą w kwocie 250 złotych pobiera się od wniosku o zarejestrowanie 
w rejestrze przedsiębiorców w Krajowym Rejestrze Sądowym spółki jawnej, spółki 
komandytowej, spółki z ograniczoną odpowiedzialnością oraz prostej spółki akcyjnej, 
których umowy zostały zawarte przy wykorzystaniu wzorców umowy udostępnionych 
w systemie teleinformatycznym.
***
## Art. 53. {#art-53}

1. Opłatę stałą w kwocie 250 złotych pobiera się od wniosku 
o zarejestrowanie w Krajowym Rejestrze Sądowym w rejestrze stowarzyszeń, innych 
organizacji społecznych i zawodowych, fundacji oraz publicznych zakładów opieki 
zdrowotnej. 
2. Opłatę stałą w kwocie 500 złotych pobiera się od wniosku, o którym mowa 
w ust. 1, jeżeli dotyczy on jednocześnie wpisu do rejestru przedsiębiorców.
***
## Art. 54. {#art-54}

Opłatę stałą w kwocie 300 złotych pobiera się od wniosku o: 
- 1) 
(uchylony) 
- 2) 
wykreślenie podmiotu z rejestru przedsiębiorców lub z rejestru stowarzyszeń, 
innych organizacji społecznych i zawodowych, fundacji oraz publicznych 
zakładów opieki zdrowotnej połączone z wykreśleniem z Krajowego Rejestru 
Sądowego.
***
## Art. 55. {#art-55}

1. Opłatę stałą w kwocie 250 złotych pobiera się od wniosku 
o dokonanie zmiany wpisu dotyczącego podmiotu wpisanego do rejestru 
przedsiębiorców. 
2. Opłatę stałą w kwocie 200 złotych pobiera się od wniosku o zarejestrowanie 
w rejestrze przedsiębiorców w Krajowym Rejestrze Sądowym zmiany dotyczącej 

©Kancelaria Sejmu 
 
 
 
 
s. 20/46 
2025-09-24 
spółki jawnej, spółki komandytowej oraz spółki z ograniczoną odpowiedzialnością 
dokonanej przy wykorzystaniu wzorca uchwały udostępnionego w systemie 
teleinformatycznym.
***
## Art. 56. {#art-56}

Opłatę stałą w kwocie 150 złotych pobiera się od wniosku o: 
- 1) 
dokonanie zmiany wpisu dotyczącego podmiotu wpisanego tylko w rejestrze 
stowarzyszeń, innych organizacji społecznych i zawodowych, fundacji oraz 
publicznych 
zakładów 
opieki 
zdrowotnej, 
niewpisanego 
do 
rejestru 
przedsiębiorców; 
- 2) 
wykreślenie z rejestru przedsiębiorców – bez wykreślenia z Krajowego Rejestru 
Sądowego; 
- 3) 
wykreślenie z rejestru dłużników niewypłacalnych.
***
## Art. 57. {#art-57}

W wypadku 
jednoczesnego 
wniesienia 
przez 
tego 
samego 
wnioskodawcę, na kilku formularzach, kilku wniosków o wpis lub o dokonanie zmian 
w Krajowym Rejestrze Sądowym – pobiera się tylko jedną opłatę, z tym że jeżeli 
przepis przewiduje dla danego rodzaju spraw opłaty w różnych wysokościach – 
pobiera się opłatę wyższą.
***
## Art. 58. {#art-58}

Jedną opłatę stałą w kwocie 100 złotych pobiera się od skargi na 
orzeczenie referendarza sądowego, chociażby dotyczyło kilku wpisów w rejestrze 
przedsiębiorców lub rejestrze stowarzyszeń, innych organizacji społecznych i 
zawodowych, fundacji oraz publicznych zakładów opieki zdrowotnej.
***
## Art. 59. {#art-59}

Opłatę stałą w kwocie 300 złotych pobiera się od innych wniosków niż 
wymienione w art. 52–58, jeżeli należą do właściwości sądu dokonującego wpisów 
w Krajowym Rejestrze Sądowym.
***
## Art. 60. {#art-60}

Opłatę stałą w kwocie 200 złotych pobiera się od wniosku o wpis 
zastawu rejestrowego do rejestru zastawów.
***
## Art. 61. {#art-61}

Opłatę stałą w kwocie 100 złotych pobiera się od wniosku o zmianę 
wpisu w rejestrze zastawów.
***
## Art. 62. {#art-62}

Opłatę stałą w kwocie 100 złotych pobiera się od wniosku 
o wykreślenie zastawu rejestrowego z rejestru zastawów.
***
## Art. 63. {#art-63}

Opłatę stałą w kwocie 40 złotych pobiera się od wniosku o przyjęcie 
dokumentów, o których sąd czyni wzmiankę w rejestrze, oraz dokumentów 
zawierających dane niepodlegające według przepisów ustawy wpisowi do okreś-
lonego działu Krajowego Rejestru Sądowego. 

©Kancelaria Sejmu 
 
 
 
 
s. 21/46 
2025-09-24
***
## Art. 64. {#art-64}

Opłatę stałą w kwocie 100 złotych pobiera się od wniosku 
o uwierzytelnienie odpisu statutu w postępowaniu rejestrowym. 
Rozdział 5a 
Sprawy z zakresu rejestru fundacji rodzinnych 
Art. 64a. Opłatę stałą w kwocie 500 złotych pobiera się od zgłoszenia fundacji 
rodzinnej do rejestru fundacji rodzinnych. 
Art. 64b. 1. Opłatę stałą w kwocie 250 złotych pobiera się od wniosku o wpis 
w rejestrze fundacji rodzinnych. 
2. Jedną opłatę stałą w kwocie 100 złotych pobiera się od skargi na orzeczenie 
referendarza sądowego, chociażby dotyczyło kilku wpisów w rejestrze fundacji 
rodzinnych. 
Rozdział 6 
Inne sprawy rozpoznawane w postępowaniu nieprocesowym
***
## Art. 65. {#art-65}

Opłatę stałą w kwocie 300 złotych pobiera się od wniosku w sprawie 
między organami przedsiębiorstwa państwowego i między przedsiębiorstwem 
państwowym lub jego organami a jego organem założycielskim albo organem 
sprawującym nadzór.
***
## Art. 66. {#art-66}

Opłatę stałą w kwocie 200 złotych pobiera się od wniosku o umorzenie 
utraconego dokumentu.
***
## Art. 67. {#art-67}

Opłatę stałą w kwocie 100 złotych pobiera się od wniosku o: 
- 1) 
złożenie przedmiotu świadczenia do depozytu sądowego; 
- 2) 
wydanie z depozytu przedmiotu świadczenia. 
Art. 67a. (uchylony) 
Art. 67b. 1. Opłatę stałą w kwocie 300 zł pobiera się od wniosku o: 
- 1) 
odwołanie zarządcy sukcesyjnego; 
- 2) 
przedłużenie okresu zarządu sukcesyjnego. 
2. Jeżeli wnioski, o których mowa w ust. 1, umieszczone są w jednym piśmie lub 
wraz z innym wnioskiem, opłatę pobiera się od każdego z nich odrębnie. 
DZIAŁ 5 
Wysokość opłat w postępowaniu zabezpieczającym
***
## Art. 68. {#art-68}

Opłatę stałą w kwocie 100 złotych pobiera się od wniosku o: 

©Kancelaria Sejmu 
 
 
 
 
s. 22/46 
2025-09-24 
- 1) 
udzielenie, zmianę lub uchylenie zabezpieczenia roszczenia; 
- 2) 
wydanie, zmianę, uchylenie, stwierdzenie wygaśnięcia, zmianę wykonania, 
ograniczenie wykonania lub zakończenie wykonania europejskiego nakazu 
zabezpieczenia na rachunku bankowym; 
- 3) 
uzyskanie informacji o rachunku bankowym, o którym mowa w rozporządzeniu 
Parlamentu Europejskiego i Rady (UE) nr 655/2014 z dnia 15 maja 2014 r. 
ustanawiającym procedurę europejskiego nakazu zabezpieczenia na rachunku 
bankowym w celu ułatwienia transgranicznego dochodzenia wierzytelności w 
sprawach cywilnych i handlowych (Dz. Urz. UE L 189 z 27.06.2014, str. 59).
***
## Art. 69. {#art-69}

1. Od wniosku o udzielenie zabezpieczenia roszczenia pieniężnego 
złożonego przed wniesieniem pisma wszczynającego postępowanie pobiera się 
czwartą część opłaty należnej od pozwu o to roszczenie. 
2. Uiszczoną opłatę zalicza się na poczet opłaty od pisma wszczynającego 
postępowanie, jeżeli zostało wniesione w terminie przewidzianym do tego 
w przepisach o zabezpieczeniu. W przypadku oddalenia wniosku termin ten wynosi 
dwa tygodnie od dnia doręczenia postanowienia, a jeżeli postanowienie zostało 
wydane na posiedzeniu jawnym – od dnia jego ogłoszenia. 
DZIAŁ 6 
Wysokość opłat w postępowaniu egzekucyjnym
***
## Art. 70. {#art-70}

Opłatę stałą w kwocie 200 złotych pobiera sąd od wniosku o: 
- 1) 
wezwanie dłużnika do wykonania egzekwowanej czynności w wyznaczonym 
terminie oraz umocowanie wierzyciela do wykonania tej czynności na koszt 
dłużnika, w razie bezskutecznego upływu wyznaczonego terminu; 
- 2) 
ukaranie grzywną dłużnika niewykonującego obowiązku zaniechania czynności 
lub nieprzeszkadzania czynnościom wierzyciela; 
- 3) 
przeprowadzenie przez sąd egzekucji czynności, której inna osoba nie może za 
dłużnika wykonać; 
- 4) 
(uchylony) 
- 5) 
nakazanie dłużnikowi wyjawienia majątku.
***
## Art. 71. {#art-71}

Opłatę stałą w kwocie 50 złotych pobiera sąd od wniosku o: 
- 1) 
nadanie klauzuli wykonalności tytułowi egzekucyjnemu, innemu niż orzeczenie 
sądu, ugoda sądowa, nakaz zapłaty albo ugoda zawarta przed mediatorem 
w wyniku prowadzenia mediacji na podstawie postanowienia sądu kierującego 
strony do mediacji; 

©Kancelaria Sejmu 
 
 
 
 
s. 23/46 
2025-09-24 
- 2) 
nadanie klauzuli wykonalności przeciwko małżonkowi dłużnika; 
- 3) 
nadanie klauzuli wykonalności przeciwko lub na rzecz osoby innej niż wskazana 
w tytule egzekucyjnym, na którą przeszły uprawnienie lub obowiązek po 
powstaniu tytułu lub w toku sprawy przed wydaniem tytułu; 
- 4) 
nadanie 
klauzuli 
wykonalności 
przeciwko 
wspólnikowi 
ponoszącemu 
odpowiedzialność bez ograniczenia całym swoim majątkiem za zobowiązania 
spółki; 
- 5) 
ustanowienie zarządcy nieruchomości lub innej rzeczy albo prawa, z których 
prowadzi się egzekucję według przepisów o egzekucji z nieruchomości; 
- 6) 
umorzenie książeczki oszczędnościowej w związku z zajęciem wkładu, na który 
ją wystawiono; 
- 7) 
(uchylony) 
- 8) 
wydanie zaświadczenia europejskiego tytułu egzekucyjnego; 
- 9) 
uchylenie zaświadczenia europejskiego tytułu egzekucyjnego; 
- 10) wydanie zaświadczenia o utracie lub ograniczeniu wykonalności tytułu 
egzekucyjnego 
opatrzonego 
zaświadczeniem 
europejskiego 
tytułu 
egzekucyjnego; 
- 11) ponowne wydanie tytułu wykonawczego zamiast utraconego.
***
## Art. 72. {#art-72}

1. Opłatę stałą w kwocie 50 złotych pobiera sąd od: 
- 1) 
zarzutów przeciwko planowi podziału sumy uzyskanej z egzekucji; 
- 2) 
zażalenia oraz skargi na orzeczenie referendarza sądowego w przedmiocie 
klauzuli wykonalności. 
2. Opłatę stałą w kwocie 150 złotych pobiera sąd od: 
- 1) 
wniosku o podział złożonej do depozytu sądowego sumy odszkodowania za 
wywłaszczoną nieruchomość i wypłatę odszkodowania; 
- 2) 
zażalenia oraz skargi na orzeczenie referendarza sądowego niewymienionych w 
ust. 1 pkt 2.
***
## Art. 73. {#art-73}

Opłatę stałą w kwocie 1000 złotych pobiera się od wniosku o: 
- 1) 
wszczęcie egzekucji przez zarząd przymusowy przedsiębiorstwa lub 
gospodarstwa rolnego; 
- 2) 
wszczęcie egzekucji przez sprzedaż przedsiębiorstwa lub gospodarstwa rolnego. 
DZIAŁ 7 
Wysokość opłat w postępowaniach upadłościowym i restrukturyzacyjnym
***
## Art. 74. {#art-74}

Opłatę stałą w kwocie 1000 złotych pobiera się od: 

©Kancelaria Sejmu 
 
 
 
 
s. 24/46 
2025-09-24 
- 1) 
wniosku o ogłoszenie upadłości; 
- 2) 
wniosku zarządcy zagranicznego w przedmiocie uznania zagranicznego 
postępowania upadłościowego; 
- 3) 
wniosku o zatwierdzenie układu po samodzielnym zbieraniu głosów albo 
otwarcie postępowania restrukturyzacyjnego.
***
## Art. 75. {#art-75}

Opłatę stałą w kwocie 200 złotych pobiera się od: 
- 1) 
(uchylony) 
- 2) 
wniosku o wszczęcie wtórnego postępowania upadłościowego; 
- 3) 
zażalenia na postanowienia wydane w postępowaniach upadłościowym 
i restrukturyzacyjnym; 
- 4) 
(uchylony) 
- 5) 
(uchylony) 
- 6) 
uproszczonego wniosku o otwarcie postępowania sanacyjnego; 
- 7) 
uproszczonego wniosku o ogłoszenie upadłości.
***
## Art. 76. {#art-76}

Opłatę stałą w kwocie 100 złotych pobiera się od: 
- 1) 
zarzutów przeciwko planowi podziału; 
- 2) 
wniosku o uchylenie lub zmianę układu; 
- 3) 
wniosku o uchylenie lub zmianę orzeczenia o uznaniu zagranicznego 
postępowania upadłościowego; 
- 4) 
wniosku w sprawie zakazu prowadzenia działalności gospodarczej; 
- 5) 
wniosku upadłego przedsiębiorcy będącego osobą fizyczną o ustalenie planu 
spłaty i umorzenie pozostałej części zobowiązań, które nie zostały zaspokojone 
w postępowaniu upadłościowym. 
Art. 76a. Opłatę podstawową pobiera się od: 
- 1) 
wniosku o ogłoszenie upadłości osoby fizycznej nieprowadzącej działalności 
gospodarczej; 
- 2) 
wniosku osoby fizycznej nieprowadzącej działalności gospodarczej o otwarcie 
postępowania o zawarcie układu na zgromadzeniu wierzycieli; 
- 3) 
skargi na czynności syndyka; 
- 4) 
skargi na odmowę dokonania obwieszczenia o ustaleniu dnia układowego przez 
nadzorcę układu. 
Art. 76b. Piątą część opłaty stosunkowej pobiera się od sprzeciwu oraz od 
zażalenia na postanowienie sędziego-komisarza wydane w wyniku rozpoznania 
sprzeciwu. 

©Kancelaria Sejmu 
 
 
 
 
s. 25/46 
2025-09-24 
DZIAŁ 8 
Opłaty kancelaryjne
***
## Art. 77. {#art-77}

1. Opłatę od wniosku o wydanie na podstawie akt: 
- 1) 
poświadczonego odpisu, wypisu lub wyciągu, 
- 2) 
odpisu orzeczenia ze stwierdzeniem prawomocności, 
- 3) 
odpisu orzeczenia ze stwierdzeniem wykonalności, 
- 4) 
zaświadczenia 
– pobiera się w kwocie 20 złotych za każde rozpoczęte 10 stron wydanego 
dokumentu. 
1a. Opłatę od wniosku o wydanie na podstawie akt zapisu dźwięku albo obrazu 
i dźwięku z przebiegu posiedzenia pobiera się w kwocie 20 złotych za każdy wydany 
informatyczny nośnik danych. 
2. (uchylony) 
3. Opłatę, o której mowa w ust. 1, pobiera się od wniosku o odpis księgi 
wieczystej, o ile przepis szczególny nie stanowi inaczej. 
Art. 77a. Nie pobiera się opłaty od pierwszego wniosku o wydanie na podstawie 
akt odpisu orzeczenia kończącego postępowanie z klauzulą wykonalności, złożonego 
przez stronę, która wszczęła postępowanie.
***
## Art. 78. {#art-78}

Opłatę od wniosku o wydanie kopii dokumentu, znajdującego się 
w aktach sprawy, pobiera się w kwocie 20 złotych za każde rozpoczęte 20 stron 
wydanej kopii. 
DZIAŁ 9 
Zwrot opłaty
***
## Art. 79. {#art-79}

1. Sąd z urzędu zwraca stronie: 
- 1) 
całą uiszczoną opłatę od: 
  - a) 
pisma zwróconego wskutek braków formalnych, 
  - b) 
pisma odrzuconego lub cofniętego, jeżeli odrzucenie lub cofnięcie nastąpiło 
przed wysłaniem odpisu pisma innym stronom, a w braku takich stron – 
przed wysłaniem zawiadomienia o terminie posiedzenia, 
  - c) 
zażalenia na postanowienie w przedmiocie ukarania grzywną albo aresztem, 
zamiany grzywny na areszt albo w przedmiocie przymusowego 
sprowadzenia, jeżeli zażalenie zostało uwzględnione w całości, 

©Kancelaria Sejmu 
 
 
 
 
s. 26/46 
2025-09-24 
  - d) 
zażalenia na postanowienie o przyznaniu wynagrodzenia biegłemu lub 
tłumaczowi, jeżeli zażalenie zostało uwzględnione w całości, 
  - e) 
apelacji, zażalenia, skargi kasacyjnej w razie uwzględnienia środka 
zaskarżenia z powodu oczywistego naruszenia prawa i stwierdzenia tego 
naruszenia przez sąd odwoławczy lub Sąd Najwyższy, 
  - f) 
skargi na orzeczenie referendarza sądowego, jeżeli została uwzględniona 
w sprawie, w której postępowanie wszczęto z urzędu, a w pozostałych 
sprawach tylko w razie uwzględnienia skargi z powodu oczywistego 
naruszenia prawa i stwierdzenia tego naruszenia przez sąd, 
  - g) 
skargi o stwierdzenie niezgodności z prawem prawomocnego orzeczenia 
w razie jej uwzględnienia, 
  - h) 
pisma wszczynającego postępowanie w pierwszej instancji oraz zarzutów 
od nakazu zapłaty, jeżeli postępowanie zakończyło się zawarciem ugody 
przed rozpoczęciem rozprawy przed sądem pierwszej instancji; 
- 2) 
trzy czwarte uiszczonej opłaty od: 
  - a) 
pisma wszczynającego postępowanie w pierwszej instancji oraz zarzutów 
od nakazu zapłaty, jeżeli w toku postępowania sądowego zawarto ugodę 
przed mediatorem po rozpoczęciu rozprawy, 
aa) pozwu w razie umorzenia postępowania na zgodny wniosek stron przed 
sądem pierwszej instancji, w następstwie zawarcia przez strony zapisu na 
sąd polubowny, 
<ab) apelacji, jeżeli w toku postępowania przed sądem drugiej instancji 
zawarto ugodę przed mediatorem,> 
  - b) 
skargi kasacyjnej lub skargi o stwierdzenie niezgodności z prawem 
prawomocnego orzeczenia nieprzyjętej do rozpoznania przez Sąd 
Najwyższy; 
  - c) 
(uchylona) 
  - d) 
(uchylona) 
  - e) 
wniosku o zawezwanie do próby ugodowej, jeżeli w postępowaniu z tego 
wniosku zawarto ugodę, chyba że sąd uznał ugodę za niedopuszczalną; 
- 3) 
połowę uiszczonej opłaty od: 
  - a) 
pisma cofniętego przed rozpoczęciem posiedzenia, na które sprawa została 
skierowana, 
Dodana lit. ab w 
pkt 2 w ust. 1 w 
art. 79 wejdzie  w 
życie 
z 
dn. 
1.03.2026 r. (Dz. 
U. z 2025 r. poz. 
- 1172). 

©Kancelaria Sejmu 
 
 
 
 
s. 27/46 
2025-09-24 
  - b) 
pozwu o rozwód lub separację w razie orzeczenia rozwodu lub separacji na 
zgodny wniosek stron bez orzekania o winie – po uprawomocnieniu się 
wyroku, z zastrzeżeniem art. 26 ust. 2, 
  - c) 
pisma wszczynającego postępowanie w pierwszej instancji oraz zarzutów 
od nakazu zapłaty, jeżeli postępowanie w pierwszej instancji zakończyło się 
zawarciem ugody sądowej po rozpoczęciu rozprawy, 
  - d) 
pisma wszczynającego postępowanie w drugiej instancji, w której sprawa 
zakończyła się zawarciem ugody sądowej. 
2. Poza wypadkami przewidzianymi w ust. 1 sąd z urzędu zwraca stronie całą 
uiszczoną opłatę od pozwu o rozwód lub separację albo wniosku o separację w razie 
cofnięcia pozwu lub wniosku na skutek pojednania się stron w pierwszej instancji. 
W razie pojednania się stron przed zakończeniem postępowania apelacyjnego, zwraca 
się połowę uiszczonej opłaty od apelacji. 
3. Opłatę zwracaną na podstawie ust. 1 pkt 1 lit. a, b i h, pkt 2 oraz pkt 3 lit. a, c 
i d obniża się o kwotę równą opłacie minimalnej. 
4. Opłata, o której mowa w art. 25b, zaliczona na poczet opłaty od środka 
zaskarżenia nie podlega zwrotowi, chyba że uwzględniono ten środek zaskarżenia 
z powodu oczywistego naruszenia prawa, a naruszenie to stwierdził sąd odwoławczy 
lub Sąd Najwyższy.
***
## Art. 80. {#art-80}

1. Sąd z urzędu zwraca stronie różnicę między opłatą pobraną od strony 
a opłatą należną. 
1a. Nie zwraca się różnicy, jeżeli jest niższa niż koszt jej zwrotu. 
2. (uchylony) 
Art. 80a. Zwrotów, o których mowa w art. 79 i art. 80, dokonuje sąd, przed 
którym sprawa toczyła się w pierwszej instancji, a sąd drugiej instancji – jeżeli opłatę 
pobrał. Jeżeli opłatę pobrał notariusz, zwrotu dokonuje sąd, który rozpoznawał 
wniosek w pierwszej instancji.
***
## Art. 81. {#art-81}

Roszczenie strony o zwrot opłaty sądowej przedawnia się z upływem 
trzech lat, licząc od dnia powstania tego roszczenia.
***
## Art. 82. {#art-82}

Zwrot opłat, o którym mowa w niniejszym rozdziale, może również 
zarządzić przewodniczący lub referendarz sądowy. 

©Kancelaria Sejmu 
 
 
 
 
s. 28/46 
2025-09-24 
TYTUŁ III 
Wydatki 
DZIAŁ 1 
Przepisy ogólne
***
## Art. 83. {#art-83}

1. 
Jeżeli 
przepisy 
ustawy 
przewidują 
obowiązek 
działania 
i dokonywania czynności połączonej z wydatkami z urzędu, sąd zarządzi wykonanie 
tej czynności, a kwotę potrzebną na ich pokrycie wykłada tymczasowo Skarb Państwa. 
Dotyczy to także dopuszczenia i przeprowadzenia przez sąd z urzędu dowodu 
niewskazanego przez stronę. 
2. W orzeczeniu kończącym postępowanie w sprawie sąd orzeka o poniesionych 
tymczasowo przez Skarb Państwa wydatkach, stosując odpowiednio przepisy art. 113.
***
## Art. 84. {#art-84}

1. Sąd z urzędu zwraca stronie wszelkie należności z tytułu wydatków, 
stanowiące różnicę między kosztami pobranymi od strony a kosztami należnymi. 
2. Przepisy art. 80–82 stosuje się odpowiednio do zwrotu zaliczki. 
3. Przepis art. 5 ust. 3 stosuje się odpowiednio. 
DZIAŁ 2 
Należności świadków, biegłych, tłumaczy i stron w postępowaniu cywilnym
***
## Art. 85. {#art-85}

1. Świadkowi przysługuje zwrot kosztów podróży – z miejsca jego 
zamieszkania do miejsca wykonywania czynności sądowej na wezwanie sądu – 
w wysokości rzeczywiście poniesionych, racjonalnych i celowych kosztów przejazdu 
własnym samochodem lub innym odpowiednim środkiem transportu. 
2. Górną granicę należności, o których mowa w ust. 1, stanowi wysokość 
kosztów 
przysługujących 
pracownikowi 
zatrudnionemu 
w państwowej 
lub 
samorządowej jednostce sfery budżetowej z tytułu podróży służbowej na obszarze 
kraju. 
3. Według tych samych zasad świadkowi przysługuje zwrot kosztów noclegu 
oraz utrzymania w miejscu wykonywania czynności sądowej. 
4. Wysokość kosztów, o których mowa w ust. 1 i 3, świadek powinien należycie 
wykazać.
***
## Art. 86. {#art-86}

1. Świadkowi przysługuje zwrot zarobku lub dochodu utraconego 
z powodu stawiennictwa na wezwanie sądu. 

©Kancelaria Sejmu 
 
 
 
 
s. 29/46 
2025-09-24 
2. Wynagrodzenie za utracony zarobek lub dochód za każdy dzień udziału 
w czynnościach sądowych przyznaje się świadkowi w wysokości jego przeciętnego 
dziennego zarobku lub dochodu. W przypadku świadka pozostającego w stosunku 
pracy przeciętny dzienny utracony zarobek oblicza się według zasad obowiązujących 
przy ustalaniu należnego pracownikowi ekwiwalentu pieniężnego za urlop. 
3. Górną granicę należności, o których mowa w ust. 2, stanowi równowartość 
4,6 % kwoty bazowej dla osób zajmujących kierownicze stanowiska państwowe, 
której wysokość, ustaloną według odrębnych zasad, określa ustawa budżetowa. 
W przypadku gdy ogłoszenie ustawy budżetowej nastąpi po dniu 1 stycznia roku, 
którego dotyczy ustawa budżetowa, podstawę obliczenia należności za okres od 
1 stycznia do dnia ogłoszenia ustawy budżetowej stanowi kwota bazowa w wysokości 
obowiązującej w grudniu roku poprzedniego. 
4. Utratę zarobku lub dochodu, o których mowa w ust. 1, oraz ich wysokość 
świadek powinien należycie wykazać.
***
## Art. 87. {#art-87}

1. Prawo do żądania należności przewidzianych w art. 85 i 86 służy 
osobie wezwanej w charakterze świadka, jeżeli się stawiła, choćby nie została 
przesłuchana. 
2. W wypadku gdy osoba uprawniona do otrzymania należności przewidzianych 
w art. 85 i 86 zostanie wezwana w charakterze świadka w kilku sprawach na ten sam 
dzień, przyznaje się jej te należności tylko raz. 
3. Świadkowi, który zgłosił się bez wezwania sądu, należności przewidziane 
w art. 85 i 86 mogą być przyznane tylko w wypadku, jeżeli został przesłuchany przez 
sąd.
***
## Art. 88. {#art-88}

Przepisy art. 85–87 stosuje się odpowiednio do osoby towarzyszącej 
świadkowi, jeżeli świadek nie mógł stawić się na wezwanie sądu bez opieki tej osoby. 
Art. 88a. Przepisów art. 85–87 nie stosuje się do świadka zatrudnionego 
w organie władzy publicznej, jeżeli powołany został do zeznawania w związku z tym 
zatrudnieniem. W tym przypadku świadkowi służy prawo do należności na zasadach 
określonych w przepisach regulujących wysokość i warunki ustalania należności 
przysługujących pracownikowi zatrudnionemu w państwowej lub samorządowej 
jednostce sfery budżetowej z tytułu podróży służbowej na obszarze kraju.
***
## Art. 89. {#art-89}

1. Biegłemu powołanemu przez sąd przysługuje wynagrodzenie za 
wykonaną pracę oraz zwrot poniesionych przez niego wydatków niezbędnych dla 
wydania opinii. 

©Kancelaria Sejmu 
 
 
 
 
s. 30/46 
2025-09-24 
2. Wysokość wynagrodzenia biegłego za wykonaną pracę ustala się, 
uwzględniając wymagane kwalifikacje, potrzebny do wydania opinii czas i nakład 
pracy, a wysokość wydatków, o których mowa w ust. 1 – na podstawie złożonego 
rachunku. 
3. Wynagrodzenie biegłych oblicza się według stawki wynagrodzenia za godzinę 
pracy albo według taryfy zryczałtowanej określonej dla poszczególnych kategorii 
biegłych ze względu na dziedzinę, w której są oni specjalistami. Podstawę obliczenia 
stawki wynagrodzenia za godzinę pracy i taryfy zryczałtowanej stanowi ułamek kwoty 
bazowej dla osób zajmujących kierownicze stanowiska państwowe, której wysokość 
określa ustawa budżetowa. 
4. Wynagrodzenie biegłego będącego podatnikiem obowiązanym do rozliczenia 
podatku od towarów i usług podwyższa się o kwotę podatku od towarów i usług, 
określoną zgodnie ze stawką tego podatku obowiązującą w dniu orzekania o tym 
wynagrodzeniu. 
4a. (uchylony) 
4b. (uchylony) 
5. Minister 
Sprawiedliwości 
określi, 
w drodze 
rozporządzenia, 
stawki 
wynagrodzenia biegłych za wykonaną pracę oraz taryfy zryczałtowane, o których 
mowa w ust. 3, mając na uwadze nakład pracy i kwalifikacje biegłego oraz poziom 
wynagrodzeń uzyskiwanych przez pracowników wykonujących podobne zawody, 
stopień złożoności problemu będącego przedmiotem opinii oraz warunki, w jakich 
opracowano opinię, a także sposób dokumentowania wydatków niezbędnych dla 
wydania opinii. 
Art. 89a. 1. Jeżeli można oszacować przewidywany nakład pracy biegłego przy 
sporządzeniu opinii i przewidywaną wysokość wydatków przewodniczący zlecając 
biegłemu sporządzenie opinii może oznaczyć wysokość wynagrodzenia lub zwrotu 
wydatków. 
2. W terminie tygodnia od dnia otrzymania zlecenia sporządzenia opinii biegły 
może zażądać wynagrodzenia lub zwrotu wydatków w innej wysokości. Jeżeli strony 
zgodzą się na żądanie biegłego i zostanie uiszczona odpowiednia zaliczka, 
przewodniczący zleci biegłemu sporządzenie opinii za wynagrodzeniem lub ze 
zwrotem wydatków żądanymi przez biegłego. Zgoda obu stron nie jest wymagana, 
jeżeli jedna z nich uiści w zakreślonym przez sąd terminie wymaganą zaliczkę, 
a łączna wysokość wynagrodzenia i zwrotu wydatków żądanych przez biegłego nie 
przekracza 5000 złotych. 

©Kancelaria Sejmu 
 
 
 
 
s. 31/46 
2025-09-24 
3. Przyznając biegłemu wynagrodzenie lub zwrot wydatków sąd jest związany 
wysokością, na którą strony wyraziły zgodę na podstawie ust. 2. 
4. W razie braku przesłanek do zlecenia biegłemu sporządzenia opinii na 
zasadach przewidzianych w ust. 2, sporządzenie opinii zleca się za wynagrodzeniem 
lub zwrotem wydatków ustalonymi zgodnie z art. 89. 
Art. 89b. 1. Jeżeli okoliczności sprawy uzasadniają przewidywanie, że 
w przypadku ustalenia wynagrodzenia lub zwrotu wydatków biegłego zgodnie 
z art. 89 wystąpią trudności ze sprawnym przeprowadzeniem dowodu z opinii 
biegłego, a nie ma podstaw do oznaczenia wysokości wynagrodzenia lub zwrotu 
wydatków biegłego zgodnie z art. 89a, stosuje się przepisy ust. 2–4. 
2. Zlecając biegłemu sporządzenie opinii, przewodniczący może zakreślić 
biegłemu termin do zgłoszenia żądania ustalenia wynagrodzenia lub zwrotu wydatków 
w określonej kwocie. Jeżeli strony zgodzą się na żądanie biegłego i zostanie uiszczona 
odpowiednia zaliczka, przewodniczący zleci biegłemu sporządzenie opinii za 
wynagrodzeniem lub ze zwrotem wydatków żądanymi przez biegłego. Zgoda obu 
stron nie jest wymagana, jeżeli jedna z nich uiści w zakreślonym przez sąd terminie 
wymaganą zaliczkę, a łączna wysokość wynagrodzenia i zwrotu wydatków biegłego 
nie przekracza 5000 złotych. Przepis art. 89a ust. 4 stosuje się odpowiednio. 
3. Termin, o którym mowa w ust. 2, przewodniczący ustala stosownie do 
obszerności materiału sprawy i stopnia jej zawiłości. Termin ten nie może być krótszy 
niż tydzień ani dłuższy niż miesiąc od dnia otrzymania zlecenia. 
4. Przyznając biegłemu wynagrodzenie lub zwrot wydatków sąd jest związany 
wysokością, na którą strony wyraziły zgodę na podstawie ust. 2. 
Art. 89c. 1. Jeżeli opinia jest nierzetelna lub została sporządzona lub złożona ze 
znacznym nieusprawiedliwionym opóźnieniem, wynagrodzenie lub zwrot wydatków 
ulega odpowiedniemu obniżeniu; w szczególnie rażących przypadkach sąd może 
odmówić przyznania wynagrodzenia lub zwrotu wydatków. 
2. Jeżeli opinia zawiera rażące błędy albo nie odpowiada treści zlecenia, 
wynagrodzenie ani zwrot wydatków nie przysługują. 
Art. 89d. 1. Tłumaczowi powołanemu przez sąd przysługuje wynagrodzenie za 
wykonaną pracę oraz zwrot poniesionych przez niego wydatków niezbędnych do 
wykonania tłumaczenia. 
2. Wysokość wynagrodzenia i zwrotu wydatków tłumacza ustala się stosując 
odpowiednio przepisy o wynagrodzeniu i zwrocie wydatków biegłego. 

©Kancelaria Sejmu 
 
 
 
 
s. 32/46 
2025-09-24 
3. Wysokość wynagrodzenia tłumacza przysięgłego ustala się według przepisów 
ustawy z dnia 25 listopada 2004 r. o zawodzie tłumacza przysięgłego (Dz. U. z 2019 r. 
poz. 1326).
***
## Art. 90. {#art-90}

Do biegłego i tłumacza powołanych przez sąd stosuje się odpowiednio 
art. 85. Dotyczy to również sytuacji, gdy sąd nie skorzystał z usług takiego biegłego 
lub tłumacza. 
Art. 90a. 1. Biegłemu lub tłumaczowi wezwanemu przez sąd, w razie 
nieskorzystania z jego usług, przysługuje zwrot utraconego zarobku lub dochodu. 
2. Wynagrodzenie za utracony zarobek lub dochód przyznaje się biegłemu lub 
tłumaczowi, uwzględniając ich kwalifikacje i czas zużyty w związku z wezwaniem. 
Przepisy art. 86 ust. 3 i 4 stosuje się odpowiednio. 
Art. 90b. W razie wezwania biegłego lub tłumacza do sądu w kilku sprawach na 
ten sam dzień, zwrot kosztów podróży, noclegu, utrzymania w miejscu wykonywania 
czynności sądowej, utraconego zarobku lub dochodu z powodu stawiennictwa na 
wezwanie sądu, przysługuje im tylko raz.
***
## Art. 91. {#art-91}

W wypadku gdy obowiązujące przepisy przewidują przyznanie stronie 
należności w związku z jej udziałem w postępowaniu sądowym, należności te 
przyznaje się stronie w wysokości przewidzianej dla świadków. 
Art. 91a. 1. Kuratorowi ustanowionemu dla strony w danej sprawie przysługuje 
wynagrodzenie oraz zwrot poniesionych przez niego wydatków niezbędnych do 
dokonania czynności. Przepis art. 85 stosuje się odpowiednio. 
2. Wynagrodzenie kuratora będącego podatnikiem obowiązanym do rozliczenia 
podatku od towarów i usług podwyższa się o kwotę podatku od towarów i usług, 
określoną zgodnie ze stawką tego podatku obowiązującą w dniu orzekania o tym 
wynagrodzeniu.
***
## Art. 92. {#art-92}

1. Wynagrodzenie oraz zwrot kosztów podróży, wydatków, utraconego 
zarobku lub dochodu przyznaje się na wniosek świadka, osoby towarzyszącej 
świadkowi, o której mowa w art. 88, biegłego, kuratora ustanowionego dla strony 
w danej sprawie lub tłumacza, a także strony lub osoby trzeciej uprawnionej do 
otrzymania należności. 
2. Wniosek o przyznanie należności, o których mowa w ust. 1, składa się ustnie 
do protokołu lub na piśmie, w terminie 3 dni od dnia zakończenia czynności 

©Kancelaria Sejmu 
 
 
 
 
s. 33/46 
2025-09-24 
z udziałem osoby uprawnionej do tych należności, a w przypadku osoby, o której 
mowa w art. 88 – z udziałem świadka, któremu ona towarzyszyła. 
3. Roszczenie o zwrot należności, o których mowa w ust. 1, przedawnia się 
z upływem lat trzech, licząc od dnia powstania tego roszczenia. 
4. Osobę uprawnioną do otrzymania należności, o której mowa w ust. 1, poucza 
się o prawie i sposobie złożenia wniosku o jej przyznanie oraz skutkach 
niezachowania terminu wskazanego w ust. 2.
***
## Art. 93. {#art-93}

1. Należności, o których mowa w art. 92, ustala i przyznaje sąd albo 
referendarz sądowy. 
1a. Przewodniczący może zarządzeniem w całości uwzględnić wniosek świadka 
o przyznanie każdej z należności, o których mowa w art. 85 i art. 86, jeżeli jego 
uwzględnienie nie pociągnie za sobą zobowiązania strony do uiszczenia dalszych kwot 
albo strona zgodziła się na pokrycie należności świadka w żądanej przez niego 
wysokości. Zarządzenie to nie podlega zaskarżeniu. 
2. Przyznaną 
należność 
należy 
wypłacić 
niezwłocznie. 
W przypadku 
niemożności niezwłocznej wypłaty należność przekazuje się przekazem pocztowym 
lub przelewem bankowym bez obciążania osoby, której ją przyznano, opłatą pocztową 
lub kosztami przelewu. 
Art. 93a. Przepisy art. 92 oraz art. 93 ust. 1 i 2 stosuje się odpowiednio do 
przyznawania należności mediatorowi w przypadku, o którym mowa w art. 1835 § 3 
ustawy z dnia 17 listopada 1964 r. – Kodeks postępowania cywilnego. 
TYTUŁ IV 
Zwolnienie od kosztów sądowych
***
## Art. 94. {#art-94}

Skarb Państwa nie ma obowiązku uiszczania opłat.
***
## Art. 95. {#art-95}

1. Nie pobiera się opłat od wniosku: 
- 1) 
o 
udzielenie 
zabezpieczenia, 
zgłoszonego 
w piśmie 
rozpoczynającym 
postępowanie; 
- 2) 
o przyjęcie oświadczenia o uznaniu dziecka, o nadanie dziecku nazwiska, 
o przysposobienie dziecka, o odebranie osoby podlegającej władzy rodzicielskiej 
lub pozostającej pod opieką oraz o umieszczenie dziecka w rodzinie zastępczej 
lub rodzinnym domu dziecka; 
- 3) 
o przesłuchanie świadka testamentu ustnego, o otwarcie i ogłoszenie testamentu 
oraz o zwolnienie z obowiązków wykonawcy testamentu; 

©Kancelaria Sejmu 
 
 
 
 
s. 34/46 
2025-09-24 
- 4) 
będącego podstawą wszczęcia przez sąd postępowania z urzędu, a także od pism 
składanych sądowi opiekuńczemu w wykonaniu obowiązku wynikającego 
z ustawy albo nałożonego przez ten sąd; 
- 5) 
o odtworzenie zaginionych lub zniszczonych akt; 
- 6) 
o wpis w księdze wieczystej prawa własności uzyskanego na podstawie 
przekształcenia, o którym mowa w art. 1 ust. 1a ustawy z dnia 29 lipca 2005 r. 
o przekształceniu prawa użytkowania wieczystego w prawo własności nie-
ruchomości (Dz. U. z 2024 r. poz. 900); 
6a) naczelnika urzędu skarbowego o wpis w księdze wieczystej hipoteki 
przymusowej na zabezpieczenie należności państw członkowskich lub państw 
trzecich w rozumieniu art. 1a pkt 8c i 8d ustawy z dnia 17 czerwca 1966 r. 
o postępowaniu egzekucyjnym w administracji (Dz. U. z 2025 r. poz. 132 i 620); 
- 7) 
o wpis do Krajowego Rejestru Sądowego organizacji pozarządowych oraz 
kościołów i związków wyznaniowych ubiegających się o status organizacji 
pożytku publicznego; 
- 8) 
wynikającego ze zmian w podziale terytorialnym państwa, o wpis w księdze 
wieczystej prawa własności i prawa użytkowania wieczystego na rzecz jednostek 
samorządu terytorialnego; 
- 9) 
o zatwierdzenie ugody zawartej przed mediatorem w wyniku prowadzenia 
mediacji na podstawie umowy o mediację; 
- 10) komornika o wykreślenie w księdze wieczystej wpisu o wszczęciu egzekucji. 
1a. Nie pobiera się opłat od pozwu o odszkodowanie, o którym mowa 
w art. 6 ustawy z dnia 22 listopada 2002 r. o wyrównywaniu strat majątkowych 
wynikających z ograniczenia w czasie stanu nadzwyczajnego wolności i praw 
człowieka i obywatela (Dz. U. poz. 1955). 
1b. Nie pobiera się opłat od pozwu o ochronę dóbr osobistych, gdy sprawa 
dotyczy patriotycznych tradycji zmagań Narodu Polskiego z okupantami, nazizmem i 
komunizmem, wniesionego przez kombatanta w rozumieniu art. 1 ust. 1 ustawy z dnia 
24 stycznia 1991 r. o kombatantach oraz niektórych osobach będących ofiarami 
represji wojennych i okresu powojennego (Dz. U. z 2022 r. poz. 2039) lub jego 
zstępnego, a także osobę prawną lub jednostkę organizacyjną niebędącą osobą prawną, 
której ustawa przyznaje zdolność prawną, których statutowym celem jest ochrona 
patriotycznych tradycji zmagań Narodu Polskiego z okupantami, nazizmem i 
komunizmem.  

©Kancelaria Sejmu 
 
 
 
 
s. 35/46 
2025-09-24 
1c. Nie pobiera się opłat od pozwu o roszczenie majątkowe z tytułu zbrodni 
ludobójstwa, zbrodni przeciwko ludzkości, zbrodni wojennej lub zbrodni agresji.  
1d. Nie pobiera się opłat od pozwu o ochronę dobrego imienia Rzeczypospolitej 
Polskiej lub Narodu Polskiego, o którym mowa w art. 53o i art. 53p ustawy z dnia 18 
grudnia 1998 r. o Instytucie Pamięci Narodowej – Komisji Ścigania Zbrodni 
przeciwko Narodowi Polskiemu (Dz. U. z 2023 r. poz. 102). 
2. Nie pobiera się opłat od: 
- 1) 
zażalenia na postanowienie sądu, którego przedmiotem jest odmowa zwolnienia 
od kosztów sądowych lub cofnięcie takiego zwolnienia oraz odmowa 
ustanowienia adwokata lub radcy prawnego lub ich odwołanie; 
- 2) 
zażalenia na postanowienie sądu dotyczące wysokości opłaty albo wysokości 
wydatków; 
- 3) 
skargi na orzeczenie referendarza sądowego w przedmiocie zwolnienia od 
kosztów sądowych; 
- 4) 
skargi na orzeczenie referendarza sądowego w przedmiocie odmowy 
ustanowienia adwokata lub radcy prawnego. 
3. Nie pobiera się opłat od wniosku, zażalenia i apelacji nieletniego 
w postępowaniu w sprawach nieletnich. 
3a. Nie pobiera się opłat od wniosku, o którym mowa w art. 5603a § 1 ustawy z 
dnia 17 listopada 1964 r. – Kodeks postępowania cywilnego, oraz zażalenia na wydane 
przez Policję albo Żandarmerię Wojskową nakaz opuszczenia wspólnie zajmowanego 
mieszkania i jego bezpośredniego otoczenia i zakaz zbliżania się do mieszkania i jego 
bezpośredniego otoczenia, zakaz zbliżania się do osoby doznającej przemocy 
domowej na wyrażoną w metrach odległość, zakaz kontaktowania się z osobą 
doznającą przemocy domowej lub zakaz wstępu na teren szkoły, placówki oświatowej, 
opiekuńczej lub artystycznej, obiektu sportowego lub miejsca pracy, i przebywania na 
tym terenie. 
4. Nie pobiera się opłat od skargi na orzeczenie referendarza sądowego 
i zażalenia w elektronicznym postępowaniu upominawczym. 
5. Nie pobiera się opłaty od wniosku o doręczenie orzeczenia lub zarządzenia 
wraz z uzasadnieniem, jeżeli strona na mocy ustępów poprzedzających nie ma 
obowiązku uiszczenia opłaty od środka zaskarżenia.
***
## Art. 96. {#art-96}

1. Nie mają obowiązku uiszczenia kosztów sądowych: 
- 1) 
strona dochodząca ustalenia ojcostwa lub macierzyństwa oraz roszczeń z tym 
związanych; 

©Kancelaria Sejmu 
 
 
 
 
s. 36/46 
2025-09-24 
- 2) 
strona dochodząca roszczeń alimentacyjnych oraz strona pozwana w sprawie 
o obniżenie alimentów; 
- 3) 
strona wnosząca o uznanie postanowień umownych za niedozwolone; 
- 4) 
pracownik wnoszący powództwo albo składający wniosek o wszczęcie 
postępowania nieprocesowego, z zastrzeżeniem art. 35 ust. 1 zdanie drugie, lub 
strona wnosząca odwołanie do sądu pracy i ubezpieczeń społecznych; 
- 5) 
kurator wyznaczony przez sąd orzekający lub sąd opiekuńczy dla danej sprawy; 
- 6) 
prokurator, Rzecznik Praw Obywatelskich, Rzecznik Praw Dziecka, Rzecznik 
Praw Pacjenta, Rzecznik Finansowy oraz Rzecznik Małych i Średnich 
Przedsiębiorców; 
- 7) 
powiatowy (miejski) rzecznik konsumentów w sprawach dotyczących praktyk 
ograniczających konkurencję oraz praktyk naruszających zbiorowe interesy 
konsumentów; 
7a) podmiot upoważniony, o którym mowa w art. 46a ustawy z dnia 16 lutego 
2007 r. o ochronie konkurencji i konsumentów (Dz. U. z 2024 r. poz. 1616 oraz 
z 2025 r. poz. 794), w sprawach o stwierdzenie stosowania praktyk 
naruszających ogólne interesy konsumentów oraz w sprawach o roszczenia 
związane z ich stosowaniem; 
- 8) 
inspektor pracy oraz związki zawodowe w sprawach z zakresu prawa pracy; 
- 9) 
strona w sprawach związanych z ochroną zdrowia psychicznego; 
9a) osoba 
ubezwłasnowolniona 
w sprawach 
o uchylenie 
lub 
zmianę 
ubezwłasnowolnienia; 
- 10) strona, która została zwolniona od kosztów sądowych przez sąd – w zakresie 
przyznanego jej zwolnienia; 
- 11) powiatowy (miejski) rzecznik konsumentów w sprawach dotyczących ochrony 
indywidualnych interesów konsumenta; 
- 12) strona dochodząca naprawienia szkód spowodowanych ruchem zakładu 
górniczego, o których mowa w dziale VIII ustawy z dnia 9 czerwca 2011 r. – 
Prawo geologiczne i górnicze (Dz. U. z 2024 r. poz. 1290 oraz z 2025 r. poz. 769 
i 1023); 
- 13) osoba ubiegająca się o uzyskanie kompensaty na podstawie ustawy z dnia 7 lipca 
2005 r. o państwowej kompensacie przysługującej ofiarom niektórych czynów 
zabronionych (Dz. U. z 2016 r. poz. 325); 

©Kancelaria Sejmu 
 
 
 
 
s. 37/46 
2025-09-24 
- 14) strona w sprawach dotyczących wypłat oraz zwrotu należności powstałych 
w wyniku realizacji przepisów z zakresu ochrony roszczeń pracowniczych 
w razie niewypłacalności pracodawcy; 
- 15) osoba doznająca przemocy domowej w sprawach z zakresu przeciwdziałania 
przemocy domowej; 
- 16) osoba wnosząca pozew o przyznanie renty na podstawie przepisów art. 444 § 2 
lub art. 446 § 2 ustawy z dnia 23 kwietnia 1964 r. – Kodeks cywilny (Dz. U. 
z 2025 r. poz. 1071 i 1172) lub występująca z żądaniem udzielenia 
zabezpieczenia takiego roszczenia; 
- 17) osoba wnosząca odwołanie od postanowień Państwowej Komisji do spraw 
przeciwdziałania wykorzystaniu seksualnemu małoletnich poniżej lat 15, 
o których mowa w art. 37 ust. 1 ustawy z dnia 30 sierpnia 2019 r. o Państwowej 
Komisji do spraw przeciwdziałania wykorzystaniu seksualnemu małoletnich 
poniżej lat 15 (Dz. U. z 2024 r. poz. 94); 
- 18) osoba wnosząca apelację od decyzji administracyjnej Państwowej Komisji do 
spraw 
badania 
wpływów 
rosyjskich 
na bezpieczeństwo 
wewnętrzne 
Rzeczypospolitej Polskiej w latach 2007–2022, o której mowa w art. 36 pkt 1 
ustawy z dnia 14 kwietnia 2023 r. o Państwowej Komisji do spraw badania 
wpływów rosyjskich na bezpieczeństwo wewnętrzne Rzeczypospolitej Polskiej 
w latach 2007–2022 (Dz. U. z 2024 r. poz. 548). 
2. Za kuratora wydatki ponosi tymczasowo strona, dla której kurator został 
ustanowiony, a gdyby to nie było możliwe – strona, która swym wnioskiem lub swą 
czynnością spowodowała ustanowienie kuratora, chyba że przepis szczególny stanowi 
inaczej. 
3. W pozostałych wypadkach, o których mowa w ust. 1, za stronę zwolnioną od 
kosztów sądowych wydatki ponosi tymczasowo Skarb Państwa. 
4. W wypadku gdy powództwo o ustalenie ojcostwa okaże się oczywiście 
bezzasadne, sąd w orzeczeniu kończącym postępowanie w sprawie może obciążyć 
powoda nieuiszczonymi kosztami sądowymi, biorąc pod uwagę wszystkie 
okoliczności sprawy.
***
## Art. 97. {#art-97}

W toku postępowania w sprawach z zakresu prawa pracy o roszczenia 
pracownika wydatki obciążające pracownika ponosi tymczasowo Skarb Państwa. Sąd 
pracy w orzeczeniu kończącym postępowanie w instancji rozstrzyga o tych 
wydatkach, stosując odpowiednio przepisy art. 113, z tym że obciążenie pracownika 
tymi wydatkami może nastąpić w wypadkach szczególnie uzasadnionych. 

©Kancelaria Sejmu 
 
 
 
 
s. 38/46 
2025-09-24
***
## Art. 98. {#art-98}

W toku postępowania w sprawach z zakresu ubezpieczeń społecznych 
wydatki ponosi Skarb Państwa. 
Art. 98a. W postępowaniu 
prowadzonym 
na 
podstawie 
ustawy 
z dnia 
22 listopada 2013 r. o postępowaniu wobec osób z zaburzeniami psychicznymi 
stwarzających zagrożenie życia, zdrowia lub wolności seksualnej innych osób (Dz. U. 
z 2022 r. poz. 1689) nie pobiera się opłat, a wydatki ponosi Skarb Państwa. 
Art. 98b. W elektronicznym postępowaniu upominawczym wydatki ponosi 
Skarb Państwa.
***
## Art. 99. {#art-99}

Nie pobiera się opłaty sądowej, a uiszczoną opłatę zwraca się, jeżeli 
zażalenie, wniesione na zarządzenie przewodniczącego o zwrocie pisma albo na 
postanowienie sądu o odrzuceniu środka zaskarżenia, sąd uzna za oczywiście 
uzasadnione.
***
## Art. 100. {#art-100}

1. Strona w całości zwolniona od kosztów sądowych z mocy ustawy 
nie uiszcza opłat sądowych i nie ponosi wydatków, które obciążają tymczasowo Skarb 
Państwa. 
2. Sąd może zwolnić stronę od kosztów sądowych w całości. Przepis 
ust. 1 stosuje się odpowiednio.
***
## Art. 101. {#art-101}

1. Sąd może zwolnić stronę od kosztów sądowych w części, jeżeli 
strona jest w stanie ponieść tylko część tych kosztów. 
2. Częściowe zwolnienie od tych kosztów może polegać na zwolnieniu od 
poniesienia albo ułamkowej lub procentowej ich części, albo określonej ich kwoty, 
albo niektórych opłat lub wydatków. Może też polegać na przyznaniu zwolnienia 
co do pewnej części roszczenia lub co do niektórych roszczeń dochodzonych łącznie; 
roszczenia te lub ich części sąd oznacza w postanowieniu o przyznaniu częściowego 
zwolnienia od kosztów sądowych. 
3. Strona częściowo zwolniona od kosztów sądowych obowiązana jest uiścić 
opłaty oraz ponieść wydatki w takiej wysokości, jaka nie jest objęta zwolnieniem 
przyznanym przez sąd. Przepis art. 100 ust. 1 stosuje się odpowiednio.
***
## Art. 102. {#art-102}

1. Zwolnienia od kosztów sądowych może się domagać osoba 
fizyczna, jeżeli złoży oświadczenie, z którego wynika, że nie jest w stanie ich ponieść 
bez uszczerbku utrzymania koniecznego dla siebie i rodziny lub ich poniesienie narazi 
ją na taki uszczerbek. 

©Kancelaria Sejmu 
 
 
 
 
s. 39/46 
2025-09-24 
2. Do wniosku o zwolnienie od kosztów sądowych powinno być dołączone 
oświadczenie obejmujące szczegółowe dane o stanie rodzinnym, majątku, dochodach 
i źródłach utrzymania osoby ubiegającej się o zwolnienie od kosztów. Oświadczenie 
sporządza się według ustalonego wzoru. Jeżeli oświadczenie nie zostało złożone albo 
nie zawiera wszystkich wymaganych danych, stosuje się art. 130 ustawy z dnia 
17 listopada 1964 r. – Kodeks postępowania cywilnego. 
3. Sąd może odebrać od osoby ubiegającej się o zwolnienie od kosztów 
sądowych 
przyrzeczenie 
o treści: 
„Świadomy 
znaczenia 
mych 
słów 
i odpowiedzialności przed prawem zapewniam, że złożone przeze mnie oświadczenie 
o stanie rodzinnym, majątku, dochodach i źródłach utrzymania jest prawdziwe 
i rzetelne”. Przed odebraniem przyrzeczenia należy pouczyć osobę ubiegającą się 
o zwolnienie od kosztów sądowych o treści art. 111. 
4. Wniosek o zwolnienie od kosztów strony reprezentowanej przez adwokata lub 
radcę prawnego złożony bez dołączenia oświadczenia, o którym mowa w ust. 2, 
przewodniczący zwraca bez wzywania o uzupełnienie braków formalnych wniosku 
o zwolnienie od kosztów sądowych. 
5. Wniosek o zwolnienie od kosztów sądowych podlega rozpoznaniu w terminie 
7 dni od dnia złożenia albo uzupełnienia jego braków formalnych.
***
## Art. 103. {#art-103}

1. Sąd może przyznać zwolnienie od kosztów sądowych osobie 
prawnej lub jednostce organizacyjnej niebędącej osobą prawną, której ustawa 
przyznaje zdolność prawną, jeżeli wykazała, że nie ma dostatecznych środków na ich 
uiszczenie. 
2. Spółka osobowa powinna wykazać również, że jej wspólnicy, którzy ponoszą 
odpowiedzialność za jej zobowiązania, nie mają dostatecznych środków na 
zwiększenie majątku spółki lub udzielenie spółce pożyczki. 
3. (uchylony)
***
## Art. 104. {#art-104}

1. Nie mają obowiązku uiszczania opłat organizacje pożytku 
publicznego działające na podstawie przepisów o działalności pożytku publicznego 
i o wolontariacie, z wyjątkiem spraw dotyczących prowadzonej przez te organizacje 
działalności gospodarczej, stowarzyszenia ogrodowe w rozumieniu ustawy z dnia 
13 grudnia 2013 r. o rodzinnych ogrodach działkowych (Dz. U. z 2021 r. poz. 1073), 
a także organizacje pozarządowe oraz podmioty wymienione w art. 3 ust. 3 ustawy 
z dnia 24 kwietnia 2003 r. o działalności pożytku publicznego i o wolontariacie 
(Dz. U. z 2024 r. poz. 1491, 1761 i 1940) w sprawach dotyczących realizacji 

©Kancelaria Sejmu 
 
 
 
 
s. 40/46 
2025-09-24 
zleconego zadania publicznego na podstawie przepisów o działalności pożytku 
publicznego i o wolontariacie. 
2. Innym organizacjom pozarządowym, których zadanie nie polega na 
prowadzeniu działalności gospodarczej, sąd może przyznać zwolnienie od kosztów 
sądowych w ich własnych sprawach prowadzonych w związku z działalnością 
społeczną, naukową, oświatową, kulturalną, sportową, dobroczynną, samopomocową, 
w zakresie ochrony konsumenta, ochrony środowiska i opieki społecznej. Przyznając 
zwolnienie od kosztów sądowych, sąd uwzględnia przede wszystkim statutowe cele 
działalności danej organizacji i możliwości oraz potrzeby realizacji tych celów na 
drodze postępowania cywilnego. 
Art. 104a. W elektronicznym postępowaniu upominawczym oraz do złożenia 
wniosku o wpis do Krajowego Rejestru Sądowego spółki, której umowa została 
zawarta przy wykorzystaniu wzorca umowy udostępnionego w systemie tele-
informatycznym, przepisów art. 96 ust. 1 pkt 10, art. 100–103, art. 104 ust. 2 
i art. 105 nie stosuje się.
***
## Art. 105. {#art-105}

1. Wniosek o przyznanie zwolnienia od kosztów sądowych należy 
zgłosić na piśmie lub ustnie do protokołu w sądzie, w którym sprawa ma być 
wytoczona lub już się toczy. W razie złożenia wniosku ustnie do protokołu, 
oświadczenie, o którym mowa w art. 102 ust. 2, może być złożone także do protokołu. 
2. Osoba fizyczna, która nie ma miejsca zamieszkania w siedzibie tego sądu, 
może złożyć wniosek o przyznanie zwolnienia od kosztów sądowych w sądzie 
rejonowym właściwym ze względu na miejsce swego zamieszkania. Sąd przesyła 
niezwłocznie ten wniosek właściwemu sądowi. 
Art. 105a. Jeżeli wniosek o zwolnienie od kosztów sądowych zgłoszony przed 
upływem terminu do opłacenia pisma został prawomocnie zwrócony, przewodniczący 
wzywa stronę do opłacenia złożonego pisma na podstawie art. 130 ustawy z dnia 
17 listopada 1964 r. – Kodeks postępowania cywilnego. Ponowny wniosek 
o zwolnienie od tych samych kosztów jest niedopuszczalny i pozostawia się go 
w aktach sprawy bez żadnych dalszych czynności. Przepisy art. 107 ust. 2 i art. 112 
ust. 4 stosuje się odpowiednio.
***
## Art. 106. {#art-106}

1. 
Zwolnienie 
od 
kosztów 
sądowych 
w postępowaniu 
wieczystoksięgowym może nastąpić wyłącznie przed złożeniem wniosku o wpis do 
księgi wieczystej. 

©Kancelaria Sejmu 
 
 
 
 
s. 41/46 
2025-09-24 
2. Jeżeli wniosek o dokonanie wpisu do księgi wieczystej ma być zamieszczony 
w akcie notarialnym, zwolnienie od kosztów sądowych może nastąpić wyłącznie 
przed zawarciem tego aktu notarialnego. 
3. Wniosek o dokonanie wpisu do księgi wieczystej powinien być złożony 
w terminie 3 miesięcy od doręczenia postanowienia o zwolnieniu od kosztów 
sądowych, pod rygorem upadku zwolnienia. 
4. Przepisów ust. 1 i 2 nie stosuje się, jeżeli obowiązek poniesienia kosztów 
sądowych powstał po wydaniu orzeczenia, w postępowaniu wieczystoksięgowym.
***
## Art. 107. {#art-107}

1. W razie oddalenia wniosku o zwolnienie od kosztów sądowych 
strona nie może ponownie domagać się zwolnienia powołując się na te same 
okoliczności, które stanowiły uzasadnienie oddalonego wniosku. 
2. Ponowny wniosek o zwolnienie od kosztów sądowych oparty na tych samych 
okolicznościach jest niedopuszczalny i pozostawia się go w aktach sprawy bez 
żadnych dalszych czynności. To samo dotyczy pism związanych z jego wniesieniem. 
O pozostawieniu wniosku i pism związanych z jego wniesieniem w aktach sprawy 
zawiadamia się stronę wnoszącą tylko raz – przy złożeniu pierwszego pisma.
***
## Art. 108. {#art-108}

Zwolnienie od kosztów sądowych nie zwalnia strony od obowiązku 
zwrotu kosztów procesu przeciwnikowi.
***
## Art. 109. {#art-109}

1. Sąd może zarządzić stosowne dochodzenie, jeżeli na podstawie 
okoliczności sprawy lub oświadczeń strony przeciwnej powziął wątpliwości co do 
rzeczywistego stanu majątkowego strony domagającej się zwolnienia od kosztów 
sądowych lub z niego korzystającej. 
2. Sąd odmawia zwolnienia od kosztów sądowych stronie w razie oczywistej 
bezzasadności dochodzonego roszczenia lub obrony praw.
***
## Art. 110. {#art-110}

Sąd cofa zwolnienie od kosztów sądowych, jeżeli okazało się, że 
okoliczności, na podstawie których je przyznano, nie istniały lub przestały istnieć. 
W obu wypadkach strona obowiązana jest uiścić wszystkie przepisane opłaty oraz 
zwrócić wydatki, jednakże w drugim wypadku sąd może obciążyć stronę tym 
obowiązkiem także częściowo, stosownie do zmiany, jaka nastąpiła w jej stosunkach. 
W takim wypadku stosuje się przepis art. 111.
***
## Art. 111. {#art-111}

1. Stronę, która uzyskała zwolnienie od kosztów sądowych na 
podstawie świadomego podania nieprawdziwych okoliczności, sąd, cofając 
zwolnienie, skazuje na grzywnę w wysokości do 1000 złotych. Niezależnie od 

©Kancelaria Sejmu 
 
 
 
 
s. 42/46 
2025-09-24 
obowiązku uiszczenia grzywny strona powinna uiścić wszystkie przepisane opłaty 
i pokryć obciążające ją wydatki. 
2. Osobę, która ponownie zgłosiła wniosek o zwolnienie od kosztów sądowych, 
świadomie podając nieprawdziwe okoliczności o stanie rodzinnym, majątku, 
dochodach i źródłach utrzymania, sąd, odrzucając wniosek, skazuje na grzywnę 
w wysokości do 2000 złotych. 
Art. 111a. Postanowienie o odmowie zwolnienia od kosztów sądowych lub 
o cofnięciu takiego zwolnienia doręcza się tylko stronie, która złożyła wniosek 
o zwolnienie od kosztów.
***
## Art. 112. {#art-112}

1. Zgłoszenie wniosku o zwolnienie od kosztów sądowych oraz 
wniesienie środka odwoławczego od postanowienia o odmowie zwolnienia od 
kosztów sądowych nie wstrzymuje biegu toczącego się postępowania, chyba że chodzi 
o zwolnienie powoda od kosztów sądowych na skutek wniosku zgłoszonego w pozwie 
lub przed wytoczeniem powództwa. 
2. Jeżeli wniosek o zwolnienie od kosztów sądowych zgłoszony przed upływem 
terminu do opłacenia pisma został prawomocnie oddalony, przewodniczący wzywa 
stronę do opłacenia złożonego pisma, na podstawie art. 130 ustawy z dnia 17 listopada 
1964 r. – Kodeks postępowania cywilnego. 
3. Przepisu ust. 2 nie stosuje się, jeżeli pismo podlegające opłacie w wysokości 
stałej lub stosunkowej obliczonej od wskazanej przez stronę wartości przedmiotu 
sporu lub wartości przedmiotu zaskarżenia, zostało wniesione przez adwokata, radcę 
prawnego lub rzecznika patentowego. W takim przypadku, jeżeli wniosek 
o zwolnienie od kosztów sądowych złożony przed upływem terminu do opłacenia 
pisma został oddalony, tygodniowy termin do opłacenia pisma biegnie od dnia 
doręczenia stronie postanowienia, a gdy postanowienie zostało wydane na posiedzeniu 
jawnym – od dnia jego ogłoszenia. Jeżeli jednak o zwolnieniu od kosztów sądowych 
orzekał sąd pierwszej instancji, a strona wniosła zażalenie w przepisanym terminie, 
termin do opłacenia pisma biegnie od dnia doręczenia stronie postanowienia 
oddalającego zażalenie, a jeżeli postanowienie sądu drugiej instancji zostało wydane 
na posiedzeniu jawnym – od dnia jego ogłoszenia. 
4. Ponowny wniosek o zwolnienie od kosztów sądowych, oparty na tych samych 
okolicznościach, nie ma wpływu na bieg terminu do opłacenia pisma.
***
## Art. 113. {#art-113}

1. Kosztami sądowymi, których strona nie miała obowiązku uiścić lub 
których nie miał obowiązku uiścić kurator albo prokurator, sąd w orzeczeniu 

©Kancelaria Sejmu 
 
 
 
 
s. 43/46 
2025-09-24 
kończącym sprawę w instancji obciąży przeciwnika, jeżeli istnieją do tego podstawy, 
przy odpowiednim zastosowaniu zasad obowiązujących przy zwrocie kosztów 
procesu. 
2. Koszty nieobciążające przeciwnika sąd w orzeczeniu kończącym sprawę 
w instancji nakazuje ściągnąć z roszczenia zasądzonego na rzecz: 
- 1) 
strony, której czynność spowodowała ich powstanie; 
- 2) 
strony zastąpionej przez kuratora lub 
- 3) 
osoby, na której rzecz prokurator wytoczył powództwo lub zgłosił wniosek 
o wszczęcie postępowania. 
3. Koszty sądowe, których nie miał obowiązku uiścić kurator, sąd może nakazać 
ściągnąć z innego majątku strony zastąpionej przez kuratora. 
3a. Koszty sądowe, których nie miał obowiązku uiścić wnioskodawca lub 
uczestnik w sprawie o zabezpieczenie spadku lub sporządzenie spisu inwentarza, sąd 
może nakazać ściągnąć także ze spadku. 
4. W przypadkach 
szczególnie 
uzasadnionych 
sąd 
może 
odstąpić 
od 
przewidzianego w ust. 2–3a obciążenia kosztami. 
5. Przepisu ust. 2 nie stosuje się do opłat, których nie miał obowiązku uiścić 
Skarb Państwa.
***
## Art. 114. {#art-114}

W wypadkach uregulowanych w art. 113 ust. 2 i 3 Skarbowi Państwa 
przysługuje na zasądzonym roszczeniu ustawowe prawo zastawu.
***
## Art. 115. {#art-115}

Należność Skarbu Państwa z tytułu kosztów sądowych obciążających 
przeciwnika strony podlega zaspokojeniu w postępowaniu egzekucyjnym lub 
upadłościowym w tej samej kolejności i w tych samych granicach, co należność tej 
strony z tytułu zasądzonego na jej rzecz zwrotu kosztów procesu. 
Art. 115a. W celu zaspokojenia należności z tytułu kosztów sądowych, 
o których mowa w art. 113 ust. 3a, sąd może pobrać odpowiednią sumę z pieniędzy 
wchodzących w skład spadku złożonych do depozytu sądowego lub znajdujących się 
na rachunku bankowym lub rachunku prowadzonym przez spółdzielczą kasę 
oszczędnościowo-kredytową. Sąd może również zarządzić sprzedaż przez komornika 
odpowiedniego przedmiotu należącego do spadku, oznaczając przy tym sposób 
sprzedaży.
***
## Art. 116. {#art-116}

Roszczenie Skarbu Państwa o uiszczenie kosztów sądowych 
przedawnia się z upływem trzech lat, licząc od dnia, w którym nastąpiło prawomocne 
zakończenie sprawy. 

©Kancelaria Sejmu 
 
 
 
 
s. 44/46 
2025-09-24
***
## Art. 117. {#art-117}

Strony mogą w ugodzie sądowej ustalić, którą z nich i w jakiej części 
mają obciążać nieuiszczone koszty sądowe. Jeżeli ugoda nie stanowi inaczej, 
w sprawie zakończonej ugodą koszty, o których mowa w art. 113 ust. 1, ponoszą obie 
strony w równych częściach. Przepisy art. 113 ust. 2–5 stosuje się odpowiednio.
***
## Art. 118. {#art-118}

Czynności w zakresie zwalniania od kosztów sądowych, przewidziane 
w ustawie, może wykonywać referendarz sądowy. 
TYTUŁ V 
Wykonanie orzeczeń w zakresie należności sądowych
***
## Art. 119. {#art-119}

Zapłata należności Skarbu Państwa z tytułu nieuiszczonych kosztów 
sądowych oraz grzywien orzeczonych w postępowaniu cywilnym, zwanych dalej 
„należnościami sądowymi”, może być rozłożona na raty albo umorzona, jeżeli 
natychmiastowe ich ściągnięcie byłoby połączone z niewspółmiernymi trudnościami 
lub groziłoby dłużnikowi zbyt ciężkimi skutkami.
***
## Art. 120. {#art-120}

1. Zapłata należności sądowych może być na wniosek dłużnika 
rozłożona na raty lub odroczona na okres do dwóch lat, a w wyjątkowych wypadkach 
na okres do trzech lat. Niezapłacenie którejkolwiek raty w terminie powoduje 
natychmiastową wymagalność pozostałej części należności. 
2. Rozłożenie na raty lub odroczenie terminu zapłaty może być cofnięte w razie 
stwierdzenia, że nie istnieją już okoliczności, które je uzasadniały. 
3. Zapłata sumy niższej niż trzykrotna wysokość opłaty podstawowej nie może 
być rozłożona na raty.
***
## Art. 121. {#art-121}

Należności sądowe mogą być umorzone na wniosek dłużnika w całości 
albo w części, jeżeli wykazał on, że ze względu na swoją sytuację rodzinną, majątkową 
i wysokość dochodów nie jest w stanie ich uiścić, a ściągnięcie należności 
pociągnęłoby wyjątkowo ciężkie skutki dla niego lub jego rodziny. Do wniosku 
dłużnik powinien dołączyć oświadczenie, o którym mowa w art. 102 ust. 2. 
Art. 121a. Należności sądowe podlegają umorzeniu na wniosek dłużnika w razie 
stwierdzenia przez Europejski Trybunał Praw Człowieka, że w postępowaniu, 
w którym je zasądzono, naruszono wobec dłużnika Konwencję o ochronie praw 

©Kancelaria Sejmu 
 
 
 
 
s. 45/46 
2025-09-24 
człowieka i podstawowych wolności, sporządzoną w Rzymie dnia 4 listopada 1950 r. 
(Dz. U. z 1993 r. poz. 284, z późn. zm.3)) lub Protokoły dodatkowe do tej Konwencji.
***
## Art. 122. {#art-122}

Należności sądowe mogą być umorzone w całości albo w części 
z urzędu, jeżeli ich egzekucja okazała się bezskuteczna, a ponowne jej wszczęcie 
w późniejszym czasie byłoby bezcelowe.
***
## Art. 123. {#art-123}

O rozłożeniu na raty lub umorzeniu należności sądowych orzeczonych 
w postępowaniu przed sądami powszechnymi oraz przed Sądem Najwyższym 
rozstrzyga ostatecznie prezes sądu właściwego do rozpoznania sprawy w pierwszej 
instancji. Uprawnienia te przysługują również kierownikowi ośrodka zamiejscowego 
sądu lub przewodniczącemu wydziału zamiejscowego sądu.
***
## Art. 124. {#art-124}

1. Wnioski o rozłożenie na raty lub umorzenie należności sądowych 
wnosi się do prezesa sądu właściwego do rozpoznania sprawy w pierwszej instancji. 
2. Po rozpoznaniu wniosku o rozłożenie na raty lub umorzenie należności 
sądowych, albo w razie wystąpienia okoliczności dających podstawę do wszczęcia 
postępowania o umorzenie należności sądowych z urzędu, prezes sądu wydaje 
stosowne zarządzenie.
***
## Art. 125. {#art-125}

Czynności w sprawach odroczenia lub rozłożenia na raty należności 
sądowych może – na zarządzenie prezesa sądu rejonowego lub okręgowego – 
wykonywać referendarz sądowy. Na zarządzenie referendarza przysługuje skarga do 
sądu. 
TYTUŁ VI 
Zmiany w przepisach obowiązujących 
Art. 126–147. (pominięte) 
TYTUŁ VII 
Przepisy przejściowe i końcowe
***
## Art. 148. {#art-148}

1. Jeżeli obowiązujące przepisy powołują się na przepisy ustawy 
o kosztach sądowych w sprawach cywilnych albo odsyłają ogólnie do tych przepisów, 
stosuje się odpowiednie przepisy niniejszej ustawy. 
- 3) Zmiany wymienionej Konwencji zostały ogłoszone w Dz. U. z 1993 r. poz. 285, z 1995 r. poz. 175, 
176 i 177, z 1998 r. poz. 962, z 2001 r. poz. 266, z 2003 r. poz. 364, z 2010 r. poz. 587, z 2021 r. 
poz. 2161 oraz z 2022 r. poz. 643. 

©Kancelaria Sejmu 
 
 
 
 
s. 46/46 
2025-09-24 
2. Do czasu wydania przepisów wykonawczych na podstawie ustawy zachowują 
moc przepisy wydane przed wejściem w życie ustawy.
***
## Art. 149. {#art-149}

1. W sprawach wszczętych przed dniem wejścia w życie ustawy 
stosuje się, do czasu zakończenia postępowania w danej instancji, dotychczasowe 
przepisy o kosztach sądowych. 
2. W sprawach egzekucyjnych wszczętych przed dniem wejścia w życie ustawy 
dotychczasowe przepisy o kosztach sądowych stosuje się aż do zakończenia 
postępowania.
***
## Art. 150. {#art-150}

Traci moc ustawa z dnia 13 czerwca 1967 r. o kosztach sądowych 
w sprawach cywilnych (Dz. U. z 2002 r. poz. 88, z późn. zm.4)).
***
## Art. 151. {#art-151}

Ustawa wchodzi w życie po upływie sześciu miesięcy od dnia 
ogłoszenia5). 
- 4) Zmiany tekstu jednolitego wymienionej ustawy zostały ogłoszone w Dz. U. z 2002 r. poz. 1955, 
z 2003 r. poz. 391, 874 i 1323, z 2004 r. poz. 2135 oraz z 2005 r. poz. 609. 
- 5) Ustawa została ogłoszona w dniu 1 września 2005 r.
